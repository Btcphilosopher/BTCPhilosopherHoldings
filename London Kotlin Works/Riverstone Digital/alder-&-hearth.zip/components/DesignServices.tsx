'use client';

import React, { useState } from 'react';
import { ArrowRight, Copy, Check, Download, AlertCircle, FileText, Sparkles, RefreshCw } from 'lucide-react';
import { Product } from '@/lib/data';

interface DesignServicesProps {
  savedProducts: Product[];
  prefilledProductId?: string | null;
}

interface FormState {
  fullName: string;
  email: string;
  roomType: string;
  approxBudget: string;
  preferredMaterials: string[];
  timeline: string;
  projectDescription: string;
  includeSavedPieces: boolean;
}

export function DesignServices({ savedProducts, prefilledProductId }: DesignServicesProps) {
  const [form, setForm] = useState<FormState>({
    fullName: '',
    email: '',
    roomType: 'living',
    approxBudget: '$25,000 – $50,000',
    preferredMaterials: ['American Black Walnut', 'Belgian Linen'],
    timeline: '3–6 Months',
    projectDescription: '',
    includeSavedPieces: true,
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isCompiled, setIsCompiled] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [briefRefId, setBriefRefId] = useState<string>('AH-782104');

  const materialOptions = [
    'American Black Walnut',
    'Quartersawn White Oak',
    'Oatmeal Belgian Linen',
    'Saddle & Cognac Leather',
    'Champlain Valley Limestone',
  ];

  const handleMaterialToggle = (material: string) => {
    setForm((prev) => {
      const exists = prev.preferredMaterials.includes(material);
      const updated = exists
        ? prev.preferredMaterials.filter((m) => m !== material)
        : [...prev.preferredMaterials, material];
      return { ...prev, preferredMaterials: updated };
    });
  };

  const validate = (): boolean => {
    const errs: Record<string, string> = {};

    if (!form.fullName.trim() || form.fullName.trim().length < 2) {
      errs.fullName = 'Please enter your full name (minimum 2 characters).';
    }

    if (!form.email.trim()) {
      errs.email = 'Please provide an email address for your records.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) {
      errs.email = 'Please enter a valid email address (e.g., name@domain.com).';
    }

    if (form.preferredMaterials.length === 0) {
      errs.materials = 'Please select at least one preferred material.';
    }

    if (!form.projectDescription.trim() || form.projectDescription.trim().length < 15) {
      errs.projectDescription = 'Please describe your space or architectural goals (minimum 15 characters).';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      setBriefRefId(`AH-${Math.floor(100000 + Math.random() * 900000)}`);
      setIsCompiled(true);
    }
  };

  const generateBriefText = (): string => {
    const piecesIncluded =
      form.includeSavedPieces && savedProducts.length > 0
        ? savedProducts.map((p) => `- ${p.name} ($${p.priceUSD.toLocaleString()} USD) - ${p.primaryMaterial}`).join('\n')
        : 'None selected yet';

    return `==========================================================
ALDER & HEARTH · BESPOKE DESIGN CONSULTATION BRIEF
Concept Furniture Portfolio · Hudson Valley, New York
Brief Reference: ${briefRefId}
==========================================================

CLIENT INFORMATION:
- Name: ${form.fullName}
- Email: ${form.email}

PROJECT SPECIFICATIONS:
- Primary Space: ${form.roomType.toUpperCase()}
- Approximate Budget Tier: ${form.approxBudget}
- Desired Execution Timeline: ${form.timeline}
- Preferred Material Palette: ${form.preferredMaterials.join(', ')}

PROJECT NARRATIVE & REQUIREMENTS:
${form.projectDescription}

SHORTLISTED PIECES FOR INCLUSION:
${piecesIncluded}

----------------------------------------------------------
NOTE: This consultation brief was generated in the Alder & Hearth
concept demonstration application. No remote server was contacted.
Keep this brief for architectural references and material planning.
==========================================================`;
  };

  const handleCopyClipboard = async () => {
    const brief = generateBriefText();
    try {
      await navigator.clipboard.writeText(brief);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch (err) {
      console.warn('Clipboard write failed:', err);
    }
  };

  const handleDownload = () => {
    const brief = generateBriefText();
    const blob = new Blob([brief], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Alder_and_Hearth_Brief_${form.fullName.replace(/\s+/g, '_')}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <section id="design-services" className="py-20 lg:py-28 bg-[#FAF8F5] border-b border-[#D8D0C4]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mb-12">
          <div className="flex items-center gap-2 text-xs tracking-[0.2em] uppercase font-sans-clean text-[#757969] mb-3">
            <span className="w-6 h-px bg-[#757969]" />
            <span>Studio Design Services</span>
          </div>

          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-6 border-b border-[#D8D0C4]">
            <div>
              <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-light text-[#28231F] text-balance">
                Plan a room. Tailor a piece.
              </h2>
            </div>
            <p className="text-sm text-[#757969] max-w-md">
              Whether curating a complete living residence or commissioning a bespoke length for the Fieldstone
              table, our studio collaborates closely with clients and architects.
            </p>
          </div>
        </div>

        {/* 3 Steps Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="p-6 bg-[#F5F1E9] border border-[#D8D0C4]">
            <span className="text-xs uppercase tracking-widest text-[#A36D47] font-semibold block mb-2">
              Phase 01 · Spatial Vision
            </span>
            <h3 className="font-serif-luxury text-xl text-[#28231F] mb-2">
              Proportion &amp; Daylight Study
            </h3>
            <p className="text-xs text-[#49372B]/80 leading-relaxed font-light">
              We review your floorplans, architectural elevations, and natural light orientations to suggest
              restrained silhouettes that breathe.
            </p>
          </div>

          <div className="p-6 bg-[#F5F1E9] border border-[#D8D0C4]">
            <span className="text-xs uppercase tracking-widest text-[#A36D47] font-semibold block mb-2">
              Phase 02 · Material Palette
            </span>
            <h3 className="font-serif-luxury text-xl text-[#28231F] mb-2">
              Tactile Swatches &amp; Timber
            </h3>
            <p className="text-xs text-[#49372B]/80 leading-relaxed font-light">
              Selecting matching walnut grain logs, unbleached flax weights, and hand-honed stone finishes
              curated for your home&apos;s micro-climate.
            </p>
          </div>

          <div className="p-6 bg-[#F5F1E9] border border-[#D8D0C4]">
            <span className="text-xs uppercase tracking-widest text-[#A36D47] font-semibold block mb-2">
              Phase 03 · Workshop Craft
            </span>
            <h3 className="font-serif-luxury text-xl text-[#28231F] mb-2">
              Heirloom Joinery &amp; Delivery
            </h3>
            <p className="text-xs text-[#49372B]/80 leading-relaxed font-light">
              Individual bench-crafted assembly by master woodworkers in Upstate New York, accompanied by white-glove
              placement.
            </p>
          </div>
        </div>

        {/* Planner Workspace */}
        <div className="bg-[#F5F1E9] border border-[#D8D0C4] p-6 sm:p-10 lg:p-12">
          {!isCompiled ? (
            /* Consultation Input Form */
            <form onSubmit={handleSubmit} className="space-y-8" noValidate>
              <div>
                <h3 className="font-serif-luxury text-2xl sm:text-3xl text-[#28231F] mb-2">
                  Design Consultation Planner
                </h3>
                <p className="text-xs sm:text-sm text-[#757969]">
                  Compile an architectural brief for your residence. Your specifications remain private and can be
                  copied or downloaded for your records.
                </p>
              </div>

              {/* Client Info Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="fullName" className="block text-xs uppercase tracking-wider font-semibold text-[#49372B] mb-2">
                    Full Name <span className="text-[#A36D47]">*</span>
                  </label>
                  <input
                    id="fullName"
                    type="text"
                    value={form.fullName}
                    onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                    placeholder="e.g. Eleanor Vance"
                    aria-describedby={errors.fullName ? 'fullName-error' : undefined}
                    className={`w-full bg-[#FAF8F5] border text-[#28231F] text-sm py-2.5 px-3 rounded-xs focus-visible:outline-2 focus-visible:outline-[#49372B] ${
                      errors.fullName ? 'border-red-600' : 'border-[#D8D0C4]'
                    }`}
                  />
                  {errors.fullName && (
                    <p id="fullName-error" className="mt-1.5 text-xs text-red-700 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>{errors.fullName}</span>
                    </p>
                  )}
                </div>

                <div>
                  <label htmlFor="email" className="block text-xs uppercase tracking-wider font-semibold text-[#49372B] mb-2">
                    Email Address <span className="text-[#A36D47]">*</span>
                  </label>
                  <input
                    id="email"
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    placeholder="e.g. eleanor@vance-studio.com"
                    aria-describedby={errors.email ? 'email-error' : undefined}
                    className={`w-full bg-[#FAF8F5] border text-[#28231F] text-sm py-2.5 px-3 rounded-xs focus-visible:outline-2 focus-visible:outline-[#49372B] ${
                      errors.email ? 'border-red-600' : 'border-[#D8D0C4]'
                    }`}
                  />
                  {errors.email && (
                    <p id="email-error" className="mt-1.5 text-xs text-red-700 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>{errors.email}</span>
                    </p>
                  )}
                </div>
              </div>

              {/* Room Type & Budget */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                <div>
                  <label htmlFor="roomType" className="block text-xs uppercase tracking-wider font-semibold text-[#49372B] mb-2">
                    Primary Space
                  </label>
                  <select
                    id="roomType"
                    value={form.roomType}
                    onChange={(e) => setForm({ ...form, roomType: e.target.value })}
                    className="w-full bg-[#FAF8F5] border border-[#D8D0C4] text-[#28231F] text-sm py-2.5 px-3 rounded-xs focus-visible:outline-2 focus-visible:outline-[#49372B]"
                  >
                    <option value="living">Living Room</option>
                    <option value="dining">Dining Room</option>
                    <option value="bedroom">Primary Bedroom Sanctuary</option>
                    <option value="workspace">Study &amp; Library Workspace</option>
                    <option value="residence">Full Residential Commission</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="approxBudget" className="block text-xs uppercase tracking-wider font-semibold text-[#49372B] mb-2">
                    Approximate Budget
                  </label>
                  <select
                    id="approxBudget"
                    value={form.approxBudget}
                    onChange={(e) => setForm({ ...form, approxBudget: e.target.value })}
                    className="w-full bg-[#FAF8F5] border border-[#D8D0C4] text-[#28231F] text-sm py-2.5 px-3 rounded-xs focus-visible:outline-2 focus-visible:outline-[#49372B]"
                  >
                    <option value="$10,000 – $25,000">$10,000 – $25,000 USD</option>
                    <option value="$25,000 – $50,000">$25,000 – $50,000 USD</option>
                    <option value="$50,000 – $100,000">$50,000 – $100,000 USD</option>
                    <option value="Over $100,000">Over $100,000 USD (Architectural)</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="timeline" className="block text-xs uppercase tracking-wider font-semibold text-[#49372B] mb-2">
                    Target Timeline
                  </label>
                  <select
                    id="timeline"
                    value={form.timeline}
                    onChange={(e) => setForm({ ...form, timeline: e.target.value })}
                    className="w-full bg-[#FAF8F5] border border-[#D8D0C4] text-[#28231F] text-sm py-2.5 px-3 rounded-xs focus-visible:outline-2 focus-visible:outline-[#49372B]"
                  >
                    <option value="Immediate (8–10 weeks standard)">Immediate (8–10 weeks standard)</option>
                    <option value="3–6 Months">3–6 Months</option>
                    <option value="6–12 Months (New Build / Renovation)">6–12 Months (New Build)</option>
                  </select>
                </div>
              </div>

              {/* Preferred Materials Checkboxes */}
              <div>
                <label className="block text-xs uppercase tracking-wider font-semibold text-[#49372B] mb-2">
                  Preferred Materials &amp; Finishes <span className="text-[#A36D47]">*</span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {materialOptions.map((mat) => {
                    const checked = form.preferredMaterials.includes(mat);
                    return (
                      <button
                        type="button"
                        key={mat}
                        onClick={() => handleMaterialToggle(mat)}
                        className={`text-left p-3 border text-xs flex items-center justify-between transition-colors ${
                          checked
                            ? 'bg-[#49372B] text-[#F5F1E9] border-[#49372B]'
                            : 'bg-[#FAF8F5] text-[#28231F] border-[#D8D0C4] hover:border-[#A36D47]'
                        }`}
                      >
                        <span>{mat}</span>
                        {checked && <Check className="w-3.5 h-3.5" />}
                      </button>
                    );
                  })}
                </div>
                {errors.materials && (
                  <p className="mt-1.5 text-xs text-red-700 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{errors.materials}</span>
                  </p>
                )}
              </div>

              {/* Saved Pieces Integration */}
              {savedProducts.length > 0 && (
                <div className="p-4 bg-[#FAF8F5] border border-[#D8D0C4] flex items-center justify-between gap-4">
                  <div>
                    <span className="text-xs font-semibold text-[#28231F] block">
                      Include Your Shortlist ({savedProducts.length} pieces)
                    </span>
                    <span className="text-xs text-[#757969]">
                      Attach {savedProducts.map((p) => p.name).join(', ')} to your consultation brief
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={form.includeSavedPieces}
                    onChange={(e) => setForm({ ...form, includeSavedPieces: e.target.checked })}
                    className="w-4 h-4 accent-[#49372B]"
                  />
                </div>
              )}

              {/* Project Description */}
              <div>
                <label htmlFor="projectDescription" className="block text-xs uppercase tracking-wider font-semibold text-[#49372B] mb-2">
                  Project Description &amp; Architectural Goals <span className="text-[#A36D47]">*</span>
                </label>
                <textarea
                  id="projectDescription"
                  rows={4}
                  value={form.projectDescription}
                  onChange={(e) => setForm({ ...form, projectDescription: e.target.value })}
                  placeholder="Share details regarding your room layout, existing architectural elements (limestone fireplace, timber beams, window light), or custom dimensions required..."
                  aria-describedby={errors.projectDescription ? 'description-error' : undefined}
                  className={`w-full bg-[#FAF8F5] border text-[#28231F] text-sm p-3 rounded-xs focus-visible:outline-2 focus-visible:outline-[#49372B] ${
                    errors.projectDescription ? 'border-red-600' : 'border-[#D8D0C4]'
                  }`}
                />
                {errors.projectDescription && (
                  <p id="description-error" className="mt-1.5 text-xs text-red-700 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{errors.projectDescription}</span>
                  </p>
                )}
              </div>

              {/* Form Actions */}
              <div className="pt-4 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
                <button
                  type="submit"
                  className="px-6 py-3.5 bg-[#49372B] text-[#F5F1E9] text-xs uppercase tracking-wider font-medium hover:bg-[#28231F] transition-colors flex items-center justify-center gap-2"
                >
                  <span>Compile Consultation Brief</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <p className="text-xs text-[#757969] italic">
                  * All fields processed locally. No unsolicited spam or marketing.
                </p>
              </div>
            </form>
          ) : (
            /* Editable Summary Review & Export Actions */
            <div className="space-y-8 animate-fadeIn">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#D8D0C4]">
                <div>
                  <div className="inline-flex items-center gap-2 text-xs tracking-widest uppercase text-[#A36D47] font-semibold mb-1">
                    <FileText className="w-4 h-4" />
                    <span>Brief Compiled Successfully</span>
                  </div>
                  <h3 className="font-serif-luxury text-2xl sm:text-3xl text-[#28231F]">
                    Review Your Design Consultation Brief
                  </h3>
                </div>

                <button
                  onClick={() => setIsCompiled(false)}
                  className="inline-flex items-center gap-2 text-xs uppercase tracking-wider text-[#49372B] hover:text-[#A36D47] underline underline-offset-4"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Edit Specifications</span>
                </button>
              </div>

              {/* Rendered Brief Preview */}
              <div className="bg-[#FAF8F5] border border-[#49372B]/30 p-6 sm:p-8 space-y-6 font-mono text-xs text-[#28231F] leading-relaxed">
                <div className="border-b border-[#D8D0C4] pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <span className="font-serif-luxury font-bold text-lg text-[#49372B]">ALDER &amp; HEARTH</span>
                  <span className="text-[#757969]">Brief Reference: {briefRefId}</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <span className="text-[#757969] block">CLIENT:</span>
                    <span className="font-semibold">{form.fullName}</span> ({form.email})
                  </div>
                  <div>
                    <span className="text-[#757969] block">ROOM CONTEXT:</span>
                    <span className="font-semibold">{form.roomType.toUpperCase()}</span>
                  </div>
                  <div>
                    <span className="text-[#757969] block">APPROXIMATE BUDGET:</span>
                    <span className="font-semibold">{form.approxBudget}</span>
                  </div>
                  <div>
                    <span className="text-[#757969] block">EXECUTION TIMELINE:</span>
                    <span className="font-semibold">{form.timeline}</span>
                  </div>
                </div>

                <div>
                  <span className="text-[#757969] block mb-1">PREFERRED MATERIAL SPECIFICATIONS:</span>
                  <div className="flex flex-wrap gap-2">
                    {form.preferredMaterials.map((m) => (
                      <span key={m} className="px-2 py-0.5 bg-[#E8DFD0] text-[#49372B] text-[11px]">
                        {m}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="text-[#757969] block mb-1">ARCHITECTURAL GOALS &amp; NARRATIVE:</span>
                  <p className="bg-[#F5F1E9] p-3 border border-[#D8D0C4] whitespace-pre-wrap">
                    {form.projectDescription}
                  </p>
                </div>

                {form.includeSavedPieces && savedProducts.length > 0 && (
                  <div>
                    <span className="text-[#757969] block mb-1">SHORTLISTED PIECES FOR INCLUSION:</span>
                    <ul className="list-disc list-inside space-y-1">
                      {savedProducts.map((p) => (
                        <li key={p.id}>
                          {p.name} — ${p.priceUSD.toLocaleString()} USD ({p.primaryMaterial})
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Action Buttons: Copy & Download */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
                <button
                  onClick={handleCopyClipboard}
                  className="flex-1 py-3.5 px-6 bg-[#49372B] text-[#F5F1E9] text-xs uppercase tracking-wider font-medium hover:bg-[#28231F] transition-colors flex items-center justify-center gap-2"
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-300" />
                      <span>Copied to Clipboard!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>Copy Brief to Clipboard</span>
                    </>
                  )}
                </button>

                <button
                  onClick={handleDownload}
                  className="py-3.5 px-6 bg-[#FAF8F5] border border-[#49372B] text-[#49372B] text-xs uppercase tracking-wider font-medium hover:bg-[#F5F1E9] transition-colors flex items-center justify-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Brief (.txt)</span>
                </button>
              </div>

              {/* Non-Transmission Disclosure */}
              <div className="p-4 bg-[#FAF8F5] border border-[#D8D0C4] text-xs text-[#757969] leading-relaxed flex items-start gap-3">
                <AlertCircle className="w-4 h-4 text-[#A36D47] shrink-0 mt-0.5" />
                <div>
                  <strong className="text-[#28231F] font-semibold block mb-0.5">
                    Concept Studio Notice:
                  </strong>
                  Alder &amp; Hearth is an editorial concept furniture portfolio. Your consultation brief
                  has been compiled client-side for your architectural records and has <strong>not been transmitted</strong> to a live backend server.
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
