'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';

interface PhilosophyIntroProps {
  onLearnMore?: () => void;
}

export function PhilosophyIntro({ onLearnMore }: PhilosophyIntroProps) {
  return (
    <section id="approach" className="py-20 lg:py-28 bg-[#F5F1E9] border-b border-[#D8D0C4]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Editorial Text */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 text-xs tracking-[0.2em] uppercase font-sans-clean text-[#757969]">
              <span className="w-6 h-px bg-[#757969]" />
              <span>Philosophy &amp; Provenance</span>
            </div>

            <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-light text-[#28231F] leading-[1.15] text-balance">
              Furniture built for permanence, shaped by the light of the Hudson Valley.
            </h2>

            <div className="space-y-4 text-[#49372B]/90 text-base sm:text-lg leading-relaxed font-light">
              <p>
                We believe a home should feel grounded, calm, and generous. In our workshops, modern
                architectural lines meet the deep warmth of domestic timber. Every joint is exposed because
                honesty in construction needs no ornament to disguise it.
              </p>
              <p className="text-sm sm:text-base text-[#49372B]/80">
                We select each walnut plank and limestone slab for character rather than uniformity. Our
                finishes are breathable oils and natural waxes, allowing wood to respond gently to the seasons
                and age with a quiet, hard-earned patina.
              </p>
            </div>

            {/* 3 Pillars */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-6 border-t border-[#D8D0C4]">
              <div>
                <span className="text-xs uppercase tracking-wider font-semibold text-[#49372B] block mb-1">
                  01. Architectural Line
                </span>
                <p className="text-xs text-[#757969] leading-relaxed">
                  Disciplined proportions that frame light and invite quiet contemplation.
                </p>
              </div>
              <div>
                <span className="text-xs uppercase tracking-wider font-semibold text-[#49372B] block mb-1">
                  02. Tactile Honesty
                </span>
                <p className="text-xs text-[#757969] leading-relaxed">
                  Pure unbleached Belgian linen, vegetable-tanned steerhide, and solid hardwood.
                </p>
              </div>
              <div>
                <span className="text-xs uppercase tracking-wider font-semibold text-[#49372B] block mb-1">
                  03. Heirloom Craft
                </span>
                <p className="text-xs text-[#757969] leading-relaxed">
                  Traditional mortise-and-tenon joinery meant to serve across generations.
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Tactile photographic diptych */}
          <div className="lg:col-span-5 grid grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="relative aspect-[3/4] overflow-hidden bg-[#D8D0C4] border border-[#D8D0C4]">
                <Image
                  src="/materials/american-walnut.png"
                  alt="American black walnut close-up showing heartwood grain and natural warm oil finish"
                  fill
                  sizes="(max-width: 1024px) 50vw, 25vw"
                  referrerPolicy="no-referrer"
                  className="object-cover hover:scale-105 transition-transform duration-700"
                />
              </div>
              <div className="text-[11px] text-[#757969] uppercase tracking-wider">
                01. American Black Walnut
              </div>
            </div>

            <div className="space-y-3 pt-8 sm:pt-12">
              <div className="relative aspect-[3/4] overflow-hidden bg-[#D8D0C4] border border-[#D8D0C4]">
                <Image
                  src="/materials/oatmeal-linen.png"
                  alt="Belgian flax linen weave with unbleached oatmeal texture"
                  fill
                  sizes="(max-width: 1024px) 50vw, 25vw"
                  referrerPolicy="no-referrer"
                  className="object-cover hover:scale-105 transition-transform duration-700"
                />
              </div>
              <div className="text-[11px] text-[#757969] uppercase tracking-wider">
                02. Oatmeal Flax Linen
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
