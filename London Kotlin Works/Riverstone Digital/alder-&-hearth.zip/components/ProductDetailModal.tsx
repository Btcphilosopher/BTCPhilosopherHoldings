'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { X, Bookmark, ArrowRight, ShieldCheck, Check, Sparkles, Ruler } from 'lucide-react';
import { Product, FinishOption } from '@/lib/data';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  isSaved: boolean;
  onToggleSave: () => void;
  onEnquirePiece: (product: Product) => void;
}

export function ProductDetailModal({
  product,
  onClose,
  isSaved,
  onToggleSave,
  onEnquirePiece,
}: ProductDetailModalProps) {
  const [selectedFinish, setSelectedFinish] = useState<FinishOption | null>(() => product?.finishes[0] || null);
  const [activeImageIndex, setActiveImageIndex] = useState<number>(0);
  const [activeCareTab, setActiveCareTab] = useState<'routine' | 'periodic' | 'prevention'>('routine');

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = '';
    };
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!product) return null;

  const currentFinish = selectedFinish ?? product.finishes[0];

  const currentDisplayImage =
    product.detailImages[activeImageIndex]?.url || product.image;
  const currentImageCaption =
    product.detailImages[activeImageIndex]?.caption || product.name;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-product-title"
      className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 lg:p-10 animate-fadeIn"
    >
      <div className="relative w-full max-w-5xl bg-[#FAF8F5] border border-[#49372B]/30 shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Modal Top Bar */}
        <div className="px-6 py-4 bg-[#F5F1E9] border-b border-[#D8D0C4] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <span className="text-[10px] uppercase tracking-widest text-[#757969]">
              Catalogue No. {product.id}
            </span>
            <span className="text-[#D8D0C4]">·</span>
            <span className="text-xs uppercase tracking-wider text-[#A36D47] font-medium">
              {product.roomLabel} Collection
            </span>
          </div>

          <button
            onClick={onClose}
            aria-label="Close product detail"
            className="p-1.5 text-[#49372B] hover:text-[#28231F] hover:bg-[#D8D0C4]/40 rounded-xs transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Modal Content */}
        <div className="overflow-y-auto p-6 sm:p-8 lg:p-10 flex-1">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
            {/* Gallery Left (7 cols) */}
            <div className="lg:col-span-7 space-y-4">
              {/* Primary Image */}
              <div className="relative aspect-[16/11] bg-[#ECE6DC]/60 overflow-hidden border border-[#D8D0C4]">
                <Image
                  src={currentDisplayImage}
                  alt={currentImageCaption}
                  fill
                  priority
                  sizes="(max-width: 1024px) 100vw, 55vw"
                  referrerPolicy="no-referrer"
                  className="object-contain p-4"
                />

                {/* Caption Bar */}
                <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-[#28231F]/80 via-[#28231F]/40 to-transparent p-3 text-[11px] text-[#F5F1E9] font-light">
                  {currentImageCaption}
                </div>
              </div>

              {/* Detail Thumbnails */}
              {product.detailImages.length > 1 && (
                <div className="grid grid-cols-3 gap-3">
                  {product.detailImages.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveImageIndex(idx)}
                      className={`relative aspect-[16/10] bg-[#ECE6DC] overflow-hidden border transition-all ${
                        activeImageIndex === idx
                          ? 'border-[#49372B] ring-1 ring-[#49372B]'
                          : 'border-[#D8D0C4] opacity-75 hover:opacity-100'
                      }`}
                    >
                      <Image
                        src={img.url}
                        alt={img.caption}
                        fill
                        sizes="160px"
                        referrerPolicy="no-referrer"
                        className="object-cover"
                      />
                    </button>
                  ))}
                </div>
              )}

              {/* Dimensions Blueprint Panel */}
              <div className="p-4 bg-[#F5F1E9] border border-[#D8D0C4] space-y-3">
                <div className="flex items-center gap-2 text-xs uppercase tracking-wider font-semibold text-[#49372B]">
                  <Ruler className="w-4 h-4 text-[#A36D47]" />
                  <span>Architectural Dimensions</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-[#757969] block">Imperial:</span>
                    <span className="font-medium text-[#28231F]">{product.dimensions.imperial}</span>
                  </div>
                  <div>
                    <span className="text-[#757969] block">Metric:</span>
                    <span className="font-medium text-[#28231F]">{product.dimensions.metric}</span>
                  </div>
                  {product.dimensions.seatHeight && (
                    <div>
                      <span className="text-[#757969] block">Seat Height:</span>
                      <span className="font-medium text-[#28231F]">{product.dimensions.seatHeight}</span>
                    </div>
                  )}
                  {product.dimensions.clearance && (
                    <div>
                      <span className="text-[#757969] block">Clearance / Foundation:</span>
                      <span className="font-medium text-[#28231F]">{product.dimensions.clearance}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Specifications & Actions Right (5 cols) */}
            <div className="lg:col-span-5 space-y-6 flex flex-col justify-between">
              <div>
                {/* Title & Price */}
                <div className="border-b border-[#D8D0C4] pb-4 mb-4">
                  <h2
                    id="modal-product-title"
                    className="font-serif-luxury text-3xl sm:text-4xl font-normal text-[#28231F] mb-1"
                  >
                    {product.name}
                  </h2>
                  <p className="text-xs text-[#757969] mb-3">{product.subtitle}</p>

                  <div className="flex items-baseline justify-between">
                    <span className="font-sans-clean text-2xl font-medium text-[#49372B] tabular-nums">
                      ${product.priceUSD.toLocaleString()} USD
                    </span>
                    <span className="text-[11px] text-[#757969] uppercase tracking-wider">
                      Lead Time: {product.leadTime}
                    </span>
                  </div>
                </div>

                {/* Finish & Upholstery Selection */}
                <div className="mb-6 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="uppercase tracking-wider font-semibold text-[#49372B]">
                      Finish / Upholstery:
                    </span>
                    <span className="text-[#A36D47] font-medium">
                      {currentFinish?.name}
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-2.5">
                    {product.finishes.map((f) => {
                      const isSelected = currentFinish?.id === f.id;
                      return (
                        <button
                          key={f.id}
                          onClick={() => setSelectedFinish(f)}
                          className={`relative flex items-center gap-2 p-2 border text-xs transition-all ${
                            isSelected
                              ? 'border-[#49372B] bg-[#F5F1E9] ring-1 ring-[#49372B]'
                              : 'border-[#D8D0C4] bg-white hover:border-[#A36D47]'
                          }`}
                        >
                          <span
                            className="w-4 h-4 rounded-full border border-black/20 shrink-0"
                            style={{ backgroundColor: f.swatchHex }}
                          />
                          <span className="truncate max-w-[130px]">{f.name}</span>
                          {isSelected && <Check className="w-3.5 h-3.5 text-[#49372B]" />}
                        </button>
                      );
                    })}
                  </div>

                  <p className="text-[11px] text-[#757969] italic">
                    Note: Finish selection updates your custom specification without modifying photography unless a dedicated render is available.
                  </p>
                </div>

                {/* Craftsmanship Narrative */}
                <div className="mb-6 space-y-2">
                  <h4 className="text-xs uppercase tracking-wider font-semibold text-[#49372B]">
                    Craftsmanship Narrative
                  </h4>
                  <p className="text-xs sm:text-sm text-[#49372B]/90 font-light leading-relaxed">
                    {product.narrative}
                  </p>
                </div>

                {/* Key Features */}
                <div className="mb-6 space-y-2">
                  <h4 className="text-xs uppercase tracking-wider font-semibold text-[#49372B]">
                    Architectural Specifications
                  </h4>
                  <ul className="space-y-1.5 text-xs text-[#757969]">
                    {product.features.map((feat, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#A36D47] mt-1.5 shrink-0" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Care Guidance Tabs */}
                <div className="p-4 bg-[#F5F1E9] border border-[#D8D0C4] space-y-2.5">
                  <div className="flex items-center justify-between border-b border-[#D8D0C4] pb-2">
                    <span className="text-[11px] uppercase tracking-wider font-semibold text-[#49372B]">
                      Material Care Guide
                    </span>
                    <div className="flex gap-1 text-[10px] uppercase">
                      {(['routine', 'periodic', 'prevention'] as const).map((tab) => (
                        <button
                          key={tab}
                          onClick={() => setActiveCareTab(tab)}
                          className={`px-2 py-0.5 border ${
                            activeCareTab === tab
                              ? 'bg-[#49372B] text-white border-[#49372B]'
                              : 'bg-white text-[#757969] border-[#D8D0C4]'
                          }`}
                        >
                          {tab}
                        </button>
                      ))}
                    </div>
                  </div>
                  <p className="text-xs text-[#49372B]/90 leading-relaxed font-light">
                    {product.careInstructions[activeCareTab]}
                  </p>
                </div>
              </div>

              {/* Bottom Sticky Action Buttons */}
              <div className="pt-4 border-t border-[#D8D0C4] flex flex-col sm:flex-row items-stretch gap-3">
                <button
                  onClick={() => {
                    onClose();
                    onEnquirePiece(product);
                  }}
                  className="flex-1 py-3 px-4 bg-[#49372B] text-[#F5F1E9] text-xs uppercase tracking-wider font-medium hover:bg-[#28231F] transition-colors flex items-center justify-center gap-2"
                >
                  <span>Enquire About This Piece</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={onToggleSave}
                  className={`py-3 px-4 border text-xs uppercase tracking-wider font-medium transition-colors flex items-center justify-center gap-2 ${
                    isSaved
                      ? 'bg-[#A36D47] text-[#F5F1E9] border-[#A36D47]'
                      : 'bg-[#FAF8F5] text-[#49372B] border-[#49372B] hover:bg-[#F5F1E9]'
                  }`}
                >
                  <Bookmark className="w-4 h-4" fill={isSaved ? '#F5F1E9' : 'none'} />
                  <span>{isSaved ? 'In Shortlist' : 'Add to Shortlist'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
