'use client';

import React, { useState } from 'react';
import { ArrowUp, BookOpen, ShieldCheck, X } from 'lucide-react';

interface FooterProps {
  onNavigateSection: (sectionId: string) => void;
  onFilterRoom: (room: 'living' | 'dining' | 'bedroom' | 'workspace') => void;
}

export function Footer({ onNavigateSection, onFilterRoom }: FooterProps) {
  const [careModalOpen, setCareModalOpen] = useState(false);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <footer className="bg-[#28231F] text-[#F5F1E9] border-t border-[#49372B]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
          {/* Main Footer Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 lg:gap-8 mb-16 pb-16 border-b border-[#49372B]/60">
            {/* Column 1: Brand & Ethos (4 cols) */}
            <div className="lg:col-span-4 space-y-4">
              <span className="font-serif-luxury text-2xl sm:text-3xl font-normal tracking-[0.12em] uppercase text-[#F5F1E9] block">
                Alder &amp; Hearth
              </span>
              <p className="text-sm text-[#D8D0C4] font-light leading-relaxed max-w-sm">
                A quieter kind of extraordinary. Handcrafted furniture shaped by American modernism,
                architectural restraint, and the tactile honesty of natural timber and stone.
              </p>
              <div className="text-xs text-[#757969] uppercase tracking-widest pt-2">
                Hudson Valley · New York
              </div>
            </div>

            {/* Column 2: Collections (2 cols) */}
            <div className="lg:col-span-2 space-y-3">
              <h4 className="text-xs uppercase tracking-widest text-[#D8D0C4] font-semibold">
                Collections
              </h4>
              <ul className="space-y-2 text-xs text-[#D8D0C4]/80 font-light">
                <li>
                  <button
                    onClick={() => {
                      onFilterRoom('living');
                      onNavigateSection('collection');
                    }}
                    className="hover:text-[#F5F1E9] transition-colors"
                  >
                    Living Room
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => {
                      onFilterRoom('dining');
                      onNavigateSection('collection');
                    }}
                    className="hover:text-[#F5F1E9] transition-colors"
                  >
                    Dining Room
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => {
                      onFilterRoom('bedroom');
                      onNavigateSection('collection');
                    }}
                    className="hover:text-[#F5F1E9] transition-colors"
                  >
                    Bedroom Sanctuary
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => {
                      onFilterRoom('workspace');
                      onNavigateSection('collection');
                    }}
                    className="hover:text-[#F5F1E9] transition-colors"
                  >
                    Study &amp; Workspace
                  </button>
                </li>
              </ul>
            </div>

            {/* Column 3: Materials & Philosophy (3 cols) */}
            <div className="lg:col-span-3 space-y-3">
              <h4 className="text-xs uppercase tracking-widest text-[#D8D0C4] font-semibold">
                Materials &amp; Craft
              </h4>
              <ul className="space-y-2 text-xs text-[#D8D0C4]/80 font-light">
                <li>
                  <button
                    onClick={() => onNavigateSection('materials')}
                    className="hover:text-[#F5F1E9] transition-colors"
                  >
                    American Black Walnut
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => onNavigateSection('materials')}
                    className="hover:text-[#F5F1E9] transition-colors"
                  >
                    Oatmeal Belgian Flax Linen
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => onNavigateSection('materials')}
                    className="hover:text-[#F5F1E9] transition-colors"
                  >
                    Vegetable-Tanned Saddle Leather
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => onNavigateSection('materials')}
                    className="hover:text-[#F5F1E9] transition-colors"
                  >
                    Champlain Valley Limestone
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => setCareModalOpen(true)}
                    className="text-[#A36D47] hover:underline pt-1 block"
                  >
                    Care &amp; Maintenance Guide &rarr;
                  </button>
                </li>
              </ul>
            </div>

            {/* Column 4: Design Services (3 cols) */}
            <div className="lg:col-span-3 space-y-3">
              <h4 className="text-xs uppercase tracking-widest text-[#D8D0C4] font-semibold">
                Design Services
              </h4>
              <ul className="space-y-2 text-xs text-[#D8D0C4]/80 font-light">
                <li>
                  <button
                    onClick={() => onNavigateSection('design-services')}
                    className="hover:text-[#F5F1E9] transition-colors"
                  >
                    Room Consultation Planner
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => onNavigateSection('design-services')}
                    className="hover:text-[#F5F1E9] transition-colors"
                  >
                    Bespoke Dimensional Scaling
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => onNavigateSection('room-story')}
                    className="hover:text-[#F5F1E9] transition-colors"
                  >
                    Architectural Room Stories
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => onNavigateSection('approach')}
                    className="hover:text-[#F5F1E9] transition-colors"
                  >
                    Our Approach
                  </button>
                </li>
              </ul>
            </div>
          </div>

          {/* Discreet Concept Disclosure & Copyright */}
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 text-xs text-[#757969]">
            <div className="max-w-2xl leading-relaxed font-light">
              <strong className="text-[#D8D0C4] font-medium">Concept Studio Disclosure: </strong>
              Alder &amp; Hearth is a concept furniture portfolio created to explore editorial American luxury
              design and architectural commerce. All designs, prices, and specifications represent concept
              studio works.
            </div>

            <div className="flex items-center gap-6 shrink-0">
              <button
                onClick={scrollToTop}
                className="flex items-center gap-1.5 text-xs uppercase tracking-wider text-[#D8D0C4] hover:text-[#F5F1E9] transition-colors"
              >
                <span>Back to Top</span>
                <ArrowUp className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </footer>

      {/* Care Guide Dialog */}
      {careModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4"
        >
          <div className="relative w-full max-w-lg bg-[#FAF8F5] border border-[#49372B] p-6 sm:p-8 text-[#28231F] shadow-2xl">
            <div className="flex items-start justify-between mb-4 border-b border-[#D8D0C4] pb-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-[#A36D47]" />
                <h3 className="font-serif-luxury text-2xl">Furniture Care &amp; Longevity</h3>
              </div>
              <button
                onClick={() => setCareModalOpen(false)}
                className="p-1 text-[#757969] hover:text-[#28231F]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs text-[#49372B] leading-relaxed font-light max-h-[60vh] overflow-y-auto pr-2">
              <div>
                <h4 className="font-semibold text-[#28231F] uppercase tracking-wider mb-1">
                  Solid Hardwoods (Walnut &amp; Oak)
                </h4>
                <p>
                  Our hardwoods are finished with breathable natural oils and organic beeswax. Dust regularly
                  along the grain with a dry microfiber cloth. Reapply organic walnut oil balm twice a year.
                  Never use industrial aerosol sprays or harsh silicone polish.
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-[#28231F] uppercase tracking-wider mb-1">
                  Belgian Flax Linen
                </h4>
                <p>
                  Natural unbleached flax breathes naturally. Vacuum gently with an upholstery brush. For
                  spills, blot immediately with clean distilled water and an un-dyed cloth. Avoid scrubbing.
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-[#28231F] uppercase tracking-wider mb-1">
                  Vegetable-Tanned Saddle Leather
                </h4>
                <p>
                  Full-grain steerhide will develop a rich amber patina. Buff minor scratches with the warmth of
                  your fingertips or horsehair brush. Apply natural lanolin leather conditioner once yearly.
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-[#28231F] uppercase tracking-wider mb-1">
                  Champlain Limestone
                </h4>
                <p>
                  Honed limestone is pre-sealed against moisture. Clean with pH-neutral stone wash and warm
                  water. Avoid vinegar, lemon juice, or acidic cleansers.
                </p>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-[#D8D0C4] flex justify-end">
              <button
                onClick={() => setCareModalOpen(false)}
                className="px-4 py-2 bg-[#49372B] text-[#F5F1E9] text-xs uppercase tracking-wider"
              >
                Close Care Guide
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
