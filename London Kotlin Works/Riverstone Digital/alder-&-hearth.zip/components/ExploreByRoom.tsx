'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowUpRight } from 'lucide-react';
import { ROOM_CATEGORIES, RoomCategory } from '@/lib/data';

interface ExploreByRoomProps {
  onSelectRoom: (roomId: 'living' | 'dining' | 'bedroom' | 'workspace') => void;
}

export function ExploreByRoom({ onSelectRoom }: ExploreByRoomProps) {
  return (
    <section className="py-20 lg:py-28 bg-[#FAF8F5] border-b border-[#D8D0C4]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Strip */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 text-xs tracking-[0.2em] uppercase font-sans-clean text-[#757969] mb-3">
              <span className="w-6 h-px bg-[#757969]" />
              <span>Architectural Contexts</span>
            </div>
            <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-light text-[#28231F]">
              Explore by room.
            </h2>
          </div>
          <p className="text-sm text-[#757969] max-w-md">
            Each environment is conceived as a harmonious composition of light, proportion, and honest material dialogue.
          </p>
        </div>

        {/* Asymmetric Photographic Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Card 1: Living (Featured 7-col wide, tall) */}
          <button
            onClick={() => onSelectRoom('living')}
            className="group text-left md:col-span-7 relative min-h-[380px] sm:min-h-[460px] overflow-hidden bg-[#28231F] border border-[#D8D0C4] focus-visible:outline-2 focus-visible:outline-[#49372B]"
          >
            <Image
              src="/editorial/hudson-valley-room.png"
              alt="Living room collection featuring walnut-framed Hudson sofa and Stillwater chair"
              fill
              sizes="(max-width: 768px) 100vw, 60vw"
              referrerPolicy="no-referrer"
              className="object-cover object-[center_40%] group-hover:scale-105 transition-transform duration-700 opacity-90"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#28231F]/90 via-[#28231F]/30 to-transparent" />

            <div className="absolute inset-0 p-8 flex flex-col justify-between z-10 text-[#F5F1E9]">
              <div className="flex items-center justify-between">
                <span className="text-[11px] uppercase tracking-widest text-[#D8D0C4]">
                  01 / 04 · Living
                </span>
                <div className="w-8 h-8 rounded-full bg-[#F5F1E9]/20 backdrop-blur-xs flex items-center justify-center group-hover:bg-[#F5F1E9] group-hover:text-[#28231F] transition-colors">
                  <ArrowUpRight className="w-4 h-4" />
                </div>
              </div>

              <div>
                <h3 className="font-serif-luxury text-3xl sm:text-4xl font-light mb-2">
                  Living
                </h3>
                <p className="text-sm text-[#D8D0C4] font-light max-w-sm mb-3">
                  Quiet hearths, generous Belgian linen seating, and sculptural walnut coffee tables.
                </p>
                <span className="inline-block text-[11px] uppercase tracking-wider text-[#FAF8F5] underline underline-offset-4 group-hover:text-[#A36D47]">
                  View 3 Pieces &rarr;
                </span>
              </div>
            </div>
          </button>

          {/* Card 2: Dining (5-col wide) */}
          <button
            onClick={() => onSelectRoom('dining')}
            className="group text-left md:col-span-5 relative min-h-[380px] sm:min-h-[460px] overflow-hidden bg-[#28231F] border border-[#D8D0C4] focus-visible:outline-2 focus-visible:outline-[#49372B]"
          >
            <Image
              src="/materials/limestone-hearth.png"
              alt="Dining collection featuring limestone slab tables and steam-bent chairs"
              fill
              sizes="(max-width: 768px) 100vw, 40vw"
              referrerPolicy="no-referrer"
              className="object-cover group-hover:scale-105 transition-transform duration-700 opacity-85"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#28231F]/90 via-[#28231F]/40 to-transparent" />

            <div className="absolute inset-0 p-8 flex flex-col justify-between z-10 text-[#F5F1E9]">
              <div className="flex items-center justify-between">
                <span className="text-[11px] uppercase tracking-widest text-[#D8D0C4]">
                  02 / 04 · Dining
                </span>
                <div className="w-8 h-8 rounded-full bg-[#F5F1E9]/20 backdrop-blur-xs flex items-center justify-center group-hover:bg-[#F5F1E9] group-hover:text-[#28231F] transition-colors">
                  <ArrowUpRight className="w-4 h-4" />
                </div>
              </div>

              <div>
                <h3 className="font-serif-luxury text-3xl sm:text-4xl font-light mb-2">
                  Dining
                </h3>
                <p className="text-sm text-[#D8D0C4] font-light max-w-xs mb-3">
                  Champlain limestone slab trestles, steam-bent dining chairs, and slatted tambour credenzas.
                </p>
                <span className="inline-block text-[11px] uppercase tracking-wider text-[#FAF8F5] underline underline-offset-4 group-hover:text-[#A36D47]">
                  View 3 Pieces &rarr;
                </span>
              </div>
            </div>
          </button>

          {/* Card 3: Bedroom (6-col wide) */}
          <button
            onClick={() => onSelectRoom('bedroom')}
            className="group text-left md:col-span-6 relative min-h-[300px] sm:min-h-[340px] overflow-hidden bg-[#28231F] border border-[#D8D0C4] focus-visible:outline-2 focus-visible:outline-[#49372B]"
          >
            <Image
              src="/materials/american-walnut.png"
              alt="Bedroom collection featuring cantilevered Laurel platform bed"
              fill
              sizes="(max-width: 768px) 100vw, 50vw"
              referrerPolicy="no-referrer"
              className="object-cover group-hover:scale-105 transition-transform duration-700 opacity-85"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#28231F]/90 via-[#28231F]/30 to-transparent" />

            <div className="absolute inset-0 p-8 flex flex-col justify-between z-10 text-[#F5F1E9]">
              <div className="flex items-center justify-between">
                <span className="text-[11px] uppercase tracking-widest text-[#D8D0C4]">
                  03 / 04 · Bedroom
                </span>
                <div className="w-8 h-8 rounded-full bg-[#F5F1E9]/20 backdrop-blur-xs flex items-center justify-center group-hover:bg-[#F5F1E9] group-hover:text-[#28231F] transition-colors">
                  <ArrowUpRight className="w-4 h-4" />
                </div>
              </div>

              <div>
                <h3 className="font-serif-luxury text-2xl sm:text-3xl font-light mb-1">
                  Bedroom
                </h3>
                <p className="text-xs sm:text-sm text-[#D8D0C4] font-light max-w-sm mb-2">
                  Floating cantilever platform beds with integrated nightstand wings and soft linen headboards.
                </p>
                <span className="inline-block text-[11px] uppercase tracking-wider text-[#FAF8F5] underline underline-offset-4 group-hover:text-[#A36D47]">
                  View Sanctuary Pieces &rarr;
                </span>
              </div>
            </div>
          </button>

          {/* Card 4: Workspace (6-col wide) */}
          <button
            onClick={() => onSelectRoom('workspace')}
            className="group text-left md:col-span-6 relative min-h-[300px] sm:min-h-[340px] overflow-hidden bg-[#28231F] border border-[#D8D0C4] focus-visible:outline-2 focus-visible:outline-[#49372B]"
          >
            <Image
              src="/editorial/autumn-window.png"
              alt="Workspace collection featuring Sylvan writing desk and reading lounge"
              fill
              sizes="(max-width: 768px) 100vw, 50vw"
              referrerPolicy="no-referrer"
              className="object-cover group-hover:scale-105 transition-transform duration-700 opacity-85"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#28231F]/90 via-[#28231F]/30 to-transparent" />

            <div className="absolute inset-0 p-8 flex flex-col justify-between z-10 text-[#F5F1E9]">
              <div className="flex items-center justify-between">
                <span className="text-[11px] uppercase tracking-widest text-[#D8D0C4]">
                  04 / 04 · Workspace
                </span>
                <div className="w-8 h-8 rounded-full bg-[#F5F1E9]/20 backdrop-blur-xs flex items-center justify-center group-hover:bg-[#F5F1E9] group-hover:text-[#28231F] transition-colors">
                  <ArrowUpRight className="w-4 h-4" />
                </div>
              </div>

              <div>
                <h3 className="font-serif-luxury text-2xl sm:text-3xl font-light mb-1">
                  Workspace
                </h3>
                <p className="text-xs sm:text-sm text-[#D8D0C4] font-light max-w-sm mb-2">
                  Tactile writing desks with inset saddle leather blotters and disciplined library seating.
                </p>
                <span className="inline-block text-[11px] uppercase tracking-wider text-[#FAF8F5] underline underline-offset-4 group-hover:text-[#A36D47]">
                  View Study Pieces &rarr;
                </span>
              </div>
            </div>
          </button>
        </div>
      </div>
    </section>
  );
}
