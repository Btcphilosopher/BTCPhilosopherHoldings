'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { ArrowRight, Sparkles, ShieldCheck } from 'lucide-react';
import { MATERIALS_DATA, MaterialInfo, PRODUCTS, Product } from '@/lib/data';

interface MaterialsSectionProps {
  onSelectProduct: (product: Product) => void;
}

export function MaterialsSection({ onSelectProduct }: MaterialsSectionProps) {
  const [selectedMaterialId, setSelectedMaterialId] = useState<string>('walnut');

  const activeMaterial = MATERIALS_DATA.find((m) => m.id === selectedMaterialId) || MATERIALS_DATA[0];

  const associatedProducts = PRODUCTS.filter((p) =>
    activeMaterial.associatedProductSlugs.includes(p.slug)
  );

  return (
    <section id="materials" className="py-20 lg:py-28 bg-[#FAF8F5] border-b border-[#D8D0C4]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mb-12">
          <div className="flex items-center gap-2 text-xs tracking-[0.2em] uppercase font-sans-clean text-[#757969] mb-3">
            <span className="w-6 h-px bg-[#757969]" />
            <span>Honest Matter</span>
          </div>

          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-6 border-b border-[#D8D0C4]">
            <div>
              <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-light text-[#28231F] text-balance">
                Materials of character &amp; quiet longevity.
              </h2>
            </div>
            <p className="text-sm text-[#757969] max-w-md">
              We never conceal timber with heavy plastic stains or mask raw steerhides. Every material
              breathes, patinas, and tells the story of its provenance.
            </p>
          </div>
        </div>

        {/* Material Selection Pills/Tabs (Interactive Functional Controls) */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-10">
          {MATERIALS_DATA.map((mat) => {
            const isSelected = mat.id === selectedMaterialId;
            return (
              <button
                key={mat.id}
                onClick={() => setSelectedMaterialId(mat.id)}
                className={`text-left p-4 border transition-all duration-200 flex flex-col justify-between ${
                  isSelected
                    ? 'bg-[#F5F1E9] border-[#49372B] shadow-xs'
                    : 'bg-[#FAF8F5] border-[#D8D0C4] hover:border-[#A36D47]/60'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <span
                    className="w-4 h-4 rounded-full border border-black/15 shrink-0"
                    style={{ backgroundColor: mat.swatchColor }}
                  />
                  <span className="text-[10px] uppercase tracking-wider text-[#757969]">
                    {mat.type}
                  </span>
                </div>
                <div>
                  <h3 className={`font-serif-luxury text-base sm:text-lg font-medium leading-tight ${
                    isSelected ? 'text-[#28231F]' : 'text-[#49372B]'
                  }`}>
                    {mat.name}
                  </h3>
                </div>
              </button>
            );
          })}
        </div>

        {/* Detailed Material Showcase Panel */}
        <div className="bg-[#F5F1E9] border border-[#D8D0C4] overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 p-6 sm:p-10 lg:p-12 items-center">
            {/* Image / Swatch representation */}
            <div className="lg:col-span-5 space-y-4">
              <div className="relative aspect-[4/3] bg-[#D8D0C4] overflow-hidden border border-[#D8D0C4]">
                <Image
                  src={activeMaterial.image}
                  alt={activeMaterial.name}
                  fill
                  sizes="(max-width: 1024px) 100vw, 40vw"
                  referrerPolicy="no-referrer"
                  className="object-cover"
                />
              </div>
              <div className="flex items-center justify-between text-xs text-[#757969] px-1">
                <span>Provenance: {activeMaterial.origin}</span>
                <span className="font-serif-luxury italic text-[#49372B]">Natural character</span>
              </div>
            </div>

            {/* Content & Care Guidance */}
            <div className="lg:col-span-7 space-y-6">
              <div>
                <span className="text-xs uppercase tracking-widest text-[#A36D47] font-semibold block mb-1">
                  {activeMaterial.subtitle}
                </span>
                <h3 className="font-serif-luxury text-3xl sm:text-4xl font-light text-[#28231F]">
                  {activeMaterial.name}
                </h3>
              </div>

              <div className="space-y-4">
                <div>
                  <h4 className="text-xs uppercase tracking-wider font-semibold text-[#49372B] mb-1">
                    Visual &amp; Structural Character
                  </h4>
                  <p className="text-sm sm:text-base text-[#49372B]/90 font-light leading-relaxed">
                    {activeMaterial.character}
                  </p>
                </div>

                <div>
                  <h4 className="text-xs uppercase tracking-wider font-semibold text-[#49372B] mb-1">
                    Tactile Hand-Feel
                  </h4>
                  <p className="text-sm text-[#757969] font-light leading-relaxed">
                    {activeMaterial.tactileNote}
                  </p>
                </div>

                <div className="p-4 bg-[#FAF8F5] border border-[#D8D0C4] flex items-start gap-3">
                  <ShieldCheck className="w-5 h-5 text-[#A36D47] shrink-0 mt-0.5" strokeWidth={1.5} />
                  <div>
                    <h5 className="text-xs uppercase tracking-wider font-semibold text-[#28231F] mb-0.5">
                      Care &amp; Longevity Guidance
                    </h5>
                    <p className="text-xs text-[#49372B]/90 leading-relaxed font-light">
                      {activeMaterial.careGuidance}
                    </p>
                  </div>
                </div>
              </div>

              {/* Associated Products in this material */}
              <div className="pt-4 border-t border-[#D8D0C4]">
                <h4 className="text-xs uppercase tracking-wider font-semibold text-[#49372B] mb-3">
                  Featured in Alder &amp; Hearth Pieces:
                </h4>
                <div className="flex flex-wrap gap-2">
                  {associatedProducts.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => onSelectProduct(p)}
                      className="group inline-flex items-center gap-2 px-3 py-1.5 text-xs bg-[#FAF8F5] hover:bg-[#49372B] hover:text-[#F5F1E9] border border-[#D8D0C4] transition-colors"
                    >
                      <span className="font-serif-luxury text-sm font-medium">{p.name}</span>
                      <span className="text-[10px] text-[#757969] group-hover:text-[#D8D0C4] tabular-nums">
                        ${p.priceUSD.toLocaleString()}
                      </span>
                      <ArrowRight className="w-3 h-3 transition-transform group-hover:translate-x-0.5" />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
