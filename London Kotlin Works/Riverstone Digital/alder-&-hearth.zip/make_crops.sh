mkdir -p public/products public/editorial public/materials

# 1. Product Cards from b00dcd3a-b04d-4b25-adbd-fd57e5f80a4b_6a8f282d.png
# Sofa: x=39, y=760, w=510, h=195
convert public/assets/aistudio/b00dcd3a-b04d-4b25-adbd-fd57e5f80a4b_6a8f282d.png -crop 510x195+39+760 +repage public/products/hudson-sofa.png

# Lounge Chair: x=610, y=760, w=380, h=195
convert public/assets/aistudio/b00dcd3a-b04d-4b25-adbd-fd57e5f80a4b_6a8f282d.png -crop 380x195+610+760 +repage public/products/stillwater-chair.png

# Ridge Coffee Table: x=1023, y=760, w=470, h=195
convert public/assets/aistudio/b00dcd3a-b04d-4b25-adbd-fd57e5f80a4b_6a8f282d.png -crop 470x195+1023+760 +repage public/products/ridge-coffee-table.png

# 2. Architectural & Vignette Crops from 3c1ab4c4-9e05-4cad-9308-58b5bb60597f_95822a6b.png (1672 x 941)
# Room full:
cp public/assets/aistudio/3c1ab4c4-9e05-4cad-9308-58b5bb60597f_95822a6b.png public/editorial/hudson-valley-room.png

# Fireplace & Hearth (Limestone): x=0, y=240, w=350, h=450
convert public/assets/aistudio/3c1ab4c4-9e05-4cad-9308-58b5bb60597f_95822a6b.png -crop 340x480+0+240 +repage public/materials/limestone-hearth.png

# Walnut Wall Grain & Sunlit Shadow: x=340, y=80, w=450, h=450
convert public/assets/aistudio/3c1ab4c4-9e05-4cad-9308-58b5bb60597f_95822a6b.png -crop 450x450+340+80 +repage public/materials/american-walnut.png

# Leather Detail on Chair: x=170, y=490, w=360, h=300
convert public/assets/aistudio/3c1ab4c4-9e05-4cad-9308-58b5bb60597f_95822a6b.png -crop 360x300+170+490 +repage public/materials/cognac-leather.png

# Oatmeal Linen Detail on Sofa: x=880, y=420, w=420, h=320
convert public/assets/aistudio/3c1ab4c4-9e05-4cad-9308-58b5bb60597f_95822a6b.png -crop 420x320+880+420 +repage public/materials/oatmeal-linen.png

# Coffee Table & Ceramic Branch Detail: x=600, y=450, w=550, h=360
convert public/assets/aistudio/3c1ab4c4-9e05-4cad-9308-58b5bb60597f_95822a6b.png -crop 550x360+600+450 +repage public/editorial/table-still-life.png

# Autumn Window & Foliage View: x=1020, y=0, w=650, h=520
convert public/assets/aistudio/3c1ab4c4-9e05-4cad-9308-58b5bb60597f_95822a6b.png -crop 650x520+1020+0 +repage public/editorial/autumn-window.png

echo "Crops completed."
