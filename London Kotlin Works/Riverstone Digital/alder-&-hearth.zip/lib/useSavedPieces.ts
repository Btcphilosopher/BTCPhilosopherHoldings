'use client';

import { useState, useEffect, useCallback } from 'react';
import { PRODUCTS, Product } from '@/lib/data';

const STORAGE_KEY = 'alder_hearth_saved_pieces_v1';

export function useSavedPieces() {
  const [savedIds, setSavedIds] = useState<string[]>(() => {
    if (typeof window === 'undefined') return [];
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.warn('Failed to read saved pieces from localStorage:', e);
    }
    return [];
  });

  const saveToStorage = useCallback((ids: string[]) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(ids));
    } catch (e) {
      console.warn('Failed to save pieces to localStorage:', e);
    }
  }, []);

  const toggleSavePiece = useCallback(
    (productId: string) => {
      setSavedIds((prev) => {
        const next = prev.includes(productId)
          ? prev.filter((id) => id !== productId)
          : [...prev, productId];
        saveToStorage(next);
        return next;
      });
    },
    [saveToStorage]
  );

  const removePiece = useCallback(
    (productId: string) => {
      setSavedIds((prev) => {
        const next = prev.filter((id) => id !== productId);
        saveToStorage(next);
        return next;
      });
    },
    [saveToStorage]
  );

  const clearAllSaved = useCallback(() => {
    setSavedIds([]);
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch (e) {
      console.warn(e);
    }
  }, []);

  const isSaved = useCallback(
    (productId: string) => savedIds.includes(productId),
    [savedIds]
  );

  const savedProducts: Product[] = savedIds
    .map((id) => PRODUCTS.find((p) => p.id === id || p.slug === id))
    .filter((p): p is Product => Boolean(p));

  const totalInvestment = savedProducts.reduce((sum, item) => sum + item.priceUSD, 0);

  return {
    savedIds,
    savedProducts,
    totalInvestment,
    toggleSavePiece,
    removePiece,
    clearAllSaved,
    isSaved,
    count: savedIds.length,
  };
}
