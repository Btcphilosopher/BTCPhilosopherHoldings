export interface FinishOption {
  id: string;
  name: string;
  type: 'wood' | 'upholstery' | 'leather' | 'stone';
  swatchHex: string;
  inStock: boolean;
  image?: string;
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  subtitle: string;
  room: 'living' | 'dining' | 'bedroom' | 'workspace';
  roomLabel: string;
  priceUSD: number;
  dimensions: {
    imperial: string;
    metric: string;
    seatHeight?: string;
    clearance?: string;
  };
  primaryMaterial: string;
  materials: string[];
  description: string;
  narrative: string;
  finishes: FinishOption[];
  features: string[];
  careInstructions: {
    routine: string;
    periodic: string;
    prevention: string;
  };
  leadTime: string;
  weight: string;
  image: string;
  detailImages: { url: string; caption: string }[];
  hotspot?: {
    xPercent: number; // percentage from left on the Hudson Valley room photo
    yPercent: number; // percentage from top
    label: string;
  };
}

export interface MaterialInfo {
  id: string;
  name: string;
  type: 'hardwood' | 'textile' | 'leather' | 'stone';
  subtitle: string;
  origin: string;
  swatchColor: string;
  image: string;
  character: string;
  tactileNote: string;
  careGuidance: string;
  associatedProductSlugs: string[];
}

export const MATERIALS_DATA: MaterialInfo[] = [
  {
    id: 'walnut',
    name: 'American Black Walnut',
    type: 'hardwood',
    subtitle: 'Juglans nigra · Responsibly harvested in New York & Pennsylvania',
    origin: 'Eastern Deciduous Hardwood Belt, USA',
    swatchColor: '#49372B',
    image: '/materials/american-walnut.png',
    character: 'Rich dark espresso heartwood with flowing honey-amber grain patterns and natural chatoyancy. Air-dried and slow-cured to maintain internal cellular tension.',
    tactileNote: 'Silky, warm to the hand, finished with zero-VOC organic cold-pressed walnut oil and beeswax.',
    careGuidance: 'Dust weekly with a dry, lint-free cloth. Re-nourish twice yearly with organic beeswax balm. Avoid prolonged direct moisture or harsh industrial solvents.',
    associatedProductSlugs: ['hudson-sofa', 'stillwater-lounge-chair', 'ridge-coffee-table', 'mercer-dining-chair', 'laurel-bed', 'oakhaven-credenza', 'sylvan-desk'],
  },
  {
    id: 'oak',
    name: 'Quartersawn White Oak',
    type: 'hardwood',
    subtitle: 'Quercus alba · Appalachian and Hudson Highlands forestry',
    origin: 'Appalachian Highlands, USA',
    swatchColor: '#A48B6E',
    image: '/materials/american-walnut.png',
    character: 'Distinguished by straight vertical grain lines and striking medullary ray flecks. Exceptional structural density and dimensional stability.',
    tactileNote: 'Fine-grained texture with an honest, matte tactile grain that gains a golden honey patina with age.',
    careGuidance: 'Wipe along the direction of grain using a barely damp chamois cloth. Avoid silicon sprays or acidic cleaners.',
    associatedProductSlugs: ['fieldstone-dining-table', 'mercer-dining-chair', 'laurel-bed', 'oakhaven-credenza'],
  },
  {
    id: 'linen',
    name: 'Oatmeal Belgian Linen',
    type: 'textile',
    subtitle: '100% Unbleached Master of Linen® certified flax',
    origin: 'Flanders, Belgium (Woven by historic family mills)',
    swatchColor: '#DDD4C4',
    image: '/materials/oatmeal-linen.png',
    character: 'Substantial 520 gsm weave featuring natural slubs and subtle flax color variations. Exceptionally breathable, naturally hypoallergenic, and softens with every sitting.',
    tactileNote: 'Substantial, softly textured weave with dry natural flax hand-feel and gentle drape.',
    careGuidance: 'Vacuum gently with a soft brush attachment. Blot spills promptly with distilled water; avoid vigorous rubbing or bleach.',
    associatedProductSlugs: ['hudson-sofa', 'stillwater-lounge-chair', 'mercer-dining-chair', 'laurel-bed'],
  },
  {
    id: 'leather',
    name: 'Saddle & Cognac Leather',
    type: 'leather',
    subtitle: 'Full-grain vegetable-tanned American steerhide',
    origin: 'Curwensville, Pennsylvania',
    swatchColor: '#A36D47',
    image: '/materials/cognac-leather.png',
    character: 'Pure uncorrected aniline leather tanned in chestnut and mimosa bark liquor pits over 60 days. Reveals natural skin hallmarks, grain variations, and will burnish to a rich amber luster.',
    tactileNote: 'Supple, glove-soft temper with immediate body warmth and a subtle natural bark aroma.',
    careGuidance: 'Gently buff scuffs with a horsehair brush. Apply a micro-amount of natural lanolin balm once per year. Keep clear of prolonged direct radiators.',
    associatedProductSlugs: ['stillwater-lounge-chair', 'hudson-sofa', 'mercer-dining-chair', 'sylvan-desk'],
  },
  {
    id: 'stone',
    name: 'Champlain Valley Limestone',
    type: 'stone',
    subtitle: 'Dense sedimentary stone with subtle calcified marine matrix',
    origin: 'Lake Champlain basin, Northern New York / Vermont',
    swatchColor: '#D8D0C4',
    image: '/materials/limestone-hearth.png',
    character: 'A soft stone of quiet gravitas. Micro-fossil impressions and delicate calcite veins run through an oatmeal-gray matrix, hand-honed to a non-reflective matte finish.',
    tactileNote: 'Cool, soothing velvet surface with rounded eased bullnose edges.',
    careGuidance: 'Penetrating-sealed before delivery. Clean with warm water and neutral pH stone cleanser. Wipe wine or citrus spills promptly.',
    associatedProductSlugs: ['fieldstone-dining-table', 'oakhaven-credenza'],
  },
];

export const PRODUCTS: Product[] = [
  {
    id: 'p-1',
    slug: 'hudson-sofa',
    name: 'Hudson Sofa',
    subtitle: 'Solid American black walnut and oatmeal Belgian flax linen',
    room: 'living',
    roomLabel: 'Living',
    priceUSD: 5850,
    dimensions: {
      imperial: '96" W × 38" D × 29" H',
      metric: '244 cm W × 96 cm D × 74 cm H',
      seatHeight: '17" (43 cm)',
      clearance: '5.5" underframe clearance',
    },
    primaryMaterial: 'Solid American Black Walnut & Belgian Linen',
    materials: ['Solid American Black Walnut', 'Oatmeal Belgian Linen', 'Down-wrapped High Resilience Foam', 'Mortise & Tenon Joinery'],
    description: 'A low, architectural sofa framed in solid American black walnut. Continuous exposed grain cradles deep, feather-wrapped cushions in unbleached Belgian linen.',
    narrative: 'The Hudson Sofa was designed around the idea of a generous, grounding horizon line. Rather than concealing the timber structure beneath fabric upholstery, we allow the hand-shaped walnut frame to remain completely visible. Traditional mortise-and-tenon joints celebrate the honesty of construction, while cushions filled with organic latex and ethically sourced waterfowl down deliver a quiet, enveloping comfort that never sags.',
    finishes: [
      { id: 'linen-oatmeal', name: 'Oatmeal Belgian Linen (Featured)', type: 'upholstery', swatchHex: '#DDD4C4', inStock: true },
      { id: 'linen-fog', name: 'Hudson Fog Woven Wool', type: 'upholstery', swatchHex: '#9E9A92', inStock: true },
      { id: 'leather-cognac', name: 'Saddle Cognac Leather', type: 'leather', swatchHex: '#A36D47', inStock: false },
      { id: 'wood-walnut', name: 'Oiled American Black Walnut Frame', type: 'wood', swatchHex: '#49372B', inStock: true },
      { id: 'wood-oak', name: 'Quartersawn White Oak Frame', type: 'wood', swatchHex: '#A48B6E', inStock: true },
    ],
    features: [
      'Individually matched solid American black walnut frame',
      'Double-sided reversible down-blend cushions for longevity',
      'Removable linen covers with concealed Swiss riri® brass zippers',
      'Reinforced webbed suspension with tempered carbon steel coils',
      'Hand-finished with natural beeswax and cold-pressed walnut oil',
    ],
    careInstructions: {
      routine: 'Fluff cushions weekly to maintain loft. Vacuum upholstery using a low-suction soft brush attachment.',
      periodic: 'Professionally dry clean linen slipcovers once every 18–24 months.',
      prevention: 'Position away from intense heat radiators to protect timber joinery tension.',
    },
    leadTime: '8–10 weeks (Handcrafted to order)',
    weight: '185 lbs (84 kg)',
    image: '/products/hudson-sofa.png',
    detailImages: [
      { url: '/products/hudson-sofa.png', caption: 'Full studio elevation with low-profile walnut apron' },
      { url: '/materials/oatmeal-linen.png', caption: 'Close-up of 520 gsm Belgian flax linen weave' },
      { url: '/assets/aistudio/3c1ab4c4-9e05-4cad-9308-58b5bb60597f_95822a6b.png', caption: 'In situ at the Hudson Valley residence alongside the hearth' },
    ],
    hotspot: {
      xPercent: 71,
      yPercent: 58,
      label: 'Hudson Sofa in Oatmeal Linen',
    },
  },
  {
    id: 'p-2',
    slug: 'stillwater-lounge-chair',
    name: 'Stillwater Lounge Chair',
    subtitle: 'Sculpted walnut armature with hand-stitched cognac saddle leather',
    room: 'living',
    roomLabel: 'Living & Study',
    priceUSD: 3200,
    dimensions: {
      imperial: '31" W × 34" D × 31" H',
      metric: '79 cm W × 86 cm D × 79 cm H',
      seatHeight: '16.5" (42 cm)',
      clearance: '6" floor clearance',
    },
    primaryMaterial: 'Solid Black Walnut & Vegetable-Tanned Saddle Leather',
    materials: ['Solid American Black Walnut', 'Full-Grain Steerhide Leather', 'High-Density Ergonomic Core', 'Solid Brass Hardware'],
    description: 'An architectural lounge chair defined by a 105-degree rake and beveled armrests. Full-grain saddle leather develops a deep amber patina with use.',
    narrative: 'Inspired by the quiet discipline of mid-century Shaker armchairs and Danish modernism, the Stillwater chair pares geometry down to its purest essentials. The armrests feature a gentle compound curve that rests naturally under the palm and forearm. Hand-dyed aniline leather is wrapped over multi-density foam and laced behind the timber backrest with heavy waxed linen cord.',
    finishes: [
      { id: 'leather-saddle', name: 'Saddle Cognac Leather (Featured)', type: 'leather', swatchHex: '#A36D47', inStock: true },
      { id: 'leather-espresso', name: 'Deep Espresso Steerhide', type: 'leather', swatchHex: '#28231F', inStock: true },
      { id: 'linen-oatmeal', name: 'Oatmeal Belgian Linen', type: 'upholstery', swatchHex: '#DDD4C4', inStock: true },
      { id: 'wood-walnut', name: 'American Black Walnut', type: 'wood', swatchHex: '#49372B', inStock: true },
    ],
    features: [
      'Compound-angled joinery designed for prolonged reading comfort',
      'Uncorrected full-grain steerhide retaining natural character marks',
      'Hand-burnished armrest edges with organic carnauba wax',
      'Concealed tension-rod internal support for structural rigidity',
    ],
    careInstructions: {
      routine: 'Wipe dust with a dry cotton cloth. Buff minor surface marks with the warmth of your fingertips.',
      periodic: 'Apply natural beeswax leather dressing once per year to preserve suppleness.',
      prevention: 'Avoid direct sunlight exposure to allow an even, gradual amber patina.',
    },
    leadTime: '6–8 weeks',
    weight: '52 lbs (24 kg)',
    image: '/products/stillwater-chair.png',
    detailImages: [
      { url: '/products/stillwater-chair.png', caption: 'Profile showing 105° architectural rake and mortise joints' },
      { url: '/materials/cognac-leather.png', caption: 'Vegetable-tanned full-grain steerhide texture and French seams' },
      { url: '/assets/aistudio/3c1ab4c4-9e05-4cad-9308-58b5bb60597f_95822a6b.png', caption: 'Paired with the hearth in the Hudson Valley living room' },
    ],
    hotspot: {
      xPercent: 23,
      yPercent: 64,
      label: 'Stillwater Chair in Cognac Leather',
    },
  },
  {
    id: 'p-3',
    slug: 'ridge-coffee-table',
    name: 'Ridge Coffee Table',
    subtitle: 'Sculptural solid black walnut plinth with organic perimeter',
    room: 'living',
    roomLabel: 'Living',
    priceUSD: 4100,
    dimensions: {
      imperial: '62" W × 36" D × 15" H',
      metric: '157 cm W × 91 cm D × 38 cm H',
      clearance: 'Plinth foundation, 2.5" shadow recess',
    },
    primaryMaterial: 'Solid Bookmatched American Black Walnut',
    materials: ['Solid American Black Walnut', 'Organic Beeswax & Tung Finish', 'Concealed Steel Cleats'],
    description: 'Carved from thick bookmatched walnut slabs. An asymmetrical, free-flowing silhouette rests upon two sculpted pedestals with continuous grain flow.',
    narrative: 'The Ridge Coffee Table is an homage to the contours of the Catskill and Hudson Highlands ridgelines. Rather than forcing wood into rigid rectangles, our woodworkers follow the natural grain flow of kiln-dried 8/4 walnut timbers. Underside edges are hand-beveled with a bullnose curve that feels sculpted and soft to the touch, resting on twin cantilevered timber pedestals.',
    finishes: [
      { id: 'walnut-natural', name: 'Natural American Black Walnut (Featured)', type: 'wood', swatchHex: '#49372B', inStock: true },
      { id: 'walnut-ebonized', name: 'Iron-Ebonized Black Walnut', type: 'wood', swatchHex: '#22201E', inStock: true },
      { id: 'oak-quartersawn', name: 'Quartersawn White Oak', type: 'wood', swatchHex: '#A48B6E', inStock: true },
    ],
    features: [
      'Hand-sculpted organic perimeter with continuous edge bevel',
      'Bookmatched top planks selected for dramatic medullary figuring',
      'Dual monolithic solid timber pedestals with concealed levelers',
      'Silky hand-rubbed finish resistant to water rings and warmth',
    ],
    careInstructions: {
      routine: 'Wipe with a soft, lint-free cloth dampened with warm water. Dry immediately.',
      periodic: 'Buff with high-purity walnut oil or beeswax paste once every 6 months.',
      prevention: 'Always use coasters for hot teapots or iced glasses.',
    },
    leadTime: '8–10 weeks',
    weight: '140 lbs (64 kg)',
    image: '/products/ridge-coffee-table.png',
    detailImages: [
      { url: '/products/ridge-coffee-table.png', caption: 'Sculpted organic profile and pedestal foundation' },
      { url: '/editorial/table-still-life.png', caption: 'Table surface with ceramic branch vase and art monograph' },
      { url: '/materials/american-walnut.png', caption: 'Deep heartwood walnut grain under afternoon window light' },
    ],
    hotspot: {
      xPercent: 54,
      yPercent: 69,
      label: 'Ridge Coffee Table in Solid Walnut',
    },
  },
  {
    id: 'p-4',
    slug: 'fieldstone-dining-table',
    name: 'Fieldstone Dining Table',
    subtitle: 'Honed Champlain limestone slab on quartersawn white oak trestle',
    room: 'dining',
    roomLabel: 'Dining',
    priceUSD: 6400,
    dimensions: {
      imperial: '98" W × 42" D × 30" H',
      metric: '249 cm W × 107 cm D × 76 cm H',
      seatHeight: 'Accommodates 8–10 seated guests',
      clearance: '28.25" leg clearance',
    },
    primaryMaterial: 'Champlain Valley Limestone & Quartersawn White Oak',
    materials: ['Honed Champlain Limestone (2" thick)', 'Solid Quartersawn White Oak', 'Internal Carbon Steel Sub-frame'],
    description: 'A monument of architectural dining. A two-inch honed limestone slab with gentle bullnose edges rests upon an open Shaker-inspired timber trestle.',
    narrative: 'Conceived for unhurried gatherings that stretch long into the evening. The Champlain Valley limestone top carries subtle impressions of ancient seabed fossils and faint charcoal veining, grounded by heavy, through-mortised oak trestle legs. The surface remains cool to the touch on summer afternoons and provides a tactile, non-reflective canvas for dinnerware and candlelight.',
    finishes: [
      { id: 'stone-champlain-oak', name: 'Champlain Limestone & White Oak (Featured)', type: 'stone', swatchHex: '#D8D0C4', inStock: true },
      { id: 'stone-champlain-walnut', name: 'Champlain Limestone & Black Walnut', type: 'wood', swatchHex: '#49372B', inStock: true },
    ],
    features: [
      'Velvet matte hand-honed stone surface with stain-resistant impregnator',
      'Engineered sub-frame dissipating point loads safely through trestle legs',
      'Through-tenon oak stretchers wedged with contrasting walnut keys',
      'Comfortably seats 8 for daily dining or 10 for festive gatherings',
    ],
    careInstructions: {
      routine: 'Wipe with pH-neutral stone soap and a microfiber cloth after meals.',
      periodic: 'Re-apply breathable stone sealant annually with an easy spray application.',
      prevention: 'Never use lemon, vinegar, or acidic cleaners directly on limestone.',
    },
    leadTime: '10–12 weeks',
    weight: '380 lbs (172 kg) — White glove installation included',
    image: '/materials/limestone-hearth.png',
    detailImages: [
      { url: '/materials/limestone-hearth.png', caption: 'Texture of honed Champlain Valley sedimentary limestone' },
      { url: '/materials/american-walnut.png', caption: 'Trestle joinery and solid timber base detailing' },
    ],
  },
  {
    id: 'p-5',
    slug: 'mercer-dining-chair',
    name: 'Mercer Dining Chair',
    subtitle: 'Steam-bent solid walnut frame with natural linen upholstery',
    room: 'dining',
    roomLabel: 'Dining',
    priceUSD: 1450,
    dimensions: {
      imperial: '21" W × 22" D × 31.5" H',
      metric: '53 cm W × 56 cm D × 80 cm H',
      seatHeight: '18.5" (47 cm)',
      clearance: 'Tuck-under design fits standard 30" tables',
    },
    primaryMaterial: 'Solid American Black Walnut & Belgian Linen',
    materials: ['Solid American Black Walnut', 'Oatmeal Belgian Linen', 'Multi-layer Lumbar Support', 'Felt Floor Glides'],
    description: 'An understated dining chair featuring a continuous curved steam-bent crest rail, slender tapered legs, and a gently padded linen seat.',
    narrative: 'Named for the historic Mercer Street workshops, this chair resolves the difficult balance between visual lightness and long-dinner comfort. The crest rail is steam-bent from a single plank of New York walnut, eliminating weak glue joints and allowing the natural wood grain to flow unbroken across the curved backrest.',
    finishes: [
      { id: 'linen-oatmeal-walnut', name: 'Oatmeal Belgian Linen & Walnut (Featured)', type: 'upholstery', swatchHex: '#DDD4C4', inStock: true },
      { id: 'leather-saddle-walnut', name: 'Saddle Leather & Walnut', type: 'leather', swatchHex: '#A36D47', inStock: true },
      { id: 'wool-olive-oak', name: 'Muted Olive Wool & White Oak', type: 'upholstery', swatchHex: '#757969', inStock: false },
    ],
    features: [
      'Single-plank steam-bent continuous backrest',
      'Curved ergonomic lumbar support calibrated for 3-hour dinners',
      'Solid through-dowel joints pinned with hardwood keys',
      'Fitted with protective natural wool felt floor glides',
    ],
    careInstructions: {
      routine: 'Wipe timber frame with dry lint-free cloth. Spot clean fabric with mild foam cleanser.',
      periodic: 'Tighten under-seat brass hex screws annually if needed.',
      prevention: 'Avoid dragging across uneven outdoor stone.',
    },
    leadTime: '6–8 weeks',
    weight: '18 lbs (8 kg)',
    image: '/products/stillwater-chair.png',
    detailImages: [
      { url: '/products/stillwater-chair.png', caption: 'Sculpted timber geometry and leather upholstery option' },
      { url: '/materials/oatmeal-linen.png', caption: 'Belgian linen seat detail with tailored corners' },
    ],
  },
  {
    id: 'p-6',
    slug: 'laurel-bed',
    name: 'Laurel Bed',
    subtitle: 'Cantilevered walnut platform bed with integrated floating nightstands',
    room: 'bedroom',
    roomLabel: 'Bedroom',
    priceUSD: 6900,
    dimensions: {
      imperial: 'King: 88" W × 94" L × 38" H (Headboard W with nightstands: 118")',
      metric: 'King: 224 cm W × 239 cm L × 96 cm H',
      seatHeight: 'Platform height: 11" (28 cm)',
      clearance: 'Recessed cantilever base creates floating effect',
    },
    primaryMaterial: 'Solid American Black Walnut & Belgian Linen Headboard',
    materials: ['Solid American Black Walnut', 'Upholstered Belgian Flax Linen', 'Concealed Solid Brass Hardware', 'European Slatted Mattress Support'],
    description: 'A low-slung platform bed that appears to float above the floor. Features an upholstered linen headboard, integrated bedside shelves, and warm under-rail illumination.',
    narrative: 'The Laurel Bed reimagines the bedroom as an unhurried, architectural retreat. The solid walnut frame features an internal cantilever steel chassis that lifts the bed into space, creating generous air and shadow beneath. Seamlessly integrated cantilever nightstands provide resting places for books and water carafes without cluttering the floor.',
    finishes: [
      { id: 'bed-walnut-linen', name: 'American Walnut & Oatmeal Linen (Featured)', type: 'wood', swatchHex: '#49372B', inStock: true },
      { id: 'bed-oak-linen', name: 'Quartersawn White Oak & Natural Linen', type: 'wood', swatchHex: '#A48B6E', inStock: true },
    ],
    features: [
      'Cantilevered platform creates an effortless floating architectural presence',
      'Padded linen headboard angled at 8° for comfortable evening reading',
      'Two integrated floating bedside ledges with concealed cable passthroughs',
      'Solid beech sprung slatted base eliminates box spring requirements',
    ],
    careInstructions: {
      routine: 'Vacuum fabric headboard gently with upholstery attachment.',
      periodic: 'Wipe walnut frame with a micro-damp cloth followed by dry towel.',
      prevention: 'Do not sit on the cantilever nightstand extensions.',
    },
    leadTime: '8–10 weeks',
    weight: '240 lbs (109 kg)',
    image: '/materials/american-walnut.png',
    detailImages: [
      { url: '/materials/american-walnut.png', caption: 'Walnut joinery and warm timber grain of the headboard' },
      { url: '/materials/oatmeal-linen.png', caption: 'Flax linen upholstered backrest panel' },
    ],
  },
  {
    id: 'p-7',
    slug: 'oakhaven-credenza',
    name: 'Oakhaven Credenza',
    subtitle: 'Slatted tambour storage credenza with inset Champlain stone top',
    room: 'dining',
    roomLabel: 'Dining & Living',
    priceUSD: 5200,
    dimensions: {
      imperial: '74" W × 20" D × 31" H',
      metric: '188 cm W × 51 cm D × 79 cm H',
      clearance: '7" slender timber legs allow robotic vacuums and light flow',
    },
    primaryMaterial: 'Solid American Black Walnut & Honed Limestone',
    materials: ['Solid American Black Walnut', 'Honed Champlain Limestone Top', 'Aromatic Cedar Interior Lining', 'Solid Brass Tambour Tracks'],
    description: 'A low-profile sideboard featuring whisper-quiet slatted tambour doors that glide around curved corners, topped with a slab of honed stone for serving.',
    narrative: 'Whether housing record collections in a sunlit living room or serving fine wine in an architectural dining room, the Oakhaven Credenza pairs precise mechanics with natural warmth. Individual solid walnut slats are backed with heavy canvas to form continuous sliding doors that vanish into concealed side pockets, revealing fragrant cedar shelves inside.',
    finishes: [
      { id: 'cred-walnut-stone', name: 'Black Walnut & Champlain Stone (Featured)', type: 'wood', swatchHex: '#49372B', inStock: true },
      { id: 'cred-oak-stone', name: 'White Oak & Honed Travertine', type: 'wood', swatchHex: '#A48B6E', inStock: true },
    ],
    features: [
      'Hand-crafted tambour doors glide seamlessly without swinging out into the room',
      'Inset 3/4" honed limestone surface ideal for cocktails and hot serving ware',
      'Solid American aromatic cedar interior shelves and cutlery drawer',
      'Concealed acoustic ventilation slots for media/audio components',
    ],
    careInstructions: {
      routine: 'Dust wooden slats with a soft microfiber brush. Wipe stone with clean water.',
      periodic: 'Apply dry graphite lubricant to tambour runners every 2 years if needed.',
      prevention: 'Do not force tambour doors beyond their natural track stop.',
    },
    leadTime: '8–10 weeks',
    weight: '195 lbs (88 kg)',
    image: '/materials/american-walnut.png',
    detailImages: [
      { url: '/materials/american-walnut.png', caption: 'Vertical timber slats and curved tambour corners' },
      { url: '/materials/limestone-hearth.png', caption: 'Inset Champlain Valley honed stone serving top' },
    ],
  },
  {
    id: 'p-8',
    slug: 'sylvan-desk',
    name: 'Sylvan Desk & Reading Table',
    subtitle: 'Mitered walnut work table with inset saddle leather blotter',
    room: 'workspace',
    roomLabel: 'Workspace & Library',
    priceUSD: 3800,
    dimensions: {
      imperial: '60" W × 28" D × 30" H',
      metric: '152 cm W × 71 cm D × 76 cm H',
      clearance: '25.5" knee clearance with shallow push drawer',
    },
    primaryMaterial: 'Solid American Black Walnut & Full-Grain Leather',
    materials: ['Solid American Black Walnut', 'Hand-Stitched Saddle Leather', 'Concealed Solid Brass Cable Hatch'],
    description: 'A disciplined workspace designed for quiet concentration. An inset cognac leather writing surface is flush-mounted into a pencil-mitered walnut table top.',
    narrative: 'In an era of disposable technology, the Sylvan Desk provides a lasting tactile anchor for creative and intellectual work. The full-grain leather blotter provides the ideal cushion for handwriting with fountain pen or resting laptop palms, while a rear timber flap swings up on friction hinges to conceal power bricks and cabling.',
    finishes: [
      { id: 'sylvan-walnut-saddle', name: 'Black Walnut & Saddle Leather (Featured)', type: 'wood', swatchHex: '#49372B', inStock: true },
      { id: 'sylvan-oak-espresso', name: 'White Oak & Espresso Leather', type: 'wood', swatchHex: '#A48B6E', inStock: true },
    ],
    features: [
      'Flush-inlaid vegetable-tanned steerhide writing blotter with edge-creasing',
      'Concealed central timber cable conduit with magnetic closure',
      'Slim push-to-open pencil drawer lined in soft wool felt',
      'Subtle knife-edge bevel on all four table perimeter sides',
    ],
    careInstructions: {
      routine: 'Dust timber with clean microfiber cloth. Condition leather blotter annually.',
      periodic: 'Check and tighten leg anchor bolts if moving desk across rooms.',
      prevention: 'Avoid placing bare boiling coffee mugs directly on the leather blotter.',
    },
    leadTime: '6–8 weeks',
    weight: '98 lbs (44 kg)',
    image: '/products/ridge-coffee-table.png',
    detailImages: [
      { url: '/materials/cognac-leather.png', caption: 'Hand-stitched saddle leather writing pad texture' },
      { url: '/materials/american-walnut.png', caption: 'Pencil-mitered walnut desk corner joinery' },
    ],
  },
];

export interface RoomCategory {
  id: 'living' | 'dining' | 'bedroom' | 'workspace';
  title: string;
  tagline: string;
  pieceCount: number;
  image: string;
  description: string;
}

export const ROOM_CATEGORIES: RoomCategory[] = [
  {
    id: 'living',
    title: 'Living',
    tagline: 'Quiet hearths & generous gatherings',
    pieceCount: 3,
    image: '/editorial/hudson-valley-room.png',
    description: 'Architectural seating, sculptural low tables, and textured armchairs anchored by the warmth of natural timber and leather.',
  },
  {
    id: 'dining',
    title: 'Dining',
    tagline: 'Ceremony, stone & unhurried evenings',
    pieceCount: 3,
    image: '/materials/limestone-hearth.png',
    description: 'Honed limestone trestles, steam-bent chairs, and tambour credenzas built to celebrate shared food and lingering conversations.',
  },
  {
    id: 'bedroom',
    title: 'Bedroom',
    tagline: 'Serene horizons & restorative shadow',
    pieceCount: 1,
    image: '/materials/american-walnut.png',
    description: 'Low-slung cantilever beds with integrated bedside wings, natural linen backrests, and whisper-quiet tactile storage.',
  },
  {
    id: 'workspace',
    title: 'Workspace',
    tagline: 'Disciplined focus & honest craft',
    pieceCount: 2,
    image: '/editorial/autumn-window.png',
    description: 'Tactile writing desks with inset saddle leather blotters, ergonomic lounge seating, and concealed architectural cable management.',
  },
];
