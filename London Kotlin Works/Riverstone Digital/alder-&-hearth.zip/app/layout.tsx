import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'ALDER & HEARTH | Considered American Furniture & Architectural Interiors',
  description: 'Concept American luxury furniture maker combining modernism, architectural simplicity, and honest materials. Handcrafted in the Hudson Valley tradition.',
  openGraph: {
    title: 'ALDER & HEARTH | Considered American Furniture',
    description: 'A quieter kind of extraordinary. Considered furniture. Honest materials. Room to live beautifully.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'ALDER & HEARTH | Considered American Furniture',
    description: 'A quieter kind of extraordinary. Considered furniture. Honest materials. Room to live beautifully.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className="min-h-screen bg-[#F5F1E9] text-[#28231F] font-sans antialiased selection:bg-[#49372B] selection:text-[#F5F1E9]" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
