'use client';

import React, { useState, useCallback } from 'react';
import { Header } from '@/components/Header';
import { Hero } from '@/components/Hero';
import { PhilosophyIntro } from '@/components/PhilosophyIntro';
import { ExploreByRoom } from '@/components/ExploreByRoom';
import { SelectedPieces } from '@/components/SelectedPieces';
import { MaterialsSection } from '@/components/MaterialsSection';
import { RoomStory } from '@/components/RoomStory';
import { DesignServices } from '@/components/DesignServices';
import { Footer } from '@/components/Footer';
import { ProductDetailModal } from '@/components/ProductDetailModal';
import { SavedPiecesDrawer } from '@/components/SavedPiecesDrawer';
import { SearchModal } from '@/components/SearchModal';
import { useSavedPieces } from '@/lib/useSavedPieces';
import { Product } from '@/lib/data';

export default function HomePage() {
  const {
    savedProducts,
    totalInvestment,
    toggleSavePiece,
    removePiece,
    clearAllSaved,
    isSaved,
    count: savedCount,
  } = useSavedPieces();

  // Modals & Drawers state
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isSavedDrawerOpen, setIsSavedDrawerOpen] = useState<boolean>(false);
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);

  // Filter state for collection view
  const [activeRoomFilter, setActiveRoomFilter] = useState<'all' | 'living' | 'dining' | 'bedroom' | 'workspace'>('all');

  const scrollToSection = useCallback((sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  }, []);

  const handleSelectRoomFromExplore = (room: 'living' | 'dining' | 'bedroom' | 'workspace') => {
    setActiveRoomFilter(room);
    scrollToSection('collection');
  };

  const handleEnquireFromProduct = (product: Product) => {
    setSelectedProduct(null);
    scrollToSection('design-services');
  };

  const handleStartConsultationWithShortlist = () => {
    setIsSavedDrawerOpen(false);
    scrollToSection('design-services');
  };

  return (
    <div className="min-h-screen bg-[#F5F1E9] text-[#28231F] flex flex-col selection:bg-[#49372B] selection:text-[#F5F1E9]">
      {/* Top Header */}
      <Header
        savedCount={savedCount}
        onOpenSavedDrawer={() => setIsSavedDrawerOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenConsultation={() => scrollToSection('design-services')}
        onNavigateSection={scrollToSection}
      />

      <main className="flex-1">
        {/* Full-width Photographic Hero */}
        <Hero
          onExploreCollection={() => scrollToSection('collection')}
          onExploreApproach={() => scrollToSection('approach')}
        />

        {/* Collection Introduction & Philosophy */}
        <PhilosophyIntro
          onLearnMore={() => scrollToSection('materials')}
        />

        {/* Explore By Room Asymmetric Layout */}
        <ExploreByRoom
          onSelectRoom={handleSelectRoomFromExplore}
        />

        {/* Selected Pieces Catalogue */}
        <SelectedPieces
          activeRoomFilter={activeRoomFilter}
          onFilterChange={setActiveRoomFilter}
          onSelectProduct={(p) => setSelectedProduct(p)}
          isSaved={isSaved}
          onToggleSave={toggleSavePiece}
        />

        {/* Tactile Materials Section */}
        <MaterialsSection
          onSelectProduct={(p) => setSelectedProduct(p)}
        />

        {/* Editorial Room Story: A Sunday in the Hudson Valley */}
        <RoomStory
          onSelectProduct={(p) => setSelectedProduct(p)}
          isSaved={isSaved}
          onToggleSave={toggleSavePiece}
        />

        {/* Design Consultation Planner Form */}
        <DesignServices
          savedProducts={savedProducts}
          prefilledProductId={selectedProduct?.id}
        />
      </main>

      {/* Footer */}
      <Footer
        onNavigateSection={scrollToSection}
        onFilterRoom={(room) => {
          setActiveRoomFilter(room);
        }}
      />

      {/* Product Detail Modal */}
      <ProductDetailModal
        key={selectedProduct?.id || 'none'}
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        isSaved={selectedProduct ? isSaved(selectedProduct.id) : false}
        onToggleSave={() => selectedProduct && toggleSavePiece(selectedProduct.id)}
        onEnquirePiece={handleEnquireFromProduct}
      />

      {/* Saved Pieces Shortlist Slide-over Drawer */}
      <SavedPiecesDrawer
        isOpen={isSavedDrawerOpen}
        onClose={() => setIsSavedDrawerOpen(false)}
        savedProducts={savedProducts}
        totalInvestment={totalInvestment}
        onRemovePiece={removePiece}
        onClearAll={clearAllSaved}
        onInspectProduct={(p) => setSelectedProduct(p)}
        onStartConsultationWithShortlist={handleStartConsultationWithShortlist}
      />

      {/* Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectProduct={(p) => setSelectedProduct(p)}
      />
    </div>
  );
}
