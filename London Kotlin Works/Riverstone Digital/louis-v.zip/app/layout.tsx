import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Louis Vuitton Official Digital Experience',
  description: 'Explore the Art of Travel, iconic Louis Vuitton handbag collections, the LV Digital Passport, interactive historical timeline, and bespoke AI personal styling.',
  openGraph: {
    title: 'Louis Vuitton Official Digital Experience',
    description: 'Explore the Art of Travel, iconic Louis Vuitton handbag collections, the LV Digital Passport, interactive historical timeline, and bespoke AI personal styling.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Louis Vuitton Official Digital Experience',
    description: 'Explore the Art of Travel, iconic Louis Vuitton handbag collections, the LV Digital Passport, interactive historical timeline, and bespoke AI personal styling.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark scroll-smooth">
      <body className="bg-[#0d0d0d] text-[#f3f3f3] selection:bg-[#c5a059] selection:text-black font-sans-lv" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
