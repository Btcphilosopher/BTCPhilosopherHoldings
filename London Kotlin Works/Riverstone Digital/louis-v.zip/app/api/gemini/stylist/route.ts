import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { prompt, selectedItem } = body;

    const systemInstruction = `You are the Louis Vuitton Private Concierge & Senior Bespoke Stylist at Maison Louis Vuitton, Paris. 
Your tone is deeply polite, refined, cultured, and authoritative regarding Louis Vuitton's heritage since 1854, exquisite leather craftsmanship (Monogram Canvas, Damier Ebene, Epi, Taïga, Empreinte, Mahina), iconic trunks, and high-fashion styling.
You provide advice on:
1. Styling Louis Vuitton bags, ready-to-wear, and accessories for formal galas, urban chic, and luxury travel.
2. Bespoke travel packing guides for elite global destinations (e.g., Paris, Saint-Tropez, Tokyo, Aspen, Venice, Amalfi Coast).
3. Monogram personalization (Hotstamping) ideas and heritage history.
4. Product care and longevity for luxury leather goods.

Keep responses elegant, concise, structured with polished headings or bullet points. Speak with warm Parisian high-fashion authority.`;

    const userMessage = selectedItem 
      ? `Regarding the ${selectedItem.name} (${selectedItem.category}, $${selectedItem.price}): ${prompt || "Provide luxury styling advice and travel recommendations for this piece."}`
      : (prompt || "What are the essential Louis Vuitton travel trunks and handbags for a weekend in Paris?");

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: userMessage,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    return NextResponse.json({ text: response.text });
  } catch (error: any) {
    console.error("Louis Vuitton Concierge API Error:", error);
    return NextResponse.json(
      { error: "Our Private Concierge is currently attending to another client. Please refresh or try again momentarily." },
      { status: 500 }
    );
  }
}
