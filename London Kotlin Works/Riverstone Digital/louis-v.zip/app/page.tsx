'use client';

import React, { useState } from 'react';
import Navbar from '@/components/Navbar';
import HeroTravel from '@/components/HeroTravel';
import NewSeasonGrid from '@/components/NewSeasonGrid';
import DualMaisonPassport from '@/components/DualMaisonPassport';
import ProductCatalogSection from '@/components/ProductCatalogSection';
import ProductDetailModal from '@/components/ProductDetailModal';
import ShoppingBagDrawer, { CartItem } from '@/components/ShoppingBagDrawer';
import DigitalPassportModal from '@/components/DigitalPassportModal';
import TimelineModal from '@/components/TimelineModal';
import AiStylistDrawer from '@/components/AiStylistDrawer';
import StoreLocatorModal from '@/components/StoreLocatorModal';
import AccountModal from '@/components/AccountModal';
import SearchModal from '@/components/SearchModal';
import Footer from '@/components/Footer';
import { Product } from '@/lib/products';

export default function Home() {
  // State management
  const [activeCategory, setActiveCategory] = useState('ALL');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isPassportOpen, setIsPassportOpen] = useState(false);
  const [passportInitialId, setPassportInitialId] = useState('LV-PASSPORT-2026-SP8921');
  const [isTimelineOpen, setIsTimelineOpen] = useState(false);
  const [isStylistOpen, setIsStylistOpen] = useState(false);
  const [isStoresOpen, setIsStoresOpen] = useState(false);
  const [isAccountOpen, setIsAccountOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);

  // Cart operations
  const handleAddToCart = (product: Product, initials?: string) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id && item.initials === initials);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id && item.initials === initials
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1, initials }];
    });
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveItem(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, quantity } : item))
    );
  };

  const handleRemoveItem = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  // Handlers for cross-modal navigation
  const handleOpenPassportForProduct = (passportId: string) => {
    setPassportInitialId(passportId);
    setQuickViewProduct(null);
    setIsPassportOpen(true);
  };

  const handleOpenStylistForProduct = (product: Product) => {
    setQuickViewProduct(product);
    setIsStylistOpen(true);
  };

  const handleSelectCategory = (category: string) => {
    setActiveCategory(category);
    // Smooth scroll down to catalog if selecting category
    if (category !== 'ALL') {
      const el = document.getElementById('catalog');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#0d0d0d] text-[#f3f3f3] flex flex-col justify-between selection:bg-[#d4af37] selection:text-black font-sans-lv">
      {/* 1. Header Navigation */}
      <Navbar
        cartCount={cart.reduce((acc, item) => acc + item.quantity, 0)}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenPassport={() => setIsPassportOpen(true)}
        onOpenStores={() => setIsStoresOpen(true)}
        onOpenStylist={() => setIsStylistOpen(true)}
        onOpenAccount={() => setIsAccountOpen(true)}
        activeCategory={activeCategory}
        onSelectCategory={handleSelectCategory}
      />

      <main className="flex-1">
        {/* 2. Hero Section "THE ART OF TRAVEL" */}
        <HeroTravel
          onDiscoverClick={() => handleSelectCategory('TRAVEL')}
          onOpenStylist={() => setIsStylistOpen(true)}
        />

        {/* 3. Section 2 "THE NEW SEASON ——" */}
        <NewSeasonGrid onSelectCategory={handleSelectCategory} />

        {/* 4. Section 3 "EXPLORE THE MAISON 1854 — NOW" & "LV DIGITAL PASSPORT" */}
        <DualMaisonPassport
          onOpenTimeline={() => setIsTimelineOpen(true)}
          onOpenPassport={() => setIsPassportOpen(true)}
        />

        {/* 5. Product Catalog & E-Commerce Grid */}
        <ProductCatalogSection
          selectedCategory={activeCategory}
          onSelectCategory={setActiveCategory}
          onQuickView={(p) => setQuickViewProduct(p)}
          onAddToCart={handleAddToCart}
          onOpenStylistForProduct={handleOpenStylistForProduct}
        />
      </main>

      {/* 6. Footer */}
      <Footer
        onOpenStores={() => setIsStoresOpen(true)}
        onOpenPassport={() => setIsPassportOpen(true)}
        onOpenTimeline={() => setIsTimelineOpen(true)}
      />

      {/* MODALS & DRAWERS */}
      {/* Quick View Product Modal */}
      <ProductDetailModal
        product={quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
        onAddToCart={handleAddToCart}
        onOpenStylistForProduct={handleOpenStylistForProduct}
        onOpenPassportForProduct={handleOpenPassportForProduct}
      />

      {/* Shopping Bag Slide-Over Drawer */}
      <ShoppingBagDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

      {/* LV Digital Passport Inspector Modal */}
      {isPassportOpen && (
        <DigitalPassportModal
          initialPassportId={passportInitialId}
          onClose={() => setIsPassportOpen(false)}
        />
      )}

      {/* 1854 - NOW Timeline Journey Modal */}
      {isTimelineOpen && (
        <TimelineModal onClose={() => setIsTimelineOpen(false)} />
      )}

      {/* AI Personal Stylist & Concierge Drawer */}
      <AiStylistDrawer
        isOpen={isStylistOpen}
        onClose={() => setIsStylistOpen(false)}
        selectedProduct={quickViewProduct}
      />

      {/* Global Store Locator Modal */}
      {isStoresOpen && (
        <StoreLocatorModal onClose={() => setIsStoresOpen(false)} />
      )}

      {/* Client Account Modal */}
      {isAccountOpen && (
        <AccountModal
          onClose={() => setIsAccountOpen(false)}
          onOpenPassport={() => {
            setIsAccountOpen(false);
            setIsPassportOpen(true);
          }}
        />
      )}

      {/* Live Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onQuickView={(p) => setQuickViewProduct(p)}
        onAddToCart={handleAddToCart}
      />
    </div>
  );
}
