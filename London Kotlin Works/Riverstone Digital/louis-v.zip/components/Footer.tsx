'use client';

import React, { useState } from 'react';
import { Instagram, Youtube, Facebook, PinIcon as Pinterest, Mail, Check } from 'lucide-react';

interface FooterProps {
  onOpenStores: () => void;
  onOpenPassport: () => void;
  onOpenTimeline: () => void;
}

export default function Footer({ onOpenStores, onOpenPassport, onOpenTimeline }: FooterProps) {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail) return;
    setSubscribed(true);
    setTimeout(() => setSubscribed(false), 3000);
    setNewsletterEmail('');
  };

  return (
    <footer className="bg-[#080808] text-white border-t border-white/10 pt-16 pb-12 px-6 lg:px-12 font-sans-lv">
      <div className="max-w-[1800px] mx-auto space-y-12">
        {/* Main Footer Links & Newsletter */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 border-b border-white/10 pb-12 text-xs">
          {/* Column 1: Maison Heritage */}
          <div className="space-y-3">
            <h4 className="text-sm font-serif-lv tracking-widest text-[#d4af37] uppercase font-medium">MAISON HERITAGE</h4>
            <ul className="space-y-2 text-white/70">
              <li>
                <button onClick={onOpenTimeline} className="hover:text-white transition-colors cursor-pointer">
                  The Story Since 1854
                </button>
              </li>
              <li>
                <button onClick={onOpenPassport} className="hover:text-white transition-colors cursor-pointer">
                  LV Digital Passport & Provenance
                </button>
              </li>
              <li>
                <a href="#catalog" className="hover:text-white transition-colors">
                  Haute Maroquinerie Ateliers
                </a>
              </li>
              <li>
                <a href="#catalog" className="hover:text-white transition-colors">
                  Art of Travel Exhibitions
                </a>
              </li>
            </ul>
          </div>

          {/* Column 2: Client Services */}
          <div className="space-y-3">
            <h4 className="text-sm font-serif-lv tracking-widest text-[#d4af37] uppercase font-medium">CLIENT SERVICES</h4>
            <ul className="space-y-2 text-white/70">
              <li>
                <button onClick={onOpenStores} className="hover:text-white transition-colors cursor-pointer">
                  Find a Maison Store
                </button>
              </li>
              <li>
                <span className="text-white/50">Complimentary Express Delivery & Returns</span>
              </li>
              <li>
                <span className="text-white/50">Hotstamping & Monogram Customization</span>
              </li>
              <li>
                <span className="text-white/50">Artisan Care & Leather Restoration</span>
              </li>
            </ul>
          </div>

          {/* Column 3: Sustainability */}
          <div className="space-y-3">
            <h4 className="text-sm font-serif-lv tracking-widest text-[#d4af37] uppercase font-medium">SUSTAINABILITY</h4>
            <p className="text-white/60 font-light leading-relaxed">
              Committed to preserve natural resources, ensure 100% material traceability, and craft products designed to last for generations.
            </p>
            <button onClick={onOpenPassport} className="text-[#d4af37] underline cursor-pointer hover:text-white transition-colors">
              Read 2026 Circularity Report
            </button>
          </div>

          {/* Column 4: Newsletter Subscription */}
          <div className="space-y-3">
            <h4 className="text-sm font-serif-lv tracking-widest text-[#d4af37] uppercase font-medium">NEWSLETTER</h4>
            <p className="text-white/60 font-light">
              Subscribe to receive private invitations to new collection unveilings and haute maroquinerie previews.
            </p>

            <form onSubmit={handleSubscribe} className="flex gap-2 pt-1">
              <input
                type="email"
                required
                placeholder="Enter your email address..."
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                className="flex-1 p-2 bg-[#181818] border border-white/20 text-xs text-white placeholder-white/40 rounded-sm focus:outline-none focus:border-[#d4af37]"
              />
              <button
                type="submit"
                className="p-2 bg-[#d4af37] text-black font-bold rounded-sm hover:bg-white transition-colors cursor-pointer shrink-0"
                title="Subscribe"
              >
                {subscribed ? <Check className="w-4 h-4 text-black" /> : <Mail className="w-4 h-4" />}
              </button>
            </form>
            {subscribed && (
              <p className="text-[10px] text-emerald-400">Thank you. You have been registered for private Maison updates.</p>
            )}
          </div>
        </div>

        {/* Bottom Bar matching Mock Image explicitly */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 text-xs text-white/70">
          {/* Left: LOUIS VUITTON —— SINCE 1854 */}
          <div className="flex items-center gap-3 font-serif-lv tracking-[0.2em] uppercase font-light text-sm">
            <span className="text-white font-medium">LOUIS VUITTON</span>
            <span className="w-8 h-[1px] bg-[#d4af37]" />
            <span className="text-white/60">SINCE 1854</span>
          </div>

          {/* Center Links */}
          <div className="flex flex-wrap items-center gap-6 tracking-[0.15em] font-medium text-[11px] uppercase">
            <button onClick={onOpenPassport} className="hover:text-[#d4af37] transition-colors cursor-pointer">
              SUSTAINABILITY
            </button>
            <span className="text-white/20">|</span>
            <button onClick={onOpenStores} className="hover:text-[#d4af37] transition-colors cursor-pointer">
              SERVICES
            </button>
            <span className="text-white/20">|</span>
            <button onClick={onOpenStores} className="hover:text-[#d4af37] transition-colors cursor-pointer">
              STORES
            </button>
            <span className="text-white/20">|</span>
            <span className="hover:text-[#d4af37] transition-colors cursor-pointer">
              NEWSLETTER
            </span>
          </div>

          {/* Right Social Icons */}
          <div className="flex items-center gap-4 text-white/60">
            <a href="https://instagram.com" target="_blank" rel="noreferrer" className="hover:text-[#d4af37] transition-colors" aria-label="Instagram">
              <Instagram className="w-4 h-4" />
            </a>
            <a href="https://youtube.com" target="_blank" rel="noreferrer" className="hover:text-[#d4af37] transition-colors" aria-label="YouTube">
              <Youtube className="w-4 h-4" />
            </a>
            <a href="https://facebook.com" target="_blank" rel="noreferrer" className="hover:text-[#d4af37] transition-colors" aria-label="Facebook">
              <Facebook className="w-4 h-4" />
            </a>
            <a href="https://pinterest.com" target="_blank" rel="noreferrer" className="hover:text-[#d4af37] transition-colors" aria-label="Pinterest">
              <Pinterest className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
