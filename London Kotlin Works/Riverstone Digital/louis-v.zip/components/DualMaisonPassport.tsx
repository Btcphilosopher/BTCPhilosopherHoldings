'use client';

import React from 'react';
import { ArrowRight, CheckCircle2, ShieldCheck, Sparkles, UserCheck, Layers, Wrench, Shield, Compass } from 'lucide-react';

interface DualMaisonPassportProps {
  onOpenTimeline: () => void;
  onOpenPassport: () => void;
}

export default function DualMaisonPassport({ onOpenTimeline, onOpenPassport }: DualMaisonPassportProps) {
  return (
    <section className="grid grid-cols-1 lg:grid-cols-2 border-b border-white/10 overflow-hidden">
      {/* Left Column: EXPLORE THE MAISON 1854 — NOW (Dark Section) */}
      <div className="relative min-h-[580px] p-8 lg:p-14 flex flex-col justify-between bg-[#0a0a0a] text-white border-b lg:border-b-0 lg:border-r border-white/10 group">
        {/* Background Image with Scrim */}
        <div className="absolute inset-0 z-0">
          <img
            src="/src/assets/images/lv_maison_trunk_1791038920083.jpg"
            alt="Maison Trunk 1854"
            className="w-full h-full object-cover opacity-35 img-zoom"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-black/40" />
        </div>

        {/* Content */}
        <div className="relative z-10 space-y-4">
          <p className="text-xs tracking-[0.3em] font-medium text-[#d4af37] uppercase">
            EXPLORE THE MAISON
          </p>

          <h2 className="text-4xl md:text-6xl font-serif-lv tracking-[0.15em] font-light text-white uppercase flex items-center gap-4">
            <span>1854</span>
            <span className="w-12 h-[1px] bg-[#d4af37]" />
            <span>NOW</span>
          </h2>

          <p className="text-sm font-light text-white/80 max-w-md leading-relaxed">
            A story of innovation, craftsmanship and a vision for tomorrow. Hand-crafted trunks and luxury maroquinerie passed down through generations.
          </p>

          <div className="pt-2">
            <button
              onClick={onOpenTimeline}
              className="group/btn inline-flex items-center gap-3 text-xs tracking-[0.25em] text-white uppercase font-semibold border-b border-white/50 pb-1 hover:border-[#d4af37] hover:text-[#d4af37] transition-all cursor-pointer"
            >
              <span>EXPLORE THE TIMELINE</span>
              <ArrowRight className="w-4 h-4 transform group-hover/btn:translate-x-1.5 transition-transform text-[#d4af37]" />
            </button>
          </div>
        </div>

        {/* Interactive Horizontal Timeline Axis (Matches Mock Image) */}
        <div className="relative z-10 pt-12 border-t border-white/15 mt-8">
          <div className="flex items-center justify-between text-xs tracking-wider text-white/70 overflow-x-auto pb-2 scrollbar-none gap-4">
            <div 
              onClick={onOpenTimeline}
              className="flex flex-col gap-1 cursor-pointer hover:text-[#d4af37] transition-colors shrink-0"
            >
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#d4af37]" />
                <span className="font-mono text-sm font-bold text-white">1854</span>
              </div>
              <span className="text-[10px] text-white/50 uppercase">Foundation</span>
            </div>

            <div className="w-8 h-[1px] bg-white/20 shrink-0" />

            <div 
              onClick={onOpenTimeline}
              className="flex flex-col gap-1 cursor-pointer hover:text-[#d4af37] transition-colors shrink-0"
            >
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-white/40" />
                <span className="font-mono text-sm font-bold text-white/90">1896</span>
              </div>
              <span className="text-[10px] text-white/50 uppercase">Monogram</span>
            </div>

            <div className="w-8 h-[1px] bg-white/20 shrink-0" />

            <div 
              onClick={onOpenTimeline}
              className="flex flex-col gap-1 cursor-pointer hover:text-[#d4af37] transition-colors shrink-0"
            >
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-white/40" />
                <span className="font-mono text-sm font-bold text-white/90">1901</span>
              </div>
              <span className="text-[10px] text-white/50 uppercase">Steamer Trunk</span>
            </div>

            <div className="w-8 h-[1px] bg-white/20 shrink-0" />

            <div 
              onClick={onOpenTimeline}
              className="flex flex-col gap-1 cursor-pointer hover:text-[#d4af37] transition-colors shrink-0"
            >
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-white/40" />
                <span className="font-mono text-sm font-bold text-white/90">1930s</span>
              </div>
              <span className="text-[10px] text-white/50 uppercase">Art of Travel</span>
            </div>

            <div className="w-8 h-[1px] bg-white/20 shrink-0" />

            <div 
              onClick={onOpenTimeline}
              className="flex flex-col gap-1 cursor-pointer hover:text-[#d4af37] transition-colors shrink-0"
            >
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#d4af37] animate-pulse" />
                <span className="font-mono text-sm font-bold text-[#d4af37]">TODAY</span>
              </div>
              <span className="text-[10px] text-[#d4af37]/80 uppercase">Fashion · Art · Tech →</span>
            </div>
          </div>
        </div>
      </div>

      {/* Right Column: LV DIGITAL PASSPORT (Light Off-White Section) */}
      <div className="bg-[#e8e4dc] text-[#1a1a1a] p-8 lg:p-14 flex flex-col justify-between relative overflow-hidden">
        {/* Fabric Texture Background Effect */}
        <div className="absolute inset-0 opacity-15 pointer-events-none bg-[radial-gradient(#1a1a1a_1px,transparent_1px)] [background-size:16px_16px]" />

        <div className="relative z-10 space-y-4">
          <p className="text-xs tracking-[0.3em] font-semibold text-[#8c6d33] uppercase">
            AUTHENTICITY & PROVENANCE
          </p>

          <h2 className="text-3xl md:text-5xl font-serif-lv tracking-[0.12em] font-light uppercase text-[#1a1a1a]">
            LV DIGITAL PASSPORT
          </h2>

          <p className="text-xs md:text-sm text-[#4a4a4a] tracking-wide font-normal max-w-md">
            Authenticity. Transparency. A more sustainable future. Trace your product’s creation from French ateliers to repair services.
          </p>

          <div>
            <button
              onClick={onOpenPassport}
              className="group/passport inline-flex items-center gap-3 text-xs tracking-[0.25em] text-[#1a1a1a] font-bold uppercase border-b border-[#1a1a1a]/60 pb-1 hover:border-[#8c6d33] hover:text-[#8c6d33] transition-all cursor-pointer"
            >
              <span>EXPLORE YOUR PRODUCT</span>
              <ArrowRight className="w-4 h-4 transform group-hover/passport:translate-x-1.5 transition-transform text-[#8c6d33]" />
            </button>
          </div>
        </div>

        {/* Features & Smartphone Graphic Layout */}
        <div className="relative z-10 grid grid-cols-1 sm:grid-cols-2 gap-6 items-center pt-8 border-t border-[#1a1a1a]/15 mt-8">
          {/* Left: Luxury Feature Checklist */}
          <div className="space-y-2 text-[11px] tracking-[0.15em] font-semibold uppercase text-[#2c2c2c]">
            <div className="flex items-center gap-2 hover:text-[#8c6d33] transition-colors cursor-pointer" onClick={onOpenPassport}>
              <CheckCircle2 className="w-4 h-4 text-[#8c6d33]" />
              <span>AUTHENTICITY</span>
            </div>
            <div className="flex items-center gap-2 hover:text-[#8c6d33] transition-colors cursor-pointer" onClick={onOpenPassport}>
              <Sparkles className="w-4 h-4 text-[#8c6d33]" />
              <span>CRAFTSMANSHIP</span>
            </div>
            <div className="flex items-center gap-2 hover:text-[#8c6d33] transition-colors cursor-pointer" onClick={onOpenPassport}>
              <Layers className="w-4 h-4 text-[#8c6d33]" />
              <span>MATERIALS</span>
            </div>
            <div className="flex items-center gap-2 hover:text-[#8c6d33] transition-colors cursor-pointer" onClick={onOpenPassport}>
              <Compass className="w-4 h-4 text-[#8c6d33]" />
              <span>ORIGIN ATELIER</span>
            </div>
            <div className="flex items-center gap-2 hover:text-[#8c6d33] transition-colors cursor-pointer" onClick={onOpenPassport}>
              <Shield className="w-4 h-4 text-[#8c6d33]" />
              <span>CARE GUIDE</span>
            </div>
            <div className="flex items-center gap-2 hover:text-[#8c6d33] transition-colors cursor-pointer" onClick={onOpenPassport}>
              <Wrench className="w-4 h-4 text-[#8c6d33]" />
              <span>REPAIR HISTORY</span>
            </div>
            <div className="flex items-center gap-2 hover:text-[#8c6d33] transition-colors cursor-pointer" onClick={onOpenPassport}>
              <UserCheck className="w-4 h-4 text-[#8c6d33]" />
              <span>DIGITAL OWNERSHIP</span>
            </div>
          </div>

          {/* Right: Mock iPhone Frame displaying Digital Passport (Matches Mock Image Graphic) */}
          <div 
            onClick={onOpenPassport}
            className="relative mx-auto sm:mr-0 w-[180px] h-[340px] bg-black rounded-[36px] p-2.5 border-[4px] border-[#2a2a2a] shadow-2xl hover:scale-105 transition-transform cursor-pointer group/phone"
          >
            {/* iPhone Dynamic Island */}
            <div className="absolute top-4 left-1/2 -translate-x-1/2 w-16 h-3 bg-black rounded-full z-20" />

            {/* Screen Content */}
            <div className="w-full h-full bg-[#121212] rounded-[28px] p-3 text-white flex flex-col justify-between overflow-hidden border border-white/10">
              <div className="text-center pt-4 space-y-1">
                <div className="text-xs font-serif-lv font-bold text-[#d4af37] tracking-widest">LV</div>
                <div className="text-[9px] font-mono tracking-widest text-white/60 uppercase">DIGITAL PASSPORT</div>
              </div>

              {/* Product Thumbnail inside phone */}
              <div className="my-auto space-y-2 text-center">
                <div className="w-20 h-20 mx-auto rounded-full overflow-hidden border border-[#d4af37]/40 p-1 bg-black">
                  <img
                    src="/src/assets/images/lv_women_collection_1791038885439.jpg"
                    alt="Speedy 25"
                    className="w-full h-full object-cover rounded-full"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="text-xs font-serif-lv tracking-wider text-white">Speedy 25</div>
                <div className="text-[9px] text-white/60 font-mono">Monogram Canvas</div>
              </div>

              {/* Phone Button */}
              <button className="w-full py-1.5 bg-[#d4af37] text-black font-bold text-[9px] tracking-widest rounded-full uppercase hover:bg-white transition-colors">
                VIEW DETAILS
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
