'use client';

import React, { useState } from 'react';
import { ArrowRight, ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface HeroTravelProps {
  onDiscoverClick: () => void;
  onOpenStylist: () => void;
}

const HERO_SLIDES = [
  {
    id: 'travel',
    kicker: 'THE ART OF',
    title: 'TRAVEL',
    tagline: 'A journey through time, culture and craftsmanship.',
    cta: 'DISCOVER THE COLLECTION',
    image: '/src/assets/images/lv_hero_travel_1791038872689.jpg',
    category: 'TRAVEL'
  },
  {
    id: 'women',
    kicker: 'THE NEW SEASON',
    title: 'WOMEN',
    tagline: 'Parisian elegance woven with iconic Monogram heritage.',
    cta: 'EXPLORE HANDBAGS',
    image: '/src/assets/images/lv_women_collection_1791038885439.jpg',
    category: 'HANDBAGS'
  },
  {
    id: 'men',
    kicker: 'SAVOIR-FAIRE',
    title: 'MEN',
    tagline: 'Modern tailoring and luxury leather craftsmanship for the contemporary traveler.',
    cta: 'EXPLORE MEN',
    image: '/src/assets/images/lv_men_collection_1791038897186.jpg',
    category: 'MEN'
  },
  {
    id: 'maison',
    kicker: 'HERITAGE SINCE 1854',
    title: 'MAISON TRUNKS',
    tagline: 'Centuries of bespoke trunk craftsmanship handmade in Asnières-sur-Seine.',
    cta: 'DISCOVER THE MAISON',
    image: '/src/assets/images/lv_maison_trunk_1791038920083.jpg',
    category: 'MAISON'
  }
];

export default function HeroTravel({ onDiscoverClick, onOpenStylist }: HeroTravelProps) {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);

  const slide = HERO_SLIDES[currentSlideIndex];

  const handleNext = () => {
    setCurrentSlideIndex((prev) => (prev + 1) % HERO_SLIDES.length);
  };

  const handlePrev = () => {
    setCurrentSlideIndex((prev) => (prev - 1 + HERO_SLIDES.length) % HERO_SLIDES.length);
  };

  return (
    <section className="relative w-full h-[75vh] min-h-[580px] max-h-[850px] overflow-hidden bg-[#0a0a0a] border-b border-white/10">
      <AnimatePresence mode="wait">
        <motion.div
          key={slide.id}
          initial={{ opacity: 0, scale: 1.03 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="absolute inset-0 w-full h-full"
        >
          {/* Background Image with Scrim Overlay */}
          <img
            src={slide.image}
            alt={slide.title}
            className="w-full h-full object-cover object-center"
            referrerPolicy="no-referrer"
          />
          {/* Gradient Scrim */}
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-black/20" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-black/30" />
        </motion.div>
      </AnimatePresence>

      {/* Hero Content Overlay (Matches Image Pixel-Perfectly) */}
      <div className="relative z-10 max-w-[1800px] mx-auto h-full px-6 lg:px-12 flex flex-col justify-between py-12">
        {/* Top Floating Badge */}
        <div className="flex items-center justify-between">
          <span className="text-[10px] md:text-xs tracking-[0.3em] font-medium text-[#d4af37] uppercase flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#d4af37] animate-pulse" />
            PARIS MAISON CAMPAIGN 2026
          </span>
          
          <button
            onClick={onOpenStylist}
            className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-full bg-black/60 backdrop-blur-md border border-[#d4af37]/40 text-[#d4af37] text-xs tracking-widest hover:bg-[#d4af37] hover:text-black transition-all cursor-pointer shadow-lg"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>ASK AI TRAVEL STYLIST</span>
          </button>
        </div>

        {/* Hero Left Text Stack */}
        <div className="max-w-xl text-white space-y-4 my-auto">
          <motion.p 
            key={`kicker-${slide.id}`}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-xs md:text-sm tracking-[0.35em] text-white/80 uppercase font-medium"
          >
            {slide.kicker}
          </motion.p>

          <motion.h1 
            key={`title-${slide.id}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-5xl md:text-7xl lg:text-8xl font-serif-lv tracking-[0.1em] text-white font-light uppercase leading-none"
          >
            {slide.title}
          </motion.h1>

          <motion.p 
            key={`tagline-${slide.id}`}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="text-sm md:text-base font-light text-white/90 tracking-wide max-w-md"
          >
            {slide.tagline}
          </motion.p>

          <motion.div
            key={`cta-${slide.id}`}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="pt-4"
          >
            <button
              onClick={onDiscoverClick}
              className="group inline-flex items-center gap-3 text-xs tracking-[0.25em] text-white uppercase font-semibold border-b border-white/60 pb-2 hover:border-[#d4af37] hover:text-[#d4af37] transition-all cursor-pointer"
            >
              <span>{slide.cta}</span>
              <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1.5 transition-transform text-[#d4af37]" />
            </button>
          </motion.div>
        </div>

        {/* Bottom Bar: LV Display Column & Slide Controls */}
        <div className="flex items-end justify-between w-full pt-4">
          {/* Subtle LV Monogram Symbol */}
          <div className="hidden lg:flex items-center gap-3 text-white/40 text-[10px] tracking-[0.3em]">
            <span className="text-[#d4af37] font-serif-lv font-bold text-lg">LV</span>
            <span className="w-12 h-[1px] bg-white/20" />
            <span>HAUTE MAROQUINERIE & VOYAGE</span>
          </div>

          {/* Slide Controls (Matches exact layout 01 / 04 < >) */}
          <div className="flex items-center gap-4 bg-black/40 backdrop-blur-md px-4 py-2 rounded-full border border-white/10">
            <span className="text-xs font-mono tracking-widest text-white/90">
              0{currentSlideIndex + 1} <span className="text-white/40">/</span> 0{HERO_SLIDES.length}
            </span>

            <div className="flex items-center gap-1">
              <button
                onClick={handlePrev}
                className="w-8 h-8 rounded-full border border-white/20 flex items-center justify-center text-white/80 hover:text-white hover:border-[#d4af37] hover:bg-[#d4af37]/20 transition-all cursor-pointer"
                aria-label="Previous slide"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={handleNext}
                className="w-8 h-8 rounded-full border border-white/20 flex items-center justify-center text-white/80 hover:text-white hover:border-[#d4af37] hover:bg-[#d4af37]/20 transition-all cursor-pointer"
                aria-label="Next slide"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
