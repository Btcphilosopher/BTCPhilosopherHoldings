'use client';

import React, { useState } from 'react';
import { Search, ShoppingBag, User, ShieldCheck, MapPin, Sparkles, Menu, X } from 'lucide-react';

interface NavbarProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenSearch: () => void;
  onOpenPassport: () => void;
  onOpenStores: () => void;
  onOpenStylist: () => void;
  onOpenAccount: () => void;
  activeCategory: string;
  onSelectCategory: (category: string) => void;
}

const CATEGORIES = ['ALL', 'WOMEN', 'MEN', 'HANDBAGS', 'TRAVEL', 'SHOES', 'WATCHES', 'JEWELLERY', 'BEAUTY', 'MAISON'];

export default function Navbar({
  cartCount,
  onOpenCart,
  onOpenSearch,
  onOpenPassport,
  onOpenStores,
  onOpenStylist,
  onOpenAccount,
  activeCategory,
  onSelectCategory
}: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-[#0d0d0d]/90 backdrop-blur-md border-b border-white/10 transition-colors">
      {/* Top Banner */}
      <div className="bg-[#181818] py-1.5 px-4 text-center text-[11px] tracking-widest text-[#d4af37] font-medium border-b border-white/5 flex items-center justify-center gap-2">
        <span>COMPLIMENTARY EXPRESS DELIVERY & SIGNATURE GIFT PACKAGING</span>
        <span className="hidden md:inline-block opacity-40">|</span>
        <button 
          onClick={onOpenPassport} 
          className="hidden md:inline-flex items-center gap-1 text-white/80 hover:text-white underline underline-offset-2 transition-colors cursor-pointer"
        >
          <ShieldCheck className="w-3 h-3 text-[#d4af37]" />
          <span>VERIFY LV DIGITAL PASSPORT</span>
        </button>
      </div>

      {/* Main Bar */}
      <div className="max-w-[1800px] mx-auto px-4 lg:px-8 h-16 md:h-20 flex items-center justify-between gap-4">
        {/* Mobile menu trigger */}
        <button 
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="lg:hidden p-2 text-white/80 hover:text-white"
          aria-label="Toggle menu"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>

        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center">
          <button 
            onClick={() => onSelectCategory('ALL')}
            className="text-xl md:text-2xl font-serif-lv tracking-[0.25em] text-white uppercase hover:opacity-80 transition-opacity cursor-pointer font-bold whitespace-nowrap"
          >
            LOUIS VUITTON
          </button>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden lg:flex items-center gap-6 xl:gap-8 text-xs tracking-[0.2em] font-medium text-white/80">
          {CATEGORIES.slice(1).map((cat) => (
            <button
              key={cat}
              onClick={() => onSelectCategory(cat)}
              className={`transition-colors py-1 relative uppercase cursor-pointer hover:text-white ${
                activeCategory === cat ? 'text-white font-semibold after:content-[""] after:absolute after:bottom-0 after:left-0 after:right-0 after:h-[1px] after:bg-[#d4af37]' : 'text-white/70'
              }`}
            >
              {cat}
            </button>
          ))}
        </nav>

        {/* Zone 3: Actions */}
        <div className="flex items-center gap-4 lg:gap-6 text-xs tracking-widest text-white/90">
          <button
            onClick={onOpenStylist}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#d4af37]/10 text-[#d4af37] border border-[#d4af37]/30 hover:bg-[#d4af37]/20 transition-all text-[11px] font-medium cursor-pointer"
            title="Louis Vuitton Private AI Concierge"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI CONCIERGE</span>
          </button>

          <button
            onClick={onOpenSearch}
            className="flex items-center gap-1.5 hover:text-[#d4af37] transition-colors cursor-pointer py-2"
            title="Search Products"
          >
            <Search className="w-4 h-4" />
            <span className="hidden xl:inline uppercase">SEARCH</span>
          </button>

          <button
            onClick={onOpenPassport}
            className="hidden md:flex items-center gap-1.5 hover:text-[#d4af37] transition-colors cursor-pointer py-2"
            title="Digital Passport Authenticator"
          >
            <ShieldCheck className="w-4 h-4 text-[#d4af37]" />
            <span className="hidden xl:inline uppercase">PASSPORT</span>
          </button>

          <button
            onClick={onOpenStores}
            className="hidden md:flex items-center gap-1.5 hover:text-[#d4af37] transition-colors cursor-pointer py-2"
            title="Store Locator"
          >
            <MapPin className="w-4 h-4" />
            <span className="hidden xl:inline uppercase font-normal">STORES</span>
          </button>

          <button
            onClick={onOpenAccount}
            className="flex items-center gap-1.5 hover:text-[#d4af37] transition-colors cursor-pointer py-2"
            title="Account"
          >
            <User className="w-4 h-4" />
            <span className="hidden xl:inline uppercase">ACCOUNT</span>
          </button>

          <button
            onClick={onOpenCart}
            className="flex items-center gap-1.5 hover:text-[#d4af37] transition-colors cursor-pointer py-2 relative"
            title="Shopping Bag"
          >
            <ShoppingBag className="w-4 h-4" />
            <span className="uppercase">BAG ({cartCount})</span>
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-2 bg-[#d4af37] text-black text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#121212] border-b border-white/10 px-6 py-6 space-y-4">
          <div className="grid grid-cols-2 gap-3 text-xs tracking-widest">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => {
                  onSelectCategory(cat);
                  setMobileMenuOpen(false);
                }}
                className={`text-left py-2 border-b border-white/5 uppercase ${
                  activeCategory === cat ? 'text-[#d4af37] font-bold' : 'text-white/80'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="pt-4 flex flex-col gap-3 text-xs tracking-widest text-white/90">
            <button 
              onClick={() => { onOpenStylist(); setMobileMenuOpen(false); }}
              className="flex items-center gap-2 text-[#d4af37] bg-[#d4af37]/10 p-2.5 rounded border border-[#d4af37]/30"
            >
              <Sparkles className="w-4 h-4" />
              <span>AI CONCIERGE & STYLIST</span>
            </button>
            <button 
              onClick={() => { onOpenPassport(); setMobileMenuOpen(false); }}
              className="flex items-center gap-2 py-2 text-white/80"
            >
              <ShieldCheck className="w-4 h-4 text-[#d4af37]" />
              <span>LV DIGITAL PASSPORT</span>
            </button>
            <button 
              onClick={() => { onOpenStores(); setMobileMenuOpen(false); }}
              className="flex items-center gap-2 py-2 text-white/80"
            >
              <MapPin className="w-4 h-4" />
              <span>STORE LOCATOR</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
