'use client';

import React, { useState } from 'react';
import { Product } from '@/lib/products';
import { X, ShoppingBag, ShieldCheck, Sparkles, Check, ChevronRight } from 'lucide-react';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, initials?: string) => void;
  onOpenStylistForProduct: (product: Product) => void;
  onOpenPassportForProduct: (passportId: string) => void;
}

export default function ProductDetailModal({
  product,
  onClose,
  onAddToCart,
  onOpenStylistForProduct,
  onOpenPassportForProduct
}: ProductDetailModalProps) {
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [monogramInitials, setMonogramInitials] = useState('');
  const [monogramColor, setMonogramColor] = useState<'gold' | 'silver' | 'red'>('gold');
  const [added, setAdded] = useState(false);

  if (!product) return null;

  const handleAdd = () => {
    onAddToCart(product, monogramInitials ? `${monogramInitials} (${monogramColor.toUpperCase()})` : undefined);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 lg:p-8 overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-[#121212] border border-white/20 rounded-sm overflow-hidden text-white my-auto shadow-2xl">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 text-white/70 hover:text-white bg-black/60 rounded-full cursor-pointer transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2">
          {/* Left: Gallery View */}
          <div className="p-6 lg:p-8 bg-[#0a0a0a] flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-white/10">
            <div className="relative aspect-square bg-[#161616] overflow-hidden rounded-sm mb-4 border border-white/10">
              <img
                src={product.gallery[selectedImageIndex] || product.image}
                alt={product.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />

              {/* Hotstamping Preview Stamp Overlay on Bag Image */}
              {monogramInitials && (
                <div className="absolute bottom-8 right-8 px-3 py-1.5 bg-black/80 backdrop-blur-md rounded border border-white/20 shadow-2xl text-center">
                  <div className="text-[9px] text-white/50 tracking-widest uppercase">MONOGRAM HOTSTAMP</div>
                  <div 
                    className={`font-serif-lv font-bold text-lg tracking-[0.2em] ${
                      monogramColor === 'gold' ? 'text-[#d4af37]' : monogramColor === 'silver' ? 'text-gray-300' : 'text-red-500'
                    }`}
                  >
                    {monogramInitials.toUpperCase()}
                  </div>
                </div>
              )}
            </div>

            {/* Gallery Thumbnails */}
            {product.gallery.length > 1 && (
              <div className="flex items-center gap-3">
                {product.gallery.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImageIndex(idx)}
                    className={`w-16 h-16 rounded overflow-hidden border cursor-pointer transition-all ${
                      selectedImageIndex === idx ? 'border-[#d4af37] scale-105' : 'border-white/20 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="Thumbnail" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right: Details & Customization */}
          <div className="p-6 lg:p-10 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs tracking-widest text-[#d4af37]">
                <span className="uppercase">{product.category}</span>
                <span className="font-mono">SKU: {product.sku}</span>
              </div>

              <h2 className="text-2xl lg:text-3xl font-serif-lv tracking-wider font-light">
                {product.name}
              </h2>

              <p className="text-2xl font-mono text-white font-semibold">
                ${product.price.toLocaleString('en-US')}
              </p>

              <p className="text-xs text-white/70 font-light leading-relaxed">
                {product.description}
              </p>

              <div className="pt-2 space-y-1 text-xs text-white/80">
                <div><span className="text-white/40">Material:</span> {product.material}</div>
                <div><span className="text-white/40">Dimensions:</span> {product.dimensions}</div>
              </div>

              {/* Complimentary Hotstamping Customization Box */}
              <div className="pt-4 border-t border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs tracking-widest text-[#d4af37] font-medium uppercase">
                    COMPLIMENTARY MONOGRAM HOTSTAMPING
                  </span>
                  <span className="text-[10px] text-white/50">OPTIONAL</span>
                </div>

                <div className="flex items-center gap-3">
                  <input
                    type="text"
                    maxLength={3}
                    placeholder="INITIALS (E.G. T.H.)"
                    value={monogramInitials}
                    onChange={(e) => setMonogramInitials(e.target.value)}
                    className="px-3 py-2 bg-[#1a1a1a] border border-white/20 text-xs font-mono uppercase text-white placeholder-white/40 rounded-sm focus:outline-none focus:border-[#d4af37] w-48"
                  />

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setMonogramColor('gold')}
                      className={`w-6 h-6 rounded-full bg-[#d4af37] border-2 cursor-pointer ${monogramColor === 'gold' ? 'border-white' : 'border-transparent'}`}
                      title="Gold Foil"
                    />
                    <button
                      onClick={() => setMonogramColor('silver')}
                      className={`w-6 h-6 rounded-full bg-slate-300 border-2 cursor-pointer ${monogramColor === 'silver' ? 'border-white' : 'border-transparent'}`}
                      title="Silver Foil"
                    />
                    <button
                      onClick={() => setMonogramColor('red')}
                      className={`w-6 h-6 rounded-full bg-red-600 border-2 cursor-pointer ${monogramColor === 'red' ? 'border-white' : 'border-transparent'}`}
                      title="Rouge Foil"
                    />
                  </div>
                </div>
              </div>

              {/* LV Digital Passport Info Trigger */}
              <div 
                onClick={() => onOpenPassportForProduct(product.digitalPassportId)}
                className="p-3 bg-[#181818] border border-[#d4af37]/30 rounded-sm flex items-center justify-between text-xs text-white/90 hover:border-[#d4af37] cursor-pointer transition-colors"
              >
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#d4af37]" />
                  <span>Inspect LV Digital Passport & Provenance</span>
                </div>
                <ChevronRight className="w-4 h-4 text-[#d4af37]" />
              </div>
            </div>

            {/* Actions */}
            <div className="pt-4 border-t border-white/10 space-y-3">
              <button
                onClick={handleAdd}
                className="w-full py-3.5 bg-[#d4af37] text-black font-bold text-xs tracking-[0.2em] uppercase rounded-sm hover:bg-white transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                {added ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-900" />
                    <span>ADDED TO BAG</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4" />
                    <span>ADD TO BAG — ${product.price.toLocaleString('en-US')}</span>
                  </>
                )}
              </button>

              <button
                onClick={() => {
                  onClose();
                  onOpenStylistForProduct(product);
                }}
                className="w-full py-2.5 bg-[#181818] text-[#d4af37] border border-[#d4af37]/40 font-medium text-xs tracking-widest uppercase rounded-sm hover:bg-[#d4af37]/10 transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>CONSULT AI STYLIST ABOUT THIS PIECE</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
