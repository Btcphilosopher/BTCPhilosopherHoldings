'use client';

import React from 'react';
import { STORES } from '@/lib/stores';
import { X, MapPin, Phone, Clock, Sparkles } from 'lucide-react';

interface StoreLocatorModalProps {
  onClose: () => void;
}

export default function StoreLocatorModal({ onClose }: StoreLocatorModalProps) {
  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 lg:p-8 overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-[#121212] border border-[#d4af37]/40 rounded-sm overflow-hidden text-white my-auto shadow-2xl p-6 lg:p-10 space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-white/10 pb-4">
          <div>
            <span className="text-xs tracking-[0.3em] font-semibold text-[#d4af37] uppercase flex items-center gap-1.5">
              <MapPin className="w-4 h-4" />
              <span>GLOBAL MAISON DIRECTORY</span>
            </span>
            <h2 className="text-2xl lg:text-4xl font-serif-lv tracking-wider text-white font-light uppercase">
              FIND A LOUIS VUITTON STORE
            </h2>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-white/60 hover:text-white bg-[#1a1a1a] rounded-full cursor-pointer transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Store List */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-h-[60vh] overflow-y-auto pr-2">
          {STORES.map((store) => (
            <div
              key={store.id}
              className="p-5 bg-[#181818] border border-white/10 hover:border-[#d4af37]/50 rounded-sm space-y-3 transition-colors"
            >
              <div className="space-y-1">
                <span className="text-[10px] text-[#d4af37] font-mono tracking-widest uppercase">{store.city}</span>
                <h3 className="text-lg font-serif-lv text-white font-medium">{store.name}</h3>
              </div>

              <div className="space-y-1.5 text-xs text-white/70">
                <p className="flex items-start gap-2">
                  <MapPin className="w-3.5 h-3.5 text-[#d4af37] shrink-0 mt-0.5" />
                  <span>{store.address}</span>
                </p>

                <p className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-white/40 shrink-0" />
                  <span>{store.hours}</span>
                </p>

                <p className="flex items-center gap-2 font-mono">
                  <Phone className="w-3.5 h-3.5 text-white/40 shrink-0" />
                  <span>{store.phone}</span>
                </p>
              </div>

              <div className="pt-2 border-t border-white/10">
                <span className="text-[10px] text-white/40 uppercase tracking-widest block mb-1">SERVICES AT THIS STORE:</span>
                <div className="flex flex-wrap gap-1.5">
                  {store.services.map((srv, idx) => (
                    <span key={idx} className="px-2 py-0.5 bg-[#222222] text-[10px] text-white/80 rounded border border-white/10">
                      {srv}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-white/10 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2.5 bg-[#d4af37] text-black font-bold text-xs tracking-widest uppercase rounded-sm hover:bg-white transition-colors cursor-pointer"
          >
            CLOSE STORE LOCATOR
          </button>
        </div>
      </div>
    </div>
  );
}
