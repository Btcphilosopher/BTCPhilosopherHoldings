'use client';

import React, { useState } from 'react';
import { Product, PRODUCTS } from '@/lib/products';
import { ShoppingBag, Eye, ShieldCheck, Sparkles } from 'lucide-react';

interface ProductCatalogSectionProps {
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onOpenStylistForProduct: (product: Product) => void;
}

export default function ProductCatalogSection({
  selectedCategory,
  onSelectCategory,
  onQuickView,
  onAddToCart,
  onOpenStylistForProduct
}: ProductCatalogSectionProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'featured' | 'price-low' | 'price-high'>('featured');

  const CATEGORIES = ['ALL', 'HANDBAGS', 'TRAVEL', 'WOMEN', 'MEN', 'WATCHES', 'JEWELLERY', 'BEAUTY'];

  // Filter products
  const filteredProducts = PRODUCTS.filter((product) => {
    const matchesCategory = selectedCategory === 'ALL' || product.category === selectedCategory || (selectedCategory === 'MAISON' && product.category === 'TRAVEL');
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          product.material.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          product.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortBy === 'price-low') return a.price - b.price;
    if (sortBy === 'price-high') return b.price - a.price;
    return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
  });

  return (
    <section id="catalog" className="bg-[#0d0d0d] py-20 px-6 lg:px-12 border-b border-white/10">
      <div className="max-w-[1800px] mx-auto">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <span className="text-xs tracking-[0.35em] font-medium text-[#d4af37] uppercase">
              EXQUISITE CRAFTSMANSHIP
            </span>
            <h2 className="text-3xl md:text-5xl font-serif-lv tracking-wider text-white font-light uppercase mt-1">
              THE COLLECTION
            </h2>
          </div>

          {/* Search & Sort Bar */}
          <div className="flex flex-wrap items-center gap-4">
            <input
              type="text"
              placeholder="Search collection or material..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="px-4 py-2 bg-[#181818] border border-white/15 text-xs text-white placeholder-white/40 rounded-sm focus:outline-none focus:border-[#d4af37] w-64 tracking-wider"
            />

            <select
              value={sortBy}
              onChange={(e: any) => setSortBy(e.target.value)}
              className="px-4 py-2 bg-[#181818] border border-white/15 text-xs text-white/80 rounded-sm focus:outline-none focus:border-[#d4af37] cursor-pointer tracking-wider"
            >
              <option value="featured">Sort: Featured</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
            </select>
          </div>
        </div>

        {/* Interactive Category Filter Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-10 border-b border-white/10 scrollbar-none">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => onSelectCategory(cat)}
              className={`px-5 py-2.5 text-xs font-medium tracking-[0.2em] rounded-sm uppercase transition-all whitespace-nowrap cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-[#d4af37] text-black font-semibold shadow-lg'
                  : 'bg-[#181818] text-white/70 hover:text-white hover:bg-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Product Cards Grid */}
        {sortedProducts.length === 0 ? (
          <div className="text-center py-20 text-white/50 space-y-3">
            <p className="text-lg font-serif-lv">No Louis Vuitton creations found matching your search.</p>
            <button
              onClick={() => { onSelectCategory('ALL'); setSearchQuery(''); }}
              className="text-xs tracking-widest text-[#d4af37] underline cursor-pointer"
            >
              RESET FILTERS
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {sortedProducts.map((product) => (
              <div
                key={product.id}
                className="group bg-[#141414] border border-white/10 rounded-sm overflow-hidden flex flex-col justify-between hover:border-[#d4af37]/50 transition-all duration-300"
              >
                {/* Image Container */}
                <div 
                  onClick={() => onQuickView(product)}
                  className="relative aspect-[4/3] bg-[#1a1a1a] overflow-hidden cursor-pointer"
                >
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover img-zoom"
                    referrerPolicy="no-referrer"
                  />

                  {/* Digital Passport Badge */}
                  <div className="absolute top-3 left-3 bg-black/70 backdrop-blur-md px-2.5 py-1 rounded-full border border-[#d4af37]/40 flex items-center gap-1 text-[10px] text-[#d4af37] tracking-wider">
                    <ShieldCheck className="w-3 h-3" />
                    <span>PASSPORT VERIFIED</span>
                  </div>

                  {/* Quick Action Overlay on Hover */}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3 p-4">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onQuickView(product);
                      }}
                      className="px-4 py-2 bg-white text-black text-xs font-bold tracking-widest uppercase rounded-sm hover:bg-[#d4af37] transition-colors flex items-center gap-1.5 shadow-lg cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>EXPLORE</span>
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenStylistForProduct(product);
                      }}
                      className="p-2 bg-black/80 text-[#d4af37] border border-[#d4af37]/50 rounded-sm hover:bg-[#d4af37] hover:text-black transition-colors cursor-pointer"
                      title="Ask AI Stylist"
                    >
                      <Sparkles className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Card Details */}
                <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                  <div>
                    <div className="flex items-center justify-between text-[10px] text-white/50 tracking-widest uppercase mb-1">
                      <span>{product.category}</span>
                      <span className="font-mono">REF: {product.sku}</span>
                    </div>

                    <h3 
                      onClick={() => onQuickView(product)}
                      className="text-lg font-serif-lv tracking-wide font-medium text-white group-hover:text-[#d4af37] transition-colors cursor-pointer"
                    >
                      {product.name}
                    </h3>

                    <p className="text-xs text-white/60 font-light line-clamp-1 mt-1">
                      {product.material}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-white/10 flex items-center justify-between">
                    <span className="text-base font-mono font-semibold text-white tracking-wider">
                      ${product.price.toLocaleString('en-US')}
                    </span>

                    <button
                      onClick={() => onAddToCart(product)}
                      className="px-3.5 py-1.5 bg-[#1f1f1f] hover:bg-[#d4af37] hover:text-black border border-white/20 hover:border-[#d4af37] text-white text-xs tracking-widest font-medium uppercase rounded-sm transition-all flex items-center gap-1.5 cursor-pointer"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>ADD</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
