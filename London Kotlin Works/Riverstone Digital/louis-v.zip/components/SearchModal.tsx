'use client';

import React, { useState } from 'react';
import { Product, PRODUCTS } from '@/lib/products';
import { X, Search, ArrowRight } from 'lucide-react';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export default function SearchModal({
  isOpen,
  onClose,
  onQuickView
}: SearchModalProps) {
  const [searchTerm, setSearchTerm] = useState('');

  if (!isOpen) return null;

  const SUGGESTIONS = ['Speedy 25', 'Neverfull MM', 'Horizon Roller Trunk', 'Courrier Wardrobe Trunk', 'Capucines', 'Soft Trunk'];

  const results = PRODUCTS.filter((p) => {
    if (!searchTerm.trim()) return false;
    return p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
           p.material.toLowerCase().includes(searchTerm.toLowerCase()) ||
           p.category.toLowerCase().includes(searchTerm.toLowerCase());
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-start justify-center pt-20 p-4">
      <div className="relative w-full max-w-3xl bg-[#121212] border border-white/20 rounded-sm p-6 text-white shadow-2xl space-y-6">
        {/* Header Search Input */}
        <div className="flex items-center gap-3 border-b border-[#d4af37] pb-3">
          <Search className="w-5 h-5 text-[#d4af37]" />
          <input
            autoFocus
            type="text"
            placeholder="Search Louis Vuitton handbags, trunks, watches..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1 bg-transparent text-sm md:text-lg text-white placeholder-white/40 focus:outline-none tracking-wider font-serif-lv"
          />
          <button
            onClick={onClose}
            className="p-1.5 text-white/60 hover:text-white cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Keyword Pills */}
        <div className="space-y-2">
          <p className="text-[10px] text-white/40 tracking-widest uppercase">POPULAR SEARCHES:</p>
          <div className="flex flex-wrap gap-2">
            {SUGGESTIONS.map((sug, i) => (
              <button
                key={i}
                onClick={() => setSearchTerm(sug)}
                className="px-3 py-1 bg-[#1c1c1c] hover:bg-[#d4af37] hover:text-black border border-white/10 rounded text-xs text-white/80 transition-colors cursor-pointer"
              >
                {sug}
              </button>
            ))}
          </div>
        </div>

        {/* Results List */}
        {searchTerm.trim() && (
          <div className="space-y-3 max-h-[50vh] overflow-y-auto pr-1 pt-2 border-t border-white/10">
            <p className="text-xs text-[#d4af37] tracking-widest uppercase font-mono">
              RESULTS FOUND ({results.length})
            </p>

            {results.length === 0 ? (
              <p className="text-sm font-serif-lv text-white/50 py-4">
                No Louis Vuitton pieces match &quot;{searchTerm}&quot;. Try searching for &apos;Monogram&apos;, &apos;Speedy&apos;, or &apos;Trunk&apos;.
              </p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {results.map((product) => (
                  <div
                    key={product.id}
                    onClick={() => {
                      onClose();
                      onQuickView(product);
                    }}
                    className="p-3 bg-[#181818] border border-white/10 hover:border-[#d4af37]/60 rounded-sm flex items-center gap-3 cursor-pointer transition-colors group"
                  >
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-16 h-16 object-cover rounded bg-black"
                      referrerPolicy="no-referrer"
                    />

                    <div className="flex-1 min-w-0">
                      <span className="text-[9px] text-[#d4af37] uppercase font-mono block">{product.category}</span>
                      <h4 className="text-sm font-serif-lv text-white group-hover:text-[#d4af37] transition-colors truncate">
                        {product.name}
                      </h4>
                      <p className="text-xs font-mono text-white/70">${product.price.toLocaleString('en-US')}</p>
                    </div>

                    <ArrowRight className="w-4 h-4 text-white/30 group-hover:text-[#d4af37] transition-colors" />
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
