'use client';

import React, { useState } from 'react';
import { DIGITAL_PASSPORTS, DigitalPassportRecord } from '@/lib/digital-passport';
import { X, ShieldCheck, CheckCircle2, Wrench, Layers, Compass, Sparkles, Copy, Check } from 'lucide-react';

interface DigitalPassportModalProps {
  initialPassportId?: string;
  onClose: () => void;
}

export default function DigitalPassportModal({
  initialPassportId = 'LV-PASSPORT-2026-SP8921',
  onClose
}: DigitalPassportModalProps) {
  const [selectedPassportId, setSelectedPassportId] = useState(initialPassportId);
  const [copiedHash, setCopiedHash] = useState(false);

  const record: DigitalPassportRecord = DIGITAL_PASSPORTS[selectedPassportId] || DIGITAL_PASSPORTS['LV-PASSPORT-2026-SP8921'];

  const handleCopyHash = () => {
    navigator.clipboard.writeText(record.blockchainHash);
    setCopiedHash(true);
    setTimeout(() => setCopiedHash(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 lg:p-8 overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-[#121212] border border-[#d4af37]/40 rounded-sm overflow-hidden text-white my-auto shadow-2xl p-6 lg:p-10 space-y-8">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-white/10 pb-6">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs tracking-[0.3em] font-semibold text-[#d4af37] uppercase">
              <ShieldCheck className="w-4 h-4 text-[#d4af37]" />
              <span>OFFICIAL LOUIS VUITTON BLOCKCHAIN PASSPORT</span>
            </div>
            <h2 className="text-2xl lg:text-4xl font-serif-lv tracking-wider text-white font-light uppercase">
              PROVENANCE & AUTHENTICITY CERTIFICATE
            </h2>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-white/60 hover:text-white bg-[#1a1a1a] rounded-full cursor-pointer transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Passport Serial Switcher */}
        <div className="flex items-center gap-3 bg-[#181818] p-3 rounded border border-white/10 text-xs">
          <span className="text-white/60 uppercase tracking-widest text-[11px]">SELECT PRODUCT PASSPORT:</span>
          <select
            value={selectedPassportId}
            onChange={(e) => setSelectedPassportId(e.target.value)}
            className="bg-[#222222] border border-[#d4af37]/40 text-[#d4af37] font-mono px-3 py-1.5 rounded focus:outline-none cursor-pointer"
          >
            {Object.keys(DIGITAL_PASSPORTS).map((id) => (
              <option key={id} value={id}>
                {id} — {DIGITAL_PASSPORTS[id].productName}
              </option>
            ))}
          </select>
        </div>

        {/* Passport Overview Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-[#181818] p-6 rounded-sm border border-white/10">
          <div className="space-y-1">
            <span className="text-[10px] text-white/40 tracking-widest uppercase">PRODUCT NAME</span>
            <p className="text-base font-serif-lv text-white">{record.productName}</p>
            <p className="text-xs text-[#d4af37] font-mono">SKU: {record.modelSku}</p>
          </div>

          <div className="space-y-1">
            <span className="text-[10px] text-white/40 tracking-widest uppercase">ATELIER ORIGIN</span>
            <p className="text-sm font-medium text-white flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5 text-[#d4af37]" />
              <span>{record.originAtelier}</span>
            </p>
            <p className="text-xs text-white/60">{record.craftsmanRegion}</p>
          </div>

          <div className="space-y-1">
            <span className="text-[10px] text-white/40 tracking-widest uppercase">AUTHENTICITY STATUS</span>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-semibold rounded-full">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>VERIFIED GENUINE</span>
            </div>
            <p className="text-[10px] text-white/50 font-mono">Issued: {record.issueDate}</p>
          </div>
        </div>

        {/* Blockchain Hash Banner */}
        <div className="p-3 bg-black/60 border border-white/15 rounded text-xs font-mono flex items-center justify-between gap-4">
          <div className="truncate text-white/70">
            <span className="text-[#d4af37] font-bold mr-2">BLOCKCHAIN RECORD:</span>
            <span className="text-white/60">{record.blockchainHash}</span>
          </div>
          <button
            onClick={handleCopyHash}
            className="p-1.5 bg-[#222222] hover:bg-[#d4af37] hover:text-black rounded text-white/80 transition-colors shrink-0 cursor-pointer"
            title="Copy Hash"
          >
            {copiedHash ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* Tabs Grid: Material Provenance & Repair Logs */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-2">
          {/* Materials */}
          <div className="space-y-3">
            <h3 className="text-xs tracking-[0.2em] font-semibold text-[#d4af37] uppercase flex items-center gap-2">
              <Layers className="w-4 h-4" />
              <span>RAW MATERIAL TRACEABILITY</span>
            </h3>

            <div className="space-y-2 text-xs">
              {record.materialsBreakdown.map((m, idx) => (
                <div key={idx} className="p-3 bg-[#181818] border border-white/5 rounded space-y-1">
                  <div className="flex justify-between font-medium text-white">
                    <span>{m.name}</span>
                    <span className="font-mono text-[#d4af37]">{m.percentage}%</span>
                  </div>
                  <p className="text-[11px] text-white/50">{m.source}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Repair History */}
          <div className="space-y-3">
            <h3 className="text-xs tracking-[0.2em] font-semibold text-[#d4af37] uppercase flex items-center gap-2">
              <Wrench className="w-4 h-4" />
              <span>ATELIER REPAIR & INSPECTION LOGS</span>
            </h3>

            <div className="space-y-2 text-xs">
              {record.repairHistory.map((rep, idx) => (
                <div key={idx} className="p-3 bg-[#181818] border border-white/5 rounded space-y-1">
                  <div className="flex justify-between font-medium text-white">
                    <span>{rep.serviceType}</span>
                    <span className="text-[10px] text-white/50 font-mono">{rep.date}</span>
                  </div>
                  <p className="text-[11px] text-[#d4af37]">{rep.location}</p>
                  <p className="text-[10px] text-white/40">{rep.technician}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2 text-white/60">
            <Sparkles className="w-4 h-4 text-[#d4af37]" />
            <span>Encrypted with Louis Vuitton Aura Blockchain Consortium Security</span>
          </div>

          <button
            onClick={onClose}
            className="w-full sm:w-auto px-6 py-2.5 bg-[#d4af37] text-black font-bold tracking-widest uppercase rounded-sm hover:bg-white transition-colors cursor-pointer"
          >
            CLOSE PASSPORT
          </button>
        </div>
      </div>
    </div>
  );
}
