'use client';

import React from 'react';
import { ArrowRight } from 'lucide-react';

interface NewSeasonGridProps {
  onSelectCategory: (category: string) => void;
}

const SEASON_ITEMS = [
  {
    id: 'women',
    category: 'WOMEN',
    title: 'WOMEN',
    cta: 'VIEW COLLECTION',
    image: '/src/assets/images/lv_women_collection_1791038885439.jpg',
    description: 'Parisian elegance & high fashion leatherware.'
  },
  {
    id: 'men',
    category: 'MEN',
    title: 'MEN',
    cta: 'VIEW COLLECTION',
    image: '/src/assets/images/lv_men_collection_1791038897186.jpg',
    description: 'Contemporary silhouettes & signature duffle travel.'
  },
  {
    id: 'travel',
    category: 'TRAVEL',
    title: 'TRAVEL',
    cta: 'VIEW COLLECTION',
    image: '/src/assets/images/lv_travel_trunk_1791038907936.jpg',
    description: 'Iconic Horizon luggage & rigid wardrobe trunks.'
  }
];

export default function NewSeasonGrid({ onSelectCategory }: NewSeasonGridProps) {
  return (
    <section className="bg-[#121212] py-16 px-6 lg:px-12 border-b border-white/10">
      <div className="max-w-[1800px] mx-auto">
        {/* Section Title matching mock */}
        <div className="flex items-center gap-4 mb-10">
          <h2 className="text-xs md:text-sm tracking-[0.3em] font-medium text-white/90 uppercase font-sans-lv">
            THE NEW SEASON
          </h2>
          <span className="w-16 md:w-24 h-[1px] bg-white/30" />
        </div>

        {/* 3-Column Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
          {SEASON_ITEMS.map((item) => (
            <div
              key={item.id}
              onClick={() => onSelectCategory(item.category)}
              className="group relative h-[420px] lg:h-[500px] overflow-hidden rounded-sm cursor-pointer border border-white/10 hover:border-[#d4af37]/50 transition-all bg-[#1a1a1a]"
            >
              {/* Background Image */}
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover img-zoom"
                referrerPolicy="no-referrer"
              />

              {/* Scrim Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent transition-opacity group-hover:from-black/95" />

              {/* Text Overlay at Bottom Left */}
              <div className="absolute bottom-0 left-0 right-0 p-8 flex flex-col justify-end text-white z-10">
                <h3 className="text-2xl lg:text-3xl font-serif-lv tracking-widest uppercase font-light mb-1 text-white group-hover:text-[#d4af37] transition-colors">
                  {item.title}
                </h3>
                <p className="text-xs text-white/70 font-light mb-4 line-clamp-1">
                  {item.description}
                </p>

                <div className="inline-flex items-center gap-2 text-xs tracking-[0.2em] font-medium text-white/90 uppercase group-hover:text-[#d4af37] transition-colors">
                  <span>{item.cta}</span>
                  <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1.5 transition-transform text-[#d4af37]" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
