'use client';

import React, { useState } from 'react';
import { X, User, ShieldCheck, ShoppingBag, Heart, LogOut } from 'lucide-react';

interface AccountModalProps {
  onClose: () => void;
  onOpenPassport: () => void;
}

export default function AccountModal({ onClose, onOpenPassport }: AccountModalProps) {
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [clientName, setClientName] = useState('Baron Henri de Saint-Germain');
  const [email, setEmail] = useState('henri@saint-germain.fr');

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 lg:p-8">
      <div className="relative w-full max-w-lg bg-[#121212] border border-white/20 rounded-sm overflow-hidden text-white my-auto shadow-2xl p-6 lg:p-8 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div className="flex items-center gap-2">
            <User className="w-5 h-5 text-[#d4af37]" />
            <h2 className="text-xl font-serif-lv tracking-wider text-white uppercase font-medium">
              MY LV CLIENT ACCOUNT
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-white/60 hover:text-white cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Client Profile Details */}
        <div className="space-y-4">
          <div className="p-4 bg-[#181818] border border-white/10 rounded-sm space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-[#d4af37] font-mono tracking-widest uppercase">VIP CLIENT TIER</span>
              <span className="text-[10px] bg-[#d4af37]/20 text-[#d4af37] px-2 py-0.5 rounded uppercase font-bold">MAISON VENDÔME SALON</span>
            </div>
            <h3 className="text-lg font-serif-lv text-white">{clientName}</h3>
            <p className="text-xs text-white/60 font-mono">{email}</p>
          </div>

          <div className="space-y-2 text-xs">
            <div 
              onClick={() => { onClose(); onOpenPassport(); }}
              className="p-3 bg-[#181818] hover:bg-[#222] border border-white/10 rounded flex items-center justify-between cursor-pointer transition-colors"
            >
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#d4af37]" />
                <span>My Registered Digital Passports (3 Items)</span>
              </div>
              <span className="text-white/40">→</span>
            </div>

            <div className="p-3 bg-[#181818] hover:bg-[#222] border border-white/10 rounded flex items-center justify-between cursor-pointer transition-colors">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-white/70" />
                <span>Order History & Atelier Invoices</span>
              </div>
              <span className="text-white/40">→</span>
            </div>

            <div className="p-3 bg-[#181818] hover:bg-[#222] border border-white/10 rounded flex items-center justify-between cursor-pointer transition-colors">
              <div className="flex items-center gap-2">
                <Heart className="w-4 h-4 text-white/70" />
                <span>My Wishlist & Hotstamping Preferences</span>
              </div>
              <span className="text-white/40">→</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-white/10 flex items-center justify-between">
          <button
            onClick={() => setIsLoggedIn(false)}
            className="text-xs text-white/50 hover:text-red-400 flex items-center gap-1.5 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>

          <button
            onClick={onClose}
            className="px-6 py-2 bg-[#d4af37] text-black font-bold text-xs tracking-widest uppercase rounded-sm hover:bg-white transition-colors cursor-pointer"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
}
