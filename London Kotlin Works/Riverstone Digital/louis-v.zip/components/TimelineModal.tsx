'use client';

import React, { useState } from 'react';
import { TIMELINE_EVENTS } from '@/lib/timeline';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

interface TimelineModalProps {
  onClose: () => void;
}

export default function TimelineModal({ onClose }: TimelineModalProps) {
  const [activeIndex, setActiveIndex] = useState(0);

  const event = TIMELINE_EVENTS[activeIndex];

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 lg:p-8 overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-[#0d0d0d] border border-[#d4af37]/40 rounded-sm overflow-hidden text-white my-auto shadow-2xl p-6 lg:p-12 space-y-8">
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 z-20 p-2 text-white/60 hover:text-white bg-[#1a1a1a] rounded-full cursor-pointer transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="space-y-1 text-center max-w-xl mx-auto">
          <p className="text-xs tracking-[0.35em] text-[#d4af37] font-semibold uppercase">
            SAVOIR-FAIRE & HERITAGE
          </p>
          <h2 className="text-3xl lg:text-5xl font-serif-lv tracking-wider font-light uppercase">
            EXPLORE THE MAISON 1854 — NOW
          </h2>
        </div>

        {/* Interactive Year Selector Bar */}
        <div className="flex items-center justify-between border-y border-white/10 py-4 overflow-x-auto gap-4 scrollbar-none">
          {TIMELINE_EVENTS.map((item, idx) => (
            <button
              key={item.year}
              onClick={() => setActiveIndex(idx)}
              className={`flex flex-col items-center px-4 py-2 rounded transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                activeIndex === idx ? 'bg-[#d4af37] text-black font-bold shadow-lg scale-105' : 'text-white/60 hover:text-white'
              }`}
            >
              <span className="font-mono text-base tracking-widest">{item.year}</span>
              <span className="text-[10px] uppercase font-light">{item.title}</span>
            </button>
          ))}
        </div>

        {/* Active Milestone Card */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center bg-[#141414] p-6 lg:p-8 rounded-sm border border-white/10">
          <div className="aspect-[16/10] bg-black overflow-hidden rounded border border-white/10 relative">
            <img
              src={event.image}
              alt={event.title}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute bottom-3 left-3 px-3 py-1 bg-black/70 backdrop-blur-md rounded border border-[#d4af37]/30 text-[#d4af37] text-xs font-mono font-bold">
              {event.year} ARCHIVE
            </div>
          </div>

          <div className="space-y-4">
            <span className="text-xs tracking-widest text-[#d4af37] font-mono uppercase">{event.subtitle}</span>

            <h3 className="text-2xl lg:text-3xl font-serif-lv tracking-wide font-light text-white">
              {event.title}
            </h3>

            <p className="text-xs lg:text-sm font-light text-white/80 leading-relaxed">
              {event.description}
            </p>

            <div className="p-3 bg-[#1d1d1d] border-l-2 border-[#d4af37] text-xs text-[#d4af37] italic font-serif-lv">
              &ldquo;{event.highlight}&rdquo;
            </div>

            {/* Navigation Buttons */}
            <div className="flex items-center justify-between pt-4">
              <button
                disabled={activeIndex === 0}
                onClick={() => setActiveIndex(activeIndex - 1)}
                className="px-4 py-2 bg-[#222222] disabled:opacity-30 text-xs font-semibold tracking-widest uppercase rounded flex items-center gap-1.5 cursor-pointer hover:bg-[#d4af37] hover:text-black transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>PREVIOUS</span>
              </button>

              <span className="text-xs font-mono text-white/50">
                {activeIndex + 1} / {TIMELINE_EVENTS.length}
              </span>

              <button
                disabled={activeIndex === TIMELINE_EVENTS.length - 1}
                onClick={() => setActiveIndex(activeIndex + 1)}
                className="px-4 py-2 bg-[#222222] disabled:opacity-30 text-xs font-semibold tracking-widest uppercase rounded flex items-center gap-1.5 cursor-pointer hover:bg-[#d4af37] hover:text-black transition-colors"
              >
                <span>NEXT</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
