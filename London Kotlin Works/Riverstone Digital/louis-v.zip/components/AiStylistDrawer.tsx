'use client';

import React, { useState } from 'react';
import { Product } from '@/lib/products';
import { X, Sparkles, Send, Loader2 } from 'lucide-react';

interface AiStylistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  selectedProduct?: Product | null;
}

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export default function AiStylistDrawer({
  isOpen,
  onClose,
  selectedProduct
}: AiStylistDrawerProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: selectedProduct
        ? `Bonjour. I am your Louis Vuitton Private Concierge in Paris. How may I assist you with styling or travel advice for the ${selectedProduct.name}?`
        : `Bonjour. Welcome to Maison Louis Vuitton Paris. I am your Senior Bespoke Stylist and Travel Concierge. How may I curate your wardrobe, recommend travel trunks, or assist with gift selections today?`
    }
  ]);

  const [inputPrompt, setInputPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleSendMessage = async (promptToSend?: string) => {
    const text = promptToSend || inputPrompt;
    if (!text.trim() || isLoading) return;

    const userMsg: Message = { role: 'user', content: text };
    setMessages((prev) => [...prev, userMsg]);
    setInputPrompt('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/gemini/stylist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: text,
          selectedItem: selectedProduct
        })
      });

      const data = await response.json();

      if (data.text) {
        setMessages((prev) => [...prev, { role: 'assistant', content: data.text }]);
      } else {
        setMessages((prev) => [...prev, { role: 'assistant', content: data.error || 'Pardon. Please try again.' }]);
      }
    } catch (error) {
      setMessages((prev) => [...prev, { role: 'assistant', content: 'Our concierge connection was interrupted. Please retry.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  const QUICK_PROMPTS = selectedProduct ? [
    `How should I style the ${selectedProduct.name} for an evening in Paris?`,
    `What travel occasions suit this piece best?`,
    `How do I care for ${selectedProduct.material}?`
  ] : [
    `Bespoke packing list for a weekend in Saint-Tropez`,
    `Best iconic Louis Vuitton handbags for everyday urban chic`,
    `How to select a heritage Horizon roller trunk`
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex justify-end">
      <div className="w-full max-w-lg bg-[#111111] border-l border-[#d4af37]/40 h-full flex flex-col justify-between text-white p-6 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#d4af37]" />
            <div>
              <h2 className="text-base font-serif-lv tracking-widest uppercase text-white font-medium">
                LV PRIVATE CONCIERGE & STYLIST
              </h2>
              <p className="text-[10px] text-[#d4af37] tracking-wider uppercase font-mono">
                POWERED BY MAISON PARIS AI
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-white/60 hover:text-white cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Selected Context Banner if applicable */}
        {selectedProduct && (
          <div className="my-3 p-3 bg-[#1a1a1a] border border-[#d4af37]/30 rounded flex items-center gap-3">
            <img src={selectedProduct.image} alt={selectedProduct.name} className="w-10 h-10 object-cover rounded bg-black" referrerPolicy="no-referrer" />
            <div className="text-xs">
              <span className="text-[10px] text-[#d4af37] uppercase tracking-widest font-bold">FOCUS PIECE</span>
              <p className="font-serif-lv text-white">{selectedProduct.name}</p>
            </div>
          </div>
        )}

        {/* Chat History Messages */}
        <div className="flex-1 py-4 overflow-y-auto space-y-4 pr-1 text-xs">
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
            >
              <span className="text-[9px] text-white/40 tracking-widest uppercase mb-1">
                {msg.role === 'user' ? 'You' : 'LV Concierge'}
              </span>
              <div
                className={`p-3.5 rounded-sm max-w-[88%] leading-relaxed ${
                  msg.role === 'user'
                    ? 'bg-[#d4af37] text-black font-medium'
                    : 'bg-[#181818] border border-white/10 text-white/90 font-light'
                }`}
              >
                {msg.content}
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-2 text-xs text-[#d4af37] p-2 italic">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Our Paris Concierge is curating your response...</span>
            </div>
          )}
        </div>

        {/* Quick Suggestions */}
        <div className="py-2 border-t border-white/10 space-y-2">
          <p className="text-[10px] tracking-widest text-white/50 uppercase">SUGGESTED ENQUIRIES:</p>
          <div className="flex flex-col gap-1.5">
            {QUICK_PROMPTS.map((qp, i) => (
              <button
                key={i}
                onClick={() => handleSendMessage(qp)}
                className="text-left text-[11px] p-2 bg-[#181818] hover:bg-[#d4af37]/20 border border-white/10 hover:border-[#d4af37]/50 rounded text-white/80 hover:text-white transition-colors truncate cursor-pointer"
              >
                &ldquo;{qp}&rdquo;
              </button>
            ))}
          </div>
        </div>

        {/* Input Box */}
        <div className="pt-3 border-t border-white/10 flex items-center gap-2">
          <input
            type="text"
            placeholder="Ask your concierge styling, travel or gift questions..."
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            className="flex-1 p-3 bg-[#181818] border border-white/20 text-xs text-white placeholder-white/40 rounded-sm focus:outline-none focus:border-[#d4af37]"
          />
          <button
            onClick={() => handleSendMessage()}
            disabled={isLoading || !inputPrompt.trim()}
            className="p-3 bg-[#d4af37] disabled:opacity-40 text-black rounded-sm hover:bg-white transition-colors cursor-pointer"
            title="Send"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
