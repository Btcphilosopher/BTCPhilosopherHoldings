'use client';

import React, { useState } from 'react';
import { Product } from '@/lib/products';
import { X, Trash2, Gift, ArrowRight, CheckCircle2 } from 'lucide-react';

export interface CartItem {
  product: Product;
  quantity: number;
  initials?: string;
}

interface ShoppingBagDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (productId: string, qty: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
}

export default function ShoppingBagDrawer({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart
}: ShoppingBagDrawerProps) {
  const [isGiftWrapped, setIsGiftWrapped] = useState(true);
  const [checkoutStep, setCheckoutStep] = useState<'bag' | 'checkout' | 'confirmed'>('bag');
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [orderNumber] = useState(() => Math.floor(1000 + Math.random() * 9000));

  if (!isOpen) return null;

  const subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCheckoutStep('confirmed');
  };

  const handleReset = () => {
    onClearCart();
    setCheckoutStep('bag');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex justify-end">
      <div className="w-full max-w-md bg-[#121212] border-l border-white/15 h-full flex flex-col justify-between text-white p-6 shadow-2xl overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-serif-lv tracking-widest uppercase text-white font-medium">
              SHOPPING BAG ({cart.reduce((acc, i) => acc + i.quantity, 0)})
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-white/60 hover:text-white cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        {checkoutStep === 'confirmed' ? (
          <div className="my-auto text-center space-y-4 py-8">
            <CheckCircle2 className="w-16 h-16 text-[#d4af37] mx-auto animate-bounce" />
            <h3 className="text-2xl font-serif-lv tracking-wider text-white">ORDER CONFIRMED</h3>
            <p className="text-xs text-white/70 font-light leading-relaxed">
              Thank you, <span className="text-white font-semibold">{customerName || 'Valued Client'}</span>. Your Louis Vuitton order #LV-2026-{orderNumber} has been received and is being prepared with signature gift packaging at our Paris atelier.
            </p>
            <div className="p-4 bg-[#1a1a1a] border border-white/10 rounded-sm text-left text-xs space-y-1 text-white/80">
              <div><span className="text-white/40">Delivery Address:</span> {deliveryAddress || 'Paris, France'}</div>
              <div><span className="text-white/40">Total Charged:</span> ${subtotal.toLocaleString('en-US')}</div>
              <div><span className="text-white/40">Courier:</span> DHL Express Signature Flight</div>
            </div>
            <button
              onClick={handleReset}
              className="w-full py-3 bg-[#d4af37] text-black font-bold text-xs tracking-widest uppercase rounded-sm hover:bg-white transition-colors cursor-pointer"
            >
              CONTINUE SHOPPING
            </button>
          </div>
        ) : checkoutStep === 'checkout' ? (
          /* Checkout Form */
          <form onSubmit={handleCheckoutSubmit} className="flex-1 py-6 space-y-4 overflow-y-auto">
            <h3 className="text-sm font-serif-lv tracking-widest text-[#d4af37] uppercase">CLIENT DETAILS</h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-white/60 uppercase tracking-widest text-[10px] mb-1">Full Name</label>
                <input
                  required
                  type="text"
                  placeholder="e.g. Baron Henri de Saint-Germain"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full p-2.5 bg-[#1a1a1a] border border-white/20 text-white placeholder-white/30 rounded-sm focus:border-[#d4af37] outline-none"
                />
              </div>

              <div>
                <label className="block text-white/60 uppercase tracking-widest text-[10px] mb-1">Email Address</label>
                <input
                  required
                  type="email"
                  placeholder="client@louisvuitton.com"
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  className="w-full p-2.5 bg-[#1a1a1a] border border-white/20 text-white placeholder-white/30 rounded-sm focus:border-[#d4af37] outline-none"
                />
              </div>

              <div>
                <label className="block text-white/60 uppercase tracking-widest text-[10px] mb-1">Delivery Address</label>
                <textarea
                  required
                  rows={2}
                  placeholder="Street, City, Postal Code, Country"
                  value={deliveryAddress}
                  onChange={(e) => setDeliveryAddress(e.target.value)}
                  className="w-full p-2.5 bg-[#1a1a1a] border border-white/20 text-white placeholder-white/30 rounded-sm focus:border-[#d4af37] outline-none"
                />
              </div>
            </div>

            <div className="p-3 bg-[#181818] border border-white/10 rounded-sm text-xs space-y-1 text-white/80">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span className="font-mono">${subtotal.toLocaleString('en-US')}</span>
              </div>
              <div className="flex justify-between text-[#d4af37]">
                <span>Signature Delivery:</span>
                <span>COMPLIMENTARY</span>
              </div>
              {isGiftWrapped && (
                <div className="flex justify-between text-white/60 text-[11px]">
                  <span>Louis Vuitton Gift Box & Ribbon:</span>
                  <span>INCLUDED</span>
                </div>
              )}
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setCheckoutStep('bag')}
                className="py-3 px-4 bg-[#1f1f1f] text-white/80 text-xs font-semibold tracking-widest uppercase rounded-sm cursor-pointer"
              >
                BACK
              </button>
              <button
                type="submit"
                className="flex-1 py-3 bg-[#d4af37] text-black font-bold text-xs tracking-widest uppercase rounded-sm hover:bg-white transition-colors cursor-pointer"
              >
                PLACE ORDER — ${subtotal.toLocaleString('en-US')}
              </button>
            </div>
          </form>
        ) : (
          /* Bag Items View */
          <div className="flex-1 py-6 overflow-y-auto space-y-4">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-3 text-white/50">
                <p className="text-base font-serif-lv">Your Louis Vuitton Shopping Bag is empty.</p>
                <button
                  onClick={onClose}
                  className="text-xs tracking-widest text-[#d4af37] underline cursor-pointer"
                >
                  DISCOVER THE COLLECTION
                </button>
              </div>
            ) : (
              cart.map((item) => (
                <div
                  key={item.product.id}
                  className="flex items-center gap-4 p-3 bg-[#181818] border border-white/10 rounded-sm"
                >
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-16 h-16 object-cover rounded bg-[#0a0a0a]"
                    referrerPolicy="no-referrer"
                  />

                  <div className="flex-1 text-xs space-y-1">
                    <h4 className="font-serif-lv text-sm text-white font-medium">{item.product.name}</h4>
                    <p className="text-white/50 font-mono">${item.product.price.toLocaleString('en-US')}</p>
                    {item.initials && (
                      <p className="text-[10px] text-[#d4af37]">Hotstamp: {item.initials}</p>
                    )}

                    <div className="flex items-center gap-2 pt-1">
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                        className="w-5 h-5 bg-[#2a2a2a] rounded flex items-center justify-center text-white/80 hover:bg-[#d4af37] hover:text-black cursor-pointer"
                      >
                        -
                      </button>
                      <span className="font-mono text-xs text-white">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                        className="w-5 h-5 bg-[#2a2a2a] rounded flex items-center justify-center text-white/80 hover:bg-[#d4af37] hover:text-black cursor-pointer"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  <button
                    onClick={() => onRemoveItem(item.product.id)}
                    className="text-white/40 hover:text-red-400 p-1 cursor-pointer"
                    title="Remove"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>
        )}

        {/* Footer Breakdown */}
        {cart.length > 0 && checkoutStep === 'bag' && (
          <div className="pt-4 border-t border-white/10 space-y-4">
            {/* Gift Wrap Toggle */}
            <div
              onClick={() => setIsGiftWrapped(!isGiftWrapped)}
              className="p-3 bg-[#1a1a1a] border border-white/10 rounded-sm flex items-center justify-between text-xs cursor-pointer hover:border-[#d4af37]/40 transition-colors"
            >
              <div className="flex items-center gap-2">
                <Gift className="w-4 h-4 text-[#d4af37]" />
                <span className="text-white/90">Signature Louis Vuitton Gift Packaging</span>
              </div>
              <input
                type="checkbox"
                checked={isGiftWrapped}
                onChange={() => {}}
                className="accent-[#d4af37] cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between text-xs tracking-widest text-white/70">
              <span className="uppercase">COMPLIMENTARY DELIVERY</span>
              <span className="text-[#d4af37] font-semibold">EXPRESS INCLUDED</span>
            </div>

            <div className="flex items-center justify-between text-sm tracking-widest text-white">
              <span className="uppercase font-serif-lv text-base">ESTIMATED TOTAL</span>
              <span className="font-mono text-lg font-bold text-white">${subtotal.toLocaleString('en-US')}</span>
            </div>

            <button
              onClick={() => setCheckoutStep('checkout')}
              className="w-full py-3.5 bg-[#d4af37] text-black font-bold text-xs tracking-[0.2em] uppercase rounded-sm hover:bg-white transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg"
            >
              <span>PROCEED TO CHECKOUT</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
