export interface Product {
  id: string;
  name: string;
  category: 'WOMEN' | 'MEN' | 'HANDBAGS' | 'TRAVEL' | 'SHOES' | 'WATCHES' | 'JEWELLERY' | 'BEAUTY';
  price: number;
  material: string;
  description: string;
  sku: string;
  image: string;
  gallery: string[];
  dimensions: string;
  digitalPassportId: string;
  inStock: boolean;
  featured?: boolean;
}

export const PRODUCTS: Product[] = [
  {
    id: 'neverfull-mm',
    name: 'Neverfull MM',
    category: 'HANDBAGS',
    price: 2030,
    material: 'Monogram Canvas & Natural Cowhide Leather',
    description: 'The Neverfull MM tote unites timeless design with heritage details. Elegant in Monogram canvas with natural cowhide trim, it is roomy without being bulky, with side laces that cinch for a sleek allure or loosen for a casual look.',
    sku: 'M41178',
    image: '/src/assets/images/lv_women_collection_1791038885439.jpg',
    gallery: [
      '/src/assets/images/lv_women_collection_1791038885439.jpg',
      '/src/assets/images/lv_hero_travel_1791038872689.jpg'
    ],
    dimensions: '31 x 28 x 14 cm',
    digitalPassportId: 'LV-PASSPORT-2026-NF8841',
    inStock: true,
    featured: true
  },
  {
    id: 'speedy-25',
    name: 'Speedy 25 Monogram',
    category: 'HANDBAGS',
    price: 1490,
    material: 'Monogram Canvas & Vachetta Leather',
    description: 'Crafted from supple Monogram canvas, the Speedy 25 is an iconic handbag designed for the city. Introduced in 1930 as the "Express" in homage to the era’s rapid transit, today’s Speedy remains a timeless House icon.',
    sku: 'M41109',
    image: '/src/assets/images/lv_women_collection_1791038885439.jpg',
    gallery: [
      '/src/assets/images/lv_women_collection_1791038885439.jpg'
    ],
    dimensions: '25 x 19 x 15 cm',
    digitalPassportId: 'LV-PASSPORT-2026-SP8921',
    inStock: true,
    featured: true
  },
  {
    id: 'horizon-55',
    name: 'Horizon 55 Roller Trunk',
    category: 'TRAVEL',
    price: 3400,
    material: 'Monogram Canvas & Anodized Aluminum',
    description: 'Meet the future of luxury travel. Designed by Marc Newson, widely acknowledged as the most influential industrial designer of his generation, the Horizon 55 is an ultra-lightweight 4-wheeled carry-on cabin luggage.',
    sku: 'M23203',
    image: '/src/assets/images/lv_hero_travel_1791038872689.jpg',
    gallery: [
      '/src/assets/images/lv_hero_travel_1791038872689.jpg',
      '/src/assets/images/lv_travel_trunk_1791038907936.jpg'
    ],
    dimensions: '38 x 55 x 21 cm',
    digitalPassportId: 'LV-PASSPORT-2026-HZ5501',
    inStock: true,
    featured: true
  },
  {
    id: 'keepall-bandouliere-50',
    name: 'Keepall Bandoulière 50',
    category: 'TRAVEL',
    price: 2570,
    material: 'Monogram Canvas & Calfskin',
    description: 'An icon since its appearance in 1930, the Keepall embodies the spirit of modern travel. Light, supple and always ready for immediate departure, the bag lives up to its name: those adept at the art of packing can easily fit a week’s wardrobe.',
    sku: 'M41416',
    image: '/src/assets/images/lv_men_collection_1791038897186.jpg',
    gallery: [
      '/src/assets/images/lv_men_collection_1791038897186.jpg',
      '/src/assets/images/lv_travel_trunk_1791038907936.jpg'
    ],
    dimensions: '50 x 29 x 23 cm',
    digitalPassportId: 'LV-PASSPORT-2026-KP5012',
    inStock: true,
    featured: true
  },
  {
    id: 'courrier-lozine-110',
    name: 'Courrier Lozine 110 Wardrobe Trunk',
    category: 'TRAVEL',
    price: 42000,
    material: 'Monogram Canvas, Solid Brass & Wooden Structure',
    description: 'The pinnacle of Louis Vuitton craftsmanship. Hand-crafted in the historic Asnières-sur-Seine atelier, the Courrier Lozine trunk features solid brass hardware, wood-slat re-enforcements, and custom velvet-lined drawers.',
    sku: 'M20011',
    image: '/src/assets/images/lv_maison_trunk_1791038920083.jpg',
    gallery: [
      '/src/assets/images/lv_maison_trunk_1791038920083.jpg',
      '/src/assets/images/lv_travel_trunk_1791038907936.jpg'
    ],
    dimensions: '110 x 55 x 52 cm',
    digitalPassportId: 'LV-PASSPORT-2026-TR1854',
    inStock: true,
    featured: true
  },
  {
    id: 'capucines-mm',
    name: 'Capucines MM Noir',
    category: 'WOMEN',
    price: 6750,
    material: 'Full-Grain Taurillon Leather',
    description: 'Named after the Rue des Capucines in Paris, where Louis Vuitton opened his first store in 1854, the Capucines bag is a testament to fine leather craftsmanship with distinct jewel-like LV initials.',
    sku: 'M48865',
    image: '/src/assets/images/lv_women_collection_1791038885439.jpg',
    gallery: [
      '/src/assets/images/lv_women_collection_1791038885439.jpg'
    ],
    dimensions: '31.5 x 20 x 11 cm',
    digitalPassportId: 'LV-PASSPORT-2026-CP9901',
    inStock: true,
    featured: true
  },
  {
    id: 'soft-trunk-eclipse',
    name: 'Soft Trunk Eclipse',
    category: 'MEN',
    price: 3800,
    material: 'Monogram Eclipse Canvas & Black Metal',
    description: 'Directly inspired by the House’s heritage trunks, the Soft Trunk in Monogram Eclipse canvas features metallic corners, a structured rectangle silhouette, and an adjustable shoulder strap.',
    sku: 'M44730',
    image: '/src/assets/images/lv_men_collection_1791038897186.jpg',
    gallery: [
      '/src/assets/images/lv_men_collection_1791038897186.jpg'
    ],
    dimensions: '25 x 18 x 10 cm',
    digitalPassportId: 'LV-PASSPORT-2026-ST4473',
    inStock: true,
    featured: true
  },
  {
    id: 'tambour-horizon-watch',
    name: 'Tambour Horizon Light Up Watch',
    category: 'WATCHES',
    price: 3600,
    material: 'Sapphire Glass & Matte Black Stainless Steel',
    description: 'The Tambour Horizon Light Up, the world’s most customizable connected timepiece, creates a luminous spectacle under its curved sapphire crystal adorned with 24 LED Monogram lights.',
    sku: 'QBB180',
    image: '/src/assets/images/lv_hero_travel_1791038872689.jpg',
    gallery: [
      '/src/assets/images/lv_hero_travel_1791038872689.jpg'
    ],
    dimensions: '44 mm Diameter',
    digitalPassportId: 'LV-PASSPORT-2026-TH2400',
    inStock: true
  }
];
