export interface DigitalPassportRecord {
  passportId: string;
  productName: string;
  modelSku: string;
  material: string;
  originAtelier: string;
  craftsmanRegion: string;
  craftsmanshipHours: number;
  sustainabilityRating: string;
  blockchainHash: string;
  issueDate: string;
  authenticityStatus: 'VERIFIED_GENUINE' | 'REGISTERED';
  materialsBreakdown: {
    name: string;
    percentage: number;
    source: string;
  }[];
  repairHistory: {
    date: string;
    location: string;
    serviceType: string;
    technician: string;
  }[];
  careGuide: string[];
}

export const DIGITAL_PASSPORTS: Record<string, DigitalPassportRecord> = {
  'LV-PASSPORT-2026-SP8921': {
    passportId: 'LV-PASSPORT-2026-SP8921',
    productName: 'Speedy 25 Monogram Canvas',
    modelSku: 'M41109',
    material: 'Monogram Coated Canvas & Natural Vachetta Cowhide',
    originAtelier: 'Asnières-sur-Seine Atelier',
    craftsmanRegion: 'Île-de-France, France',
    craftsmanshipHours: 18,
    sustainabilityRating: '100% Traceable Organic Sourcing',
    blockchainHash: '0x8f7a912b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b',
    issueDate: '14 May 2025',
    authenticityStatus: 'VERIFIED_GENUINE',
    materialsBreakdown: [
      { name: 'Organic Cotton Canvas Base', percentage: 45, source: 'GOTS Certified French Weaver' },
      { name: 'Natural Cowhide Leather (Vachetta)', percentage: 35, source: 'LWG Gold-Rated Tannery, Italy' },
      { name: 'Recycled Brass Hardware', percentage: 20, source: 'Sainte-Soline Forge, France' }
    ],
    repairHistory: [
      { date: '12 Jan 2026', location: 'Maison Vendôme Paris Atelier', serviceType: 'Complimentary Leather Conditioning & Edge Polish', technician: 'Master Artisan Pierre L.' },
      { date: '04 Oct 2025', location: 'Asnières-sur-Seine', serviceType: 'Initial Quality & Water-Resistance Inspection', technician: 'Inspector Helene V.' }
    ],
    careGuide: [
      'Keep away from prolonged exposure to direct sunlight and humidity.',
      'Allow natural Vachetta leather to develop a rich amber patina over time.',
      'Clean canvas with a soft damp cloth and diluted mild soap if required.',
      'Store inside the provided felt dust bag when not in use.'
    ]
  },
  'LV-PASSPORT-2026-NF8841': {
    passportId: 'LV-PASSPORT-2026-NF8841',
    productName: 'Neverfull MM Monogram',
    modelSku: 'M41178',
    material: 'Monogram Coated Canvas & Striped Textile Lining',
    originAtelier: 'Ducey Atelier',
    craftsmanRegion: 'Normandy, France',
    craftsmanshipHours: 22,
    sustainabilityRating: '98% Circular Material Lifecycle',
    blockchainHash: '0x3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b',
    issueDate: '28 August 2025',
    authenticityStatus: 'VERIFIED_GENUINE',
    materialsBreakdown: [
      { name: 'Coated Canvas Outer', percentage: 50, source: 'Normandy Atelier, France' },
      { name: 'Heritage Heritage Leather Straps', percentage: 30, source: 'Tuscany Tannery, Italy' },
      { name: 'Textile Lining', percentage: 20, source: 'Lyon Textile Mills, France' }
    ],
    repairHistory: [
      { date: '15 Feb 2026', location: 'Maison Champs-Élysées', serviceType: 'Side Lace Conditioning', technician: 'Master Artisan Marc B.' }
    ],
    careGuide: [
      'Avoid overloading beyond the recommended weight limit of 10kg.',
      'Protect internal pouch with microfiber cloth.',
      'Use official LV leather nourishing cream once annually.'
    ]
  },
  'LV-PASSPORT-2026-HZ5501': {
    passportId: 'LV-PASSPORT-2026-HZ5501',
    productName: 'Horizon 55 Roller Trunk',
    modelSku: 'M23203',
    material: 'Monogram Canvas, Aluminum Frame & Ultra-Quiet Wheels',
    originAtelier: 'Santa Isabel Atelier',
    craftsmanRegion: 'Catalonia, Spain',
    craftsmanshipHours: 34,
    sustainabilityRating: 'Lifetime Repair Guarantee',
    blockchainHash: '0x1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f',
    issueDate: '10 November 2025',
    authenticityStatus: 'VERIFIED_GENUINE',
    materialsBreakdown: [
      { name: 'Anodized Aircraft Aluminum Frame', percentage: 40, source: 'AeroTech Toulouse, France' },
      { name: 'Monogram Canvas Shell', percentage: 35, source: 'Asnières-sur-Seine, France' },
      { name: 'High-Impact Polymer Wheels', percentage: 25, source: 'Zurich Engineering, Switzerland' }
    ],
    repairHistory: [
      { date: '01 Feb 2026', location: 'Fifth Avenue NYC Service Hub', serviceType: 'Wheel Bearing Lubrication & Alignment Check', technician: 'Artisan David K.' }
    ],
    careGuide: [
      'Wipe down aluminum handle with dry microfiber after transit.',
      'Wheel assemblies can be serviced or replaced at any Louis Vuitton store worldwide.'
    ]
  }
};
