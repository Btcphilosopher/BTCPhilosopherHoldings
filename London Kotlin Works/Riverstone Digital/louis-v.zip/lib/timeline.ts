export interface TimelineEvent {
  year: string;
  title: string;
  subtitle: string;
  description: string;
  highlight: string;
  image: string;
}

export const TIMELINE_EVENTS: TimelineEvent[] = [
  {
    year: '1854',
    title: 'The Foundation',
    subtitle: '4 Rue Neuve-des-Capucines, Paris',
    description: 'At age 33, Louis Vuitton opens his master trunk-making workshop near Place Vendôme. He revolutionizes luggage by introducing flat-topped, waterproof Trianon grey canvas trunks designed for effortless stacking aboard steamships and trains.',
    highlight: 'Pioneered the modern flat trunk for the Golden Age of Steam.',
    image: '/src/assets/images/lv_maison_trunk_1791038920083.jpg'
  },
  {
    year: '1896',
    title: 'The Monogram Canvas',
    subtitle: 'Created by Georges Vuitton',
    description: 'In honor of his late father, Georges Vuitton designs the revolutionary Monogram Canvas. Featuring the interlocking LV initials surrounded by geometric four-petal floral motifs, it becomes an everlasting symbol of French luxury.',
    highlight: 'An iconic heritage signature patented worldwide.',
    image: '/src/assets/images/lv_women_collection_1791038885439.jpg'
  },
  {
    year: '1901',
    title: 'The Steamer Trunk',
    subtitle: 'Art of Transatlantic Crossing',
    description: 'The Steamer Bag is introduced as a lightweight canvas bag designed to be folded and placed inside a Louis Vuitton wardrobe trunk compartment during ocean liner voyages across the Atlantic.',
    highlight: 'Birth of the soft luxury travel bag concept.',
    image: '/src/assets/images/lv_travel_trunk_1791038907936.jpg'
  },
  {
    year: '1930s',
    title: 'The Art of Travel',
    subtitle: 'Golden Era of Aviation & Automobiles',
    description: 'Creation of iconic silhouettes including the Speedy bag (originally the "Express") and the Keepall duffle bag, accompanying pioneers, royalty, and international aviators.',
    highlight: 'Redefining luxury luggage for the fast-paced 20th century.',
    image: '/src/assets/images/lv_hero_travel_1791038872689.jpg'
  },
  {
    year: 'TODAY',
    title: 'Fashion, Art & Technology',
    subtitle: 'Maison Louis Vuitton',
    description: 'Blending centuries-old leatherworking savoir-faire with futuristic digital passports, sustainable atelier repairs, artistic collaborations, and high-fashion runways across Paris, Tokyo, and New York.',
    highlight: 'A global benchmark of innovation and enduring luxury.',
    image: '/src/assets/images/lv_men_collection_1791038897186.jpg'
  }
];
