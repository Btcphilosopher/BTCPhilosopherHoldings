export interface StoreLocation {
  id: string;
  name: string;
  city: string;
  address: string;
  hours: string;
  phone: string;
  services: string[];
}

export const STORES: StoreLocation[] = [
  {
    id: 'paris-vendome',
    name: 'Maison Louis Vuitton Vendôme',
    city: 'Paris, France',
    address: '2 Place Vendôme, 75001 Paris',
    hours: 'Mon - Sat: 10:00 AM - 7:30 PM | Sun: 11:00 AM - 7:00 PM',
    phone: '+33 1 81 69 22 10',
    services: ['Hotstamping Monogram Personalization', 'Private Salon Concierge', 'Master Craftsman Trunk Restoration', 'Fine Jewellery & High Horology']
  },
  {
    id: 'paris-champs-elysees',
    name: 'Maison Louis Vuitton Champs-Élysées',
    city: 'Paris, France',
    address: '101 Avenue des Champs-Élysées, 75008 Paris',
    hours: 'Mon - Sat: 10:00 AM - 8:00 PM | Sun: 11:00 AM - 7:00 PM',
    phone: '+33 1 53 57 52 00',
    services: ['Hotstamping', 'Fragrance Fountain Refilling', 'Ready-to-Wear Tailoring', 'Exhibition Gallery']
  },
  {
    id: 'new-york-5th-ave',
    name: 'Louis Vuitton Fifth Avenue',
    city: 'New York, USA',
    address: '1 East 57th Street, New York, NY 10022',
    hours: 'Mon - Sat: 10:00 AM - 8:00 PM | Sun: 11:00 AM - 6:00 PM',
    phone: '+1 212 758 8877',
    services: ['Bespoke Trunk Customization', 'VIP Private Lounge', 'Digital Passport NFC Service', 'Same-Day Hotel Delivery']
  },
  {
    id: 'tokyo-ginza-namiki',
    name: 'Maison Louis Vuitton Ginza Namiki',
    city: 'Tokyo, Japan',
    address: '7-6-1 Ginza, Chuo-ku, Tokyo 104-0061',
    hours: 'Mon - Sun: 11:00 AM - 8:00 PM',
    phone: '+81 3 3567 1261',
    services: ['Le Café V', 'Savoir-Faire Salon', 'Hotstamping', 'Personal Shopping']
  },
  {
    id: 'london-new-bond',
    name: 'Maison Louis Vuitton New Bond Street',
    city: 'London, UK',
    address: '17-20 New Bond Street, London W1S 2RB',
    hours: 'Mon - Sat: 10:00 AM - 7:00 PM | Sun: 12:00 PM - 6:00 PM',
    phone: '+44 20 7399 4050',
    services: ['Private Appointment Suite', 'Fine Horology & Watches', 'Hotstamping']
  }
];
