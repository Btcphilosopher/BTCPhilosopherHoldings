'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { SpiritProduct, CartItem, UserProfile, OrderRecord } from '@/lib/types';
import { SPIRITS_CATALOG } from '@/lib/data';

interface AppContextType {
  // Theme
  isDark: boolean;
  toggleTheme: () => void;

  // Age Gate
  isAgeVerified: boolean;
  verifyAge: (verified: boolean) => void;

  // Auth
  user: UserProfile | null;
  orders: OrderRecord[];
  isAuthOpen: boolean;
  authView: 'signin' | 'register' | 'profile';
  openAuth: (view?: 'signin' | 'register' | 'profile') => void;
  closeAuth: () => void;
  loginWithEmail: (email: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  registerWithEmail: (name: string, email: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  loginWithSocial: (provider: 'google' | 'apple' | 'github') => Promise<void>;
  logout: () => void;

  // Cart
  cart: CartItem[];
  isCartOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
  addToCart: (product: SpiritProduct, quantity?: number, size?: string) => void;
  removeFromCart: (productId: string, size: string) => void;
  updateQuantity: (productId: string, size: string, delta: number) => void;
  clearCart: () => void;
  promoCode: string;
  discountPercent: number;
  applyPromo: (code: string) => { success: boolean; message: string };
  subtotal: number;
  shipping: number;
  discountAmount: number;
  total: number;
  freeShippingThreshold: number;
  placeOrder: (shippingDetails: { name: string; address: string; city: string; postalCode: string }) => OrderRecord;

  // Search & Navigation
  isSearchOpen: boolean;
  openSearch: () => void;
  closeSearch: () => void;

  // Modals for Spirit details / Recipe details
  selectedSpirit: SpiritProduct | null;
  setSelectedSpirit: (spirit: SpiritProduct | null) => void;
  activeRecipeId: string | null;
  setActiveRecipeId: (id: string | null) => void;
  isHeritageModalOpen: boolean;
  setIsHeritageModalOpen: (open: boolean) => void;
  isTradeModalOpen: boolean;
  setIsTradeModalOpen: (open: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const FREE_SHIPPING_THRESHOLD = 75.0;

export function AppProvider({ children }: { children: React.ReactNode }) {
  // Theme state
  const [isDark, setIsDark] = useState<boolean>(true);

  // Age verification state
  const [isAgeVerified, setIsAgeVerified] = useState<boolean>(true); // default true for SSR, checked in useEffect

  // Auth state
  const [user, setUser] = useState<UserProfile | null>(null);
  const [orders, setOrders] = useState<OrderRecord[]>([]);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authView, setAuthView] = useState<'signin' | 'register' | 'profile'>('signin');

  // Cart state
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [promoCode, setPromoCode] = useState<string>('');
  const [discountPercent, setDiscountPercent] = useState<number>(0);

  // Modals
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [selectedSpirit, setSelectedSpirit] = useState<SpiritProduct | null>(null);
  const [activeRecipeId, setActiveRecipeId] = useState<string | null>(null);
  const [isHeritageModalOpen, setIsHeritageModalOpen] = useState(false);
  const [isTradeModalOpen, setIsTradeModalOpen] = useState(false);

  // Initial load from localStorage
  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        // Theme
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'light') {
          setIsDark(false);
          document.documentElement.classList.remove('dark');
          document.documentElement.classList.add('light');
        } else {
          setIsDark(true);
          document.documentElement.classList.add('dark');
          document.documentElement.classList.remove('light');
        }

        // Age verification check
        const ageCheck = localStorage.getItem('navy_age_verified');
        if (ageCheck !== 'true') {
          setIsAgeVerified(false);
        }

        // User session
        const savedUser = localStorage.getItem('navy_user_session');
        if (savedUser) {
          setUser(JSON.parse(savedUser));
        }

        // Orders
        const savedOrders = localStorage.getItem('navy_orders');
        if (savedOrders) {
          setOrders(JSON.parse(savedOrders));
        }

        // Cart
        const savedCart = localStorage.getItem('navy_cart');
        if (savedCart) {
          setCart(JSON.parse(savedCart));
        }
      } catch (e) {
        console.warn('Storage init failed:', e);
      }
    }, 0);

    return () => clearTimeout(timer);
  }, []);

  // Theme toggle
  const toggleTheme = () => {
    setIsDark((prev) => {
      const next = !prev;
      if (next) {
        document.documentElement.classList.add('dark');
        document.documentElement.classList.remove('light');
        localStorage.setItem('theme', 'dark');
      } else {
        document.documentElement.classList.remove('dark');
        document.documentElement.classList.add('light');
        localStorage.setItem('theme', 'light');
      }
      return next;
    });
  };

  const verifyAge = (verified: boolean) => {
    if (verified) {
      setIsAgeVerified(true);
      try {
        localStorage.setItem('navy_age_verified', 'true');
      } catch (_) {}
    } else {
      window.location.href = 'https://www.drinkaware.co.uk';
    }
  };

  // Auth actions
  const openAuth = (view: 'signin' | 'register' | 'profile' = 'signin') => {
    setAuthView(user ? 'profile' : view);
    setIsAuthOpen(true);
  };

  const closeAuth = () => {
    setIsAuthOpen(false);
  };

  const loginWithEmail = async (email: string, pass: string) => {
    if (!email || !pass) {
      return { success: false, error: 'Please enter both email and password.' };
    }
    if (pass.length < 6) {
      return { success: false, error: 'Password must be at least 6 characters.' };
    }

    // Instant simulated authentication with zero latency
    const nameFromEmail = email.split('@')[0];
    const formattedName = nameFromEmail.charAt(0).toUpperCase() + nameFromEmail.slice(1);
    const mockUser: UserProfile = {
      id: 'usr_' + Math.random().toString(36).substring(2, 9),
      name: formattedName || 'Officer Connoisseur',
      email: email.toLowerCase(),
      provider: 'email',
      membershipTier: 'Admiralty Club',
      ordersCount: orders.length,
      joinedDate: 'Joined Nov 2026',
    };

    setUser(mockUser);
    try {
      localStorage.setItem('navy_user_session', JSON.stringify(mockUser));
    } catch (_) {}
    setIsAuthOpen(false);
    return { success: true };
  };

  const registerWithEmail = async (name: string, email: string, pass: string) => {
    if (!name.trim()) {
      return { success: false, error: 'Please provide your full name.' };
    }
    if (!email || !email.includes('@')) {
      return { success: false, error: 'Please enter a valid email address.' };
    }
    if (pass.length < 6) {
      return { success: false, error: 'Password must be at least 6 characters.' };
    }

    const newUser: UserProfile = {
      id: 'usr_' + Math.random().toString(36).substring(2, 9),
      name: name.trim(),
      email: email.toLowerCase(),
      provider: 'email',
      membershipTier: 'Officer',
      ordersCount: 0,
      joinedDate: 'Member since Nov 2026',
    };

    setUser(newUser);
    try {
      localStorage.setItem('navy_user_session', JSON.stringify(newUser));
    } catch (_) {}
    setIsAuthOpen(false);
    return { success: true };
  };

  const loginWithSocial = async (provider: 'google' | 'apple' | 'github') => {
    const providerNames = {
      google: 'Commander Alexander Wright',
      apple: 'Lady Victoria Sterling',
      github: 'Captain Christopher Nelson',
    };

    const mockSocialUser: UserProfile = {
      id: 'soc_' + Math.random().toString(36).substring(2, 9),
      name: providerNames[provider],
      email: `${provider.toLowerCase()}.officer@admiralty.navy`,
      provider,
      avatarUrl: provider === 'google' ? 'https://picsum.photos/seed/captain/120/120' : undefined,
      membershipTier: 'Admiralty Club',
      ordersCount: 2,
      joinedDate: 'Royal Patron since 2025',
    };

    setUser(mockSocialUser);
    try {
      localStorage.setItem('navy_user_session', JSON.stringify(mockSocialUser));
    } catch (_) {}
    setIsAuthOpen(false);
  };

  const logout = () => {
    setUser(null);
    try {
      localStorage.removeItem('navy_user_session');
    } catch (_) {}
    setIsAuthOpen(false);
  };

  // Cart actions
  const saveCart = (items: CartItem[]) => {
    setCart(items);
    try {
      localStorage.setItem('navy_cart', JSON.stringify(items));
    } catch (_) {}
  };

  const addToCart = (product: SpiritProduct, quantity = 1, size = '70cl') => {
    setCart((prev) => {
      const existingIndex = prev.findIndex(
        (item) => item.product.id === product.id && item.selectedSize === size
      );
      let updated: CartItem[];
      if (existingIndex > -1) {
        updated = [...prev];
        updated[existingIndex].quantity += quantity;
      } else {
        updated = [...prev, { product, quantity, selectedSize: size }];
      }
      try {
        localStorage.setItem('navy_cart', JSON.stringify(updated));
      } catch (_) {}
      return updated;
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (productId: string, size: string) => {
    const updated = cart.filter(
      (item) => !(item.product.id === productId && item.selectedSize === size)
    );
    saveCart(updated);
  };

  const updateQuantity = (productId: string, size: string, delta: number) => {
    const updated = cart
      .map((item) => {
        if (item.product.id === productId && item.selectedSize === size) {
          const newQty = item.quantity + delta;
          return newQty > 0 ? { ...item, quantity: newQty } : null;
        }
        return item;
      })
      .filter(Boolean) as CartItem[];
    saveCart(updated);
  };

  const clearCart = () => {
    saveCart([]);
    setPromoCode('');
    setDiscountPercent(0);
  };

  const applyPromo = (code: string) => {
    const clean = code.trim().toUpperCase();
    if (clean === 'ADMIRAL10' || clean === 'NAVY10') {
      setPromoCode(clean);
      setDiscountPercent(10);
      return { success: true, message: 'Admiralty Discount applied (10% off)!' };
    }
    if (clean === 'ROYAL20') {
      setPromoCode(clean);
      setDiscountPercent(20);
      return { success: true, message: 'Royal Patron Discount applied (20% off)!' };
    }
    return { success: false, message: 'Invalid promo code. Try "ADMIRAL10".' };
  };

  const subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const discountAmount = (subtotal * discountPercent) / 100;
  const shipping = subtotal >= FREE_SHIPPING_THRESHOLD || subtotal === 0 ? 0 : 5.95;
  const total = Math.max(0, subtotal - discountAmount + shipping);

  const placeOrder = (shippingDetails: {
    name: string;
    address: string;
    city: string;
    postalCode: string;
  }): OrderRecord => {
    const newOrder: OrderRecord = {
      id: 'NSS-' + Math.floor(100000 + Math.random() * 900000),
      date: new Date().toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      }),
      items: cart.map((i) => ({
        name: `${i.product.name} (${i.selectedSize})`,
        quantity: i.quantity,
        price: i.product.price,
      })),
      total,
      status: 'Processing',
      trackingNumber: 'GB-RN-' + Math.floor(1000000 + Math.random() * 9000000),
    };

    const nextOrders = [newOrder, ...orders];
    setOrders(nextOrders);
    try {
      localStorage.setItem('navy_orders', JSON.stringify(nextOrders));
    } catch (_) {}

    clearCart();
    return newOrder;
  };

  return (
    <AppContext.Provider
      value={{
        isDark,
        toggleTheme,
        isAgeVerified,
        verifyAge,
        user,
        orders,
        isAuthOpen,
        authView,
        openAuth,
        closeAuth,
        loginWithEmail,
        registerWithEmail,
        loginWithSocial,
        logout,
        cart,
        isCartOpen,
        openCart: () => setIsCartOpen(true),
        closeCart: () => setIsCartOpen(false),
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        promoCode,
        discountPercent,
        applyPromo,
        subtotal,
        shipping,
        discountAmount,
        total,
        freeShippingThreshold: FREE_SHIPPING_THRESHOLD,
        placeOrder,
        isSearchOpen,
        openSearch: () => setIsSearchOpen(true),
        closeSearch: () => setIsSearchOpen(false),
        selectedSpirit,
        setSelectedSpirit,
        activeRecipeId,
        setActiveRecipeId,
        isHeritageModalOpen,
        setIsHeritageModalOpen,
        isTradeModalOpen,
        setIsTradeModalOpen,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
