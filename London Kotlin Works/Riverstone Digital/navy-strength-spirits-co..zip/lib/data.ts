import { SpiritProduct, CocktailRecipe } from './types';

export const SPIRITS_CATALOG: SpiritProduct[] = [
  {
    id: 'british-navy-rum-57',
    name: 'British Navy Rum Overproof',
    subtitle: 'The Royal Navy Standard • 57% ABV',
    abv: '57% ABV',
    price: 48.0,
    volume: '70cl',
    category: 'Rum',
    image: '/assets/aistudio/Navy_Rum_852cb1fd.png',
    description:
      'Distilled to the exacting historic Admiralty specification. A robust, rich blend of Jamaican pot still and Guyanese demerara rums aged in ex-bourbon white oak casks, passing the genuine gunpowder test.',
    tastingNotes: {
      nose: 'Dark molasses, charred Seville orange peel, vanilla pod, and roasted coffee bean.',
      palate: 'Viscous and velvety; treacle tart, dried dates, pipe tobacco, warming Jamaican allspice, and oak tannins.',
      finish: 'Exceptionally long, dry, and warming with echoes of dark dark chocolate and maritime sea spray.',
    },
    details: {
      origin: 'Guyana & Jamaica (Blended in Great Britain)',
      caskType: 'First-fill American White Oak',
      proof: 100, // 57% ABV = 100° UK Sikes Proof
    },
    badge: 'Original Admiralty Standard',
  },
  {
    id: 'gunpowder-spiced-rum',
    name: 'Gunpowder Proof Spiced Rum',
    subtitle: 'Infused with British Botanicals • 54.5% ABV',
    abv: '54.5% ABV',
    price: 44.0,
    volume: '70cl',
    category: 'Rum',
    image: '/images/cocktail_rum_punch_1793526138875.jpg',
    description:
      'A fiery, aromatic spiced rum macerated with whole clove, Ceylon cinnamon, charred ginger, and fresh kaffir lime zest. Perfect for elevated grogs and fiery highballs.',
    tastingNotes: {
      nose: 'Zesty candied lime, warm cinnamon bark, nutmeg, and smoked honeycomb.',
      palate: 'Burnt brown sugar, warming ginger heat, star anise, and toasted pimento.',
      finish: 'Lingering peppery warmth balanced by smooth molasses sweetness.',
    },
    details: {
      origin: 'Caribbean Blend, Spiced in Devonshire',
      caskType: 'Charred French Limousin Oak',
      proof: 95,
    },
    badge: 'Gold Medal 2025',
  },
  {
    id: 'overproof-pure-vodka',
    name: 'Overproof Pure Grain Vodka',
    subtitle: 'Triple Distilled Navy Strength • 50% ABV',
    abv: '50% ABV',
    price: 42.0,
    volume: '70cl',
    category: 'Vodka',
    image: '/images/spirits_range_vodka_1793526138920.jpg',
    description:
      'Crafted from 100% single-estate British wheat and drawn from pure Cornish spring water. Distilled seven times through copper column stills for crystal clarity with bold naval intensity.',
    tastingNotes: {
      nose: 'Crisp cracked black pepper, fresh lemon zest, and subtle sourdough crust.',
      palate: 'Silky, full-bodied grain mouthfeel, mineral freshness, and gentle citrus oils.',
      finish: 'Ultra-clean, crisp, and refreshing with an invigorating warm finish.',
    },
    details: {
      origin: 'Cornwall, Great Britain',
      caskType: 'Copper Column Rectified',
      proof: 87.5,
    },
    badge: 'Pure British Grain',
  },
  {
    id: 'admiralty-cask-reserve',
    name: "Admiralty Officer's Reserve 12-Year",
    subtitle: 'Single Cask Vintage Rum • 60% ABV',
    abv: '60% ABV',
    price: 85.0,
    volume: '70cl',
    category: 'Reserve',
    image: '/images/heritage_naval_officer_1793526138787.jpg',
    description:
      'Rare single barrel release aged 12 tropical years in Trinidad and finished for 24 months in Oloroso Sherry casks in coastal Scotland. Each numbered bottle is individually wax-sealed.',
    tastingNotes: {
      nose: 'Rich Christmas pudding, toasted marzipan, old leather binding, and Oloroso raisins.',
      palate: 'Immense depth; roasted hazelnuts, dark cocoa nibs, dried figs, and smoldering cedarwood.',
      finish: 'Majestic and enduring; sweet tobacco, salted caramel, and fine aged rancio.',
    },
    details: {
      origin: 'Trinidad & Scotland',
      caskType: 'Ex-Oloroso Sherry Puncheons',
      proof: 105,
    },
    badge: 'Limited Single Cask',
  },
  {
    id: 'royal-marine-gin',
    name: 'Royal Marine Navy Strength Gin',
    subtitle: 'Classic Juniper & Maritime Kelp • 57.2% ABV',
    abv: '57.2% ABV',
    price: 46.0,
    volume: '70cl',
    category: 'Gin',
    image: '/images/spirits_range_vodka_1793526138920.jpg',
    description:
      'Packed with double botanical charge. Distilled with Tuscan juniper, fresh coriander seed, angelica root, and wild foraged sea kelp from the windswept British coastline.',
    tastingNotes: {
      nose: 'Explosive piney juniper, maritime saline breeze, coriander citrus, and cardamom.',
      palate: 'Robust oily mouthfeel; bright citrus oils, herbal spice, and delicate mineral salt.',
      finish: 'Bracing, aromatic, and invigoratingly dry.',
    },
    details: {
      origin: 'Plymouth Sound, Great Britain',
      caskType: 'Copper Pot Still Distillation',
      proof: 100,
    },
    badge: 'Craft Heritage',
  },
];

export const COCKTAIL_RECIPES: CocktailRecipe[] = [
  {
    id: 'nelsons-blood',
    name: "Nelson's Blood",
    tagline: 'Legendary naval grog with pomegranate and dark spices',
    spiritBase: 'British Navy Rum Overproof (57% ABV)',
    glassware: 'Ornate Crystal Rocks Glass',
    garnish: 'Dehydrated blood orange wheel & star anise',
    image: '/images/cocktail_rum_punch_1793526138875.jpg',
    ingredients: [
      { item: 'British Navy Rum Overproof 57%', amountMetric: '50 ml', amountImperial: '1.75 oz' },
      { item: 'Cold-pressed Pomegranate Juice', amountMetric: '25 ml', amountImperial: '0.85 oz' },
      { item: 'Fresh Lime Juice', amountMetric: '20 ml', amountImperial: '0.7 oz' },
      { item: 'Demerara & Cinnamon Syrup', amountMetric: '15 ml', amountImperial: '0.5 oz' },
      { item: 'Angostura Aromatic Bitters', amountMetric: '2 dashes', amountImperial: '2 dashes' },
    ],
    instructions: [
      'Fill a heavy crystal mixing glass with large cubes of clear ice.',
      'Add Navy Rum 57%, pomegranate juice, fresh lime juice, cinnamon demerara syrup, and bitters.',
      'Stir vigorously for 25 seconds until chilled and silky.',
      'Strain over a single oversized hand-carved ice cube in a crystal rocks glass.',
      'Garnish with a dehydrated orange wheel and gently blow-torched star anise pod.',
    ],
    bartenderTip:
      'The 57% ABV cuts cleanly through rich fruit acids, providing a deep molasses spine without losing its botanical nuances.',
  },
  {
    id: 'royal-grog',
    name: "The Admiralty Grog",
    tagline: 'The historic 1740 daily ration perfected for modern palates',
    spiritBase: 'British Navy Rum Overproof (57% ABV)',
    glassware: 'Heavy Pewter or Crystal Tumbler',
    garnish: 'Expressed lime peel & grated nutmeg',
    image: '/assets/aistudio/Navy_Rum_852cb1fd.png',
    ingredients: [
      { item: 'British Navy Rum Overproof 57%', amountMetric: '60 ml', amountImperial: '2.0 oz' },
      { item: 'Fresh Key Lime Juice', amountMetric: '25 ml', amountImperial: '0.85 oz' },
      { item: 'Dark Raw Muscovado Syrup', amountMetric: '20 ml', amountImperial: '0.7 oz' },
      { item: 'Chilled British Spring Water', amountMetric: '30 ml', amountImperial: '1.0 oz' },
      { item: 'Freshly Grated Nutmeg', amountMetric: 'Pinch', amountImperial: 'Pinch' },
    ],
    instructions: [
      'Dissolve muscovado syrup into fresh lime juice in a cocktail shaker.',
      'Add overproof Navy Rum and chilled spring water.',
      'Fill shaker with crushed pebble ice and shake briefly for 10 seconds.',
      'Dump unstrained into a frozen crystal tumbler and top with fresh crushed ice.',
      'Grate whole nutmeg over the foam and float a freshly cut lime wheel.',
    ],
    bartenderTip:
      'In 1740, Vice-Admiral Edward Vernon ordered rum to be mixed with lime and water to sustain sailors on long Atlantic voyages.',
  },
  {
    id: 'overproof-dark-stormy',
    name: 'HMS Victory Dark & Stormy',
    tagline: 'Fiery craft ginger beer layered beneath overproof dark rum',
    spiritBase: 'Gunpowder Proof Spiced Rum',
    glassware: 'Cut-Crystal Highball Glass',
    garnish: 'Fresh lime wedge & candied ginger slice',
    image: '/images/spirits_range_vodka_1793526138920.jpg',
    ingredients: [
      { item: 'Gunpowder Proof Spiced Rum', amountMetric: '50 ml', amountImperial: '1.75 oz' },
      { item: 'Artisanal Fiery Ginger Beer', amountMetric: '120 ml', amountImperial: '4.0 oz' },
      { item: 'Fresh Lime Juice', amountMetric: '15 ml', amountImperial: '0.5 oz' },
      { item: 'Regans Orange Bitters', amountMetric: '1 dash', amountImperial: '1 dash' },
    ],
    instructions: [
      'Pack a crystal highball glass with tall spear ice.',
      'Pour in chilled ginger beer, fresh lime juice, and orange bitters; stir gently once.',
      'Carefully float the Gunpowder Proof Rum over the back of a bar spoon to create the dramatic stormy dark cloud layer.',
      'Serve with a polished copper straw and let guests stir as they drink.',
    ],
    bartenderTip:
      'Float slowly onto the surface tension to maintain the stark visual line between golden ginger brew and rich rum.',
  },
  {
    id: 'queens-cask-old-fashioned',
    name: "Queen's Cask Old Fashioned",
    tagline: "Officer's reserve rum stirred with bespoke smoked maple & bitters",
    spiritBase: "Admiralty Officer's Reserve 12-Year",
    glassware: 'Hand-blown Old Fashioned Tumbler',
    garnish: 'Flamed orange peel & Luxardo maraschino cherry',
    image: '/images/cocktail_rum_punch_1793526138875.jpg',
    ingredients: [
      { item: "Admiralty Officer's Reserve 12-Year", amountMetric: '60 ml', amountImperial: '2.0 oz' },
      { item: 'Grade-A Smoked Maple Syrup', amountMetric: '10 ml', amountImperial: '0.35 oz' },
      { item: 'Chocolate Mole Bitters', amountMetric: '2 dashes', amountImperial: '2 dashes' },
      { item: 'Orange Peel Oils', amountMetric: 'Expressed', amountImperial: 'Expressed' },
    ],
    instructions: [
      'Combine smoked maple and chocolate bitters in an old fashioned glass.',
      'Add 30ml of reserve rum and a large ice block; stir 15 times.',
      'Add remaining 30ml rum and stir another 15 rotations until chilled and silky.',
      'Express oils of fresh Seville orange peel across surface and rub the rim.',
    ],
    bartenderTip:
      'Because 60% ABV rum holds more aromatic weight, it withstands slow dilution gracefully as you sip.',
  },
];

export const HERITAGE_TIMELINE = [
  {
    year: '1655',
    title: 'The Royal Navy Rum Tradition Begins',
    description:
      'Following the British fleet’s capture of Jamaica under Admiral William Penn, the Royal Navy discovered Caribbean rum stored far better than traditional beer and wine, which soured in tropical heat. A daily ration of half a pint was established for every seaman.',
  },
  {
    year: '1740',
    title: 'Admiral Vernon & The Invention of "Grog"',
    description:
      'Vice-Admiral Edward Vernon, nicknamed "Old Grog" for his grogram fabric cloak, ordered that the sailor’s rum be diluted with fresh water and lime juice. This legendary order inadvertently cured scurvy and created the world’s most famous naval cocktail.',
  },
  {
    year: '1866',
    title: 'The Gunpowder Proof Standard',
    description:
      'Before modern hydrometers, ship pursers ("purveyors") tested the spirit by mixing it with black gunpowder. If the gunpowder still flashed when touched with a flame, the rum was "At Proof" (exactly 57% ABV or 100° Sikes). If it drowned the powder, it was rejected.',
  },
  {
    year: '1970',
    title: 'Black Tot Day (July 31st)',
    description:
      'After 315 continuous years, the British Admiralty discontinued the daily rum tot, citing the complexity of modern radar, nuclear submarines, and weapons systems. Sailors across the fleet wore black armbands and held symbolic burials at sea.',
  },
  {
    year: 'Today',
    title: 'The Navy Strength Spirits Revival',
    description:
      'Navy Strength Spirits Co. revives the authentic 57% ABV recipe, partnering with historic cooperages and pot stills to craft uncompromised overproof spirits honoring Britain’s seafaring heritage.',
  },
];
