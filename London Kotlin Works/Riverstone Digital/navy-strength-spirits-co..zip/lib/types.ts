export interface SpiritProduct {
  id: string;
  name: string;
  subtitle: string;
  abv: string;
  price: number;
  volume: string;
  category: 'Rum' | 'Vodka' | 'Gin' | 'Reserve';
  image: string;
  description: string;
  tastingNotes: {
    nose: string;
    palate: string;
    finish: string;
  };
  details: {
    origin: string;
    caskType: string;
    proof: number;
  };
  badge?: string;
}

export interface CartItem {
  product: SpiritProduct;
  quantity: number;
  selectedSize: string;
  giftWrap?: boolean;
}

export interface CocktailRecipe {
  id: string;
  name: string;
  tagline: string;
  spiritBase: string;
  glassware: string;
  garnish: string;
  image: string;
  ingredients: {
    item: string;
    amountMetric: string;
    amountImperial: string;
  }[];
  instructions: string[];
  bartenderTip: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
  provider: 'email' | 'google' | 'apple' | 'github';
  membershipTier: 'Admiralty Club' | 'Quartermaster' | 'Officer';
  ordersCount: number;
  joinedDate: string;
}

export interface OrderRecord {
  id: string;
  date: string;
  items: { name: string; quantity: number; price: number }[];
  total: number;
  status: 'Processing' | 'Dispatched' | 'Delivered';
  trackingNumber: string;
}
