'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useApp } from '@/context/AppContext';
import { X, ShoppingBag, Check, ShieldCheck, Award, Sparkles } from 'lucide-react';

export default function SpiritModal() {
  const { selectedSpirit, setSelectedSpirit, addToCart } = useApp();
  const [selectedSize, setSelectedSize] = useState<string>('70cl');
  const [isAdded, setIsAdded] = useState(false);

  if (!selectedSpirit) return null;

  const sizePricing: Record<string, { label: string; priceMultiplier: number }> = {
    '70cl': { label: '70cl Standard Admiralty Cask', priceMultiplier: 1.0 },
    '50cl': { label: '50cl Officer Flask', priceMultiplier: 0.75 },
    'Miniature': { label: '5cl Tasting Dram', priceMultiplier: 0.18 },
    'Collector Box': { label: '70cl in Waxed Oak Presentation Crate', priceMultiplier: 1.4 },
  };

  const calculatedPrice = selectedSpirit.price * sizePricing[selectedSize].priceMultiplier;

  const handleAdd = () => {
    addToCart(selectedSpirit, 1, selectedSize);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="spirit-modal-title"
      onKeyDown={(e) => e.key === 'Escape' && setSelectedSpirit(null)}
    >
      <div className="relative w-full max-w-3xl bg-[#0a1320] dark:bg-[#0a1320] light:bg-white border border-[#dfb74a]/40 shadow-2xl p-6 sm:p-8 text-slate-100 dark:text-slate-100 light:text-slate-900 max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={() => setSelectedSpirit(null)}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a]"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          {/* Left Column: Image */}
          <div className="md:col-span-5 relative aspect-[3/4] bg-[#04080e] border border-slate-800 overflow-hidden shadow-xl">
            <Image
              src={selectedSpirit.image}
              alt={selectedSpirit.name}
              fill
              referrerPolicy="no-referrer"
              className="object-cover"
              sizes="(max-width: 768px) 100vw, 320px"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />

            <div className="absolute bottom-4 left-4 right-4 text-center">
              <span className="font-mono text-xs text-[#ECC872] uppercase tracking-widest font-bold block">
                {selectedSpirit.abv} • {selectedSpirit.details.proof}° Sikes Proof
              </span>
            </div>
          </div>

          {/* Right Column: Details */}
          <div className="md:col-span-7 space-y-5 text-left">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold text-[#ECC872] uppercase tracking-[0.2em] mb-1">
                <span>{selectedSpirit.category} Collection</span>
                <span>•</span>
                <span>{selectedSpirit.details.origin.split(',')[0]}</span>
              </div>
              <h3
                id="spirit-modal-title"
                className="font-brand text-2xl sm:text-3xl font-bold tracking-wider text-slate-100 dark:text-slate-100 light:text-slate-900"
              >
                {selectedSpirit.name}
              </h3>
              <p className="font-editorial text-sm italic text-[#dfb74a] mt-0.5">
                {selectedSpirit.subtitle}
              </p>
            </div>

            <p className="text-xs text-slate-300 dark:text-slate-300 light:text-slate-600 leading-relaxed font-light">
              {selectedSpirit.description}
            </p>

            {/* Tasting Notes */}
            <div className="p-4 bg-[#070e17] dark:bg-[#070e17] light:bg-slate-50 border border-slate-800 dark:border-slate-800 light:border-slate-200 space-y-2 text-xs">
              <div className="font-brand uppercase tracking-wider text-[#ECC872] font-bold text-[11px]">
                Official Admiralty Tasting Notes
              </div>
              <div>
                <span className="text-[#dfb74a] font-semibold">Nose: </span>
                <span className="text-slate-300 dark:text-slate-300 light:text-slate-700 italic">
                  {selectedSpirit.tastingNotes.nose}
                </span>
              </div>
              <div>
                <span className="text-[#dfb74a] font-semibold">Palate: </span>
                <span className="text-slate-300 dark:text-slate-300 light:text-slate-700 italic">
                  {selectedSpirit.tastingNotes.palate}
                </span>
              </div>
              <div>
                <span className="text-[#dfb74a] font-semibold">Finish: </span>
                <span className="text-slate-300 dark:text-slate-300 light:text-slate-700 italic">
                  {selectedSpirit.tastingNotes.finish}
                </span>
              </div>
            </div>

            {/* Size selection */}
            <div className="space-y-2">
              <label className="block text-xs uppercase tracking-wider font-semibold text-slate-300 dark:text-slate-300 light:text-slate-700">
                Select Edition & Volume:
              </label>
              <div className="grid grid-cols-2 gap-2">
                {Object.keys(sizePricing).map((sz) => (
                  <button
                    key={sz}
                    onClick={() => setSelectedSize(sz)}
                    className={`p-2.5 text-left border text-xs transition-colors ${
                      selectedSize === sz
                        ? 'border-[#dfb74a] bg-[#dfb74a]/10 text-slate-100 dark:text-slate-100 light:text-slate-900 font-bold'
                        : 'border-slate-800 dark:border-slate-800 light:border-slate-200 text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="font-medium text-slate-200 dark:text-slate-200 light:text-slate-800">
                      {sz}
                    </div>
                    <div className="text-[10px] text-slate-400 truncate">
                      {sizePricing[sz].label}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Price & Add to Cart */}
            <div className="pt-4 border-t border-[#dfb74a]/20 flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase tracking-widest text-slate-400 block">
                  Total Allocation
                </span>
                <span className="font-mono text-2xl font-bold text-[#ECC872] tabular-nums">
                  £{calculatedPrice.toFixed(2)}
                </span>
              </div>

              <button
                onClick={handleAdd}
                className="px-6 py-3 bg-[#ECC872] hover:bg-[#dfb74a] text-slate-950 font-bold text-xs uppercase tracking-widest transition-all flex items-center gap-2 shadow-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a]"
              >
                {isAdded ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Added to Cart</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4" />
                    <span>Add to Cart</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
