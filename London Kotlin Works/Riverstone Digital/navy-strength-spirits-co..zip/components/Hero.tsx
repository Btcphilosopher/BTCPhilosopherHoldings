'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useApp } from '@/context/AppContext';
import { SPIRITS_CATALOG } from '@/lib/data';
import { ChevronRight, Award, Compass, Sparkles, Check, Info } from 'lucide-react';

export default function Hero() {
  const { addToCart, setSelectedSpirit } = useApp();
  const flagshipSpirit = SPIRITS_CATALOG[0]; // British Navy Rum Overproof 57%

  const [isAddedFeedback, setIsAddedFeedback] = useState(false);

  const handleQuickAdd = () => {
    addToCart(flagshipSpirit, 1, '70cl');
    setIsAddedFeedback(true);
    setTimeout(() => setIsAddedFeedback(false), 2000);
  };

  return (
    <section
      className="relative w-full overflow-hidden bg-[#070e17] dark:bg-[#070e17] light:bg-[#fcf9f2] border-b border-[#dfb74a]/20"
      aria-labelledby="hero-title"
    >
      {/* Background ambient lighting */}
      <div
        className="absolute inset-0 pointer-events-none opacity-40 dark:opacity-40 light:opacity-10"
        style={{
          background:
            'radial-gradient(circle at 75% 35%, rgba(223, 183, 74, 0.15) 0%, rgba(10, 25, 47, 0.4) 50%, transparent 80%)',
        }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 lg:py-20 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Typography & Story */}
          <div className="lg:col-span-6 flex flex-col justify-center text-left space-y-6">
            {/* Main Headline */}
            <div className="space-y-1">
              <h1
                id="hero-title"
                className="font-brand text-4xl sm:text-5xl lg:text-6xl font-light tracking-[0.14em] text-slate-100 dark:text-slate-100 light:text-slate-900 uppercase leading-[1.08]"
              >
                British
                <span className="block font-medium tracking-[0.16em] text-slate-50 dark:text-slate-50 light:text-slate-950">
                  Navy Rum
                </span>
              </h1>
            </div>

            {/* Sub-kicker */}
            <div className="flex items-center gap-2 text-xs sm:text-sm tracking-[0.24em] font-semibold text-[#ECC872] uppercase">
              <span>Tradition</span>
              <span className="text-[#dfb74a]/60">•</span>
              <span>Strength</span>
              <span className="text-[#dfb74a]/60">•</span>
              <span>Excellence</span>
            </div>

            {/* Editorial Lead & Description */}
            <div className="space-y-3 max-w-xl">
              <p className="font-editorial text-xl sm:text-2xl italic text-slate-200 dark:text-slate-200 light:text-slate-800 font-normal leading-relaxed">
                Overproof. Uncompromising. British.
              </p>
              <p className="text-sm sm:text-base text-slate-300 dark:text-slate-300 light:text-slate-600 leading-relaxed font-light">
                Our Navy Rum is crafted for those who demand more — with a rich heritage and a
                legendary strength. Distilled to the authentic 57% ABV Royal standard, where spirit
                and gunpowder met in test of true proof.
              </p>
            </div>

            {/* Quick Proof Badges (Informational, unboxed per anti-slop guidelines) */}
            <div className="flex flex-wrap items-center gap-y-2 gap-x-6 text-xs text-slate-400 dark:text-slate-400 light:text-slate-500 pt-2 border-t border-slate-800 dark:border-slate-800 light:border-slate-200">
              <div className="flex items-center gap-1.5">
                <span className="text-[#dfb74a] font-semibold">57% ABV</span>
                <span>(100° UK Sikes)</span>
              </div>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <div className="flex items-center gap-1.5">
                <span className="text-slate-200 dark:text-slate-200 light:text-slate-800 font-medium">Pot & Column Blend</span>
              </div>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <div className="flex items-center gap-1.5">
                <span className="text-slate-200 dark:text-slate-200 light:text-slate-800 font-medium">White Oak Aged</span>
              </div>
            </div>

            {/* CTA Buttons Row */}
            <div className="pt-2 flex flex-wrap items-center gap-4">
              <button
                onClick={() => setSelectedSpirit(flagshipSpirit)}
                className="inline-flex items-center justify-center gap-2 px-6 sm:px-8 py-3.5 bg-[#ECC872] hover:bg-[#dfb74a] text-slate-950 font-bold text-xs sm:text-sm tracking-[0.18em] uppercase transition-all duration-200 shadow-lg hover:shadow-amber-500/20 active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[#dfb74a] whitespace-nowrap"
              >
                <span>Discover Our Navy Rum</span>
                <ChevronRight className="w-4 h-4" />
              </button>

              <button
                onClick={handleQuickAdd}
                className="inline-flex items-center justify-center gap-2 px-5 py-3.5 border border-[#dfb74a]/60 hover:border-[#dfb74a] text-[#dfb74a] hover:bg-[#dfb74a]/10 font-semibold text-xs tracking-[0.16em] uppercase transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a] whitespace-nowrap"
              >
                {isAddedFeedback ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span className="text-emerald-400">Added to Cart</span>
                  </>
                ) : (
                  <>
                    <span>Quick Add • £48.00</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Right Column: Hero Visual from Design Attachment */}
          <div className="lg:col-span-6 relative flex items-center justify-center">
            <div className="relative w-full aspect-[4/3] sm:aspect-[16/11] lg:aspect-[4/3] rounded-sm overflow-hidden shadow-2xl border border-[#dfb74a]/30 group">
              <Image
                src="/assets/aistudio/Navy_Rum_852cb1fd.png"
                alt="British Navy Rum Overproof 57% ABV bottle beside a crystal tumbler of amber rum on ice, with a naval tall ship sailing at golden sunset"
                fill
                priority
                referrerPolicy="no-referrer"
                className="object-cover object-center group-hover:scale-[1.02] transition-transform duration-700 ease-out"
                sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 600px"
              />

              {/* Gradient Scrim for contrast overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#070e17]/80 via-transparent to-transparent pointer-events-none" />

              {/* Interactive Bottle Feature Hotspot */}
              <div className="absolute bottom-4 left-4 right-4 p-3 bg-[#070e17]/85 backdrop-blur-md border border-[#dfb74a]/40 flex items-center justify-between text-xs">
                <div>
                  <div className="text-[10px] tracking-widest text-[#dfb74a] uppercase font-bold">
                    Official Flagship
                  </div>
                  <div className="font-editorial text-sm sm:text-base text-slate-100 dark:text-slate-100 font-semibold">
                    British Navy Rum • 57% ABV (70cl)
                  </div>
                </div>
                <button
                  onClick={() => setSelectedSpirit(flagshipSpirit)}
                  className="px-3 py-1.5 bg-[#dfb74a]/20 hover:bg-[#dfb74a] text-[#dfb74a] hover:text-slate-950 font-semibold text-[11px] tracking-wider uppercase transition-colors"
                >
                  Tasting Notes
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
