'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { HERITAGE_TIMELINE } from '@/lib/data';
import { Flame, ShieldAlert, Sparkles, Anchor, Compass } from 'lucide-react';

export default function HeritageTimeline() {
  const [testProofAbv, setTestProofAbv] = useState<number>(57);
  const [isIgnited, setIsIgnited] = useState<boolean>(false);
  const [testResult, setTestResult] = useState<string | null>(null);

  const runGunpowderTest = () => {
    setIsIgnited(true);
    if (testProofAbv >= 57) {
      setTestResult('PROOF VERIFIED! Gunpowder flashes brilliantly. Firepower preserved!');
    } else {
      setTestResult('FAILED PROOF: Drowned powder will not ignite. Purser rejects the barrel!');
    }
  };

  return (
    <section
      id="brand-ethos"
      className="py-16 sm:py-24 bg-[#070e17] dark:bg-[#070e17] light:bg-[#fcf9f2] text-slate-100 dark:text-slate-100 light:text-slate-900 border-b border-[#dfb74a]/20"
      aria-labelledby="heritage-heading"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
          <div className="flex items-center justify-center gap-2 text-xs tracking-[0.24em] font-semibold text-[#ECC872] uppercase">
            <Anchor className="w-4 h-4 text-[#dfb74a]" />
            <span>Royal Admiralty Chronicles</span>
          </div>
          <h2
            id="heritage-heading"
            className="font-brand text-3xl sm:text-4xl font-light tracking-[0.14em] uppercase text-slate-100 dark:text-slate-100 light:text-slate-900"
          >
            A Proud Tradition Since the Age of Sail
          </h2>
          <p className="font-editorial text-lg italic text-slate-300 dark:text-slate-300 light:text-slate-600">
            For more than three centuries, the British fleet was sustained by unyielding spirit and
            uncompromising standards.
          </p>
        </div>

        {/* Interactive Gunpowder Proof Simulator */}
        <div className="mb-20 p-6 sm:p-10 bg-[#0a1320] dark:bg-[#0a1320] light:bg-white border border-[#dfb74a]/40 shadow-2xl rounded-sm">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7 space-y-4 text-left">
              <div className="flex items-center gap-2 text-[#ECC872] text-xs font-bold tracking-widest uppercase">
                <Flame className="w-4 h-4 text-amber-500" />
                <span>Historic Demonstration</span>
              </div>
              <h3 className="font-brand text-2xl font-bold tracking-wider text-slate-100 dark:text-slate-100 light:text-slate-900">
                The 18th Century Gunpowder Proof Test
              </h3>
              <p className="text-sm text-slate-300 dark:text-slate-300 light:text-slate-600 leading-relaxed font-light">
                In wooden warships, spirit casks were stowed alongside gunpowder magazines. If a
                cask ruptured during battle, rum under 57% ABV would soak and ruin the powder,
                leaving cannons silent. Officers tested every delivery: rum and black powder were
                mixed and ignited with a flint spark.
              </p>

              {/* Interactive Controller */}
              <div className="pt-2 space-y-3">
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span className="text-slate-300 dark:text-slate-300 light:text-slate-700">
                    Adjust Spirit Strength:
                  </span>
                  <span className="font-mono text-base font-bold text-[#dfb74a]">
                    {testProofAbv}% ABV {testProofAbv === 57 && '— Official Admiralty Standard'}
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-xs font-mono text-slate-500">40%</span>
                  <input
                    type="range"
                    min="35"
                    max="65"
                    step="1"
                    value={testProofAbv}
                    onChange={(e) => {
                      setTestProofAbv(Number(e.target.value));
                      setIsIgnited(false);
                      setTestResult(null);
                    }}
                    className="w-full accent-[#ECC872] cursor-pointer"
                    aria-label="Spirit ABV slider for gunpowder test"
                  />
                  <span className="text-xs font-mono text-slate-500">65%</span>
                </div>

                <div className="flex items-center gap-4 pt-2">
                  <button
                    onClick={runGunpowderTest}
                    className="px-6 py-2.5 bg-[#ECC872] hover:bg-[#dfb74a] text-slate-950 font-bold text-xs tracking-widest uppercase transition-all shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a]"
                  >
                    Strike Flint & Test Proof
                  </button>
                  <button
                    onClick={() => {
                      setTestProofAbv(57);
                      setIsIgnited(false);
                      setTestResult(null);
                    }}
                    className="text-xs text-slate-400 hover:text-[#dfb74a] underline"
                  >
                    Reset to 57%
                  </button>
                </div>
              </div>
            </div>

            {/* Visual Flare Box */}
            <div className="lg:col-span-5 flex flex-col items-center justify-center p-8 bg-[#04080e] dark:bg-[#04080e] light:bg-slate-950 border border-slate-800 rounded-sm min-h-[220px] relative overflow-hidden text-center">
              {isIgnited ? (
                testProofAbv >= 57 ? (
                  <div className="space-y-3 animate-in zoom-in-95 duration-200">
                    <div className="w-16 h-16 mx-auto rounded-full bg-amber-500/20 border border-amber-400 flex items-center justify-center animate-pulse">
                      <Flame className="w-10 h-10 text-amber-400" />
                    </div>
                    <div className="text-amber-400 font-brand text-sm tracking-widest uppercase font-bold">
                      100° Sikes Proof Verified
                    </div>
                    <p className="text-xs text-slate-300 max-w-xs">{testResult}</p>
                  </div>
                ) : (
                  <div className="space-y-3 animate-in zoom-in-95 duration-200">
                    <div className="w-16 h-16 mx-auto rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center">
                      <ShieldAlert className="w-10 h-10 text-rose-400" />
                    </div>
                    <div className="text-rose-400 font-brand text-sm tracking-widest uppercase font-bold">
                      Proof Failed (&lt; 57% ABV)
                    </div>
                    <p className="text-xs text-slate-400 max-w-xs">{testResult}</p>
                  </div>
                )
              ) : (
                <div className="space-y-2 text-slate-400">
                  <Compass className="w-10 h-10 mx-auto text-[#dfb74a] opacity-80" />
                  <p className="text-xs font-editorial italic text-slate-300">
                    Gunpowder grains placed on copper pan. Adjust ABV and strike flint to test.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Editorial Timeline (Zero-pill discipline, clean unboxed markers) */}
        <div className="relative border-l border-[#dfb74a]/30 ml-4 md:ml-32 space-y-12">
          {HERITAGE_TIMELINE.map((item, idx) => (
            <div key={idx} className="relative pl-8 sm:pl-10 group">
              {/* Year marker */}
              <div className="absolute -left-[9px] top-1.5 w-4 h-4 rounded-full bg-[#070e17] dark:bg-[#070e17] light:bg-[#fcf9f2] border-2 border-[#dfb74a] group-hover:bg-[#dfb74a] transition-colors" />

              <div className="md:absolute md:-left-32 md:top-0 md:w-24 md:text-right">
                <span className="font-mono text-base font-bold text-[#ECC872] tracking-wider block">
                  {item.year}
                </span>
              </div>

              <div className="space-y-1.5">
                <h3 className="font-brand text-lg font-bold tracking-wider text-slate-100 dark:text-slate-100 light:text-slate-900 group-hover:text-[#dfb74a] transition-colors">
                  {item.title}
                </h3>
                <p className="text-sm text-slate-300 dark:text-slate-300 light:text-slate-600 leading-relaxed font-light max-w-3xl">
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
