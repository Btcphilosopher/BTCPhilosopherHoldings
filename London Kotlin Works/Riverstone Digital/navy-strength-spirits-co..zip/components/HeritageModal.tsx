'use client';

import React from 'react';
import Image from 'next/image';
import { useApp } from '@/context/AppContext';
import { X, Anchor } from 'lucide-react';

export default function HeritageModal() {
  const { isHeritageModalOpen, setIsHeritageModalOpen } = useApp();

  if (!isHeritageModalOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in"
      role="dialog"
      aria-modal="true"
      aria-labelledby="heritage-modal-title"
    >
      <div className="relative w-full max-w-3xl bg-[#0a1320] dark:bg-[#0a1320] light:bg-white border border-[#dfb74a]/40 shadow-2xl p-6 sm:p-8 text-slate-100 dark:text-slate-100 light:text-slate-900 max-h-[85vh] overflow-y-auto">
        <button
          onClick={() => setIsHeritageModalOpen(false)}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white"
          aria-label="Close heritage modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="space-y-6 text-left">
          <div className="space-y-1 border-b border-[#dfb74a]/20 pb-4">
            <div className="flex items-center gap-2 text-xs font-bold text-[#dfb74a] uppercase tracking-widest">
              <Anchor className="w-4 h-4" />
              <span>Three Centuries of Naval Maritime History</span>
            </div>
            <h2
              id="heritage-modal-title"
              className="font-brand text-2xl sm:text-3xl font-bold tracking-wider"
            >
              The Story of British Navy Rum
            </h2>
            <p className="font-editorial text-sm italic text-slate-300 dark:text-slate-300 light:text-slate-600">
              From the battle of Trafalgar to Black Tot Day 1970 — the world&apos;s most storied spirit.
            </p>
          </div>

          <div className="relative aspect-[16/8] overflow-hidden border border-slate-800">
            <Image
              src="/images/heritage_naval_officer_1793526138787.jpg"
              alt="Naval officer on wooden warship"
              fill
              referrerPolicy="no-referrer"
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
            <div className="absolute bottom-3 left-4 text-xs font-mono text-[#ECC872]">
              Quarterdeck of HMS Victory, Royal Navy Fleet
            </div>
          </div>

          <div className="space-y-4 text-xs sm:text-sm text-slate-300 dark:text-slate-300 light:text-slate-600 leading-relaxed font-light">
            <p>
              In 1655, a British expeditionary fleet captured Jamaica. Aboard King Charles II&apos;s
              ships, beer and wine soured rapidly under the sweltering Caribbean sun. Rum, distilled
              from sugarcane molasses, remained pristine indefinitely. The daily rum ration—known as
              the &ldquo;tot&rdquo;—was instituted, becoming an indelible ritual of British naval life.
            </p>
            <p>
              By 1866, the standard was codified into British law: rum supplied to His Majesty&apos;s
              fleet had to test at 100° Sikes proof (57% alcohol by volume). This ensured that even
              if rum casks were punctured by cannon fire in the hold and flooded gunpowder
              cartridges, the gunpowder would still ignite.
            </p>
            <p>
              Today, Navy Strength Spirits Co. revives this storied maritime legacy, blending
              heavy pot still rums aged in tropical climates with charred oak casks, bringing the
              uncompromised taste of maritime history to your glass.
            </p>
          </div>

          <div className="p-4 bg-[#070e17] dark:bg-[#070e17] light:bg-slate-50 border border-slate-800 flex items-center justify-between">
            <div className="text-xs">
              <span className="font-bold text-[#dfb74a] block uppercase">
                Admiralty Heritage Archive
              </span>
              <span className="text-slate-400">
                Official specifications curated in partnership with British naval historians.
              </span>
            </div>
            <button
              onClick={() => setIsHeritageModalOpen(false)}
              className="px-5 py-2 bg-[#ECC872] text-slate-950 font-bold text-xs uppercase tracking-wider hover:bg-[#dfb74a]"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
