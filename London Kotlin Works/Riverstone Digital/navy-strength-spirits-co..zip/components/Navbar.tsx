'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useApp } from '@/context/AppContext';
import {
  Search,
  ShoppingBag,
  Moon,
  Sun,
  User,
  Menu,
  X,
  ChevronDown,
  ShieldCheck,
  Crown,
} from 'lucide-react';
import { SPIRITS_CATALOG } from '@/lib/data';

export default function Navbar() {
  const {
    isDark,
    toggleTheme,
    user,
    openAuth,
    cart,
    openCart,
    openSearch,
    setSelectedSpirit,
    setIsHeritageModalOpen,
    setIsTradeModalOpen,
  } = useApp();

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSpiritsDropdownOpen, setIsSpiritsDropdownOpen] = useState(false);

  const cartItemCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  const scrollToSection = (id: string) => {
    setIsMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-[#dfb74a]/20 bg-[#070e17]/95 dark:bg-[#070e17]/95 light:bg-[#fcf9f2]/95 backdrop-blur-md transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4 md:gap-8">
        {/* Zone 1: Brand Wordmark & Crown Insignia */}
        <Link
          href="/"
          className="flex flex-col items-center group shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a] rounded px-1"
          aria-label="Navy Strength Spirits Co. Home"
        >
          <div className="flex items-center gap-1.5 text-[#ECC872] group-hover:text-[#dfb74a] transition-colors">
            <Crown className="w-5 h-5 text-[#dfb74a]" aria-hidden="true" />
          </div>
          <span className="font-brand text-xs sm:text-sm tracking-[0.22em] font-bold text-slate-100 dark:text-slate-100 light:text-slate-900 uppercase whitespace-nowrap">
            Navy Strength
          </span>
          <div className="flex items-center gap-1.5 w-full justify-center">
            <div className="h-[1px] w-3 bg-[#dfb74a]/60"></div>
            <span className="text-[9px] tracking-[0.3em] font-semibold text-[#dfb74a] uppercase">
              British
            </span>
            <div className="h-[1px] w-3 bg-[#dfb74a]/60"></div>
          </div>
        </Link>

        {/* Zone 2: Navigation Links */}
        <nav
          className="hidden md:flex items-center gap-6 lg:gap-8 text-xs tracking-[0.16em] uppercase font-medium text-slate-300 dark:text-slate-300 light:text-slate-700"
          aria-label="Primary Navigation"
        >
          {/* Spirits Dropdown */}
          <div
            className="relative"
            onMouseEnter={() => setIsSpiritsDropdownOpen(true)}
            onMouseLeave={() => setIsSpiritsDropdownOpen(false)}
          >
            <button
              onClick={() => scrollToSection('spirits-collection')}
              className="flex items-center gap-1 hover:text-[#dfb74a] transition-colors py-2 whitespace-nowrap shrink-0"
              aria-expanded={isSpiritsDropdownOpen}
              aria-haspopup="true"
            >
              <span>Our Spirits</span>
              <ChevronDown className="w-3.5 h-3.5 opacity-70" aria-hidden="true" />
            </button>

            {/* Dropdown menu */}
            {isSpiritsDropdownOpen && (
              <div className="absolute top-full left-0 w-64 bg-[#0a1424] dark:bg-[#0a1424] light:bg-white border border-[#dfb74a]/30 shadow-2xl py-2 z-50 animate-in fade-in slide-in-from-top-1 duration-150">
                <div className="px-3 py-1.5 text-[10px] tracking-wider text-[#dfb74a] font-semibold border-b border-[#dfb74a]/10 uppercase">
                  Royal Standard Spirits
                </div>
                {SPIRITS_CATALOG.map((spirit) => (
                  <button
                    key={spirit.id}
                    onClick={() => {
                      setSelectedSpirit(spirit);
                      setIsSpiritsDropdownOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 text-xs text-slate-200 dark:text-slate-200 light:text-slate-800 hover:bg-[#dfb74a]/10 hover:text-[#dfb74a] transition-colors flex items-center justify-between"
                  >
                    <span className="font-editorial text-sm normal-case tracking-normal">
                      {spirit.name}
                    </span>
                    <span className="text-[10px] text-[#dfb74a] font-mono">{spirit.abv}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <button
            onClick={() => setIsHeritageModalOpen(true)}
            className="hover:text-[#dfb74a] transition-colors whitespace-nowrap shrink-0"
          >
            Our Heritage
          </button>

          <button
            onClick={() => scrollToSection('cocktails-section')}
            className="hover:text-[#dfb74a] transition-colors whitespace-nowrap shrink-0"
          >
            Cocktails
          </button>

          <button
            onClick={() => setIsTradeModalOpen(true)}
            className="hover:text-[#dfb74a] transition-colors whitespace-nowrap shrink-0"
          >
            Trade
          </button>

          <button
            onClick={() => scrollToSection('brand-ethos')}
            className="hover:text-[#dfb74a] transition-colors whitespace-nowrap shrink-0"
          >
            About
          </button>
        </nav>

        {/* Zone 3: Actions & Top Bar Contract */}
        <div className="flex items-center gap-2 sm:gap-4 shrink-0">
          {/* Quick Search */}
          <button
            onClick={openSearch}
            className="p-2 text-slate-300 dark:text-slate-300 light:text-slate-700 hover:text-[#dfb74a] transition-colors rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a]"
            aria-label="Search spirits, recipes, and history"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Theme Toggle */}
          <button
            onClick={toggleTheme}
            className="p-2 text-slate-300 dark:text-slate-300 light:text-slate-700 hover:text-[#dfb74a] transition-colors rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a]"
            aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
            title={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
          >
            {isDark ? <Sun className="w-4 h-4 text-amber-300" /> : <Moon className="w-4 h-4 text-slate-700" />}
          </button>

          {/* Auth Button */}
          <button
            onClick={() => openAuth(user ? 'profile' : 'signin')}
            className="flex items-center gap-1.5 py-1.5 px-2.5 text-xs tracking-wider uppercase text-slate-300 dark:text-slate-300 light:text-slate-800 hover:text-[#dfb74a] transition-colors border border-transparent hover:border-[#dfb74a]/30 rounded focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a]"
            aria-label={user ? `User profile: ${user.name}` : 'Sign in or register'}
          >
            <User className="w-4 h-4 text-[#dfb74a]" />
            <span className="hidden xl:inline text-[11px] font-medium">
              {user ? user.name.split(' ')[0] : 'Sign In'}
            </span>
          </button>

          {/* Hairline Divider */}
          <div className="hidden sm:block h-5 w-[1px] bg-slate-700/60 dark:bg-slate-700/60 light:bg-slate-300" />

          {/* Shop Now Primary Button with Cart Trigger */}
          <button
            onClick={openCart}
            className="relative flex items-center gap-2 px-3.5 sm:px-4 py-2 border border-[#dfb74a] text-[#dfb74a] hover:bg-[#dfb74a] hover:text-slate-950 transition-all duration-200 text-xs tracking-[0.14em] uppercase font-semibold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a] whitespace-nowrap shrink-0 group"
            aria-label={`Open shopping cart. ${cartItemCount} items in cart.`}
          >
            <span>Shop Now</span>
            <ShoppingBag className="w-3.5 h-3.5 group-hover:scale-110 transition-transform" />
            {cartItemCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-[#ECC872] text-slate-950 text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center shadow-md">
                {cartItemCount}
              </span>
            )}
          </button>

          {/* Mobile menu toggle */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 text-slate-300 dark:text-slate-300 light:text-slate-800 hover:text-[#dfb74a] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a]"
            aria-label={isMobileMenuOpen ? 'Close menu' : 'Open mobile menu'}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {isMobileMenuOpen && (
        <div className="md:hidden border-t border-[#dfb74a]/20 bg-[#070e17] dark:bg-[#070e17] light:bg-[#fcf9f2] px-6 py-6 space-y-4 animate-in slide-in-from-top-4 duration-200">
          <div className="flex flex-col gap-3 text-sm tracking-wider uppercase font-medium text-slate-200 dark:text-slate-200 light:text-slate-800">
            <button
              onClick={() => scrollToSection('spirits-collection')}
              className="text-left py-2 hover:text-[#dfb74a] border-b border-slate-800 dark:border-slate-800 light:border-slate-200"
            >
              Our Spirits Collection
            </button>
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                setIsHeritageModalOpen(true);
              }}
              className="text-left py-2 hover:text-[#dfb74a] border-b border-slate-800 dark:border-slate-800 light:border-slate-200"
            >
              Our Heritage & Lore
            </button>
            <button
              onClick={() => scrollToSection('cocktails-section')}
              className="text-left py-2 hover:text-[#dfb74a] border-b border-slate-800 dark:border-slate-800 light:border-slate-200"
            >
              Cocktail Recipes
            </button>
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                setIsTradeModalOpen(true);
              }}
              className="text-left py-2 hover:text-[#dfb74a] border-b border-slate-800 dark:border-slate-800 light:border-slate-200"
            >
              Trade & Wholesale
            </button>
            <button
              onClick={() => scrollToSection('brand-ethos')}
              className="text-left py-2 hover:text-[#dfb74a] border-b border-slate-800 dark:border-slate-800 light:border-slate-200"
            >
              About the Distillery
            </button>
          </div>

          <div className="pt-2 flex items-center justify-between">
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                openAuth(user ? 'profile' : 'signin');
              }}
              className="flex items-center gap-2 text-xs uppercase tracking-wider text-[#dfb74a]"
            >
              <User className="w-4 h-4" />
              <span>{user ? `Account (${user.name})` : 'Account Sign In'}</span>
            </button>

            <button
              onClick={toggleTheme}
              className="flex items-center gap-2 text-xs uppercase tracking-wider text-slate-300 dark:text-slate-300 light:text-slate-700"
            >
              {isDark ? <Sun className="w-4 h-4 text-amber-300" /> : <Moon className="w-4 h-4" />}
              <span>{isDark ? 'Light Mode' : 'Dark Mode'}</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
