'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { X, Building2, CheckCircle2, Send } from 'lucide-react';

export default function TradeModal() {
  const { isTradeModalOpen, setIsTradeModalOpen } = useApp();
  const [submitted, setSubmitted] = useState(false);
  const [companyName, setCompanyName] = useState('');
  const [contactName, setContactName] = useState('');
  const [tradeEmail, setTradeEmail] = useState('');
  const [businessType, setBusinessType] = useState('Luxury Hotel / Cocktail Bar');
  const [estimatedCases, setEstimatedCases] = useState('10 - 50 cases / month');

  if (!isTradeModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in"
      role="dialog"
      aria-modal="true"
      aria-labelledby="trade-modal-title"
    >
      <div className="relative w-full max-w-lg bg-[#0a1320] dark:bg-[#0a1320] light:bg-white border border-[#dfb74a]/40 shadow-2xl p-6 sm:p-8 text-slate-100 dark:text-slate-100 light:text-slate-900">
        <button
          onClick={() => {
            setIsTradeModalOpen(false);
            setSubmitted(false);
          }}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white"
          aria-label="Close trade modal"
        >
          <X className="w-5 h-5" />
        </button>

        {submitted ? (
          <div className="text-center py-6 space-y-4">
            <div className="w-14 h-14 mx-auto rounded-full bg-emerald-500/20 border border-emerald-400 flex items-center justify-center text-emerald-400">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <div className="space-y-1">
              <div className="text-xs uppercase tracking-widest text-[#dfb74a] font-bold">
                Inquiry Logged
              </div>
              <h3 className="font-brand text-2xl font-bold">
                Thank You, {contactName || 'Partner'}
              </h3>
              <p className="text-xs text-slate-400 max-w-xs mx-auto">
                Our Commercial Admiralty Liaison will review your trade account application and
                transmit wholesale rate sheets within 24 hours.
              </p>
            </div>
            <button
              onClick={() => {
                setIsTradeModalOpen(false);
                setSubmitted(false);
              }}
              className="px-6 py-2.5 bg-[#ECC872] hover:bg-[#dfb74a] text-slate-950 font-bold text-xs uppercase tracking-widest"
            >
              Done
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 text-left">
            <div className="space-y-1 border-b border-[#dfb74a]/20 pb-3">
              <div className="flex items-center gap-1.5 text-xs text-[#dfb74a] font-bold uppercase tracking-widest">
                <Building2 className="w-4 h-4" />
                <span>Trade & Wholesale Accounts</span>
              </div>
              <h3 id="trade-modal-title" className="font-brand text-xl font-bold">
                Apply for Admiralty Allocation
              </h3>
              <p className="text-xs text-slate-400">
                Direct wholesale pricing, custom cask selections, and bar staff masterclasses for
                hospitality partners worldwide.
              </p>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block uppercase tracking-wider font-semibold text-slate-300 dark:text-slate-300 light:text-slate-700 mb-1">
                  Establishment / Company Name
                </label>
                <input
                  type="text"
                  required
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  placeholder="e.g. The Connaught Bar or Royal Yacht Club"
                  className="w-full bg-[#070e17] dark:bg-[#070e17] light:bg-slate-50 border border-slate-700 p-2.5 text-slate-100 dark:text-slate-100 light:text-slate-900 placeholder:text-slate-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block uppercase tracking-wider font-semibold text-slate-300 dark:text-slate-300 light:text-slate-700 mb-1">
                    Contact Name
                  </label>
                  <input
                    type="text"
                    required
                    value={contactName}
                    onChange={(e) => setContactName(e.target.value)}
                    placeholder="Head Bartender / Beverage Director"
                    className="w-full bg-[#070e17] dark:bg-[#070e17] light:bg-slate-50 border border-slate-700 p-2.5 text-slate-100 dark:text-slate-100 light:text-slate-900 placeholder:text-slate-500"
                  />
                </div>
                <div>
                  <label className="block uppercase tracking-wider font-semibold text-slate-300 dark:text-slate-300 light:text-slate-700 mb-1">
                    Business Email
                  </label>
                  <input
                    type="email"
                    required
                    value={tradeEmail}
                    onChange={(e) => setTradeEmail(e.target.value)}
                    placeholder="orders@establishment.co.uk"
                    className="w-full bg-[#070e17] dark:bg-[#070e17] light:bg-slate-50 border border-slate-700 p-2.5 text-slate-100 dark:text-slate-100 light:text-slate-900 placeholder:text-slate-500"
                  />
                </div>
              </div>

              <div>
                <label className="block uppercase tracking-wider font-semibold text-slate-300 dark:text-slate-300 light:text-slate-700 mb-1">
                  Business Category
                </label>
                <select
                  value={businessType}
                  onChange={(e) => setBusinessType(e.target.value)}
                  className="w-full bg-[#070e17] dark:bg-[#070e17] light:bg-slate-50 border border-slate-700 p-2.5 text-slate-100 dark:text-slate-100 light:text-slate-900"
                >
                  <option>Luxury Hotel / Cocktail Bar</option>
                  <option>Independent Wine & Spirits Merchant</option>
                  <option>Private Members Club</option>
                  <option>International Importer / Distributor</option>
                </select>
              </div>

              <div>
                <label className="block uppercase tracking-wider font-semibold text-slate-300 dark:text-slate-300 light:text-slate-700 mb-1">
                  Estimated Monthly Allocation
                </label>
                <select
                  value={estimatedCases}
                  onChange={(e) => setEstimatedCases(e.target.value)}
                  className="w-full bg-[#070e17] dark:bg-[#070e17] light:bg-slate-50 border border-slate-700 p-2.5 text-slate-100 dark:text-slate-100 light:text-slate-900"
                >
                  <option>5 - 10 cases / month</option>
                  <option>10 - 50 cases / month</option>
                  <option>50 - 200 cases / month</option>
                  <option>Pallet / Container shipments</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-[#ECC872] hover:bg-[#dfb74a] text-slate-950 font-bold text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-2"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Submit Wholesale Application</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
