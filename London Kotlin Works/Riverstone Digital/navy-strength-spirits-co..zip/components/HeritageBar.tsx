'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';

export default function HeritageBar() {
  const { setIsHeritageModalOpen } = useApp();

  const pillars = [
    {
      title: 'British Heritage',
      description: 'Dating back to 1655 and the daily naval tot of the Royal Navy.',
      icon: (
        <svg
          className="w-7 h-7 text-[#dfb74a]"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
        >
          {/* Stylized Union Jack geometry */}
          <rect x="2" y="3" width="20" height="18" rx="1" />
          <line x1="2" y1="12" x2="22" y2="12" strokeWidth="2" />
          <line x1="12" y1="3" x2="12" y2="21" strokeWidth="2" />
          <line x1="2" y1="3" x2="22" y2="21" />
          <line x1="22" y1="3" x2="2" y2="21" />
        </svg>
      ),
    },
    {
      title: 'Overproof Strength',
      description: 'Tested at 57% ABV to ignite gunpowder without failing.',
      icon: (
        <svg
          className="w-7 h-7 text-[#dfb74a]"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
        >
          {/* Stylized Diamond */}
          <polygon points="12 2 22 8.5 12 22 2 8.5 12 2" />
          <line x1="2" y1="8.5" x2="22" y2="8.5" />
          <polyline points="6 8.5 12 2 18 8.5" />
          <line x1="12" y1="22" x2="12" y2="8.5" />
        </svg>
      ),
    },
    {
      title: 'Premium Quality',
      description: 'Hand-blended pot still rums matured in char-fired oak casks.',
      icon: (
        <svg
          className="w-7 h-7 text-[#dfb74a]"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
        >
          {/* Stylized Oak Barrel */}
          <ellipse cx="12" cy="4" rx="7" ry="2" />
          <path d="M5 4c-1.5 5-1.5 11 0 16" />
          <path d="M19 4c1.5 5 1.5 11 0 16" />
          <ellipse cx="12" cy="20" rx="7" ry="2" />
          <line x1="3.5" y1="9" x2="20.5" y2="9" />
          <line x1="3.5" y1="15" x2="20.5" y2="15" />
          <line x1="9" y1="4.5" x2="9" y2="19.5" />
          <line x1="15" y1="4.5" x2="15" y2="19.5" />
        </svg>
      ),
    },
    {
      title: 'Global Distribution',
      description: 'Shipped to maritime wardrooms, luxury bars, and fine cellars worldwide.',
      icon: (
        <svg
          className="w-7 h-7 text-[#dfb74a]"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
        >
          {/* Stylized Nautical Globe */}
          <circle cx="12" cy="12" r="10" />
          <line x1="2" y1="12" x2="22" y2="12" />
          <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
        </svg>
      ),
    },
  ];

  return (
    <section
      className="border-b border-[#dfb74a]/20 bg-[#060c14] dark:bg-[#060c14] light:bg-[#f5efe2] text-slate-100 dark:text-slate-100 light:text-slate-900 transition-colors"
      aria-label="Quality Pillars"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-[#dfb74a]/20">
          {pillars.map((pillar, idx) => (
            <button
              key={idx}
              onClick={() => setIsHeritageModalOpen(true)}
              className="py-6 px-4 sm:px-6 flex items-center gap-4 group text-left hover:bg-[#dfb74a]/5 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[#dfb74a]"
            >
              <div className="shrink-0 p-2 border border-[#dfb74a]/30 group-hover:border-[#dfb74a] transition-colors rounded-sm bg-[#0a1422] dark:bg-[#0a1422] light:bg-white">
                {pillar.icon}
              </div>
              <div className="space-y-0.5">
                <h2 className="font-brand text-xs sm:text-sm tracking-[0.16em] uppercase font-bold text-slate-100 dark:text-slate-100 light:text-slate-900 group-hover:text-[#dfb74a] transition-colors">
                  {pillar.title}
                </h2>
                <p className="text-[11px] text-slate-400 dark:text-slate-400 light:text-slate-600 line-clamp-2 leading-snug">
                  {pillar.description}
                </p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
