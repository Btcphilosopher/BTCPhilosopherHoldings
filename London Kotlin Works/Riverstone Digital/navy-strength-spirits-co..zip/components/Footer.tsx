'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Crown, Mail, Check, ShieldCheck, ArrowUp } from 'lucide-react';

export default function Footer() {
  const {
    openCart,
    openAuth,
    setIsHeritageModalOpen,
    setIsTradeModalOpen,
  } = useApp();

  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterSubscribed, setNewsletterSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail) {
      setNewsletterSubscribed(true);
      setNewsletterEmail('');
      setTimeout(() => setNewsletterSubscribed(false), 4000);
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#04080e] dark:bg-[#04080e] light:bg-[#ede5d5] text-slate-400 dark:text-slate-400 light:text-slate-700 border-t border-[#dfb74a]/20 transition-colors">
      {/* Top Banner: Responsible Drinking & Admiralty Dispatch */}
      <div className="border-b border-[#dfb74a]/10 py-6 px-4 sm:px-6 lg:px-8 text-center text-xs tracking-wider uppercase font-medium">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-slate-300 dark:text-slate-300 light:text-slate-800">
            <ShieldCheck className="w-4 h-4 text-[#dfb74a]" />
            <span>Age 18+ Verification Mandatory on All British Spirit Deliveries</span>
          </div>
          <div className="text-slate-400 dark:text-slate-400 light:text-slate-600 font-mono text-[11px]">
            Please Drink Responsibly · Drinkaware.co.uk
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 lg:gap-12">
          {/* Brand Column */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-2">
              <Crown className="w-6 h-6 text-[#dfb74a]" />
              <div className="font-brand text-base tracking-[0.2em] font-bold text-slate-100 dark:text-slate-100 light:text-slate-900 uppercase">
                Navy Strength Spirits Co.
              </div>
            </div>
            <p className="font-editorial text-sm italic text-[#ECC872] max-w-sm">
              Overproof. Uncompromising. British.
            </p>
            <p className="text-xs text-slate-400 dark:text-slate-400 light:text-slate-600 leading-relaxed max-w-md font-light">
              Crafted in reverence of the Royal Navy standard since 1655. We distill and bottle authentic
              overproof spirits at 57% ABV, passing the historic gunpowder test for those who demand
              genuine proof.
            </p>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-brand text-xs uppercase tracking-[0.2em] font-bold text-slate-100 dark:text-slate-100 light:text-slate-900">
              Wardroom Navigation
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a
                  href="#spirits-collection"
                  className="hover:text-[#dfb74a] transition-colors"
                >
                  Our Spirits Collection
                </a>
              </li>
              <li>
                <button
                  onClick={() => setIsHeritageModalOpen(true)}
                  className="hover:text-[#dfb74a] transition-colors text-left"
                >
                  Naval Heritage & Black Tot Day
                </button>
              </li>
              <li>
                <a
                  href="#cocktails-section"
                  className="hover:text-[#dfb74a] transition-colors"
                >
                  Wardroom Cocktail Recipes
                </a>
              </li>
              <li>
                <button
                  onClick={() => setIsTradeModalOpen(true)}
                  className="hover:text-[#dfb74a] transition-colors text-left"
                >
                  Trade & Wholesale Accounts
                </button>
              </li>
              <li>
                <button
                  onClick={openCart}
                  className="hover:text-[#dfb74a] transition-colors text-left"
                >
                  Cask Shop & Bag
                </button>
              </li>
            </ul>
          </div>

          {/* Newsletter Column */}
          <div className="lg:col-span-4 space-y-3">
            <h4 className="font-brand text-xs uppercase tracking-[0.2em] font-bold text-slate-100 dark:text-slate-100 light:text-slate-900">
              The Admiralty Gazette
            </h4>
            <p className="text-xs text-slate-400 dark:text-slate-400 light:text-slate-600 leading-relaxed font-light">
              Subscribe for private single-cask allocation notices, tasting invites, and maritime
              chronicles.
            </p>

            <form onSubmit={handleSubscribe} className="space-y-2">
              <div className="flex">
                <input
                  type="email"
                  required
                  placeholder="officer@domain.com"
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  className="flex-1 bg-[#0a1320] dark:bg-[#0a1320] light:bg-white border border-[#dfb74a]/30 px-3 py-2 text-xs text-slate-100 dark:text-slate-100 light:text-slate-900 placeholder:text-slate-500 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#dfb74a]"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#ECC872] hover:bg-[#dfb74a] text-slate-950 font-bold text-xs uppercase tracking-wider transition-colors"
                >
                  Join
                </button>
              </div>
              {newsletterSubscribed && (
                <div className="flex items-center gap-1.5 text-xs text-emerald-400">
                  <Check className="w-3.5 h-3.5" />
                  <span>Welcome aboard. Your allocation dispatch code is ADMIRAL10.</span>
                </div>
              )}
            </form>
          </div>
        </div>

        {/* Bottom Strip */}
        <div className="mt-12 pt-6 border-t border-slate-800 dark:border-slate-800 light:border-slate-300 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="text-slate-500 text-[11px]">
            © {new Date().getFullYear()} Navy Strength Spirits Co. Ltd. British Admiralty Standards.
            All rights reserved.
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => openAuth('signin')}
              className="hover:text-[#dfb74a] transition-colors"
            >
              Account Login
            </button>
            <span aria-hidden="true">·</span>
            <button
              onClick={scrollToTop}
              className="flex items-center gap-1 hover:text-[#dfb74a] transition-colors"
              aria-label="Scroll back to top"
            >
              <span>Back to Top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
