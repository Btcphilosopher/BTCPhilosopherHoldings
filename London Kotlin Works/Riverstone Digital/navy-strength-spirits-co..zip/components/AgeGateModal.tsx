'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { Crown, ShieldCheck } from 'lucide-react';

export default function AgeGateModal() {
  const { isAgeVerified, verifyAge } = useApp();

  if (isAgeVerified) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95 backdrop-blur-md animate-in fade-in duration-300"
      role="dialog"
      aria-modal="true"
      aria-labelledby="age-gate-title"
    >
      <div className="relative w-full max-w-md bg-[#0a1320] border-2 border-[#dfb74a]/60 p-8 text-center text-slate-100 shadow-2xl space-y-6">
        <div className="w-16 h-16 mx-auto rounded-full bg-[#dfb74a]/10 border border-[#dfb74a] flex items-center justify-center text-[#ECC872]">
          <Crown className="w-8 h-8" />
        </div>

        <div className="space-y-2">
          <div className="text-[11px] tracking-[0.3em] uppercase font-bold text-[#dfb74a]">
            Royal Navy Standard
          </div>
          <h2
            id="age-gate-title"
            className="font-brand text-2xl font-bold tracking-wider text-slate-50 uppercase"
          >
            Welcome to the Wardroom
          </h2>
          <p className="text-xs text-slate-300 leading-relaxed font-light">
            Navy Strength Spirits Co. produces authentic overproof British spirits. You must be of
            legal drinking age in your country to enter.
          </p>
        </div>

        <div className="p-3 bg-[#070e17] border border-slate-800 text-[11px] text-slate-400">
          Are you 18 years of age or older (21+ in the United States)?
        </div>

        <div className="flex flex-col sm:flex-row gap-3 pt-2">
          <button
            onClick={() => verifyAge(true)}
            className="flex-1 py-3 bg-[#ECC872] hover:bg-[#dfb74a] text-slate-950 font-bold text-xs uppercase tracking-widest transition-all shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a]"
          >
            Yes, I Am of Legal Age
          </button>
          <button
            onClick={() => verifyAge(false)}
            className="flex-1 py-3 border border-slate-700 hover:bg-slate-800 text-slate-400 hover:text-white text-xs uppercase tracking-widest transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-500"
          >
            No, Exit Site
          </button>
        </div>

        <div className="text-[10px] text-slate-500 uppercase tracking-wider">
          Please drink responsibly • Drinkaware.co.uk
        </div>
      </div>
    </div>
  );
}
