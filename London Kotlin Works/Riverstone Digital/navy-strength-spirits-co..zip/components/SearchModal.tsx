'use client';

import React, { useState, useEffect } from 'react';
import { useApp } from '@/context/AppContext';
import { SPIRITS_CATALOG, COCKTAIL_RECIPES, HERITAGE_TIMELINE } from '@/lib/data';
import { Search, X, Wine, GlassWater, BookOpen, ChevronRight } from 'lucide-react';

export default function SearchModal() {
  const {
    isSearchOpen,
    closeSearch,
    setSelectedSpirit,
    setActiveRecipeId,
    setIsHeritageModalOpen,
  } = useApp();

  const [query, setQuery] = useState('');

  // Keyboard shortcut Cmd+K or Ctrl+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        // Handled by context
      }
      if (e.key === 'Escape' && isSearchOpen) {
        closeSearch();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isSearchOpen, closeSearch]);

  if (!isSearchOpen) return null;

  const cleanQuery = query.toLowerCase().trim();

  const matchedSpirits = SPIRITS_CATALOG.filter(
    (s) =>
      s.name.toLowerCase().includes(cleanQuery) ||
      s.category.toLowerCase().includes(cleanQuery) ||
      s.description.toLowerCase().includes(cleanQuery) ||
      s.abv.toLowerCase().includes(cleanQuery)
  );

  const matchedCocktails = COCKTAIL_RECIPES.filter(
    (c) =>
      c.name.toLowerCase().includes(cleanQuery) ||
      c.tagline.toLowerCase().includes(cleanQuery) ||
      c.spiritBase.toLowerCase().includes(cleanQuery)
  );

  const matchedHeritage = HERITAGE_TIMELINE.filter(
    (h) =>
      h.title.toLowerCase().includes(cleanQuery) ||
      h.year.toLowerCase().includes(cleanQuery) ||
      h.description.toLowerCase().includes(cleanQuery)
  );

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center p-4 sm:p-6 md:p-20 bg-black/85 backdrop-blur-md animate-in fade-in"
      role="dialog"
      aria-modal="true"
      aria-labelledby="search-modal-title"
    >
      <div className="relative w-full max-w-2xl bg-[#0a1320] dark:bg-[#0a1320] light:bg-white border border-[#dfb74a]/40 shadow-2xl p-6 text-slate-100 dark:text-slate-100 light:text-slate-900 rounded-sm">
        {/* Search Input Bar */}
        <div className="relative flex items-center border-b border-[#dfb74a]/30 pb-4">
          <Search className="w-5 h-5 text-[#ECC872] mr-3" />
          <input
            id="search-modal-title"
            type="search"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search spirits, 57% ABV, cocktails, or naval lore..."
            className="w-full bg-transparent text-sm sm:text-base text-slate-100 dark:text-slate-100 light:text-slate-900 placeholder:text-slate-500 focus:outline-none"
          />
          <button
            onClick={closeSearch}
            className="p-1.5 text-slate-400 hover:text-white"
            aria-label="Close search"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Results */}
        <div className="mt-4 max-h-[60vh] overflow-y-auto space-y-6 pr-2">
          {/* Spirits Results */}
          {matchedSpirits.length > 0 && (
            <div>
              <div className="text-[10px] tracking-widest uppercase font-bold text-[#dfb74a] mb-2 flex items-center gap-1.5">
                <Wine className="w-3.5 h-3.5" />
                <span>Spirits & Bottlings ({matchedSpirits.length})</span>
              </div>
              <div className="space-y-1.5">
                {matchedSpirits.map((spirit) => (
                  <button
                    key={spirit.id}
                    onClick={() => {
                      setSelectedSpirit(spirit);
                      closeSearch();
                    }}
                    className="w-full p-2.5 text-left bg-[#070e17] dark:bg-[#070e17] light:bg-slate-50 hover:bg-[#dfb74a]/10 border border-slate-800 dark:border-slate-800 light:border-slate-200 transition-colors flex items-center justify-between group"
                  >
                    <div>
                      <div className="font-brand text-xs font-bold text-slate-100 dark:text-slate-100 light:text-slate-900 group-hover:text-[#dfb74a]">
                        {spirit.name}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {spirit.abv} · £{spirit.price.toFixed(2)} · {spirit.details.origin}
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-[#dfb74a] group-hover:translate-x-1 transition-transform" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Cocktails Results */}
          {matchedCocktails.length > 0 && (
            <div>
              <div className="text-[10px] tracking-widest uppercase font-bold text-[#dfb74a] mb-2 flex items-center gap-1.5">
                <GlassWater className="w-3.5 h-3.5" />
                <span>Cocktail Recipes ({matchedCocktails.length})</span>
              </div>
              <div className="space-y-1.5">
                {matchedCocktails.map((cocktail) => (
                  <button
                    key={cocktail.id}
                    onClick={() => {
                      setActiveRecipeId(cocktail.id);
                      closeSearch();
                      const el = document.getElementById('cocktails-section');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="w-full p-2.5 text-left bg-[#070e17] dark:bg-[#070e17] light:bg-slate-50 hover:bg-[#dfb74a]/10 border border-slate-800 dark:border-slate-800 light:border-slate-200 transition-colors flex items-center justify-between group"
                  >
                    <div>
                      <div className="font-brand text-xs font-bold text-slate-100 dark:text-slate-100 light:text-slate-900 group-hover:text-[#dfb74a]">
                        {cocktail.name}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Base: {cocktail.spiritBase} · Glass: {cocktail.glassware}
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-[#dfb74a] group-hover:translate-x-1 transition-transform" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Heritage Results */}
          {matchedHeritage.length > 0 && (
            <div>
              <div className="text-[10px] tracking-widest uppercase font-bold text-[#dfb74a] mb-2 flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5" />
                <span>Naval Lore & Timeline ({matchedHeritage.length})</span>
              </div>
              <div className="space-y-1.5">
                {matchedHeritage.map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setIsHeritageModalOpen(true);
                      closeSearch();
                    }}
                    className="w-full p-2.5 text-left bg-[#070e17] dark:bg-[#070e17] light:bg-slate-50 hover:bg-[#dfb74a]/10 border border-slate-800 dark:border-slate-800 light:border-slate-200 transition-colors flex items-center justify-between group"
                  >
                    <div>
                      <div className="font-mono text-[11px] text-[#dfb74a] font-bold">
                        {item.year}
                      </div>
                      <div className="font-brand text-xs font-semibold text-slate-200 dark:text-slate-200 light:text-slate-800">
                        {item.title}
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-[#dfb74a] group-hover:translate-x-1 transition-transform" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {matchedSpirits.length === 0 &&
            matchedCocktails.length === 0 &&
            matchedHeritage.length === 0 && (
              <div className="p-8 text-center text-xs text-slate-400 space-y-1">
                <p>No spirits or recipes found for &quot;{query}&quot;.</p>
                <p className="text-[11px] text-slate-500">
                  Try searching for &quot;Navy Rum&quot;, &quot;Grog&quot;, &quot;Vodka&quot;, &quot;57%&quot;, or &quot;Gunpowder&quot;.
                </p>
              </div>
            )}
        </div>
      </div>
    </div>
  );
}
