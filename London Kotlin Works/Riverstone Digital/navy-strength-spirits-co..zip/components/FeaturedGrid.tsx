'use client';

import React from 'react';
import Image from 'next/image';
import { useApp } from '@/context/AppContext';
import { Crown, ChevronRight } from 'lucide-react';

export default function FeaturedGrid() {
  const {
    openCart,
    setIsHeritageModalOpen,
    setActiveRecipeId,
  } = useApp();

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="w-full bg-[#050b12] dark:bg-[#050b12] light:bg-[#f2ece0] border-b border-[#dfb74a]/20">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-[#dfb74a]/20">
        {/* Card 1: Our Heritage */}
        <div
          onClick={() => setIsHeritageModalOpen(true)}
          className="relative aspect-[4/3] group overflow-hidden cursor-pointer focus-within:ring-2 focus-within:ring-[#dfb74a]"
          tabIndex={0}
          role="button"
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              setIsHeritageModalOpen(true);
            }
          }}
          aria-label="Learn about Our Heritage"
        >
          <Image
            src="/images/heritage_naval_officer_1793526138787.jpg"
            alt="British Naval officer in historic coat observing wooden tall ships"
            fill
            referrerPolicy="no-referrer"
            className="object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
          />
          {/* Scrim gradient for contrast */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />

          <div className="absolute inset-0 p-6 flex flex-col justify-end text-left z-10">
            <h3 className="font-brand text-base sm:text-lg font-bold tracking-[0.16em] uppercase text-white group-hover:text-[#ECC872] transition-colors">
              Our Heritage
            </h3>
            <p className="font-editorial text-sm sm:text-base text-slate-200 mt-1 line-clamp-2">
              A proud tradition since the age of sail.
            </p>
            <div className="mt-3 flex items-center gap-1 text-xs tracking-[0.18em] uppercase font-semibold text-[#ECC872] group-hover:translate-x-1 transition-transform">
              <span>Learn More</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
        </div>

        {/* Card 2: Cocktail Recipes */}
        <div
          onClick={() => {
            scrollToSection('cocktails-section');
            setActiveRecipeId('nelsons-blood');
          }}
          className="relative aspect-[4/3] group overflow-hidden cursor-pointer focus-within:ring-2 focus-within:ring-[#dfb74a]"
          tabIndex={0}
          role="button"
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              scrollToSection('cocktails-section');
            }
          }}
          aria-label="Explore Cocktail Recipes"
        >
          <Image
            src="/images/cocktail_rum_punch_1793526138875.jpg"
            alt="Dark spiced rum cocktail in cut crystal glass with orange slice"
            fill
            referrerPolicy="no-referrer"
            className="object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />

          <div className="absolute inset-0 p-6 flex flex-col justify-end text-left z-10">
            <h3 className="font-brand text-base sm:text-lg font-bold tracking-[0.16em] uppercase text-white group-hover:text-[#ECC872] transition-colors">
              Cocktail Recipes
            </h3>
            <p className="font-editorial text-sm sm:text-base text-slate-200 mt-1 line-clamp-2">
              Bold drinks for bold spirits.
            </p>
            <div className="mt-3 flex items-center gap-1 text-xs tracking-[0.18em] uppercase font-semibold text-[#ECC872] group-hover:translate-x-1 transition-transform">
              <span>Explore Recipes</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
        </div>

        {/* Card 3: Our Range */}
        <div
          onClick={() => scrollToSection('spirits-collection')}
          className="relative aspect-[4/3] group overflow-hidden cursor-pointer focus-within:ring-2 focus-within:ring-[#dfb74a]"
          tabIndex={0}
          role="button"
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              scrollToSection('spirits-collection');
            }
          }}
          aria-label="View Spirits Range"
        >
          <Image
            src="/images/spirits_range_vodka_1793526138920.jpg"
            alt="Crystal highball glass with clear overproof vodka and lime wedge on rustic wooden bar"
            fill
            referrerPolicy="no-referrer"
            className="object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />

          <div className="absolute inset-0 p-6 flex flex-col justify-end text-left z-10">
            <h3 className="font-brand text-base sm:text-lg font-bold tracking-[0.16em] uppercase text-white group-hover:text-[#ECC872] transition-colors">
              Our Range
            </h3>
            <p className="font-editorial text-sm sm:text-base text-slate-200 mt-1 line-clamp-2">
              From Navy Rum to Overproof Vodka.
            </p>
            <div className="mt-3 flex items-center gap-1 text-xs tracking-[0.18em] uppercase font-semibold text-[#ECC872] group-hover:translate-x-1 transition-transform">
              <span>View Range</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
        </div>

        {/* Card 4: Gold Foil Emblem & Shop Now Card */}
        <div
          onClick={openCart}
          className="relative aspect-[4/3] p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-transform duration-300 group focus-within:ring-2 focus-within:ring-[#996D14]"
          style={{
            background:
              'linear-gradient(135deg, #ECC872 0%, #D4AF37 35%, #C49A32 70%, #996D14 100%)',
          }}
          tabIndex={0}
          role="button"
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              openCart();
            }
          }}
          aria-label="Shop Navy Strength Spirits collection"
        >
          <div className="flex flex-col items-center space-y-3">
            <Crown className="w-10 h-10 text-slate-950/80 group-hover:scale-110 transition-transform" />
            <div>
              <span className="font-brand text-sm sm:text-base tracking-[0.24em] font-bold text-slate-950 uppercase block">
                Navy Strength
              </span>
              <span className="font-brand text-xs sm:text-sm tracking-[0.2em] font-semibold text-slate-900 uppercase block">
                Spirits Co.
              </span>
              <span className="text-[10px] tracking-[0.32em] font-bold text-slate-800 uppercase block mt-0.5">
                British
              </span>
            </div>

            <div className="pt-2">
              <span className="inline-flex items-center gap-1.5 px-6 py-2 border border-slate-950/70 hover:bg-slate-950 hover:text-[#ECC872] text-slate-950 font-bold text-xs tracking-[0.2em] uppercase transition-colors">
                <span>Shop Now</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
