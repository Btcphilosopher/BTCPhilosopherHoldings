'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useApp } from '@/context/AppContext';
import { SPIRITS_CATALOG } from '@/lib/data';
import { SpiritProduct } from '@/lib/types';
import { ShoppingBag, Eye, Check, Sparkles } from 'lucide-react';

export default function SpiritsCatalog() {
  const { addToCart, setSelectedSpirit } = useApp();
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [addedMap, setAddedMap] = useState<Record<string, boolean>>({});

  const categories = ['All', 'Rum', 'Vodka', 'Gin', 'Reserve'];

  const filteredSpirits =
    activeCategory === 'All'
      ? SPIRITS_CATALOG
      : SPIRITS_CATALOG.filter((s) => s.category === activeCategory);

  const handleAddToCart = (product: SpiritProduct) => {
    addToCart(product, 1, '70cl');
    setAddedMap((prev) => ({ ...prev, [product.id]: true }));
    setTimeout(() => {
      setAddedMap((prev) => ({ ...prev, [product.id]: false }));
    }, 1800);
  };

  return (
    <section
      id="spirits-collection"
      className="py-16 sm:py-24 bg-[#070e17] dark:bg-[#070e17] light:bg-[#fcf9f2] text-slate-100 dark:text-slate-100 light:text-slate-900 border-b border-[#dfb74a]/20"
      aria-labelledby="collection-heading"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 border-b border-slate-800 dark:border-slate-800 light:border-slate-200 pb-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs tracking-[0.24em] font-semibold text-[#ECC872] uppercase">
              <span>Distillery Collection</span>
              <span className="text-[#dfb74a]/60">•</span>
              <span>Admiralty Standard</span>
            </div>
            <h2
              id="collection-heading"
              className="font-brand text-3xl sm:text-4xl font-light tracking-[0.14em] uppercase text-slate-100 dark:text-slate-100 light:text-slate-900"
            >
              The Spirits of the Fleet
            </h2>
            <p className="font-editorial text-lg italic text-slate-300 dark:text-slate-300 light:text-slate-600 max-w-xl">
              Authentic overproof strengths, pot still complexity, and single-cask heritage bottlings.
            </p>
          </div>

          {/* Interactive Category Filter Tabs (Zero-pill discipline: functional segmented buttons) */}
          <div
            className="flex items-center gap-1 p-1 bg-[#0a1422] dark:bg-[#0a1422] light:bg-slate-200/80 border border-[#dfb74a]/30 rounded-sm self-start md:self-auto overflow-x-auto max-w-full"
            role="tablist"
            aria-label="Filter spirits by category"
          >
            {categories.map((cat) => (
              <button
                key={cat}
                role="tab"
                aria-selected={activeCategory === cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3 sm:px-4 py-1.5 text-xs font-medium tracking-wider uppercase transition-colors whitespace-nowrap shrink-0 rounded-xs focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#dfb74a] ${
                  activeCategory === cat
                    ? 'bg-[#dfb74a] text-slate-950 font-bold shadow-sm'
                    : 'text-slate-300 dark:text-slate-300 light:text-slate-700 hover:text-[#dfb74a]'
                }`}
              >
                {cat === 'All' ? 'All Spirits' : cat}
              </button>
            ))}
          </div>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredSpirits.map((spirit) => {
            const isAdded = addedMap[spirit.id];

            return (
              <article
                key={spirit.id}
                className="group relative flex flex-col justify-between bg-[#0a1320] dark:bg-[#0a1320] light:bg-white border border-[#dfb74a]/20 hover:border-[#dfb74a]/60 transition-all duration-300 shadow-lg hover:shadow-2xl"
              >
                {/* Image Showcase */}
                <div
                  onClick={() => setSelectedSpirit(spirit)}
                  className="relative aspect-[4/3] overflow-hidden cursor-pointer bg-[#04080e] dark:bg-[#04080e] light:bg-slate-100"
                >
                  <Image
                    src={spirit.image}
                    alt={spirit.name}
                    fill
                    referrerPolicy="no-referrer"
                    className="object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out"
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0a1320] dark:from-[#0a1320] light:from-white/30 via-transparent to-transparent opacity-80" />

                  {/* Clean unboxed text badge */}
                  {spirit.badge && (
                    <div className="absolute top-3 left-3 bg-[#070e17]/90 dark:bg-[#070e17]/90 light:bg-white/95 px-2.5 py-1 border border-[#dfb74a]/40 text-[10px] tracking-wider uppercase font-semibold text-[#ECC872] dark:text-[#ECC872] light:text-[#996D14]">
                      {spirit.badge}
                    </div>
                  )}

                  {/* Quick Inspect Hover Icon */}
                  <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
                    <span className="p-2 bg-[#070e17]/90 text-[#dfb74a] border border-[#dfb74a]/40 rounded-full flex items-center justify-center">
                      <Eye className="w-4 h-4" />
                    </span>
                  </div>
                </div>

                {/* Content Section */}
                <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    {/* Clean unboxed metadata with separators */}
                    <div className="flex items-center gap-2 text-xs text-slate-400 dark:text-slate-400 light:text-slate-500">
                      <span className="text-[#dfb74a] font-semibold">{spirit.abv}</span>
                      <span aria-hidden="true">·</span>
                      <span>{spirit.details.origin.split(',')[0]}</span>
                      <span aria-hidden="true">·</span>
                      <span>{spirit.volume}</span>
                    </div>

                    <h3
                      onClick={() => setSelectedSpirit(spirit)}
                      className="font-brand text-lg font-semibold tracking-wider text-slate-100 dark:text-slate-100 light:text-slate-900 group-hover:text-[#dfb74a] transition-colors cursor-pointer"
                    >
                      {spirit.name}
                    </h3>

                    <p className="text-xs text-slate-300 dark:text-slate-300 light:text-slate-600 line-clamp-2 leading-relaxed">
                      {spirit.description}
                    </p>
                  </div>

                  {/* Tasting notes highlights */}
                  <div className="pt-2 border-t border-slate-800/80 dark:border-slate-800/80 light:border-slate-200 text-[11px] text-slate-400 dark:text-slate-400 light:text-slate-500 space-y-1">
                    <div className="flex gap-1.5">
                      <span className="text-[#dfb74a] font-medium shrink-0">Palate:</span>
                      <span className="italic line-clamp-1">{spirit.tastingNotes.palate}</span>
                    </div>
                  </div>

                  {/* Price & Actions Row */}
                  <div className="pt-4 flex items-center justify-between border-t border-[#dfb74a]/20">
                    <div>
                      <span className="text-[10px] tracking-widest uppercase text-slate-400 dark:text-slate-400 light:text-slate-500 block">
                        Bottle Price
                      </span>
                      <span className="font-mono text-xl font-bold text-slate-50 dark:text-slate-50 light:text-slate-950 tabular-nums">
                        £{spirit.price.toFixed(2)}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setSelectedSpirit(spirit)}
                        className="px-3 py-2 text-xs tracking-wider uppercase font-medium text-slate-300 dark:text-slate-300 light:text-slate-700 hover:text-[#dfb74a] transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#dfb74a]"
                        aria-label={`View tasting notes for ${spirit.name}`}
                      >
                        Notes
                      </button>

                      <button
                        onClick={() => handleAddToCart(spirit)}
                        className={`inline-flex items-center gap-1.5 px-4 py-2 text-xs tracking-wider uppercase font-bold transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a] ${
                          isAdded
                            ? 'bg-emerald-600 text-white'
                            : 'bg-[#ECC872] hover:bg-[#dfb74a] text-slate-950 shadow'
                        }`}
                        aria-label={`Add ${spirit.name} to cart for £${spirit.price.toFixed(2)}`}
                      >
                        {isAdded ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>Added</span>
                          </>
                        ) : (
                          <>
                            <ShoppingBag className="w-3.5 h-3.5" />
                            <span>Add</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
