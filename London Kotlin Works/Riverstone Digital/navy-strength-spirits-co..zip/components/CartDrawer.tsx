'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useApp } from '@/context/AppContext';
import {
  X,
  Trash2,
  Plus,
  Minus,
  ShoppingBag,
  ArrowRight,
  ShieldCheck,
  CheckCircle,
  Truck,
  Tag,
} from 'lucide-react';
import { OrderRecord } from '@/lib/types';

export default function CartDrawer() {
  const {
    cart,
    isCartOpen,
    closeCart,
    removeFromCart,
    updateQuantity,
    subtotal,
    shipping,
    discountAmount,
    total,
    promoCode,
    applyPromo,
    freeShippingThreshold,
    placeOrder,
  } = useApp();

  const [promoInput, setPromoInput] = useState('');
  const [promoFeedback, setPromoFeedback] = useState<{ success: boolean; message: string } | null>(
    null
  );

  // Checkout modal view state
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [confirmedOrder, setConfirmedOrder] = useState<OrderRecord | null>(null);

  // Checkout form
  const [buyerName, setBuyerName] = useState('Alexander Wright');
  const [buyerAddress, setBuyerAddress] = useState('Admiralty Arch, The Mall');
  const [buyerCity, setBuyerCity] = useState('London');
  const [buyerPostal, setBuyerPostal] = useState('SW1A 2WH');
  const [isProcessingOrder, setIsProcessingOrder] = useState(false);

  if (!isCartOpen) return null;

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoInput) return;
    const res = applyPromo(promoInput);
    setPromoFeedback(res);
  };

  const handleCompletePurchase = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessingOrder(true);
    setTimeout(() => {
      const order = placeOrder({
        name: buyerName,
        address: buyerAddress,
        city: buyerCity,
        postalCode: buyerPostal,
      });
      setConfirmedOrder(order);
      setIsProcessingOrder(false);
    }, 600);
  };

  const remainingForFreeShipping = Math.max(0, freeShippingThreshold - subtotal);
  const shippingProgress = Math.min(100, (subtotal / freeShippingThreshold) * 100);

  return (
    <div
      className="fixed inset-0 z-50 overflow-hidden bg-black/75 backdrop-blur-sm animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="cart-title"
    >
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#0a1320] dark:bg-[#0a1320] light:bg-white text-slate-100 dark:text-slate-100 light:text-slate-900 border-l border-[#dfb74a]/40 shadow-2xl flex flex-col justify-between">
          {/* Header */}
          <div className="p-6 border-b border-[#dfb74a]/20 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#ECC872]" />
              <h2
                id="cart-title"
                className="font-brand text-lg font-bold tracking-wider uppercase text-slate-100 dark:text-slate-100 light:text-slate-900"
              >
                Wardroom Cask Cart
              </h2>
            </div>
            <button
              onClick={closeCart}
              className="p-2 text-slate-400 hover:text-white transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a]"
              aria-label="Close cart"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Complimentary Shipping Progress */}
          <div className="px-6 py-3 bg-[#070e17] dark:bg-[#070e17] light:bg-slate-100 border-b border-slate-800 dark:border-slate-800 light:border-slate-200 text-xs">
            <div className="flex items-center justify-between mb-1.5 font-medium">
              <span className="flex items-center gap-1.5 text-slate-300 dark:text-slate-300 light:text-slate-700">
                <Truck className="w-4 h-4 text-[#dfb74a]" />
                {remainingForFreeShipping === 0
                  ? 'Complimentary Admiralty Shipping Unlocked!'
                  : `Add £${remainingForFreeShipping.toFixed(2)} more for Free UK Delivery`}
              </span>
              <span className="font-mono text-[#dfb74a]">
                {Math.round(shippingProgress)}%
              </span>
            </div>
            <div className="w-full h-1.5 bg-slate-800 dark:bg-slate-800 light:bg-slate-300 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-[#ECC872] to-[#dfb74a] transition-all duration-300"
                style={{ width: `${shippingProgress}%` }}
              />
            </div>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-3 py-16">
                <ShoppingBag className="w-12 h-12 text-slate-600" />
                <h3 className="font-brand text-base font-bold text-slate-300">
                  Your Cask Cart is Empty
                </h3>
                <p className="text-xs text-slate-400 max-w-xs">
                  Discover our flagship 57% ABV British Navy Rum or overproof vodkas to begin your
                  order.
                </p>
                <button
                  onClick={closeCart}
                  className="px-6 py-2.5 bg-[#ECC872] text-slate-950 font-bold text-xs uppercase tracking-wider hover:bg-[#dfb74a] transition-colors"
                >
                  Explore Collection
                </button>
              </div>
            ) : (
              cart.map((item) => (
                <div
                  key={`${item.product.id}-${item.selectedSize}`}
                  className="p-4 bg-[#070e17]/80 dark:bg-[#070e17]/80 light:bg-slate-50 border border-slate-800 dark:border-slate-800 light:border-slate-200 flex gap-4 relative group"
                >
                  {/* Thumbnail */}
                  <div className="relative w-20 h-20 bg-slate-950 shrink-0 border border-slate-700 overflow-hidden">
                    <Image
                      src={item.product.image}
                      alt={item.product.name}
                      fill
                      referrerPolicy="no-referrer"
                      className="object-cover"
                    />
                  </div>

                  {/* Details */}
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-start">
                        <h4 className="font-brand text-xs sm:text-sm font-bold text-slate-100 dark:text-slate-100 light:text-slate-900 line-clamp-1">
                          {item.product.name}
                        </h4>
                        <button
                          onClick={() => removeFromCart(item.product.id, item.selectedSize)}
                          className="text-slate-500 hover:text-rose-400 p-1"
                          aria-label={`Remove ${item.product.name} from cart`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="text-[11px] text-slate-400 flex items-center gap-2 mt-0.5">
                        <span className="text-[#dfb74a] font-semibold">{item.product.abv}</span>
                        <span>•</span>
                        <span>{item.selectedSize} Bottle</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2">
                      {/* Quantity Stepper */}
                      <div className="flex items-center border border-slate-700 dark:border-slate-700 light:border-slate-300 bg-[#0a1422] dark:bg-[#0a1422] light:bg-white">
                        <button
                          onClick={() => updateQuantity(item.product.id, item.selectedSize, -1)}
                          className="px-2 py-1 text-slate-400 hover:text-white"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="px-2 font-mono text-xs font-semibold tabular-nums">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.product.id, item.selectedSize, 1)}
                          className="px-2 py-1 text-slate-400 hover:text-white"
                          aria-label="Increase quantity"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      <div className="font-mono text-sm font-bold tabular-nums text-slate-100 dark:text-slate-100 light:text-slate-900">
                        £{(item.product.price * item.quantity).toFixed(2)}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer & Totals */}
          {cart.length > 0 && (
            <div className="p-6 border-t border-[#dfb74a]/20 bg-[#070e17] dark:bg-[#070e17] light:bg-slate-50 space-y-4">
              {/* Promo code form */}
              <form onSubmit={handleApplyPromo} className="flex gap-2">
                <input
                  type="text"
                  placeholder="Promo Code (try ADMIRAL10)"
                  value={promoInput}
                  onChange={(e) => setPromoInput(e.target.value)}
                  className="flex-1 bg-[#0a1320] dark:bg-[#0a1320] light:bg-white border border-slate-700 px-3 py-2 text-xs uppercase tracking-wider text-slate-100 dark:text-slate-100 light:text-slate-900 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#dfb74a]"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-slate-800 dark:bg-slate-800 light:bg-slate-200 text-xs uppercase font-semibold text-slate-200 dark:text-slate-200 light:text-slate-800 hover:text-[#dfb74a]"
                >
                  Apply
                </button>
              </form>
              {promoFeedback && (
                <div
                  className={`text-xs ${
                    promoFeedback.success ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {promoFeedback.message}
                </div>
              )}

              {/* Price Breakdown */}
              <div className="space-y-1.5 text-xs text-slate-300 dark:text-slate-300 light:text-slate-700">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-mono tabular-nums">£{subtotal.toFixed(2)}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-400">
                    <span>Admiralty Discount ({promoCode})</span>
                    <span className="font-mono tabular-nums">-£{discountAmount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>UK Royal Delivery</span>
                  <span className="font-mono tabular-nums">
                    {shipping === 0 ? 'COMPLIMENTARY' : `£${shipping.toFixed(2)}`}
                  </span>
                </div>
                <div className="pt-2 border-t border-slate-800 dark:border-slate-800 light:border-slate-300 flex justify-between text-base font-bold text-slate-100 dark:text-slate-100 light:text-slate-900">
                  <span className="font-brand uppercase tracking-wider">Total</span>
                  <span className="font-mono text-lg text-[#ECC872] tabular-nums">
                    £{total.toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Checkout CTA */}
              <button
                onClick={() => setIsCheckoutOpen(true)}
                className="w-full py-3.5 bg-[#ECC872] hover:bg-[#dfb74a] text-slate-950 font-bold text-xs uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-2 shadow-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a]"
              >
                <span>Proceed to Wardroom Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Checkout & Order Confirmation Modal */}
      {isCheckoutOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in"
          role="dialog"
          aria-modal="true"
        >
          <div className="relative w-full max-w-lg bg-[#0a1320] dark:bg-[#0a1320] light:bg-white border border-[#dfb74a]/40 p-6 sm:p-8 text-slate-100 dark:text-slate-100 light:text-slate-900">
            <button
              onClick={() => {
                setIsCheckoutOpen(false);
                setConfirmedOrder(null);
              }}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            {confirmedOrder ? (
              <div className="text-center space-y-4 py-4">
                <div className="w-16 h-16 mx-auto rounded-full bg-emerald-500/20 border border-emerald-400 flex items-center justify-center text-emerald-400">
                  <CheckCircle className="w-10 h-10" />
                </div>
                <div className="space-y-1">
                  <div className="text-xs uppercase tracking-widest text-[#dfb74a] font-bold">
                    Order Dispatch Confirmed
                  </div>
                  <h3 className="font-brand text-2xl font-bold">
                    Order #{confirmedOrder.id}
                  </h3>
                  <p className="text-xs text-slate-400">
                    A copy of your Admiralty manifest has been transmitted to your email.
                  </p>
                </div>

                <div className="p-4 bg-[#070e17] dark:bg-[#070e17] light:bg-slate-50 border border-slate-800 text-left text-xs space-y-2">
                  <div className="flex justify-between font-semibold border-b border-slate-800 pb-1">
                    <span>Tracking Number:</span>
                    <span className="font-mono text-[#dfb74a]">
                      {confirmedOrder.trackingNumber}
                    </span>
                  </div>
                  <div className="space-y-1">
                    {confirmedOrder.items.map((it, idx) => (
                      <div key={idx} className="flex justify-between text-slate-300">
                        <span>
                          {it.quantity}x {it.name}
                        </span>
                        <span className="font-mono">
                          £{(it.price * it.quantity).toFixed(2)}
                        </span>
                      </div>
                    ))}
                  </div>
                  <div className="border-t border-slate-800 pt-2 flex justify-between font-bold text-sm">
                    <span>Total Paid:</span>
                    <span className="font-mono text-[#ECC872]">
                      £{confirmedOrder.total.toFixed(2)}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setIsCheckoutOpen(false);
                    setConfirmedOrder(null);
                    closeCart();
                  }}
                  className="w-full py-3 bg-[#ECC872] hover:bg-[#dfb74a] text-slate-950 font-bold text-xs uppercase tracking-widest"
                >
                  Return to Storefront
                </button>
              </div>
            ) : (
              <form onSubmit={handleCompletePurchase} className="space-y-4">
                <div className="space-y-1 border-b border-[#dfb74a]/20 pb-3">
                  <h3 className="font-brand text-xl font-bold">
                    Wardroom Express Checkout
                  </h3>
                  <p className="text-xs text-slate-400">
                    Fast, secure checkout. Age 18+ signature required on delivery.
                  </p>
                </div>

                <div className="space-y-3 text-xs text-left">
                  <div>
                    <label className="block uppercase tracking-wider font-semibold text-slate-300 mb-1">
                      Recipient Officer Name
                    </label>
                    <input
                      type="text"
                      required
                      value={buyerName}
                      onChange={(e) => setBuyerName(e.target.value)}
                      className="w-full bg-[#070e17] dark:bg-[#070e17] light:bg-slate-50 border border-slate-700 p-2 text-slate-100 dark:text-slate-100 light:text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block uppercase tracking-wider font-semibold text-slate-300 mb-1">
                      Delivery Address
                    </label>
                    <input
                      type="text"
                      required
                      value={buyerAddress}
                      onChange={(e) => setBuyerAddress(e.target.value)}
                      className="w-full bg-[#070e17] dark:bg-[#070e17] light:bg-slate-50 border border-slate-700 p-2 text-slate-100 dark:text-slate-100 light:text-slate-900"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block uppercase tracking-wider font-semibold text-slate-300 mb-1">
                        City / Port
                      </label>
                      <input
                        type="text"
                        required
                        value={buyerCity}
                        onChange={(e) => setBuyerCity(e.target.value)}
                        className="w-full bg-[#070e17] dark:bg-[#070e17] light:bg-slate-50 border border-slate-700 p-2 text-slate-100 dark:text-slate-100 light:text-slate-900"
                      />
                    </div>
                    <div>
                      <label className="block uppercase tracking-wider font-semibold text-slate-300 mb-1">
                        Postal Code
                      </label>
                      <input
                        type="text"
                        required
                        value={buyerPostal}
                        onChange={(e) => setBuyerPostal(e.target.value)}
                        className="w-full bg-[#070e17] dark:bg-[#070e17] light:bg-slate-50 border border-slate-700 p-2 text-slate-100 dark:text-slate-100 light:text-slate-900"
                      />
                    </div>
                  </div>

                  <div className="p-3 bg-[#070e17] border border-slate-800 space-y-1">
                    <div className="flex justify-between font-bold">
                      <span>Order Total to Authorize:</span>
                      <span className="font-mono text-[#ECC872] text-sm">
                        £{total.toFixed(2)}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-400 block">
                      Encrypted Royal Cask payment processor. Zero latency instant authorization.
                    </span>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isProcessingOrder}
                  className="w-full py-3 bg-[#ECC872] hover:bg-[#dfb74a] text-slate-950 font-bold text-xs uppercase tracking-widest transition-colors shadow-lg"
                >
                  {isProcessingOrder ? 'Authorizing Dispatch...' : `Authorize & Pay £${total.toFixed(2)}`}
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
