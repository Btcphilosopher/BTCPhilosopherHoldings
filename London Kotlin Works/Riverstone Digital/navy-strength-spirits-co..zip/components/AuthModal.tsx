'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import {
  X,
  User,
  Mail,
  Lock,
  ShieldCheck,
  LogOut,
  Package,
  Award,
  CheckCircle2,
  AlertCircle,
  Sparkles,
} from 'lucide-react';

export default function AuthModal() {
  const {
    isAuthOpen,
    closeAuth,
    authView,
    openAuth,
    user,
    orders,
    loginWithEmail,
    registerWithEmail,
    loginWithSocial,
    logout,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'signin' | 'register'>(
    authView === 'register' ? 'register' : 'signin'
  );

  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [isAgeConfirmed, setIsAgeConfirmed] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isAuthOpen) return null;

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setIsSubmitting(true);

    try {
      if (activeTab === 'signin') {
        const res = await loginWithEmail(email, password);
        if (!res.success) {
          setErrorMessage(res.error || 'Authentication failed');
        }
      } else {
        if (!isAgeConfirmed) {
          setErrorMessage('You must confirm you are of legal drinking age (18+).');
          setIsSubmitting(false);
          return;
        }
        const res = await registerWithEmail(fullName, email, password);
        if (!res.success) {
          setErrorMessage(res.error || 'Registration failed');
        }
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSocialClick = async (provider: 'google' | 'apple' | 'github') => {
    setIsSubmitting(true);
    setErrorMessage(null);
    try {
      await loginWithSocial(provider);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
      onKeyDown={(e) => e.key === 'Escape' && closeAuth()}
    >
      <div className="relative w-full max-w-md bg-[#0a1320] dark:bg-[#0a1320] light:bg-white border border-[#dfb74a]/40 shadow-2xl p-6 sm:p-8 text-slate-100 dark:text-slate-100 light:text-slate-900 overflow-hidden">
        {/* Close Button */}
        <button
          onClick={closeAuth}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-100 dark:hover:text-slate-100 light:hover:text-slate-900 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a]"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        {/* If user is already logged in, show User Profile */}
        {user ? (
          <div className="space-y-6">
            <div className="flex items-center gap-4 border-b border-[#dfb74a]/20 pb-5">
              <div className="w-14 h-14 rounded-full bg-[#dfb74a]/20 border-2 border-[#dfb74a] flex items-center justify-center text-[#ECC872] font-brand font-bold text-xl shrink-0">
                {user.name.charAt(0)}
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h3
                    id="auth-modal-title"
                    className="font-brand text-lg font-bold text-slate-100 dark:text-slate-100 light:text-slate-900"
                  >
                    {user.name}
                  </h3>
                  <Award className="w-4 h-4 text-[#dfb74a]" />
                </div>
                <p className="text-xs text-slate-400 dark:text-slate-400 light:text-slate-600 font-mono">
                  {user.email}
                </p>
                <div className="flex items-center gap-2 text-[10px] text-[#ECC872] font-semibold uppercase tracking-wider">
                  <span>{user.membershipTier}</span>
                  <span>•</span>
                  <span>{user.joinedDate}</span>
                </div>
              </div>
            </div>

            {/* Orders Summary */}
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs tracking-wider uppercase font-bold text-slate-300 dark:text-slate-300 light:text-slate-700">
                <span className="flex items-center gap-1.5">
                  <Package className="w-4 h-4 text-[#dfb74a]" />
                  <span>Wardroom Orders ({orders.length})</span>
                </span>
              </div>

              {orders.length === 0 ? (
                <div className="p-4 bg-[#070e17] dark:bg-[#070e17] light:bg-slate-50 border border-slate-800 dark:border-slate-800 light:border-slate-200 text-center text-xs text-slate-400">
                  No orders yet. Discover our British Navy Rum above.
                </div>
              ) : (
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {orders.map((ord) => (
                    <div
                      key={ord.id}
                      className="p-3 bg-[#070e17] dark:bg-[#070e17] light:bg-slate-50 border border-slate-800 dark:border-slate-800 light:border-slate-200 text-xs flex justify-between items-center"
                    >
                      <div>
                        <div className="font-mono text-[#dfb74a] font-semibold">{ord.id}</div>
                        <div className="text-[11px] text-slate-400">{ord.date}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-mono font-bold">£{ord.total.toFixed(2)}</div>
                        <span className="text-[10px] text-emerald-400 font-medium">
                          {ord.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="pt-2 border-t border-[#dfb74a]/20 flex items-center justify-between">
              <button
                onClick={logout}
                className="inline-flex items-center gap-2 px-4 py-2 border border-rose-500/40 text-rose-400 hover:bg-rose-500/10 text-xs uppercase tracking-wider font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>

              <button
                onClick={closeAuth}
                className="px-5 py-2 bg-[#ECC872] hover:bg-[#dfb74a] text-slate-950 font-bold text-xs uppercase tracking-wider transition-colors"
              >
                Done
              </button>
            </div>
          </div>
        ) : (
          /* Sign In / Register Tabs */
          <div className="space-y-6">
            <div className="text-center space-y-1">
              <div className="font-brand text-xs tracking-[0.24em] font-bold text-[#dfb74a] uppercase">
                Admiralty Wardroom
              </div>
              <h3
                id="auth-modal-title"
                className="font-brand text-xl font-bold tracking-wide text-slate-100 dark:text-slate-100 light:text-slate-900"
              >
                {activeTab === 'signin' ? 'Sign In to Your Account' : 'Join the Admiralty Club'}
              </h3>
              <p className="text-xs text-slate-400 dark:text-slate-400 light:text-slate-600">
                {activeTab === 'signin'
                  ? 'Access exclusive single cask allocations and member reserves.'
                  : 'Receive complimentary gift wrapping and allocation previews.'}
              </p>
            </div>

            {/* Fast Social Logins with low latency */}
            <div className="space-y-2.5">
              <button
                type="button"
                onClick={() => handleSocialClick('google')}
                disabled={isSubmitting}
                className="w-full py-2.5 px-4 bg-[#070e17] dark:bg-[#070e17] light:bg-slate-100 hover:bg-slate-800 dark:hover:bg-slate-800 light:hover:bg-slate-200 border border-slate-700 dark:border-slate-700 light:border-slate-300 transition-colors flex items-center justify-center gap-3 text-xs font-semibold tracking-wide text-slate-200 dark:text-slate-200 light:text-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a]"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.66v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.15z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.26v3.15C3.25 21.36 7.35 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.26C.46 8.16 0 9.94 0 12s.46 3.84 1.26 5.42l4.02-3.15z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.35 0 3.25 2.64 1.26 6.58l4.02 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                  />
                </svg>
                <span>Continue with Google</span>
              </button>

              <button
                type="button"
                onClick={() => handleSocialClick('apple')}
                disabled={isSubmitting}
                className="w-full py-2.5 px-4 bg-[#070e17] dark:bg-[#070e17] light:bg-slate-100 hover:bg-slate-800 dark:hover:bg-slate-800 light:hover:bg-slate-200 border border-slate-700 dark:border-slate-700 light:border-slate-300 transition-colors flex items-center justify-center gap-3 text-xs font-semibold tracking-wide text-slate-200 dark:text-slate-200 light:text-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a]"
              >
                <svg className="w-4 h-4 fill-current" viewBox="0 0 170 170">
                  <path d="M150.37 130.25c-2.45 5.66-5.35 10.87-8.71 15.66-4.58 6.53-8.33 11.05-11.22 13.56-4.48 4.12-9.28 6.23-14.42 6.35-3.69 0-8.14-1.05-13.32-3.18-5.19-2.12-9.97-3.17-14.34-3.17-4.58 0-9.49 1.05-14.75 3.17-5.26 2.13-9.5 3.24-12.74 3.35-4.35.13-9.16-1.9-14.42-6.08-3.69-3.08-7.58-7.85-11.68-14.32-6.52-10.28-11.46-21.67-14.81-34.17-3.35-12.5-5.03-24.3-5.03-35.4 0-14.07 3.51-26.04 10.53-35.91 7.02-9.87 16.03-14.86 27.04-14.98 5.48 0 11.23 1.34 17.26 4.02 6.03 2.68 9.94 4.08 11.73 4.2 1.57-.24 5.49-1.63 11.76-4.17 6.27-2.54 11.96-3.71 17.07-3.52 13.06.84 23.36 5.86 30.91 15.06-11.44 6.89-17.03 16.48-16.77 28.77.26 9.8 4.07 18 11.44 24.6 7.37 6.6 16.14 10.32 26.31 11.16-2.22 6.88-5.05 13.91-8.5 21.08zM119.22 33.15c0-7.05 2.59-13.68 7.77-19.89 5.18-6.21 11.44-10.02 18.78-11.44.22 1.35.33 2.59.33 3.73 0 7.05-2.67 13.88-8.01 20.49-5.34 6.61-11.74 10.45-19.2 11.53-.22-.96-.33-2.13-.33-3.51z" />
                </svg>
                <span>Continue with Apple</span>
              </button>

              <button
                type="button"
                onClick={() => handleSocialClick('github')}
                disabled={isSubmitting}
                className="w-full py-2.5 px-4 bg-[#070e17] dark:bg-[#070e17] light:bg-slate-100 hover:bg-slate-800 dark:hover:bg-slate-800 light:hover:bg-slate-200 border border-slate-700 dark:border-slate-700 light:border-slate-300 transition-colors flex items-center justify-center gap-3 text-xs font-semibold tracking-wide text-slate-200 dark:text-slate-200 light:text-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a]"
              >
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z" />
                </svg>
                <span>Continue with GitHub</span>
              </button>
            </div>

            {/* Separator */}
            <div className="relative flex items-center justify-center">
              <div className="w-full border-t border-slate-700/60 dark:border-slate-700/60 light:border-slate-300"></div>
              <span className="absolute px-3 bg-[#0a1320] dark:bg-[#0a1320] light:bg-white text-[11px] tracking-widest uppercase text-slate-400">
                Or With Email
              </span>
            </div>

            {/* Segmented Tab Selector */}
            <div className="flex border border-slate-800 dark:border-slate-800 light:border-slate-300 p-0.5 bg-[#070e17] dark:bg-[#070e17] light:bg-slate-100">
              <button
                type="button"
                onClick={() => {
                  setActiveTab('signin');
                  setErrorMessage(null);
                }}
                className={`flex-1 py-1.5 text-xs font-semibold uppercase tracking-wider transition-colors ${
                  activeTab === 'signin'
                    ? 'bg-[#ECC872] text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-slate-100 dark:hover:text-slate-100 light:hover:text-slate-900'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveTab('register');
                  setErrorMessage(null);
                }}
                className={`flex-1 py-1.5 text-xs font-semibold uppercase tracking-wider transition-colors ${
                  activeTab === 'register'
                    ? 'bg-[#ECC872] text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-slate-100 dark:hover:text-slate-100 light:hover:text-slate-900'
                }`}
              >
                Register
              </button>
            </div>

            {/* Error banner */}
            {errorMessage && (
              <div
                className="p-3 bg-rose-950/60 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2"
                role="alert"
              >
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleEmailSubmit} className="space-y-4">
              {activeTab === 'register' && (
                <div className="space-y-1 text-left">
                  <label
                    htmlFor="reg-name"
                    className="block text-xs uppercase tracking-wider text-slate-300 dark:text-slate-300 light:text-slate-700 font-medium"
                  >
                    Full Name
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                    <input
                      id="reg-name"
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="e.g. Commander Arthur Pendelton"
                      className="w-full bg-[#070e17] dark:bg-[#070e17] light:bg-slate-50 border border-slate-700 dark:border-slate-700 light:border-slate-300 pl-10 pr-4 py-2.5 text-xs text-slate-100 dark:text-slate-100 light:text-slate-900 placeholder:text-slate-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a]"
                    />
                  </div>
                </div>
              )}

              <div className="space-y-1 text-left">
                <label
                  htmlFor="auth-email"
                  className="block text-xs uppercase tracking-wider text-slate-300 dark:text-slate-300 light:text-slate-700 font-medium"
                >
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                  <input
                    id="auth-email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="officer@royaladmiralty.navy"
                    className="w-full bg-[#070e17] dark:bg-[#070e17] light:bg-slate-50 border border-slate-700 dark:border-slate-700 light:border-slate-300 pl-10 pr-4 py-2.5 text-xs text-slate-100 dark:text-slate-100 light:text-slate-900 placeholder:text-slate-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a]"
                  />
                </div>
              </div>

              <div className="space-y-1 text-left">
                <label
                  htmlFor="auth-pass"
                  className="block text-xs uppercase tracking-wider text-slate-300 dark:text-slate-300 light:text-slate-700 font-medium"
                >
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                  <input
                    id="auth-pass"
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-[#070e17] dark:bg-[#070e17] light:bg-slate-50 border border-slate-700 dark:border-slate-700 light:border-slate-300 pl-10 pr-4 py-2.5 text-xs text-slate-100 dark:text-slate-100 light:text-slate-900 placeholder:text-slate-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a]"
                  />
                </div>
              </div>

              {activeTab === 'register' && (
                <div className="flex items-start gap-2 pt-1 text-left">
                  <input
                    id="reg-age"
                    type="checkbox"
                    checked={isAgeConfirmed}
                    onChange={(e) => setIsAgeConfirmed(e.target.checked)}
                    className="mt-0.5 accent-[#ECC872] cursor-pointer"
                  />
                  <label htmlFor="reg-age" className="text-[11px] text-slate-300 dark:text-slate-300 light:text-slate-700">
                    I confirm that I am at least 18 years of age (or legal drinking age in my
                    jurisdiction).
                  </label>
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 bg-[#ECC872] hover:bg-[#dfb74a] text-slate-950 font-bold text-xs tracking-widest uppercase transition-all shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a]"
              >
                {isSubmitting
                  ? 'Verifying Credentials...'
                  : activeTab === 'signin'
                  ? 'Sign In'
                  : 'Create Admiralty Account'}
              </button>
            </form>

            {/* Quick Demo Access */}
            <div className="pt-2 border-t border-slate-800 dark:border-slate-800 light:border-slate-200 text-center">
              <span className="text-[11px] text-slate-400 block mb-2">
                Quick Test Credentials:
              </span>
              <div className="flex gap-2 justify-center">
                <button
                  type="button"
                  onClick={() => {
                    setEmail('admiral@ahyx.org');
                    setPassword('royalrum57');
                  }}
                  className="px-2 py-1 text-[10px] bg-slate-800 dark:bg-slate-800 light:bg-slate-200 text-slate-300 dark:text-slate-300 light:text-slate-800 rounded hover:text-[#dfb74a]"
                >
                  Fill Admiral Login
                </button>
                <button
                  type="button"
                  onClick={() => {
                    handleSocialClick('google');
                  }}
                  className="px-2 py-1 text-[10px] bg-[#dfb74a]/20 text-[#dfb74a] rounded hover:bg-[#dfb74a]/30"
                >
                  One-Click Officer Login
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
