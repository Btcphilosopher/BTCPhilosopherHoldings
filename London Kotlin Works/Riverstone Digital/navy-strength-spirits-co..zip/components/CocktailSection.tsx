'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useApp } from '@/context/AppContext';
import { COCKTAIL_RECIPES, SPIRITS_CATALOG } from '@/lib/data';
import { Check, Plus, ChefHat } from 'lucide-react';

export default function CocktailSection() {
  const { activeRecipeId, setActiveRecipeId, addToCart } = useApp();
  const selectedRecipe =
    COCKTAIL_RECIPES.find((r) => r.id === activeRecipeId) || COCKTAIL_RECIPES[0];

  const [useImperial, setUseImperial] = useState<boolean>(false);
  const [checkedIngredients, setCheckedIngredients] = useState<Record<string, boolean>>({});

  const toggleIngredientCheck = (idx: number) => {
    setCheckedIngredients((prev) => ({
      ...prev,
      [`${selectedRecipe.id}-${idx}`]: !prev[`${selectedRecipe.id}-${idx}`],
    }));
  };

  const handleOrderSpirit = () => {
    const spirit =
      SPIRITS_CATALOG.find((s) =>
        selectedRecipe.spiritBase.toLowerCase().includes(s.category.toLowerCase())
      ) || SPIRITS_CATALOG[0];
    addToCart(spirit, 1, '70cl');
  };

  return (
    <section
      id="cocktails-section"
      className="py-16 sm:py-24 bg-[#050b12] dark:bg-[#050b12] light:bg-[#f6f0e4] text-slate-100 dark:text-slate-100 light:text-slate-900 border-b border-[#dfb74a]/20"
      aria-labelledby="cocktail-heading"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-3">
          <div className="flex items-center justify-center gap-2 text-xs tracking-[0.24em] font-semibold text-[#ECC872] uppercase">
            <span>Wardroom Mixology</span>
            <span className="text-[#dfb74a]/60">•</span>
            <span>Overproof Recipes</span>
          </div>
          <h2
            id="cocktail-heading"
            className="font-brand text-3xl sm:text-4xl font-light tracking-[0.14em] uppercase text-slate-100 dark:text-slate-100 light:text-slate-900"
          >
            Cocktails for Bold Spirits
          </h2>
          <p className="font-editorial text-lg italic text-slate-300 dark:text-slate-300 light:text-slate-600">
            Historic Admiralty grogs, elevated punches, and maritime libations crafted to showcase
            57% ABV depth.
          </p>
        </div>

        {/* Recipe Selector Navigation */}
        <div className="flex justify-center mb-10 overflow-x-auto pb-2">
          <div
            className="flex items-center gap-2 p-1.5 bg-[#0a1422] dark:bg-[#0a1422] light:bg-slate-200/90 border border-[#dfb74a]/30 rounded-sm"
            role="tablist"
            aria-label="Select cocktail recipe"
          >
            {COCKTAIL_RECIPES.map((recipe) => (
              <button
                key={recipe.id}
                role="tab"
                aria-selected={selectedRecipe.id === recipe.id}
                onClick={() => setActiveRecipeId(recipe.id)}
                className={`px-3 sm:px-5 py-2 text-xs tracking-wider uppercase font-semibold transition-all whitespace-nowrap rounded-xs focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#dfb74a] ${
                  selectedRecipe.id === recipe.id
                    ? 'bg-[#ECC872] text-slate-950 shadow-md'
                    : 'text-slate-300 dark:text-slate-300 light:text-slate-700 hover:text-[#dfb74a]'
                }`}
              >
                {recipe.name}
              </button>
            ))}
          </div>
        </div>

        {/* Active Cocktail Showcase */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch bg-[#0a1320] dark:bg-[#0a1320] light:bg-white border border-[#dfb74a]/30 shadow-2xl overflow-hidden">
          {/* Left Column: Photography */}
          <div className="lg:col-span-5 relative min-h-[320px] lg:min-h-[500px]">
            <Image
              src={selectedRecipe.image}
              alt={selectedRecipe.name}
              fill
              referrerPolicy="no-referrer"
              className="object-cover object-center"
              sizes="(max-width: 1024px) 100vw, 42vw"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0a1320] lg:from-transparent lg:to-transparent via-transparent to-transparent opacity-80" />

            {/* Quick Badge overlay */}
            <div className="absolute top-4 left-4 p-3 bg-[#070e17]/85 backdrop-blur-md border border-[#dfb74a]/40 text-xs">
              <span className="text-[10px] uppercase tracking-widest text-[#dfb74a] font-bold block">
                Recommended Glass
              </span>
              <span className="font-editorial text-sm font-semibold text-slate-100">
                {selectedRecipe.glassware}
              </span>
            </div>
          </div>

          {/* Right Column: Recipe Details & Method */}
          <div className="lg:col-span-7 p-6 sm:p-10 flex flex-col justify-between space-y-6">
            <div>
              {/* Title & Tagline */}
              <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2 border-b border-[#dfb74a]/20 pb-4">
                <div>
                  <h3 className="font-brand text-2xl sm:text-3xl font-bold tracking-wider text-slate-100 dark:text-slate-100 light:text-slate-900">
                    {selectedRecipe.name}
                  </h3>
                  <p className="font-editorial text-base italic text-[#ECC872] mt-0.5">
                    {selectedRecipe.tagline}
                  </p>
                </div>

                {/* Unit Switcher */}
                <div className="flex items-center gap-1.5 self-start sm:self-auto text-xs bg-[#070e17] dark:bg-[#070e17] light:bg-slate-100 p-1 border border-[#dfb74a]/20">
                  <button
                    onClick={() => setUseImperial(false)}
                    className={`px-2.5 py-1 font-mono transition-colors ${
                      !useImperial
                        ? 'bg-[#dfb74a] text-slate-950 font-bold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Metric (ml)
                  </button>
                  <button
                    onClick={() => setUseImperial(true)}
                    className={`px-2.5 py-1 font-mono transition-colors ${
                      useImperial
                        ? 'bg-[#dfb74a] text-slate-950 font-bold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Imperial (oz)
                  </button>
                </div>
              </div>

              {/* Ingredients Checklist */}
              <div className="mt-6">
                <div className="flex items-center justify-between text-xs tracking-wider uppercase font-bold text-slate-300 dark:text-slate-300 light:text-slate-700 mb-3">
                  <span>Ingredients Checklist</span>
                  <span className="text-[11px] lowercase text-[#dfb74a] normal-case tracking-normal">
                    tap to check ingredients you have
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {selectedRecipe.ingredients.map((ing, idx) => {
                    const isChecked = !!checkedIngredients[`${selectedRecipe.id}-${idx}`];
                    return (
                      <button
                        key={idx}
                        onClick={() => toggleIngredientCheck(idx)}
                        className={`p-2.5 flex items-center justify-between text-left border transition-all text-xs focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#dfb74a] ${
                          isChecked
                            ? 'bg-[#dfb74a]/10 border-[#dfb74a] text-slate-100 dark:text-slate-100 light:text-slate-900'
                            : 'bg-[#070e17]/60 dark:bg-[#070e17]/60 light:bg-slate-50 border-slate-800 dark:border-slate-800 light:border-slate-200 text-slate-300 dark:text-slate-300 light:text-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span
                            className={`w-4 h-4 rounded-xs border flex items-center justify-center shrink-0 ${
                              isChecked
                                ? 'bg-[#dfb74a] border-[#dfb74a] text-slate-950'
                                : 'border-slate-600'
                            }`}
                          >
                            {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                          </span>
                          <span className={isChecked ? 'line-through opacity-75' : 'font-medium'}>
                            {ing.item}
                          </span>
                        </div>
                        <span className="font-mono text-[#ECC872] shrink-0 ml-2 font-bold">
                          {useImperial ? ing.amountImperial : ing.amountMetric}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Mixology Steps */}
              <div className="mt-6 space-y-2">
                <h4 className="text-xs tracking-wider uppercase font-bold text-slate-300 dark:text-slate-300 light:text-slate-700">
                  Method &amp; Preparation
                </h4>
                <ol className="space-y-2 text-xs text-slate-300 dark:text-slate-300 light:text-slate-600">
                  {selectedRecipe.instructions.map((step, idx) => (
                    <li key={idx} className="flex gap-3 items-start">
                      <span className="font-mono text-[#dfb74a] font-bold shrink-0">
                        0{idx + 1}.
                      </span>
                      <span className="leading-relaxed">{step}</span>
                    </li>
                  ))}
                </ol>
              </div>

              {/* Bartender Tip */}
              <div className="mt-6 p-3.5 bg-[#070e17] dark:bg-[#070e17] light:bg-amber-50/70 border border-[#dfb74a]/30 text-xs">
                <div className="flex items-center gap-2 text-[#ECC872] font-bold text-[11px] tracking-wider uppercase mb-1">
                  <ChefHat className="w-4 h-4" />
                  <span>The Officer&apos;s Secret</span>
                </div>
                <p className="text-slate-300 dark:text-slate-300 light:text-slate-700 font-light italic leading-relaxed">
                  &ldquo;{selectedRecipe.bartenderTip}&rdquo;
                </p>
              </div>
            </div>

            {/* Action Bar */}
            <div className="pt-4 border-t border-[#dfb74a]/20 flex flex-wrap items-center justify-between gap-4">
              <div className="text-xs text-slate-400 dark:text-slate-400 light:text-slate-500">
                <span className="font-medium text-slate-200 dark:text-slate-200 light:text-slate-800">
                  Spirit Foundation:
                </span>{' '}
                {selectedRecipe.spiritBase}
              </div>

              <button
                onClick={handleOrderSpirit}
                className="inline-flex items-center gap-2 px-6 py-2.5 bg-[#ECC872] hover:bg-[#dfb74a] text-slate-950 font-bold text-xs tracking-widest uppercase transition-colors shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#dfb74a]"
              >
                <Plus className="w-4 h-4" />
                <span>Order Spirit for this Cocktail</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
