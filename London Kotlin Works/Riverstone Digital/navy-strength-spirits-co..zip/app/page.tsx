'use client';

import React from 'react';
import { AppProvider } from '@/context/AppContext';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import HeritageBar from '@/components/HeritageBar';
import FeaturedGrid from '@/components/FeaturedGrid';
import SpiritsCatalog from '@/components/SpiritsCatalog';
import CocktailSection from '@/components/CocktailSection';
import HeritageTimeline from '@/components/HeritageTimeline';
import Footer from '@/components/Footer';

// Modals & Drawers
import AuthModal from '@/components/AuthModal';
import CartDrawer from '@/components/CartDrawer';
import SpiritModal from '@/components/SpiritModal';
import SearchModal from '@/components/SearchModal';
import HeritageModal from '@/components/HeritageModal';
import TradeModal from '@/components/TradeModal';
import AgeGateModal from '@/components/AgeGateModal';

export default function HomePage() {
  return (
    <AppProvider>
      <div className="min-h-screen flex flex-col bg-[#070e17] dark:bg-[#070e17] light:bg-[#fcf9f2] text-slate-100 dark:text-slate-100 light:text-slate-900 transition-colors duration-200">
        {/* Navigation Bar */}
        <Navbar />

        {/* Main Content Landmark for WCAG 2.1 */}
        <main id="main-content" className="flex-1 focus:outline-none">
          {/* Hero Section matching design reference */}
          <Hero />

          {/* 4-Pillar Heritage Trust Bar */}
          <HeritageBar />

          {/* 4-Card Featured Grid from Design (Heritage, Cocktails, Range, Shop Now Gold Card) */}
          <FeaturedGrid />

          {/* Complete Spirits Collection with Tasting Notes */}
          <SpiritsCatalog />

          {/* Interactive Wardroom Cocktail Mixology Suite */}
          <CocktailSection />

          {/* Royal Admiralty Lore & Gunpowder Proof Simulator */}
          <HeritageTimeline />
        </main>

        {/* Brand Footer */}
        <Footer />

        {/* Interactive Modals and Flyouts */}
        <AuthModal />
        <CartDrawer />
        <SpiritModal />
        <SearchModal />
        <HeritageModal />
        <TradeModal />
        <AgeGateModal />
      </div>
    </AppProvider>
  );
}
