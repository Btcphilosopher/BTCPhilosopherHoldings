import type { Metadata, Viewport } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Navy Strength Spirits Co. | British Navy Rum',
  description: 'Authentic British Navy Rum & Overproof Spirits. Tradition, Strength, Excellence. Overproof 57% ABV crafted for those who demand more.',
  keywords: ['Navy Rum', 'British Spirits', 'Overproof Rum', 'Navy Strength', '57% ABV', 'Craft Spirits', 'British Heritage'],
  authors: [{ name: 'Navy Strength Spirits Co.' }],
  openGraph: {
    title: 'Navy Strength Spirits Co. | British Navy Rum',
    description: 'Overproof. Uncompromising. British. Handcrafted British Navy Rum at 57% ABV steeped in maritime tradition.',
    type: 'website',
    locale: 'en_GB',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Navy Strength Spirits Co. | British Navy Rum',
    description: 'Overproof. Uncompromising. British. Authentic British Navy Rum at 57% ABV.',
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: '(prefers-color-scheme: dark)', color: '#070e17' },
    { media: '(prefers-color-scheme: light)', color: '#fcf9f2' },
  ],
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              try {
                const saved = localStorage.getItem('theme');
                if (saved === 'light') {
                  document.documentElement.classList.remove('dark');
                  document.documentElement.classList.add('light');
                } else {
                  document.documentElement.classList.add('dark');
                  document.documentElement.classList.remove('light');
                }
              } catch (_) {}
            `,
          }}
        />
      </head>
      <body
        className="min-h-screen bg-[#070e17] text-slate-100 antialiased selection:bg-[#dfb74a] selection:text-slate-950 dark:bg-[#070e17] dark:text-slate-100 transition-colors duration-200"
        suppressHydrationWarning
      >
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-50 focus:px-4 focus:py-2 focus:bg-[#dfb74a] focus:text-slate-950 focus:font-semibold focus:shadow-lg"
        >
          Skip to main content
        </a>
        {children}
      </body>
    </html>
  );
}
