import { NextRequest, NextResponse } from 'next/server';
import { spawn } from 'child_process';
import path from 'path';
import fs from 'fs';

/**
 * Next.js API Bridge to native PHP 8.2 Backend Microservice
 */
async function executePhpScript(scriptPath: string, args: Record<string, string> = {}, postBody?: string): Promise<{ stdout: string; stderr: string; code: number; executionTimeMs: number }> {
  const start = performance.now();
  return new Promise((resolve) => {
    // Build query string for PHP CLI
    const queryString = new URLSearchParams(args).toString();
    
    const env = {
      ...process.env,
      REQUEST_METHOD: postBody ? 'POST' : 'GET',
      QUERY_STRING: queryString,
      CONTENT_TYPE: 'application/json',
      CONTENT_LENGTH: postBody ? Buffer.byteLength(postBody).toString() : '0',
    };

    // Construct mock CLI wrapper to populate $_GET and php://input
    const phpCommand = `
      parse_str(getenv('QUERY_STRING') ?: '', $_GET);
      $_REQUEST = array_merge($_GET, $_POST);
      require '${scriptPath.replace(/'/g, "\\'")}';
    `;

    const child = spawn('php', ['-r', phpCommand], { env });
    let stdout = '';
    let stderr = '';

    if (postBody) {
      child.stdin.write(postBody);
    }
    child.stdin.end();

    child.stdout.on('data', (data) => {
      stdout += data.toString();
    });

    child.stderr.on('data', (data) => {
      stderr += data.toString();
    });

    child.on('close', (code) => {
      const executionTimeMs = Math.round((performance.now() - start) * 100) / 100;
      resolve({ stdout, stderr, code: code ?? 0, executionTimeMs });
    });

    child.on('error', (err) => {
      resolve({ stdout: '', stderr: err.message, code: 1, executionTimeMs: 0 });
    });
  });
}

export async function GET(request: NextRequest) {
  const url = new URL(request.url);
  const endpoint = url.searchParams.get('endpoint') || 'products';
  
  // Whitelist allowable PHP endpoints
  const allowedEndpoints: Record<string, string> = {
    products: 'products.php',
    cart: 'cart.php',
    animation_specs: 'animation_specs.php',
    newsletter: 'newsletter.php',
    checkout: 'checkout.php',
  };

  const scriptFileName = allowedEndpoints[endpoint];
  if (!scriptFileName) {
    return NextResponse.json({ error: `Unknown PHP endpoint: ${endpoint}` }, { status: 400 });
  }

  const scriptPath = path.join(process.cwd(), 'php_backend', 'api', scriptFileName);
  if (!fs.existsSync(scriptPath)) {
    return NextResponse.json({ error: `PHP script not found: ${scriptFileName}` }, { status: 404 });
  }

  const params: Record<string, string> = {};
  url.searchParams.forEach((value, key) => {
    if (key !== 'endpoint') {
      params[key] = value;
    }
  });

  const { stdout, stderr, executionTimeMs } = await executePhpScript(scriptPath, params);

  // Extract JSON from output (ignoring HTTP headers if emitted)
  let jsonString = stdout.trim();
  const jsonStart = jsonString.indexOf('{');
  if (jsonStart !== -1) {
    jsonString = jsonString.slice(jsonStart);
  }

  try {
    const data = JSON.parse(jsonString);
    return NextResponse.json(data, {
      headers: {
        'X-Powered-By': 'PHP/8.2-FPM (Integrated Next.js Bridge)',
        'X-PHP-Execution-Time': `${executionTimeMs}ms`,
        'X-PHP-Script': scriptFileName,
      },
    });
  } catch {
    return NextResponse.json(
      {
        error: 'PHP execution returned invalid JSON',
        rawOutput: stdout,
        stderr,
        executionTimeMs,
      },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  const url = new URL(request.url);
  const endpoint = url.searchParams.get('endpoint') || 'cart';

  const allowedEndpoints: Record<string, string> = {
    products: 'products.php',
    cart: 'cart.php',
    checkout: 'checkout.php',
    newsletter: 'newsletter.php',
    animation_specs: 'animation_specs.php',
  };

  const scriptFileName = allowedEndpoints[endpoint];
  if (!scriptFileName) {
    return NextResponse.json({ error: `Unknown PHP endpoint: ${endpoint}` }, { status: 400 });
  }

  const scriptPath = path.join(process.cwd(), 'php_backend', 'api', scriptFileName);
  if (!fs.existsSync(scriptPath)) {
    return NextResponse.json({ error: `PHP script not found: ${scriptFileName}` }, { status: 404 });
  }

  const bodyText = await request.text();
  const params: Record<string, string> = {};
  url.searchParams.forEach((value, key) => {
    if (key !== 'endpoint') {
      params[key] = value;
    }
  });

  const { stdout, stderr, executionTimeMs } = await executePhpScript(scriptPath, params, bodyText);

  let jsonString = stdout.trim();
  const jsonStart = jsonString.indexOf('{');
  if (jsonStart !== -1) {
    jsonString = jsonString.slice(jsonStart);
  }

  try {
    const data = JSON.parse(jsonString);
    return NextResponse.json(data, {
      headers: {
        'X-Powered-By': 'PHP/8.2-FPM (Integrated Next.js Bridge)',
        'X-PHP-Execution-Time': `${executionTimeMs}ms`,
        'X-PHP-Script': scriptFileName,
      },
    });
  } catch {
    return NextResponse.json(
      {
        error: 'PHP execution returned invalid JSON',
        rawOutput: stdout,
        stderr,
        executionTimeMs,
      },
      { status: 500 }
    );
  }
}
