import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Michael Kors | Modern Luxury & Designer Fashion',
  description: 'Explore the latest Michael Kors collections of designer handbags, watches, shoes, clothing and accessories. Effortless style for wherever life takes you.',
  openGraph: {
    title: 'Michael Kors | Modern Luxury & Designer Fashion',
    description: 'Explore the latest Michael Kors collections of designer handbags, watches, shoes, clothing and accessories.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Michael Kors | Modern Luxury & Designer Fashion',
    description: 'Explore the latest Michael Kors collections of designer handbags, watches, shoes, clothing and accessories.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className="antialiased bg-[#FAF8F5] text-neutral-900 selection:bg-amber-100 selection:text-neutral-900 min-h-screen font-sans" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
