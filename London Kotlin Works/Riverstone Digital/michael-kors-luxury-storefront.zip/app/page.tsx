'use client';

import React, { useState, useEffect } from 'react';
import Header from '@/components/Header';
import HeroSlider from '@/components/HeroSlider';
import CategoryGrid from '@/components/CategoryGrid';
import EditorialBanner from '@/components/EditorialBanner';
import ProductCatalog from '@/components/ProductCatalog';
import ProductDetailModal from '@/components/ProductDetailModal';
import CartDrawer from '@/components/CartDrawer';
import CheckoutModal from '@/components/CheckoutModal';
import WishlistDrawer from '@/components/WishlistDrawer';
import SearchModal from '@/components/SearchModal';
import VipClubModal from '@/components/VipClubModal';
import PhpKotlinConsole from '@/components/PhpKotlinConsole';
import Footer from '@/components/Footer';

import { Product, CartState, CartItem, OrderConfirmation, KotlinPhysicsPreset } from '@/lib/types';
import { KOTLIN_PRESETS } from '@/lib/kotlin-physics';

// Initial fallback catalog in case network is delayed
const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'mk-bag-01',
    name: 'Hamilton Legacy Large Leather Belted Satchel',
    category: 'bags',
    categoryName: 'Bags',
    price: 498.0,
    originalPrice: 558.0,
    rating: 4.9,
    reviewsCount: 142,
    tag: 'Best Seller',
    colors: [
      { name: 'Luggage Tan', hex: '#9B5B2E', selected: true },
      { name: 'Classic Black', hex: '#1A1A1A' },
      { name: 'Cream White', hex: '#F4EFE6' },
    ],
    sizes: ['One Size'],
    image: '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png',
    imageSlice: 'bag',
    gallery: ['/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png'],
    description: 'A pragmatic yet glamorous satchel crafted from supple leather with statement chain-link hardware and decorative padlock pendant.',
    details: [
      '100% Genuine Full-Grain Calfskin Leather',
      'Gold-tone luxury hardware with polished padlock charm',
      'Dimensions: 15.5"W X 9.5"H X 6"D',
      'Adjustable cross-body shoulder strap: 18.5"-22"',
      'Interior features center zip compartment, 2 slip pockets',
    ],
    craftsmanship: 'Handcrafted in Florence atelier by master leather artisans with hand-painted raw edges.',
    inStock: true,
    inventory: 28,
    kotlinAnimation: {
      type: 'spring',
      dampingRatio: 0.75,
      stiffness: 300.0,
      spec: 'spring(dampingRatio = 0.75f, stiffness = 300f)',
    },
  },
  {
    id: 'mk-men-01',
    name: 'Coastal Tailored Suede Trim Field Jacket',
    category: 'men',
    categoryName: 'Men',
    price: 595.0,
    originalPrice: 695.0,
    rating: 4.8,
    reviewsCount: 89,
    tag: 'Runway Edition',
    colors: [
      { name: 'Midnight Navy', hex: '#1B263B', selected: true },
      { name: 'Sand Beige', hex: '#C8B89F' },
      { name: 'Espresso Brown', hex: '#3D2B1F' },
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    image: '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png',
    imageSlice: 'men',
    gallery: ['/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png'],
    description: 'Sophisticated coastal outerwear cut from water-resistant technical twill with Italian suede collar trim and custom engraved snaps.',
    details: [
      'Fabric: 85% Technical Twill, 15% Polyurethane',
      'Suede trim collar lining sourced from Tuscany',
      'Dual zip and storm placket button front closure',
    ],
    craftsmanship: 'Precision cut and tailored in Milan with reinforced articulated sleeve seams.',
    inStock: true,
    inventory: 19,
    kotlinAnimation: {
      type: 'spring',
      dampingRatio: 0.85,
      stiffness: 500.0,
      spec: 'spring(dampingRatio = 0.85f, stiffness = 500f)',
    },
  },
  {
    id: 'mk-shoes-01',
    name: 'Monique Logo Jacquard Low-Top Sneakers',
    category: 'shoes',
    categoryName: 'Shoes',
    price: 225.0,
    originalPrice: 265.0,
    rating: 4.9,
    reviewsCount: 310,
    tag: 'Essential',
    colors: [
      { name: 'Optic White / Gold', hex: '#FFFFFF', selected: true },
      { name: 'Soft Pink / Rose Gold', hex: '#E8CCD7' },
      { name: 'All Black Mono', hex: '#1A1A1A' },
    ],
    sizes: ['6 US', '7 US', '8 US', '8.5 US', '9 US', '10 US'],
    image: '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png',
    imageSlice: 'shoes',
    gallery: ['/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png'],
    description: 'A sporty-luxe essential rendered in signature MK logo jacquard with smooth metallic calf leather trim and molded ergonomic footbed.',
    details: [
      'Upper: 67% Coated Canvas, 17% Polyester, 14% Cotton',
      'Sole: 100% Shock-absorbing vulcanized rubber',
      'Signature MK gold-tone heel counter plaque',
    ],
    craftsmanship: 'Stitched cupsole construction engineered for all-day metropolitan comfort.',
    inStock: true,
    inventory: 42,
    kotlinAnimation: {
      type: 'spring',
      dampingRatio: 0.65,
      stiffness: 250.0,
      spec: 'spring(dampingRatio = 0.65f, stiffness = 250f)',
    },
  },
  {
    id: 'mk-watches-01',
    name: 'Bradshaw Oversized Gold-Tone Chronograph Watch',
    category: 'watches',
    categoryName: 'Watches',
    price: 295.0,
    originalPrice: 350.0,
    rating: 5.0,
    reviewsCount: 428,
    tag: 'Iconic Piece',
    colors: [
      { name: '18K Yellow Gold-Tone', hex: '#D4AF37', selected: true },
      { name: 'Rose Gold-Tone', hex: '#B76E79' },
      { name: 'Stainless Steel Silver', hex: '#C0C0C0' },
    ],
    sizes: ['43mm Case'],
    image: '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png',
    imageSlice: 'watches',
    gallery: ['/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png'],
    description: 'The definitive statement timepiece featuring architectural Roman numerals, three sub-dials, date window, and polished link bracelet.',
    details: [
      'Case size: 43mm stainless steel with PVD gold plating',
      'Movement: High-precision Japanese quartz chronograph',
      'Water resistance: Up to 100 meters (10 ATM)',
    ],
    craftsmanship: 'Diamond-turned bezel and scratch-resistant sapphire mineral crystal coating.',
    inStock: true,
    inventory: 35,
    kotlinAnimation: {
      type: 'spring',
      dampingRatio: 0.8,
      stiffness: 400.0,
      spec: 'spring(dampingRatio = 0.8f, stiffness = 400f)',
    },
  },
  {
    id: 'mk-acc-01',
    name: 'Empire Black Acetate Cat-Eye Sunglasses',
    category: 'accessories',
    categoryName: 'Accessories',
    price: 179.0,
    originalPrice: 210.0,
    rating: 4.9,
    reviewsCount: 195,
    tag: 'Editorial Favorite',
    colors: [
      { name: 'Glossy Onyx Black', hex: '#111111', selected: true },
      { name: 'Havana Tortoise', hex: '#5C381E' },
    ],
    sizes: ['54-18-140 mm'],
    image: '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png',
    imageSlice: 'accessories',
    gallery: ['/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png'],
    description: 'Sculpted from hand-polished Italian Mazzucchelli acetate with gold-tone MK monogram temple hardware and 100% UVA/UVB gradient lenses.',
    details: [
      '100% Mazzucchelli Italian Acetate frame',
      '100% UVA/UVB total spectrum radiation protection',
      'Includes embossed Saffiano leather hard case',
    ],
    craftsmanship: 'Precision hand-beveled edges and hand-mounted temple hardware.',
    inStock: true,
    inventory: 50,
    kotlinAnimation: {
      type: 'spring',
      dampingRatio: 0.7,
      stiffness: 350.0,
      spec: 'spring(dampingRatio = 0.7f, stiffness = 350f)',
    },
  },
  {
    id: 'mk-col-01',
    name: 'Michael Kors Collection Italian Leather Moto Coat',
    category: 'collections',
    categoryName: 'Collections',
    price: 1290.0,
    originalPrice: 1450.0,
    rating: 5.0,
    reviewsCount: 64,
    tag: 'Limited Runway',
    colors: [
      { name: 'Jet Black Glaze', hex: '#0A0A0A', selected: true },
      { name: 'Cognac Brown', hex: '#7A3816' },
    ],
    sizes: ['XS', 'S', 'M', 'L'],
    image: '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png',
    imageSlice: 'collections',
    gallery: ['/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png'],
    description: 'The crown jewel of the Fall Runway: an architectural moto coat cut from buttery Italian glove leather with sharp notched lapels and custom metal hardware.',
    details: [
      '100% Italian Glove Lambskin Leather',
      'Lining: 100% Silk Cupro with Michael Kors signature script',
      'Belted waist with polished square roller buckle',
    ],
    craftsmanship: 'Tailored in limited numbered production in our historic studio in Naples.',
    inStock: true,
    inventory: 12,
    kotlinAnimation: {
      type: 'spring',
      dampingRatio: 0.8,
      stiffness: 280.0,
      spec: 'spring(dampingRatio = 0.8f, stiffness = 280f)',
    },
  },
];

export default function Home() {
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [phpExecutionTimeMs, setPhpExecutionTimeMs] = useState<number>(1.2);
  const [selectedPreset, setSelectedPreset] = useState<KotlinPhysicsPreset>(KOTLIN_PRESETS.luxury_smooth);

  // Modals state
  const [activeProductModal, setActiveProductModal] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isVipOpen, setIsVipOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);

  // Wishlist state initialized from localStorage
  const [wishlist, setWishlist] = useState<Product[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('mk_wishlist');
        return saved ? JSON.parse(saved) : [];
      } catch {
        return [];
      }
    }
    return [];
  });
  const [cart, setCart] = useState<CartState>({
    sessionId: 'mk_user_session',
    items: [],
    itemCount: 0,
    subtotal: 0,
    discountPercent: 0,
    discountAmount: 0,
    couponCode: null,
    couponDescription: null,
    shippingFee: 0,
    isFreeShipping: true,
    freeShippingThreshold: 150,
    freeShippingProgress: 0,
    amountUntilFreeShipping: 150,
    giftWrap: false,
    giftWrapFee: 0,
    taxRate: 0.0825,
    tax: 0,
    grandTotal: 0,
  });
  const [couponError, setCouponError] = useState<string | null>(null);

  // Fetch product catalog from PHP backend on load
  useEffect(() => {
    async function loadProductsFromPhp() {
      try {
        const res = await fetch('/api/php?endpoint=products');
        const data = await res.json();
        if (data.status === 'success' && Array.isArray(data.data)) {
          setProducts(data.data);
          if (data.executionTimeMs) {
            setPhpExecutionTimeMs(data.executionTimeMs);
          }
        }
      } catch (e) {
        console.warn('PHP API load fallback:', e);
      }
    }
    loadProductsFromPhp();
  }, []);

  // Fetch initial cart from PHP backend
  useEffect(() => {
    async function fetchCart() {
      try {
        const res = await fetch('/api/php?endpoint=cart');
        const data = await res.json();
        if (data.status === 'success' && data.cart) {
          setCart(data.cart);
        }
      } catch (e) {
        console.warn('PHP Cart load fallback:', e);
      }
    }
    fetchCart();
  }, []);

  const saveWishlist = (newList: Product[]) => {
    setWishlist(newList);
    try {
      localStorage.setItem('mk_wishlist', JSON.stringify(newList));
    } catch {
      // ignore
    }
  };

  const toggleWishlist = (product: Product) => {
    const exists = wishlist.some((item) => item.id === product.id);
    if (exists) {
      saveWishlist(wishlist.filter((item) => item.id !== product.id));
    } else {
      saveWishlist([...wishlist, product]);
    }
  };

  // Cart operations through PHP backend
  const handleAddToCart = async (
    product: Product,
    selectedColor = 'Standard',
    selectedSize = 'One Size',
    quantity = 1
  ) => {
    try {
      const res = await fetch('/api/php?endpoint=cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'add',
          item: {
            ...product,
            selectedColor,
            selectedSize,
            quantity,
          },
        }),
      });
      const data = await res.json();
      if (data.status === 'success' && data.cart) {
        setCart(data.cart);
        setIsCartOpen(true);
      }
    } catch (err) {
      // Fallback local cart calculation
      const existing = cart.items.find(
        (i) => i.id === product.id && i.selectedColor === selectedColor && i.selectedSize === selectedSize
      );
      let updatedItems: CartItem[];
      if (existing) {
        updatedItems = cart.items.map((i) =>
          i === existing ? { ...i, quantity: i.quantity + quantity } : i
        );
      } else {
        updatedItems = [
          ...cart.items,
          { ...product, selectedColor, selectedSize, quantity },
        ];
      }
      const count = updatedItems.reduce((acc, i) => acc + i.quantity, 0);
      const subtotal = updatedItems.reduce((acc, i) => acc + i.price * i.quantity, 0);
      const shipping = subtotal >= 150 ? 0 : 15;
      const tax = subtotal * 0.0825;
      setCart({
        ...cart,
        items: updatedItems,
        itemCount: count,
        subtotal,
        shippingFee: shipping,
        isFreeShipping: shipping === 0,
        amountUntilFreeShipping: Math.max(0, 150 - subtotal),
        freeShippingProgress: Math.min(100, (subtotal / 150) * 100),
        tax,
        grandTotal: subtotal + shipping + tax,
      });
      setIsCartOpen(true);
    }
  };

  const handleUpdateQuantity = async (id: string, quantity: number) => {
    try {
      const res = await fetch('/api/php?endpoint=cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'update', id, quantity }),
      });
      const data = await res.json();
      if (data.status === 'success' && data.cart) {
        setCart(data.cart);
      }
    } catch {
      // ignore
    }
  };

  const handleRemoveFromCart = async (id: string) => {
    try {
      const res = await fetch('/api/php?endpoint=cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'remove', id }),
      });
      const data = await res.json();
      if (data.status === 'success' && data.cart) {
        setCart(data.cart);
      }
    } catch {
      // ignore
    }
  };

  const handleApplyCoupon = async (code: string) => {
    setCouponError(null);
    try {
      const res = await fetch('/api/php?endpoint=cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'apply_coupon', code }),
      });
      const data = await res.json();
      if (data.status === 'success' && data.cart) {
        setCart(data.cart);
        if (data.couponError) {
          setCouponError(data.couponError);
        }
      }
    } catch {
      // ignore
    }
  };

  const handleRemoveCoupon = async () => {
    try {
      const res = await fetch('/api/php?endpoint=cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'remove_coupon' }),
      });
      const data = await res.json();
      if (data.status === 'success' && data.cart) {
        setCart(data.cart);
      }
    } catch {
      // ignore
    }
  };

  const handleToggleGiftWrap = async () => {
    try {
      const res = await fetch('/api/php?endpoint=cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'toggle_giftwrap' }),
      });
      const data = await res.json();
      if (data.status === 'success' && data.cart) {
        setCart(data.cart);
      }
    } catch {
      // ignore
    }
  };

  const handleOrderComplete = async (order: OrderConfirmation) => {
    // Clear cart via PHP
    try {
      await fetch('/api/php?endpoint=cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'clear' }),
      });
    } catch {
      // ignore
    }
    setCart((prev) => ({
      ...prev,
      items: [],
      itemCount: 0,
      subtotal: 0,
      discountAmount: 0,
      couponCode: null,
      grandTotal: 0,
    }));
  };

  const handleScrollToCatalog = () => {
    const el = document.getElementById('catalog-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectCategory = (category: string) => {
    setActiveCategory(category);
    handleScrollToCatalog();
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F5] text-neutral-900">
      {/* 1. Header with Cart, Wishlist, Search, VIP triggers */}
      <Header
        cartCount={cart.itemCount}
        wishlistCount={wishlist.length}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenVip={() => setIsVipOpen(true)}
        onSelectCategory={handleSelectCategory}
        activeCategory={activeCategory}
      />

      {/* 2. Hero Slider reproducing the exact yacht scene from the screenshot */}
      <HeroSlider
        onShopCollection={handleScrollToCatalog}
        onExploreSlide={handleSelectCategory}
      />

      {/* 3. Six Category Cards directly matching the screenshot */}
      <CategoryGrid
        onSelectCategory={handleSelectCategory}
        activeCategory={activeCategory}
      />

      {/* 4. Editorial Fall Collection Banner directly matching the screenshot */}
      <EditorialBanner onExplore={handleSelectCategory} />

      {/* 5. Complete Luxury Catalog with Kotlin Physics Spring Animations & PHP 8.2 */}
      <ProductCatalog
        products={products}
        activeCategory={activeCategory}
        onSelectCategory={setActiveCategory}
        onQuickView={(p) => setActiveProductModal(p)}
        onAddToCart={handleAddToCart}
        onToggleWishlist={toggleWishlist}
        wishlistIds={wishlist.map((w) => w.id)}
        phpExecutionTimeMs={phpExecutionTimeMs}
      />

      {/* 6. Footer */}
      <Footer
        onOpenVip={() => setIsVipOpen(true)}
        onSelectCategory={handleSelectCategory}
      />

      {/* Modals & Slide-Over Drawers */}
      {/* Product Detail Modal with 360 viewer, Kotlin Compose code, and PHP response tabs */}
      <ProductDetailModal
        key={activeProductModal?.id || 'none'}
        product={activeProductModal}
        onClose={() => setActiveProductModal(null)}
        onAddToCart={(p, c, s, q) => handleAddToCart(p, c, s, q)}
        onToggleWishlist={toggleWishlist}
        isWishlisted={activeProductModal ? wishlist.some((w) => w.id === activeProductModal.id) : false}
      />

      {/* Shopping Bag Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveFromCart}
        onApplyCoupon={handleApplyCoupon}
        onRemoveCoupon={handleRemoveCoupon}
        onToggleGiftWrap={handleToggleGiftWrap}
        onProceedToCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
        couponError={couponError}
      />

      {/* Checkout Modal with full order submission */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cart={cart}
        onOrderComplete={handleOrderComplete}
      />

      {/* Wishlist Drawer */}
      <WishlistDrawer
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlist={wishlist}
        onRemoveWishlist={toggleWishlist}
        onAddToCart={handleAddToCart}
      />

      {/* Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        products={products}
        onSelectProduct={(p) => setActiveProductModal(p)}
      />

      {/* VIP Club Modal */}
      <VipClubModal
        isOpen={isVipOpen}
        onClose={() => setIsVipOpen(false)}
        onApplyPromoCode={handleApplyCoupon}
      />

      {/* Interactive PHP & Kotlin Engineering Console */}
      <PhpKotlinConsole
        currentPreset={selectedPreset}
        onSelectPreset={setSelectedPreset}
        lastPhpExecutionTime={phpExecutionTimeMs}
      />
    </div>
  );
}
