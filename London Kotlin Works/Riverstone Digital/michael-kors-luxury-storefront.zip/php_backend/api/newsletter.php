<?php
/**
 * Michael Kors VIP Club Newsletter Subscription Endpoint
 * PHP 8.2 Production REST API
 */

header('Content-Type: application/json; charset=utf-8');
header('X-Powered-By: PHP/8.2-FPM (Michael Kors VIP Club)');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$startTime = microtime(true);
$rawInput = file_get_contents('php://input');
$input = json_decode($rawInput, true) ?? [];

$email = filter_var(trim($input['email'] ?? ''), FILTER_VALIDATE_EMAIL);

if (!$email) {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => 'Please provide a valid email address for VIP Club privileges.',
        'phpEngine' => 'PHP ' . PHP_VERSION
    ]);
    exit;
}

$executionTime = round((microtime(true) - $startTime) * 1000, 2);
header("X-PHP-Execution-Time: {$executionTime}ms");

echo json_encode([
    'status' => 'success',
    'message' => 'Welcome to Michael Kors VIP Club. Enjoy 15% off your first order with code MKLUXURY.',
    'promoCode' => 'MKLUXURY',
    'discountPercent' => 15,
    'email' => $email,
    'phpEngine' => 'PHP ' . PHP_VERSION,
    'executionTimeMs' => $executionTime
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
