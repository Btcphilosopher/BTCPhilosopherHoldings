<?php
/**
 * Michael Kors - Kotlin Compose Animation Specifications API
 * PHP 8.2 Endpoint providing Kotlin Multiplatform (KMP) & Jetpack Compose animation configurations
 */

header('Content-Type: application/json; charset=utf-8');
header('X-Powered-By: PHP/8.2-FPM (Kotlin Animation Spec Bridge)');
header('Access-Control-Allow-Origin: *');

$startTime = microtime(true);

$animationPresets = [
    'luxury_smooth' => [
        'name' => 'Michael Kors Luxury Smooth',
        'framework' => 'androidx.compose.animation.core.spring',
        'dampingRatio' => 0.85,
        'dampingConstant' => 'Spring.DampingRatioLowBouncy',
        'stiffness' => 300.0,
        'stiffnessConstant' => 'Spring.StiffnessLow',
        'description' => 'Gentle, high-end deceleration mimicking weighted leather and fine jewelry movement.'
    ],
    'medium_bouncy' => [
        'name' => 'Snappy Spring Interaction',
        'framework' => 'androidx.compose.animation.core.spring',
        'dampingRatio' => 0.75,
        'dampingConstant' => 'Spring.DampingRatioMediumBouncy',
        'stiffness' => 450.0,
        'stiffnessConstant' => 'Spring.StiffnessMedium',
        'description' => 'Tactile button presses, wishlist favorites, and quick-add feedback.'
    ],
    'high_bouncy' => [
        'name' => 'Playful Sneaker Bounce',
        'framework' => 'androidx.compose.animation.core.spring',
        'dampingRatio' => 0.5,
        'dampingConstant' => 'Spring.DampingRatioHighBouncy',
        'stiffness' => 220.0,
        'stiffnessConstant' => 'Spring.StiffnessLow',
        'description' => 'High-elasticity spring bounce for athletic sneakers and badge popups.'
    ],
    'critically_damped' => [
        'name' => 'Critically Damped Luxury Slide',
        'framework' => 'androidx.compose.animation.core.spring',
        'dampingRatio' => 1.0,
        'dampingConstant' => 'Spring.DampingRatioNoBouncy',
        'stiffness' => 500.0,
        'stiffnessConstant' => 'Spring.StiffnessMedium',
        'description' => 'Zero overshoot, smooth fluid slide for hero campaign slides and drawer panels.'
    ]
];

$kotlinCodeSnippets = [
    'productCard' => <<<'KOTLIN'
// Kotlin Multiplatform / Jetpack Compose Product Card Animation
import androidx.compose.animation.core.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp

@Composable
fun LuxuryProductCard(
    product: Product,
    onProductClick: (Product) -> Unit,
    onQuickAdd: (Product) -> Unit
) {
    var isHovered by remember { mutableStateOf(false) }
    
    // Kotlin Jetpack Compose spring animation physics
    val scale by animateFloatAsState(
        targetValue = if (isHovered) 1.035f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "luxuryProductCardScale"
    )
    
    val elevation by animateDpAsState(
        targetValue = if (isHovered) 12.dp else 0.dp,
        animationSpec = spring(dampingRatio = 0.8f, stiffness = 400f),
        label = "luxuryElevation"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        isHovered = true
                        tryAwaitRelease()
                        isHovered = false
                    },
                    onTap = { onProductClick(product) }
                )
            }
    ) {
        // Luxury Product Presentation Box
        LuxuryProductImage(product = product)
        ProductMetadata(product = product)
    }
}
KOTLIN
,
    'interactive360' => <<<'KOTLIN'
// Kotlin Multiplatform 360-Degree Touch/Drag Product Rotation
import androidx.compose.animation.core.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.roundToInt

@Composable
fun Interactive360ProductViewer(
    frameCount: Int = 36,
    damping: Float = 0.75f,
    modifier: Modifier = Modifier
) {
    var rotationAngle by remember { mutableFloatStateOf(0f) }
    val animatedRotation = remember { Animatable(0f) }
    
    Box(
        modifier = modifier.pointerInput(Unit) {
            detectDragGestures(
                onDrag = { change, dragAmount ->
                    change.consume()
                    rotationAngle = (rotationAngle + dragAmount.x * 0.5f) % 360f
                },
                onDragEnd = {
                    // Settle onto nearest frame with Kotlin spring inertia
                    val nearestFrameAngle = (rotationAngle / 10f).roundToInt() * 10f
                    // Launch smooth spring settle
                }
            )
        }
    ) {
        val currentFrame = (((rotationAngle % 360f + 360f) % 360f) / (360f / frameCount)).toInt()
        RenderProductFrame(frameIndex = currentFrame)
    }
}
KOTLIN
,
    'flyToCart' => <<<'KOTLIN'
// Kotlin Bezier Arc Fly-to-Cart Trajectory Animation
import androidx.compose.animation.core.*
import androidx.compose.ui.geometry.Offset

@Composable
fun rememberFlyToCartState(
    startOffset: Offset,
    cartBadgeOffset: Offset
): State<Offset> {
    val progress = remember { Animatable(0f) }
    
    LaunchedEffect(startOffset) {
        progress.snapTo(0f)
        progress.animateTo(
            targetValue = 1f,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioLowBouncy,
                stiffness = Spring.StiffnessMedium
            )
        )
    }
    
    // Quadratic Bézier curve in Kotlin
    return derivedStateOf {
        val t = progress.value
        val controlPoint = Offset(
            x = (startOffset.x + cartBadgeOffset.x) / 2f,
            y = minOf(startOffset.y, cartBadgeOffset.y) - 180f
        )
        val p0 = startOffset
        val p1 = controlPoint
        val p2 = cartBadgeOffset
        
        Offset(
            x = (1 - t) * (1 - t) * p0.x + 2 * (1 - t) * t * p1.x + t * t * p2.x,
            y = (1 - t) * (1 - t) * p0.y + 2 * (1 - t) * t * p1.y + t * t * p2.y
        )
    }
}
KOTLIN
];

$executionTime = round((microtime(true) - $startTime) * 1000, 2);
header("X-PHP-Execution-Time: {$executionTime}ms");

echo json_encode([
    'status' => 'success',
    'language' => 'Kotlin Multiplatform 2.0 / Jetpack Compose',
    'presets' => $animationPresets,
    'codeSnippets' => $kotlinCodeSnippets,
    'phpEngine' => 'PHP ' . PHP_VERSION,
    'executionTimeMs' => $executionTime
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
