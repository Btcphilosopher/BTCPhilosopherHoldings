<?php
/**
 * Michael Kors Luxury E-Commerce Backend - Checkout API
 * PHP 8.2 Production Order Fulfillment Endpoint
 */

header('Content-Type: application/json; charset=utf-8');
header('X-Powered-By: PHP/8.2-FPM (Michael Kors Microservice)');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$startTime = microtime(true);
$rawInput = file_get_contents('php://input');
$input = json_decode($rawInput, true) ?? [];

$shipping = $input['shipping'] ?? [];
$cart = $input['cart'] ?? [];
$paymentMethod = $input['paymentMethod'] ?? 'card';

// Validation
$firstName = trim($shipping['firstName'] ?? '');
$lastName = trim($shipping['lastName'] ?? '');
$email = trim($shipping['email'] ?? '');
$address = trim($shipping['address'] ?? '');
$city = trim($shipping['city'] ?? '');
$state = trim($shipping['state'] ?? 'NY');
$zip = trim($shipping['zip'] ?? '');

if (empty($firstName) || empty($lastName) || empty($email) || empty($address)) {
    http_response_code(422);
    echo json_encode([
        'status' => 'error',
        'message' => 'Please provide full name, email, and shipping address.',
        'phpEngine' => 'PHP ' . PHP_VERSION
    ]);
    exit;
}

// Generate luxury order ID
$orderNumber = 'MK-' . strtoupper(substr(uniqid(), 7, 5)) . '-' . rand(100, 999);
$orderDate = date('F j, Y - g:i A T');
$estimatedDelivery = date('l, F j, Y', strtotime('+3 business days'));

$subtotal = (float)($cart['subtotal'] ?? 0);
$discountAmount = (float)($cart['discountAmount'] ?? 0);
$shippingFee = (float)($cart['shippingFee'] ?? 0);
$giftWrapFee = (float)($cart['giftWrapFee'] ?? 0);
$tax = (float)($cart['tax'] ?? 0);
$grandTotal = (float)($cart['grandTotal'] ?? 0);

$orderRecord = [
    'orderId' => $orderNumber,
    'status' => 'CONFIRMED',
    'createdAt' => $orderDate,
    'estimatedDelivery' => $estimatedDelivery,
    'carrier' => 'UPS Worldwide Luxury Express (Insured)',
    'trackingNumber' => '1Z' . strtoupper(substr(md5($orderNumber), 0, 16)),
    'customer' => [
        'name' => "$firstName $lastName",
        'email' => $email,
        'shippingAddress' => [
            'street' => $address,
            'city' => $city,
            'state' => $state,
            'zip' => $zip,
            'country' => 'United States'
        ]
    ],
    'payment' => [
        'method' => $paymentMethod,
        'status' => 'PAID',
        'authCode' => 'AUTH-' . rand(100000, 999999),
        'last4' => $input['payment']['last4'] ?? '4242'
    ],
    'items' => $cart['items'] ?? [],
    'summary' => [
        'subtotal' => $subtotal,
        'discount' => $discountAmount,
        'couponCode' => $cart['couponCode'] ?? null,
        'shipping' => $shippingFee,
        'giftWrap' => $giftWrapFee,
        'tax' => $tax,
        'grandTotal' => $grandTotal
    ],
    'vipClubPointsEarned' => floor($grandTotal) * 10
];

$executionTime = round((microtime(true) - $startTime) * 1000, 2);
header("X-PHP-Execution-Time: {$executionTime}ms");

echo json_encode([
    'status' => 'success',
    'message' => 'Thank you for your order with Michael Kors. Your luxury shipment is being prepared.',
    'order' => $orderRecord,
    'phpEngine' => 'PHP ' . PHP_VERSION,
    'executionTimeMs' => $executionTime
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
