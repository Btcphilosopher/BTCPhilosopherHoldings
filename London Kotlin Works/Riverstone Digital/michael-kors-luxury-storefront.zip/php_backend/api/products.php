<?php
/**
 * Michael Kors Luxury E-Commerce Backend - Products API
 * PHP 8.2 Production REST Endpoint
 */

header('Content-Type: application/json; charset=utf-8');
header('X-Powered-By: PHP/8.2-FPM (Michael Kors Microservice)');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$startTime = microtime(true);

// Luxury Product Catalog
$products = [
    [
        'id' => 'mk-bag-01',
        'name' => 'Hamilton Legacy Large Leather Belted Satchel',
        'category' => 'bags',
        'categoryName' => 'Bags',
        'price' => 498.00,
        'originalPrice' => 558.00,
        'rating' => 4.9,
        'reviewsCount' => 142,
        'tag' => 'Best Seller',
        'colors' => [
            ['name' => 'Luggage Tan', 'hex' => '#9B5B2E', 'selected' => true],
            ['name' => 'Classic Black', 'hex' => '#1A1A1A'],
            ['name' => 'Cream White', 'hex' => '#F4EFE6']
        ],
        'sizes' => ['One Size'],
        'image' => '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png',
        'imageSlice' => 'bag',
        'gallery' => [
            '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png',
            '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png',
            '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png'
        ],
        'description' => 'A pragmatic yet glamorous satchel crafted from supple leather with statement chain-link hardware and decorative padlock pendant.',
        'details' => [
            '100% Genuine Full-Grain Calfskin Leather',
            'Gold-tone luxury hardware with polished padlock charm',
            'Dimensions: 15.5"W X 9.5"H X 6"D',
            'Adjustable cross-body shoulder strap: 18.5"-22"',
            'Interior features center zip compartment, 2 slip pockets',
            'Lining: 100% Polyester jacquard monogram'
        ],
        'craftsmanship' => 'Handcrafted in Florence atelier by master leather artisans with hand-painted raw edges.',
        'inStock' => true,
        'inventory' => 28,
        'kotlinAnimation' => [
            'type' => 'spring',
            'dampingRatio' => 0.75, // Spring.DampingRatioMediumBouncy
            'stiffness' => 300.0,   // Spring.StiffnessLow
            'spec' => 'spring(dampingRatio = 0.75f, stiffness = 300f)'
        ]
    ],
    [
        'id' => 'mk-men-01',
        'name' => 'Coastal Tailored Suede Trim Field Jacket',
        'category' => 'men',
        'categoryName' => 'Men',
        'price' => 595.00,
        'originalPrice' => 695.00,
        'rating' => 4.8,
        'reviewsCount' => 89,
        'tag' => 'Runway Edition',
        'colors' => [
            ['name' => 'Midnight Navy', 'hex' => '#1B263B', 'selected' => true],
            ['name' => 'Sand Beige', 'hex' => '#C8B89F'],
            ['name' => 'Espresso Brown', 'hex' => '#3D2B1F']
        ],
        'sizes' => ['S', 'M', 'L', 'XL', 'XXL'],
        'image' => '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png',
        'imageSlice' => 'men',
        'gallery' => [
            '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png'
        ],
        'description' => 'Sophisticated coastal outerwear cut from water-resistant technical twill with Italian suede collar trim and custom engraved snaps.',
        'details' => [
            'Fabric: 85% Technical Twill, 15% Polyurethane',
            'Suede trim collar lining sourced from Tuscany',
            'Dual zip and storm placket button front closure',
            'Four exterior patch bellows pockets with side-entry hand warmers',
            'Internal passport travel pocket with RFID security shield'
        ],
        'craftsmanship' => 'Precision cut and tailored in Milan with reinforced articulated sleeve seams.',
        'inStock' => true,
        'inventory' => 19,
        'kotlinAnimation' => [
            'type' => 'spring',
            'dampingRatio' => 0.85, // Spring.DampingRatioLowBouncy
            'stiffness' => 500.0,
            'spec' => 'spring(dampingRatio = 0.85f, stiffness = 500f)'
        ]
    ],
    [
        'id' => 'mk-shoes-01',
        'name' => 'Monique Logo Jacquard Low-Top Sneakers',
        'category' => 'shoes',
        'categoryName' => 'Shoes',
        'price' => 225.00,
        'originalPrice' => 265.00,
        'rating' => 4.9,
        'reviewsCount' => 310,
        'tag' => 'Essential',
        'colors' => [
            ['name' => 'Optic White / Gold', 'hex' => '#FFFFFF', 'selected' => true],
            ['name' => 'Soft Pink / Rose Gold', 'hex' => '#E8CCD7'],
            ['name' => 'All Black Mono', 'hex' => '#1A1A1A']
        ],
        'sizes' => ['6 US', '7 US', '8 US', '8.5 US', '9 US', '10 US'],
        'image' => '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png',
        'imageSlice' => 'shoes',
        'gallery' => [
            '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png'
        ],
        'description' => 'A sporty-luxe essential rendered in signature MK logo jacquard with smooth metallic calf leather trim and molded ergonomic footbed.',
        'details' => [
            'Upper: 67% Coated Canvas, 17% Polyester, 14% Cotton, 2% Polyurethane',
            'Lining: Breathable technical mesh and kidskin leather',
            'Sole: 100% Shock-absorbing vulcanized rubber',
            'Signature MK gold-tone heel counter plaque',
            'Molded anti-fatigue orthotic arch support'
        ],
        'craftsmanship' => 'Stitched cupsole construction engineered for all-day metropolitan comfort.',
        'inStock' => true,
        'inventory' => 42,
        'kotlinAnimation' => [
            'type' => 'spring',
            'dampingRatio' => 0.65, // Spring.DampingRatioHighBouncy
            'stiffness' => 250.0,
            'spec' => 'spring(dampingRatio = 0.65f, stiffness = 250f)'
        ]
    ],
    [
        'id' => 'mk-watches-01',
        'name' => 'Bradshaw Oversized Gold-Tone Chronograph Watch',
        'category' => 'watches',
        'categoryName' => 'Watches',
        'price' => 295.00,
        'originalPrice' => 350.00,
        'rating' => 5.0,
        'reviewsCount' => 428,
        'tag' => 'Iconic Piece',
        'colors' => [
            ['name' => '18K Yellow Gold-Tone', 'hex' => '#D4AF37', 'selected' => true],
            ['name' => 'Rose Gold-Tone', 'hex' => '#B76E79'],
            ['name' => 'Stainless Steel Silver', 'hex' => '#C0C0C0']
        ],
        'sizes' => ['43mm Case'],
        'image' => '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png',
        'imageSlice' => 'watches',
        'gallery' => [
            '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png'
        ],
        'description' => 'The definitive statement timepiece featuring architectural Roman numerals, three sub-dials, date window, and polished link bracelet.',
        'details' => [
            'Case size: 43mm stainless steel with PVD gold plating',
            'Movement: High-precision Japanese quartz chronograph',
            'Water resistance: Up to 100 meters (10 ATM)',
            'Dial: Champagne sunray with Roman numerals and stop-watch pushers',
            'Clasp: Deployant butterfly buckle closure'
        ],
        'craftsmanship' => 'Diamond-turned bezel and scratch-resistant sapphire mineral crystal coating.',
        'inStock' => true,
        'inventory' => 35,
        'kotlinAnimation' => [
            'type' => 'spring',
            'dampingRatio' => 0.8,
            'stiffness' => 400.0,
            'spec' => 'spring(dampingRatio = 0.8f, stiffness = 400f)'
        ]
    ],
    [
        'id' => 'mk-acc-01',
        'name' => 'Empire Black Acetate Cat-Eye Sunglasses',
        'category' => 'accessories',
        'categoryName' => 'Accessories',
        'price' => 179.00,
        'originalPrice' => 210.00,
        'rating' => 4.9,
        'reviewsCount' => 195,
        'tag' => 'Editorial Favorite',
        'colors' => [
            ['name' => 'Glossy Onyx Black', 'hex' => '#111111', 'selected' => true],
            ['name' => 'Havana Tortoise', 'hex' => '#5C381E'],
            ['name' => 'Milky Almond', 'hex' => '#D9C5B2']
        ],
        'sizes' => ['54-18-140 mm'],
        'image' => '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png',
        'imageSlice' => 'accessories',
        'gallery' => [
            '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png'
        ],
        'description' => 'Sculpted from hand-polished Italian Mazzucchelli acetate with gold-tone MK monogram temple hardware and 100% UVA/UVB gradient lenses.',
        'details' => [
            '100% Mazzucchelli Italian Acetate frame',
            'Lenses: Impact-resistant nylon category 3 solar filter',
            '100% UVA/UVB total spectrum radiation protection',
            'Five-barrel hinges reinforced with internal stainless steel core',
            'Includes embossed Saffiano leather hard case and microfiber cleaning cloth'
        ],
        'craftsmanship' => 'Precision hand-beveled edges and hand-mounted temple hardware.',
        'inStock' => true,
        'inventory' => 50,
        'kotlinAnimation' => [
            'type' => 'spring',
            'dampingRatio' => 0.7,
            'stiffness' => 350.0,
            'spec' => 'spring(dampingRatio = 0.7f, stiffness = 350f)'
        ]
    ],
    [
        'id' => 'mk-col-01',
        'name' => 'Michael Kors Collection Italian Leather Moto Coat',
        'category' => 'collections',
        'categoryName' => 'Collections',
        'price' => 1290.00,
        'originalPrice' => 1450.00,
        'rating' => 5.0,
        'reviewsCount' => 64,
        'tag' => 'Limited Runway',
        'colors' => [
            ['name' => 'Jet Black Glaze', 'hex' => '#0A0A0A', 'selected' => true],
            ['name' => 'Cognac Brown', 'hex' => '#7A3816']
        ],
        'sizes' => ['XS', 'S', 'M', 'L'],
        'image' => '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png',
        'imageSlice' => 'collections',
        'gallery' => [
            '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png'
        ],
        'description' => 'The crown jewel of the Fall Runway: an architectural moto coat cut from buttery Italian glove leather with sharp notched lapels and custom metal hardware.',
        'details' => [
            '100% Italian Glove Lambskin Leather',
            'Lining: 100% Silk Cupro with Michael Kors signature script',
            'Asymmetric heavy-gauge nickel zipper with pull tab',
            'Belted waist with polished square roller buckle',
            'Specialist leather dry clean only'
        ],
        'craftsmanship' => 'Tailored in limited numbered production in our historic studio in Naples.',
        'inStock' => true,
        'inventory' => 12,
        'kotlinAnimation' => [
            'type' => 'spring',
            'dampingRatio' => 0.8,
            'stiffness' => 280.0,
            'spec' => 'spring(dampingRatio = 0.8f, stiffness = 280f)'
        ]
    ],
    [
        'id' => 'mk-bag-02',
        'name' => 'Parker Medium Empire Logo Leather Shoulder Bag',
        'category' => 'bags',
        'categoryName' => 'Bags',
        'price' => 398.00,
        'originalPrice' => 448.00,
        'rating' => 4.9,
        'reviewsCount' => 218,
        'tag' => 'New Season',
        'colors' => [
            ['name' => 'Vanilla Monogram', 'hex' => '#EAE5D9', 'selected' => true],
            ['name' => 'Luggage Tan', 'hex' => '#9B5B2E'],
            ['name' => 'Noir Black', 'hex' => '#111111']
        ],
        'sizes' => ['Medium'],
        'image' => '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png',
        'imageSlice' => 'hero',
        'gallery' => [
            '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png'
        ],
        'description' => 'Showcased in the Mediterranean yacht campaign: featuring bold Empire hardware, streamlined silhouette, and dual interchangeable leather and chain straps.',
        'details' => [
            'Coated twill canvas with 100% leather trim',
            'Fold-over flap with magnetic snap and Empire buckle',
            'Adjustable chain & leather strap: 21.5"',
            'Exterior back slip pocket with magnetic fastener',
            'Dimensions: 10.75"W X 6.25"H X 4"D'
        ],
        'craftsmanship' => 'Engineered with reinforced structured gussets to retain its silhouette over time.',
        'inStock' => true,
        'inventory' => 34,
        'kotlinAnimation' => [
            'type' => 'spring',
            'dampingRatio' => 0.75,
            'stiffness' => 320.0,
            'spec' => 'spring(dampingRatio = 0.75f, stiffness = 320f)'
        ]
    ],
    [
        'id' => 'mk-shoes-02',
        'name' => 'Kerrigan Metallic Napa Leather Stiletto Pump',
        'category' => 'shoes',
        'categoryName' => 'Shoes',
        'price' => 285.00,
        'originalPrice' => 325.00,
        'rating' => 4.8,
        'reviewsCount' => 77,
        'tag' => 'Evening Edit',
        'colors' => [
            ['name' => 'Pale Gold Foil', 'hex' => '#E5C158', 'selected' => true],
            ['name' => 'Liquid Silver', 'hex' => '#D8D8D8'],
            ['name' => 'Patent Black', 'hex' => '#0A0A0A']
        ],
        'sizes' => ['6 US', '6.5 US', '7 US', '7.5 US', '8 US', '8.5 US', '9 US'],
        'image' => '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png',
        'imageSlice' => 'shoes',
        'gallery' => [
            '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png'
        ],
        'description' => 'A sculptural 95mm stiletto pump crafted from foil-laminated napa leather with a clean pointed toe and signature cushioned footbed.',
        'details' => [
            '100% Metallic Napa Lambskin Leather',
            'Heel height: 95mm (3.75 inches)',
            'Pointed toe with deep low-cut vamp',
            'Smooth buffed leather outsole with engraved logo',
            'Made in Italy'
        ],
        'craftsmanship' => 'Hand-buffed outsole and triple-cushioned insole pad for evening wear.',
        'inStock' => true,
        'inventory' => 15,
        'kotlinAnimation' => [
            'type' => 'spring',
            'dampingRatio' => 0.72,
            'stiffness' => 310.0,
            'spec' => 'spring(dampingRatio = 0.72f, stiffness = 310f)'
        ]
    ]
];

// Read request parameters
$category = isset($_GET['category']) ? strtolower(trim($_GET['category'])) : '';
$search = isset($_GET['search']) ? strtolower(trim($_GET['search'])) : '';
$sort = isset($_GET['sort']) ? trim($_GET['sort']) : 'featured';
$id = isset($_GET['id']) ? trim($_GET['id']) : '';

// Handle single product query
if (!empty($id)) {
    foreach ($products as $p) {
        if ($p['id'] === $id) {
            $executionTime = round((microtime(true) - $startTime) * 1000, 2);
            header("X-PHP-Execution-Time: {$executionTime}ms");
            echo json_encode([
                'status' => 'success',
                'data' => $p,
                'phpEngine' => 'PHP ' . PHP_VERSION,
                'executionTimeMs' => $executionTime
            ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
            exit;
        }
    }
    http_response_code(404);
    echo json_encode(['status' => 'error', 'message' => 'Product not found', 'phpEngine' => 'PHP ' . PHP_VERSION]);
    exit;
}

// Filter by category
$filtered = $products;
if (!empty($category) && $category !== 'all') {
    $filtered = array_values(array_filter($filtered, function($item) use ($category) {
        return strtolower($item['category']) === $category;
    }));
}

// Filter by search query
if (!empty($search)) {
    $filtered = array_values(array_filter($filtered, function($item) use ($search) {
        return str_contains(strtolower($item['name']), $search) ||
               str_contains(strtolower($item['description']), $search) ||
               str_contains(strtolower($item['categoryName']), $search);
    }));
}

// Sorting
if ($sort === 'price_asc') {
    usort($filtered, fn($a, $b) => $a['price'] <=> $b['price']);
} elseif ($sort === 'price_desc') {
    usort($filtered, fn($a, $b) => $b['price'] <=> $a['price']);
} elseif ($sort === 'rating') {
    usort($filtered, fn($a, $b) => $b['rating'] <=> $a['rating']);
}

$executionTime = round((microtime(true) - $startTime) * 1000, 2);
header("X-PHP-Execution-Time: {$executionTime}ms");

echo json_encode([
    'status' => 'success',
    'total' => count($filtered),
    'filters' => [
        'category' => $category ?: 'all',
        'search' => $search,
        'sort' => $sort
    ],
    'data' => $filtered,
    'categories' => [
        ['slug' => 'all', 'label' => 'All Pieces', 'count' => count($products)],
        ['slug' => 'bags', 'label' => 'Bags', 'count' => 2],
        ['slug' => 'men', 'label' => 'Men', 'count' => 1],
        ['slug' => 'shoes', 'label' => 'Shoes', 'count' => 2],
        ['slug' => 'watches', 'label' => 'Watches', 'count' => 1],
        ['slug' => 'accessories', 'label' => 'Accessories', 'count' => 1],
        ['slug' => 'collections', 'label' => 'Collections', 'count' => 1]
    ],
    'phpEngine' => 'PHP ' . PHP_VERSION,
    'executionTimeMs' => $executionTime,
    'timestamp' => date('Y-m-d H:i:s T')
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
