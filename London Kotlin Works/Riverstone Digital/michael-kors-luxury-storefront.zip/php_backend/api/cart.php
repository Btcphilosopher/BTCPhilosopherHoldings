<?php
/**
 * Michael Kors Luxury E-Commerce Backend - Cart Management API
 * PHP 8.2 Production REST Endpoint with promo codes and luxury gift packaging logic
 */

header('Content-Type: application/json; charset=utf-8');
header('X-Powered-By: PHP/8.2-FPM (Michael Kors Microservice)');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$startTime = microtime(true);

// Read raw body if POST
$rawInput = file_get_contents('php://input');
$input = json_decode($rawInput, true) ?? [];

$action = $input['action'] ?? $_GET['action'] ?? 'get';
$sessionId = $input['sessionId'] ?? $_GET['sessionId'] ?? 'mk_session_default';

// Session cart file
$sessionSafe = preg_replace('/[^a-zA-Z0-9_-]/', '', $sessionId);
$cartDir = sys_get_temp_dir() . '/mk_carts';
if (!is_dir($cartDir)) {
    @mkdir($cartDir, 0777, true);
}
$cartFile = $cartDir . '/' . ($sessionSafe ?: 'default') . '.json';

$cart = [
    'items' => [],
    'couponCode' => null,
    'discountPercent' => 0,
    'giftWrap' => false
];

if (file_exists($cartFile)) {
    $existing = json_decode(file_get_contents($cartFile), true);
    if (is_array($existing)) {
        $cart = array_merge($cart, $existing);
    }
}

// Coupons dictionary
$coupons = [
    'MKLUXURY' => ['discount' => 15, 'desc' => '15% Off VIP Member Luxury Access'],
    'FALL20'   => ['discount' => 20, 'desc' => '20% Off Fall Campaign Preview'],
    'FREESHIP' => ['discount' => 0,  'freeShip' => true, 'desc' => 'Complimentary White-Glove Shipping']
];

switch ($action) {
    case 'add':
        $item = $input['item'] ?? null;
        if ($item && !empty($item['id'])) {
            $found = false;
            foreach ($cart['items'] as &$ci) {
                if ($ci['id'] === $item['id'] && 
                    ($ci['selectedColor'] ?? '') === ($item['selectedColor'] ?? '') &&
                    ($ci['selectedSize'] ?? '') === ($item['selectedSize'] ?? '')) {
                    $ci['quantity'] = ($ci['quantity'] ?? 1) + ($item['quantity'] ?? 1);
                    $found = true;
                    break;
                }
            }
            if (!$found) {
                $item['quantity'] = $item['quantity'] ?? 1;
                $cart['items'][] = $item;
            }
        }
        break;

    case 'update':
        $itemId = $input['id'] ?? '';
        $quantity = (int)($input['quantity'] ?? 1);
        $color = $input['selectedColor'] ?? null;
        $size = $input['selectedSize'] ?? null;
        
        foreach ($cart['items'] as $idx => &$ci) {
            if ($ci['id'] === $itemId) {
                if ($quantity <= 0) {
                    unset($cart['items'][$idx]);
                } else {
                    $ci['quantity'] = $quantity;
                }
                break;
            }
        }
        $cart['items'] = array_values($cart['items']);
        break;

    case 'remove':
        $itemId = $input['id'] ?? '';
        $cart['items'] = array_values(array_filter($cart['items'], function($ci) use ($itemId) {
            return $ci['id'] !== $itemId;
        }));
        break;

    case 'apply_coupon':
        $code = strtoupper(trim($input['code'] ?? ''));
        if (isset($coupons[$code])) {
            $cart['couponCode'] = $code;
            $cart['discountPercent'] = $coupons[$code]['discount'] ?? 0;
            $cart['couponDescription'] = $coupons[$code]['desc'] ?? '';
        } else {
            $errorCoupon = "Invalid promotional code '$code'. Try code 'MKLUXURY' for 15% off.";
        }
        break;

    case 'remove_coupon':
        $cart['couponCode'] = null;
        $cart['discountPercent'] = 0;
        unset($cart['couponDescription']);
        break;

    case 'toggle_giftwrap':
        $cart['giftWrap'] = !($cart['giftWrap'] ?? false);
        break;

    case 'clear':
        $cart['items'] = [];
        $cart['couponCode'] = null;
        $cart['discountPercent'] = 0;
        $cart['giftWrap'] = false;
        break;
}

// Calculate totals
$subtotal = 0;
$itemCount = 0;
foreach ($cart['items'] as $item) {
    $qty = (int)($item['quantity'] ?? 1);
    $subtotal += ((float)($item['price'] ?? 0)) * $qty;
    $itemCount += $qty;
}

$discountAmount = 0;
if (!empty($cart['couponCode']) && $cart['discountPercent'] > 0) {
    $discountAmount = round(($subtotal * $cart['discountPercent']) / 100, 2);
}

$freeShippingThreshold = 150.00;
$hasFreeShipCode = ($cart['couponCode'] ?? '') === 'FREESHIP';
$shippingFee = ($subtotal >= $freeShippingThreshold || $hasFreeShipCode || $subtotal === 0) ? 0.00 : 15.00;
$freeShippingProgress = min(100, round(($subtotal / $freeShippingThreshold) * 100, 1));
$amountUntilFreeShipping = max(0, round($freeShippingThreshold - $subtotal, 2));

$giftWrapFee = (!empty($cart['giftWrap']) && $subtotal < 300) ? 10.00 : 0.00;
$taxRate = 0.0825; // 8.25% luxury sales tax
$taxableBase = max(0, $subtotal - $discountAmount);
$tax = round($taxableBase * $taxRate, 2);
$grandTotal = round($taxableBase + $shippingFee + $giftWrapFee + $tax, 2);

$cartCalculated = [
    'sessionId' => $sessionId,
    'items' => $cart['items'],
    'itemCount' => $itemCount,
    'subtotal' => round($subtotal, 2),
    'discountPercent' => $cart['discountPercent'],
    'discountAmount' => $discountAmount,
    'couponCode' => $cart['couponCode'],
    'couponDescription' => $cart['couponDescription'] ?? null,
    'shippingFee' => $shippingFee,
    'isFreeShipping' => $shippingFee === 0.00,
    'freeShippingThreshold' => $freeShippingThreshold,
    'freeShippingProgress' => $freeShippingProgress,
    'amountUntilFreeShipping' => $amountUntilFreeShipping,
    'giftWrap' => $cart['giftWrap'],
    'giftWrapFee' => $giftWrapFee,
    'taxRate' => $taxRate,
    'tax' => $tax,
    'grandTotal' => $grandTotal
];

// Persist cart
@file_put_contents($cartFile, json_encode($cart));

$executionTime = round((microtime(true) - $startTime) * 1000, 2);
header("X-PHP-Execution-Time: {$executionTime}ms");

echo json_encode([
    'status' => 'success',
    'cart' => $cartCalculated,
    'couponError' => $errorCoupon ?? null,
    'phpEngine' => 'PHP ' . PHP_VERSION,
    'executionTimeMs' => $executionTime
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
