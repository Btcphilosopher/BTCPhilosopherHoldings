export interface ProductColor {
  name: string;
  hex: string;
  selected?: boolean;
}

export interface Product {
  id: string;
  name: string;
  category: 'bags' | 'men' | 'shoes' | 'watches' | 'accessories' | 'collections';
  categoryName: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewsCount: number;
  tag?: string;
  colors: ProductColor[];
  sizes: string[];
  image: string;
  imageSlice?: string;
  gallery: string[];
  description: string;
  details: string[];
  craftsmanship: string;
  inStock: boolean;
  inventory: number;
  kotlinAnimation: {
    type: string;
    dampingRatio: number;
    stiffness: number;
    spec: string;
  };
}

export interface CartItem extends Product {
  selectedColor: string;
  selectedSize: string;
  quantity: number;
}

export interface CartState {
  sessionId: string;
  items: CartItem[];
  itemCount: number;
  subtotal: number;
  discountPercent: number;
  discountAmount: number;
  couponCode: string | null;
  couponDescription?: string | null;
  shippingFee: number;
  isFreeShipping: boolean;
  freeShippingThreshold: number;
  freeShippingProgress: number;
  amountUntilFreeShipping: number;
  giftWrap: boolean;
  giftWrapFee: number;
  taxRate: number;
  tax: number;
  grandTotal: number;
}

export interface OrderConfirmation {
  orderId: string;
  status: string;
  createdAt: string;
  estimatedDelivery: string;
  carrier: string;
  trackingNumber: string;
  customer: {
    name: string;
    email: string;
    shippingAddress: {
      street: string;
      city: string;
      state: string;
      zip: string;
      country: string;
    };
  };
  payment: {
    method: string;
    status: string;
    authCode: string;
    last4: string;
  };
  items: CartItem[];
  summary: {
    subtotal: number;
    discount: number;
    couponCode: string | null;
    shipping: number;
    giftWrap: number;
    tax: number;
    grandTotal: number;
  };
  vipClubPointsEarned: number;
}

export interface KotlinPhysicsPreset {
  id: string;
  name: string;
  dampingRatio: number; // zeta
  stiffness: number;    // k
  composeSpec: string;
  description: string;
}
