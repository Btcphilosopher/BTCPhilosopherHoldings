import { KotlinPhysicsPreset } from './types';

/**
 * Kotlin Jetpack Compose Spring Physics Presets
 * Mirrors androidx.compose.animation.core.Spring constants
 */
export const KOTLIN_PRESETS: Record<string, KotlinPhysicsPreset> = {
  luxury_smooth: {
    id: 'luxury_smooth',
    name: 'MK Luxury Smooth (Default)',
    dampingRatio: 0.82, // Spring.DampingRatioLowBouncy (~0.85f)
    stiffness: 300,     // Spring.StiffnessLow (300f)
    composeSpec: 'spring(dampingRatio = 0.82f, stiffness = 300f)',
    description: 'Weighted luxury movement reminiscent of rich calfskin leather, gold hardware, and high-fashion grace.'
  },
  medium_bouncy: {
    id: 'medium_bouncy',
    name: 'Snappy Spring Interaction',
    dampingRatio: 0.72, // Spring.DampingRatioMediumBouncy (0.75f)
    stiffness: 450,     // Spring.StiffnessMedium (1500f scaled for web)
    composeSpec: 'spring(dampingRatio = 0.72f, stiffness = 450f)',
    description: 'Crisp micro-interactions for button presses, drawer reveals, and quick bag additions.'
  },
  playful_sneaker: {
    id: 'playful_sneaker',
    name: 'Playful Sneaker Bounce',
    dampingRatio: 0.52, // Spring.DampingRatioHighBouncy (0.5f)
    stiffness: 220,     // Spring.StiffnessLow (220f)
    composeSpec: 'spring(dampingRatio = 0.52f, stiffness = 220f)',
    description: 'High-elasticity bounce engineered for sporty luxury sneakers and badge popups.'
  },
  critically_damped: {
    id: 'critically_damped',
    name: 'Critically Damped Luxury Slide',
    dampingRatio: 1.0,  // Spring.DampingRatioNoBouncy (1.0f)
    stiffness: 400,     // Spring.StiffnessMedium
    composeSpec: 'spring(dampingRatio = 1.0f, stiffness = 400f)',
    description: 'Zero overshoot, silky glide for editorial full-screen hero sliders and modal overlays.'
  }
};

/**
 * Convert Jetpack Compose dampingRatio (zeta) and stiffness (k) to Framer Motion spring config
 * Physics:
 *   c = 2 * zeta * sqrt(k * m), with m = 1
 *   motion: { type: 'spring', stiffness: k, damping: c, mass: 1 }
 */
export function kotlinToMotionSpring(dampingRatio: number, stiffness: number, mass = 1) {
  const damping = 2 * dampingRatio * Math.sqrt(stiffness * mass);
  return {
    type: 'spring' as const,
    stiffness: Math.round(stiffness),
    damping: Math.round(damping * 10) / 10,
    mass,
  };
}

/**
 * Generate Kotlin Multiplatform / Jetpack Compose code representation
 */
export function generateKotlinCodeForComponent(
  componentName: string,
  preset: KotlinPhysicsPreset,
  extraParams: Record<string, string | number> = {}
): string {
  return `// ============================================================================
// Kotlin Multiplatform 2.0 / Jetpack Compose for Android & Web
// Package: com.michaelkors.luxury.ui.animation
// ============================================================================

package com.michaelkors.luxury.ui.animation

import androidx.compose.animation.core.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.unit.dp

/**
 * ${componentName} with Kotlin Spring Physics
 * Preset: ${preset.name}
 * Spec: ${preset.composeSpec}
 */
@Composable
fun ${componentName}(
    isInteracted: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    // Jetpack Compose Physics Animation Spec
    val springSpec = remember {
        spring<Float>(
            dampingRatio = ${preset.dampingRatio}f,
            stiffness = ${preset.stiffness}f,
            visibilityThreshold = 0.001f
        )
    }

    val animatedScale by animateFloatAsState(
        targetValue = if (isInteracted) 1.04f else 1.0f,
        animationSpec = springSpec,
        label = "${componentName}Scale"
    )

    val animatedElevation by animateDpAsState(
        targetValue = if (isInteracted) 16.dp else 2.dp,
        animationSpec = spring(
            dampingRatio = ${preset.dampingRatio}f,
            stiffness = ${preset.stiffness}f
        ),
        label = "${componentName}Elevation"
    )

    Box(
        modifier = modifier
            .scale(animatedScale)
            .shadow(elevation = animatedElevation)
    ) {
        content()
    }
}
`;
}
