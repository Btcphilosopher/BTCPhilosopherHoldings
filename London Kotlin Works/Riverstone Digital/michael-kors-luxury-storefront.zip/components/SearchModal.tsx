'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Search, X, ArrowRight, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Product } from '@/lib/types';
import { kotlinToMotionSpring } from '@/lib/kotlin-physics';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onSelectProduct: (product: Product) => void;
}

const POPULAR_SEARCHES = [
  'Hamilton Satchel',
  'Gold Chronograph Watch',
  'Runway Moto Coat',
  'Monique Sneaker',
  'Cat-Eye Sunglasses',
  'Men Coastal Jacket',
];

export default function SearchModal({
  isOpen,
  onClose,
  products,
  onSelectProduct,
}: SearchModalProps) {
  const [searchQuery, setSearchQuery] = useState('');

  if (!isOpen) return null;

  const filtered = products.filter((p) => {
    if (!searchQuery.trim()) return false;
    const q = searchQuery.toLowerCase();
    return (
      p.name.toLowerCase().includes(q) ||
      p.categoryName.toLowerCase().includes(q) ||
      p.description.toLowerCase().includes(q)
    );
  });

  const modalSpring = kotlinToMotionSpring(0.85, 380);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-start justify-center pt-16 sm:pt-24 px-4">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        transition={modalSpring}
        className="relative w-full max-w-3xl bg-white shadow-2xl border border-neutral-200 overflow-hidden rounded-sm"
      >
        {/* Search Input Bar */}
        <div className="p-4 sm:p-6 border-b border-neutral-200 flex items-center gap-4 bg-[#FAF8F5]">
          <Search className="w-5 h-5 text-neutral-400 shrink-0" />
          <input
            type="text"
            autoFocus
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search handbags, watches, shoes, runway collections..."
            className="w-full bg-transparent text-sm sm:text-base font-medium text-neutral-900 focus:outline-none placeholder:text-neutral-400"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="p-1 text-neutral-400 hover:text-black"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="text-xs font-semibold uppercase tracking-wider text-neutral-500 hover:text-black ml-2"
          >
            ESC
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 max-h-[70vh] overflow-y-auto">
          {!searchQuery.trim() ? (
            <div>
              <p className="text-xs font-bold uppercase tracking-widest text-neutral-400 mb-3">
                Trending Inquiries
              </p>
              <div className="flex flex-wrap gap-2">
                {POPULAR_SEARCHES.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => setSearchQuery(tag)}
                    className="px-3.5 py-1.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-medium rounded-full transition-colors cursor-pointer"
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div>
              <div className="flex items-center justify-between text-xs text-neutral-500 mb-4 font-mono">
                <span>Found {filtered.length} matching pieces</span>
                <span>Indexed via PHP 8.2</span>
              </div>

              {filtered.length === 0 ? (
                <div className="text-center py-8 text-neutral-500">
                  <p className="text-sm font-semibold text-neutral-800 mb-1">
                    No results found for &ldquo;{searchQuery}&rdquo;
                  </p>
                  <p className="text-xs text-neutral-500">
                    Try searching for &ldquo;bags&rdquo;, &ldquo;gold&rdquo;, or &ldquo;leather&rdquo;.
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-neutral-100">
                  {filtered.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => {
                        onSelectProduct(item);
                        onClose();
                      }}
                      className="py-3 flex items-center justify-between gap-4 hover:bg-neutral-50 p-2 rounded cursor-pointer transition-colors group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-14 bg-neutral-100 border border-neutral-200 relative overflow-hidden shrink-0">
                          <Image
                            src={item.image}
                            alt={item.name}
                            fill
                            sizes="48px"
                            referrerPolicy="no-referrer"
                            className="object-cover"
                            style={{
                              objectPosition:
                                item.imageSlice === 'bag'
                                  ? '8% 66%'
                                  : item.imageSlice === 'men'
                                  ? '27% 66%'
                                  : item.imageSlice === 'shoes'
                                  ? '42% 66%'
                                  : item.imageSlice === 'watches'
                                  ? '58% 66%'
                                  : item.imageSlice === 'accessories'
                                  ? '73% 66%'
                                  : 'center 20%',
                              transform: 'scale(1.9)',
                            }}
                          />
                        </div>
                        <div>
                          <p className="text-[10px] text-neutral-400 uppercase tracking-widest font-semibold">
                            {item.categoryName}
                          </p>
                          <h4 className="text-xs sm:text-sm font-semibold text-neutral-900 group-hover:text-black">
                            {item.name}
                          </h4>
                          <span className="text-xs font-mono font-bold text-neutral-800">
                            ${item.price.toFixed(2)}
                          </span>
                        </div>
                      </div>

                      <div className="text-neutral-400 group-hover:text-black pr-2">
                        <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
