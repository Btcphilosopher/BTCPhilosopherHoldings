'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { X, ShoppingBag, Trash2, ArrowRight, Gift, Tag, Check, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CartState, CartItem } from '@/lib/types';
import { kotlinToMotionSpring } from '@/lib/kotlin-physics';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartState;
  onUpdateQuantity: (id: string, qty: number, color?: string, size?: string) => void;
  onRemoveItem: (id: string) => void;
  onApplyCoupon: (code: string) => void;
  onRemoveCoupon: () => void;
  onToggleGiftWrap: () => void;
  onProceedToCheckout: () => void;
  couponError?: string | null;
}

export default function CartDrawer({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onApplyCoupon,
  onRemoveCoupon,
  onToggleGiftWrap,
  onProceedToCheckout,
  couponError,
}: CartDrawerProps) {
  const [promoInput, setPromoInput] = useState('');

  const drawerSpring = kotlinToMotionSpring(0.85, 360);

  const handleCouponSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (promoInput.trim()) {
      onApplyCoupon(promoInput.trim());
      setPromoInput('');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-xs flex justify-end">
      <motion.div
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={drawerSpring}
        className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between"
      >
        {/* Header */}
        <div className="p-5 border-b border-neutral-200 flex items-center justify-between bg-[#FAF8F5]">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-neutral-900" />
            <h2 className="text-sm font-extrabold uppercase tracking-[0.18em] text-neutral-900 font-sans">
              Shopping Bag ({cart.itemCount})
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-500 hover:text-black rounded-full hover:bg-neutral-200/50 transition-colors cursor-pointer"
            aria-label="Close shopping bag"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Shipping Progress Indicator */}
        <div className="p-4 bg-amber-50/70 border-b border-amber-100 text-xs">
          {cart.isFreeShipping ? (
            <div className="flex items-center gap-2 text-emerald-800 font-medium">
              <Check className="w-4 h-4 text-emerald-600" />
              <span>You have unlocked complimentary white-glove shipping!</span>
            </div>
          ) : (
            <div>
              <div className="flex justify-between font-medium text-neutral-800 mb-1.5">
                <span>Add ${cart.amountUntilFreeShipping.toFixed(2)} more for Free Shipping</span>
                <span className="font-mono">{cart.freeShippingProgress}%</span>
              </div>
              <div className="w-full h-1.5 bg-neutral-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-neutral-900 transition-all duration-300"
                  style={{ width: `${cart.freeShippingProgress}%` }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Line Items List */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {cart.items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-neutral-500">
              <ShoppingBag className="w-12 h-12 stroke-1 text-neutral-300 mb-3" />
              <p className="text-sm font-semibold uppercase tracking-wider text-neutral-800 mb-1">
                Your Shopping Bag is Empty
              </p>
              <p className="text-xs text-neutral-500 max-w-xs mb-6">
                Explore the latest Italian leather handbags, watches, and runway tailoring.
              </p>
              <button
                onClick={onClose}
                className="px-6 py-2.5 bg-neutral-950 text-white text-xs font-bold tracking-widest uppercase hover:bg-neutral-800 transition-colors"
              >
                Continue Shopping
              </button>
            </div>
          ) : (
            cart.items.map((item) => (
              <div
                key={`${item.id}-${item.selectedColor}-${item.selectedSize}`}
                className="flex gap-4 p-3 bg-neutral-50 border border-neutral-200/80 rounded-sm relative group"
              >
                {/* Thumbnail */}
                <div className="w-20 h-24 bg-white border border-neutral-200 relative overflow-hidden shrink-0">
                  <Image
                    src={item.image}
                    alt={item.name}
                    fill
                    sizes="80px"
                    referrerPolicy="no-referrer"
                    className="object-cover"
                    style={{
                      objectPosition:
                        item.imageSlice === 'bag'
                          ? '8% 66%'
                          : item.imageSlice === 'men'
                          ? '27% 66%'
                          : item.imageSlice === 'shoes'
                          ? '42% 66%'
                          : item.imageSlice === 'watches'
                          ? '58% 66%'
                          : item.imageSlice === 'accessories'
                          ? '73% 66%'
                          : 'center 20%',
                      transform: 'scale(1.9)',
                    }}
                  />
                </div>

                {/* Details */}
                <div className="flex-1 flex flex-col justify-between text-xs">
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="font-semibold text-neutral-900 leading-snug line-clamp-1">
                        {item.name}
                      </h3>
                      <button
                        onClick={() => onRemoveItem(item.id)}
                        className="text-neutral-400 hover:text-red-600 transition-colors p-1"
                        title="Remove item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="text-[11px] text-neutral-500 space-y-0.5 mt-1">
                      <p>Shade: <span className="text-neutral-800 font-medium">{item.selectedColor}</span></p>
                      <p>Size: <span className="text-neutral-800 font-medium">{item.selectedSize}</span></p>
                    </div>
                  </div>

                  {/* Quantity Stepper & Price */}
                  <div className="flex items-center justify-between pt-2 border-t border-neutral-200/60 mt-2">
                    <div className="flex items-center border border-neutral-300 bg-white">
                      <button
                        onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                        className="px-2 py-0.5 text-xs text-neutral-700 hover:bg-neutral-100"
                      >
                        -
                      </button>
                      <span className="px-2 text-[11px] font-mono font-bold">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                        className="px-2 py-0.5 text-xs text-neutral-700 hover:bg-neutral-100"
                      >
                        +
                      </button>
                    </div>

                    <span className="font-mono font-bold text-neutral-900 tabular-nums">
                      ${(item.price * item.quantity).toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer Summary & Checkout */}
        {cart.items.length > 0 && (
          <div className="p-5 border-t border-neutral-200 bg-[#FAF8F5] space-y-3">
            {/* Luxury Gift Wrap Toggle */}
            <div className="flex items-center justify-between p-2.5 bg-white border border-neutral-200 rounded text-xs">
              <label className="flex items-center gap-2 cursor-pointer text-neutral-800">
                <input
                  type="checkbox"
                  checked={cart.giftWrap}
                  onChange={onToggleGiftWrap}
                  className="rounded text-neutral-900 focus:ring-neutral-900"
                />
                <Gift className="w-4 h-4 text-amber-700" />
                <span>Signature Gold-Embossed Gift Box</span>
              </label>
              <span className="font-mono text-neutral-600">
                {cart.giftWrapFee === 0 ? 'FREE' : `$${cart.giftWrapFee.toFixed(2)}`}
              </span>
            </div>

            {/* Promo Code Input */}
            <form onSubmit={handleCouponSubmit} className="flex gap-2">
              <div className="relative flex-1">
                <Tag className="w-3.5 h-3.5 text-neutral-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={promoInput}
                  onChange={(e) => setPromoInput(e.target.value)}
                  placeholder="Promo Code (e.g. MKLUXURY)"
                  className="w-full bg-white border border-neutral-200 pl-8 pr-3 py-1.5 text-xs uppercase tracking-wider rounded-sm focus:outline-none focus:border-neutral-900 font-mono"
                />
              </div>
              <button
                type="submit"
                className="px-3 py-1.5 bg-neutral-800 text-white text-xs font-bold tracking-wider uppercase hover:bg-black transition-colors rounded-sm cursor-pointer"
              >
                Apply
              </button>
            </form>

            {/* Active Coupon Tag */}
            {cart.couponCode && (
              <div className="flex items-center justify-between text-xs bg-emerald-50 text-emerald-800 p-2 rounded border border-emerald-200">
                <span className="font-bold">Code applied: {cart.couponCode} ({cart.discountPercent}% OFF)</span>
                <button
                  onClick={onRemoveCoupon}
                  className="text-emerald-900 hover:text-red-600 font-bold ml-2 underline"
                >
                  Remove
                </button>
              </div>
            )}

            {couponError && (
              <div className="flex items-center gap-1.5 text-xs text-red-600 bg-red-50 p-2 rounded border border-red-200">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{couponError}</span>
              </div>
            )}

            {/* Subtotal Calculations */}
            <div className="space-y-1.5 text-xs pt-2 border-t border-neutral-200 text-neutral-600">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-mono font-medium text-neutral-900">${cart.subtotal.toFixed(2)}</span>
              </div>

              {cart.discountAmount > 0 && (
                <div className="flex justify-between text-emerald-700 font-medium">
                  <span>VIP Privilege Discount</span>
                  <span className="font-mono">-${cart.discountAmount.toFixed(2)}</span>
                </div>
              )}

              <div className="flex justify-between">
                <span>Insured Courier Shipping</span>
                <span className="font-mono text-neutral-900">
                  {cart.shippingFee === 0 ? 'COMPLIMENTARY' : `$${cart.shippingFee.toFixed(2)}`}
                </span>
              </div>

              {cart.giftWrapFee > 0 && (
                <div className="flex justify-between">
                  <span>Gift Box & Ribbon</span>
                  <span className="font-mono text-neutral-900">${cart.giftWrapFee.toFixed(2)}</span>
                </div>
              )}

              <div className="flex justify-between">
                <span>Estimated Sales Tax (8.25%)</span>
                <span className="font-mono text-neutral-900">${cart.tax.toFixed(2)}</span>
              </div>

              <div className="flex justify-between text-sm font-extrabold text-neutral-950 pt-2 border-t border-neutral-300">
                <span>Total Amount</span>
                <span className="font-mono text-base">${cart.grandTotal.toFixed(2)}</span>
              </div>
            </div>

            {/* Checkout Button */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={onProceedToCheckout}
              className="w-full py-3.5 bg-neutral-950 text-white font-extrabold text-xs tracking-[0.2em] uppercase hover:bg-neutral-800 transition-all flex items-center justify-center gap-2 shadow-lg cursor-pointer"
            >
              <span>PROCEED TO SECURE CHECKOUT</span>
              <ArrowRight className="w-4 h-4" />
            </motion.button>

            <p className="text-[10px] text-center text-neutral-400 uppercase tracking-widest font-mono">
              Managed by PHP 8.2 Microservice · 256-Bit SSL Encryption
            </p>
          </div>
        )}
      </motion.div>
    </div>
  );
}
