'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Heart, ShoppingBag, Eye, RotateCw, Sparkles, Star, Check } from 'lucide-react';
import { motion } from 'motion/react';
import { Product } from '@/lib/types';
import { kotlinToMotionSpring } from '@/lib/kotlin-physics';

interface ProductCatalogProps {
  products: Product[];
  activeCategory: string;
  onSelectCategory: (category: string) => void;
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product, colorName?: string, size?: string) => void;
  onToggleWishlist: (product: Product) => void;
  wishlistIds: string[];
  phpExecutionTimeMs?: number;
}

export default function ProductCatalog({
  products,
  activeCategory,
  onSelectCategory,
  onQuickView,
  onAddToCart,
  onToggleWishlist,
  wishlistIds,
  phpExecutionTimeMs,
}: ProductCatalogProps) {
  const [sortBy, setSortBy] = useState<'featured' | 'price_asc' | 'price_desc' | 'rating'>('featured');
  const [addedProductId, setAddedProductId] = useState<string | null>(null);

  // Filter products by category
  const filteredProducts = products.filter((p) => {
    if (activeCategory === 'all') return true;
    return p.category === activeCategory;
  });

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortBy === 'price_asc') return a.price - b.price;
    if (sortBy === 'price_desc') return b.price - a.price;
    if (sortBy === 'rating') return b.rating - a.rating;
    return 0; // default featured
  });

  const categoriesList = [
    { id: 'all', label: 'All Pieces' },
    { id: 'bags', label: 'Bags' },
    { id: 'men', label: 'Men' },
    { id: 'shoes', label: 'Shoes' },
    { id: 'watches', label: 'Watches' },
    { id: 'accessories', label: 'Accessories' },
    { id: 'collections', label: 'Collections' },
  ];

  const handleQuickAdd = (product: Product) => {
    const defaultColor = product.colors.find((c) => c.selected)?.name || product.colors[0]?.name || 'Standard';
    const defaultSize = product.sizes[0] || 'One Size';
    onAddToCart(product, defaultColor, defaultSize);
    setAddedProductId(product.id);
    setTimeout(() => setAddedProductId(null), 1800);
  };

  // Kotlin spring curves
  const cardSpring = kotlinToMotionSpring(0.75, 300);
  const heartSpring = kotlinToMotionSpring(0.55, 400);

  return (
    <section id="catalog-section" className="py-16 sm:py-24 bg-[#FAF8F5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <p className="text-xs font-semibold uppercase tracking-[0.25em] text-neutral-500 mb-2">
            Signature Craftsmanship
          </p>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-[0.14em] text-neutral-900 uppercase font-sans">
            The Featured Collection
          </h2>
          <p className="mt-3 text-xs sm:text-sm text-neutral-600 font-normal leading-relaxed">
            Engineered with Jetpack Compose Kotlin physics springs and served live via native PHP 8.2 microservices.
          </p>
        </div>

        {/* Filter Tabs & Sort Controls */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-8 mb-8 border-b border-neutral-200">
          {/* Category Filter Buttons */}
          <div className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
            {categoriesList.map((cat) => {
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => onSelectCategory(cat.id)}
                  className={`px-3.5 py-1.5 text-xs font-semibold tracking-wider uppercase transition-colors cursor-pointer whitespace-nowrap rounded-sm ${
                    isActive
                      ? 'bg-neutral-900 text-white shadow-sm'
                      : 'bg-white text-neutral-700 hover:text-neutral-950 border border-neutral-200 hover:border-neutral-300'
                  }`}
                >
                  {cat.label}
                </button>
              );
            })}
          </div>

          {/* Sort & PHP Diagnostics Tag */}
          <div className="flex items-center justify-between sm:justify-end gap-3 text-xs">
            {phpExecutionTimeMs !== undefined && (
              <span className="text-[11px] font-mono text-neutral-500 bg-neutral-100 px-2.5 py-1 rounded border border-neutral-200">
                PHP 8.2: {phpExecutionTimeMs}ms
              </span>
            )}
            <div className="flex items-center gap-2">
              <label htmlFor="sort-select" className="text-neutral-500 uppercase tracking-wider text-[11px]">
                Sort:
              </label>
              <select
                id="sort-select"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-white border border-neutral-200 text-neutral-900 text-xs px-3 py-1.5 rounded-sm focus:outline-none focus:border-neutral-900 font-medium"
              >
                <option value="featured">Featured First</option>
                <option value="price_asc">Price: Low to High</option>
                <option value="price_desc">Price: High to Low</option>
                <option value="rating">Highest Rated</option>
              </select>
            </div>
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {sortedProducts.map((product) => {
            const isWishlisted = wishlistIds.includes(product.id);
            const isJustAdded = addedProductId === product.id;

            return (
              <motion.div
                key={product.id}
                whileHover={{ y: -6 }}
                transition={cardSpring}
                className="group flex flex-col bg-white border border-neutral-200/90 hover:border-neutral-900 transition-all duration-300 shadow-sm hover:shadow-md relative"
              >
                {/* Product Tag */}
                {product.tag && (
                  <div className="absolute top-3 left-3 z-10">
                    <span className="text-[10px] uppercase font-bold tracking-widest bg-white/95 text-neutral-900 px-2.5 py-1 shadow-sm border border-neutral-100">
                      {product.tag}
                    </span>
                  </div>
                )}

                {/* Wishlist Button */}
                <motion.button
                  whileHover={{ scale: 1.15 }}
                  whileTap={{ scale: 0.9 }}
                  transition={heartSpring}
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleWishlist(product);
                  }}
                  className={`absolute top-3 right-3 z-10 p-2 rounded-full transition-colors ${
                    isWishlisted
                      ? 'bg-red-50 text-red-600 shadow-sm'
                      : 'bg-white/80 text-neutral-600 hover:text-red-600 hover:bg-white'
                  }`}
                  aria-label={isWishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
                >
                  <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-red-600' : ''}`} />
                </motion.button>

                {/* Product Image Stage */}
                <div
                  onClick={() => onQuickView(product)}
                  className="relative w-full aspect-[4/5] bg-[#F5F2EC] overflow-hidden cursor-pointer"
                >
                  <div className="w-full h-full relative group-hover:scale-105 transition-transform duration-700 ease-out">
                    <Image
                      src={product.image}
                      alt={product.name}
                      fill
                      sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
                      referrerPolicy="no-referrer"
                      className="object-cover"
                      style={{
                        objectPosition:
                          product.imageSlice === 'bag'
                            ? '8% 66%'
                            : product.imageSlice === 'men'
                            ? '27% 66%'
                            : product.imageSlice === 'shoes'
                            ? '42% 66%'
                            : product.imageSlice === 'watches'
                            ? '58% 66%'
                            : product.imageSlice === 'accessories'
                            ? '73% 66%'
                            : product.imageSlice === 'collections'
                            ? '92% 66%'
                            : 'center 20%',
                        transform: 'scale(1.9)',
                      }}
                    />
                  </div>

                  {/* Hover Overlay with Kotlin 360 & Quick View Buttons */}
                  <div className="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-black/60 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-between gap-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onQuickView(product);
                      }}
                      className="flex-1 py-2 px-3 bg-white text-neutral-900 text-[11px] font-bold tracking-wider uppercase flex items-center justify-center gap-1.5 hover:bg-neutral-100 transition-colors shadow"
                    >
                      <RotateCw className="w-3.5 h-3.5" />
                      <span>360° View</span>
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleQuickAdd(product);
                      }}
                      className="py-2 px-3 bg-neutral-950 text-white text-[11px] font-bold tracking-wider uppercase flex items-center justify-center hover:bg-neutral-800 transition-colors shadow"
                      title="Quick Add"
                    >
                      {isJustAdded ? <Check className="w-3.5 h-3.5 text-green-400" /> : <ShoppingBag className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                {/* Product Metadata */}
                <div className="p-4 flex flex-col flex-1 justify-between bg-white">
                  <div>
                    {/* Category kicker */}
                    <div className="flex items-center justify-between text-[11px] text-neutral-500 uppercase tracking-widest mb-1.5 font-medium">
                      <span>{product.categoryName}</span>
                      <div className="flex items-center gap-1 text-amber-600 font-sans">
                        <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                        <span className="font-mono tabular-nums">{product.rating}</span>
                      </div>
                    </div>

                    {/* Product Name */}
                    <h3
                      onClick={() => onQuickView(product)}
                      className="text-sm font-semibold text-neutral-900 leading-snug line-clamp-2 hover:text-black cursor-pointer mb-2"
                    >
                      {product.name}
                    </h3>

                    {/* Color Swatches */}
                    <div className="flex items-center gap-1.5 mb-3">
                      {product.colors.map((color, idx) => (
                        <div
                          key={color.name}
                          title={color.name}
                          className={`w-3.5 h-3.5 rounded-full border ${
                            idx === 0 ? 'ring-1 ring-neutral-950 ring-offset-1' : 'border-neutral-300'
                          }`}
                          style={{ backgroundColor: color.hex }}
                        />
                      ))}
                      <span className="text-[10px] text-neutral-400 ml-1">
                        {product.colors.length} {product.colors.length === 1 ? 'shade' : 'shades'}
                      </span>
                    </div>
                  </div>

                  {/* Price & Quick Add Button */}
                  <div className="pt-3 border-t border-neutral-100 flex items-center justify-between">
                    <div>
                      <div className="flex items-baseline gap-2">
                        <span className="text-sm font-bold text-neutral-950 font-mono tabular-nums">
                          ${product.price.toFixed(2)}
                        </span>
                        {product.originalPrice && product.originalPrice > product.price && (
                          <span className="text-xs text-neutral-400 line-through font-mono tabular-nums">
                            ${product.originalPrice.toFixed(2)}
                          </span>
                        )}
                      </div>
                    </div>

                    <button
                      onClick={() => handleQuickAdd(product)}
                      className="text-[11px] font-bold tracking-wider uppercase text-neutral-800 hover:text-black underline underline-offset-4 cursor-pointer"
                    >
                      {isJustAdded ? 'Added ✓' : 'Add to Bag'}
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
