'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';
import { kotlinToMotionSpring } from '@/lib/kotlin-physics';

interface EditorialBannerProps {
  onExplore: (category: string) => void;
}

export default function EditorialBanner({ onExplore }: EditorialBannerProps) {
  const kotlinButtonSpring = kotlinToMotionSpring(0.78, 380);

  return (
    <section className="w-full bg-[#1A1816] text-white overflow-hidden border-t border-neutral-800">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 min-h-[480px]">
        {/* Left Dark Editorial Box matching the screenshot */}
        <div className="lg:col-span-4 p-8 sm:p-12 lg:p-16 flex flex-col justify-center bg-[#151311] relative z-10 border-b lg:border-b-0 lg:border-r border-neutral-800">
          <p className="text-[11px] sm:text-xs font-semibold uppercase tracking-[0.25em] text-neutral-400 mb-4 font-sans">
            THE FALL COLLECTION
          </p>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-medium tracking-tight text-[#FAF7F2] leading-[1.15] mb-4">
            New Season.
            <br />
            Same Spirit.
          </h2>

          <p className="text-xs sm:text-sm text-neutral-400 font-light tracking-wide mb-8 leading-relaxed max-w-sm">
            Elevated essentials for a modern world. Hand-finished coats, structured leather bags, and timeless accessories designed for metropolitan momentum.
          </p>

          <div>
            <motion.button
              whileHover={{ scale: 1.025, x: 2 }}
              whileTap={{ scale: 0.98 }}
              transition={kotlinButtonSpring}
              onClick={() => onExplore('collections')}
              className="inline-flex items-center gap-3 px-6 py-3 border border-white/80 text-white hover:bg-white hover:text-black transition-colors duration-200 text-xs font-semibold tracking-[0.2em] uppercase cursor-pointer"
            >
              <span>EXPLORE THE COLLECTION</span>
              <ArrowRight className="w-4 h-4" />
            </motion.button>
          </div>
        </div>

        {/* Center Editorial Imagery (City skyline + sunglasses model) */}
        <div className="lg:col-span-5 relative min-h-[320px] lg:min-h-full overflow-hidden bg-neutral-900">
          <div className="w-full h-full relative" style={{ overflow: 'hidden' }}>
            <Image
              src="/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png"
              alt="Michael Kors Fall Campaign Model in Sunglasses"
              fill
              sizes="(max-width: 1024px) 100vw, 42vw"
              referrerPolicy="no-referrer"
              className="object-cover"
              style={{
                objectPosition: '49% 94%',
                transform: 'scale(1.85)',
                transformOrigin: '49% 94%',
              }}
            />
          </div>
          {/* Subtle gradient scrim */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />
          <div className="absolute bottom-6 left-6 text-xs text-white/90 tracking-widest uppercase font-medium drop-shadow">
            Runway Eyewear & Italian Outerwear
          </div>
        </div>

        {/* Right Editorial Imagery (Male model overlooking city skyline) */}
        <div className="lg:col-span-3 relative min-h-[260px] lg:min-h-full overflow-hidden bg-neutral-900 border-t lg:border-t-0 lg:border-l border-neutral-800">
          <div className="w-full h-full relative" style={{ overflow: 'hidden' }}>
            <Image
              src="/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png"
              alt="Michael Kors Men Fall City Tailoring"
              fill
              sizes="(max-width: 1024px) 100vw, 25vw"
              referrerPolicy="no-referrer"
              className="object-cover"
              style={{
                objectPosition: '86% 94%',
                transform: 'scale(1.85)',
                transformOrigin: '86% 94%',
              }}
            />
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />
          <div className="absolute bottom-6 left-6 text-xs text-white/90 tracking-widest uppercase font-medium drop-shadow">
            Michael Kors Menswear
          </div>
        </div>
      </div>
    </section>
  );
}
