'use client';

import React from 'react';
import Image from 'next/image';
import { X, Heart, ShoppingBag, Trash2, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Product } from '@/lib/types';
import { kotlinToMotionSpring } from '@/lib/kotlin-physics';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  wishlist: Product[];
  onRemoveWishlist: (product: Product) => void;
  onAddToCart: (product: Product, color?: string, size?: string) => void;
}

export default function WishlistDrawer({
  isOpen,
  onClose,
  wishlist,
  onRemoveWishlist,
  onAddToCart,
}: WishlistDrawerProps) {
  if (!isOpen) return null;

  const drawerSpring = kotlinToMotionSpring(0.85, 360);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-xs flex justify-end">
      <motion.div
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={drawerSpring}
        className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between"
      >
        {/* Header */}
        <div className="p-5 border-b border-neutral-200 flex items-center justify-between bg-[#FAF8F5]">
          <div className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-red-600 fill-red-600" />
            <h2 className="text-sm font-extrabold uppercase tracking-[0.18em] text-neutral-900 font-sans">
              Saved Favorites ({wishlist.length})
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-500 hover:text-black rounded-full hover:bg-neutral-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Wishlist Items List */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {wishlist.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-neutral-500">
              <Heart className="w-12 h-12 stroke-1 text-neutral-300 mb-3" />
              <p className="text-sm font-semibold uppercase tracking-wider text-neutral-800 mb-1">
                Your Wishlist is Empty
              </p>
              <p className="text-xs text-neutral-500 max-w-xs mb-6">
                Save your favorite designer satchels, watches, and runway looks for quick access anytime.
              </p>
              <button
                onClick={onClose}
                className="px-6 py-2.5 bg-neutral-950 text-white text-xs font-bold tracking-widest uppercase hover:bg-neutral-800 transition-colors"
              >
                Explore Collection
              </button>
            </div>
          ) : (
            wishlist.map((item) => (
              <div
                key={item.id}
                className="flex gap-4 p-3 bg-neutral-50 border border-neutral-200/80 rounded-sm"
              >
                <div className="w-20 h-24 bg-white border border-neutral-200 relative overflow-hidden shrink-0">
                  <Image
                    src={item.image}
                    alt={item.name}
                    fill
                    sizes="80px"
                    referrerPolicy="no-referrer"
                    className="object-cover"
                    style={{
                      objectPosition:
                        item.imageSlice === 'bag'
                          ? '8% 66%'
                          : item.imageSlice === 'men'
                          ? '27% 66%'
                          : item.imageSlice === 'shoes'
                          ? '42% 66%'
                          : item.imageSlice === 'watches'
                          ? '58% 66%'
                          : item.imageSlice === 'accessories'
                          ? '73% 66%'
                          : 'center 20%',
                      transform: 'scale(1.9)',
                    }}
                  />
                </div>

                <div className="flex-1 flex flex-col justify-between text-xs">
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="font-semibold text-neutral-900 leading-snug line-clamp-1">
                        {item.name}
                      </h3>
                      <button
                        onClick={() => onRemoveWishlist(item)}
                        className="text-neutral-400 hover:text-red-600 p-1"
                        title="Remove"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <p className="text-[11px] text-neutral-400 uppercase tracking-widest mt-1">
                      {item.categoryName}
                    </p>
                    <p className="font-mono font-bold text-neutral-900 mt-1">
                      ${item.price.toFixed(2)}
                    </p>
                  </div>

                  <button
                    onClick={() => {
                      onAddToCart(item);
                      onRemoveWishlist(item);
                    }}
                    className="mt-3 w-full py-2 bg-neutral-900 text-white text-[11px] font-bold tracking-wider uppercase flex items-center justify-center gap-1.5 hover:bg-black transition-colors"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>Move to Bag</span>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {wishlist.length > 0 && (
          <div className="p-5 border-t border-neutral-200 bg-[#FAF8F5]">
            <p className="text-xs text-neutral-500 text-center mb-3">
              Items remain saved in your browser session and VIP account.
            </p>
            <button
              onClick={onClose}
              className="w-full py-3 border border-neutral-300 text-neutral-900 text-xs font-bold uppercase tracking-widest hover:bg-neutral-100"
            >
              Continue Browsing
            </button>
          </div>
        )}
      </motion.div>
    </div>
  );
}
