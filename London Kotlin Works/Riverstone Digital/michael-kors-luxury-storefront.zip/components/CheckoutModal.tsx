'use client';

import React, { useState } from 'react';
import { X, CheckCircle, ShieldCheck, Truck, CreditCard, Lock, ArrowLeft, Printer, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CartState, OrderConfirmation } from '@/lib/types';
import { kotlinToMotionSpring } from '@/lib/kotlin-physics';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartState;
  onOrderComplete: (order: OrderConfirmation) => void;
}

export default function CheckoutModal({
  isOpen,
  onClose,
  cart,
  onOrderComplete,
}: CheckoutModalProps) {
  const [step, setStep] = useState<'shipping' | 'payment' | 'confirmed'>('shipping');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [confirmedOrder, setConfirmedOrder] = useState<OrderConfirmation | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    firstName: 'Eleanor',
    lastName: 'Vance',
    email: 'eleanor.vance@luxurymail.com',
    address: '740 Park Avenue, Apt 14B',
    city: 'New York',
    state: 'NY',
    zip: '10021',
    cardName: 'Eleanor Vance',
    cardNumber: '•••• •••• •••• 4242',
    cardExp: '12/28',
    cardCvc: '884',
    giftMessage: 'Happy Anniversary with love',
  });

  if (!isOpen) return null;

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg(null);

    try {
      const response = await fetch('/api/php?endpoint=checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          shipping: {
            firstName: formData.firstName,
            lastName: formData.lastName,
            email: formData.email,
            address: formData.address,
            city: formData.city,
            state: formData.state,
            zip: formData.zip,
          },
          cart: cart,
          paymentMethod: 'card',
          payment: {
            last4: '4242',
          },
        }),
      });

      const resData = await response.json();

      if (resData.status === 'success' && resData.order) {
        setConfirmedOrder(resData.order);
        onOrderComplete(resData.order);
        setStep('confirmed');
      } else {
        setErrorMsg(resData.message || 'Unable to place order. Please review information.');
      }
    } catch {
      setErrorMsg('Network error communicating with PHP order fulfillment service.');
    } finally {
      setLoading(false);
    }
  };

  const modalSpring = kotlinToMotionSpring(0.85, 400);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={modalSpring}
        className="relative w-full max-w-2xl bg-white shadow-2xl border border-neutral-200 overflow-hidden flex flex-col max-h-[92vh]"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-200 bg-[#FAF8F5]">
          <div className="flex items-center gap-3">
            <h2 className="text-sm font-extrabold tracking-[0.2em] text-neutral-900 uppercase font-sans">
              MICHAEL KORS · SECURE CHECKOUT
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-500 hover:text-black rounded-full hover:bg-neutral-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stepper Bar */}
        {step !== 'confirmed' && (
          <div className="flex border-b border-neutral-200 text-xs font-semibold uppercase tracking-wider bg-white">
            <button
              onClick={() => setStep('shipping')}
              className={`flex-1 py-3 text-center transition-colors ${
                step === 'shipping' ? 'border-b-2 border-neutral-900 text-neutral-950 font-bold' : 'text-neutral-400'
              }`}
            >
              1. Delivery Address
            </button>
            <button
              onClick={() => setStep('payment')}
              className={`flex-1 py-3 text-center transition-colors ${
                step === 'payment' ? 'border-b-2 border-neutral-900 text-neutral-950 font-bold' : 'text-neutral-400'
              }`}
            >
              2. Payment & Confirmation
            </button>
          </div>
        )}

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-8">
          {errorMsg && (
            <div className="mb-4 p-3 bg-red-50 text-red-700 text-xs rounded border border-red-200">
              {errorMsg}
            </div>
          )}

          {step === 'shipping' && (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setStep('payment');
              }}
              className="space-y-4 text-xs"
            >
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-neutral-600 font-semibold mb-1 uppercase tracking-wider">
                    First Name
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 rounded-sm focus:outline-none focus:border-neutral-900"
                  />
                </div>
                <div>
                  <label className="block text-neutral-600 font-semibold mb-1 uppercase tracking-wider">
                    Last Name
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.lastName}
                    onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 rounded-sm focus:outline-none focus:border-neutral-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-neutral-600 font-semibold mb-1 uppercase tracking-wider">
                  Email Address for Receipt & Tracking
                </label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 rounded-sm focus:outline-none focus:border-neutral-900"
                />
              </div>

              <div>
                <label className="block text-neutral-600 font-semibold mb-1 uppercase tracking-wider">
                  Street Address
                </label>
                <input
                  type="text"
                  required
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full bg-neutral-50 border border-neutral-300 p-2.5 rounded-sm focus:outline-none focus:border-neutral-900"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-neutral-600 font-semibold mb-1 uppercase tracking-wider">
                    City
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 rounded-sm focus:outline-none focus:border-neutral-900"
                  />
                </div>
                <div>
                  <label className="block text-neutral-600 font-semibold mb-1 uppercase tracking-wider">
                    State
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.state}
                    onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 rounded-sm focus:outline-none focus:border-neutral-900"
                  />
                </div>
                <div>
                  <label className="block text-neutral-600 font-semibold mb-1 uppercase tracking-wider">
                    ZIP Code
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.zip}
                    onChange={(e) => setFormData({ ...formData, zip: e.target.value })}
                    className="w-full bg-neutral-50 border border-neutral-300 p-2.5 rounded-sm focus:outline-none focus:border-neutral-900"
                  />
                </div>
              </div>

              <div className="p-3 bg-[#FAF8F5] border border-neutral-200 rounded text-neutral-600 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Truck className="w-4 h-4 text-neutral-800" />
                  <span>UPS Insured Luxury Express Delivery</span>
                </div>
                <span className="font-mono font-bold text-neutral-900">
                  {cart.shippingFee === 0 ? 'FREE' : `$${cart.shippingFee.toFixed(2)}`}
                </span>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 bg-neutral-950 text-white font-bold text-xs tracking-[0.2em] uppercase hover:bg-neutral-800 transition-colors shadow-lg cursor-pointer"
              >
                Continue to Payment
              </button>
            </form>
          )}

          {step === 'payment' && (
            <form onSubmit={handleSubmitOrder} className="space-y-4 text-xs">
              <div className="p-4 bg-neutral-50 border border-neutral-200 rounded-sm">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2 font-semibold text-neutral-900">
                    <CreditCard className="w-4 h-4" />
                    <span>Credit / Debit Card (Simulated)</span>
                  </div>
                  <Lock className="w-3.5 h-3.5 text-neutral-500" />
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-neutral-500 font-medium mb-1">Name on Card</label>
                    <input
                      type="text"
                      required
                      value={formData.cardName}
                      onChange={(e) => setFormData({ ...formData, cardName: e.target.value })}
                      className="w-full bg-white border border-neutral-300 p-2 rounded-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-neutral-500 font-medium mb-1">Card Number</label>
                    <input
                      type="text"
                      required
                      value={formData.cardNumber}
                      onChange={(e) => setFormData({ ...formData, cardNumber: e.target.value })}
                      className="w-full bg-white border border-neutral-300 p-2 rounded-sm font-mono"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-neutral-500 font-medium mb-1">Expiry Date</label>
                      <input
                        type="text"
                        value={formData.cardExp}
                        onChange={(e) => setFormData({ ...formData, cardExp: e.target.value })}
                        className="w-full bg-white border border-neutral-300 p-2 rounded-sm font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-neutral-500 font-medium mb-1">Security Code (CVC)</label>
                      <input
                        type="password"
                        value={formData.cardCvc}
                        onChange={(e) => setFormData({ ...formData, cardCvc: e.target.value })}
                        className="w-full bg-white border border-neutral-300 p-2 rounded-sm font-mono"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Order Summary Recap */}
              <div className="p-3 bg-[#FAF8F5] border border-neutral-200 rounded-sm space-y-1.5">
                <div className="flex justify-between text-neutral-600">
                  <span>Items Total ({cart.itemCount})</span>
                  <span className="font-mono">${cart.subtotal.toFixed(2)}</span>
                </div>
                {cart.discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-700">
                    <span>Discount ({cart.couponCode})</span>
                    <span className="font-mono">-${cart.discountAmount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-neutral-600">
                  <span>Shipping</span>
                  <span className="font-mono">{cart.shippingFee === 0 ? 'FREE' : `$${cart.shippingFee.toFixed(2)}`}</span>
                </div>
                <div className="flex justify-between text-neutral-600">
                  <span>Tax</span>
                  <span className="font-mono">${cart.tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-bold text-neutral-900 text-sm pt-2 border-t border-neutral-300">
                  <span>Total Due</span>
                  <span className="font-mono">${cart.grandTotal.toFixed(2)}</span>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setStep('shipping')}
                  className="px-4 py-3 border border-neutral-300 text-neutral-700 hover:bg-neutral-100 uppercase tracking-wider font-semibold rounded-sm"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 py-3.5 bg-neutral-950 text-white font-extrabold text-xs tracking-[0.2em] uppercase hover:bg-neutral-800 transition-colors shadow-lg cursor-pointer disabled:opacity-50"
                >
                  {loading ? 'Processing via PHP Microservice...' : `Authorize & Pay $${cart.grandTotal.toFixed(2)}`}
                </button>
              </div>
            </form>
          )}

          {step === 'confirmed' && confirmedOrder && (
            <div className="text-center py-4 space-y-6">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto shadow-inner">
                <CheckCircle className="w-9 h-9" />
              </div>

              <div>
                <span className="text-[11px] font-bold tracking-[0.25em] text-neutral-400 uppercase font-sans">
                  Order Successfully Placed
                </span>
                <h3 className="text-2xl font-bold text-neutral-950 font-sans tracking-tight mt-1">
                  Thank You, {confirmedOrder.customer.name}
                </h3>
                <p className="text-xs text-neutral-600 max-w-md mx-auto mt-2 leading-relaxed">
                  Your luxury order confirmation has been emailed to{' '}
                  <span className="font-semibold text-neutral-900">{confirmedOrder.customer.email}</span>.
                </p>
              </div>

              {/* Order Receipt Box */}
              <div className="bg-[#FAF8F5] border border-neutral-200 text-left p-5 text-xs rounded-sm space-y-3 font-mono">
                <div className="flex justify-between border-b border-neutral-200 pb-2">
                  <span className="text-neutral-500">Order Reference:</span>
                  <span className="font-bold text-neutral-950">{confirmedOrder.orderId}</span>
                </div>
                <div className="flex justify-between border-b border-neutral-200 pb-2">
                  <span className="text-neutral-500">Tracking Number:</span>
                  <span className="text-neutral-800">{confirmedOrder.trackingNumber}</span>
                </div>
                <div className="flex justify-between border-b border-neutral-200 pb-2">
                  <span className="text-neutral-500">Carrier:</span>
                  <span className="text-neutral-800">{confirmedOrder.carrier}</span>
                </div>
                <div className="flex justify-between border-b border-neutral-200 pb-2">
                  <span className="text-neutral-500">Estimated Delivery:</span>
                  <span className="text-neutral-800 font-semibold">{confirmedOrder.estimatedDelivery}</span>
                </div>
                <div className="flex justify-between pt-1 font-bold text-neutral-950">
                  <span>Grand Total Paid:</span>
                  <span>${confirmedOrder.summary.grandTotal.toFixed(2)}</span>
                </div>
                <div className="pt-2 text-emerald-700 font-semibold flex items-center gap-1.5 font-sans">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  <span>+{confirmedOrder.vipClubPointsEarned} VIP Kors Club Points Awarded</span>
                </div>
              </div>

              <div className="flex justify-center gap-4">
                <button
                  onClick={() => window.print()}
                  className="px-5 py-2.5 border border-neutral-300 text-neutral-800 text-xs font-semibold uppercase tracking-wider hover:bg-neutral-100 flex items-center gap-2 rounded-sm"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Receipt</span>
                </button>
                <button
                  onClick={onClose}
                  className="px-6 py-2.5 bg-neutral-950 text-white text-xs font-bold uppercase tracking-widest hover:bg-neutral-800 transition-colors rounded-sm"
                >
                  Return to Storefront
                </button>
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
