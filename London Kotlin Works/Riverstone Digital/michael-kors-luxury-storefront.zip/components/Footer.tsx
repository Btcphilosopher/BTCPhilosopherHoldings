'use client';

import React, { useState } from 'react';
import { ArrowRight, Check, ShieldCheck, MapPin, Phone, Mail, Globe } from 'lucide-react';

interface FooterProps {
  onOpenVip: () => void;
  onSelectCategory: (category: string) => void;
}

export default function Footer({ onOpenVip, onSelectCategory }: FooterProps) {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    try {
      await fetch('/api/php?endpoint=newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
    } catch {
      // Fallback
    }
    setSubscribed(true);
  };

  return (
    <footer className="bg-[#121110] text-[#EFEBE4] pt-16 pb-12 border-t border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top VIP Newsletter Section */}
        <div className="pb-14 border-b border-neutral-800 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-6">
            <span className="text-[11px] font-bold tracking-[0.25em] text-amber-400 uppercase font-sans">
              MICHAEL KORS · KORSVIP
            </span>
            <h3 className="text-2xl sm:text-3xl font-display font-medium tracking-tight text-white mt-1 mb-2">
              Receive 15% Off Your Next Designer Order
            </h3>
            <p className="text-xs text-neutral-400 max-w-md font-light leading-relaxed">
              Subscribe to discover our new seasonal runway collections, VIP private events, and complimentary white-glove delivery privileges.
            </p>
          </div>

          <div className="lg:col-span-6">
            {subscribed ? (
              <div className="flex items-center gap-2 p-3 bg-neutral-900 border border-neutral-700 text-emerald-400 text-xs rounded-sm">
                <Check className="w-4 h-4 shrink-0" />
                <span>Thank you. Your exclusive 15% VIP code <strong>MKLUXURY</strong> is ready to use!</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex gap-2">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email address"
                  className="w-full bg-neutral-900 border border-neutral-700 px-4 py-3 text-xs text-white placeholder:text-neutral-500 rounded-sm focus:outline-none focus:border-white"
                />
                <button
                  type="submit"
                  className="px-6 py-3 bg-white text-neutral-950 font-bold text-xs tracking-wider uppercase hover:bg-neutral-200 transition-colors whitespace-nowrap cursor-pointer rounded-sm"
                >
                  Join VIP
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Links Grid */}
        <div className="py-12 grid grid-cols-2 md:grid-cols-4 gap-8 text-xs border-b border-neutral-800">
          <div>
            <h4 className="font-bold uppercase tracking-[0.18em] text-white mb-4 font-sans text-xs">
              CUSTOMER ASSISTANCE
            </h4>
            <ul className="space-y-2.5 text-neutral-400">
              <li><a href="#" className="hover:text-white transition-colors">Track Order & Courier Status</a></li>
              <li><a href="#" className="hover:text-white transition-colors">White-Glove Shipping & Delivery</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Complimentary Returns & Exchanges</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Authenticity & Lifetime Warranty</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Watch Repair & Leather Spa</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold uppercase tracking-[0.18em] text-white mb-4 font-sans text-xs">
              DISCOVER COLLECTIONS
            </h4>
            <ul className="space-y-2.5 text-neutral-400">
              <li>
                <button onClick={() => onSelectCategory('bags')} className="hover:text-white transition-colors cursor-pointer">
                  Designer Handbags & Satchels
                </button>
              </li>
              <li>
                <button onClick={() => onSelectCategory('watches')} className="hover:text-white transition-colors cursor-pointer">
                  Gold & Pavé Chronographs
                </button>
              </li>
              <li>
                <button onClick={() => onSelectCategory('shoes')} className="hover:text-white transition-colors cursor-pointer">
                  Signature Jacquard Sneakers
                </button>
              </li>
              <li>
                <button onClick={() => onSelectCategory('accessories')} className="hover:text-white transition-colors cursor-pointer">
                  Italian Acetate Sunglasses
                </button>
              </li>
              <li>
                <button onClick={() => onSelectCategory('collections')} className="hover:text-white transition-colors cursor-pointer">
                  Runway Leather Moto Coats
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold uppercase tracking-[0.18em] text-white mb-4 font-sans text-xs">
              KORSVIP MEMBERSHIP
            </h4>
            <ul className="space-y-2.5 text-neutral-400">
              <li>
                <button onClick={onOpenVip} className="hover:text-white transition-colors cursor-pointer">
                  About KorsVIP Loyalty
                </button>
              </li>
              <li><a href="#" className="hover:text-white transition-colors">Member Tier Benefits</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Private Runway In-Store Styling</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Annual Anniversary Gifts</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold uppercase tracking-[0.18em] text-white mb-4 font-sans text-xs">
              HERITAGE & ATELIER
            </h4>
            <ul className="space-y-2.5 text-neutral-400">
              <li><a href="#" className="hover:text-white transition-colors">The World of Michael Kors</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Florence Leather Atelier</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Kors Cares: Watch Hunger Stop</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Sustainable Craft Initiatives</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Store Locator & Global Flagships</a></li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between text-[11px] text-neutral-500 gap-4">
          <div className="flex items-center gap-6">
            <span className="font-extrabold tracking-[0.2em] text-white uppercase font-sans">
              MICHAEL KORS
            </span>
            <span>&copy; {new Date().getFullYear()} Michael Kors. All rights reserved.</span>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-neutral-400 font-mono">
            <span className="hover:text-white cursor-pointer">Privacy Policy</span>
            <span>·</span>
            <span className="hover:text-white cursor-pointer">Terms of Use</span>
            <span>·</span>
            <span className="hover:text-white cursor-pointer">PHP 8.2 Microservice</span>
            <span>·</span>
            <span className="hover:text-white cursor-pointer">Kotlin Compose Specs</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
