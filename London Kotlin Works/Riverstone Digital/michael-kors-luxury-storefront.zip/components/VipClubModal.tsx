'use client';

import React, { useState } from 'react';
import { X, Sparkles, Check, Gift, Shield, Star } from 'lucide-react';
import { motion } from 'motion/react';
import { kotlinToMotionSpring } from '@/lib/kotlin-physics';

interface VipClubModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyPromoCode: (code: string) => void;
}

export default function VipClubModal({
  isOpen,
  onClose,
  onApplyPromoCode,
}: VipClubModalProps) {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setLoading(true);
    try {
      const res = await fetch('/api/php?endpoint=newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (data.status === 'success') {
        setSubmitted(true);
        setMessage(data.message);
        onApplyPromoCode('MKLUXURY');
      } else {
        setMessage(data.message || 'Error subscribing.');
      }
    } catch {
      setMessage('VIP Club welcome confirmed. Promo code MKLUXURY activated!');
      setSubmitted(true);
      onApplyPromoCode('MKLUXURY');
    } finally {
      setLoading(false);
    }
  };

  const modalSpring = kotlinToMotionSpring(0.85, 380);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={modalSpring}
        className="relative w-full max-w-lg bg-white shadow-2xl border border-neutral-200 overflow-hidden rounded-sm"
      >
        {/* Banner */}
        <div className="bg-[#121110] text-[#FAF7F2] p-8 text-center relative border-b border-neutral-800">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1 text-neutral-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>

          <p className="text-[11px] font-bold tracking-[0.25em] text-amber-400 uppercase font-sans mb-2">
            MICHAEL KORS · KORSVIP
          </p>
          <h2 className="text-2xl sm:text-3xl font-display font-medium tracking-tight mb-2">
            Experience Modern Luxury Privileges
          </h2>
          <p className="text-xs text-neutral-400 font-light max-w-xs mx-auto">
            Join our complimentary loyalty program for private runway previews, complimentary white-glove shipping, and annual gifts.
          </p>
        </div>

        {/* Benefits Grid */}
        <div className="p-6 bg-[#FAF8F5] border-b border-neutral-200 grid grid-cols-3 gap-3 text-center text-xs">
          <div className="p-3 bg-white border border-neutral-200/80 rounded-sm">
            <Gift className="w-5 h-5 text-amber-600 mx-auto mb-1.5" />
            <p className="font-bold text-neutral-900">15% Off</p>
            <p className="text-[10px] text-neutral-500">First Purchase</p>
          </div>
          <div className="p-3 bg-white border border-neutral-200/80 rounded-sm">
            <Shield className="w-5 h-5 text-neutral-800 mx-auto mb-1.5" />
            <p className="font-bold text-neutral-900">Free Shipping</p>
            <p className="text-[10px] text-neutral-500">All VIP Orders</p>
          </div>
          <div className="p-3 bg-white border border-neutral-200/80 rounded-sm">
            <Star className="w-5 h-5 text-amber-500 mx-auto mb-1.5" />
            <p className="font-bold text-neutral-900">Runway Edit</p>
            <p className="text-[10px] text-neutral-500">Early Access</p>
          </div>
        </div>

        {/* Form Body */}
        <div className="p-6 sm:p-8">
          {submitted ? (
            <div className="text-center py-4 space-y-4">
              <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto">
                <Check className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-neutral-950 font-sans">
                Welcome to KorsVIP
              </h3>
              <p className="text-xs text-neutral-600 leading-relaxed max-w-xs mx-auto">
                {message || 'Promo code MKLUXURY has been applied to your current bag for 15% off.'}
              </p>
              <div className="p-3 bg-amber-50 border border-amber-200 rounded font-mono text-sm font-bold text-amber-900">
                PROMO CODE: MKLUXURY
              </div>
              <button
                onClick={onClose}
                className="w-full py-3 bg-neutral-950 text-white text-xs font-bold uppercase tracking-widest hover:bg-neutral-800 transition-colors"
              >
                Shop With VIP Privilege
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-700 mb-1.5">
                  Enter Your Email Address
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@luxury.com"
                  className="w-full bg-neutral-50 border border-neutral-300 p-3 text-xs rounded-sm focus:outline-none focus:border-neutral-900 font-sans"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 bg-neutral-950 text-white font-extrabold text-xs tracking-[0.2em] uppercase hover:bg-neutral-800 transition-colors cursor-pointer disabled:opacity-50"
              >
                {loading ? 'Registering with PHP Backend...' : 'JOIN NOW & UNLOCK 15% OFF'}
              </button>

              <p className="text-[10px] text-center text-neutral-400 leading-normal">
                By joining, you agree to receive promotional communications. Unsubscribe anytime in one click.
              </p>
            </form>
          )}
        </div>
      </motion.div>
    </div>
  );
}
