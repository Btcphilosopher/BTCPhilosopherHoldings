'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { ArrowRight, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { kotlinToMotionSpring } from '@/lib/kotlin-physics';

interface HeroSliderProps {
  onShopCollection: () => void;
  onExploreSlide: (category: string) => void;
}

const SLIDES = [
  {
    id: 1,
    number: '01',
    kicker: 'MODERN LUXURY. TIMELESS STYLE.',
    headline: 'MICHAEL KORS',
    subhead: 'Effortless style for wherever life takes you.',
    cta: 'SHOP THE NEW COLLECTION',
    category: 'all',
    bgPosition: 'center 20%',
    accent: 'Mediterranean Coast Collection',
  },
  {
    id: 2,
    number: '02',
    kicker: 'THE EMBOSSED MONOGRAM EDIT',
    headline: 'SIGNATURE PIECES',
    subhead: 'Iconic silhouettes reimagined with refined gilded hardware.',
    cta: 'EXPLORE BAGS & ACCESSORIES',
    category: 'bags',
    bgPosition: 'center 40%',
    accent: 'Hand-Crafted Italian Leather',
  },
  {
    id: 3,
    number: '03',
    kicker: 'FALL RUNWAY 2026',
    headline: 'ELEVATED TAILORING',
    subhead: 'Rich Italian lambskin coats and precision chronographs.',
    cta: 'VIEW THE RUNWAY EDIT',
    category: 'collections',
    bgPosition: 'center 70%',
    accent: 'Limited Numbered Edition',
  },
];

export default function HeroSlider({ onShopCollection, onExploreSlide }: HeroSliderProps) {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const currentSlide = SLIDES[currentSlideIndex];

  // Auto-advance slides every 8 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlideIndex((prev) => (prev + 1) % SLIDES.length);
    }, 8000);
    return () => clearInterval(timer);
  }, []);

  // Kotlin Compose Spring Animation configuration
  const kotlinSlideSpring = kotlinToMotionSpring(0.85, 300);

  return (
    <section className="relative w-full h-[620px] sm:h-[700px] lg:h-[760px] overflow-hidden bg-neutral-900 select-none">
      {/* Background Image Container */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png"
          alt="Michael Kors Campaign - Modern Luxury, Timeless Style"
          fill
          priority
          sizes="100vw"
          referrerPolicy="no-referrer"
          className="object-cover transition-transform duration-1000 ease-out"
          style={{ objectPosition: 'center 25%' }}
        />
        {/* Soft luxury editorial overlay to guarantee WCAG contrast */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/55 via-black/25 to-transparent pointer-events-none" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-black/10 pointer-events-none" />
      </div>

      {/* Hero Content Overlay */}
      <div className="relative z-10 max-w-7xl mx-auto h-full px-6 sm:px-8 lg:px-12 flex flex-col justify-between py-12 sm:py-16">
        {/* Top subtle campaign tag */}
        <div className="opacity-0 md:opacity-100 transition-opacity">
          <span className="text-[11px] tracking-[0.25em] text-white/80 uppercase font-medium bg-black/30 backdrop-blur-sm px-3 py-1 rounded-sm border border-white/10">
            Fall Campaign · Portofino & Capri
          </span>
        </div>

        {/* Center-Left Main Typography matching screenshot exactly */}
        <div className="max-w-xl pb-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentSlide.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={kotlinSlideSpring}
            >
              {/* Kicker */}
              <p className="text-xs sm:text-sm font-semibold tracking-[0.25em] text-white/95 uppercase mb-3 drop-shadow-sm font-sans">
                {currentSlide.kicker}
              </p>

              {/* Title */}
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-[0.14em] text-white mb-4 uppercase drop-shadow-md font-sans">
                {currentSlide.headline}
              </h1>

              {/* Subhead */}
              <p className="text-sm sm:text-base text-white/90 font-light tracking-wide mb-8 max-w-md drop-shadow">
                {currentSlide.subhead}
              </p>

              {/* Action Button - White CTA matching screenshot */}
              <motion.button
                whileHover={{ scale: 1.025, x: 2 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => {
                  onExploreSlide(currentSlide.category);
                  onShopCollection();
                }}
                className="group inline-flex items-center gap-3 px-7 py-3.5 bg-white text-neutral-950 font-semibold text-xs tracking-[0.18em] uppercase hover:bg-neutral-100 transition-all duration-200 shadow-lg cursor-pointer"
              >
                <span>{currentSlide.cta}</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </motion.button>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Right Vertical Slide Pagination - 01, 02, 03 matching screenshot */}
        <div className="absolute right-6 sm:right-10 lg:right-16 top-1/2 -translate-y-1/2 flex flex-col items-center gap-6 z-20">
          {SLIDES.map((slide, index) => {
            const isActive = currentSlideIndex === index;
            return (
              <button
                key={slide.number}
                onClick={() => setCurrentSlideIndex(index)}
                className="group flex items-center gap-3 py-1 cursor-pointer focus:outline-none"
                aria-label={`Go to slide ${slide.number}`}
              >
                <span
                  className={`text-sm sm:text-base font-mono tracking-widest transition-all ${
                    isActive
                      ? 'text-white font-bold scale-110 drop-shadow'
                      : 'text-white/50 group-hover:text-white/80 font-normal'
                  }`}
                >
                  {slide.number}
                </span>
                <div
                  className={`h-0.5 transition-all duration-300 ${
                    isActive
                      ? 'w-6 bg-white'
                      : 'w-2 bg-white/40 group-hover:w-4 group-hover:bg-white/70'
                  }`}
                />
              </button>
            );
          })}
        </div>

        {/* Bottom subtle progress track */}
        <div className="w-full flex items-center justify-between text-[11px] tracking-widest text-white/70 border-t border-white/20 pt-4">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            <span className="uppercase">Kotlin Spring Physics Engine Active</span>
          </div>
          <div className="hidden sm:block uppercase">
            Handcrafted Luxury Craftsmanship
          </div>
        </div>
      </div>
    </section>
  );
}
