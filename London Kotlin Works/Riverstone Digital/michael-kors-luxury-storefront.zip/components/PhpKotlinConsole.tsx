'use client';

import React, { useState } from 'react';
import { Terminal, Cpu, Play, CheckCircle2, ChevronDown, ChevronUp, Copy, Check, RotateCw, Sparkles, Server } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { KOTLIN_PRESETS, kotlinToMotionSpring } from '@/lib/kotlin-physics';
import { KotlinPhysicsPreset } from '@/lib/types';

interface PhpKotlinConsoleProps {
  currentPreset: KotlinPhysicsPreset;
  onSelectPreset: (preset: KotlinPhysicsPreset) => void;
  lastPhpExecutionTime?: number;
}

export default function PhpKotlinConsole({
  currentPreset,
  onSelectPreset,
  lastPhpExecutionTime = 1.4,
}: PhpKotlinConsoleProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'php' | 'kotlin' | 'code'>('php');
  const [copiedCode, setCopiedCode] = useState(false);

  // Live PHP testing state
  const [testingEndpoint, setTestingEndpoint] = useState<string | null>(null);
  const [apiResponse, setApiResponse] = useState<any>(null);

  // Interactive animation test bounce
  const [bounceTrigger, setBounceTrigger] = useState(0);

  const testPhpEndpoint = async (endpoint: string) => {
    setTestingEndpoint(endpoint);
    try {
      const res = await fetch(`/api/php?endpoint=${endpoint}`);
      const data = await res.json();
      setApiResponse({
        endpoint,
        status: res.status,
        headers: {
          'x-powered-by': res.headers.get('x-powered-by') || 'PHP/8.2-FPM',
          'x-php-execution-time': res.headers.get('x-php-execution-time') || `${lastPhpExecutionTime}ms`,
        },
        body: data,
      });
    } catch (err: any) {
      setApiResponse({ error: err.message });
    } finally {
      setTestingEndpoint(null);
    }
  };

  const copyCode = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const testSpring = kotlinToMotionSpring(currentPreset.dampingRatio, currentPreset.stiffness);

  return (
    <>
      {/* Floating Bottom Console Trigger Button */}
      <div className="fixed bottom-4 right-4 z-40">
        <motion.button
          whileHover={{ scale: 1.04 }}
          whileTap={{ scale: 0.96 }}
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center gap-2.5 px-4 py-2.5 bg-[#121110] text-white text-xs font-semibold rounded-full shadow-2xl border border-neutral-700/80 hover:border-amber-400 transition-colors cursor-pointer group"
          aria-label="Toggle PHP & Kotlin Architecture Console"
        >
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-mono text-emerald-300">PHP 8.2</span>
          </div>
          <span className="text-neutral-500">|</span>
          <div className="flex items-center gap-1 text-purple-300">
            <Cpu className="w-3.5 h-3.5" />
            <span>Kotlin Physics</span>
          </div>
          <span className="text-[11px] font-mono text-neutral-400 tabular-nums ml-1">
            {lastPhpExecutionTime}ms
          </span>
          {isOpen ? <ChevronDown className="w-3.5 h-3.5 text-neutral-400" /> : <ChevronUp className="w-3.5 h-3.5 text-neutral-400" />}
        </motion.button>
      </div>

      {/* Slide-Up Console Drawer */}
      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-x-0 bottom-0 z-50 p-2 sm:p-4 max-w-4xl mx-auto flex justify-center pointer-events-none">
            <motion.div
              initial={{ opacity: 0, y: 40, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 40, scale: 0.98 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
              className="w-full bg-[#141417] text-[#FAF7F2] rounded-lg shadow-2xl border border-neutral-800 overflow-hidden pointer-events-auto flex flex-col max-h-[82vh]"
            >
              {/* Top Bar */}
              <div className="p-3.5 sm:p-4 bg-[#0E0E10] border-b border-neutral-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Terminal className="w-4 h-4 text-amber-400" />
                  <span className="text-xs font-mono font-bold tracking-wider uppercase text-neutral-200">
                    Michael Kors Architecture · PHP 8.2 & Kotlin Compose Bridge
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsOpen(false)}
                    className="text-xs font-mono text-neutral-400 hover:text-white px-2 py-1 rounded bg-neutral-800/60"
                  >
                    CLOSE [ESC]
                  </button>
                </div>
              </div>

              {/* Navigation Tabs */}
              <div className="flex border-b border-neutral-800 bg-[#121214] text-xs font-mono font-medium">
                <button
                  onClick={() => setActiveTab('php')}
                  className={`flex-1 py-2.5 px-4 flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                    activeTab === 'php'
                      ? 'bg-[#18181B] text-blue-400 border-b-2 border-blue-400'
                      : 'text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  <Server className="w-3.5 h-3.5" />
                  <span>PHP 8.2 API Monitor</span>
                </button>
                <button
                  onClick={() => setActiveTab('kotlin')}
                  className={`flex-1 py-2.5 px-4 flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                    activeTab === 'kotlin'
                      ? 'bg-[#18181B] text-purple-400 border-b-2 border-purple-400'
                      : 'text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  <Cpu className="w-3.5 h-3.5" />
                  <span>Kotlin Physics Lab</span>
                </button>
                <button
                  onClick={() => setActiveTab('code')}
                  className={`flex-1 py-2.5 px-4 flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                    activeTab === 'code'
                      ? 'bg-[#18181B] text-emerald-400 border-b-2 border-emerald-400'
                      : 'text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  <Terminal className="w-3.5 h-3.5" />
                  <span>Kotlin & PHP Source</span>
                </button>
              </div>

              {/* Tab 1: PHP 8.2 Monitor */}
              {activeTab === 'php' && (
                <div className="p-4 sm:p-6 overflow-y-auto space-y-4 text-xs font-mono">
                  {/* Status Card */}
                  <div className="p-3 bg-neutral-900/80 rounded border border-neutral-800 flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p className="text-neutral-400 text-[11px]">Runtime Environment</p>
                      <p className="text-white font-bold text-sm">PHP 8.2.35 (Zend Engine OPcache)</p>
                    </div>
                    <div>
                      <p className="text-neutral-400 text-[11px]">Average Latency</p>
                      <p className="text-emerald-400 font-bold text-sm tabular-nums">~{lastPhpExecutionTime}ms</p>
                    </div>
                    <div>
                      <p className="text-neutral-400 text-[11px]">Integration Mode</p>
                      <p className="text-neutral-300 font-bold">Next.js 15 Native Spawn Bridge</p>
                    </div>
                  </div>

                  {/* Test Endpoints Toolbar */}
                  <div>
                    <p className="text-[11px] text-neutral-400 uppercase tracking-widest mb-2 font-bold">
                      Execute Live PHP Microservice Endpoints:
                    </p>
                    <div className="flex flex-wrap gap-2">
                      <button
                        onClick={() => testPhpEndpoint('products')}
                        disabled={testingEndpoint !== null}
                        className="px-3 py-1.5 bg-blue-900/40 hover:bg-blue-800/60 text-blue-200 rounded border border-blue-700/50 flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Play className="w-3 h-3 text-blue-400" />
                        <span>GET /api/php?endpoint=products</span>
                      </button>
                      <button
                        onClick={() => testPhpEndpoint('animation_specs')}
                        disabled={testingEndpoint !== null}
                        className="px-3 py-1.5 bg-purple-900/40 hover:bg-purple-800/60 text-purple-200 rounded border border-purple-700/50 flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Play className="w-3 h-3 text-purple-400" />
                        <span>GET /api/php?endpoint=animation_specs</span>
                      </button>
                      <button
                        onClick={() => testPhpEndpoint('cart')}
                        disabled={testingEndpoint !== null}
                        className="px-3 py-1.5 bg-emerald-900/40 hover:bg-emerald-800/60 text-emerald-200 rounded border border-emerald-700/50 flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Play className="w-3 h-3 text-emerald-400" />
                        <span>GET /api/php?endpoint=cart</span>
                      </button>
                    </div>
                  </div>

                  {/* Live Response Output */}
                  <div className="bg-[#09090B] p-3 rounded border border-neutral-800 text-[11px] leading-relaxed max-h-56 overflow-y-auto">
                    {testingEndpoint ? (
                      <div className="text-amber-400 flex items-center gap-2">
                        <RotateCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Executing native PHP script on server...</span>
                      </div>
                    ) : apiResponse ? (
                      <pre className="text-emerald-300 whitespace-pre-wrap">
                        {JSON.stringify(apiResponse, null, 2)}
                      </pre>
                    ) : (
                      <div className="text-neutral-500 italic">
                        Click any endpoint above to trigger a real PHP script execution and view the exact JSON payload returned by the PHP engine.
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Tab 2: Kotlin Physics Lab */}
              {activeTab === 'kotlin' && (
                <div className="p-4 sm:p-6 overflow-y-auto space-y-5 text-xs font-mono">
                  {/* Presets Grid */}
                  <div>
                    <p className="text-[11px] text-neutral-400 uppercase tracking-widest mb-2 font-bold">
                      Select Jetpack Compose Spring Spec:
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {Object.values(KOTLIN_PRESETS).map((p) => {
                        const isSelected = currentPreset.id === p.id;
                        return (
                          <button
                            key={p.id}
                            onClick={() => onSelectPreset(p)}
                            className={`p-3 rounded text-left border transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-purple-950/40 border-purple-500 text-white shadow-sm'
                                : 'bg-neutral-900/60 border-neutral-800 text-neutral-400 hover:border-neutral-700 hover:text-neutral-200'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-1">
                              <span className="font-bold text-neutral-200">{p.name}</span>
                              {isSelected && <Check className="w-3.5 h-3.5 text-purple-400" />}
                            </div>
                            <p className="text-[11px] text-purple-300 font-semibold mb-1">{p.composeSpec}</p>
                            <p className="text-[10px] text-neutral-500 leading-normal">{p.description}</p>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Interactive Spring Playground Sandbox */}
                  <div className="p-4 bg-neutral-900/60 rounded border border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div>
                      <p className="font-bold text-white text-sm mb-1">Interactive Spring Sandbox</p>
                      <p className="text-[11px] text-neutral-400">
                        Click the luxury emblem to test current damping (&zeta; = {currentPreset.dampingRatio}) and stiffness (k = {currentPreset.stiffness}) in real time!
                      </p>
                    </div>

                    <motion.div
                      key={bounceTrigger}
                      initial={{ scale: 0.75, rotate: -8 }}
                      animate={{ scale: 1, rotate: 0 }}
                      transition={testSpring}
                      onClick={() => setBounceTrigger((prev) => prev + 1)}
                      className="w-20 h-20 bg-gradient-to-br from-amber-400 via-amber-600 to-amber-800 rounded-lg shadow-xl flex flex-col items-center justify-center cursor-pointer select-none border border-amber-300/40"
                    >
                      <span className="text-white font-extrabold text-sm tracking-wider font-sans">MK</span>
                      <span className="text-[9px] text-amber-100 uppercase tracking-widest font-mono">BOUNCE</span>
                    </motion.div>
                  </div>
                </div>
              )}

              {/* Tab 3: Kotlin & PHP Source Code */}
              {activeTab === 'code' && (
                <div className="p-4 sm:p-6 overflow-y-auto space-y-4 text-xs font-mono">
                  <div className="flex items-center justify-between">
                    <span className="text-purple-400 font-bold">
                      Jetpack Compose @Composable Component
                    </span>
                    <button
                      onClick={() => copyCode(KOTLIN_PRESETS[currentPreset.id].composeSpec)}
                      className="px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 flex items-center gap-1.5 transition-colors"
                    >
                      {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedCode ? 'Copied' : 'Copy Kotlin Spec'}</span>
                    </button>
                  </div>

                  <pre className="p-3 bg-[#09090B] text-neutral-300 rounded border border-neutral-800 text-[11px] max-h-60 overflow-y-auto leading-relaxed whitespace-pre-wrap">
{`// Kotlin Multiplatform / Jetpack Compose Animation Specification
// Product: Michael Kors Luxury Storefront
val LuxuryCardSpring = spring<Float>(
    dampingRatio = ${currentPreset.dampingRatio}f,
    stiffness = ${currentPreset.stiffness}f,
    visibilityThreshold = 0.001f
)

@Composable
fun LuxuryProductItem(product: Product) {
    val scale by animateFloatAsState(
        targetValue = if (isHovered) 1.035f else 1.0f,
        animationSpec = LuxuryCardSpring,
        label = "luxuryProductCardScale"
    )
    
    Card(modifier = Modifier.scale(scale)) {
        // Product content
    }
}`}
                  </pre>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
