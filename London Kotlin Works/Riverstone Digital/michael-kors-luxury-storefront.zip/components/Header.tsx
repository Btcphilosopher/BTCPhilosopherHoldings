'use client';

import React, { useState } from 'react';
import { Search, User, Heart, ShoppingBag, Menu, X, ArrowRight, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { kotlinToMotionSpring } from '@/lib/kotlin-physics';

interface HeaderProps {
  cartCount: number;
  wishlistCount: number;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onOpenSearch: () => void;
  onOpenVip: () => void;
  onSelectCategory: (category: string) => void;
  activeCategory: string;
}

const NAV_LINKS = [
  { label: 'WOMEN', slug: 'all', subtitle: 'New Season Runway & Essentials' },
  { label: 'MEN', slug: 'men', subtitle: 'Tailored Jackets, Bags & Leather' },
  { label: 'BAGS', slug: 'bags', subtitle: 'Totes, Satchels & Crossbodies' },
  { label: 'SHOES', slug: 'shoes', subtitle: 'Sneakers, Pumps & Stilettos' },
  { label: 'WATCHES', slug: 'watches', subtitle: 'Chronographs & Pavé Timepieces' },
  { label: 'ACCESSORIES', slug: 'accessories', subtitle: 'Sunglasses, Belts & Silk' },
  { label: 'COLLECTIONS', slug: 'collections', subtitle: 'Italian Lambskin & Runway Edit' },
  { label: 'SALE', slug: 'all', isSale: true, subtitle: 'Up to 40% Off Select Styles' },
];

export default function Header({
  cartCount,
  wishlistCount,
  onOpenCart,
  onOpenWishlist,
  onOpenSearch,
  onOpenVip,
  onSelectCategory,
  activeCategory,
}: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [hoveredNav, setHoveredNav] = useState<string | null>(null);

  const springBadge = kotlinToMotionSpring(0.72, 450);

  return (
    <>
      {/* Top Promotional Bar */}
      <div className="bg-[#111111] text-[#EFEBE4] text-xs py-2 px-4 tracking-wider uppercase flex items-center justify-between text-center transition-all border-b border-neutral-800">
        <div className="hidden lg:block text-[11px] text-neutral-400">
          Complimentary White-Glove Shipping & Returns on Orders $150+
        </div>
        <div className="w-full lg:w-auto text-center font-medium">
          Fall 2026 Collection — Use Code <span className="text-amber-300 font-semibold underline underline-offset-2">MKLUXURY</span> for 15% Off
        </div>
        <div className="hidden lg:flex items-center gap-4 text-[11px] text-neutral-400">
          <button onClick={onOpenVip} className="hover:text-white transition-colors cursor-pointer">
            VIP Kors Club
          </button>
          <span>·</span>
          <span>Find a Store</span>
        </div>
      </div>

      {/* Main Luxury Header */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-neutral-200/80 transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-6">
          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-neutral-800 hover:text-black transition-colors"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>

          {/* Brand Logo - MICHAEL KORS */}
          <div className="flex-1 lg:flex-none text-center lg:text-left">
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onSelectCategory('all');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="inline-block text-2xl sm:text-3xl font-extrabold tracking-[0.22em] text-neutral-950 font-sans hover:opacity-85 transition-opacity"
            >
              MICHAEL KORS
            </a>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-7 xl:gap-8 text-xs font-semibold tracking-[0.16em]">
            {NAV_LINKS.map((link) => {
              const isActive = activeCategory === link.slug && !link.isSale;
              return (
                <div
                  key={link.label}
                  className="relative py-6 group"
                  onMouseEnter={() => setHoveredNav(link.label)}
                  onMouseLeave={() => setHoveredNav(null)}
                >
                  <button
                    onClick={() => onSelectCategory(link.slug)}
                    className={`transition-colors uppercase whitespace-nowrap cursor-pointer ${
                      link.isSale
                        ? 'text-red-700 hover:text-red-800 font-bold'
                        : isActive
                        ? 'text-neutral-950 border-b-2 border-neutral-950 pb-1'
                        : 'text-neutral-700 hover:text-neutral-950'
                    }`}
                  >
                    {link.label}
                  </button>

                  {/* Mega-menu hover card for enhanced luxury interaction */}
                  <AnimatePresence>
                    {hoveredNav === link.label && (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 8 }}
                        transition={{ duration: 0.18, ease: 'easeOut' }}
                        className="absolute left-1/2 -translate-x-1/2 top-full w-72 bg-white shadow-xl border border-neutral-100 p-4 rounded-b-sm pointer-events-none"
                      >
                        <p className="text-[11px] font-medium text-neutral-400 uppercase tracking-widest mb-1">
                          Curated Category
                        </p>
                        <p className="text-sm font-semibold text-neutral-900 tracking-normal mb-2">
                          {link.label}
                        </p>
                        <p className="text-xs text-neutral-600 font-normal leading-relaxed">
                          {link.subtitle}
                        </p>
                        <div className="mt-3 flex items-center text-xs font-semibold text-neutral-900 tracking-wider">
                          <span>EXPLORE</span>
                          <ArrowRight className="w-3.5 h-3.5 ml-1.5" />
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </nav>

          {/* Right Action Icons */}
          <div className="flex items-center gap-4 sm:gap-6 text-neutral-800">
            {/* Search */}
            <button
              onClick={onOpenSearch}
              className="p-1.5 hover:text-black transition-colors rounded-full hover:bg-neutral-100"
              aria-label="Search collection"
              title="Search catalog"
            >
              <Search className="w-5 h-5" strokeWidth={1.75} />
            </button>

            {/* Account / VIP Club */}
            <button
              onClick={onOpenVip}
              className="p-1.5 hover:text-black transition-colors rounded-full hover:bg-neutral-100 hidden sm:block"
              aria-label="Account and VIP access"
              title="VIP Kors Club"
            >
              <User className="w-5 h-5" strokeWidth={1.75} />
            </button>

            {/* Wishlist */}
            <button
              onClick={onOpenWishlist}
              className="relative p-1.5 hover:text-black transition-colors rounded-full hover:bg-neutral-100"
              aria-label={`Wishlist with ${wishlistCount} items`}
              title="Saved items"
            >
              <Heart className="w-5 h-5" strokeWidth={1.75} />
              {wishlistCount > 0 && (
                <motion.span
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={springBadge}
                  className="absolute -top-1 -right-1 w-4 h-4 bg-neutral-900 text-white rounded-full text-[10px] font-bold flex items-center justify-center leading-none"
                >
                  {wishlistCount}
                </motion.span>
              )}
            </button>

            {/* Shopping Bag */}
            <button
              onClick={onOpenCart}
              className="relative p-1.5 hover:text-black transition-colors rounded-full hover:bg-neutral-100"
              aria-label={`Shopping bag with ${cartCount} items`}
              title="Shopping Bag"
            >
              <ShoppingBag className="w-5 h-5" strokeWidth={1.75} />
              {cartCount > 0 && (
                <motion.span
                  key={cartCount}
                  initial={{ scale: 0.4 }}
                  animate={{ scale: 1 }}
                  transition={springBadge}
                  className="absolute -top-1 -right-1 w-4.5 h-4.5 bg-neutral-950 text-white rounded-full text-[10px] font-bold flex items-center justify-center leading-none shadow-sm"
                >
                  {cartCount}
                </motion.span>
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.25, ease: 'easeInOut' }}
              className="lg:hidden border-t border-neutral-200 bg-white overflow-hidden"
            >
              <div className="px-6 py-6 space-y-4">
                {NAV_LINKS.map((link) => (
                  <button
                    key={link.label}
                    onClick={() => {
                      onSelectCategory(link.slug);
                      setMobileMenuOpen(false);
                    }}
                    className={`block w-full text-left text-sm font-semibold tracking-widest uppercase py-2 border-b border-neutral-100 ${
                      link.isSale ? 'text-red-700' : 'text-neutral-800'
                    }`}
                  >
                    {link.label}
                  </button>
                ))}
                <div className="pt-2 flex flex-col gap-3 text-xs tracking-wider">
                  <button
                    onClick={() => {
                      onOpenVip();
                      setMobileMenuOpen(false);
                    }}
                    className="flex items-center gap-2 py-2 text-neutral-700"
                  >
                    <User className="w-4 h-4" />
                    <span>VIP KORS CLUB REWARDS</span>
                  </button>
                  <button
                    onClick={() => {
                      onOpenWishlist();
                      setMobileMenuOpen(false);
                    }}
                    className="flex items-center gap-2 py-2 text-neutral-700"
                  >
                    <Heart className="w-4 h-4" />
                    <span>SAVED FAVORITES ({wishlistCount})</span>
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>
    </>
  );
}
