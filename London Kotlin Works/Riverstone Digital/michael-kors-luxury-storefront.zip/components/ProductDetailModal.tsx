'use client';

import React, { useState, useRef } from 'react';
import Image from 'next/image';
import { X, Heart, ShoppingBag, Star, ShieldCheck, Truck, RotateCw, Check, Code, Server, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Product } from '@/lib/types';
import { kotlinToMotionSpring, KOTLIN_PRESETS, generateKotlinCodeForComponent } from '@/lib/kotlin-physics';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, color: string, size: string, quantity: number) => void;
  onToggleWishlist: (product: Product) => void;
  isWishlisted: boolean;
}

export default function ProductDetailModal({
  product,
  onClose,
  onAddToCart,
  onToggleWishlist,
  isWishlisted,
}: ProductDetailModalProps) {
  // Initialize state directly from product prop
  const [selectedColor, setSelectedColor] = useState<string>(() => product?.colors[0]?.name || '');
  const [selectedSize, setSelectedSize] = useState<string>(() => product?.sizes[0] || 'One Size');
  const [quantity, setQuantity] = useState(1);
  const [isAdded, setIsAdded] = useState(false);
  const [activeTab, setActiveTab] = useState<'details' | 'kotlin' | 'php'>('details');

  // Interactive 360 rotation drag state
  const [rotationAngle, setRotationAngle] = useState(0);
  const isDraggingRef = useRef(false);
  const startXRef = useRef(0);

  if (!product) return null;

  const handlePointerDown = (e: React.PointerEvent) => {
    isDraggingRef.current = true;
    startXRef.current = e.clientX;
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDraggingRef.current) return;
    const deltaX = e.clientX - startXRef.current;
    startXRef.current = e.clientX;
    setRotationAngle((prev) => (prev + deltaX * 0.7) % 360);
  };

  const handlePointerUp = () => {
    isDraggingRef.current = false;
  };

  const handleAdd = () => {
    onAddToCart(product, selectedColor, selectedSize, quantity);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  const modalSpring = kotlinToMotionSpring(0.82, 380);
  const kotlinCode = generateKotlinCodeForComponent('LuxuryProductCard', KOTLIN_PRESETS.luxury_smooth);

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 lg:p-10">
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 16 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 12 }}
          transition={modalSpring}
          className="relative w-full max-w-4xl bg-white shadow-2xl border border-neutral-200 overflow-hidden flex flex-col max-h-[90vh]"
        >
          {/* Top Bar with Close button */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-200 bg-[#FAF8F5]">
            <div className="flex items-center gap-3">
              <span className="text-[11px] font-bold tracking-[0.2em] text-neutral-500 uppercase font-sans">
                MICHAEL KORS · {product.categoryName}
              </span>
              <span className="text-[10px] font-mono text-emerald-800 bg-emerald-100/80 px-2 py-0.5 rounded border border-emerald-300">
                In Stock ({product.inventory} available)
              </span>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 text-neutral-500 hover:text-black hover:bg-neutral-200/60 rounded-full transition-colors cursor-pointer"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Modal Body */}
          <div className="flex-1 overflow-y-auto p-6 sm:p-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Left Column: Interactive 360 Drag Stage */}
              <div className="lg:col-span-6 flex flex-col">
                <div
                  onPointerDown={handlePointerDown}
                  onPointerMove={handlePointerMove}
                  onPointerUp={handlePointerUp}
                  onPointerLeave={handlePointerUp}
                  className="relative aspect-square w-full bg-[#F5F2EC] overflow-hidden border border-neutral-200 cursor-grab active:cursor-grabbing select-none"
                >
                  {/* Subtle 360 instruction badge */}
                  <div className="absolute top-3 left-3 z-10 flex items-center gap-1.5 bg-black/70 text-white text-[10px] uppercase font-bold tracking-widest px-2.5 py-1 backdrop-blur-sm rounded-sm">
                    <RotateCw className="w-3 h-3 animate-spin text-amber-300" style={{ animationDuration: '6s' }} />
                    <span>Drag horizontally for 360° view</span>
                  </div>

                  {/* Dynamic angle reflection simulation */}
                  <div
                    className="w-full h-full relative transition-transform duration-75"
                    style={{
                      transform: `perspective(1000px) rotateY(${rotationAngle}deg)`,
                      transformStyle: 'preserve-3d',
                    }}
                  >
                    <Image
                      src={product.image}
                      alt={product.name}
                      fill
                      sizes="(max-width: 1024px) 100vw, 50vw"
                      referrerPolicy="no-referrer"
                      className="object-cover"
                      style={{
                        objectPosition:
                          product.imageSlice === 'bag'
                            ? '8% 66%'
                            : product.imageSlice === 'men'
                            ? '27% 66%'
                            : product.imageSlice === 'shoes'
                            ? '42% 66%'
                            : product.imageSlice === 'watches'
                            ? '58% 66%'
                            : product.imageSlice === 'accessories'
                            ? '73% 66%'
                            : product.imageSlice === 'collections'
                            ? '92% 66%'
                            : 'center 20%',
                        transform: 'scale(1.9)',
                      }}
                    />
                  </div>

                  {/* Bottom Angle HUD */}
                  <div className="absolute bottom-3 inset-x-3 flex items-center justify-between text-[11px] font-mono text-neutral-600 bg-white/90 backdrop-blur-sm px-3 py-1 border border-neutral-200/80 rounded-sm">
                    <span>Angle: {Math.round(((rotationAngle % 360 + 360) % 360))}°</span>
                    <span className="text-amber-800">Kotlin Gesture Damping: 0.75f</span>
                  </div>
                </div>

                {/* Micro guarantees */}
                <div className="mt-4 grid grid-cols-2 gap-3 text-xs text-neutral-600">
                  <div className="flex items-center gap-2 p-2 bg-neutral-50 rounded border border-neutral-200">
                    <ShieldCheck className="w-4 h-4 text-neutral-800 shrink-0" />
                    <span>100% Guaranteed Authentic</span>
                  </div>
                  <div className="flex items-center gap-2 p-2 bg-neutral-50 rounded border border-neutral-200">
                    <Truck className="w-4 h-4 text-neutral-800 shrink-0" />
                    <span>Complimentary Insured Delivery</span>
                  </div>
                </div>
              </div>

              {/* Right Column: Product Configurator & Purchasing */}
              <div className="lg:col-span-6 flex flex-col justify-between">
                <div>
                  {/* Rating & Reviews */}
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex items-center text-amber-500">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                      ))}
                    </div>
                    <span className="text-xs font-semibold text-neutral-800 font-mono tabular-nums">
                      {product.rating}
                    </span>
                    <span className="text-xs text-neutral-500">
                      ({product.reviewsCount} verified reviews)
                    </span>
                  </div>

                  {/* Title & Price */}
                  <h2 className="text-xl sm:text-2xl font-bold text-neutral-950 font-sans tracking-tight mb-2">
                    {product.name}
                  </h2>

                  <div className="flex items-baseline gap-3 mb-4">
                    <span className="text-2xl font-bold text-neutral-950 font-mono tabular-nums">
                      ${product.price.toFixed(2)}
                    </span>
                    {product.originalPrice && product.originalPrice > product.price && (
                      <span className="text-sm text-neutral-400 line-through font-mono tabular-nums">
                        ${product.originalPrice.toFixed(2)}
                      </span>
                    )}
                    <span className="text-xs font-medium text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      Includes Luxury Gift Packaging
                    </span>
                  </div>

                  <p className="text-xs sm:text-sm text-neutral-600 font-light leading-relaxed mb-6">
                    {product.description}
                  </p>

                  {/* Color Selector */}
                  <div className="mb-5">
                    <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-wider text-neutral-700 mb-2">
                      <span>Color / Material:</span>
                      <span className="text-neutral-900 font-bold">{selectedColor}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      {product.colors.map((color) => {
                        const isSelected = selectedColor === color.name;
                        return (
                          <button
                            key={color.name}
                            onClick={() => setSelectedColor(color.name)}
                            className={`flex items-center gap-2 px-3 py-1.5 text-xs rounded border transition-all cursor-pointer ${
                              isSelected
                                ? 'border-neutral-900 bg-neutral-900 text-white font-medium shadow-sm'
                                : 'border-neutral-200 bg-white text-neutral-700 hover:border-neutral-400'
                            }`}
                          >
                            <span
                              className="w-3.5 h-3.5 rounded-full border border-black/20"
                              style={{ backgroundColor: color.hex }}
                            />
                            <span>{color.name}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Size Selector */}
                  <div className="mb-6">
                    <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-wider text-neutral-700 mb-2">
                      <span>Select Size:</span>
                      <span className="text-neutral-500 font-normal">True to Designer Fit</span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {product.sizes.map((sz) => {
                        const isSelected = selectedSize === sz;
                        return (
                          <button
                            key={sz}
                            onClick={() => setSelectedSize(sz)}
                            className={`min-w-14 py-2 px-3 text-xs font-bold tracking-wider uppercase border transition-all cursor-pointer ${
                              isSelected
                                ? 'border-neutral-900 bg-neutral-900 text-white shadow-sm'
                                : 'border-neutral-200 bg-white text-neutral-800 hover:border-neutral-400'
                            }`}
                          >
                            {sz}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Quantity Stepper & Actions */}
                  <div className="flex items-center gap-4 mb-6">
                    <div className="flex items-center border border-neutral-300 bg-white">
                      <button
                        onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                        className="px-3 py-2 text-sm font-bold text-neutral-700 hover:bg-neutral-100 transition-colors"
                        aria-label="Decrease quantity"
                      >
                        -
                      </button>
                      <span className="px-4 py-2 text-xs font-mono font-bold text-neutral-900 tabular-nums">
                        {quantity}
                      </span>
                      <button
                        onClick={() => setQuantity((q) => Math.min(product.inventory, q + 1))}
                        className="px-3 py-2 text-sm font-bold text-neutral-700 hover:bg-neutral-100 transition-colors"
                        aria-label="Increase quantity"
                      >
                        +
                      </button>
                    </div>

                    {/* Primary Buy CTA */}
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={handleAdd}
                      className="flex-1 py-3 px-6 bg-neutral-950 text-white font-bold text-xs tracking-[0.2em] uppercase hover:bg-neutral-800 transition-all flex items-center justify-center gap-2 shadow-lg cursor-pointer"
                    >
                      {isAdded ? (
                        <>
                          <Check className="w-4 h-4 text-emerald-400" />
                          <span>Added to Shopping Bag</span>
                        </>
                      ) : (
                        <>
                          <ShoppingBag className="w-4 h-4" />
                          <span>Add to Shopping Bag</span>
                        </>
                      )}
                    </motion.button>

                    {/* Wishlist Button */}
                    <button
                      onClick={() => onToggleWishlist(product)}
                      className={`p-3 border transition-colors ${
                        isWishlisted
                          ? 'border-red-300 bg-red-50 text-red-600'
                          : 'border-neutral-300 bg-white text-neutral-700 hover:text-black hover:border-neutral-400'
                      }`}
                      aria-label="Save to Wishlist"
                    >
                      <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-red-600' : ''}`} />
                    </button>
                  </div>
                </div>

                {/* Technical Inspector Tabs */}
                <div className="border-t border-neutral-200 pt-4 mt-2">
                  <div className="flex items-center gap-4 border-b border-neutral-200 pb-2 mb-3 text-xs font-bold uppercase tracking-wider">
                    <button
                      onClick={() => setActiveTab('details')}
                      className={`pb-1 transition-colors cursor-pointer flex items-center gap-1.5 ${
                        activeTab === 'details'
                          ? 'text-neutral-900 border-b-2 border-neutral-900 font-extrabold'
                          : 'text-neutral-400 hover:text-neutral-700'
                      }`}
                    >
                      <Info className="w-3.5 h-3.5" />
                      <span>Details & Craft</span>
                    </button>
                    <button
                      onClick={() => setActiveTab('kotlin')}
                      className={`pb-1 transition-colors cursor-pointer flex items-center gap-1.5 ${
                        activeTab === 'kotlin'
                          ? 'text-neutral-900 border-b-2 border-neutral-900 font-extrabold'
                          : 'text-neutral-400 hover:text-neutral-700'
                      }`}
                    >
                      <Code className="w-3.5 h-3.5 text-purple-600" />
                      <span>Kotlin Compose Code</span>
                    </button>
                    <button
                      onClick={() => setActiveTab('php')}
                      className={`pb-1 transition-colors cursor-pointer flex items-center gap-1.5 ${
                        activeTab === 'php'
                          ? 'text-neutral-900 border-b-2 border-neutral-900 font-extrabold'
                          : 'text-neutral-400 hover:text-neutral-700'
                      }`}
                    >
                      <Server className="w-3.5 h-3.5 text-blue-600" />
                      <span>PHP 8.2 API Output</span>
                    </button>
                  </div>

                  {activeTab === 'details' && (
                    <div className="space-y-2 text-xs text-neutral-600 max-h-36 overflow-y-auto">
                      <p className="font-semibold text-neutral-900">Craftsmanship Heritage:</p>
                      <p className="italic text-neutral-700">{product.craftsmanship}</p>
                      <ul className="list-disc pl-4 space-y-1 pt-1">
                        {product.details.map((detail, idx) => (
                          <li key={idx}>{detail}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {activeTab === 'kotlin' && (
                    <div className="bg-[#18181B] text-[#E4E4E7] p-3 rounded font-mono text-[11px] max-h-36 overflow-y-auto leading-relaxed border border-neutral-800">
                      <div className="text-purple-400 mb-1">{'// Jetpack Compose Physics Animation Spec'}</div>
                      <div className="text-amber-300 font-semibold mb-2">
                        {product.kotlinAnimation.spec}
                      </div>
                      <pre className="text-neutral-300 whitespace-pre-wrap">{kotlinCode}</pre>
                    </div>
                  )}

                  {activeTab === 'php' && (
                    <div className="bg-[#0F172A] text-[#93C5FD] p-3 rounded font-mono text-[11px] max-h-36 overflow-y-auto leading-relaxed border border-blue-900/40">
                      <div className="text-emerald-400 mb-1">
                        HTTP/1.1 200 OK · X-Powered-By: PHP/8.2.35
                      </div>
                      <pre className="text-neutral-200 whitespace-pre-wrap">
                        {JSON.stringify(
                          {
                            id: product.id,
                            name: product.name,
                            category: product.category,
                            price: product.price,
                            inventory: product.inventory,
                            kotlinSpec: product.kotlinAnimation,
                            endpoint: `/api/php/products.php?id=${product.id}`,
                          },
                          null,
                          2
                        )}
                      </pre>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
