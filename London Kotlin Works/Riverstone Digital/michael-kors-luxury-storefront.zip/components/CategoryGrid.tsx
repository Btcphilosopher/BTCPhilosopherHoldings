'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';
import { kotlinToMotionSpring } from '@/lib/kotlin-physics';

interface CategoryGridProps {
  onSelectCategory: (category: string) => void;
  activeCategory: string;
}

// 6 Categories matching the exact row in the uploaded screenshot
const CATEGORIES = [
  {
    id: 'bags',
    name: 'BAGS',
    label: 'Bags',
    subtitle: 'Signature Totes, Satchels & Crossbodies',
    cta: 'Shop Now',
    // Using user uploaded asset with tailored focus
    image: '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png',
    objectPosition: '8% 66%',
    scale: 2.2,
  },
  {
    id: 'men',
    name: 'MEN',
    label: 'Men',
    subtitle: 'Tailored Jackets & Modern Outerwear',
    cta: 'Shop Now',
    image: '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png',
    objectPosition: '27% 66%',
    scale: 2.2,
  },
  {
    id: 'shoes',
    name: 'SHOES',
    label: 'Shoes',
    subtitle: 'Luxe Sneakers, Stilettos & Flats',
    cta: 'Shop Now',
    image: '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png',
    objectPosition: '42% 66%',
    scale: 2.2,
  },
  {
    id: 'watches',
    name: 'WATCHES',
    label: 'Watches',
    subtitle: 'Iconic Gold-Tone & Pavé Timepieces',
    cta: 'Shop Now',
    image: '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png',
    objectPosition: '58% 66%',
    scale: 2.2,
  },
  {
    id: 'accessories',
    name: 'ACCESSORIES',
    label: 'Accessories',
    subtitle: 'Italian Acetate Sunglasses & Belts',
    cta: 'Shop Now',
    image: '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png',
    objectPosition: '73% 66%',
    scale: 2.2,
  },
  {
    id: 'collections',
    name: 'COLLECTIONS',
    label: 'Collections',
    subtitle: 'Runway Lambskin & Editorial Coats',
    cta: 'Shop Now',
    image: '/assets/aistudio/bdc013a3-9460-41c0-b33c-912cdc9065a8_798f7e31.png',
    objectPosition: '92% 66%',
    scale: 2.2,
  },
];

export default function CategoryGrid({ onSelectCategory, activeCategory }: CategoryGridProps) {
  const kotlinHoverSpring = kotlinToMotionSpring(0.75, 350);

  return (
    <section className="py-14 sm:py-20 bg-[#FAF8F5] border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 sm:mb-12 border-b border-neutral-200/80 pb-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-neutral-500 mb-2">
              Curated Highlights
            </p>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-[0.14em] text-neutral-900 uppercase font-sans">
              Shop By Category
            </h2>
          </div>
          <button
            onClick={() => onSelectCategory('all')}
            className="mt-3 sm:mt-0 text-xs font-bold tracking-[0.18em] uppercase text-neutral-800 hover:text-black flex items-center gap-2 group cursor-pointer"
          >
            <span>View All Collections</span>
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </button>
        </div>

        {/* 6 Category Tiles Row matching screenshot */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 sm:gap-5">
          {CATEGORIES.map((cat) => {
            const isSelected = activeCategory === cat.id;

            return (
              <motion.div
                key={cat.id}
                whileHover={{ y: -4 }}
                transition={kotlinHoverSpring}
                onClick={() => onSelectCategory(cat.id)}
                className={`group cursor-pointer flex flex-col bg-white border transition-all duration-200 ${
                  isSelected
                    ? 'border-neutral-950 shadow-md ring-1 ring-neutral-950'
                    : 'border-neutral-200/80 hover:border-neutral-400 hover:shadow-sm'
                }`}
              >
                {/* Image Frame */}
                <div className="relative w-full aspect-[4/3] sm:aspect-square overflow-hidden bg-neutral-100">
                  <div
                    className="w-full h-full relative transition-transform duration-500 group-hover:scale-105"
                    style={{ overflow: 'hidden' }}
                  >
                    <Image
                      src={cat.image}
                      alt={`Michael Kors ${cat.name}`}
                      fill
                      sizes="(max-width: 768px) 50vw, (max-width: 1200px) 33vw, 16vw"
                      referrerPolicy="no-referrer"
                      className="object-cover"
                      style={{
                        objectPosition: cat.objectPosition,
                        transform: `scale(${cat.scale})`,
                        transformOrigin: cat.objectPosition,
                      }}
                    />
                  </div>
                </div>

                {/* Card Text & CTA matching screenshot exactly */}
                <div className="p-3.5 sm:p-4 flex flex-col justify-between flex-1 bg-white">
                  <div>
                    <h3 className="text-xs sm:text-sm font-bold tracking-[0.18em] text-neutral-950 uppercase font-sans">
                      {cat.name}
                    </h3>
                  </div>

                  <div className="mt-2.5 flex items-center text-[11px] font-semibold tracking-wider text-neutral-700 group-hover:text-black">
                    <span className="group-hover:underline underline-offset-4">{cat.cta}</span>
                    <ArrowRight className="w-3.5 h-3.5 ml-1 transition-transform group-hover:translate-x-1" />
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
