export interface Product {
  id: string;
  name: string;
  subtitle?: string;
  brand: string;
  department: string;
  category: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewsCount: number;
  image: string;
  isNew?: boolean;
  isBestseller?: boolean;
  isWindsorExclusive?: boolean;
  description: string;
  features: string[];
  inStock: boolean;
  sizes?: string[];
  colors?: string[];
}

export interface Department {
  id: string;
  name: string;
  isItalic?: boolean;
  hasSubmenu?: boolean;
  subcategories: string[];
}

export const DEPARTMENTS: Department[] = [
  {
    id: 'christmas',
    name: 'Christmas',
    hasSubmenu: true,
    subcategories: ['Christmas Trees & Lights', 'Festive Baubles & Trim', 'Christmas Hampers', 'Advent Calendars', 'Gift Wrap & Cards', 'Tableware & Crackers']
  },
  {
    id: 'women',
    name: 'Women',
    hasSubmenu: true,
    subcategories: ['Coats & Jackets', 'Cashmere & Knitwear', 'Dresses', 'Handbags & Leather', 'Shoes & Boots', 'Jewellery & Watches']
  },
  {
    id: 'men',
    name: 'Men',
    hasSubmenu: true,
    subcategories: ['Tailoring & Suits', 'Overcoats & Jackets', 'Knitwear & Shirts', 'Shoes & Brogues', 'Accessories & Ties', 'Grooming']
  },
  {
    id: 'beauty',
    name: 'Beauty',
    hasSubmenu: true,
    subcategories: ['Fragrance & Perfume', 'Luxury Skincare', 'Cosmetics', 'Bath & Body', 'Candles & Diffusers', 'Men’s Grooming']
  },
  {
    id: 'home',
    name: 'Home & Living',
    hasSubmenu: true,
    subcategories: ['Bedding & Linens', 'Throws & Tartan Cushions', 'Cookware & Tableware', 'Lighting & Lamps', 'Home Fragrance', 'Rugs & Flooring']
  },
  {
    id: 'furniture',
    name: 'Furniture',
    hasSubmenu: true,
    subcategories: ['Sofas & Armchairs', 'Dining Tables', 'Bedroom Suites', 'Bookcases & Cabinets', 'Occasional Tables']
  },
  {
    id: 'electricals',
    name: 'Electricals',
    hasSubmenu: true,
    subcategories: ['Coffee Machines', 'Stand Mixers & Blenders', 'Kettles & Toasters', 'Audio & Radios', 'Personal Care Tech']
  },
  {
    id: 'gifts',
    name: 'Gifts',
    hasSubmenu: true,
    subcategories: ['Gifts for Her', 'Gifts for Him', 'Gifts for Children', 'Luxury Hampers', 'Personalised Keepsakes', 'Gift Vouchers']
  },
  {
    id: 'toys',
    name: 'Toys',
    hasSubmenu: true,
    subcategories: ['The Toy Emporium', 'Traditional Wooden Toys', 'LEGO & Building Sets', 'Steiff & Soft Bears', 'Board Games & Puzzles', 'Baby & Nursery']
  },
  {
    id: 'food-wine',
    name: 'Food & Wine',
    hasSubmenu: true,
    subcategories: ['Fine Wines & Champagne', 'Artisan Chocolates', 'British Teas & Coffee', 'Biscuits & Preserves', 'Gourmet Hampers', 'Liqueurs & Spirits']
  },
  {
    id: 'brands',
    name: 'Brands',
    hasSubmenu: true,
    subcategories: ['Barbour', 'Diptyque', 'Mulberry', 'Dualit', 'KitchenAid', 'Steiff', 'Fortnum Pantry', 'Wedgwood']
  },
  {
    id: 'inspiration',
    name: 'Inspiration',
    isItalic: true,
    hasSubmenu: true,
    subcategories: ['The Christmas Gift Guide', 'Windsor Castle Heritage Journal', 'Hosting Festive Dinners', 'Autumn/Winter Lookbook', 'Afternoon Tea at Daniel’s']
  }
];

export const HERO_SLIDES = [
  {
    id: 'slide-christmas',
    kicker: 'THE CHRISTMAS COLLECTION',
    title: 'A Season of Gifting',
    titleItalicWord: 'of',
    description: 'Beautiful presents, timeless favourites and festive inspiration at Daniel’s.',
    ctaPrimary: 'Shop Christmas',
    ctaPrimaryTarget: 'christmas',
    ctaSecondary: 'Visit Our Windsor Store',
    ctaSecondaryAction: 'store-modal',
    badge: 'Flagship Holiday 2026',
    image: '/assets/aistudio/ea03ea82-87f7-40b3-ba24-3f1a34822318_3ecbe935.png',
    overlayPosition: 'left'
  },
  {
    id: 'slide-fashion',
    kicker: 'AUTUMN / WINTER 2026',
    title: 'Heritage Elegance',
    titleItalicWord: 'Elegance',
    description: 'Sumptuous Scottish cashmere, tailored woollen overcoats, and handcrafted leather accessories.',
    ctaPrimary: 'Shop Womenswear',
    ctaPrimaryTarget: 'women',
    ctaSecondary: 'Shop Menswear',
    ctaSecondaryAction: 'men',
    badge: 'New Season In Store',
    image: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=1920&q=85',
    overlayPosition: 'left'
  },
  {
    id: 'slide-hampers',
    kicker: 'WINDSOR FINE PANTRY',
    title: 'The Royal Hamper Collection',
    titleItalicWord: 'Hamper',
    description: 'Curated wicker hampers filled with champagne, artisan preserves, and handmade truffles.',
    ctaPrimary: 'Discover Hampers',
    ctaPrimaryTarget: 'food-wine',
    ctaSecondary: 'Gift Food & Wine',
    ctaSecondaryAction: 'food-wine',
    badge: 'Hand-packed in Windsor',
    image: 'https://images.unsplash.com/photo-1543339308-43e59d6b73a6?auto=format&fit=crop&w=1920&q=85',
    overlayPosition: 'left'
  }
];

export const VALUE_PROPOSITIONS = [
  {
    icon: 'truck',
    title: 'Free UK Delivery',
    subtitle: 'on orders over £75'
  },
  {
    icon: 'bag',
    title: 'Click & Collect',
    subtitle: 'from Daniel of Windsor'
  },
  {
    icon: 'crown',
    title: 'Proudly Independent',
    subtitle: 'Family owned since 1900'
  },
  {
    icon: 'leaf',
    title: 'Sustainable Choices',
    subtitle: 'Responsible brands and packaging'
  }
];

export const CATEGORY_TILES = [
  {
    id: 'women',
    name: 'Women',
    image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80',
    description: 'Cashmere, tailoring, dresses & accessories'
  },
  {
    id: 'men',
    name: 'Men',
    image: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80',
    description: 'Heritage overcoats, shirts & grooming'
  },
  {
    id: 'beauty',
    name: 'Beauty',
    image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=800&q=80',
    description: 'Fine fragrances, luxury serums & candles'
  },
  {
    id: 'home',
    name: 'Home & Living',
    image: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=800&q=80',
    description: 'Plush cushions, festive table settings & lamps'
  },
  {
    id: 'food-wine',
    name: 'Food & Wine',
    image: 'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=800&q=80',
    description: 'Vintage champagnes, artisan hampers & tea'
  }
];

export const PRODUCTS: Product[] = [
  {
    id: 'dw-001',
    name: 'The Windsor Castle Luxury Wicker Hamper',
    subtitle: 'Feast of British Artisan Preserves, Fine Champagne & Truffles',
    brand: 'Daniel of Windsor Exclusives',
    department: 'food-wine',
    category: 'Christmas Hampers',
    price: 155.00,
    originalPrice: 175.00,
    rating: 4.9,
    reviewsCount: 142,
    image: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=800&q=80',
    isBestseller: true,
    isWindsorExclusive: true,
    description: 'Our signature festive wicker hamper, hand-embossed with the Daniel of Windsor crest and filled with estate-bottled Champagne, Windsor Spiced Plum Jam, artisan butter shortbread, and dark chocolate truffles.',
    features: [
      'Authentic handcrafted British steamed wicker basket with leather straps',
      '75cl Premier Cru Brut Reserve Champagne',
      'Handmade Windsor Castle all-butter shortbread rounds',
      'Artisan Spiced Orange & Fig preserve (320g)',
      'Single-origin Peruvian dark chocolate truffles (200g)',
      'Complimentary royal Windsor presentation card'
    ],
    inStock: true
  },
  {
    id: 'dw-002',
    name: 'Hand-Carved Royal Guard Nutcracker (45cm)',
    subtitle: 'Hand-Painted Traditional Wooden Figurine in Regal Uniform',
    brand: 'Daniel Festive Heritage',
    department: 'christmas',
    category: 'Festive Baubles & Trim',
    price: 68.00,
    rating: 5.0,
    reviewsCount: 88,
    image: 'https://images.unsplash.com/photo-1545641203-7d072a14e3b2?auto=format&fit=crop&w=800&q=80',
    isBestseller: true,
    description: 'A stately 45cm hand-carved nutcracker soldier standing proudly in festive regalia, complete with ceremonial sword, gilded epaulettes, and gold-leaf details.',
    features: [
      'Solid sustainable European beechwood construction',
      'Detailed hand-painted enamel finish with 24k gold leaf accents',
      'Working jaw lever mechanism',
      'Velvet base pad to protect polished mantelpieces and surfaces'
    ],
    inStock: true
  },
  {
    id: 'dw-003',
    name: 'Pure Scottish Cashmere Scarf in Windsor Tartan',
    subtitle: '100% Ripple-Finish Cashmere Woven in Elgin, Scotland',
    brand: 'Johnstons of Elgin for Daniel',
    department: 'women',
    category: 'Cashmere & Knitwear',
    price: 135.00,
    rating: 4.9,
    reviewsCount: 210,
    image: 'https://images.unsplash.com/photo-1520903920243-00d872a2d1c9?auto=format&fit=crop&w=800&q=80',
    isBestseller: true,
    isWindsorExclusive: true,
    description: 'Spun from the finest cashmere yarns with an exceptionally soft ripple water-wash finish. Custom-dyed in Daniel’s signature royal plum and honey tones.',
    features: [
      '100% Grade-A Mongolian Cashmere',
      'Woven on historic looms in Scotland',
      'Dimensions: 190cm x 35cm with fringed ends',
      'Dry clean only; delivered in Daniel gold-foil gift envelope'
    ],
    sizes: ['One Size'],
    colors: ['Windsor Tartan', 'Deep Plum', 'Camel Heather', 'Forest Green'],
    inStock: true
  },
  {
    id: 'dw-004',
    name: 'Royal Botanical Frankincense & Amber Candle',
    subtitle: 'Hand-Poured Mineral & Vegetable Wax Candle (300g)',
    brand: 'Daniel of Windsor Apothecary',
    department: 'beauty',
    category: 'Candles & Diffusers',
    price: 42.00,
    rating: 4.8,
    reviewsCount: 96,
    image: 'https://images.unsplash.com/photo-1603006905003-be475563bc59?auto=format&fit=crop&w=800&q=80',
    isNew: true,
    description: 'An evocative winter scent inspired by the ancient royal chapels of Windsor. Notes of warm frankincense, golden amber, cedar smoke, and spiced orange peel.',
    features: [
      '300g hand-blown frosted amber glass vessel',
      'Approximate burn time of 65 hours',
      'Double lead-free cotton wicks for an even pool',
      'Embossed brass dust cover stamped with 1900 founding year'
    ],
    inStock: true
  },
  {
    id: 'dw-005',
    name: 'Heritage Tailored Wool Double-Breasted Overcoat',
    subtitle: '100% British Melleton Wool with Horn Buttons',
    brand: 'Daniel Bespoke Tailors',
    department: 'men',
    category: 'Overcoats & Jackets',
    price: 345.00,
    originalPrice: 395.00,
    rating: 4.9,
    reviewsCount: 54,
    image: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=800&q=80',
    isWindsorExclusive: true,
    description: 'Meticulously tailored from heavy 650gsm Yorkshire wool melton. Designed to withstand crisp winter days in Windsor Great Park while keeping an immaculate silhouette.',
    features: [
      '100% British wool spun in Yorkshire mills',
      'Full Bemberg cupro silk lining in contrasting burgundy',
      'Genuine polished buffalo horn buttons',
      'Deep welt pockets and interior ticket pocket'
    ],
    sizes: ['38R', '40R', '42R', '44R', '46R'],
    colors: ['Charcoal Melton', 'Windsor Navy', 'Camel'],
    inStock: true
  },
  {
    id: 'dw-006',
    name: 'Festive Tartan Wool Cushion & Down Insert',
    subtitle: 'Traditional Scottish Wool Fabric with Burgundy Velvet Piping',
    brand: 'Daniel Home Collection',
    department: 'home',
    category: 'Throws & Tartan Cushions',
    price: 65.00,
    rating: 4.7,
    reviewsCount: 78,
    image: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=800&q=80',
    description: 'Introduce rich warmth to your living room. Woven from 100% pure new wool in rich berry and forest green checks, backed with plush plum cotton velvet.',
    features: [
      '50cm x 50cm square cushion',
      'Includes plump British duck feather and down pad',
      'Concealed brass zipper closure',
      'Dry clean recommended'
    ],
    colors: ['Royal Tartan Berry', 'Balmoral Forest', 'Heather Slate'],
    inStock: true
  },
  {
    id: 'dw-007',
    name: 'Dualit Heritage 2-Slice Architect Toaster',
    subtitle: 'Polished Stainless Steel with Patented ProHeat Elements',
    brand: 'Dualit',
    department: 'electricals',
    category: 'Kettles & Toasters',
    price: 185.00,
    rating: 4.9,
    reviewsCount: 165,
    image: 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?auto=format&fit=crop&w=800&q=80',
    isBestseller: true,
    description: 'Built to commercial standards by Britain’s premier kitchenware brand. Features interchangeable side panels, peek-and-pop browning check, and extra-wide 36mm slots.',
    features: [
      'Commercial-grade stainless steel body built to last a lifetime',
      'Patented ProHeat elements with protective armour plate',
      'Bagel and defrost warming controls',
      'Handcrafted in Crawley, West Sussex, UK'
    ],
    inStock: true
  },
  {
    id: 'dw-008',
    name: 'Limited Edition Steiff Collector Bear in Velvet Waistcoat',
    subtitle: 'Handmade Mohair Teddy Bear with Historic Growler (32cm)',
    brand: 'Steiff',
    department: 'toys',
    category: 'Steiff & Soft Bears',
    price: 110.00,
    rating: 5.0,
    reviewsCount: 43,
    image: 'https://images.unsplash.com/photo-1559454403-b8fb88521f11?auto=format&fit=crop&w=800&q=80',
    isWindsorExclusive: true,
    description: 'Exclusively commissioned for Daniel of Windsor Toy Emporium. Crafted from golden cinnamon mohair, dressed in a royal plum velvet waistcoat with brass buttons.',
    features: [
      'Fine woven mohair coat with 5-way jointed limbs',
      'Famous Steiff gold-plated "Button in Ear" certification',
      'Internal classic tilt growler voice',
      'Strictly limited edition of 500 numbered pieces worldwide'
    ],
    inStock: true
  },
  {
    id: 'dw-009',
    name: 'Windsor Castle Limited Edition Musical Snow Globe',
    subtitle: 'Plays "Silent Night" with Automatic Gilded Snow Flurry',
    brand: 'Daniel of Windsor Keepsakes',
    department: 'christmas',
    category: 'Festive Baubles & Trim',
    price: 52.00,
    rating: 4.8,
    reviewsCount: 112,
    image: 'https://images.unsplash.com/photo-1512474932049-78ac69eed10c?auto=format&fit=crop&w=800&q=80',
    isNew: true,
    isBestseller: true,
    description: 'A magical heirloom centrepiece capturing Windsor Castle’s Round Tower in a snow flurry, with a wind-up Swiss mechanical movement playing Silent Night.',
    features: [
      'Heavy 120mm crystal glass dome',
      'Ornate cast resin base with relief sculptures of Windsor Castle gates',
      'Precision wind-up 18-note mechanical musical chime',
      'Packaged in satin-lined royal presentation box'
    ],
    inStock: true
  },
  {
    id: 'dw-010',
    name: 'Advanced Botanical Youth Renewal Elixir (50ml)',
    subtitle: 'Certified Organic British Meadow Botanical Face Oil',
    brand: 'Aurelia Botanical Care',
    department: 'beauty',
    category: 'Luxury Skincare',
    price: 78.00,
    rating: 4.9,
    reviewsCount: 187,
    image: 'https://images.unsplash.com/photo-1608248597359-561352115197?auto=format&fit=crop&w=800&q=80',
    description: 'Formulated with cold-pressed rosehip, English borage seed, and neroli flower oils. Deeply nourishes winter-stressed skin, leaving a dewy, youthful radiance.',
    features: [
      'Formulated and blended in the English countryside',
      'Rich in Essential Fatty Acids Omega 3, 6 & 9',
      '100% natural, cruelty-free, and vegan certified',
      'Presented in UV-protective violet glass with dropper'
    ],
    inStock: true
  },
  {
    id: 'dw-011',
    name: 'Royal Windsor Fine Bone China Teapot for Four',
    subtitle: 'Hand-Applied 22k Gold Filigree on Pristine English China',
    brand: 'Royal Crown Derby for Daniel',
    department: 'home',
    category: 'Cookware & Tableware',
    price: 145.00,
    originalPrice: 165.00,
    rating: 4.9,
    reviewsCount: 67,
    image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=800&q=80',
    isWindsorExclusive: true,
    description: 'Made by master artisans in Stoke-on-Trent. Adorned with delicate botanical tendrils and hand-burnished 22-karat liquid gold leaf, embodying traditional tea ritual.',
    features: [
      'Translucent English fine bone china',
      'Capacity: 1.1 Litres (serves 4-6 cups)',
      'Non-drip spout with built-in internal strainer holes',
      'Hand washing recommended'
    ],
    inStock: true
  },
  {
    id: 'dw-012',
    name: 'Reserve Brut Vintage Champagne & Truffle Caddy',
    subtitle: 'Grand Cru Vintage 2018 with Marc de Champagne Truffles',
    brand: 'Daniel Cellar Reserve',
    department: 'food-wine',
    category: 'Fine Wines & Champagne',
    price: 85.00,
    rating: 5.0,
    reviewsCount: 104,
    image: 'https://images.unsplash.com/photo-1569919659476-f0852f6834b7?auto=format&fit=crop&w=800&q=80',
    isBestseller: true,
    description: 'The definitive gift for celebrations. A bottle of our acclaimed vintage Brut Champagne paired with dusted Marc de Champagne truffles in an embossed gold tin.',
    features: [
      'Aged 5 years on lees for delicate brioche and golden pear notes',
      'Box of 16 artisan dusted truffles',
      'Gold foil-embossed Daniel presentation gift bag with velvet ties'
    ],
    inStock: true
  }
];

export const WINDSOR_STORE_INFO = {
  name: 'Daniel of Windsor Department Store',
  established: '1900',
  address: {
    line1: '120–124 Peascod Street',
    town: 'Windsor',
    county: 'Berkshire',
    postcode: 'SL4 1DP',
    country: 'United Kingdom'
  },
  landmark: '2 minutes walk from Windsor Castle and Windsor & Eton Central Station',
  phone: '+44 (0)1753 801000',
  customerServiceEmail: 'concierge@danielofwindsor.co.uk',
  openingHours: [
    { day: 'Monday', hours: '09:00 – 17:30' },
    { day: 'Tuesday', hours: '09:00 – 17:30' },
    { day: 'Wednesday', hours: '09:00 – 17:30' },
    { day: 'Thursday', hours: '09:00 – 17:30' },
    { day: 'Friday', hours: '09:00 – 17:30' },
    { day: 'Saturday', hours: '09:00 – 18:00' },
    { day: 'Sunday', hours: '10:30 – 16:30' }
  ],
  services: [
    {
      title: 'Personal Shopping Suite',
      desc: 'Complimentary styling appointments with champagne in our private Georgian suite.'
    },
    {
      title: 'The Toy Emporium',
      desc: 'Two dedicated floors of magic, Steiff bears, LEGO masterworks, and festive model railways.'
    },
    {
      title: 'Daniel’s Tea Room & Coffee Lounge',
      desc: 'Traditional high tea, artisan cakes, and panoramic views of Windsor’s historic quarter.'
    },
    {
      title: 'Complimentary Gift Wrapping',
      desc: 'Signature Daniel of Windsor gift paper with wax seal and satin ribbon on all purchases.'
    },
    {
      title: 'Click & Collect Concierge',
      desc: 'Collect online orders in store within 2 hours, 7 days a week.'
    }
  ]
};
