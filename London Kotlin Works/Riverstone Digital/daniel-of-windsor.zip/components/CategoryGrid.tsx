'use client';

import React from 'react';
import { ChevronRight } from 'lucide-react';
import { useStore } from '@/context/StoreContext';

export default function CategoryGrid() {
  const { setActiveDepartment } = useStore();

  const categories = [
    {
      id: 'women',
      title: 'Women',
      image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=800&q=80',
      alt: 'Daniel of Windsor Women collection with luxury knitwear and coats',
      target: 'women'
    },
    {
      id: 'men',
      title: 'Men',
      image: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80',
      alt: 'Daniel of Windsor Men collection with tailored wool coats',
      target: 'men'
    },
    {
      id: 'beauty',
      title: 'Beauty',
      image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=800&q=80',
      alt: 'Daniel of Windsor Beauty, fine fragrances, and luxury skincare',
      target: 'beauty'
    },
    {
      id: 'home',
      title: 'Home & Living',
      image: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=800&q=80',
      alt: 'Daniel of Windsor Home and Living with tartan cushions and cosy furnishings',
      target: 'home'
    },
    {
      id: 'food-wine',
      title: 'Food & Wine',
      image: 'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=800&q=80',
      alt: 'Daniel of Windsor Food and Wine with festive banquet and champagne',
      target: 'food-wine'
    }
  ];

  const handleCategorySelect = (deptId: string) => {
    setActiveDepartment(deptId);
    const catalog = document.getElementById('curated-collection');
    if (catalog) {
      catalog.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="w-full bg-[#fbf9f6] py-8 sm:py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* 5-Column Responsive Category Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
          {categories.map((cat) => (
            <div
              key={cat.id}
              onClick={() => handleCategorySelect(cat.target)}
              className="group relative h-48 sm:h-56 md:h-64 lg:h-72 w-full overflow-hidden rounded-xs cursor-pointer shadow-xs bg-stone-200"
            >
              {/* Background Photo */}
              <img
                src={cat.image}
                alt={cat.alt}
                className="w-full h-full object-cover object-center group-hover:scale-108 transition-transform duration-700 ease-out"
                loading="lazy"
              />

              {/* Gradient Scrim Overlay at base */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-transparent pointer-events-none group-hover:from-black/90 transition-colors" />

              {/* Category Label at Bottom Left matching reference */}
              <div className="absolute bottom-3.5 left-4 right-4 flex items-center justify-between text-white z-10">
                <span className="font-serif text-lg sm:text-xl font-normal tracking-wide text-white drop-shadow-sm flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                  {cat.title}
                  <ChevronRight className="w-4 h-4 text-white/90 stroke-[2]" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
