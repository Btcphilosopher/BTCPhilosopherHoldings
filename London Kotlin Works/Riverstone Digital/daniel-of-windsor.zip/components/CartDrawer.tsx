'use client';

import React, { useState } from 'react';
import { X, Trash2, ShoppingBag, ArrowRight, ShieldCheck, Gift, CheckCircle2 } from 'lucide-react';
import { useStore } from '@/context/StoreContext';

export default function CartDrawer() {
  const {
    cart,
    isCartOpen,
    setIsCartOpen,
    removeFromCart,
    updateQuantity,
    toggleGiftWrap,
    cartSubtotal,
    clearCart,
  } = useStore();

  const [promoCode, setPromoCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const [promoError, setPromoError] = useState('');
  const [promoSuccess, setPromoSuccess] = useState('');
  const [isCheckoutModalOpen, setIsCheckoutModalOpen] = useState(false);
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [orderNumber, setOrderNumber] = useState('DW-819204');
  const [customerName, setCustomerName] = useState('Lady Eleanor');
  const [customerEmail, setCustomerEmail] = useState('eleanor@windsor-estate.co.uk');

  if (!isCartOpen && !isCheckoutModalOpen) return null;

  const freeDeliveryThreshold = 75;
  const isFreeDelivery = cartSubtotal >= freeDeliveryThreshold;
  const amountToFreeDelivery = Math.max(0, freeDeliveryThreshold - cartSubtotal);
  const deliveryFee = cart.length === 0 ? 0 : isFreeDelivery ? 0 : 4.95;

  const discountAmount = (cartSubtotal * discountPercent) / 100;
  const grandTotal = Math.max(0, cartSubtotal - discountAmount + deliveryFee);

  const applyPromoCode = (e: React.FormEvent) => {
    e.preventDefault();
    setPromoError('');
    setPromoSuccess('');
    const code = promoCode.trim().toUpperCase();
    if (code === 'WINDSOR10' || code === 'CHRISTMAS10') {
      setDiscountPercent(10);
      setPromoSuccess('10% Royal Heritage discount applied!');
    } else if (code === 'ROYAL15') {
      setDiscountPercent(15);
      setPromoSuccess('15% VIP Festive discount applied!');
    } else {
      setPromoError('Invalid promo code. Try "WINDSOR10".');
    }
  };

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setOrderNumber(`DW-${Math.floor(100000 + Math.random() * 900000)}`);
    setOrderPlaced(true);
    setTimeout(() => {
      clearCart();
    }, 400);
  };

  return (
    <>
      {/* 1. SHOPPING BAG SLIDE-OVER DRAWER */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-black/50 backdrop-blur-xs flex justify-end">
          <div
            className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between animate-in slide-in-from-right duration-300"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="p-5 border-b border-stone-200 flex items-center justify-between bg-stone-50">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-[#481634]" />
                <h2 className="font-serif text-lg font-semibold text-stone-900">
                  Your Shopping Bag ({cart.reduce((acc, item) => acc + item.quantity, 0)})
                </h2>
              </div>
              <button
                onClick={() => setIsCartOpen(false)}
                className="p-1.5 rounded-full hover:bg-stone-200 text-stone-500 hover:text-stone-900 transition-colors"
                aria-label="Close bag"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Free Delivery Bar */}
            <div className="px-5 py-3 bg-[#faedf3] border-b border-[#f3dbe8] text-xs">
              {isFreeDelivery ? (
                <div className="flex items-center gap-2 text-emerald-800 font-medium">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Complimentary UK Delivery unlocked on your order!</span>
                </div>
              ) : (
                <div className="space-y-1.5 text-stone-700">
                  <p>
                    Add <strong className="text-[#52193b]">£{amountToFreeDelivery.toFixed(2)}</strong> more to receive <strong>Free UK Delivery</strong>
                  </p>
                  <div className="w-full bg-stone-200 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-[#52193b] h-full transition-all duration-300"
                      style={{
                        width: `${Math.min(100, (cartSubtotal / freeDeliveryThreshold) * 100)}%`,
                      }}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Cart Items List */}
            <div className="flex-1 overflow-y-auto p-5 divide-y divide-stone-100">
              {cart.length === 0 ? (
                <div className="text-center py-16 space-y-3">
                  <div className="w-16 h-16 mx-auto rounded-full bg-stone-100 flex items-center justify-center text-stone-400">
                    <ShoppingBag className="w-8 h-8" />
                  </div>
                  <h3 className="font-serif text-lg text-stone-800">Your bag is empty</h3>
                  <p className="text-xs text-stone-500 max-w-xs mx-auto">
                    Explore our Christmas collection or gourmet hampers to begin your Windsor order.
                  </p>
                  <button
                    onClick={() => setIsCartOpen(false)}
                    className="mt-4 px-6 py-2.5 bg-[#481634] text-white text-xs font-semibold uppercase tracking-wider rounded-none"
                  >
                    Start Shopping
                  </button>
                </div>
              ) : (
                cart.map((item) => (
                  <div key={item.product.id} className="py-4 flex gap-4">
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-20 h-20 object-cover rounded-xs border border-stone-200 bg-stone-50 shrink-0"
                    />
                    <div className="flex-1 min-w-0 flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-start">
                          <p className="text-[11px] font-semibold text-stone-400 uppercase tracking-wider">
                            {item.product.brand}
                          </p>
                          <button
                            onClick={() => removeFromCart(item.product.id)}
                            className="text-stone-400 hover:text-rose-600 transition-colors p-0.5"
                            aria-label="Remove item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <h4 className="text-sm font-medium text-stone-900 line-clamp-1">
                          {item.product.name}
                        </h4>
                        {(item.selectedSize || item.selectedColor) && (
                          <p className="text-xs text-stone-500 mt-0.5">
                            {item.selectedSize && `Size: ${item.selectedSize}`}
                            {item.selectedSize && item.selectedColor && ' · '}
                            {item.selectedColor && `Colour: ${item.selectedColor}`}
                          </p>
                        )}
                      </div>

                      {/* Gift wrapping toggle button */}
                      <button
                        onClick={() => toggleGiftWrap(item.product.id)}
                        className={`text-[11px] flex items-center gap-1.5 mt-1 cursor-pointer ${
                          item.giftWrapped ? 'text-[#52193b] font-semibold' : 'text-stone-500 hover:text-stone-700'
                        }`}
                      >
                        <Gift className="w-3 h-3" />
                        <span>{item.giftWrapped ? 'Gift wrap added (+£4.95)' : '+ Add gift wrap (£4.95)'}</span>
                      </button>

                      {/* Quantity & Item Subtotal */}
                      <div className="flex items-center justify-between mt-2 pt-1">
                        <div className="flex items-center border border-stone-200 rounded-none bg-stone-50">
                          <button
                            onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                            className="px-2 py-0.5 text-xs font-semibold text-stone-600 hover:text-stone-900"
                          >
                            -
                          </button>
                          <span className="px-2 py-0.5 text-xs font-medium text-stone-900 min-w-6 text-center">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                            className="px-2 py-0.5 text-xs font-semibold text-stone-600 hover:text-stone-900"
                          >
                            +
                          </button>
                        </div>

                        <span className="text-sm font-bold text-stone-900">
                          £{((item.product.price + (item.giftWrapped ? 4.95 : 0)) * item.quantity).toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Footer Summary & Checkout Action */}
            {cart.length > 0 && (
              <div className="p-5 border-t border-stone-200 bg-stone-50 space-y-4">
                {/* Promo Code Form */}
                <form onSubmit={applyPromoCode} className="flex gap-2">
                  <input
                    type="text"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    placeholder="Promo code (e.g. WINDSOR10)"
                    className="flex-1 px-3 py-1.5 text-xs border border-stone-300 rounded-none bg-white uppercase placeholder:normal-case focus:outline-none focus:border-[#481634]"
                  />
                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-stone-800 hover:bg-stone-900 text-white text-xs font-semibold rounded-none uppercase cursor-pointer"
                  >
                    Apply
                  </button>
                </form>
                {promoSuccess && <p className="text-xs text-emerald-700 font-medium">{promoSuccess}</p>}
                {promoError && <p className="text-xs text-rose-600">{promoError}</p>}

                {/* Subtotals */}
                <div className="space-y-1.5 text-xs text-stone-600 pt-1">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span className="text-stone-900 font-medium">£{cartSubtotal.toFixed(2)}</span>
                  </div>
                  {discountPercent > 0 && (
                    <div className="flex justify-between text-emerald-700">
                      <span>Promotional Discount ({discountPercent}%)</span>
                      <span>-£{discountAmount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span>UK Standard Delivery</span>
                    <span>{deliveryFee === 0 ? <strong className="text-emerald-700">FREE</strong> : `£${deliveryFee.toFixed(2)}`}</span>
                  </div>
                  <div className="flex justify-between text-base font-bold text-stone-900 pt-2 border-t border-stone-200">
                    <span>Grand Total (GBP)</span>
                    <span>£{grandTotal.toFixed(2)}</span>
                  </div>
                </div>

                {/* Checkout Trigger */}
                <button
                  onClick={() => {
                    setIsCartOpen(false);
                    setIsCheckoutModalOpen(true);
                  }}
                  className="w-full py-3.5 bg-[#481634] hover:bg-[#5f1d45] text-white text-xs sm:text-sm font-semibold uppercase tracking-wider flex items-center justify-center gap-2 rounded-none transition-all shadow-md active:scale-98 cursor-pointer"
                >
                  <span>Proceed to Windsor Checkout</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <div className="flex items-center justify-center gap-2 text-[11px] text-stone-400">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Secure 256-bit encrypted British checkout</span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 2. ORDER CONFIRMATION / CHECKOUT SIMULATION MODAL */}
      {isCheckoutModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white max-w-lg w-full p-6 sm:p-8 rounded-xs shadow-2xl border border-stone-200 relative animate-in zoom-in-95 duration-200">
            <button
              onClick={() => {
                setIsCheckoutModalOpen(false);
                setOrderPlaced(false);
              }}
              className="absolute top-4 right-4 text-stone-400 hover:text-stone-700"
            >
              <X className="w-5 h-5" />
            </button>

            {!orderPlaced ? (
              <div>
                <span className="text-[11px] uppercase tracking-widest text-[#52193b] font-semibold">
                  ESTABLISHED 1900 · SECURE CHECKOUT
                </span>
                <h3 className="font-serif text-2xl text-stone-900 mt-1 mb-4">
                  Complete Your Daniel of Windsor Order
                </h3>

                <form onSubmit={handlePlaceOrder} className="space-y-4 text-xs">
                  <div>
                    <label className="block text-stone-700 font-semibold mb-1">Full Name / Title</label>
                    <input
                      type="text"
                      required
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      className="w-full p-2.5 border border-stone-300 rounded-none focus:outline-none focus:border-[#481634]"
                    />
                  </div>

                  <div>
                    <label className="block text-stone-700 font-semibold mb-1">Delivery Address (UK & Channel Islands)</label>
                    <input
                      type="text"
                      required
                      defaultValue="The Mews, High Street, Windsor, Berkshire, SL4 1LR"
                      className="w-full p-2.5 border border-stone-300 rounded-none focus:outline-none focus:border-[#481634]"
                    />
                  </div>

                  <div>
                    <label className="block text-stone-700 font-semibold mb-1">Email for Dispatch & Tracking</label>
                    <input
                      type="email"
                      required
                      value={customerEmail}
                      onChange={(e) => setCustomerEmail(e.target.value)}
                      className="w-full p-2.5 border border-stone-300 rounded-none focus:outline-none focus:border-[#481634]"
                    />
                  </div>

                  {/* Order review */}
                  <div className="p-3 bg-stone-50 border border-stone-200 space-y-1">
                    <div className="flex justify-between font-semibold text-stone-900">
                      <span>Total to Pay:</span>
                      <span>£{grandTotal.toFixed(2)}</span>
                    </div>
                    <p className="text-[11px] text-stone-500">
                      Includes tracked Royal Mail / DPD courier delivery and hand-wrapped presentation.
                    </p>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-[#481634] hover:bg-[#5f1d45] text-white text-xs font-semibold uppercase tracking-wider rounded-none transition-all cursor-pointer shadow-md"
                  >
                    Confirm & Place Order (£{grandTotal.toFixed(2)})
                  </button>
                </form>
              </div>
            ) : (
              <div className="text-center py-6 space-y-4">
                <div className="w-16 h-16 mx-auto rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h3 className="font-serif text-2xl text-stone-900">
                  Thank You for Your Patronage
                </h3>
                <p className="text-sm text-stone-600">
                  Your order <strong className="text-stone-900">#{orderNumber}</strong> has been received by our Peascod Street dispatch concierge.
                </p>
                <div className="p-4 bg-stone-50 border border-stone-200 rounded-xs text-xs text-left text-stone-600 space-y-1">
                  <p><strong>Customer:</strong> {customerName}</p>
                  <p><strong>Confirmation Sent to:</strong> {customerEmail}</p>
                  <p><strong>Collection/Dispatch:</strong> Within 24 Hours with signature seal</p>
                </div>
                <button
                  onClick={() => setIsCheckoutModalOpen(false)}
                  className="px-6 py-2.5 bg-[#481634] text-white text-xs font-semibold uppercase tracking-wider rounded-none"
                >
                  Return to Storefront
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
