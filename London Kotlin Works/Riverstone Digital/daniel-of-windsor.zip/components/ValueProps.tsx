'use client';

import React from 'react';
import { Truck, ShoppingBag, Crown, Leaf } from 'lucide-react';
import { useStore } from '@/context/StoreContext';

export default function ValueProps() {
  const { setIsStoreModalOpen } = useStore();

  const props = [
    {
      icon: <Truck className="w-6 h-6 text-stone-800 stroke-[1.5]" />,
      title: 'Free UK Delivery',
      subtitle: 'on orders over £75',
      action: () => {}
    },
    {
      icon: <ShoppingBag className="w-6 h-6 text-stone-800 stroke-[1.5]" />,
      title: 'Click & Collect',
      subtitle: 'from Daniel of Windsor',
      action: () => setIsStoreModalOpen(true)
    },
    {
      icon: <Crown className="w-6 h-6 text-stone-800 stroke-[1.5]" />,
      title: 'Proudly Independent',
      subtitle: 'Family owned since 1900',
      action: () => setIsStoreModalOpen(true)
    },
    {
      icon: <Leaf className="w-6 h-6 text-stone-800 stroke-[1.5]" />,
      title: 'Sustainable Choices',
      subtitle: 'Responsible brands and packaging',
      action: () => {}
    }
  ];

  return (
    <div className="w-full bg-[#f8f6f2] border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-stone-200">
          {props.map((item, index) => (
            <div
              key={index}
              onClick={item.action}
              className={`flex items-center space-x-3.5 px-4 py-3 sm:py-1 cursor-pointer transition-colors group ${
                index !== 0 ? 'sm:pl-6' : ''
              }`}
            >
              <div className="shrink-0 p-2 rounded-full bg-white shadow-xs group-hover:scale-105 transition-transform text-stone-800">
                {item.icon}
              </div>
              <div className="flex flex-col">
                <span className="text-sm font-semibold text-stone-900 group-hover:text-[#481634] transition-colors leading-tight">
                  {item.title}
                </span>
                <span className="text-xs text-stone-500 font-normal leading-tight mt-0.5">
                  {item.subtitle}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
