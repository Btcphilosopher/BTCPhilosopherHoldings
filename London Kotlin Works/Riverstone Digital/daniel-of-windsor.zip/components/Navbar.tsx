'use client';

import React, { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import { 
  Search, 
  Heart, 
  ShoppingBag, 
  MapPin, 
  Headphones, 
  User, 
  Menu, 
  X, 
  ChevronRight,
  Clock,
  Sparkles,
  Phone
} from 'lucide-react';
import RoyalCrest from './RoyalCrest';
import { DEPARTMENTS, PRODUCTS } from '@/data/storeData';
import { useStore } from '@/context/StoreContext';

export default function Navbar() {
  const {
    cartCount,
    wishlistIds,
    setIsCartOpen,
    setIsWishlistOpen,
    setIsStoreModalOpen,
    isMobileMenuOpen,
    setIsMobileMenuOpen,
    activeDepartment,
    setActiveDepartment,
    searchQuery,
    setSearchQuery,
    setQuickViewProduct
  } = useStore();

  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Search filter results
  const searchResults = searchQuery.trim()
    ? PRODUCTS.filter(
        (p) =>
          p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.category.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 5)
    : [];

  // Close search dropdown on click outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        searchContainerRef.current &&
        !searchContainerRef.current.contains(event.target as Node)
      ) {
        setIsSearchFocused(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleDepartmentClick = (deptId: string) => {
    setActiveDepartment(deptId);
    // Smooth scroll to catalog or department view
    const section = document.getElementById('curated-collection');
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white shadow-xs">
      {/* 1. TOP UTILITY BAR (Deep regal plum) */}
      <div className="bg-[#2c1221] text-[#e6d8ce] text-xs font-normal border-b border-[#3e1b30]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-8 flex items-center justify-between">
          {/* Left: Heritage label */}
          <div className="flex items-center space-x-2">
            <span className="tracking-wide text-[11px] sm:text-xs">
              Daniel of Windsor – Established 1900
            </span>
          </div>

          {/* Right: Store, Customer Service & Account */}
          <div className="flex items-center space-x-4 sm:space-x-6 text-[11px] sm:text-xs">
            <button
              onClick={() => setIsStoreModalOpen(true)}
              className="flex items-center space-x-1.5 hover:text-white transition-colors cursor-pointer group"
              title="Store location and opening hours"
            >
              <MapPin className="w-3.5 h-3.5 text-[#d8ad83] group-hover:scale-110 transition-transform" />
              <span>Windsor (Store & Opening Hours)</span>
            </button>

            <a
              href="tel:+441753801000"
              className="hidden md:flex items-center space-x-1.5 hover:text-white transition-colors cursor-pointer"
            >
              <Headphones className="w-3.5 h-3.5 text-[#d8ad83]" />
              <span>Customer Service</span>
            </a>

            <button
              onClick={() => setIsStoreModalOpen(true)}
              className="hidden sm:flex items-center space-x-1.5 hover:text-white transition-colors cursor-pointer"
            >
              <User className="w-3.5 h-3.5 text-[#d8ad83]" />
              <span>Sign In / Register</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. MAIN HEADER (Logo, Search Bar, Wishlist, Bag) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 sm:py-4">
        <div className="flex items-center justify-between gap-4 sm:gap-8">
          {/* Mobile menu button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2 text-stone-700 hover:text-stone-900 rounded-md -ml-2"
            aria-label="Toggle navigation menu"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>

          {/* Brand Logo & Royal Warrant Crest */}
          <Link
            href="/"
            className="flex items-center space-x-3 group text-left shrink-0"
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          >
            <RoyalCrest
              size={46}
              className="text-[#3b172a] group-hover:text-[#52193b] transition-colors"
            />
            <div className="flex flex-col leading-none">
              <span className="font-crest tracking-[0.22em] text-xl sm:text-2xl font-bold text-[#341427]">
                DANIEL
              </span>
              <span className="font-serif italic text-xs sm:text-sm text-[#5a2a44] tracking-widest pl-0.5 -mt-0.5">
                of <span className="font-crest not-italic tracking-[0.24em] font-medium text-xs sm:text-sm text-[#341427]">WINDSOR</span>
              </span>
            </div>
          </Link>

          {/* Center Search Input */}
          <div
            ref={searchContainerRef}
            className="relative hidden md:block flex-1 max-w-2xl mx-auto"
          >
            <div className="relative flex items-center">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => setIsSearchFocused(true)}
                placeholder="Search for products, brands and inspiration..."
                className="w-full pl-5 pr-11 py-2.5 rounded-full border border-stone-300 bg-white text-sm text-stone-800 placeholder-stone-400 focus:outline-none focus:border-[#4d1936] focus:ring-1 focus:ring-[#4d1936] transition-all shadow-xs"
              />
              <button
                type="button"
                className="absolute right-3.5 text-stone-500 hover:text-[#4d1936] transition-colors"
                aria-label="Submit search"
              >
                <Search className="w-4 h-4" />
              </button>
            </div>

            {/* Live Search Popup Overlay */}
            {isSearchFocused && (
              <div className="absolute left-0 right-0 top-full mt-2 bg-white rounded-xl shadow-xl border border-stone-200 overflow-hidden z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                {searchQuery.trim() === '' ? (
                  <div className="p-4">
                    <p className="text-xs uppercase tracking-wider text-stone-400 font-semibold mb-2">
                      Popular Windsor Searches
                    </p>
                    <div className="flex flex-wrap gap-2 text-xs">
                      {['Christmas Hampers', 'Cashmere Scarf', 'Nutcracker', 'Diptyque Candle', 'Windsor Snow Globe', 'Steiff Bears', 'Fine Bone China'].map(
                        (tag) => (
                          <button
                            key={tag}
                            onClick={() => {
                              setSearchQuery(tag);
                              setIsSearchFocused(false);
                              const sec = document.getElementById('curated-collection');
                              if (sec) sec.scrollIntoView({ behavior: 'smooth' });
                            }}
                            className="px-3 py-1.5 bg-stone-100 hover:bg-[#faeef4] hover:text-[#4d1936] text-stone-700 rounded-full transition-colors cursor-pointer"
                          >
                            {tag}
                          </button>
                        )
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="divide-y divide-stone-100">
                    <div className="p-3 bg-stone-50 text-xs text-stone-500">
                      Showing results for &ldquo;{searchQuery}&rdquo;
                    </div>
                    {searchResults.length > 0 ? (
                      searchResults.map((product) => (
                        <div
                          key={product.id}
                          onClick={() => {
                            setQuickViewProduct(product);
                            setIsSearchFocused(false);
                          }}
                          className="flex items-center gap-3 p-3 hover:bg-[#faf7f4] cursor-pointer transition-colors"
                        >
                          <img
                            src={product.image}
                            alt={product.name}
                            className="w-12 h-12 object-cover rounded-md bg-stone-100"
                          />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-stone-900 truncate">
                              {product.name}
                            </p>
                            <p className="text-xs text-stone-500">
                              {product.brand} · £{product.price.toFixed(2)}
                            </p>
                          </div>
                          <span className="text-xs text-[#52193b] font-medium shrink-0">
                            View →
                          </span>
                        </div>
                      ))
                    ) : (
                      <div className="p-6 text-center text-sm text-stone-500">
                        No products found for &ldquo;{searchQuery}&rdquo;. Try browsing our Christmas or Food & Wine collections.
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Right Utility Actions: Wishlist & Bag */}
          <div className="flex items-center space-x-5 sm:space-x-7 shrink-0">
            {/* Wishlist */}
            <button
              onClick={() => setIsWishlistOpen(true)}
              className="relative flex items-center space-x-1.5 text-stone-800 hover:text-[#4d1936] transition-colors cursor-pointer group"
              aria-label={`Wishlist with ${wishlistIds.length} items`}
            >
              <Heart className="w-5 h-5 group-hover:scale-105 transition-transform" />
              <span className="hidden sm:inline text-sm font-medium">Wishlist</span>
              {wishlistIds.length > 0 && (
                <span className="absolute -top-1.5 -right-2 sm:-top-2 sm:-right-2 bg-[#52193b] text-white text-[10px] font-semibold w-4 h-4 rounded-full flex items-center justify-center">
                  {wishlistIds.length}
                </span>
              )}
            </button>

            {/* Bag */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="flex items-center space-x-1.5 text-stone-800 hover:text-[#4d1936] transition-colors cursor-pointer group"
              aria-label={`Shopping bag with ${cartCount} items`}
            >
              <div className="relative">
                <ShoppingBag className="w-5 h-5 group-hover:scale-105 transition-transform" />
              </div>
              <span className="text-sm font-medium">
                Bag ({cartCount})
              </span>
            </button>
          </div>
        </div>

        {/* Mobile Search Input (Visible only on mobile) */}
        <div className="mt-3 md:hidden">
          <div className="relative flex items-center">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search products & brands..."
              className="w-full pl-4 pr-10 py-2 rounded-full border border-stone-300 text-sm text-stone-800 placeholder-stone-400 focus:outline-none focus:border-[#4d1936]"
            />
            <Search className="w-4 h-4 text-stone-400 absolute right-3" />
          </div>
        </div>
      </div>

      {/* 3. DEPARTMENT NAVIGATION BAR */}
      <nav className="border-t border-stone-200 bg-[#fdfdfd] hidden lg:block">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ul className="flex items-center justify-between text-[13px] tracking-wide font-medium text-stone-800 overflow-x-auto no-scrollbar py-2.5">
            {DEPARTMENTS.map((dept) => {
              const isActive = activeDepartment === dept.id;
              // In the screenshot, "Electricals" had a soft highlight indicator
              const isElectricals = dept.id === 'electricals';

              return (
                <li key={dept.id} className="relative shrink-0">
                  <button
                    onClick={() => handleDepartmentClick(dept.id)}
                    className={`px-3 py-1 transition-all rounded-md relative cursor-pointer ${
                      isActive
                        ? 'text-[#481634] font-semibold'
                        : 'text-stone-700 hover:text-[#481634]'
                    } ${dept.isItalic ? 'italic font-serif tracking-normal text-sm' : ''} ${
                      isElectricals ? 'text-blue-900 font-semibold' : ''
                    }`}
                  >
                    <span>{dept.name}</span>
                    {/* Active Department Indicator Underline / Glow */}
                    {isActive && (
                      <span className="absolute bottom-0 left-2 right-2 h-0.5 bg-[#52193b] rounded-full" />
                    )}
                    {/* Visual reproduction of Electricals highlight from original screenshot */}
                    {isElectricals && !isActive && (
                      <span className="absolute inset-x-1 bottom-0.5 h-1 bg-blue-100 -z-10 rounded-sm" />
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      </nav>

      {/* 4. MOBILE SLIDE-OUT DRAWER MENU */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 top-[110px] z-50 bg-white/95 backdrop-blur-md lg:hidden flex flex-col overflow-y-auto animate-in slide-in-from-left duration-200 border-t border-stone-200 p-6">
          <div className="space-y-6">
            <div>
              <p className="text-xs uppercase tracking-widest text-[#52193b] font-semibold mb-3">
                All Departments
              </p>
              <div className="grid grid-cols-1 divide-y divide-stone-100">
                {DEPARTMENTS.map((dept) => (
                  <button
                    key={dept.id}
                    onClick={() => {
                      handleDepartmentClick(dept.id);
                      setIsMobileMenuOpen(false);
                    }}
                    className="py-3 flex items-center justify-between text-left text-sm font-medium text-stone-800 hover:text-[#52193b]"
                  >
                    <span className={dept.isItalic ? 'italic font-serif' : ''}>
                      {dept.name}
                    </span>
                    <ChevronRight className="w-4 h-4 text-stone-400" />
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-stone-200 space-y-3">
              <button
                onClick={() => {
                  setIsStoreModalOpen(true);
                  setIsMobileMenuOpen(false);
                }}
                className="w-full flex items-center gap-3 p-3 bg-stone-50 rounded-lg text-sm text-stone-800"
              >
                <MapPin className="w-4 h-4 text-[#52193b]" />
                <div className="text-left">
                  <p className="font-semibold">Windsor Store & Opening Hours</p>
                  <p className="text-xs text-stone-500">120 Peascod St, Open today until 17:30</p>
                </div>
              </button>

              <a
                href="tel:+441753801000"
                className="w-full flex items-center gap-3 p-3 bg-stone-50 rounded-lg text-sm text-stone-800"
              >
                <Phone className="w-4 h-4 text-[#52193b]" />
                <div className="text-left">
                  <p className="font-semibold">Store Concierge & Support</p>
                  <p className="text-xs text-stone-500">+44 (0)1753 801000</p>
                </div>
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
