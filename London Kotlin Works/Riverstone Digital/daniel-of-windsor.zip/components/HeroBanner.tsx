'use client';

import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, ArrowRight } from 'lucide-react';
import { HERO_SLIDES } from '@/data/storeData';
import { useStore } from '@/context/StoreContext';

export default function HeroBanner() {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const { setActiveDepartment, setIsStoreModalOpen } = useStore();

  const currentSlide = HERO_SLIDES[currentSlideIndex];

  // Auto slide rotation every 7 seconds when not hovered
  useEffect(() => {
    if (isHovered) return;
    const interval = setInterval(() => {
      setCurrentSlideIndex((prev) => (prev + 1) % HERO_SLIDES.length);
    }, 7000);
    return () => clearInterval(interval);
  }, [isHovered]);

  const prevSlide = () => {
    setCurrentSlideIndex((prev) => (prev - 1 + HERO_SLIDES.length) % HERO_SLIDES.length);
  };

  const nextSlide = () => {
    setCurrentSlideIndex((prev) => (prev + 1) % HERO_SLIDES.length);
  };

  const handleCtaClick = (target: string) => {
    setActiveDepartment(target);
    const catalog = document.getElementById('curated-collection');
    if (catalog) {
      catalog.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section 
      aria-label="Featured Seasonal Showcase"
      className="relative w-full overflow-hidden bg-stone-900 text-white min-h-[460px] sm:min-h-[520px] lg:h-[580px] flex items-center"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Background Images with smooth crossfade */}
      {HERO_SLIDES.map((slide, index) => (
        <div
          key={slide.id}
          className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
            index === currentSlideIndex ? 'opacity-100 z-10' : 'opacity-0 z-0'
          }`}
        >
          {/* Main Background Image */}
          <img
            src={slide.image}
            alt={slide.title}
            className="w-full h-full object-cover object-center scale-100 transition-transform duration-10000"
          />

          {/* Luxury Vignette & Dark Contrast Overlay */}
          <div className="absolute inset-0 bg-gradient-to-r from-black/75 via-black/45 to-transparent pointer-events-none" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20 pointer-events-none" />
        </div>
      ))}

      {/* Hero Content Overlay (Positioned exactly as in the reference image) */}
      <div className="relative z-20 max-w-7xl mx-auto px-6 sm:px-10 lg:px-12 w-full py-16 sm:py-20">
        <div className="max-w-xl text-left">
          {/* Kicker label */}
          <div className="inline-block mb-3">
            <span className="text-xs sm:text-sm uppercase tracking-[0.22em] text-[#e8d5c4] font-medium drop-shadow-sm">
              {currentSlide.kicker}
            </span>
          </div>

          {/* Main headline: e.g. "A Season of Gifting" */}
          <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-normal leading-[1.12] text-white tracking-tight drop-shadow-md mb-4">
            {currentSlide.title.split(' ').map((word, wIdx) => {
              const isItalic =
                word.toLowerCase() === currentSlide.titleItalicWord.toLowerCase();
              return (
                <span key={wIdx}>
                  {isItalic ? (
                    <span className="italic font-normal font-serif text-[#f6ece3]">
                      {word}{' '}
                    </span>
                  ) : (
                    <span>{word} </span>
                  )}
                </span>
              );
            })}
          </h1>

          {/* Subtitle / Description: "Beautiful presents, timeless favourites and festive inspiration at Daniel's." */}
          <p className="font-serif italic text-base sm:text-lg lg:text-xl text-[#f3e9df] leading-relaxed max-w-lg mb-8 drop-shadow-sm font-light">
            {currentSlide.description}
          </p>

          {/* CTA Buttons Row */}
          <div className="flex flex-wrap items-center gap-3 sm:gap-4">
            {/* Primary CTA (Burgundy Filled Button) */}
            <button
              onClick={() => handleCtaClick(currentSlide.ctaPrimaryTarget)}
              className="inline-flex items-center gap-2.5 px-6 sm:px-7 py-3 rounded-none bg-[#481634] hover:bg-[#5a1b41] text-white text-sm sm:text-base font-medium tracking-wide transition-all shadow-md hover:shadow-lg border border-[#6b254e] cursor-pointer group"
            >
              <span>{currentSlide.ctaPrimary}</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            {/* Secondary CTA (Dark Transparent Outline Button) */}
            <button
              onClick={() => {
                if (currentSlide.ctaSecondaryAction === 'store-modal') {
                  setIsStoreModalOpen(true);
                } else {
                  handleCtaClick(currentSlide.ctaSecondaryAction);
                }
              }}
              className="inline-flex items-center gap-2 px-6 sm:px-7 py-3 rounded-none bg-black/40 hover:bg-black/60 text-white text-sm sm:text-base font-medium tracking-wide transition-all border border-white/40 hover:border-white/80 cursor-pointer group backdrop-blur-xs"
            >
              <span>{currentSlide.ctaSecondary}</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </div>

      {/* Carousel Navigation Arrow: Left */}
      <button
        onClick={prevSlide}
        aria-label="Previous slide"
        className="absolute left-3 sm:left-6 top-1/2 -translate-y-1/2 z-30 w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-black/40 hover:bg-black/70 text-white flex items-center justify-center transition-all border border-white/20 backdrop-blur-xs cursor-pointer shadow-md hover:scale-105"
      >
        <ChevronLeft className="w-5 h-5" />
      </button>

      {/* Carousel Navigation Arrow: Right */}
      <button
        onClick={nextSlide}
        aria-label="Next slide"
        className="absolute right-3 sm:right-6 top-1/2 -translate-y-1/2 z-30 w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-black/40 hover:bg-black/70 text-white flex items-center justify-center transition-all border border-white/20 backdrop-blur-xs cursor-pointer shadow-md hover:scale-105"
      >
        <ChevronRight className="w-5 h-5" />
      </button>

      {/* Pagination Indicator Dots at bottom */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-30 flex items-center space-x-2">
        {HERO_SLIDES.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentSlideIndex(idx)}
            aria-label={`Jump to slide ${idx + 1}`}
            className={`transition-all duration-300 rounded-full cursor-pointer ${
              idx === currentSlideIndex
                ? 'w-7 h-2 bg-white'
                : 'w-2 h-2 bg-white/45 hover:bg-white/75'
            }`}
          />
        ))}
      </div>
    </section>
  );
}
