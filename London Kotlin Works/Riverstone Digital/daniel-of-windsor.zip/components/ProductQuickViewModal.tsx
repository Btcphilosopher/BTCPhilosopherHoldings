'use client';

import React, { useState } from 'react';
import { X, Heart, ShoppingBag, Star, Check, Truck, ShieldCheck, Gift } from 'lucide-react';
import { useStore } from '@/context/StoreContext';

export default function ProductQuickViewModal() {
  const {
    quickViewProduct,
    setQuickViewProduct,
    addToCart,
    toggleWishlist,
    isInWishlist,
  } = useStore();

  const [quantity, setQuantity] = useState(1);
  const [selectedSize, setSelectedSize] = useState<string | undefined>(
    quickViewProduct?.sizes?.[0]
  );
  const [selectedColor, setSelectedColor] = useState<string | undefined>(
    quickViewProduct?.colors?.[0]
  );
  const [giftWrapped, setGiftWrapped] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!quickViewProduct) return null;

  const isWishlisted = isInWishlist(quickViewProduct.id);

  const handleAddToCart = () => {
    addToCart(quickViewProduct, quantity, {
      size: selectedSize,
      color: selectedColor,
      giftWrapped,
    });
    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      setQuickViewProduct(null);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div 
        className="relative bg-white w-full max-w-4xl rounded-xs shadow-2xl overflow-hidden border border-stone-200 animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={() => setQuickViewProduct(null)}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-white/80 hover:bg-stone-100 text-stone-600 hover:text-stone-900 transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Product Image */}
          <div className="relative aspect-square md:aspect-auto bg-stone-100 overflow-hidden">
            <img
              src={quickViewProduct.image}
              alt={quickViewProduct.name}
              className="w-full h-full object-cover object-center"
            />
            {quickViewProduct.isWindsorExclusive && (
              <span className="absolute top-4 left-4 bg-[#481634] text-white text-xs font-semibold px-2.5 py-1 uppercase tracking-wider">
                Windsor Exclusive
              </span>
            )}
          </div>

          {/* Product Details Column */}
          <div className="p-6 sm:p-8 flex flex-col justify-between max-h-[85vh] overflow-y-auto">
            <div>
              {/* Brand and category */}
              <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1">
                <span>{quickViewProduct.brand}</span>
                <span>{quickViewProduct.category}</span>
              </div>

              {/* Title */}
              <h2 className="font-serif text-2xl sm:text-3xl font-medium text-stone-900 leading-tight">
                {quickViewProduct.name}
              </h2>

              {/* Rating */}
              <div className="flex items-center gap-2 mt-2">
                <div className="flex items-center text-amber-500">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < Math.floor(quickViewProduct.rating)
                          ? 'fill-amber-400 text-amber-400'
                          : 'text-stone-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-xs text-stone-500 font-medium">
                  {quickViewProduct.rating} ({quickViewProduct.reviewsCount} customer reviews)
                </span>
              </div>

              {/* Price */}
              <div className="flex items-baseline gap-3 my-4">
                <span className="text-2xl font-bold text-stone-900">
                  £{quickViewProduct.price.toFixed(2)}
                </span>
                {quickViewProduct.originalPrice && (
                  <span className="text-base text-stone-400 line-through">
                    £{quickViewProduct.originalPrice.toFixed(2)}
                  </span>
                )}
                <span className="text-xs text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-medium">
                  In Stock in Windsor Store
                </span>
              </div>

              {/* Description */}
              <p className="text-stone-600 text-sm leading-relaxed mb-4">
                {quickViewProduct.description}
              </p>

              {/* Key Features Bullet points */}
              <div className="border-t border-b border-stone-100 py-3 my-4 space-y-1.5">
                {quickViewProduct.features.slice(0, 3).map((feat, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-xs text-stone-600">
                    <span className="text-[#52193b] font-bold">✓</span>
                    <span>{feat}</span>
                  </div>
                ))}
              </div>

              {/* Size Selector if available */}
              {quickViewProduct.sizes && quickViewProduct.sizes.length > 0 && (
                <div className="mb-4">
                  <label className="block text-xs font-semibold uppercase text-stone-700 tracking-wider mb-2">
                    Select Size: {selectedSize}
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {quickViewProduct.sizes.map((size) => (
                      <button
                        key={size}
                        onClick={() => setSelectedSize(size)}
                        className={`px-3 py-1.5 text-xs font-medium border cursor-pointer transition-colors ${
                          selectedSize === size
                            ? 'border-stone-900 bg-stone-900 text-white'
                            : 'border-stone-300 text-stone-700 hover:border-stone-500'
                        }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Colors if available */}
              {quickViewProduct.colors && quickViewProduct.colors.length > 0 && (
                <div className="mb-4">
                  <label className="block text-xs font-semibold uppercase text-stone-700 tracking-wider mb-2">
                    Colour Palette: {selectedColor}
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {quickViewProduct.colors.map((color) => (
                      <button
                        key={color}
                        onClick={() => setSelectedColor(color)}
                        className={`px-3 py-1 text-xs border rounded-none cursor-pointer transition-colors ${
                          selectedColor === color
                            ? 'border-[#52193b] bg-[#faedf3] text-[#52193b] font-semibold'
                            : 'border-stone-200 text-stone-700 hover:border-stone-400'
                        }`}
                      >
                        {color}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Gift Wrapping checkbox */}
              <label className="flex items-center gap-2.5 p-2.5 bg-stone-50 border border-stone-200 rounded-xs cursor-pointer mb-5 text-xs text-stone-700">
                <input
                  type="checkbox"
                  checked={giftWrapped}
                  onChange={(e) => setGiftWrapped(e.target.checked)}
                  className="rounded text-[#52193b] focus:ring-[#52193b]"
                />
                <Gift className="w-4 h-4 text-[#52193b] shrink-0" />
                <span>Add Royal Windsor signature gift wrap & seal (+£4.95)</span>
              </label>
            </div>

            {/* Quantity and Actions */}
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="flex items-center border border-stone-300 rounded-none bg-white">
                  <button
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    className="px-3 py-2 text-stone-600 hover:text-stone-900 text-sm font-semibold"
                  >
                    -
                  </button>
                  <span className="px-3 py-2 text-sm font-medium text-stone-900 min-w-8 text-center">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity((q) => q + 1)}
                    className="px-3 py-2 text-stone-600 hover:text-stone-900 text-sm font-semibold"
                  >
                    +
                  </button>
                </div>

                <button
                  onClick={handleAddToCart}
                  disabled={isSuccess}
                  className={`flex-1 py-3 px-6 text-sm font-semibold uppercase tracking-wider rounded-none flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md ${
                    isSuccess
                      ? 'bg-emerald-700 text-white'
                      : 'bg-[#481634] hover:bg-[#5f1d45] text-white active:scale-98'
                  }`}
                >
                  {isSuccess ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Added to Bag</span>
                    </>
                  ) : (
                    <>
                      <ShoppingBag className="w-4 h-4" />
                      <span>Add to Bag · £{(quickViewProduct.price * quantity + (giftWrapped ? 4.95 : 0)).toFixed(2)}</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => toggleWishlist(quickViewProduct.id)}
                  className={`p-3 border rounded-none transition-colors cursor-pointer ${
                    isWishlisted
                      ? 'bg-[#52193b] text-white border-[#52193b]'
                      : 'border-stone-300 text-stone-700 hover:border-stone-400'
                  }`}
                  aria-label="Wishlist"
                >
                  <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-white' : ''}`} />
                </button>
              </div>

              {/* Delivery info guarantee */}
              <div className="grid grid-cols-2 gap-2 text-[11px] text-stone-500 pt-2 border-t border-stone-100">
                <div className="flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 text-stone-400" />
                  <span>Free UK delivery on £75+</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-stone-400" />
                  <span>Daniel 30-day guarantee</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
