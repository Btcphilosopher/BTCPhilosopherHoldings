'use client';

import React from 'react';
import { X, MapPin, Clock, Phone, Mail, Navigation, Car, Train, Building2 } from 'lucide-react';
import RoyalCrest from './RoyalCrest';
import { WINDSOR_STORE_INFO } from '@/data/storeData';
import { useStore } from '@/context/StoreContext';

export default function StoreModal() {
  const { isStoreModalOpen, setIsStoreModalOpen } = useStore();

  if (!isStoreModalOpen) return null;

  // Determine current day for opening hours highlight
  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const todayName = daysOfWeek[new Date().getDay()];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div 
        className="relative bg-white w-full max-w-3xl rounded-xs shadow-2xl overflow-hidden border border-stone-200 animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Banner */}
        <div className="bg-[#2c1221] text-white p-6 sm:p-8 relative">
          <button
            onClick={() => setIsStoreModalOpen(false)}
            className="absolute top-4 right-4 text-white/70 hover:text-white p-2 rounded-full hover:bg-white/10 transition-colors"
            aria-label="Close store modal"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <RoyalCrest size={44} className="text-[#dfcbb5]" />
            <div>
              <p className="text-xs uppercase tracking-widest text-[#dfcbb5] font-semibold">
                HERITAGE STORE SINCE 1900
              </p>
              <h2 className="font-serif text-2xl sm:text-3xl text-white">
                Daniel of Windsor Flagship
              </h2>
            </div>
          </div>
        </div>

        {/* Content body */}
        <div className="p-6 sm:p-8 max-h-[75vh] overflow-y-auto space-y-6">
          {/* Address and quick contact */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-6 border-b border-stone-200">
            <div>
              <h3 className="text-xs uppercase tracking-wider text-stone-400 font-semibold mb-2">
                Store Location
              </h3>
              <p className="font-serif text-lg text-stone-900 font-medium">
                {WINDSOR_STORE_INFO.address.line1}
              </p>
              <p className="text-sm text-stone-600">
                {WINDSOR_STORE_INFO.address.town}, {WINDSOR_STORE_INFO.address.county}, {WINDSOR_STORE_INFO.address.postcode}
              </p>
              <p className="text-xs text-[#52193b] font-medium mt-1">
                📍 {WINDSOR_STORE_INFO.landmark}
              </p>

              <div className="mt-4 flex flex-col gap-2 text-xs text-stone-600">
                <a
                  href={`tel:${WINDSOR_STORE_INFO.phone}`}
                  className="flex items-center gap-2 hover:text-[#52193b]"
                >
                  <Phone className="w-3.5 h-3.5 text-[#52193b]" />
                  <span>Concierge: {WINDSOR_STORE_INFO.phone}</span>
                </a>
                <a
                  href={`mailto:${WINDSOR_STORE_INFO.customerServiceEmail}`}
                  className="flex items-center gap-2 hover:text-[#52193b]"
                >
                  <Mail className="w-3.5 h-3.5 text-[#52193b]" />
                  <span>{WINDSOR_STORE_INFO.customerServiceEmail}</span>
                </a>
              </div>
            </div>

            {/* Opening Hours Table */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xs uppercase tracking-wider text-stone-400 font-semibold">
                  Weekly Opening Hours
                </h3>
                <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded">
                  Open Today
                </span>
              </div>
              <div className="bg-stone-50 rounded-xs border border-stone-200 divide-y divide-stone-200 text-xs">
                {WINDSOR_STORE_INFO.openingHours.map((sched) => {
                  const isToday = sched.day.toLowerCase() === todayName.toLowerCase();
                  return (
                    <div
                      key={sched.day}
                      className={`flex justify-between py-2 px-3 ${
                        isToday ? 'bg-[#faedf3] font-semibold text-[#52193b]' : 'text-stone-700'
                      }`}
                    >
                      <span>{sched.day} {isToday && '(Today)'}</span>
                      <span>{sched.hours}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Floor Directory */}
          <div>
            <h3 className="text-xs uppercase tracking-wider text-stone-400 font-semibold mb-3 flex items-center gap-1.5">
              <Building2 className="w-4 h-4 text-[#52193b]" />
              <span>Department Store Floor Directory</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-stone-50 border border-stone-200">
                <strong className="text-stone-900 block font-semibold mb-1">Ground Floor:</strong>
                <p className="text-stone-600">
                  Beauty & Fine Fragrances, Handbags & Leather Goods, Fine Food & Confectionery, Luxury Christmas Hampers.
                </p>
              </div>
              <div className="p-3 bg-stone-50 border border-stone-200">
                <strong className="text-stone-900 block font-semibold mb-1">First Floor:</strong>
                <p className="text-stone-600">
                  Womenswear Collections, Scottish Cashmere, Menswear & Tailoring, Footwear, Personal Styling Suite.
                </p>
              </div>
              <div className="p-3 bg-stone-50 border border-stone-200">
                <strong className="text-stone-900 block font-semibold mb-1">Second Floor:</strong>
                <p className="text-stone-600">
                  Home & Living, Tartan Cushions & Throws, Fine Bone China, Cookware, Kitchen Electricals & Lighting.
                </p>
              </div>
              <div className="p-3 bg-stone-50 border border-stone-200">
                <strong className="text-stone-900 block font-semibold mb-1">Third Floor:</strong>
                <p className="text-stone-600">
                  The Historic Toy Emporium, Steiff Collector Bears, Baby & Nursery, Daniel’s Afternoon Tea Lounge & Restaurant.
                </p>
              </div>
            </div>
          </div>

          {/* Travel & Directions Guide */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="flex items-start gap-2.5 p-3 border border-stone-200">
              <Train className="w-4 h-4 text-[#52193b] shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-stone-900">Arriving by Train</p>
                <p className="text-stone-600 mt-0.5">Windsor & Eton Central Station is a 3-minute walk via Windsor Royal Station arcade.</p>
              </div>
            </div>
            <div className="flex items-start gap-2.5 p-3 border border-stone-200">
              <Car className="w-4 h-4 text-[#52193b] shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-stone-900">Parking & Click & Collect</p>
                <p className="text-stone-600 mt-0.5">King Edward VII and Victoria Street Multi-Storey car parks located directly adjacent.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer CTAs */}
        <div className="p-4 bg-stone-100 border-t border-stone-200 flex justify-end gap-3">
          <a
            href="https://maps.google.com/?q=Daniel+of+Windsor+120+Peascod+Street+Windsor"
            target="_blank"
            rel="noreferrer noopener"
            className="px-5 py-2.5 bg-[#481634] hover:bg-[#5f1d45] text-white text-xs font-semibold uppercase tracking-wider rounded-none inline-flex items-center gap-1.5"
          >
            <Navigation className="w-3.5 h-3.5" />
            <span>Open in Google Maps</span>
          </a>
        </div>
      </div>
    </div>
  );
}
