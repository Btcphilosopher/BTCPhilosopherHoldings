import React from 'react';

interface RoyalCrestProps {
  className?: string;
  size?: number;
}

export default function RoyalCrest({ className = 'text-[#5a3e2b]', size = 52 }: RoyalCrestProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 95"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="Daniel of Windsor Royal Coat of Arms Warrant"
    >
      {/* Crown Top */}
      <path
        d="M50 8C52 14 55 17 58 17C61 17 64 13 65 10C68 15 72 17 74 17C71 22 66 25 50 25C34 25 29 22 26 17C28 17 32 15 35 10C36 13 39 17 42 17C45 17 48 14 50 8Z"
        fill="currentColor"
        opacity="0.9"
      />
      <circle cx="50" cy="5" r="2.5" fill="currentColor" />
      <circle cx="35" cy="8" r="2" fill="currentColor" />
      <circle cx="65" cy="8" r="2" fill="currentColor" />

      {/* Heraldic Shield Quartering */}
      <path
        d="M37 27C44 26 56 26 63 27C64 36 63 52 50 63C37 52 36 36 37 27Z"
        stroke="currentColor"
        strokeWidth="2.5"
        fill="currentColor"
        fillOpacity="0.08"
      />
      {/* Shield Cross Divider */}
      <path d="M50 27V63" stroke="currentColor" strokeWidth="1.5" />
      <path d="M37 42H63" stroke="currentColor" strokeWidth="1.5" />

      {/* Lions in Quarters */}
      <path d="M41 33C42 32 45 32 46 34C45 36 43 37 42 39" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
      <path d="M54 48C55 47 58 47 59 49C58 51 56 52 55 54" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
      <path d="M54 33C57 33 58 35 58 38C57 39 55 38 54 37" stroke="currentColor" strokeWidth="1" strokeLinecap="round" />
      <path d="M42 47C44 47 46 48 46 51C44 52 43 54 41 55" stroke="currentColor" strokeWidth="1" strokeLinecap="round" />

      {/* Left Supporter: The Crowned Lion */}
      <path
        d="M26 23C24 21 21 21 20 23C19 25 21 27 22 29C19 31 16 34 16 39C16 45 20 52 23 57C24 60 26 65 24 68C22 71 18 73 15 72C14 71 15 70 17 69C18 67 18 64 16 63C13 62 10 65 11 69C12 74 18 78 26 77C31 76 34 72 34 67C34 61 31 53 29 48C28 45 29 40 31 38C33 36 34 32 32 29C30 26 28 25 26 23Z"
        fill="currentColor"
        opacity="0.85"
      />
      <path d="M21 19L23 23H17L19 19L20 21L21 19Z" fill="currentColor" />

      {/* Right Supporter: The Unicorn */}
      <path
        d="M74 23C76 21 79 21 80 23C81 25 79 27 78 29C81 31 84 34 84 39C84 45 80 52 77 57C76 60 74 65 76 68C78 71 82 73 85 72C86 71 85 70 83 69C82 67 82 64 84 63C87 62 90 65 89 69C88 74 82 78 74 77C69 76 66 72 66 67C66 61 69 53 71 48C72 45 71 40 69 38C67 36 66 32 68 29C70 26 72 25 74 23Z"
        fill="currentColor"
        opacity="0.85"
      />
      <path d="M78 22L84 12L80 21" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <path d="M72 35C74 38 75 44 76 50" stroke="currentColor" strokeWidth="1" strokeDasharray="1.5 1.5" />

      {/* Motto Ribbon at Base */}
      <path
        d="M14 80C28 77 40 82 50 82C60 82 72 77 86 80C88 83 87 87 84 89C71 86 61 90 50 90C39 90 29 86 16 89C13 87 12 83 14 80Z"
        fill="currentColor"
        opacity="0.9"
      />
    </svg>
  );
}
