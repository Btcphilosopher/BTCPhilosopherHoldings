'use client';

import React from 'react';
import { MapPin, Clock, Coffee, Sparkles, Gift, ArrowRight } from 'lucide-react';
import RoyalCrest from './RoyalCrest';
import { WINDSOR_STORE_INFO } from '@/data/storeData';
import { useStore } from '@/context/StoreContext';

export default function WindsorExperience() {
  const { setIsStoreModalOpen } = useStore();

  return (
    <section className="w-full bg-[#f6f2ec] py-16 sm:py-24 border-b border-stone-200 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          {/* Left Text & Heritage Story */}
          <div className="lg:col-span-7 space-y-6">
            <div className="flex items-center space-x-3">
              <RoyalCrest size={38} className="text-[#571e3c]" />
              <span className="text-xs uppercase tracking-[0.22em] text-[#571e3c] font-semibold">
                HERITAGE SINCE 1900 · WINDSOR, BERKSHIRE
              </span>
            </div>

            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-stone-900 leading-tight">
              A Stroll from Windsor Castle to Our Historic Doors
            </h2>

            <p className="text-stone-700 leading-relaxed text-base sm:text-lg">
              For over a century, Daniel of Windsor has welcomed generations of royal visitors, local families, and discerning travellers through our Peascod Street entrance. Spanning four floors of British craftsmanship, fashion, and festive splendour, every visit is treated as an occasion.
            </p>

            {/* Feature bullets */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="flex items-start gap-3 p-3.5 bg-white/80 rounded-sm border border-stone-200">
                <Coffee className="w-5 h-5 text-[#571e3c] shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-semibold text-stone-900 text-sm">Daniel’s Tea Lounge</h4>
                  <p className="text-xs text-stone-600 mt-0.5">Classic English afternoon tea and artisan roast coffees overlooking Windsor.</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3.5 bg-white/80 rounded-sm border border-stone-200">
                <Sparkles className="w-5 h-5 text-[#571e3c] shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-semibold text-stone-900 text-sm">The Famous Toy Emporium</h4>
                  <p className="text-xs text-stone-600 mt-0.5">Two enchanting floors dedicated to Steiff, traditional wooden toys, and festive displays.</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3.5 bg-white/80 rounded-sm border border-stone-200">
                <Gift className="w-5 h-5 text-[#571e3c] shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-semibold text-stone-900 text-sm">Complimentary Gift Wrap</h4>
                  <p className="text-xs text-stone-600 mt-0.5">Signature plum and gold paper with Daniel wax seal and hand-tied ribbons.</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3.5 bg-white/80 rounded-sm border border-stone-200">
                <Clock className="w-5 h-5 text-[#571e3c] shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-semibold text-stone-900 text-sm">Open 7 Days a Week</h4>
                  <p className="text-xs text-stone-600 mt-0.5">Monday–Saturday 9:00–17:30, Sunday 10:30–16:30. Click & Collect in 2 hours.</p>
                </div>
              </div>
            </div>

            {/* CTAs */}
            <div className="pt-4 flex flex-wrap gap-4 items-center">
              <button
                onClick={() => setIsStoreModalOpen(true)}
                className="px-6 py-3 bg-[#38152c] hover:bg-[#4d1d3c] text-white text-sm font-semibold tracking-wide rounded-none inline-flex items-center gap-2 transition-all cursor-pointer shadow-xs"
              >
                <span>Store Hours & Floor Directory</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <a
                href="https://maps.google.com/?q=Daniel+of+Windsor+120+Peascod+Street+Windsor"
                target="_blank"
                rel="noreferrer noopener"
                className="px-6 py-3 bg-transparent hover:bg-stone-200/60 text-stone-800 text-sm font-semibold tracking-wide border border-stone-300 rounded-none inline-flex items-center gap-2 transition-all"
              >
                <MapPin className="w-4 h-4 text-[#571e3c]" />
                <span>Get Directions (SL4 1DP)</span>
              </a>
            </div>
          </div>

          {/* Right Image Collage */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Primary Photo */}
              <div className="aspect-4/5 overflow-hidden rounded-xs shadow-xl border-4 border-white bg-stone-300">
                <img
                  src="https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&w=1000&q=80"
                  alt="Daniel of Windsor Flagship festive windows"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Floating Heritage Plaque Badge */}
              <div className="absolute -bottom-6 -left-6 bg-white p-5 rounded-xs shadow-2xl border border-stone-200 max-w-xs hidden sm:block">
                <p className="font-crest text-xs tracking-widest text-[#571e3c] font-bold">
                  ROYAL BOROUGH OF WINDSOR
                </p>
                <p className="font-serif italic text-sm text-stone-800 mt-1">
                  &ldquo;A Berkshire landmark of warmth, service and bespoke luxury since 1900.&rdquo;
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
