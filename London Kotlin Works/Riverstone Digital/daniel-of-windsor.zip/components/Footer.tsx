'use client';

import React, { useState } from 'react';
import { Mail, Check, MapPin, Phone, ArrowUp } from 'lucide-react';
import RoyalCrest from './RoyalCrest';
import { useStore } from '@/context/StoreContext';

export default function Footer() {
  const { setIsStoreModalOpen, setActiveDepartment } = useStore();
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setSubscribed(true);
      setEmail('');
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="w-full bg-[#1e0e18] text-[#e8dbd1] border-t border-[#38192d]">
      {/* 1. NEWSLETTER & ROYAL WARRANT BANNER */}
      <div className="border-b border-[#351528] py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Warrant & Heritage */}
            <div className="lg:col-span-6 flex items-start gap-4">
              <RoyalCrest size={56} className="text-[#d8b894] shrink-0" />
              <div>
                <p className="text-[11px] uppercase tracking-[0.22em] text-[#d8b894] font-semibold">
                  BY APPOINTMENT TO THE ROYAL HOUSEHOLD
                </p>
                <h3 className="font-serif text-xl sm:text-2xl text-white mt-1">
                  Daniel of Windsor Gazette
                </h3>
                <p className="text-xs text-[#c9b7aa] mt-1 max-w-md font-light leading-relaxed">
                  Join our Windsor circle to receive early access to festive collections, private sales, and seasonal invitations from Peascod Street.
                </p>
              </div>
            </div>

            {/* Newsletter input form */}
            <div className="lg:col-span-6">
              {subscribed ? (
                <div className="p-4 bg-[#351528] border border-[#52193b] rounded-none flex items-center gap-3 text-sm text-[#e8dbd1]">
                  <Check className="w-5 h-5 text-[#d8b894]" />
                  <span>Thank you. You have been subscribed to the Daniel of Windsor Gazette.</span>
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-2">
                  <div className="relative flex-1">
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Enter your email address..."
                      className="w-full px-4 py-3 bg-[#2d1424] border border-[#4d1f37] text-white text-sm placeholder-[#aa9384] focus:outline-none focus:border-[#d8b894] rounded-none"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-6 py-3 bg-[#d8b894] hover:bg-[#ebd5be] text-[#2c1221] text-xs font-bold uppercase tracking-wider rounded-none transition-colors cursor-pointer shrink-0"
                  >
                    Subscribe
                  </button>
                </form>
              )}
              <p className="text-[10px] text-[#9c8475] mt-2">
                We respect your privacy. You can unsubscribe at any time.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 2. FOOTER NAVIGATION DIRECTORY */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-xs">
          {/* Column 1: Customer Concierge */}
          <div>
            <h4 className="font-serif text-sm font-semibold uppercase tracking-wider text-white mb-4">
              Customer Concierge
            </h4>
            <ul className="space-y-2.5 text-[#cfbeb2]">
              <li>
                <button
                  onClick={() => setIsStoreModalOpen(true)}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  Windsor Store & Opening Hours
                </button>
              </li>
              <li>
                <button
                  onClick={() => setIsStoreModalOpen(true)}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  Click & Collect (2hr Service)
                </button>
              </li>
              <li>
                <span className="hover:text-white cursor-pointer">
                  Delivery & Free Returns
                </span>
              </li>
              <li>
                <span className="hover:text-white cursor-pointer">
                  Gift Cards & Presentation Vouchers
                </span>
              </li>
              <li>
                <span className="hover:text-white cursor-pointer">
                  Personal Shopping Suite
                </span>
              </li>
              <li>
                <a href="tel:+441753801000" className="hover:text-white inline-flex items-center gap-1.5 mt-2">
                  <Phone className="w-3.5 h-3.5 text-[#d8b894]" />
                  <span>+44 (0)1753 801000</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Column 2: Departments */}
          <div>
            <h4 className="font-serif text-sm font-semibold uppercase tracking-wider text-white mb-4">
              Departments
            </h4>
            <ul className="space-y-2.5 text-[#cfbeb2]">
              {['Christmas', 'Women', 'Men', 'Beauty', 'Home & Living', 'Toys', 'Food & Wine'].map((dept) => (
                <li key={dept}>
                  <button
                    onClick={() => {
                      const id = dept.toLowerCase().replace(/ & /g, '-').replace(/ /g, '-');
                      setActiveDepartment(id);
                      const sec = document.getElementById('curated-collection');
                      if (sec) sec.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="hover:text-white transition-colors cursor-pointer text-left"
                  >
                    {dept}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: The Windsor Flagship */}
          <div>
            <h4 className="font-serif text-sm font-semibold uppercase tracking-wider text-white mb-4">
              The Flagship Store
            </h4>
            <ul className="space-y-2.5 text-[#cfbeb2]">
              <li>120–124 Peascod Street</li>
              <li>Royal Borough of Windsor</li>
              <li>Berkshire, SL4 1DP</li>
              <li className="pt-2">
                <span className="text-[#d8b894] font-medium block">Daniel’s Tea Lounge</span>
                <span>Open daily for High Tea & Coffee</span>
              </li>
              <li className="pt-1">
                <span className="text-[#d8b894] font-medium block">The Toy Emporium</span>
                <span>Third floor wonderland</span>
              </li>
            </ul>
          </div>

          {/* Column 4: Heritage & Sustainability */}
          <div>
            <h4 className="font-serif text-sm font-semibold uppercase tracking-wider text-white mb-4">
              Independent Heritage
            </h4>
            <p className="text-[#cfbeb2] leading-relaxed mb-3">
              Independent and family-owned since 1900. Committed to preserving British retail heritage, craftsmanship, and local community values in Windsor.
            </p>
            <div className="flex items-center gap-2 pt-2">
              <span className="text-[11px] text-[#d8b894] font-semibold border border-[#d8b894]/40 px-2 py-0.5">
                ESTABLISHED 1900
              </span>
              <span className="text-[11px] text-[#d8b894] font-semibold border border-[#d8b894]/40 px-2 py-0.5">
                ROYAL WARRANT
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 3. BOTTOM COPYRIGHT & LEGAL BAR */}
      <div className="border-t border-[#301323] bg-[#160a12] py-6 text-xs text-[#a38e81]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© 1900–2026 Daniel of Windsor Ltd. All Rights Reserved. Registered in England & Wales.</p>

          <div className="flex items-center space-x-6 text-[11px]">
            <span className="hover:text-white cursor-pointer">Privacy Policy</span>
            <span className="hover:text-white cursor-pointer">Terms & Conditions</span>
            <span className="hover:text-white cursor-pointer">Accessibility</span>
            <button
              onClick={scrollToTop}
              className="flex items-center gap-1 text-[#d8b894] hover:text-white transition-colors cursor-pointer"
              aria-label="Scroll to top"
            >
              <span>Back to Top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
