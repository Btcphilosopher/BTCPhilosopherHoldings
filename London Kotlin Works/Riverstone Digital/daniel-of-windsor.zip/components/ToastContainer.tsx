'use client';

import React from 'react';
import { Check, X } from 'lucide-react';
import { useStore } from '@/context/StoreContext';

export default function ToastContainer() {
  const { toasts, removeToast } = useStore();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-2 max-w-sm pointer-events-none">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className="pointer-events-auto bg-[#2b1220] text-white p-3.5 rounded-none shadow-2xl border border-[#4d1f39] flex items-start gap-3 animate-in slide-in-from-bottom-2 duration-200"
        >
          <div className="p-1 rounded-full bg-[#52193b] text-[#ebd5be] shrink-0 mt-0.5">
            <Check className="w-3.5 h-3.5" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold tracking-wide text-white">{toast.title}</p>
            {toast.description && (
              <p className="text-[11px] text-[#dacbc0] line-clamp-1 mt-0.5">{toast.description}</p>
            )}
          </div>
          <button
            onClick={() => removeToast(toast.id)}
            className="text-stone-400 hover:text-white transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      ))}
    </div>
  );
}
