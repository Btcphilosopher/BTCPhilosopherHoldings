'use client';

import React, { useState } from 'react';
import { Heart, Eye, ShoppingBag, Star, Check } from 'lucide-react';
import { PRODUCTS, Product } from '@/data/storeData';
import { useStore } from '@/context/StoreContext';

export default function FeaturedProducts() {
  const {
    addToCart,
    toggleWishlist,
    isInWishlist,
    setQuickViewProduct,
    activeDepartment,
    setActiveDepartment,
  } = useStore();

  const [filterTab, setFilterTab] = useState<'all' | 'christmas' | 'fashion' | 'home' | 'gourmet' | 'beauty'>('all');
  const [addedIds, setAddedIds] = useState<string[]>([]);

  // Filter products based on active tab and department
  const filteredProducts = PRODUCTS.filter((product) => {
    if (filterTab === 'all') {
      if (activeDepartment === 'christmas') return true; // show all curated
      if (activeDepartment === 'women' || activeDepartment === 'men') {
        return product.department === 'women' || product.department === 'men';
      }
      if (activeDepartment === 'food-wine') return product.department === 'food-wine';
      if (activeDepartment === 'home' || activeDepartment === 'furniture') return product.department === 'home';
      if (activeDepartment === 'beauty') return product.department === 'beauty';
      if (activeDepartment === 'toys') return product.department === 'toys';
      if (activeDepartment === 'electricals') return product.department === 'electricals';
      return true;
    }
    if (filterTab === 'christmas') return product.department === 'christmas' || product.category.includes('Christmas');
    if (filterTab === 'fashion') return product.department === 'women' || product.department === 'men';
    if (filterTab === 'home') return product.department === 'home' || product.department === 'electricals';
    if (filterTab === 'gourmet') return product.department === 'food-wine';
    if (filterTab === 'beauty') return product.department === 'beauty';
    return true;
  });

  const handleQuickAdd = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, 1);
    setAddedIds((prev) => [...prev, product.id]);
    setTimeout(() => {
      setAddedIds((prev) => prev.filter((id) => id !== product.id));
    }, 2000);
  };

  return (
    <section id="curated-collection" className="w-full bg-white py-14 sm:py-20 border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <span className="text-xs uppercase tracking-[0.25em] text-[#52193b] font-semibold">
            ESTABLISHED 1900 · WINDSOR ARCHIVE
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl text-stone-900 mt-2 mb-3">
            Festive Highlights & Department Exclusives
          </h2>
          <p className="font-serif italic text-stone-600 text-base sm:text-lg">
            Hand-selected by our Windsor buyers — from heritage Scottish cashmere to royal hampers.
          </p>
        </div>

        {/* Filter Navigation Tabs */}
        <div className="flex items-center justify-center gap-1.5 sm:gap-2 overflow-x-auto no-scrollbar pb-6 mb-8 text-xs sm:text-sm font-medium">
          {[
            { id: 'all', label: 'All Curations' },
            { id: 'christmas', label: 'Festive & Hampers' },
            { id: 'fashion', label: 'Cashmere & Coats' },
            { id: 'home', label: 'Home & Living' },
            { id: 'beauty', label: 'Luxury Apothecary' },
            { id: 'gourmet', label: 'Fine Food & Cellar' },
          ].map((tab) => {
            const isActive = filterTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setFilterTab(tab.id as typeof filterTab)}
                className={`px-4 py-2 rounded-full transition-all cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-[#3c152a] text-white shadow-xs'
                    : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {filteredProducts.map((product) => {
            const isWishlisted = isInWishlist(product.id);
            const isJustAdded = addedIds.includes(product.id);

            return (
              <div
                key={product.id}
                onClick={() => setQuickViewProduct(product)}
                className="group flex flex-col bg-white border border-stone-100 rounded-sm hover:border-stone-300 transition-all duration-300 hover:shadow-lg cursor-pointer overflow-hidden"
              >
                {/* Image Container with Badges */}
                <div className="relative aspect-4/5 w-full overflow-hidden bg-stone-100">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
                    loading="lazy"
                  />

                  {/* Badges Overlay */}
                  <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10">
                    {product.isWindsorExclusive && (
                      <span className="bg-[#481634] text-white text-[10px] uppercase font-semibold px-2 py-0.5 tracking-wider shadow-xs">
                        Windsor Exclusive
                      </span>
                    )}
                    {product.isBestseller && !product.isWindsorExclusive && (
                      <span className="bg-stone-900 text-white text-[10px] uppercase font-semibold px-2 py-0.5 tracking-wider shadow-xs">
                        Bestseller
                      </span>
                    )}
                    {product.isNew && (
                      <span className="bg-[#c5a47e] text-stone-900 text-[10px] uppercase font-semibold px-2 py-0.5 tracking-wider shadow-xs">
                        New Season
                      </span>
                    )}
                  </div>

                  {/* Wishlist Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleWishlist(product.id);
                    }}
                    className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-xs transition-colors z-10 cursor-pointer shadow-xs ${
                      isWishlisted
                        ? 'bg-[#52193b] text-white'
                        : 'bg-white/80 hover:bg-white text-stone-700 hover:text-[#52193b]'
                    }`}
                    aria-label="Toggle wishlist"
                  >
                    <Heart
                      className={`w-4 h-4 ${isWishlisted ? 'fill-white' : ''}`}
                    />
                  </button>

                  {/* Hover Quick View Strip */}
                  <div className="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex justify-center z-10">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setQuickViewProduct(product);
                      }}
                      className="w-full py-2 bg-white/95 hover:bg-white text-stone-900 text-xs font-semibold uppercase tracking-wider rounded-none flex items-center justify-center gap-1.5 shadow-sm transition-transform active:scale-95"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      Quick View
                    </button>
                  </div>
                </div>

                {/* Content details */}
                <div className="p-4 sm:p-5 flex flex-col flex-1 justify-between">
                  <div>
                    {/* Brand kicker */}
                    <p className="text-[11px] uppercase tracking-wider text-stone-400 font-semibold mb-1">
                      {product.brand}
                    </p>

                    {/* Title */}
                    <h3 className="font-serif text-base sm:text-lg font-medium text-stone-900 line-clamp-2 leading-snug group-hover:text-[#481634] transition-colors">
                      {product.name}
                    </h3>

                    {/* Subtitle / Spec */}
                    {product.subtitle && (
                      <p className="text-xs text-stone-500 line-clamp-1 mt-1 font-light">
                        {product.subtitle}
                      </p>
                    )}

                    {/* Rating stars */}
                    <div className="flex items-center gap-1.5 mt-2">
                      <div className="flex items-center text-amber-500">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-3.5 h-3.5 ${
                              i < Math.floor(product.rating)
                                ? 'fill-amber-400 text-amber-400'
                                : 'text-stone-300'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-[11px] text-stone-500 font-medium">
                        ({product.reviewsCount})
                      </span>
                    </div>
                  </div>

                  {/* Price & Add to Bag CTA */}
                  <div className="pt-4 mt-3 border-t border-stone-100 flex items-center justify-between">
                    <div className="flex items-baseline gap-2">
                      <span className="text-base sm:text-lg font-bold text-stone-900">
                        £{product.price.toFixed(2)}
                      </span>
                      {product.originalPrice && (
                        <span className="text-xs text-stone-400 line-through">
                          £{product.originalPrice.toFixed(2)}
                        </span>
                      )}
                    </div>

                    <button
                      onClick={(e) => handleQuickAdd(product, e)}
                      className={`px-3 py-1.5 rounded-none text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-1 cursor-pointer ${
                        isJustAdded
                          ? 'bg-emerald-700 text-white'
                          : 'bg-[#481634] hover:bg-[#5e1d44] text-white active:scale-95'
                      }`}
                      aria-label={`Add ${product.name} to bag`}
                    >
                      {isJustAdded ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Added</span>
                        </>
                      ) : (
                        <>
                          <ShoppingBag className="w-3.5 h-3.5" />
                          <span>Add</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
