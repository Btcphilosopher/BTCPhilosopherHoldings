import type {Metadata, Viewport} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Daniel of Windsor | Department Store – Established 1900',
  description: 'Windsor’s premier independent department store since 1900. Discover British luxury fashion, beauty, home & living, toys, and the festive Christmas Collection.',
  keywords: ['Daniel of Windsor', 'Windsor department store', 'British luxury', 'Christmas collection', 'Peascod Street', 'Windsor Castle'],
  openGraph: {
    title: 'Daniel of Windsor | Department Store – Established 1900',
    description: 'Windsor’s premier independent department store since 1900. Discover British luxury fashion, beauty, home & living, toys, and festive gifts.',
    type: 'website',
    locale: 'en_GB',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Daniel of Windsor | Department Store – Established 1900',
    description: 'Windsor’s premier independent department store since 1900. A Season of Gifting at Daniel’s.',
  },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  themeColor: '#2b1420',
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="scroll-smooth">
      <body suppressHydrationWarning className="min-h-screen bg-white text-stone-900 selection:bg-amber-100 selection:text-amber-950">
        {children}
      </body>
    </html>
  );
}
