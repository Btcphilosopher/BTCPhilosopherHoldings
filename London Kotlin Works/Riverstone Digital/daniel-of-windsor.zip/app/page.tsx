'use client';

import React from 'react';
import { StoreProvider } from '@/context/StoreContext';
import Navbar from '@/components/Navbar';
import HeroBanner from '@/components/HeroBanner';
import ValueProps from '@/components/ValueProps';
import CategoryGrid from '@/components/CategoryGrid';
import FeaturedProducts from '@/components/FeaturedProducts';
import WindsorExperience from '@/components/WindsorExperience';
import Footer from '@/components/Footer';
import ProductQuickViewModal from '@/components/ProductQuickViewModal';
import CartDrawer from '@/components/CartDrawer';
import WishlistDrawer from '@/components/WishlistDrawer';
import StoreModal from '@/components/StoreModal';
import ToastContainer from '@/components/ToastContainer';
import { Sparkles, Gift, ArrowRight } from 'lucide-react';

function PageContent() {
  return (
    <div className="min-h-screen flex flex-col bg-white text-stone-900">
      {/* 1. Header & Navigation */}
      <Navbar />

      {/* 2. Main Hero Showcase with Reference Asset */}
      <main className="flex-1">
        <HeroBanner />

        {/* 3. Value Propositions / Trust Bar */}
        <ValueProps />

        {/* 4. Category Visual Grid (Women, Men, Beauty, Home, Food & Wine) */}
        <CategoryGrid />

        {/* 5. Curated Products Collection with Interactive Filters */}
        <FeaturedProducts />

        {/* 6. Festive Feature Highlight Banner */}
        <section className="w-full bg-[#38152c] text-white py-12 sm:py-16 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
          <div className="max-w-7xl mx-auto relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="max-w-xl text-left">
              <span className="text-xs uppercase tracking-[0.25em] text-[#dfcbb5] font-semibold flex items-center gap-1.5 mb-2">
                <Sparkles className="w-4 h-4 text-[#dfcbb5]" />
                THE WINDSOR CHRISTMAS BUREAU
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl text-white font-normal leading-tight">
                Complimentary Bespoke Gift Wrapping on Every Order
              </h2>
              <p className="font-serif italic text-sm sm:text-base text-[#e8dbd1] mt-3 font-light">
                Hand-wrapped in Daniel’s archival plum paper, sealed with traditional red wax and finished with royal satin ribbon.
              </p>
            </div>

            <div className="flex flex-wrap gap-4 items-center shrink-0">
              <button
                onClick={() => {
                  const sec = document.getElementById('curated-collection');
                  if (sec) sec.scrollIntoView({ behavior: 'smooth' });
                }}
                className="px-6 py-3 bg-[#dfcbb5] hover:bg-[#ebd5be] text-[#2e1324] text-xs sm:text-sm font-bold uppercase tracking-wider rounded-none inline-flex items-center gap-2 transition-all cursor-pointer shadow-md"
              >
                <Gift className="w-4 h-4" />
                <span>Shop Christmas Gifts</span>
              </button>
            </div>
          </div>
        </section>

        {/* 7. Windsor Heritage & Flagship Store Experience */}
        <WindsorExperience />
      </main>

      {/* 8. Footer */}
      <Footer />

      {/* Global Interactive Modals & Slide Drawers */}
      <ProductQuickViewModal />
      <CartDrawer />
      <WishlistDrawer />
      <StoreModal />
      <ToastContainer />
    </div>
  );
}

export default function Home() {
  return (
    <StoreProvider>
      <PageContent />
    </StoreProvider>
  );
}
