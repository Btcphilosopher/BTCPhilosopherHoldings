'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, PRODUCTS } from '@/data/storeData';

export interface CartItem {
  product: Product;
  quantity: number;
  selectedSize?: string;
  selectedColor?: string;
  giftWrapped?: boolean;
}

interface ToastMessage {
  id: string;
  title: string;
  description?: string;
  type?: 'success' | 'info';
}

interface StoreContextType {
  cart: CartItem[];
  wishlistIds: string[];
  addToCart: (product: Product, quantity?: number, options?: { size?: string; color?: string; giftWrapped?: boolean }) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  toggleGiftWrap: (productId: string) => void;
  clearCart: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;
  isWishlistOpen: boolean;
  setIsWishlistOpen: (open: boolean) => void;
  quickViewProduct: Product | null;
  setQuickViewProduct: (product: Product | null) => void;
  isStoreModalOpen: boolean;
  setIsStoreModalOpen: (open: boolean) => void;
  isMobileMenuOpen: boolean;
  setIsMobileMenuOpen: (open: boolean) => void;
  activeDepartment: string;
  setActiveDepartment: (deptId: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  cartCount: number;
  cartSubtotal: number;
  toasts: ToastMessage[];
  addToast: (title: string, description?: string) => void;
  removeToast: (id: string) => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  // Initial cart with a curated Christmas hamper to give an immediate authentic feel
  const [cart, setCart] = useState<CartItem[]>([
    {
      product: PRODUCTS[0], // The Windsor Castle Luxury Wicker Hamper
      quantity: 1,
      giftWrapped: true,
    }
  ]);
  const [wishlistIds, setWishlistIds] = useState<string[]>([PRODUCTS[1].id, PRODUCTS[2].id]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [isStoreModalOpen, setIsStoreModalOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeDepartment, setActiveDepartment] = useState('christmas');
  const [searchQuery, setSearchQuery] = useState('');
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Calculate cart counts
  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);
  const cartSubtotal = cart.reduce((total, item) => {
    const itemPrice = item.product.price + (item.giftWrapped ? 4.95 : 0);
    return total + itemPrice * item.quantity;
  }, 0);

  const addToast = (title: string, description?: string) => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 6);
    setToasts((prev) => [...prev, { id, title, description, type: 'success' }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const addToCart = (
    product: Product,
    quantity = 1,
    options?: { size?: string; color?: string; giftWrapped?: boolean }
  ) => {
    setCart((prevCart) => {
      const existingIndex = prevCart.findIndex(
        (item) =>
          item.product.id === product.id &&
          item.selectedSize === options?.size &&
          item.selectedColor === options?.color
      );

      if (existingIndex > -1) {
        const next = [...prevCart];
        next[existingIndex].quantity += quantity;
        return next;
      }

      return [
        ...prevCart,
        {
          product,
          quantity,
          selectedSize: options?.size,
          selectedColor: options?.color,
          giftWrapped: options?.giftWrapped ?? false,
        },
      ];
    });

    addToast('Added to your Bag', `${product.name} (x${quantity})`);
    setIsCartOpen(true);
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, quantity } : item))
    );
  };

  const toggleGiftWrap = (productId: string) => {
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, giftWrapped: !item.giftWrapped } : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const toggleWishlist = (productId: string) => {
    const isSaved = wishlistIds.includes(productId);
    const prod = PRODUCTS.find((p) => p.id === productId);
    if (isSaved) {
      setWishlistIds((prev) => prev.filter((id) => id !== productId));
      if (prod) addToast('Removed from Wishlist', prod.name);
    } else {
      setWishlistIds((prev) => [...prev, productId]);
      if (prod) addToast('Saved to Wishlist', prod.name);
    }
  };

  const isInWishlist = (productId: string) => wishlistIds.includes(productId);

  return (
    <StoreContext.Provider
      value={{
        cart,
        wishlistIds,
        addToCart,
        removeFromCart,
        updateQuantity,
        toggleGiftWrap,
        clearCart,
        isCartOpen,
        setIsCartOpen,
        toggleWishlist,
        isInWishlist,
        isWishlistOpen,
        setIsWishlistOpen,
        quickViewProduct,
        setQuickViewProduct,
        isStoreModalOpen,
        setIsStoreModalOpen,
        isMobileMenuOpen,
        setIsMobileMenuOpen,
        activeDepartment,
        setActiveDepartment,
        searchQuery,
        setSearchQuery,
        cartCount,
        cartSubtotal,
        toasts,
        addToast,
        removeToast,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
}
