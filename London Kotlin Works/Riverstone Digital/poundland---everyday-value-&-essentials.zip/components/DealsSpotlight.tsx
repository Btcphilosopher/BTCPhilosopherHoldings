'use client';

import React from 'react';
import Image from 'next/image';
import { Sparkles, ArrowRight, ShoppingBasket, CheckCircle2 } from 'lucide-react';
import { useStore } from '@/context/StoreContext';
import { PRODUCTS } from '@/data/products';

export default function DealsSpotlight() {
  const { addToCart, showToast, setSelectedCategory } = useStore();

  const handleAddBundle = (productIds: string[], bundleName: string) => {
    productIds.forEach(id => {
      const prod = PRODUCTS.find(p => p.id === id);
      if (prod) {
        addToCart(prod, 1);
      }
    });
    showToast(`Added ${bundleName} to basket!`, 'success');
  };

  return (
    <section className="py-10 bg-gradient-to-b from-white via-slate-50 to-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4">
        
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 mb-6">
          <div>
            <div className="flex items-center gap-1.5 text-xs font-bold text-[#006967] uppercase tracking-wider mb-1">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>Multi-Buy Savings</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Deals of the Week & Bundles
            </h2>
          </div>
          <button
            onClick={() => {
              setSelectedCategory('offers');
              const el = document.getElementById('product-catalog');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className="text-xs sm:text-sm font-bold text-[#006967] hover:underline flex items-center gap-1"
          >
            <span>See All Multi-Buy Offers</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* 3 Bundle Deal Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6">
          
          {/* Bundle 1 */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="bg-[#FFDD00] text-emerald-950 text-xs font-black px-2.5 py-1 rounded-full uppercase tracking-wider">
                  Save 25%
                </span>
                <span className="text-xs font-semibold text-slate-400">Household Essentials</span>
              </div>
              <h3 className="text-base font-bold text-slate-900 leading-snug">
                Sparkling Clean Kitchen Bundle
              </h3>
              <p className="text-xs text-slate-500 mt-1 mb-4">
                Fairy Washing Up Liquid 320ml + Flash Multi-Surface Spray 500ml
              </p>

              <div className="space-y-1.5 text-xs text-slate-600 mb-4">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Ultra grease cutting Fairy formula</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Antibacterial lemon surface spray</span>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-400 line-through mr-1.5">£2.50</span>
                <span className="text-lg font-black text-slate-900">£2.00</span>
              </div>
              <button
                onClick={() => handleAddBundle(['pl-002', 'pl-006'], 'Clean Kitchen Bundle')}
                className="px-3.5 py-2 bg-[#006967] hover:bg-[#005452] active:scale-95 text-white font-bold text-xs rounded-lg flex items-center gap-1.5 shadow-xs transition-all cursor-pointer"
              >
                <ShoppingBasket className="w-3.5 h-3.5" />
                <span>Add Both</span>
              </button>
            </div>
          </div>

          {/* Bundle 2 */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="bg-[#FFDD00] text-emerald-950 text-xs font-black px-2.5 py-1 rounded-full uppercase tracking-wider">
                  Movie Night
                </span>
                <span className="text-xs font-semibold text-slate-400">Sweet Treats</span>
              </div>
              <h3 className="text-base font-bold text-slate-900 leading-snug">
                Sweet Treats Double Pack
              </h3>
              <p className="text-xs text-slate-500 mt-1 mb-4">
                Cadbury Dairy Milk Giant Buttons 110g + Haribo Starmix 140g
              </p>

              <div className="space-y-1.5 text-xs text-slate-600 mb-4">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Velvety smooth British milk chocolate</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Iconic chewy gummy mix without artificial colours</span>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-400 line-through mr-1.5">£2.00</span>
                <span className="text-lg font-black text-slate-900">£1.80</span>
              </div>
              <button
                onClick={() => handleAddBundle(['pl-010', 'pl-011'], 'Sweet Treats Bundle')}
                className="px-3.5 py-2 bg-[#006967] hover:bg-[#005452] active:scale-95 text-white font-bold text-xs rounded-lg flex items-center gap-1.5 shadow-xs transition-all cursor-pointer"
              >
                <ShoppingBasket className="w-3.5 h-3.5" />
                <span>Add Both</span>
              </button>
            </div>
          </div>

          {/* Bundle 3 */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="bg-[#FFDD00] text-emerald-950 text-xs font-black px-2.5 py-1 rounded-full uppercase tracking-wider">
                  Party Ready
                </span>
                <span className="text-xs font-semibold text-slate-400">Celebration Pack</span>
              </div>
              <h3 className="text-base font-bold text-slate-900 leading-snug">
                Birthday Bash Starter Pack
              </h3>
              <p className="text-xs text-slate-500 mt-1 mb-4">
                50 Assorted Latex Balloons + Gold Happy Birthday Garland 2m
              </p>

              <div className="space-y-1.5 text-xs text-slate-600 mb-4">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Biodegradable 10-inch party balloons</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Pre-strung metallic gold foil lettering</span>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-400 line-through mr-1.5">£2.00</span>
                <span className="text-lg font-black text-slate-900">£1.75</span>
              </div>
              <button
                onClick={() => handleAddBundle(['pl-017', 'pl-018'], 'Birthday Party Bundle')}
                className="px-3.5 py-2 bg-[#006967] hover:bg-[#005452] active:scale-95 text-white font-bold text-xs rounded-lg flex items-center gap-1.5 shadow-xs transition-all cursor-pointer"
              >
                <ShoppingBasket className="w-3.5 h-3.5" />
                <span>Add Both</span>
              </button>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
