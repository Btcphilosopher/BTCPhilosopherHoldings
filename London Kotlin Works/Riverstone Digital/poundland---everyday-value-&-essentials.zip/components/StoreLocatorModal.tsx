'use client';

import React, { useState } from 'react';
import { 
  X, 
  MapPin, 
  Search, 
  Phone, 
  Clock, 
  Check, 
  Store,
  Navigation
} from 'lucide-react';
import { useStore } from '@/context/StoreContext';
import { UK_STORES, UKStore } from '@/data/products';

export default function StoreLocatorModal() {
  const { 
    isStoreLocatorOpen, 
    setIsStoreLocatorOpen, 
    selectedStore, 
    setSelectedStore,
    showToast 
  } = useStore();

  const [searchQuery, setSearchQuery] = useState('');

  if (!isStoreLocatorOpen) return null;

  const filteredStores = UK_STORES.filter(store =>
    store.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    store.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
    store.postcode.toLowerCase().includes(searchQuery.toLowerCase()) ||
    store.address.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSelectStore = (store: UKStore) => {
    setSelectedStore(store);
    showToast(`Selected store: ${store.name}`, 'success');
    setIsStoreLocatorOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={() => setIsStoreLocatorOpen(false)}
      />

      <div className="flex min-h-full items-center justify-center p-4 text-center sm:p-0">
        <div className="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-2xl transition-all sm:my-8 sm:w-full sm:max-w-xl">
          
          {/* Header */}
          <div className="bg-[#006967] text-white p-5 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-[#FFDD00]" />
              <div>
                <h3 className="text-lg font-black tracking-tight">Find a Poundland Store</h3>
                <p className="text-xs text-emerald-100">700+ stores UK-wide with Click & Collect</p>
              </div>
            </div>
            <button
              onClick={() => setIsStoreLocatorOpen(false)}
              className="text-white/80 hover:text-white p-1 rounded-md hover:bg-white/10"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Search Box */}
          <div className="p-4 bg-slate-50 border-b border-slate-200">
            <div className="relative">
              <input
                type="text"
                placeholder="Enter UK postcode or town (e.g. London, Birmingham, W1D)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white text-slate-800 text-xs sm:text-sm pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#006967]"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            </div>
            <div className="flex items-center gap-2 mt-2 text-[11px] text-slate-500">
              <Navigation className="w-3 h-3 text-[#006967]" />
              <span>Current selected store: <strong className="text-slate-900">{selectedStore.name}</strong></span>
            </div>
          </div>

          {/* Store List */}
          <div className="p-4 max-h-[380px] overflow-y-auto space-y-3">
            {filteredStores.length > 0 ? (
              filteredStores.map((store) => {
                const isSelected = selectedStore.id === store.id;

                return (
                  <div
                    key={store.id}
                    className={`p-3.5 rounded-xl border transition-all ${
                      isSelected
                        ? 'border-[#006967] bg-emerald-50/50 ring-1 ring-[#006967]'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-bold text-slate-900">{store.name}</h4>
                          {isSelected && (
                            <span className="bg-[#006967] text-white text-[10px] font-bold px-1.5 py-0.5 rounded-sm">
                              My Store
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-600 mt-0.5">{store.address}</p>
                        <p className="text-xs font-semibold text-slate-500">{store.postcode}</p>
                      </div>

                      <div className="text-right shrink-0">
                        <span className="text-xs font-bold text-[#006967] bg-emerald-100/70 px-2 py-0.5 rounded-full">
                          {store.distance}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 mt-3 pt-2.5 border-t border-slate-100 text-[11px] text-slate-600">
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-slate-400" />
                        <span>Today: <strong>{store.hoursToday}</strong></span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5 text-slate-400" />
                        <span>{store.phone}</span>
                      </div>
                    </div>

                    <div className="mt-3 flex items-center justify-between">
                      <span className="text-[11px] font-medium text-emerald-800 flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                        Click & Collect Ready
                      </span>

                      <button
                        onClick={() => handleSelectStore(store)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-slate-200 text-slate-700 cursor-default'
                            : 'bg-[#FFDD00] hover:bg-yellow-400 text-slate-950 active:scale-95 shadow-xs'
                        }`}
                      >
                        {isSelected ? 'Selected' : 'Set as My Store'}
                      </button>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="p-8 text-center text-slate-500">
                <Store className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <p className="text-sm font-semibold">No stores found matching &ldquo;{searchQuery}&rdquo;</p>
                <p className="text-xs text-slate-400 mt-1">Try searching by city like London or Manchester</p>
              </div>
            )}
          </div>

          {/* Footer note */}
          <div className="p-3 bg-slate-50 border-t border-slate-200 text-center text-xs text-slate-500">
            Need directions? Opening times are subject to bank holidays.
          </div>

        </div>
      </div>
    </div>
  );
}
