'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { 
  X, 
  User, 
  Award, 
  Heart, 
  ShoppingBag, 
  PackageCheck, 
  Trash2,
  Plus
} from 'lucide-react';
import { useStore } from '@/context/StoreContext';
import { PRODUCTS } from '@/data/products';

export default function AccountModal() {
  const { 
    isAccountOpen, 
    setIsAccountOpen, 
    wishlist, 
    toggleWishlist, 
    addToCart,
    showToast 
  } = useStore();

  const [activeTab, setActiveTab] = useState<'rewards' | 'wishlist' | 'orders'>('rewards');

  if (!isAccountOpen) return null;

  const savedProducts = PRODUCTS.filter(p => wishlist.includes(p.id));

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={() => setIsAccountOpen(false)}
      />

      <div className="flex min-h-full items-center justify-center p-4 text-center sm:p-0">
        <div className="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-2xl transition-all sm:my-8 sm:w-full sm:max-w-xl">
          
          {/* Header */}
          <div className="bg-[#006967] text-white p-5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center text-white">
                <User className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-black">Alex Taylor</h3>
                <p className="text-xs text-emerald-100">Poundland Club Member · Gold Tier</p>
              </div>
            </div>
            <button
              onClick={() => setIsAccountOpen(false)}
              className="text-white/80 hover:text-white p-1 rounded-md hover:bg-white/10"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Tabs */}
          <div className="flex border-b border-slate-200 bg-slate-50 text-xs font-bold text-slate-600">
            <button
              onClick={() => setActiveTab('rewards')}
              className={`flex-1 py-3 text-center border-b-2 transition-colors flex items-center justify-center gap-1.5 ${
                activeTab === 'rewards'
                  ? 'border-[#006967] text-[#006967] bg-white'
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              <Award className="w-4 h-4" />
              <span>Rewards Club</span>
            </button>
            <button
              onClick={() => setActiveTab('wishlist')}
              className={`flex-1 py-3 text-center border-b-2 transition-colors flex items-center justify-center gap-1.5 ${
                activeTab === 'wishlist'
                  ? 'border-[#006967] text-[#006967] bg-white'
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              <Heart className="w-4 h-4" />
              <span>Saved Items ({wishlist.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('orders')}
              className={`flex-1 py-3 text-center border-b-2 transition-colors flex items-center justify-center gap-1.5 ${
                activeTab === 'orders'
                  ? 'border-[#006967] text-[#006967] bg-white'
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              <PackageCheck className="w-4 h-4" />
              <span>Past Orders</span>
            </button>
          </div>

          {/* Tab Content */}
          <div className="p-5 max-h-[400px] overflow-y-auto">
            {activeTab === 'rewards' && (
              <div className="space-y-4">
                {/* Rewards Card */}
                <div className="rounded-2xl p-5 bg-gradient-to-br from-[#006967] via-[#005250] to-[#003b39] text-white shadow-md relative overflow-hidden">
                  <div className="absolute right-[-20px] top-[-20px] w-32 h-32 rounded-full bg-white/5 pointer-events-none" />
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-bold tracking-wider text-[#FFDD00] uppercase">
                      Poundland Club Card
                    </span>
                    <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full">
                      Member ID: 8941 2049
                    </span>
                  </div>

                  <div className="space-y-1">
                    <span className="text-xs text-emerald-100">Reward Balance</span>
                    <div className="flex items-baseline gap-2">
                      <span className="text-3xl font-black tabular-nums">340</span>
                      <span className="text-sm font-semibold text-emerald-200">Points = £3.40 Voucher</span>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs text-emerald-100">
                    <span>Spend points at checkout</span>
                    <span className="text-[#FFDD00] font-bold">100 pts = £1.00</span>
                  </div>
                </div>

                {/* Exclusive Member Perks */}
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                    Your Active Perks
                  </h4>
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1">
                    <div className="flex justify-between font-bold text-slate-800">
                      <span>10% Off Household Cleaning</span>
                      <span className="text-[#006967]">Active</span>
                    </div>
                    <p className="text-slate-500 text-[11px]">Automatically applied to qualifying items in basket.</p>
                  </div>
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1">
                    <div className="flex justify-between font-bold text-slate-800">
                      <span>Free Click & Collect under £20</span>
                      <span className="text-[#006967]">1 token available</span>
                    </div>
                    <p className="text-slate-500 text-[11px]">Valid on your next store pickup.</p>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'wishlist' && (
              <div className="space-y-3">
                {savedProducts.length > 0 ? (
                  savedProducts.map((product) => (
                    <div 
                      key={product.id}
                      className="p-3 bg-white border border-slate-200 rounded-xl flex items-center justify-between gap-3 hover:border-slate-300 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-center shrink-0 p-1">
                          <Image
                            src={product.image}
                            alt={product.name}
                            width={48}
                            height={48}
                            className="object-contain max-h-full"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-slate-400">{product.brand}</p>
                          <h4 className="text-xs sm:text-sm font-bold text-slate-900 line-clamp-1">{product.name}</h4>
                          <span className="text-xs font-black text-slate-900 tabular-nums">£{product.price.toFixed(2)}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          onClick={() => {
                            addToCart(product, 1);
                          }}
                          className="px-2.5 py-1.5 bg-[#FFDD00] text-slate-950 font-bold text-xs rounded-lg hover:bg-yellow-400 active:scale-95 transition-all flex items-center gap-1 shadow-xs cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>Basket</span>
                        </button>
                        <button
                          onClick={() => toggleWishlist(product.id)}
                          className="p-1.5 text-slate-400 hover:text-red-500 transition-colors"
                          title="Remove from saved"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="py-8 text-center text-slate-400">
                    <Heart className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                    <p className="text-sm font-bold text-slate-700">No saved items yet</p>
                    <p className="text-xs text-slate-500 mt-1">Tap the heart icon on any product to save it here.</p>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'orders' && (
              <div className="space-y-3">
                <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-900">Order #PL-73921</span>
                    <span className="bg-emerald-100 text-[#006967] font-bold text-[10px] px-2 py-0.5 rounded-full">
                      Collected
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">Oxford Street Branch · 3 items · £5.25</p>
                  <p className="text-[11px] text-slate-400">Date: 28 Oct 2026</p>
                </div>

                <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-900">Order #PL-61402</span>
                    <span className="bg-emerald-100 text-[#006967] font-bold text-[10px] px-2 py-0.5 rounded-full">
                      Delivered
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">Home Delivery · 8 items · £14.50</p>
                  <p className="text-[11px] text-slate-400">Date: 12 Oct 2026</p>
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="p-3 bg-slate-50 border-t border-slate-200 flex justify-between items-center text-xs text-slate-500">
            <span>Signed in as alex.taylor@example.co.uk</span>
            <button
              onClick={() => {
                showToast('Signed out of demo session', 'info');
                setIsAccountOpen(false);
              }}
              className="text-xs font-bold text-red-600 hover:underline cursor-pointer"
            >
              Sign Out
            </button>
          </div>

        </div>
      </div>
    </div>
  );
}
