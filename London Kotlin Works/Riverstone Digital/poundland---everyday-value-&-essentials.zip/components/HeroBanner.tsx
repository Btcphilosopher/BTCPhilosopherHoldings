'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { ChevronLeft, ChevronRight, ArrowRight, Sparkles } from 'lucide-react';
import { useStore } from '@/context/StoreContext';

interface Slide {
  id: string;
  badge: string;
  titleLine1: string;
  titleLine2: string;
  titleHighlight: string;
  subtitle: string;
  ctaText: string;
  categoryTarget: string;
  imageSrc: string;
  imageAlt: string;
  accentBg: string;
}

const SLIDES: Slide[] = [
  {
    id: 'essentials',
    badge: 'Everyday Low Prices',
    titleLine1: 'Everyday',
    titleLine2: 'Essentials',
    titleHighlight: 'for £1',
    subtitle: 'Great value on the products you use every day.',
    ctaText: 'Shop £1 Essentials',
    categoryTarget: 'essentials',
    imageSrc: '/hero/basket_products.png',
    imageAlt: 'Poundland shopping basket with Fairy, Toilet Tissue, Colgate, NIVEA and Carex',
    accentBg: 'from-[#006967] via-[#005c5a] to-[#004f4d]'
  },
  {
    id: 'bigbrands',
    badge: 'Household Brands',
    titleLine1: 'Big Brands,',
    titleLine2: 'Unbeatable',
    titleHighlight: 'Mega Value',
    subtitle: 'Top names like Heinz, Cadbury, Flash & Haribo at everyday prices.',
    ctaText: 'Explore Big Brands',
    categoryTarget: 'food',
    imageSrc: '/hero/basket_products.png',
    imageAlt: 'Big brand grocery and household savings',
    accentBg: 'from-[#005f5d] via-[#005250] to-[#004442]'
  },
  {
    id: 'seasonal',
    badge: 'Seasonal Collections',
    titleLine1: 'Make Every',
    titleLine2: 'Celebration Special',
    titleHighlight: 'for Less',
    subtitle: 'Parties, holidays, and cozy home decor without the big price tag.',
    ctaText: 'Discover Seasonal',
    categoryTarget: 'seasonal',
    imageSrc: '/hero/basket_products.png',
    imageAlt: 'Seasonal parties and cozy decor',
    accentBg: 'from-[#006967] via-[#005452] to-[#004342]'
  }
];

export default function HeroBanner() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const { setSelectedCategory } = useStore();

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + SLIDES.length) % SLIDES.length);
  };

  useEffect(() => {
    if (isPaused) return;
    const timer = setInterval(() => {
      nextSlide();
    }, 6000);
    return () => clearInterval(timer);
  }, [isPaused, currentSlide]);

  const slide = SLIDES[currentSlide];

  const handleCtaClick = () => {
    setSelectedCategory(slide.categoryTarget);
    const el = document.getElementById('product-catalog');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section 
      className="relative overflow-hidden bg-[#006967] text-white"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      aria-label="Promotional campaign banner"
    >
      {/* Background stylized radiant pattern */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-white/10 via-transparent to-black/20 pointer-events-none" />

      {/* Decorative yellow burst rays on desktop */}
      <div className="hidden lg:block absolute left-[380px] top-[70px] pointer-events-none select-none opacity-90">
        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M10 20L0 15L10 10L15 0L20 10L30 15L20 20L15 30L10 20Z" fill="#FFDD00" />
          <path d="M42 35L35 30L42 25L45 18L48 25L55 30L48 35L45 42L42 35Z" fill="#FFDD00" />
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12 md:py-14 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center min-h-[380px] sm:min-h-[420px]">
          
          {/* Left Text Column (as in screenshot) */}
          <div className="lg:col-span-6 xl:col-span-5 text-left space-y-4 sm:space-y-6">
            
            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-black tracking-tight text-white leading-[1.08] text-balance">
              <span className="block">{slide.titleLine1}</span>
              <span className="block">{slide.titleLine2}</span>
              <span className="inline-block relative text-white mt-1">
                {slide.titleHighlight}
                {/* Yellow Hand-drawn Brush Underline */}
                <span className="absolute -bottom-2 left-0 right-0 h-2 bg-[#FFDD00] rounded-sm transform -rotate-1 origin-left shadow-xs"></span>
              </span>
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg md:text-xl text-emerald-50 max-w-md font-normal leading-relaxed">
              {slide.subtitle.includes('use every day') ? (
                <>
                  Great value on the products you{' '}
                  <strong className="text-white font-bold">use every day.</strong>
                </>
              ) : (
                slide.subtitle
              )}
            </p>

            {/* CTA Button (Yellow button with chevron, matching screenshot) */}
            <div className="pt-2">
              <button
                onClick={handleCtaClick}
                className="inline-flex items-center gap-2 px-6 sm:px-7 py-3 sm:py-3.5 bg-[#FFDD00] hover:bg-yellow-400 active:scale-98 text-slate-950 font-bold text-sm sm:text-base rounded-full shadow-lg hover:shadow-xl transition-all duration-150 cursor-pointer group"
              >
                <span>{slide.ctaText}</span>
                <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>

            {/* Quick feature pill */}
            <div className="pt-2 flex items-center gap-2 text-xs text-emerald-200">
              <span className="inline-block w-2 h-2 rounded-full bg-[#FFDD00]"></span>
              <span>In store & online · While stocks last</span>
            </div>
          </div>

          {/* Right Visual Column (Poundland Basket with essentials) */}
          <div className="lg:col-span-6 xl:col-span-7 flex justify-center lg:justify-end items-center relative">
            <div className="relative w-full max-w-[560px] lg:max-w-[640px] aspect-[16/10] sm:aspect-[16/9] drop-shadow-2xl">
              <Image
                src={slide.imageSrc}
                alt={slide.imageAlt}
                fill
                priority
                className="object-contain object-center lg:object-right transition-transform duration-500 hover:scale-102"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>

        </div>
      </div>

      {/* Carousel Navigation Buttons (Chevron circles, as in screenshot) */}
      <button
        onClick={prevSlide}
        aria-label="Previous slide"
        className="absolute left-3 sm:left-6 top-1/2 -translate-y-1/2 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-black/20 hover:bg-black/40 text-white backdrop-blur-xs flex items-center justify-center border border-white/20 transition-all active:scale-95 cursor-pointer z-20"
      >
        <ChevronLeft className="w-6 h-6" />
      </button>

      <button
        onClick={nextSlide}
        aria-label="Next slide"
        className="absolute right-3 sm:right-6 top-1/2 -translate-y-1/2 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-black/20 hover:bg-black/40 text-white backdrop-blur-xs flex items-center justify-center border border-white/20 transition-all active:scale-95 cursor-pointer z-20"
      >
        <ChevronRight className="w-6 h-6" />
      </button>

      {/* Pagination Dots (Matching screenshot with active elongated pill) */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 z-20">
        {SLIDES.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentSlide(idx)}
            aria-label={`Go to slide ${idx + 1}`}
            className={`transition-all duration-200 cursor-pointer ${
              currentSlide === idx
                ? 'w-7 h-2 bg-white rounded-full'
                : 'w-2 h-2 bg-white/40 hover:bg-white/70 rounded-full'
            }`}
          />
        ))}
      </div>
    </section>
  );
}
