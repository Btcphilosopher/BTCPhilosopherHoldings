'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { 
  X, 
  Star, 
  ShoppingBasket, 
  Heart, 
  Check, 
  ShieldCheck, 
  Store, 
  Plus, 
  Minus 
} from 'lucide-react';
import { useStore } from '@/context/StoreContext';

export default function QuickViewModal() {
  const { 
    quickViewProduct, 
    setQuickViewProduct, 
    addToCart, 
    toggleWishlist, 
    isWishlisted,
    selectedStore
  } = useStore();

  const [quantity, setQuantity] = useState(1);

  if (!quickViewProduct) return null;

  const isSaved = isWishlisted(quickViewProduct.id);

  const handleAdd = () => {
    addToCart(quickViewProduct, quantity);
    setQuickViewProduct(null);
    setQuantity(1);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={() => setQuickViewProduct(null)}
      />

      <div className="flex min-h-full items-center justify-center p-4 text-center sm:p-0">
        <div className="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-2xl transition-all sm:my-8 sm:w-full sm:max-w-2xl">
          
          {/* Close button */}
          <button
            onClick={() => setQuickViewProduct(null)}
            className="absolute top-4 right-4 z-10 w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="grid grid-cols-1 md:grid-cols-2">
            
            {/* Image side */}
            <div className="p-8 bg-slate-50 flex items-center justify-center relative border-b md:border-b-0 md:border-r border-slate-200">
              {quickViewProduct.badge && (
                <span className="absolute top-4 left-4 bg-[#006967] text-white text-[11px] font-bold px-2 py-0.5 rounded-sm shadow-xs uppercase tracking-wider">
                  {quickViewProduct.badge}
                </span>
              )}
              <div className="relative w-full aspect-square max-w-[260px]">
                <Image
                  src={quickViewProduct.image}
                  alt={quickViewProduct.name}
                  fill
                  className="object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>

            {/* Content side */}
            <div className="p-6 flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                  <span className="font-bold text-[#006967] uppercase tracking-wider">
                    {quickViewProduct.brand}
                  </span>
                  <span>{quickViewProduct.unit}</span>
                </div>

                <h3 className="text-lg font-black text-slate-900 leading-snug">
                  {quickViewProduct.name}
                </h3>

                {/* Rating */}
                <div className="flex items-center gap-1.5 mt-2">
                  <div className="flex items-center text-amber-400">
                    <Star className="w-4 h-4 fill-current" />
                  </div>
                  <span className="text-xs font-bold text-slate-800">{quickViewProduct.rating}</span>
                  <span className="text-xs text-slate-400">({quickViewProduct.reviewsCount} verified reviews)</span>
                </div>

                {/* Price */}
                <div className="mt-3 flex items-baseline gap-2">
                  <span className="text-2xl font-black text-slate-900 tabular-nums">
                    £{quickViewProduct.price.toFixed(2)}
                  </span>
                  {quickViewProduct.originalPrice && (
                    <span className="text-sm text-slate-400 line-through tabular-nums">
                      £{quickViewProduct.originalPrice.toFixed(2)}
                    </span>
                  )}
                  <span className="text-xs text-slate-500 font-medium">
                    ({quickViewProduct.pricePerUnit})
                  </span>
                </div>

                {/* Description */}
                <p className="text-xs text-slate-600 mt-3 leading-relaxed">
                  {quickViewProduct.description}
                </p>

                {/* Features */}
                <div className="mt-3 space-y-1">
                  {quickViewProduct.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-1.5 text-xs text-slate-700">
                      <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>

                {/* Store Availability */}
                <div className="mt-4 p-2.5 bg-emerald-50 rounded-lg text-[11px] text-[#006967] flex items-center gap-2 font-medium">
                  <Store className="w-4 h-4 shrink-0" />
                  <span>In stock for Click & Collect today at <strong>{selectedStore.name}</strong></span>
                </div>
              </div>

              {/* Quantity & Actions */}
              <div className="pt-3 border-t border-slate-200 space-y-3">
                <div className="flex items-center gap-3">
                  <div className="flex items-center border border-slate-300 rounded-lg bg-slate-50">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="w-8 h-9 flex items-center justify-center text-slate-600 hover:bg-slate-200"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="w-8 text-center text-xs font-bold tabular-nums">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity(quantity + 1)}
                      className="w-8 h-9 flex items-center justify-center text-slate-600 hover:bg-slate-200"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <button
                    onClick={handleAdd}
                    className="flex-1 py-2.5 px-4 bg-[#FFDD00] hover:bg-yellow-400 text-slate-950 font-black text-xs sm:text-sm rounded-lg shadow-sm flex items-center justify-center gap-2 active:scale-98 transition-all cursor-pointer"
                  >
                    <ShoppingBasket className="w-4 h-4" />
                    <span>Add to Basket · £{(quickViewProduct.price * quantity).toFixed(2)}</span>
                  </button>

                  <button
                    onClick={() => toggleWishlist(quickViewProduct.id)}
                    className={`p-2.5 rounded-lg border transition-colors ${
                      isSaved
                        ? 'border-red-200 bg-red-50 text-red-600'
                        : 'border-slate-300 text-slate-600 hover:bg-slate-100'
                    }`}
                    title="Save to wishlist"
                  >
                    <Heart className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
                  </button>
                </div>
              </div>

            </div>

          </div>

        </div>
      </div>
    </div>
  );
}
