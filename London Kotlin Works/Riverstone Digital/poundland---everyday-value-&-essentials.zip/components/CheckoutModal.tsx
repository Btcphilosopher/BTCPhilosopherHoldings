'use client';

import React, { useState } from 'react';
import { 
  X, 
  CheckCircle2, 
  CreditCard, 
  Store, 
  Truck, 
  Lock, 
  ArrowRight, 
  Receipt,
  Download,
  ShoppingBag
} from 'lucide-react';
import { useStore } from '@/context/StoreContext';

export default function CheckoutModal() {
  const { 
    isCheckoutOpen, 
    setIsCheckoutOpen,
    cart,
    clearCart,
    subtotal,
    deliveryMethod,
    deliveryFee,
    appliedCoupon,
    discountAmount,
    grandTotal,
    selectedStore,
    showToast
  } = useStore();

  const [step, setStep] = useState<'details' | 'payment' | 'confirmed'>('details');
  const [formData, setFormData] = useState({
    firstName: 'Alex',
    lastName: 'Taylor',
    email: 'alex.taylor@example.co.uk',
    phone: '07700 900123',
    postcode: 'W1D 2LP',
    address: '14 Berwick Street, Soho, London',
    paymentMethod: 'card',
    cardNumber: '•••• •••• •••• 4242',
    cardExpiry: '11/28',
    cardCvc: '123'
  });
  const [orderNumber, setOrderNumber] = useState('');

  if (!isCheckoutOpen) return null;

  const handleDetailsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('payment');
  };

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const newOrderNum = 'PL-' + Math.floor(100000 + Math.random() * 900000);
    setOrderNumber(newOrderNum);
    setStep('confirmed');
    clearCart();
    showToast(`Order ${newOrderNum} confirmed!`, 'success');
  };

  const handleClose = () => {
    setIsCheckoutOpen(false);
    setStep('details');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={step === 'confirmed' ? handleClose : undefined}
      />

      <div className="flex min-h-full items-center justify-center p-4 text-center sm:p-0">
        <div className="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-2xl transition-all sm:my-8 sm:w-full sm:max-w-xl">
          
          {/* Header */}
          <div className="bg-[#006967] text-white p-5 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Lock className="w-5 h-5 text-[#FFDD00]" />
              <h3 className="text-lg font-black tracking-tight">
                {step === 'confirmed' ? 'Order Confirmed' : 'Secure Poundland Checkout'}
              </h3>
            </div>
            <button
              onClick={handleClose}
              className="text-white/80 hover:text-white p-1 rounded-md hover:bg-white/10"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Stepper indicator if not confirmed */}
          {step !== 'confirmed' && (
            <div className="bg-slate-50 px-6 py-3 border-b border-slate-200 flex items-center justify-between text-xs font-semibold">
              <div className={`flex items-center gap-1.5 ${step === 'details' ? 'text-[#006967]' : 'text-slate-400'}`}>
                <span className="w-5 h-5 rounded-full bg-[#006967] text-white flex items-center justify-center text-[10px] font-bold">1</span>
                <span>Contact & Delivery</span>
              </div>
              <div className="w-8 h-px bg-slate-300" />
              <div className={`flex items-center gap-1.5 ${step === 'payment' ? 'text-[#006967]' : 'text-slate-400'}`}>
                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${step === 'payment' ? 'bg-[#006967] text-white' : 'bg-slate-200 text-slate-600'}`}>2</span>
                <span>Payment</span>
              </div>
            </div>
          )}

          {/* Content */}
          <div className="p-6">
            {step === 'details' && (
              <form onSubmit={handleDetailsSubmit} className="space-y-4">
                <div className="bg-emerald-50 text-emerald-900 p-3 rounded-lg text-xs font-medium border border-emerald-200 flex items-center gap-2">
                  <Store className="w-4 h-4 text-[#006967] shrink-0" />
                  <span>
                    Fulfilling via: <strong>{selectedStore.name}</strong> ({deliveryMethod === 'collect' ? 'Click & Collect' : 'Local Dispatch'})
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">First Name</label>
                    <input
                      type="text"
                      required
                      value={formData.firstName}
                      onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                      className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg p-2.5 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#006967]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Last Name</label>
                    <input
                      type="text"
                      required
                      value={formData.lastName}
                      onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                      className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg p-2.5 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#006967]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Email Address</label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg p-2.5 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#006967]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Mobile Phone</label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg p-2.5 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#006967]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Address / Street</label>
                  <input
                    type="text"
                    required
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg p-2.5 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#006967]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">UK Postcode</label>
                    <input
                      type="text"
                      required
                      value={formData.postcode}
                      onChange={(e) => setFormData({ ...formData, postcode: e.target.value })}
                      className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg p-2.5 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#006967]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Country</label>
                    <input
                      type="text"
                      disabled
                      value="United Kingdom"
                      className="w-full text-xs bg-slate-100 border border-slate-300 rounded-lg p-2.5 text-slate-500 cursor-not-allowed"
                    />
                  </div>
                </div>

                <div className="pt-4 flex items-center justify-between border-t border-slate-200">
                  <div className="text-xs text-slate-500">
                    Order Total: <strong className="text-sm font-black text-slate-900">£{grandTotal.toFixed(2)}</strong>
                  </div>
                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-[#FFDD00] text-slate-950 font-black text-xs sm:text-sm rounded-lg hover:bg-yellow-400 active:scale-95 transition-all shadow-sm flex items-center gap-1.5"
                  >
                    <span>Continue to Payment</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </form>
            )}

            {step === 'payment' && (
              <form onSubmit={handlePlaceOrder} className="space-y-4">
                <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  Select Payment Method
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, paymentMethod: 'card' })}
                    className={`p-3 rounded-xl border text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-all ${
                      formData.paymentMethod === 'card'
                        ? 'border-[#006967] bg-emerald-50/50 text-[#006967] ring-1 ring-[#006967]'
                        : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <CreditCard className="w-5 h-5" />
                    <span>Debit / Credit</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, paymentMethod: 'applepay' })}
                    className={`p-3 rounded-xl border text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-all ${
                      formData.paymentMethod === 'applepay'
                        ? 'border-[#006967] bg-emerald-50/50 text-[#006967] ring-1 ring-[#006967]'
                        : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span className="text-base font-black"> Pay</span>
                    <span>Apple Pay</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, paymentMethod: 'collection' })}
                    className={`p-3 rounded-xl border text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-all ${
                      formData.paymentMethod === 'collection'
                        ? 'border-[#006967] bg-emerald-50/50 text-[#006967] ring-1 ring-[#006967]'
                        : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <Store className="w-5 h-5" />
                    <span>Pay in Store</span>
                  </button>
                </div>

                {formData.paymentMethod === 'card' && (
                  <div className="space-y-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Card Number</label>
                      <input
                        type="text"
                        value={formData.cardNumber}
                        onChange={(e) => setFormData({ ...formData, cardNumber: e.target.value })}
                        className="w-full text-xs bg-white border border-slate-300 rounded-lg p-2.5 font-mono"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Expiry Date</label>
                        <input
                          type="text"
                          value={formData.cardExpiry}
                          onChange={(e) => setFormData({ ...formData, cardExpiry: e.target.value })}
                          className="w-full text-xs bg-white border border-slate-300 rounded-lg p-2.5 font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">CVC / CVV</label>
                        <input
                          type="text"
                          value={formData.cardCvc}
                          onChange={(e) => setFormData({ ...formData, cardCvc: e.target.value })}
                          className="w-full text-xs bg-white border border-slate-300 rounded-lg p-2.5 font-mono"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Final Order Review Summary */}
                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1.5 text-xs">
                  <div className="flex justify-between text-slate-600">
                    <span>Items Total ({cart.reduce((s, i) => s + i.quantity, 0)})</span>
                    <span className="font-bold tabular-nums">£{subtotal.toFixed(2)}</span>
                  </div>
                  {discountAmount > 0 && (
                    <div className="flex justify-between text-emerald-700 font-semibold">
                      <span>Discount ({appliedCoupon})</span>
                      <span className="tabular-nums">-£{discountAmount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-slate-600">
                    <span>Delivery ({deliveryMethod === 'collect' ? 'Click & Collect' : 'Home Delivery'})</span>
                    <span className="font-bold tabular-nums">
                      {deliveryFee === 0 ? 'FREE' : `£${deliveryFee.toFixed(2)}`}
                    </span>
                  </div>
                  <div className="flex justify-between text-base font-black text-slate-950 pt-2 border-t border-slate-200">
                    <span>Total Amount</span>
                    <span className="tabular-nums text-emerald-900">£{grandTotal.toFixed(2)}</span>
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setStep('details')}
                    className="text-xs font-semibold text-slate-600 hover:text-slate-900"
                  >
                    ← Back to Details
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-3 bg-[#FFDD00] text-slate-950 font-black text-sm rounded-lg hover:bg-yellow-400 active:scale-95 transition-all shadow-md flex items-center gap-2 cursor-pointer"
                  >
                    <span>Place Order · £{grandTotal.toFixed(2)}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </form>
            )}

            {step === 'confirmed' && (
              <div className="text-center py-4 space-y-4">
                <div className="w-16 h-16 bg-emerald-100 text-[#006967] rounded-full flex items-center justify-center mx-auto shadow-inner">
                  <CheckCircle2 className="w-10 h-10" />
                </div>

                <div>
                  <h4 className="text-xl font-black text-slate-900">Thank You for Your Order!</h4>
                  <p className="text-xs text-slate-500 mt-1">
                    Order confirmation email has been sent to <strong>{formData.email}</strong>
                  </p>
                </div>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-left text-xs space-y-2 max-w-md mx-auto">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Order Reference:</span>
                    <strong className="font-mono text-slate-900 font-bold">{orderNumber}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Collection Point:</span>
                    <strong className="text-slate-900">{selectedStore.name}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Estimated Ready Time:</span>
                    <strong className="text-emerald-700 font-bold">Today by 3:30 PM</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Total Paid:</span>
                    <strong className="text-slate-900 font-bold">£{grandTotal.toFixed(2)}</strong>
                  </div>
                </div>

                <div className="pt-2 flex flex-col sm:flex-row gap-2 justify-center">
                  <button
                    onClick={handleClose}
                    className="px-6 py-2.5 bg-[#006967] text-white font-bold text-xs rounded-lg hover:bg-[#005250] transition-colors"
                  >
                    Continue Shopping
                  </button>
                </div>
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
}
