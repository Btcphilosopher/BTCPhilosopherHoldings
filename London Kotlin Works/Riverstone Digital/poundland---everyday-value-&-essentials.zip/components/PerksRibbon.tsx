'use client';

import React from 'react';
import { Tag, Store, MousePointerClick, Leaf } from 'lucide-react';
import { useStore } from '@/context/StoreContext';

export default function PerksRibbon() {
  const { setIsStoreLocatorOpen } = useStore();

  const perks = [
    {
      icon: Tag,
      title: 'Amazing value',
      subtitle: 'across the store',
      action: null
    },
    {
      icon: Store,
      title: '700+ stores UK-wide',
      subtitle: 'Find your nearest',
      action: () => setIsStoreLocatorOpen(true)
    },
    {
      icon: MousePointerClick,
      title: 'Click & Collect',
      subtitle: 'Order online, collect in store',
      action: () => setIsStoreLocatorOpen(true)
    },
    {
      icon: Leaf,
      title: 'Bigger value, greener choices',
      subtitle: 'More recycled & sustainable products',
      action: null
    }
  ];

  return (
    <section className="bg-white border-b border-slate-200 py-3.5 sm:py-5">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 divide-y md:divide-y-0 md:divide-x divide-slate-100">
          {perks.map((perk, idx) => {
            const Icon = perk.icon;
            const isClickable = !!perk.action;

            return (
              <div
                key={idx}
                onClick={perk.action ? perk.action : undefined}
                className={`flex items-center gap-3.5 px-3 py-2.5 sm:px-4 sm:py-2 transition-colors ${
                  isClickable 
                    ? 'cursor-pointer hover:bg-slate-50 group rounded-lg' 
                    : ''
                }`}
              >
                <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-emerald-50 text-[#006967] flex items-center justify-center shrink-0 border border-emerald-100 group-hover:scale-105 group-hover:bg-[#006967] group-hover:text-white transition-all">
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-slate-900 leading-snug group-hover:text-[#006967] transition-colors">
                    {perk.title}
                  </h4>
                  <p className="text-[11px] sm:text-xs text-slate-500 font-medium">
                    {perk.subtitle}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
