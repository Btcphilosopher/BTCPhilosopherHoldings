'use client';

import React, { useMemo } from 'react';
import Image from 'next/image';
import { 
  Heart, 
  Star, 
  ShoppingBasket, 
  Eye, 
  SlidersHorizontal, 
  Check, 
  Plus, 
  Minus,
  Sparkles,
  ArrowUpDown
} from 'lucide-react';
import { useStore } from '@/context/StoreContext';
import { PRODUCTS, Product } from '@/data/products';

export default function ProductCatalog() {
  const { 
    selectedCategory, 
    setSelectedCategory,
    searchQuery,
    setSearchQuery,
    priceFilter,
    setPriceFilter,
    sortBy,
    setSortBy,
    addToCart,
    cart,
    updateQuantity,
    toggleWishlist,
    isWishlisted,
    selectedStore,
    setQuickViewProduct
  } = useStore();

  // Filter and sort products
  const filteredProducts = useMemo(() => {
    let list = [...PRODUCTS];

    // Category filter
    if (selectedCategory && selectedCategory !== 'all') {
      if (selectedCategory === 'essentials') {
        list = list.filter(p => p.category === 'essentials' || p.price === 1.00);
      } else if (selectedCategory === 'offers') {
        list = list.filter(p => p.isOffer || (p.originalPrice && p.originalPrice > p.price));
      } else {
        list = list.filter(p => p.category === selectedCategory);
      }
    }

    // Search filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(p => 
        p.name.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q) ||
        p.categoryLabel.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q)
      );
    }

    // Price filter
    if (priceFilter === 'one-pound') {
      list = list.filter(p => p.price === 1.00);
    } else if (priceFilter === 'under-two') {
      list = list.filter(p => p.price > 1.00 && p.price <= 2.00);
    } else if (priceFilter === 'mega-value') {
      list = list.filter(p => p.price > 2.00);
    }

    // Sorting
    if (sortBy === 'price-asc') {
      list.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-desc') {
      list.sort((a, b) => b.price - a.price);
    } else if (sortBy === 'rating') {
      list.sort((a, b) => b.rating - a.rating);
    }

    return list;
  }, [selectedCategory, searchQuery, priceFilter, sortBy]);

  const categoryTitle = useMemo(() => {
    switch (selectedCategory) {
      case 'essentials': return '£1 Essentials Store';
      case 'food': return 'Food & Drink Groceries';
      case 'beauty': return 'Health & Beauty';
      case 'home': return 'Home & Living Essentials';
      case 'cleaning': return 'Cleaning & Laundry';
      case 'party': return 'Party & Celebrations';
      case 'seasonal': return 'Seasonal Savings';
      case 'offers': return 'Special Offers & Multi-buys';
      default: return 'Featured Poundland Essentials';
    }
  }, [selectedCategory]);

  return (
    <section id="product-catalog" className="py-8 sm:py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        
        {/* Header & Controls */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-slate-200">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-[#006967] uppercase tracking-wider mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Great British Value</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              {searchQuery ? `Search Results for "${searchQuery}"` : categoryTitle}
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              Showing <strong className="text-slate-900 font-semibold">{filteredProducts.length}</strong> products
              {selectedStore && ` · In stock for Click & Collect at ${selectedStore.name}`}
            </p>
          </div>

          {/* Filtering and Sorting Row */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            {/* Price Filter Pills */}
            <div className="flex items-center bg-slate-100 p-1 rounded-lg text-xs font-medium">
              <button
                onClick={() => setPriceFilter('all')}
                className={`px-2.5 py-1 rounded-md transition-colors ${
                  priceFilter === 'all'
                    ? 'bg-white text-slate-900 font-bold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All Prices
              </button>
              <button
                onClick={() => setPriceFilter('one-pound')}
                className={`px-2.5 py-1 rounded-md transition-colors ${
                  priceFilter === 'one-pound'
                    ? 'bg-[#FFDD00] text-slate-950 font-bold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                £1 Only
              </button>
              <button
                onClick={() => setPriceFilter('under-two')}
                className={`px-2.5 py-1 rounded-md transition-colors ${
                  priceFilter === 'under-two'
                    ? 'bg-white text-slate-900 font-bold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                £1 - £2
              </button>
              <button
                onClick={() => setPriceFilter('mega-value')}
                className={`px-2.5 py-1 rounded-md transition-colors ${
                  priceFilter === 'mega-value'
                    ? 'bg-white text-slate-900 font-bold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                £2+ Mega Value
              </button>
            </div>

            {/* Sort Dropdown */}
            <div className="relative">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="appearance-none bg-slate-100 border border-slate-200 text-slate-800 text-xs font-semibold rounded-lg pl-3 pr-8 py-2 focus:outline-none focus:ring-2 focus:ring-[#006967]/20 cursor-pointer"
              >
                <option value="featured">Featured First</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="rating">Top Customer Rated</option>
              </select>
              <ArrowUpDown className="w-3.5 h-3.5 text-slate-500 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Product Cards Grid */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6 pt-6">
            {filteredProducts.map((product) => {
              const inCartItem = cart.find(item => item.product.id === product.id);
              const isSaved = isWishlisted(product.id);

              return (
                <div
                  key={product.id}
                  className="group bg-white rounded-xl border border-slate-200 hover:border-[#006967]/40 shadow-xs hover:shadow-lg transition-all duration-200 flex flex-col overflow-hidden relative"
                >
                  {/* Top Badges & Wishlist Action */}
                  <div className="relative aspect-square bg-slate-50 overflow-hidden">
                    {/* Badge */}
                    {product.badge && (
                      <div className="absolute top-2.5 left-2.5 z-10">
                        <span className="bg-[#006967] text-white text-[10px] sm:text-xs font-bold px-2 py-0.5 rounded-sm shadow-xs uppercase tracking-wide">
                          {product.badge}
                        </span>
                      </div>
                    )}

                    {/* Wishlist Button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleWishlist(product.id);
                      }}
                      aria-label="Save to wishlist"
                      className={`absolute top-2.5 right-2.5 z-10 w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                        isSaved
                          ? 'bg-red-50 text-red-600 shadow-sm'
                          : 'bg-white/80 hover:bg-white text-slate-600 hover:text-red-500 shadow-xs'
                      }`}
                    >
                      <Heart className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
                    </button>

                    {/* Image with zoom on hover */}
                    <div 
                      onClick={() => setQuickViewProduct(product)}
                      className="w-full h-full p-4 flex items-center justify-center cursor-pointer"
                    >
                      <Image
                        src={product.image}
                        alt={product.name}
                        width={240}
                        height={240}
                        className="object-contain max-h-full group-hover:scale-105 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                    </div>

                    {/* Quick View Hover Pill */}
                    <button
                      onClick={() => setQuickViewProduct(product)}
                      className="absolute bottom-2.5 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-slate-900/80 hover:bg-slate-950 text-white text-xs font-medium px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-md backdrop-blur-xs cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Quick View</span>
                    </button>
                  </div>

                  {/* Product Details */}
                  <div className="p-3.5 sm:p-4 flex flex-col flex-1">
                    {/* Brand & Unit */}
                    <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                      <span className="font-semibold text-slate-600">{product.brand}</span>
                      <span className="text-slate-400 font-medium">{product.unit}</span>
                    </div>

                    {/* Title */}
                    <h3 
                      onClick={() => setQuickViewProduct(product)}
                      className="text-xs sm:text-sm font-bold text-slate-900 group-hover:text-[#006967] line-clamp-2 leading-snug cursor-pointer transition-colors mb-2 flex-1"
                    >
                      {product.name}
                    </h3>

                    {/* Rating */}
                    <div className="flex items-center gap-1 mb-3">
                      <div className="flex items-center text-amber-400">
                        <Star className="w-3.5 h-3.5 fill-current" />
                      </div>
                      <span className="text-xs font-bold text-slate-700">{product.rating}</span>
                      <span className="text-[11px] text-slate-400">({product.reviewsCount})</span>
                    </div>

                    {/* Price and Unit Cost */}
                    <div className="flex items-baseline justify-between mb-3 pt-1 border-t border-slate-100">
                      <div>
                        <div className="flex items-baseline gap-1.5">
                          <span className="text-lg sm:text-xl font-black text-slate-900 tabular-nums">
                            £{product.price.toFixed(2)}
                          </span>
                          {product.originalPrice && (
                            <span className="text-xs text-slate-400 line-through tabular-nums">
                              £{product.originalPrice.toFixed(2)}
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-500 font-medium">
                          {product.pricePerUnit}
                        </span>
                      </div>
                    </div>

                    {/* Add to Basket Action */}
                    {inCartItem ? (
                      <div className="flex items-center justify-between bg-emerald-50 rounded-lg p-1 border border-emerald-200">
                        <button
                          onClick={() => updateQuantity(product.id, inCartItem.quantity - 1)}
                          className="w-7 h-7 bg-white rounded-md flex items-center justify-center text-emerald-800 hover:bg-emerald-100 font-bold shadow-xs active:scale-95 transition-all"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="text-xs font-bold text-emerald-950 tabular-nums">
                          {inCartItem.quantity} in Basket
                        </span>
                        <button
                          onClick={() => updateQuantity(product.id, inCartItem.quantity + 1)}
                          className="w-7 h-7 bg-[#FFDD00] rounded-md flex items-center justify-center text-slate-950 hover:bg-yellow-400 font-bold shadow-xs active:scale-95 transition-all"
                          aria-label="Increase quantity"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => addToCart(product, 1)}
                        className="w-full py-2 sm:py-2.5 px-3 bg-[#FFDD00] hover:bg-yellow-400 active:scale-98 text-slate-950 font-bold text-xs sm:text-sm rounded-lg shadow-xs hover:shadow-sm flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                      >
                        <ShoppingBasket className="w-4 h-4" />
                        <span>Add to Basket</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="py-16 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 mt-6">
            <ShoppingBasket className="w-12 h-12 text-slate-400 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-slate-800">No matching products found</h3>
            <p className="text-sm text-slate-500 max-w-md mx-auto mt-1 mb-4">
              We couldn&apos;t find any items matching your current filters. Try resetting to view all everyday £1 essentials.
            </p>
            <button
              onClick={() => {
                setSelectedCategory('all');
                setSearchQuery('');
                setPriceFilter('all');
              }}
              className="px-5 py-2.5 bg-[#006967] text-white font-bold text-xs sm:text-sm rounded-lg hover:bg-[#005250] transition-colors cursor-pointer"
            >
              Reset All Filters
            </button>
          </div>
        )}

      </div>
    </section>
  );
}
