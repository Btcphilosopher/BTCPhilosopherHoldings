'use client';

import React, { useState, useRef, useEffect } from 'react';
import Image from 'next/image';
import { 
  Search, 
  MapPin, 
  User, 
  ShoppingBasket, 
  Menu, 
  X, 
  ChevronRight, 
  Heart,
  Tag,
  Sparkles,
  Percent
} from 'lucide-react';
import { useStore } from '@/context/StoreContext';
import { PRODUCTS } from '@/data/products';

export const CATEGORIES = [
  { id: 'all', label: 'All Products' },
  { id: 'essentials', label: '£1 Essentials' },
  { id: 'food', label: 'Food & Drink' },
  { id: 'beauty', label: 'Health & Beauty' },
  { id: 'home', label: 'Home & Living' },
  { id: 'cleaning', label: 'Cleaning' },
  { id: 'party', label: 'Party' },
  { id: 'seasonal', label: 'Seasonal' },
  { id: 'offers', label: 'Offers', isHighlighted: true }
];

export default function Navbar() {
  const { 
    totalItems, 
    subtotal, 
    selectedStore, 
    setIsCartOpen, 
    setIsStoreLocatorOpen, 
    setIsAccountOpen,
    selectedCategory,
    setSelectedCategory,
    searchQuery,
    setSearchQuery,
    wishlist,
    addToCart
  } = useStore();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchFocused, setSearchFocused] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Close search suggestions on click outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
        setSearchFocused(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Filter products for search autocomplete preview
  const searchResults = searchQuery.trim().length > 1
    ? PRODUCTS.filter(p => 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.categoryLabel.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 5)
    : [];

  const handleSelectCategory = (catId: string) => {
    setSelectedCategory(catId);
    setMobileMenuOpen(false);
    // Smooth scroll to catalog
    const el = document.getElementById('product-catalog');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white shadow-xs">
      {/* Top Promotional Announcement */}
      <div className="bg-[#005953] text-white text-xs py-1.5 px-4 font-medium">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2 overflow-hidden text-ellipsis whitespace-nowrap">
            <span className="bg-[#FFDD00] text-emerald-950 font-bold px-1.5 py-0.5 rounded-sm text-[10px] tracking-wide uppercase">
              Free Delivery
            </span>
            <span className="text-emerald-50">
              Free Click & Collect to 700+ stores on orders over £20!
            </span>
          </div>
          <div className="hidden md:flex items-center gap-4 text-emerald-100 text-xs shrink-0">
            <button 
              onClick={() => setIsStoreLocatorOpen(true)}
              className="hover:text-white transition-colors flex items-center gap-1 cursor-pointer"
            >
              <MapPin className="w-3.5 h-3.5 text-[#FFDD00]" />
              <span>Nearest Store: <strong className="text-white underline">{selectedStore.name}</strong></span>
            </button>
            <span className="text-emerald-400">|</span>
            <span className="text-emerald-200">Help & FAQs</span>
          </div>
        </div>
      </div>

      {/* Main Brand & Action Header */}
      <div className="bg-[#006967] text-white px-4 py-3 sm:py-3.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-3 md:gap-6">
          
          {/* Brand Logo */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-1.5 text-white hover:bg-white/10 rounded-md cursor-pointer transition-colors"
              aria-label="Open mobile menu"
            >
              <Menu className="w-6 h-6" />
            </button>

            <button 
              onClick={() => handleSelectCategory('all')} 
              className="flex items-center gap-2 group cursor-pointer focus-visible:outline-none"
            >
              <div className="relative flex items-center">
                {/* Fallback & Custom Poundland Wordmark */}
                <div className="flex items-center text-2xl sm:text-3xl font-black tracking-tight text-white select-none">
                  <span className="text-white drop-shadow-sm font-sans tracking-tight">Pound</span>
                  <span className="text-[#FFDD00] font-sans tracking-tight">land</span>
                  <span className="inline-block w-2.5 h-2.5 rounded-full bg-[#FFDD00] ml-1 mb-3 animate-pulse"></span>
                </div>
              </div>
            </button>
          </div>

          {/* Search Bar with live autocomplete */}
          <div ref={searchContainerRef} className="relative flex-1 max-w-2xl mx-1 sm:mx-4">
            <div className="relative">
              <input
                type="text"
                placeholder="Search products, brands and more..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setSearchFocused(true);
                }}
                onFocus={() => setSearchFocused(true)}
                className="w-full bg-white text-slate-800 placeholder-slate-500 rounded-full pl-11 pr-10 py-2 sm:py-2.5 text-sm sm:text-base border border-transparent focus:border-[#FFDD00] focus:outline-none focus:ring-2 focus:ring-[#FFDD00]/30 shadow-inner transition-all"
              />
              <Search className="w-5 h-5 text-slate-500 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Live Autocomplete Dropdown */}
            {searchFocused && (
              <div className="absolute left-0 right-0 top-full mt-2 bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden z-50 text-slate-800 animate-in fade-in slide-in-from-top-1 duration-150">
                {searchResults.length > 0 ? (
                  <div>
                    <div className="px-4 py-2 bg-slate-50 border-b border-slate-100 flex items-center justify-between text-xs font-semibold text-slate-500 uppercase tracking-wider">
                      <span>Matching Products ({searchResults.length})</span>
                      <span className="text-[#006967] font-bold">Poundland Value</span>
                    </div>
                    <div className="divide-y divide-slate-100 max-h-80 overflow-y-auto">
                      {searchResults.map((product) => (
                        <div
                          key={product.id}
                          onClick={() => {
                            setSearchFocused(false);
                            const el = document.getElementById('product-catalog');
                            if (el) el.scrollIntoView({ behavior: 'smooth' });
                          }}
                          className="px-4 py-2.5 flex items-center justify-between hover:bg-emerald-50/60 transition-colors cursor-pointer group"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-md bg-slate-100 overflow-hidden flex items-center justify-center shrink-0 border border-slate-200">
                              <Image
                                src={product.image}
                                alt={product.name}
                                width={40}
                                height={40}
                                className="object-cover w-full h-full"
                                referrerPolicy="no-referrer"
                              />
                            </div>
                            <div>
                              <p className="text-xs font-medium text-slate-500">{product.brand}</p>
                              <p className="text-sm font-semibold text-slate-900 group-hover:text-[#006967] line-clamp-1">
                                {product.name}
                              </p>
                              <span className="text-xs text-slate-500">{product.unit}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-3 shrink-0 ml-3">
                            <span className="text-sm font-bold text-slate-900 tabular-nums">
                              £{product.price.toFixed(2)}
                            </span>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                addToCart(product, 1);
                              }}
                              className="px-2.5 py-1 text-xs font-semibold bg-[#FFDD00] text-emerald-950 rounded-md hover:bg-yellow-400 active:scale-95 transition-all"
                            >
                              + Add
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : searchQuery.trim().length > 1 ? (
                  <div className="p-6 text-center text-slate-500">
                    <p className="text-sm">No items found for &ldquo;{searchQuery}&rdquo;</p>
                    <p className="text-xs text-slate-400 mt-1">Try searching &ldquo;Toilet Tissue&rdquo;, &ldquo;Fairy&rdquo;, or &ldquo;Cadbury&rdquo;</p>
                  </div>
                ) : (
                  <div className="p-4">
                    <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                      Popular Searches
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {['£1 Essentials', 'Fairy Liquid', 'Toilet Roll', 'NIVEA', 'Heinz Beans', 'Balloons'].map((term) => (
                        <button
                          key={term}
                          onClick={() => {
                            setSearchQuery(term);
                          }}
                          className="px-2.5 py-1 bg-slate-100 hover:bg-emerald-50 hover:text-[#006967] text-xs font-medium text-slate-700 rounded-md transition-colors"
                        >
                          {term}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Right Action Icons: Store, Account, Basket */}
          <div className="flex items-center gap-1 sm:gap-3 md:gap-4 shrink-0">
            {/* Find a Store */}
            <button
              onClick={() => setIsStoreLocatorOpen(true)}
              className="flex flex-col items-center justify-center px-2 py-1 text-white hover:text-[#FFDD00] transition-colors cursor-pointer group"
            >
              <MapPin className="w-5 h-5 sm:w-6 sm:h-6 group-hover:scale-110 transition-transform" />
              <span className="hidden sm:inline text-[11px] font-medium mt-0.5 tracking-tight whitespace-nowrap">
                Find a Store
              </span>
            </button>

            {/* My Account */}
            <button
              onClick={() => setIsAccountOpen(true)}
              className="flex flex-col items-center justify-center px-2 py-1 text-white hover:text-[#FFDD00] transition-colors cursor-pointer group"
            >
              <User className="w-5 h-5 sm:w-6 sm:h-6 group-hover:scale-110 transition-transform" />
              <span className="hidden sm:inline text-[11px] font-medium mt-0.5 tracking-tight whitespace-nowrap">
                My Account
              </span>
            </button>

            {/* Shopping Basket */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative flex flex-col items-center justify-center px-2 py-1 text-white hover:text-[#FFDD00] transition-colors cursor-pointer group"
              aria-label={`Shopping basket with ${totalItems} items`}
            >
              <div className="relative">
                <ShoppingBasket className="w-6 h-6 sm:w-7 sm:h-7 group-hover:scale-110 transition-transform" />
                {totalItems > 0 && (
                  <span className="absolute -top-1.5 -right-2 bg-[#FFDD00] text-emerald-950 text-xs font-extrabold rounded-full w-5 h-5 flex items-center justify-center shadow-md animate-in zoom-in-75">
                    {totalItems}
                  </span>
                )}
              </div>
              <span className="hidden sm:inline text-[11px] font-medium mt-0.5 tracking-tight whitespace-nowrap">
                Basket ({totalItems})
              </span>
            </button>
          </div>

        </div>
      </div>

      {/* Category Navigation Bar (Desktop & Tablet) */}
      <nav className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between gap-1 overflow-x-auto no-scrollbar py-2">
            <div className="flex items-center gap-1 sm:gap-2">
              {CATEGORIES.map((cat) => {
                const isActive = selectedCategory === cat.id;

                if (cat.isHighlighted) {
                  return (
                    <button
                      key={cat.id}
                      onClick={() => handleSelectCategory(cat.id)}
                      className={`px-4 py-1.5 rounded-full text-xs sm:text-sm font-bold transition-all shadow-xs shrink-0 cursor-pointer ${
                        isActive
                          ? 'bg-amber-400 text-slate-950 ring-2 ring-amber-500'
                          : 'bg-[#FFDD00] hover:bg-yellow-400 text-slate-950'
                      }`}
                    >
                      {cat.label}
                    </button>
                  );
                }

                return (
                  <button
                    key={cat.id}
                    onClick={() => handleSelectCategory(cat.id)}
                    className={`px-3 py-1.5 rounded-md text-xs sm:text-sm font-semibold transition-colors shrink-0 whitespace-nowrap cursor-pointer ${
                      isActive
                        ? 'text-[#006967] bg-emerald-50 font-bold border-b-2 border-[#006967]'
                        : 'text-slate-700 hover:text-[#006967] hover:bg-slate-50'
                    }`}
                  >
                    {cat.label}
                  </button>
                );
              })}
            </div>

            {/* Quick trust tag on desktop */}
            <div className="hidden xl:flex items-center gap-2 text-xs text-slate-500 font-medium shrink-0">
              <span className="flex items-center gap-1 text-emerald-700 font-semibold">
                <Tag className="w-3.5 h-3.5" /> 1000s of £1 Essentials
              </span>
              <span>·</span>
              <span>Price Checked Daily</span>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          {/* Backdrop */}
          <div 
            className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
            onClick={() => setMobileMenuOpen(false)}
          />

          <div className="fixed inset-y-0 left-0 w-full max-w-xs bg-white shadow-2xl flex flex-col z-10 animate-in slide-in-from-left duration-200">
            {/* Header */}
            <div className="p-4 bg-[#006967] text-white flex items-center justify-between">
              <div className="text-xl font-black">
                <span>Pound</span>
                <span className="text-[#FFDD00]">land</span>
              </div>
              <button 
                onClick={() => setMobileMenuOpen(false)}
                className="p-1 rounded-md text-white hover:bg-white/10"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Store & Quick Actions */}
            <div className="p-3 bg-slate-50 border-b border-slate-200 text-xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-slate-700 font-medium">
                  <MapPin className="w-4 h-4 text-[#006967]" />
                  <span>My Store: <strong>{selectedStore.name}</strong></span>
                </div>
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    setIsStoreLocatorOpen(true);
                  }}
                  className="text-xs font-bold text-[#006967] hover:underline"
                >
                  Change
                </button>
              </div>
            </div>

            {/* Category Links */}
            <div className="flex-1 overflow-y-auto p-4 space-y-1">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                Browse Departments
              </div>
              {CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => handleSelectCategory(cat.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-semibold transition-colors ${
                    cat.isHighlighted
                      ? 'bg-[#FFDD00] text-emerald-950 font-bold'
                      : selectedCategory === cat.id
                      ? 'bg-emerald-50 text-[#006967] font-bold'
                      : 'text-slate-800 hover:bg-slate-100'
                  }`}
                >
                  <span>{cat.label}</span>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </button>
              ))}

              <div className="pt-4 border-t border-slate-200 mt-4 space-y-2">
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    setIsAccountOpen(true);
                  }}
                  className="w-full flex items-center gap-3 px-3 py-2 text-sm text-slate-700 font-medium hover:bg-slate-100 rounded-lg"
                >
                  <User className="w-4 h-4 text-slate-500" />
                  <span>My Account & Orders</span>
                </button>
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    setIsStoreLocatorOpen(true);
                  }}
                  className="w-full flex items-center gap-3 px-3 py-2 text-sm text-slate-700 font-medium hover:bg-slate-100 rounded-lg"
                >
                  <MapPin className="w-4 h-4 text-slate-500" />
                  <span>Store Finder (700+ Stores)</span>
                </button>
              </div>
            </div>

            {/* Footer in Drawer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 text-center">
              Poundland Online · Great Value Everyday
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
