'use client';

import React from 'react';
import { Home, Grid, MapPin, Heart, ShoppingBasket } from 'lucide-react';
import { useStore } from '@/context/StoreContext';

export default function MobileQuickBar() {
  const { 
    totalItems, 
    subtotal, 
    setIsCartOpen, 
    setIsStoreLocatorOpen, 
    setIsAccountOpen, 
    wishlist,
    setSelectedCategory 
  } = useStore();

  const handleHome = () => {
    setSelectedCategory('all');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCategories = () => {
    const el = document.getElementById('product-catalog');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <nav className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 py-1.5 shadow-lg">
      <div className="flex items-center justify-around text-slate-600">
        <button
          onClick={handleHome}
          className="flex flex-col items-center justify-center p-1 hover:text-[#006967] transition-colors"
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] font-semibold mt-0.5">Home</span>
        </button>

        <button
          onClick={handleCategories}
          className="flex flex-col items-center justify-center p-1 hover:text-[#006967] transition-colors"
        >
          <Grid className="w-5 h-5" />
          <span className="text-[10px] font-semibold mt-0.5">Shop</span>
        </button>

        <button
          onClick={() => setIsStoreLocatorOpen(true)}
          className="flex flex-col items-center justify-center p-1 hover:text-[#006967] transition-colors"
        >
          <MapPin className="w-5 h-5" />
          <span className="text-[10px] font-semibold mt-0.5">Stores</span>
        </button>

        <button
          onClick={() => setIsAccountOpen(true)}
          className="relative flex flex-col items-center justify-center p-1 hover:text-[#006967] transition-colors"
        >
          <Heart className="w-5 h-5" />
          {wishlist.length > 0 && (
            <span className="absolute top-0 right-2 w-2 h-2 rounded-full bg-red-500" />
          )}
          <span className="text-[10px] font-semibold mt-0.5">Saved</span>
        </button>

        <button
          onClick={() => setIsCartOpen(true)}
          className="relative flex flex-col items-center justify-center p-1 text-[#006967] font-bold"
        >
          <div className="relative">
            <ShoppingBasket className="w-5 h-5" />
            {totalItems > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-[#FFDD00] text-slate-950 text-[10px] font-extrabold rounded-full w-4 h-4 flex items-center justify-center">
                {totalItems}
              </span>
            )}
          </div>
          <span className="text-[10px] font-black mt-0.5">
            £{subtotal.toFixed(2)}
          </span>
        </button>
      </div>
    </nav>
  );
}
