'use client';

import React from 'react';
import Image from 'next/image';
import { ChevronRight } from 'lucide-react';
import { useStore } from '@/context/StoreContext';

interface CategoryCard {
  id: string;
  name: string;
  image: string;
  accentColor: string;
  itemCount: string;
}

const CATEGORY_CARDS: CategoryCard[] = [
  {
    id: 'essentials',
    name: '£1 Essentials',
    image: '/categories/cat_essentials.png',
    accentColor: 'from-amber-400/20 to-amber-500/10',
    itemCount: '500+ items'
  },
  {
    id: 'food',
    name: 'Food & Drink',
    image: '/categories/cat_food.png',
    accentColor: 'from-orange-400/20 to-orange-500/10',
    itemCount: '350+ items'
  },
  {
    id: 'beauty',
    name: 'Health & Beauty',
    image: '/categories/cat_beauty.png',
    accentColor: 'from-pink-400/20 to-rose-500/10',
    itemCount: '400+ items'
  },
  {
    id: 'home',
    name: 'Home & Living',
    image: '/categories/cat_home.png',
    accentColor: 'from-stone-400/20 to-stone-500/10',
    itemCount: '250+ items'
  },
  {
    id: 'party',
    name: 'Party',
    image: '/categories/cat_party.png',
    accentColor: 'from-sky-400/20 to-blue-500/10',
    itemCount: '180+ items'
  },
  {
    id: 'seasonal',
    name: 'Seasonal',
    image: '/categories/cat_seasonal.png',
    accentColor: 'from-red-400/20 to-emerald-500/10',
    itemCount: '220+ items'
  }
];

export default function CategoryShowcase() {
  const { setSelectedCategory, selectedCategory } = useStore();

  const handleCategoryClick = (categoryId: string) => {
    setSelectedCategory(categoryId);
    const catalog = document.getElementById('product-catalog');
    if (catalog) {
      catalog.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="py-8 sm:py-10 bg-slate-50/70 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4">
        {/* Section Header */}
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Shop by Category
            </h2>
            <p className="text-xs sm:text-sm text-slate-500">
              Big brands and household staples at everyday low prices
            </p>
          </div>
          <button
            onClick={() => handleCategoryClick('all')}
            className="text-xs sm:text-sm font-bold text-[#006967] hover:text-emerald-800 flex items-center gap-1 cursor-pointer transition-colors"
          >
            <span>View All Departments</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* 6 Category Cards Grid (Matching screenshot layout) */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
          {CATEGORY_CARDS.map((cat) => {
            const isSelected = selectedCategory === cat.id;

            return (
              <div
                key={cat.id}
                onClick={() => handleCategoryClick(cat.id)}
                className={`group bg-white rounded-xl overflow-hidden border transition-all duration-200 cursor-pointer flex flex-col shadow-xs hover:shadow-md hover:-translate-y-1 ${
                  isSelected 
                    ? 'border-[#006967] ring-2 ring-[#006967]/30' 
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                {/* Image Container */}
                <div className="relative aspect-[16/10] w-full bg-slate-100 overflow-hidden">
                  <Image
                    src={cat.image}
                    alt={cat.name}
                    fill
                    className="object-cover object-center group-hover:scale-105 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>

                {/* Card Title Label (Matching screenshot: e.g. "£1 Essentials >") */}
                <div className="p-3 bg-white flex items-center justify-between border-t border-slate-100">
                  <div>
                    <h3 className="text-xs sm:text-sm font-bold text-slate-900 group-hover:text-[#006967] transition-colors flex items-center gap-0.5">
                      <span>{cat.name}</span>
                      <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-[#006967] group-hover:translate-x-0.5 transition-all" />
                    </h3>
                    <span className="text-[10px] text-slate-400 font-medium">
                      {cat.itemCount}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
