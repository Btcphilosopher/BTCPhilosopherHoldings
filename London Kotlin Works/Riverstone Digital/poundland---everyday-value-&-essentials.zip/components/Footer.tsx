'use client';

import React, { useState } from 'react';
import { 
  Store, 
  Truck, 
  ShieldCheck, 
  Mail, 
  ArrowRight, 
  MapPin, 
  Heart,
  Sparkles
} from 'lucide-react';
import { useStore } from '@/context/StoreContext';

export default function Footer() {
  const [email, setEmail] = useState('');
  const { showToast, setIsStoreLocatorOpen } = useStore();

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      showToast('Please enter a valid email address', 'info');
      return;
    }
    showToast('Subscribed! Welcome to Poundland VIP Club 🎁', 'success');
    setEmail('');
  };

  return (
    <footer className="bg-slate-900 text-slate-300 text-xs">
      
      {/* Newsletter Strip */}
      <div className="bg-[#005953] text-white py-8 px-4 border-b border-emerald-900">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2 text-[#FFDD00] font-black text-xs uppercase tracking-wider mb-1">
              <Sparkles className="w-4 h-4" />
              <span>Join the Poundland Rewards Club</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Get exclusive £1 vouchers and member-only deals
            </h3>
            <p className="text-xs sm:text-sm text-emerald-100 mt-0.5">
              Be the first to hear about new arrivals, seasonal ranges, and weekly multi-buys.
            </p>
          </div>

          <form onSubmit={handleSubscribe} className="w-full md:w-auto flex-1 max-w-md flex gap-2">
            <input
              type="email"
              required
              placeholder="Enter your email address..."
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="flex-1 bg-white text-slate-800 text-xs sm:text-sm px-4 py-2.5 rounded-lg border-0 focus:outline-none focus:ring-2 focus:ring-[#FFDD00] placeholder:text-slate-400"
            />
            <button
              type="submit"
              className="px-5 py-2.5 bg-[#FFDD00] hover:bg-yellow-400 active:scale-95 text-slate-950 font-black text-xs sm:text-sm rounded-lg transition-all shadow-md flex items-center gap-1.5 shrink-0 cursor-pointer"
            >
              <span>Join Free</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
          
          {/* Brand Info */}
          <div className="col-span-2 space-y-3">
            <div className="flex items-center text-2xl font-black tracking-tight text-white">
              <span>Pound</span>
              <span className="text-[#FFDD00]">land</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Providing everyday essentials, big household brands, groceries, health & beauty and seasonal treats at unbeatable low British prices since 1990.
            </p>
            <div className="pt-2 flex items-center gap-3 text-slate-400">
              <button
                onClick={() => setIsStoreLocatorOpen(true)}
                className="flex items-center gap-1.5 text-xs text-[#FFDD00] hover:underline cursor-pointer"
              >
                <MapPin className="w-4 h-4" />
                <span>Find Your Local Store (700+ UK Locations)</span>
              </button>
            </div>
          </div>

          {/* Column 1: Customer Care */}
          <div>
            <h4 className="text-xs font-black uppercase tracking-wider text-white mb-3">
              Customer Services
            </h4>
            <ul className="space-y-2 text-slate-400">
              <li><a href="#help" className="hover:text-white transition-colors">Help Centre & FAQs</a></li>
              <li><a href="#track" className="hover:text-white transition-colors">Track My Order</a></li>
              <li><a href="#delivery" className="hover:text-white transition-colors">Click & Collect Info</a></li>
              <li><a href="#returns" className="hover:text-white transition-colors">Returns & Refunds</a></li>
              <li><a href="#contact" className="hover:text-white transition-colors">Contact Customer Care</a></li>
            </ul>
          </div>

          {/* Column 2: Departments */}
          <div>
            <h4 className="text-xs font-black uppercase tracking-wider text-white mb-3">
              Popular Ranges
            </h4>
            <ul className="space-y-2 text-slate-400">
              <li><a href="#catalog" className="hover:text-white transition-colors">£1 Essentials Range</a></li>
              <li><a href="#catalog" className="hover:text-white transition-colors">Big Brand Groceries</a></li>
              <li><a href="#catalog" className="hover:text-white transition-colors">Cleaning & Laundry</a></li>
              <li><a href="#catalog" className="hover:text-white transition-colors">Health & Toiletries</a></li>
              <li><a href="#catalog" className="hover:text-white transition-colors">Seasonal & Celebration</a></li>
            </ul>
          </div>

          {/* Column 3: About Poundland */}
          <div>
            <h4 className="text-xs font-black uppercase tracking-wider text-white mb-3">
              About Poundland
            </h4>
            <ul className="space-y-2 text-slate-400">
              <li><a href="#about" className="hover:text-white transition-colors">About Us</a></li>
              <li><a href="#careers" className="hover:text-white transition-colors">Careers & Jobs</a></li>
              <li><a href="#green" className="hover:text-white transition-colors">Greener Choices Policy</a></li>
              <li><a href="#terms" className="hover:text-white transition-colors">Terms & Conditions</a></li>
              <li><a href="#privacy" className="hover:text-white transition-colors">Privacy & Cookies</a></li>
            </ul>
          </div>

        </div>

        {/* Payment Badges & Bottom Legal Bar */}
        <div className="mt-12 pt-8 border-t border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-slate-500 text-[11px] text-center md:text-left">
            © {new Date().getFullYear()} Poundland Limited. All rights reserved. Registered in England & Wales.
          </p>

          {/* Payment Icons */}
          <div className="flex items-center gap-3 text-slate-400 text-xs font-semibold">
            <span className="text-[10px] uppercase text-slate-500">Secure Payments:</span>
            <span className="px-2 py-1 rounded bg-slate-800 text-slate-300 text-[10px] font-bold">VISA</span>
            <span className="px-2 py-1 rounded bg-slate-800 text-slate-300 text-[10px] font-bold">Mastercard</span>
            <span className="px-2 py-1 rounded bg-slate-800 text-slate-300 text-[10px] font-bold">Apple Pay</span>
            <span className="px-2 py-1 rounded bg-slate-800 text-slate-300 text-[10px] font-bold">PayPal</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
