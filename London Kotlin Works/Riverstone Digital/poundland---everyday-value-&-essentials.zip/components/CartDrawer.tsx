'use client';

import React from 'react';
import Image from 'next/image';
import { 
  X, 
  Trash2, 
  Plus, 
  Minus, 
  ShoppingBasket, 
  ArrowRight, 
  ShieldCheck, 
  Tag, 
  Truck, 
  Store 
} from 'lucide-react';
import { useStore } from '@/context/StoreContext';

export default function CartDrawer() {
  const { 
    isCartOpen, 
    setIsCartOpen,
    cart, 
    removeFromCart, 
    updateQuantity,
    clearCart,
    subtotal,
    deliveryMethod,
    setDeliveryMethod,
    deliveryFee,
    freeCollectThreshold,
    freeShippingProgress,
    couponCode,
    setCouponCode,
    appliedCoupon,
    applyCoupon,
    discountAmount,
    grandTotal,
    selectedStore,
    setIsCheckoutOpen
  } = useStore();

  if (!isCartOpen) return null;

  const amountUntilFree = Math.max(0, freeCollectThreshold - subtotal);

  const handleCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={() => setIsCartOpen(false)}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col">
          
          {/* Header */}
          <div className="p-4 sm:p-5 bg-[#006967] text-white flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingBasket className="w-6 h-6 text-[#FFDD00]" />
              <h2 className="text-lg font-black tracking-tight">
                Your Basket ({cart.reduce((s, i) => s + i.quantity, 0)})
              </h2>
            </div>
            <button
              onClick={() => setIsCartOpen(false)}
              className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Click & Collect Progress Bar */}
          <div className="p-3.5 bg-emerald-50 border-b border-emerald-100">
            <div className="flex items-center justify-between text-xs font-semibold mb-1.5">
              <span className="text-[#006967]">
                {amountUntilFree > 0
                  ? `Add £${amountUntilFree.toFixed(2)} more for FREE Click & Collect`
                  : '🎉 You have qualified for FREE Click & Collect!'}
              </span>
              <span className="text-slate-600 font-bold">{freeShippingProgress}%</span>
            </div>
            <div className="w-full bg-emerald-200/60 rounded-full h-2 overflow-hidden">
              <div 
                className="bg-[#006967] h-2 rounded-full transition-all duration-300"
                style={{ width: `${freeShippingProgress}%` }}
              />
            </div>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-4 divide-y divide-slate-100">
            {cart.length > 0 ? (
              cart.map(({ product, quantity }) => (
                <div key={product.id} className="py-3.5 flex gap-3 group">
                  <div className="w-16 h-16 rounded-lg bg-slate-50 border border-slate-200 overflow-hidden shrink-0 flex items-center justify-center p-1">
                    <Image
                      src={product.image}
                      alt={product.name}
                      width={64}
                      height={64}
                      className="object-contain max-h-full"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <span className="text-[11px] font-semibold text-slate-400 uppercase">
                          {product.brand}
                        </span>
                        <button
                          onClick={() => removeFromCart(product.id)}
                          className="text-slate-400 hover:text-red-500 transition-colors p-0.5"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <h4 className="text-xs sm:text-sm font-bold text-slate-900 line-clamp-1">
                        {product.name}
                      </h4>
                      <p className="text-[11px] text-slate-500">{product.unit}</p>
                    </div>

                    <div className="flex items-center justify-between pt-2">
                      {/* Quantity Controls */}
                      <div className="flex items-center border border-slate-200 rounded-md bg-white">
                        <button
                          onClick={() => updateQuantity(product.id, quantity - 1)}
                          className="w-7 h-7 flex items-center justify-center text-slate-600 hover:bg-slate-100 active:scale-95"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="w-8 text-center text-xs font-bold tabular-nums">
                          {quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(product.id, quantity + 1)}
                          className="w-7 h-7 flex items-center justify-center text-slate-600 hover:bg-slate-100 active:scale-95"
                          aria-label="Increase quantity"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      {/* Line Item Total */}
                      <div className="text-right">
                        <span className="text-sm font-black text-slate-900 tabular-nums">
                          £{(product.price * quantity).toFixed(2)}
                        </span>
                        <p className="text-[10px] text-slate-400">£{product.price.toFixed(2)} each</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
                <ShoppingBasket className="w-16 h-16 stroke-1 text-slate-300 mb-3" />
                <h3 className="text-base font-bold text-slate-700">Your basket is empty</h3>
                <p className="text-xs text-slate-500 max-w-xs mt-1 mb-5">
                  Browse our everyday essentials and big brands from just £1 to get started!
                </p>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="px-6 py-2.5 bg-[#FFDD00] text-slate-950 font-bold text-xs rounded-lg hover:bg-yellow-400 transition-colors shadow-xs"
                >
                  Start Shopping
                </button>
              </div>
            )}
          </div>

          {/* Footer & Checkout Module (Only if cart not empty) */}
          {cart.length > 0 && (
            <div className="p-4 bg-slate-50 border-t border-slate-200 space-y-3">
              
              {/* Delivery Mode Toggle */}
              <div className="grid grid-cols-2 gap-2 p-1 bg-white border border-slate-200 rounded-lg text-xs font-semibold">
                <button
                  onClick={() => setDeliveryMethod('collect')}
                  className={`py-2 px-2 rounded-md flex items-center justify-center gap-1.5 transition-all ${
                    deliveryMethod === 'collect'
                      ? 'bg-[#006967] text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Store className="w-3.5 h-3.5" />
                  <span>Click & Collect</span>
                </button>
                <button
                  onClick={() => setDeliveryMethod('delivery')}
                  className={`py-2 px-2 rounded-md flex items-center justify-center gap-1.5 transition-all ${
                    deliveryMethod === 'delivery'
                      ? 'bg-[#006967] text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Truck className="w-3.5 h-3.5" />
                  <span>Home Delivery</span>
                </button>
              </div>

              {/* Delivery destination hint */}
              <div className="text-[11px] text-slate-500 flex items-center justify-between">
                <span>
                  {deliveryMethod === 'collect' 
                    ? `Collection store: ${selectedStore.name}`
                    : 'Standard UK 2-3 Day Delivery'}
                </span>
                <span className="font-bold text-slate-700">
                  {deliveryFee === 0 ? 'FREE' : `£${deliveryFee.toFixed(2)}`}
                </span>
              </div>

              {/* Promo Coupon Field */}
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <input
                    type="text"
                    placeholder="Promo code (e.g. POUND10)"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-md px-3 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-[#006967]"
                  />
                  <Tag className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2" />
                </div>
                <button
                  onClick={() => applyCoupon(couponCode)}
                  className="px-3 py-1.5 bg-slate-900 text-white font-bold text-xs rounded-md hover:bg-slate-800 shrink-0"
                >
                  Apply
                </button>
              </div>

              {/* Pricing Breakdown */}
              <div className="space-y-1.5 text-xs pt-2 border-t border-slate-200">
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal</span>
                  <span className="font-bold tabular-nums">£{subtotal.toFixed(2)}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-700 font-semibold">
                    <span>Discount ({appliedCoupon})</span>
                    <span className="tabular-nums">-£{discountAmount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-slate-600">
                  <span>
                    {deliveryMethod === 'collect' ? 'Click & Collect' : 'Delivery'}
                  </span>
                  <span className="font-bold tabular-nums">
                    {deliveryFee === 0 ? (
                      <span className="text-emerald-700 uppercase font-black text-[11px]">FREE</span>
                    ) : (
                      `£${deliveryFee.toFixed(2)}`
                    )}
                  </span>
                </div>
                <div className="flex justify-between text-sm sm:text-base font-black text-slate-950 pt-1.5 border-t border-slate-200">
                  <span>Total to Pay</span>
                  <span className="tabular-nums text-lg">£{grandTotal.toFixed(2)}</span>
                </div>
              </div>

              {/* Checkout CTA */}
              <button
                onClick={handleCheckout}
                className="w-full py-3 px-4 bg-[#FFDD00] hover:bg-yellow-400 active:scale-98 text-slate-950 font-black text-sm rounded-lg shadow-md hover:shadow-lg flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <span>Checkout Now</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                <span>SSL Encrypted Checkout · 100% Secure Payment</span>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
