export interface Product {
  id: string;
  name: string;
  brand: string;
  category: 'essentials' | 'food' | 'beauty' | 'home' | 'cleaning' | 'party' | 'seasonal' | 'offers';
  categoryLabel: string;
  price: number;
  originalPrice?: number;
  unit: string;
  pricePerUnit: string;
  rating: number;
  reviewsCount: number;
  image: string;
  badge?: string;
  inStock: boolean;
  isOffer?: boolean;
  description: string;
  features: string[];
}

export const PRODUCTS: Product[] = [
  // £1 Essentials & Cleaning
  {
    id: 'pl-001',
    name: 'Soft Toilet Tissue 4 Rolls Quilted Luxury',
    brand: 'Soft Touch',
    category: 'essentials',
    categoryLabel: '£1 Essentials',
    price: 1.00,
    unit: '4 Rolls',
    pricePerUnit: '£0.25 / roll',
    rating: 4.8,
    reviewsCount: 342,
    image: '/categories/thumb_essentials.png',
    badge: '£1 Hero',
    inStock: true,
    description: 'Luxuriously soft and strong 2-ply quilted toilet tissue. Designed for everyday family comfort with embossed micro-cushions.',
    features: ['2-ply quilted thickness', '160 sheets per roll', 'Sustainably sourced paper', 'Dermatologically tested']
  },
  {
    id: 'pl-002',
    name: 'Fairy Original Washing Up Liquid 320ml',
    brand: 'Fairy',
    category: 'cleaning',
    categoryLabel: 'Cleaning',
    price: 1.00,
    originalPrice: 1.50,
    unit: '320ml',
    pricePerUnit: '£0.31 / 100ml',
    rating: 4.9,
    reviewsCount: 819,
    image: '/categories/thumb_essentials.png',
    badge: 'Big Brand £1',
    inStock: true,
    isOffer: true,
    description: 'The iconic green grease-cutting liquid. Lasts up to 2x longer than generic alternatives with rich, long-lasting suds.',
    features: ['Original fresh scent', 'Ultra grease cutting formula', 'Gentle on skin', '100% recycled plastic bottle']
  },
  {
    id: 'pl-003',
    name: 'Colgate Triple Action Toothpaste 100ml',
    brand: 'Colgate',
    category: 'beauty',
    categoryLabel: 'Health & Beauty',
    price: 1.00,
    unit: '100ml',
    pricePerUnit: '£1.00 / 100ml',
    rating: 4.7,
    reviewsCount: 420,
    image: '/categories/thumb_beauty.png',
    badge: 'Everyday £1',
    inStock: true,
    description: 'Delivers three key oral health benefits: cavity protection, whiter teeth, and long-lasting fresh breath with active fluoride.',
    features: ['Fluoride enamel protection', 'Original mint flavour', 'Stain removal action', 'Recyclable tube']
  },
  {
    id: 'pl-004',
    name: 'Carex Moisture Antibacterial Handwash 250ml',
    brand: 'Carex',
    category: 'beauty',
    categoryLabel: 'Health & Beauty',
    price: 1.00,
    unit: '250ml',
    pricePerUnit: '£0.40 / 100ml',
    rating: 4.8,
    reviewsCount: 512,
    image: '/categories/thumb_beauty.png',
    badge: 'Best Seller',
    inStock: true,
    description: 'Kills 99.9% of bacteria while keeping your hands moisturised and soft with natural skin cleansers.',
    features: ['Kills 99.9% of bacteria', 'Added moisturising ingredients', 'Dermatologically tested', 'Eco-refill compatible pump']
  },
  {
    id: 'pl-005',
    name: 'NIVEA Creme Soft Rich Moisturising Shower Gel 250ml',
    brand: 'NIVEA',
    category: 'beauty',
    categoryLabel: 'Health & Beauty',
    price: 1.25,
    originalPrice: 2.00,
    unit: '250ml',
    pricePerUnit: '£0.50 / 100ml',
    rating: 4.9,
    reviewsCount: 290,
    image: '/categories/thumb_beauty.png',
    badge: 'Super Value',
    inStock: true,
    description: 'Silky cream shower gel enriched with nourishing almond oil for intensely cared-for, touchably soft skin.',
    features: ['Enriched with Almond Oil', 'Hydra IQ 24h moisture', 'pH skin-balanced formula', 'Subtle clean fragrance']
  },
  {
    id: 'pl-006',
    name: 'Flash Multi-Surface Antibacterial Cleaning Spray 500ml',
    brand: 'Flash',
    category: 'cleaning',
    categoryLabel: 'Cleaning',
    price: 1.00,
    unit: '500ml',
    pricePerUnit: '£0.20 / 100ml',
    rating: 4.7,
    reviewsCount: 198,
    image: '/categories/thumb_essentials.png',
    badge: '£1 Essential',
    inStock: true,
    description: 'Powers through kitchen grease and bathroom grime, leaving all hard surfaces hygienically clean with a crisp lemon scent.',
    features: ['Cuts through 100% of grease', 'Lemon fresh scent', 'Streak-free shine', 'Suitable for food prep areas']
  },
  {
    id: 'pl-007',
    name: 'Elbow Grease All-Purpose Miracle Degreaser 500ml',
    brand: 'Elbow Grease',
    category: 'cleaning',
    categoryLabel: 'Cleaning',
    price: 1.00,
    unit: '500ml',
    pricePerUnit: '£0.20 / 100ml',
    rating: 4.9,
    reviewsCount: 650,
    image: '/categories/thumb_essentials.png',
    badge: 'Cult Classic',
    inStock: true,
    description: 'The miracle degreaser that removes grease and oil from fabrics, metals, plastics, and household appliances effortlessly.',
    features: ['Solvent-free formulation', 'Great for fabrics & metals', 'Instant grease dissolving', 'Trigger spray head']
  },
  {
    id: 'pl-008',
    name: 'Astonish Mould & Mildew Specialist Stain Remover 750ml',
    brand: 'Astonish',
    category: 'cleaning',
    categoryLabel: 'Cleaning',
    price: 1.25,
    originalPrice: 1.75,
    unit: '750ml',
    pricePerUnit: '£0.17 / 100ml',
    rating: 4.8,
    reviewsCount: 310,
    image: '/categories/thumb_essentials.png',
    badge: 'Specialist',
    inStock: true,
    description: 'Effective mould and mildew remover blast that eliminates stains in minutes without scrubbing needed.',
    features: ['Fast acting bleach action', 'No scrubbing required', 'Cruelty-free & Vegan certified', 'Made in the UK']
  },

  // Food & Drink
  {
    id: 'pl-009',
    name: 'Heinz Baked Beanz in Rich Tomato Sauce 415g',
    brand: 'Heinz',
    category: 'food',
    categoryLabel: 'Food & Drink',
    price: 1.00,
    originalPrice: 1.40,
    unit: '415g',
    pricePerUnit: '£0.24 / 100g',
    rating: 4.8,
    reviewsCount: 520,
    image: '/categories/thumb_food.png',
    badge: 'Top Brand £1',
    inStock: true,
    isOffer: true,
    description: '1 of your 5 a day in every half can! High in fiber, low in fat, and naturally high in protein with classic Heinz tomato sauce.',
    features: ['1 of your 5 a day', 'Rich tomato recipe', 'No artificial colors or flavors', 'Gluten free']
  },
  {
    id: 'pl-010',
    name: 'Cadbury Dairy Milk Giant Buttons Pouch 110g',
    brand: 'Cadbury',
    category: 'food',
    categoryLabel: 'Food & Drink',
    price: 1.00,
    unit: '110g',
    pricePerUnit: '£0.91 / 100g',
    rating: 4.9,
    reviewsCount: 680,
    image: '/categories/thumb_food.png',
    badge: 'Sweet Treat £1',
    inStock: true,
    description: 'Bite-sized pieces of velvety smooth classic Cadbury Dairy Milk chocolate in a handy resealable sharing bag.',
    features: ['100% sustainably sourced cocoa', 'Smooth British milk chocolate', 'Ideal for sharing or movies', 'Resealable bag']
  },
  {
    id: 'pl-011',
    name: 'Haribo Starmix Family Sharing Treat Bag 140g',
    brand: 'Haribo',
    category: 'food',
    categoryLabel: 'Food & Drink',
    price: 1.00,
    unit: '140g',
    pricePerUnit: '£0.71 / 100g',
    rating: 4.8,
    reviewsCount: 410,
    image: '/categories/thumb_food.png',
    badge: 'Favourite',
    inStock: true,
    description: 'The UK\'s favourite mix of jelly and foam sweets featuring gummy bears, fried eggs, friendship rings, and cola bottles.',
    features: ['No artificial colours', 'Iconic Starmix shapes', 'Fun fruit flavours', 'Chewy texture']
  },
  {
    id: 'pl-012',
    name: 'Tetley Original Everyday Round Tea Bags 80s',
    brand: 'Tetley',
    category: 'food',
    categoryLabel: 'Food & Drink',
    price: 1.50,
    originalPrice: 2.20,
    unit: '80 Bags',
    pricePerUnit: '£0.019 / bag',
    rating: 4.7,
    reviewsCount: 380,
    image: '/categories/thumb_food.png',
    badge: 'Mega Value',
    inStock: true,
    description: 'Full-flavoured, smooth and warming British cuppa made with carefully selected leaves from Rainforest Alliance certified farms.',
    features: ['100% Rainforest Alliance Certified', 'Signature round tea bags', 'Deep, rich amber brew', 'Biodegradable bags']
  },
  {
    id: 'pl-013',
    name: 'Walkers Ready Salted Potato Crisps 6 Pack',
    brand: 'Walkers',
    category: 'food',
    categoryLabel: 'Food & Drink',
    price: 1.50,
    unit: '6 x 25g',
    pricePerUnit: '£0.25 / bag',
    rating: 4.7,
    reviewsCount: 295,
    image: '/categories/thumb_food.png',
    badge: 'Lunchbox Deal',
    inStock: true,
    description: 'Classic British crisps made with 100% Great British potatoes, seasoned simply with British salt.',
    features: ['100% Great British potatoes', 'No added MSG or artificial colors', 'Suitable for vegetarians', 'Crunchy freshness']
  },

  // Home & Living
  {
    id: 'pl-014',
    name: 'Cozy Textured Cable Knit Cushion 40x40cm',
    brand: 'Homestyle',
    category: 'home',
    categoryLabel: 'Home & Living',
    price: 3.50,
    originalPrice: 6.00,
    unit: 'Each',
    pricePerUnit: '£3.50 / unit',
    rating: 4.8,
    reviewsCount: 165,
    image: '/categories/thumb_home.png',
    badge: 'Home Style',
    inStock: true,
    description: 'Bring warm texture and Scandinavian comfort to your sofa or bedroom with this plush knitted scatter cushion.',
    features: ['Super soft acrylic knit', 'Plump hollowfibre filling', 'Concealed zipper cover', 'Spot cleanable']
  },
  {
    id: 'pl-015',
    name: 'French Vanilla & Warm Amber Glass Jar Candle 18oz',
    brand: 'Aroma Home',
    category: 'home',
    categoryLabel: 'Home & Living',
    price: 2.00,
    unit: '18oz Jar',
    pricePerUnit: '£2.00 / jar',
    rating: 4.9,
    reviewsCount: 320,
    image: '/categories/thumb_home.png',
    badge: 'Aroma £2',
    inStock: true,
    description: 'A decadent blend of Madagascar vanilla beans and soothing amber. Delivers up to 60 hours of continuous room fragrance.',
    features: ['Up to 60 hours burn time', 'Double cotton lead-free wick', 'Heavy apothecary glass jar', 'Clean burning soy blend']
  },
  {
    id: 'pl-016',
    name: 'Warm White Micro LED Fairy String Lights 10m',
    brand: 'Lumina',
    category: 'home',
    categoryLabel: 'Home & Living',
    price: 1.50,
    unit: '100 LEDs',
    pricePerUnit: '10m Cable',
    rating: 4.8,
    reviewsCount: 275,
    image: '/categories/thumb_home.png',
    badge: 'Cozy Living',
    inStock: true,
    description: 'Flexible bendable copper wire with 100 warm white micro LEDs. Battery operated with timer function.',
    features: ['100 micro warm white LEDs', 'Bendable copper wire', '6h on / 18h off timer', 'Battery operated (3x AA)']
  },

  // Party & Celebration
  {
    id: 'pl-017',
    name: 'Assorted Latex Party Balloons 50 Pack Vibrant Mix',
    brand: 'Party Central',
    category: 'party',
    categoryLabel: 'Party',
    price: 1.00,
    unit: '50 Pack',
    pricePerUnit: '£0.02 / balloon',
    rating: 4.7,
    reviewsCount: 310,
    image: '/categories/thumb_party.png',
    badge: 'Party £1',
    inStock: true,
    description: '10-inch high elasticity biodegradable natural latex party balloons in vivid rainbow colours for birthdays and gatherings.',
    features: ['50 assorted colour balloons', 'Biodegradable natural rubber', 'Helium or air fillable', 'Tear resistant']
  },
  {
    id: 'pl-018',
    name: 'Sparkling Gold Foil Happy Birthday Banner Garland 2m',
    brand: 'Party Central',
    category: 'party',
    categoryLabel: 'Party',
    price: 1.00,
    unit: '2 Metre',
    pricePerUnit: '£1.00 / set',
    rating: 4.8,
    reviewsCount: 220,
    image: '/categories/thumb_party.png',
    badge: '£1 Party Essential',
    inStock: true,
    description: 'Pre-strung shimmering metallic gold letters with luxury ribbon. Easy to hang anywhere in seconds.',
    features: ['2m pre-threaded satin ribbon', 'Reflective gold foil cardstock', 'Reusable durable design', 'Eye-catching centerpiece']
  },
  {
    id: 'pl-019',
    name: 'Biodegradable Kraft Paper Party Cups 20 Pack',
    brand: 'EcoParty',
    category: 'party',
    categoryLabel: 'Party',
    price: 1.00,
    unit: '20 Pack',
    pricePerUnit: '£0.05 / cup',
    rating: 4.6,
    reviewsCount: 140,
    image: '/categories/thumb_party.png',
    badge: 'Eco Choice',
    inStock: true,
    description: 'FSC-certified unbleached kraft paper drinking cups for cold and warm party beverages. Fully compostable.',
    features: ['250ml capacity each', '100% recyclable & compostable', 'Leak-proof internal seal', 'Plastic-free choice']
  },

  // Seasonal
  {
    id: 'pl-020',
    name: 'Festive Crimson & Gold Bauble Hanging Ornaments 6pk',
    brand: 'Seasonal Joy',
    category: 'seasonal',
    categoryLabel: 'Seasonal',
    price: 1.25,
    originalPrice: 2.00,
    unit: '6 Pack',
    pricePerUnit: '£0.21 / bauble',
    rating: 4.8,
    reviewsCount: 195,
    image: '/categories/thumb_seasonal.png',
    badge: 'Festive Value',
    inStock: true,
    description: 'Shatterproof Christmas tree baubles with intricate glitter patterns and hanging cords included.',
    features: ['Shatterproof durable plastic', 'Mixed matte and glitter finish', 'Hanging threads pre-attached', 'Child & pet safe']
  },
  {
    id: 'pl-021',
    name: 'Frosted Pine & Winter Berry Table Garland 1.5m',
    brand: 'Seasonal Joy',
    category: 'seasonal',
    categoryLabel: 'Seasonal',
    price: 2.50,
    unit: '1.5 Metre',
    pricePerUnit: '£2.50 / item',
    rating: 4.9,
    reviewsCount: 180,
    image: '/categories/thumb_seasonal.png',
    badge: 'Holiday Special',
    inStock: true,
    description: 'Realistic artificial fir tips sprinkled with artificial snow, pinecones, and bright scarlet holly berries.',
    features: ['Snow frosted needles', 'Real miniature pinecones', 'Bendable wire branch', 'Indoor decorative use']
  },

  // Special Offers
  {
    id: 'pl-022',
    name: 'Simple Kind to Skin Facial Cleansing Wipes 25s',
    brand: 'Simple',
    category: 'offers',
    categoryLabel: 'Offers',
    price: 1.00,
    originalPrice: 1.80,
    unit: '25 Wipes',
    pricePerUnit: '£0.04 / wipe',
    rating: 4.8,
    reviewsCount: 460,
    image: '/categories/thumb_beauty.png',
    badge: 'Offer · Was £1.80',
    inStock: true,
    isOffer: true,
    description: 'Gentle facial wipes enriched with Pro-Vitamin B5 and Vitamin E. Effectively removes waterproof mascara without stinging.',
    features: ['No artificial perfume or colour', 'No harsh chemicals', '100% plant-based fibers', 'Biodegradable wipes']
  },
  {
    id: 'pl-023',
    name: 'Finish Classic All-in-1 Dishwasher Tablets 14pk',
    brand: 'Finish',
    category: 'offers',
    categoryLabel: 'Offers',
    price: 2.00,
    originalPrice: 3.50,
    unit: '14 Pack',
    pricePerUnit: '£0.14 / tab',
    rating: 4.9,
    reviewsCount: 520,
    image: '/categories/thumb_essentials.png',
    badge: 'Mega Deal',
    inStock: true,
    isOffer: true,
    description: 'Powerball technology soaks and softens tough food stains while powerful detergents lift stubborn residues.',
    features: ['Powerball pre-soaking action', 'Cuts baked-on grease', 'Glass protection formula', 'Dissolving wrapper']
  },
  {
    id: 'pl-024',
    name: 'Cadbury Dairy Milk Chocolate Sharing Bar 110g',
    brand: 'Cadbury',
    category: 'offers',
    categoryLabel: 'Offers',
    price: 1.00,
    originalPrice: 1.35,
    unit: '110g Bar',
    pricePerUnit: '£0.91 / 100g',
    rating: 4.9,
    reviewsCount: 710,
    image: '/categories/thumb_food.png',
    badge: '2 for £1.80 Promo',
    inStock: true,
    isOffer: true,
    description: 'The nation\'s favourite creamy milk chocolate block made with fresh glass-and-a-half of milk in every half pound.',
    features: ['100% sustainably sourced cocoa', 'Classic British recipe', 'Perfect afternoon treat', 'Recyclable packaging']
  }
];

export interface UKStore {
  id: string;
  name: string;
  city: string;
  postcode: string;
  address: string;
  phone: string;
  distance: string;
  hoursToday: string;
  clickAndCollect: boolean;
  isOpen: boolean;
}

export const UK_STORES: UKStore[] = [
  {
    id: 'store-1',
    name: 'London Oxford Street',
    city: 'London',
    postcode: 'W1D 2LP',
    address: '422 Oxford Street, Mayfair, London',
    phone: '020 7493 1122',
    distance: '0.4 miles',
    hoursToday: '08:00 - 21:00',
    clickAndCollect: true,
    isOpen: true
  },
  {
    id: 'store-2',
    name: 'Birmingham Bullring',
    city: 'Birmingham',
    postcode: 'B5 4BU',
    address: 'Unit 14, Bullring Shopping Centre, Birmingham',
    phone: '0121 643 8901',
    distance: '1.2 miles',
    hoursToday: '08:30 - 20:00',
    clickAndCollect: true,
    isOpen: true
  },
  {
    id: 'store-3',
    name: 'Manchester Arndale',
    city: 'Manchester',
    postcode: 'M4 3AQ',
    address: 'Upper Mall, Arndale Centre, Market St, Manchester',
    phone: '0161 834 6500',
    distance: '1.8 miles',
    hoursToday: '08:00 - 20:00',
    clickAndCollect: true,
    isOpen: true
  },
  {
    id: 'store-4',
    name: 'Leeds Trinity',
    city: 'Leeds',
    postcode: 'LS1 5ER',
    address: 'Albion Street, Trinity Centre, Leeds',
    phone: '0113 245 7800',
    distance: '2.5 miles',
    hoursToday: '08:30 - 19:30',
    clickAndCollect: true,
    isOpen: true
  },
  {
    id: 'store-5',
    name: 'Glasgow Argyle Street',
    city: 'Glasgow',
    postcode: 'G2 8BG',
    address: '112 Argyle Street, Glasgow',
    phone: '0141 221 4400',
    distance: '3.1 miles',
    hoursToday: '08:00 - 19:00',
    clickAndCollect: true,
    isOpen: true
  },
  {
    id: 'store-6',
    name: 'Bristol Broadmead',
    city: 'Bristol',
    postcode: 'BS1 3HA',
    address: '45 Broadmead Shopping Quarter, Bristol',
    phone: '0117 929 1190',
    distance: '4.0 miles',
    hoursToday: '08:30 - 18:30',
    clickAndCollect: true,
    isOpen: true
  }
];
