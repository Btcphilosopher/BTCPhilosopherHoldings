'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, PRODUCTS, UKStore, UK_STORES } from '@/data/products';

export interface CartItem {
  product: Product;
  quantity: number;
}

interface Toast {
  id: string;
  message: string;
  type: 'success' | 'info';
}

interface StoreContextType {
  // Cart
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  totalItems: number;
  subtotal: number;
  deliveryMethod: 'collect' | 'delivery';
  setDeliveryMethod: (method: 'collect' | 'delivery') => void;
  deliveryFee: number;
  freeCollectThreshold: number;
  freeShippingProgress: number;
  couponCode: string;
  setCouponCode: (code: string) => void;
  appliedCoupon: string | null;
  applyCoupon: (code: string) => boolean;
  discountAmount: number;
  grandTotal: number;

  // Wishlist
  wishlist: string[];
  toggleWishlist: (productId: string) => void;
  isWishlisted: (productId: string) => boolean;

  // Store Locator
  selectedStore: UKStore;
  setSelectedStore: (store: UKStore) => void;

  // Modals & Drawers
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  isStoreLocatorOpen: boolean;
  setIsStoreLocatorOpen: (open: boolean) => void;
  isAccountOpen: boolean;
  setIsAccountOpen: (open: boolean) => void;
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;
  quickViewProduct: Product | null;
  setQuickViewProduct: (product: Product | null) => void;

  // Filtering & Search
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  priceFilter: string;
  setPriceFilter: (filter: string) => void;
  sortBy: string;
  setSortBy: (sort: string) => void;

  // Notification Toasts
  toasts: Toast[];
  showToast: (message: string, type?: 'success' | 'info') => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  // Initial demo cart with 2 popular items
  const [cart, setCart] = useState<CartItem[]>([
    { product: PRODUCTS[0], quantity: 2 },
    { product: PRODUCTS[1], quantity: 1 }
  ]);
  const [wishlist, setWishlist] = useState<string[]>(['pl-003', 'pl-010']);
  const [selectedStore, setSelectedStore] = useState<UKStore>(UK_STORES[0]);
  const [deliveryMethod, setDeliveryMethod] = useState<'collect' | 'delivery'>('collect');
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);

  // Modals
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isStoreLocatorOpen, setIsStoreLocatorOpen] = useState(false);
  const [isAccountOpen, setIsAccountOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);

  // Filtering
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [priceFilter, setPriceFilter] = useState('all');
  const [sortBy, setSortBy] = useState('featured');

  // Toasts
  const [toasts, setToasts] = useState<Toast[]>([]);

  const showToast = (message: string, type: 'success' | 'info' = 'success') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3200);
  };

  const addToCart = (product: Product, quantity = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
    showToast(`Added ${quantity}x "${product.name.slice(0, 24)}..." to basket!`, 'success');
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
    showToast('Item removed from basket', 'info');
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const toggleWishlist = (productId: string) => {
    setWishlist((prev) => {
      const exists = prev.includes(productId);
      if (exists) {
        showToast('Removed from saved items', 'info');
        return prev.filter((id) => id !== productId);
      } else {
        showToast('Saved to your wishlist ❤️', 'success');
        return [...prev, productId];
      }
    });
  };

  const isWishlisted = (productId: string) => wishlist.includes(productId);

  const applyCoupon = (code: string) => {
    const clean = code.trim().toUpperCase();
    if (clean === 'POUND10' || clean === 'VALUE10') {
      setAppliedCoupon(clean);
      showToast('Promo code applied: 10% discount!', 'success');
      return true;
    } else if (clean === 'SAVE2') {
      setAppliedCoupon(clean);
      showToast('Promo code applied: £2.00 off!', 'success');
      return true;
    } else {
      showToast('Invalid coupon. Try POUND10', 'info');
      return false;
    }
  };

  // Calculations
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = Number(
    cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0).toFixed(2)
  );

  const freeCollectThreshold = 20.00;
  const freeShippingProgress = Math.min(100, Math.round((subtotal / freeCollectThreshold) * 100));

  let deliveryFee = 0;
  if (subtotal > 0) {
    if (deliveryMethod === 'collect') {
      deliveryFee = subtotal >= freeCollectThreshold ? 0 : 1.50;
    } else {
      deliveryFee = subtotal >= 40.00 ? 0 : 3.95;
    }
  }

  let discountAmount = 0;
  if (appliedCoupon === 'POUND10' || appliedCoupon === 'VALUE10') {
    discountAmount = Number((subtotal * 0.1).toFixed(2));
  } else if (appliedCoupon === 'SAVE2') {
    discountAmount = Math.min(subtotal, 2.00);
  }

  const grandTotal = Number(
    Math.max(0, subtotal - discountAmount + deliveryFee).toFixed(2)
  );

  return (
    <StoreContext.Provider
      value={{
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        totalItems,
        subtotal,
        deliveryMethod,
        setDeliveryMethod,
        deliveryFee,
        freeCollectThreshold,
        freeShippingProgress,
        couponCode,
        setCouponCode,
        appliedCoupon,
        applyCoupon,
        discountAmount,
        grandTotal,
        wishlist,
        toggleWishlist,
        isWishlisted,
        selectedStore,
        setSelectedStore,
        isCartOpen,
        setIsCartOpen,
        isStoreLocatorOpen,
        setIsStoreLocatorOpen,
        isAccountOpen,
        setIsAccountOpen,
        isCheckoutOpen,
        setIsCheckoutOpen,
        quickViewProduct,
        setQuickViewProduct,
        selectedCategory,
        setSelectedCategory,
        searchQuery,
        setSearchQuery,
        priceFilter,
        setPriceFilter,
        sortBy,
        setSortBy,
        toasts,
        showToast,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
}
