import React from 'react';
import { StoreProvider } from '@/context/StoreContext';
import Navbar from '@/components/Navbar';
import HeroBanner from '@/components/HeroBanner';
import PerksRibbon from '@/components/PerksRibbon';
import CategoryShowcase from '@/components/CategoryShowcase';
import DealsSpotlight from '@/components/DealsSpotlight';
import ProductCatalog from '@/components/ProductCatalog';
import Footer from '@/components/Footer';
import CartDrawer from '@/components/CartDrawer';
import CheckoutModal from '@/components/CheckoutModal';
import StoreLocatorModal from '@/components/StoreLocatorModal';
import AccountModal from '@/components/AccountModal';
import QuickViewModal from '@/components/QuickViewModal';
import ToastContainer from '@/components/ToastContainer';
import MobileQuickBar from '@/components/MobileQuickBar';

export default function Home() {
  return (
    <StoreProvider>
      <div className="min-h-screen bg-slate-50/50 flex flex-col font-sans pb-16 sm:pb-0 text-slate-900 selection:bg-[#FFDD00] selection:text-slate-900">
        
        {/* Navigation Header */}
        <Navbar />

        {/* Main Content Area */}
        <main className="flex-1">
          {/* Hero Banner (Faithful to Screenshot) */}
          <HeroBanner />

          {/* 4 Value Propositions Ribbon */}
          <PerksRibbon />

          {/* 6 Category Showcase Cards */}
          <CategoryShowcase />

          {/* Deals of the Week & Bundles Spotlight */}
          <DealsSpotlight />

          {/* Complete Product Catalog with Filtering & Cart Integration */}
          <ProductCatalog />
        </main>

        {/* Global Footer */}
        <Footer />

        {/* Sticky Mobile Quick Bar */}
        <MobileQuickBar />

        {/* Slide-over Drawers & Interactive Modals */}
        <CartDrawer />
        <CheckoutModal />
        <StoreLocatorModal />
        <AccountModal />
        <QuickViewModal />
        <ToastContainer />

      </div>
    </StoreProvider>
  );
}
