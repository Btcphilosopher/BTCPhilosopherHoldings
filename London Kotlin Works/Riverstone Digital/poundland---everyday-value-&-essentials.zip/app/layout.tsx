import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Poundland - Everyday Value & Essentials | Online Store',
  description: 'Shop great value everyday essentials, food & drink, cleaning supplies, health & beauty and seasonal goods online with Poundland UK.',
  openGraph: {
    title: 'Poundland - Everyday Value & Essentials | Online Store',
    description: 'Shop great value everyday essentials, food & drink, cleaning supplies, health & beauty and seasonal goods online with Poundland UK.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Poundland - Everyday Value & Essentials | Online Store',
    description: 'Shop great value everyday essentials, food & drink, cleaning supplies, health & beauty and seasonal goods online with Poundland UK.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
