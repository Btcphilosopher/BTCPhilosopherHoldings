'use client';

import React, { useState, useEffect, useRef } from 'react';
import Image from 'next/image';
import { Search, X } from 'lucide-react';
import { useStore } from '@/lib/store';
import { PRODUCTS, Product } from '@/lib/catalog';
import { haptic } from '@/lib/audio';

export default function SearchOverlay() {
  const { isSearchOpen, setIsSearchOpen, setQuickViewProduct, formatPrice } = useStore();
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isSearchOpen) {
      const timer = setTimeout(() => inputRef.current?.focus(), 50);
      return () => clearTimeout(timer);
    }
  }, [isSearchOpen]);

  if (!isSearchOpen) return null;

  const handleClose = () => {
    haptic.playSoftSnap();
    setQuery('');
    setIsSearchOpen(false);
  };

  const results = query.trim()
    ? PRODUCTS.filter(
        (p) =>
          p.name.toLowerCase().includes(query.toLowerCase()) ||
          p.category.toLowerCase().includes(query.toLowerCase()) ||
          p.fabric.toLowerCase().includes(query.toLowerCase()) ||
          p.description.toLowerCase().includes(query.toLowerCase())
      )
    : [];

  const handleSelect = (product: Product) => {
    haptic.playLuxuryClick();
    setQuery('');
    setIsSearchOpen(false);
    setQuickViewProduct(product);
  };

  const trendingTags = ['Cashmere Jumper', 'Wool Blazer', 'Silk Blouse', 'Wide-Leg Trouser', 'Leather Tote'];

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex flex-col justify-start animate-in fade-in duration-200">
      <div className="w-full bg-[#FAF8F5] border-b border-neutral-300 shadow-2xl p-6 sm:p-10">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold tracking-luxury uppercase text-neutral-500 font-brand">
              Search ME+EM Collection
            </span>
            <button
              onClick={handleClose}
              className="p-1 text-neutral-500 hover:text-neutral-900 transition-colors"
              aria-label="Close search"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Search Input */}
          <div className="relative flex items-center border-b-2 border-neutral-900 pb-3">
            <Search className="w-6 h-6 text-neutral-500 mr-4" />
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by garment, fabric (e.g. Cashmere, Silk, Biella Wool)..."
              className="w-full bg-transparent text-xl sm:text-2xl font-light font-editorial text-neutral-900 placeholder:text-neutral-400 focus:outline-hidden"
            />
            {query && (
              <button
                onClick={() => setQuery('')}
                className="p-1 text-xs text-neutral-400 hover:text-neutral-700 uppercase tracking-wider"
              >
                Clear
              </button>
            )}
          </div>

          {/* Trending Searches */}
          <div className="flex items-center gap-2 flex-wrap text-xs text-neutral-600">
            <span className="font-semibold text-neutral-800 tracking-wider text-[11px] uppercase">
              Trending:
            </span>
            {trendingTags.map((tag) => (
              <button
                key={tag}
                onClick={() => {
                  haptic.playSwatchTap();
                  setQuery(tag);
                }}
                className="px-2.5 py-1 bg-white border border-neutral-200 hover:border-neutral-900 text-neutral-700 hover:text-neutral-900 transition-colors rounded-xs"
              >
                {tag}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Results View */}
      <div className="flex-1 overflow-y-auto max-w-4xl w-full mx-auto p-6 sm:p-10">
        {query.trim() && (
          <div className="space-y-4">
            <div className="text-xs tracking-luxury uppercase text-neutral-300 font-medium">
              Found {results.length} result{results.length === 1 ? '' : 's'} for &ldquo;{query}&rdquo;
            </div>

            {results.length === 0 ? (
              <div className="py-12 text-center text-neutral-400 font-light">
                No matching garments found. Try searching for &ldquo;Cashmere&rdquo; or &ldquo;Trouser&rdquo;.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {results.map((product) => (
                  <div
                    key={product.id}
                    onClick={() => handleSelect(product)}
                    className="bg-white p-4 border border-neutral-200 hover:border-neutral-900 cursor-pointer transition-all flex gap-3 group rounded-xs"
                  >
                    <div className="relative w-16 h-20 bg-neutral-100 shrink-0 overflow-hidden rounded-xs">
                      <Image
                        src={product.image}
                        alt={product.name}
                        fill
                        sizes="64px"
                        referrerPolicy="no-referrer"
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0 flex flex-col justify-between">
                      <div>
                        <div className="text-[10px] tracking-luxury uppercase text-neutral-400 font-semibold">
                          {product.category}
                        </div>
                        <h4 className="text-xs font-semibold text-neutral-900 truncate mt-0.5">
                          {product.name}
                        </h4>
                      </div>
                      <div className="text-xs font-medium tabular-nums text-neutral-800">
                        {formatPrice(product.price)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
