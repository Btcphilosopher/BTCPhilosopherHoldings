'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { haptic } from '@/lib/audio';

export default function IntelligentStylePhilosophy({ onExplore }: { onExplore: () => void }) {
  const rules = [
    {
      num: '01',
      title: 'Flattering Silhouettes',
      desc: 'Every garment is fitted on real women of diverse body shapes. We obsess over fractions of a millimeter: high-waisted bands, deep hem side-splits, and dropped shoulders engineered to elongate and flatter.',
    },
    {
      num: '02',
      title: '24/7 Multi-Function',
      desc: 'No piece is created for a single occasion. If an item cannot be dressed up with sleek stilettos and down with clean trainers, it does not make the collection.',
    },
    {
      num: '03',
      title: 'Direct-to-Consumer Luxury',
      desc: 'By working directly with prestigious mills in Biella, Como, and Scotland, we eliminate customary luxury markups. You receive Savile Row grade craftsmanship at honest direct pricing.',
    },
    {
      num: '04',
      title: 'Fabric Longevity',
      desc: 'Scottish 2-ply cashmeres that do not pill, 19-momme washable silks, and crease-resistant bi-stretch Italian virgin wools built to retain architectural form for years to come.',
    },
  ];

  return (
    <section id="philosophy" className="w-full bg-[#1A1A1A] text-[#FAF8F5] py-20 sm:py-24">
      <div className="max-w-[1536px] mx-auto px-4 sm:px-8">
        
        {/* Section Headline */}
        <div className="max-w-3xl mb-16 space-y-4">
          <div className="text-[11px] font-semibold tracking-[0.25em] uppercase text-neutral-400">
            OUR PHILOSOPHY
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-light font-editorial leading-tight text-white">
            Intelligent Style. Designed in London, Engineered for Modern Living.
          </h2>
          <p className="text-sm sm:text-base text-neutral-300 leading-relaxed font-light">
            Founded in London by Clare Hornby, ME+EM was created to solve the compromise women face between trend-led fashion that lacks quality, and traditional luxury that lacks everyday function.
          </p>
        </div>

        {/* 4 Core Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 pt-4">
          {rules.map((rule) => (
            <div
              key={rule.num}
              className="border-t border-neutral-700/80 pt-6 space-y-3 group hover:border-neutral-400 transition-colors"
            >
              <div className="font-mono text-xs tracking-wider text-neutral-500 font-semibold">
                {rule.num}
              </div>
              <h3 className="text-lg font-medium text-white tracking-wide">
                {rule.title}
              </h3>
              <p className="text-xs text-neutral-400 leading-relaxed font-light">
                {rule.desc}
              </p>
            </div>
          ))}
        </div>

        {/* Campaign Editorial Spotlight Card */}
        <div className="mt-16 bg-neutral-900 border border-neutral-800 p-8 sm:p-12 flex flex-col lg:flex-row items-center justify-between gap-8 rounded-xs">
          <div className="space-y-4 max-w-xl">
            <span className="text-[10px] tracking-luxury uppercase font-semibold text-neutral-400">
              Autumn / Winter 2026 Collection
            </span>
            <h3 className="text-2xl sm:text-3xl font-light font-editorial text-white">
              Discover the Tailored Suiting & Knitwear Capsule
            </h3>
            <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
              Engineered with pure Biella wool and Scottish cashmere. Designed to transition effortlessly from boardroom meetings to evening occasions.
            </p>
          </div>
          <button
            onClick={() => {
              haptic.playLuxuryClick();
              onExplore();
            }}
            className="px-8 py-3.5 bg-white text-neutral-950 text-xs font-semibold tracking-luxury uppercase hover:bg-neutral-200 transition-colors whitespace-nowrap active:scale-[0.98] flex items-center gap-2"
          >
            <span>Explore The Collection</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
}
