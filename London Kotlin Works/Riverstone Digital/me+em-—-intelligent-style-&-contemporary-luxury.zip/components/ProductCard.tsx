'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Heart, Eye, Plus } from 'lucide-react';
import { Product } from '@/lib/catalog';
import { useStore } from '@/lib/store';
import { haptic } from '@/lib/audio';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const {
    formatPrice,
    addToCart,
    toggleWishlist,
    isWishlisted,
    setQuickViewProduct,
  } = useStore();

  const [selectedColor, setSelectedColor] = useState(product.colors[0]?.name || '');
  const [selectedSize, setSelectedSize] = useState(product.sizes[1] || product.sizes[0]);
  const [isHovered, setIsHovered] = useState(false);

  const wishlisted = isWishlisted(product.id);

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    haptic.playBagAdd();
    addToCart(product, selectedSize, selectedColor);
  };

  const handleOpenQuickView = () => {
    haptic.playLuxuryClick();
    setQuickViewProduct(product);
  };

  return (
    <div
      className="group relative flex flex-col bg-white border border-neutral-200/80 hover:border-neutral-400/80 transition-all duration-300 hover:shadow-lg rounded-xs overflow-hidden"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Visual Image Showcase */}
      <div
        className="relative w-full aspect-[3/4] bg-neutral-100 overflow-hidden cursor-pointer"
        onClick={handleOpenQuickView}
      >
        <Image
          src={isHovered && product.secondaryImage ? product.secondaryImage : product.image}
          alt={product.name}
          fill
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
          referrerPolicy="no-referrer"
          className="object-cover object-top transition-transform duration-700 ease-out group-hover:scale-105"
        />

        {/* Quiet Subtle Badge */}
        {product.badge && (
          <div className="absolute top-3 left-3 bg-[#FAF8F5]/90 backdrop-blur-xs px-2.5 py-1 text-[10px] tracking-luxury uppercase font-medium text-neutral-800 border border-neutral-300/60 shadow-xs">
            {product.badge}
          </div>
        )}

        {/* Wishlist Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleWishlist(product.id);
          }}
          aria-label={wishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
          className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-md transition-all duration-200 ${
            wishlisted
              ? 'bg-neutral-900 text-white'
              : 'bg-white/80 text-neutral-700 hover:bg-white hover:text-neutral-950'
          }`}
        >
          <Heart className={`w-4 h-4 ${wishlisted ? 'fill-white' : ''}`} />
        </button>

        {/* Hover Quick Actions Bar */}
        <div className="absolute inset-x-3 bottom-3 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-auto">
          <button
            onClick={handleOpenQuickView}
            className="flex-1 py-2.5 px-3 bg-white/95 backdrop-blur-md text-neutral-900 text-[11px] font-medium tracking-luxury uppercase border border-neutral-200 hover:bg-neutral-900 hover:text-white transition-colors flex items-center justify-center gap-1.5 shadow-sm active:scale-[0.98]"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Quick View</span>
          </button>
          <button
            onClick={handleQuickAdd}
            title="Quick Add to Bag"
            className="py-2.5 px-3 bg-neutral-900 text-white text-[11px] font-medium tracking-luxury uppercase hover:bg-neutral-800 transition-colors flex items-center justify-center gap-1 shadow-sm active:scale-[0.98]"
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Add</span>
          </button>
        </div>
      </div>

      {/* Card Metadata Section */}
      <div className="p-4 sm:p-5 flex flex-col flex-1 justify-between gap-3 bg-white">
        <div>
          {/* Unboxed Metadata: Category and Fabric */}
          <div className="flex items-center gap-2 text-[10px] sm:text-[11px] tracking-luxury uppercase text-neutral-500 mb-1.5 font-medium">
            <span>{product.category}</span>
            <span aria-hidden="true" className="opacity-40">·</span>
            <span className="truncate">{product.fabric.split(' ')[0]}</span>
          </div>

          {/* Product Title */}
          <h3
            onClick={handleOpenQuickView}
            className="text-sm sm:text-[15px] font-medium text-neutral-900 hover:text-neutral-600 cursor-pointer line-clamp-1 transition-colors leading-snug"
          >
            {product.name}
          </h3>

          {/* Flatter Feature Micro-callout */}
          <p className="text-xs text-neutral-500 line-clamp-1 mt-1 font-light italic">
            {product.flatterFeature}
          </p>
        </div>

        {/* Bottom Line: Price & Color Swatches */}
        <div className="pt-2 border-t border-neutral-100 flex items-center justify-between gap-2">
          {/* Price with Tabular Numerals */}
          <div className="text-sm font-semibold tabular-nums text-neutral-900">
            {formatPrice(product.price)}
          </div>

          {/* Color Swatch Circles */}
          <div className="flex items-center gap-1.5">
            {product.colors.map((color) => (
              <button
                key={color.name}
                onClick={(e) => {
                  e.stopPropagation();
                  haptic.playSwatchTap();
                  setSelectedColor(color.name);
                }}
                title={color.name}
                aria-label={`Select color ${color.name}`}
                className={`w-3.5 h-3.5 rounded-full border transition-all ${
                  selectedColor === color.name
                    ? 'ring-1.5 ring-neutral-900 scale-110 border-white'
                    : 'border-neutral-300 hover:scale-105'
                }`}
                style={{ backgroundColor: color.hex }}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
