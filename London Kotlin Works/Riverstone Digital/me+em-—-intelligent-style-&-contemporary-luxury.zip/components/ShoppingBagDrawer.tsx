'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { X, Trash2, Plus, Minus, ArrowRight, ShieldCheck, Gift, CheckCircle, Package } from 'lucide-react';
import { useStore } from '@/lib/store';
import { haptic } from '@/lib/audio';

export default function ShoppingBagDrawer() {
  const {
    cart,
    isBagOpen,
    setIsBagOpen,
    removeFromCart,
    updateCartQuantity,
    cartCount,
    cartSubtotal,
    formatPrice,
    currency,
  } = useStore();

  const [giftWrap, setGiftWrap] = useState(false);
  const [giftMessage, setGiftMessage] = useState('');
  const [deliveryTier, setDeliveryTier] = useState<
    'ComplimentaryExpress' | 'LondonWhiteGloveSameDay' | 'CarbonNeutralWorldwide'
  >('ComplimentaryExpress');
  
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [orderConfirmed, setOrderConfirmed] = useState<{
    orderId: string;
    trackingRef: string;
    totalFormatted: string;
    shippingFormatted: string;
    packagingSpec: string;
    estimatedDelivery: string;
    executionMicroseconds: number;
  } | null>(null);

  if (!isBagOpen) return null;

  const freeDeliveryThreshold = 250;
  const progressToFreeDelivery = Math.min(100, (cartSubtotal / freeDeliveryThreshold) * 100);
  const remainingForFreeDelivery = Math.max(0, freeDeliveryThreshold - cartSubtotal);

  const handleExecuteCheckout = async () => {
    haptic.playLuxuryClick();
    setIsCheckingOut(true);
    try {
      const res = await fetch('/api/backend/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName: 'Victoria Hastings',
          customerEmail: 'victoria.hastings@mayfair.co.uk',
          country: 'GB',
          currency,
          deliveryTier,
          giftWrap,
          giftMessage: giftWrap ? giftMessage : undefined,
          items: cart.map((i) => ({
            id: i.productId,
            name: i.name,
            size: i.size,
            color: i.color,
            price: i.price,
            quantity: i.quantity,
          })),
        }),
      });
      const data = await res.json();
      if (data.order) {
        haptic.playBagAdd();
        setOrderConfirmed({
          orderId: data.order.orderId,
          trackingRef: data.order.trackingRef,
          totalFormatted: data.order.totalFormatted,
          shippingFormatted: data.order.shippingFormatted,
          packagingSpec: data.order.packagingSpec,
          estimatedDelivery: data.order.estimatedDelivery,
          executionMicroseconds: data.executionMicroseconds,
        });
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsCheckingOut(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-xs flex justify-end animate-in fade-in duration-200">
      <div
        className="w-full max-w-md bg-[#FAF8F5] h-full shadow-2xl flex flex-col justify-between border-l border-neutral-300 animate-in slide-in-from-right duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-neutral-200 flex items-center justify-between bg-white">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-semibold tracking-luxury uppercase text-neutral-900">
              Your Shopping Bag
            </h2>
            <span className="text-xs font-mono text-neutral-500">({cartCount})</span>
          </div>
          <button
            onClick={() => {
              haptic.playSoftSnap();
              setIsBagOpen(false);
            }}
            className="p-1.5 text-neutral-500 hover:text-neutral-900 transition-colors"
            aria-label="Close Shopping Bag"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Delivery Meter */}
        <div className="bg-neutral-100 px-5 py-3 border-b border-neutral-200 text-xs">
          <div className="flex items-center justify-between text-neutral-700 font-medium mb-1.5">
            <span>
              {remainingForFreeDelivery === 0 ? (
                <span className="text-emerald-700 font-semibold flex items-center gap-1">
                  <CheckCircle className="w-3.5 h-3.5" />
                  Unlocked: Complimentary Worldwide Express Delivery
                </span>
              ) : (
                <span>Add {formatPrice(remainingForFreeDelivery)} more for free express shipping</span>
              )}
            </span>
            <span className="font-mono text-[10px] text-neutral-500">
              {Math.round(progressToFreeDelivery)}%
            </span>
          </div>
          <div className="w-full bg-neutral-200 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-neutral-900 h-full transition-all duration-500 ease-out"
              style={{ width: `${progressToFreeDelivery}%` }}
            />
          </div>
        </div>

        {/* Order Confirmed Screen */}
        {orderConfirmed ? (
          <div className="flex-1 p-6 overflow-y-auto space-y-6 flex flex-col justify-center items-center text-center">
            <div className="w-14 h-14 bg-emerald-50 rounded-full flex items-center justify-center border border-emerald-200">
              <Package className="w-7 h-7 text-emerald-700" />
            </div>

            <div className="space-y-1">
              <span className="text-[10px] font-mono uppercase tracking-wider text-neutral-500">
                Kotlin Coroutine Pipeline Confirmed ({orderConfirmed.executionMicroseconds}µs)
              </span>
              <h3 className="text-2xl font-editorial font-light text-neutral-900">
                Order Received
              </h3>
              <p className="text-xs text-neutral-500">
                A confirmation has been sent to your email.
              </p>
            </div>

            <div className="w-full bg-white p-4 border border-neutral-200 rounded-xs text-left space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-neutral-500">Order ID:</span>
                <span className="font-mono font-semibold">{orderConfirmed.orderId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Tracking Reference:</span>
                <span className="font-mono">{orderConfirmed.trackingRef}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Estimated Delivery:</span>
                <span>{orderConfirmed.estimatedDelivery}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Total Charged:</span>
                <span className="font-semibold">{orderConfirmed.totalFormatted}</span>
              </div>
              <div className="pt-2 border-t border-neutral-100 text-[11px] text-neutral-600 italic">
                Packaging: {orderConfirmed.packagingSpec}
              </div>
            </div>

            <button
              onClick={() => {
                setOrderConfirmed(null);
                setIsBagOpen(false);
              }}
              className="w-full py-3 bg-neutral-900 text-white text-xs font-semibold tracking-luxury uppercase hover:bg-neutral-800 transition-colors"
            >
              Continue Shopping
            </button>
          </div>
        ) : (
          /* Cart Items List */
          <div className="flex-1 overflow-y-auto p-5 divide-y divide-neutral-200">
            {cart.length === 0 ? (
              <div className="py-20 text-center space-y-3">
                <p className="text-sm text-neutral-500 font-light">Your bag is currently empty.</p>
                <button
                  onClick={() => setIsBagOpen(false)}
                  className="px-6 py-2.5 border border-neutral-900 text-xs font-medium tracking-luxury uppercase hover:bg-neutral-900 hover:text-white transition-colors"
                >
                  Discover New Arrivals
                </button>
              </div>
            ) : (
              cart.map((item) => (
                <div key={item.id} className="py-4 flex gap-4">
                  <div className="relative w-20 h-24 bg-neutral-100 shrink-0 overflow-hidden rounded-xs">
                    <Image
                      src={item.image}
                      alt={item.name}
                      fill
                      sizes="80px"
                      referrerPolicy="no-referrer"
                      className="object-cover object-top"
                    />
                  </div>

                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-start gap-2">
                        <h4 className="text-xs font-semibold text-neutral-900 leading-tight">
                          {item.name}
                        </h4>
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="text-neutral-400 hover:text-neutral-700 p-1"
                          aria-label="Remove item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="text-[11px] text-neutral-500 mt-1 flex items-center gap-2">
                        <span>{item.size}</span>
                        <span>·</span>
                        <span>{item.color}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2">
                      <div className="flex items-center border border-neutral-300 rounded-xs bg-white">
                        <button
                          onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
                          className="p-1 hover:bg-neutral-100 text-neutral-700"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="px-2 text-xs font-mono font-medium">{item.quantity}</span>
                        <button
                          onClick={() => updateCartQuantity(item.id, item.quantity + 1)}
                          className="p-1 hover:bg-neutral-100 text-neutral-700"
                          aria-label="Increase quantity"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      <div className="text-xs font-semibold tabular-nums text-neutral-900">
                        {formatPrice(item.price * item.quantity)}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}

            {cart.length > 0 && (
              <div className="pt-4 space-y-3">
                {/* Gift Wrap Option */}
                <div className="bg-white p-3 border border-neutral-200 rounded-xs space-y-2">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-neutral-800">
                    <input
                      type="checkbox"
                      checked={giftWrap}
                      onChange={(e) => setGiftWrap(e.target.checked)}
                      className="accent-neutral-900 w-4 h-4"
                    />
                    <Gift className="w-3.5 h-3.5 text-neutral-600" />
                    <span>Complimentary Signature Gift Wrapping</span>
                  </label>
                  {giftWrap && (
                    <input
                      type="text"
                      placeholder="Personalized gift card note..."
                      value={giftMessage}
                      onChange={(e) => setGiftMessage(e.target.value)}
                      className="w-full text-xs p-2 border border-neutral-300 rounded-xs focus:ring-1 focus:ring-neutral-900"
                    />
                  )}
                </div>

                {/* Shipping Tier Selector */}
                <div className="text-xs space-y-1.5">
                  <span className="text-[10px] font-semibold tracking-luxury uppercase text-neutral-500">
                    Delivery Speed
                  </span>
                  <select
                    value={deliveryTier}
                    onChange={(e) => setDeliveryTier(e.target.value as typeof deliveryTier)}
                    className="w-full p-2 bg-white border border-neutral-200 text-xs text-neutral-800 rounded-xs focus:ring-1 focus:ring-neutral-900"
                  >
                    <option value="ComplimentaryExpress">
                      Complimentary Express (Over £250: Free · 2-3 Days)
                    </option>
                    <option value="LondonWhiteGloveSameDay">
                      London Mayfair Same-Day White Glove (£25.00)
                    </option>
                    <option value="CarbonNeutralWorldwide">
                      DHL Express Carbon-Neutral Worldwide (£18.00)
                    </option>
                  </select>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Bottom Checkout Module */}
        {cart.length > 0 && !orderConfirmed && (
          <div className="p-5 border-t border-neutral-200 bg-white space-y-3">
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-neutral-600">
                <span>Subtotal</span>
                <span className="font-medium text-neutral-900 tabular-nums">
                  {formatPrice(cartSubtotal)}
                </span>
              </div>
              <div className="flex justify-between text-neutral-600">
                <span>Estimated Shipping</span>
                <span className="text-emerald-700 font-medium">
                  {cartSubtotal >= freeDeliveryThreshold && deliveryTier === 'ComplimentaryExpress'
                    ? 'Complimentary'
                    : 'Calculated at checkout'}
                </span>
              </div>
              <div className="flex justify-between text-sm font-semibold text-neutral-900 pt-2 border-t border-neutral-100">
                <span>Estimated Total</span>
                <span className="tabular-nums">{formatPrice(cartSubtotal)}</span>
              </div>
            </div>

            <button
              onClick={handleExecuteCheckout}
              disabled={isCheckingOut}
              className="w-full py-3.5 px-4 bg-neutral-900 text-white text-xs font-semibold tracking-luxury uppercase hover:bg-neutral-800 transition-colors flex items-center justify-center gap-2 shadow-sm active:scale-[0.98] disabled:opacity-50"
            >
              <span>{isCheckingOut ? 'DISPATCHING VIA KOTLIN ENGINE...' : 'PROCEED TO CHECKOUT'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="flex items-center justify-center gap-2 text-[10px] text-neutral-500 pt-1">
              <ShieldCheck className="w-3.5 h-3.5 text-neutral-700" />
              <span>Complimentary 30-Day Returns · 100% Carbon Neutral</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
