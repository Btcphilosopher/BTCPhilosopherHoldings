'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Search, Heart, ShoppingBag, Volume2, VolumeX, Cpu, ChevronDown, X } from 'lucide-react';
import { useStore, CurrencyCode } from '@/lib/store';
import { haptic } from '@/lib/audio';

export default function Navbar({ onSelectCategory }: { onSelectCategory?: (cat: string) => void }) {
  const {
    cartCount,
    wishlist,
    setIsBagOpen,
    setIsSearchOpen,
    setIsBackendModalOpen,
    isSoundMuted,
    toggleSound,
    currency,
    setCurrency,
  } = useStore();

  const [isShopMenuOpen, setIsShopMenuOpen] = useState(false);
  const [currencyMenuOpen, setCurrencyMenuOpen] = useState(false);

  const handleNavClick = (anchorId: string) => {
    haptic.playLuxuryClick();
    const el = document.getElementById(anchorId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleCategorySelect = (category: string) => {
    haptic.playLuxuryClick();
    setIsShopMenuOpen(false);
    if (onSelectCategory) {
      onSelectCategory(category);
    }
    const el = document.getElementById('collection');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* Announcement Bar */}
      <div className="bg-[#141414] text-[#FAF8F5] text-[11px] tracking-luxury uppercase py-2 px-4 text-center font-medium border-b border-neutral-800 flex items-center justify-center gap-4">
        <span>COMPLIMENTARY WORLDWIDE EXPRESS DELIVERY ON ORDERS OVER £250</span>
        <span className="hidden sm:inline opacity-40">·</span>
        <span className="hidden sm:inline">EXTENDED 30-DAY COMPLIMENTARY RETURNS</span>
      </div>

      {/* Main Luxury Header */}
      <header className="sticky top-0 z-40 bg-[#FAF8F5]/95 backdrop-blur-md border-b border-neutral-200/80 transition-all duration-300">
        <div className="max-w-[1536px] mx-auto px-4 sm:px-8 h-20 flex items-center justify-between gap-4">
          
          {/* Zone 1: Navigation Links */}
          <nav className="flex items-center gap-6 sm:gap-8">
            <div className="relative">
              <button
                onClick={() => {
                  haptic.playLuxuryClick();
                  setIsShopMenuOpen(!isShopMenuOpen);
                }}
                className="flex items-center gap-1.5 text-xs font-semibold tracking-luxury uppercase hover:text-neutral-500 transition-colors whitespace-nowrap group py-2"
                aria-expanded={isShopMenuOpen}
              >
                <span>SHOP</span>
                <ChevronDown
                  className={`w-3.5 h-3.5 transition-transform duration-200 ${
                    isShopMenuOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>

              {/* Shop Mega Dropdown */}
              {isShopMenuOpen && (
                <div
                  className="absolute left-0 top-full mt-2 w-72 bg-white border border-neutral-200 shadow-xl p-5 z-50 animate-in fade-in slide-in-from-top-1 duration-150"
                  onMouseLeave={() => setIsShopMenuOpen(false)}
                >
                  <div className="text-[10px] tracking-luxury uppercase text-neutral-400 font-semibold mb-3">
                    Collections
                  </div>
                  <div className="flex flex-col gap-2.5 text-xs font-medium tracking-wide">
                    {['All Categories', 'Knitwear', 'Coats & Jackets', 'Shirts & Blouses', 'Trousers', 'Bags & Accessories'].map(
                      (cat) => (
                        <button
                          key={cat}
                          onClick={() => handleCategorySelect(cat === 'All Categories' ? 'All' : cat)}
                          className="text-left py-1 text-neutral-800 hover:text-neutral-500 hover:translate-x-1 transition-all"
                        >
                          {cat}
                        </button>
                      )
                    )}
                  </div>
                  <div className="mt-4 pt-3 border-t border-neutral-100 flex items-center justify-between text-[11px] text-neutral-500">
                    <span className="font-editorial italic">Autumn / Winter 2026</span>
                    <button
                      onClick={() => handleCategorySelect('All')}
                      className="underline hover:text-neutral-900"
                    >
                      View All
                    </button>
                  </div>
                </div>
              )}
            </div>

            <button
              onClick={() => handleNavClick('philosophy')}
              className="text-xs font-medium tracking-luxury uppercase text-neutral-800 hover:text-neutral-500 transition-colors whitespace-nowrap hidden sm:inline-block"
            >
              OUR WORLD
            </button>

            <button
              onClick={() => handleNavClick('the-edit')}
              className="text-xs font-medium tracking-luxury uppercase text-neutral-800 hover:text-neutral-500 transition-colors whitespace-nowrap hidden sm:inline-block"
            >
              THE EDIT
            </button>
          </nav>

          {/* Zone 2: Centered Brand Wordmark */}
          <div className="absolute left-1/2 -translate-x-1/2 pointer-events-auto">
            <Link
              href="/"
              onClick={() => haptic.playLuxuryClick()}
              className="text-2xl sm:text-3xl font-extrabold font-brand tracking-[0.35em] text-neutral-900 select-none hover:opacity-85 transition-opacity whitespace-nowrap"
            >
              ME+EM
            </Link>
          </div>

          {/* Zone 3: Actions & Affordances */}
          <div className="flex items-center gap-3 sm:gap-5">
            {/* Currency Selector */}
            <div className="relative hidden md:block">
              <button
                onClick={() => {
                  haptic.playSwatchTap();
                  setCurrencyMenuOpen(!currencyMenuOpen);
                }}
                className="text-xs font-medium tracking-wider text-neutral-600 hover:text-neutral-900 transition-colors px-2 py-1 rounded border border-transparent hover:border-neutral-200"
              >
                {currency}
              </button>
              {currencyMenuOpen && (
                <div className="absolute right-0 top-full mt-1 bg-white border border-neutral-200 shadow-md py-1 w-24 z-50 text-xs">
                  {(['GBP', 'USD', 'EUR', 'AUD'] as CurrencyCode[]).map((c) => (
                    <button
                      key={c}
                      onClick={() => {
                        setCurrency(c);
                        setCurrencyMenuOpen(false);
                      }}
                      className={`w-full text-left px-3 py-1.5 hover:bg-neutral-50 transition-colors ${
                        currency === c ? 'font-semibold text-neutral-900' : 'text-neutral-600'
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Tactile Audio Switcher */}
            <button
              onClick={toggleSound}
              title={isSoundMuted ? 'Enable Tactile Click Audio' : 'Mute Tactile Click Audio'}
              className="p-1.5 text-neutral-600 hover:text-neutral-900 transition-colors"
              aria-label="Toggle haptic sound feedback"
            >
              {isSoundMuted ? <VolumeX className="w-4 h-4 text-neutral-400" /> : <Volume2 className="w-4 h-4" />}
            </button>

            {/* Polyglot Backend Architecture Badge / Modal trigger */}
            <button
              onClick={() => {
                haptic.playSoftSnap();
                setIsBackendModalOpen(true);
              }}
              title="Polyglot Architecture Engine (Rust, C, Kotlin, JS)"
              className="group flex items-center gap-1.5 py-1 px-2.5 text-[11px] font-mono uppercase bg-neutral-100 hover:bg-neutral-200 text-neutral-800 transition-all border border-neutral-300 rounded"
            >
              <Cpu className="w-3.5 h-3.5 text-neutral-700 group-hover:rotate-12 transition-transform" />
              <span className="hidden lg:inline font-semibold">Engine</span>
              <span className="hidden xl:inline text-neutral-500">C · Rust · Kt</span>
            </button>

            {/* Search Button */}
            <button
              onClick={() => {
                haptic.playLuxuryClick();
                setIsSearchOpen(true);
              }}
              className="p-1.5 text-neutral-800 hover:text-neutral-500 transition-colors"
              aria-label="Search collection"
            >
              <Search className="w-4 h-4 sm:w-5 sm:h-5 stroke-[1.75]" />
            </button>

            {/* Wishlist Link / Counter */}
            <button
              onClick={() => {
                haptic.playLuxuryClick();
                handleNavClick('collection');
              }}
              className="relative p-1.5 text-neutral-800 hover:text-neutral-500 transition-colors"
              aria-label="Wishlist"
            >
              <Heart className="w-4 h-4 sm:w-5 sm:h-5 stroke-[1.75]" />
              {wishlist.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-neutral-900 text-white text-[9px] font-mono flex items-center justify-center font-bold">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Shopping Bag Button */}
            <button
              onClick={() => {
                haptic.playSoftSnap();
                setIsBagOpen(true);
              }}
              className="relative p-1.5 text-neutral-800 hover:text-neutral-500 transition-colors"
              aria-label="Shopping Bag"
            >
              <ShoppingBag className="w-4 h-4 sm:w-5 sm:h-5 stroke-[1.75]" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-neutral-900 text-white text-[9px] font-mono flex items-center justify-center font-bold">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>
    </>
  );
}
