'use client';

import React, { useState } from 'react';
import { ArrowRight, SlidersHorizontal } from 'lucide-react';
import { PRODUCTS, Product } from '@/lib/catalog';
import ProductCard from './ProductCard';
import { haptic } from '@/lib/audio';

interface NewArrivalsProps {
  selectedCategory: string;
  onSelectCategory: (cat: string) => void;
}

export default function NewArrivals({ selectedCategory, onSelectCategory }: NewArrivalsProps) {
  const [sortOption, setSortOption] = useState<'featured' | 'price-asc' | 'price-desc'>('featured');

  const filterTabs = [
    { label: 'All', value: 'All' },
    { label: 'Knitwear', value: 'Knitwear' },
    { label: 'Coats & Jackets', value: 'Coats & Jackets' },
    { label: 'Shirts & Blouses', value: 'Shirts & Blouses' },
    { label: 'Trousers', value: 'Trousers' },
    { label: 'Bags & Accessories', value: 'Bags & Accessories' },
  ];

  const filtered = PRODUCTS.filter((p) => {
    if (selectedCategory === 'All') return true;
    return p.category === selectedCategory;
  });

  const sorted = [...filtered].sort((a, b) => {
    if (sortOption === 'price-asc') return a.price - b.price;
    if (sortOption === 'price-desc') return b.price - a.price;
    return 0; // featured order
  });

  return (
    <section id="collection" className="max-w-[1536px] mx-auto px-4 sm:px-8 py-12 sm:py-16">
      {/* Editorial Header matching screenshot: "NEW ARRIVALS ───" and "VIEW ALL →" */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-neutral-200 gap-4">
        <div className="flex items-center gap-4">
          <h2 className="text-xl sm:text-2xl font-light tracking-[0.2em] uppercase text-neutral-900 font-brand">
            NEW ARRIVALS
          </h2>
          <span className="w-16 h-px bg-neutral-400 inline-block" />
        </div>

        <div className="flex items-center gap-6">
          {/* Sort Selector */}
          <div className="flex items-center gap-2 text-xs text-neutral-600 font-medium">
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <select
              value={sortOption}
              onChange={(e) => {
                haptic.playSwatchTap();
                setSortOption(e.target.value as 'featured' | 'price-asc' | 'price-desc');
              }}
              className="bg-transparent border-none text-xs font-medium focus:ring-0 cursor-pointer pr-4 text-neutral-800"
            >
              <option value="featured">Featured Order</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
            </select>
          </div>

          <button
            onClick={() => {
              haptic.playLuxuryClick();
              onSelectCategory('All');
            }}
            className="group flex items-center gap-1.5 text-xs font-semibold tracking-luxury uppercase text-neutral-900 hover:text-neutral-500 transition-colors"
          >
            <span>VIEW ALL</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>

      {/* Interactive Category Segmented Control */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-6">
        {filterTabs.map((tab) => {
          const isActive = selectedCategory === tab.value;
          return (
            <button
              key={tab.value}
              onClick={() => {
                haptic.playLuxuryClick();
                onSelectCategory(tab.value);
              }}
              className={`px-4 py-2 text-xs font-medium tracking-luxury uppercase whitespace-nowrap transition-all duration-200 ${
                isActive
                  ? 'bg-neutral-900 text-white shadow-xs'
                  : 'bg-white text-neutral-700 hover:bg-neutral-100 border border-neutral-200/80'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Product Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 sm:gap-8 pt-4">
        {sorted.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </section>
  );
}
