'use client';

import React, { useState } from 'react';
import { ArrowRight, Check, MapPin, Mail, Phone, Cpu } from 'lucide-react';
import { useStore } from '@/lib/store';
import { haptic } from '@/lib/audio';

export default function Footer() {
  const { setIsBackendModalOpen } = useStore();
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    haptic.playBagAdd();
    setSubscribed(true);
  };

  return (
    <footer className="w-full bg-[#111111] text-[#FAF8F5] border-t border-neutral-800 pt-16 pb-12">
      <div className="max-w-[1536px] mx-auto px-4 sm:px-8 space-y-16">
        
        {/* Top Newsletter & Brand Statement */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 pb-12 border-b border-neutral-800">
          <div className="lg:col-span-5 space-y-4">
            <div className="text-2xl sm:text-3xl font-extrabold font-brand tracking-[0.35em] text-white">
              ME+EM
            </div>
            <p className="text-xs sm:text-sm text-neutral-400 font-light leading-relaxed max-w-md">
              Intelligent style for modern living. Designed in London, crafted with the world’s finest mills in Scotland and Italy, and delivered directly to you.
            </p>
            <div className="pt-2 flex items-center gap-4 text-xs text-neutral-400">
              <span className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-neutral-300" />
                London W1 & Nationwide Boutiques
              </span>
            </div>
          </div>

          <div className="lg:col-span-7 space-y-3">
            <span className="text-[11px] font-semibold tracking-luxury uppercase text-neutral-300">
              Receive The Edit & Private Previews
            </span>
            <p className="text-xs text-neutral-400 font-light">
              Be the first to view new seasonal drops, styling masterclasses, and private collection previews.
            </p>
            {subscribed ? (
              <div className="p-3 bg-neutral-900 border border-neutral-700 rounded-xs flex items-center gap-2 text-xs text-emerald-400 font-medium">
                <Check className="w-4 h-4" />
                <span>Thank you. You have been added to the ME+EM Private Registry.</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex gap-2 max-w-md pt-1">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email address..."
                  className="flex-1 bg-neutral-900 border border-neutral-700 px-4 py-2.5 text-xs text-white placeholder:text-neutral-500 focus:outline-hidden focus:border-white rounded-xs"
                  required
                />
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-white text-neutral-950 text-xs font-semibold tracking-luxury uppercase hover:bg-neutral-200 transition-colors whitespace-nowrap rounded-xs active:scale-95"
                >
                  Join
                </button>
              </form>
            )}
          </div>
        </div>

        {/* 4 Navigation Columns */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-xs font-light text-neutral-400 leading-relaxed">
          <div className="space-y-3">
            <h4 className="text-white font-medium text-xs tracking-luxury uppercase">
              The Collection
            </h4>
            <ul className="space-y-2">
              <li><a href="#collection" className="hover:text-white transition-colors">Scottish Cashmere Knitwear</a></li>
              <li><a href="#collection" className="hover:text-white transition-colors">Tailored Wool Blazers</a></li>
              <li><a href="#collection" className="hover:text-white transition-colors">19-Momme Silk Blouses</a></li>
              <li><a href="#collection" className="hover:text-white transition-colors">Wide-Leg Flattering Trousers</a></li>
              <li><a href="#collection" className="hover:text-white transition-colors">Pebbled Calfskin Day Totes</a></li>
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="text-white font-medium text-xs tracking-luxury uppercase">
              Our World
            </h4>
            <ul className="space-y-2">
              <li><a href="#philosophy" className="hover:text-white transition-colors">The 7 Rules of Intelligent Style</a></li>
              <li><a href="#the-edit" className="hover:text-white transition-colors">The Autumn / Winter Edit</a></li>
              <li><span className="text-neutral-500">Savile Row Tailoring Legacy</span></li>
              <li><span className="text-neutral-500">Biella & Scottish Mill Partners</span></li>
              <li><span className="text-neutral-500">B-Corp Sustainability Standards</span></li>
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="text-white font-medium text-xs tracking-luxury uppercase">
              Client Concierge
            </h4>
            <ul className="space-y-2">
              <li><span className="text-neutral-500">Complimentary Global Express (Over £250)</span></li>
              <li><span className="text-neutral-500">30-Day Extended Complimentary Returns</span></li>
              <li><span className="text-neutral-500">London White-Glove Same-Day Delivery</span></li>
              <li><span className="text-neutral-500">Bespoke Size Fitting Consultation</span></li>
              <li><span className="text-neutral-500">Mayfair VIP Client Suite</span></li>
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="text-white font-medium text-xs tracking-luxury uppercase">
              Engineering Architecture
            </h4>
            <p className="text-[11px] text-neutral-400 font-light">
              Engineered using a high-performance polyglot backend:
            </p>
            <div className="space-y-1.5 font-mono text-[11px] text-neutral-300">
              <div>🦀 Rust: Biometric Sizing Engine</div>
              <div>⚡ C: Textile KES-FB Tensor Dynamics</div>
              <div>🎯 Kotlin: Order Coroutine Pipeline</div>
              <div>🌐 JS: Next.js 15 & Web Audio Haptics</div>
            </div>
            <button
              onClick={() => {
                haptic.playSoftSnap();
                setIsBackendModalOpen(true);
              }}
              className="mt-2 text-xs text-emerald-400 hover:text-emerald-300 underline flex items-center gap-1 font-mono"
            >
              <Cpu className="w-3.5 h-3.5" />
              <span>Inspect Live Backend</span>
            </button>
          </div>
        </div>

        {/* Bottom Bar: Copyright & Terms */}
        <div className="pt-8 border-t border-neutral-800 flex flex-col sm:flex-row items-center justify-between text-[11px] text-neutral-500 gap-4">
          <div>
            © 2026 ME+EM London Ltd. All rights reserved. Registered in England & Wales.
          </div>
          <div className="flex items-center gap-6">
            <span>Privacy Policy</span>
            <span>Terms of Service</span>
            <span>Accessibility</span>
            <span>Modern Slavery Act</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
