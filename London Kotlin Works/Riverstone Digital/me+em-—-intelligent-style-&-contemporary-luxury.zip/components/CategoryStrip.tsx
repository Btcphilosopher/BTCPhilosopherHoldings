'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';
import { CATEGORIES } from '@/lib/catalog';
import { haptic } from '@/lib/audio';

interface CategoryStripProps {
  activeCategory: string;
  onSelectCategory: (categoryName: string) => void;
}

export default function CategoryStrip({ activeCategory, onSelectCategory }: CategoryStripProps) {
  return (
    <section className="max-w-[1536px] mx-auto px-4 sm:px-8 py-6 sm:py-8">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
        {CATEGORIES.map((cat) => {
          const isSelected = activeCategory === cat.slug;
          return (
            <button
              key={cat.id}
              onClick={() => {
                haptic.playLuxuryClick();
                onSelectCategory(cat.slug);
                const el = document.getElementById('collection');
                if (el) {
                  el.scrollIntoView({ behavior: 'smooth' });
                }
              }}
              className={`group relative h-40 sm:h-44 md:h-48 overflow-hidden rounded-xs text-left transition-all duration-300 focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-neutral-900 ${
                isSelected ? 'ring-2 ring-neutral-900 shadow-md' : 'border border-neutral-200'
              }`}
            >
              {/* Category Image */}
              <Image
                src={cat.image}
                alt={cat.name}
                fill
                sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 20vw"
                referrerPolicy="no-referrer"
                className="object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out"
              />

              {/* Bottom Contrast Scrim */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent group-hover:from-black/85 transition-colors" />

              {/* Category Label with Arrow */}
              <div className="absolute bottom-3 sm:bottom-4 left-3 sm:left-4 right-3 sm:right-4 flex items-center justify-between text-white">
                <span className="text-[11px] sm:text-xs font-semibold tracking-luxury uppercase">
                  {cat.name}
                </span>
                <ArrowRight className="w-3.5 h-3.5 text-white/90 group-hover:translate-x-1 transition-transform" />
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
}
