'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';
import { haptic } from '@/lib/audio';

export default function Hero({ onShopClick }: { onShopClick: () => void }) {
  return (
    <section className="relative w-full overflow-hidden bg-neutral-900 text-white min-h-[580px] sm:min-h-[640px] lg:min-h-[720px] flex items-center">
      {/* Hero Photography Asset */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/extracted/hero_full.webp"
          alt="ME+EM Autumn Winter Collection — Tailored Suits and Modern Knitwear"
          fill
          priority
          referrerPolicy="no-referrer"
          className="object-cover object-top sm:object-center brightness-[0.92]"
        />
        {/* Measured scrim to ensure high-contrast legibility */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/35 to-transparent sm:via-black/20" />
      </div>

      {/* Hero Content Container */}
      <div className="relative z-10 max-w-[1536px] w-full mx-auto px-6 sm:px-12 lg:px-16 py-20 flex flex-col justify-between min-h-[540px] sm:min-h-[600px]">
        {/* Editorial Text Overlay */}
        <div className="max-w-xl space-y-4 sm:space-y-6 pt-8 sm:pt-12">
          {/* Spaced Kicker */}
          <div className="text-[11px] sm:text-xs font-semibold tracking-[0.25em] uppercase text-neutral-300">
            TIMELESS STYLE. MODERN LIVING.
          </div>

          {/* Main Headline */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-light font-editorial leading-[1.08] tracking-tight text-white text-balance">
            Effortless Elegance for Everyday Life
          </h1>

          {/* Subtitle */}
          <p className="text-sm sm:text-base text-neutral-200 leading-relaxed font-normal max-w-md">
            ME+EM creates modern, versatile pieces for women who do more. Designed in London. Worn everywhere.
          </p>

          {/* CTA Button */}
          <div className="pt-2">
            <button
              onClick={() => {
                haptic.playLuxuryClick();
                onShopClick();
              }}
              className="group inline-flex items-center gap-3 px-6 py-3.5 text-xs font-medium tracking-luxury uppercase text-white border border-white/80 bg-black/20 backdrop-blur-xs hover:bg-white hover:text-neutral-950 transition-all duration-200 active:scale-[0.98]"
            >
              <span>SHOP NEW ARRIVALS</span>
              <ArrowRight className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-1" />
            </button>
          </div>
        </div>

        {/* Season Indicator Tag */}
        <div className="self-end pt-8 flex items-center gap-4 text-xs font-medium tracking-luxury uppercase text-neutral-300">
          <span className="w-12 h-px bg-neutral-400/60 inline-block" />
          <span>AUTUMN / WINTER 2026</span>
        </div>
      </div>
    </section>
  );
}
