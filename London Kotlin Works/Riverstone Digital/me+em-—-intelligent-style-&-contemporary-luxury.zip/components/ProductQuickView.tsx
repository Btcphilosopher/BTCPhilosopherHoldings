'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { X, Sparkles, Cpu, Layers, Heart, ShieldCheck, RefreshCw } from 'lucide-react';
import { Product } from '@/lib/catalog';
import { useStore } from '@/lib/store';
import { haptic } from '@/lib/audio';

interface QuickViewProps {
  product: Product;
  onClose: () => void;
}

export default function ProductQuickView({ product, onClose }: QuickViewProps) {
  const { formatPrice, addToCart, toggleWishlist, isWishlisted } = useStore();

  const [selectedColor, setSelectedColor] = useState(product.colors[0]?.name || '');
  const [selectedSize, setSelectedSize] = useState(product.sizes[1] || product.sizes[0]);
  const [quantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'details' | 'rust-sizing' | 'c-textile'>('details');

  // Rust Sizing interactive state
  const [bustCm, setBustCm] = useState(88);
  const [waistCm, setWaistCm] = useState(70);
  const [hipCm, setHipCm] = useState(96);
  const [heightCm, setHeightCm] = useState(168);
  const [preference, setPreference] = useState<'Tailored' | 'Classic' | 'Relaxed'>('Classic');
  const [rustLoading, setRustLoading] = useState(false);
  const [rustResult, setRustResult] = useState<{
    recommendedUkSize: number;
    fitConfidencePct: number;
    drapeTensionIndex: number;
    legLengthRecommendation: string;
    stylingGuidance: string;
    executionMicroseconds: number;
  }>({
    recommendedUkSize: 10,
    fitConfidencePct: 96.8,
    drapeTensionIndex: 0.94,
    legLengthRecommendation: 'Regular (Inseam: 80cm / 31.5in)',
    stylingGuidance: 'The signature ME+EM flattering fit. True to size with comfortable ease.',
    executionMicroseconds: 68,
  });

  // C Textile Physics state
  const [cTextileLoading, setCTextileLoading] = useState(false);
  const [cTextileResult, setCTextileResult] = useState<{
    fabricDescriptor: string;
    drapeCoefficient: number;
    wrinkleRecoveryAngleDeg: number;
    tactileSoftnessScore: number;
    breathabilityCfm: number;
    executionMicroseconds: number;
  }>({
    fabricDescriptor: product.fabric,
    drapeCoefficient: product.fiberType.includes('SILK') ? 0.28 : product.fiberType.includes('CASHMERE') ? 0.38 : 0.52,
    wrinkleRecoveryAngleDeg: 168.0,
    tactileSoftnessScore: 9.9,
    breathabilityCfm: 82.5,
    executionMicroseconds: 42,
  });

  // Trigger Rust calculation
  const calculateRustFit = async () => {
    setRustLoading(true);
    try {
      const res = await fetch('/api/backend/sizing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bust_cm: bustCm,
          waist_cm: waistCm,
          hip_cm: hipCm,
          height_cm: heightCm,
          preference,
          category: product.category.replace(/\s+/g, ''),
        }),
      });
      const data = await res.json();
      if (data.recommendation) {
        setRustResult({
          ...data.recommendation,
          executionMicroseconds: data.executionMicroseconds,
        });
        setSelectedSize(`UK ${data.recommendation.recommendedUkSize}`);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setRustLoading(false);
    }
  };

  // Trigger C physics computation
  const calculateCTextile = async () => {
    setCTextileLoading(true);
    try {
      const res = await fetch('/api/backend/textile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fiberType: product.fiberType,
          gsm: product.gsm,
        }),
      });
      const data = await res.json();
      if (data.tensor) {
        setCTextileResult({
          fabricDescriptor: data.spec.fabricDescriptor,
          ...data.tensor,
          executionMicroseconds: data.executionMicroseconds,
        });
      }
    } catch (e) {
      console.error(e);
    } finally {
      setCTextileLoading(false);
    }
  };

  const handleAdd = () => {
    haptic.playBagAdd();
    addToCart(product, selectedSize, selectedColor, quantity);
    onClose();
  };

  const wishlisted = isWishlisted(product.id);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-4xl max-h-[92vh] overflow-y-auto bg-[#FAF8F5] border border-neutral-300 shadow-2xl flex flex-col md:flex-row rounded-xs"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={() => {
            haptic.playSoftSnap();
            onClose();
          }}
          className="absolute top-4 right-4 z-20 p-2 bg-white/90 hover:bg-white text-neutral-800 rounded-full shadow-xs transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Left: Product Imagery Showcase */}
        <div className="w-full md:w-1/2 relative min-h-[380px] md:min-h-[520px] bg-neutral-100">
          <Image
            src={product.image}
            alt={product.name}
            fill
            sizes="(max-width: 768px) 100vw, 50vw"
            referrerPolicy="no-referrer"
            className="object-cover object-top"
          />
          {product.badge && (
            <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-xs px-3 py-1 text-[10px] tracking-luxury uppercase font-medium text-neutral-900 border border-neutral-200 shadow-xs">
              {product.badge}
            </div>
          )}
        </div>

        {/* Right: Specifications & Interactive Tabs */}
        <div className="w-full md:w-1/2 p-6 sm:p-8 flex flex-col justify-between space-y-6">
          <div>
            {/* Header info */}
            <div className="flex items-center justify-between gap-2 text-xs tracking-luxury uppercase text-neutral-500 font-medium mb-1">
              <span>{product.category}</span>
              <span>{product.fabric}</span>
            </div>

            <h2 className="text-xl sm:text-2xl font-light font-editorial text-neutral-900 leading-tight">
              {product.name}
            </h2>

            <div className="mt-2 text-lg font-semibold tabular-nums text-neutral-900">
              {formatPrice(product.price)}
            </div>

            {/* Interactive Tab Switcher */}
            <div className="flex border-b border-neutral-200 mt-5 text-xs font-medium tracking-wide">
              <button
                onClick={() => {
                  haptic.playLuxuryClick();
                  setActiveTab('details');
                }}
                className={`pb-2.5 px-3 border-b-2 transition-colors ${
                  activeTab === 'details'
                    ? 'border-neutral-900 text-neutral-900 font-semibold'
                    : 'border-transparent text-neutral-500 hover:text-neutral-800'
                }`}
              >
                Intelligent Style
              </button>
              <button
                onClick={() => {
                  haptic.playLuxuryClick();
                  setActiveTab('rust-sizing');
                }}
                className={`pb-2.5 px-3 border-b-2 flex items-center gap-1.5 transition-colors ${
                  activeTab === 'rust-sizing'
                    ? 'border-neutral-900 text-neutral-900 font-semibold'
                    : 'border-transparent text-neutral-500 hover:text-neutral-800'
                }`}
              >
                <Cpu className="w-3.5 h-3.5 text-neutral-600" />
                <span>Rust Fit Matrix</span>
              </button>
              <button
                onClick={() => {
                  haptic.playLuxuryClick();
                  setActiveTab('c-textile');
                }}
                className={`pb-2.5 px-3 border-b-2 flex items-center gap-1.5 transition-colors ${
                  activeTab === 'c-textile'
                    ? 'border-neutral-900 text-neutral-900 font-semibold'
                    : 'border-transparent text-neutral-500 hover:text-neutral-800'
                }`}
              >
                <Layers className="w-3.5 h-3.5 text-neutral-600" />
                <span>C Drape Tensor</span>
              </button>
            </div>

            {/* Tab 1: Product Overview & ME+EM Philosophy */}
            {activeTab === 'details' && (
              <div className="pt-4 space-y-4 text-xs text-neutral-600 leading-relaxed">
                <p>{product.description}</p>
                <div className="bg-white p-3.5 border border-neutral-200 rounded-xs space-y-1.5">
                  <div className="text-[10px] tracking-luxury uppercase font-semibold text-neutral-900 flex items-center gap-1.5">
                    <Sparkles className="w-3 h-3 text-amber-700" />
                    <span>Intelligent Style Rule</span>
                  </div>
                  <p className="text-neutral-700 italic">{product.intelligentStyleRule}</p>
                </div>
                <div className="flex items-center gap-2 text-neutral-700">
                  <ShieldCheck className="w-4 h-4 text-neutral-900" />
                  <span>Flatter Guarantee: {product.flatterFeature}</span>
                </div>
              </div>
            )}

            {/* Tab 2: Rust Sizing Engine */}
            {activeTab === 'rust-sizing' && (
              <div className="pt-4 space-y-4 text-xs">
                <div className="bg-neutral-900 text-neutral-100 p-3 rounded-xs font-mono text-[11px] flex items-center justify-between">
                  <span>Engine: me_em_sizing_engine.rs</span>
                  <span className="text-emerald-400">
                    {rustLoading ? 'Computing...' : `${rustResult.executionMicroseconds}µs`}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] uppercase font-semibold tracking-wider text-neutral-500">
                      Bust: {bustCm} cm
                    </label>
                    <input
                      type="range"
                      min="75"
                      max="115"
                      value={bustCm}
                      onChange={(e) => setBustCm(Number(e.target.value))}
                      className="w-full accent-neutral-900"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-semibold tracking-wider text-neutral-500">
                      Waist: {waistCm} cm
                    </label>
                    <input
                      type="range"
                      min="60"
                      max="100"
                      value={waistCm}
                      onChange={(e) => setWaistCm(Number(e.target.value))}
                      className="w-full accent-neutral-900"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-semibold tracking-wider text-neutral-500">
                      Hip: {hipCm} cm
                    </label>
                    <input
                      type="range"
                      min="80"
                      max="125"
                      value={hipCm}
                      onChange={(e) => setHipCm(Number(e.target.value))}
                      className="w-full accent-neutral-900"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-semibold tracking-wider text-neutral-500">
                      Height: {heightCm} cm
                    </label>
                    <input
                      type="range"
                      min="150"
                      max="185"
                      value={heightCm}
                      onChange={(e) => setHeightCm(Number(e.target.value))}
                      className="w-full accent-neutral-900"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <div className="flex items-center gap-1">
                    {(['Tailored', 'Classic', 'Relaxed'] as const).map((pref) => (
                      <button
                        key={pref}
                        onClick={() => setPreference(pref)}
                        className={`px-2.5 py-1 text-[11px] rounded-xs border transition-colors ${
                          preference === pref
                            ? 'bg-neutral-900 text-white border-neutral-900 font-semibold'
                            : 'bg-white text-neutral-600 border-neutral-200 hover:border-neutral-400'
                        }`}
                      >
                        {pref}
                      </button>
                    ))}
                  </div>

                  <button
                    onClick={calculateRustFit}
                    disabled={rustLoading}
                    className="flex items-center gap-1 px-3 py-1 bg-neutral-900 text-white text-[11px] font-mono rounded-xs hover:bg-neutral-800 transition-colors"
                  >
                    <RefreshCw className={`w-3 h-3 ${rustLoading ? 'animate-spin' : ''}`} />
                    <span>Recalculate Fit</span>
                  </button>
                </div>

                <div className="bg-white p-3 border border-neutral-200 rounded-xs space-y-1.5 text-neutral-800">
                  <div className="flex items-center justify-between font-semibold">
                    <span>Recommended Size: UK {rustResult.recommendedUkSize}</span>
                    <span className="text-emerald-700 font-mono">
                      {rustResult.fitConfidencePct}% Confidence
                    </span>
                  </div>
                  <div className="text-[11px] text-neutral-500">
                    Leg/Hem: {rustResult.legLengthRecommendation}
                  </div>
                  <p className="text-[11px] text-neutral-600 italic">
                    {rustResult.stylingGuidance}
                  </p>
                </div>
              </div>
            )}

            {/* Tab 3: C Textile Physics */}
            {activeTab === 'c-textile' && (
              <div className="pt-4 space-y-3.5 text-xs">
                <div className="bg-neutral-900 text-neutral-100 p-3 rounded-xs font-mono text-[11px] flex items-center justify-between">
                  <span>Engine: me_em_compute_drape_tensor (C99)</span>
                  <div className="flex items-center gap-2">
                    <span className="text-emerald-400">
                      {cTextileLoading ? 'Computing...' : `${cTextileResult.executionMicroseconds}µs`}
                    </span>
                    <button
                      onClick={calculateCTextile}
                      title="Recompute C tensor"
                      className="text-neutral-400 hover:text-white"
                    >
                      <RefreshCw className={`w-3 h-3 ${cTextileLoading ? 'animate-spin' : ''}`} />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 text-neutral-800">
                  <div className="bg-white p-3 border border-neutral-200 rounded-xs">
                    <div className="text-[10px] uppercase tracking-wider text-neutral-400 font-semibold">
                      Cusick Drape Index
                    </div>
                    <div className="text-base font-semibold font-mono mt-1">
                      {cTextileResult.drapeCoefficient}
                    </div>
                    <div className="text-[10px] text-neutral-500">Fluid low-resistance flow</div>
                  </div>
                  <div className="bg-white p-3 border border-neutral-200 rounded-xs">
                    <div className="text-[10px] uppercase tracking-wider text-neutral-400 font-semibold">
                      Wrinkle Recovery
                    </div>
                    <div className="text-base font-semibold font-mono mt-1">
                      {cTextileResult.wrinkleRecoveryAngleDeg}°
                    </div>
                    <div className="text-[10px] text-neutral-500">Resilient travel memory</div>
                  </div>
                  <div className="bg-white p-3 border border-neutral-200 rounded-xs">
                    <div className="text-[10px] uppercase tracking-wider text-neutral-400 font-semibold">
                      Kawabata Softness
                    </div>
                    <div className="text-base font-semibold font-mono mt-1">
                      {cTextileResult.tactileSoftnessScore} / 10.0
                    </div>
                    <div className="text-[10px] text-neutral-500">Superior skin-contact feel</div>
                  </div>
                  <div className="bg-white p-3 border border-neutral-200 rounded-xs">
                    <div className="text-[10px] uppercase tracking-wider text-neutral-400 font-semibold">
                      Air Permeability
                    </div>
                    <div className="text-base font-semibold font-mono mt-1">
                      {cTextileResult.breathabilityCfm} CFM
                    </div>
                    <div className="text-[10px] text-neutral-500">Thermoregulating comfort</div>
                  </div>
                </div>
              </div>
            )}

            {/* Color Swatch Picker */}
            <div className="mt-5 space-y-2">
              <label className="text-[11px] font-semibold tracking-luxury uppercase text-neutral-700">
                Colour: <span className="text-neutral-900 font-normal">{selectedColor}</span>
              </label>
              <div className="flex items-center gap-2">
                {product.colors.map((c) => (
                  <button
                    key={c.name}
                    onClick={() => {
                      haptic.playSwatchTap();
                      setSelectedColor(c.name);
                    }}
                    className={`w-6 h-6 rounded-full border transition-all ${
                      selectedColor === c.name
                        ? 'ring-2 ring-neutral-900 scale-110 border-white shadow-xs'
                        : 'border-neutral-300 hover:scale-105'
                    }`}
                    style={{ backgroundColor: c.hex }}
                    title={c.name}
                  />
                ))}
              </div>
            </div>

            {/* Size Picker */}
            <div className="mt-4 space-y-2">
              <div className="flex items-center justify-between text-[11px] font-semibold tracking-luxury uppercase text-neutral-700">
                <span>Select Size</span>
                <button
                  onClick={() => setActiveTab('rust-sizing')}
                  className="text-neutral-500 hover:text-neutral-900 underline"
                >
                  Size Guide & Drape
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((s) => (
                  <button
                    key={s}
                    onClick={() => {
                      haptic.playSwatchTap();
                      setSelectedSize(s);
                    }}
                    className={`px-3 py-2 text-xs font-medium tracking-wide transition-all ${
                      selectedSize === s
                        ? 'bg-neutral-900 text-white shadow-xs'
                        : 'bg-white text-neutral-800 border border-neutral-200 hover:border-neutral-400'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Bottom Action Section */}
          <div className="pt-4 border-t border-neutral-200 flex items-center gap-3">
            <button
              onClick={handleAdd}
              className="flex-1 py-3.5 px-6 bg-neutral-900 text-white text-xs font-semibold tracking-luxury uppercase hover:bg-neutral-800 transition-colors shadow-md active:scale-[0.98] flex items-center justify-center gap-2"
            >
              <span>ADD TO BAG</span>
              <span className="opacity-40">·</span>
              <span className="tabular-nums">{formatPrice(product.price * quantity)}</span>
            </button>

            <button
              onClick={() => toggleWishlist(product.id)}
              aria-label="Toggle Wishlist"
              className={`p-3.5 border transition-colors rounded-xs ${
                wishlisted
                  ? 'bg-neutral-900 text-white border-neutral-900'
                  : 'bg-white text-neutral-800 border-neutral-300 hover:border-neutral-900'
              }`}
            >
              <Heart className={`w-4 h-4 ${wishlisted ? 'fill-white' : ''}`} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
