'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { ArrowRight, ShoppingBag } from 'lucide-react';
import { useStore } from '@/lib/store';
import { PRODUCTS } from '@/lib/catalog';
import { haptic } from '@/lib/audio';

export default function TheEditLookbook() {
  const { setQuickViewProduct, addToCart, formatPrice } = useStore();

  const looks = [
    {
      id: 'look-1',
      title: 'The Modern Monochrome Tailoring',
      tagline: 'Effortless Authority in Pure Wool & Cashmere',
      image: '/extracted/look_cream_tailoring.webp',
      description: 'Clean architectural lines paired with soft tactile Scottish knitwear. Cut for comfort and commanding presence.',
      items: [
        PRODUCTS.find((p) => p.id === 'coat-01')!,
        PRODUCTS.find((p) => p.id === 'knit-01')!,
        PRODUCTS.find((p) => p.id === 'trouser-01')!,
      ].filter(Boolean),
    },
    {
      id: 'look-2',
      title: 'The Midnight City Uniform',
      tagline: 'Architectural Overcoat & Turtleneck Silhouette',
      image: '/extracted/look_navy_coat.webp',
      description: 'British Melton wool maxi coat layered over textured rib knitwear. Built for cold morning commutes and gallery evenings.',
      items: [
        PRODUCTS.find((p) => p.id === 'coat-02')!,
        PRODUCTS.find((p) => p.id === 'knit-02')!,
        PRODUCTS.find((p) => p.id === 'bag-01')!,
      ].filter(Boolean),
    },
  ];

  const [activeLookIdx, setActiveLookIdx] = useState(0);
  const activeLook = looks[activeLookIdx];

  return (
    <section id="the-edit" className="max-w-[1536px] mx-auto px-4 sm:px-8 py-16 sm:py-24">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-8 border-b border-neutral-200 gap-4">
        <div>
          <div className="text-[11px] font-semibold tracking-[0.25em] uppercase text-neutral-500">
            EDITORIAL CURATION
          </div>
          <h2 className="text-2xl sm:text-3xl font-light font-editorial text-neutral-900 mt-1">
            The Edit: 3 Ways to Style
          </h2>
        </div>

        {/* Look Switcher Buttons */}
        <div className="flex items-center gap-2">
          {looks.map((l, idx) => (
            <button
              key={l.id}
              onClick={() => {
                haptic.playLuxuryClick();
                setActiveLookIdx(idx);
              }}
              className={`px-4 py-2 text-xs font-semibold tracking-luxury uppercase transition-all ${
                activeLookIdx === idx
                  ? 'bg-neutral-900 text-white'
                  : 'bg-white text-neutral-700 border border-neutral-200 hover:bg-neutral-100'
              }`}
            >
              Look 0{idx + 1}
            </button>
          ))}
        </div>
      </div>

      {/* Main Split Layout: Look Image & Shop the Look Coordinates */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 mt-8 items-stretch">
        
        {/* Left: Campaign Photograph */}
        <div className="lg:col-span-7 relative min-h-[480px] sm:min-h-[580px] bg-neutral-100 rounded-xs overflow-hidden">
          <Image
            src={activeLook.image}
            alt={activeLook.title}
            fill
            sizes="(max-width: 1024px) 100vw, 60vw"
            referrerPolicy="no-referrer"
            className="object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-6 sm:p-10 text-white">
            <span className="text-[10px] tracking-luxury uppercase font-semibold text-neutral-300">
              {activeLook.tagline}
            </span>
            <h3 className="text-2xl sm:text-3xl font-light font-editorial mt-1">
              {activeLook.title}
            </h3>
            <p className="text-xs sm:text-sm text-neutral-200 mt-2 max-w-lg font-light leading-relaxed">
              {activeLook.description}
            </p>
          </div>
        </div>

        {/* Right: "Shop The Look" itemized coordinates */}
        <div className="lg:col-span-5 flex flex-col justify-between space-y-4">
          <div>
            <div className="text-xs tracking-luxury uppercase font-semibold text-neutral-900 pb-3 border-b border-neutral-200 flex items-center justify-between">
              <span>Pieces in this Look</span>
              <span className="text-neutral-500 font-mono text-[11px]">{activeLook.items.length} Items</span>
            </div>

            <div className="divide-y divide-neutral-200">
              {activeLook.items.map((item) => (
                <div key={item.id} className="py-4 flex items-center gap-4 group">
                  <div className="relative w-16 h-20 bg-neutral-100 shrink-0 overflow-hidden rounded-xs">
                    <Image
                      src={item.image}
                      alt={item.name}
                      fill
                      sizes="64px"
                      referrerPolicy="no-referrer"
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-[10px] tracking-luxury uppercase text-neutral-500 font-medium">
                      {item.category}
                    </div>
                    <h4
                      onClick={() => {
                        haptic.playLuxuryClick();
                        setQuickViewProduct(item);
                      }}
                      className="text-xs font-semibold text-neutral-900 truncate hover:text-neutral-600 cursor-pointer mt-0.5"
                    >
                      {item.name}
                    </h4>
                    <div className="text-xs font-medium tabular-nums text-neutral-800 mt-1">
                      {formatPrice(item.price)}
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      haptic.playBagAdd();
                      addToCart(item, item.sizes[1] || item.sizes[0], item.colors[0]?.name || 'Classic');
                    }}
                    className="p-2.5 bg-neutral-100 hover:bg-neutral-900 hover:text-white text-neutral-800 transition-colors rounded-xs shrink-0"
                    title="Add piece to bag"
                    aria-label={`Add ${item.name} to bag`}
                  >
                    <ShoppingBag className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Bundle Action */}
          <div className="bg-white p-5 border border-neutral-200 rounded-xs space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="text-neutral-600 font-medium">Complete Capsule Price:</span>
              <span className="font-semibold text-sm tabular-nums text-neutral-900">
                {formatPrice(activeLook.items.reduce((acc, i) => acc + i.price, 0))}
              </span>
            </div>
            <button
              onClick={() => {
                haptic.playBagAdd();
                activeLook.items.forEach((item) => {
                  addToCart(item, item.sizes[1] || item.sizes[0], item.colors[0]?.name || 'Classic');
                });
              }}
              className="w-full py-3 px-4 bg-neutral-900 text-white text-xs font-semibold tracking-luxury uppercase hover:bg-neutral-800 transition-colors flex items-center justify-center gap-2 active:scale-[0.98]"
            >
              <span>ADD ENTIRE LOOK TO BAG</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </section>
  );
}
