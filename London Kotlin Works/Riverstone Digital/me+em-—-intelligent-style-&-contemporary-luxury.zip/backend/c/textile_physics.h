/**
 * ME+EM London - Luxury Textile Dynamics & Drape Physics Engine
 * Written in ANSI C (C99) for sub-millisecond tensor computation and cache-optimal memory layout.
 *
 * Copyright (c) 2026 ME+EM London. All rights reserved.
 */

#ifndef ME_EM_TEXTILE_PHYSICS_H
#define ME_EM_TEXTILE_PHYSICS_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    FIBER_SCOTTISH_CASHMERE_2PLY,
    FIBER_ITALIAN_VIRGIN_WOOL_120S,
    FIBER_MULBERRY_SILK_CREPE_19MOMME,
    FIBER_ORGANIC_ITALIAN_COTTON_POPLIN,
    FIBER_DOUBLE_FACED_SHEARLING
} FiberComposition;

typedef struct {
    FiberComposition fiber_type;
    double gsm_weight;          // Grams per Square Meter
    double yarn_count_warp;     // Ne or Nm count
    double yarn_count_weft;
    double weave_density_ends;  // Ends per inch
    double weave_density_picks; // Picks per inch
    double elastane_percentage; // 0.0 to 10.0%
} TextileSpecification;

typedef struct {
    double drape_coefficient;       // Cusick drape factor (0.0 to 1.0)
    double bending_rigidity_warp;    // mg * cm
    double bending_rigidity_weft;    // mg * cm
    double wrinkle_recovery_angle;  // Degrees (0 to 180)
    double breathability_cfm;       // Air permeability (ft3/min/ft2)
    double thermal_resistance_clo;  // Insulation rating (Clo)
    double tactile_softness_score;  // Kawabata KES-FB scale (0.0 to 10.0)
    uint64_t compute_cycles;
    char fabric_descriptor[64];
} DrapeTensorResult;

/**
 * Computes drape tensor metrics using the Kawabata Evaluation System (KES-FB) formulation.
 */
DrapeTensorResult me_em_compute_drape_tensor(const TextileSpecification* spec);

#ifdef __cplusplus
}
#endif

#endif // ME_EM_TEXTILE_PHYSICS_H
