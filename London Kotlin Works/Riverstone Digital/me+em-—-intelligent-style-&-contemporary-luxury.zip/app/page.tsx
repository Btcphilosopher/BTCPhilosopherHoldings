'use client';

import React, { useState } from 'react';
import { StoreProvider, useStore } from '@/lib/store';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import CategoryStrip from '@/components/CategoryStrip';
import NewArrivals from '@/components/NewArrivals';
import IntelligentStylePhilosophy from '@/components/IntelligentStylePhilosophy';
import TheEditLookbook from '@/components/TheEditLookbook';
import Footer from '@/components/Footer';
import ProductQuickView from '@/components/ProductQuickView';
import ShoppingBagDrawer from '@/components/ShoppingBagDrawer';
import SearchOverlay from '@/components/SearchOverlay';
import PolyglotBackendModal from '@/components/PolyglotBackendModal';

function StoreFront() {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const { quickViewProduct, setQuickViewProduct } = useStore();

  const handleShopHero = () => {
    setSelectedCategory('All');
    const el = document.getElementById('collection');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F5] text-neutral-900 selection:bg-neutral-900 selection:text-white">
      {/* Top Navbar */}
      <Navbar onSelectCategory={(cat) => setSelectedCategory(cat)} />

      {/* Hero Section */}
      <Hero onShopClick={handleShopHero} />

      {/* 5-Category Horizontal Strip */}
      <CategoryStrip
        activeCategory={selectedCategory}
        onSelectCategory={(cat) => setSelectedCategory(cat)}
      />

      {/* New Arrivals & Collection Section */}
      <NewArrivals
        selectedCategory={selectedCategory}
        onSelectCategory={(cat) => setSelectedCategory(cat)}
      />

      {/* Brand Philosophy: The 7 Rules of Intelligent Style */}
      <IntelligentStylePhilosophy onExplore={handleShopHero} />

      {/* The Edit: Lookbook & Styling Suites */}
      <TheEditLookbook />

      {/* Footer */}
      <Footer />

      {/* Modals & Slide-over Drawers */}
      {quickViewProduct && (
        <ProductQuickView
          product={quickViewProduct}
          onClose={() => setQuickViewProduct(null)}
        />
      )}
      <ShoppingBagDrawer />
      <SearchOverlay />
      <PolyglotBackendModal />
    </div>
  );
}

export default function Page() {
  return (
    <StoreProvider>
      <StoreFront />
    </StoreProvider>
  );
}
