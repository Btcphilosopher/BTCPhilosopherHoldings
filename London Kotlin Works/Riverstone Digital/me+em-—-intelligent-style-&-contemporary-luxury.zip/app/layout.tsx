import type { Metadata } from 'next';
import { Plus_Jakarta_Sans, Playfair_Display, JetBrains_Mono } from 'next/font/google';
import './globals.css';

const plusJakartaSans = Plus_Jakarta_Sans({
  subsets: ['latin'],
  variable: '--font-sans',
  display: 'swap',
});

const playfairDisplay = Playfair_Display({
  subsets: ['latin'],
  variable: '--font-serif',
  display: 'swap',
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'ME+EM — Intelligent Style & Contemporary Luxury',
  description: 'Timeless style, modern living. ME+EM creates flattering, versatile luxury fashion engineered with intelligent sizing, direct luxury pricing, and effortless elegance.',
  openGraph: {
    title: 'ME+EM — Intelligent Style & Contemporary Luxury',
    description: 'Timeless style, modern living. ME+EM creates flattering, versatile luxury fashion engineered with intelligent sizing, direct luxury pricing, and effortless elegance.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'ME+EM — Intelligent Style & Contemporary Luxury',
    description: 'Timeless style, modern living. ME+EM creates flattering, versatile luxury fashion engineered with intelligent sizing, direct luxury pricing, and effortless elegance.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="en"
      className={`scroll-smooth ${plusJakartaSans.variable} ${playfairDisplay.variable} ${jetbrainsMono.variable}`}
    >
      <body className="bg-[#FAF8F5] text-neutral-900 antialiased selection:bg-neutral-900 selection:text-white" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
