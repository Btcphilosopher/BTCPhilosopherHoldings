'use client';

import React, { createContext, useContext, useState, useMemo } from 'react';
import { Product } from './catalog';
import { haptic } from './audio';

export interface CartItem {
  id: string;
  productId: string;
  name: string;
  size: string;
  color: string;
  price: number;
  image: string;
  quantity: number;
}

export type CurrencyCode = 'GBP' | 'USD' | 'EUR' | 'AUD';

interface StoreContextType {
  cart: CartItem[];
  wishlist: string[];
  currency: CurrencyCode;
  currencySymbol: string;
  fxRate: number;
  formatPrice: (amountInGbp: number) => string;
  addToCart: (product: Product, size: string, color: string, quantity?: number) => void;
  removeFromCart: (cartItemId: string) => void;
  updateCartQuantity: (cartItemId: string, quantity: number) => void;
  toggleWishlist: (productId: string) => void;
  isWishlisted: (productId: string) => boolean;
  setCurrency: (c: CurrencyCode) => void;
  
  // UI states
  isBagOpen: boolean;
  setIsBagOpen: (open: boolean) => void;
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  isBackendModalOpen: boolean;
  setIsBackendModalOpen: (open: boolean) => void;
  quickViewProduct: Product | null;
  setQuickViewProduct: (product: Product | null) => void;
  isSoundMuted: boolean;
  toggleSound: () => void;
  cartCount: number;
  cartSubtotal: number;
}

const FX_RATES: Record<CurrencyCode, { symbol: string; rate: number }> = {
  GBP: { symbol: '£', rate: 1.0 },
  USD: { symbol: '$', rate: 1.30 },
  EUR: { symbol: '€', rate: 1.18 },
  AUD: { symbol: 'A$', rate: 1.95 },
};

const DEFAULT_CART: CartItem[] = [
  {
    id: 'cart-init-1',
    productId: 'knit-01',
    name: 'Cashmere Ribbed Trim Crew Neck Jumper',
    size: 'UK 10',
    color: 'Ivory White',
    price: 275,
    image: '/extracted/cat_knitwear.webp',
    quantity: 1,
  },
];

const StoreContext = createContext<StoreContextType | null>(null);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>(DEFAULT_CART);
  const [wishlist, setWishlist] = useState<string[]>(['coat-01', 'knit-01']);
  const [currency, setCurrencyState] = useState<CurrencyCode>('GBP');
  const [isBagOpen, setIsBagOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isBackendModalOpen, setIsBackendModalOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [isSoundMuted, setIsSoundMuted] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return haptic.getMuted();
    }
    return false;
  });

  const toggleSound = () => {
    const muted = haptic.toggleMute();
    setIsSoundMuted(muted);
  };

  const setCurrency = (c: CurrencyCode) => {
    haptic.playSwatchTap();
    setCurrencyState(c);
  };

  const formatPrice = (amountInGbp: number) => {
    const { symbol, rate } = FX_RATES[currency];
    const converted = amountInGbp * rate;
    return `${symbol}${Math.round(converted).toLocaleString()}`;
  };

  const addToCart = (product: Product, size: string, color: string, quantity = 1) => {
    haptic.playBagAdd();
    setCart((prev) => {
      const existingIdx = prev.findIndex(
        (item) => item.productId === product.id && item.size === size && item.color === color
      );
      if (existingIdx > -1) {
        const next = [...prev];
        next[existingIdx].quantity += quantity;
        return next;
      }
      return [
        ...prev,
        {
          id: `${product.id}-${size}-${color}-${Date.now()}`,
          productId: product.id,
          name: product.name,
          size,
          color,
          price: product.price,
          image: product.image,
          quantity,
        },
      ];
    });
    setIsBagOpen(true);
  };

  const removeFromCart = (cartItemId: string) => {
    haptic.playSoftSnap();
    setCart((prev) => prev.filter((item) => item.id !== cartItemId));
  };

  const updateCartQuantity = (cartItemId: string, quantity: number) => {
    haptic.playSwatchTap();
    if (quantity <= 0) {
      removeFromCart(cartItemId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => (item.id === cartItemId ? { ...item, quantity } : item))
    );
  };

  const toggleWishlist = (productId: string) => {
    haptic.playSoftSnap();
    setWishlist((prev) =>
      prev.includes(productId) ? prev.filter((id) => id !== productId) : [...prev, productId]
    );
  };

  const isWishlisted = (productId: string) => wishlist.includes(productId);

  const cartCount = useMemo(() => cart.reduce((acc, item) => acc + item.quantity, 0), [cart]);
  const cartSubtotal = useMemo(() => cart.reduce((acc, item) => acc + item.price * item.quantity, 0), [cart]);

  return (
    <StoreContext.Provider
      value={{
        cart,
        wishlist,
        currency,
        currencySymbol: FX_RATES[currency].symbol,
        fxRate: FX_RATES[currency].rate,
        formatPrice,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        toggleWishlist,
        isWishlisted,
        setCurrency,
        isBagOpen,
        setIsBagOpen,
        isSearchOpen,
        setIsSearchOpen,
        isBackendModalOpen,
        setIsBackendModalOpen,
        quickViewProduct,
        setQuickViewProduct,
        isSoundMuted,
        toggleSound,
        cartCount,
        cartSubtotal,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
}
