export interface Product {
  id: string;
  name: string;
  category: 'Knitwear' | 'Coats & Jackets' | 'Shirts & Blouses' | 'Trousers' | 'Bags & Accessories';
  price: number;
  badge?: string;
  image: string;
  secondaryImage?: string;
  colors: { name: string; hex: string }[];
  sizes: string[];
  fabric: string;
  gsm: number;
  fiberType: string;
  description: string;
  intelligentStyleRule: string;
  flatterFeature: string;
}

export const CATEGORIES = [
  {
    id: 'knitwear',
    name: 'KNITWEAR',
    slug: 'Knitwear',
    image: '/extracted/cat_knitwear.webp',
    tagline: 'Pure Scottish cashmere and breathable extra-fine merino',
  },
  {
    id: 'coats',
    name: 'COATS & JACKETS',
    slug: 'Coats & Jackets',
    image: '/extracted/cat_coats.webp',
    tagline: 'Tailored architectural silhouettes and double-faced wools',
  },
  {
    id: 'shirts',
    name: 'SHIRTS & BLOUSES',
    slug: 'Shirts & Blouses',
    image: '/extracted/cat_shirts.webp',
    tagline: '19-momme fluid silk crepe de Chine and Italian crisp poplin',
  },
  {
    id: 'trousers',
    name: 'TROUSERS',
    slug: 'Trousers',
    image: '/extracted/cat_trousers.webp',
    tagline: 'Our signature flattering side-stripe and tailored wide-leg cuts',
  },
  {
    id: 'bags',
    name: 'BAGS & ACCESSORIES',
    slug: 'Bags & Accessories',
    image: '/extracted/cat_bags.webp',
    tagline: 'Italian pebbled calfskin and cashmere travel wraps',
  },
] as const;

export const PRODUCTS: Product[] = [
  {
    id: 'knit-01',
    name: 'Cashmere Ribbed Trim Crew Neck Jumper',
    category: 'Knitwear',
    price: 275,
    badge: 'Best Seller',
    image: '/extracted/cat_knitwear.webp',
    secondaryImage: '/extracted/prod_knit_1.webp',
    colors: [
      { name: 'Ivory White', hex: '#FAF7F2' },
      { name: 'Camel Melange', hex: '#B89B7A' },
      { name: 'Midnight Navy', hex: '#1C2433' },
    ],
    sizes: ['UK 6', 'UK 8', 'UK 10', 'UK 12', 'UK 14', 'UK 16'],
    fabric: '100% 2-Ply Scottish Cashmere',
    gsm: 290,
    fiberType: 'FIBER_SCOTTISH_CASHMERE_2PLY',
    description: 'Knitted from ethically spun 2-ply Scottish cashmere from Todd & Duncan. Engineered with subtle side splits and an elongated ribbed cuff designed to flatter the wrist.',
    intelligentStyleRule: 'Rule 2: 24/7 Versatility. Layer casually over a white poplin collar for the boardroom, or pair with fluid silk trousers for evening dining.',
    flatterFeature: 'Engineered dropped shoulder that elongates the neck and gently softens the upper silhouette.',
  },
  {
    id: 'coat-01',
    name: 'Italian Wool Tailored Single-Breasted Blazer',
    category: 'Coats & Jackets',
    price: 425,
    badge: 'Campaign Look',
    image: '/extracted/cat_coats.webp',
    secondaryImage: '/extracted/prod_blazer_2.webp',
    colors: [
      { name: 'Moss Olive', hex: '#4A503D' },
      { name: 'Oatmeal Taupe', hex: '#C4B9A7' },
      { name: 'Black', hex: '#141414' },
    ],
    sizes: ['UK 6', 'UK 8', 'UK 10', 'UK 12', 'UK 14', 'UK 16'],
    fabric: 'Super 120s Italian Virgin Wool',
    gsm: 340,
    fiberType: 'FIBER_ITALIAN_VIRGIN_WOOL_120S',
    description: 'Sourced from an esteemed Italian mill in Biella. Features structured peak lapels, genuine horn buttons, and internal pocketing tailored for the woman on the move.',
    intelligentStyleRule: 'Rule 1: Flattering Silhouette. Contoured waist darting creates a bespoke tailored silhouette without restricting natural arm movement.',
    flatterFeature: 'Slightly elongated body cut that balances proportions over both trousers and midi skirts.',
  },
  {
    id: 'shirt-01',
    name: 'Pure Silk Crepe de Chine Collared Blouse',
    category: 'Shirts & Blouses',
    price: 225,
    badge: 'Signature Silk',
    image: '/extracted/cat_shirts.webp',
    secondaryImage: '/extracted/prod_suit_5.webp',
    colors: [
      { name: 'Soft Cream', hex: '#F6F3EC' },
      { name: 'French Navy', hex: '#1E2838' },
      { name: 'Powder Blush', hex: '#EEDDD8' },
    ],
    sizes: ['UK 6', 'UK 8', 'UK 10', 'UK 12', 'UK 14', 'UK 16'],
    fabric: '19-Momme Pure Mulberry Silk',
    gsm: 130,
    fiberType: 'FIBER_MULBERRY_SILK_CREPE_19MOMME',
    description: 'Substantial 19-momme silk drape that remains opaque and wrinkle-resilient through a long day of travel. Mother-of-pearl buttons and discreet collar stays.',
    intelligentStyleRule: 'Rule 3: Function + Luxury. Specially treated silk with easy-care washability, eliminating delicate dry-cleaning cycles.',
    flatterFeature: 'V-shaped split placket opens collar line to elongate and flatter the neck and décolletage.',
  },
  {
    id: 'trouser-01',
    name: 'High-Waist Tailored Wide-Leg Trouser',
    category: 'Trousers',
    price: 220,
    badge: 'Iconic Fit',
    image: '/extracted/cat_trousers.webp',
    secondaryImage: '/extracted/prod_coat_4.webp',
    colors: [
      { name: 'Deep Black', hex: '#111111' },
      { name: 'Midnight Navy', hex: '#1A2230' },
      { name: 'Sandstone', hex: '#C5BCB0' },
    ],
    sizes: ['UK 6', 'UK 8', 'UK 10', 'UK 12', 'UK 14', 'UK 16'],
    fabric: 'Crease-Resistant Bi-Stretch Wool Blend',
    gsm: 280,
    fiberType: 'FIBER_ITALIAN_VIRGIN_WOOL_120S',
    description: 'The definitive ME+EM trouser. Features our signature double front pleat, concealed inner elasticated waistband for all-day comfort, and a fluid, sweeping drape.',
    intelligentStyleRule: 'Rule 1: Flattering Silhouette. The wide leg falls directly from the hip bone, instantly creating the optical illusion of endless leg length.',
    flatterFeature: 'Hidden adjustable inner waist tabs for custom bespoke fit after dinner or travel.',
  },
  {
    id: 'bag-01',
    name: 'The Structured Leather Day-To-Evening Tote',
    category: 'Bags & Accessories',
    price: 395,
    badge: 'Handcrafted',
    image: '/extracted/cat_bags.webp',
    secondaryImage: '/extracted/look_cream_tailoring.webp',
    colors: [
      { name: 'Grained Black', hex: '#181818' },
      { name: 'Cognac Saddle', hex: '#7D4E2D' },
      { name: 'Ivory Pebble', hex: '#EBE6DC' },
    ],
    sizes: ['One Size'],
    fabric: 'Full-Grain Italian Pebbled Calfskin',
    gsm: 450,
    fiberType: 'FIBER_DOUBLE_FACED_SHEARLING',
    description: 'Handcrafted in Tuscany from pebbled Italian leather. Features padded 15-inch laptop compartment, suede-lined zipped security pouch, and gold-tone custom hardware.',
    intelligentStyleRule: 'Rule 4: Multi-Functional Luxury. Convertible straps transition instantly from over-the-shoulder boardroom tote to cross-body weekend carry.',
    flatterFeature: 'Slim 14cm profile sits flat against the hip without adding bulk to tailored coats.',
  },
  {
    id: 'knit-02',
    name: 'Chunky Rib Turtleneck in Oatmeal Melange',
    category: 'Knitwear',
    price: 295,
    badge: 'New Season',
    image: '/extracted/prod_turtleneck_3.webp',
    secondaryImage: '/extracted/cat_knitwear.webp',
    colors: [
      { name: 'Oatmeal Melange', hex: '#CDC4B5' },
      { name: 'Charcoal Grey', hex: '#3B3B3D' },
    ],
    sizes: ['UK 6', 'UK 8', 'UK 10', 'UK 12', 'UK 14', 'UK 16'],
    fabric: '70% Ultra-Fine Merino, 30% Cashmere',
    gsm: 360,
    fiberType: 'FIBER_SCOTTISH_CASHMERE_2PLY',
    description: 'Textured fisherman rib stitch designed to maintain sculptural volume without heavy weight. Non-scratchy neck opening designed to stay upright or fold gently.',
    intelligentStyleRule: 'Rule 2: 24/7 Versatility. Contrast heavy rib with lightweight satin trousers or sharp wool tailoring.',
    flatterFeature: 'Generous side hem vents prevent fabric bunching when sitting or walking.',
  },
  {
    id: 'coat-02',
    name: 'Double-Breasted Melton Wool Maxi Coat',
    category: 'Coats & Jackets',
    price: 595,
    badge: 'Runway Look',
    image: '/extracted/look_navy_coat.webp',
    secondaryImage: '/extracted/cat_coats.webp',
    colors: [
      { name: 'Midnight Navy', hex: '#161E2E' },
      { name: 'Camel', hex: '#B89772' },
    ],
    sizes: ['UK 6', 'UK 8', 'UK 10', 'UK 12', 'UK 14', 'UK 16'],
    fabric: 'Pure British Melton Wool (Biella Finish)',
    gsm: 520,
    fiberType: 'FIBER_ITALIAN_VIRGIN_WOOL_120S',
    description: 'As featured in our Autumn / Winter 2026 campaign. Crafted with high thermal insulation, sharp military-inspired epaulettes, and clean architectural lines.',
    intelligentStyleRule: 'Rule 5: Investment Longevity. Heavyweight natural wool fibers resist wind and pilling for decades of seasonal wear.',
    flatterFeature: 'Strategic back-belt placement accentuates the natural waistline on a full-length silhouette.',
  },
  {
    id: 'shirt-02',
    name: 'Relaxed Italian Cotton Poplin Boyfriend Shirt',
    category: 'Shirts & Blouses',
    price: 145,
    badge: 'Wardrobe Essential',
    image: '/extracted/prod_suit_5.webp',
    secondaryImage: '/extracted/cat_shirts.webp',
    colors: [
      { name: 'Optical White', hex: '#FFFFFF' },
      { name: 'Pale Blue Stripe', hex: '#D2DEE9' },
    ],
    sizes: ['UK 6', 'UK 8', 'UK 10', 'UK 12', 'UK 14', 'UK 16'],
    fabric: '100% GOTS Certified Italian Cotton Poplin',
    gsm: 120,
    fiberType: 'FIBER_ORGANIC_ITALIAN_COTTON_POPLIN',
    description: 'The quintessential crisp shirt tailored with modern proportions. Dipped back hem, deep cuffs designed to stay folded when pushed up, and clean concealed closure.',
    intelligentStyleRule: 'Rule 6: Wash and Wear Ease. Premium compact yarn technology prevents deep creasing during normal wear.',
    flatterFeature: 'Carefully measured bust darting prevents gapes between buttons.',
  },
];
