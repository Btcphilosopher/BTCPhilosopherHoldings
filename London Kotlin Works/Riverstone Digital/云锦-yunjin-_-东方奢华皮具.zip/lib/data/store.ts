import { Product, Order } from '../types';
import { INITIAL_PRODUCTS } from './products';

// Global memory store for Next.js API routes
declare global {
  var __YUNJIN_PRODUCTS__: Product[] | undefined;
  var __YUNJIN_ORDERS__: Order[] | undefined;
  var __YUNJIN_APPOINTMENTS__: any[] | undefined;
}

export function getProductsStore(): Product[] {
  if (!global.__YUNJIN_PRODUCTS__) {
    global.__YUNJIN_PRODUCTS__ = [...INITIAL_PRODUCTS];
  }
  return global.__YUNJIN_PRODUCTS__;
}

export function getOrdersStore(): Order[] {
  if (!global.__YUNJIN_ORDERS__) {
    global.__YUNJIN_ORDERS__ = [];
  }
  return global.__YUNJIN_ORDERS__;
}

export function getAppointmentsStore(): any[] {
  if (!global.__YUNJIN_APPOINTMENTS__) {
    global.__YUNJIN_APPOINTMENTS__ = [];
  }
  return global.__YUNJIN_APPOINTMENTS__;
}
