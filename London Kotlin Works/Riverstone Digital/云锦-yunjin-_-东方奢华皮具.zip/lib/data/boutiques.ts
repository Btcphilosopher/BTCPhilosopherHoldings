import { Boutique } from '../types';

export const BOUTIQUES: Boutique[] = [
  {
    id: 'btq-shanghai',
    name: '上海恒隆广场旗舰工坊',
    nameEn: 'Shanghai Plaza 66 Flagship Maison',
    city: '上海',
    cityEn: 'Shanghai',
    address: '上海市静安区南京西路1266号恒隆广场2层218号',
    addressEn: 'Shop 218, Level 2, Plaza 66, 1266 West Nanjing Rd, Jing\'an District, Shanghai',
    telephone: '+86 (21) 6288 8899',
    hours: '周一至周日 10:00 - 22:00',
    hoursEn: 'Mon - Sun 10:00 - 22:00',
    vipSalon: true,
    image: '/images/craftsmanship_artisan.jpg'
  },
  {
    id: 'btq-beijing',
    name: '北京SKP典藏概念店',
    nameEn: 'Beijing SKP Heritage Concept Store',
    city: '北京',
    cityEn: 'Beijing',
    address: '北京市朝阳区建国路87号北京SKP 1层D区',
    addressEn: 'Zone D, 1st Floor, SKP Beijing, 87 Jianguo Road, Chaoyang District, Beijing',
    telephone: '+86 (10) 6598 8866',
    hours: '周一至周日 10:00 - 22:00',
    hoursEn: 'Mon - Sun 10:00 - 22:00',
    vipSalon: true,
    image: '/images/hero_yunjin_model.jpg'
  },
  {
    id: 'btq-chengdu',
    name: '成都太古里院落会所',
    nameEn: 'Chengdu Taikoo Li Courtyard Salon',
    city: '成都',
    cityEn: 'Chengdu',
    address: '成都市锦江区中纱帽街8号远洋太古里东里1层1128号 (马家巷旁)',
    addressEn: 'Shop 1128, East Lane, Sino-Ocean Taikoo Li, Jinjiang District, Chengdu',
    telephone: '+86 (28) 8678 9988',
    hours: '周一至周日 10:00 - 22:00',
    hoursEn: 'Mon - Sun 10:00 - 22:00',
    vipSalon: true,
    image: '/images/brand_story_pagoda.jpg'
  },
  {
    id: 'btq-paris',
    name: '巴黎旺多姆广场高定沙龙',
    nameEn: 'Paris Place Vendôme Haute Salon',
    city: '巴黎',
    cityEn: 'Paris',
    address: '14 Place Vendôme, 75001 Paris, France',
    addressEn: '14 Place Vendôme, 75001 Paris, France',
    telephone: '+33 1 42 68 88 00',
    hours: '周一至周六 10:30 - 19:30 (周日预约制)',
    hoursEn: 'Mon - Sat 10:30 - 19:30 (Sunday by Appointment)',
    vipSalon: true,
    image: '/images/hero_yunjin_model.jpg'
  },
  {
    id: 'btq-tokyo',
    name: '东京银座六丁目艺术名邸',
    nameEn: 'Tokyo Ginza 6-Chome Art Salon',
    city: '东京',
    cityEn: 'Tokyo',
    address: '东京都中央区银座6-10-1 GINZA SIX 3F',
    addressEn: '3F GINZA SIX, 6-10-1 Ginza, Chuo-ku, Tokyo, Japan',
    telephone: '+81 3 6264 8877',
    hours: '周一至周日 10:30 - 20:30',
    hoursEn: 'Mon - Sun 10:30 - 20:30',
    vipSalon: true,
    image: '/images/product_yulan_ivory.jpg'
  }
];
