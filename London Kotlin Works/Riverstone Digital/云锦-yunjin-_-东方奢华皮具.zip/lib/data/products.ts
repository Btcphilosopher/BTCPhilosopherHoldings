import { Product } from '../types';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'yj-01',
    slug: 'yulan-ivory',
    name: '云锦 · 玉兰',
    nameEn: 'YUNJIN · Yulan (Magnolia Ivory)',
    subtitle: '以玉兰之姿 绽放东方气韵',
    subtitleEn: 'In the pure grace of magnolia, blooms timeless Eastern elegance',
    category: 'handbags',
    price: 36800,
    priceUSD: 5180,
    image: '/images/product_yulan_ivory.jpg',
    galleryImages: [
      '/images/product_yulan_ivory.jpg',
      '/images/hero_yunjin_model.jpg',
      '/images/craftsmanship_artisan.jpg'
    ],
    description: '云锦·玉兰手袋以宋代理学素雅之风与江南玉兰花为灵感，精选法国头层小牛皮，纯手工鞣制温润哑光触感。正面镶嵌手工琢磨的新疆和田羊脂白玉如意云纹锁，配以24K古法镀金拉丝包扣。内衬精工融入国家非遗南京云锦真丝寸金织锦，开合之间流转千年宫廷风韵。',
    descriptionEn: 'The Yulan Handbag takes inspiration from the serene elegance of Song Dynasty aesthetics and blooming southern magnolias. Crafted from premium full-grain French box calfskin, it features a hand-carved Xinjiang Hetian mutton-fat white jade Ruyi cloud clasp set into 24K brushed gold hardware. The interior is lined with authentic UNESCO-recognized Nanjing Cloud Brocade woven with real gold thread.',
    dimensions: '26 cm (长) × 18 cm (高) × 10 cm (宽) · 手柄高度 11 cm',
    materials: {
      leather: '法国进口头层特选小牛皮 (哑光掌纹)',
      lining: '国家级非物质文化遗产·南京真丝寸金云锦',
      hardware: '24K古法镀金耐磨拉丝黄铜',
      gemstone: '纯天然新疆和田羊脂白玉 (经国家珠宝鉴定认证)'
    },
    materialsEn: {
      leather: 'Select French Full-Grain Calfskin (Matte finish)',
      lining: 'UNESCO Intangible Heritage Nanjing Cloud Brocade Silk',
      hardware: '24K Antiqued Brushed Gold Brass',
      gemstone: 'Natural Xinjiang Hetian Mutton-Fat White Jade'
    },
    colorVariants: [
      { id: 'v1', name: '玉兰象牙白', nameEn: 'Magnolia Ivory', colorCode: '#F4EFE6', image: '/images/product_yulan_ivory.jpg' },
      { id: 'v2', name: '墨韵沉香黑', nameEn: 'Obsidian Ink', colorCode: '#1E1E1E', image: '/images/product_moyun_black.jpg' },
      { id: 'v3', name: '故宫朱槿红', nameEn: 'Imperial Crimson', colorCode: '#8B1E1E', image: '/images/product_zhujin_crimson.jpg' }
    ],
    lockType: '羊脂白玉如意云纹锁扣',
    lockTypeEn: 'Hetian White Jade Ruyi Cloud Clasp',
    inStock: true,
    stockCount: 8,
    isFeatured: true,
    tag: '工坊典藏',
    tagEn: 'Masterpiece'
  },
  {
    id: 'yj-02',
    slug: 'moyun-black',
    name: '云锦 · 墨韵',
    nameEn: 'YUNJIN · Moyun (Ink Black)',
    subtitle: '沉稳内敛 气度非凡',
    subtitleEn: 'Subtle composure, extraordinary oriental poise',
    category: 'handbags',
    price: 38500,
    priceUSD: 5420,
    image: '/images/product_moyun_black.jpg',
    galleryImages: [
      '/images/product_moyun_black.jpg',
      '/images/craftsmanship_artisan.jpg',
      '/images/brand_story_pagoda.jpg'
    ],
    description: '云锦·墨韵手袋以东方水墨哲思入魂，线条挺拔而内敛。严选欧洲顶级特级黑盒掌纹皮，经过数十道手工抛光封边。锁扣特邀非遗花丝镶嵌大师，以细若游丝的金丝层层编结出古典直条门锁图案，中央微镶天然水润碧玉。包身内侧配有云锦暗纹织锦隔层与拉链暗袋。',
    descriptionEn: 'The Moyun Handbag channels the poetic restraint of traditional ink wash calligraphy. Built with architectural poise using European heirloom-grade box calfskin, its centerpiece is an intricate hand-filigreed 24K gold vertical door-bolt lock crafted by master goldsmiths, centered with a translucent green nephrite cabochon.',
    dimensions: '28 cm (长) × 20 cm (高) × 11 cm (宽) · 手柄高度 12 cm',
    materials: {
      leather: '欧洲特选级黑盒掌纹牛皮',
      lining: '南京玄黑暗纹提花真丝云锦',
      hardware: '国家非遗花丝镶嵌古法造金锁扣',
      gemstone: '纯天然温润碧玉蛋面'
    },
    materialsEn: {
      leather: 'European Heirloom Box Calfskin',
      lining: 'Midnight Black Jacquard Cloud Brocade Silk',
      hardware: 'Hand-Filigreed 24K Gold Clasp',
      gemstone: 'Natural Translucent Green Jade Cabochon'
    },
    colorVariants: [
      { id: 'v1', name: '墨韵沉香黑', nameEn: 'Obsidian Ink', colorCode: '#1A1A1A', image: '/images/product_moyun_black.jpg' },
      { id: 'v2', name: '玉兰象牙白', nameEn: 'Magnolia Ivory', colorCode: '#F4EFE6', image: '/images/product_yulan_ivory.jpg' }
    ],
    lockType: '国家级非遗花丝镶嵌金锁',
    lockTypeEn: 'Imperial Gold Filigree Bolt Clasp',
    inStock: true,
    stockCount: 5,
    isFeatured: true,
    tag: '大师非遗',
    tagEn: 'Artisan Heritage'
  },
  {
    id: 'yj-03',
    slug: 'zhujin-crimson',
    name: '云锦 · 朱槿',
    nameEn: 'YUNJIN · Zhujin (Imperial Crimson)',
    subtitle: '东方色彩 优雅永恒',
    subtitleEn: 'Imperial majesty, timeless feminine allure',
    category: 'handbags',
    price: 39200,
    priceUSD: 5520,
    image: '/images/product_zhujin_crimson.jpg',
    galleryImages: [
      '/images/product_zhujin_crimson.jpg',
      '/images/craftsmanship_artisan.jpg',
      '/images/hero_yunjin_model.jpg'
    ],
    description: '云锦·朱槿手袋重现故宫红墙大漆的庄重与艳丽。包身表面饰以若隐若现的祥云暗纹压花，中央如意形云头锁以古法金箔鎏金工艺打造，嵌缀天然深红南红玛瑙。内衬为皇家级真丝织金大红缎，专为盛大晚宴、重要典礼与东方节庆而生。',
    descriptionEn: 'The Zhujin Handbag revives the ceremonial splendor of Forbidden City cinnabar lacquer. Its leather exterior is discreetly debossed with auspicious cloud scrolls, complemented by an ornate gilt-bronze Ruyi medallion lock inlaid with a deep natural red Nanhong agate gem. Lined with crimson gold-woven royal silk satin.',
    dimensions: '27 cm (长) × 19 cm (高) × 10.5 cm (宽) · 手柄高度 11 cm',
    materials: {
      leather: '定制朱红祥云压纹特等小牛皮',
      lining: '故宫贡品级朱砂红织金真丝锦缎',
      hardware: '24K手工鎏金祥云如意锁具',
      gemstone: '天然四川凉山南红玛瑙'
    },
    materialsEn: {
      leather: 'Bespoke Crimson Cloud-Embossed Calfskin',
      lining: 'Imperial Cinnabar Gold Brocade Satin',
      hardware: '24K Gilded Ruyi Medallion Lock',
      gemstone: 'Natural Sichuan Nanhong Red Agate'
    },
    colorVariants: [
      { id: 'v1', name: '故宫朱槿红', nameEn: 'Imperial Crimson', colorCode: '#8B1E1E', image: '/images/product_zhujin_crimson.jpg' },
      { id: 'v2', name: '墨韵沉香黑', nameEn: 'Obsidian Ink', colorCode: '#1A1A1A', image: '/images/product_moyun_black.jpg' }
    ],
    lockType: '鎏金南红玛瑙如意云锁',
    lockTypeEn: 'Gilded Nanhong Agate Ruyi Clasp',
    inStock: true,
    stockCount: 6,
    isFeatured: true,
    tag: '宫廷限定',
    tagEn: 'Imperial Tribute'
  },
  {
    id: 'yj-04',
    slug: 'shanshui-azure',
    name: '云锦 · 山水',
    nameEn: 'YUNJIN · Shanshui (Mist Azure)',
    subtitle: '山水入包 行旅相随',
    subtitleEn: 'Mountains and misty waters carried alongside your journey',
    category: 'handbags',
    price: 29800,
    priceUSD: 4190,
    image: '/images/product_shanshui_azure.jpg',
    galleryImages: [
      '/images/product_shanshui_azure.jpg',
      '/images/brand_story_pagoda.jpg',
      '/images/hero_yunjin_model.jpg'
    ],
    description: '云锦·山水手袋汲取《千里江山图》之青绿水色，呈素雅霁蓝之调。轻便翻盖设计搭配可拆卸宽皮肩带，可单肩亦可斜挎。包扣采用中国传统“天圆地方”理念，外圈为24K抛光圆环，中嵌正圆形天然苹果绿翡翠平安扣，寓意岁岁平安、行旅顺达。',
    descriptionEn: 'Inspired by the celadon pigments of classical Chinese landscape scrolls, the Shanshui Azure crossbody features a harmonious rounded silhouette. The centerpiece clasp honors the ancient Chinese cosmological philosophy of "Round Sky, Square Earth", holding a genuine Apple Green jade Ping-an disc symbolizing serenity and protection.',
    dimensions: '24 cm (长) × 16 cm (高) × 8.5 cm (宽) · 肩带调节 48-58 cm',
    materials: {
      leather: '精选霁青雾蓝掌纹软牛皮',
      lining: '青绿山水织意真丝云锦',
      hardware: '24K镜面黄金质感合金扣具',
      gemstone: '纯天然缅甸翡翠平安扣'
    },
    materialsEn: {
      leather: 'Supple Mist Celadon Textured Calfskin',
      lining: 'Shanshui Landscape Woven Silk Brocade',
      hardware: '24K Mirror-Polished Gold-Tone Brass',
      gemstone: 'Natural Apple Green Jadeite Ping-An Ring'
    },
    colorVariants: [
      { id: 'v1', name: '霁青烟雨蓝', nameEn: 'Mist Celadon Azure', colorCode: '#7A9196', image: '/images/product_shanshui_azure.jpg' },
      { id: 'v2', name: '玉兰象牙白', nameEn: 'Magnolia Ivory', colorCode: '#F4EFE6', image: '/images/product_yulan_ivory.jpg' }
    ],
    lockType: '翡翠平安圆环同心锁',
    lockTypeEn: 'Jadeite Ping-an Circle Lock',
    inStock: true,
    stockCount: 10,
    isFeatured: true,
    tag: '轻奢随行',
    tagEn: 'Day-to-Evening'
  },
  {
    id: 'yj-05',
    slug: 'ningzhi-wallet',
    name: '云锦 · 凝脂 羊脂玉长款皮夹',
    nameEn: 'YUNJIN · Ningzhi Continental Wallet',
    subtitle: '触手生温 锦绣暗藏',
    subtitleEn: 'Tactile warmth of jade, hidden brocade wealth',
    category: 'small-leather',
    price: 9800,
    priceUSD: 1380,
    image: '/images/product_yulan_ivory.jpg',
    galleryImages: ['/images/product_yulan_ivory.jpg'],
    description: '采用整张法国细腻小牛皮折叠缝制，外嵌精致和田白玉如意纽扣，内设12张卡槽、多层纸币隔层及一枚云锦织金拉链零钱袋。',
    descriptionEn: 'Folded from a single piece of supple French calfskin, featuring a miniature Hetian white jade Ruyi snap button, 12 card slots, and a gold brocade zippered coin pouch.',
    dimensions: '19 cm (长) × 10 cm (高) × 2.5 cm (厚)',
    materials: {
      leather: '法国进口小牛皮',
      lining: '寸金真丝云锦',
      hardware: '24K镀金按扣',
      gemstone: '天然和田白玉小雕件'
    },
    materialsEn: {
      leather: 'French Box Calfskin',
      lining: 'Gold Brocade Silk',
      hardware: '24K Gilt Hardware',
      gemstone: 'Natural Hetian White Jade'
    },
    colorVariants: [
      { id: 'v1', name: '玉兰象牙白', nameEn: 'Magnolia Ivory', colorCode: '#F4EFE6', image: '/images/product_yulan_ivory.jpg' },
      { id: 'v2', name: '墨韵沉香黑', nameEn: 'Obsidian Ink', colorCode: '#1A1A1A', image: '/images/product_moyun_black.jpg' }
    ],
    lockType: '和田玉如意按扣',
    lockTypeEn: 'Hetian Jade Snap Clasp',
    inStock: true,
    stockCount: 15,
    isFeatured: false
  },
  {
    id: 'yj-06',
    slug: 'qionghua-clutch',
    name: '云锦 · 琼华 织金链条手拿包',
    nameEn: 'YUNJIN · Qionghua Brocade Minaudière',
    subtitle: '寸锦寸金 华光夜宴',
    subtitleEn: 'Inch of brocade, inch of gold for midnight galas',
    category: 'small-leather',
    price: 18800,
    priceUSD: 2650,
    image: '/images/product_zhujin_crimson.jpg',
    galleryImages: ['/images/product_zhujin_crimson.jpg'],
    description: '包身主体全部由南京云锦木机妆花真丝手工织就，金银线相交辉映，配有可拆卸古法錾花金链条，可手拿或斜挎。',
    descriptionEn: 'Body woven entirely on ancient Chinese drawlooms using pure mulberry silk and gold threads, with detachable engraved chain.',
    dimensions: '20 cm (长) × 12 cm (高) × 5 cm (宽)',
    materials: {
      leather: '边框包覆朱红小牛皮',
      lining: '双面寸金妆花云锦',
      hardware: '手工錾金链条',
      gemstone: '红玛瑙搭扣'
    },
    materialsEn: {
      leather: 'Crimson Calfskin Trims',
      lining: 'Double-sided Gold Brocade',
      hardware: 'Hand-chiseled Gold Chain',
      gemstone: 'Red Agate Clasp'
    },
    colorVariants: [
      { id: 'v1', name: '朱砂织金', nameEn: 'Cinnabar & Gold', colorCode: '#8B1E1E', image: '/images/product_zhujin_crimson.jpg' }
    ],
    lockType: '錾金玛瑙弹簧锁',
    lockTypeEn: 'Agate Push Lock',
    inStock: true,
    stockCount: 4,
    isFeatured: false
  },
  {
    id: 'yj-07',
    slug: 'siyu-shawl',
    name: '云锦 · 丝语 桑蚕丝羊绒提花披肩',
    nameEn: 'YUNJIN · Siyu Cashmere Silk Stole',
    subtitle: '经纬交织 柔暖如初',
    subtitleEn: 'Mulberry silk and cashmere in tender embrace',
    category: 'accessories',
    price: 7800,
    priceUSD: 1100,
    image: '/images/craftsmanship_artisan.jpg',
    galleryImages: ['/images/craftsmanship_artisan.jpg'],
    description: '70%顶级内蒙古山羊绒与30%特级桑蚕丝混纺，织入明清皇家云锦经典的“万寿藤纹”暗提花，两端手工流苏修饰。',
    descriptionEn: '70% premium Inner Mongolian cashmere blended with 30% Mulberry silk, woven with royal longevity vine jacquard patterns.',
    dimensions: '200 cm × 75 cm',
    materials: {
      leather: '真丝与羊绒提花',
      lining: '无',
      hardware: '皮质铭牌',
      gemstone: '无'
    },
    materialsEn: {
      leather: 'Cashmere & Mulberry Silk Blend',
      lining: 'None',
      hardware: 'Leather Label',
      gemstone: 'None'
    },
    colorVariants: [
      { id: 'v1', name: '玉兰米白', nameEn: 'Oatmeal & Ivory', colorCode: '#EAE5D9', image: '/images/craftsmanship_artisan.jpg' }
    ],
    lockType: '手工流苏打结',
    lockTypeEn: 'Hand-Tasseled',
    inStock: true,
    stockCount: 12,
    isFeatured: false
  },
  {
    id: 'yj-08',
    slug: 'wangshu-coat',
    name: '云锦 · 望舒 羊绒织金立领长大衣',
    nameEn: 'YUNJIN · Wangshu Cashmere Brocade Coat',
    subtitle: '当代中式剪裁 气韵贯通',
    subtitleEn: 'Contemporary Chinese silhouette, sovereign poise',
    category: 'ready-to-wear',
    price: 48000,
    priceUSD: 6760,
    image: '/images/hero_yunjin_model.jpg',
    galleryImages: ['/images/hero_yunjin_model.jpg'],
    description: '采用双面纯羊绒呢料结合后背云锦织金滚边工艺，优雅立领与西式落肩剪裁，配有一枚手工打磨的白玉暗扣。',
    descriptionEn: 'Double-faced pure cashmere with Cloud Brocade gold piping across interior yokes, architectural mandarin collar, and hidden jade button.',
    dimensions: '定制尺码 (XS, S, M, L)',
    materials: {
      leather: '100%阿尔巴斯双面山羊绒',
      lining: '局部纯真丝云锦贴边',
      hardware: '隐藏式暗扣',
      gemstone: '和田白玉盘扣纽扣'
    },
    materialsEn: {
      leather: '100% Double-Faced Cashmere',
      lining: 'Silk Cloud Brocade Trimmings',
      hardware: 'Concealed Fasteners',
      gemstone: 'Hetian White Jade Toggle'
    },
    colorVariants: [
      { id: 'v1', name: '雪松月白', nameEn: 'Moonlight Ivory', colorCode: '#F4EFE6', image: '/images/hero_yunjin_model.jpg' }
    ],
    lockType: '白玉盘扣',
    lockTypeEn: 'Jade Toggle Fastener',
    inStock: true,
    stockCount: 3,
    isFeatured: false
  }
];
