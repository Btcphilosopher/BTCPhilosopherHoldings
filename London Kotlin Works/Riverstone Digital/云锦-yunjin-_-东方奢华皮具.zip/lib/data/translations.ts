export const TRANSLATIONS = {
  zh: {
    nav: {
      home: '首页',
      collections: '臻品系列',
      story: '品牌故事',
      craft: '匠心工艺',
      boutiques: '门店',
      concierge: '私享顾问',
      search: '搜索臻品',
      account: '贵宾中心',
      bag: '购物袋',
      lang: '中文'
    },
    hero: {
      headline: '东方之美\n当代演绎',
      subheading: '传承东方美学 · 致敬当代女性',
      cta: '探索系列',
      slide: '01 / 04',
      slides: [
        {
          title: '东方之美 当代演绎',
          desc: '传承东方美学 · 致敬当代女性',
          tag: '2026 春夏高级定制'
        },
        {
          title: '寸锦寸金 天工开物',
          desc: '一千六百年南京云锦皇家非遗重塑现代奢华',
          tag: '非物质文化遗产'
        },
        {
          title: '温润如玉 如意承吉',
          desc: '新疆和田羊脂白玉与古法錾金锁扣的永恒对话',
          tag: '东方典藏工坊'
        },
        {
          title: '千里江山 行旅如诗',
          desc: '以青绿墨韵入皮，伴随当代雅士漫步世界',
          tag: '现代艺术风尚'
        }
      ]
    },
    collections: {
      title: '臻品系列',
      subtitle: 'OUR COLLECTIONS',
      categories: {
        'handbags': '手袋',
        'small-leather': '小皮具',
        'accessories': '配饰',
        'ready-to-wear': '成衣'
      },
      viewDetails: '查看详情',
      quickAdd: '加入购物袋',
      craftBadge: '非遗金银织锦',
      inStock: '现货典藏',
      limited: '工坊限量',
      pricePrefix: '¥'
    },
    craftSection: {
      craftTitle: '匠心工艺',
      craftSub: '以传统工艺 造就现代奢华',
      craftCta: '了解更多',
      storyTitle: '品牌故事',
      storySub: '源于东方 走向世界',
      storyCta: '探索云锦'
    },
    pdp: {
      monogramTitle: '专属客制烫印 (Bespoke Monogramming)',
      monogramDesc: '工坊金箔冷烫或素压印记，可定制英文字母或吉祥汉字',
      foilGold: '24K金箔烫印',
      foilSilver: '雅银箔烫印',
      foilBlind: '古法素面压印',
      materialsTitle: '材质与工艺溯源',
      dimensionsTitle: '规格与空间',
      addToBag: '加入购物袋',
      buyNow: '立即订购',
      complimentaryShipping: '全境尊享顺丰特快空运 / 专人冷压木匣包装',
      authenticityGuarantee: '每一枚手袋均附带国家珠宝玉石质检证书与专属NFC芯片防伪溯源卡'
    },
    cart: {
      title: '您的购物袋',
      empty: '您的购物袋目前为空，敬请挑选心仪臻品',
      subtotal: '小计',
      tax: '税费 (已含)',
      shipping: '顺丰特快保价专送',
      complimentary: '尊享免邮',
      total: '合计',
      checkout: '前往结算',
      giftPackaging: '尊享工坊大漆红木礼盒与手写致礼卡',
      giftMessagePlaceholder: '请输入赠礼手写卡片寄语 (可选)...'
    },
    checkout: {
      title: '贵宾私享结算',
      step1: '配送与礼宾信息',
      step2: '支付方式',
      name: '收件贵宾姓名',
      phone: '联系电话',
      email: '电子邮箱',
      address: '详细地址',
      city: '所在城市',
      province: '省份 / 地区',
      postal: '邮政编码',
      note: '贵宾特别配送嘱托 (可选)',
      payWithWechat: '微信支付 (WeChat Pay)',
      payWithAlipay: '支付宝 (Alipay)',
      payWithUnionpay: '银联国际 (UnionPay)',
      payWithCard: '国际信用卡 / Apple Pay',
      placeOrder: '确认并支付',
      processing: '工坊系统验真并生成私享单号...',
      orderSuccess: '订购成功，尊荣开启',
      orderNumberPrefix: '私享订单号',
      certificatePrefix: '典藏证书编号',
      trackingPrefix: '顺丰保价单号',
      continueShopping: '返回浏览更多臻品'
    },
    footer: {
      story: '品牌故事',
      shoppingGuide: '购物指南',
      vipCenter: '会员中心',
      contact: '联系我们',
      copyright: '© 2026 云锦 (YUNJIN) . All rights reserved.'
    }
  },
  en: {
    nav: {
      home: 'Home',
      collections: 'Collections',
      story: 'Heritage',
      craft: 'Craftsmanship',
      boutiques: 'Boutiques',
      concierge: 'VIP Concierge',
      search: 'Search',
      account: 'VIP Salon',
      bag: 'Shopping Bag',
      lang: 'EN'
    },
    hero: {
      headline: 'Eastern Aesthetics\nContemporary Expression',
      subheading: 'Inheriting Eastern Aesthetics · Honoring Modern Women',
      cta: 'Explore Collection',
      slide: '01 / 04',
      slides: [
        {
          title: 'Eastern Aesthetics, Contemporary Expression',
          desc: 'Inheriting Eastern Aesthetics · Honoring Modern Women',
          tag: 'Spring/Summer Haute Collection'
        },
        {
          title: 'An Inch of Brocade, An Inch of Gold',
          desc: '1,600 Years of Imperial Cloud Brocade Reimagined in Modern Luxury',
          tag: 'UNESCO Intangible Heritage'
        },
        {
          title: 'Warm as Jade, Auspicious as Ruyi',
          desc: 'An Eternal Dialogue Between Mutton-Fat Hetian Jade and Chiseled Gold',
          tag: 'Master Artisan Atelier'
        },
        {
          title: 'Rivers & Mountains Carried Serene',
          desc: 'Celadon and Ink Wash Landscapes Accompanying the Modern Connoisseur',
          tag: 'Contemporary Art of Travel'
        }
      ]
    },
    collections: {
      title: '臻品系列',
      subtitle: 'OUR COLLECTIONS',
      categories: {
        'handbags': 'Handbags',
        'small-leather': 'Small Leather Goods',
        'accessories': 'Accessories',
        'ready-to-wear': 'Ready-to-Wear'
      },
      viewDetails: 'View Details',
      quickAdd: 'Add to Bag',
      craftBadge: 'Heritage Gold Brocade',
      inStock: 'Atelier Available',
      limited: 'Atelier Limited',
      pricePrefix: '$'
    },
    craftSection: {
      craftTitle: 'Master Craftsmanship',
      craftSub: 'Creating Modern Luxury with Traditional Artistry',
      craftCta: 'Discover More',
      storyTitle: 'Brand Story',
      storySub: 'Rooted in the East, Reaching the World',
      storyCta: 'Explore Yunjin'
    },
    pdp: {
      monogramTitle: 'Bespoke Monogramming Studio',
      monogramDesc: 'Complimentary artisan hot-stamping with initials or auspicious calligraphy',
      foilGold: '24K Gold Foil Stamping',
      foilSilver: 'Platinum Silver Stamping',
      foilBlind: 'Traditional Blind Deboss',
      materialsTitle: 'Provenance & Craftsmanship',
      dimensionsTitle: 'Dimensions & Silhouette',
      addToBag: 'Add to Bag',
      buyNow: 'Purchase Now',
      complimentaryShipping: 'Complimentary express insured courier / Signature lacquered wooden presentation casket',
      authenticityGuarantee: 'Each creation is accompanied by a National Gemological Jade Certificate and embedded encrypted NFC authentication.'
    },
    cart: {
      title: 'Shopping Bag',
      empty: 'Your shopping bag is currently empty. Explore our haute collections.',
      subtotal: 'Subtotal',
      tax: 'Estimated Taxes (Included)',
      shipping: 'White-Glove Express Shipping',
      complimentary: 'Complimentary',
      total: 'Total',
      checkout: 'Proceed to Checkout',
      giftPackaging: 'Signature Imperial Lacquered Wooden Gift Box with Silk Ribbon',
      giftMessagePlaceholder: 'Handwritten calligraphy gift message (optional)...'
    },
    checkout: {
      title: 'VIP Private Checkout',
      step1: 'Delivery & Concierge Address',
      step2: 'Payment Method',
      name: 'Full Name',
      phone: 'Telephone',
      email: 'Email Address',
      address: 'Street Address',
      city: 'City',
      province: 'Province / State',
      postal: 'Postal Code',
      note: 'Special Concierge Delivery Instructions (Optional)',
      payWithWechat: 'WeChat Pay',
      payWithAlipay: 'Alipay',
      payWithUnionpay: 'UnionPay Global',
      payWithCard: 'Credit Card / Apple Pay',
      placeOrder: 'Confirm & Authorize Payment',
      processing: 'Authenticating atelier order & assigning certificate...',
      orderSuccess: 'Order Confirmed · Your Journey Begins',
      orderNumberPrefix: 'Private Order Ref',
      certificatePrefix: 'Certificate of Provenance',
      trackingPrefix: 'Insured Tracking',
      continueShopping: 'Explore More Creations'
    },
    footer: {
      story: 'Heritage',
      shoppingGuide: 'Shopping Guide',
      vipCenter: 'VIP Salon',
      contact: 'Client Services',
      copyright: '© 2026 YUNJIN Haute Maroquinerie. All rights reserved.'
    }
  }
};
