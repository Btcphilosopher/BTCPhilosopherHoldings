export type ProductCategory = 'handbags' | 'small-leather' | 'accessories' | 'ready-to-wear';

export interface ProductVariant {
  id: string;
  name: string;
  nameEn: string;
  colorCode: string;
  image: string;
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  nameEn: string;
  subtitle: string;
  subtitleEn: string;
  category: ProductCategory;
  price: number; // in CNY (¥)
  priceUSD: number; // in USD ($)
  image: string;
  galleryImages: string[];
  description: string;
  descriptionEn: string;
  dimensions: string;
  materials: {
    leather: string;
    lining: string;
    hardware: string;
    gemstone: string;
  };
  materialsEn: {
    leather: string;
    lining: string;
    hardware: string;
    gemstone: string;
  };
  colorVariants: ProductVariant[];
  lockType: string;
  lockTypeEn: string;
  inStock: boolean;
  stockCount: number;
  isFeatured: boolean;
  tag?: string;
  tagEn?: string;
}

export interface BespokePersonalization {
  text: string;
  finish: 'gold' | 'silver' | 'blind';
  position: 'clasp_tag' | 'interior_label' | 'strap';
}

export interface CartItem {
  id: string;
  productId: string;
  product: Product;
  quantity: number;
  selectedVariant: ProductVariant;
  personalization?: BespokePersonalization;
  giftPackaging: boolean;
  giftCardMessage?: string;
}

export interface CustomerInfo {
  fullName: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  provinceOrState: string;
  postalCode: string;
  country: string;
  vipNote?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  createdAt: string;
  items: CartItem[];
  customer: CustomerInfo;
  subtotal: number;
  shipping: number;
  tax: number;
  total: number;
  currency: 'CNY' | 'USD';
  paymentMethod: 'wechat' | 'alipay' | 'unionpay' | 'card' | 'applepay';
  status: 'confirmed' | 'atelier_crafting' | 'courier_dispatch' | 'delivered';
  certificateId: string;
  trackingNumber: string;
}

export interface Boutique {
  id: string;
  name: string;
  nameEn: string;
  city: string;
  cityEn: string;
  address: string;
  addressEn: string;
  telephone: string;
  hours: string;
  hoursEn: string;
  vipSalon: boolean;
  image?: string;
}

export interface ConciergeMessage {
  id: string;
  sender: 'user' | 'concierge';
  text: string;
  timestamp: string;
  suggestedProductSlug?: string;
}
