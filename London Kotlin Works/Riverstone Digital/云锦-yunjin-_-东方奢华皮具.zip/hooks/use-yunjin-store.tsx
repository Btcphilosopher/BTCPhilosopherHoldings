'use client';

import { useState, useEffect, createContext, useContext } from 'react';
import { Product, CartItem, ProductVariant, BespokePersonalization, Order } from '@/lib/types';
import { INITIAL_PRODUCTS } from '@/lib/data/products';
import { TRANSLATIONS } from '@/lib/data/translations';

interface YunjinStoreContextType {
  language: 'zh' | 'en';
  setLanguage: (lang: 'zh' | 'en') => void;
  currency: 'CNY' | 'USD';
  setCurrency: (cur: 'CNY' | 'USD') => void;
  t: typeof TRANSLATIONS.zh;
  cart: CartItem[];
  addToCart: (
    product: Product,
    variant?: ProductVariant,
    personalization?: BespokePersonalization,
    quantity?: number,
    giftPackaging?: boolean,
    giftCardMessage?: string
  ) => void;
  removeFromCart: (cartItemId: string) => void;
  updateQuantity: (cartItemId: string, delta: number) => void;
  clearCart: () => void;
  cartCount: number;
  cartTotal: number;
  
  // Modals
  selectedProduct: Product | null;
  setSelectedProduct: (p: Product | null) => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;
  isConciergeOpen: boolean;
  setIsConciergeOpen: (open: boolean) => void;
  isBoutiqueOpen: boolean;
  setIsBoutiqueOpen: (open: boolean) => void;
  isCraftOpen: boolean;
  setIsCraftOpen: (open: boolean) => void;
  isStoryOpen: boolean;
  setIsStoryOpen: (open: boolean) => void;
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;

  // Checkout result
  lastOrder: Order | null;
  setLastOrder: (order: Order | null) => void;
}

const YunjinStoreContext = createContext<YunjinStoreContextType | null>(null);

export function YunjinStoreProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<'zh' | 'en'>('zh');
  const [currency, setCurrency] = useState<'CNY' | 'USD'>('CNY');
  const [cart, setCart] = useState<CartItem[]>(() => {
    if (typeof window === 'undefined') return [];
    try {
      const saved = localStorage.getItem('__yunjin_cart');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });
  
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isConciergeOpen, setIsConciergeOpen] = useState(false);
  const [isBoutiqueOpen, setIsBoutiqueOpen] = useState(false);
  const [isCraftOpen, setIsCraftOpen] = useState(false);
  const [isStoryOpen, setIsStoryOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [lastOrder, setLastOrder] = useState<Order | null>(null);

  // Sync cart to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('__yunjin_cart', JSON.stringify(cart));
    } catch (e) {
      // ignore
    }
  }, [cart]);

  const t = language === 'zh' ? TRANSLATIONS.zh : TRANSLATIONS.en;

  const addToCart = (
    product: Product,
    variant?: ProductVariant,
    personalization?: BespokePersonalization,
    quantity = 1,
    giftPackaging = true,
    giftCardMessage = ''
  ) => {
    const selectedVariant = variant || product.colorVariants[0];
    const cartItemId = `${product.id}-${selectedVariant.id}-${personalization?.text || 'standard'}`;

    setCart(prev => {
      const existing = prev.find(item => item.id === cartItemId);
      if (existing) {
        return prev.map(item =>
          item.id === cartItemId
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [
        ...prev,
        {
          id: cartItemId,
          productId: product.id,
          product,
          quantity,
          selectedVariant,
          personalization,
          giftPackaging,
          giftCardMessage
        }
      ];
    });

    setIsCartOpen(true);
  };

  const removeFromCart = (cartItemId: string) => {
    setCart(prev => prev.filter(item => item.id !== cartItemId));
  };

  const updateQuantity = (cartItemId: string, delta: number) => {
    setCart(prev =>
      prev
        .map(item => {
          if (item.id === cartItemId) {
            const nextQty = item.quantity + delta;
            return nextQty > 0 ? { ...item, quantity: nextQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const clearCart = () => setCart([]);

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartTotal = cart.reduce((sum, item) => {
    const price = currency === 'USD' ? item.product.priceUSD : item.product.price;
    return sum + price * item.quantity;
  }, 0);

  return (
    <YunjinStoreContext.Provider
      value={{
        language,
        setLanguage,
        currency,
        setCurrency,
        t,
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        cartCount,
        cartTotal,
        selectedProduct,
        setSelectedProduct,
        isCartOpen,
        setIsCartOpen,
        isCheckoutOpen,
        setIsCheckoutOpen,
        isConciergeOpen,
        setIsConciergeOpen,
        isBoutiqueOpen,
        setIsBoutiqueOpen,
        isCraftOpen,
        setIsCraftOpen,
        isStoryOpen,
        setIsStoryOpen,
        isSearchOpen,
        setIsSearchOpen,
        lastOrder,
        setLastOrder
      }}
    >
      {children}
    </YunjinStoreContext.Provider>
  );
}

export function useYunjinStore() {
  const context = useContext(YunjinStoreContext);
  if (!context) {
    throw new Error('useYunjinStore must be used within YunjinStoreProvider');
  }
  return context;
}
