'use client';

import React from 'react';
import Image from 'next/image';
import { useYunjinStore } from '@/hooks/use-yunjin-store';
import { ArrowRight } from 'lucide-react';

export default function CraftsmanshipAndStory() {
  const { t, setIsCraftOpen, setIsStoryOpen } = useYunjinStore();

  return (
    <section className="w-full grid grid-cols-1 md:grid-cols-2 border-b border-[#E8E1D5]">
      {/* Left Block: 匠心工艺 (Master Craftsmanship) */}
      <div className="relative group min-h-[380px] lg:min-h-[440px] flex items-end p-8 sm:p-12 overflow-hidden bg-black">
        <Image
          src="/images/craftsmanship_artisan.jpg"
          alt="匠心工艺 Master Craftsmanship"
          fill
          sizes="(max-width: 768px) 100vw, 50vw"
          referrerPolicy="no-referrer"
          className="object-cover object-center transition-transform duration-1000 group-hover:scale-105 opacity-75"
        />

        {/* Gradient Scrim */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/45 to-transparent pointer-events-none" />

        {/* Content matching screenshot */}
        <div className="relative z-10 max-w-md">
          <h3 className="text-2xl sm:text-3xl font-serif text-white tracking-widest font-normal">
            {t.craftSection.craftTitle}
          </h3>
          <p className="mt-2 text-sm text-white/80 font-serif tracking-widest">
            {t.craftSection.craftSub}
          </p>

          <button
            onClick={() => setIsCraftOpen(true)}
            className="mt-6 group/btn inline-flex items-center gap-3 px-6 py-2.5 border border-white/60 text-white text-xs tracking-widest uppercase transition-all duration-300 hover:border-[#C5A059] hover:bg-white/10 cursor-pointer"
          >
            <span>{t.craftSection.craftCta}</span>
            <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover/btn:translate-x-1 text-[#C5A059]" />
          </button>
        </div>
      </div>

      {/* Right Block: 品牌故事 (Brand Story) */}
      <div className="relative group min-h-[380px] lg:min-h-[440px] flex items-end p-8 sm:p-12 overflow-hidden bg-black border-t md:border-t-0 md:border-l border-[#E8E1D5]/20">
        <Image
          src="/images/brand_story_pagoda.jpg"
          alt="品牌故事 Brand Story"
          fill
          sizes="(max-width: 768px) 100vw, 50vw"
          referrerPolicy="no-referrer"
          className="object-cover object-center transition-transform duration-1000 group-hover:scale-105 opacity-75"
        />

        {/* Gradient Scrim */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/45 to-transparent pointer-events-none" />

        {/* Content matching screenshot */}
        <div className="relative z-10 max-w-md">
          <h3 className="text-2xl sm:text-3xl font-serif text-white tracking-widest font-normal">
            {t.craftSection.storyTitle}
          </h3>
          <p className="mt-2 text-sm text-white/80 font-serif tracking-widest">
            {t.craftSection.storySub}
          </p>

          <button
            onClick={() => setIsStoryOpen(true)}
            className="mt-6 group/btn inline-flex items-center gap-3 px-6 py-2.5 border border-white/60 text-white text-xs tracking-widest uppercase transition-all duration-300 hover:border-[#C5A059] hover:bg-white/10 cursor-pointer"
          >
            <span>{t.craftSection.storyCta}</span>
            <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover/btn:translate-x-1 text-[#C5A059]" />
          </button>
        </div>
      </div>
    </section>
  );
}
