'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'motion/react';
import { useYunjinStore } from '@/hooks/use-yunjin-store';
import { BOUTIQUES } from '@/lib/data/boutiques';
import { X, MapPin, Phone, Clock, Calendar, CheckCircle, Sparkles } from 'lucide-react';

export default function BoutiqueModal() {
  const { isBoutiqueOpen, setIsBoutiqueOpen, language } = useYunjinStore();
  const [selectedBoutique, setSelectedBoutique] = useState(BOUTIQUES[0]);
  const [bookingSuccess, setBookingSuccess] = useState(false);
  const [guestName, setGuestName] = useState('王女士 (Ms. Wang)');
  const [phone, setPhone] = useState('139 1888 6666');
  const [date, setDate] = useState('2026-10-25');
  const [time, setTime] = useState('15:00');
  const [loading, setLoading] = useState(false);

  if (!isBoutiqueOpen) return null;

  const handleBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await fetch('/api/boutiques', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          boutiqueId: selectedBoutique.id,
          guestName,
          phone,
          date,
          time
        })
      });
      const data = await res.json();
      if (data.success) {
        setBookingSuccess(true);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="relative w-full max-w-4xl bg-[#FBF9F5] border border-[#E8E1D5] shadow-2xl overflow-hidden my-auto"
        >
          {/* Close button */}
          <button
            onClick={() => {
              setIsBoutiqueOpen(false);
              setBookingSuccess(false);
            }}
            className="absolute top-4 right-4 z-20 p-2 text-[#7A746B] hover:text-[#1A1A1A] transition-colors rounded-full"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="p-6 sm:p-8 max-h-[85vh] overflow-y-auto">
            {/* Header */}
            <div className="border-b border-[#E8E1D5] pb-4">
              <span className="text-[10px] tracking-[0.25em] uppercase text-[#8C8478] font-sans">
                FLAGSHIP MAISONS & SALONS
              </span>
              <h3 className="text-2xl font-serif text-[#1A1A1A] tracking-wider font-medium mt-1">
                {language === 'zh' ? '全球工坊旗舰店与私享沙龙' : 'Global Flagship Boutiques & VIP Salons'}
              </h3>
            </div>

            {bookingSuccess ? (
              <div className="py-12 text-center space-y-4">
                <div className="w-16 h-16 rounded-full bg-[#8B1E1E]/10 text-[#8B1E1E] flex items-center justify-center mx-auto">
                  <CheckCircle className="w-10 h-10" />
                </div>
                <h4 className="text-xl font-serif font-medium text-[#1A1A1A]">
                  {language === 'zh' ? '私享预约已尊崇确认' : 'VIP Appointment Confirmed'}
                </h4>
                <p className="text-xs text-[#7A746B] font-serif max-w-md mx-auto">
                  {language === 'zh'
                    ? `工坊已为阁下安排在「${selectedBoutique.name}」的私享品茗与专人试背服务，专属礼宾经理将致电与您确认细节。`
                    : `Your private viewing and imperial tea service at "${selectedBoutique.nameEn}" is confirmed. Our salon manager will contact you shortly.`}
                </p>
                <button
                  onClick={() => {
                    setIsBoutiqueOpen(false);
                    setBookingSuccess(false);
                  }}
                  className="px-6 py-2.5 bg-[#1A1A1A] text-white text-xs font-serif tracking-widest uppercase hover:bg-[#8B1E1E]"
                >
                  {language === 'zh' ? '完成' : 'Close'}
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mt-6">
                {/* Left 5 cols: Boutique selector */}
                <div className="lg:col-span-5 space-y-3">
                  <h4 className="text-xs font-sans uppercase tracking-widest text-[#8C8478] mb-3">
                    {language === 'zh' ? '选择名邸名店' : 'Select Boutique'}
                  </h4>

                  <div className="space-y-2">
                    {BOUTIQUES.map((b) => (
                      <button
                        key={b.id}
                        onClick={() => setSelectedBoutique(b)}
                        className={`w-full text-left p-3.5 border transition-all cursor-pointer ${
                          selectedBoutique.id === b.id
                            ? 'border-[#8B1E1E] bg-[#8B1E1E]/5 shadow-xs'
                            : 'border-[#E8E1D5] bg-white hover:border-[#C5A059]'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-serif font-bold text-[#1A1A1A]">
                            {language === 'zh' ? b.city : b.cityEn}
                          </span>
                          <span className="text-[10px] text-[#C5A059] border border-[#C5A059]/40 px-1.5 py-0.5">
                            VIP SALON
                          </span>
                        </div>
                        <p className="text-xs font-serif text-[#4A453E] mt-1 font-medium">
                          {language === 'zh' ? b.name : b.nameEn}
                        </p>
                        <p className="text-[11px] text-[#7A746B] font-serif mt-1 truncate">
                          {language === 'zh' ? b.address : b.addressEn}
                        </p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Right 7 cols: Boutique Details & Appointment Form */}
                <div className="lg:col-span-7 bg-white border border-[#E8E1D5] p-6 flex flex-col justify-between">
                  <div>
                    <h4 className="text-base font-serif font-medium text-[#1A1A1A]">
                      {language === 'zh' ? selectedBoutique.name : selectedBoutique.nameEn}
                    </h4>

                    <div className="mt-3 space-y-2 text-xs font-serif text-[#6A6459]">
                      <div className="flex items-start gap-2">
                        <MapPin className="w-3.5 h-3.5 text-[#8B1E1E] shrink-0 mt-0.5" />
                        <span>{language === 'zh' ? selectedBoutique.address : selectedBoutique.addressEn}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Phone className="w-3.5 h-3.5 text-[#8B1E1E] shrink-0" />
                        <span>{selectedBoutique.telephone}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-3.5 h-3.5 text-[#8B1E1E] shrink-0" />
                        <span>{language === 'zh' ? selectedBoutique.hours : selectedBoutique.hoursEn}</span>
                      </div>
                    </div>

                    {/* Booking Form */}
                    <form onSubmit={handleBooking} className="mt-6 pt-6 border-t border-[#E8E1D5] space-y-4">
                      <div className="flex items-center gap-2 text-xs font-serif text-[#8B1E1E] font-medium">
                        <Sparkles className="w-3.5 h-3.5 text-[#C5A059]" />
                        <span>{language === 'zh' ? '预约私享试背与明前春茶品茗' : 'Reserve Private Salon & Imperial Tea'}</span>
                      </div>

                      <div className="grid grid-cols-2 gap-3 text-xs font-serif">
                        <div>
                          <label className="block text-[11px] text-[#7A746B] mb-1">贵宾姓名</label>
                          <input
                            type="text"
                            required
                            value={guestName}
                            onChange={(e) => setGuestName(e.target.value)}
                            className="w-full border border-[#E8E1D5] p-2 bg-[#FBF9F5] focus:outline-none focus:border-[#C5A059]"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-[#7A746B] mb-1">预约电话</label>
                          <input
                            type="tel"
                            required
                            value={phone}
                            onChange={(e) => setPhone(e.target.value)}
                            className="w-full border border-[#E8E1D5] p-2 bg-[#FBF9F5] focus:outline-none focus:border-[#C5A059]"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-[#7A746B] mb-1">预约日期</label>
                          <input
                            type="date"
                            required
                            value={date}
                            onChange={(e) => setDate(e.target.value)}
                            className="w-full border border-[#E8E1D5] p-2 bg-[#FBF9F5] focus:outline-none focus:border-[#C5A059]"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-[#7A746B] mb-1">预约时段</label>
                          <select
                            value={time}
                            onChange={(e) => setTime(e.target.value)}
                            className="w-full border border-[#E8E1D5] p-2 bg-[#FBF9F5] focus:outline-none focus:border-[#C5A059]"
                          >
                            <option value="11:00">11:00 上午品鉴</option>
                            <option value="14:30">14:30 午后茶席</option>
                            <option value="16:30">16:30 傍晚雅集</option>
                            <option value="19:00">19:00 华灯夜筵</option>
                          </select>
                        </div>
                      </div>

                      <button
                        type="submit"
                        disabled={loading}
                        className="w-full py-3 bg-[#8B1E1E] text-white text-xs font-serif tracking-widest uppercase hover:bg-[#A32828] transition-colors cursor-pointer"
                      >
                        {loading ? '正在登记预约...' : (language === 'zh' ? '尊享预约私享沙龙' : 'Confirm Salon Reservation')}
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
