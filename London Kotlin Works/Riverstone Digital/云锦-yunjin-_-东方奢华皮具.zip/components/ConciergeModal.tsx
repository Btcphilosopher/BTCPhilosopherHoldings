'use client';

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useYunjinStore } from '@/hooks/use-yunjin-store';
import { X, Sparkles, Send, Bot, User, MapPin } from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'concierge';
  text: string;
  time: string;
}

export default function ConciergeModal() {
  const {
    isConciergeOpen,
    setIsConciergeOpen,
    language,
    setIsBoutiqueOpen
  } = useYunjinStore();

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const initialGreetingZh = '阁下安好。我是云锦工坊高级私享顾问。不论您需要为中式雅宴挑选配包、探寻和田白玉与云锦非遗背后的吉祥寓意，还是预约上海恒隆、北京SKP或巴黎旺多姆沙龙，我都竭诚为您效劳。请问今日有何雅事？';
  const initialGreetingEn = 'Greetings, honored guest. I am your Senior Bespoke Advisor at YUNJIN Maison. Whether you seek styling guidance for an upcoming gala, wish to explore the imperial symbolism of our Hetian jade and gold brocade, or reserve a private salon viewing in Shanghai or Paris, I am delighted to assist you.';

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      sender: 'concierge',
      text: language === 'zh' ? initialGreetingZh : initialGreetingEn,
      time: '14:00'
    }
  ]);

  const msgCountRef = useRef(100);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isConciergeOpen) {
      scrollToBottom();
    }
  }, [messages, isConciergeOpen]);

  if (!isConciergeOpen) return null;

  const quickPromptsZh = [
    '出席高雅晚宴，玉兰与朱槿哪款更合适？',
    '包身内衬的“南京云锦”有何非遗历史？',
    '如何养护天然和田白玉与特级小牛皮？',
    '我想预约私享沙龙品茗试背'
  ];

  const quickPromptsEn = [
    'For a formal evening gala, should I choose Yulan or Zhujin?',
    'What is the heritage of Nanjing Cloud Brocade silk?',
    'How should I care for the Hetian jade lock and calfskin?',
    'I would like to book a private VIP salon tasting'
  ];

  const quickPrompts = language === 'zh' ? quickPromptsZh : quickPromptsEn;

  const handleSend = async (messageText?: string) => {
    const textToSend = messageText || input;
    if (!textToSend.trim() || loading) return;

    msgCountRef.current += 1;
    const currentId = msgCountRef.current;
    const formattedTime = '14:30';

    const userMsg: ChatMessage = {
      id: `u-${currentId}`,
      sender: 'user',
      text: textToSend,
      time: formattedTime
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/concierge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          history: messages.slice(-4),
          language
        })
      });

      const data = await res.json();
      msgCountRef.current += 1;
      const botMsg: ChatMessage = {
        id: `c-${msgCountRef.current}`,
        sender: 'concierge',
        text: data.reply || (language === 'zh' ? '工坊顾问已为您记录，随时为您奉上高定建议。' : 'Our advisor has noted your preference and is at your continuous service.'),
        time: formattedTime
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      console.error(err);
      msgCountRef.current += 1;
      setMessages((prev) => [
        ...prev,
        {
          id: `c-err-${msgCountRef.current}`,
          sender: 'concierge',
          text: language === 'zh' ? '谨致歉意，工坊网络偶有延宕。阁下可直接致电预约全国旗舰沙龙。' : 'Our apologies for the slight delay. You may also contact our flagship salons directly.',
          time: formattedTime
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-xs flex justify-end">
        <div className="absolute inset-0" onClick={() => setIsConciergeOpen(false)} />

        <motion.div
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ type: 'spring', damping: 28, stiffness: 260 }}
          className="relative w-full max-w-lg bg-[#FBF9F5] h-full shadow-2xl flex flex-col justify-between border-l border-[#E8E1D5]"
        >
          {/* Header */}
          <div className="p-6 border-b border-[#E8E1D5] bg-[#F5F1E9] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#8B1E1E]/10 border border-[#8B1E1E]/30 text-[#8B1E1E] flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-[#C5A059]" />
              </div>
              <div>
                <h3 className="text-base font-serif font-medium text-[#1A1A1A] tracking-wider">
                  {language === 'zh' ? '云锦 · 私享高定顾问' : 'YUNJIN Private Concierge'}
                </h3>
                <p className="text-[10px] text-[#8C8478] font-sans tracking-widest uppercase">
                  HAUTE ADVISORY & BESPOKE STYLING
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsConciergeOpen(false)}
              className="p-2 text-[#7A746B] hover:text-[#1A1A1A] rounded-full hover:bg-black/5"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.map((m) => {
              const isUser = m.sender === 'user';
              return (
                <div
                  key={m.id}
                  className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
                >
                  {!isUser && (
                    <div className="w-7 h-7 rounded-full bg-[#1A1A1A] text-[#C5A059] flex items-center justify-center text-xs shrink-0 mt-1">
                      云
                    </div>
                  )}

                  <div
                    className={`max-w-[82%] p-4 text-xs font-serif leading-relaxed ${
                      isUser
                        ? 'bg-[#8B1E1E] text-white rounded-tl-lg rounded-tr-lg rounded-bl-lg'
                        : 'bg-white text-[#1A1A1A] border border-[#E8E1D5] rounded-tl-lg rounded-tr-lg rounded-br-lg shadow-xs'
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{m.text}</p>
                    <span
                      className={`block text-[9px] mt-2 text-right ${
                        isUser ? 'text-white/60' : 'text-[#8C8478]'
                      }`}
                    >
                      {m.time}
                    </span>
                  </div>
                </div>
              );
            })}

            {loading && (
              <div className="flex items-center gap-2 text-xs text-[#8C8478] font-serif pl-10">
                <span className="w-2 h-2 rounded-full bg-[#C5A059] animate-bounce" />
                <span className="w-2 h-2 rounded-full bg-[#C5A059] animate-bounce [animation-delay:0.2s]" />
                <span className="w-2 h-2 rounded-full bg-[#C5A059] animate-bounce [animation-delay:0.4s]" />
                <span className="ml-1 tracking-wider">
                  {language === 'zh' ? '顾问沉思中...' : 'Advisor is consulting the atelier...'}
                </span>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick Prompts */}
          <div className="px-6 py-2 border-t border-[#E8E1D5] bg-[#F5F1E9]/60 flex gap-2 overflow-x-auto">
            {quickPrompts.map((q, i) => (
              <button
                key={i}
                onClick={() => handleSend(q)}
                className="whitespace-nowrap px-3 py-1.5 bg-white border border-[#E8E1D5] text-[11px] font-serif text-[#555047] hover:text-[#8B1E1E] hover:border-[#C5A059] transition-colors rounded-xs shadow-2xs shrink-0"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Input Box */}
          <div className="p-4 sm:p-6 border-t border-[#E8E1D5] bg-white">
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder={language === 'zh' ? '请在此输入阁下的垂询...' : 'Inquire with your private client advisor...'}
                className="flex-1 bg-[#FBF9F5] border border-[#E8E1D5] px-4 py-3 text-xs font-serif text-[#1A1A1A] focus:outline-none focus:border-[#C5A059]"
              />
              <button
                onClick={() => handleSend()}
                disabled={loading || !input.trim()}
                className="p-3 bg-[#8B1E1E] text-white hover:bg-[#A32828] disabled:opacity-40 transition-colors shadow-xs"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-3 flex items-center justify-between text-[11px] text-[#8C8478] font-serif">
              <span>{language === 'zh' ? '提供中英双语私享解答' : 'Bilingual Haute Client Services'}</span>
              <button
                onClick={() => {
                  setIsConciergeOpen(false);
                  setIsBoutiqueOpen(true);
                }}
                className="text-[#8B1E1E] hover:underline flex items-center gap-1"
              >
                <MapPin className="w-3 h-3" />
                <span>{language === 'zh' ? '直接预约线下沙龙' : 'Book Boutique Salon'}</span>
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
