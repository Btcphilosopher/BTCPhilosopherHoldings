'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'motion/react';
import { useYunjinStore } from '@/hooks/use-yunjin-store';
import { ChevronLeft, ChevronRight, ArrowRight } from 'lucide-react';

export default function Hero() {
  const { t, language } = useYunjinStore();
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      image: '/images/hero_yunjin_model.jpg',
      headline: language === 'zh' ? '东方之美\n当代演绎' : 'Eastern Aesthetics\nContemporary Expression',
      subheading: language === 'zh' ? '传承东方美学 · 致敬当代女性' : 'Inheriting Eastern Aesthetics · Honoring Modern Women',
      tag: language === 'zh' ? '2026 春夏高级定制' : 'Spring/Summer Haute Couture',
      accentProduct: '云锦 · 玉兰'
    },
    {
      image: '/images/craftsmanship_artisan.jpg',
      headline: language === 'zh' ? '寸锦寸金\n天工开物' : 'Imperial Heritage\nGolden Tapestry',
      subheading: language === 'zh' ? '一千六百年南京云锦 · 皇家金银织物入包' : '1,600 Years of Nanjing Cloud Brocade · Pure Gold Weave',
      tag: language === 'zh' ? '非物质文化遗产' : 'UNESCO Intangible Heritage',
      accentProduct: '云锦 · 墨韵'
    },
    {
      image: '/images/brand_story_pagoda.jpg',
      headline: language === 'zh' ? '千里江山\n行旅相随' : 'Rivers & Waters\nCarried Serene',
      subheading: language === 'zh' ? '青绿水色入皮 · 天然翡翠平安环佩' : 'Celadon Tones and Natural Jadeite Ping-An Ring',
      tag: language === 'zh' ? '东方雅士典藏' : 'Elegance in Motion',
      accentProduct: '云锦 · 山水'
    },
    {
      image: '/images/product_zhujin_crimson.jpg',
      headline: language === 'zh' ? '故宫大漆\n朱槿华彩' : 'Imperial Cinnabar\nForbidden Splendor',
      subheading: language === 'zh' ? '古法手工鎏金如意锁 · 纯天然南红玛瑙' : '24K Gilt Ruyi Medallion Clasp · Natural Red Agate',
      tag: language === 'zh' ? '宫廷仪典限定' : 'Imperial Ceremony Edition',
      accentProduct: '云锦 · 朱槿'
    }
  ];

  // Auto-advance slide gently
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 9000);
    return () => clearInterval(timer);
  }, [slides.length]);

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % slides.length);
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);

  const activeSlide = slides[currentSlide];

  return (
    <section id="home" className="relative w-full h-[92vh] min-h-[640px] max-h-[960px] overflow-hidden bg-[#121212]">
      {/* Background Images with smooth crossfade */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentSlide}
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
          className="absolute inset-0 z-0"
        >
          <Image
            src={activeSlide.image}
            alt={activeSlide.headline}
            fill
            priority
            referrerPolicy="no-referrer"
            className="object-cover object-center"
          />
          {/* Measured cinematic contrast gradient overlays */}
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/45 to-black/20" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-black/35" />
        </motion.div>
      </AnimatePresence>

      {/* Hero Content Container */}
      <div className="relative z-10 max-w-7xl mx-auto h-full px-6 sm:px-12 flex flex-col justify-between pt-36 pb-12">
        {/* Top Tag */}
        <motion.div
          key={`tag-${currentSlide}`}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="flex items-center gap-3"
        >
          <span className="w-6 h-[1px] bg-[#C5A059]" />
          <span className="text-[#C5A059] text-xs sm:text-sm tracking-[0.25em] font-medium uppercase">
            {activeSlide.tag}
          </span>
        </motion.div>

        {/* Central Headlines & Call to Action */}
        <div className="max-w-2xl my-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={`text-${currentSlide}`}
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            >
              <h1 className="text-4xl sm:text-6xl md:text-7xl font-serif font-light text-white tracking-wider leading-[1.15] whitespace-pre-line text-balance drop-shadow-md">
                {activeSlide.headline}
              </h1>

              <p className="mt-5 text-base sm:text-xl text-white/85 font-serif font-light tracking-widest leading-relaxed">
                {activeSlide.subheading}
              </p>

              {/* CTA Button matching the reference screenshot */}
              <div className="mt-8 flex items-center gap-4">
                <a
                  href="#collections"
                  className="group inline-flex items-center gap-3 px-7 py-3.5 border border-white/60 text-white text-sm tracking-widest uppercase transition-all duration-300 hover:border-[#C5A059] hover:bg-white/10 hover:shadow-lg"
                >
                  <span>{t.hero.cta}</span>
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1.5 text-[#C5A059]" />
                </a>

                {activeSlide.accentProduct && (
                  <span className="hidden sm:inline-block text-xs tracking-widest text-white/60 italic font-serif">
                    — {activeSlide.accentProduct}
                  </span>
                )}
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Bottom Pagination & Slide Navigation */}
        <div className="flex items-center justify-between border-t border-white/15 pt-6">
          {/* Numerical Slide Indicator matching reference: "01 / 04" */}
          <div className="flex items-center gap-6 text-white text-xs sm:text-sm tracking-[0.2em] font-sans tabular-nums">
            <button
              onClick={prevSlide}
              className="p-1 text-white/70 hover:text-[#C5A059] transition-colors"
              aria-label="Previous Slide"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <span className="font-semibold text-white">
              0{currentSlide + 1}
            </span>
            <span className="text-white/40">/</span>
            <span className="text-white/60">
              0{slides.length}
            </span>

            <button
              onClick={nextSlide}
              className="p-1 text-white/70 hover:text-[#C5A059] transition-colors"
              aria-label="Next Slide"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Quick Category Jump hints */}
          <div className="hidden md:flex items-center gap-6 text-xs text-white/60 tracking-widest">
            <span>手作非遗</span>
            <span>·</span>
            <span>天然和田玉</span>
            <span>·</span>
            <span>花丝镶嵌</span>
            <span>·</span>
            <span>法国特等皮</span>
          </div>
        </div>
      </div>
    </section>
  );
}
