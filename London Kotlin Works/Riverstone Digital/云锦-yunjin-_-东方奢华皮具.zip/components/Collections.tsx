'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { motion } from 'motion/react';
import { useYunjinStore } from '@/hooks/use-yunjin-store';
import { Product, ProductCategory } from '@/lib/types';
import { ArrowRight, Plus, Eye, Sparkles } from 'lucide-react';

interface CollectionsProps {
  products: Product[];
}

export default function Collections({ products }: CollectionsProps) {
  const {
    t,
    language,
    currency,
    setSelectedProduct,
    addToCart
  } = useYunjinStore();

  const [activeCategory, setActiveCategory] = useState<ProductCategory>('handbags');

  const categories: { id: ProductCategory; labelZh: string; labelEn: string }[] = [
    { id: 'handbags', labelZh: '手袋', labelEn: 'Handbags' },
    { id: 'small-leather', labelZh: '小皮具', labelEn: 'Small Leather Goods' },
    { id: 'accessories', labelZh: '配饰', labelEn: 'Accessories' },
    { id: 'ready-to-wear', labelZh: '成衣', labelEn: 'Ready-to-Wear' }
  ];

  const filteredProducts = products.filter(p => p.category === activeCategory);

  return (
    <section id="collections" className="py-24 bg-[#FBF9F5] border-b border-[#E8E1D5]/60 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
          
          {/* Left Column: Brand Category Sidebar with Seal & Magnolia Line Art */}
          <div className="lg:col-span-3 flex flex-col justify-between relative">
            <div>
              {/* Botanical Magnolia Line Art Watermark */}
              <div className="relative mb-8">
                <svg
                  className="w-32 h-32 text-[#C5A059]/25 stroke-current fill-none stroke-[1]"
                  viewBox="0 0 100 100"
                  aria-hidden="true"
                >
                  <path d="M50 10 C35 30 20 45 30 65 C38 80 50 85 50 95 C50 85 62 80 70 65 C80 45 65 30 50 10 Z" />
                  <path d="M50 25 C40 40 30 50 38 65 C43 73 50 80 50 85" />
                  <path d="M50 25 C60 40 70 50 62 65 C57 73 50 80 50 85" />
                  <circle cx="50" cy="50" r="3" className="fill-[#C5A059]/30" />
                </svg>

                {/* Section Title matching the screenshot */}
                <h2 className="text-2xl sm:text-3xl font-serif text-[#1A1A1A] tracking-widest font-normal">
                  {t.collections.title}
                </h2>
                <p className="text-[11px] tracking-[0.3em] text-[#8C8478] uppercase mt-1.5 font-sans font-medium">
                  {t.collections.subtitle}
                </p>
              </div>

              {/* Category Links with Right Arrow */}
              <nav className="flex flex-col space-y-4 my-8">
                {categories.map((cat) => {
                  const isActive = activeCategory === cat.id;
                  const label = language === 'zh' ? cat.labelZh : cat.labelEn;
                  return (
                    <button
                      key={cat.id}
                      onClick={() => setActiveCategory(cat.id)}
                      className={`group flex items-center justify-between text-left py-2 border-b transition-all duration-300 cursor-pointer ${
                        isActive
                          ? 'border-[#8B1E1E] text-[#8B1E1E] font-medium'
                          : 'border-[#E8E1D5] text-[#555047] hover:text-[#1A1A1A] hover:border-[#C5A059]'
                      }`}
                    >
                      <span className="text-sm tracking-widest font-serif">
                        {label}
                      </span>
                      <ArrowRight
                        className={`w-3.5 h-3.5 transition-transform duration-300 ${
                          isActive
                            ? 'translate-x-1 text-[#8B1E1E]'
                            : 'opacity-40 group-hover:opacity-100 group-hover:translate-x-1'
                        }`}
                      />
                    </button>
                  );
                })}
              </nav>
            </div>

            {/* Traditional Chinese Square Red Seal Stamp (印章) from screenshot */}
            <div className="pt-6 pb-2">
              <div
                className="chinese-seal w-11 h-11 text-xs font-bold select-none shadow-xs"
                title="云锦工坊印"
              >
                <span className="font-seal text-[11px] leading-tight text-[#A32828]">
                  云锦<br />工坊
                </span>
              </div>
              <p className="mt-3 text-[11px] text-[#9A9387] tracking-wider font-serif">
                {language === 'zh' ? '一千六百年皇家织金非遗传承' : '1,600 Years Imperial Heritage'}
              </p>
            </div>
          </div>

          {/* Right Column: 4-Column Responsive Product Grid */}
          <div className="lg:col-span-9">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {filteredProducts.map((product, idx) => {
                const formattedPrice = currency === 'USD'
                  ? `$${product.priceUSD.toLocaleString()}`
                  : `¥${product.price.toLocaleString()}`;

                return (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: idx * 0.1 }}
                    className="group flex flex-col justify-between bg-white border border-[#E8E1D5] p-3.5 transition-all duration-300 hover:shadow-xl hover:border-[#C5A059]/60"
                  >
                    {/* Product Image Stage */}
                    <div className="relative aspect-[4/3] sm:aspect-square w-full overflow-hidden bg-[#F3EFE6] cursor-pointer"
                         onClick={() => setSelectedProduct(product)}>
                      <Image
                        src={product.image}
                        alt={product.name}
                        fill
                        sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 25vw"
                        referrerPolicy="no-referrer"
                        className="object-cover object-center transition-transform duration-700 group-hover:scale-108"
                      />

                      {/* Tag Badge */}
                      {product.tag && (
                        <div className="absolute top-2.5 left-2.5 bg-black/75 backdrop-blur-xs text-[#C5A059] text-[10px] tracking-widest px-2 py-0.5 uppercase font-medium">
                          {language === 'zh' ? product.tag : product.tagEn}
                        </div>
                      )}

                      {/* Hover Action Overlay */}
                      <div className="absolute inset-0 bg-black/25 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedProduct(product);
                          }}
                          className="p-2.5 rounded-full bg-white text-[#1A1A1A] hover:bg-[#8B1E1E] hover:text-white transition-colors shadow-md"
                          title="查看详情"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            addToCart(product);
                          }}
                          className="p-2.5 rounded-full bg-white text-[#1A1A1A] hover:bg-[#8B1E1E] hover:text-white transition-colors shadow-md"
                          title="加入购物袋"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Product Info matching reference layout */}
                    <div className="pt-4 flex flex-col flex-grow justify-between">
                      <div>
                        {/* Product Title */}
                        <h3
                          onClick={() => setSelectedProduct(product)}
                          className="text-base font-serif font-medium text-[#1A1A1A] tracking-wider hover:text-[#8B1E1E] transition-colors cursor-pointer"
                        >
                          {language === 'zh' ? product.name : product.nameEn}
                        </h3>

                        {/* Poetic Subtitle */}
                        <p className="text-xs text-[#7A746B] font-serif tracking-wide mt-1.5 line-clamp-2 leading-relaxed">
                          {language === 'zh' ? product.subtitle : product.subtitleEn}
                        </p>
                      </div>

                      {/* Price & View Detail Action */}
                      <div className="pt-4 mt-3 border-t border-[#F0EBE1] flex items-center justify-between">
                        <span className="text-xs font-serif font-semibold text-[#8B1E1E] tracking-wider tabular-nums">
                          {formattedPrice}
                        </span>

                        <button
                          onClick={() => setSelectedProduct(product)}
                          className="group/link flex items-center gap-1.5 text-xs text-[#1A1A1A] hover:text-[#8B1E1E] transition-colors tracking-widest font-serif cursor-pointer"
                        >
                          <span>{t.collections.viewDetails}</span>
                          <ArrowRight className="w-3 h-3 text-[#C5A059] transition-transform group-hover/link:translate-x-1" />
                        </button>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
