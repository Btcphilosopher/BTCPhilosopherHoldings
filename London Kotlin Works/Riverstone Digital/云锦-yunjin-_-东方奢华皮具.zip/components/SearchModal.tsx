'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'motion/react';
import { useYunjinStore } from '@/hooks/use-yunjin-store';
import { Product } from '@/lib/types';
import { X, Search, ArrowRight } from 'lucide-react';

export default function SearchModal({ products }: { products: Product[] }) {
  const {
    isSearchOpen,
    setIsSearchOpen,
    setSelectedProduct,
    language,
    currency
  } = useYunjinStore();

  const [query, setQuery] = useState('');

  const results = React.useMemo(() => {
    if (!query.trim()) {
      return products.slice(0, 4);
    }
    const q = query.toLowerCase().trim();
    return products.filter((p) =>
      p.name.toLowerCase().includes(q) ||
      p.nameEn.toLowerCase().includes(q) ||
      p.subtitle.toLowerCase().includes(q) ||
      p.subtitleEn.toLowerCase().includes(q) ||
      p.materials.gemstone.toLowerCase().includes(q) ||
      p.materials.leather.toLowerCase().includes(q) ||
      p.lockType.toLowerCase().includes(q)
    );
  }, [query, products]);

  if (!isSearchOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-sm flex items-start justify-center p-4 sm:p-10 pt-16 sm:pt-24">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="relative w-full max-w-2xl bg-[#FBF9F5] border border-[#E8E1D5] shadow-2xl overflow-hidden"
        >
          {/* Close button */}
          <button
            onClick={() => setIsSearchOpen(false)}
            className="absolute top-4 right-4 z-20 p-2 text-[#7A746B] hover:text-[#1A1A1A] transition-colors rounded-full"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="p-6">
            {/* Search Input */}
            <div className="relative border-b border-[#C5A059] pb-3 flex items-center gap-3">
              <Search className="w-5 h-5 text-[#C5A059]" />
              <input
                type="text"
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={language === 'zh' ? '搜索手袋、和田玉锁、朱红、丝织云锦...' : 'Search collections, jade clasps, silk brocade...'}
                className="w-full bg-transparent text-sm sm:text-base font-serif text-[#1A1A1A] placeholder-[#9A9387] focus:outline-none tracking-wide"
              />
            </div>

            {/* Quick Keyword tags */}
            <div className="mt-4 flex flex-wrap items-center gap-2 text-xs font-serif text-[#6A6459]">
              <span className="text-[#8C8478]">{language === 'zh' ? '热门探索：' : 'Suggestions:'}</span>
              {['玉兰', '墨韵', '朱槿', '山水', '和田白玉', '花丝金锁'].map((tag) => (
                <button
                  key={tag}
                  onClick={() => setQuery(tag)}
                  className="px-2.5 py-1 bg-white border border-[#E8E1D5] hover:border-[#8B1E1E] hover:text-[#8B1E1E] transition-colors"
                >
                  {tag}
                </button>
              ))}
            </div>

            {/* Results list */}
            <div className="mt-6 max-h-[50vh] overflow-y-auto space-y-3">
              <span className="text-[10px] uppercase font-sans tracking-widest text-[#8C8478]">
                {query ? `${language === 'zh' ? '搜索结果' : 'Results'} (${results.length})` : (language === 'zh' ? '典藏推荐' : 'Featured Collections')}
              </span>

              {results.length === 0 ? (
                <div className="py-8 text-center text-xs text-[#8C8478] font-serif">
                  {language === 'zh' ? '未找到相关臻品，请尝试其他关键词' : 'No creations found matching your inquiry.'}
                </div>
              ) : (
                results.map((product) => {
                  const formattedPrice = currency === 'USD'
                    ? `$${product.priceUSD.toLocaleString()}`
                    : `¥${product.price.toLocaleString()}`;

                  return (
                    <div
                      key={product.id}
                      onClick={() => {
                        setSelectedProduct(product);
                        setIsSearchOpen(false);
                      }}
                      className="group flex items-center justify-between p-3 bg-white border border-[#E8E1D5] hover:border-[#8B1E1E] transition-all cursor-pointer shadow-2xs"
                    >
                      <div className="flex items-center gap-3">
                        <div className="relative w-12 h-12 bg-[#F3EFE6] shrink-0 overflow-hidden border border-[#E8E1D5]">
                          <Image
                            src={product.image}
                            alt={product.name}
                            fill
                            referrerPolicy="no-referrer"
                            className="object-cover"
                          />
                        </div>
                        <div>
                          <h4 className="text-xs sm:text-sm font-serif font-medium text-[#1A1A1A] group-hover:text-[#8B1E1E] transition-colors">
                            {language === 'zh' ? product.name : product.nameEn}
                          </h4>
                          <p className="text-[11px] text-[#7A746B] font-serif">
                            {product.lockType}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <span className="text-xs font-serif font-bold text-[#8B1E1E] tabular-nums">
                          {formattedPrice}
                        </span>
                        <ArrowRight className="w-3.5 h-3.5 text-[#C5A059] opacity-40 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
