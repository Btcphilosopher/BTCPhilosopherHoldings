'use client';

import React from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'motion/react';
import { useYunjinStore } from '@/hooks/use-yunjin-store';
import { X, Sparkles, Award, Shield } from 'lucide-react';

export default function CraftsmanshipModal() {
  const { isCraftOpen, setIsCraftOpen, language } = useYunjinStore();

  if (!isCraftOpen) return null;

  const steps = [
    {
      num: '01',
      titleZh: '寸锦寸金 · 南京木机妆花真丝织金',
      titleEn: '1,600-Year Ancient Drawloom Silk Weaving',
      descZh: '云锦为中国古代皇家御用织物，由两人在上、下一同于大花楼木织机上手工织造。至今仍无法用任何现代机器完全替代，每日仅能织造数厘米，故称“寸锦寸金”。云锦工坊精工将真金孔雀羽线与特级桑蚕丝织入包袋内衬，历久弥新。',
      descEn: 'Cloud Brocade cannot be replicated by any modern machinery. Two master weavers coordinate synchronously on ancient wooden drawlooms to weave just a few centimeters per day using pure silk, gold threads, and peacock feather filaments.',
      tag: '国家级非遗'
    },
    {
      num: '02',
      titleZh: '温润致祥 · 新疆和田羊脂白玉手工琢玉',
      titleEn: 'Hetian Mutton-Fat White Jade Lapidary Art',
      descZh: '甄选新疆和田优质白玉籽料，特邀扬州玉雕传人手工起板、粗磨、精雕与慢速水抛光。玉石锁扣通体温润柔滑，内敛含蓄，与金属构件以传统榫卯灵感严密咬合，成就经年触手生温之东方印记。',
      descEn: 'Carved from genuine Xinjiang Hetian white jade pebbles by master lapidaries. Softly polished to a lustrous mutton-fat sheen, each clasp is precision-mounted with mortise-and-tenon mechanical integrity.',
      tag: '天然玉石国检认证'
    },
    {
      num: '03',
      titleZh: '细若游丝 · 国家级非遗花丝镶嵌与古法金工',
      titleEn: 'Imperial 24K Gold Filigree Inlay',
      descZh: '花丝镶嵌源自燕京八绝之首，工匠将24K纯金或纯银拉成细若发丝的金丝，经掐、填、攒、焊等数十道手工工序编织出古典云纹及如意构架，再微镶天然南红玛瑙或祖母绿，气度非凡。',
      descEn: 'Dating back to imperial dynastic court workshops, master goldsmiths draw 24K gold wire as thin as silk thread, hand-weaving intricate openwork filigree lattices crowned with natural cabochons.',
      tag: '燕京八绝古法'
    },
    {
      num: '04',
      titleZh: '法式双针马鞍针法 · 手工特选皮料封边',
      titleEn: 'Traditional Double-Needle Saddle Stitching',
      descZh: '选用欧洲顶级Box Calf小牛皮与原生态鞣制皮革，使用两根针与一根天然浸蜡麻线，左右穿引回扣拉紧。即便日后其中一针磨损，整条缝线依然牢固不散，配合七遍天然植物色油手工封边。',
      descEn: 'Stitched entirely by hand using two needles and a single continuous beeswax-conditioned linen thread. Sealed with seven layers of natural vegetal lacquer for heirloom durability.',
      tag: '百年马鞍针法'
    }
  ];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 md:p-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="relative w-full max-w-4xl bg-[#FBF9F5] border border-[#E8E1D5] shadow-2xl overflow-hidden my-auto"
        >
          <button
            onClick={() => setIsCraftOpen(false)}
            className="absolute top-4 right-4 z-20 p-2 text-[#7A746B] hover:text-[#1A1A1A] transition-colors rounded-full"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="p-6 sm:p-10 max-h-[85vh] overflow-y-auto space-y-8">
            <div className="border-b border-[#E8E1D5] pb-4">
              <span className="text-[10px] tracking-[0.25em] uppercase text-[#8C8478] font-sans">
                ATELIER SAVOIR-FAIRE
              </span>
              <h3 className="text-2xl sm:text-3xl font-serif text-[#1A1A1A] tracking-wider font-medium mt-1">
                {language === 'zh' ? '云锦非遗与现代高奢皮具工艺' : 'The Haute Savoir-Faire of YUNJIN'}
              </h3>
              <p className="text-xs text-[#7A746B] font-serif mt-2 max-w-2xl leading-relaxed">
                {language === 'zh'
                  ? '以传统工艺，造就现代奢华。每一只云锦手袋，皆由平均拥有三十年以上工龄的非遗传人与皮具巨匠共同打造，历经两百余道精密手工工序。'
                  : 'Bridging timeless imperial artisanship with contemporary architectural leathercraft. Crafted by masters with over 30 years of dedicated discipline.'}
              </p>
            </div>

            {/* Visual Banner */}
            <div className="relative h-60 w-full overflow-hidden border border-[#E8E1D5]">
              <Image
                src="/images/craftsmanship_artisan.jpg"
                alt="Artisan Craftsmanship"
                fill
                referrerPolicy="no-referrer"
                className="object-cover object-center"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-6">
                <span className="text-white text-xs font-serif tracking-widest">
                  {language === 'zh' ? '南京云锦织锦工坊与金工琢玉台实景' : 'Live from the Nanjing Cloud Brocade & Lapidary Atelier'}
                </span>
              </div>
            </div>

            {/* 4 Steps */}
            <div className="space-y-6">
              {steps.map((st, i) => (
                <div key={i} className="p-5 bg-white border border-[#E8E1D5] flex flex-col sm:flex-row gap-5 items-start">
                  <div className="text-2xl font-serif font-bold text-[#8B1E1E] tabular-nums shrink-0">
                    {st.num}
                  </div>
                  <div className="flex-1 space-y-1.5">
                    <div className="flex items-center gap-3">
                      <h4 className="text-base font-serif font-medium text-[#1A1A1A]">
                        {language === 'zh' ? st.titleZh : st.titleEn}
                      </h4>
                      <span className="text-[10px] text-[#C5A059] border border-[#C5A059]/40 px-2 py-0.5">
                        {st.tag}
                      </span>
                    </div>
                    <p className="text-xs text-[#555047] font-serif leading-relaxed">
                      {language === 'zh' ? st.descZh : st.descEn}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-4 border-t border-[#E8E1D5] flex justify-end">
              <button
                onClick={() => setIsCraftOpen(false)}
                className="px-6 py-2.5 bg-[#1A1A1A] text-white text-xs font-serif tracking-widest uppercase hover:bg-[#8B1E1E]"
              >
                {language === 'zh' ? '知悉并返回' : 'Return'}
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
