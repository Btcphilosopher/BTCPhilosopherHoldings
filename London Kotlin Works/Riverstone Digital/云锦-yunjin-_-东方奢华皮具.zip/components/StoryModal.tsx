'use client';

import React from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'motion/react';
import { useYunjinStore } from '@/hooks/use-yunjin-store';
import { X } from 'lucide-react';

export default function StoryModal() {
  const { isStoryOpen, setIsStoryOpen, language } = useYunjinStore();

  if (!isStoryOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 md:p-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="relative w-full max-w-4xl bg-[#FBF9F5] border border-[#E8E1D5] shadow-2xl overflow-hidden my-auto"
        >
          <button
            onClick={() => setIsStoryOpen(false)}
            className="absolute top-4 right-4 z-20 p-2 text-[#7A746B] hover:text-[#1A1A1A] transition-colors rounded-full"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="p-6 sm:p-10 max-h-[85vh] overflow-y-auto space-y-8">
            <div className="border-b border-[#E8E1D5] pb-4">
              <span className="text-[10px] tracking-[0.25em] uppercase text-[#8C8478] font-sans">
                HERITAGE & VISION
              </span>
              <h3 className="text-2xl sm:text-3xl font-serif text-[#1A1A1A] tracking-wider font-medium mt-1">
                {language === 'zh' ? '源于东方 · 走向世界' : 'Rooted in the East, Reaching the World'}
              </h3>
              <p className="text-xs text-[#8B1E1E] font-serif tracking-widest mt-1">
                {language === 'zh' ? '云锦品牌起源与东方美学哲学' : 'The Origins & Aesthetic Philosophy of YUNJIN'}
              </p>
            </div>

            {/* Visual Banner */}
            <div className="relative h-64 w-full overflow-hidden border border-[#E8E1D5]">
              <Image
                src="/images/brand_story_pagoda.jpg"
                alt="Brand Story Pagoda Landscape"
                fill
                referrerPolicy="no-referrer"
                className="object-cover object-center"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent flex items-end p-6">
                <span className="text-white text-xs font-serif tracking-widest">
                  {language === 'zh' ? '江南山水与东方诗意建筑' : 'Jiangnan Serenity & Imperial Architecture'}
                </span>
              </div>
            </div>

            {/* Narrative text */}
            <div className="space-y-5 text-xs sm:text-sm text-[#4A453E] font-serif leading-relaxed">
              <p>
                {language === 'zh'
                  ? '千百年来，东方奢华从未追逐浮华的喧嚣，而是沉淀于深邃的文人风骨、内敛的哲学沉思与极致的手工造物之中。南朝伊始，江宁织锦便专供皇室，元明清三代设江宁织造府，云锦更被尊为锦中冠冕。'
                  : 'For centuries, true Eastern luxury has never chased ephemeral trends. Instead, it flourishes in poetic restraint, scholarly poise, and extraordinary manual mastery. Cloud Brocade originated 1,600 years ago during the Southern Dynasties, becoming the crown jewel of imperial court wear throughout the Ming and Qing Dynasties.'}
              </p>
              <p>
                {language === 'zh'
                  ? '“云锦”品牌诞生于对东方千年手工艺断代危机与当代女性自我表达的深刻思考。我们坚信：真正的中国高奢，不应只是西方皮具轮廓上附着简单的东方符号，而是由内而外的文化重塑——将和田玉的温润、金银丝的剔透、云锦丝织的璀璨与现代建筑感皮具线条融为一体。'
                  : 'YUNJIN was founded with a profound mission: to awaken centuries-old Chinese heritage crafts and celebrate the sovereign strength of modern women. True Chinese haute luxury is not merely applying superficial motifs onto Western silhouettes; it is a profound reimagination that fuses the tactile warmth of jade, the luminosity of gold filigree, and the architectural discipline of contemporary leatherwork.'}
              </p>
              <p>
                {language === 'zh'
                  ? '今天，云锦手袋已跨越山海，从南京与苏州的私密工坊走向巴黎、米兰、东京与纽约，成为全球品味雅士出席世界舞台时无声却极具力量的文化语言。'
                  : 'Today, YUNJIN creations travel across oceans, bridging private ateliers in Nanjing with collectors in Paris, Tokyo, London, and New York. A silent yet magnificent cultural ambassador on the world stage.'}
              </p>
            </div>

            {/* Red Seal */}
            <div className="pt-4 border-t border-[#E8E1D5] flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="chinese-seal w-8 h-8 text-[9px]">
                  <span className="font-seal">天工<br />开物</span>
                </div>
                <span className="text-xs font-serif text-[#8C8478]">云锦高级皮具研造局 · 敬立</span>
              </div>

              <button
                onClick={() => setIsStoryOpen(false)}
                className="px-6 py-2 bg-[#1A1A1A] text-white text-xs font-serif tracking-widest uppercase hover:bg-[#8B1E1E]"
              >
                {language === 'zh' ? '关闭' : 'Close'}
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
