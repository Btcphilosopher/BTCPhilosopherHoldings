'use client';

import React from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'motion/react';
import { useYunjinStore } from '@/hooks/use-yunjin-store';
import { X, Trash2, ShieldCheck, ArrowRight, Gift } from 'lucide-react';

export default function CartDrawer() {
  const {
    isCartOpen,
    setIsCartOpen,
    setIsCheckoutOpen,
    cart,
    removeFromCart,
    updateQuantity,
    cartTotal,
    language,
    currency,
    t
  } = useYunjinStore();

  if (!isCartOpen) return null;

  const formattedTotal = currency === 'USD'
    ? `$${cartTotal.toLocaleString()}`
    : `¥${cartTotal.toLocaleString()}`;

  const handleProceedToCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-xs flex justify-end">
        {/* Backdrop click */}
        <div
          className="absolute inset-0"
          onClick={() => setIsCartOpen(false)}
        />

        {/* Drawer panel */}
        <motion.div
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ type: 'spring', damping: 28, stiffness: 260 }}
          className="relative w-full max-w-md bg-[#FBF9F5] h-full shadow-2xl flex flex-col justify-between border-l border-[#E8E1D5]"
        >
          {/* Header */}
          <div className="p-6 border-b border-[#E8E1D5] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="text-lg font-serif font-medium text-[#1A1A1A] tracking-wider">
                {t.cart.title}
              </span>
              <span className="text-xs text-[#8C8478] font-sans font-bold">
                ({cart.reduce((s, i) => s + i.quantity, 0)})
              </span>
            </div>
            <button
              onClick={() => setIsCartOpen(false)}
              className="p-2 text-[#7A746B] hover:text-[#1A1A1A] transition-colors rounded-full hover:bg-black/5"
              aria-label="Close cart"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Item List */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6 divide-y divide-[#E8E1D5]">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-16 space-y-4">
                <div className="w-16 h-16 rounded-full bg-[#F3EFE6] flex items-center justify-center text-[#8C8478]">
                  <Gift className="w-8 h-8" />
                </div>
                <p className="text-sm font-serif text-[#7A746B] max-w-xs leading-relaxed">
                  {t.cart.empty}
                </p>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="px-6 py-2.5 border border-[#1A1A1A] text-xs font-serif tracking-widest uppercase hover:bg-[#1A1A1A] hover:text-white transition-colors"
                >
                  {language === 'zh' ? '浏览典藏系列' : 'Explore Collections'}
                </button>
              </div>
            ) : (
              cart.map((item) => {
                const itemPrice = currency === 'USD'
                  ? item.product.priceUSD * item.quantity
                  : item.product.price * item.quantity;
                const formattedItemPrice = currency === 'USD'
                  ? `$${itemPrice.toLocaleString()}`
                  : `¥${itemPrice.toLocaleString()}`;

                return (
                  <div key={item.id} className="pt-6 first:pt-0 flex gap-4">
                    {/* Thumbnail */}
                    <div className="relative w-20 h-20 shrink-0 bg-[#F3EFE6] border border-[#E8E1D5] overflow-hidden">
                      <Image
                        src={item.product.image}
                        alt={item.product.name}
                        fill
                        referrerPolicy="no-referrer"
                        className="object-cover"
                      />
                    </div>

                    {/* Details */}
                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex items-start justify-between">
                          <h4 className="text-sm font-serif font-medium text-[#1A1A1A] tracking-wide">
                            {language === 'zh' ? item.product.name : item.product.nameEn}
                          </h4>
                          <button
                            onClick={() => removeFromCart(item.id)}
                            className="text-[#9A9387] hover:text-[#8B1E1E] transition-colors p-1"
                            title="移除"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <p className="text-xs text-[#7A746B] font-serif mt-0.5">
                          {language === 'zh' ? item.selectedVariant.name : item.selectedVariant.nameEn}
                        </p>

                        {/* Bespoke Tag */}
                        {item.personalization && (
                          <div className="mt-1.5 inline-flex items-center gap-1.5 px-2 py-0.5 bg-[#8B1E1E]/5 border border-[#8B1E1E]/30 text-[10px] text-[#8B1E1E] font-serif">
                            <span>客制烫印:</span>
                            <span className="font-bold tracking-widest">{item.personalization.text}</span>
                            <span>({item.personalization.finish === 'gold' ? '24K金箔' : item.personalization.finish === 'silver' ? '雅银' : '素压'})</span>
                          </div>
                        )}
                      </div>

                      {/* Quantity & Price */}
                      <div className="flex items-center justify-between mt-3">
                        <div className="flex items-center border border-[#E8E1D5] bg-white text-xs">
                          <button
                            onClick={() => updateQuantity(item.id, -1)}
                            className="px-2 py-1 hover:bg-[#F5F1E9]"
                          >
                            -
                          </button>
                          <span className="px-2 py-1 font-bold tabular-nums min-w-[24px] text-center">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.id, 1)}
                            className="px-2 py-1 hover:bg-[#F5F1E9]"
                          >
                            +
                          </button>
                        </div>

                        <span className="text-sm font-serif font-bold text-[#8B1E1E] tabular-nums">
                          {formattedItemPrice}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Footer Summary & Checkout */}
          {cart.length > 0 && (
            <div className="p-6 bg-[#F5F1E9] border-t border-[#E8E1D5] space-y-4">
              <div className="space-y-1.5 text-xs font-serif text-[#6A6459]">
                <div className="flex items-center justify-between">
                  <span>{t.cart.subtotal}</span>
                  <span className="tabular-nums font-medium text-[#1A1A1A]">{formattedTotal}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>{t.cart.shipping}</span>
                  <span className="text-[#8B1E1E] font-medium">{t.cart.complimentary}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>{t.cart.tax}</span>
                  <span className="text-[#8C8478]">{language === 'zh' ? '增值税已计入' : 'Included'}</span>
                </div>
              </div>

              <div className="pt-3 border-t border-[#E8E1D5] flex items-center justify-between">
                <span className="text-base font-serif font-medium text-[#1A1A1A]">
                  {t.cart.total}
                </span>
                <span className="text-xl font-serif font-bold text-[#8B1E1E] tabular-nums">
                  {formattedTotal}
                </span>
              </div>

              <button
                onClick={handleProceedToCheckout}
                className="w-full flex items-center justify-center gap-3 py-3.5 bg-[#8B1E1E] text-white text-xs font-serif tracking-widest uppercase hover:bg-[#A32828] transition-all shadow-md cursor-pointer"
              >
                <span>{t.cart.checkout}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-center gap-2 text-[10px] text-[#8C8478] font-serif pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-[#C5A059]" />
                <span>顺丰特快保价 · 专属木匣密封包装</span>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
