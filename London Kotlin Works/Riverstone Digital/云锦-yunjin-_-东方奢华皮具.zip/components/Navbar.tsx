'use client';

import React, { useState, useEffect } from 'react';
import { useYunjinStore } from '@/hooks/use-yunjin-store';
import { Search, ShoppingBag, Sparkles, MapPin, Globe, Menu, X, ShieldCheck } from 'lucide-react';

export default function Navbar() {
  const {
    language,
    setLanguage,
    t,
    cartCount,
    setIsCartOpen,
    setIsSearchOpen,
    setIsConciergeOpen,
    setIsBoutiqueOpen,
    setIsCraftOpen,
    setIsStoryOpen
  } = useYunjinStore();

  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 24);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleLanguage = () => {
    setLanguage(language === 'zh' ? 'en' : 'zh');
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#FBF9F5]/90 backdrop-blur-md border-b border-[#E8E1D5] py-3.5 shadow-xs'
          : 'bg-gradient-to-b from-black/60 via-black/25 to-transparent text-white py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8 flex items-center justify-between gap-8">
        
        {/* Zone 1: Brand Lockup */}
        <a
          href="#home"
          className="flex items-center gap-3 group shrink-0"
          aria-label="YUNJIN Homepage"
        >
          {/* Traditional Cloud Knot Emblem */}
          <div
            className={`w-9 h-9 rounded-full flex items-center justify-center transition-transform group-hover:scale-105 ${
              isScrolled
                ? 'border border-[#C5A059]/40 bg-[#C5A059]/10 text-[#8B1E1E]'
                : 'border border-white/40 bg-white/10 text-white'
            }`}
          >
            <svg
              className="w-5 h-5 fill-current"
              viewBox="0 0 24 24"
            >
              <path d="M12 2C8.69 2 6 4.69 6 8c0 .48.06.94.17 1.39C4.34 10.15 3 11.91 3 14c0 2.76 2.24 5 5 5h8c2.76 0 5-2.24 5-5 0-2.09-1.34-3.85-3.17-4.61.11-.45.17-.91.17-1.39 0-3.31-2.69-6-6-6zm0 2c2.21 0 4 1.79 4 4 0 .28-.03.56-.09.83-.2.96.42 1.9 1.39 2.1 1.62.33 2.7 1.76 2.7 3.07 0 1.66-1.34 3-3 3H8c-1.66 0-3-1.34-3-3 0-1.31 1.08-2.74 2.7-3.07.97-.2 1.59-1.14 1.39-2.1-.06-.27-.09-.55-.09-.83 0-2.21 1.79-4 4-4z" />
            </svg>
          </div>

          <div className="flex flex-col">
            <span
              className={`text-xl font-bold tracking-widest font-serif leading-none transition-colors ${
                isScrolled ? 'text-[#1A1A1A]' : 'text-white'
              }`}
            >
              云锦
            </span>
            <span
              className={`text-[9px] tracking-[0.25em] font-sans font-medium uppercase transition-colors ${
                isScrolled ? 'text-[#8A857C]' : 'text-white/80'
              }`}
            >
              YUNJIN
            </span>
          </div>
        </a>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden lg:flex items-center gap-8 text-sm font-medium tracking-wider">
          <a
            href="#home"
            className={`whitespace-nowrap transition-colors relative pb-1 group ${
              isScrolled
                ? 'text-[#2C2A26] hover:text-[#8B1E1E]'
                : 'text-white/90 hover:text-white'
            }`}
          >
            {t.nav.home}
            <span className="absolute bottom-0 left-0 w-full h-[1.5px] bg-[#C5A059] opacity-0 group-hover:opacity-100 transition-opacity" />
          </a>
          <a
            href="#collections"
            className={`whitespace-nowrap transition-colors relative pb-1 group ${
              isScrolled
                ? 'text-[#2C2A26] hover:text-[#8B1E1E]'
                : 'text-white/90 hover:text-white'
            }`}
          >
            {t.nav.collections}
            <span className="absolute bottom-0 left-0 w-full h-[1.5px] bg-[#C5A059] opacity-0 group-hover:opacity-100 transition-opacity" />
          </a>
          <button
            onClick={() => setIsStoryOpen(true)}
            className={`whitespace-nowrap transition-colors relative pb-1 group cursor-pointer ${
              isScrolled
                ? 'text-[#2C2A26] hover:text-[#8B1E1E]'
                : 'text-white/90 hover:text-white'
            }`}
          >
            {t.nav.story}
            <span className="absolute bottom-0 left-0 w-full h-[1.5px] bg-[#C5A059] opacity-0 group-hover:opacity-100 transition-opacity" />
          </button>
          <button
            onClick={() => setIsCraftOpen(true)}
            className={`whitespace-nowrap transition-colors relative pb-1 group cursor-pointer ${
              isScrolled
                ? 'text-[#2C2A26] hover:text-[#8B1E1E]'
                : 'text-white/90 hover:text-white'
            }`}
          >
            {t.nav.craft}
            <span className="absolute bottom-0 left-0 w-full h-[1.5px] bg-[#C5A059] opacity-0 group-hover:opacity-100 transition-opacity" />
          </button>
          <button
            onClick={() => setIsBoutiqueOpen(true)}
            className={`whitespace-nowrap transition-colors relative pb-1 group cursor-pointer ${
              isScrolled
                ? 'text-[#2C2A26] hover:text-[#8B1E1E]'
                : 'text-white/90 hover:text-white'
            }`}
          >
            {t.nav.boutiques}
            <span className="absolute bottom-0 left-0 w-full h-[1.5px] bg-[#C5A059] opacity-0 group-hover:opacity-100 transition-opacity" />
          </button>
        </nav>

        {/* Zone 3: Actions & Affordances */}
        <div className="flex items-center gap-5 shrink-0">
          
          {/* Language Switcher */}
          <button
            onClick={toggleLanguage}
            className={`flex items-center gap-1.5 text-xs font-medium tracking-widest px-2.5 py-1 rounded transition-colors ${
              isScrolled
                ? 'text-[#4A453E] hover:text-[#1A1A1A] hover:bg-black/5'
                : 'text-white/90 hover:text-white hover:bg-white/10'
            }`}
            title="Switch Language / 切换语言"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>{language === 'zh' ? '中文' : 'EN'}</span>
            <span className="text-[10px] opacity-60">▾</span>
          </button>

          {/* Search trigger */}
          <button
            onClick={() => setIsSearchOpen(true)}
            className={`p-2 rounded-full transition-colors ${
              isScrolled
                ? 'text-[#2C2A26] hover:text-[#8B1E1E] hover:bg-black/5'
                : 'text-white hover:bg-white/10'
            }`}
            aria-label="Search"
            title="搜索臻品"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* AI VIP Concierge Consultation */}
          <button
            onClick={() => setIsConciergeOpen(true)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium tracking-wide transition-all border ${
              isScrolled
                ? 'border-[#C5A059]/50 text-[#8B1E1E] bg-[#C5A059]/10 hover:bg-[#C5A059]/20'
                : 'border-white/40 text-white bg-white/10 hover:bg-white/20'
            }`}
            title="私人定制顾问"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#C5A059]" />
            <span className="hidden sm:inline">{t.nav.concierge}</span>
          </button>

          {/* Shopping Bag Trigger */}
          <button
            onClick={() => setIsCartOpen(true)}
            className={`relative p-2 rounded-full transition-colors ${
              isScrolled
                ? 'text-[#2C2A26] hover:text-[#8B1E1E] hover:bg-black/5'
                : 'text-white hover:bg-white/10'
            }`}
            aria-label="Shopping Bag"
            title={t.nav.bag}
          >
            <ShoppingBag className="w-4 h-4" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] rounded-full bg-[#8B1E1E] text-white text-[10px] font-bold flex items-center justify-center px-1 animate-fadeIn">
                {cartCount}
              </span>
            )}
          </button>

          {/* Mobile hamburger menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className={`lg:hidden p-2 rounded-md ${
              isScrolled ? 'text-[#2C2A26]' : 'text-white'
            }`}
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#FBF9F5] border-b border-[#E8E1D5] px-6 py-6 text-[#1A1A1A] space-y-4 animate-fadeIn">
          <nav className="flex flex-col space-y-3 text-base font-serif">
            <a
              href="#home"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1 border-b border-[#E8E1D5]/40 hover:text-[#8B1E1E]"
            >
              {t.nav.home}
            </a>
            <a
              href="#collections"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1 border-b border-[#E8E1D5]/40 hover:text-[#8B1E1E]"
            >
              {t.nav.collections}
            </a>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                setIsStoryOpen(true);
              }}
              className="text-left py-1 border-b border-[#E8E1D5]/40 hover:text-[#8B1E1E]"
            >
              {t.nav.story}
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                setIsCraftOpen(true);
              }}
              className="text-left py-1 border-b border-[#E8E1D5]/40 hover:text-[#8B1E1E]"
            >
              {t.nav.craft}
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                setIsBoutiqueOpen(true);
              }}
              className="text-left py-1 border-b border-[#E8E1D5]/40 hover:text-[#8B1E1E]"
            >
              {t.nav.boutiques}
            </button>
          </nav>
        </div>
      )}
    </header>
  );
}
