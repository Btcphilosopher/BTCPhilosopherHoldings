'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'motion/react';
import { useYunjinStore } from '@/hooks/use-yunjin-store';
import { CustomerInfo, Order } from '@/lib/types';
import { X, CheckCircle2, ShieldCheck, Lock, ArrowRight, Printer } from 'lucide-react';

export default function CheckoutModal() {
  const {
    isCheckoutOpen,
    setIsCheckoutOpen,
    cart,
    clearCart,
    cartTotal,
    language,
    currency,
    t,
    lastOrder,
    setLastOrder
  } = useYunjinStore();

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'wechat' | 'alipay' | 'unionpay' | 'card'>('wechat');

  const [formData, setFormData] = useState<CustomerInfo>({
    fullName: '林雅琴 (Ms. Lin)',
    phone: '138 0012 8888',
    email: 'yalin@oriental-luxury.cn',
    address: '黄浦区中山东一路27号外滩罗斯福公馆801室',
    city: '上海市',
    provinceOrState: '上海',
    postalCode: '200002',
    country: '中国',
    vipNote: '请工坊附带红木大漆典藏礼盒与手写致礼贺卡'
  });

  if (!isCheckoutOpen) return null;

  const formattedTotal = currency === 'USD'
    ? `$${cartTotal.toLocaleString()}`
    : `¥${cartTotal.toLocaleString()}`;

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: cart,
          customer: formData,
          paymentMethod,
          currency
        })
      });

      const res = await response.json();
      if (res.success && res.data) {
        setLastOrder(res.data);
        clearCart();
      } else {
        alert(res.error || '下单遇到问题，请重试');
      }
    } catch (err: any) {
      console.error(err);
      alert('网络繁忙，请稍后重试');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    setIsCheckoutOpen(false);
    setLastOrder(null);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="relative w-full max-w-3xl bg-[#FBF9F5] border border-[#E8E1D5] shadow-2xl overflow-hidden my-auto"
        >
          {/* Close button */}
          <button
            onClick={handleClose}
            className="absolute top-4 right-4 z-20 p-2 text-[#7A746B] hover:text-[#1A1A1A] transition-colors rounded-full"
            aria-label="Close checkout"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Success Confirmation View */}
          {lastOrder ? (
            <div className="p-8 sm:p-12 text-center space-y-6">
              <div className="w-16 h-16 rounded-full bg-[#8B1E1E]/10 text-[#8B1E1E] flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <h3 className="text-2xl font-serif text-[#1A1A1A] tracking-wider font-medium">
                  {t.checkout.orderSuccess}
                </h3>
                <p className="text-xs text-[#7A746B] font-serif mt-1">
                  云锦高级皮具工坊已收到阁下的尊崇订购，工匠正以传统非遗工艺为您甄选包覆
                </p>
              </div>

              {/* Certificate & Receipt Card */}
              <div className="p-6 bg-white border border-[#E8E1D5] max-w-lg mx-auto text-left space-y-3 font-serif text-xs shadow-xs">
                <div className="flex items-center justify-between pb-3 border-b border-[#E8E1D5]">
                  <span className="text-[#8C8478]">{t.checkout.orderNumberPrefix}:</span>
                  <span className="font-bold font-sans text-sm text-[#1A1A1A] tracking-wider">
                    {lastOrder.orderNumber}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#8C8478]">{t.checkout.certificatePrefix}:</span>
                  <span className="font-bold text-[#8B1E1E] tracking-wider">
                    {lastOrder.certificateId}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#8C8478]">{t.checkout.trackingPrefix}:</span>
                  <span className="font-sans font-medium text-[#1A1A1A]">
                    {lastOrder.trackingNumber}
                  </span>
                </div>
                <div className="flex items-center justify-between pt-3 border-t border-[#E8E1D5]">
                  <span className="text-[#8C8478]">收件贵宾:</span>
                  <span className="font-medium text-[#1A1A1A]">{lastOrder.customer.fullName}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#8C8478]">配送地址:</span>
                  <span className="text-[#1A1A1A] max-w-[280px] text-right truncate">
                    {lastOrder.customer.address}
                  </span>
                </div>
              </div>

              <div className="flex justify-center gap-4 pt-4">
                <button
                  onClick={handleClose}
                  className="px-8 py-3 bg-[#1A1A1A] text-white text-xs font-serif tracking-widest uppercase hover:bg-[#8B1E1E] transition-colors"
                >
                  {t.checkout.continueShopping}
                </button>
              </div>
            </div>
          ) : (
            /* Checkout Form */
            <form onSubmit={handleSubmitOrder} className="p-6 sm:p-10 max-h-[85vh] overflow-y-auto space-y-8">
              {/* Header */}
              <div className="border-b border-[#E8E1D5] pb-4">
                <span className="text-[10px] tracking-[0.25em] uppercase text-[#8C8478] font-sans">
                  YUNJIN PRIVATE ORDER
                </span>
                <h3 className="text-xl sm:text-2xl font-serif text-[#1A1A1A] tracking-wide font-medium mt-1">
                  {t.checkout.title}
                </h3>
              </div>

              {/* Step 1: Address */}
              <div className="space-y-4">
                <h4 className="text-xs uppercase tracking-widest text-[#8B1E1E] font-sans font-bold flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-[#8B1E1E] text-white text-[10px] flex items-center justify-center">1</span>
                  <span>{t.checkout.step1}</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-serif text-[#555047] mb-1">
                      {t.checkout.name} *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      className="w-full bg-white border border-[#E8E1D5] px-3.5 py-2 text-xs font-serif text-[#1A1A1A] focus:outline-none focus:border-[#C5A059]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-serif text-[#555047] mb-1">
                      {t.checkout.phone} *
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full bg-white border border-[#E8E1D5] px-3.5 py-2 text-xs font-serif text-[#1A1A1A] focus:outline-none focus:border-[#C5A059]"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-serif text-[#555047] mb-1">
                      {t.checkout.email} *
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full bg-white border border-[#E8E1D5] px-3.5 py-2 text-xs font-serif text-[#1A1A1A] focus:outline-none focus:border-[#C5A059]"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-serif text-[#555047] mb-1">
                      {t.checkout.address} *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      className="w-full bg-white border border-[#E8E1D5] px-3.5 py-2 text-xs font-serif text-[#1A1A1A] focus:outline-none focus:border-[#C5A059]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-serif text-[#555047] mb-1">
                      {t.checkout.city} *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      className="w-full bg-white border border-[#E8E1D5] px-3.5 py-2 text-xs font-serif text-[#1A1A1A] focus:outline-none focus:border-[#C5A059]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-serif text-[#555047] mb-1">
                      {t.checkout.postal} *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.postalCode}
                      onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
                      className="w-full bg-white border border-[#E8E1D5] px-3.5 py-2 text-xs font-serif text-[#1A1A1A] focus:outline-none focus:border-[#C5A059]"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-serif text-[#555047] mb-1">
                      {t.checkout.note}
                    </label>
                    <textarea
                      rows={2}
                      value={formData.vipNote}
                      onChange={(e) => setFormData({ ...formData, vipNote: e.target.value })}
                      className="w-full bg-white border border-[#E8E1D5] px-3.5 py-2 text-xs font-serif text-[#1A1A1A] focus:outline-none focus:border-[#C5A059]"
                    />
                  </div>
                </div>
              </div>

              {/* Step 2: Payment Method */}
              <div className="space-y-4">
                <h4 className="text-xs uppercase tracking-widest text-[#8B1E1E] font-sans font-bold flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-[#8B1E1E] text-white text-[10px] flex items-center justify-center">2</span>
                  <span>{t.checkout.step2}</span>
                </h4>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {[
                    { id: 'wechat', label: '微信支付', sub: 'WeChat Pay', icon: '🟢' },
                    { id: 'alipay', label: '支付宝', sub: 'Alipay', icon: '🔵' },
                    { id: 'unionpay', label: '银联国际', sub: 'UnionPay', icon: '🔴' },
                    { id: 'card', label: 'Apple Pay', sub: 'Credit Card', icon: '💳' }
                  ].map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => setPaymentMethod(p.id as any)}
                      className={`p-3 border text-left flex flex-col justify-between transition-all cursor-pointer ${
                        paymentMethod === p.id
                          ? 'border-[#8B1E1E] bg-[#8B1E1E]/5 shadow-xs'
                          : 'border-[#E8E1D5] bg-white hover:border-[#C5A059]'
                      }`}
                    >
                      <div className="text-base">{p.icon}</div>
                      <div className="mt-2">
                        <div className="text-xs font-serif font-medium text-[#1A1A1A]">{p.label}</div>
                        <div className="text-[10px] text-[#8C8478]">{p.sub}</div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Summary & Submit */}
              <div className="pt-6 border-t border-[#E8E1D5] flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="text-left w-full sm:w-auto">
                  <span className="text-xs text-[#8C8478] font-serif block">应付合计 (含税免邮)</span>
                  <span className="text-2xl font-serif font-bold text-[#8B1E1E] tabular-nums">
                    {formattedTotal}
                  </span>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full sm:w-auto px-8 py-3.5 bg-[#8B1E1E] text-white text-xs font-serif tracking-widest uppercase hover:bg-[#A32828] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md disabled:opacity-50"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>{isSubmitting ? t.checkout.processing : t.checkout.placeOrder}</span>
                </button>
              </div>
            </form>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
