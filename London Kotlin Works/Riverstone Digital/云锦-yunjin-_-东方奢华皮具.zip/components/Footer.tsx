'use client';

import React from 'react';
import { useYunjinStore } from '@/hooks/use-yunjin-store';

export default function Footer() {
  const { t, setIsStoryOpen, setIsCraftOpen, setIsBoutiqueOpen } = useYunjinStore();

  return (
    <footer className="bg-[#FAF8F4] border-t border-[#E8E1D5] py-16 px-6 sm:px-8">
      <div className="max-w-7xl mx-auto flex flex-col items-center">
        
        {/* Brand Mark matching reference footer */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full border border-[#C5A059]/50 bg-[#C5A059]/10 text-[#8B1E1E] flex items-center justify-center">
            <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
              <path d="M12 2C8.69 2 6 4.69 6 8c0 .48.06.94.17 1.39C4.34 10.15 3 11.91 3 14c0 2.76 2.24 5 5 5h8c2.76 0 5-2.24 5-5 0-2.09-1.34-3.85-3.17-4.61.11-.45.17-.91.17-1.39 0-3.31-2.69-6-6-6zm0 2c2.21 0 4 1.79 4 4 0 .28-.03.56-.09.83-.2.96.42 1.9 1.39 2.1 1.62.33 2.7 1.76 2.7 3.07 0 1.66-1.34 3-3 3H8c-1.66 0-3-1.34-3-3 0-1.31 1.08-2.74 2.7-3.07.97-.2 1.59-1.14 1.39-2.1-.06-.27-.09-.55-.09-.83 0-2.21 1.79-4 4-4z" />
            </svg>
          </div>
          <div className="flex flex-col text-left">
            <span className="text-lg font-serif font-bold tracking-widest text-[#1A1A1A]">
              云锦
            </span>
            <span className="text-[8px] tracking-[0.25em] font-sans font-medium uppercase text-[#8C8478]">
              YUNJIN
            </span>
          </div>
        </div>

        {/* Navigation Links matching reference */}
        <nav className="mt-8 flex flex-wrap items-center justify-center gap-4 sm:gap-8 text-xs font-serif tracking-widest text-[#555047]">
          <button
            onClick={() => setIsStoryOpen(true)}
            className="hover:text-[#8B1E1E] transition-colors cursor-pointer"
          >
            {t.footer.story}
          </button>
          <span className="text-[#C5A059]/40">|</span>
          <button
            onClick={() => setIsCraftOpen(true)}
            className="hover:text-[#8B1E1E] transition-colors cursor-pointer"
          >
            {t.footer.shoppingGuide}
          </button>
          <span className="text-[#C5A059]/40">|</span>
          <button
            onClick={() => setIsBoutiqueOpen(true)}
            className="hover:text-[#8B1E1E] transition-colors cursor-pointer"
          >
            {t.footer.vipCenter}
          </button>
          <span className="text-[#C5A059]/40">|</span>
          <button
            onClick={() => setIsBoutiqueOpen(true)}
            className="hover:text-[#8B1E1E] transition-colors cursor-pointer"
          >
            {t.footer.contact}
          </button>
        </nav>

        {/* Social Media Icons & Copyright */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-between w-full pt-8 border-t border-[#E8E1D5]/60 text-xs text-[#8A8376]">
          {/* Copyright matching screenshot */}
          <p className="order-2 sm:order-1 mt-4 sm:mt-0 tracking-wider font-sans text-center sm:text-left">
            {t.footer.copyright}
          </p>

          {/* Social Icons matching screenshot: WeChat, Weibo, Instagram, YouTube */}
          <div className="order-1 sm:order-2 flex items-center gap-5">
            {/* WeChat */}
            <span className="p-1.5 rounded-full hover:text-[#8B1E1E] transition-colors cursor-pointer" title="微信公众号">
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M8.5 2C4.36 2 1 4.91 1 8.5c0 1.95.98 3.7 2.53 4.88l-.66 2.01 2.36-1.18c.99.39 2.1.6 3.27.6.21 0 .42-.01.63-.03-.23-.62-.35-1.28-.35-1.97 0-3.32 3.09-6 6.9-6 .46 0 .91.04 1.34.12C16.03 4.54 12.59 2 8.5 2zm-2.25 4a1.25 1.25 0 110 2.5 1.25 1.25 0 010-2.5zm4.5 0a1.25 1.25 0 110 2.5 1.25 1.25 0 010-2.5zm5.55 4.5c-3.14 0-5.7 2.19-5.7 4.9 0 1.55.83 2.92 2.12 3.84l-.52 1.59 1.86-.93c.69.26 1.45.4 2.24.4 3.14 0 5.7-2.19 5.7-4.9s-2.56-4.9-5.7-4.9zm-2 3.1a1 1 0 110 2 1 1 0 010-2zm4 0a1 1 0 110 2 1 1 0 010-2z" />
              </svg>
            </span>

            {/* Weibo */}
            <span className="p-1.5 rounded-full hover:text-[#8B1E1E] transition-colors cursor-pointer" title="新浪微博">
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M10.2 16.8c-2.8.2-5.1-1.3-5.2-3.4-.1-2.1 2.1-3.9 4.9-4.1 2.8-.2 5.1 1.3 5.2 3.4.1 2.1-2.1 4-4.9 4.1zm9.3-5.3c-.4-.1-.7-.1-.9.1-.3.3-.2.7 0 1 .5.7.5 1.5.2 2.3-.6 1.6-2.5 2.5-4.5 2.5-3.3 0-6.1-2.2-6.2-5 0-3 2.7-5.4 6-5.4 1.7 0 3.3.6 4.3 1.8.3.3.7.4 1 .2.4-.2.5-.6.3-1-1.4-1.6-3.5-2.5-5.7-2.5-4.1 0-7.5 3.1-7.6 7 0 3.7 3.2 6.7 7.2 6.7 2.6 0 5-1.3 6.2-3.4.5-1.1.5-2.3-.2-3.3z" />
              </svg>
            </span>

            {/* Instagram */}
            <span className="p-1.5 rounded-full hover:text-[#8B1E1E] transition-colors cursor-pointer" title="Instagram">
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
              </svg>
            </span>

            {/* YouTube */}
            <span className="p-1.5 rounded-full hover:text-[#8B1E1E] transition-colors cursor-pointer" title="YouTube">
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
              </svg>
            </span>
          </div>
        </div>

      </div>
    </footer>
  );
}
