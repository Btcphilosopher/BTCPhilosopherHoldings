'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'motion/react';
import { useYunjinStore } from '@/hooks/use-yunjin-store';
import { ProductVariant, BespokePersonalization } from '@/lib/types';
import { X, Check, ShieldCheck, Sparkles, ShoppingBag, ArrowRight } from 'lucide-react';

export default function ProductDetailModal() {
  const {
    selectedProduct,
    setSelectedProduct,
    language,
    currency,
    t,
    addToCart,
    setIsCheckoutOpen
  } = useYunjinStore();

  const [activeImageIdx, setActiveImageIdx] = useState(0);
  const [selectedVariant, setSelectedVariant] = useState<ProductVariant | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [enableMonogram, setEnableMonogram] = useState(false);
  const [monogramText, setMonogramText] = useState('Y.J');
  const [monogramFinish, setMonogramFinish] = useState<'gold' | 'silver' | 'blind'>('gold');
  const [giftPackaging, setGiftPackaging] = useState(true);

  if (!selectedProduct) return null;

  const currentVariant = selectedVariant || selectedProduct.colorVariants[0];
  const images = selectedProduct.galleryImages.length > 0
    ? selectedProduct.galleryImages
    : [selectedProduct.image];

  const formattedPrice = currency === 'USD'
    ? `$${(selectedProduct.priceUSD * quantity).toLocaleString()}`
    : `¥${(selectedProduct.price * quantity).toLocaleString()}`;

  const handleAddToCart = () => {
    const personalization: BespokePersonalization | undefined = enableMonogram
      ? {
          text: monogramText.trim() || 'Y.J',
          finish: monogramFinish,
          position: 'clasp_tag'
        }
      : undefined;

    addToCart(selectedProduct, currentVariant, personalization, quantity, giftPackaging);
    setSelectedProduct(null);
  };

  const handleBuyNow = () => {
    handleAddToCart();
    setIsCheckoutOpen(true);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 md:p-10">
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.96 }}
          transition={{ duration: 0.3 }}
          className="relative w-full max-w-5xl bg-[#FBF9F5] border border-[#E8E1D5] shadow-2xl overflow-hidden my-auto"
        >
          {/* Close button */}
          <button
            onClick={() => setSelectedProduct(null)}
            className="absolute top-4 right-4 z-20 p-2 rounded-full bg-white/80 hover:bg-white text-[#1A1A1A] transition-colors shadow-sm"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="grid grid-cols-1 lg:grid-cols-12 max-h-[88vh] overflow-y-auto">
            
            {/* Left 6 cols: Gallery */}
            <div className="lg:col-span-6 p-6 sm:p-8 bg-[#F5F1E9] flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-[#E8E1D5]">
              {/* Main Photo */}
              <div className="relative aspect-square w-full overflow-hidden bg-white shadow-xs border border-[#E8E1D5]">
                <Image
                  src={images[activeImageIdx] || selectedProduct.image}
                  alt={selectedProduct.name}
                  fill
                  priority
                  referrerPolicy="no-referrer"
                  className="object-cover object-center transition-all duration-500"
                />

                {/* Auspicious Badge */}
                <div className="absolute top-3 left-3 bg-[#1A1A1A]/85 backdrop-blur-xs text-[#C5A059] text-xs tracking-widest px-3 py-1 font-serif">
                  {selectedProduct.lockType}
                </div>
              </div>

              {/* Thumbnails */}
              {images.length > 1 && (
                <div className="flex items-center gap-3 mt-4 overflow-x-auto pb-1">
                  {images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveImageIdx(idx)}
                      className={`relative w-16 h-16 shrink-0 border overflow-hidden transition-all ${
                        activeImageIdx === idx
                          ? 'border-[#8B1E1E] ring-1 ring-[#8B1E1E]'
                          : 'border-[#E8E1D5] opacity-70 hover:opacity-100'
                      }`}
                    >
                      <Image
                        src={img}
                        alt="Thumbnail"
                        fill
                        referrerPolicy="no-referrer"
                        className="object-cover"
                      />
                    </button>
                  ))}
                </div>
              )}

              {/* Artisan Seal & Guarantee Box */}
              <div className="mt-6 pt-6 border-t border-[#E8E1D5] flex items-center gap-4 text-xs text-[#6A6459] font-serif">
                <div className="chinese-seal w-9 h-9 text-[10px] shrink-0">
                  <span className="font-seal">
                    非遗<br />国检
                  </span>
                </div>
                <p className="leading-relaxed">
                  {t.pdp.authenticityGuarantee}
                </p>
              </div>
            </div>

            {/* Right 6 cols: Contiguous Purchase Module */}
            <div className="lg:col-span-6 p-6 sm:p-8 flex flex-col justify-between space-y-6">
              
              <div>
                {/* Header */}
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-xs uppercase tracking-[0.25em] text-[#8C8478] font-sans">
                      {selectedProduct.category.toUpperCase()} · YUNJIN ATELIER
                    </span>
                    <h2 className="text-2xl sm:text-3xl font-serif text-[#1A1A1A] font-medium tracking-wide mt-1">
                      {language === 'zh' ? selectedProduct.name : selectedProduct.nameEn}
                    </h2>
                  </div>
                  <span className="text-2xl font-serif font-bold text-[#8B1E1E] tracking-wider tabular-nums">
                    {formattedPrice}
                  </span>
                </div>

                <p className="text-xs sm:text-sm text-[#7A746B] font-serif italic mt-2 tracking-wide">
                  {language === 'zh' ? selectedProduct.subtitle : selectedProduct.subtitleEn}
                </p>

                {/* Story Description */}
                <p className="text-xs sm:text-sm text-[#4A453E] font-serif leading-relaxed mt-4 pt-4 border-t border-[#E8E1D5]">
                  {language === 'zh' ? selectedProduct.description : selectedProduct.descriptionEn}
                </p>

                {/* Color Variants */}
                <div className="mt-5">
                  <label className="block text-xs uppercase tracking-widest text-[#7A746B] font-sans font-medium mb-2">
                    {language === 'zh' ? '皮质色泽选择' : 'Leather Colorway'}
                  </label>
                  <div className="flex flex-wrap gap-2.5">
                    {selectedProduct.colorVariants.map((v) => (
                      <button
                        key={v.id}
                        onClick={() => setSelectedVariant(v)}
                        className={`flex items-center gap-2 px-3 py-1.5 border text-xs tracking-wider transition-all font-serif cursor-pointer ${
                          currentVariant.id === v.id
                            ? 'border-[#8B1E1E] text-[#8B1E1E] bg-[#8B1E1E]/5 shadow-xs'
                            : 'border-[#E8E1D5] text-[#555047] hover:border-[#1A1A1A]'
                        }`}
                      >
                        <span
                          className="w-3 h-3 rounded-full border border-black/20"
                          style={{ backgroundColor: v.colorCode }}
                        />
                        <span>{language === 'zh' ? v.name : v.nameEn}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Interactive Bespoke Monogramming Studio */}
                <div className="mt-6 p-4 bg-[#F5F1E9] border border-[#E8E1D5]">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-[#C5A059]" />
                      <span className="text-xs font-serif font-medium tracking-wide text-[#1A1A1A]">
                        {t.pdp.monogramTitle}
                      </span>
                    </div>
                    <button
                      onClick={() => setEnableMonogram(!enableMonogram)}
                      className="text-xs text-[#8B1E1E] font-serif hover:underline cursor-pointer"
                    >
                      {enableMonogram ? (language === 'zh' ? '取消定制' : 'Remove') : (language === 'zh' ? '+ 开启定制' : '+ Customize')}
                    </button>
                  </div>

                  {enableMonogram && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="mt-3 pt-3 border-t border-[#E8E1D5] space-y-3"
                    >
                      <p className="text-[11px] text-[#7A746B] font-serif">
                        {t.pdp.monogramDesc}
                      </p>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] text-[#7A746B] uppercase mb-1">
                            {language === 'zh' ? '定制字样 (如: Y.J 或 兰/福)' : 'Initials / Characters'}
                          </label>
                          <input
                            type="text"
                            maxLength={4}
                            value={monogramText}
                            onChange={(e) => setMonogramText(e.target.value)}
                            className="w-full bg-white border border-[#E8E1D5] px-3 py-1.5 text-xs text-[#1A1A1A] font-serif tracking-widest focus:outline-none focus:border-[#C5A059]"
                            placeholder="Y.J"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] text-[#7A746B] uppercase mb-1">
                            {language === 'zh' ? '烫金箔面' : 'Foil Finish'}
                          </label>
                          <select
                            value={monogramFinish}
                            onChange={(e: any) => setMonogramFinish(e.target.value)}
                            className="w-full bg-white border border-[#E8E1D5] px-2 py-1.5 text-xs text-[#1A1A1A] font-serif focus:outline-none focus:border-[#C5A059]"
                          >
                            <option value="gold">{t.pdp.foilGold}</option>
                            <option value="silver">{t.pdp.foilSilver}</option>
                            <option value="blind">{t.pdp.foilBlind}</option>
                          </select>
                        </div>
                      </div>

                      {/* Live Monogram Preview Tag */}
                      <div className="flex items-center justify-between p-2.5 bg-white border border-[#E8E1D5]">
                        <span className="text-[11px] text-[#7A746B] font-serif">
                          {language === 'zh' ? '皮牌烫印效果预览：' : 'Live Tag Preview:'}
                        </span>
                        <div
                          className={`px-3 py-1 border rounded-xs font-serif text-xs font-bold tracking-widest ${
                            monogramFinish === 'gold'
                              ? 'bg-[#1E1E1E] text-[#D4AF37] border-[#D4AF37]/50 shadow-inner'
                              : monogramFinish === 'silver'
                              ? 'bg-[#2A2A2A] text-[#E0E0E0] border-[#E0E0E0]/50'
                              : 'bg-[#DCD5C9] text-[#4A453E] border-[#A8A093]'
                          }`}
                        >
                          {monogramText.toUpperCase() || 'Y.J'}
                        </div>
                      </div>
                    </motion.div>
                  )}
                </div>

                {/* Materials & Provenance Specs */}
                <div className="mt-5 space-y-2 text-xs font-serif border-t border-[#E8E1D5] pt-4">
                  <div className="flex items-start justify-between">
                    <span className="text-[#8C8478]">{language === 'zh' ? '面料皮革' : 'Leather'}:</span>
                    <span className="text-[#1A1A1A] font-medium text-right max-w-[240px]">
                      {language === 'zh' ? selectedProduct.materials.leather : selectedProduct.materialsEn.leather}
                    </span>
                  </div>
                  <div className="flex items-start justify-between">
                    <span className="text-[#8C8478]">{language === 'zh' ? '内衬非遗' : 'Silk Lining'}:</span>
                    <span className="text-[#1A1A1A] font-medium text-right max-w-[240px]">
                      {language === 'zh' ? selectedProduct.materials.lining : selectedProduct.materialsEn.lining}
                    </span>
                  </div>
                  <div className="flex items-start justify-between">
                    <span className="text-[#8C8478]">{language === 'zh' ? '锁扣玉石' : 'Gem Clasp'}:</span>
                    <span className="text-[#8B1E1E] font-medium text-right max-w-[240px]">
                      {language === 'zh' ? selectedProduct.materials.gemstone : selectedProduct.materialsEn.gemstone}
                    </span>
                  </div>
                  <div className="flex items-start justify-between">
                    <span className="text-[#8C8478]">{language === 'zh' ? '包身规格' : 'Dimensions'}:</span>
                    <span className="text-[#1A1A1A] font-medium text-right">
                      {selectedProduct.dimensions}
                    </span>
                  </div>
                </div>
              </div>

              {/* Purchase Actions */}
              <div className="pt-6 border-t border-[#E8E1D5] space-y-3">
                <div className="flex items-center gap-3">
                  <div className="flex items-center border border-[#E8E1D5] bg-white">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-3 py-2 text-xs hover:bg-[#F5F1E9] transition-colors"
                    >
                      -
                    </button>
                    <span className="px-3 py-2 text-xs font-serif font-bold tabular-nums min-w-[32px] text-center">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity(quantity + 1)}
                      className="px-3 py-2 text-xs hover:bg-[#F5F1E9] transition-colors"
                    >
                      +
                    </button>
                  </div>

                  <button
                    onClick={handleAddToCart}
                    className="flex-1 flex items-center justify-center gap-2 py-3 px-4 border border-[#1A1A1A] text-[#1A1A1A] text-xs font-serif tracking-widest uppercase hover:bg-[#1A1A1A] hover:text-white transition-all cursor-pointer"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>{t.pdp.addToBag}</span>
                  </button>
                </div>

                <button
                  onClick={handleBuyNow}
                  className="w-full flex items-center justify-center gap-2 py-3.5 px-4 bg-[#8B1E1E] text-white text-xs font-serif tracking-widest uppercase hover:bg-[#A32828] transition-all shadow-md cursor-pointer"
                >
                  <span>{t.pdp.buyNow}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <p className="text-[11px] text-center text-[#8C8478] font-serif pt-1">
                  {t.pdp.complimentaryShipping}
                </p>
              </div>

            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
