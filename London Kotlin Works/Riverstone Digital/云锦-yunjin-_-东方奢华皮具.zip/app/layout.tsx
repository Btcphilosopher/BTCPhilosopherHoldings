import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: '云锦 YUNJIN | 东方奢华皮具 (Chinese Luxury Handbags)',
  description: '传承东方美学，致敬当代女性。云锦（YUNJIN）高级皮具工坊，融合南京云锦非遗与羊脂白玉、花丝金锁精粹，呈现当代中国高奢手袋与配饰。',
  openGraph: {
    title: '云锦 YUNJIN | 东方奢华皮具',
    description: '传承东方美学，致敬当代女性。云锦（YUNJIN）高级皮具工坊，融合南京云锦非遗与羊脂白玉、花丝金锁精粹。',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: '云锦 YUNJIN | 东方奢华皮具',
    description: '传承东方美学，致敬当代女性。当代中国高奢手袋与精粹工艺。',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="zh-CN" className="scroll-smooth">
      <body className="min-h-screen bg-[#FBF9F5] text-[#1A1A1A] antialiased selection:bg-[#C5A059]/20 selection:text-[#8B1E1E]">
        {children}
      </body>
    </html>
  );
}
