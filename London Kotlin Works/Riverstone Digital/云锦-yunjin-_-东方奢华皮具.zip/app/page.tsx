'use client';

import React, { useEffect, useState } from 'react';
import { YunjinStoreProvider, useYunjinStore } from '@/hooks/use-yunjin-store';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import Collections from '@/components/Collections';
import CraftsmanshipAndStory from '@/components/CraftsmanshipAndStory';
import ProductDetailModal from '@/components/ProductDetailModal';
import CartDrawer from '@/components/CartDrawer';
import CheckoutModal from '@/components/CheckoutModal';
import ConciergeModal from '@/components/ConciergeModal';
import BoutiqueModal from '@/components/BoutiqueModal';
import CraftsmanshipModal from '@/components/CraftsmanshipModal';
import StoryModal from '@/components/StoryModal';
import SearchModal from '@/components/SearchModal';
import Footer from '@/components/Footer';
import { INITIAL_PRODUCTS } from '@/lib/data/products';
import { Product } from '@/lib/types';
import { Sparkles, MessageSquareText } from 'lucide-react';

function MainApp() {
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const { setIsConciergeOpen, language } = useYunjinStore();

  useEffect(() => {
    // Fetch live products from backend API to ensure backend synchronization
    async function loadProducts() {
      try {
        const res = await fetch('/api/products');
        const data = await res.json();
        if (data.success && Array.isArray(data.data) && data.data.length > 0) {
          setProducts(data.data);
        }
      } catch (e) {
        // Fallback to in-memory initial products
      }
    }
    loadProducts();
  }, []);

  return (
    <div className="min-h-screen bg-[#FBF9F5] text-[#1A1A1A] flex flex-col justify-between">
      {/* Top Navigation */}
      <Navbar />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* Hero Banner Section */}
        <Hero />

        {/* Collections Grid with Sidebar */}
        <Collections products={products} />

        {/* Master Craftsmanship & Brand Story Split Feature */}
        <CraftsmanshipAndStory />
      </main>

      {/* Footer */}
      <Footer />

      {/* Interactive Modals and Drawers */}
      <ProductDetailModal />
      <CartDrawer />
      <CheckoutModal />
      <ConciergeModal />
      <BoutiqueModal />
      <CraftsmanshipModal />
      <StoryModal />
      <SearchModal products={products} />

      {/* Floating VIP Concierge Seal Button */}
      <div className="fixed bottom-6 right-6 z-30">
        <button
          onClick={() => setIsConciergeOpen(true)}
          className="group flex items-center gap-2.5 px-4 py-3 rounded-full bg-[#1A1A1A] text-white border border-[#C5A059]/60 shadow-xl hover:bg-[#8B1E1E] transition-all duration-300 hover:scale-105 cursor-pointer"
          aria-label="VIP Concierge Advisor"
        >
          <div className="w-5 h-5 rounded-full bg-[#C5A059]/20 flex items-center justify-center text-[#C5A059]">
            <Sparkles className="w-3.5 h-3.5" />
          </div>
          <span className="text-xs font-serif tracking-wider">
            {language === 'zh' ? '云锦私享顾问' : 'VIP Concierge'}
          </span>
          <span className="w-1.5 h-1.5 rounded-full bg-[#C5A059] animate-pulse" />
        </button>
      </div>
    </div>
  );
}

export default function Page() {
  return (
    <YunjinStoreProvider>
      <MainApp />
    </YunjinStoreProvider>
  );
}
