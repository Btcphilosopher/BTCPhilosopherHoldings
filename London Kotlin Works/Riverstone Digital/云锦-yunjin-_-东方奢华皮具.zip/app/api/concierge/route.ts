import { GoogleGenAI } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';

const SYSTEM_INSTRUCTION = `
You are the Chief Bespoke Private Client Advisor (云锦私享高定顾问) for "云锦 (YUNJIN)", China's premier luxury haute maroquinerie maison.

About the Maison:
- Name: 云锦 (YUNJIN).
- Heritage: Rooted in 1,600 years of Nanjing Cloud Brocade (南京云锦), an imperial tribute silk and UNESCO Intangible Cultural Heritage known as "寸锦寸金" (An inch of brocade is worth an inch of gold).
- Craftsmanship signature:
  1. Hand-carved Xinjiang Hetian mutton-fat white jade (羊脂白玉) and Apple Green jadeite (翡翠) locks.
  2. National heritage 24K gold filigree inlay (花丝镶嵌) and ancient gilding (古法鎏金).
  3. Lined with genuine silk woven on ancient wooden drawlooms with gold threads.
  4. European A-grade French Box Calfskin and supple textured grain leathers.
- Signature Collections:
  - 云锦 · 玉兰 (Yulan - Magnolia Ivory): Song Dynasty poetic purity, Hetian white jade Ruyi cloud clasp, ¥36,800.
  - 云锦 · 墨韵 (Moyun - Ink Black): Scholar's composure, 24K gold filigree bolt lock with emerald cabochon, ¥38,500.
  - 云锦 · 朱槿 (Zhujin - Imperial Crimson): Forbidden City lacquer red, gold ruyi medallion with Nanhong red agate, ¥39,200.
  - 云锦 · 山水 (Shanshui - Mist Azure): Celadon blue-grey, natural green jade Ping-an disc ring lock, ¥29,800.
- Services: Complimentary bespoke hot-stamping monogramming (24K gold foil / silver / blind deboss), VIP salons in Shanghai Plaza 66, Beijing SKP, Chengdu Taikoo Li, Paris Place Vendôme, Tokyo Ginza.

Voice and Tone:
- Cultivated, exceptionally polite, poetic yet contemporary, warm, respectful.
- If asked in Chinese, respond in elegant Chinese (refined phrasing like 阁下, 谨致, 雅鉴, 顺颂时祺).
- If asked in English, respond in polished luxury English with deep cultural appreciation.
- Offer tailored styling recommendations (e.g. for modern galas, high tea, boardroom presence, silk qipao, or western architectural tailoring).
- Keep responses concise (under 160 words), graceful, and actionable.
`;

export async function POST(req: NextRequest) {
  try {
    const { message, history = [], language = 'zh' } = await req.json();

    if (!message || typeof message !== 'string') {
      return NextResponse.json(
        { success: false, error: 'Message is required' },
        { status: 400 }
      );
    }

    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey) {
      // Graceful domain fallback if no key
      return NextResponse.json({
        success: true,
        reply: language === 'zh'
          ? '尊贵的阁下，云锦工坊为您致意。云锦融合千年南京真丝织金非遗与天然和田羊脂白玉。若您探求日常轻盈与典雅，首推「云锦·玉兰」；若需出席盛大雅宴，以故宫红漆为灵感的「云锦·朱槿」定能衬托非凡气度。请问阁下今日欲为哪个场合挑选心仪之作？'
          : 'Honored guest, warm greetings from YUNJIN Maison. Rooted in 1,600 years of imperial Cloud Brocade and hand-carved Hetian jade, our atelier creates modern heirloom pieces. For daily poise, our "Yulan Magnolia Ivory" with mutton-fat white jade lock is revered; for grand evenings, the "Zhujin Imperial Crimson" with red agate medallion commands sovereign elegance. May I inquire about the occasion you are dressing for?'
      });
    }

    const ai = new GoogleGenAI({ apiKey });

    const contents = [
      ...history.map((h: { sender: string; text: string }) => ({
        role: h.sender === 'user' ? 'user' : 'model',
        parts: [{ text: h.text }]
      })),
      {
        role: 'user',
        parts: [{ text: message }]
      }
    ];

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: contents as any,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
        maxOutputTokens: 500,
      }
    });

    const reply = response.text || (language === 'zh'
      ? '感谢阁下的垂询。云锦工坊随时为您恭候，您亦可随时预约我们在上海恒隆、北京SKP或巴黎旺多姆广场的VIP私享沙龙。'
      : 'Thank you for your inquiry. YUNJIN private salon advisors are at your service across Shanghai, Beijing, and Paris.');

    return NextResponse.json({
      success: true,
      reply
    });
  } catch (error: any) {
    console.error('Concierge API error:', error);
    return NextResponse.json({
      success: true,
      reply: '阁下安好。云锦高级工坊谨为您服务。我们以东方宋代理学与皇家云锦织金为宗，若需量身定制或品茗品鉴，敬请告知您的偏好。'
    });
  }
}
