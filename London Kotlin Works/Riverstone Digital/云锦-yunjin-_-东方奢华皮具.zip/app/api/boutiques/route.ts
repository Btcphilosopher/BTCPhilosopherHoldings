import { NextRequest, NextResponse } from 'next/server';
import { BOUTIQUES } from '@/lib/data/boutiques';
import { getAppointmentsStore } from '@/lib/data/store';

export async function GET() {
  return NextResponse.json({
    success: true,
    data: BOUTIQUES
  });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { boutiqueId, guestName, phone, date, time, guestCount, notes } = body;

    if (!guestName || !phone || !date) {
      return NextResponse.json(
        { success: false, error: 'Name, phone, and date are required' },
        { status: 400 }
      );
    }

    const boutique = BOUTIQUES.find(b => b.id === boutiqueId) || BOUTIQUES[0];
    const appointmentId = `VIP-${Math.floor(100000 + Math.random() * 900000)}`;

    const appointment = {
      id: appointmentId,
      createdAt: new Date().toISOString(),
      boutique,
      guestName,
      phone,
      date,
      time: time || '14:30',
      guestCount: guestCount || 1,
      notes: notes || '品茗品鉴与高定皮具私享试背 (Tea tasting & bespoke bag preview)',
      status: 'confirmed'
    };

    const appointments = getAppointmentsStore();
    appointments.unshift(appointment);

    return NextResponse.json({
      success: true,
      message: 'VIP appointment reserved',
      data: appointment
    });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}
