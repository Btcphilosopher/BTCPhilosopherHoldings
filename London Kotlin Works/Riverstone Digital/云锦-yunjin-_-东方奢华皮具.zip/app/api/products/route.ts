import { NextRequest, NextResponse } from 'next/server';
import { getProductsStore } from '@/lib/data/store';
import { Product } from '@/lib/types';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const category = searchParams.get('category');
    const search = searchParams.get('search');
    const featured = searchParams.get('featured');
    const sort = searchParams.get('sort');

    let products = getProductsStore();

    if (category && category !== 'all') {
      products = products.filter(p => p.category === category);
    }

    if (featured === 'true') {
      products = products.filter(p => p.isFeatured);
    }

    if (search) {
      const q = search.toLowerCase();
      products = products.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.nameEn.toLowerCase().includes(q) ||
        p.subtitle.toLowerCase().includes(q) ||
        p.subtitleEn.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.materials.gemstone.toLowerCase().includes(q) ||
        p.materials.leather.toLowerCase().includes(q)
      );
    }

    if (sort === 'price-asc') {
      products = [...products].sort((a, b) => a.price - b.price);
    } else if (sort === 'price-desc') {
      products = [...products].sort((a, b) => b.price - a.price);
    }

    return NextResponse.json({
      success: true,
      count: products.length,
      data: products
    });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to fetch products' },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const products = getProductsStore();

    const newProduct: Product = {
      id: `yj-${Date.now().toString(36)}`,
      slug: body.slug || `custom-${Date.now()}`,
      name: body.name || '云锦 · 东方新作',
      nameEn: body.nameEn || 'YUNJIN · New Creation',
      subtitle: body.subtitle || '当代东方 典藏之美',
      subtitleEn: body.subtitleEn || 'Contemporary Eastern Allure',
      category: body.category || 'handbags',
      price: Number(body.price) || 28800,
      priceUSD: Number(body.priceUSD) || 4050,
      image: body.image || '/images/product_yulan_ivory.jpg',
      galleryImages: body.galleryImages || ['/images/product_yulan_ivory.jpg'],
      description: body.description || '东方非遗工艺与现代顶级皮具结合之作。',
      descriptionEn: body.descriptionEn || 'A harmonious blend of Eastern heritage craft and modern luxury leather goods.',
      dimensions: body.dimensions || '25 cm × 18 cm × 10 cm',
      materials: body.materials || {
        leather: '法国进口头层特选小牛皮',
        lining: '南京真丝寸金云锦',
        hardware: '24K古法镀金耐磨拉丝黄铜',
        gemstone: '纯天然新疆和田白玉'
      },
      materialsEn: body.materialsEn || {
        leather: 'French Box Calfskin',
        lining: 'Nanjing Gold Brocade Silk',
        hardware: '24K Brushed Gilt Brass',
        gemstone: 'Natural Hetian White Jade'
      },
      colorVariants: body.colorVariants || [
        { id: 'v1', name: '象牙白', nameEn: 'Ivory White', colorCode: '#F4EFE6', image: '/images/product_yulan_ivory.jpg' }
      ],
      lockType: body.lockType || '祥云如意锁',
      lockTypeEn: body.lockTypeEn || 'Auspicious Cloud Clasp',
      inStock: true,
      stockCount: 10,
      isFeatured: Boolean(body.isFeatured),
      tag: body.tag || '工坊新作',
      tagEn: body.tagEn || 'New Arrival'
    };

    products.unshift(newProduct);

    return NextResponse.json(
      { success: true, message: 'Product created successfully', data: newProduct },
      { status: 201 }
    );
  } catch (error: any) {
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to create product' },
      { status: 400 }
    );
  }
}
