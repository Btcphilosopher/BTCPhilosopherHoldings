import { NextRequest, NextResponse } from 'next/server';
import { getOrdersStore, getProductsStore } from '@/lib/data/store';
import { Order, CartItem } from '@/lib/types';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const orderNumber = searchParams.get('orderNumber');
    const phone = searchParams.get('phone');
    const email = searchParams.get('email');

    const orders = getOrdersStore();

    if (orderNumber) {
      const match = orders.find(o => o.orderNumber.toUpperCase() === orderNumber.toUpperCase());
      return NextResponse.json({ success: true, data: match || null });
    }

    if (phone || email) {
      const matches = orders.filter(o => 
        (phone && o.customer.phone === phone) ||
        (email && o.customer.email.toLowerCase() === email.toLowerCase())
      );
      return NextResponse.json({ success: true, data: matches });
    }

    return NextResponse.json({
      success: true,
      count: orders.length,
      data: orders
    });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { items, customer, paymentMethod, currency = 'CNY' } = body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      return NextResponse.json(
        { success: false, error: 'Shopping bag is empty' },
        { status: 400 }
      );
    }

    if (!customer?.fullName || !customer?.phone || !customer?.address) {
      return NextResponse.json(
        { success: false, error: 'Recipient name, phone number, and delivery address are required' },
        { status: 400 }
      );
    }

    // Calculate subtotal
    const subtotal = items.reduce((sum: number, item: CartItem) => {
      const price = currency === 'USD' ? item.product.priceUSD : item.product.price;
      return sum + (price * item.quantity);
    }, 0);

    const shipping = 0; // Complimentary VIP white glove shipping
    const tax = Math.round(subtotal * 0.08); // 8% luxury sales tax included
    const total = subtotal;

    // Generate prestigious serial numbers
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const orderNumber = `YJ-${new Date().getFullYear()}-${randomSuffix}`;
    const certificateId = `NGTC-YJ${Math.floor(100000 + Math.random() * 900000)}`;
    const trackingNumber = `SF-${Math.floor(100000000000 + Math.random() * 900000000000)}`;

    const newOrder: Order = {
      id: `order-${Date.now()}`,
      orderNumber,
      createdAt: new Date().toISOString(),
      items,
      customer,
      subtotal,
      shipping,
      tax,
      total,
      currency,
      paymentMethod: paymentMethod || 'wechat',
      status: 'confirmed',
      certificateId,
      trackingNumber
    };

    const orders = getOrdersStore();
    orders.unshift(newOrder);

    // Update in-stock quantities
    const products = getProductsStore();
    items.forEach((item: CartItem) => {
      const prod = products.find(p => p.id === item.productId);
      if (prod && prod.stockCount > 0) {
        prod.stockCount = Math.max(0, prod.stockCount - item.quantity);
      }
    });

    return NextResponse.json({
      success: true,
      message: 'Order placed successfully',
      data: newOrder
    });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, error: error.message || 'Order processing failed' },
      { status: 500 }
    );
  }
}
