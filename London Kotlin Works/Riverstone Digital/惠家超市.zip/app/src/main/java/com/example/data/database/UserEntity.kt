package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String = "current_user",
    val username: String,
    val phone: String,
    val memberPoints: Int = 0,
    val balance: Double = 100.00, // Starts with a simulated ¥100.00 coupon/balance
    val isMember: Boolean = false,
    val tier: String = "普通用户" // "普通用户", "银牌会员", "金牌会员", "钻石会员"
)
