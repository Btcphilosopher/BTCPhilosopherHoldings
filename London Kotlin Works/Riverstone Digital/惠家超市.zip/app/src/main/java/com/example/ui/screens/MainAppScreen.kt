package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.database.OrderEntity
import com.example.data.database.ProductEntity
import com.example.data.database.UserEntity
import com.example.ui.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(viewModel: SupermarketViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val userProfile by viewModel.user.collectAsStateWithLifecycle()
    val cartCount by viewModel.cartCount.collectAsStateWithLifecycle()
    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()
    val selectedProduct by viewModel.selectedProduct.collectAsStateWithLifecycle()

    var showRegisterDialog by remember { mutableStateOf(false) }
    var showCheckoutDialog by remember { mutableStateOf(false) }

    // System Back Press Handler
    androidx.activity.compose.BackHandler(enabled = currentScreen != AppScreen.HOME) {
        viewModel.navigateBack()
    }

    // Toast logic
    LaunchedEffect(toastMessage) {
        toastMessage?.let {
            delay(2000)
            viewModel.clearToast()
        }
    }

    Scaffold(
        topBar = {
            Column {
                // Top Mini Header info
                TopMiniHeader()

                // Main Top Search Bar & Branding
                TopBrandSearchBar(
                    cartCount = cartCount,
                    userProfile = userProfile,
                    onSearch = { viewModel.setSearchText(it) },
                    onCartClick = { viewModel.navigateTo(AppScreen.CART) },
                    onMemberClick = { viewModel.navigateTo(AppScreen.MEMBER) },
                    onFavClick = { viewModel.navigateTo(AppScreen.FAVORITES) },
                    onOrdersClick = { viewModel.navigateTo(AppScreen.ORDERS) }
                )
            }
        },
        bottomBar = {
            BottomNavBar(
                currentScreen = currentScreen,
                cartCount = cartCount,
                onScreenSelected = { screen ->
                    viewModel.navigateTo(screen)
                }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Screen Switcher
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    fadeIn() togetherWith fadeOut()
                },
                label = "ScreenTransition"
            ) { targetScreen ->
                when (targetScreen) {
                    AppScreen.HOME -> HomeScreenContent(
                        viewModel = viewModel,
                        onOpenRegister = { showRegisterDialog = true }
                    )
                    AppScreen.CATEGORY -> CategoryScreenContent(viewModel = viewModel)
                    AppScreen.CART -> CartScreenContent(
                        viewModel = viewModel,
                        onCheckout = { showCheckoutDialog = true }
                    )
                    AppScreen.MEMBER -> MemberScreenContent(
                        viewModel = viewModel,
                        onOpenRegister = { showRegisterDialog = true }
                    )
                    AppScreen.ORDERS -> OrdersScreenContent(viewModel = viewModel)
                    AppScreen.FAVORITES -> FavoritesScreenContent(viewModel = viewModel)
                }
            }

            // Custom Toast Overlay
            toastMessage?.let { msg ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = NeutralDark),
                        shape = RoundedCornerShape(24.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                    ) {
                        Text(
                            text = msg,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Product Detail Bottom Sheet/Dialog
            selectedProduct?.let { product ->
                ProductDetailDialog(
                    product = product,
                    isFavorite = viewModel.favorites.collectAsStateWithLifecycle().value.contains(product.id),
                    onToggleFavorite = { viewModel.toggleFavorite(product) },
                    onAddToCart = { viewModel.addToCart(product) },
                    onDismiss = { viewModel.viewProductDetails(null) }
                )
            }

            // Member Registration Dialog
            if (showRegisterDialog) {
                RegisterMemberDialog(
                    onRegister = { name, phone ->
                        viewModel.registerMember(name, phone)
                        showRegisterDialog = false
                    },
                    onDismiss = { showRegisterDialog = false }
                )
            }

            // Checkout Confirmation Dialog
            if (showCheckoutDialog) {
                val totalAmount by viewModel.cartTotal.collectAsStateWithLifecycle()
                CheckoutDialog(
                    totalAmount = totalAmount,
                    userBalance = userProfile?.balance ?: 0.0,
                    onConfirm = {
                        viewModel.checkoutCart {
                            showCheckoutDialog = false
                            viewModel.navigateTo(AppScreen.ORDERS)
                        }
                    },
                    onDismiss = { showCheckoutDialog = false }
                )
            }
        }
    }
}

// ==========================================
// SHARED HEADERS & BARS
// ==========================================

@Composable
fun TopMiniHeader() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(FreshGreenLight)
            .padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = FreshGreenPrimary,
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text("新鲜", fontSize = 10.sp, color = FreshGreenDark, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
                imageVector = Icons.Default.PriceCheck,
                contentDescription = null,
                tint = FreshGreenPrimary,
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text("便宜", fontSize = 10.sp, color = FreshGreenDark, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
                imageVector = Icons.Default.VerifiedUser,
                contentDescription = null,
                tint = FreshGreenPrimary,
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text("放心", fontSize = 10.sp, color = FreshGreenDark, fontWeight = FontWeight.Bold)
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.LocalShipping,
                contentDescription = null,
                tint = NeutralGray,
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "满59元免运费 (部分地区除外)",
                fontSize = 10.sp,
                color = NeutralDark
            )
        }
    }
}

@Composable
fun TopBrandSearchBar(
    cartCount: Int,
    userProfile: UserEntity?,
    onSearch: (String) -> Unit,
    onCartClick: () -> Unit,
    onMemberClick: () -> Unit,
    onFavClick: () -> Unit,
    onOrdersClick: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    val keyboardController = LocalSoftwareKeyboardController.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand Logo & Subtitle
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable { onMemberClick() }
            ) {
                // Leafy Shopping Cart Icon
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(FreshGreenLight, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ShoppingCart,
                        contentDescription = "Logo",
                        tint = FreshGreenPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    // Little Sprout Leaf Overlay
                    Icon(
                        imageVector = Icons.Default.Spa,
                        contentDescription = null,
                        tint = GoldAccent,
                        modifier = Modifier
                            .size(14.dp)
                            .align(Alignment.TopEnd)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column {
                    Text(
                        text = "惠家超市",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = FreshGreenPrimary,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "让生活更简单",
                        fontSize = 9.sp,
                        color = NeutralGray,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Quick Nav Links (Desktop Style turned mobile action row)
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onOrdersClick, modifier = Modifier.size(24.dp)) {
                    Icon(
                        imageVector = Icons.Outlined.ReceiptLong,
                        contentDescription = "Orders",
                        tint = NeutralDark
                    )
                }

                IconButton(onClick = onFavClick, modifier = Modifier.size(24.dp)) {
                    Icon(
                        imageVector = Icons.Outlined.FavoriteBorder,
                        contentDescription = "Favorites",
                        tint = NeutralDark
                    )
                }

                Box(modifier = Modifier.clickable { onCartClick() }) {
                    Icon(
                        imageVector = Icons.Outlined.ShoppingCart,
                        contentDescription = "Cart",
                        tint = NeutralDark,
                        modifier = Modifier.size(24.dp)
                    )
                    if (cartCount > 0) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .offset(x = 6.dp, y = (-6).dp)
                                .background(AccentOrange, CircleShape)
                                .size(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = cartCount.toString(),
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Large Search Bar Input
        OutlinedTextField(
            value = query,
            onValueChange = {
                query = it
                onSearch(it)
            },
            placeholder = { Text("搜索商品、品牌、分类...", fontSize = 13.sp, color = NeutralGray) },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = NeutralGray
                )
            },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = {
                        query = ""
                        onSearch("")
                    }) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Clear",
                            tint = NeutralGray
                        )
                    }
                }
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(
                imeAction = ImeAction.Search
            ),
            keyboardActions = KeyboardActions(
                onSearch = {
                    keyboardController?.hide()
                }
            ),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = LightBg,
                unfocusedContainerColor = LightBg,
                focusedBorderColor = FreshGreenPrimary,
                unfocusedBorderColor = BorderGray
            ),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .testTag("search_input")
        )
    }
}

@Composable
fun BottomNavBar(
    currentScreen: AppScreen,
    cartCount: Int,
    onScreenSelected: (AppScreen) -> Unit
) {
    NavigationBar(
        containerColor = Color.White,
        tonalElevation = 8.dp,
        modifier = Modifier.shadow(12.dp)
    ) {
        val navItems = listOf(
            Triple(AppScreen.HOME, "首页", Icons.Default.Home),
            Triple(AppScreen.CATEGORY, "分类", Icons.Default.GridView),
            Triple(AppScreen.CART, "购物车", Icons.Default.ShoppingCart),
            Triple(AppScreen.MEMBER, "会员福利", Icons.Default.CardMembership),
            Triple(AppScreen.ORDERS, "订单", Icons.Default.Assignment)
        )

        navItems.forEach { (screen, label, icon) ->
            NavigationBarItem(
                selected = currentScreen == screen,
                onClick = { onScreenSelected(screen) },
                icon = {
                    Box {
                        Icon(imageVector = icon, contentDescription = label)
                        if (screen == AppScreen.CART && cartCount > 0) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .offset(x = 8.dp, y = (-8).dp)
                                    .background(AccentOrange, CircleShape)
                                    .size(16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = cartCount.toString(),
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                },
                label = { Text(label, fontSize = 11.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = FreshGreenPrimary,
                    selectedTextColor = FreshGreenPrimary,
                    indicatorColor = FreshGreenLight,
                    unselectedIconColor = NeutralGray,
                    unselectedTextColor = NeutralGray
                )
            )
        }
    }
}

// ==========================================
// SCREEN 1: HOME CONTENT
// ==========================================

@Composable
fun HomeScreenContent(
    viewModel: SupermarketViewModel,
    onOpenRegister: () -> Unit
) {
    val products by viewModel.allProducts.collectAsStateWithLifecycle()
    val userProfile by viewModel.user.collectAsStateWithLifecycle()
    val searchText by viewModel.searchText.collectAsStateWithLifecycle()

    // Filter products if search is active
    val filteredProducts = if (searchText.isBlank()) {
        products
    } else {
        products.filter { it.name.contains(searchText, ignoreCase = true) || it.category.contains(searchText, ignoreCase = true) }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(LightBg)
    ) {
        if (searchText.isBlank()) {
            // 1. Large Seasonal Promo Banner
            item { LargePromoBanner(onShopNow = { viewModel.navigateTo(AppScreen.CATEGORY) }) }

            // 2. Quick Horizontal Category Row
            item { QuickCategoryRow(onCategorySelect = { category ->
                viewModel.setActiveCategory(category)
                viewModel.navigateTo(AppScreen.CATEGORY)
            }) }

            // 3. Register Member Benefit Banner
            if (userProfile == null || userProfile?.isMember == false) {
                item { HomeRegisterMemberCard(onOpenRegister = onOpenRegister) }
            }

            // 4. 限时特惠 (Limited Time Specials) Section with Countdown
            item {
                HomeSpecialsSection(
                    specials = products.filter { it.isSpecial },
                    onProductClick = { viewModel.viewProductDetails(it) },
                    onAddToCart = { viewModel.addToCart(it) }
                )
            }

            // 5. 新品上架 (New Arrivals) Section
            item {
                HomeNewArrivalsSection(
                    newArrivals = products.filter { it.isNew },
                    onProductClick = { viewModel.viewProductDetails(it) },
                    onAddToCart = { viewModel.addToCart(it) },
                    onViewMore = { viewModel.navigateTo(AppScreen.CATEGORY) }
                )
            }

            // 6. Supermarket Service Gurantees
            item { ServiceGuarantees() }

            // 7. Footer
            item { HomeFooter() }
        } else {
            // Search Results Heading
            item {
                Text(
                    text = "搜索结果 (\"$searchText\"):",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeutralDark,
                    modifier = Modifier.padding(16.dp)
                )
            }

            if (filteredProducts.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(48.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.SearchOff,
                            contentDescription = null,
                            tint = NeutralGray,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            "没有找到相关商品",
                            color = NeutralGray,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "试试搜索其他词汇吧！比如：西红柿、纯牛奶",
                            color = NeutralGray,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                items(filteredProducts.chunked(2)) { pair ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        pair.forEach { product ->
                            Box(modifier = Modifier.weight(1f)) {
                                HomeProductGridItem(
                                    product = product,
                                    onProductClick = { viewModel.viewProductDetails(product) },
                                    onAddToCart = { viewModel.addToCart(product) }
                                )
                            }
                        }
                        if (pair.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(32.dp)) }
        }
    }
}

@Composable
fun LargePromoBanner(onShopNow: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFFDCF2E6),
                            Color(0xFFEBF7F0),
                            Color(0xFFF7FDF9)
                        )
                    )
                )
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Text & Call to Action
                Column(modifier = Modifier.weight(1.2f)) {
                    Box(
                        modifier = Modifier
                            .background(FreshGreenPrimary, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            "新鲜直达",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "当季新鲜蔬菜",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = FreshGreenDark
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "从田间到餐桌\n每一口都是自然的味道",
                        fontSize = 11.sp,
                        color = NeutralDark,
                        lineHeight = 15.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onShopNow,
                        colors = ButtonDefaults.buttonColors(containerColor = FreshGreenPrimary),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("shop_now_banner"),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("立即选购", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = null,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }

                // Vegetable Illustration Graphic Group
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(110.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Back circular glow shadow
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .background(GoldAccentLight, CircleShape)
                    )

                    // Fresh veggie illustration via text layers/emojis
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("🥦 🥕 🍅 🥬", fontSize = 32.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .background(GoldAccent, RoundedCornerShape(12.dp))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                "每日新鲜 • 品质保证",
                                fontSize = 8.sp,
                                color = NeutralDark,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuickCategoryRow(onCategorySelect: (String) -> Unit) {
    val categories = listOf(
        Pair("新鲜蔬菜", "蔬菜水果"),
        Pair("肉禽蛋奶", "肉类禽蛋"),
        Pair("海鲜水产", "海鲜水产"),
        Pair("粮油调味", "粮油调味"),
        Pair("乳品烘焙", "乳品烘焙"),
        Pair("休闲零食", "休闲零食"),
        Pair("饮料酒水", "饮料酒水"),
        Pair("日用百货", "日用百货")
    )

    val categoryEmojis = mapOf(
        "新鲜蔬菜" to "🥬",
        "肉禽蛋奶" to "🥩",
        "海鲜水产" to "🐟",
        "粮油调味" to "🍳",
        "乳品烘焙" to "🍞",
        "休闲零食" to "🍿",
        "饮料酒水" to "🍹",
        "日用百货" to "🧴"
    )

    LazyRow(
        contentPadding = PaddingValues(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp)
    ) {
        items(categories) { (originalCat, displayCat) ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clickable { onCategorySelect(originalCat) }
                    .testTag("category_tab_$originalCat")
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(Color.White, CircleShape)
                        .shadow(1.dp, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = categoryEmojis[originalCat] ?: "🍎",
                        fontSize = 24.sp
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = displayCat,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = NeutralDark
                )
            }
        }
    }
}

@Composable
fun HomeRegisterMemberCard(onOpenRegister: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = FreshGreenDark)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1.5f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Stars,
                            contentDescription = null,
                            tint = GoldAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            "注册会员 享专属优惠",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "• 会员专享价  • 积分换好礼  • 生日特惠专享福利",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Button(
                    onClick = onOpenRegister,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier
                        .height(28.dp)
                        .weight(0.7f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        "立即注册",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = FreshGreenDark
                    )
                }
            }
        }
    }
}

@Composable
fun HomeSpecialsSection(
    specials: List<ProductEntity>,
    onProductClick: (ProductEntity) -> Unit,
    onAddToCart: (ProductEntity) -> Unit
) {
    var hours by remember { mutableStateOf(12) }
    var minutes by remember { mutableStateOf(45) }
    var seconds by remember { mutableStateOf(30) }

    // Countdown effect loop
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            if (seconds > 0) {
                seconds--
            } else {
                seconds = 59
                if (minutes > 0) {
                    minutes--
                } else {
                    minutes = 59
                    if (hours > 0) {
                        hours--
                    } else {
                        hours = 12
                    }
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp)
            .background(Color.White, RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFFFFF0E6), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Orange Alarm Clock Icon
                Icon(
                    imageVector = Icons.Default.AccessTime,
                    contentDescription = null,
                    tint = AccentOrange,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "限时特惠",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccentOrange
                )
                Spacer(modifier = Modifier.width(10.dp))

                // Timer badging
                Text("距离结束", fontSize = 10.sp, color = NeutralGray)
                Spacer(modifier = Modifier.width(4.dp))
                TimerCell(String.format("%02d", hours))
                Text(":", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = AccentOrange)
                TimerCell(String.format("%02d", minutes))
                Text(":", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = AccentOrange)
                TimerCell(String.format("%02d", seconds))
            }

            Text(
                text = "查看更多 >",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = AccentOrange,
                modifier = Modifier.clickable { }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(specials) { product ->
                SpecialProductItem(
                    product = product,
                    onClick = { onProductClick(product) },
                    onAddToCart = { onAddToCart(product) }
                )
            }
        }
    }
}

@Composable
fun TimerCell(value: String) {
    Box(
        modifier = Modifier
            .background(AccentOrange, RoundedCornerShape(4.dp))
            .padding(horizontal = 4.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = value,
            color = Color.White,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun SpecialProductItem(
    product: ProductEntity,
    onClick: () -> Unit,
    onAddToCart: () -> Unit
) {
    val foodEmojis = mapOf(
        "tomato_1" to "🍅",
        "egg_1" to "🥚",
        "cabbage_1" to "🥬",
        "milk_1" to "🥛",
        "blueberry_1" to "🫐",
        "durian_1" to "🍈"
    )

    Card(
        modifier = Modifier
            .width(115.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = LightBg)
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                // Product Graphic (Emoji inside Card)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(65.dp)
                        .background(Color.White, RoundedCornerShape(6.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = foodEmojis[product.id] ?: "🍎",
                        fontSize = 32.sp
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Name
                Text(
                    text = product.name,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeutralDark,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Price line
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = "¥${product.price}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentOrange
                        )
                        if (product.originalPrice != null) {
                            Text(
                                text = "¥${product.originalPrice}",
                                fontSize = 8.sp,
                                color = NeutralGray,
                                textDecoration = TextDecoration.LineThrough
                            )
                        }
                    }

                    // Plus cart button
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .background(FreshGreenPrimary, CircleShape)
                            .clickable { onAddToCart() }
                            .testTag("add_to_cart_specials_${product.id}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add",
                            tint = Color.White,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }

            // "特惠" tag
            Box(
                modifier = Modifier
                    .background(AccentOrange, RoundedCornerShape(topStart = 8.dp, bottomEnd = 8.dp))
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                Text(
                    "特惠",
                    color = Color.White,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun HomeNewArrivalsSection(
    newArrivals: List<ProductEntity>,
    onProductClick: (ProductEntity) -> Unit,
    onAddToCart: (ProductEntity) -> Unit,
    onViewMore: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp)
            .background(Color.White, RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFFE6F4EA), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.NewReleases,
                    contentDescription = null,
                    tint = FreshGreenPrimary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "新品上架",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = FreshGreenPrimary
                )
            }

            Text(
                text = "查看更多 >",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = FreshGreenPrimary,
                modifier = Modifier.clickable { onViewMore() }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            newArrivals.forEach { product ->
                Box(modifier = Modifier.weight(1f)) {
                    NewProductItem(
                        product = product,
                        onClick = { onProductClick(product) },
                        onAddToCart = { onAddToCart(product) }
                    )
                }
            }
        }
    }
}

@Composable
fun NewProductItem(
    product: ProductEntity,
    onClick: () -> Unit,
    onAddToCart: () -> Unit
) {
    val foodEmojis = mapOf(
        "blueberry_1" to "🫐",
        "durian_1" to "🍈"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = LightBg)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp)
                    .background(Color.White, RoundedCornerShape(6.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = foodEmojis[product.id] ?: "🍍",
                    fontSize = 38.sp
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .background(FreshGreenPrimary, RoundedCornerShape(topStart = 6.dp, bottomEnd = 6.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text("新品", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = product.name,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = NeutralDark,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "¥${product.price}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = FreshGreenPrimary
                )

                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .background(FreshGreenPrimary, CircleShape)
                        .clickable { onAddToCart() }
                        .testTag("add_to_cart_new_${product.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ServiceGuarantees() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                "惠家服务保障",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = NeutralDark
            )
            Spacer(modifier = Modifier.height(10.dp))

            val guarantees = listOf(
                Triple(Icons.Default.Verified, "新鲜直达", "每日新鲜 严把品质保障"),
                Triple(Icons.Default.Speed, "快速配送", "专业物流 最快30分钟送达"),
                Triple(Icons.Default.Savings, "价格实惠", "天天低价 产地直采省钱省心"),
                Triple(Icons.Default.SupportAgent, "售后无忧", "不满意退款 7天无理由退换")
            )

            guarantees.forEach { (icon, title, desc) ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = FreshGreenPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NeutralDark)
                        Text(desc, fontSize = 9.sp, color = NeutralGray)
                    }
                }
            }
        }
    }
}

@Composable
fun HomeFooter() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "好食材 • 好生活",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = FreshGreenPrimary,
            letterSpacing = 2.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "惠家超市 用心挑选 只为更好的你",
            fontSize = 10.sp,
            color = NeutralGray
        )
        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun HomeProductGridItem(
    product: ProductEntity,
    onProductClick: () -> Unit,
    onAddToCart: () -> Unit
) {
    val foodEmojis = mapOf(
        "tomato_1" to "🍅", "egg_1" to "🥚", "cabbage_1" to "🥬", "milk_1" to "🥛",
        "blueberry_1" to "🫐", "durian_1" to "🍈", "pork_1" to "🥩", "fish_1" to "🐟",
        "shrimp_1" to "🍤", "oil_1" to "🍳", "soy_1" to "🧂", "snack_1" to "🍿",
        "rice_cake_1" to "🍘", "water_1" to "🥤", "detergent_1" to "🧴", "laundry_1" to "🧼"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onProductClick() }
            .shadow(1.dp, RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp)
                    .background(LightBg, RoundedCornerShape(6.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = foodEmojis[product.id] ?: "🍎",
                    fontSize = 42.sp
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = product.name,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = NeutralDark,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = product.description,
                fontSize = 9.sp,
                color = NeutralGray,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "¥${product.price}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = FreshGreenPrimary
                )

                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .background(FreshGreenPrimary, CircleShape)
                        .clickable { onAddToCart() }
                        .testTag("add_to_cart_grid_${product.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

// ==========================================
// SCREEN 2: DUAL PANE CATEGORY LAYOUT
// ==========================================

@Composable
fun CategoryScreenContent(viewModel: SupermarketViewModel) {
    val products by viewModel.allProducts.collectAsStateWithLifecycle()
    val activeCategory by viewModel.activeCategory.collectAsStateWithLifecycle()

    val categories = listOf(
        "新鲜蔬菜", "肉禽蛋奶", "海鲜水产", "粮油调味", "乳品烘焙", "休闲零食", "饮料酒水", "日用百货"
    )

    val categoryIcons = mapOf(
        "新鲜蔬菜" to "🥬", "肉禽蛋奶" to "🥩", "海鲜水产" to "🐟", "粮油调味" to "🍳",
        "乳品烘焙" to "🍞", "休闲零食" to "🍿", "饮料酒水" to "🍹", "日用百货" to "🧴"
    )

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(LightBg)
    ) {
        // Left Side categories list (Sidebar Rail)
        Column(
            modifier = Modifier
                .width(90.dp)
                .fillMaxHeight()
                .background(Color.White)
        ) {
            categories.forEach { cat ->
                val isSelected = cat == activeCategory
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .background(if (isSelected) LightBg else Color.White)
                        .clickable { viewModel.setActiveCategory(cat) }
                        .testTag("sidebar_cat_$cat"),
                    contentAlignment = Alignment.CenterStart
                ) {
                    if (isSelected) {
                        // Left active indicator strip
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(4.dp)
                                .background(FreshGreenPrimary)
                        )
                    }

                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(categoryIcons[cat] ?: "🍎", fontSize = 14.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = cat.replace("新鲜", "").replace("水产", ""),
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) FreshGreenPrimary else NeutralDark
                        )
                    }
                }
            }
        }

        // Thin vertical divider line
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .width(1.dp)
                .background(BorderGray)
        )

        // Right Side product grid list
        val catProducts = products.filter { it.category == activeCategory }

        if (catProducts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("该分类下暂无商品", color = NeutralGray, fontSize = 12.sp)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(catProducts) { product ->
                    HomeProductGridItem(
                        product = product,
                        onProductClick = { viewModel.viewProductDetails(product) },
                        onAddToCart = { viewModel.addToCart(product) }
                    )
                }
            }
        }
    }
}

// ==========================================
// SCREEN 3: INTERACTIVE SHOPPING CART
// ==========================================

@Composable
fun CartScreenContent(
    viewModel: SupermarketViewModel,
    onCheckout: () -> Unit
) {
    val cartItems by viewModel.cartWithProducts.collectAsStateWithLifecycle()
    val totalAmount by viewModel.cartTotal.collectAsStateWithLifecycle()

    val foodEmojis = mapOf(
        "tomato_1" to "🍅", "egg_1" to "🥚", "cabbage_1" to "🥬", "milk_1" to "🥛",
        "blueberry_1" to "🫐", "durian_1" to "🍈", "pork_1" to "🥩", "fish_1" to "🐟",
        "shrimp_1" to "🍤", "oil_1" to "🍳", "soy_1" to "🧂", "snack_1" to "🍿",
        "rice_cake_1" to "🍘", "water_1" to "🥤", "detergent_1" to "🧴", "laundry_1" to "🧼"
    )

    if (cartItems.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(FreshGreenLight, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ShoppingCart,
                    contentDescription = null,
                    tint = FreshGreenPrimary,
                    modifier = Modifier.size(40.dp)
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text("您的购物车是空的", fontWeight = FontWeight.Bold, color = NeutralDark, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Text("去选购些新鲜、放心的好食材吧！", color = NeutralGray, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(24.dp))
            Button(
                onClick = { viewModel.navigateTo(AppScreen.HOME) },
                colors = ButtonDefaults.buttonColors(containerColor = FreshGreenPrimary)
            ) {
                Text("去选购")
            }
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(LightBg)
        ) {
            // Cart Header with clean option
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "购物车 (已选 ${cartItems.size} 件商品)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = NeutralDark
                )

                Text(
                    text = "清空全部",
                    color = NeutralGray,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .clickable { viewModel.clearCart() }
                        .testTag("clear_cart_btn")
                )
            }

            // Cart lists
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(cartItems) { (product, quantity) ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Product Graphic
                            Box(
                                modifier = Modifier
                                    .size(60.dp)
                                    .background(LightBg, RoundedCornerShape(6.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = foodEmojis[product.id] ?: "🍎",
                                    fontSize = 28.sp
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            // Product details
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = product.name,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NeutralDark
                                )
                                Text(
                                    text = "规格: ${product.unit}  •  库存: 充足",
                                    fontSize = 10.sp,
                                    color = NeutralGray
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "¥${product.price}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = FreshGreenPrimary
                                )
                            }

                            // Quantity Adjusters
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .background(LightBg, CircleShape)
                                        .clickable { viewModel.updateCartQuantity(product.id, quantity - 1) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Remove,
                                        contentDescription = "Reduce",
                                        tint = NeutralDark,
                                        modifier = Modifier.size(12.dp)
                                    )
                                }

                                Text(
                                    text = quantity.toString(),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NeutralDark
                                )

                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .background(FreshGreenPrimary, CircleShape)
                                        .clickable { viewModel.updateCartQuantity(product.id, quantity + 1) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Increase",
                                        tint = Color.White,
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Bottom billing bar
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(8.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("合计金额", fontSize = 11.sp, color = NeutralGray)
                        Text(
                            text = "¥${String.format("%.2f", totalAmount)}",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = AccentOrange
                        )
                    }

                    Button(
                        onClick = onCheckout,
                        colors = ButtonDefaults.buttonColors(containerColor = FreshGreenPrimary),
                        contentPadding = PaddingValues(horizontal = 28.dp, vertical = 12.dp),
                        modifier = Modifier.testTag("checkout_button")
                    ) {
                        Text("去结算", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ==========================================
// SCREEN 4: MEMBER CARD & POINTS BENEFITS STORE
// ==========================================

@Composable
fun MemberScreenContent(
    viewModel: SupermarketViewModel,
    onOpenRegister: () -> Unit
) {
    val userProfile by viewModel.user.collectAsStateWithLifecycle()
    var pointsTabActive by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LightBg)
            .verticalScroll(rememberScrollState())
    ) {
        // 1. Membership Status Card
        if (userProfile == null || userProfile?.isMember == false) {
            Box(modifier = Modifier.padding(16.dp)) {
                HomeRegisterMemberCard(onOpenRegister = onOpenRegister)
            }
        } else {
            userProfile?.let { profile ->
                MemberPremiumCard(profile = profile, onRecharge = { amount ->
                    viewModel.rechargeWallet(amount)
                })
            }
        }

        // 2. Tab Navigation between "积分好礼" (Points Store) and "会员专属特权" (Privileges)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { pointsTabActive = true }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "积分换好礼",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (pointsTabActive) FreshGreenPrimary else NeutralDark
                    )
                    if (pointsTabActive) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .width(60.dp)
                                .height(3.dp)
                                .background(FreshGreenPrimary)
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { pointsTabActive = false }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "会员特权",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (!pointsTabActive) FreshGreenPrimary else NeutralDark
                    )
                    if (!pointsTabActive) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .width(60.dp)
                                .height(3.dp)
                                .background(FreshGreenPrimary)
                        )
                    }
                }
            }

            // Thin horizontal divider line
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(BorderGray)
            )
        }

        if (pointsTabActive) {
            PointsStoreContent(viewModel = viewModel)
        } else {
            PrivilegesContent()
        }
    }
}

@Composable
fun MemberPremiumCard(
    profile: UserEntity,
    onRecharge: (Double) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .shadow(4.dp, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = FreshGreenPrimary)
    ) {
        Column(
            modifier = Modifier
                .background(
                    Brush.radialGradient(
                        colors = listOf(FreshGreenPrimary, FreshGreenDark)
                    )
                )
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(Color.White.copy(alpha = 0.2f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = profile.username,
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .background(GoldAccent, RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                profile.tier,
                                color = NeutralDark,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }

                Text(
                    text = "HJ8880${profile.phone.takeLast(4)}",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Points and Wallet balance Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text("当前会员积分", fontSize = 10.sp, color = Color.White.copy(alpha = 0.8f))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Stars,
                            contentDescription = null,
                            tint = GoldAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = profile.memberPoints.toString(),
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            color = GoldAccent
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("钱包卡内余额", fontSize = 10.sp, color = Color.White.copy(alpha = 0.8f))
                    Text(
                        text = "¥${String.format("%.2f", profile.balance)}",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Wallet Recharge Actions
            Divider(color = Color.White.copy(alpha = 0.2f))
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                "快速充值(模拟卡包优惠):",
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                val recharges = listOf(
                    Pair(20.0, "得20"),
                    Pair(50.0, "送5"),
                    Pair(100.0, "送15")
                )

                recharges.forEach { (amount, bonus) ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(Color.White.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                            .clickable {
                                // Double Reward logic
                                val totalCredit = amount + if (amount == 50.0) 5.0 else if (amount == 100.0) 15.0 else 0.0
                                onRecharge(totalCredit)
                            }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("¥${amount.toInt()}", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            Text(bonus, fontSize = 8.sp, color = GoldAccent, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PointsStoreContent(viewModel: SupermarketViewModel) {
    val userProfile by viewModel.user.collectAsStateWithLifecycle()

    val redeemItems = listOf(
        Triple("snack_1", "卫龙大面筋 106g", 250),
        Triple("rice_cake_1", "旺旺雪饼 84g", 300),
        Triple("egg_1", "正大鲜鸡蛋 10枚", 500),
        Triple("milk_1", "伊利纯牛奶 24盒", 3000)
    )

    val foodEmojis = mapOf(
        "snack_1" to "🍿",
        "rice_cake_1" to "🍘",
        "egg_1" to "🥚",
        "milk_1" to "🥛"
    )

    Column(modifier = Modifier.padding(16.dp)) {
        Text(
            "积分换豪礼 (兑换直接包邮送达)",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = NeutralDark
        )
        Spacer(modifier = Modifier.height(12.dp))

        redeemItems.forEach { (id, name, pointsRequired) ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(LightBg, RoundedCornerShape(6.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(foodEmojis[id] ?: "🎁", fontSize = 24.sp)
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NeutralDark)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Stars,
                                    contentDescription = null,
                                    tint = GoldAccent,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Text("$pointsRequired 积分", fontSize = 10.sp, color = GoldAccent, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Button(
                        onClick = {
                            val currentPoints = userProfile?.memberPoints ?: 0
                            if (currentPoints < pointsRequired) {
                                viewModel.showToast("积分不足，购物下单可获得积分")
                            } else {
                                viewModel.redeemPointsProduct(pointsRequired)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                        modifier = Modifier
                            .height(28.dp)
                            .testTag("redeem_btn_$id"),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("立即兑换", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = NeutralDark)
                    }
                }
            }
        }
    }
}

@Composable
fun PrivilegesContent() {
    val privileges = listOf(
        Pair("会员专享价", "全店精选好物，会员一律享受8.8折至9.5折特惠"),
        Pair("1.5倍积分增值", "会员每消费 ¥1 可获 1.5 积分（普通用户为 1 积分）"),
        Pair("退换无忧保障", "专享7天内上门取件退款服务，免配送费"),
        Pair("生日专享礼包", "生日当天可获 1000 积分大礼包及 ¥30 无门槛券")
    )

    Column(modifier = Modifier.padding(16.dp)) {
        Text(
            "白金会员特权服务",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = NeutralDark
        )
        Spacer(modifier = Modifier.height(12.dp))

        privileges.forEach { (title, desc) ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Stars,
                        contentDescription = null,
                        tint = GoldAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NeutralDark)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(desc, fontSize = 10.sp, color = NeutralGray)
                    }
                }
            }
        }
    }
}

// ==========================================
// SCREEN 5: ORDER COMPOSABLE LIST
// ==========================================

@Composable
fun OrdersScreenContent(viewModel: SupermarketViewModel) {
    val orders by viewModel.orders.collectAsStateWithLifecycle()

    if (orders.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.Assignment,
                contentDescription = null,
                tint = NeutralGray,
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text("您还没有购买记录", fontWeight = FontWeight.Bold, color = NeutralDark, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Text("在这里可以看到您的历史配送订单", color = NeutralGray, fontSize = 11.sp)
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(LightBg)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Text(
                    "全部配送订单",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeutralDark,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }

            items(orders) { order ->
                OrderHistoryCard(order = order, onUrgeDelivery = {
                    viewModel.showToast("催单成功！商家已安排加急极速配送")
                })
            }
        }
    }
}

@Composable
fun OrderHistoryCard(
    order: OrderEntity,
    onUrgeDelivery: () -> Unit
) {
    val dateStr = remember(order.timestamp) {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        sdf.format(Date(order.timestamp))
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.ReceiptLong,
                        contentDescription = null,
                        tint = FreshGreenPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "订单号: ${order.orderId}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeutralDark
                    )
                }

                Box(
                    modifier = Modifier
                        .background(FreshGreenLight, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = order.status,
                        fontSize = 9.sp,
                        color = FreshGreenDark,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = BorderGray)
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "购买商品:",
                fontSize = 11.sp,
                color = NeutralGray,
                fontWeight = FontWeight.Medium
            )

            Text(
                text = order.itemsSummary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = NeutralDark,
                modifier = Modifier.padding(vertical = 2.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text(
                        text = "下单时间: $dateStr",
                        fontSize = 10.sp,
                        color = NeutralGray
                    )
                    Text(
                        text = "获得积分: +${order.pointsEarned}",
                        fontSize = 10.sp,
                        color = GoldAccent,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "实付款: ¥${String.format("%.2f", order.totalPrice)}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        color = AccentOrange
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Button(
                        onClick = onUrgeDelivery,
                        colors = ButtonDefaults.buttonColors(containerColor = FreshGreenPrimary),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                        modifier = Modifier.height(24.dp)
                    ) {
                        Text("一键催单", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ==========================================
// SCREEN 6: FAVORITES BOOKMARK SCREEN
// ==========================================

@Composable
fun FavoritesScreenContent(viewModel: SupermarketViewModel) {
    val products by viewModel.allProducts.collectAsStateWithLifecycle()
    val favorites by viewModel.favorites.collectAsStateWithLifecycle()

    val favProducts = products.filter { favorites.contains(it.id) }

    if (favProducts.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.FavoriteBorder,
                contentDescription = null,
                tint = NeutralGray,
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text("您还没有收藏任何商品", fontWeight = FontWeight.Bold, color = NeutralDark, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Text("在浏览食材时点击爱心图标，即可保存到这里", color = NeutralGray, fontSize = 11.sp, textAlign = TextAlign.Center)
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(LightBg)
                .padding(12.dp)
        ) {
            Text(
                "我的收藏 (${favProducts.size})",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = NeutralDark,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(favProducts) { product ->
                    HomeProductGridItem(
                        product = product,
                        onProductClick = { viewModel.viewProductDetails(product) },
                        onAddToCart = { viewModel.addToCart(product) }
                    )
                }
            }
        }
    }
}

// ==========================================
// INTERACTIVE DIALOGS & POPUPS
// ==========================================

@Composable
fun ProductDetailDialog(
    product: ProductEntity,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onAddToCart: () -> Unit,
    onDismiss: () -> Unit
) {
    val foodEmojis = mapOf(
        "tomato_1" to "🍅", "egg_1" to "🥚", "cabbage_1" to "🥬", "milk_1" to "🥛",
        "blueberry_1" to "🫐", "durian_1" to "🍈", "pork_1" to "🥩", "fish_1" to "🐟",
        "shrimp_1" to "🍤", "oil_1" to "🍳", "soy_1" to "🧂", "snack_1" to "🍿",
        "rice_cake_1" to "🍘", "water_1" to "🥤", "detergent_1" to "🧴", "laundry_1" to "🧼"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Image Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .background(LightBg, RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = foodEmojis[product.id] ?: "🍎",
                        fontSize = 64.sp
                    )

                    // Favorite toggler
                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .background(Color.White.copy(alpha = 0.8f), CircleShape)
                            .size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Fav",
                            tint = if (isFavorite) Color.Red else NeutralGray,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Special tag
                    if (product.isSpecial) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .background(AccentOrange, RoundedCornerShape(topStart = 10.dp, bottomEnd = 10.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("特惠特惠", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Name & Spec
                Text(
                    text = product.name,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    color = NeutralDark
                )
                Text(
                    text = "规格: ${product.unit}  •  品类: ${product.category}",
                    fontSize = 11.sp,
                    color = NeutralGray
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Price line
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "¥${product.price}",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = AccentOrange
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    if (product.originalPrice != null) {
                        Text(
                            text = "¥${product.originalPrice}",
                            fontSize = 12.sp,
                            color = NeutralGray,
                            textDecoration = TextDecoration.LineThrough
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Description
                Text(
                    text = "宝贝介绍:",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeutralDark
                )
                Text(
                    text = product.description,
                    fontSize = 11.sp,
                    color = NeutralDark,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Actions row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = NeutralGray)
                    ) {
                        Text("返回", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            onAddToCart()
                            onDismiss()
                        },
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("add_to_cart_dialog_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = FreshGreenPrimary)
                    ) {
                        Icon(imageVector = Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("加入购物车", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun RegisterMemberDialog(
    onRegister: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Sprout image
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .background(FreshGreenLight, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Stars,
                        contentDescription = null,
                        tint = FreshGreenPrimary,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    "注册惠家白金会员",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = FreshGreenDark
                )

                Text(
                    "注册立享 ¥100 优惠券与 500 会员积分！",
                    fontSize = 11.sp,
                    color = AccentOrange,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("您的姓名", fontSize = 12.sp) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reg_name_input"),
                    shape = RoundedCornerShape(8.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("手机号码", fontSize = 12.sp) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reg_phone_input"),
                    shape = RoundedCornerShape(8.dp)
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("取消", color = NeutralGray)
                    }

                    Button(
                        onClick = { onRegister(name, phone) },
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("reg_confirm_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = FreshGreenPrimary)
                    ) {
                        Text("提交并注册", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun CheckoutDialog(
    totalAmount: Double,
    userBalance: Double,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "确认配送订单",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeutralDark
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "配送地址:",
                    fontSize = 11.sp,
                    color = NeutralGray,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "北京市朝阳区惠家大厦 A座 512室",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = NeutralDark
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "预计送达时间:",
                    fontSize = 11.sp,
                    color = NeutralGray,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "极速送达 (预计 30 分钟内送达)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = FreshGreenPrimary
                )

                Spacer(modifier = Modifier.height(12.dp))
                Divider(color = BorderGray)
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("应付金额:", fontSize = 12.sp, color = NeutralDark)
                    Text("¥${String.format("%.2f", totalAmount)}", fontSize = 14.sp, fontWeight = FontWeight.Black, color = AccentOrange)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("您的卡包余额:", fontSize = 12.sp, color = NeutralDark)
                    Text("¥${String.format("%.2f", userBalance)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (userBalance >= totalAmount) FreshGreenPrimary else Color.Red)
                }

                Spacer(modifier = Modifier.height(20.dp))

                if (userBalance < totalAmount) {
                    Text(
                        "余额不足！请到会员特利页快速充值",
                        color = Color.Red,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("取消", color = NeutralGray)
                    }

                    Button(
                        onClick = onConfirm,
                        enabled = userBalance >= totalAmount,
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("checkout_confirm_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = FreshGreenPrimary)
                    ) {
                        Text("确认支付", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
