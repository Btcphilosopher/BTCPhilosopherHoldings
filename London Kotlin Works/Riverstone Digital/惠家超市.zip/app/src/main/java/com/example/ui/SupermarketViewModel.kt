package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.SupermarketRepository
import com.example.data.database.CartItemEntity
import com.example.data.database.OrderEntity
import com.example.data.database.ProductEntity
import com.example.data.database.UserEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppScreen {
    HOME,
    CATEGORY,
    CART,
    MEMBER,
    ORDERS,
    FAVORITES
}

data class CartItemWithProduct(
    val product: ProductEntity,
    val quantity: Int
)

class SupermarketViewModel(private val repository: SupermarketRepository) : ViewModel() {

    init {
        viewModelScope.launch {
            // Seed database on first startup
            repository.populateInitialProducts()
            // Ensure there is a local guest/profile active
            repository.createInitialGuestUser()
        }
    }

    // --- Navigation State ---
    private val _currentScreen = MutableStateFlow(AppScreen.HOME)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val screenHistory = mutableListOf<AppScreen>()

    fun navigateTo(screen: AppScreen) {
        if (_currentScreen.value != screen) {
            screenHistory.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (screenHistory.isNotEmpty()) {
            _currentScreen.value = screenHistory.removeAt(screenHistory.lastIndex)
            return true
        }
        return false
    }

    // --- Search & Filters State ---
    private val _searchText = MutableStateFlow("")
    val searchText: StateFlow<String> = _searchText.asStateFlow()

    private val _activeCategory = MutableStateFlow("新鲜蔬菜")
    val activeCategory: StateFlow<String> = _activeCategory.asStateFlow()

    fun setSearchText(text: String) {
        _searchText.value = text
    }

    fun setActiveCategory(category: String) {
        _activeCategory.value = category
    }

    // --- Selected Product for Detail View ---
    private val _selectedProduct = MutableStateFlow<ProductEntity?>(null)
    val selectedProduct: StateFlow<ProductEntity?> = _selectedProduct.asStateFlow()

    fun viewProductDetails(product: ProductEntity?) {
        _selectedProduct.value = product
    }

    // --- Notification & Feedbacks ---
    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    fun showToast(message: String) {
        _toastMessage.value = message
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    // --- Reactive Data Mapping ---
    val allProducts: StateFlow<List<ProductEntity>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val user: StateFlow<UserEntity?> = repository.user
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val orders: StateFlow<List<OrderEntity>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favorites: StateFlow<List<String>> = repository.favorites
        .map { favList -> favList.map { it.productId } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cartWithProducts: StateFlow<List<CartItemWithProduct>> = combine(
        repository.cartItems,
        repository.allProducts
    ) { cartList, productList ->
        cartList.mapNotNull { cartItem ->
            val product = productList.find { it.id == cartItem.productId }
            if (product != null) CartItemWithProduct(product, cartItem.quantity) else null
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cartTotal: StateFlow<Double> = cartWithProducts.map { list ->
        list.sumOf { it.product.price * it.quantity }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val cartCount: StateFlow<Int> = cartWithProducts.map { list ->
        list.sumOf { it.quantity }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // --- Cart Actions ---
    fun addToCart(product: ProductEntity) {
        viewModelScope.launch {
            repository.addToCart(product.id)
            showToast("已加入购物车: ${product.name}")
        }
    }

    fun updateCartQuantity(productId: String, quantity: Int) {
        viewModelScope.launch {
            repository.updateCartQuantity(productId, quantity)
        }
    }

    fun removeFromCart(productId: String) {
        viewModelScope.launch {
            repository.removeFromCart(productId)
        }
    }

    fun clearCart() {
        viewModelScope.launch {
            repository.clearCart()
        }
    }

    // --- Favorites ---
    fun toggleFavorite(product: ProductEntity) {
        viewModelScope.launch {
            repository.toggleFavorite(product.id)
            val isFav = favorites.value.contains(product.id)
            if (!isFav) {
                showToast("已添加到收藏")
            } else {
                showToast("已取消收藏")
            }
        }
    }

    // --- Membership actions ---
    fun registerMember(username: String, phone: String) {
        viewModelScope.launch {
            if (username.isBlank() || phone.isBlank()) {
                showToast("请填写完整的名字和手机号")
                return@launch
            }
            val u = repository.registerUser(username, phone)
            showToast("注册会员成功！赠送500积分和¥100余额")
        }
    }

    fun rechargeWallet(amount: Double) {
        viewModelScope.launch {
            repository.topUpWallet(amount)
            showToast("成功充值 ¥${String.format("%.2f", amount)}")
        }
    }

    fun redeemPointsProduct(pointsRequired: Int) {
        viewModelScope.launch {
            repository.updatePointsAndBalance(-pointsRequired, 0.0)
            showToast("兑换成功！礼品将在近期随单配送")
        }
    }

    // --- Order placement ---
    fun checkoutCart(onSuccess: () -> Unit) {
        viewModelScope.launch {
            val items = cartWithProducts.value
            if (items.isEmpty()) {
                showToast("购物车是空的")
                return@launch
            }
            val total = cartTotal.value
            val userProfile = user.value
            if (userProfile == null) {
                showToast("未检测到用户状态")
                return@launch
            }
            if (userProfile.balance < total) {
                showToast("余额不足，请在个人中心充值")
                return@launch
            }

            // Generate summary string
            val itemsSummary = items.joinToString { "${it.product.name.take(6)}... x${it.quantity}" }

            val success = repository.createOrder(total, itemsSummary)
            if (success) {
                repository.clearCart()
                showToast("下单成功！获得 ${(total).toInt()} 积分")
                onSuccess()
            } else {
                showToast("下单失败")
            }
        }
    }
}

class SupermarketViewModelFactory(private val repository: SupermarketRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SupermarketViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return SupermarketViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
