package com.example.data

import com.example.data.database.CartItemEntity
import com.example.data.database.FavoriteEntity
import com.example.data.database.OrderEntity
import com.example.data.database.ProductEntity
import com.example.data.database.SupermarketDao
import com.example.data.database.UserEntity
import kotlinx.coroutines.flow.Flow

class SupermarketRepository(private val dao: SupermarketDao) {

    // --- Products ---
    val allProducts: Flow<List<ProductEntity>> = dao.getAllProducts()

    suspend fun getProductById(id: String): ProductEntity? {
        return dao.getProductById(id)
    }

    suspend fun populateInitialProducts() {
        if (dao.getProductCount() > 0) return

        val initialProducts = listOf(
            ProductEntity(
                id = "tomato_1",
                name = "新鲜西红柿 500g",
                category = "新鲜蔬菜",
                price = 3.98,
                originalPrice = 6.90,
                isSpecial = true,
                isNew = false,
                description = "优质当季新鲜红熟西红柿，沙瓤多汁，酸甜可口，富含维生素C，凉拌、炒蛋、煮汤皆宜。",
                imageResName = "ic_tomato"
            ),
            ProductEntity(
                id = "egg_1",
                name = "正大鲜鸡蛋 10枚",
                category = "肉禽蛋奶",
                price = 8.90,
                originalPrice = 12.90,
                isSpecial = true,
                isNew = false,
                description = "精选谷物喂养蛋鸡，蛋壳完整，蛋黄饱满，新鲜直达，每一颗都是高蛋白好营养。",
                imageResName = "ic_egg"
            ),
            ProductEntity(
                id = "cabbage_1",
                name = "上海青 500g",
                category = "新鲜蔬菜",
                price = 2.98,
                originalPrice = 5.90,
                isSpecial = true,
                isNew = false,
                description = "优质上海青，叶绿茎白，口感鲜脆，田间直达，美味健康，炒食煮面极佳。",
                imageResName = "ic_cabbage"
            ),
            ProductEntity(
                id = "milk_1",
                name = "伊利纯牛奶 250ml*24",
                category = "乳品烘焙",
                price = 59.90,
                originalPrice = 79.90,
                isSpecial = true,
                isNew = false,
                description = "伊利纯牛奶整箱装，优质奶源，100%纯牛乳，口感香醇，给全家每天的营养健康保障。",
                imageResName = "ic_milk"
            ),
            ProductEntity(
                id = "blueberry_1",
                name = "云南蓝莓 125g",
                category = "乳品烘焙", // Placed in Dairy/Bakery in custom categorizations, or Fruit
                price = 12.90,
                originalPrice = null,
                isSpecial = false,
                isNew = true,
                description = "来自云南高原的阳光蓝莓，颗粒饱满，皮薄多汁，爽甜爆汁，富含花青素的健康水果。",
                imageResName = "ic_blueberry"
            ),
            ProductEntity(
                id = "durian_1",
                name = "泰国榴莲 1kg",
                category = "新鲜蔬菜", // Or general fruit section
                price = 39.90,
                originalPrice = null,
                isSpecial = false,
                isNew = true,
                description = "泰国原装进口金枕头榴莲，肉质金黄，绵密细腻，浓郁香甜，极富营养的水果之王。",
                imageResName = "ic_durian"
            ),
            ProductEntity(
                id = "pork_1",
                name = "优选五花肉 500g",
                category = "肉禽蛋奶",
                price = 19.90,
                originalPrice = 25.00,
                isSpecial = false,
                isNew = false,
                description = "精选肥瘦相间优质五花肉，肉质细嫩，红烧、烤肉、小炒美味难挡。",
                imageResName = "ic_pork"
            ),
            ProductEntity(
                id = "fish_1",
                name = "活鲜鲈鱼 550g",
                category = "海鲜水产",
                price = 18.90,
                originalPrice = 24.00,
                isSpecial = false,
                isNew = false,
                description = "活水鲜美鲈鱼，清蒸首选，肉质洁白细嫩，少刺鲜美，老少咸宜。",
                imageResName = "ic_fish"
            ),
            ProductEntity(
                id = "shrimp_1",
                name = "南美白对虾 500g",
                category = "海鲜水产",
                price = 29.90,
                originalPrice = null,
                isSpecial = false,
                isNew = false,
                description = "深冷速冻鲜对虾，壳薄体丰，虾肉紧致弹牙，清白鲜美，白灼香脆红烧皆宜。",
                imageResName = "ic_shrimp"
            ),
            ProductEntity(
                id = "oil_1",
                name = "金龙鱼调和油 5L",
                category = "粮油调味",
                price = 69.90,
                originalPrice = 79.90,
                isSpecial = false,
                isNew = false,
                description = "经典食用植物调和油，黄金比例，富含不饱和脂肪酸，烟点适中，健康美味每一餐。",
                imageResName = "ic_oil"
            ),
            ProductEntity(
                id = "soy_1",
                name = "海天金标生抽 500ml",
                category = "粮油调味",
                price = 8.90,
                originalPrice = null,
                isSpecial = false,
                isNew = false,
                description = "非转基因黄豆酿造生抽，香气浓郁，提鲜上色，家常烹饪必不可少的经典佐料。",
                imageResName = "ic_soy"
            ),
            ProductEntity(
                id = "snack_1",
                name = "卫龙大面筋 106g",
                category = "休闲零食",
                price = 4.50,
                originalPrice = null,
                isSpecial = false,
                isNew = false,
                description = "经典国民辣条，香辣鲜甜，香气扑鼻，筋道十足，休闲追剧解馋必备神物。",
                imageResName = "ic_snack"
            ),
            ProductEntity(
                id = "rice_cake_1",
                name = "旺旺雪饼 84g",
                category = "休闲零食",
                price = 5.80,
                originalPrice = null,
                isSpecial = false,
                isNew = false,
                description = "精选优质大米，雪花糖衣，松脆甜香，旺旺经典雪饼，童年的甜脆美味。",
                imageResName = "ic_rice_cake"
            ),
            ProductEntity(
                id = "water_1",
                name = "农夫山泉饮用水 5L",
                category = "饮料酒水",
                price = 9.90,
                originalPrice = null,
                isSpecial = false,
                isNew = false,
                description = "天然弱碱性优质矿泉水，大容量，适合家庭煮汤泡茶及日常饮用。",
                imageResName = "ic_water"
            ),
            ProductEntity(
                id = "detergent_1",
                name = "雕牌洗洁精 1.5kg",
                category = "日用百货",
                price = 12.90,
                originalPrice = 16.00,
                isSpecial = false,
                isNew = false,
                description = "强力去油洗洁精，温和护手，无残留，高效洗净餐具果蔬，大容量实惠装。",
                imageResName = "ic_detergent"
            ),
            ProductEntity(
                id = "laundry_1",
                name = "蓝月亮洗衣液 2kg",
                category = "日用百货",
                price = 39.90,
                originalPrice = null,
                isSpecial = false,
                isNew = false,
                description = "深层洁净亮白，温和配方不伤手，薰衣草香芬怡人，强力去渍，柔顺衣物。",
                imageResName = "ic_laundry"
            )
        )
        dao.insertProducts(initialProducts)
    }

    // --- Cart ---
    val cartItems: Flow<List<CartItemEntity>> = dao.getCartItems()

    suspend fun addToCart(productId: String) {
        val existing = dao.getCartItem(productId)
        if (existing != null) {
            dao.insertCartItem(CartItemEntity(productId, existing.quantity + 1))
        } else {
            dao.insertCartItem(CartItemEntity(productId, 1))
        }
    }

    suspend fun updateCartQuantity(productId: String, quantity: Int) {
        if (quantity <= 0) {
            dao.deleteCartItem(productId)
        } else {
            dao.insertCartItem(CartItemEntity(productId, quantity))
        }
    }

    suspend fun removeFromCart(productId: String) {
        dao.deleteCartItem(productId)
    }

    suspend fun clearCart() {
        dao.clearCart()
    }

    // --- Favorites ---
    val favorites: Flow<List<FavoriteEntity>> = dao.getFavorites()

    suspend fun toggleFavorite(productId: String) {
        val existing = dao.getFavoriteItem(productId)
        if (existing != null) {
            dao.deleteFavorite(productId)
        } else {
            dao.insertFavorite(FavoriteEntity(productId))
        }
    }

    fun isFavorite(productId: String): Flow<Boolean> {
        return dao.isFavorite(productId)
    }

    // --- User ---
    val user: Flow<UserEntity?> = dao.getUserFlow()

    suspend fun registerUser(username: String, phone: String): UserEntity {
        val defaultUser = dao.getUserSync()
        val u = if (defaultUser != null) {
            defaultUser.copy(
                username = username,
                phone = phone,
                isMember = true,
                memberPoints = defaultUser.memberPoints + 500, // Gift 500 points on registration!
                balance = defaultUser.balance + 100.00, // Gift ¥100.00 wallet balance!
                tier = "白金会员"
            )
        } else {
            UserEntity(
                username = username,
                phone = phone,
                memberPoints = 500, // Gift 500 points
                balance = 150.00, // Starts with ¥150.00
                isMember = true,
                tier = "白金会员"
            )
        }
        dao.insertUser(u)
        return u
    }

    suspend fun createInitialGuestUser() {
        if (dao.getUserSync() == null) {
            dao.insertUser(
                UserEntity(
                    username = "游客用户",
                    phone = "未绑定",
                    memberPoints = 0,
                    balance = 100.00, // Pre-load 100 RMB for simulation
                    isMember = false,
                    tier = "普通游客"
                )
            )
        }
    }

    suspend fun topUpWallet(amount: Double) {
        val current = dao.getUserSync()
        if (current != null) {
            dao.updateUser(current.copy(balance = current.balance + amount))
        }
    }

    suspend fun updatePointsAndBalance(pointsDelta: Int, balanceDelta: Double) {
        val current = dao.getUserSync()
        if (current != null) {
            dao.updateUser(current.copy(
                memberPoints = current.memberPoints + pointsDelta,
                balance = current.balance + balanceDelta
            ))
        }
    }

    // --- Orders ---
    val allOrders: Flow<List<OrderEntity>> = dao.getAllOrders()

    suspend fun createOrder(totalPrice: Double, itemsSummary: String): Boolean {
        val currentUser = dao.getUserSync() ?: return false
        if (currentUser.balance < totalPrice) return false

        val pointsEarned = totalPrice.toInt() // 1 point per ¥1 spent
        val newOrder = OrderEntity(
            orderId = "HJ" + System.currentTimeMillis().toString().takeLast(8),
            timestamp = System.currentTimeMillis(),
            totalPrice = totalPrice,
            itemsSummary = itemsSummary,
            status = "已下单",
            pointsEarned = pointsEarned
        )
        dao.insertOrder(newOrder)

        // Update user: deduct wallet balance, increase points
        val updatedUser = currentUser.copy(
            balance = currentUser.balance - totalPrice,
            memberPoints = currentUser.memberPoints + pointsEarned
        )
        dao.updateUser(updatedUser)
        return true
    }
}
