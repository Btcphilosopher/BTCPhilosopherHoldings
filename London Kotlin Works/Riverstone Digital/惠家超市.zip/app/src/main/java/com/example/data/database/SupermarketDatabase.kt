package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ProductEntity::class,
        CartItemEntity::class,
        FavoriteEntity::class,
        UserEntity::class,
        OrderEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SupermarketDatabase : RoomDatabase() {
    abstract fun supermarketDao(): SupermarketDao

    companion object {
        @Volatile
        private var INSTANCE: SupermarketDatabase? = null

        fun getDatabase(context: Context): SupermarketDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SupermarketDatabase::class.java,
                    "supermarket_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
