package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val orderId: String,
    val timestamp: Long,
    val totalPrice: Double,
    val itemsSummary: String, // e.g. "西红柿 x2, 上海青 x1"
    val status: String, // "已下单" (Placed), "商家已接单" (Accepted), "配送中" (Delivering), "已送达" (Delivered)
    val pointsEarned: Int
)
