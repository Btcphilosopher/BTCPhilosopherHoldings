package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Green Palette
val FreshGreenPrimary = Color(0xFF00965E)
val FreshGreenDark = Color(0xFF006D44)
val FreshGreenLight = Color(0xFFE8F5E9)

// Accent Orange/Red Palette (For Specials, discount tags, active states)
val AccentOrange = Color(0xFFFA541C)
val AccentOrangeDark = Color(0xFFD4380D)
val AccentOrangeLight = Color(0xFFFFECE5)

// Gold Palette (For Membership, levels, stars)
val GoldAccent = Color(0xFFFAAD14)
val GoldAccentLight = Color(0xFFFFFBE6)

// Dark/Neutral colors for text and background
val NeutralDark = Color(0xFF1F1F1F)
val NeutralGray = Color(0xFF8C8C8C)
val LightBg = Color(0xFFF7F9F7)
val CardBg = Color(0xFFFFFFFF)
val BorderGray = Color(0xFFE8E8E8)

