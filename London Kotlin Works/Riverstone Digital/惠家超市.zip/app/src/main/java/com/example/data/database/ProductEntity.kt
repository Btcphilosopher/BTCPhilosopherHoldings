package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String,
    val name: String,
    val category: String,
    val price: Double,
    val originalPrice: Double?,
    val isSpecial: Boolean,
    val isNew: Boolean,
    val description: String,
    val imageResName: String,
    val unit: String = "500g",
    val stock: Int = 100
)
