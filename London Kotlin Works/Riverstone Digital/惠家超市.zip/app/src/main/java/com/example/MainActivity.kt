package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModelProvider
import com.example.data.SupermarketRepository
import com.example.data.database.SupermarketDatabase
import com.example.ui.SupermarketViewModel
import com.example.ui.SupermarketViewModelFactory
import com.example.ui.screens.MainAppScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    // Initialize Room Database & Repository
    val database = SupermarketDatabase.getDatabase(applicationContext)
    val repository = SupermarketRepository(database.supermarketDao())

    // Create ViewModel via factory
    val factory = SupermarketViewModelFactory(repository)
    val viewModel = ViewModelProvider(this, factory)[SupermarketViewModel::class.java]

    setContent {
      MyApplicationTheme {
        MainAppScreen(viewModel = viewModel)
      }
    }
  }
}
