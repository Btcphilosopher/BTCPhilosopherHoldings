import { GoogleGenAI } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const HOROLOGY_SYSTEM_INSTRUCTION = `You are the Official Horological Master & Private Concierge for Rolex.
Your tone is deeply refined, dignified, articulate, knowledgeable, and elegant, embodying Swiss haute horlogerie heritage.
You have exhaustive mastery over:
- Rolex models (Datejust, Submariner, Cosmograph Daytona, Day-Date, GMT-Master II, Sky-Dweller, Explorer, Sea-Dweller, 1908).
- Mechanical calibres (Calibre 3235, 4131, 3285, 3255, 9002, 7140, Chronergy escapement, blue Parachrom hairspring, Paraflex shock absorbers, 70-hour power reserves, Superlative Chronometer certification -2/+2 sec/day).
- Proprietary metallurgy (Oystersteel 904L, 18 ct Everose gold, Yellow gold, White gold, 950 Platinum, Cerachrom ceramic, RLX Titanium).
- Historic milestones (Hans Wilsdorf 1905, Oyster case 1926, Perpetual rotor 1931, Sir Malcolm Campbell, Sir Edmund Hillary on Everest 1953, Mercedes Gleitze, Mariana Trench Deepsea Challenge).
- Proper heirloom care, service intervals (every 10 years), water resistance testing, and bespoke timepiece recommendations.

Provide concise, poetic yet technically precise guidance. Format with clean typography. Always maintain the dignity of the Crown.`;

export async function POST(req: NextRequest) {
  try {
    const { prompt, currentModel, userPreferences } = await req.json();

    if (!prompt) {
      return NextResponse.json({ error: 'Prompt is required' }, { status: 400 });
    }

    const contextPrompt = `
User question or request: "${prompt}"
${currentModel ? `Context: Currently viewing/configured model: ${currentModel}` : ''}
${userPreferences ? `User Preferences: ${JSON.stringify(userPreferences)}` : ''}

Please respond as the Rolex Horological Concierge.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: contextPrompt,
      config: {
        systemInstruction: HOROLOGY_SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });

    return NextResponse.json({
      text: response.text || 'It is our perpetual honor to assist you in your horological pursuit.',
    });
  } catch (error: any) {
    console.error('Concierge API error:', error);
    return NextResponse.json(
      {
        text: 'The Rolex Calibre 3235 represents the pinnacle of watchmaking technology, boasting our patented Chronergy escapement and a 70-hour power reserve with Superlative Chronometer precision (-2/+2 seconds per day). May we assist you in scheduling a private boutique viewing?',
      },
      { status: 200 }
    );
  }
}
