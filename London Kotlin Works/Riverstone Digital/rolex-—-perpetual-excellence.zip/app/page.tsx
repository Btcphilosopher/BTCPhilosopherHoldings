'use client';

import React, { useState } from 'react';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import PillarsSection from '@/components/PillarsSection';
import CollectionSection from '@/components/CollectionSection';
import WatchConfigurator from '@/components/WatchConfigurator';
import HeritageTimeline from '@/components/HeritageTimeline';
import BoutiqueGlobe from '@/components/BoutiqueGlobe';
import CalibreInspector from '@/components/CalibreInspector';
import HorologyConcierge from '@/components/HorologyConcierge';
import SavedWatchesModal from '@/components/SavedWatchesModal';
import Footer from '@/components/Footer';
import { FEATURED_MODELS } from '@/lib/horologyData';

export default function HomePage() {
  const [activeTab, setActiveTab] = useState('hero');
  const [currency, setCurrency] = useState<'CHF' | 'USD' | 'EUR'>('CHF');
  const [selectedModelId, setSelectedModelId] = useState('datejust-41');
  const [savedWatchIds, setSavedWatchIds] = useState<string[]>(['datejust-41']);
  const [savedCustomConfigs, setSavedCustomConfigs] = useState<any[]>([]);

  // Modals state
  const [isCalibreInspectorOpen, setIsCalibreInspectorOpen] = useState(false);
  const [isConciergeOpen, setIsConciergeOpen] = useState(false);
  const [isSavedModalOpen, setIsSavedModalOpen] = useState(false);
  const [appointmentPrefilled, setAppointmentPrefilled] = useState<string>('');

  const toggleSaveWatch = (id: string) => {
    setSavedWatchIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSaveCustomConfig = (config: any) => {
    setSavedCustomConfigs((prev) => [config, ...prev]);
  };

  const handleBookAppointment = (watchTitle: string) => {
    setAppointmentPrefilled(watchTitle);
    const element = document.getElementById('boutiques');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectModel = (id: string) => {
    setSelectedModelId(id);
    const element = document.getElementById('hero');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleConfigureWatch = (id: string) => {
    setSelectedModelId(id);
    const element = document.getElementById('configurator');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const currentModel =
    FEATURED_MODELS.find((m) => m.id === selectedModelId) || FEATURED_MODELS[0];

  return (
    <main className="min-h-screen bg-[#080B0F] text-[#F3F4F6] flex flex-col font-sans">
      {/* 1. TOP NAVIGATION BAR */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currency={currency}
        setCurrency={setCurrency}
        savedWatchIds={savedWatchIds}
        onOpenSavedModal={() => setIsSavedModalOpen(true)}
        onOpenConcierge={() => setIsConciergeOpen(true)}
        onSelectModel={handleSelectModel}
      />

      {/* 2. HERO SHOWCASE WITH DATEJUST 41 ALPS LAKE & LIVE SWISS MECHANICAL DIAL */}
      <Hero
        selectedModelId={selectedModelId}
        setSelectedModelId={setSelectedModelId}
        onExploreCollection={() => {
          const el = document.getElementById('watches');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
        onConfigureWatch={handleConfigureWatch}
        onOpenPrecisionLab={() => setIsCalibreInspectorOpen(true)}
      />

      {/* 3. 4-PILLAR REVOLUTION PORTALS (Precision, Manufacture, Crown, Presence) */}
      <PillarsSection
        onOpenPrecision={() => setIsCalibreInspectorOpen(true)}
        onOpenManufacture={() => {
          const el = document.getElementById('heritage');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
        onOpenCrownTrust={() => {
          const el = document.getElementById('watches');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
        onOpenBoutiques={() => {
          const el = document.getElementById('boutiques');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
      />

      {/* 4. THE COLLECTION SECTION */}
      <CollectionSection
        currency={currency}
        savedWatchIds={savedWatchIds}
        onToggleSaveWatch={toggleSaveWatch}
        onSelectModel={handleSelectModel}
        onConfigureWatch={handleConfigureWatch}
      />

      {/* 5. THE ATELIER BESPOKE CONFIGURATOR */}
      <WatchConfigurator
        initialModelId={selectedModelId}
        currency={currency}
        onBookAppointment={handleBookAppointment}
        onSaveConfig={handleSaveCustomConfig}
      />

      {/* 6. HERITAGE & CENTURY CHRONICLE */}
      <HeritageTimeline />

      {/* 7. WORLDWIDE BOUTIQUE NETWORK & APPOINTMENT SALON */}
      <BoutiqueGlobe prefilledWatch={appointmentPrefilled} />

      {/* 8. FOOTER */}
      <Footer />

      {/* INTERACTIVE MODALS */}
      <CalibreInspector
        isOpen={isCalibreInspectorOpen}
        onClose={() => setIsCalibreInspectorOpen(false)}
      />

      <HorologyConcierge
        isOpen={isConciergeOpen}
        onClose={() => setIsConciergeOpen(false)}
        currentModelName={currentModel.name}
      />

      <SavedWatchesModal
        isOpen={isSavedModalOpen}
        onClose={() => setIsSavedModalOpen(false)}
        savedWatchIds={savedWatchIds}
        savedCustomConfigs={savedCustomConfigs}
        currency={currency}
        onRemoveWatch={(id) => setSavedWatchIds((prev) => prev.filter((i) => i !== id))}
        onRemoveCustomConfig={(idx) =>
          setSavedCustomConfigs((prev) => prev.filter((_, i) => i !== idx))
        }
        onBookAppointment={handleBookAppointment}
      />
    </main>
  );
}
