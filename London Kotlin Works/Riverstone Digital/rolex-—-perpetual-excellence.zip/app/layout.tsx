import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'ROLEX — Perpetual Excellence',
  description: 'For over a century, Rolex has defined the art of time. Explore iconic Swiss horology, mechanical calibres, bespoke configurators, and boutique experiences.',
  openGraph: {
    title: 'ROLEX — Perpetual Excellence',
    description: 'For over a century, Rolex has defined the art of time. Explore iconic Swiss horology, mechanical calibres, bespoke configurators, and boutique experiences.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'ROLEX — Perpetual Excellence',
    description: 'For over a century, Rolex has defined the art of time. Explore iconic Swiss horology, mechanical calibres, bespoke configurators, and boutique experiences.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="dark bg-[#080B0F] text-[#F3F4F6] antialiased">
      <body suppressHydrationWarning className="min-h-screen bg-[#080B0F] selection:bg-[#C5A059]/30 selection:text-[#F3F4F6]">
        {children}
      </body>
    </html>
  );
}
