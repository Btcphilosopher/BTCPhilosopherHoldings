'use client';

import React, { useState } from 'react';
import { HERITAGE_MILESTONES, HeritageMilestone } from '@/lib/horologyData';

export default function HeritageTimeline() {
  const [selectedMilestone, setSelectedMilestone] = useState<HeritageMilestone>(
    HERITAGE_MILESTONES[0]
  );

  return (
    <section id="heritage" className="py-24 px-6 max-w-7xl mx-auto w-full space-y-12">
      {/* SECTION HEADER */}
      <div className="space-y-3 max-w-2xl">
        <div className="flex items-center gap-2 text-xs font-semibold tracking-[0.26em] uppercase text-[#E5C384]">
          <span className="w-5 h-[1px] bg-[#C5A059]" />
          <span>Heritage & Legacy</span>
        </div>
        <h2 className="font-cinzel text-3xl sm:text-4xl font-light text-[#F3F4F6]">
          A Century of Horological Innovation
        </h2>
        <p className="text-sm text-slate-400 font-light leading-relaxed">
          From the invention of the waterproof Oyster case to deep-sea expeditions and Everest
          conquests, explore the pioneering milestones that shaped modern watchmaking.
        </p>
      </div>

      {/* HORIZONTAL / VERTICAL CHRONICLE TIMELINE */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* MILESTONE YEARS SELECTOR */}
        <div className="lg:col-span-5 space-y-3">
          {HERITAGE_MILESTONES.map((m) => {
            const isCurrent = m.year === selectedMilestone.year;
            return (
              <div
                key={m.year}
                onClick={() => setSelectedMilestone(m)}
                className={`p-5 rounded-xl border cursor-pointer transition-all duration-300 ${
                  isCurrent
                    ? 'bg-[#121824] border-[#C5A059] shadow-lg shadow-[#C5A059]/5'
                    : 'bg-[#0B0F16] border-slate-800/80 hover:border-slate-700 hover:bg-[#0E131C]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span
                    className={`font-cinzel text-xl font-bold tracking-wider ${
                      isCurrent ? 'text-[#ECC880]' : 'text-slate-400'
                    }`}
                  >
                    {m.year}
                  </span>
                  <span className="w-2 h-2 rounded-full bg-[#C5A059] opacity-70" />
                </div>
                <h4 className="text-sm font-semibold text-slate-200 mt-1">{m.title}</h4>
                <p className="text-xs text-slate-400 font-light mt-0.5">{m.subtitle}</p>
              </div>
            );
          })}
        </div>

        {/* MILESTONE SPOTLIGHT EXHIBIT */}
        <div className="lg:col-span-7 bg-[#0B0F16] border border-[#C5A059]/30 rounded-2xl p-8 sm:p-10 space-y-6 relative overflow-hidden shadow-2xl">
          {/* Subtle Year Background Watermark */}
          <div className="flex items-center gap-3">
            <span className="font-cinzel text-5xl sm:text-6xl font-bold text-[#ECC880]/90">
              {selectedMilestone.year}
            </span>
            <span className="w-12 h-[1.5px] bg-[#C5A059]" />
          </div>

          <div className="space-y-2">
            <h3 className="font-cinzel text-2xl sm:text-3xl font-semibold text-[#F3F4F6]">
              {selectedMilestone.title}
            </h3>
            <div className="text-xs font-mono-num uppercase tracking-widest text-[#E5C384]">
              {selectedMilestone.subtitle}
            </div>
          </div>

          <p className="text-sm sm:text-base text-slate-300 font-light leading-relaxed">
            {selectedMilestone.narrative}
          </p>

          <div className="pt-6 border-t border-slate-800/80 grid grid-cols-2 gap-4 text-xs font-mono-num text-slate-400">
            <div>
              <span className="text-slate-500 block uppercase text-[10px]">Location</span>
              <span className="text-slate-200">Geneva & Bienne, Switzerland</span>
            </div>
            <div>
              <span className="text-slate-500 block uppercase text-[10px]">Perpetual Commitment</span>
              <span className="text-slate-200">Superlative Standard</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
