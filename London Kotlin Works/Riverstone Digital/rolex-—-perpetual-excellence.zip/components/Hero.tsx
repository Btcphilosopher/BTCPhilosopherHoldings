'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { ArrowRight, Moon, Sun, ShieldCheck } from 'lucide-react';
import WatchCanvas from './WatchCanvas';
import { FEATURED_MODELS } from '@/lib/horologyData';

interface HeroProps {
  selectedModelId: string;
  setSelectedModelId: (id: string) => void;
  onExploreCollection: () => void;
  onConfigureWatch: (id: string) => void;
  onOpenPrecisionLab: () => void;
}

export default function Hero({
  selectedModelId,
  setSelectedModelId,
  onExploreCollection,
  onConfigureWatch,
}: HeroProps) {
  const [isLumeMode, setIsLumeMode] = useState(false);
  const [powerReserve, setPowerReserve] = useState(90);

  const currentModelIndex = FEATURED_MODELS.findIndex((m) => m.id === selectedModelId);
  const activeModel = FEATURED_MODELS[currentModelIndex >= 0 ? currentModelIndex : 0];

  const handleNextModel = (index: number) => {
    if (index >= 0 && index < FEATURED_MODELS.length) {
      setSelectedModelId(FEATURED_MODELS[index].id);
    }
  };

  const handleWindWatch = () => {
    setPowerReserve((prev) => Math.min(100, prev + 10));
  };

  return (
    <section
      id="hero"
      className="relative min-h-[92vh] w-full flex flex-col justify-between overflow-hidden bg-[#070A0E] select-none"
    >
      {/* BACKGROUND ALPINE LAKE CINEMATIC PANORAMA */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        <Image
          src="/src/assets/images/hero_rolex_datejust_alps_1791012596637.jpg"
          alt="Rolex Perpetual Excellence Alpine Lake"
          fill
          priority
          sizes="100vw"
          className="object-cover object-center scale-105 transition-transform duration-1000 opacity-65"
          referrerPolicy="no-referrer"
        />
        {/* Soft Vignette and Scrim Gradients */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#080B0F] via-[#080B0F]/35 to-[#080B0F]/60" />
        <div className="absolute inset-0 bg-radial-glow opacity-80" />
      </div>

      {/* TOP CONTENT ZONE: TYPOGRAPHIC EDITORIAL STATEMENT */}
      <div className="relative z-10 max-w-7xl mx-auto w-full px-6 pt-12 md:pt-16 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* LEFT COLUMN: HERO HEADLINE & MANIFESTO */}
        <div className="lg:col-span-6 space-y-6">
          {/* Editorial Kicker */}
          <div className="flex items-center gap-2.5 text-[11px] font-semibold tracking-[0.3em] uppercase text-[#E5C384]">
            <span className="w-6 h-[1px] bg-[#C5A059]" />
            <span>A Crown for Every Generation</span>
          </div>

          {/* Master Headline in High-Craft Luxury Serif */}
          <h1 className="font-cinzel text-4xl sm:text-6xl xl:text-7xl font-light tracking-[0.06em] leading-[1.05] text-[#F3F4F6] text-wrap-balance">
            {activeModel.heroHeadline}
          </h1>

          {/* Subheading Narrative */}
          <p className="text-sm sm:text-base font-light tracking-[0.14em] uppercase leading-relaxed text-slate-300 max-w-lg">
            {activeModel.heroSubheading}
          </p>

          {/* Action Row */}
          <div className="pt-2 flex flex-wrap items-center gap-6">
            <button
              onClick={onExploreCollection}
              className="group flex items-center gap-3 text-xs font-semibold tracking-[0.24em] uppercase text-[#F3F4F6] hover:text-[#ECC880] transition-colors py-2"
            >
              <span>Explore The Collection</span>
              <ArrowRight className="w-4 h-4 text-[#C5A059] transition-transform group-hover:translate-x-1.5" />
            </button>

            <button
              onClick={() => onConfigureWatch(activeModel.id)}
              className="px-5 py-2.5 text-xs font-semibold tracking-[0.2em] uppercase rounded bg-[#C5A059]/15 hover:bg-[#C5A059]/25 text-[#ECC880] border border-[#C5A059]/40 hover:border-[#C5A059] transition-all backdrop-blur-md"
            >
              Configure Timepiece
            </button>
          </div>
        </div>

        {/* RIGHT COLUMN: QUICK TIMEPIECE SPECS CARD */}
        <div className="lg:col-span-6 flex justify-end">
          <div className="hidden md:flex flex-col items-end text-right space-y-3 p-5 rounded-lg bg-[#0B0F15]/60 backdrop-blur-md border border-[#C5A059]/15 max-w-xs">
            <div className="flex items-center gap-2 text-xs text-[#E5C384] font-medium uppercase tracking-wider">
              <ShieldCheck className="w-3.5 h-3.5 text-[#C5A059]" />
              <span>Superlative Chronometer</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Precision tested to -2/+2 sec/day after casing. 5-year international guarantee.
            </p>
            <div className="pt-2 flex items-center gap-3 text-[11px] font-mono-num text-slate-400 border-t border-slate-800/80 w-full justify-end">
              <span>{activeModel.material.split('(')[0]}</span>
              <span>·</span>
              <span>{activeModel.caseDiameter}</span>
            </div>
          </div>
        </div>
      </div>

      {/* CENTER FOCAL ANCHOR: INTERACTIVE SWISS MECHANICAL WATCH DIAL HOVERING OVER WATER */}
      <div className="relative z-20 my-auto py-6 flex flex-col items-center justify-center">
        {/* Lume Mode & Interactive Mode Controls */}
        <div className="mb-4 flex items-center gap-3 p-1 rounded-full bg-[#0B0F15]/80 backdrop-blur-md border border-[#C5A059]/20 shadow-xl">
          <button
            onClick={() => setIsLumeMode(false)}
            className={`flex items-center gap-1.5 px-3 py-1 text-[11px] font-medium tracking-wider rounded-full transition-all ${
              !isLumeMode
                ? 'bg-[#C5A059]/20 text-[#ECC880] border border-[#C5A059]/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sun className="w-3 h-3" />
            <span>Studio Daylight</span>
          </button>
          <button
            onClick={() => setIsLumeMode(true)}
            className={`flex items-center gap-1.5 px-3 py-1 text-[11px] font-medium tracking-wider rounded-full transition-all ${
              isLumeMode
                ? 'bg-[#00E5FF]/20 text-[#00E5FF] border border-[#00E5FF]/40 shadow-[0_0_15px_rgba(0,229,255,0.3)]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Moon className="w-3 h-3" />
            <span>Chromalight Lume</span>
          </button>
        </div>

        {/* Real-Time Mechanical Watch Canvas Engine */}
        <WatchCanvas
          modelId={activeModel.id}
          isLumeMode={isLumeMode}
          powerReservePercent={powerReserve}
          onCrownTurn={handleWindWatch}
          size={420}
        />
      </div>

      {/* BOTTOM CONTROL ZONE: SCROLL INDICATOR & MODEL SLIDER COUNTER */}
      <div className="relative z-10 max-w-7xl mx-auto w-full px-6 pb-8 flex items-end justify-between">
        {/* LEFT: SCROLL LUXURY ACCENT */}
        <div className="flex items-center gap-3">
          <div className="w-[1.5px] h-10 bg-gradient-to-b from-[#C5A059] to-transparent animate-pulse" />
          <span className="text-[11px] font-mono-num font-medium tracking-[0.28em] uppercase text-slate-400">
            Scroll
          </span>
        </div>

        {/* RIGHT: MODEL CAPTION & INDEX SWITCHER (01 —— 04) */}
        <div className="flex flex-col items-end text-right space-y-2">
          <div className="text-[11px] font-semibold tracking-[0.24em] uppercase text-[#E5C384]">
            {activeModel.name.toUpperCase()}
          </div>
          <div className="text-xs tracking-[0.18em] uppercase text-slate-400 font-light">
            {activeModel.tagline}
          </div>

          {/* Interactive Pagination Index (01 —— 04) */}
          <div className="pt-2 flex items-center gap-4 text-xs font-mono-num">
            {FEATURED_MODELS.map((model, idx) => {
              const isActive = model.id === activeModel.id;
              const numStr = `0${idx + 1}`;
              return (
                <button
                  key={model.id}
                  onClick={() => handleNextModel(idx)}
                  className={`flex items-center gap-2 group transition-all ${
                    isActive ? 'text-[#ECC880] font-bold' : 'text-slate-500 hover:text-slate-300'
                  }`}
                  title={`Switch to ${model.name}`}
                >
                  <span className="tracking-widest">{numStr}</span>
                  {isActive && <span className="w-6 h-[1.5px] bg-[#C5A059]" />}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
