'use client';

import React, { useEffect, useRef, useState } from 'react';
import { horologyAudio } from '@/lib/audioSynthesis';

interface WatchCanvasProps {
  modelId?: string;
  isLumeMode?: boolean;
  powerReservePercent?: number; // 0 - 100
  onCrownTurn?: () => void;
  interactive?: boolean;
  size?: number;
}

export default function WatchCanvas({
  modelId = 'datejust-41',
  isLumeMode = false,
  powerReservePercent = 85,
  onCrownTurn,
  interactive = true,
  size = 460,
}: WatchCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [mousePos, setMousePos] = useState({ x: 0.5, y: 0.5 });
  const [isWinding, setIsWinding] = useState(false);
  const animationFrameRef = useRef<number | null>(null);

  // Handle mouse / pointer interaction for 3D dial reflection & specular sweep
  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!interactive) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    setMousePos({ x, y });
  };

  const handleCrownClick = () => {
    setIsWinding(true);
    horologyAudio.playWindingClick();
    if (onCrownTurn) onCrownTurn();
    setTimeout(() => setIsWinding(false), 200);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let lastTickSecond = -1;

    const render = () => {
      const now = new Date();
      const ms = now.getMilliseconds();
      const seconds = now.getSeconds();
      const minutes = now.getMinutes();
      const hours = now.getHours() % 12;
      const dayOfMonth = now.getDate();

      // Mechanical 8-beat per second quantised sweep or smooth
      const subSecond = Math.floor(ms / (1000 / 8)) * (1 / 8);
      const totalSeconds = seconds + subSecond;
      const totalMinutes = minutes + totalSeconds / 60;
      const totalHours = hours + totalMinutes / 60;

      // Audio tick trigger at second changes if running
      const currentIntSec = seconds;
      if (currentIntSec !== lastTickSecond) {
        lastTickSecond = currentIntSec;
        horologyAudio.playTick();
      }

      const width = canvas.width;
      const height = canvas.height;
      const centerX = width / 2;
      const centerY = height / 2;
      const radius = Math.min(centerX, centerY) - 20;

      ctx.clearRect(0, 0, width, height);

      // Light reflection vector from mouse
      const lightAngle = Math.atan2(mousePos.y - 0.5, mousePos.x - 0.5);
      const lightDistance = Math.hypot(mousePos.x - 0.5, mousePos.y - 0.5);

      // 1. OUTER CASE (Oystersteel 904L polished steel rim)
      const caseGrad = ctx.createLinearGradient(
        centerX - radius,
        centerY - radius,
        centerX + radius,
        centerY + radius
      );
      if (modelId === 'day-date-40') {
        caseGrad.addColorStop(0, '#E5C27C');
        caseGrad.addColorStop(0.3, '#FFF2D1');
        caseGrad.addColorStop(0.7, '#A57E32');
        caseGrad.addColorStop(1, '#6F5116');
      } else {
        caseGrad.addColorStop(0, '#B8BCC4');
        caseGrad.addColorStop(0.2, '#EAECEF');
        caseGrad.addColorStop(0.5, '#7F8694');
        caseGrad.addColorStop(0.8, '#CBD0D8');
        caseGrad.addColorStop(1, '#565C68');
      }

      ctx.beginPath();
      ctx.arc(centerX, centerY, radius + 12, 0, Math.PI * 2);
      ctx.fillStyle = caseGrad;
      ctx.shadowColor = 'rgba(0, 0, 0, 0.7)';
      ctx.shadowBlur = 24;
      ctx.fill();
      ctx.shadowBlur = 0;

      // 2. FLUTED / CERACHROM BEZEL
      const bezelRadius = radius + 2;
      const innerBezelRadius = radius - 18;

      if (modelId === 'submariner-date' || modelId === 'cosmograph-daytona') {
        // Cerachrom Ceramic Bezel
        ctx.beginPath();
        ctx.arc(centerX, centerY, bezelRadius, 0, Math.PI * 2);
        ctx.fillStyle = '#0F1216';
        ctx.fill();

        // White platinum-coated graduations
        for (let i = 0; i < 60; i++) {
          const angle = (i * 6 - 90) * (Math.PI / 180);
          const isMajor = i % 5 === 0;
          const r1 = bezelRadius - 3;
          const r2 = isMajor ? innerBezelRadius + 4 : innerBezelRadius + 8;
          ctx.beginPath();
          ctx.moveTo(centerX + Math.cos(angle) * r1, centerY + Math.sin(angle) * r1);
          ctx.lineTo(centerX + Math.cos(angle) * r2, centerY + Math.sin(angle) * r2);
          ctx.strokeStyle = isMajor ? 'rgba(230, 235, 245, 0.9)' : 'rgba(200, 210, 220, 0.6)';
          ctx.lineWidth = isMajor ? 2.5 : 1.2;
          ctx.stroke();
        }
      } else {
        // Iconic Rolex 18 ct Fluted Bezel (facet geometry)
        const flutes = 72;
        ctx.beginPath();
        for (let i = 0; i < flutes; i++) {
          const angle1 = (i / flutes) * Math.PI * 2;
          const angle2 = ((i + 0.5) / flutes) * Math.PI * 2;
          const rOut = bezelRadius + Math.sin(i * 0.4 + lightAngle) * 1.5;
          const rIn = innerBezelRadius;

          const x1 = centerX + Math.cos(angle1) * rOut;
          const y1 = centerY + Math.sin(angle1) * rOut;
          const x2 = centerX + Math.cos(angle2) * rIn;
          const y2 = centerY + Math.sin(angle2) * rIn;

          ctx.moveTo(x1, y1);
          ctx.lineTo(x2, y2);
        }
        ctx.strokeStyle = modelId === 'day-date-40' ? 'rgba(235, 200, 120, 0.4)' : 'rgba(255, 255, 255, 0.35)';
        ctx.lineWidth = 2.5;
        ctx.stroke();
      }

      // 3. REHAUT (ROLEX ROLEX ROLEX engraved inner ring)
      ctx.beginPath();
      ctx.arc(centerX, centerY, innerBezelRadius, 0, Math.PI * 2);
      const rehautGrad = ctx.createRadialGradient(
        centerX,
        centerY,
        innerBezelRadius - 10,
        centerX,
        centerY,
        innerBezelRadius
      );
      rehautGrad.addColorStop(0, '#10141A');
      rehautGrad.addColorStop(1, '#252B35');
      ctx.fillStyle = rehautGrad;
      ctx.fill();

      // 4. DIAL FACE (Sunray brushed slate / intense black)
      const dialRadius = innerBezelRadius - 6;
      const dialGrad = ctx.createRadialGradient(
        centerX + Math.cos(lightAngle) * 30 * lightDistance,
        centerY + Math.sin(lightAngle) * 30 * lightDistance,
        5,
        centerX,
        centerY,
        dialRadius
      );

      if (isLumeMode) {
        dialGrad.addColorStop(0, '#04070A');
        dialGrad.addColorStop(1, '#020305');
      } else if (modelId === 'day-date-40') {
        dialGrad.addColorStop(0, '#E8CD8F');
        dialGrad.addColorStop(0.7, '#A57C32');
        dialGrad.addColorStop(1, '#563E14');
      } else if (modelId === 'cosmograph-daytona') {
        dialGrad.addColorStop(0, '#FFFFFF');
        dialGrad.addColorStop(0.8, '#F0F2F5');
        dialGrad.addColorStop(1, '#D8DDE4');
      } else {
        dialGrad.addColorStop(0, '#1E232B');
        dialGrad.addColorStop(0.6, '#12161D');
        dialGrad.addColorStop(1, '#090C10');
      }

      ctx.beginPath();
      ctx.arc(centerX, centerY, dialRadius, 0, Math.PI * 2);
      ctx.fillStyle = dialGrad;
      ctx.fill();

      // Sunray lines on dial
      if (!isLumeMode && modelId !== 'cosmograph-daytona') {
        ctx.save();
        ctx.translate(centerX, centerY);
        ctx.rotate(lightAngle * 0.1);
        for (let i = 0; i < 90; i++) {
          const a = (i / 90) * Math.PI * 2;
          const intensity = (Math.sin(a * 2 + lightAngle) + 1) * 0.5;
          ctx.beginPath();
          ctx.moveTo(0, 0);
          ctx.lineTo(Math.cos(a) * dialRadius, Math.sin(a) * dialRadius);
          ctx.strokeStyle = `rgba(210, 220, 240, ${intensity * 0.04})`;
          ctx.lineWidth = 1;
          ctx.stroke();
        }
        ctx.restore();
      }

      // 5. HOUR MARKERS & CHROMALIGHT LUME
      for (let i = 0; i < 12; i++) {
        if (i === 3 && (modelId === 'datejust-41' || modelId === 'submariner-date')) {
          // Skip marker 3 for Cyclops date aperture
          continue;
        }

        const angle = (i * 30 - 90) * (Math.PI / 180);
        const markerDist = dialRadius - 24;
        const mx = centerX + Math.cos(angle) * markerDist;
        const my = centerY + Math.sin(angle) * markerDist;

        ctx.save();
        ctx.translate(mx, my);
        ctx.rotate(angle + Math.PI / 2);

        if (i === 0) {
          // 12 o'clock ROLEX CORONET CROWN (at top)
          ctx.beginPath();
          ctx.arc(0, 0, 4, 0, Math.PI * 2);
          ctx.fillStyle = isLumeMode ? '#00E5FF' : (modelId === 'day-date-40' ? '#FFD700' : '#E6E8ED');
          if (isLumeMode) {
            ctx.shadowColor = '#00E5FF';
            ctx.shadowBlur = 12;
          }
          ctx.fill();
        } else {
          // 18 ct Gold Applique Batons
          const markerW = i % 3 === 0 ? 7 : 5;
          const markerH = 18;

          // Gold border
          ctx.fillStyle = modelId === 'day-date-40' ? '#D4AF37' : '#B0B5C0';
          ctx.fillRect(-markerW / 2, -markerH / 2, markerW, markerH);

          // Chromalight luminescent core
          ctx.fillStyle = isLumeMode ? '#00E5FF' : '#F4F6FA';
          if (isLumeMode) {
            ctx.shadowColor = '#00E5FF';
            ctx.shadowBlur = 14;
          }
          ctx.fillRect(-markerW / 2 + 1, -markerH / 2 + 1, markerW - 2, markerH - 2);
        }
        ctx.restore();
      }

      // 6. CYCLOPS DATE WINDOW (at 3 o'clock)
      if (modelId === 'datejust-41' || modelId === 'submariner-date') {
        const dateX = centerX + dialRadius - 38;
        const dateY = centerY;

        // Aperture background
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(dateX - 14, dateY - 10, 26, 20);

        // Date text
        ctx.font = 'bold 15px "JetBrains Mono", monospace';
        ctx.fillStyle = '#0B0D11';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(dayOfMonth.toString().padStart(2, '0'), dateX - 1, dateY + 1);

        // Cyclops magnifying lens bubble reflection
        if (!isLumeMode) {
          ctx.beginPath();
          ctx.ellipse(dateX - 1, dateY, 17, 13, 0, 0, Math.PI * 2);
          const cyclopsGrad = ctx.createLinearGradient(dateX - 17, dateY - 13, dateX + 17, dateY + 13);
          cyclopsGrad.addColorStop(0, 'rgba(255, 255, 255, 0.4)');
          cyclopsGrad.addColorStop(0.5, 'rgba(255, 255, 255, 0.05)');
          cyclopsGrad.addColorStop(1, 'rgba(255, 255, 255, 0.25)');
          ctx.fillStyle = cyclopsGrad;
          ctx.fill();
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
          ctx.lineWidth = 1;
          ctx.stroke();
        }
      }

      // 7. DIAL INSCRIPTIONS (ROLEX OYSTER PERPETUAL)
      if (!isLumeMode) {
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        // Coronet Crown icon at upper dial
        const crownY = centerY - dialRadius * 0.46;
        ctx.font = '16px "Cinzel", serif';
        ctx.fillStyle = modelId === 'day-date-40' ? '#FFDF78' : '#ECEFF4';
        ctx.fillText('♛', centerX, crownY);

        // ROLEX
        ctx.font = '700 17px "Cinzel", serif';
        ctx.letterSpacing = '4px';
        ctx.fillStyle = modelId === 'cosmograph-daytona' ? '#111317' : (modelId === 'day-date-40' ? '#FFF5D6' : '#F5F7FA');
        ctx.fillText('ROLEX', centerX, crownY + 16);

        // OYSTER PERPETUAL
        ctx.font = '500 8px "Plus Jakarta Sans", sans-serif';
        ctx.letterSpacing = '2px';
        ctx.fillStyle = modelId === 'cosmograph-daytona' ? '#4A5568' : 'rgba(230, 235, 245, 0.7)';
        ctx.fillText('OYSTER PERPETUAL', centerX, crownY + 28);
        ctx.fillText('DATEJUST', centerX, crownY + 37);

        // SUPERLATIVE CHRONOMETER OFFICIALLY CERTIFIED (at bottom)
        const certY = centerY + dialRadius * 0.42;
        ctx.font = '500 7.5px "Plus Jakarta Sans", sans-serif';
        ctx.letterSpacing = '1.5px';
        ctx.fillStyle = modelId === 'cosmograph-daytona' ? '#4A5568' : 'rgba(230, 235, 245, 0.65)';
        ctx.fillText('SUPERLATIVE CHRONOMETER', centerX, certY);
        ctx.fillText('OFFICIALLY CERTIFIED', centerX, certY + 10);

        // SWISS MADE (at 6 o'clock bottom)
        ctx.font = '500 6.5px "Plus Jakarta Sans", sans-serif';
        ctx.fillText('SWISS  ♛  MADE', centerX, centerY + dialRadius - 8);
      }

      // 8. HANDS (Hour, Minute, Seconds)
      const hourAngle = (totalHours * 30 - 90) * (Math.PI / 180);
      const minAngle = (totalMinutes * 6 - 90) * (Math.PI / 180);
      const secAngle = (totalSeconds * 6 - 90) * (Math.PI / 180);

      // HOUR HAND
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(hourAngle);
      ctx.beginPath();
      ctx.moveTo(-10, 0);
      ctx.lineTo(dialRadius * 0.52, 0);
      ctx.strokeStyle = isLumeMode ? '#00E5FF' : (modelId === 'day-date-40' ? '#E5C27C' : '#D0D5DD');
      ctx.lineWidth = 6;
      ctx.lineCap = 'round';
      if (isLumeMode) {
        ctx.shadowColor = '#00E5FF';
        ctx.shadowBlur = 12;
      }
      ctx.stroke();
      ctx.restore();

      // MINUTE HAND
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(minAngle);
      ctx.beginPath();
      ctx.moveTo(-12, 0);
      ctx.lineTo(dialRadius * 0.78, 0);
      ctx.strokeStyle = isLumeMode ? '#00E5FF' : (modelId === 'day-date-40' ? '#E5C27C' : '#E2E6EC');
      ctx.lineWidth = 4.5;
      ctx.lineCap = 'round';
      if (isLumeMode) {
        ctx.shadowColor = '#00E5FF';
        ctx.shadowBlur = 12;
      }
      ctx.stroke();
      ctx.restore();

      // SECONDS HAND (Fine needle with counterweight and luminous circle)
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(secAngle);
      ctx.beginPath();
      ctx.moveTo(-dialRadius * 0.22, 0);
      ctx.lineTo(dialRadius * 0.88, 0);
      ctx.strokeStyle = isLumeMode ? '#00E5FF' : (modelId === 'day-date-40' ? '#FFD700' : '#E5C384');
      ctx.lineWidth = 1.6;
      ctx.stroke();

      // Lume pip on seconds hand
      ctx.beginPath();
      ctx.arc(dialRadius * 0.58, 0, 3.5, 0, Math.PI * 2);
      ctx.fillStyle = isLumeMode ? '#00E5FF' : '#FFFFFF';
      if (isLumeMode) {
        ctx.shadowColor = '#00E5FF';
        ctx.shadowBlur = 10;
      }
      ctx.fill();
      ctx.strokeStyle = modelId === 'day-date-40' ? '#C5A059' : '#8A919F';
      ctx.lineWidth = 1;
      ctx.stroke();

      // Center Pinion Cap
      ctx.beginPath();
      ctx.arc(0, 0, 5, 0, Math.PI * 2);
      ctx.fillStyle = modelId === 'day-date-40' ? '#D4AF37' : '#E8EBEE';
      ctx.fill();
      ctx.restore();

      // 9. SAPPHIRE GLASS CURVATURE & SPECULAR SHEEN
      if (!isLumeMode) {
        ctx.save();
        const glassGrad = ctx.createLinearGradient(
          centerX - radius * Math.cos(lightAngle),
          centerY - radius * Math.sin(lightAngle),
          centerX + radius * Math.cos(lightAngle),
          centerY + radius * Math.sin(lightAngle)
        );
        glassGrad.addColorStop(0, 'rgba(255, 255, 255, 0.16)');
        glassGrad.addColorStop(0.3, 'rgba(255, 255, 255, 0.03)');
        glassGrad.addColorStop(0.5, 'transparent');
        glassGrad.addColorStop(0.8, 'rgba(255, 255, 255, 0.08)');
        glassGrad.addColorStop(1, 'rgba(255, 255, 255, 0.18)');

        ctx.beginPath();
        ctx.arc(centerX, centerY, dialRadius + 2, 0, Math.PI * 2);
        ctx.fillStyle = glassGrad;
        ctx.fill();
        ctx.restore();
      }

      animationFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [modelId, isLumeMode, mousePos, interactive]);

  return (
    <div className="relative inline-flex flex-col items-center justify-center select-none group">
      {/* 3D Watch Dial Canvas */}
      <canvas
        ref={canvasRef}
        width={size}
        height={size}
        onPointerMove={handlePointerMove}
        className="cursor-crosshair transition-transform duration-500 hover:scale-[1.02] drop-shadow-[0_25px_35px_rgba(0,0,0,0.85)]"
        title="Interactive Swiss Mechanical Movement — Move mouse to inspect sapphire reflection"
      />

      {/* Interactive Crown Button */}
      {interactive && (
        <button
          onClick={handleCrownClick}
          className={`absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1.5 px-2.5 py-1 text-[11px] tracking-wider uppercase font-mono-num rounded bg-[#131922]/90 hover:bg-[#1C2532] border border-[#C5A059]/40 text-[#E5C384] transition-all shadow-lg backdrop-blur-md ${
            isWinding ? 'scale-95 border-[#C5A059]' : ''
          }`}
          title="Wind Crown — Charges the 70-Hour Power Reserve"
        >
          <span className="w-2 h-2 rounded-full bg-[#C5A059] animate-pulse" />
          <span>{isWinding ? 'Winding...' : 'Wind Crown'}</span>
        </button>
      )}

      {/* Chromalight luminescence / Swiss Calibre indicator */}
      <div className="mt-3 flex items-center gap-4 text-xs font-mono-num text-slate-400">
        <div className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
          <span>28,800 vph (4 Hz)</span>
        </div>
        <span className="text-slate-600">·</span>
        <div className="flex items-center gap-1.5">
          <span className="text-slate-300">Reserve</span>
          <span className="text-[#C5A059] font-medium">{powerReservePercent}%</span>
        </div>
        <span className="text-slate-600">·</span>
        <div className="flex items-center gap-1.5">
          <span className="text-slate-400">Superlative ±2s/d</span>
        </div>
      </div>
    </div>
  );
}
