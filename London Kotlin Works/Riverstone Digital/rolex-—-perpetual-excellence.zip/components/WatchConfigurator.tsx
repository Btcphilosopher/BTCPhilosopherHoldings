'use client';

import React, { useState } from 'react';
import { Sliders, Sparkles, Check, Bookmark, Calendar, ArrowRight } from 'lucide-react';
import { FEATURED_MODELS, WatchModel } from '@/lib/horologyData';
import { horologyAudio } from '@/lib/audioSynthesis';

interface WatchConfiguratorProps {
  initialModelId?: string;
  currency: 'CHF' | 'USD' | 'EUR';
  onBookAppointment: (configSummary: string) => void;
  onSaveConfig: (config: any) => void;
}

export default function WatchConfigurator({
  initialModelId = 'datejust-41',
  currency,
  onBookAppointment,
  onSaveConfig,
}: WatchConfiguratorProps) {
  const [selectedBaseId, setSelectedBaseId] = useState(initialModelId);
  const [selectedMetal, setSelectedMetal] = useState('Oystersteel');
  const [selectedBezel, setSelectedBezel] = useState('Fluted');
  const [selectedDialColor, setSelectedDialColor] = useState('Bright Black');
  const [selectedBracelet, setSelectedBracelet] = useState('Jubilee');
  const [engravingText, setEngravingText] = useState('');
  const [isSavedToast, setIsSavedToast] = useState(false);

  const baseWatch =
    FEATURED_MODELS.find((m) => m.id === selectedBaseId) || FEATURED_MODELS[0];

  const metals = [
    { id: 'Oystersteel', name: 'Oystersteel (904L)', priceAdd: 0, color: '#B0B5C0' },
    { id: 'White Rolesor', name: 'White Rolesor (Steel & 18 ct White Gold)', priceAdd: 1200, color: '#D8DDE6' },
    { id: 'Everose Gold', name: '18 ct Everose Gold', priceAdd: 18500, color: '#E8A598' },
    { id: 'Yellow Gold', name: '18 ct Yellow Gold', priceAdd: 16800, color: '#E5C27C' },
    { id: 'Platinum', name: '950 Platinum', priceAdd: 28000, color: '#EAEFF5' },
  ];

  const bezels = [
    { id: 'Fluted', name: 'Rolex Fluted Bezel', priceAdd: 800 },
    { id: 'Smooth', name: 'Smooth Polished Bezel', priceAdd: 0 },
    { id: 'Cerachrom', name: 'Cerachrom Ceramic Graduated', priceAdd: 600 },
  ];

  const dialColors = [
    { id: 'Bright Black', name: 'Bright Black Sunray', hex: '#11141A' },
    { id: 'Mint Green', name: 'Mint Green Sunray', hex: '#1C3A2B' },
    { id: 'Azzurro Blue', name: 'Azzurro Blue Radial', hex: '#162C46' },
    { id: 'Champagne', name: 'Champagne Sunray Gold', hex: '#8C733B' },
    { id: 'Slate Wimbledon', name: 'Slate with Green Roman Numerals', hex: '#2A2E35' },
  ];

  const bracelets = [
    { id: 'Jubilee', name: 'Jubilee, five-piece links', desc: 'Supple and comfortable' },
    { id: 'Oyster', name: 'Oyster, flat three-piece links', desc: 'Robust and sporty' },
    { id: 'President', name: 'President, semi-circular links', desc: 'Exclusive luxury' },
  ];

  // Dynamic price calculation
  const metalAdd = metals.find((m) => m.id === selectedMetal)?.priceAdd || 0;
  const bezelAdd = bezels.find((b) => b.id === selectedBezel)?.priceAdd || 0;
  const totalPrice = baseWatch[`price${currency}`] + metalAdd + bezelAdd;

  const generatedRef = `${baseWatch.reference.slice(0, 5)}${
    selectedMetal === 'Yellow Gold' ? '8' : selectedMetal === 'Everose Gold' ? '5' : '4'
  }-${selectedDialColor.slice(0, 3).toUpperCase()}`;

  const handleSave = () => {
    horologyAudio.playChime();
    onSaveConfig({
      model: baseWatch.name,
      metal: selectedMetal,
      bezel: selectedBezel,
      dial: selectedDialColor,
      bracelet: selectedBracelet,
      engraving: engravingText,
      price: `${currency} ${totalPrice.toLocaleString()}`,
      reference: generatedRef,
    });
    setIsSavedToast(true);
    setTimeout(() => setIsSavedToast(false), 2500);
  };

  const handleBook = () => {
    const summary = `${baseWatch.name} (${selectedMetal}, ${selectedBezel} Bezel, ${selectedDialColor} Dial, ${selectedBracelet} Bracelet) - Ref: ${generatedRef}`;
    onBookAppointment(summary);
  };

  return (
    <section id="configurator" className="py-24 px-6 max-w-7xl mx-auto w-full space-y-12">
      {/* SECTION HEADER */}
      <div className="space-y-3 max-w-2xl">
        <div className="flex items-center gap-2 text-xs font-semibold tracking-[0.26em] uppercase text-[#E5C384]">
          <span className="w-5 h-[1px] bg-[#C5A059]" />
          <span>The Atelier</span>
        </div>
        <h2 className="font-cinzel text-3xl sm:text-4xl font-light text-[#F3F4F6]">
          Bespoke Horological Configurator
        </h2>
        <p className="text-sm text-slate-400 font-light leading-relaxed">
          Craft your personal signature piece. Select noble metallurgy, dial executions, fluting,
          and custom case back engraving.
        </p>
      </div>

      {/* CONFIGURATOR WORKSPACE */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* LEFT COLUMN: VISUAL ATELIER PREVIEW */}
        <div className="lg:col-span-6 bg-[#0B0F16] border border-[#C5A059]/25 rounded-2xl p-8 flex flex-col items-center justify-between sticky top-28 space-y-8 shadow-2xl">
          <div className="w-full flex items-center justify-between">
            <span className="text-xs font-mono-num uppercase tracking-wider text-[#ECC880]">
              Configuration Ref: {generatedRef}
            </span>
            <span className="text-xs font-mono-num text-slate-400">
              {baseWatch.caseDiameter} · {baseWatch.calibre.split(',')[0]}
            </span>
          </div>

          {/* WATCH CUSTOM ATELIER RENDER */}
          <div className="relative py-12 flex flex-col items-center justify-center">
            {/* Ambient Dial Aura */}
            <div
              className="absolute w-64 h-64 rounded-full blur-3xl opacity-30 pointer-events-none transition-all duration-700"
              style={{
                backgroundColor:
                  dialColors.find((d) => d.id === selectedDialColor)?.hex || '#11141A',
              }}
            />

            {/* Simulated Custom Dial */}
            <div
              className="relative w-56 h-56 rounded-full border-4 shadow-2xl flex items-center justify-center p-3 transition-all duration-500"
              style={{
                borderColor: metals.find((m) => m.id === selectedMetal)?.color || '#B0B5C0',
                backgroundColor: '#090C10',
              }}
            >
              <div
                className="w-full h-full rounded-full border-2 border-white/10 flex flex-col items-center justify-center text-center p-4 relative overflow-hidden transition-all duration-500"
                style={{
                  backgroundColor:
                    dialColors.find((d) => d.id === selectedDialColor)?.hex || '#11141A',
                }}
              >
                {/* Coronet */}
                <span className="text-[#C5A059] text-xl mb-1">♛</span>
                <span className="font-cinzel text-sm font-bold tracking-[0.2em] text-[#F3F4F6]">
                  ROLEX
                </span>
                <span className="text-[9px] font-mono-num uppercase tracking-wider text-slate-300 mt-0.5">
                  {selectedBracelet} · {selectedBezel}
                </span>

                {engravingText && (
                  <div className="mt-3 px-2 py-0.5 rounded bg-black/50 border border-[#C5A059]/30 text-[9px] font-mono-num text-[#ECC880] tracking-widest uppercase">
                    Engraving: &ldquo;{engravingText}&rdquo;
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* BOTTOM SUMMARY STATS */}
          <div className="w-full pt-6 border-t border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono-num uppercase text-slate-500 block">
                Estimated Price ({currency})
              </span>
              <span className="text-xl font-mono-num font-bold text-[#ECC880]">
                {currency} {totalPrice.toLocaleString()}
              </span>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={handleSave}
                className="p-2.5 rounded-lg border border-[#C5A059]/40 bg-[#C5A059]/10 text-[#ECC880] hover:bg-[#C5A059]/20 transition-all"
                title="Save Configuration"
              >
                <Bookmark className="w-4 h-4" />
              </button>
              <button
                onClick={handleBook}
                className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#C5A059] hover:bg-[#D4AF37] text-[#080B0F] font-semibold text-xs uppercase tracking-wider transition-all shadow-lg"
              >
                <Calendar className="w-4 h-4" />
                <span>Book Boutique Viewing</span>
              </button>
            </div>
          </div>

          {isSavedToast && (
            <div className="text-xs font-mono-num text-emerald-400 bg-emerald-950/80 border border-emerald-500/40 px-3 py-1.5 rounded-full animate-in fade-in">
              ✓ Specification Saved to Personal Horology Briefcase
            </div>
          )}
        </div>

        {/* RIGHT COLUMN: CONFIGURATION CONTROLS */}
        <div className="lg:col-span-6 space-y-8 bg-[#0E131C] border border-slate-800 rounded-2xl p-6 sm:p-8">
          {/* 1. BASE TIMEPIECE MODEL */}
          <div className="space-y-3">
            <label className="text-xs font-mono-num uppercase tracking-wider text-slate-400 block">
              1. Base Model Family
            </label>
            <div className="grid grid-cols-2 gap-2">
              {FEATURED_MODELS.map((m) => (
                <button
                  key={m.id}
                  onClick={() => setSelectedBaseId(m.id)}
                  className={`p-3 rounded-lg text-left border transition-all ${
                    selectedBaseId === m.id
                      ? 'bg-[#182230] border-[#C5A059] text-white'
                      : 'bg-[#121722] border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span className="text-xs font-semibold block">{m.name}</span>
                  <span className="text-[10px] font-mono-num text-slate-500">{m.caseDiameter}</span>
                </button>
              ))}
            </div>
          </div>

          {/* 2. NOBLE MATERIAL & METALLURGY */}
          <div className="space-y-3">
            <label className="text-xs font-mono-num uppercase tracking-wider text-slate-400 block">
              2. Case Material & Metallurgy
            </label>
            <div className="space-y-2">
              {metals.map((metal) => (
                <button
                  key={metal.id}
                  onClick={() => {
                    setSelectedMetal(metal.id);
                    horologyAudio.playBezelClick();
                  }}
                  className={`w-full p-3 rounded-lg flex items-center justify-between border transition-all text-xs font-mono-num ${
                    selectedMetal === metal.id
                      ? 'bg-[#182230] border-[#C5A059] text-white font-medium'
                      : 'bg-[#121722] border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span
                      className="w-3.5 h-3.5 rounded-full border border-white/20"
                      style={{ backgroundColor: metal.color }}
                    />
                    <span>{metal.name}</span>
                  </div>
                  <span className="text-[#ECC880]">
                    {metal.priceAdd > 0 ? `+${currency} ${metal.priceAdd.toLocaleString()}` : 'Included'}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* 3. BEZEL STYLE */}
          <div className="space-y-3">
            <label className="text-xs font-mono-num uppercase tracking-wider text-slate-400 block">
              3. Bezel Architecture
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {bezels.map((b) => (
                <button
                  key={b.id}
                  onClick={() => {
                    setSelectedBezel(b.id);
                    horologyAudio.playBezelClick();
                  }}
                  className={`p-3 rounded-lg text-center border transition-all text-xs ${
                    selectedBezel === b.id
                      ? 'bg-[#182230] border-[#C5A059] text-[#ECC880] font-semibold'
                      : 'bg-[#121722] border-slate-800 text-slate-300 hover:text-white'
                  }`}
                >
                  <div>{b.name}</div>
                </button>
              ))}
            </div>
          </div>

          {/* 4. DIAL COLOR & EXECUTION */}
          <div className="space-y-3">
            <label className="text-xs font-mono-num uppercase tracking-wider text-slate-400 block">
              4. Dial Color & Finish
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {dialColors.map((dial) => (
                <button
                  key={dial.id}
                  onClick={() => setSelectedDialColor(dial.id)}
                  className={`p-3 rounded-lg flex items-center gap-3 border transition-all text-xs ${
                    selectedDialColor === dial.id
                      ? 'bg-[#182230] border-[#C5A059] text-white font-medium'
                      : 'bg-[#121722] border-slate-800 text-slate-300 hover:text-white'
                  }`}
                >
                  <span
                    className="w-4 h-4 rounded-full border border-white/30 shrink-0"
                    style={{ backgroundColor: dial.hex }}
                  />
                  <span className="truncate">{dial.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* 5. BRACELET SELECTION */}
          <div className="space-y-3">
            <label className="text-xs font-mono-num uppercase tracking-wider text-slate-400 block">
              5. Bracelet & Clasp System
            </label>
            <div className="space-y-2">
              {bracelets.map((br) => (
                <button
                  key={br.id}
                  onClick={() => setSelectedBracelet(br.id)}
                  className={`w-full p-3 rounded-lg flex items-center justify-between border transition-all text-xs ${
                    selectedBracelet === br.id
                      ? 'bg-[#182230] border-[#C5A059] text-white font-medium'
                      : 'bg-[#121722] border-slate-800 text-slate-300 hover:text-white'
                  }`}
                >
                  <div>
                    <span className="font-semibold block">{br.name}</span>
                    <span className="text-[10px] text-slate-500">{br.desc}</span>
                  </div>
                  {selectedBracelet === br.id && <Check className="w-4 h-4 text-[#C5A059]" />}
                </button>
              ))}
            </div>
          </div>

          {/* 6. PERSONALIZED CASEBACK ENGRAVING */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <label className="text-xs font-mono-num uppercase tracking-wider text-slate-400 block">
              6. Case Back Heirloom Engraving (Optional)
            </label>
            <input
              type="text"
              maxLength={24}
              value={engravingText}
              onChange={(e) => setEngravingText(e.target.value.toUpperCase())}
              placeholder="e.g. H. WILSDORF 1905"
              className="w-full px-4 py-2.5 rounded-lg bg-[#121722] border border-slate-800 focus:border-[#C5A059] text-xs font-mono-num text-slate-100 placeholder:text-slate-600 focus:outline-none uppercase"
            />
            <span className="text-[10px] text-slate-500 font-mono-num">
              Hand-engraved by Rolex master artisans at the Geneva manufacture.
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
