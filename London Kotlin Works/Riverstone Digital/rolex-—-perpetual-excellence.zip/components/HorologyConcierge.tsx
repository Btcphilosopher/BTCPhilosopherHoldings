'use client';

import React, { useState } from 'react';
import { Sparkles, Send, Bot, User, X, Loader2, Award } from 'lucide-react';
import { horologyAudio } from '@/lib/audioSynthesis';

interface HorologyConciergeProps {
  isOpen: boolean;
  onClose: () => void;
  currentModelName?: string;
}

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export default function HorologyConcierge({
  isOpen,
  onClose,
  currentModelName,
}: HorologyConciergeProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content:
        'Greetings. I am the Rolex Horological Master & Private Concierge. Whether you seek counsel on mechanical calibre architecture, bespoke reference matching, or the legacy of our Geneva manufacture, I am at your service.',
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const samplePrompts = [
    'What makes the Chronergy escapement and Parachrom hairspring so precise?',
    'Recommend a timeless timepiece for transatlantic travel and formal galas.',
    'Explain the superior corrosion resistance of Oystersteel 904L vs 316L.',
    'What are the official servicing intervals for Superlative Chronometers?',
  ];

  const handleSend = async (queryText?: string) => {
    const promptToSend = queryText || input;
    if (!promptToSend.trim() || loading) return;

    const newMessages: Message[] = [...messages, { role: 'user', content: promptToSend }];
    setMessages(newMessages);
    if (!queryText) setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/concierge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: promptToSend,
          currentModel: currentModelName,
        }),
      });

      const data = await res.json();
      setMessages([...newMessages, { role: 'assistant', content: data.text }]);
      horologyAudio.playTick();
    } catch {
      setMessages([
        ...newMessages,
        {
          role: 'assistant',
          content:
            'The Calibre 3235 features our patented Chronergy escapement and blue Parachrom hairspring, ensuring extreme precision within -2/+2 seconds daily and a 70-hour power reserve.',
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 select-none">
      <div className="relative w-full max-w-2xl h-[650px] max-h-[90vh] bg-[#0A0D14] border border-[#C5A059]/40 rounded-2xl shadow-2xl flex flex-col justify-between overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* MODAL HEADER */}
        <div className="p-5 bg-[#0E131C] border-b border-[#C5A059]/20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-[#C5A059]/15 border border-[#C5A059]/40 flex items-center justify-center text-[#ECC880]">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-cinzel text-base font-semibold text-[#F3F4F6]">
                Rolex Horological Concierge
              </h3>
              <p className="text-[10px] font-mono-num uppercase tracking-wider text-[#E5C384]">
                Direct Advisory · Geneva Manufacture
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* CONVERSATION STREAM */}
        <div className="flex-1 p-5 overflow-y-auto custom-scrollbar space-y-4">
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex items-start gap-3 ${
                msg.role === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              {msg.role === 'assistant' && (
                <div className="w-7 h-7 rounded-full bg-[#182130] border border-[#C5A059]/30 flex items-center justify-center shrink-0 text-[#C5A059] text-xs">
                  ♛
                </div>
              )}
              <div
                className={`max-w-[80%] p-4 rounded-xl text-xs sm:text-sm leading-relaxed ${
                  msg.role === 'user'
                    ? 'bg-[#C5A059] text-[#080B0F] font-medium rounded-tr-none'
                    : 'bg-[#121722] border border-slate-800 text-slate-200 rounded-tl-none font-light'
                }`}
              >
                {msg.content}
              </div>
              {msg.role === 'user' && (
                <div className="w-7 h-7 rounded-full bg-slate-800 flex items-center justify-center shrink-0 text-slate-300 text-xs">
                  <User className="w-3.5 h-3.5" />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-3">
              <div className="w-7 h-7 rounded-full bg-[#182130] border border-[#C5A059]/30 flex items-center justify-center text-[#C5A059] text-xs">
                ♛
              </div>
              <div className="p-3.5 rounded-xl bg-[#121722] border border-slate-800 text-xs text-slate-400 flex items-center gap-2">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-[#C5A059]" />
                <span>Consulting Geneva Horological Archives...</span>
              </div>
            </div>
          )}
        </div>

        {/* SUGGESTED PROMPTS */}
        <div className="px-5 py-2 bg-[#0C1017] border-t border-slate-800/80 flex gap-2 overflow-x-auto custom-scrollbar">
          {samplePrompts.map((sp, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(sp)}
              className="text-[11px] whitespace-nowrap px-3 py-1 rounded bg-[#141A24] hover:bg-[#1D2635] text-slate-300 hover:text-[#ECC880] border border-slate-800 transition-colors"
            >
              {sp}
            </button>
          ))}
        </div>

        {/* INPUT BAR */}
        <div className="p-4 bg-[#0E131C] border-t border-slate-800 flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSend();
            }}
            placeholder="Ask about calibres, metallurgy, historical milestones, or bespoke advice..."
            className="flex-1 px-4 py-2.5 rounded-lg bg-[#141A24] border border-slate-800 text-xs text-slate-100 placeholder:text-slate-500 focus:border-[#C5A059] focus:outline-none"
          />
          <button
            onClick={() => handleSend()}
            disabled={loading || !input.trim()}
            className="p-2.5 rounded-lg bg-[#C5A059] hover:bg-[#D4AF37] text-[#080B0F] disabled:opacity-40 transition-all"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
