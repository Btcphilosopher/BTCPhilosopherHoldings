'use client';

import React from 'react';
import { X, Trash2, ArrowRight, Calendar, BookmarkCheck } from 'lucide-react';
import { FEATURED_MODELS, WatchModel } from '@/lib/horologyData';

interface SavedWatchesModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedWatchIds: string[];
  savedCustomConfigs: any[];
  currency: 'CHF' | 'USD' | 'EUR';
  onRemoveWatch: (id: string) => void;
  onRemoveCustomConfig: (index: number) => void;
  onBookAppointment: (title: string) => void;
}

export default function SavedWatchesModal({
  isOpen,
  onClose,
  savedWatchIds,
  savedCustomConfigs,
  currency,
  onRemoveWatch,
  onRemoveCustomConfig,
  onBookAppointment,
}: SavedWatchesModalProps) {
  if (!isOpen) return null;

  const savedWatches = FEATURED_MODELS.filter((m) => savedWatchIds.includes(m.id));

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 select-none">
      <div className="relative w-full max-w-3xl max-h-[85vh] bg-[#0C1017] border border-[#C5A059]/30 rounded-2xl shadow-2xl flex flex-col justify-between overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* HEADER */}
        <div className="p-6 bg-[#0E141E] border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BookmarkCheck className="w-5 h-5 text-[#C5A059]" />
            <div>
              <h3 className="font-cinzel text-lg font-semibold text-[#F3F4F6]">
                Personal Horology Briefcase
              </h3>
              <p className="text-xs font-mono-num text-[#E5C384]">
                Saved References & Bespoke Configurations ({savedWatches.length + savedCustomConfigs.length})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* CONTENT LIST */}
        <div className="flex-1 p-6 overflow-y-auto custom-scrollbar space-y-6">
          {/* STANDARD CATALOG PIECES */}
          {savedWatches.length > 0 && (
            <div className="space-y-3">
              <span className="text-xs font-mono-num uppercase tracking-widest text-slate-400 block">
                Catalog Selections
              </span>
              <div className="space-y-3">
                {savedWatches.map((watch) => (
                  <div
                    key={watch.id}
                    className="p-4 rounded-xl bg-[#121822] border border-slate-800 flex items-center justify-between gap-4"
                  >
                    <div>
                      <h4 className="text-sm font-semibold text-white">{watch.name}</h4>
                      <p className="text-xs font-mono-num text-slate-400">
                        Ref: {watch.reference} · {watch.material}
                      </p>
                      <div className="text-xs font-mono-num text-[#ECC880] mt-1">
                        {currency} {watch[`price${currency}`].toLocaleString()}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          onBookAppointment(watch.name);
                          onClose();
                        }}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#C5A059]/20 hover:bg-[#C5A059] text-[#ECC880] hover:text-[#080B0F] text-xs font-semibold uppercase tracking-wider transition-all"
                      >
                        <Calendar className="w-3.5 h-3.5" />
                        <span>Book</span>
                      </button>
                      <button
                        onClick={() => onRemoveWatch(watch.id)}
                        className="p-2 text-slate-400 hover:text-red-400"
                        title="Remove"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* BESPOKE ATELIER CONFIGURATIONS */}
          {savedCustomConfigs.length > 0 && (
            <div className="space-y-3">
              <span className="text-xs font-mono-num uppercase tracking-widest text-[#E5C384] block">
                Bespoke Atelier Configurations
              </span>
              <div className="space-y-3">
                {savedCustomConfigs.map((cfg, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-xl bg-[#151C28] border border-[#C5A059]/30 flex items-center justify-between gap-4"
                  >
                    <div>
                      <h4 className="text-sm font-semibold text-white">{cfg.model}</h4>
                      <p className="text-xs font-mono-num text-slate-300">
                        {cfg.metal} · {cfg.bezel} Bezel · {cfg.dial} Dial · {cfg.bracelet}
                      </p>
                      {cfg.engraving && (
                        <div className="text-[11px] font-mono-num text-[#ECC880]">
                          Engraved: &ldquo;{cfg.engraving}&rdquo;
                        </div>
                      )}
                      <div className="text-xs font-mono-num text-[#ECC880] mt-1 font-bold">
                        {cfg.price} (Ref: {cfg.reference})
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          onBookAppointment(`${cfg.model} (${cfg.metal}, ${cfg.dial})`);
                          onClose();
                        }}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#C5A059] text-[#080B0F] hover:bg-[#D4AF37] text-xs font-semibold uppercase tracking-wider transition-all"
                      >
                        <Calendar className="w-3.5 h-3.5" />
                        <span>Book</span>
                      </button>
                      <button
                        onClick={() => onRemoveCustomConfig(idx)}
                        className="p-2 text-slate-400 hover:text-red-400"
                        title="Remove"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {savedWatches.length === 0 && savedCustomConfigs.length === 0 && (
            <div className="text-center py-16 space-y-3">
              <span className="text-4xl text-slate-600 block">♛</span>
              <h4 className="text-base font-cinzel text-slate-300">Your briefcase is empty</h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Explore our collection or craft a bespoke timepiece in the Atelier to save
                references here for your private salon appointment.
              </p>
            </div>
          )}
        </div>

        {/* FOOTER */}
        <div className="p-4 bg-[#0E141E] border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs uppercase tracking-wider font-semibold"
          >
            Close Briefcase
          </button>
        </div>
      </div>
    </div>
  );
}
