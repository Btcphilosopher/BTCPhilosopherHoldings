'use client';

import React, { useEffect, useRef, useState } from 'react';
import { MapPin, Phone, Clock, Calendar, Check, Globe } from 'lucide-react';
import { BOUTIQUES, BoutiqueLocation } from '@/lib/horologyData';
import { horologyAudio } from '@/lib/audioSynthesis';

interface BoutiqueGlobeProps {
  prefilledWatch?: string;
}

export default function BoutiqueGlobe({ prefilledWatch }: BoutiqueGlobeProps) {
  const [selectedBoutique, setSelectedBoutique] = useState<BoutiqueLocation>(BOUTIQUES[0]);
  const [bookingName, setBookingName] = useState('');
  const [bookingEmail, setBookingEmail] = useState('');
  const [bookingDate, setBookingDate] = useState('');
  const [bookingTime, setBookingTime] = useState('14:00');
  const [isBooked, setIsBooked] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Live local times ticker
  const [currentTimes, setCurrentTimes] = useState<Record<string, string>>({});

  useEffect(() => {
    const updateTimes = () => {
      const times: Record<string, string> = {};
      BOUTIQUES.forEach((b) => {
        try {
          const now = new Date();
          const str = now.toLocaleTimeString('en-GB', {
            timeZone: b.timezone,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
          });
          times[b.id] = str;
        } catch {
          times[b.id] = '--:--:--';
        }
      });
      setCurrentTimes(times);
    };

    updateTimes();
    const interval = setInterval(updateTimes, 1000);
    return () => clearInterval(interval);
  }, []);

  // Interactive 3D/2D Night Earth Canvas with illuminated connection arcs
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let rotation = 0;

    const renderGlobe = () => {
      rotation += 0.003;
      const w = canvas.width;
      const h = canvas.height;
      const cx = w / 2;
      const cy = h / 2;
      const r = Math.min(cx, cy) - 25;

      ctx.clearRect(0, 0, w, h);

      // Globe base sphere
      const sphereGrad = ctx.createRadialGradient(cx - 30, cy - 30, 20, cx, cy, r);
      sphereGrad.addColorStop(0, '#151D2A');
      sphereGrad.addColorStop(0.6, '#0B1017');
      sphereGrad.addColorStop(1, '#05070A');

      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fillStyle = sphereGrad;
      ctx.shadowColor = 'rgba(197, 160, 89, 0.2)';
      ctx.shadowBlur = 25;
      ctx.fill();
      ctx.shadowBlur = 0;

      // Latitude / Longitude grid lines
      ctx.strokeStyle = 'rgba(197, 160, 89, 0.12)';
      ctx.lineWidth = 1;
      for (let lat = -60; lat <= 60; lat += 30) {
        const yOffset = Math.sin((lat * Math.PI) / 180) * r;
        const radiusAtLat = Math.cos((lat * Math.PI) / 180) * r;
        ctx.beginPath();
        ctx.ellipse(cx, cy + yOffset, radiusAtLat, radiusAtLat * 0.2, 0, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Longitude meridians rotating
      for (let lon = 0; lon < 360; lon += 45) {
        const rad = ((lon * Math.PI) / 180) + rotation;
        const xOffset = Math.sin(rad) * r;
        ctx.beginPath();
        ctx.ellipse(cx, cy, Math.abs(xOffset), r, 0, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Boutique Nodes & Connection Arcs
      const projectedNodes: { x: number; y: number; b: BoutiqueLocation; visible: boolean }[] = [];

      BOUTIQUES.forEach((b) => {
        // Simple spherical projection with longitude rotation
        const lonRad = ((b.lng * Math.PI) / 180) + rotation;
        const latRad = (b.lat * Math.PI) / 180;

        const isFront = Math.cos(lonRad) > -0.2;
        const px = cx + Math.sin(lonRad) * Math.cos(latRad) * r;
        const py = cy - Math.sin(latRad) * r;

        projectedNodes.push({ x: px, y: py, b, visible: isFront });
      });

      // Draw glowing golden arcs between Geneva (index 0) and all other boutiques
      const geneva = projectedNodes[0];
      if (geneva && geneva.visible) {
        projectedNodes.forEach((node) => {
          if (node.b.id !== 'geneva-rhone' && node.visible) {
            ctx.beginPath();
            ctx.moveTo(geneva.x, geneva.y);
            const midX = (geneva.x + node.x) / 2;
            const midY = (geneva.y + node.y) / 2 - 35;
            ctx.quadraticCurveTo(midX, midY, node.x, node.y);
            ctx.strokeStyle = 'rgba(236, 200, 128, 0.4)';
            ctx.lineWidth = 1.2;
            ctx.stroke();
          }
        });
      }

      // Draw Nodes
      projectedNodes.forEach((node) => {
        if (!node.visible) return;
        const isSel = node.b.id === selectedBoutique.id;

        ctx.beginPath();
        ctx.arc(node.x, node.y, isSel ? 7 : 4, 0, Math.PI * 2);
        ctx.fillStyle = isSel ? '#00E5FF' : '#ECC880';
        if (isSel) {
          ctx.shadowColor = '#00E5FF';
          ctx.shadowBlur = 15;
        }
        ctx.fill();
        ctx.shadowBlur = 0;

        // Label
        if (isSel) {
          ctx.font = '10px "Plus Jakarta Sans", sans-serif';
          ctx.fillStyle = '#FFFFFF';
          ctx.textAlign = 'center';
          ctx.fillText(node.b.city, node.x, node.y - 12);
        }
      });

      animId = requestAnimationFrame(renderGlobe);
    };

    animId = requestAnimationFrame(renderGlobe);
    return () => {
      if (animId) cancelAnimationFrame(animId);
    };
  }, [selectedBoutique]);

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookingName || !bookingEmail || !bookingDate) return;
    horologyAudio.playChime();
    setIsBooked(true);
  };

  return (
    <section id="boutiques" className="py-24 px-6 max-w-7xl mx-auto w-full space-y-12">
      {/* SECTION HEADER */}
      <div className="space-y-3 max-w-2xl">
        <div className="flex items-center gap-2 text-xs font-semibold tracking-[0.26em] uppercase text-[#E5C384]">
          <span className="w-5 h-[1px] bg-[#C5A059]" />
          <span>Worldwide Presence</span>
        </div>
        <h2 className="font-cinzel text-3xl sm:text-4xl font-light text-[#F3F4F6]">
          Boutiques & Authorised Retailers
        </h2>
        <p className="text-sm text-slate-400 font-light leading-relaxed">
          Experience the pinnacle of Swiss hospitality. Book a private salon consultation with our
          certified master horologists.
        </p>
      </div>

      {/* 3D GLOBE & BOUTIQUE DIRECTORY GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* INTERACTIVE 3D/2D GLOBE CANVAS */}
        <div className="lg:col-span-6 bg-[#090C12] border border-[#C5A059]/30 rounded-2xl p-6 flex flex-col items-center justify-between shadow-2xl relative overflow-hidden">
          <div className="w-full flex items-center justify-between z-10">
            <div className="flex items-center gap-2 text-xs font-mono-num uppercase tracking-wider text-[#E5C384]">
              <Globe className="w-4 h-4 text-[#C5A059]" />
              <span>Global Boutique Satellite Grid</span>
            </div>
            <span className="text-xs font-mono-num text-slate-400">
              Geneva Headquarters: {currentTimes['geneva-rhone'] || '12:00:00'}
            </span>
          </div>

          <div className="py-6 my-auto">
            <canvas ref={canvasRef} width={380} height={380} className="rounded-full cursor-grab" />
          </div>

          <div className="w-full pt-4 border-t border-slate-800/80 flex flex-wrap items-center justify-center gap-2 text-xs font-mono-num">
            {BOUTIQUES.map((b) => (
              <button
                key={b.id}
                onClick={() => setSelectedBoutique(b)}
                className={`px-3 py-1 rounded transition-all ${
                  selectedBoutique.id === b.id
                    ? 'bg-[#C5A059] text-[#080B0F] font-bold shadow-md'
                    : 'bg-[#121722] text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {b.city} ({currentTimes[b.id]?.slice(0, 5) || '--:--'})
              </button>
            ))}
          </div>
        </div>

        {/* BOUTIQUE DETAILS & APPOINTMENT RESERVATION */}
        <div className="lg:col-span-6 space-y-6">
          {/* SELECTED BOUTIQUE INFO CARD */}
          <div className="bg-[#0E131C] border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-xs font-mono-num uppercase tracking-widest text-[#E5C384]">
                  {selectedBoutique.country}
                </span>
                <h3 className="font-cinzel text-xl sm:text-2xl font-semibold text-[#F3F4F6] mt-1">
                  {selectedBoutique.name}
                </h3>
              </div>
              <div className="text-right font-mono-num">
                <span className="text-[10px] text-slate-500 uppercase block">Local Time</span>
                <span className="text-sm font-semibold text-emerald-400">
                  {currentTimes[selectedBoutique.id] || 'Loading...'}
                </span>
              </div>
            </div>

            <div className="space-y-2 text-xs text-slate-300 font-light border-y border-slate-800 py-4">
              <div className="flex items-center gap-2.5">
                <MapPin className="w-4 h-4 text-[#C5A059] shrink-0" />
                <span>{selectedBoutique.address}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#C5A059] shrink-0" />
                <span>{selectedBoutique.phone}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-[#C5A059] shrink-0" />
                <span>Monday – Saturday: 10:00 – 19:00 (Private Salons by Appointment)</span>
              </div>
            </div>

            <div>
              <span className="text-[10px] font-mono-num uppercase tracking-widest text-slate-500 block mb-2">
                Available Salon Services
              </span>
              <div className="flex flex-wrap gap-2">
                {selectedBoutique.services.map((serv, idx) => (
                  <span
                    key={idx}
                    className="text-xs text-slate-300 bg-[#151C26] px-2.5 py-1 rounded border border-slate-800"
                  >
                    {serv}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* PRIVATE SALON BOOKING FORM */}
          <div className="bg-[#0E131C] border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-4">
            <h4 className="font-cinzel text-lg font-semibold text-slate-100 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#C5A059]" />
              <span>Reserve a Private Horological Viewing</span>
            </h4>

            {isBooked ? (
              <div className="p-6 rounded-xl bg-[#092B18] border border-emerald-500/40 text-center space-y-3">
                <div className="w-10 h-10 rounded-full bg-emerald-500 text-black flex items-center justify-center mx-auto">
                  <Check className="w-6 h-6" />
                </div>
                <h5 className="font-cinzel text-lg font-bold text-white">
                  Appointment Confirmed
                </h5>
                <p className="text-xs text-emerald-200">
                  Thank you, {bookingName}. A private concierge invitation has been dispatched to{' '}
                  <span className="font-semibold text-white">{bookingEmail}</span> for your viewing at{' '}
                  {selectedBoutique.name} on {bookingDate} at {bookingTime}.
                </p>
                {prefilledWatch && (
                  <div className="text-[11px] font-mono-num text-emerald-300">
                    Piece of interest: {prefilledWatch}
                  </div>
                )}
                <button
                  onClick={() => setIsBooked(false)}
                  className="mt-2 text-xs text-emerald-300 underline hover:text-white"
                >
                  Schedule another appointment
                </button>
              </div>
            ) : (
              <form onSubmit={handleBookingSubmit} className="space-y-4">
                {prefilledWatch && (
                  <div className="p-2.5 rounded bg-[#151C28] border border-[#C5A059]/30 text-xs font-mono-num text-[#ECC880]">
                    Requested Timepiece: {prefilledWatch}
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-mono-num uppercase text-slate-400 block mb-1">
                      Full Name
                    </label>
                    <input
                      type="text"
                      required
                      value={bookingName}
                      onChange={(e) => setBookingName(e.target.value)}
                      placeholder="Lord / Lady / Mr / Ms..."
                      className="w-full px-3 py-2 text-xs rounded bg-[#141A24] border border-slate-800 text-slate-100 focus:border-[#C5A059] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-mono-num uppercase text-slate-400 block mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      required
                      value={bookingEmail}
                      onChange={(e) => setBookingEmail(e.target.value)}
                      placeholder="collector@domain.com"
                      className="w-full px-3 py-2 text-xs rounded bg-[#141A24] border border-slate-800 text-slate-100 focus:border-[#C5A059] focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-mono-num uppercase text-slate-400 block mb-1">
                      Preferred Date
                    </label>
                    <input
                      type="date"
                      required
                      value={bookingDate}
                      onChange={(e) => setBookingDate(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded bg-[#141A24] border border-slate-800 text-slate-100 focus:border-[#C5A059] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-mono-num uppercase text-slate-400 block mb-1">
                      Preferred Time Slot
                    </label>
                    <select
                      value={bookingTime}
                      onChange={(e) => setBookingTime(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded bg-[#141A24] border border-slate-800 text-slate-100 focus:border-[#C5A059] focus:outline-none"
                    >
                      <option value="11:00">11:00 AM (Morning Salon)</option>
                      <option value="14:00">02:00 PM (Afternoon Salon)</option>
                      <option value="16:30">04:30 PM (Private Twilight Session)</option>
                      <option value="18:00">06:00 PM (Executive Viewing)</option>
                    </select>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded bg-[#C5A059] hover:bg-[#D4AF37] text-[#080B0F] font-semibold text-xs uppercase tracking-widest transition-all shadow-md mt-2"
                >
                  Request Private Salon Reservation
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
