'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowUpRight } from 'lucide-react';

interface PillarsSectionProps {
  onOpenPrecision: () => void;
  onOpenManufacture: () => void;
  onOpenCrownTrust: () => void;
  onOpenBoutiques: () => void;
}

export default function PillarsSection({
  onOpenPrecision,
  onOpenManufacture,
  onOpenCrownTrust,
  onOpenBoutiques,
}: PillarsSectionProps) {
  const pillars = [
    {
      id: 'precision',
      title: 'THE ART OF PRECISION',
      subtitle: 'INSIDE EVERY ROLEX',
      image: '/src/assets/images/movement_art_of_precision_1791012610050.jpg',
      action: onOpenPrecision,
      badge: 'Calibre 3235 & 4131',
    },
    {
      id: 'manufacture',
      title: 'OUR MANUFACTURE',
      subtitle: 'FINE CRAFTSMANSHIP. LASTING VALUE.',
      image: '/src/assets/images/manufacture_swiss_alps_1791012620670.jpg',
      action: onOpenManufacture,
      badge: 'Geneva & Bienne',
    },
    {
      id: 'crown',
      title: 'THE ROLEX CROWN',
      subtitle: 'A SYMBOL OF TRUST',
      image: '/src/assets/images/macro_fluted_bezel_crown_1791012631327.jpg',
      action: onOpenCrownTrust,
      badge: 'Superlative Standard',
    },
    {
      id: 'presence',
      title: 'A GLOBAL PRESENCE',
      subtitle: 'BOUTIQUES & AUTHORISED RETAILERS',
      image: '/src/assets/images/global_presence_illuminated_globe_1791012642447.jpg',
      action: onOpenBoutiques,
      badge: 'Worldwide Flagships',
    },
  ];

  return (
    <section id="pillars" className="w-full bg-[#080B0F] border-t border-[#C5A059]/20">
      {/* 4 EQUAL-WIDTH LUXURY TILES EXACTLY AS IN THE HERO FOOTER OF THE REFERENCE IMAGE */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 divide-y lg:divide-y-0 lg:divide-x divide-slate-800/80 border-b border-slate-800/80">
        {pillars.map((pillar) => (
          <div
            key={pillar.id}
            onClick={pillar.action}
            className="group relative h-72 sm:h-80 xl:h-96 overflow-hidden cursor-pointer flex flex-col justify-end p-6 md:p-8 bg-[#0B0F15] transition-all"
          >
            {/* Background Media with Smooth Zoom on Hover */}
            <div className="absolute inset-0 z-0">
              <Image
                src={pillar.image}
                alt={pillar.title}
                fill
                sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
                className="object-cover object-center transition-transform duration-700 ease-out group-hover:scale-108 group-hover:opacity-95 opacity-80"
                referrerPolicy="no-referrer"
              />
              {/* Measured contrast scrim */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#080B0F] via-[#080B0F]/60 to-transparent transition-opacity duration-300 group-hover:opacity-80" />
            </div>

            {/* Hover Gold Accent Border Top */}
            <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-[#C5A059] to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

            {/* Pillar Content Card */}
            <div className="relative z-10 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono-num uppercase tracking-[0.24em] text-[#E5C384]">
                  {pillar.badge}
                </span>
                <ArrowUpRight className="w-4 h-4 text-[#C5A059] opacity-0 group-hover:opacity-100 transition-all duration-300 -translate-y-1 translate-x-1" />
              </div>

              <h3 className="font-cinzel text-base sm:text-lg font-semibold tracking-[0.14em] text-[#F3F4F6] group-hover:text-[#ECC880] transition-colors">
                {pillar.title}
              </h3>

              <p className="text-xs font-medium tracking-[0.18em] uppercase text-slate-400 group-hover:text-slate-200 transition-colors">
                {pillar.subtitle}
              </p>

              {/* Decorative underline indicator */}
              <div className="pt-2">
                <div className="w-8 h-[1px] bg-[#C5A059]/60 group-hover:w-16 group-hover:bg-[#C5A059] transition-all duration-500" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
