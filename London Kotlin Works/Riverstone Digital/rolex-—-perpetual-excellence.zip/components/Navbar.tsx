'use client';

import React, { useState } from 'react';
import { Search, Volume2, VolumeX, Bookmark, Sparkles, X } from 'lucide-react';
import { horologyAudio } from '@/lib/audioSynthesis';
import { FEATURED_MODELS } from '@/lib/horologyData';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currency: 'CHF' | 'USD' | 'EUR';
  setCurrency: (c: 'CHF' | 'USD' | 'EUR') => void;
  savedWatchIds: string[];
  onOpenSavedModal: () => void;
  onOpenConcierge: () => void;
  onSelectModel: (id: string) => void;
}

export default function Navbar({
  activeTab,
  setActiveTab,
  currency,
  setCurrency,
  savedWatchIds,
  onOpenSavedModal,
  onOpenConcierge,
  onSelectModel,
}: NavbarProps) {
  const [isAudioActive, setIsAudioActive] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isCurrencyDropdown, setIsCurrencyDropdown] = useState(false);

  const toggleSound = () => {
    const isPlaying = horologyAudio.toggleMute();
    setIsAudioActive(isPlaying);
  };

  const filteredWatches = searchQuery.trim()
    ? FEATURED_MODELS.filter(
        (w) =>
          w.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          w.reference.toLowerCase().includes(searchQuery.toLowerCase()) ||
          w.family.toLowerCase().includes(searchQuery.toLowerCase()) ||
          w.calibre.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  const handleNavClick = (tabId: string) => {
    setActiveTab(tabId);
    const element = document.getElementById(tabId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <header className="sticky top-0 z-50 w-full bg-[#080B0F]/90 backdrop-blur-xl border-b border-[#C5A059]/15 transition-all">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          {/* ZONE 1: BRAND LOGO (Rolex Crown + Typographic Wordmark in Display Face) */}
          <button
            onClick={() => handleNavClick('hero')}
            className="flex items-center gap-3 text-left group transition-transform focus:outline-none"
          >
            {/* Iconic Rolex Coronet Crown */}
            <svg
              viewBox="0 0 100 80"
              className="w-7 h-7 fill-[#C5A059] transition-transform duration-300 group-hover:scale-105"
              aria-label="Rolex Crown"
            >
              <path d="M50 0L62 30L85 10L80 50L20 50L15 10L38 30L50 0Z" />
              <rect x="20" y="56" width="60" height="10" rx="2" />
              <circle cx="50" cy="4" r="3.5" />
              <circle cx="86" cy="12" r="3.5" />
              <circle cx="14" cy="12" r="3.5" />
            </svg>
            <span className="font-cinzel text-xl font-bold tracking-[0.28em] text-[#F3F4F6] group-hover:text-[#ECC880] transition-colors">
              ROLEX
            </span>
          </button>

          {/* ZONE 2: PRIMARY NAVIGATION LINKS (Clean typography with subtle indicators) */}
          <nav className="hidden lg:flex items-center gap-8 text-[13px] font-medium tracking-[0.18em] uppercase text-slate-300">
            <button
              onClick={() => handleNavClick('watches')}
              className={`hover:text-[#ECC880] transition-colors py-1 relative ${
                activeTab === 'watches' ? 'text-[#ECC880]' : ''
              }`}
            >
              Watches
              {activeTab === 'watches' && (
                <span className="absolute bottom-0 left-0 w-full h-[1.5px] bg-[#C5A059]" />
              )}
            </button>
            <button
              onClick={() => handleNavClick('pillars')}
              className={`hover:text-[#ECC880] transition-colors py-1 relative ${
                activeTab === 'pillars' ? 'text-[#ECC880]' : ''
              }`}
            >
              The Rolex World
              {activeTab === 'pillars' && (
                <span className="absolute bottom-0 left-0 w-full h-[1.5px] bg-[#C5A059]" />
              )}
            </button>
            <button
              onClick={() => handleNavClick('heritage')}
              className={`hover:text-[#ECC880] transition-colors py-1 relative ${
                activeTab === 'heritage' ? 'text-[#ECC880]' : ''
              }`}
            >
              Heritage
              {activeTab === 'heritage' && (
                <span className="absolute bottom-0 left-0 w-full h-[1.5px] bg-[#C5A059]" />
              )}
            </button>
            <button
              onClick={() => handleNavClick('boutiques')}
              className={`hover:text-[#ECC880] transition-colors py-1 relative ${
                activeTab === 'boutiques' ? 'text-[#ECC880]' : ''
              }`}
            >
              Boutiques
              {activeTab === 'boutiques' && (
                <span className="absolute bottom-0 left-0 w-full h-[1.5px] bg-[#C5A059]" />
              )}
            </button>
            <button
              onClick={() => handleNavClick('configurator')}
              className={`hover:text-[#ECC880] transition-colors py-1 relative ${
                activeTab === 'configurator' ? 'text-[#ECC880]' : ''
              }`}
            >
              Atelier
              {activeTab === 'configurator' && (
                <span className="absolute bottom-0 left-0 w-full h-[1.5px] bg-[#C5A059]" />
              )}
            </button>
          </nav>

          {/* ZONE 3: ACTIONS & UTILITIES */}
          <div className="flex items-center gap-4 text-slate-300">
            {/* AI Horology Concierge Button */}
            <button
              onClick={onOpenConcierge}
              className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded text-xs font-medium tracking-wider uppercase border border-[#C5A059]/40 bg-[#C5A059]/10 text-[#ECC880] hover:bg-[#C5A059]/20 hover:border-[#C5A059] transition-all"
              title="Speak with the Master Horologist Concierge"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#ECC880]" />
              <span>Concierge</span>
            </button>

            {/* Sound Tick Toggle */}
            <button
              onClick={toggleSound}
              className={`p-2 rounded-full border transition-all ${
                isAudioActive
                  ? 'border-[#C5A059] text-[#ECC880] bg-[#C5A059]/10'
                  : 'border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
              }`}
              title={isAudioActive ? 'Mute Mechanical Escapement' : 'Enable 28,800 vph Swiss Escapement Acoustics'}
              aria-label="Toggle Escapement Acoustics"
            >
              {isAudioActive ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Search Trigger */}
            <button
              onClick={() => setIsSearchOpen(true)}
              className="p-2 text-slate-300 hover:text-[#ECC880] transition-colors"
              title="Search References & Models"
              aria-label="Search"
            >
              <Search className="w-4 h-4" />
            </button>

            {/* Bookmarked Watches Drawer */}
            <button
              onClick={onOpenSavedModal}
              className="relative p-2 text-slate-300 hover:text-[#ECC880] transition-colors"
              title="Saved Timepieces"
              aria-label="Saved Timepieces"
            >
              <Bookmark className="w-4 h-4" />
              {savedWatchIds.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#C5A059] text-[#080B0F] text-[10px] font-bold rounded-full flex items-center justify-center font-mono-num">
                  {savedWatchIds.length}
                </span>
              )}
            </button>

            <span className="text-slate-700">|</span>

            {/* Currency / Region Selector */}
            <div className="relative">
              <button
                onClick={() => setIsCurrencyDropdown(!isCurrencyDropdown)}
                className="flex items-center gap-1 text-xs font-mono-num tracking-widest uppercase hover:text-[#ECC880] transition-colors px-1 py-1"
              >
                <span>EN · {currency}</span>
                <span className="text-[9px]">▾</span>
              </button>
              {isCurrencyDropdown && (
                <div className="absolute right-0 mt-2 w-28 bg-[#0F141C] border border-[#C5A059]/25 rounded shadow-2xl py-1 z-50 text-xs font-mono-num">
                  {(['CHF', 'USD', 'EUR'] as const).map((curr) => (
                    <button
                      key={curr}
                      onClick={() => {
                        setCurrency(curr);
                        setIsCurrencyDropdown(false);
                      }}
                      className={`w-full text-left px-3 py-1.5 hover:bg-[#1C2532] hover:text-[#ECC880] transition-colors ${
                        currency === curr ? 'text-[#ECC880] font-bold' : 'text-slate-300'
                      }`}
                    >
                      {curr}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* SEARCH MODAL */}
      {isSearchOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-start justify-center pt-24 px-4">
          <div className="w-full max-w-2xl bg-[#0F141C] border border-[#C5A059]/30 rounded-lg p-6 shadow-2xl animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3 flex-1">
                <Search className="w-5 h-5 text-[#C5A059]" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by model (e.g. Datejust, Submariner, Daytona, Calibre 3235)..."
                  className="w-full bg-transparent border-none text-slate-100 placeholder:text-slate-500 text-sm focus:outline-none"
                  autoFocus
                />
              </div>
              <button
                onClick={() => setIsSearchOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 max-h-80 overflow-y-auto custom-scrollbar space-y-2">
              {filteredWatches.length > 0 ? (
                filteredWatches.map((watch) => (
                  <div
                    key={watch.id}
                    onClick={() => {
                      onSelectModel(watch.id);
                      setIsSearchOpen(false);
                    }}
                    className="p-3 rounded bg-[#151C26] hover:bg-[#1E2938] border border-transparent hover:border-[#C5A059]/30 cursor-pointer flex items-center justify-between transition-colors"
                  >
                    <div>
                      <h4 className="text-sm font-semibold text-slate-100">{watch.name}</h4>
                      <p className="text-xs text-slate-400 font-mono-num">
                        Ref: {watch.reference} · {watch.calibre}
                      </p>
                    </div>
                    <span className="text-xs text-[#ECC880] font-mono-num font-medium">
                      {currency} {watch[`price${currency}`].toLocaleString()}
                    </span>
                  </div>
                ))
              ) : searchQuery.trim() ? (
                <p className="text-center py-6 text-sm text-slate-500">
                  No timepieces found matching &quot;{searchQuery}&quot;.
                </p>
              ) : (
                <div className="py-4">
                  <span className="text-xs font-mono-num uppercase tracking-wider text-slate-500">
                    Suggested Explorations
                  </span>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {FEATURED_MODELS.map((w) => (
                      <button
                        key={w.id}
                        onClick={() => {
                          onSelectModel(w.id);
                          setIsSearchOpen(false);
                        }}
                        className="px-3 py-1 text-xs rounded bg-[#18202D] hover:bg-[#202C3E] text-slate-300 hover:text-[#ECC880] border border-slate-800 transition-colors"
                      >
                        {w.name}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
