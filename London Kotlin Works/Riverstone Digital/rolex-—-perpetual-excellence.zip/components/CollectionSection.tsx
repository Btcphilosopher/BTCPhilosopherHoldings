'use client';

import React, { useState } from 'react';
import { Bookmark, Sparkles, SlidersHorizontal, Check } from 'lucide-react';
import { FEATURED_MODELS, WatchModel } from '@/lib/horologyData';

interface CollectionSectionProps {
  currency: 'CHF' | 'USD' | 'EUR';
  savedWatchIds: string[];
  onToggleSaveWatch: (id: string) => void;
  onSelectModel: (id: string) => void;
  onConfigureWatch: (id: string) => void;
}

export default function CollectionSection({
  currency,
  savedWatchIds,
  onToggleSaveWatch,
  onSelectModel,
  onConfigureWatch,
}: CollectionSectionProps) {
  const [activeCategory, setActiveCategory] = useState<'all' | 'Classic' | 'Professional'>('all');

  const filteredModels =
    activeCategory === 'all'
      ? FEATURED_MODELS
      : FEATURED_MODELS.filter((m) => m.family === activeCategory);

  return (
    <section id="watches" className="py-24 px-6 max-w-7xl mx-auto w-full space-y-12">
      {/* SECTION HEADER */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-slate-800 pb-8">
        <div className="space-y-3 max-w-xl">
          <div className="flex items-center gap-2 text-xs font-semibold tracking-[0.26em] uppercase text-[#E5C384]">
            <span className="w-5 h-[1px] bg-[#C5A059]" />
            <span>The Collection</span>
          </div>
          <h2 className="font-cinzel text-3xl sm:text-4xl font-light tracking-wide text-[#F3F4F6]">
            Icons of Haute Horlogerie
          </h2>
          <p className="text-sm text-slate-400 font-light leading-relaxed">
            Every Rolex watch is designed, crafted, and tested with constant attention to the
            tiniest details. Explore our timeless classic and professional creations.
          </p>
        </div>

        {/* CATEGORY FILTER BUTTONS */}
        <div className="flex items-center gap-2 p-1 bg-[#10141C] border border-slate-800 rounded-lg self-start md:self-auto">
          <button
            onClick={() => setActiveCategory('all')}
            className={`px-4 py-2 text-xs font-medium tracking-wider uppercase rounded transition-all ${
              activeCategory === 'all'
                ? 'bg-[#C5A059] text-[#080B0F] font-bold shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Watches
          </button>
          <button
            onClick={() => setActiveCategory('Classic')}
            className={`px-4 py-2 text-xs font-medium tracking-wider uppercase rounded transition-all ${
              activeCategory === 'Classic'
                ? 'bg-[#C5A059] text-[#080B0F] font-bold shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Classic
          </button>
          <button
            onClick={() => setActiveCategory('Professional')}
            className={`px-4 py-2 text-xs font-medium tracking-wider uppercase rounded transition-all ${
              activeCategory === 'Professional'
                ? 'bg-[#C5A059] text-[#080B0F] font-bold shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Professional
          </button>
        </div>
      </div>

      {/* PRODUCTS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
        {filteredModels.map((watch: WatchModel) => {
          const isSaved = savedWatchIds.includes(watch.id);
          const priceValue = watch[`price${currency}`];

          return (
            <div
              key={watch.id}
              className="group relative bg-[#0C1017] border border-[#C5A059]/15 hover:border-[#C5A059]/40 rounded-xl overflow-hidden transition-all duration-300 hover:shadow-[0_20px_40px_rgba(0,0,0,0.6)] flex flex-col justify-between"
            >
              {/* TOP CARD BAR */}
              <div className="p-6 flex items-start justify-between border-b border-slate-800/60 z-10 relative">
                <div>
                  <div className="text-[11px] font-mono-num uppercase tracking-widest text-[#E5C384] mb-1">
                    {watch.family} Timepiece · {watch.caseDiameter}
                  </div>
                  <h3 className="font-cinzel text-xl font-semibold text-[#F3F4F6] group-hover:text-[#ECC880] transition-colors">
                    {watch.name}
                  </h3>
                  <div className="text-xs font-mono-num text-slate-400 mt-1">
                    Ref: {watch.reference}
                  </div>
                </div>

                {/* Bookmark / Wishlist button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleSaveWatch(watch.id);
                  }}
                  className={`p-2 rounded-full border transition-all ${
                    isSaved
                      ? 'bg-[#C5A059] border-[#C5A059] text-[#080B0F]'
                      : 'border-slate-700 bg-black/40 text-slate-400 hover:text-white hover:border-slate-500'
                  }`}
                  title={isSaved ? 'Remove from Saved' : 'Save to Personal Briefcase'}
                >
                  <Bookmark className="w-4 h-4" />
                </button>
              </div>

              {/* CARD PREVIEW AREA WITH STYLED DIAL APERÇU */}
              <div
                onClick={() => onSelectModel(watch.id)}
                className="relative py-12 px-6 flex flex-col items-center justify-center cursor-pointer bg-gradient-to-b from-[#0C1017] via-[#101622] to-[#0C1017] overflow-hidden group-hover:bg-[#111724] transition-colors"
              >
                {/* Radial Glow */}
                <div
                  className="absolute w-48 h-48 rounded-full blur-3xl opacity-20 pointer-events-none"
                  style={{ backgroundColor: watch.dialColorCode }}
                />

                {/* Stylized Visual Watch Case Simulation */}
                <div className="relative w-44 h-44 rounded-full border-4 border-[#3A4250] shadow-2xl flex items-center justify-center p-2 bg-[#090C10] group-hover:scale-105 transition-transform duration-500">
                  <div
                    className="w-full h-full rounded-full border-2 border-slate-700 flex flex-col items-center justify-center text-center p-3 relative overflow-hidden"
                    style={{ backgroundColor: watch.dialColorCode }}
                  >
                    <span className="text-[#C5A059] text-base mb-1">♛</span>
                    <span className="font-cinzel text-xs font-bold tracking-widest text-[#F3F4F6]">
                      ROLEX
                    </span>
                    <span className="text-[8px] font-mono-num tracking-wider text-slate-300 mt-0.5">
                      {watch.calibre.split(',')[0]}
                    </span>
                    <div className="mt-2 text-[9px] font-mono-num text-[#ECC880]">
                      {watch.waterResistance.split('/')[0]}
                    </div>
                  </div>
                </div>

                <p className="mt-6 text-xs text-center text-slate-300 max-w-sm px-4 line-clamp-2 font-light">
                  {watch.description}
                </p>
              </div>

              {/* SPECIFICATIONS & ACTION FOOTER */}
              <div className="p-6 bg-[#090D14] border-t border-slate-800/80 space-y-4">
                <div className="grid grid-cols-2 gap-3 text-xs font-mono-num text-slate-400">
                  <div>
                    <span className="text-slate-500 block text-[10px] uppercase tracking-wider">
                      Material
                    </span>
                    <span className="text-slate-200 truncate block">{watch.material}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px] uppercase tracking-wider">
                      Power Reserve
                    </span>
                    <span className="text-slate-200 block">{watch.powerReserve}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                  <div>
                    <span className="text-[10px] font-mono-num uppercase tracking-widest text-slate-500 block">
                      Official Price
                    </span>
                    <span className="text-base font-mono-num font-bold text-[#ECC880]">
                      {currency} {priceValue.toLocaleString()}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onSelectModel(watch.id)}
                      className="px-3.5 py-1.5 text-xs font-medium tracking-wider uppercase rounded bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
                    >
                      Live Dial
                    </button>
                    <button
                      onClick={() => onConfigureWatch(watch.id)}
                      className="px-4 py-1.5 text-xs font-semibold tracking-wider uppercase rounded bg-[#C5A059]/20 hover:bg-[#C5A059] text-[#ECC880] hover:text-[#080B0F] border border-[#C5A059]/50 transition-all shadow-sm"
                    >
                      Atelier
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
