'use client';

import React from 'react';

export default function Footer() {
  return (
    <footer className="w-full bg-[#05070A] border-t border-[#C5A059]/15 text-slate-400 py-16 px-6 select-none">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* TOP BRAND EMBLEM */}
        <div className="flex flex-col items-center justify-center text-center space-y-3">
          <svg viewBox="0 0 100 80" className="w-9 h-9 fill-[#C5A059]" aria-label="Rolex Crown">
            <path d="M50 0L62 30L85 10L80 50L20 50L15 10L38 30L50 0Z" />
            <rect x="20" y="56" width="60" height="10" rx="2" />
            <circle cx="50" cy="4" r="3.5" />
            <circle cx="86" cy="12" r="3.5" />
            <circle cx="14" cy="12" r="3.5" />
          </svg>
          <span className="font-cinzel text-2xl font-bold tracking-[0.3em] text-[#F3F4F6]">
            ROLEX
          </span>
          <p className="text-xs font-mono-num uppercase tracking-widest text-[#E5C384]">
            Geneva, Switzerland · Since 1905
          </p>
        </div>

        {/* NAVIGATION DIRECTORY */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-xs">
          <div className="space-y-3">
            <h4 className="font-cinzel font-semibold text-slate-200 tracking-wider">Rolex Watches</h4>
            <ul className="space-y-2 text-slate-400 font-light">
              <li><a href="#watches" className="hover:text-[#ECC880] transition-colors">Datejust 41</a></li>
              <li><a href="#watches" className="hover:text-[#ECC880] transition-colors">Submariner Date</a></li>
              <li><a href="#watches" className="hover:text-[#ECC880] transition-colors">Cosmograph Daytona</a></li>
              <li><a href="#watches" className="hover:text-[#ECC880] transition-colors">Day-Date 40</a></li>
              <li><a href="#watches" className="hover:text-[#ECC880] transition-colors">GMT-Master II</a></li>
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="font-cinzel font-semibold text-slate-200 tracking-wider">The Rolex World</h4>
            <ul className="space-y-2 text-slate-400 font-light">
              <li><a href="#pillars" className="hover:text-[#ECC880] transition-colors">The Art of Precision</a></li>
              <li><a href="#pillars" className="hover:text-[#ECC880] transition-colors">Our Manufacture</a></li>
              <li><a href="#pillars" className="hover:text-[#ECC880] transition-colors">The Rolex Crown</a></li>
              <li><a href="#pillars" className="hover:text-[#ECC880] transition-colors">Perpetual Planet Initiative</a></li>
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="font-cinzel font-semibold text-slate-200 tracking-wider">Services</h4>
            <ul className="space-y-2 text-slate-400 font-light">
              <li><a href="#configurator" className="hover:text-[#ECC880] transition-colors">The Atelier Configurator</a></li>
              <li><a href="#boutiques" className="hover:text-[#ECC880] transition-colors">Find a Boutique</a></li>
              <li><a href="#boutiques" className="hover:text-[#ECC880] transition-colors">Private Salon Appointment</a></li>
              <li><a href="#watches" className="hover:text-[#ECC880] transition-colors">Watch Care & Servicing</a></li>
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="font-cinzel font-semibold text-slate-200 tracking-wider">Legal & Trust</h4>
            <ul className="space-y-2 text-slate-400 font-light">
              <li><span className="text-slate-400">Official Superlative Chronometer</span></li>
              <li><span className="text-slate-400">5-Year International Guarantee</span></li>
              <li><span className="text-slate-400">Swiss Manufacture Standards</span></li>
              <li><span className="text-slate-400">Privacy Notice & Legal Terms</span></li>
            </ul>
          </div>
        </div>

        {/* BOTTOM COPYRIGHT */}
        <div className="pt-8 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 font-mono-num">
          <div>
            © {new Date().getFullYear()} Rolex S.A. All rights reserved. Registered Swiss Trademark.
          </div>
          <div className="mt-2 sm:mt-0 flex items-center gap-4">
            <span>Manufacture des Montres Rolex S.A.</span>
            <span>·</span>
            <span>Geneva, Switzerland</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
