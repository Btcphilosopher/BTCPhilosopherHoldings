'use client';

import React, { useEffect, useRef, useState } from 'react';
import { ShieldAlert, Zap, Cog, Activity, X } from 'lucide-react';
import { CALIBRES } from '@/lib/horologyData';
import { horologyAudio } from '@/lib/audioSynthesis';

interface CalibreInspectorProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CalibreInspector({ isOpen, onClose }: CalibreInspectorProps) {
  const [activeCalibreKey, setActiveCalibreKey] = useState<'3235' | '4131'>('3235');
  const [isOscillating, setIsOscillating] = useState(true);
  const [simulatedDeviation, setSimulatedDeviation] = useState(+0.4);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const calibre = CALIBRES[activeCalibreKey];

  // Canvas-based real-time 4Hz Swiss Balance Spring & Escapement Physics Sim
  useEffect(() => {
    if (!isOpen) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let startTime = performance.now();

    const renderMovement = (time: number) => {
      const elapsed = (time - startTime) / 1000;
      const width = canvas.width;
      const height = canvas.height;
      const cx = width / 2;
      const cy = height / 2;

      ctx.clearRect(0, 0, width, height);

      // Mainplate with circular graining / perlage
      ctx.beginPath();
      ctx.arc(cx, cy, 140, 0, Math.PI * 2);
      const plateGrad = ctx.createRadialGradient(cx, cy, 30, cx, cy, 140);
      plateGrad.addColorStop(0, '#2A303C');
      plateGrad.addColorStop(0.7, '#1C212B');
      plateGrad.addColorStop(1, '#11151C');
      ctx.fillStyle = plateGrad;
      ctx.fill();
      ctx.strokeStyle = '#C5A059';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Perlage circular spotting
      ctx.fillStyle = 'rgba(255, 255, 255, 0.03)';
      for (let r = 20; r < 130; r += 16) {
        const count = Math.floor(r * 0.35);
        for (let i = 0; i < count; i++) {
          const a = (i / count) * Math.PI * 2;
          ctx.beginPath();
          ctx.arc(cx + Math.cos(a) * r, cy + Math.sin(a) * r, 8, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // 4 Hz oscillation angle = sin(2 * pi * 4 * t)
      const balanceAngle = isOscillating ? Math.sin(elapsed * Math.PI * 8) * (Math.PI * 1.2) : 0;

      // 1. ESCAPE WHEEL (Chronergy nickel-phosphorus cutouts)
      const escapeX = cx - 50;
      const escapeY = cy - 30;
      const escapeAngle = isOscillating ? elapsed * 2 : 0;

      ctx.save();
      ctx.translate(escapeX, escapeY);
      ctx.rotate(escapeAngle);
      ctx.beginPath();
      ctx.arc(0, 0, 32, 0, Math.PI * 2);
      ctx.strokeStyle = '#D4AF37';
      ctx.lineWidth = 2;
      ctx.stroke();
      for (let i = 0; i < 15; i++) {
        const a = (i / 15) * Math.PI * 2;
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * 16, Math.sin(a) * 16);
        ctx.lineTo(Math.cos(a + 0.1) * 32, Math.sin(a + 0.1) * 32);
        ctx.strokeStyle = '#F0D179';
        ctx.lineWidth = 2;
        ctx.stroke();
      }
      // Ruby jewel bearing at escape center
      ctx.beginPath();
      ctx.arc(0, 0, 5, 0, Math.PI * 2);
      ctx.fillStyle = '#E11D48';
      ctx.fill();
      ctx.restore();

      // 2. GLUCYDUR BALANCE WHEEL WITH GOLD MICROSTELLA NUTS
      const balanceX = cx + 45;
      const balanceY = cy + 20;

      ctx.save();
      ctx.translate(balanceX, balanceY);
      ctx.rotate(balanceAngle);

      // Outer gold rim
      ctx.beginPath();
      ctx.arc(0, 0, 54, 0, Math.PI * 2);
      ctx.strokeStyle = '#ECC880';
      ctx.lineWidth = 3.5;
      ctx.stroke();

      // 2 Balance arms
      ctx.beginPath();
      ctx.moveTo(-54, 0);
      ctx.lineTo(54, 0);
      ctx.moveTo(0, -54);
      ctx.lineTo(0, 54);
      ctx.strokeStyle = '#C5A059';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Microstella adjustment screws
      const screws = [0, Math.PI / 2, Math.PI, (3 * Math.PI) / 2];
      screws.forEach((ang) => {
        ctx.beginPath();
        ctx.arc(Math.cos(ang) * 54, Math.sin(ang) * 54, 3, 0, Math.PI * 2);
        ctx.fillStyle = '#FFFFFF';
        ctx.fill();
      });

      // 3. BLUE PARACHROM HAIRSPRING (Coiled spiral)
      ctx.beginPath();
      const coils = 5;
      for (let theta = 0; theta < coils * Math.PI * 2; theta += 0.1) {
        const breathe = 1 + Math.sin(balanceAngle) * 0.08;
        const r = (theta / (coils * Math.PI * 2)) * 32 * breathe;
        const x = Math.cos(theta) * r;
        const y = Math.sin(theta) * r;
        if (theta === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.strokeStyle = '#00B4D8'; // Patented Paramagnetic Blue Parachrom
      ctx.lineWidth = 1.8;
      ctx.stroke();

      // Central ruby capstone & Paraflex shock absorber spring
      ctx.beginPath();
      ctx.arc(0, 0, 7, 0, Math.PI * 2);
      ctx.fillStyle = '#E11D48';
      ctx.fill();
      ctx.strokeStyle = '#ECC880';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.restore();

      // 4. PERPETUAL OSCILLATING ROTOR (Semi-circular gold weight in background)
      const rotorAngle = Math.sin(elapsed * 0.8) * 0.6;
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(rotorAngle);
      ctx.beginPath();
      ctx.arc(0, 0, 130, -Math.PI * 0.6, Math.PI * 0.6);
      ctx.lineTo(0, 0);
      ctx.closePath();
      const rotorGrad = ctx.createLinearGradient(-100, -100, 100, 100);
      rotorGrad.addColorStop(0, 'rgba(236, 200, 128, 0.25)');
      rotorGrad.addColorStop(1, 'rgba(197, 160, 89, 0.1)');
      ctx.fillStyle = rotorGrad;
      ctx.fill();
      ctx.strokeStyle = 'rgba(236, 200, 128, 0.5)';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Engraved Coronet on Rotor
      ctx.font = '14px "Cinzel", serif';
      ctx.fillStyle = '#ECC880';
      ctx.textAlign = 'center';
      ctx.fillText('♛ ROLEX GENEVE', 65, 0);
      ctx.restore();

      animId = requestAnimationFrame(renderMovement);
    };

    animId = requestAnimationFrame(renderMovement);

    return () => {
      if (animId) cancelAnimationFrame(animId);
    };
  }, [isOpen, isOscillating, activeCalibreKey]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-lg flex items-center justify-center p-4 sm:p-6 select-none overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-[#0B0F16] border border-[#C5A059]/40 rounded-2xl shadow-2xl p-6 sm:p-10 space-y-8 animate-in fade-in zoom-in-95 duration-200">
        {/* CLOSE BUTTON */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 p-2 rounded-full border border-slate-800 text-slate-400 hover:text-white hover:border-[#C5A059] transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        {/* HEADER */}
        <div className="space-y-2 border-b border-slate-800 pb-6">
          <div className="flex items-center gap-2 text-xs font-mono-num uppercase tracking-[0.24em] text-[#E5C384]">
            <Cog className="w-4 h-4 text-[#C5A059]" />
            <span>Haute Horlogerie Laboratory · Manufacture Rolex</span>
          </div>
          <h2 className="font-cinzel text-2xl sm:text-3xl font-semibold text-[#F3F4F6]">
            The Art of Precision: Calibre Architecture
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 max-w-2xl font-light">
            Rolex movements are developed and assembled entirely in-house. Certified as a Superlative
            Chronometer for extreme reliability, magnetic resistance, and -2/+2 seconds daily precision.
          </p>
        </div>

        {/* CALIBRE SELECTOR TABS */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveCalibreKey('3235')}
            className={`px-5 py-2 rounded text-xs font-semibold tracking-wider uppercase transition-all ${
              activeCalibreKey === '3235'
                ? 'bg-[#C5A059] text-[#080B0F] font-bold shadow-lg'
                : 'bg-[#141A24] text-slate-300 hover:bg-[#1D2534] border border-slate-800'
            }`}
          >
            Calibre 3235 (Datejust / Submariner)
          </button>
          <button
            onClick={() => setActiveCalibreKey('4131')}
            className={`px-5 py-2 rounded text-xs font-semibold tracking-wider uppercase transition-all ${
              activeCalibreKey === '4131'
                ? 'bg-[#C5A059] text-[#080B0F] font-bold shadow-lg'
                : 'bg-[#141A24] text-slate-300 hover:bg-[#1D2534] border border-slate-800'
            }`}
          >
            Calibre 4131 (Cosmograph Daytona)
          </button>
        </div>

        {/* MAIN DISPLAY GRID */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* PHYSICS SIMULATOR CANVAS */}
          <div className="lg:col-span-6 flex flex-col items-center justify-center p-6 rounded-xl bg-[#070A0F] border border-[#C5A059]/20 relative">
            <canvas ref={canvasRef} width={340} height={340} className="rounded-full shadow-2xl" />

            <div className="mt-4 flex items-center justify-between w-full px-4 text-xs font-mono-num text-slate-400">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-400 animate-ping" />
                <span className="text-blue-400">Blue Parachrom Spring</span>
              </div>
              <button
                onClick={() => setIsOscillating(!isOscillating)}
                className="px-3 py-1 rounded bg-[#151C26] hover:bg-[#202C3D] text-slate-300 text-[11px] border border-slate-800"
              >
                {isOscillating ? 'Halt Balance' : 'Release Balance'}
              </button>
            </div>
          </div>

          {/* TELEMETRY & SPECIFICATIONS */}
          <div className="lg:col-span-6 space-y-6">
            <div className="p-5 rounded-xl bg-[#0E131C] border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono-num uppercase tracking-wider text-slate-400">
                  Superlative Chronometer Rate Monitor
                </span>
                <span className="text-xs font-mono-num text-emerald-400 font-semibold">
                  {simulatedDeviation >= 0 ? `+${simulatedDeviation}` : simulatedDeviation} s/day
                </span>
              </div>

              {/* Rate Tolerance Bar */}
              <div className="w-full h-2 rounded-full bg-slate-800 relative overflow-hidden">
                <div className="absolute inset-y-0 left-[30%] right-[30%] bg-emerald-500/30 border-x border-emerald-400" />
                <div
                  className="absolute top-0 bottom-0 w-2 bg-[#ECC880] rounded-full shadow-md"
                  style={{ left: `${50 + simulatedDeviation * 15}%` }}
                />
              </div>

              <div className="flex justify-between text-[10px] font-mono-num text-slate-500">
                <span>-2.0 s/d (COSC Min)</span>
                <span className="text-emerald-400">0.0 s/d (Target)</span>
                <span>+2.0 s/d (COSC Max)</span>
              </div>
            </div>

            {/* Calibre Patents List */}
            <div className="space-y-3">
              <h4 className="text-xs font-mono-num uppercase tracking-widest text-[#E5C384]">
                Patented Horological Breakthroughs
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {calibre.innovations.map((inv, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-lg bg-[#121822] border border-slate-800 hover:border-[#C5A059]/40 transition-colors"
                  >
                    <h5 className="text-xs font-semibold text-slate-200">{inv.title}</h5>
                    <p className="text-[11px] text-slate-400 font-light mt-1 leading-relaxed">
                      {inv.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Movement Specs Table */}
            <div className="grid grid-cols-3 gap-3 p-4 rounded-lg bg-[#0E131C] border border-slate-800 text-center font-mono-num">
              <div>
                <span className="text-[10px] text-slate-500 block uppercase">Jewels</span>
                <span className="text-sm font-semibold text-[#ECC880]">{calibre.jewels}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block uppercase">Frequency</span>
                <span className="text-sm font-semibold text-[#ECC880]">{calibre.frequency.split(' ')[0]}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block uppercase">Power Reserve</span>
                <span className="text-sm font-semibold text-[#ECC880]">{calibre.powerReserveHours} Hours</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
