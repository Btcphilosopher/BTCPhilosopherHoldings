export interface WatchModel {
  id: string;
  name: string;
  family: string;
  tagline: string;
  reference: string;
  caseDiameter: string;
  material: string;
  bezel: string;
  dial: string;
  bracelet: string;
  calibre: string;
  powerReserve: string;
  waterResistance: string;
  priceCHF: number;
  priceUSD: number;
  priceEUR: number;
  description: string;
  heroHeadline: string;
  heroSubheading: string;
  specifications: {
    label: string;
    value: string;
  }[];
  image?: string;
  dialColorCode: string;
  bezelColorCode: string;
}

export const FEATURED_MODELS: WatchModel[] = [
  {
    id: 'datejust-41',
    name: 'Oyster Perpetual Datejust 41',
    family: 'Classic',
    tagline: 'An Icon, Reimagined',
    reference: 'M126334-0002',
    caseDiameter: '41 mm',
    material: 'White Rolesor (Oystersteel & 18 ct White Gold)',
    bezel: 'Fluted',
    dial: 'Bright Black, Sunray finish with 18 ct gold markers',
    bracelet: 'Jubilee, five-piece links',
    calibre: 'Calibre 3235, Manufacture Rolex',
    powerReserve: 'Approximately 70 hours',
    waterResistance: '100 metres / 330 feet',
    priceCHF: 10450,
    priceUSD: 10600,
    priceEUR: 10850,
    heroHeadline: 'PERPETUAL EXCELLENCE',
    heroSubheading: 'FOR OVER A CENTURY, ROLEX HAS DEFINED THE ART OF TIME. TODAY, WE CONTINUE TO SHAPE ITS FUTURE.',
    description: 'The archetype of the modern watch. Since 1945, the Datejust has been the hallmark of timeless classic elegance and precision horological function.',
    dialColorCode: '#111317',
    bezelColorCode: '#E0E2E6',
    specifications: [
      { label: 'Model Case', value: 'Oyster, 41 mm, Oystersteel and white gold' },
      { label: 'Oyster Architecture', value: 'Monobloc middle case, screw-down case back and winding crown' },
      { label: 'Diameter', value: '41 mm' },
      { label: 'Material', value: 'White Rolesor - combination of Oystersteel and white gold' },
      { label: 'Bezel', value: 'Fluted, 18 ct white gold' },
      { label: 'Winding Crown', value: 'Screw-down, Twinlock double waterproofness system' },
      { label: 'Crystal', value: 'Scratch-resistant sapphire, Cyclops lens over the date' },
      { label: 'Water Resistance', value: 'Waterproof to 100 metres / 330 feet' },
      { label: 'Movement', value: 'Perpetual, mechanical, self-winding' },
      { label: 'Calibre', value: '3235, Manufacture Rolex' },
      { label: 'Precision', value: '-2/+2 sec/day, after casing' },
      { label: 'Functions', value: 'Centre hour, minute and seconds hands. Instantaneous date with rapid setting.' },
      { label: 'Oscillator', value: 'Paramagnetic blue Parachrom hairspring. High-performance Paraflex shock absorbers.' },
      { label: 'Escapement', value: 'Chronergy with optimised energy efficiency' },
      { label: 'Winding', value: 'Bidirectional self-winding via Perpetual rotor' },
      { label: 'Power Reserve', value: 'Approximately 70 hours' },
      { label: 'Certification', value: 'Superlative Chronometer (COSC + Rolex certification after casing)' },
    ]
  },
  {
    id: 'submariner-date',
    name: 'Oyster Perpetual Submariner Date',
    family: 'Professional',
    tagline: 'The Reference Among Divers’ Watches',
    reference: 'M126610LN-0001',
    caseDiameter: '41 mm',
    material: 'Oystersteel (904L)',
    bezel: 'Unidirectional rotatable 60-minute graduated, Cerachrom in black ceramic',
    dial: 'Black with Chromalight display',
    bracelet: 'Oyster, flat three-piece links with Oysterlock safety clasp',
    calibre: 'Calibre 3235, Manufacture Rolex',
    powerReserve: 'Approximately 70 hours',
    waterResistance: '300 metres / 1,000 feet',
    priceCHF: 10100,
    priceUSD: 10250,
    priceEUR: 10500,
    heroHeadline: 'CONQUERING THE ABYSS',
    heroSubheading: 'ENGINEERED FOR THE DEEP, CELEBRATED FOR TIMELESS ELEGANCE ON LAND.',
    description: 'Launched in 1953, the Submariner was the first divers’ wristwatch waterproof to a depth of 100 metres. Now engineered to 300 metres with iconic Cerachrom ceramic.',
    dialColorCode: '#0A0C0E',
    bezelColorCode: '#1A1D20',
    specifications: [
      { label: 'Model Case', value: 'Oyster, 41 mm, Oystersteel' },
      { label: 'Bezel', value: 'Unidirectional rotatable 60-minute graduated, scratch-resistant Cerachrom insert in ceramic' },
      { label: 'Winding Crown', value: 'Screw-down, Triplock triple waterproofness system' },
      { label: 'Water Resistance', value: 'Waterproof to 300 metres / 1,000 feet' },
      { label: 'Calibre', value: '3235, Manufacture Rolex' },
      { label: 'Power Reserve', value: 'Approximately 70 hours' },
      { label: 'Clasp', value: 'Folding Oysterlock safety clasp with Rolex Glidelock extension system' }
    ]
  },
  {
    id: 'cosmograph-daytona',
    name: 'Oyster Perpetual Cosmograph Daytona',
    family: 'Professional',
    tagline: 'The Triumph of Endurance',
    reference: 'M126500LN-0001',
    caseDiameter: '40 mm',
    material: 'Oystersteel (904L)',
    bezel: 'Black Cerachrom in ceramic with tachymetric scale',
    dial: 'White lacquer with snailed counters',
    bracelet: 'Oyster, flat three-piece links',
    calibre: 'Calibre 4131, Manufacture Rolex',
    powerReserve: 'Approximately 72 hours',
    waterResistance: '100 metres / 330 feet',
    priceCHF: 14800,
    priceUSD: 15100,
    priceEUR: 15400,
    heroHeadline: 'BORN TO RACE',
    heroSubheading: 'AN UNRIVALLED CHRONOGRAPH FOR MOTORSPORT LEGENDS AND HIGH-SPEED PURSUITS.',
    description: 'The ultimate tool watch for those with a passion for driving and speed. Introduced in 1963 to meet the demands of professional racing drivers.',
    dialColorCode: '#F8F9FA',
    bezelColorCode: '#111316',
    specifications: [
      { label: 'Model Case', value: 'Oyster, 40 mm, Oystersteel' },
      { label: 'Bezel', value: 'Monobloc Cerachrom in black ceramic with moulded tachymetric scale' },
      { label: 'Calibre', value: '4131, Manufacture Rolex (Chronograph)' },
      { label: 'Precision', value: '-2/+2 sec/day' },
      { label: 'Functions', value: 'Centre hour and minute hands, small seconds hand at 6 o’clock. Chronograph accurate to 1/8 second.' },
      { label: 'Power Reserve', value: 'Approximately 72 hours' }
    ]
  },
  {
    id: 'day-date-40',
    name: 'Oyster Perpetual Day-Date 40',
    family: 'Classic',
    tagline: 'The Presidents’ Watch',
    reference: 'M228238-0006',
    caseDiameter: '40 mm',
    material: '18 ct Yellow Gold',
    bezel: 'Fluted, 18 ct Yellow Gold',
    dial: 'Champagne-colour, sunray finish',
    bracelet: 'President, semi-circular three-piece links with Crownclasp',
    calibre: 'Calibre 3255, Manufacture Rolex',
    powerReserve: 'Approximately 70 hours',
    waterResistance: '100 metres / 330 feet',
    priceCHF: 37400,
    priceUSD: 38500,
    priceEUR: 39200,
    heroHeadline: 'THE ULTIMATE EMBLEM',
    heroSubheading: 'WORN BY VISIONARIES, HEADS OF STATE, AND PIONEERS WHO SHAPE THE WORLD.',
    description: 'When it was launched in 1956, the Day-Date was a major innovation: it was the first calendar wristwatch to indicate, in addition to the date, the day of the week spelt out in full in an arc window.',
    dialColorCode: '#E5C27C',
    bezelColorCode: '#D9AE55',
    specifications: [
      { label: 'Model Case', value: 'Oyster, 40 mm, 18 ct yellow gold' },
      { label: 'Bezel', value: 'Fluted, 18 ct yellow gold' },
      { label: 'Bracelet', value: 'President, semi-circular three-piece links with ceramic inserts' },
      { label: 'Calibre', value: '3255, Manufacture Rolex' },
      { label: 'Day Display', value: 'Spelt out in full in choice of 26 languages' },
      { label: 'Power Reserve', value: 'Approximately 70 hours' }
    ]
  }
];

export interface CalibreDetails {
  id: string;
  name: string;
  type: string;
  jewels: number;
  frequency: string;
  vph: number;
  powerReserveHours: number;
  innovations: {
    title: string;
    description: string;
  }[];
  architecture: string;
}

export const CALIBRES: Record<string, CalibreDetails> = {
  '3235': {
    id: '3235',
    name: 'Rolex Calibre 3235',
    type: 'Self-winding mechanical movement',
    jewels: 31,
    frequency: '28,800 beats per hour (4 Hz)',
    vph: 28800,
    powerReserveHours: 70,
    architecture: 'Entirely developed and manufactured by Rolex, offering superlative performance in terms of precision, power reserve, resistance to shocks and magnetic fields.',
    innovations: [
      {
        title: 'Chronergy Escapement',
        description: 'Patented nickel-phosphorus escapement combining high energy efficiency with great dependability. Insensitive to magnetic interference.'
      },
      {
        title: 'Blue Parachrom Hairspring',
        description: 'Manufactured from an exclusive paramagnetic niobium-zirconium alloy. Up to 10 times more precise than a traditional hairspring in case of shocks.'
      },
      {
        title: 'Paraflex Shock Absorbers',
        description: 'Exclusive high-performance shock absorbers increasing movement shock resistance by 50%.'
      },
      {
        title: 'Perpetual Rotor',
        description: 'Bidirectional self-winding module maintaining constant mainspring tension during wrist movement.'
      }
    ]
  },
  '4131': {
    id: '4131',
    name: 'Rolex Calibre 4131',
    type: 'Self-winding chronograph movement',
    jewels: 47,
    frequency: '28,800 beats per hour (4 Hz)',
    vph: 28800,
    powerReserveHours: 72,
    architecture: 'A distilled masterpiece of chronograph engineering with simplified architecture, column wheel, vertical clutch, and Rolex Côtes de Genève decoration.',
    innovations: [
      {
        title: 'Column Wheel & Vertical Clutch',
        description: 'Instantaneous and crisp chronograph start with zero jitter on the seconds hand.'
      },
      {
        title: 'Optimized Ball Bearing Rotor',
        description: 'Cut-out oscillating weight with ceramic ball bearings for frictionless perpetual winding.'
      },
      {
        title: 'Rolex Côtes de Genève',
        description: 'Exclusive decorative finishing with polished bevels and golden Superlative engraving.'
      }
    ]
  }
};

export interface BoutiqueLocation {
  id: string;
  city: string;
  country: string;
  name: string;
  address: string;
  phone: string;
  timezone: string;
  utcOffset: number;
  lat: number;
  lng: number;
  services: string[];
}

export const BOUTIQUES: BoutiqueLocation[] = [
  {
    id: 'geneva-rhone',
    city: 'Geneva',
    country: 'Switzerland',
    name: 'Rolex Boutique — Rue du Rhône Flagship',
    address: 'Rue du Rhône 3, 1204 Genève',
    phone: '+41 22 818 22 00',
    timezone: 'Europe/Zurich',
    utcOffset: 1,
    lat: 46.2044,
    lng: 6.1432,
    services: ['Private Horological Salon', 'Master Watchmaker on Site', 'Bespoke Sizing & Fitting', 'Perpetual Care Servicing']
  },
  {
    id: 'london-bond',
    city: 'London',
    country: 'United Kingdom',
    name: 'Rolex Boutique — New Bond Street',
    address: '43-44 New Bond St, Mayfair, London W1S 2SA',
    phone: '+44 20 7493 2299',
    timezone: 'Europe/London',
    utcOffset: 0,
    lat: 51.5113,
    lng: -0.1444,
    services: ['VIP Viewing Lounge', 'Heritage Showcase', 'Authorised Service Reception']
  },
  {
    id: 'new-york-5th',
    city: 'New York',
    country: 'United States',
    name: 'Rolex Building — Fifth Avenue',
    address: '665 Fifth Avenue, New York, NY 10022',
    phone: '+1 212 758 7700',
    timezone: 'America/New_York',
    utcOffset: -5,
    lat: 40.7601,
    lng: -73.9748,
    services: ['Executive Atelier', 'Private Collector Suite', 'Master Horologist Consultation']
  },
  {
    id: 'tokyo-ginza',
    city: 'Tokyo',
    country: 'Japan',
    name: 'Rolex Boutique — Ginza',
    address: '6-10-1 Ginza, Chuo-ku, Tokyo 104-0061',
    phone: '+81 3 3571 8888',
    timezone: 'Asia/Tokyo',
    utcOffset: 9,
    lat: 35.6696,
    lng: 139.7634,
    services: ['Zen Viewing Garden Lounge', 'Crown Heritage Gallery', 'Precision Assessment']
  },
  {
    id: 'dubai-mall',
    city: 'Dubai',
    country: 'United Arab Emirates',
    name: 'Rolex Boutique — The Dubai Mall (Ahmed Seddiqi & Sons)',
    address: 'Fashion Avenue, Ground Floor, Dubai Mall',
    phone: '+971 4 339 8999',
    timezone: 'Asia/Dubai',
    utcOffset: 4,
    lat: 25.1972,
    lng: 55.2744,
    services: ['Royal Viewing Suite', 'Perpetual Archive Display', 'Private Valet & Concierge']
  },
  {
    id: 'paris-vendome',
    city: 'Paris',
    country: 'France',
    name: 'Rolex Boutique — Place Vendôme',
    address: '9 Place Vendôme, 75001 Paris',
    phone: '+33 1 40 15 12 00',
    timezone: 'Europe/Paris',
    utcOffset: 1,
    lat: 48.8675,
    lng: 2.3294,
    services: ['Haute Horlogerie Salon', 'Historic Archive Library', 'Custom Clasp Engraving']
  }
];

export interface HeritageMilestone {
  year: string;
  title: string;
  subtitle: string;
  narrative: string;
}

export const HERITAGE_MILESTONES: HeritageMilestone[] = [
  {
    year: '1905',
    title: 'The Vision of Hans Wilsdorf',
    subtitle: 'A Century of Uncompromising Pursuit',
    narrative: 'At age 24, Hans Wilsdorf foresaw that wristwatches could become not only elegant accessories, but instruments of utmost precision, robust enough for any endeavor.'
  },
  {
    year: '1926',
    title: 'The First Waterproof Watch: The Oyster',
    subtitle: 'Hermetic Innovation that Redefined Horology',
    narrative: 'Rolex created the first waterproof and dustproof wristwatch. To prove its resilience, Mercedes Gleitze swam the English Channel wearing the Oyster, emerging with the watch in flawless working order.'
  },
  {
    year: '1931',
    title: 'The Perpetual Rotor',
    subtitle: 'The Birth of Modern Automatic Winding',
    narrative: 'Rolex invented and patented the world’s first self-winding mechanism with a free rotor: the Perpetual rotor. This system forms the heart of every modern automatic timepiece today.'
  },
  {
    year: '1953',
    title: 'Summit of Mount Everest & The Submariner',
    subtitle: 'Living Laboratories on Earth’s Extremes',
    narrative: 'Sir Edmund Hillary and Tenzing Norgay summited Mount Everest equipped with Rolex Oyster Perpetuals. That same year, Rolex unveiled the Submariner, the pioneer of deep-sea exploration.'
  },
  {
    year: '1963',
    title: 'The Cosmograph Daytona',
    subtitle: 'Engineered for High-Speed Endurance',
    narrative: 'Designed for endurance racing drivers, featuring a high-contrast tachymetric bezel and precision chronograph, forever linking Rolex to the legendary Daytona International Speedway.'
  },
  {
    year: 'Present',
    title: 'The Perpetual Quest',
    subtitle: 'Mastery of Materials and Calibres',
    narrative: 'From proprietary Oystersteel 904L and 18 ct Everose gold cast in our private foundry, to the Superlative Chronometer standard with -2/+2 seconds daily tolerance.'
  }
];
