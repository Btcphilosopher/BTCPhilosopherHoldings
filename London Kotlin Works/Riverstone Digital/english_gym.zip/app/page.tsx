'use client';

import React, { useState, useEffect } from 'react';
import { Navbar } from '@/components/Navbar';
import { HeroSection } from '@/components/HeroSection';
import { HomepageCards } from '@/components/HomepageCards';
import { BrandStatement } from '@/components/BrandStatement';
import { MembershipSection } from '@/components/MembershipSection';
import { FacilitiesSection } from '@/components/FacilitiesSection';
import { TrainingSection } from '@/components/TrainingSection';
import { WellnessSection } from '@/components/WellnessSection';
import { AboutSection } from '@/components/AboutSection';
import { LocationFinder } from '@/components/LocationFinder';
import { MembershipModal } from '@/components/MembershipModal';
import { SearchModal } from '@/components/SearchModal';
import { Footer } from '@/components/Footer';

export default function HomePage() {
  const [activeSection, setActiveSection] = useState<string>('hero');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isMembershipModalOpen, setIsMembershipModalOpen] = useState(false);
  const [preselectedTier, setPreselectedTier] = useState<string>('premier');
  const [preselectedCity, setPreselectedCity] = useState<string>('London');

  // Handle section scrolling
  const scrollToSection = (sectionId: string) => {
    setActiveSection(sectionId);
    if (sectionId === 'hero') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    const elem = document.getElementById(sectionId);
    if (elem) {
      const navOffset = 80;
      const elementPosition = elem.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - navOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
    }
  };

  // Intersection observer to keep activeSection updated during scroll
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['hero', 'membership', 'facilities', 'training', 'wellness', 'about', 'locations'];
      const scrollPosition = window.scrollY + 120;

      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleOpenJoinModal = (tierId = 'premier', city = 'London') => {
    setPreselectedTier(tierId);
    setPreselectedCity(city);
    setIsMembershipModalOpen(true);
  };

  const handleSelectCityFromHero = (city: string) => {
    setPreselectedCity(city);
    scrollToSection('locations');
  };

  return (
    <main className="min-h-screen bg-[#07121B] text-[#F0EBDD] selection:bg-[#C6A46A] selection:text-[#07121B]">
      {/* Fixed Sophisticated Header */}
      <Navbar
        activeSection={activeSection}
        onNavigate={scrollToSection}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenJoinModal={handleOpenJoinModal}
      />

      {/* Hero Section */}
      <HeroSection
        onJoinClick={() => handleOpenJoinModal('premier')}
        onExploreFacilities={() => scrollToSection('facilities')}
        onSelectLocation={handleSelectCityFromHero}
      />

      {/* Homepage Pillars (3 Large Editorial Cards) */}
      <HomepageCards
        onNavigateSection={scrollToSection}
        onOpenCardDetail={(index) => {
          if (index === 0) scrollToSection('facilities');
          else if (index === 1) scrollToSection('training');
          else scrollToSection('wellness');
        }}
      />

      {/* Brand Statement with Sunset Architectural Image */}
      <BrandStatement
        onBecomeMember={() => handleOpenJoinModal('founders')}
        onReadManifesto={() => scrollToSection('about')}
      />

      {/* Membership Echelons Section */}
      <MembershipSection
        onSelectTierForApplication={(tierId) => handleOpenJoinModal(tierId)}
      />

      {/* 10 Detailed Architectural Facilities Section */}
      <FacilitiesSection
        onJoinClick={() => handleOpenJoinModal('premier')}
      />

      {/* Sports Science & Athletic Coaching Section */}
      <TrainingSection
        onBookAssessment={(coachName, discipline) =>
          handleOpenJoinModal('founders', preselectedCity)
        }
      />

      {/* Wellness Sanctuary & Longevity Diagnostic Section */}
      <WellnessSection
        onJoinClick={() => handleOpenJoinModal('premier')}
        onBookTreatment={() => handleOpenJoinModal('premier')}
      />

      {/* About The English Gym - Brand Manifesto */}
      <AboutSection
        onJoinClick={() => handleOpenJoinModal('standard')}
      />

      {/* Interactive UK Locations Finder & Directory */}
      <LocationFinder
        selectedCity={preselectedCity}
        onScheduleClubTour={(city) => handleOpenJoinModal('premier', city)}
      />

      {/* Footer */}
      <Footer
        onNavigate={scrollToSection}
        onJoinClick={() => handleOpenJoinModal('premier')}
      />

      {/* Interactive Membership Application Modal */}
      <MembershipModal
        isOpen={isMembershipModalOpen}
        onClose={() => setIsMembershipModalOpen(false)}
        defaultTierId={preselectedTier}
        defaultCity={preselectedCity}
      />

      {/* Interactive Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onNavigateTo={scrollToSection}
      />
    </main>
  );
}
