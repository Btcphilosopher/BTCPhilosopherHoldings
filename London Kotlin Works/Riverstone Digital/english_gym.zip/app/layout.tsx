import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'The English Gym | A Higher Standard',
  description:
    'A supermodernist British fitness and wellness club combining British architectural heritage, contemporary luxury, advanced sports science, and longevity.',
  keywords: [
    'The English Gym',
    'British fitness club',
    'Luxury gym London',
    'Sports science',
    'Longevity centre',
    'British wellness club',
  ],
  openGraph: {
    title: 'The English Gym | A Higher Standard',
    description:
      'Supermodernist British Fitness & Wellness Club. Strength. Discipline. Longevity.',
    type: 'website',
    locale: 'en_GB',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'The English Gym | A Higher Standard',
    description:
      'Supermodernist British Fitness & Wellness Club. Strength. Discipline. Longevity.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="bg-[#07121B] text-[#F0EBDD] antialiased selection:bg-[#C6A46A] selection:text-[#07121B]" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
