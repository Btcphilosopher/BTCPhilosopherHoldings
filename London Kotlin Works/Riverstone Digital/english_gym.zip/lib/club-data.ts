export interface MembershipTier {
  id: string;
  name: string;
  tagline: string;
  monthlyPrice: number;
  annualPrice: number;
  featured?: boolean;
  features: string[];
  exclusivePerks: string[];
  accessHours: string;
}

export interface FacilityItem {
  id: string;
  title: string;
  category: 'strength' | 'aquatics' | 'athletics' | 'wellness' | 'specialized';
  subtitle: string;
  description: string;
  specs: string[];
  equipmentHighlights: string[];
  image: string;
  fallbackGradient: string;
}

export interface TrainingDiscipline {
  id: string;
  title: string;
  focus: string;
  description: string;
  sportsScienceRationale: string;
  duration: string;
  intensity: 'High' | 'Moderate-High' | 'Precision' | 'Restorative';
  keyOutcomes: string[];
}

export interface CoachProfile {
  id: string;
  name: string;
  role: string;
  credentials: string;
  specialties: string[];
  bio: string;
  background: string;
  initials: string;
}

export interface WellnessTherapy {
  id: string;
  title: string;
  subhead: string;
  description: string;
  physiologicalBenefits: string[];
  recommendedFrequency: string;
  temperature?: string;
}

export interface ClubLocation {
  id: string;
  city: string;
  district: string;
  address: string;
  postcode: string;
  hours: {
    weekdays: string;
    saturday: string;
    sunday: string;
  };
  phone: string;
  email: string;
  metro: string;
  sizeSqFt: string;
  highlights: string[];
  availableMemberships: string[];
  status: 'Open' | 'Accepting Founding Members';
  coordinates: { x: number; y: number }; // percentage on UK schematic map
}

export const MEMBERSHIP_TIERS: MembershipTier[] = [
  {
    id: 'standard',
    name: 'THE STANDARD',
    tagline: 'The uncompromising foundation of British physical discipline.',
    monthlyPrice: 195,
    annualPrice: 1990,
    features: [
      'Full gym floor & free-weight hall access',
      'Advanced Olympic lifting platforms',
      'Comprehensive functional training areas',
      'All signature group conditioning classes',
      'Luxurious oak & marble changing suites',
      'Towel service & grooming amenities',
    ],
    exclusivePerks: [
      'Bi-annual body composition screening',
      'Access to The English Gym digital companion app',
    ],
    accessHours: '05:30 – 23:00 Daily',
  },
  {
    id: 'premier',
    name: 'THE PREMIER',
    tagline: 'Complete athletic conditioning with world-class thermal recovery.',
    monthlyPrice: 340,
    annualPrice: 3470,
    featured: true,
    features: [
      'Full facility access across all UK locations',
      '25m heated lap pool & hydrotherapy suites',
      'Sauna, Finnish cedar room & steam suites',
      'Cold water immersion plunge pools (3°C)',
      'Monthly 1-on-1 sports science consultation',
      'Priority 14-day class booking window',
      'Complimentary garment laundry service',
    ],
    exclusivePerks: [
      'Quarterly VO2 max & metabolic assessment',
      '2 complimentary guest invitations per month',
      'Access to member quiet workspaces & library',
    ],
    accessHours: '24/7 Unrestricted Keycard Access',
  },
  {
    id: 'founders',
    name: "THE FOUNDERS' CLUB",
    tagline: 'The pinnacle of bespoke sports science, privacy, and longevity.',
    monthlyPrice: 650,
    annualPrice: 6630,
    features: [
      'Strictly limited to 75 members per club',
      'Dedicated Senior Performance Coach assigned',
      'Weekly 1-on-1 private training suite sessions',
      'Clinical physiotherapy & sports massage credits',
      'Full clinical biomarker & DEXA body scans',
      'Personalized longevity & sleep architecture protocol',
      'Private valet parking & secure kit lockers',
      'Access to private member dining & boardroom',
    ],
    exclusivePerks: [
      'Annual private retreat at English countryside estate',
      'Dedicated concierge direct mobile line',
      'Bespoke monogrammed British leather gym duffle',
    ],
    accessHours: '24/7 Concierge-Supported Private Access',
  },
];

export const FACILITIES: FacilityItem[] = [
  {
    id: 'strength-halls',
    title: 'Strength & Weightlifting Halls',
    category: 'strength',
    subtitle: 'Forged in heavy British steel and calibrated Scandinavian iron.',
    description:
      'Engineered for purposeful progression. Handcrafted solid English oak lifting decks, Eleiko calibrated competition bumpers, custom matte-black steel power cages, and dumbbells ranging from 2kg to 70kg in precision knurled steel.',
    specs: ['6,500 sq ft hall floor', 'Eleiko IPF-certified bars', 'Anti-vibration acoustic substructure'],
    equipmentHighlights: ['Bespoke Sheffield steel racks', 'Watson animal leg presses', 'Calibrated steel fractional plates'],
    image: '/images/strength_hall.jpg',
    fallbackGradient: 'from-[#111C25] to-[#183D35]',
  },
  {
    id: 'cardiovascular-suite',
    title: 'Cardiovascular Training Suite',
    category: 'athletics',
    subtitle: 'Floor-to-ceiling panoramic glass facing the historic skyline.',
    description:
      'Conditioning designed around human physiology. Non-motorized Woodway curve treadmills, Wattbike Atoms with pedal stroke biometric feedback, Concept2 SkiErgs, and fluid rowers, flooded with natural daylight.',
    specs: ['40+ precision aerobic stations', 'Real-time telemetry pairing', 'Filtered HEPA air circulation'],
    equipmentHighlights: ['Woodway 4Front & Curve treadmills', 'Wattbike Pro smart trainers', 'WaterRower club ash series'],
    image: '/images/hero_gym.jpg',
    fallbackGradient: 'from-[#07121B] to-[#111C25]',
  },
  {
    id: 'olympic-platforms',
    title: 'Olympic Lifting Platforms',
    category: 'strength',
    subtitle: 'Competition-grade platforms with high-speed bar tracking.',
    description:
      'Eight competition lifting stations featuring inlaid oak platforms, friction-reduced bearings, IWF tournament bars, and optical velocity-based training cameras to measure barbell speed, bar path, and peak power output.',
    specs: ['8 competition platforms', 'GymAware VBT optical sensors', 'Full set of jerk boxes and pulling blocks'],
    equipmentHighlights: ['Eleiko IWF Competition barbells', 'Calibrated disc sets', 'Solid oak inset flooring'],
    image: '/images/strength_hall.jpg',
    fallbackGradient: 'from-[#183D35] to-[#07121B]',
  },
  {
    id: 'athletics-track',
    title: 'Indoor Athletics Sprint Track',
    category: 'athletics',
    subtitle: '60-metre high-rebound synthetic sprint track with laser timing gates.',
    description:
      'A dedicated indoor speed track finished in regulation British racing green athletic rubber. Equipped with dual-beam optical gates for precise acceleration testing, sled pushes, and ballistic plyometric drills.',
    specs: ['60m straight with deceleration zone', 'Dual-beam timing gates', 'Heavy-load sled turf lane'],
    equipmentHighlights: ['Freelap optical timing hubs', 'Dog sleds & prowlers with brass skids', 'Plyometric wooden boxes'],
    image: '/images/coaching_track.jpg',
    fallbackGradient: 'from-[#183D35] to-[#111C25]',
  },
  {
    id: 'swimming-hydrotherapy',
    title: '25m Lap Pool & Hydrotherapy',
    category: 'aquatics',
    subtitle: 'Acoustically dampened natural limestone water sanctuary.',
    description:
      'A tranquil 25-metre ozone-purified lap pool maintained at a constant 28°C for athletic swimming, alongside hydrotherapy vitality jets, underwater massage loungers, and mineral relaxation basins.',
    specs: ['25m x 10m four-lane pool', 'Low-chlorine UV ozone sanitation', 'Acoustic baffle ceiling tiles'],
    equipmentHighlights: ['Counter-current swim jets', 'Hydro-massage reflexology wall', 'Deep-tissue water cascades'],
    image: '/images/wellness_pool.jpg',
    fallbackGradient: 'from-[#07121B] to-[#183D35]',
  },
  {
    id: 'boxing-martial-arts',
    title: 'Boxing & Combat Studio',
    category: 'specialized',
    subtitle: 'Rooted in the noble English prize-fighting tradition.',
    description:
      'A bespoke boxing hall with a regulation 18-foot elevated ring, handcrafted English saddle leather punch bags, water teardrop bags, and vintage speedballs. Coached by former amateur champions and tactical conditioning coaches.',
    specs: ['18ft elevated competition ring', '12 suspended leather heavy bags', 'Dedicated shadow-boxing mirror hall'],
    equipmentHighlights: ['Cleto Reyes heavy leather bags', 'Title slip balls', 'Bespoke canvas ring surface'],
    image: '/images/coaching_track.jpg',
    fallbackGradient: 'from-[#111C25] to-[#07121B]',
  },
  {
    id: 'functional-fitness',
    title: 'Functional Fitness & Movement Arena',
    category: 'strength',
    subtitle: 'Unrestricted open floor space for multidirectional human power.',
    description:
      'High-ceiling arena equipped with ceiling-hung competition gymnastic rings, climbing ropes, cast-iron kettlebells forged in England, custom assault bikes, and soft-drop impact flooring.',
    specs: ['4,000 sq ft open turf & rubber zone', 'Ceiling-suspended ring rigging', 'Comprehensive kettlebell bells to 48kg'],
    equipmentHighlights: ['Rogue Echo bikes', 'Natural Manila climbing ropes', 'Custom cast iron bell series'],
    image: '/images/hero_gym.jpg',
    fallbackGradient: 'from-[#07121B] to-[#183D35]',
  },
  {
    id: 'private-suites',
    title: 'Private Training Suites',
    category: 'specialized',
    subtitle: 'Secluded athletic sanctuaries for focused, distraction-free sessions.',
    description:
      'Discreet, self-contained training suites equipped with private squat racks, bespoke dumbell racks, sound isolation, and private en-suite showers. Favoured by high-profile members, executives, and Founders Club patrons.',
    specs: ['4 private self-contained suites', 'Private Bluetooth audio zones', 'En-suite shower & steam cubicle'],
    equipmentHighlights: ['Compact all-in-one Eleiko unit', 'Private cardio ergometer', 'Personal recovery pod'],
    image: '/images/strength_hall.jpg',
    fallbackGradient: 'from-[#111C25] to-[#07121B]',
  },
  {
    id: 'recovery-rehab',
    title: 'Recovery & Thermal Wing',
    category: 'wellness',
    subtitle: 'Advanced contrast therapy, Finnish saunas, and cryogenic immersion.',
    description:
      'Where cellular adaptation happens. High-heat dry cedar saunas (90°C), eucalyptus steam rooms, stainless steel cold plunge tubs maintained at 3°C, and compression boot lounge chairs with dim architectural lighting.',
    specs: ['Dual Finnish cedar saunas', 'Twin 3°C cold plunge tubs', '8-chair NormaTec compression lounge'],
    equipmentHighlights: ['Harvia commercial heaters', 'Chilled filtered water immersion', 'Hyperice vibration suites'],
    image: '/images/wellness_pool.jpg',
    fallbackGradient: 'from-[#183D35] to-[#07121B]',
  },
  {
    id: 'outdoor-gardens',
    title: 'Rooftop & Outdoor Training Gardens',
    category: 'specialized',
    subtitle: 'Open-air conditioning amidst British flora and skyline horizons.',
    description:
      'All-weather landscaped outdoor terraces featuring weathered stone pavers, covered calisthenics rigs, sprint turf, and warm radiant heaters for bracing winter morning workouts under English skies.',
    specs: ['Rooftop panoramic vista', 'All-weather non-slip heated turf', 'Infrared radiant overhead heating'],
    equipmentHighlights: ['Custom weatherized steel rig', 'Outdoor kettlebell racks', 'Calisthenics bar park'],
    image: '/images/sunset_building.jpg',
    fallbackGradient: 'from-[#111C25] to-[#183D35]',
  },
];

export const COACHES: CoachProfile[] = [
  {
    id: 'alistair-vance',
    name: 'Alistair Vance, MSc',
    role: 'Director of Performance & Sports Science',
    credentials: 'MSc Applied Sports Biomechanics (Loughborough), UKSCA Master Coach',
    specialties: ['Olympic Weightlifting', 'Barbell Velocity Training', 'Postural Restoration'],
    bio: 'Former senior athletic coach for British Rowing and Team GB Track & Field. Alistair leads The English Gym sports science methodology, blending empirical laboratory data with classic British physical discipline.',
    background: '16 years coaching elite Olympians and discerning private clients.',
    initials: 'AV',
  },
  {
    id: 'eleanor-sinclair',
    name: 'Dr. Eleanor Sinclair, PhD',
    role: 'Head of Longevity & Metabolic Health',
    credentials: 'PhD Exercise Physiology (Oxford), Fellow of the Royal Society of Medicine',
    specialties: ['Cardiorespiratory VO2 Max', 'Mitochondrial Biogenesis', 'Nutritional Biochemistry'],
    bio: 'Pioneering researcher in cellular senescence and metabolic optimization. Dr. Sinclair oversees member biomarker profiling, designing customized protocols that marry rigorous physical training with systemic longevity.',
    background: 'Author of 24 peer-reviewed clinical papers on longevity in athletic populations.',
    initials: 'ES',
  },
  {
    id: 'marcus-holloway',
    name: 'Marcus Holloway',
    role: 'Head of Combat & Strength Conditioning',
    credentials: 'Former Commonwealth Boxing Medalist, CSCS Certified',
    specialties: ['Traditional English Boxing', 'Rotational Power', 'High-Threshold Conditioning'],
    bio: 'Marcus teaches the pure art of boxing combined with heavy compound lifting. His sessions emphasize precision footwork, tactical cadence, and mental resolve under cardiovascular pressure.',
    background: '12 years in professional combat sports conditioning and youth athletic development.',
    initials: 'MH',
  },
  {
    id: 'beatrice-morley',
    name: 'Beatrice Morley',
    role: 'Master Reformer & Structural Alignment Lead',
    credentials: 'Comprehensive Classical Pilates (London), Polestar Rehabilitation Specialist',
    specialties: ['Spinal Articulation', 'Core Stability & Pelvic Integrity', 'Injury Rehabilitation'],
    bio: 'Specializing in structural alignment and neuromuscular control for athletes and sedentary executives alike. Beatrice restores mechanical symmetry to unlock pain-free power.',
    background: 'Former classical ballet soloist turned rehabilitation specialist.',
    initials: 'BM',
  },
];

export const WELLNESS_THERAPIES: WellnessTherapy[] = [
  {
    id: 'finnish-sauna',
    title: 'Finnish Dry Cedar Sauna',
    subhead: 'Deep thermal vascular dilation and heat shock protein activation.',
    description:
      'Engineered with sustainable Nordic red cedar and Finnish volcanic peridotite stones. Exposure to 85°C–95°C activates heat shock proteins (Hsp70), increases plasma growth hormone, and accelerates muscle repair.',
    physiologicalBenefits: [
      'Upregulates cellular repair mechanisms',
      'Improves vascular endothelial function',
      'Deep autonomic nervous system relaxation',
    ],
    recommendedFrequency: '3–4 sessions per week (15–20 min)',
    temperature: '88°C – 95°C',
  },
  {
    id: 'cold-immersion',
    title: 'Cold Water Immersion Plunge',
    subhead: 'Rapid vasoconstriction, dopamine elevation, and systemic anti-inflammation.',
    description:
      'Ultra-chilled, constantly circulating mineral water maintained at exactly 3°C. Triggers a potent 250% surge in baseline norepinephrine and dopamine, dampening inflammatory cytokines and sharpening mental fortitude.',
    physiologicalBenefits: [
      'Rapid suppression of muscular inflammation',
      'Sustained mental alertness and catecholamine release',
      'Vagus nerve stimulation and stress resilience',
    ],
    recommendedFrequency: '2–3 sessions per week (2–4 min)',
    temperature: '3°C (37°F)',
  },
  {
    id: 'sports-physiotherapy',
    title: 'Clinical Physiotherapy & Biomechanics',
    subhead: 'Root-cause mechanical analysis and manual therapy by chartered practitioners.',
    description:
      'Our chartered physiotherapists conduct comprehensive 3D gait screenings, joint mobilization, dry needling, and targeted corrective exercise prescriptions to eliminate chronic pain and restore joint freedom.',
    physiologicalBenefits: [
      'Resolution of chronic kinetic chain dysfunction',
      'Restoration of optimal joint range of motion',
      'Targeted return-to-performance protocols',
    ],
    recommendedFrequency: 'Monthly maintenance or weekly rehabilitative blocks',
  },
  {
    id: 'sports-massage',
    title: 'Deep Tissue & Myofascial Release',
    subhead: 'Targeted manipulation of deep fascial sheaths and neuromuscular trigger points.',
    description:
      'Delivered by specialized soft tissue therapists. Releases entrenched muscular tension, promotes venous return, and restores natural tissue glide following high-intensity training.',
    physiologicalBenefits: [
      'Alleviates delayed onset muscle soreness (DOMS)',
      'Breaks down cross-linked collagen scar adhesions',
      'Improves local tissue oxygenation and lymphatic flow',
    ],
    recommendedFrequency: 'Bi-weekly or post-competition',
  },
  {
    id: 'longevity-assessments',
    title: 'Biomarker, DEXA & VO2 Max Profiling',
    subhead: 'The quantitative gold standard in predictive physical longevity.',
    description:
      'Medical-grade physiological evaluation combining true metabolic gas exchange VO2 max testing, Hologic dual-energy X-ray absorptiometry (DEXA) for visceral fat and bone density, and continuous heart rate variability tracking.',
    physiologicalBenefits: [
      'Accurate biological vs chronological age measurement',
      'Pinpoint anaerobic and aerobic metabolic thresholds',
      'Actionable data-driven training prescription',
    ],
    recommendedFrequency: 'Every 6 months',
  },
];

export const CLUB_LOCATIONS: ClubLocation[] = [
  {
    id: 'london-mayfair',
    city: 'London',
    district: 'Mayfair & The City',
    address: '14 Berkeley Square & 28 Cornhill',
    postcode: 'W1J 6BQ / EC3V 3ND',
    hours: {
      weekdays: '05:30 – 23:30',
      saturday: '06:30 – 22:00',
      sunday: '07:30 – 21:00',
    },
    phone: '+44 (0)20 7946 0880',
    email: 'mayfair@theenglishgym.co.uk',
    metro: 'Green Park & Bank Stations (3 min walk)',
    sizeSqFt: '28,000 sq ft',
    highlights: ['Panoramic London skyline view', '25m limestone lap pool', 'Private boardroom & member library', 'Dedicated valet'],
    availableMemberships: ['Standard', 'Premier', 'Founders Club'],
    status: 'Open',
    coordinates: { x: 74, y: 78 },
  },
  {
    id: 'manchester',
    city: 'Manchester',
    district: "St. John's Cultural Quarter",
    address: 'Goods Yard, Enterprise Way',
    postcode: 'M3 4EZ',
    hours: {
      weekdays: '05:30 – 23:00',
      saturday: '07:00 – 22:00',
      sunday: '08:00 – 20:00',
    },
    phone: '+44 (0)161 832 9100',
    email: 'manchester@theenglishgym.co.uk',
    metro: 'Deansgate / Spinningfields',
    sizeSqFt: '24,500 sq ft',
    highlights: ['Industrial heritage brick & glass architecture', '60m indoor sprint track', 'Full contrast therapy zone'],
    availableMemberships: ['Standard', 'Premier', 'Founders Club'],
    status: 'Open',
    coordinates: { x: 55, y: 55 },
  },
  {
    id: 'birmingham',
    city: 'Birmingham',
    district: 'Colmore Business District',
    address: '55 Colmore Row',
    postcode: 'B3 2AA',
    hours: {
      weekdays: '06:00 – 22:30',
      saturday: '07:30 – 21:00',
      sunday: '08:00 – 20:00',
    },
    phone: '+44 (0)121 236 4480',
    email: 'birmingham@theenglishgym.co.uk',
    metro: 'Snow Hill & New Street (4 min walk)',
    sizeSqFt: '21,000 sq ft',
    highlights: ['Victorian grand banking hall reimagined', 'Eleiko weightlifting amphitheatre', 'Thermal hydrotherapy'],
    availableMemberships: ['Standard', 'Premier', 'Founders Club'],
    status: 'Open',
    coordinates: { x: 58, y: 65 },
  },
  {
    id: 'edinburgh',
    city: 'Edinburgh',
    district: 'New Town Heritage Quarter',
    address: '32 Charlotte Square',
    postcode: 'EH2 4ET',
    hours: {
      weekdays: '06:00 – 22:30',
      saturday: '07:00 – 21:00',
      sunday: '08:00 – 20:00',
    },
    phone: '+44 (0)131 556 7200',
    email: 'edinburgh@theenglishgym.co.uk',
    metro: 'Princes Street Tram (3 min walk)',
    sizeSqFt: '22,000 sq ft',
    highlights: ['Georgian sandstone pavilion with modernist glass wing', 'Cold Scottish plunge ritual', 'Private coaching suites'],
    availableMemberships: ['Standard', 'Premier', 'Founders Club'],
    status: 'Open',
    coordinates: { x: 50, y: 32 },
  },
  {
    id: 'leeds',
    city: 'Leeds',
    district: 'Wellington Place',
    address: '3 Wellington Place',
    postcode: 'LS1 4AP',
    hours: {
      weekdays: '06:00 – 22:30',
      saturday: '07:30 – 21:00',
      sunday: '08:00 – 20:00',
    },
    phone: '+44 (0)113 245 8820',
    email: 'leeds@theenglishgym.co.uk',
    metro: 'Leeds Central (5 min walk)',
    sizeSqFt: '19,500 sq ft',
    highlights: ['Yorkshire stone facade', 'Olympic lifting mezzanine', 'Infrared recovery sanctuary'],
    availableMemberships: ['Standard', 'Premier'],
    status: 'Open',
    coordinates: { x: 62, y: 52 },
  },
  {
    id: 'bristol',
    city: 'Bristol',
    district: 'Clifton Village',
    address: '18 The Mall, Clifton',
    postcode: 'BS8 4DR',
    hours: {
      weekdays: '06:00 – 22:00',
      saturday: '07:30 – 20:30',
      sunday: '08:00 – 19:30',
    },
    phone: '+44 (0)117 973 1150',
    email: 'bristol@theenglishgym.co.uk',
    metro: 'Clifton Down (10 min walk)',
    sizeSqFt: '18,000 sq ft',
    highlights: ['Outdoor training garden with gorge view', 'Specialized reformer Pilates', 'Ozone hydrotherapy pool'],
    availableMemberships: ['Standard', 'Premier'],
    status: 'Open',
    coordinates: { x: 45, y: 77 },
  },
  {
    id: 'oxford',
    city: 'Oxford',
    district: 'St Giles’ Quarter',
    address: '42 St Giles’',
    postcode: 'OX1 3LW',
    hours: {
      weekdays: '06:00 – 22:00',
      saturday: '07:30 – 21:00',
      sunday: '08:00 – 20:00',
    },
    phone: '+44 (0)1865 244 900',
    email: 'oxford@theenglishgym.co.uk',
    metro: 'Oxford Railway (8 min walk)',
    sizeSqFt: '17,500 sq ft',
    highlights: ['Rowing & endurance sports science lab', 'Oak-panelled member study', 'Bespoke Eleiko equipment'],
    availableMemberships: ['Standard', 'Premier', 'Founders Club'],
    status: 'Open',
    coordinates: { x: 64, y: 72 },
  },
  {
    id: 'cambridge',
    city: 'Cambridge',
    district: 'Station Square',
    address: '2 Station Square',
    postcode: 'CB1 2GA',
    hours: {
      weekdays: '06:00 – 22:30',
      saturday: '07:00 – 21:00',
      sunday: '08:00 – 20:00',
    },
    phone: '+44 (0)1223 358 600',
    email: 'cambridge@theenglishgym.co.uk',
    metro: 'Cambridge Station (1 min walk)',
    sizeSqFt: '19,000 sq ft',
    highlights: ['Biomarker & metabolic testing laboratory', '20m lap pool', 'Acoustic meditation lounge'],
    availableMemberships: ['Standard', 'Premier', 'Founders Club'],
    status: 'Open',
    coordinates: { x: 77, y: 68 },
  },
];
