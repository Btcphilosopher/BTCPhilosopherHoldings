'use client';

import React, { useState, useEffect } from 'react';
import { HeraldicLogo } from './HeraldicLogo';
import { Search, Menu, X, ArrowRight } from 'lucide-react';

interface NavbarProps {
  activeSection: string;
  onNavigate: (sectionId: string) => void;
  onOpenSearch: () => void;
  onOpenJoinModal: (tierId?: string) => void;
}

const NAV_ITEMS = [
  { id: 'hero', label: 'Home' },
  { id: 'membership', label: 'Membership' },
  { id: 'facilities', label: 'Facilities' },
  { id: 'training', label: 'Training' },
  { id: 'wellness', label: 'Wellness' },
  { id: 'about', label: 'About' },
  { id: 'locations', label: 'Locations' },
];

export function Navbar({
  activeSection,
  onNavigate,
  onOpenSearch,
  onOpenJoinModal,
}: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLinkClick = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'bg-[#07121B]/95 backdrop-blur-md border-b border-[#C6A46A]/20 shadow-2xl py-3.5'
            : 'bg-gradient-to-b from-[#07121B]/90 via-[#07121B]/60 to-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-4 lg:gap-8">
            {/* Left Zone: Heraldic Shield & Brand Lockup */}
            <button
              onClick={() => handleLinkClick('hero')}
              className="text-left focus:outline-none focus-visible:ring-1 focus-visible:ring-[#C6A46A] rounded transition-transform hover:scale-[1.01]"
              aria-label="The English Gym Home"
            >
              <HeraldicLogo size="md" showTagline={true} />
            </button>

            {/* Centre Zone: Primary Navigation Links */}
            <nav className="hidden xl:flex items-center gap-7 text-xs uppercase tracking-[0.16em] font-medium text-[#89949A]">
              {NAV_ITEMS.map((item) => {
                const isActive = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleLinkClick(item.id)}
                    className={`relative py-1 whitespace-nowrap transition-colors duration-200 hover:text-[#F0EBDD] focus:outline-none focus-visible:text-[#C6A46A] ${
                      isActive ? 'text-[#C6A46A] font-semibold' : ''
                    }`}
                  >
                    {item.label}
                    {isActive && (
                      <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#C6A46A]" />
                    )}
                  </button>
                );
              })}
            </nav>

            {/* Right Zone: Search, Join CTA & Hamburger */}
            <div className="flex items-center gap-3 shrink-0">
              {/* Search Trigger */}
              <button
                onClick={onOpenSearch}
                aria-label="Search facilities, coaching, and memberships"
                className="p-2.5 rounded text-[#89949A] hover:text-[#C6A46A] hover:bg-[#111C25]/80 transition-colors focus:outline-none focus-visible:ring-1 focus-visible:ring-[#C6A46A]"
              >
                <Search className="w-4 h-4" />
              </button>

              {/* Primary Action Button */}
              <button
                onClick={() => onOpenJoinModal()}
                className="hidden sm:inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold uppercase tracking-[0.18em] text-[#07121B] bg-[#C6A46A] hover:bg-[#D9B87F] rounded transition-all duration-200 shadow-[0_2px_12px_rgba(198,164,106,0.3)] hover:shadow-[0_4px_20px_rgba(198,164,106,0.45)] whitespace-nowrap"
              >
                <span>Join Now</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              {/* Hamburger Button for Mobile / Tablet */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                aria-label="Toggle Navigation Menu"
                className="xl:hidden p-2.5 text-[#F0EBDD] hover:text-[#C6A46A] hover:bg-[#111C25]/80 rounded transition-colors focus:outline-none focus-visible:ring-1 focus-visible:ring-[#C6A46A]"
              >
                {mobileMenuOpen ? (
                  <X className="w-5 h-5 text-[#C6A46A]" />
                ) : (
                  <Menu className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile / Tablet Menu Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-[#07121B]/95 backdrop-blur-xl pt-24 pb-8 px-6 flex flex-col justify-between xl:hidden border-b border-[#C6A46A]/20">
          <div className="space-y-4 max-w-md mx-auto w-full pt-4">
            <div className="text-[10px] uppercase tracking-[0.24em] text-[#C6A46A] font-semibold border-b border-[#C6A46A]/20 pb-2">
              Club Navigation
            </div>
            <nav className="flex flex-col space-y-3">
              {NAV_ITEMS.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleLinkClick(item.id)}
                  className={`text-left text-lg font-serif tracking-[0.06em] py-2 transition-colors ${
                    activeSection === item.id
                      ? 'text-[#C6A46A] font-bold pl-2 border-l-2 border-[#C6A46A]'
                      : 'text-[#F0EBDD] hover:text-[#C6A46A]'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </nav>
          </div>

          <div className="max-w-md mx-auto w-full pt-6 border-t border-[#111C25] space-y-4">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenJoinModal();
              }}
              className="w-full py-3.5 flex items-center justify-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#07121B] bg-[#C6A46A] hover:bg-[#D9B87F] rounded transition-all shadow-lg"
            >
              <span>Apply for Membership</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <div className="text-center text-[11px] text-[#89949A] tracking-wider uppercase">
              London · Manchester · Birmingham · Edinburgh
            </div>
          </div>
        </div>
      )}
    </>
  );
}
