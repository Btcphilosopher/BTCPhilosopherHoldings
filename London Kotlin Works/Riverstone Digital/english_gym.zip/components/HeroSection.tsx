'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight, Compass, Shield, Award } from 'lucide-react';
import { motion } from 'motion/react';

interface HeroSectionProps {
  onJoinClick: () => void;
  onExploreFacilities: () => void;
  onSelectLocation: (city: string) => void;
}

export function HeroSection({
  onJoinClick,
  onExploreFacilities,
  onSelectLocation,
}: HeroSectionProps) {
  return (
    <section id="hero" className="relative min-h-[95vh] lg:min-h-screen flex items-center justify-center overflow-hidden bg-[#07121B]">
      {/* Cinematic Full-Width Architectural Background */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/hero_gym.jpg"
          alt="The English Gym - Supermodernist architectural fitness interior overlooking the London skyline with lap pool, polished concrete and Olympic iron"
          fill
          priority
          sizes="100vw"
          className="object-cover object-center scale-105 transition-transform duration-1000 ease-out"
          referrerPolicy="no-referrer"
        />
        {/* Measured Scrim Gradient for Contrast Discipline */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#07121B] via-[#07121B]/60 to-[#07121B]/40" />
        <div className="absolute inset-0 bg-radial-gradient from-transparent via-[#07121B]/30 to-[#07121B]/80" />
        {/* Subtle British racing green tonal wash */}
        <div className="absolute inset-0 bg-[#183D35]/15 mix-blend-overlay pointer-events-none" />
      </div>

      {/* Main Content Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-32 pb-20 w-full flex flex-col justify-between min-h-[85vh]">
        {/* Top Kicker */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="flex items-center gap-3 text-xs uppercase tracking-[0.28em] text-[#C6A46A]"
        >
          <span className="w-8 h-[1px] bg-[#C6A46A]" />
          <span className="font-semibold">Supermodernist British Fitness & Wellness</span>
          <span className="hidden sm:inline w-8 h-[1px] bg-[#C6A46A]" />
        </motion.div>

        {/* Central Editorial Display */}
        <div className="my-auto max-w-4xl pt-6 pb-10">
          <motion.h1
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.25 }}
            className="font-serif text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-normal text-[#F0EBDD] tracking-tight leading-[1.05] drop-shadow-md text-balance"
          >
            A Higher Standard
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="mt-6 text-lg sm:text-xl md:text-2xl text-[#F0EBDD]/90 font-light max-w-2xl leading-relaxed tracking-wide font-sans text-balance"
          >
            World-class fitness. British values. A healthier, stronger you.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.55 }}
            className="mt-10 flex flex-wrap items-center gap-4 sm:gap-6"
          >
            {/* Primary Action Button */}
            <button
              onClick={onJoinClick}
              className="inline-flex items-center gap-3 px-8 py-4 text-xs sm:text-sm font-semibold uppercase tracking-[0.2em] text-[#07121B] bg-[#C6A46A] hover:bg-[#D9B87F] rounded transition-all duration-200 shadow-[0_4px_24px_rgba(198,164,106,0.35)] hover:shadow-[0_6px_32px_rgba(198,164,106,0.5)] cursor-pointer whitespace-nowrap"
            >
              <span>Join Now</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {/* Secondary Action: Explore Facilities */}
            <button
              onClick={onExploreFacilities}
              className="inline-flex items-center gap-2 px-6 py-4 text-xs sm:text-sm font-medium uppercase tracking-[0.18em] text-[#F0EBDD] hover:text-[#C6A46A] bg-[#111C25]/80 hover:bg-[#111C25] border border-[#C6A46A]/30 hover:border-[#C6A46A] rounded transition-all duration-200 backdrop-blur-sm cursor-pointer whitespace-nowrap"
            >
              <span>Explore Facilities</span>
            </button>
          </motion.div>
        </div>

        {/* Bottom Strip: Location Indicators & Architectural Calling Cards */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.7 }}
          className="pt-8 border-t border-[#C6A46A]/20 flex flex-col md:flex-row md:items-center justify-between gap-6"
        >
          {/* Small Location Indicator */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-xs tracking-[0.2em] uppercase text-[#89949A]">
            <span className="text-[#C6A46A] font-semibold flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5 text-[#C6A46A]" />
              Clubs:
            </span>
            {['LONDON', 'MANCHESTER', 'BIRMINGHAM', 'EDINBURGH'].map((city, idx) => (
              <React.Fragment key={city}>
                <button
                  onClick={() => onSelectLocation(city)}
                  className="hover:text-[#F0EBDD] transition-colors focus:outline-none focus-visible:text-[#C6A46A]"
                >
                  {city}
                </button>
                {idx < 3 && <span className="text-[#C6A46A]/40">/</span>}
              </React.Fragment>
            ))}
          </div>

          {/* Architectural Notes */}
          <div className="flex items-center gap-6 text-[11px] uppercase tracking-[0.18em] text-[#89949A]">
            <span className="flex items-center gap-1.5 text-[#F0EBDD]/80">
              <Shield className="w-3.5 h-3.5 text-[#C6A46A]" />
              Architectural Rigor
            </span>
            <span className="hidden sm:inline text-[#C6A46A]/30">·</span>
            <span className="hidden sm:inline flex items-center gap-1.5 text-[#F0EBDD]/80">
              <Award className="w-3.5 h-3.5 text-[#C6A46A]" />
              Sports Science
            </span>
            <span className="hidden sm:inline text-[#C6A46A]/30">·</span>
            <span className="text-[#C6A46A] font-medium">Est. MMXVIII</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
