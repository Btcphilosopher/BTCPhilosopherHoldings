'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { FACILITIES, FacilityItem } from '@/lib/club-data';
import { ArrowUpRight, CheckCircle2, SlidersHorizontal, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface FacilitiesSectionProps {
  onJoinClick: () => void;
}

export function FacilitiesSection({ onJoinClick }: FacilitiesSectionProps) {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [selectedFacility, setSelectedFacility] = useState<FacilityItem | null>(null);

  const categories = [
    { id: 'all', label: 'All Facilities (10)' },
    { id: 'strength', label: 'Strength & Iron' },
    { id: 'athletics', label: 'Track & Cardio' },
    { id: 'aquatics', label: 'Lap Pools & Hydro' },
    { id: 'wellness', label: 'Recovery Sanctuary' },
    { id: 'specialized', label: 'Boxing & Private' },
  ];

  const filteredFacilities =
    activeCategory === 'all'
      ? FACILITIES
      : FACILITIES.filter((f) => f.category === activeCategory);

  return (
    <section id="facilities" className="py-28 bg-[#0B1720] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 pb-6 border-b border-[#C6A46A]/20">
          <div>
            <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.26em] text-[#C6A46A] font-semibold mb-3">
              <span>Architectural Rigor</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#F0EBDD] font-normal tracking-tight">
              Spaces Built for Serious Purpose
            </h2>
          </div>
          <p className="mt-4 md:mt-0 text-sm text-[#89949A] max-w-md leading-relaxed font-sans">
            Every square foot is conceived as a marriage of English industrial craftsmanship, natural stone, acoustic engineering, and high-performance biomechanics.
          </p>
        </div>

        {/* Category Filter Bar */}
        <div className="mb-10 flex flex-wrap items-center gap-2 p-1.5 bg-[#07121B] border border-[#89949A]/20 rounded">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 text-xs font-semibold uppercase tracking-[0.16em] rounded transition-all whitespace-nowrap cursor-pointer ${
                activeCategory === cat.id
                  ? 'bg-[#C6A46A] text-[#07121B] shadow-sm'
                  : 'text-[#89949A] hover:text-[#F0EBDD]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Facilities Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredFacilities.map((facility, idx) => (
            <motion.div
              key={facility.id}
              layout
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: idx * 0.08 }}
              className="group flex flex-col bg-[#111C25] border border-[#89949A]/15 hover:border-[#C6A46A]/40 rounded overflow-hidden transition-all duration-300"
            >
              {/* Photo Showcase */}
              <div className="relative h-60 w-full overflow-hidden bg-[#07121B]">
                <Image
                  src={facility.image}
                  alt={facility.title}
                  fill
                  sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                  className="object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#111C25] via-transparent to-transparent opacity-80" />
                <span className="absolute bottom-3 left-4 text-[10px] uppercase tracking-[0.2em] font-semibold text-[#C6A46A] bg-[#07121B]/80 px-2 py-0.5 rounded backdrop-blur-sm border border-[#C6A46A]/20">
                  {facility.category}
                </span>
              </div>

              {/* Editorial Description */}
              <div className="p-6 flex flex-col flex-1 justify-between">
                <div>
                  <h3 className="font-serif text-xl sm:text-2xl text-[#F0EBDD] group-hover:text-[#C6A46A] transition-colors leading-snug">
                    {facility.title}
                  </h3>
                  <p className="mt-1.5 text-xs text-[#C6A46A] font-medium leading-relaxed">
                    {facility.subtitle}
                  </p>
                  <p className="mt-3 text-xs text-[#89949A] leading-relaxed line-clamp-3">
                    {facility.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-[#89949A]/15 flex items-center justify-between">
                  <div className="text-[11px] text-[#89949A]">
                    {facility.specs[0]}
                  </div>
                  <button
                    onClick={() => setSelectedFacility(facility)}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-[0.16em] text-[#C6A46A] hover:text-[#F0EBDD] transition-colors cursor-pointer"
                  >
                    <span>Inspect</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Facility Detail Modal */}
      <AnimatePresence>
        {selectedFacility && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-[#07121B]/90 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#111C25] border border-[#C6A46A]/40 rounded max-w-2xl w-full overflow-hidden shadow-2xl"
            >
              {/* Modal Image Header */}
              <div className="relative h-64 sm:h-72 w-full">
                <Image
                  src={selectedFacility.image}
                  alt={selectedFacility.title}
                  fill
                  className="object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#111C25] via-[#111C25]/40 to-transparent" />
                <button
                  onClick={() => setSelectedFacility(null)}
                  className="absolute top-4 right-4 p-2 bg-[#07121B]/80 text-[#F0EBDD] hover:text-[#C6A46A] rounded-full border border-[#89949A]/20 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
                <div className="absolute bottom-4 left-6">
                  <div className="text-[10px] uppercase tracking-[0.24em] text-[#C6A46A] font-semibold">
                    {selectedFacility.category}
                  </div>
                  <h3 className="font-serif text-2xl sm:text-3xl text-[#F0EBDD] font-bold">
                    {selectedFacility.title}
                  </h3>
                </div>
              </div>

              {/* Modal Content */}
              <div className="p-6 sm:p-8 space-y-6">
                <div>
                  <h4 className="text-xs uppercase tracking-[0.2em] text-[#C6A46A] font-semibold mb-2">
                    Architectural & Engineering Brief
                  </h4>
                  <p className="text-sm text-[#F0EBDD]/90 leading-relaxed font-sans">
                    {selectedFacility.description}
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4 border-t border-[#89949A]/15">
                  <div>
                    <h5 className="text-[11px] uppercase tracking-[0.18em] text-[#89949A] font-semibold mb-2.5">
                      Facility Specifications
                    </h5>
                    <ul className="space-y-2 text-xs text-[#F0EBDD]/80">
                      {selectedFacility.specs.map((spec) => (
                        <li key={spec} className="flex items-start gap-2">
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#C6A46A] shrink-0 mt-0.5" />
                          <span>{spec}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h5 className="text-[11px] uppercase tracking-[0.18em] text-[#89949A] font-semibold mb-2.5">
                      Equipment Highlights
                    </h5>
                    <ul className="space-y-2 text-xs text-[#F0EBDD]/80">
                      {selectedFacility.equipmentHighlights.map((eq) => (
                        <li key={eq} className="flex items-start gap-2">
                          <span className="text-[#C6A46A]">·</span>
                          <span>{eq}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="pt-6 border-t border-[#89949A]/15 flex items-center justify-between gap-4">
                  <button
                    onClick={() => setSelectedFacility(null)}
                    className="px-5 py-2.5 text-xs uppercase tracking-[0.16em] text-[#89949A] hover:text-[#F0EBDD] transition-colors"
                  >
                    Close
                  </button>
                  <button
                    onClick={() => {
                      setSelectedFacility(null);
                      onJoinClick();
                    }}
                    className="px-6 py-2.5 text-xs font-semibold uppercase tracking-[0.18em] text-[#07121B] bg-[#C6A46A] hover:bg-[#D9B87F] rounded transition-all"
                  >
                    Experience in Person
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
