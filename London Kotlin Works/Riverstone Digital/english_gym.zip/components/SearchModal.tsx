'use client';

import React, { useState, useMemo } from 'react';
import { Search, X, ArrowRight, MapPin, Dumbbell, Sparkles, User, Shield } from 'lucide-react';
import { FACILITIES, COACHES, WELLNESS_THERAPIES, CLUB_LOCATIONS, MEMBERSHIP_TIERS } from '@/lib/club-data';
import { motion, AnimatePresence } from 'motion/react';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateTo: (sectionId: string) => void;
}

export function SearchModal({
  isOpen,
  onClose,
  onNavigateTo,
}: SearchModalProps) {
  const [query, setQuery] = useState('');

  const searchResults = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();

    const results: Array<{
      category: string;
      title: string;
      subtitle: string;
      sectionId: string;
      icon: any;
    }> = [];

    // Facilities
    FACILITIES.forEach((f) => {
      if (
        f.title.toLowerCase().includes(q) ||
        f.description.toLowerCase().includes(q) ||
        f.category.toLowerCase().includes(q)
      ) {
        results.push({
          category: 'Facility',
          title: f.title,
          subtitle: f.subtitle,
          sectionId: 'facilities',
          icon: Dumbbell,
        });
      }
    });

    // Coaches
    COACHES.forEach((c) => {
      if (
        c.name.toLowerCase().includes(q) ||
        c.role.toLowerCase().includes(q) ||
        c.specialties.some((s) => s.toLowerCase().includes(q))
      ) {
        results.push({
          category: 'Coaching',
          title: c.name,
          subtitle: `${c.role} — ${c.specialties.join(', ')}`,
          sectionId: 'training',
          icon: User,
        });
      }
    });

    // Wellness
    WELLNESS_THERAPIES.forEach((w) => {
      if (
        w.title.toLowerCase().includes(q) ||
        w.description.toLowerCase().includes(q)
      ) {
        results.push({
          category: 'Wellness & Longevity',
          title: w.title,
          subtitle: w.subhead,
          sectionId: 'wellness',
          icon: Sparkles,
        });
      }
    });

    // Locations
    CLUB_LOCATIONS.forEach((loc) => {
      if (
        loc.city.toLowerCase().includes(q) ||
        loc.district.toLowerCase().includes(q) ||
        loc.address.toLowerCase().includes(q)
      ) {
        results.push({
          category: 'Club Location',
          title: `${loc.city} (${loc.district})`,
          subtitle: `${loc.address}, ${loc.postcode}`,
          sectionId: 'locations',
          icon: MapPin,
        });
      }
    });

    // Memberships
    MEMBERSHIP_TIERS.forEach((m) => {
      if (
        m.name.toLowerCase().includes(q) ||
        m.tagline.toLowerCase().includes(q)
      ) {
        results.push({
          category: 'Membership',
          title: m.name,
          subtitle: `£${m.monthlyPrice}/mo — ${m.tagline}`,
          sectionId: 'membership',
          icon: Shield,
        });
      }
    });

    return results.slice(0, 8);
  }, [query]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 pb-6 bg-[#07121B]/90 backdrop-blur-md">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className="bg-[#111C25] border border-[#C6A46A]/40 rounded max-w-2xl w-full overflow-hidden shadow-2xl text-[#F0EBDD]"
      >
        {/* Search Bar Input */}
        <div className="relative p-4 border-b border-[#89949A]/20 flex items-center gap-3">
          <Search className="w-5 h-5 text-[#C6A46A] shrink-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search facilities, coaching, thermal suites, memberships or UK clubs..."
            className="w-full bg-transparent text-sm sm:text-base text-[#F0EBDD] placeholder:text-[#89949A] focus:outline-none"
          />
          <button
            onClick={onClose}
            className="p-1 text-[#89949A] hover:text-[#C6A46A] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results Body */}
        <div className="p-4 sm:p-6 max-h-96 overflow-y-auto space-y-2">
          {query.trim() === '' ? (
            <div className="text-center py-8 text-xs text-[#89949A] space-y-3">
              <div className="text-[10px] uppercase tracking-[0.2em] text-[#C6A46A]">
                Suggested Searches
              </div>
              <div className="flex flex-wrap justify-center gap-2">
                {[
                  'Olympic Lifting',
                  'Mayfair Club',
                  'Cold Plunge',
                  'Founders Club',
                  'Finnish Sauna',
                  'Biomechanics',
                  'Manchester',
                ].map((term) => (
                  <button
                    key={term}
                    onClick={() => setQuery(term)}
                    className="px-3 py-1 bg-[#07121B] hover:bg-[#183D35] border border-[#89949A]/20 rounded text-xs text-[#F0EBDD] transition-colors"
                  >
                    {term}
                  </button>
                ))}
              </div>
            </div>
          ) : searchResults.length > 0 ? (
            <div className="space-y-1.5">
              {searchResults.map((res, i) => {
                const IconComponent = res.icon;
                return (
                  <button
                    key={i}
                    onClick={() => {
                      onNavigateTo(res.sectionId);
                      onClose();
                    }}
                    className="w-full p-3 rounded bg-[#07121B]/60 hover:bg-[#07121B] border border-transparent hover:border-[#C6A46A]/40 transition-all flex items-center justify-between text-left group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded bg-[#111C25] text-[#C6A46A]">
                        <IconComponent className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-[10px] uppercase tracking-wider text-[#C6A46A] font-semibold">
                          {res.category}
                        </div>
                        <div className="text-sm font-serif font-bold text-[#F0EBDD] group-hover:text-[#C6A46A] transition-colors">
                          {res.title}
                        </div>
                        <div className="text-xs text-[#89949A] truncate max-w-sm sm:max-w-md">
                          {res.subtitle}
                        </div>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-[#89949A] group-hover:text-[#C6A46A] shrink-0" />
                  </button>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-8 text-xs text-[#89949A]">
              No results found for &ldquo;{query}&rdquo;. Try another term.
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
