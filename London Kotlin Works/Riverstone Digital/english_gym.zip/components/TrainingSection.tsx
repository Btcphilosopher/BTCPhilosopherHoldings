'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { COACHES, CoachProfile } from '@/lib/club-data';
import { Award, Calendar, Check, Compass, Gauge, Microscope, User, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface TrainingSectionProps {
  onBookAssessment: (coachName?: string, discipline?: string) => void;
}

export function TrainingSection({ onBookAssessment }: TrainingSectionProps) {
  const [selectedCoach, setSelectedCoach] = useState<CoachProfile | null>(null);

  const trainingPillars = [
    {
      id: 'biomechanics',
      title: 'Biomechanics & Kinetic Screen',
      science: '3D optical movement tracking, joint range of motion, and bilateral asymmetry detection.',
      objective: 'Prevent musculoskeletal breakdown and uncover force leakage before loading.',
      intensity: 'Precision Diagnostic',
    },
    {
      id: 'strength',
      title: 'Barbell Velocity & Absolute Strength',
      science: 'Linear transducer barbell telemetry measuring m/s velocity and peak wattage.',
      objective: 'Systemic neuromuscular adaptation, skeletal density, and maximum power generation.',
      intensity: 'High Neural Load',
    },
    {
      id: 'endurance',
      title: 'Metabolic Conditioning & VO2 Max',
      science: 'Direct spirometry gas exchange assessment to pinpoint lactate threshold 1 & 2.',
      objective: 'Cardiovascular longevity, mitochondrial density, and cellular waste clearance.',
      intensity: 'Aerobic & Anaerobic',
    },
    {
      id: 'combat',
      title: 'English Prize-Ring Boxing',
      science: 'High-speed cognitive decision-making under severe cardiovascular and lactic load.',
      objective: 'Rotational kinetic chain power, defensive agility, and psychological resilience.',
      intensity: 'High Glycolytic',
    },
    {
      id: 'pilates',
      title: 'Classical Pilates & Pelvic Alignment',
      science: 'Spring-loaded resistance carriages enforcing eccentric muscle lengthening and deep core stability.',
      objective: 'Decompression of spinal column, structural symmetry, and flawless posture.',
      intensity: 'Restorative Alignment',
    },
    {
      id: 'mobility',
      title: 'Fascial Tension & Joint Freedom',
      science: 'PNF neuromuscular stretching, loaded end-range mobility, and connective tissue remodeling.',
      objective: 'Complete joint resilience, freedom of movement, and long-term athletic independence.',
      intensity: 'Corrective & Active',
    },
  ];

  return (
    <section id="training" className="py-28 bg-[#07121B] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 pb-6 border-b border-[#C6A46A]/20">
          <div>
            <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.26em] text-[#C6A46A] font-semibold mb-3">
              <span>Sports Science & Methodology</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#F0EBDD] font-normal tracking-tight">
              An Empirical Approach to Human Potential
            </h2>
          </div>
          <p className="mt-4 md:mt-0 text-sm text-[#89949A] max-w-md leading-relaxed font-sans">
            We abandon fitness fads in favour of verified sports physiology, precise biomechanical metrics, and timeless British athletic grit.
          </p>
        </div>

        {/* Feature Hero Banner for Training */}
        <div className="relative rounded overflow-hidden mb-16 border border-[#C6A46A]/30">
          <div className="relative h-72 sm:h-96 w-full">
            <Image
              src="/images/coaching_track.jpg"
              alt="Elite athletics and sports science training at The English Gym"
              fill
              className="object-cover object-center"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#07121B] via-[#07121B]/75 to-transparent" />
          </div>

          <div className="absolute inset-0 p-6 sm:p-12 flex flex-col justify-center max-w-2xl">
            <div className="text-[10px] uppercase tracking-[0.24em] text-[#C6A46A] font-semibold mb-2">
              The Laboratory on the Gym Floor
            </div>
            <h3 className="font-serif text-2xl sm:text-4xl text-[#F0EBDD] font-normal leading-tight">
              Every Repetition Guided by Evidence
            </h3>
            <p className="mt-3 text-xs sm:text-sm text-[#F0EBDD]/85 leading-relaxed font-sans">
              Our coaching methodology incorporates velocity-based barbell measurement, real-time heart rate variability, and lactate testing to ensure no training volume is wasted.
            </p>
            <div className="mt-6 flex items-center gap-4">
              <button
                onClick={() => onBookAssessment()}
                className="px-6 py-3 text-xs font-semibold uppercase tracking-[0.18em] text-[#07121B] bg-[#C6A46A] hover:bg-[#D9B87F] rounded transition-all shadow-md cursor-pointer whitespace-nowrap"
              >
                Book Science Assessment
              </button>
            </div>
          </div>
        </div>

        {/* Scientific Disciplines Grid */}
        <div className="mb-20">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <h3 className="font-serif text-2xl sm:text-3xl text-[#F0EBDD]">
              Sports Science Disciplines
            </h3>
            <p className="text-xs sm:text-sm text-[#89949A] mt-2 font-sans">
              Structured physical disciplines programmed individually to ensure progressive overload without chronic injury.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {trainingPillars.map((pillar, idx) => (
              <motion.div
                key={pillar.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className="bg-[#111C25] border border-[#89949A]/15 hover:border-[#C6A46A]/40 rounded p-6 flex flex-col justify-between transition-colors"
              >
                <div>
                  <div className="flex items-center justify-between text-[10px] uppercase tracking-[0.2em] text-[#C6A46A] font-semibold mb-3">
                    <span className="flex items-center gap-1.5">
                      <Microscope className="w-3.5 h-3.5 text-[#C6A46A]" />
                      0{idx + 1}
                    </span>
                    <span className="text-[#89949A]">{pillar.intensity}</span>
                  </div>

                  <h4 className="font-serif text-lg sm:text-xl text-[#F0EBDD] font-medium leading-snug">
                    {pillar.title}
                  </h4>

                  <p className="mt-3 text-xs text-[#89949A] leading-relaxed">
                    <strong className="text-[#C6A46A] font-normal block mb-1">Physiological Mechanism:</strong>
                    {pillar.science}
                  </p>
                </div>

                <div className="mt-5 pt-4 border-t border-[#89949A]/15">
                  <div className="text-[11px] text-[#F0EBDD]/90">
                    <span className="text-[#89949A]">Outcome: </span>
                    {pillar.objective}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Elite Coaching Roster */}
        <div className="pt-8 border-t border-[#C6A46A]/20">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
            <div>
              <div className="text-xs uppercase tracking-[0.24em] text-[#C6A46A] font-semibold mb-2">
                The Faculty
              </div>
              <h3 className="font-serif text-3xl sm:text-4xl text-[#F0EBDD]">
                Elite Coaching Directors
              </h3>
            </div>
            <p className="mt-2 md:mt-0 text-xs sm:text-sm text-[#89949A] max-w-md">
              Our faculty comprises former Olympic athletes, sports science researchers, and master conditioning practitioners.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {COACHES.map((coach) => (
              <div
                key={coach.id}
                className="bg-[#111C25] border border-[#89949A]/15 hover:border-[#C6A46A]/40 rounded p-6 flex flex-col justify-between transition-all"
              >
                <div>
                  {/* Monogram Crest Avatar */}
                  <div className="w-14 h-14 rounded bg-[#07121B] border border-[#C6A46A]/40 flex items-center justify-center font-serif text-lg font-bold text-[#C6A46A] mb-4 shadow-inner">
                    {coach.initials}
                  </div>

                  <h4 className="font-serif text-xl text-[#F0EBDD] font-medium leading-snug">
                    {coach.name}
                  </h4>
                  <div className="text-xs text-[#C6A46A] font-medium mt-1">
                    {coach.role}
                  </div>

                  <div className="mt-3 text-[11px] text-[#89949A] italic border-t border-[#89949A]/15 pt-2">
                    {coach.credentials}
                  </div>

                  <p className="mt-3 text-xs text-[#89949A] leading-relaxed line-clamp-3">
                    {coach.bio}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-[#89949A]/15 flex items-center justify-between">
                  <button
                    onClick={() => setSelectedCoach(coach)}
                    className="text-xs text-[#89949A] hover:text-[#F0EBDD] uppercase tracking-wider"
                  >
                    View Biography
                  </button>
                  <button
                    onClick={() => onBookAssessment(coach.name)}
                    className="text-xs font-semibold uppercase tracking-wider text-[#C6A46A] hover:text-[#D9B87F]"
                  >
                    Book Session
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Coach Bio Modal */}
      <AnimatePresence>
        {selectedCoach && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#07121B]/90 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#111C25] border border-[#C6A46A]/40 rounded max-w-lg w-full p-6 sm:p-8 relative shadow-2xl"
            >
              <button
                onClick={() => setSelectedCoach(null)}
                className="absolute top-4 right-4 p-2 text-[#89949A] hover:text-[#C6A46A] transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="w-16 h-16 rounded bg-[#07121B] border border-[#C6A46A]/50 flex items-center justify-center font-serif text-2xl font-bold text-[#C6A46A] mb-4">
                {selectedCoach.initials}
              </div>

              <h3 className="font-serif text-2xl text-[#F0EBDD] font-bold">
                {selectedCoach.name}
              </h3>
              <div className="text-xs text-[#C6A46A] font-semibold uppercase tracking-wider mt-0.5">
                {selectedCoach.role}
              </div>
              <div className="text-xs text-[#89949A] mt-2 pb-4 border-b border-[#89949A]/15">
                {selectedCoach.credentials}
              </div>

              <div className="py-4 space-y-3">
                <p className="text-xs text-[#F0EBDD]/90 leading-relaxed font-sans">
                  {selectedCoach.bio}
                </p>
                <div className="text-xs text-[#89949A]">
                  <strong className="text-[#C6A46A]">Tenure: </strong>
                  {selectedCoach.background}
                </div>

                <div className="pt-2">
                  <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#C6A46A] mb-2">
                    Specialist Focus Areas
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedCoach.specialties.map((spec) => (
                      <span
                        key={spec}
                        className="text-[11px] text-[#F0EBDD] bg-[#07121B] px-2.5 py-1 rounded border border-[#89949A]/20"
                      >
                        {spec}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-[#89949A]/15 flex items-center justify-between">
                <button
                  onClick={() => setSelectedCoach(null)}
                  className="text-xs uppercase tracking-wider text-[#89949A] hover:text-[#F0EBDD]"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    const name = selectedCoach.name;
                    setSelectedCoach(null);
                    onBookAssessment(name);
                  }}
                  className="px-5 py-2.5 text-xs font-semibold uppercase tracking-[0.18em] text-[#07121B] bg-[#C6A46A] hover:bg-[#D9B87F] rounded transition-all"
                >
                  Book Private Assessment
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
