'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowUpRight } from 'lucide-react';
import { motion } from 'motion/react';

interface HomepageCardsProps {
  onNavigateSection: (sectionId: string) => void;
  onOpenCardDetail: (cardIndex: number) => void;
}

export function HomepageCards({
  onNavigateSection,
  onOpenCardDetail,
}: HomepageCardsProps) {
  const cards = [
    {
      index: 0,
      number: '01',
      title: 'STATE-OF-THE-ART FACILITIES',
      subtitle: 'Architectural spaces engineered for serious physical output.',
      sectionId: 'facilities',
      image: '/images/strength_hall.jpg',
      points: [
        'Advanced strength and conditioning',
        'Olympic lifting platforms',
        'Indoor running track',
        'Swimming pools',
        'Functional fitness spaces',
      ],
      actionLabel: 'Explore Facilities',
    },
    {
      index: 1,
      number: '02',
      title: 'EXPERT COACHING & PERSONAL TRAINING',
      subtitle: 'Sports science and physiological rigor applied to every rep.',
      sectionId: 'training',
      image: '/images/coaching_track.jpg',
      points: [
        'Elite personal trainers',
        'Athletic performance specialists',
        'Individual training programmes',
        'Sports science assessments',
      ],
      actionLabel: 'Discover Coaching',
    },
    {
      index: 2,
      number: '03',
      title: 'WELLNESS & RECOVERY',
      subtitle: 'Thermal contrast therapy, restorative medicine and longevity.',
      sectionId: 'wellness',
      image: '/images/wellness_pool.jpg',
      points: [
        'Sauna and steam rooms',
        'Cold plunge pools',
        'Physiotherapy',
        'Mobility studios',
        'Nutrition support',
      ],
      actionLabel: 'Explore Sanctuary',
    },
  ];

  return (
    <section className="py-24 bg-[#07121B] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 pb-6 border-b border-[#C6A46A]/20">
          <div>
            <div className="flex items-center gap-2 text-xs uppercase tracking-[0.24em] text-[#C6A46A] font-semibold mb-3">
              <span>Pillars of the Institution</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#F0EBDD] font-normal tracking-tight">
              An Elevated Approach to Human Performance
            </h2>
          </div>
          <p className="mt-4 md:mt-0 text-sm text-[#89949A] max-w-md tracking-wide font-sans">
            Three foundational disciplines uniting classic British dedication with the forefront of sports science.
          </p>
        </div>

        {/* 3 Large Editorial Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {cards.map((card, idx) => (
            <motion.div
              key={card.number}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.7, delay: idx * 0.15 }}
              className="group flex flex-col bg-[#111C25] border border-[#89949A]/15 hover:border-[#C6A46A]/40 transition-all duration-300 rounded overflow-hidden"
            >
              {/* Image Container with subtle zoom on hover */}
              <div className="relative h-64 sm:h-72 w-full overflow-hidden bg-[#07121B]">
                <Image
                  src={card.image}
                  alt={card.title}
                  fill
                  sizes="(max-width: 1024px) 100vw, 33vw"
                  className="object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#111C25] via-[#111C25]/40 to-transparent" />
                {/* Index numeral */}
                <div className="absolute top-4 left-4 font-serif text-xl font-bold text-[#C6A46A] bg-[#07121B]/80 px-2.5 py-1 rounded backdrop-blur-sm border border-[#C6A46A]/20">
                  {card.number}
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 sm:p-8 flex flex-col flex-1 justify-between">
                <div>
                  <h3 className="font-serif text-xl sm:text-2xl text-[#F0EBDD] group-hover:text-[#C6A46A] transition-colors leading-snug">
                    {card.title}
                  </h3>
                  <p className="mt-2 text-xs text-[#89949A] font-sans leading-relaxed">
                    {card.subtitle}
                  </p>

                  {/* Bullet points as clean unboxed editorial list */}
                  <ul className="mt-6 space-y-2.5 border-t border-[#89949A]/15 pt-5 text-xs text-[#F0EBDD]/80">
                    {card.points.map((point) => (
                      <li key={point} className="flex items-start gap-2.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#C6A46A] mt-1.5 flex-shrink-0" />
                        <span className="leading-snug">{point}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Interactive Action Button */}
                <div className="pt-8 mt-6 border-t border-[#89949A]/10 flex items-center justify-between">
                  <button
                    onClick={() => onNavigateSection(card.sectionId)}
                    className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-[#C6A46A] group-hover:text-[#F0EBDD] transition-colors cursor-pointer"
                  >
                    <span>{card.actionLabel}</span>
                    <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </button>
                  <button
                    onClick={() => onOpenCardDetail(card.index)}
                    className="text-[11px] text-[#89949A] hover:text-[#C6A46A] uppercase tracking-wider transition-colors cursor-pointer"
                  >
                    Quick Overview
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
