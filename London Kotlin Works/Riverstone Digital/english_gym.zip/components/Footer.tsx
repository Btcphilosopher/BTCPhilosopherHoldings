'use client';

import React from 'react';
import { HeraldicLogo } from './HeraldicLogo';
import { Compass, Mail, Phone, ArrowUp } from 'lucide-react';

interface FooterProps {
  onNavigate: (sectionId: string) => void;
  onJoinClick: () => void;
}

export function Footer({ onNavigate, onJoinClick }: FooterProps) {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#07121B] text-[#F0EBDD] border-t border-[#C6A46A]/20 pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-16 border-b border-[#89949A]/15">
          {/* Col 1 & 2: Brand Lockup & Purpose */}
          <div className="lg:col-span-2 space-y-4">
            <HeraldicLogo size="md" showTagline={true} />
            <p className="text-xs sm:text-sm text-[#89949A] leading-relaxed max-w-sm pt-2 font-sans">
              The English Gym is a supermodernist fitness and wellness institution combining British architectural heritage, contemporary luxury, advanced sports science and holistic health.
            </p>
            <div className="pt-2 text-xs text-[#C6A46A] tracking-wider uppercase font-semibold">
              London · Manchester · Birmingham · Edinburgh
            </div>
          </div>

          {/* Col 3: Navigation */}
          <div>
            <div className="text-xs uppercase tracking-[0.22em] text-[#C6A46A] font-semibold mb-4">
              Institution
            </div>
            <ul className="space-y-2.5 text-xs text-[#89949A]">
              <li>
                <button
                  onClick={() => onNavigate('hero')}
                  className="hover:text-[#F0EBDD] transition-colors"
                >
                  Home
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('about')}
                  className="hover:text-[#F0EBDD] transition-colors"
                >
                  Our Manifesto
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('facilities')}
                  className="hover:text-[#F0EBDD] transition-colors"
                >
                  Facilities & Architecture
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('training')}
                  className="hover:text-[#F0EBDD] transition-colors"
                >
                  Sports Science Coaching
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('wellness')}
                  className="hover:text-[#F0EBDD] transition-colors"
                >
                  Longevity & Thermal Baths
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Membership & Locations */}
          <div>
            <div className="text-xs uppercase tracking-[0.22em] text-[#C6A46A] font-semibold mb-4">
              Membership
            </div>
            <ul className="space-y-2.5 text-xs text-[#89949A]">
              <li>
                <button
                  onClick={() => onNavigate('membership')}
                  className="hover:text-[#F0EBDD] transition-colors"
                >
                  The Standard (£195/mo)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('membership')}
                  className="hover:text-[#F0EBDD] transition-colors"
                >
                  The Premier (£340/mo)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('membership')}
                  className="hover:text-[#F0EBDD] transition-colors"
                >
                  The Founders&apos; Club
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('locations')}
                  className="hover:text-[#F0EBDD] transition-colors"
                >
                  UK Club Directory
                </button>
              </li>
              <li>
                <button
                  onClick={onJoinClick}
                  className="text-[#C6A46A] font-semibold hover:underline"
                >
                  Apply for Membership →
                </button>
              </li>
            </ul>
          </div>

          {/* Col 5: Contact & Careers */}
          <div>
            <div className="text-xs uppercase tracking-[0.22em] text-[#C6A46A] font-semibold mb-4">
              Concierge
            </div>
            <ul className="space-y-2.5 text-xs text-[#89949A]">
              <li className="flex items-center gap-2 text-[#F0EBDD]">
                <Phone className="w-3.5 h-3.5 text-[#C6A46A]" />
                <span>+44 (0)20 7946 0880</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-[#C6A46A]" />
                <span>membership@theenglishgym.co.uk</span>
              </li>
              <li className="pt-2">
                <span className="block text-[11px] text-[#C6A46A] uppercase tracking-wider font-semibold">
                  Careers & Fellowships
                </span>
                <span className="text-[11px] text-[#89949A]">
                  Seeking chartered biomechanists and elite coaches.
                </span>
              </li>
            </ul>

            {/* Social channels */}
            <div className="pt-4 flex items-center gap-4 text-xs text-[#89949A]">
              <a
                href="#instagram"
                className="hover:text-[#C6A46A] transition-colors uppercase tracking-wider text-[11px]"
              >
                Instagram
              </a>
              <a
                href="#linkedin"
                className="hover:text-[#C6A46A] transition-colors uppercase tracking-wider text-[11px]"
              >
                LinkedIn
              </a>
              <a
                href="#youtube"
                className="hover:text-[#C6A46A] transition-colors uppercase tracking-wider text-[11px]"
              >
                YouTube
              </a>
            </div>
          </div>
        </div>

        {/* Closing Brand Statement: "STRONGER TOGETHER." */}
        <div className="py-12 border-b border-[#89949A]/15 text-center">
          <div className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#C6A46A] tracking-[0.25em] uppercase font-bold">
            STRONGER TOGETHER.
          </div>
          <div className="text-[10px] uppercase tracking-[0.3em] text-[#89949A] mt-2">
            A HIGHER STANDARD · THE ENGLISH GYM · UNITED KINGDOM
          </div>
        </div>

        {/* Bottom Legal Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#89949A]">
          <div>
            &copy; {new Date().getFullYear()} The English Gym Ltd. Registered in England & Wales. All rights reserved.
          </div>

          <div className="flex items-center gap-6 text-[11px]">
            <a href="#privacy" className="hover:text-[#F0EBDD] transition-colors">
              Privacy Policy
            </a>
            <a href="#terms" className="hover:text-[#F0EBDD] transition-colors">
              Terms of Membership
            </a>
            <a href="#governance" className="hover:text-[#F0EBDD] transition-colors">
              Club Governance
            </a>
            <button
              onClick={scrollToTop}
              className="p-1.5 rounded bg-[#111C25] hover:bg-[#183D35] text-[#C6A46A] hover:text-[#F0EBDD] transition-colors"
              aria-label="Scroll to top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
