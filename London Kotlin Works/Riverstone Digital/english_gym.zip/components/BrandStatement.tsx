'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight, Landmark, Activity, HeartPulse } from 'lucide-react';
import { motion } from 'motion/react';

interface BrandStatementProps {
  onBecomeMember: () => void;
  onReadManifesto: () => void;
}

export function BrandStatement({
  onBecomeMember,
  onReadManifesto,
}: BrandStatementProps) {
  return (
    <section className="relative py-32 bg-[#07121B] overflow-hidden">
      {/* Panoramic Architectural Background */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/sunset_building.jpg"
          alt="The English Gym - Panoramic architectural view at sunset with illuminated glass facade, bronze and Portland stone architecture"
          fill
          sizes="100vw"
          className="object-cover object-center"
          referrerPolicy="no-referrer"
        />
        {/* Deep architectural overlay */}
        <div className="absolute inset-0 bg-[#07121B]/80 backdrop-blur-[2px]" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#07121B] via-[#07121B]/70 to-[#07121B]" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#07121B] via-transparent to-[#07121B]" />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.26em] text-[#C6A46A] font-semibold mb-6 border border-[#C6A46A]/30 px-4 py-1.5 rounded-full bg-[#07121B]/60 backdrop-blur-sm"
        >
          <span>The Institutional Creed</span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.15 }}
          className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl text-[#F0EBDD] font-normal tracking-tight text-balance"
        >
          More than a gym. <br className="hidden sm:inline" />
          <span className="text-[#C6A46A] italic">A way of life.</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="mt-8 text-base sm:text-lg md:text-xl text-[#F0EBDD]/85 font-light leading-relaxed max-w-3xl mx-auto tracking-wide text-balance font-sans"
        >
          The English Gym is built for those who believe in self-improvement, discipline and a stronger tomorrow. Join a community that values health, performance and purpose.
        </motion.p>

        {/* CTA Strip */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.45 }}
          className="mt-12 flex flex-wrap items-center justify-center gap-5"
        >
          <button
            onClick={onBecomeMember}
            className="inline-flex items-center gap-3 px-8 py-4 text-xs sm:text-sm font-semibold uppercase tracking-[0.2em] text-[#07121B] bg-[#C6A46A] hover:bg-[#D9B87F] rounded transition-all duration-200 shadow-[0_4px_24px_rgba(198,164,106,0.35)] cursor-pointer"
          >
            <span>Become a Member</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={onReadManifesto}
            className="inline-flex items-center gap-2 px-6 py-4 text-xs sm:text-sm font-medium uppercase tracking-[0.18em] text-[#F0EBDD] hover:text-[#C6A46A] border border-[#89949A]/30 hover:border-[#C6A46A] rounded transition-all bg-[#07121B]/60 backdrop-blur-sm cursor-pointer"
          >
            <span>Read Our Manifesto</span>
          </button>
        </motion.div>

        {/* Quiet 3-Column Institutional Metrics */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-20 pt-12 border-t border-[#C6A46A]/20 grid grid-cols-1 sm:grid-cols-3 gap-8 text-left"
        >
          <div className="flex items-start gap-4">
            <Landmark className="w-6 h-6 text-[#C6A46A] shrink-0 mt-1" />
            <div>
              <div className="font-serif text-lg text-[#F0EBDD]">Architectural Heritage</div>
              <div className="text-xs text-[#89949A] mt-1 leading-relaxed">
                Supermodernist design meeting British Portland stone, dark oak, and daylight.
              </div>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <Activity className="w-6 h-6 text-[#C6A46A] shrink-0 mt-1" />
            <div>
              <div className="font-serif text-lg text-[#F0EBDD]">Sports Science</div>
              <div className="text-xs text-[#89949A] mt-1 leading-relaxed">
                Olympic coaching, velocity-based training, and laboratory metabolic testing.
              </div>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <HeartPulse className="w-6 h-6 text-[#C6A46A] shrink-0 mt-1" />
            <div>
              <div className="font-serif text-lg text-[#F0EBDD]">Lifelong Longevity</div>
              <div className="text-xs text-[#89949A] mt-1 leading-relaxed">
                Thermal bathing, cold plunge contrast, and physician-led recovery protocols.
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
