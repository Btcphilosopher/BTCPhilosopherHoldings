'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { WELLNESS_THERAPIES, WellnessTherapy } from '@/lib/club-data';
import { Flame, Snowflake, Sparkles, HeartPulse, Moon, Salad, Activity, RefreshCw } from 'lucide-react';
import { motion } from 'motion/react';

interface WellnessSectionProps {
  onJoinClick: () => void;
  onBookTreatment: (treatmentTitle: string) => void;
}

export function WellnessSection({
  onJoinClick,
  onBookTreatment,
}: WellnessSectionProps) {
  // Longevity Calculator State
  const [calcStep, setCalcStep] = useState(0);
  const [trainingDays, setTrainingDays] = useState(4);
  const [sleepHours, setSleepHours] = useState(7);
  const [stressLevel, setStressLevel] = useState<'moderate' | 'high' | 'low'>('moderate');
  const [primaryGoal, setPrimaryGoal] = useState<'cellular_repair' | 'inflammation' | 'endurance' | 'structural'>('cellular_repair');
  const [showProtocol, setShowProtocol] = useState(false);

  const calculateBiologicalScore = () => {
    let score = 70;
    if (sleepHours >= 8) score += 12;
    else if (sleepHours < 6) score -= 14;

    if (trainingDays >= 4 && trainingDays <= 5) score += 10;
    else if (trainingDays > 6) score -= 5;

    if (stressLevel === 'low') score += 8;
    if (stressLevel === 'high') score -= 12;

    return Math.min(Math.max(score, 45), 98);
  };

  const bioScore = calculateBiologicalScore();

  return (
    <section id="wellness" className="py-28 bg-[#0D241F] relative text-[#F0EBDD]">
      {/* Subtle architectural background texture */}
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#C6A46A_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 pb-6 border-b border-[#C6A46A]/20">
          <div>
            <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.26em] text-[#C6A46A] font-semibold mb-3">
              <span>The Longevity Sanctuary</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#F0EBDD] font-normal tracking-tight">
              A Holistic Health Institution
            </h2>
          </div>
          <p className="mt-4 md:mt-0 text-sm text-[#F0EBDD]/80 max-w-md leading-relaxed font-sans">
            Muscular adaptation is only half the equation. Cellular regeneration, vascular dilation, and nervous system recalibration form the foundation of lifelong vitality.
          </p>
        </div>

        {/* Feature Hero Sanctuary Banner */}
        <div className="relative rounded overflow-hidden mb-16 border border-[#C6A46A]/30">
          <div className="relative h-72 sm:h-96 w-full">
            <Image
              src="/images/wellness_pool.jpg"
              alt="Thermal swimming pool and marble cold plunge sanctuary at The English Gym"
              fill
              className="object-cover object-center"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#07121B]/95 via-[#07121B]/75 to-transparent" />
          </div>

          <div className="absolute inset-0 p-6 sm:p-12 flex flex-col justify-center max-w-2xl">
            <div className="inline-flex items-center gap-2 text-[10px] uppercase tracking-[0.24em] text-[#C6A46A] font-semibold mb-2">
              <Sparkles className="w-3.5 h-3.5 text-[#C6A46A]" />
              Thermal Contrast Suite
            </div>
            <h3 className="font-serif text-2xl sm:text-4xl text-[#F0EBDD] font-normal leading-tight">
              88°C Cedar Heat Meets 3°C Glacial Immersion
            </h3>
            <p className="mt-3 text-xs sm:text-sm text-[#F0EBDD]/85 leading-relaxed font-sans">
              Designed according to deliberate cold and heat shock protocols. Stimulates noradrenergic pathways, dampens inflammatory cytokines, and facilitates deep cellular autophagy.
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-4">
              <button
                onClick={onJoinClick}
                className="px-6 py-3 text-xs font-semibold uppercase tracking-[0.18em] text-[#07121B] bg-[#C6A46A] hover:bg-[#D9B87F] rounded transition-all shadow-md cursor-pointer whitespace-nowrap"
              >
                Access Wellness Suites
              </button>
            </div>
          </div>
        </div>

        {/* Wellness & Longevity Therapies Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-20">
          {WELLNESS_THERAPIES.map((therapy, idx) => (
            <div
              key={therapy.id}
              className="bg-[#07121B]/80 border border-[#89949A]/20 hover:border-[#C6A46A]/40 rounded p-6 sm:p-7 flex flex-col justify-between backdrop-blur-sm transition-all"
            >
              <div>
                <div className="flex items-center justify-between text-xs text-[#C6A46A] mb-3">
                  <span className="font-semibold uppercase tracking-wider">
                    {therapy.temperature ? `Temp: ${therapy.temperature}` : 'Clinical Therapy'}
                  </span>
                  <span className="text-[#89949A] text-[10px] uppercase tracking-wider">0{idx + 1}</span>
                </div>

                <h4 className="font-serif text-xl sm:text-2xl text-[#F0EBDD] font-normal">
                  {therapy.title}
                </h4>
                <p className="text-xs text-[#C6A46A] font-medium mt-1">
                  {therapy.subhead}
                </p>

                <p className="mt-3 text-xs text-[#F0EBDD]/75 leading-relaxed">
                  {therapy.description}
                </p>

                <div className="mt-5 pt-4 border-t border-[#89949A]/15">
                  <div className="text-[11px] font-semibold uppercase tracking-wider text-[#89949A] mb-2">
                    Key Biological Adaptations
                  </div>
                  <ul className="space-y-1.5 text-xs text-[#F0EBDD]/90">
                    {therapy.physiologicalBenefits.map((b) => (
                      <li key={b} className="flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#C6A46A] mt-1.5 shrink-0" />
                        <span>{b}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-[#89949A]/15 flex items-center justify-between">
                <span className="text-[11px] text-[#89949A]">
                  {therapy.recommendedFrequency}
                </span>
                <button
                  onClick={() => onBookTreatment(therapy.title)}
                  className="text-xs font-semibold uppercase tracking-wider text-[#C6A46A] hover:text-[#F0EBDD] transition-colors"
                >
                  Consult
                </button>
              </div>
            </div>
          ))}

          {/* Dedicated Pillar Card for Nutrition & Sleep Architecture */}
          <div className="bg-[#07121B]/80 border border-[#89949A]/20 hover:border-[#C6A46A]/40 rounded p-6 sm:p-7 flex flex-col justify-between backdrop-blur-sm transition-all">
            <div>
              <div className="flex items-center justify-between text-xs text-[#C6A46A] mb-3">
                <span className="font-semibold uppercase tracking-wider">Lifestyle Biology</span>
                <span className="text-[#89949A] text-[10px] uppercase tracking-wider">06</span>
              </div>
              <h4 className="font-serif text-xl sm:text-2xl text-[#F0EBDD] font-normal">
                Metabolic Nutrition & Sleep
              </h4>
              <p className="text-xs text-[#C6A46A] font-medium mt-1">
                Fueling mitochondrial output and non-REM deep sleep cycles.
              </p>
              <p className="mt-3 text-xs text-[#F0EBDD]/75 leading-relaxed">
                Direct guidance on continuous glucose dynamics, micronutrient optimization, and circadian lighting exposure to maximize nighttime growth hormone secretion and restorative neuroplasticity.
              </p>

              <div className="mt-5 pt-4 border-t border-[#89949A]/15 space-y-2">
                <div className="flex items-center gap-2 text-xs text-[#F0EBDD]">
                  <Salad className="w-3.5 h-3.5 text-[#C6A46A]" />
                  <span>Clinical blood lipid & glucose profiling</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-[#F0EBDD]">
                  <Moon className="w-3.5 h-3.5 text-[#C6A46A]" />
                  <span>Circadian bedroom and sleep tracking setup</span>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-[#89949A]/15 flex items-center justify-between">
              <span className="text-[11px] text-[#89949A]">Continuous Monitoring</span>
              <button
                onClick={() => onBookTreatment('Metabolic Nutrition & Sleep')}
                className="text-xs font-semibold uppercase tracking-wider text-[#C6A46A] hover:text-[#F0EBDD] transition-colors"
              >
                Consult
              </button>
            </div>
          </div>
        </div>

        {/* Interactive Longevity & Biological Recovery Calculator */}
        <div className="bg-[#07121B] border border-[#C6A46A]/40 rounded p-8 sm:p-10 shadow-2xl">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-8">
              <div className="inline-flex items-center gap-1.5 text-xs uppercase tracking-[0.22em] text-[#C6A46A] font-semibold mb-2">
                <HeartPulse className="w-4 h-4 text-[#C6A46A]" />
                Interactive Diagnostic
              </div>
              <h3 className="font-serif text-2xl sm:text-3xl text-[#F0EBDD]">
                Personalized Longevity & Recovery Protocol
              </h3>
              <p className="text-xs sm:text-sm text-[#89949A] mt-2 font-sans">
                Adjust your training variables to view your estimated biological recovery baseline and recommended English Gym therapeutic cycle.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              {/* Training Days */}
              <div className="bg-[#111C25] p-5 rounded border border-[#89949A]/15">
                <label className="block text-xs uppercase tracking-wider text-[#89949A] mb-2">
                  Weekly Training Frequency
                </label>
                <div className="flex items-center justify-between">
                  <span className="font-serif text-2xl text-[#C6A46A]">{trainingDays} Days</span>
                  <input
                    type="range"
                    min="1"
                    max="7"
                    value={trainingDays}
                    onChange={(e) => setTrainingDays(Number(e.target.value))}
                    className="accent-[#C6A46A] cursor-pointer"
                  />
                </div>
              </div>

              {/* Sleep Hours */}
              <div className="bg-[#111C25] p-5 rounded border border-[#89949A]/15">
                <label className="block text-xs uppercase tracking-wider text-[#89949A] mb-2">
                  Nightly Deep Sleep
                </label>
                <div className="flex items-center justify-between">
                  <span className="font-serif text-2xl text-[#C6A46A]">{sleepHours} Hours</span>
                  <input
                    type="range"
                    min="4"
                    max="10"
                    step="0.5"
                    value={sleepHours}
                    onChange={(e) => setSleepHours(Number(e.target.value))}
                    className="accent-[#C6A46A] cursor-pointer"
                  />
                </div>
              </div>

              {/* Stress Baseline */}
              <div className="bg-[#111C25] p-5 rounded border border-[#89949A]/15">
                <label className="block text-xs uppercase tracking-wider text-[#89949A] mb-2">
                  Autonomic Work Stress
                </label>
                <div className="grid grid-cols-3 gap-1">
                  {(['low', 'moderate', 'high'] as const).map((lvl) => (
                    <button
                      key={lvl}
                      onClick={() => setStressLevel(lvl)}
                      className={`text-[10px] uppercase font-semibold py-1.5 rounded transition-all ${
                        stressLevel === lvl
                          ? 'bg-[#C6A46A] text-[#07121B]'
                          : 'bg-[#07121B] text-[#89949A] hover:text-[#F0EBDD]'
                      }`}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Calculated Output Card */}
            <div className="bg-[#183D35]/40 border border-[#C6A46A]/30 rounded p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-6">
                <div className="w-20 h-20 rounded-full border-4 border-[#C6A46A] flex flex-col items-center justify-center shrink-0 bg-[#07121B]">
                  <span className="font-serif text-2xl font-bold text-[#F0EBDD] tabular-nums leading-none">
                    {bioScore}
                  </span>
                  <span className="text-[8px] uppercase tracking-wider text-[#C6A46A] font-semibold mt-0.5">
                    INDEX
                  </span>
                </div>

                <div>
                  <div className="text-xs uppercase tracking-[0.2em] text-[#C6A46A] font-semibold">
                    Estimated Recovery Readiness
                  </div>
                  <h4 className="font-serif text-xl sm:text-2xl text-[#F0EBDD] mt-0.5">
                    {bioScore >= 80
                      ? 'Optimal Cellular Supercompensation'
                      : bioScore >= 65
                      ? 'Balanced Load & Reconditioning Required'
                      : 'Accumulated Fatigue – Prioritize Thermal Rest'}
                  </h4>
                  <p className="text-xs text-[#F0EBDD]/80 mt-1 max-w-lg">
                    {bioScore >= 80
                      ? 'Recommendation: 3x Cold Immersion (3°C) + 2x Contrast Therapy to accelerate muscle protein synthesis.'
                      : bioScore >= 65
                      ? 'Recommendation: 15 min Finnish Cedar Sauna (90°C) post-lift + 1 clinical sports massage session bi-weekly.'
                      : 'Recommendation: 20 min infrared thermal soak + full 8-hour sleep protocol before heavy neural barbell sessions.'}
                  </p>
                </div>
              </div>

              <button
                onClick={onJoinClick}
                className="shrink-0 px-6 py-3 text-xs font-semibold uppercase tracking-[0.18em] text-[#07121B] bg-[#C6A46A] hover:bg-[#D9B87F] rounded transition-all shadow-md cursor-pointer whitespace-nowrap"
              >
                Discuss with Club Doctor
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
