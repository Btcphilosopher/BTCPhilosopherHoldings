import React from 'react';

interface HeraldicLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showTagline?: boolean;
}

export function HeraldicLogo({
  className = '',
  size = 'md',
  showTagline = false,
}: HeraldicLogoProps) {
  const iconSizes = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-12 h-12',
  };

  return (
    <div className={`flex items-center gap-3.5 ${className}`}>
      {/* Heraldic Shield Crest */}
      <div className={`relative ${iconSizes[size]} flex-shrink-0 text-[#C6A46A]`}>
        <svg
          viewBox="0 0 100 120"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full drop-shadow-[0_2px_8px_rgba(198,164,106,0.2)]"
        >
          {/* Shield Outer Boundary */}
          <path
            d="M50 4L12 18V56C12 86 50 114 50 114C50 114 88 86 88 56V18L50 4Z"
            stroke="currentColor"
            strokeWidth="3.5"
            strokeLinejoin="round"
            fill="#07121B"
          />
          {/* Shield Inner Hairline */}
          <path
            d="M50 12L20 23V54C20 79 50 104 50 104C50 104 80 79 80 54V23L50 12Z"
            stroke="currentColor"
            strokeWidth="1.2"
            strokeOpacity="0.6"
          />
          {/* St George / British Cross Hairline */}
          <path
            d="M50 16V98M22 46H78"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeDasharray="2 2"
            strokeOpacity="0.4"
          />
          {/* Central Barbell & Crown Iconography */}
          {/* Barbell Bar */}
          <line
            x1="30"
            y1="50"
            x2="70"
            y2="50"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
          {/* Barbell Left Discs */}
          <rect x="34" y="42" width="4" height="16" rx="1" fill="currentColor" />
          <rect x="30" y="44" width="3" height="12" rx="0.5" fill="currentColor" opacity="0.8" />
          {/* Barbell Right Discs */}
          <rect x="62" y="42" width="4" height="16" rx="1" fill="currentColor" />
          <rect x="67" y="44" width="3" height="12" rx="0.5" fill="currentColor" opacity="0.8" />
          {/* Monogram E / Crown Motif */}
          <path
            d="M44 32H56M44 36H53M44 40H56M44 32V40"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="square"
          />
          {/* Bottom Star of Discipline */}
          <polygon
            points="50,68 52.5,74 59,74 54,78 56,84 50,80 44,84 46,78 41,74 47.5,74"
            fill="currentColor"
          />
        </svg>
      </div>

      {/* Typography Lockup */}
      <div className="flex flex-col text-left">
        <span className="font-serif text-lg md:text-xl font-bold tracking-[0.2em] text-[#F0EBDD] uppercase whitespace-nowrap leading-none">
          THE ENGLISH GYM
        </span>
        {showTagline ? (
          <span className="text-[9px] md:text-[10px] font-sans uppercase tracking-[0.26em] text-[#C6A46A] font-semibold mt-1 whitespace-nowrap">
            Strength · Discipline · Longevity
          </span>
        ) : (
          <span className="text-[8px] md:text-[9px] font-sans uppercase tracking-[0.22em] text-[#89949A] font-medium mt-0.5 whitespace-nowrap">
            Est. London · MMXVIII
          </span>
        )}
      </div>
    </div>
  );
}
