'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { CLUB_LOCATIONS, ClubLocation } from '@/lib/club-data';
import { MapPin, Clock, Phone, Mail, Navigation, CheckCircle, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

interface LocationFinderProps {
  onScheduleClubTour: (city: string) => void;
  selectedCity?: string;
}

export function LocationFinder({
  onScheduleClubTour,
  selectedCity: initialCity,
}: LocationFinderProps) {
  const [activeCityId, setActiveCityId] = useState<string>(
    initialCity
      ? CLUB_LOCATIONS.find((c) => c.city.toLowerCase() === initialCity.toLowerCase())?.id || 'london-mayfair'
      : 'london-mayfair'
  );

  const activeClub =
    CLUB_LOCATIONS.find((c) => c.id === activeCityId) || CLUB_LOCATIONS[0];

  return (
    <section id="locations" className="py-28 bg-[#0B1720] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 pb-6 border-b border-[#C6A46A]/20">
          <div>
            <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.26em] text-[#C6A46A] font-semibold mb-3">
              <span>National Presence</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#F0EBDD] font-normal tracking-tight">
              UK Club Locations
            </h2>
          </div>
          <p className="mt-4 md:mt-0 text-sm text-[#89949A] max-w-md leading-relaxed font-sans">
            Eight distinguished institutions across the United Kingdom. Standard and Premier members enjoy reciprocal access.
          </p>
        </div>

        {/* City Tab Selectors */}
        <div className="flex flex-wrap items-center gap-2 mb-10 pb-2 border-b border-[#89949A]/15 overflow-x-auto">
          {CLUB_LOCATIONS.map((club) => {
            const isActive = club.id === activeCityId;
            return (
              <button
                key={club.id}
                onClick={() => setActiveCityId(club.id)}
                className={`px-4 py-2 text-xs font-semibold uppercase tracking-[0.16em] rounded transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-[#C6A46A] text-[#07121B] shadow-sm'
                    : 'text-[#89949A] hover:text-[#F0EBDD] bg-[#111C25]/60 hover:bg-[#111C25]'
                }`}
              >
                <span>{club.city}</span>
              </button>
            );
          })}
        </div>

        {/* 2-Column Split: Active Club Card & Interactive UK Schematic Map */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Active Club Detailed Card (7 cols) */}
          <div className="lg:col-span-7 bg-[#111C25] border border-[#C6A46A]/30 rounded overflow-hidden shadow-xl">
            {/* Club Architectural Header Photo */}
            <div className="relative h-64 sm:h-80 w-full">
              <Image
                src={
                  activeClub.city === 'London'
                    ? '/images/hero_gym.jpg'
                    : activeClub.city === 'Manchester'
                    ? '/images/strength_hall.jpg'
                    : activeClub.city === 'Edinburgh'
                    ? '/images/wellness_pool.jpg'
                    : '/images/sunset_building.jpg'
                }
                alt={`${activeClub.city} location - The English Gym`}
                fill
                className="object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#111C25] via-[#111C25]/40 to-transparent" />
              <div className="absolute bottom-5 left-6 right-6 flex items-end justify-between">
                <div>
                  <span className="text-[10px] uppercase tracking-[0.24em] text-[#C6A46A] font-semibold block">
                    {activeClub.district}
                  </span>
                  <h3 className="font-serif text-2xl sm:text-4xl text-[#F0EBDD] font-bold">
                    The English Gym {activeClub.city}
                  </h3>
                </div>
                <div className="text-right">
                  <span className="text-xs uppercase tracking-wider text-[#C6A46A] bg-[#07121B]/90 px-3 py-1 rounded border border-[#C6A46A]/30 font-semibold">
                    {activeClub.status}
                  </span>
                </div>
              </div>
            </div>

            {/* Club Details Grid */}
            <div className="p-6 sm:p-8 space-y-6">
              {/* Address & Transit */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pb-6 border-b border-[#89949A]/15">
                <div>
                  <div className="text-[11px] uppercase tracking-wider text-[#89949A] flex items-center gap-1.5 mb-1.5">
                    <MapPin className="w-3.5 h-3.5 text-[#C6A46A]" />
                    <span>Address</span>
                  </div>
                  <div className="text-sm text-[#F0EBDD] font-medium">
                    {activeClub.address}
                  </div>
                  <div className="text-xs text-[#89949A] mt-0.5">
                    {activeClub.postcode}
                  </div>
                </div>

                <div>
                  <div className="text-[11px] uppercase tracking-wider text-[#89949A] flex items-center gap-1.5 mb-1.5">
                    <Navigation className="w-3.5 h-3.5 text-[#C6A46A]" />
                    <span>Transit & Metro</span>
                  </div>
                  <div className="text-sm text-[#F0EBDD] font-medium">
                    {activeClub.metro}
                  </div>
                  <div className="text-xs text-[#89949A] mt-0.5">
                    Club Scale: {activeClub.sizeSqFt}
                  </div>
                </div>
              </div>

              {/* Hours of Operation */}
              <div className="pb-6 border-b border-[#89949A]/15">
                <div className="text-[11px] uppercase tracking-wider text-[#89949A] flex items-center gap-1.5 mb-3">
                  <Clock className="w-3.5 h-3.5 text-[#C6A46A]" />
                  <span>Hours of Operation</span>
                </div>
                <div className="grid grid-cols-3 gap-3 text-xs">
                  <div className="bg-[#07121B] p-2.5 rounded border border-[#89949A]/15">
                    <span className="text-[#89949A] block text-[10px] uppercase">Mon – Fri</span>
                    <span className="text-[#F0EBDD] font-medium mt-0.5 block">{activeClub.hours.weekdays}</span>
                  </div>
                  <div className="bg-[#07121B] p-2.5 rounded border border-[#89949A]/15">
                    <span className="text-[#89949A] block text-[10px] uppercase">Saturday</span>
                    <span className="text-[#F0EBDD] font-medium mt-0.5 block">{activeClub.hours.saturday}</span>
                  </div>
                  <div className="bg-[#07121B] p-2.5 rounded border border-[#89949A]/15">
                    <span className="text-[#89949A] block text-[10px] uppercase">Sunday</span>
                    <span className="text-[#F0EBDD] font-medium mt-0.5 block">{activeClub.hours.sunday}</span>
                  </div>
                </div>
              </div>

              {/* Facility Highlights */}
              <div className="pb-6 border-b border-[#89949A]/15">
                <div className="text-[11px] uppercase tracking-wider text-[#C6A46A] font-semibold mb-2.5">
                  Distinctive Club Features
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-[#F0EBDD]/90">
                  {activeClub.highlights.map((h) => (
                    <div key={h} className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#C6A46A]" />
                      <span>{h}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Concierge & Action */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 pt-2">
                <div className="text-xs text-[#89949A] space-y-1">
                  <div className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-[#C6A46A]" />
                    <span className="text-[#F0EBDD]">{activeClub.phone}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-[#C6A46A]" />
                    <span>{activeClub.email}</span>
                  </div>
                </div>

                <button
                  onClick={() => onScheduleClubTour(activeClub.city)}
                  className="px-6 py-3 text-xs font-semibold uppercase tracking-[0.18em] text-[#07121B] bg-[#C6A46A] hover:bg-[#D9B87F] rounded transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                >
                  <span>Book Private Tour</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Right Column: UK Architectural Schematic Map (5 cols) */}
          <div className="lg:col-span-5 bg-[#111C25] border border-[#89949A]/20 rounded p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <div className="text-xs uppercase tracking-[0.24em] text-[#C6A46A] font-semibold mb-1">
                Interactive Directory
              </div>
              <h4 className="font-serif text-2xl text-[#F0EBDD]">
                United Kingdom Network
              </h4>
              <p className="text-xs text-[#89949A] mt-1.5">
                Click any pin on the map to inspect that location.
              </p>

              {/* Schematic Map Viewport */}
              <div className="relative mt-6 w-full aspect-[4/5] bg-[#07121B] rounded border border-[#89949A]/20 overflow-hidden p-4">
                {/* Stylized UK Outline SVG */}
                <svg
                  viewBox="0 0 100 120"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="w-full h-full opacity-30 text-[#89949A]"
                >
                  {/* Abstract stylized British Isles landmass contour */}
                  <path
                    d="M45 10 C55 12, 60 20, 52 28 C48 33, 56 38, 52 46 C48 52, 62 58, 65 68 C68 76, 76 80, 72 90 C68 98, 48 100, 38 96 C30 92, 34 82, 42 78 C40 70, 48 64, 46 56 C44 48, 40 40, 42 30 C44 20, 38 12, 45 10 Z"
                    stroke="currentColor"
                    strokeWidth="1.2"
                    fill="#183D35"
                    fillOpacity="0.3"
                  />
                  {/* Subtle latitude/longitude grid hairlines */}
                  <line x1="10" y1="30" x2="90" y2="30" stroke="currentColor" strokeWidth="0.5" strokeDasharray="1 3" />
                  <line x1="10" y1="60" x2="90" y2="60" stroke="currentColor" strokeWidth="0.5" strokeDasharray="1 3" />
                  <line x1="10" y1="90" x2="90" y2="90" stroke="currentColor" strokeWidth="0.5" strokeDasharray="1 3" />
                  <line x1="50" y1="10" x2="50" y2="110" stroke="currentColor" strokeWidth="0.5" strokeDasharray="1 3" />
                </svg>

                {/* Interactive Location Pins */}
                {CLUB_LOCATIONS.map((club) => {
                  const isSelected = club.id === activeCityId;
                  return (
                    <button
                      key={club.id}
                      onClick={() => setActiveCityId(club.id)}
                      style={{
                        left: `${club.coordinates.x}%`,
                        top: `${club.coordinates.y}%`,
                      }}
                      className={`absolute -translate-x-1/2 -translate-y-1/2 group focus:outline-none z-10 transition-transform ${
                        isSelected ? 'scale-125 z-20' : 'hover:scale-110'
                      }`}
                      aria-label={`Select ${club.city}`}
                    >
                      <div
                        className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center transition-all ${
                          isSelected
                            ? 'bg-[#C6A46A] border-[#F0EBDD] ring-4 ring-[#C6A46A]/30'
                            : 'bg-[#183D35] border-[#C6A46A] hover:bg-[#C6A46A]'
                        }`}
                      />
                      <span
                        className={`absolute top-4 left-1/2 -translate-x-1/2 whitespace-nowrap text-[9px] uppercase tracking-wider font-semibold px-1.5 py-0.5 rounded transition-all ${
                          isSelected
                            ? 'bg-[#C6A46A] text-[#07121B]'
                            : 'bg-[#07121B]/90 text-[#89949A] group-hover:text-[#F0EBDD]'
                        }`}
                      >
                        {club.city}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Reciprocal Privileges Note */}
            <div className="mt-6 pt-5 border-t border-[#89949A]/15 text-xs text-[#89949A]">
              <span className="text-[#C6A46A] font-semibold uppercase tracking-wider block mb-1">
                Reciprocal Access Policy
              </span>
              Premier and Founders Club memberships include unrestricted multi-club access across all UK institutions.
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
