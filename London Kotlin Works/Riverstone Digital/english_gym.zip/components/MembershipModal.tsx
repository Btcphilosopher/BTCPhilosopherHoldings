'use client';

import React, { useState } from 'react';
import { MEMBERSHIP_TIERS, CLUB_LOCATIONS } from '@/lib/club-data';
import { X, CheckCircle, ShieldCheck, ArrowRight, UserCheck, Calendar, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { HeraldicLogo } from './HeraldicLogo';

interface MembershipModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultTierId?: string;
  defaultCity?: string;
}

export function MembershipModal({
  isOpen,
  onClose,
  defaultTierId = 'premier',
  defaultCity = 'London',
}: MembershipModalProps) {
  const [selectedTier, setSelectedTier] = useState<string>(defaultTierId);
  const [selectedClub, setSelectedClub] = useState<string>(defaultCity);
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [goal, setGoal] = useState('Strength & Powerlifting');
  const [preferredDate, setPreferredDate] = useState('2026-11-05');
  const [submitted, setSubmitted] = useState(false);
  const [applicationRef, setApplicationRef] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !email) return;

    // Generate unique English Gym application reference
    const cityCode = selectedClub.substring(0, 3).toUpperCase();
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    const ref = `TEG-2026-${cityCode}-${randomNum}`;
    setApplicationRef(ref);
    setSubmitted(true);
  };

  const handleResetAndClose = () => {
    setSubmitted(false);
    onClose();
  };

  const activeTierObj =
    MEMBERSHIP_TIERS.find((t) => t.id === selectedTier) || MEMBERSHIP_TIERS[1];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-[#07121B]/95 backdrop-blur-md overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-[#111C25] border border-[#C6A46A]/40 rounded max-w-2xl w-full my-8 overflow-hidden shadow-2xl relative text-[#F0EBDD]"
      >
        {/* Close Button */}
        <button
          onClick={handleResetAndClose}
          className="absolute top-5 right-5 p-2 rounded text-[#89949A] hover:text-[#C6A46A] hover:bg-[#07121B] transition-colors z-20"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {!submitted ? (
          <div className="p-6 sm:p-10">
            {/* Modal Header */}
            <div className="border-b border-[#89949A]/20 pb-6 mb-8 text-center sm:text-left">
              <HeraldicLogo size="sm" showTagline={false} className="mb-4" />
              <div className="text-[10px] uppercase tracking-[0.24em] text-[#C6A46A] font-semibold">
                Membership Application & Concierge Consultation
              </div>
              <h3 className="font-serif text-2xl sm:text-3xl text-[#F0EBDD] font-bold mt-1">
                Apply for The English Gym
              </h3>
              <p className="text-xs text-[#89949A] mt-2 font-sans">
                Please complete your candidacy details. A membership director will review your submission and contact you within 24 hours.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Step 1: Select Tier */}
              <div>
                <label className="block text-xs uppercase tracking-wider font-semibold text-[#C6A46A] mb-3">
                  1. Desired Membership Category
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {MEMBERSHIP_TIERS.map((tier) => (
                    <button
                      type="button"
                      key={tier.id}
                      onClick={() => setSelectedTier(tier.id)}
                      className={`p-3.5 rounded text-left border transition-all cursor-pointer ${
                        selectedTier === tier.id
                          ? 'border-[#C6A46A] bg-[#07121B] text-[#F0EBDD] ring-1 ring-[#C6A46A]'
                          : 'border-[#89949A]/20 bg-[#07121B]/40 text-[#89949A] hover:border-[#89949A]/50'
                      }`}
                    >
                      <div className="font-serif font-bold text-sm text-[#F0EBDD]">
                        {tier.name}
                      </div>
                      <div className="text-xs text-[#C6A46A] mt-1 font-semibold">
                        £{tier.monthlyPrice} / mo
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 2: Preferred Home Club */}
              <div>
                <label className="block text-xs uppercase tracking-wider font-semibold text-[#C6A46A] mb-2">
                  2. Preferred Home Club
                </label>
                <select
                  value={selectedClub}
                  onChange={(e) => setSelectedClub(e.target.value)}
                  className="w-full bg-[#07121B] border border-[#89949A]/30 rounded px-4 py-3 text-xs sm:text-sm text-[#F0EBDD] focus:border-[#C6A46A] focus:outline-none"
                >
                  {CLUB_LOCATIONS.map((c) => (
                    <option key={c.id} value={c.city}>
                      The English Gym {c.city} — {c.district}
                    </option>
                  ))}
                </select>
              </div>

              {/* Step 3: Contact Information */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#89949A] mb-1.5">
                    Full Legal Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Lord Alistair Sterling"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full bg-[#07121B] border border-[#89949A]/30 rounded px-4 py-2.5 text-xs sm:text-sm text-[#F0EBDD] focus:border-[#C6A46A] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#89949A] mb-1.5">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="alistair@sterling.co.uk"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-[#07121B] border border-[#89949A]/30 rounded px-4 py-2.5 text-xs sm:text-sm text-[#F0EBDD] focus:border-[#C6A46A] focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#89949A] mb-1.5">
                    Telephone (Direct Mobile)
                  </label>
                  <input
                    type="tel"
                    placeholder="+44 7946 088012"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-[#07121B] border border-[#89949A]/30 rounded px-4 py-2.5 text-xs sm:text-sm text-[#F0EBDD] focus:border-[#C6A46A] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#89949A] mb-1.5">
                    Primary Athletic Discipline
                  </label>
                  <select
                    value={goal}
                    onChange={(e) => setGoal(e.target.value)}
                    className="w-full bg-[#07121B] border border-[#89949A]/30 rounded px-4 py-2.5 text-xs sm:text-sm text-[#F0EBDD] focus:border-[#C6A46A] focus:outline-none"
                  >
                    <option value="Strength & Powerlifting">Strength & Powerlifting</option>
                    <option value="Athletic Longevity & VO2 Max">Athletic Longevity & VO2 Max</option>
                    <option value="Traditional Boxing Conditioning">Traditional Boxing Conditioning</option>
                    <option value="Rehabilitation & Spinal Alignment">Rehabilitation & Spinal Alignment</option>
                    <option value="High-Performance Healthspan">High-Performance Healthspan</option>
                  </select>
                </div>
              </div>

              {/* Preferred Tour / Induction Date */}
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#89949A] mb-1.5">
                  Preferred Private Induction Date
                </label>
                <input
                  type="date"
                  value={preferredDate}
                  onChange={(e) => setPreferredDate(e.target.value)}
                  className="w-full bg-[#07121B] border border-[#89949A]/30 rounded px-4 py-2.5 text-xs sm:text-sm text-[#F0EBDD] focus:border-[#C6A46A] focus:outline-none"
                />
              </div>

              {/* Submission Button */}
              <div className="pt-4 border-t border-[#89949A]/20 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-2 text-xs text-[#89949A]">
                  <ShieldCheck className="w-4 h-4 text-[#C6A46A]" />
                  <span>Strict member privacy guaranteed</span>
                </div>

                <button
                  type="submit"
                  className="w-full sm:w-auto px-8 py-3.5 text-xs font-semibold uppercase tracking-[0.2em] text-[#07121B] bg-[#C6A46A] hover:bg-[#D9B87F] rounded transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Submit Application</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          </div>
        ) : (
          /* Prestigious Application Confirmation Screen */
          <div className="p-8 sm:p-12 text-center space-y-6">
            <div className="w-16 h-16 rounded-full bg-[#183D35] border-2 border-[#C6A46A] mx-auto flex items-center justify-center shadow-lg">
              <CheckCircle className="w-8 h-8 text-[#C6A46A]" />
            </div>

            <div className="text-xs uppercase tracking-[0.26em] text-[#C6A46A] font-semibold">
              Application Officially Received
            </div>

            <h3 className="font-serif text-3xl sm:text-4xl text-[#F0EBDD] font-bold">
              Welcome to the Candidacy, {fullName.split(' ')[0]}
            </h3>

            <p className="text-sm text-[#F0EBDD]/85 max-w-lg mx-auto font-sans leading-relaxed">
              Your application for <strong className="text-[#C6A46A]">{activeTierObj.name}</strong> at The English Gym <strong className="text-[#C6A46A]">{selectedClub}</strong> has been assigned to our Club Membership Director.
            </p>

            {/* Reference Badge */}
            <div className="bg-[#07121B] border border-[#C6A46A]/40 rounded p-4 max-w-md mx-auto text-left space-y-2">
              <div className="text-[10px] uppercase tracking-wider text-[#89949A]">
                Membership Application ID
              </div>
              <div className="font-mono text-lg text-[#C6A46A] font-bold tracking-wider">
                {applicationRef}
              </div>
              <div className="text-xs text-[#89949A] pt-2 border-t border-[#89949A]/15 flex items-center justify-between">
                <span>Club: {selectedClub}</span>
                <span>Tier: {activeTierObj.name}</span>
              </div>
            </div>

            <div className="pt-4 max-w-md mx-auto text-xs text-[#89949A] space-y-2 text-left">
              <div className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#C6A46A] mt-1.5 shrink-0" />
                <span>A confirmation dossier has been dispatched to {email}.</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#C6A46A] mt-1.5 shrink-0" />
                <span>Our concierge team will telephone you to confirm your private induction on {preferredDate}.</span>
              </div>
            </div>

            <div className="pt-6">
              <button
                onClick={handleResetAndClose}
                className="px-8 py-3 text-xs font-semibold uppercase tracking-[0.18em] text-[#07121B] bg-[#C6A46A] hover:bg-[#D9B87F] rounded transition-all"
              >
                Return to Club
              </button>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
}
