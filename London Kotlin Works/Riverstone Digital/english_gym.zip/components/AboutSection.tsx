'use client';

import React from 'react';
import Image from 'next/image';
import { Shield, BookOpen, Layers, CheckCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface AboutSectionProps {
  onJoinClick: () => void;
}

export function AboutSection({ onJoinClick }: AboutSectionProps) {
  const architecturalMaterials = [
    {
      name: 'Portland & York Stone',
      detail: 'Quarried in Britain for enduring solidity, thermal stability, and acoustic calm.',
    },
    {
      name: 'Dark English Oak',
      detail: 'Warm, tactile natural timber that softens concrete geometry with historic British warmth.',
    },
    {
      name: 'Solid Brushed Brass',
      detail: 'Uncoated architectural hardware that naturally patinas with human touch over decades.',
    },
    {
      name: 'Floor-to-Ceiling Glazing',
      detail: 'Connecting indoor physical exertion with natural daylight and the historic British cityscape.',
    },
  ];

  const timelineMilestones = [
    {
      era: 'The Tradition',
      title: 'Noble Athleticism & Classical Rigor',
      text: 'From the Thames rowing regattas and prizefighting academies to the Victorian sporting clubs, physical discipline has always stood at the centre of British civic character.',
    },
    {
      era: 'The Disruption',
      title: 'Rejecting Commercialized Mediocrity',
      text: 'By the 2010s, fitness had degenerated into crowded fluorescent basements, cheap plastic machines, and aggressive marketing. The dignity of physical training was lost.',
    },
    {
      era: 'The Supermodern Era',
      title: 'Founding The English Gym',
      text: 'Founded to unite English architectural heritage with Scandinavian precision iron, clinical sports science, and a sanctuary of quiet focus. A new standard for British life.',
    },
  ];

  return (
    <section id="about" className="py-28 bg-[#07121B] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header / Manifesto Lead */}
        <div className="max-w-4xl mx-auto text-center mb-20">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.28em] text-[#C6A46A] font-semibold mb-4">
            <Shield className="w-3.5 h-3.5 text-[#C6A46A]" />
            <span>The Institutional Manifesto</span>
          </div>

          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#F0EBDD] font-normal tracking-tight leading-tight">
            Strength is a British tradition.
          </h2>

          <div className="w-24 h-[1px] bg-[#C6A46A] mx-auto my-8" />

          <p className="text-base sm:text-lg md:text-xl text-[#F0EBDD]/90 font-light leading-relaxed font-sans text-balance">
            The English Gym believes that physical fitness is inseparable from intellectual discipline, personal responsibility and a healthy society.
          </p>

          <p className="mt-4 text-sm sm:text-base text-[#89949A] leading-relaxed max-w-2xl mx-auto font-sans">
            The brand draws inspiration from English sporting traditions, classical architecture, modern sports science and the enduring ideal of lifelong physical improvement. Our ambition is to establish a new standard for British fitness.
          </p>
        </div>

        {/* 2-Column Split: Architectural Heritage & Materials */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-24 pb-16 border-b border-[#C6A46A]/20">
          <div className="relative h-96 sm:h-[480px] rounded overflow-hidden border border-[#C6A46A]/30">
            <Image
              src="/images/sunset_building.jpg"
              alt="The English Gym architecture combining Portland stone, bronze glass, and English landscaping"
              fill
              className="object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#07121B] via-transparent to-transparent opacity-60" />
            <div className="absolute bottom-6 left-6 right-6 p-4 bg-[#07121B]/90 backdrop-blur-md rounded border border-[#C6A46A]/30">
              <span className="text-[10px] uppercase tracking-[0.24em] text-[#C6A46A] font-semibold block">
                Architectural Principle
              </span>
              <p className="font-serif text-lg text-[#F0EBDD] mt-1">
                Honesty of Materials · Monumental Daylight · Acoustic Quietude
              </p>
            </div>
          </div>

          <div className="space-y-8">
            <div>
              <div className="text-xs uppercase tracking-[0.22em] text-[#C6A46A] font-semibold mb-2">
                Spatial Philosophy
              </div>
              <h3 className="font-serif text-3xl sm:text-4xl text-[#F0EBDD]">
                Built Like an English Sanctuary
              </h3>
              <p className="mt-3 text-xs sm:text-sm text-[#89949A] leading-relaxed font-sans">
                We believe that the spaces in which humans train exert a profound psychological influence. Where commercial gyms offer noise and synthetic vinyl, The English Gym offers architectural proportion, tactile honesty, and cathedral-like reverence for physical exertion.
              </p>
            </div>

            {/* Material Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              {architecturalMaterials.map((mat) => (
                <div
                  key={mat.name}
                  className="p-4 bg-[#111C25] border border-[#89949A]/20 rounded"
                >
                  <div className="text-xs font-serif font-bold text-[#F0EBDD]">
                    {mat.name}
                  </div>
                  <div className="text-[11px] text-[#89949A] mt-1 leading-relaxed">
                    {mat.detail}
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-2">
              <button
                onClick={onJoinClick}
                className="px-6 py-3 text-xs font-semibold uppercase tracking-[0.18em] text-[#07121B] bg-[#C6A46A] hover:bg-[#D9B87F] rounded transition-all shadow-md cursor-pointer"
              >
                Experience The Standard
              </button>
            </div>
          </div>
        </div>

        {/* The Evolution Timeline */}
        <div>
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h3 className="font-serif text-3xl text-[#F0EBDD]">
              The Lineage of British Discipline
            </h3>
            <p className="text-xs sm:text-sm text-[#89949A] mt-2">
              From historic tradition to supermodern institution.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {timelineMilestones.map((item, idx) => (
              <div
                key={item.era}
                className="relative bg-[#111C25] border border-[#89949A]/15 rounded p-7 flex flex-col justify-between"
              >
                <div className="absolute top-4 right-4 font-serif text-xl font-bold text-[#C6A46A]/40">
                  0{idx + 1}
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-[0.24em] text-[#C6A46A] font-semibold mb-2">
                    {item.era}
                  </div>
                  <h4 className="font-serif text-xl text-[#F0EBDD] font-normal leading-snug">
                    {item.title}
                  </h4>
                  <p className="mt-3 text-xs text-[#89949A] leading-relaxed">
                    {item.text}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
