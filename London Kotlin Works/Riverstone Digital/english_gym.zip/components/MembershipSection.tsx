'use client';

import React, { useState } from 'react';
import { MEMBERSHIP_TIERS, CLUB_LOCATIONS, MembershipTier } from '@/lib/club-data';
import { Check, ShieldCheck, Sparkles, Clock, ArrowRight, UserCheck } from 'lucide-react';
import { motion } from 'motion/react';

interface MembershipSectionProps {
  onSelectTierForApplication: (tierId: string) => void;
}

export function MembershipSection({
  onSelectTierForApplication,
}: MembershipSectionProps) {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('monthly');

  return (
    <section id="membership" className="py-28 bg-[#07121B] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.26em] text-[#C6A46A] font-semibold mb-3">
            <span>Membership Tiers</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#F0EBDD] font-normal tracking-tight">
            A Commitment to Excellence
          </h2>
          <p className="mt-4 text-sm sm:text-base text-[#89949A] font-sans leading-relaxed">
            Membership is strictly curated to preserve space, quality, and calm across our institutions. Select the echelon that matches your pursuit.
          </p>

          {/* Billing Cycle Segmented Control */}
          <div className="mt-8 inline-flex items-center p-1 bg-[#111C25] border border-[#89949A]/20 rounded">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-5 py-2 text-xs font-semibold uppercase tracking-[0.16em] transition-all rounded ${
                billingCycle === 'monthly'
                  ? 'bg-[#C6A46A] text-[#07121B] shadow-sm'
                  : 'text-[#89949A] hover:text-[#F0EBDD]'
              }`}
            >
              Monthly Billing
            </button>
            <button
              onClick={() => setBillingCycle('annual')}
              className={`px-5 py-2 text-xs font-semibold uppercase tracking-[0.16em] transition-all rounded flex items-center gap-2 ${
                billingCycle === 'annual'
                  ? 'bg-[#C6A46A] text-[#07121B] shadow-sm'
                  : 'text-[#89949A] hover:text-[#F0EBDD]'
              }`}
            >
              <span>Annual Privilege</span>
              <span className="text-[10px] text-[#07121B] bg-[#F0EBDD] px-1.5 py-0.2 rounded font-bold">
                Save 15%
              </span>
            </button>
          </div>
        </div>

        {/* 3 Membership Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
          {MEMBERSHIP_TIERS.map((tier, idx) => {
            const isFeatured = tier.featured;
            const price = billingCycle === 'monthly' ? tier.monthlyPrice : Math.round(tier.annualPrice / 12);

            return (
              <motion.div
                key={tier.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.7, delay: idx * 0.15 }}
                className={`relative flex flex-col justify-between rounded p-8 transition-all duration-300 ${
                  isFeatured
                    ? 'bg-[#111C25] border-2 border-[#C6A46A] shadow-[0_8px_32px_rgba(198,164,106,0.15)] lg:-translate-y-2'
                    : 'bg-[#111C25]/80 border border-[#89949A]/20 hover:border-[#C6A46A]/40'
                }`}
              >
                {/* Featured Crest Marker */}
                {isFeatured && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-[#C6A46A] text-[#07121B] text-[10px] uppercase font-bold tracking-[0.24em] px-4 py-1 rounded shadow-md whitespace-nowrap">
                    Most Popular Choice
                  </div>
                )}

                <div>
                  {/* Category Name & Tagline */}
                  <div className="border-b border-[#89949A]/15 pb-6">
                    <h3 className="font-serif text-2xl sm:text-3xl text-[#F0EBDD] tracking-wide">
                      {tier.name}
                    </h3>
                    <p className="mt-2 text-xs text-[#89949A] leading-relaxed min-h-[36px]">
                      {tier.tagline}
                    </p>
                  </div>

                  {/* Pricing Display */}
                  <div className="py-6 border-b border-[#89949A]/15">
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-sm font-sans text-[#C6A46A] font-semibold">£</span>
                      <span className="font-serif text-4xl sm:text-5xl font-bold text-[#F0EBDD] tabular-nums tracking-tight">
                        {price}
                      </span>
                      <span className="text-xs uppercase tracking-wider text-[#89949A]">
                        / month
                      </span>
                    </div>
                    <div className="mt-1 text-[11px] text-[#89949A]">
                      {billingCycle === 'annual'
                        ? `Billed annually (£${tier.annualPrice}/yr)`
                        : 'Billed monthly with no long-term lock-in'}
                    </div>

                    {/* Access Hours */}
                    <div className="mt-3 flex items-center gap-1.5 text-xs text-[#C6A46A]">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{tier.accessHours}</span>
                    </div>
                  </div>

                  {/* Included Features List */}
                  <div className="pt-6">
                    <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#89949A] mb-3">
                      Included Privileges
                    </div>
                    <ul className="space-y-3 text-xs text-[#F0EBDD]/90">
                      {tier.features.map((feature) => (
                        <li key={feature} className="flex items-start gap-2.5">
                          <Check className="w-4 h-4 text-[#C6A46A] shrink-0 mt-0.5" />
                          <span className="leading-snug">{feature}</span>
                        </li>
                      ))}
                    </ul>

                    {/* Exclusive Perks */}
                    {tier.exclusivePerks.length > 0 && (
                      <div className="mt-6 pt-5 border-t border-[#89949A]/15">
                        <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#C6A46A] mb-2.5 flex items-center gap-1.5">
                          <Sparkles className="w-3 h-3 text-[#C6A46A]" />
                          Exclusive Honours
                        </div>
                        <ul className="space-y-2 text-xs text-[#89949A]">
                          {tier.exclusivePerks.map((perk) => (
                            <li key={perk} className="flex items-start gap-2">
                              <span className="text-[#C6A46A]">·</span>
                              <span>{perk}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>

                {/* Apply Button */}
                <div className="pt-8 mt-8 border-t border-[#89949A]/15">
                  <button
                    onClick={() => onSelectTierForApplication(tier.id)}
                    className={`w-full py-3.5 flex items-center justify-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] rounded transition-all cursor-pointer ${
                      isFeatured
                        ? 'bg-[#C6A46A] text-[#07121B] hover:bg-[#D9B87F] shadow-[0_2px_16px_rgba(198,164,106,0.3)]'
                        : 'bg-[#183D35] text-[#F0EBDD] hover:bg-[#1E4D43] border border-[#C6A46A]/30'
                    }`}
                  >
                    <span>Apply for {tier.name}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Member Application Assurance Notice */}
        <div className="mt-16 bg-[#111C25] border border-[#C6A46A]/20 rounded p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded bg-[#07121B] border border-[#C6A46A]/30 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-6 h-6 text-[#C6A46A]" />
            </div>
            <div>
              <div className="font-serif text-lg text-[#F0EBDD]">The English Gym Curation Standard</div>
              <p className="text-xs text-[#89949A] mt-1">
                To guarantee uncrowded lifting platforms, pristine wellness water, and immediate coach access, all applications undergo personal review by the club director within 24 hours.
              </p>
            </div>
          </div>
          <button
            onClick={() => onSelectTierForApplication('standard')}
            className="shrink-0 px-6 py-3 text-xs font-semibold uppercase tracking-[0.18em] text-[#C6A46A] hover:text-[#F0EBDD] border border-[#C6A46A]/50 hover:border-[#C6A46A] rounded transition-colors whitespace-nowrap"
          >
            Schedule Private Tour First
          </button>
        </div>
      </div>
    </section>
  );
}
