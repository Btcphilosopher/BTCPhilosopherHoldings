'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShoppingCart, 
  Search, 
  Heart, 
  User, 
  ChevronRight, 
  X, 
  Minus, 
  Plus, 
  Check, 
  Sparkles, 
  Flame, 
  Shield, 
  Truck, 
  Tag, 
  MapPin, 
  Phone, 
  Info, 
  LogOut, 
  Eye, 
  UserPlus, 
  Clock,
  ArrowRight,
  Filter
} from 'lucide-react';

// Image Imports matching generated files
import heroVegetablesBasket from '../src/assets/images/hero_vegetables_basket_1791448906910.jpg';
import productFreshTomatoes from '../src/assets/images/product_fresh_tomatoes_1791448918541.jpg';
import productFreshEggs from '../src/assets/images/product_fresh_eggs_1791448927976.jpg';
import productShanghaiBokchoy from '../src/assets/images/product_shanghai_bokchoy_1791448935780.jpg';
import productPureMilkBox from '../src/assets/images/product_pure_milk_box_1791448944246.jpg';
import productYunnanBlueberries from '../src/assets/images/product_yunnan_blueberries_1791448952705.jpg';
import productThaiDurian from '../src/assets/images/product_thai_durian_1791448961033.jpg';
import promoDailySpecial from '../src/assets/images/promo_daily_special_1791448969960.jpg';
import footerMistyMountains from '../src/assets/images/footer_misty_mountains_1791448980378.jpg';

// Types and Interfaces
interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  category: string;
  image: any;
  badge?: string;
  spec: string;
  description: string;
  stock: number;
}

interface CartItem {
  product: Product;
  quantity: number;
}

interface Order {
  id: string;
  items: CartItem[];
  total: number;
  date: string;
  name: string;
  phone: string;
  address: string;
  paymentMethod: string;
  status: string;
}

interface UserProfile {
  phone: string;
  points: number;
  level: string;
  balance: number;
}

// Deterministic state-independent order generator to comply with ESLint purity rules
let orderCounter = 1;
function getDeterministicOrderId(phone: string, total: number) {
  const lastFour = phone.length >= 4 ? phone.slice(-4) : '5678';
  const phoneInt = parseInt(lastFour) || 5678;
  const hash = (phoneInt * 17 + Math.floor(total * 100) + orderCounter) % 900000;
  orderCounter += 1;
  return `HJ${100000 + hash}`;
}

export default function Home() {
  // --- Data Store ---
  const products: Product[] = [
    {
      id: 'tomato',
      name: '新鲜西红柿',
      price: 3.98,
      originalPrice: 6.90,
      category: '新鲜蔬果',
      image: productFreshTomatoes,
      badge: '特惠',
      spec: '500g',
      description: '精选优质大红西红柿，沙瓤多汁，酸甜可口。富含番茄红素与维生素C，不论是做番茄炒蛋还是凉拌、沙拉，都是餐桌上的生鲜极品。',
      stock: 150
    },
    {
      id: 'egg',
      name: '正大鲜鸡蛋',
      price: 8.90,
      originalPrice: 12.90,
      category: '肉禽蛋奶',
      image: productFreshEggs,
      badge: '特惠',
      spec: '10枚',
      description: '正大食品出品，精选健康蛋鸡，科学饲养。每枚鸡蛋都经过紫外线杀菌与严格筛选，蛋黄饱满、蛋清浓稠，营养丰富，是每日早餐的不二之选。',
      stock: 80
    },
    {
      id: 'bokchoy',
      name: '上海青',
      price: 2.98,
      originalPrice: 5.90,
      category: '新鲜蔬果',
      image: productShanghaiBokchoy,
      badge: '特惠',
      spec: '500g',
      description: '本地直采新鲜上海青，叶绿茎白，口感清脆。绿色无公害种植，富含膳食纤维，清炒、下火锅或作汤底配菜皆宜。',
      stock: 200
    },
    {
      id: 'milk',
      name: '伊利纯牛奶',
      price: 59.90,
      originalPrice: 79.90,
      category: '肉禽蛋奶',
      image: productPureMilkBox,
      badge: '特惠',
      spec: '250ml*24',
      description: '伊利高品质纯牛奶整箱装，100%优质生牛乳，保留牛奶原始纯香与丰富营养。高钙高蛋白，全家共享的健康好奶。',
      stock: 45
    },
    {
      id: 'blueberry',
      name: '云南蓝莓',
      price: 12.90,
      category: '新鲜蔬果',
      image: productYunnanBlueberries,
      badge: '新品',
      spec: '125g',
      description: '来自云南高原纯净温差产区，手工采采。颗颗饱满带果粉，口感爽脆，酸甜适口，含有丰富的花青素，健康好滋味。',
      stock: 120
    },
    {
      id: 'durian',
      name: '泰国金枕头榴莲',
      price: 39.90,
      category: '新鲜蔬果',
      image: productThaiDurian,
      badge: '新品',
      spec: '1kg',
      description: '正宗泰国进口金枕头榴莲，产地直达。果肉金黄丰腴，口感如冰淇淋般细腻绵密，浓郁香甜，齿颊留香。',
      stock: 30
    },
    // Extra products to make app functional across other categories
    {
      id: 'sea-bass',
      name: '鲜活鲈鱼',
      price: 18.80,
      category: '海鲜水产',
      image: productFreshTomatoes, // Fallback visual
      spec: '500g-600g',
      description: '野生捕捞或生态养殖鲈鱼，肉质细嫩，无细刺，清蒸最佳，味道极其鲜美。',
      stock: 25
    },
    {
      id: 'oil',
      name: '金龙鱼黄金比例调和油',
      price: 68.90,
      category: '粮油调味',
      image: productPureMilkBox, // Fallback visual
      spec: '5L',
      description: '倡导膳食脂肪酸黄金比例1:1:1，科学配比，富含多种植物营养，适合日常各种烹饪方式。',
      stock: 90
    },
    {
      id: 'nuts',
      name: '三只松鼠每日坚果',
      price: 59.00,
      category: '休闲零食',
      image: productYunnanBlueberries, // Fallback visual
      spec: '750g',
      description: '精选全球优质坚果与干果，科学搭配，果仁香脆，干果清甜，每日一包，健康活力。',
      stock: 110
    },
    {
      id: 'soda',
      name: '元气森林白桃气泡水',
      price: 45.90,
      category: '饮料酒水',
      image: productPureMilkBox, // Fallback visual
      spec: '480ml*12',
      description: '0糖0脂0卡，添加真果汁，清新白桃香气，充沛气泡带来沁爽口感，畅饮无负担。',
      stock: 150
    },
    {
      id: 'paper',
      name: '维达超韧抽纸',
      price: 49.90,
      category: '日用百货',
      image: productFreshEggs, // Fallback visual
      spec: '3层100抽*24包',
      description: '精选进口优质原生木浆，超韧纤维湿水不易破。无化学添加，亲肤柔韧，家庭必备。',
      stock: 200
    }
  ];

  const categories = [
    '新鲜蔬果',
    '肉禽蛋奶',
    '海鲜水产',
    '粮油调味',
    '休闲零食',
    '饮料酒水',
    '日用百货',
    '家居清洁',
    '个护美妆',
    '母婴用品'
  ];

  // --- States ---
  const [cart, setCart] = useState<CartItem[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const stored = localStorage.getItem('hj_cart');
        return stored ? JSON.parse(stored) : [];
      } catch (e) {
        return [];
      }
    }
    return [];
  });

  const [favorites, setFavorites] = useState<Product[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const stored = localStorage.getItem('hj_favorites');
        return stored ? JSON.parse(stored) : [];
      } catch (e) {
        return [];
      }
    }
    return [];
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const stored = localStorage.getItem('hj_orders');
        return stored ? JSON.parse(stored) : [];
      } catch (e) {
        return [];
      }
    }
    return [];
  });

  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    if (typeof window !== 'undefined') {
      try {
        const stored = localStorage.getItem('hj_user');
        return stored ? JSON.parse(stored) : null;
      } catch (e) {
        return null;
      }
    }
    return null;
  });
  
  const [activeTab, setActiveTab] = useState<string>('首页'); // '首页' | '限时特惠' | '新品专区' | '品牌馆' | '会员中心'
  const [selectedCategory, setSelectedCategory] = useState<string>('all'); // 'all' or specific category name
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Carousel State
  const [currentSlide, setCurrentSlide] = useState<number>(0);
  const slides = [
    {
      title: '当季新鲜蔬果',
      subtitle: '从田间到餐桌 每一口都是自然的味道',
      tag: '新鲜直达',
      buttonText: '立即选购',
      image: heroVegetablesBasket,
      bgColor: 'bg-emerald-50/90'
    },
    {
      title: '中秋国庆团圆季',
      subtitle: '精选生鲜礼盒、高档纯乳制品，尊享特惠折扣',
      tag: '好礼相送',
      buttonText: '会员抢购',
      image: heroVegetablesBasket,
      bgColor: 'bg-green-50/90'
    },
    {
      title: '产地原箱直采',
      subtitle: '省去中间商，天天平价，30分钟冷链急达',
      tag: '平价保障',
      buttonText: '了解详情',
      image: heroVegetablesBasket,
      bgColor: 'bg-teal-50/90'
    }
  ];

  // UI Drawer / Modal States
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isFavoritesOpen, setIsFavoritesOpen] = useState(false);
  const [isOrdersOpen, setIsOrdersOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  
  // Auth Form State
  const [authPhone, setAuthPhone] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  
  // Checkout Form State
  const [shippingName, setShippingName] = useState('');
  const [shippingPhone, setShippingPhone] = useState('');
  const [shippingAddress, setShippingAddress] = useState('上海市浦东新区张江高科技园区');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'online'>('cod');
  
  // Toast notifications state
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' } | null>(null);

  // Countdown timer state for Limited Time Offers
  const [countdown, setCountdown] = useState({ hours: 12, minutes: 45, seconds: 30 });

  // --- Effects ---
  // Countdown decrement
  useEffect(() => {
    const interval = setInterval(() => {
      setCountdown(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else {
          // Reset countdown back to 12 hours
          return { hours: 12, minutes: 45, seconds: 30 };
        }
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Sync to LocalStorage
  const saveCart = (newCart: CartItem[]) => {
    setCart(newCart);
    localStorage.setItem('hj_cart', JSON.stringify(newCart));
  };

  const saveFavorites = (newFavs: Product[]) => {
    setFavorites(newFavs);
    localStorage.setItem('hj_favorites', JSON.stringify(newFavs));
  };

  const saveOrders = (newOrders: Order[]) => {
    setOrders(newOrders);
    localStorage.setItem('hj_orders', JSON.stringify(newOrders));
  };

  const saveUser = (user: UserProfile | null) => {
    setCurrentUser(user);
    if (user) {
      localStorage.setItem('hj_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('hj_user');
    }
  };

  // Carousel slide auto-advance
  useEffect(() => {
    const slideInterval = setInterval(() => {
      setCurrentSlide(prev => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(slideInterval);
  }, [slides.length]);

  // Toast helper
  const showToast = (message: string, type: 'success' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 3000);
  };

  // --- Actions ---
  const handleAddToCart = (product: Product, quantity = 1, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    
    const existingIndex = cart.findIndex(item => item.product.id === product.id);
    let newCart = [...cart];
    if (existingIndex > -1) {
      newCart[existingIndex].quantity += quantity;
    } else {
      newCart.push({ product, quantity });
    }
    saveCart(newCart);
    showToast(`已将 ${product.name} 添加至购物车！`);
  };

  const handleUpdateQuantity = (productId: string, delta: number) => {
    const existingIndex = cart.findIndex(item => item.product.id === productId);
    if (existingIndex === -1) return;

    let newCart = [...cart];
    newCart[existingIndex].quantity += delta;
    if (newCart[existingIndex].quantity <= 0) {
      newCart.splice(existingIndex, 1);
    }
    saveCart(newCart);
  };

  const handleToggleFavorite = (product: Product, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const isFav = favorites.some(item => item.id === product.id);
    let newFavs = [];
    if (isFav) {
      newFavs = favorites.filter(item => item.id !== product.id);
      showToast(`已取消收藏 ${product.name}`, 'info');
    } else {
      newFavs = [...favorites, product];
      showToast(`已添加 ${product.name} 到我的收藏！`);
    }
    saveFavorites(newFavs);
  };

  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authPhone) {
      showToast('请输入手机号', 'info');
      return;
    }

    if (authMode === 'login') {
      // Simple Login mock
      const mockUser: UserProfile = {
        phone: authPhone,
        points: 245,
        level: '黄金会员',
        balance: 150.00
      };
      saveUser(mockUser);
      showToast('登录成功，欢迎回来！');
    } else {
      // Register mock
      const mockUser: UserProfile = {
        phone: authPhone,
        points: 100, // Gift 100 points
        level: '普通会员',
        balance: 0.00
      };
      saveUser(mockUser);
      showToast('注册成功！已赠送您 100 会员积分。');
    }
    setIsAuthOpen(false);
  };

  const handleLogout = () => {
    saveUser(null);
    showToast('已退出登录', 'info');
  };

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!shippingName || !shippingPhone || !shippingAddress) {
      showToast('请完整填写收货人信息', 'info');
      return;
    }

    const finalTotal = getCartTotal() + (getCartTotal() >= 59 ? 0 : 6);
    const orderId = getDeterministicOrderId(shippingPhone, finalTotal);
    const newOrder: Order = {
      id: orderId,
      items: [...cart],
      total: finalTotal,
      date: new Date().toLocaleDateString('zh-CN'),
      name: shippingName,
      phone: shippingPhone,
      address: shippingAddress,
      paymentMethod: paymentMethod === 'cod' ? '货到付款' : '在线支付',
      status: '待发货'
    };

    saveOrders([newOrder, ...orders]);
    saveCart([]); // Clear cart
    setIsCheckoutOpen(false);
    setIsCartOpen(false);
    
    // Add points to user if logged in
    if (currentUser) {
      const earnedPoints = Math.floor(newOrder.total);
      saveUser({
        ...currentUser,
        points: currentUser.points + earnedPoints
      });
    }

    showToast(`订单提交成功！单号: ${orderId}`);
    setIsOrdersOpen(true); // Open orders summary list
  };

  // Calculations
  const getCartCount = () => cart.reduce((sum, item) => sum + item.quantity, 0);
  const getCartTotal = () => cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);

  // Filter products by category & search
  const filteredProducts = products.filter(product => {
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          product.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          product.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800 antialiased flex flex-col selection:bg-emerald-100 selection:text-emerald-900">
      
      {/* 1. TOP NOTICE BAR / MINI HEADER (Green/Dark Teal banner) */}
      <div className="bg-emerald-900 text-emerald-100 text-xs py-2 px-4 sm:px-6 md:px-12 flex justify-between items-center whitespace-nowrap overflow-x-auto gap-4 shrink-0 shadow-inner">
        <div className="flex items-center gap-4 text-emerald-200">
          <span className="flex items-center gap-1 font-medium"><Sparkles className="w-3.5 h-3.5 text-amber-300" /> 新鲜</span>
          <span aria-hidden="true">·</span>
          <span className="font-medium">便宜</span>
          <span aria-hidden="true">·</span>
          <span className="font-medium">放心</span>
        </div>
        <div className="flex items-center gap-5">
          <span className="text-emerald-300 hidden md:inline">满59元免运费（部分地区除外）</span>
          <div className="flex items-center gap-3">
            {currentUser ? (
              <div className="flex items-center gap-3">
                <span className="text-emerald-200">您好, <span className="font-semibold text-white">{currentUser.phone}</span> ({currentUser.level})</span>
                <span className="text-emerald-400">|</span>
                <button 
                  onClick={handleLogout}
                  className="hover:text-white transition-colors flex items-center gap-1 cursor-pointer font-medium"
                >
                  <LogOut className="w-3 h-3" /> 退出
                </button>
              </div>
            ) : (
              <>
                <button 
                  onClick={() => { setAuthMode('login'); setIsAuthOpen(true); }}
                  className="hover:text-white transition-colors cursor-pointer font-medium"
                >
                  登录
                </button>
                <span className="text-emerald-600">|</span>
                <button 
                  onClick={() => { setAuthMode('register'); setIsAuthOpen(true); }}
                  className="hover:text-white transition-colors cursor-pointer font-medium"
                >
                  注册
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* 2. BRAND & SEARCH HEADER (White Background) */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40 transition-shadow duration-200 px-4 sm:px-6 md:px-12 py-3.5 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        
        {/* Brand Zone */}
        <div 
          onClick={() => { setSelectedCategory('all'); setActiveTab('首页'); setSearchQuery(''); }}
          className="flex items-center gap-3 cursor-pointer shrink-0 group select-none"
        >
          <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white shadow-md shadow-emerald-200 group-hover:scale-105 transition-transform duration-200">
            <ShoppingCart className="w-5.5 h-5.5" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-emerald-900 flex items-center gap-2">
              惠家超市
            </h1>
            <p className="text-[10px] text-slate-500 tracking-widest font-medium uppercase">让 生活 更 简单</p>
          </div>
        </div>

        {/* Center Zone: Search bar */}
        <div className="flex-1 max-w-xl md:mx-8">
          <div className="relative flex items-center">
            <input
              type="text"
              placeholder="搜索商品、品牌、分类..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-4 pr-12 py-2.5 rounded-full border-2 border-emerald-600 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 bg-slate-50 focus:bg-white transition-all text-slate-900 shadow-sm"
            />
            <button 
              className="absolute right-1.5 p-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-full transition-colors cursor-pointer shadow-sm"
              aria-label="Submit search"
            >
              <Search className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Right Zone: Interactive Icons */}
        <div className="flex items-center justify-between md:justify-end gap-5 shrink-0 text-slate-700 text-sm font-medium">
          
          <button 
            onClick={() => setIsOrdersOpen(true)}
            className="flex items-center gap-1.5 hover:text-emerald-700 transition-colors p-1.5 rounded-lg hover:bg-slate-50 cursor-pointer"
          >
            <User className="w-5 h-5 text-slate-500" />
            <span className="hidden sm:inline">我的订单</span>
          </button>

          <button 
            onClick={() => setIsFavoritesOpen(true)}
            className="flex items-center gap-1.5 hover:text-emerald-700 transition-colors p-1.5 rounded-lg hover:bg-slate-50 cursor-pointer relative"
          >
            <Heart className="w-5 h-5 text-rose-500 fill-rose-500/10 hover:fill-rose-500 transition-colors" />
            <span className="hidden sm:inline">收藏</span>
            {favorites.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[10px] font-bold rounded-full w-4.5 h-4.5 flex items-center justify-center scale-95 animate-pulse">
                {favorites.length}
              </span>
            )}
          </button>

          <button 
            onClick={() => setIsCartOpen(true)}
            className="flex items-center gap-1.5 hover:text-emerald-700 transition-colors bg-emerald-50 hover:bg-emerald-100 text-emerald-800 px-4 py-2 rounded-full cursor-pointer relative shadow-sm"
          >
            <ShoppingCart className="w-5 h-5 text-emerald-700" />
            <span className="font-semibold">{getCartCount() > 0 ? `购物车` : '购物车'}</span>
            <span className="bg-red-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center font-mono shadow-md">
              {getCartCount()}
            </span>
          </button>

        </div>
      </header>

      {/* 3. MAIN NAVIGATION TABS */}
      <nav className="bg-white border-b border-slate-200/80 px-4 sm:px-6 md:px-12 py-1 sticky top-[69px] md:top-[73px] z-30 shadow-sm flex items-center justify-between">
        <div className="flex items-center gap-1 overflow-x-auto scrollbar-none py-1.5 w-full">
          {/* Header classification placeholder */}
          <div className="flex items-center gap-2 font-bold text-slate-900 bg-slate-100 text-xs px-3 py-1.5 rounded-lg mr-4 whitespace-nowrap hidden lg:flex">
            <span className="w-2.5 h-2.5 bg-emerald-600 rounded-full animate-ping"></span>
            全部商品分类
          </div>

          {['首页', '限时特惠', '新品专区', '品牌馆', '会员中心'].map((tab) => (
            <button
              key={tab}
              onClick={() => {
                setActiveTab(tab);
                setSearchQuery('');
                if (tab === '首页') {
                  setSelectedCategory('all');
                } else if (tab === '限时特惠') {
                  setSelectedCategory('新鲜蔬果'); // Focus on main deals
                } else if (tab === '新品专区') {
                  setSelectedCategory('新鲜蔬果');
                } else if (tab === '会员中心') {
                  if (!currentUser) {
                    setAuthMode('login');
                    setIsAuthOpen(true);
                  }
                }
              }}
              className={`px-4 py-1.5 rounded-lg text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === tab
                  ? 'bg-emerald-700 text-white shadow-sm shadow-emerald-100'
                  : 'text-slate-600 hover:text-slate-950 hover:bg-slate-100/75'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </nav>

      {/* 4. HERO LAYOUT & CAROUSEL */}
      {activeTab === '首页' && searchQuery === '' && selectedCategory === 'all' && (
        <section className="px-4 sm:px-6 md:px-12 py-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          
          {/* Left Menu Panel: All Product Categories */}
          <aside className="lg:col-span-3 bg-white rounded-2xl border border-slate-200/80 p-3 flex flex-col justify-between shadow-sm hidden lg:flex">
            <div className="space-y-1">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`w-full text-left flex items-center justify-between px-3 py-2 text-sm font-medium rounded-xl transition-all cursor-pointer ${
                    selectedCategory === cat
                      ? 'bg-emerald-50 text-emerald-800 font-semibold'
                      : 'text-slate-600 hover:text-slate-950 hover:bg-slate-50'
                  }`}
                >
                  <span>{cat}</span>
                  <ChevronRight className="w-4 h-4 text-slate-400 opacity-60" />
                </button>
              ))}
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 text-xs text-slate-400 text-center font-medium">
              30分钟冷链急送达 · 天天平价
            </div>
          </aside>

          {/* Center Banner: Interactive Carousel */}
          <div className="col-span-1 lg:col-span-6 relative overflow-hidden rounded-2xl border border-slate-200/80 shadow-md bg-white min-h-[320px] md:min-h-[360px] flex">
            
            <AnimatePresence mode="wait">
              <motion.div
                key={currentSlide}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.5, ease: 'easeInOut' }}
                className={`absolute inset-0 p-6 md:p-8 flex flex-col md:flex-row items-center justify-between gap-6 ${slides[currentSlide].bgColor}`}
              >
                {/* Text Content */}
                <div className="flex-1 space-y-4 text-left z-10">
                  <span className="inline-block bg-emerald-600 text-white text-[11px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider shadow-sm">
                    {slides[currentSlide].tag}
                  </span>
                  <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-emerald-950 leading-tight">
                    {slides[currentSlide].title}
                  </h2>
                  <p className="text-sm md:text-base text-emerald-800 max-w-xs font-medium">
                    {slides[currentSlide].subtitle}
                  </p>
                  <button 
                    onClick={() => setSelectedCategory('新鲜蔬果')}
                    className="inline-flex items-center gap-1.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs sm:text-sm font-semibold px-5 py-2.5 rounded-xl transition-all shadow-md shadow-emerald-900/10 cursor-pointer"
                  >
                    <span>{slides[currentSlide].buttonText}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>

                {/* Visual Imagery */}
                <div className="w-full md:w-1/2 h-[180px] md:h-full relative shrink-0">
                  <Image
                    src={slides[currentSlide].image}
                    alt={slides[currentSlide].title}
                    fill
                    sizes="(max-width: 768px) 100vw, 50vw"
                    className="object-contain hover:scale-105 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                    priority
                  />
                  {/* Subtle Badge */}
                  <div className="absolute right-2 bottom-2 bg-amber-400 text-amber-950 text-[10px] sm:text-xs font-bold px-3 py-1.5 rounded-2xl shadow-lg border border-amber-300/50 flex flex-col items-center">
                    <span className="font-semibold text-center leading-tight">每日新鲜</span>
                    <span className="opacity-90 font-medium">品质保证</span>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Slide Navigation Buttons (Dots) */}
            <div className="absolute bottom-4 left-6 md:left-8 flex gap-2 z-20">
              {slides.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentSlide(idx)}
                  className={`w-2.5 h-2.5 rounded-full transition-all cursor-pointer ${
                    currentSlide === idx ? 'bg-emerald-800 w-6' : 'bg-slate-300'
                  }`}
                  aria-label={`Go to slide ${idx + 1}`}
                />
              ))}
            </div>
          </div>

          {/* Right VIP panel + service highlights */}
          <div className="col-span-1 lg:col-span-3 flex flex-col gap-4">
            
            {/* VIP Registration Promo card */}
            <div className="bg-gradient-to-br from-emerald-800 to-teal-950 text-white p-5 rounded-2xl shadow-md border border-emerald-700/30 flex flex-col justify-between relative overflow-hidden group min-h-[160px] flex-1">
              {/* Background Graphic */}
              <div className="absolute right-0 bottom-0 opacity-10 translate-x-3 translate-y-3 group-hover:scale-110 transition-transform duration-300">
                <ShoppingCart className="w-32 h-32 text-white" />
              </div>

              <div>
                <div className="flex items-center gap-1.5 text-xs text-amber-300 font-bold mb-1">
                  <span className="px-1.5 py-0.5 bg-amber-400/20 text-amber-300 rounded border border-amber-300/30">VIP</span>
                  注册会员 · 享专属优惠
                </div>
                <h3 className="text-xl font-bold tracking-tight text-white mb-2">
                  成为惠家尊贵会员
                </h3>
                <ul className="text-xs text-emerald-200 space-y-1 font-medium list-disc pl-4">
                  <li>享特惠会员尊享价</li>
                  <li>购物得积分，免费兑换好礼</li>
                  <li>尊享生日惊喜福利包</li>
                </ul>
              </div>

              <div className="mt-4 pt-1 z-10">
                {currentUser ? (
                  <div className="text-xs bg-white/10 px-3 py-2 rounded-xl backdrop-blur-sm border border-white/10 flex justify-between items-center">
                    <div>
                      <p className="text-[10px] text-emerald-300">积分余额</p>
                      <p className="font-semibold text-amber-300 font-mono text-sm">{currentUser.points} 积分</p>
                    </div>
                    <button 
                      onClick={() => setActiveTab('会员中心')}
                      className="text-[11px] font-bold text-amber-300 hover:underline flex items-center gap-0.5"
                    >
                      积分商城 <ChevronRight className="w-3 h-3" />
                    </button>
                  </div>
                ) : (
                  <button 
                    onClick={() => { setAuthMode('register'); setIsAuthOpen(true); }}
                    className="w-full bg-amber-400 hover:bg-amber-500 text-amber-950 font-bold text-xs py-2 rounded-xl transition-all flex items-center justify-center gap-1 cursor-pointer shadow-md shadow-amber-900/10"
                  >
                    <span>立即注册会员</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {/* Service Highlight Icons Stack */}
            <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-sm flex flex-col justify-around gap-3 text-slate-700">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-emerald-50 rounded-lg flex items-center justify-center text-emerald-700 shrink-0">
                  <Shield className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-800">新鲜直达</h4>
                  <p className="text-[10px] text-slate-400">产地空运直采 每日新鲜品质保障</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center text-blue-700 shrink-0">
                  <Truck className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-800">快速配送</h4>
                  <p className="text-[10px] text-slate-400">多仓冷链极速发货 最快30分钟达</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-amber-50 rounded-lg flex items-center justify-center text-amber-700 shrink-0">
                  <Tag className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-800">价格实惠</h4>
                  <p className="text-[10px] text-slate-400">天天低价省钱省心 绝无套路加价</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-rose-50 rounded-lg flex items-center justify-center text-rose-700 shrink-0">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-800">售后无忧</h4>
                  <p className="text-[10px] text-slate-400">严格把控冷链 7天无理由退换货</p>
                </div>
              </div>
            </div>

          </div>
        </section>
      )}

      {/* 5. CIRCULAR CATEGORY QUICK-NAV LINK ROW */}
      {activeTab === '首页' && searchQuery === '' && selectedCategory === 'all' && (
        <section className="px-4 sm:px-6 md:px-12 py-4">
          <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-sm flex items-center justify-between gap-4 overflow-x-auto scrollbar-none">
            {[
              { label: '蔬果水果', color: 'bg-green-100 hover:bg-green-200 text-green-700 border-green-200' },
              { label: '肉类禽蛋', color: 'bg-rose-100 hover:bg-rose-200 text-rose-700 border-rose-200' },
              { label: '海鲜水产', color: 'bg-blue-100 hover:bg-blue-200 text-blue-700 border-blue-200' },
              { label: '粮油调味', color: 'bg-amber-100 hover:bg-amber-200 text-amber-700 border-amber-200' },
              { label: '乳品烘焙', color: 'bg-sky-100 hover:bg-sky-200 text-sky-700 border-sky-200' },
              { label: '休闲零食', color: 'bg-orange-100 hover:bg-orange-200 text-orange-700 border-orange-200' },
              { label: '饮料酒水', color: 'bg-red-100 hover:bg-red-200 text-red-700 border-red-200' },
              { label: '日用百货', color: 'bg-indigo-100 hover:bg-indigo-200 text-indigo-700 border-indigo-200' },
            ].map((item, idx) => (
              <button
                key={idx}
                onClick={() => setSelectedCategory(item.label === '乳品烘焙' ? '肉禽蛋奶' : item.label)}
                className="flex flex-col items-center gap-2 shrink-0 group select-none cursor-pointer focus:outline-none"
              >
                <div className={`w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 transform group-hover:scale-105 border-2 shadow-inner font-bold text-sm ${item.color}`}>
                  {item.label.substring(0, 2)}
                </div>
                <span className="text-xs font-semibold text-slate-600 group-hover:text-slate-900 transition-colors">
                  {item.label}
                </span>
              </button>
            ))}
          </div>
        </section>
      )}

      {/* 6. PRIMARY PRODUCT DISPLAY VIEWS */}
      <main className="flex-1 px-4 sm:px-6 md:px-12 py-6">

        {/* Dynamic Category List Filter Title banner */}
        {(selectedCategory !== 'all' || searchQuery !== '' || activeTab !== '首页') && (
          <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-emerald-100 rounded-xl flex items-center justify-center text-emerald-700">
                <Filter className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-950 flex items-center gap-1.5">
                  {searchQuery ? `关于 "${searchQuery}" 的搜索结果` : `${selectedCategory === 'all' ? activeTab : selectedCategory}`}
                </h3>
                <p className="text-xs text-slate-400">已为您筛选出 {filteredProducts.length} 款优质好物</p>
              </div>
            </div>
            
            {/* Filter controls */}
            <div className="flex items-center gap-2">
              <button 
                onClick={() => { setSelectedCategory('all'); setSearchQuery(''); setActiveTab('首页'); }}
                className="px-3 py-1.5 text-xs font-bold text-slate-500 hover:text-slate-800 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer border border-slate-200/50"
              >
                重置筛选
              </button>
            </div>
          </div>
        )}

        {/* MAIN HOMEPAGE DISPLAY BLOCK */}
        {selectedCategory === 'all' && searchQuery === '' && activeTab === '首页' ? (
          <div className="space-y-10">
            
            {/* --- BLOCK A: 限时特惠 (Limited Time Offers) --- */}
            <section className="bg-orange-50/40 rounded-2xl p-6 border border-orange-100/50 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-orange-100">
                <div className="flex items-center gap-4">
                  <span className="flex items-center gap-1 text-lg font-extrabold text-orange-950">
                    <Flame className="w-5.5 h-5.5 text-orange-600 animate-bounce" />
                    限时特惠
                  </span>
                  
                  {/* Real Ticking Countdown Timer */}
                  <div className="flex items-center gap-1.5 text-xs font-bold text-orange-800">
                    <span className="opacity-95">距离结束</span>
                    <div className="flex items-center gap-1">
                      <span className="bg-orange-600 text-white font-mono px-2 py-0.5 rounded-md min-w-[22px] text-center shadow-sm">
                        {String(countdown.hours).padStart(2, '0')}
                      </span>
                      <span>:</span>
                      <span className="bg-orange-600 text-white font-mono px-2 py-0.5 rounded-md min-w-[22px] text-center shadow-sm">
                        {String(countdown.minutes).padStart(2, '0')}
                      </span>
                      <span>:</span>
                      <span className="bg-orange-600 text-white font-mono px-2 py-0.5 rounded-md min-w-[22px] text-center shadow-sm">
                        {String(countdown.seconds).padStart(2, '0')}
                      </span>
                    </div>
                  </div>
                </div>

                <button 
                  onClick={() => setSelectedCategory('新鲜蔬果')}
                  className="text-xs font-bold text-orange-700 hover:text-orange-900 transition-colors flex items-center gap-0.5"
                >
                  查看更多 <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {/* Grid of 4 limited offer items */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {products.filter(p => p.badge === '特惠').slice(0, 4).map((product) => (
                  <div 
                    key={product.id}
                    onClick={() => setSelectedProduct(product)}
                    className="bg-white rounded-xl border border-slate-200/60 p-3 flex flex-col justify-between hover:shadow-md hover:border-orange-200 transition-all cursor-pointer group relative"
                  >
                    {/* Badge */}
                    <span className="absolute top-2 left-2 bg-gradient-to-r from-orange-500 to-amber-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-md shadow-sm z-10">
                      {product.badge}
                    </span>

                    {/* Image Area */}
                    <div className="w-full h-32 relative rounded-lg overflow-hidden bg-slate-50 mb-3.5 flex items-center justify-center shrink-0">
                      <Image
                        src={product.image}
                        alt={product.name}
                        fill
                        sizes="(max-width: 768px) 50vw, 25vw"
                        className="object-contain group-hover:scale-105 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                    </div>

                    {/* Metadata & Title */}
                    <div className="space-y-1.5 flex-1 flex flex-col justify-between">
                      <div>
                        <h4 className="text-xs text-slate-400 font-bold tracking-tight">{product.category}</h4>
                        <h3 className="text-sm font-bold text-slate-800 line-clamp-1 group-hover:text-emerald-700 transition-colors">
                          {product.name}
                        </h3>
                        <p className="text-[11px] text-slate-500 font-medium">{product.spec}</p>
                      </div>

                      {/* Pricing Footer */}
                      <div className="flex items-center justify-between pt-1">
                        <div>
                          <div className="text-orange-600 font-black font-mono text-base tracking-tight flex items-baseline">
                            <span className="text-xs font-bold mr-0.5">¥</span>
                            {product.price.toFixed(2)}
                          </div>
                          {product.originalPrice && (
                            <div className="text-[10px] text-slate-400 font-mono line-through">
                              ¥{product.originalPrice.toFixed(2)}
                            </div>
                          )}
                        </div>

                        {/* Cart add button */}
                        <button
                          onClick={(e) => handleAddToCart(product, 1, e)}
                          className="p-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-full transition-colors shadow-sm shadow-emerald-200/50 cursor-pointer"
                          aria-label={`Add ${product.name} to cart`}
                        >
                          <ShoppingCart className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* --- BLOCK B: 新品上架 (New Arrivals) & Right Side Special Banner --- */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              
              {/* Left Column: New Arrivals list */}
              <section className="lg:col-span-8 bg-emerald-50/30 rounded-2xl p-6 border border-emerald-100/40 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between gap-4 mb-6 pb-4 border-b border-emerald-100">
                    <span className="flex items-center gap-1 text-lg font-extrabold text-emerald-950">
                      <Sparkles className="w-5.5 h-5.5 text-emerald-600 animate-pulse" />
                      新品上架
                    </span>

                    <button 
                      onClick={() => setSelectedCategory('新鲜蔬果')}
                      className="text-xs font-bold text-emerald-700 hover:text-emerald-900 transition-colors flex items-center gap-0.5"
                    >
                      查看更多 <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>

                  {/* New product grid */}
                  <div className="grid grid-cols-2 gap-4">
                    {products.filter(p => p.badge === '新品').slice(0, 2).map((product) => (
                      <div 
                        key={product.id}
                        onClick={() => setSelectedProduct(product)}
                        className="bg-white rounded-xl border border-slate-200/60 p-4 flex flex-col justify-between hover:shadow-md hover:border-emerald-200 transition-all cursor-pointer group relative"
                      >
                        {/* Image Area */}
                        <div className="w-full h-36 relative rounded-lg overflow-hidden bg-slate-50 mb-3.5 flex items-center justify-center shrink-0">
                          <Image
                            src={product.image}
                            alt={product.name}
                            fill
                            sizes="(max-width: 768px) 50vw, 33vw"
                            className="object-contain group-hover:scale-105 transition-transform duration-300"
                            referrerPolicy="no-referrer"
                          />
                        </div>

                        {/* Title & Specs */}
                        <div className="space-y-1">
                          <h4 className="text-[10px] text-emerald-700 font-bold tracking-tight uppercase">{product.category}</h4>
                          <h3 className="text-sm font-bold text-slate-800 line-clamp-1 group-hover:text-emerald-700 transition-colors">
                            {product.name}
                          </h3>
                          <p className="text-xs text-slate-400 font-medium">{product.spec}</p>
                        </div>

                        {/* Pricing & Add to cart */}
                        <div className="flex items-center justify-between pt-2">
                          <span className="text-emerald-700 font-black font-mono text-base flex items-baseline">
                            <span className="text-xs font-bold mr-0.5">¥</span>
                            {product.price.toFixed(2)}
                          </span>

                          <button
                            onClick={(e) => handleAddToCart(product, 1, e)}
                            className="p-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-full transition-colors cursor-pointer"
                            aria-label={`Add ${product.name} to cart`}
                          >
                            <ShoppingCart className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </section>

              {/* Right Column: Special Promotion banner */}
              <div className="lg:col-span-4 relative overflow-hidden rounded-2xl border border-amber-100 bg-gradient-to-br from-amber-50 to-orange-100/50 p-6 shadow-sm flex flex-col justify-between min-h-[300px]">
                
                {/* Floating graphic vector effect */}
                <div className="absolute right-0 bottom-0 w-32 h-32 opacity-15">
                  <Tag className="w-full h-full text-orange-950" />
                </div>

                <div className="space-y-2 text-left z-10">
                  <div className="inline-flex items-center gap-1 bg-orange-600 text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wide">
                    特价
                  </div>
                  <h3 className="text-2xl font-extrabold text-orange-950 leading-snug">
                    每日特价
                  </h3>
                  <p className="text-xs sm:text-sm text-orange-800 max-w-xs font-medium">
                    精选好物 惊喜不断
                  </p>
                </div>

                {/* Main illustrative photo */}
                <div className="w-full h-24 relative my-4 rounded-xl overflow-hidden shrink-0 shadow-sm border border-amber-200">
                  <Image
                    src={promoDailySpecial}
                    alt="Daily Special Vegetables"
                    fill
                    sizes="(max-width: 768px) 100vw, 30vw"
                    className="object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <button 
                  onClick={() => setSelectedCategory('新鲜蔬果')}
                  className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs sm:text-sm py-2.5 rounded-xl transition-all shadow-md shadow-orange-900/10 cursor-pointer text-center"
                >
                  立即抢购
                </button>
              </div>

            </div>

          </div>
        ) : (
          /* CATEGORY FILTERED VIEW GRID / SEARCH GRID */
          <div>
            {filteredProducts.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center shadow-sm flex flex-col items-center justify-center space-y-4">
                <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center text-slate-400">
                  <Info className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-base font-bold text-slate-800">未找到相关商品</h4>
                  <p className="text-xs text-slate-400 mt-1 max-w-xs">
                    抱歉，没有搜到与 “{searchQuery || selectedCategory}” 匹配的商品。请尝试其他搜索词或浏览其他分类。
                  </p>
                </div>
                <button 
                  onClick={() => { setSelectedCategory('all'); setSearchQuery(''); setActiveTab('首页'); }}
                  className="bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold px-4 py-2 rounded-xl transition-colors cursor-pointer"
                >
                  返回首页
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
                {filteredProducts.map((product) => (
                  <div 
                    key={product.id}
                    onClick={() => setSelectedProduct(product)}
                    className="bg-white rounded-xl border border-slate-200/80 p-4 flex flex-col justify-between hover:shadow-md hover:border-emerald-200 transition-all cursor-pointer group relative"
                  >
                    {/* Badge */}
                    {product.badge && (
                      <span className="absolute top-2 left-2 bg-orange-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-md shadow-sm z-10">
                        {product.badge}
                      </span>
                    )}

                    {/* Image */}
                    <div className="w-full h-36 relative rounded-lg overflow-hidden bg-slate-50 mb-3.5 flex items-center justify-center shrink-0">
                      <Image
                        src={product.image}
                        alt={product.name}
                        fill
                        sizes="(max-width: 768px) 50vw, 25vw"
                        className="object-contain group-hover:scale-105 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                    </div>

                    {/* Metadata & Title */}
                    <div className="space-y-1 flex-1 flex flex-col justify-between">
                      <div>
                        <span className="text-[10px] text-slate-400 font-bold uppercase tracking-tight">{product.category}</span>
                        <h3 className="text-sm font-bold text-slate-800 line-clamp-2 group-hover:text-emerald-700 transition-colors">
                          {product.name}
                        </h3>
                        <p className="text-[11px] text-slate-500 font-medium">{product.spec}</p>
                      </div>

                      {/* Bottom row: pricing & quick add */}
                      <div className="flex items-center justify-between pt-3">
                        <div>
                          <div className="text-emerald-800 font-extrabold font-mono text-base tracking-tight">
                            <span className="text-xs font-bold mr-0.5">¥</span>
                            {product.price.toFixed(2)}
                          </div>
                          {product.originalPrice && (
                            <div className="text-[10px] text-slate-400 font-mono line-through">
                              ¥{product.originalPrice.toFixed(2)}
                            </div>
                          )}
                        </div>

                        <button
                          onClick={(e) => handleAddToCart(product, 1, e)}
                          className="p-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-full transition-colors cursor-pointer"
                          aria-label={`Add ${product.name} to cart`}
                        >
                          <ShoppingCart className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

      </main>

      {/* 7. WATERCOLOR LANDSCAPE FOOTER */}
      <footer className="relative bg-white border-t border-slate-200 mt-12 overflow-hidden flex flex-col shrink-0">
        
        {/* Misty Watercolor Background Container */}
        <div className="relative w-full h-[180px] sm:h-[220px] md:h-[240px] select-none flex items-center justify-center text-center px-4">
          <Image
            src={footerMistyMountains}
            alt="Misty landscape background"
            fill
            sizes="100vw"
            className="object-cover opacity-85"
            referrerPolicy="no-referrer"
          />
          {/* Subtle contrast overlay */}
          <div className="absolute inset-0 bg-white/20" />

          {/* Slogan details overlay inside the mountains */}
          <div className="relative z-10 space-y-2">
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-widest text-slate-900 drop-shadow-sm font-serif">
              好 食 材 · 好 生 活
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 max-w-sm mx-auto font-medium tracking-wide">
              惠家超市 · 用心挑选 只为更好的你
            </p>
          </div>
        </div>

        {/* Quality trust bars */}
        <div className="bg-slate-50 border-y border-slate-200/60 px-4 sm:px-6 md:px-12 py-5 grid grid-cols-1 md:grid-cols-3 gap-6 text-center select-none">
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 text-slate-700">
            <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-800">
              <Shield className="w-5 h-5" />
            </div>
            <div className="text-left">
              <h4 className="text-sm font-bold">品质保证</h4>
              <p className="text-xs text-slate-400 font-medium">严格把控食品安全、冷链运输、极速保鲜</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 text-slate-700 border-y md:border-y-0 md:border-x border-slate-200/80 py-4 md:py-0">
            <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-800">
              <Truck className="w-5 h-5" />
            </div>
            <div className="text-left">
              <h4 className="text-sm font-bold">极速配送</h4>
              <p className="text-xs text-slate-400 font-medium">多仓发货冷链运输，30分钟极速送达</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 text-slate-700">
            <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-800">
              <Tag className="w-5 h-5" />
            </div>
            <div className="text-left">
              <h4 className="text-sm font-bold">价格实惠</h4>
              <p className="text-xs text-slate-400 font-medium">源头基地产地直采，天天平价不耍花招</p>
            </div>
          </div>
        </div>

        {/* Bottom copyright list */}
        <div className="bg-white text-slate-400 text-xs py-5 px-4 sm:px-6 md:px-12 text-center space-y-2">
          <div className="flex flex-wrap items-center justify-center gap-x-5 gap-y-1.5 font-medium">
            <button onClick={() => { setSelectedCategory('all'); setActiveTab('首页'); setSearchQuery(''); }} className="hover:text-emerald-700 transition-colors">关于我们</button>
            <span>·</span>
            <button onClick={() => { setSelectedCategory('all'); setActiveTab('首页'); setSearchQuery(''); }} className="hover:text-emerald-700 transition-colors">隐私条款</button>
            <span>·</span>
            <button onClick={() => { setSelectedCategory('all'); setActiveTab('首页'); setSearchQuery(''); }} className="hover:text-emerald-700 transition-colors">商家合作</button>
            <span>·</span>
            <button onClick={() => { setSelectedCategory('all'); setActiveTab('首页'); setSearchQuery(''); }} className="hover:text-emerald-700 transition-colors">客服热线：400-888-999</button>
          </div>
          <p>© 2026 惠家超市. All rights reserved. 沪ICP备12345678号-1</p>
        </div>
      </footer>

      {/* --- FLOATING TOAST SYSTEM --- */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className={`fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-xl border flex items-center gap-2.5 max-w-sm text-sm font-semibold select-none ${
              toast.type === 'success' 
                ? 'bg-emerald-900 border-emerald-800 text-white' 
                : 'bg-slate-900 border-slate-800 text-white'
            }`}
          >
            <div className="w-5 h-5 rounded-full bg-white/10 flex items-center justify-center shrink-0">
              <Check className="w-3.5 h-3.5 text-white" />
            </div>
            <span>{toast.message}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- DRAWERS & MODALS PANEL SYSTEM --- */}

      {/* 1. SHOPPING CART SIDEBAR DRAWER */}
      <AnimatePresence>
        {isCartOpen && (
          <>
            {/* Backdrop */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="fixed inset-0 bg-black/40 backdrop-blur-xs z-50 cursor-pointer"
            />
            {/* Drawer */}
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 h-full w-full max-w-md bg-white shadow-2xl z-50 flex flex-col justify-between border-l border-slate-200"
            >
              {/* Drawer Header */}
              <div className="p-4 border-b border-slate-150 flex items-center justify-between">
                <div className="flex items-center gap-2 text-emerald-800 font-extrabold text-base">
                  <ShoppingCart className="w-5 h-5" />
                  <span>我的购物车 ({getCartCount()})</span>
                </div>
                <button 
                  onClick={() => setIsCartOpen(false)}
                  className="p-1.5 rounded-lg hover:bg-slate-100 transition-colors text-slate-500 cursor-pointer"
                  aria-label="Close cart"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Drawer Content */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {cart.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center space-y-3">
                    <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center text-slate-300">
                      <ShoppingCart className="w-8 h-8" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-800">购物车空空如也</h4>
                      <p className="text-xs text-slate-400 mt-1">快去选购一些新鲜好食材吧！</p>
                    </div>
                    <button 
                      onClick={() => { setIsCartOpen(false); setSelectedCategory('新鲜蔬果'); }}
                      className="bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold px-4 py-2 rounded-xl transition-colors cursor-pointer"
                    >
                      去逛逛
                    </button>
                  </div>
                ) : (
                  cart.map((item) => (
                    <div 
                      key={item.product.id}
                      className="flex gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200/50"
                    >
                      {/* Product Image */}
                      <div className="w-16 h-16 relative bg-white rounded-lg border border-slate-100 overflow-hidden shrink-0 flex items-center justify-center">
                        <Image
                          src={item.product.image}
                          alt={item.product.name}
                          fill
                          sizes="64px"
                          className="object-contain"
                          referrerPolicy="no-referrer"
                        />
                      </div>

                      {/* Info & Quantity controls */}
                      <div className="flex-1 flex flex-col justify-between">
                        <div>
                          <div className="flex justify-between items-start gap-1">
                            <h4 className="text-xs sm:text-sm font-bold text-slate-800 line-clamp-1">
                              {item.product.name}
                            </h4>
                            <span className="text-xs font-mono font-bold text-slate-800 shrink-0">
                              ¥{(item.product.price * item.quantity).toFixed(2)}
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-400 font-medium">{item.product.spec} · 单价: ¥{item.product.price.toFixed(2)}</p>
                        </div>

                        {/* Quantity steppers */}
                        <div className="flex items-center justify-between mt-2">
                          <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-lg p-0.5 shadow-sm">
                            <button
                              onClick={() => handleUpdateQuantity(item.product.id, -1)}
                              className="p-1 rounded-md text-slate-500 hover:bg-slate-100 cursor-pointer"
                              aria-label="Decrease quantity"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="text-xs font-mono font-bold px-2 text-slate-800">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => handleUpdateQuantity(item.product.id, 1)}
                              className="p-1 rounded-md text-slate-500 hover:bg-slate-100 cursor-pointer"
                              aria-label="Increase quantity"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <button 
                            onClick={() => handleUpdateQuantity(item.product.id, -item.quantity)}
                            className="text-[10px] font-bold text-rose-500 hover:underline cursor-pointer"
                          >
                            移除
                          </button>
                        </div>

                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Drawer Footer summary */}
              {cart.length > 0 && (
                <div className="p-4 border-t border-slate-150 space-y-4 bg-slate-50/50">
                  <div className="space-y-1.5 text-xs text-slate-600">
                    <div className="flex justify-between">
                      <span>商品总额</span>
                      <span className="font-mono font-bold">¥{getCartTotal().toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>配送费</span>
                      <span className="font-mono font-bold">
                        {getCartTotal() >= 59 ? (
                          <span className="text-emerald-700">免运费</span>
                        ) : (
                          '¥6.00'
                        )}
                      </span>
                    </div>
                    {getCartTotal() < 59 && (
                      <p className="text-[10px] text-amber-600 font-medium text-right bg-amber-50 p-1.5 rounded-lg border border-amber-100">
                        再买 <span className="font-bold">¥{(59 - getCartTotal()).toFixed(2)}</span> 即可享受免运费哦！
                      </p>
                    )}
                    <div className="border-t border-slate-200/80 my-2" />
                    <div className="flex justify-between text-sm text-slate-800 font-bold">
                      <span>预计实付</span>
                      <span className="text-orange-600 font-mono text-base font-black">
                        ¥{(getCartTotal() + (getCartTotal() >= 59 ? 0 : 6)).toFixed(2)}
                      </span>
                    </div>
                  </div>

                  <button 
                    onClick={() => setIsCheckoutOpen(true)}
                    className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm py-3 rounded-xl transition-all shadow-md shadow-emerald-800/10 flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <span>去结算</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* 2. FAVORITES MODAL */}
      <AnimatePresence>
        {isFavoritesOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsFavoritesOpen(false)}
              className="absolute inset-0 bg-black/40 backdrop-blur-xs cursor-pointer"
            />
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl max-w-lg w-full p-5 relative shadow-2xl border border-slate-200 z-10 max-h-[85vh] flex flex-col"
            >
              <div className="flex items-center justify-between pb-3 border-b border-slate-150">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-1.5">
                  <Heart className="w-5 h-5 text-rose-500 fill-rose-500" />
                  <span>我的商品收藏 ({favorites.length})</span>
                </h3>
                <button 
                  onClick={() => setIsFavoritesOpen(false)}
                  className="p-1 rounded-lg hover:bg-slate-100 text-slate-500 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto py-3 space-y-3">
                {favorites.length === 0 ? (
                  <div className="py-12 text-center space-y-3">
                    <p className="text-sm text-slate-400">您目前还没有收藏任何商品</p>
                    <button 
                      onClick={() => { setIsFavoritesOpen(false); setSelectedCategory('新鲜蔬果'); }}
                      className="bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold px-4 py-1.5 rounded-lg transition-colors cursor-pointer"
                    >
                      去添加
                    </button>
                  </div>
                ) : (
                  favorites.map((product) => (
                    <div 
                      key={product.id}
                      className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200/40"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 relative bg-white rounded-lg border border-slate-100 overflow-hidden shrink-0 flex items-center justify-center">
                          <Image
                            src={product.image}
                            alt={product.name}
                            fill
                            sizes="48px"
                            className="object-contain"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <div>
                          <h4 className="text-xs sm:text-sm font-bold text-slate-800">{product.name}</h4>
                          <p className="text-[10px] text-slate-400 font-semibold">{product.spec} · ¥{product.price.toFixed(2)}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button 
                          onClick={() => handleAddToCart(product)}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white p-1.5 rounded-lg text-xs font-semibold cursor-pointer"
                          aria-label="Add to cart"
                        >
                          <ShoppingCart className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={(e) => handleToggleFavorite(product, e)}
                          className="text-xs font-bold text-rose-500 hover:underline p-1 cursor-pointer"
                        >
                          取消收藏
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 3. MY ORDERS HISTORY MODAL */}
      <AnimatePresence>
        {isOrdersOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOrdersOpen(false)}
              className="absolute inset-0 bg-black/40 backdrop-blur-xs cursor-pointer"
            />
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl max-w-2xl w-full p-5 relative shadow-2xl border border-slate-200 z-10 max-h-[85vh] flex flex-col"
            >
              <div className="flex items-center justify-between pb-3 border-b border-slate-150">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-1.5">
                  <User className="w-5 h-5 text-emerald-800" />
                  <span>我的订单记录 ({orders.length})</span>
                </h3>
                <button 
                  onClick={() => setIsOrdersOpen(false)}
                  className="p-1 rounded-lg hover:bg-slate-100 text-slate-500 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto py-3 space-y-4">
                {orders.length === 0 ? (
                  <div className="py-16 text-center space-y-3">
                    <p className="text-sm text-slate-400">目前还没有任何订购订单</p>
                    <button 
                      onClick={() => { setIsOrdersOpen(false); setSelectedCategory('新鲜蔬果'); }}
                      className="bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold px-4 py-1.5 rounded-lg transition-colors cursor-pointer"
                    >
                      去买点好吃的
                    </button>
                  </div>
                ) : (
                  orders.map((order) => (
                    <div 
                      key={order.id}
                      className="bg-slate-50 rounded-xl border border-slate-200 p-4 space-y-2.5"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 pb-2 border-b border-slate-200/50">
                        <div>
                          <span>单号：<span className="font-bold text-slate-800">{order.id}</span></span>
                          <span className="mx-2">·</span>
                          <span>日期：{order.date}</span>
                        </div>
                        <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-bold rounded">
                          {order.status}
                        </span>
                      </div>

                      {/* Item list inside order */}
                      <div className="space-y-1.5">
                        {order.items.map((item, idx) => (
                          <div key={idx} className="flex justify-between items-center text-xs">
                            <span className="text-slate-700 font-medium">
                              {item.product.name} ({item.product.spec}) <span className="text-slate-400">x{item.quantity}</span>
                            </span>
                            <span className="font-mono font-semibold text-slate-800">¥{(item.product.price * item.quantity).toFixed(2)}</span>
                          </div>
                        ))}
                      </div>

                      <div className="border-t border-slate-200/50 pt-2 flex flex-wrap items-center justify-between text-xs gap-2">
                        <div className="text-slate-400 font-medium">
                          收货人：{order.name} | {order.phone}
                          <br />
                          地址：{order.address}
                        </div>
                        <div className="text-right">
                          <span className="text-slate-500 mr-1 font-semibold">支付方式：{order.paymentMethod}</span>
                          <br />
                          <span className="font-semibold text-slate-700">总计：</span>
                          <span className="text-sm font-black text-orange-600 font-mono">¥{order.total.toFixed(2)}</span>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 4. LOGIN / REGISTER AUTH MODAL */}
      <AnimatePresence>
        {isAuthOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAuthOpen(false)}
              className="absolute inset-0 bg-black/40 backdrop-blur-xs cursor-pointer"
            />
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl max-w-sm w-full p-6 relative shadow-2xl border border-slate-200 z-10"
            >
              <button 
                onClick={() => setIsAuthOpen(false)}
                className="absolute top-4 right-4 p-1 rounded-lg hover:bg-slate-100 text-slate-500 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <h3 className="text-xl font-bold text-slate-900 text-center mb-6">
                {authMode === 'login' ? '会员登录' : '新会员注册'}
              </h3>

              <form onSubmit={handleAuthSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">手机号</label>
                  <input
                    type="tel"
                    required
                    placeholder="请输入您的手机号"
                    value={authPhone}
                    onChange={(e) => setAuthPhone(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/25 bg-slate-50 focus:bg-white text-slate-950 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">登录密码</label>
                  <input
                    type="password"
                    required
                    placeholder="请输入密码"
                    value={authPassword}
                    onChange={(e) => setAuthPassword(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/25 bg-slate-50 focus:bg-white text-slate-950 font-mono"
                  />
                </div>

                <button 
                  type="submit"
                  className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2.5 rounded-xl transition-all cursor-pointer shadow-md shadow-emerald-700/15"
                >
                  {authMode === 'login' ? '立即登录' : '立即注册'}
                </button>
              </form>

              <div className="mt-4 pt-3 border-t border-slate-100 text-center text-xs text-slate-500 font-medium">
                {authMode === 'login' ? (
                  <span>
                    还没有账号？{' '}
                    <button 
                      onClick={() => setAuthMode('register')}
                      className="text-emerald-700 font-bold hover:underline cursor-pointer"
                    >
                      立即注册
                    </button>
                  </span>
                ) : (
                  <span>
                    已有账号？{' '}
                    <button 
                      onClick={() => setAuthMode('login')}
                      className="text-emerald-700 font-bold hover:underline cursor-pointer"
                    >
                      立即登录
                    </button>
                  </span>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 5. PRODUCT DETAILS MODAL (POPUP) */}
      <AnimatePresence>
        {selectedProduct && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedProduct(null)}
              className="absolute inset-0 bg-black/45 backdrop-blur-xs cursor-pointer"
            />
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl max-w-2xl w-full relative shadow-2xl border border-slate-200 z-10 overflow-hidden max-h-[90vh] flex flex-col md:flex-row"
            >
              {/* Close Button */}
              <button 
                onClick={() => setSelectedProduct(null)}
                className="absolute top-3 right-3 p-1.5 bg-slate-100/80 hover:bg-slate-200 rounded-full transition-colors text-slate-600 z-20 cursor-pointer shadow-sm"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Left Column: Big Image Display */}
              <div className="w-full md:w-1/2 h-64 md:h-auto bg-slate-50 relative flex items-center justify-center p-6 shrink-0 border-r border-slate-150">
                <Image
                  src={selectedProduct.image}
                  alt={selectedProduct.name}
                  fill
                  sizes="(max-width: 768px) 100vw, 50vw"
                  className="object-contain p-4"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Right Column: Detailed Purchase Module */}
              <div className="w-full md:w-1/2 p-6 flex flex-col justify-between overflow-y-auto space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs bg-emerald-50 text-emerald-800 font-bold px-2.5 py-0.5 rounded border border-emerald-100">
                      {selectedProduct.category}
                    </span>
                    {selectedProduct.badge && (
                      <span className="text-xs bg-orange-600 text-white font-bold px-2 py-0.5 rounded">
                        {selectedProduct.badge}
                      </span>
                    )}
                  </div>

                  <h3 className="text-xl font-extrabold text-slate-900 leading-tight">
                    {selectedProduct.name}
                  </h3>
                  
                  <p className="text-xs text-slate-400 font-semibold">规格参数：{selectedProduct.spec}</p>
                  
                  <div className="text-2xl font-black text-orange-600 font-mono tracking-tight pt-1 flex items-baseline">
                    <span className="text-sm font-bold mr-0.5">¥</span>
                    {selectedProduct.price.toFixed(2)}
                    {selectedProduct.originalPrice && (
                      <span className="text-xs text-slate-400 line-through font-mono ml-2 font-normal">
                        原价 ¥{selectedProduct.originalPrice.toFixed(2)}
                      </span>
                    )}
                  </div>

                  <div className="border-t border-slate-100 pt-2.5" />
                  
                  <div>
                    <h4 className="text-xs font-bold text-slate-700 mb-1">商品亮点</h4>
                    <p className="text-xs text-slate-500 leading-relaxed font-medium">
                      {selectedProduct.description}
                    </p>
                  </div>
                </div>

                <div className="space-y-3 pt-3 border-t border-slate-100">
                  <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
                    <span>配送时效：最快30分钟达</span>
                    <span>库存余量：{selectedProduct.stock}件</span>
                  </div>

                  <div className="flex gap-2.5">
                    <button 
                      onClick={() => handleToggleFavorite(selectedProduct)}
                      className={`p-3 rounded-xl border transition-all cursor-pointer ${
                        favorites.some(f => f.id === selectedProduct.id)
                          ? 'border-rose-200 bg-rose-50 text-rose-500'
                          : 'border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-500'
                      }`}
                      aria-label="Add to favorites"
                    >
                      <Heart className="w-5 h-5 fill-current" />
                    </button>

                    <button 
                      onClick={() => { handleAddToCart(selectedProduct, 1); setSelectedProduct(null); }}
                      className="flex-1 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm py-3 rounded-xl transition-all shadow-md shadow-emerald-700/15 flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <ShoppingCart className="w-4 h-4" />
                      <span>加入购物车</span>
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 6. CHECKOUT ORDER PLACEMENT DIALOG MODAL */}
      <AnimatePresence>
        {isCheckoutOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCheckoutOpen(false)}
              className="absolute inset-0 bg-black/45 backdrop-blur-xs cursor-pointer"
            />
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl max-w-md w-full p-6 relative shadow-2xl border border-slate-200 z-10 max-h-[90vh] flex flex-col"
            >
              <button 
                onClick={() => setIsCheckoutOpen(false)}
                className="absolute top-4 right-4 p-1 rounded-lg hover:bg-slate-100 text-slate-500 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <h3 className="text-lg font-bold text-slate-900 pb-3 border-b border-slate-150 flex items-center gap-1.5">
                <MapPin className="w-5 h-5 text-emerald-800" />
                <span>填写收货信息 & 下单</span>
              </h3>

              <form onSubmit={handleCheckoutSubmit} className="flex-1 overflow-y-auto py-4 space-y-4 pr-1">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">收货人姓名</label>
                  <input
                    type="text"
                    required
                    placeholder="请输入收货人姓名"
                    value={shippingName}
                    onChange={(e) => setShippingName(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/25 bg-slate-50 focus:bg-white text-slate-950 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">联系电话</label>
                  <input
                    type="tel"
                    required
                    placeholder="请输入联系手机号"
                    value={shippingPhone}
                    onChange={(e) => setShippingPhone(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/25 bg-slate-50 focus:bg-white text-slate-950 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">详细收货地址</label>
                  <textarea
                    required
                    rows={2}
                    placeholder="请输入详细派送地址"
                    value={shippingAddress}
                    onChange={(e) => setShippingAddress(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/25 bg-slate-50 focus:bg-white text-slate-950 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-2">付款方式</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('cod')}
                      className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all text-center cursor-pointer ${
                        paymentMethod === 'cod'
                          ? 'bg-emerald-50 border-emerald-500 text-emerald-800 ring-1 ring-emerald-500'
                          : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      货到付款 (COD)
                    </button>
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('online')}
                      className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all text-center cursor-pointer ${
                        paymentMethod === 'online'
                          ? 'bg-emerald-50 border-emerald-500 text-emerald-800 ring-1 ring-emerald-500'
                          : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      在线支付
                    </button>
                  </div>
                </div>

                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/50 space-y-1.5 text-xs text-slate-500">
                  <div className="flex justify-between">
                    <span>商品小计</span>
                    <span className="font-mono font-semibold">¥{getCartTotal().toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>运费</span>
                    <span className="font-mono font-semibold">{getCartTotal() >= 59 ? '免运费' : '¥6.00'}</span>
                  </div>
                  <div className="border-t border-slate-200/50 my-2" />
                  <div className="flex justify-between text-slate-800 font-bold text-sm">
                    <span>实付总额</span>
                    <span className="text-orange-600 font-mono text-base font-black">
                      ¥{(getCartTotal() + (getCartTotal() >= 59 ? 0 : 6)).toFixed(2)}
                    </span>
                  </div>
                </div>

                <button 
                  type="submit"
                  className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold text-sm py-3 rounded-xl transition-all shadow-md shadow-orange-900/15 flex items-center justify-center gap-1 cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>确认提交订单</span>
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
