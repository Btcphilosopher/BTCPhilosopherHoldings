import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: '惠家超市 - 新鲜 · 便宜 · 放心',
  description: '惠家超市 - 您的线上生鲜超市。提供时令蔬果、肉禽蛋奶、海鲜水产、日用百货等优质商品的30分钟极速配送服务。',
  openGraph: {
    title: '惠家超市 - 新鲜 · 便宜 · 放心',
    description: '惠家超市 - 您的线上生鲜超市。提供时令蔬果、肉禽蛋奶、海鲜水产、日用百货等优质商品的30分钟极速配送服务。',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: '惠家超市 - 新鲜 · 便宜 · 放心',
    description: '惠家超市 - 您的线上生鲜超市。提供时令蔬果、肉禽蛋奶、海鲜水产、日用百货等优质商品的30分钟极速配送服务。',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
