'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, ProductShade, CartItem, Sample, Booking, LoyaltyReward, ProductCategory } from '@/types';
import { ESTEE_PRODUCTS, COMPLIMENTARY_SAMPLES, SPECIALISTS, CONSULTATIONS } from '@/data/catalog';

interface AppContextType {
  // Navigation & Modals
  activeTab: 'catalog' | 'try-on' | 'consultations' | 'loyalty';
  setActiveTab: (tab: 'catalog' | 'try-on' | 'consultations' | 'loyalty') => void;
  activeCategory: ProductCategory;
  setActiveCategory: (cat: ProductCategory) => void;
  selectedProductForModal: Product | null;
  setSelectedProductForModal: (prod: Product | null) => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;

  // Cart
  cart: CartItem[];
  addToCart: (product: Product, shade?: ProductShade, size?: string, quantity?: number) => void;
  removeFromCart: (itemId: string) => void;
  updateQuantity: (itemId: string, delta: number) => void;
  clearCart: () => void;
  cartCount: number;
  cartSubtotal: number;
  freeShippingThreshold: number;
  
  // Complimentary Samples
  selectedSamples: Sample[];
  toggleSample: (sample: Sample) => void;

  // Wishlist
  wishlist: string[];
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;

  // Loyalty Program
  userPoints: number;
  userTier: string;
  appliedVoucherDiscount: number;
  redeemedRewards: LoyaltyReward[];
  redeemReward: (reward: LoyaltyReward) => boolean;
  addPoints: (points: number) => void;

  // Virtual Try-on State
  tryOnProduct: Product | null;
  tryOnShade: ProductShade | null;
  launchTryOn: (product: Product, shade?: ProductShade) => void;
  setTryOnShade: (shade: ProductShade | null) => void;

  // Bookings
  bookings: Booking[];
  addBooking: (booking: Omit<Booking, 'id' | 'createdAt' | 'status'>) => Booking;
  cancelBooking: (id: string) => void;

  // Notification Toast
  toastMessage: string | null;
  showToast: (msg: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [activeTab, setActiveTab] = useState<'catalog' | 'try-on' | 'consultations' | 'loyalty'>('catalog');
  const [activeCategory, setActiveCategory] = useState<ProductCategory>('All');
  const [selectedProductForModal, setSelectedProductForModal] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);

  // Initialize with iconic Advanced Night Repair in cart so user can immediately experience checkout
  const [cart, setCart] = useState<CartItem[]>(() => {
    const defaultProduct = ESTEE_PRODUCTS[0];
    return [
      {
        id: 'anr-serum-50ml',
        product: defaultProduct,
        selectedSize: defaultProduct.size,
        quantity: 1,
      },
    ];
  });

  const [selectedSamples, setSelectedSamples] = useState<Sample[]>([COMPLIMENTARY_SAMPLES[0]]);
  const [wishlist, setWishlist] = useState<string[]>(['double-wear-foundation']);
  const [userPoints, setUserPoints] = useState(420); // Initial points in Be Enthusiastic tier
  const [appliedVoucherDiscount, setAppliedVoucherDiscount] = useState(0);
  const [redeemedRewards, setRedeemedRewards] = useState<LoyaltyReward[]>([]);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Try-on state (defaults to Pure Color Envy lipstick)
  const [tryOnProduct, setTryOnProduct] = useState<Product | null>(ESTEE_PRODUCTS[2]);
  const [tryOnShade, setTryOnShade] = useState<ProductShade | null>(ESTEE_PRODUCTS[2].shades?.[0] || null);

  // Initial demo confirmed consultation booking
  const [bookings, setBookings] = useState<Booking[]>([
    {
      id: 'EL-BOOK-9481',
      consultationId: 'consult-skin',
      consultationTitle: 'The 1-on-1 Skin Longevity & Barrier Repair Analysis',
      format: 'virtual',
      location: 'Virtual Private Studio (Google Meet HD)',
      specialist: SPECIALISTS[0],
      date: '2026-11-14',
      timeSlot: '14:30 GMT',
      customerName: 'Victoria Hastings',
      customerEmail: 'victoria.hastings@luxury-client.com',
      customerPhone: '+44 7700 900821',
      skinType: 'Combination / Sensitive',
      concerns: ['Dehydration', 'Fine Lines', 'Barrier Restoration'],
      notes: 'Interested in layering Advanced Night Repair with Re-Nutriv.',
      status: 'Confirmed',
      createdAt: '2026-11-01',
    },
  ]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
  };

  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => setToastMessage(null), 3800);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  const addToCart = (product: Product, shade?: ProductShade, size?: string, quantity: number = 1) => {
    const itemId = `${product.id}-${shade?.id || size || 'std'}`;
    setCart((prev) => {
      const existing = prev.find((item) => item.id === itemId);
      if (existing) {
        return prev.map((item) =>
          item.id === itemId ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [
        ...prev,
        {
          id: itemId,
          product,
          selectedShade: shade,
          selectedSize: size || product.size,
          quantity,
        },
      ];
    });

    const addedTitle = shade ? `${product.name} (${shade.name})` : product.name;
    showToast(`Added "${addedTitle}" to your shopping bag.`);
    setIsCartOpen(true);
  };

  const removeFromCart = (itemId: string) => {
    setCart((prev) => prev.filter((item) => item.id !== itemId));
  };

  const updateQuantity = (itemId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.id === itemId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter((item): item is CartItem => item !== null)
    );
  };

  const clearCart = () => {
    setCart([]);
    setSelectedSamples([]);
    setAppliedVoucherDiscount(0);
  };

  const toggleSample = (sample: Sample) => {
    setSelectedSamples((prev) => {
      const exists = prev.some((s) => s.id === sample.id);
      if (exists) {
        return prev.filter((s) => s.id !== sample.id);
      }
      if (prev.length >= 2) {
        showToast('You can select a maximum of 2 complimentary luxury samples.');
        return prev;
      }
      showToast(`Selected "${sample.name}" as your complimentary sample.`);
      return [...prev, sample];
    });
  };

  const toggleWishlist = (productId: string) => {
    setWishlist((prev) => {
      const exists = prev.includes(productId);
      if (exists) {
        showToast('Item removed from your wishlist.');
        return prev.filter((id) => id !== productId);
      }
      showToast('Saved to your private wishlist.');
      return [...prev, productId];
    });
  };

  const isInWishlist = (productId: string) => wishlist.includes(productId);

  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);
  const cartSubtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const freeShippingThreshold = 100.0;

  // Determine user tier
  const userTier = userPoints >= 650 ? 'Be Envied' : userPoints >= 250 ? 'Be Enthusiastic' : 'Be Excited';

  const redeemReward = (reward: LoyaltyReward): boolean => {
    if (userPoints < reward.pointsCost) {
      showToast(`Insufficient E-List points. You need ${reward.pointsCost - userPoints} more points.`);
      return false;
    }
    setUserPoints((prev) => prev - reward.pointsCost);
    setRedeemedRewards((prev) => [...prev, reward]);

    if (reward.discountValue) {
      setAppliedVoucherDiscount((prev) => prev + reward.discountValue!);
      showToast(`Redeemed £${reward.discountValue} shopping voucher! Applied to your cart.`);
    } else {
      showToast(`Reward unlocked: "${reward.name}". Added to your loyalty perks.`);
    }
    return true;
  };

  const addPoints = (points: number) => {
    setUserPoints((prev) => prev + points);
    showToast(`Congratulations! +${points} Estée E-List loyalty points added to your account.`);
  };

  const launchTryOn = (product: Product, shade?: ProductShade) => {
    setTryOnProduct(product);
    if (shade) {
      setTryOnShade(shade);
    } else if (product.shades && product.shades.length > 0) {
      setTryOnShade(product.shades[0]);
    }
    setActiveTab('try-on');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const addBooking = (bookingData: Omit<Booking, 'id' | 'createdAt' | 'status'>): Booking => {
    const newId = `EL-BOOK-${Math.floor(1000 + Math.random() * 9000)}`;
    const newBooking: Booking = {
      ...bookingData,
      id: newId,
      status: 'Confirmed',
      createdAt: new Date().toISOString().split('T')[0],
    };
    setBookings((prev) => [newBooking, ...prev]);
    // Reward loyalty points for booking consultation
    addPoints(75);
    return newBooking;
  };

  const cancelBooking = (id: string) => {
    setBookings((prev) =>
      prev.map((b) => (b.id === id ? { ...b, status: 'Cancelled' as const } : b))
    );
    showToast('Consultation appointment has been cancelled.');
  };

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        activeCategory,
        setActiveCategory,
        selectedProductForModal,
        setSelectedProductForModal,
        isCartOpen,
        setIsCartOpen,
        isCheckoutOpen,
        setIsCheckoutOpen,
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        cartCount,
        cartSubtotal,
        freeShippingThreshold,
        selectedSamples,
        toggleSample,
        wishlist,
        toggleWishlist,
        isInWishlist,
        userPoints,
        userTier,
        appliedVoucherDiscount,
        redeemedRewards,
        redeemReward,
        addPoints,
        tryOnProduct,
        tryOnShade,
        launchTryOn,
        setTryOnShade,
        bookings,
        addBooking,
        cancelBooking,
        toastMessage,
        showToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
