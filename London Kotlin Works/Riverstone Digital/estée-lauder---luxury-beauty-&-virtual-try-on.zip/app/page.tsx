'use client';

import React from 'react';
import { AppProvider, useApp } from '@/context/AppContext';
import Header from '@/components/Header';
import HeroBanner from '@/components/HeroBanner';
import ProductCatalog from '@/components/ProductCatalog';
import VirtualTryOn from '@/components/VirtualTryOn';
import ConsultationBooking from '@/components/ConsultationBooking';
import LoyaltyEList from '@/components/LoyaltyEList';
import CartDrawer from '@/components/CartDrawer';
import CheckoutModal from '@/components/CheckoutModal';
import Footer from '@/components/Footer';
import { Sparkles, Calendar, Award, CheckCircle2, ShoppingBag } from 'lucide-react';

function MainApp() {
  const { activeTab, setActiveTab, toastMessage } = useApp();

  return (
    <div className="min-h-screen flex flex-col bg-[#faf9f6] text-[#121820]">
      {/* Toast Notification Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 max-w-sm bg-[#061325] text-white border border-[#c5a059] p-4 shadow-2xl animate-fade-in flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-[#c5a059] flex-shrink-0" />
          <p className="text-xs text-stone-200 font-sans-refined">{toastMessage}</p>
        </div>
      )}

      {/* Main Luxury Header */}
      <Header />

      {/* Main Content Area Based on Active Tab */}
      <main className="flex-1">
        {activeTab === 'catalog' && (
          <>
            <HeroBanner />
            <ProductCatalog />
          </>
        )}

        {activeTab === 'try-on' && <VirtualTryOn />}

        {activeTab === 'consultations' && <ConsultationBooking />}

        {activeTab === 'loyalty' && <LoyaltyEList />}
      </main>

      {/* Drawers and Overlays */}
      <CartDrawer />
      <CheckoutModal />

      {/* Luxury Footer */}
      <Footer />
    </div>
  );
}

export default function Page() {
  return (
    <AppProvider>
      <MainApp />
    </AppProvider>
  );
}
