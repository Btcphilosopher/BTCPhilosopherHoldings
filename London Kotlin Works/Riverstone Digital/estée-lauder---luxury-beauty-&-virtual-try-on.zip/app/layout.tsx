import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Estée Lauder | Luxury Skincare, Makeup & Fragrance',
  description: 'Explore iconic skincare including Advanced Night Repair, Double Wear foundation, bespoke beauty consultation bookings, E-List loyalty rewards, and virtual try-on.',
  openGraph: {
    title: 'Estée Lauder | Luxury Skincare, Makeup & Fragrance',
    description: 'Explore iconic skincare including Advanced Night Repair, Double Wear foundation, bespoke beauty consultation bookings, E-List loyalty rewards, and virtual try-on.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Estée Lauder | Luxury Skincare, Makeup & Fragrance',
    description: 'Explore iconic skincare including Advanced Night Repair, Double Wear foundation, bespoke beauty consultation bookings, E-List loyalty rewards, and virtual try-on.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
