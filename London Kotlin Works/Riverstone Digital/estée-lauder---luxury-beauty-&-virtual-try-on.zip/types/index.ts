export type ProductCategory = 'All' | 'Skincare' | 'Makeup' | 'Fragrance' | 'Re-Nutriv' | 'Gifts';

export interface ProductShade {
  id: string;
  name: string;
  code: string;
  hex: string;
  finish: 'Matte' | 'Satin' | 'Gloss' | 'Natural';
  undertone: 'Cool' | 'Neutral' | 'Warm';
  description?: string;
}

export interface Product {
  id: string;
  name: string;
  subtitle: string;
  category: 'Skincare' | 'Makeup' | 'Fragrance' | 'Re-Nutriv' | 'Gifts';
  price: number;
  originalPrice?: number;
  size: string;
  rating: number;
  reviewCount: number;
  badge?: string;
  description: string;
  benefits: string[];
  keyIngredients: string[];
  howToUse: string;
  shades?: ProductShade[];
  concern?: 'Anti-Aging' | 'Hydration' | 'Radiance' | 'Long-Wear' | 'Firming' | 'Pore Minimizing';
  imageUrl: string;
  canTryOn?: boolean;
  tryOnType?: 'lipstick' | 'foundation';
}

export interface CartItem {
  id: string; // unique item id combining product id and shade id
  product: Product;
  selectedShade?: ProductShade;
  selectedSize?: string;
  quantity: number;
}

export interface Sample {
  id: string;
  name: string;
  category: string;
  size: string;
  description: string;
  imageUrl: string;
}

export interface Specialist {
  id: string;
  name: string;
  title: string;
  experience: string;
  bio: string;
  languages: string[];
  avatar: string;
}

export interface Consultation {
  id: string;
  title: string;
  subtitle: string;
  duration: string;
  price: number;
  redeemable: boolean;
  type: 'both' | 'virtual' | 'counter';
  description: string;
  highlights: string[];
  recommendedFor: string;
  specialistIds: string[];
}

export interface Booking {
  id: string;
  consultationId: string;
  consultationTitle: string;
  format: 'virtual' | 'in-counter';
  location: string;
  specialist: Specialist;
  date: string;
  timeSlot: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  skinType: string;
  concerns: string[];
  notes?: string;
  status: 'Confirmed' | 'Completed' | 'Cancelled';
  createdAt: string;
}

export interface LoyaltyTier {
  id: string;
  name: string;
  minPoints: number;
  maxPoints: number | null;
  tagline: string;
  perks: string[];
  multiplier: number;
  color: string;
}

export interface LoyaltyReward {
  id: string;
  name: string;
  pointsCost: number;
  category: 'Skincare Mini' | 'Makeup Mini' | 'Fragrance' | 'Voucher';
  description: string;
  worth: string;
  imageUrl: string;
  discountValue?: number;
}
