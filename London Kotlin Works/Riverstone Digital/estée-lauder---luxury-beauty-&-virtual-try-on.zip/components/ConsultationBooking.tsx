'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { CONSULTATIONS, SPECIALISTS, BOUTIQUE_LOCATIONS } from '@/data/catalog';
import { Consultation, Specialist, Booking } from '@/types';
import { Calendar as CalendarIcon, Clock, MapPin, Video, User, Check, Sparkles, ChevronRight, CheckCircle2, ShieldCheck, Download, AlertCircle } from 'lucide-react';

export default function ConsultationBooking() {
  const { bookings, addBooking, cancelBooking, showToast } = useApp();

  // Booking Flow Steps: 1: Select Service, 2: Format & Specialist, 3: Date & Time, 4: Skin Profile & Contact, 5: Confirmed
  const [step, setStep] = useState<number>(1);
  const [selectedConsultation, setSelectedConsultation] = useState<Consultation>(CONSULTATIONS[0]);
  const [selectedFormat, setSelectedFormat] = useState<'virtual' | 'in-counter'>('virtual');
  const [selectedLocation, setSelectedLocation] = useState<string>(BOUTIQUE_LOCATIONS[0]);
  const [selectedSpecialist, setSelectedSpecialist] = useState<Specialist>(SPECIALISTS[0]);

  // Date and Time selection
  const [selectedDate, setSelectedDate] = useState<string>('2026-11-16');
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>('14:00 GMT');

  // Customer Profile
  const [customerName, setCustomerName] = useState<string>('');
  const [customerEmail, setCustomerEmail] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [skinType, setSkinType] = useState<string>('Combination');
  const [selectedConcerns, setSelectedConcerns] = useState<string[]>(['Fine Lines', 'Hydration']);
  const [notes, setNotes] = useState<string>('');

  const [activeTab, setActiveTabState] = useState<'new' | 'my-appointments'>('new');
  const [confirmedBooking, setConfirmedBooking] = useState<Booking | null>(null);

  const availableDates = [
    { date: '2026-11-16', label: 'Mon, 16 Nov' },
    { date: '2026-11-17', label: 'Tue, 17 Nov' },
    { date: '2026-11-18', label: 'Wed, 18 Nov' },
    { date: '2026-11-19', label: 'Thu, 19 Nov' },
    { date: '2026-11-20', label: 'Fri, 20 Nov' },
    { date: '2026-11-21', label: 'Sat, 21 Nov' },
  ];

  const timeSlots = [
    '10:30 GMT',
    '11:45 GMT',
    '13:15 GMT',
    '14:30 GMT',
    '16:00 GMT',
    '17:30 GMT',
  ];

  const concernOptions = [
    'Fine Lines & Wrinkles',
    'Loss of Firmness',
    'Dehydration',
    'Dark Spots & Dullness',
    'Pores & Texture',
    'Undertone Matching',
  ];

  const toggleConcern = (concern: string) => {
    setSelectedConcerns((prev) =>
      prev.includes(concern) ? prev.filter((c) => c !== concern) : [...prev, concern]
    );
  };

  const handleConsultationSelect = (c: Consultation) => {
    setSelectedConsultation(c);
    if (c.type === 'counter') {
      setSelectedFormat('in-counter');
    }
    setStep(2);
  };

  const handleConfirmBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerEmail || !customerPhone) {
      showToast('Please provide your name, email, and phone number.');
      return;
    }

    const newBooking = addBooking({
      consultationId: selectedConsultation.id,
      consultationTitle: selectedConsultation.title,
      format: selectedFormat,
      location: selectedFormat === 'virtual' ? 'Virtual Private Studio (Google Meet HD)' : selectedLocation,
      specialist: selectedSpecialist,
      date: selectedDate,
      timeSlot: selectedTimeSlot,
      customerName,
      customerEmail,
      customerPhone,
      skinType,
      concerns: selectedConcerns,
      notes,
    });

    setConfirmedBooking(newBooking);
    setStep(5);
    showToast(`Appointment confirmed! Reference: ${newBooking.id}`);
  };

  const handleDownloadCalendar = (booking: Booking) => {
    const icsContent = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Estee Lauder//Beauty Consultation//EN
BEGIN:VEVENT
SUMMARY:Estée Lauder Consultation: ${booking.consultationTitle}
DESCRIPTION:Specialist: ${booking.specialist.name}\\nLocation: ${booking.location}\\nRef: ${booking.id}
DTSTART:${booking.date.replace(/-/g, '')}T140000Z
DTEND:${booking.date.replace(/-/g, '')}T150000Z
STATUS:CONFIRMED
END:VEVENT
END:VCALENDAR`;

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.setAttribute('download', `Estee-Lauder-Consultation-${booking.id}.ics`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Calendar appointment (.ics) exported!');
  };

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
      {/* Editorial Header */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <span className="text-[11px] tracking-[0.3em] uppercase text-[#8b6f38] font-sans-refined font-semibold block mb-2">
          Private Artistry & Skin Science
        </span>
        <h2 className="font-serif-luxury text-3xl sm:text-4xl text-[#061325] font-normal tracking-wide">
          The Estée Lauder Consultation Service
        </h2>
        <div className="w-12 h-0.5 bg-[#c5a059] mx-auto my-3" />
        <p className="text-xs sm:text-sm text-stone-600 font-sans-refined font-light leading-relaxed">
          Book private 1-on-1 consultations with our senior skin longevity specialists and celebrity makeup artists. Experience bespoke chronobiology routines and flawless shade matching.
        </p>

        {/* View Switcher: New Booking vs My Appointments */}
        <div className="flex items-center justify-center gap-2 mt-6">
          <button
            onClick={() => setActiveTabState('new')}
            className={`px-4 py-2 text-xs uppercase tracking-wider font-semibold transition-all ${
              activeTab === 'new'
                ? 'bg-[#061325] text-white shadow'
                : 'bg-white border border-stone-200 text-stone-600 hover:text-black'
            }`}
          >
            Book New Consultation
          </button>
          <button
            onClick={() => setActiveTabState('my-appointments')}
            className={`px-4 py-2 text-xs uppercase tracking-wider font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'my-appointments'
                ? 'bg-[#061325] text-white shadow'
                : 'bg-white border border-stone-200 text-stone-600 hover:text-black'
            }`}
          >
            <CalendarIcon className="w-3.5 h-3.5 text-[#c5a059]" />
            <span>My Bookings ({bookings.filter((b) => b.status === 'Confirmed').length})</span>
          </button>
        </div>
      </div>

      {activeTab === 'my-appointments' ? (
        /* My Appointments View */
        <div className="max-w-4xl mx-auto space-y-6">
          {bookings.length === 0 ? (
            <div className="bg-white border border-stone-200 p-12 text-center">
              <p className="text-stone-500 text-sm">You have no scheduled consultations at this time.</p>
              <button
                onClick={() => setActiveTabState('new')}
                className="mt-4 px-6 py-2.5 bg-[#061325] text-white text-xs uppercase tracking-wider hover:bg-[#c5a059] hover:text-[#061325] transition-colors"
              >
                Schedule A Service
              </button>
            </div>
          ) : (
            bookings.map((booking) => (
              <div
                key={booking.id}
                className="bg-white border border-stone-200 p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-sm hover:border-[#c5a059]/50 transition-colors"
              >
                <div className="space-y-2 flex-1">
                  <div className="flex items-center gap-3">
                    <span className="text-[10px] font-mono tracking-wider px-2 py-0.5 bg-stone-100 text-stone-700 border border-stone-200">
                      REF: {booking.id}
                    </span>
                    <span
                      className={`text-[10px] uppercase tracking-wider px-2 py-0.5 font-semibold ${
                        booking.status === 'Confirmed'
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          : 'bg-red-50 text-red-700 border border-red-200'
                      }`}
                    >
                      {booking.status}
                    </span>
                  </div>

                  <h3 className="font-serif-luxury text-xl sm:text-2xl text-[#061325] font-normal">
                    {booking.consultationTitle}
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-stone-600 pt-1">
                    <div className="flex items-center gap-1.5">
                      <CalendarIcon className="w-3.5 h-3.5 text-[#8b6f38]" />
                      <span>{booking.date} at {booking.timeSlot}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      {booking.format === 'virtual' ? (
                        <Video className="w-3.5 h-3.5 text-[#8b6f38]" />
                      ) : (
                        <MapPin className="w-3.5 h-3.5 text-[#8b6f38]" />
                      )}
                      <span className="truncate">{booking.location}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-[#8b6f38]" />
                      <span>Specialist: {booking.specialist.name}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-stone-500">
                      <span>Client: {booking.customerName}</span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row md:flex-col gap-2 w-full md:w-auto">
                  <button
                    onClick={() => handleDownloadCalendar(booking)}
                    className="px-4 py-2 border border-stone-300 hover:border-black text-xs uppercase tracking-wider font-medium text-stone-800 flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Add to Calendar</span>
                  </button>

                  {booking.status === 'Confirmed' && (
                    <button
                      onClick={() => cancelBooking(booking.id)}
                      className="px-4 py-2 border border-stone-200 hover:border-red-400 text-xs uppercase tracking-wider font-medium text-red-600 hover:bg-red-50 transition-colors"
                    >
                      Cancel Booking
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      ) : (
        /* Multi-Step Booking Wizard */
        <div className="max-w-4xl mx-auto bg-white border border-stone-200 shadow-md">
          {/* Progress Header */}
          <div className="border-b border-stone-200 px-6 py-4 bg-[#faf9f6] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[#061325] text-white text-xs flex items-center justify-center font-bold">
                {step < 5 ? step : 4}
              </span>
              <span className="text-xs uppercase tracking-wider font-semibold text-[#061325]">
                {step === 1 && 'Step 1: Choose Luxury Experience'}
                {step === 2 && 'Step 2: Format & Beauty Specialist'}
                {step === 3 && 'Step 3: Preferred Date & Time'}
                {step === 4 && 'Step 4: Skin Profile & Contact'}
                {step === 5 && 'Appointment Confirmed'}
              </span>
            </div>

            {step > 1 && step < 5 && (
              <button
                onClick={() => setStep(step - 1)}
                className="text-xs text-stone-500 hover:text-black uppercase tracking-wider"
              >
                ← Back
              </button>
            )}
          </div>

          <div className="p-6 sm:p-8">
            {/* STEP 1: Select Consultation Experience */}
            {step === 1 && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {CONSULTATIONS.map((c) => {
                    const isSelected = selectedConsultation.id === c.id;

                    return (
                      <div
                        key={c.id}
                        onClick={() => handleConsultationSelect(c)}
                        className={`p-6 border cursor-pointer transition-all flex flex-col justify-between ${
                          isSelected
                            ? 'border-[#061325] bg-[#fbf9f5] ring-1 ring-[#061325]'
                            : 'border-stone-200 hover:border-[#c5a059]'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between text-xs text-stone-500 mb-1">
                            <span className="flex items-center gap-1 font-mono">
                              <Clock className="w-3 h-3 text-[#8b6f38]" /> {c.duration}
                            </span>
                            <span className="font-semibold text-stone-900">
                              {c.price === 0 ? 'COMPLIMENTARY' : `£${c.price.toFixed(2)}`}
                            </span>
                          </div>

                          <h3 className="font-serif-luxury text-xl text-[#061325] font-normal leading-snug">
                            {c.title}
                          </h3>
                          <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                            {c.subtitle}
                          </p>

                          <ul className="mt-3 space-y-1 text-xs text-stone-600">
                            {c.highlights.slice(0, 2).map((h, i) => (
                              <li key={i} className="flex items-start gap-1.5">
                                <Check className="w-3 h-3 text-[#8b6f38] flex-shrink-0 mt-0.5" />
                                <span>{h}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="mt-5 pt-3 border-t border-stone-200 flex items-center justify-between text-xs">
                          <span className="text-[#8b6f38] font-medium uppercase tracking-wider text-[11px]">
                            {c.redeemable ? '100% Redeemable in product' : 'Expert Service'}
                          </span>
                          <span className="inline-flex items-center gap-1 text-[#061325] font-semibold uppercase tracking-wider text-[11px]">
                            Select <ChevronRight className="w-3 h-3" />
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* STEP 2: Format & Specialist */}
            {step === 2 && (
              <div className="space-y-6">
                {/* Format: Virtual vs In-Counter */}
                <div>
                  <label className="text-xs font-semibold text-stone-900 uppercase tracking-wider block mb-2">
                    Choose Experience Format
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <button
                      type="button"
                      disabled={selectedConsultation.type === 'counter'}
                      onClick={() => setSelectedFormat('virtual')}
                      className={`p-4 border text-left flex items-start gap-3 transition-colors ${
                        selectedFormat === 'virtual'
                          ? 'border-[#061325] bg-[#fbf9f5] ring-1 ring-[#061325]'
                          : 'border-stone-200 hover:border-stone-400'
                      } ${selectedConsultation.type === 'counter' ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                      <Video className="w-5 h-5 text-[#8b6f38] flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-xs font-bold text-stone-900 uppercase tracking-wider">
                          Virtual 1-on-1 Consultation
                        </p>
                        <p className="text-xs text-stone-500 mt-0.5">
                          Private HD video session from the comfort of home. Includes complimentary travel samples shipped in advance.
                        </p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setSelectedFormat('in-counter')}
                      className={`p-4 border text-left flex items-start gap-3 transition-colors ${
                        selectedFormat === 'in-counter'
                          ? 'border-[#061325] bg-[#fbf9f5] ring-1 ring-[#061325]'
                          : 'border-stone-200 hover:border-stone-400'
                      }`}
                    >
                      <MapPin className="w-5 h-5 text-[#8b6f38] flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-xs font-bold text-stone-900 uppercase tracking-wider">
                          In-Counter Boutique Suite
                        </p>
                        <p className="text-xs text-stone-500 mt-0.5">
                          Exclusive luxury counter appointment at an Estée Lauder flagship salon.
                        </p>
                      </div>
                    </button>
                  </div>
                </div>

                {/* Location selector if in-counter */}
                {selectedFormat === 'in-counter' && (
                  <div>
                    <label className="text-xs font-semibold text-stone-900 uppercase tracking-wider block mb-2">
                      Select Boutique Flagship
                    </label>
                    <select
                      value={selectedLocation}
                      onChange={(e) => setSelectedLocation(e.target.value)}
                      className="w-full bg-stone-50 border border-stone-300 p-2.5 text-xs text-stone-900 focus:outline-none focus:border-[#061325]"
                    >
                      {BOUTIQUE_LOCATIONS.map((loc) => (
                        <option key={loc} value={loc}>
                          {loc}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                {/* Specialist Selection */}
                <div>
                  <label className="text-xs font-semibold text-stone-900 uppercase tracking-wider block mb-2">
                    Select Your Estée Lauder Beauty Specialist
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {SPECIALISTS.map((spec) => {
                      const isSelected = selectedSpecialist.id === spec.id;

                      return (
                        <div
                          key={spec.id}
                          onClick={() => setSelectedSpecialist(spec)}
                          className={`p-4 border cursor-pointer text-center transition-all ${
                            isSelected
                              ? 'border-[#061325] bg-[#fbf9f5] ring-1 ring-[#061325]'
                              : 'border-stone-200 hover:border-stone-400'
                          }`}
                        >
                          <div className="w-16 h-16 rounded-full overflow-hidden mx-auto border-2 border-[#c5a059] mb-3">
                            {/* eslint-disable-next-line @next/next/no-img-element */}
                            <img src={spec.avatar} alt={spec.name} className="w-full h-full object-cover" />
                          </div>
                          <h4 className="text-xs font-bold text-stone-900 uppercase tracking-wider">{spec.name}</h4>
                          <p className="text-[11px] text-[#8b6f38] mt-0.5">{spec.title}</p>
                          <p className="text-[10px] text-stone-500 mt-1 font-mono">{spec.experience}</p>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="pt-4 flex justify-end">
                  <button
                    onClick={() => setStep(3)}
                    className="px-6 py-2.5 bg-[#061325] text-white hover:bg-[#c5a059] hover:text-[#061325] text-xs uppercase tracking-wider font-semibold transition-colors"
                  >
                    Continue to Date & Time →
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3: Preferred Date & Time */}
            {step === 3 && (
              <div className="space-y-6">
                <div>
                  <label className="text-xs font-semibold text-stone-900 uppercase tracking-wider block mb-2">
                    Select Consultation Date
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
                    {availableDates.map((item) => (
                      <button
                        key={item.date}
                        onClick={() => setSelectedDate(item.date)}
                        className={`p-3 border text-center transition-all ${
                          selectedDate === item.date
                            ? 'border-[#061325] bg-[#061325] text-white'
                            : 'border-stone-200 hover:border-stone-400 bg-white text-stone-800'
                        }`}
                      >
                        <span className="block text-xs font-bold">{item.label.split(',')[0]}</span>
                        <span className="block text-[11px] text-stone-400">{item.label.split(',')[1]}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-stone-900 uppercase tracking-wider block mb-2">
                    Select Available Time Slot
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {timeSlots.map((slot) => (
                      <button
                        key={slot}
                        onClick={() => setSelectedTimeSlot(slot)}
                        className={`p-2.5 border text-center text-xs font-mono transition-all ${
                          selectedTimeSlot === slot
                            ? 'border-[#061325] bg-[#fbf9f5] text-[#061325] font-bold ring-1 ring-[#061325]'
                            : 'border-stone-200 hover:border-stone-400 bg-white text-stone-700'
                        }`}
                      >
                        {slot}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-4 bg-stone-50 border border-stone-200 flex items-center justify-between text-xs text-stone-700">
                  <div className="flex items-center gap-2">
                    <CalendarIcon className="w-4 h-4 text-[#8b6f38]" />
                    <span>
                      Selected: <strong>{selectedDate}</strong> at <strong>{selectedTimeSlot}</strong> with <strong>{selectedSpecialist.name}</strong>
                    </span>
                  </div>
                </div>

                <div className="pt-4 flex justify-end">
                  <button
                    onClick={() => setStep(4)}
                    className="px-6 py-2.5 bg-[#061325] text-white hover:bg-[#c5a059] hover:text-[#061325] text-xs uppercase tracking-wider font-semibold transition-colors"
                  >
                    Continue to Profile →
                  </button>
                </div>
              </div>
            )}

            {/* STEP 4: Skin Profile & Contact Info */}
            {step === 4 && (
              <form onSubmit={handleConfirmBooking} className="space-y-6">
                <div>
                  <h4 className="text-xs font-bold text-stone-900 uppercase tracking-wider mb-3">
                    Skin Profile Questionnaire
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[11px] text-stone-600 block mb-1">Primary Skin Type</label>
                      <select
                        value={skinType}
                        onChange={(e) => setSkinType(e.target.value)}
                        className="w-full bg-stone-50 border border-stone-300 p-2 text-xs text-stone-800 focus:outline-none"
                      >
                        <option value="Dry">Dry / Dehydrated</option>
                        <option value="Combination">Combination</option>
                        <option value="Normal">Normal</option>
                        <option value="Oily">Oily</option>
                        <option value="Sensitive">Sensitive / Reactive</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[11px] text-stone-600 block mb-1">Specific Needs / Allergies</label>
                      <input
                        type="text"
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        placeholder="e.g. Fragrance-free preferences, upcoming wedding"
                        className="w-full bg-stone-50 border border-stone-300 p-2 text-xs text-stone-800 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="mt-3">
                    <label className="text-[11px] text-stone-600 block mb-1.5">
                      Target Skin Concerns (Select all that apply)
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {concernOptions.map((concern) => (
                        <button
                          key={concern}
                          type="button"
                          onClick={() => toggleConcern(concern)}
                          className={`px-3 py-1 text-xs border rounded-none transition-colors ${
                            selectedConcerns.includes(concern)
                              ? 'border-[#061325] bg-[#061325] text-white'
                              : 'border-stone-300 text-stone-700 bg-white hover:border-stone-500'
                          }`}
                        >
                          {concern}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-stone-200">
                  <h4 className="text-xs font-bold text-stone-900 uppercase tracking-wider mb-3">
                    Contact & Confirmation Details
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="text-[11px] text-stone-600 block mb-1">Full Name *</label>
                      <input
                        type="text"
                        required
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        placeholder="Lady Victoria Hastings"
                        className="w-full bg-stone-50 border border-stone-300 p-2 text-xs text-stone-800 focus:outline-none focus:border-[#061325]"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-stone-600 block mb-1">Email Address *</label>
                      <input
                        type="email"
                        required
                        value={customerEmail}
                        onChange={(e) => setCustomerEmail(e.target.value)}
                        placeholder="victoria@client.com"
                        className="w-full bg-stone-50 border border-stone-300 p-2 text-xs text-stone-800 focus:outline-none focus:border-[#061325]"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-stone-600 block mb-1">Mobile Telephone *</label>
                      <input
                        type="tel"
                        required
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                        placeholder="+44 7700 900821"
                        className="w-full bg-stone-50 border border-stone-300 p-2 text-xs text-stone-800 focus:outline-none focus:border-[#061325]"
                      />
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-[#faf7f2] border border-[#c5a059]/40 flex items-center gap-3">
                  <Sparkles className="w-5 h-5 text-[#8b6f38] flex-shrink-0" />
                  <div className="text-xs text-stone-700">
                    <p className="font-semibold text-[#061325]">
                      E-List Privilege: Earn +75 Loyalty Points with this Consultation
                    </p>
                    <p className="text-stone-500">
                      Points will be automatically credited to your member account upon appointment confirmation.
                    </p>
                  </div>
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    type="submit"
                    className="px-8 py-3 bg-[#061325] text-white hover:bg-[#c5a059] hover:text-[#061325] text-xs uppercase tracking-[0.16em] font-semibold transition-colors shadow-md"
                  >
                    Confirm Private Appointment →
                  </button>
                </div>
              </form>
            )}

            {/* STEP 5: Booking Confirmed Screen */}
            {step === 5 && confirmedBooking && (
              <div className="text-center py-6 space-y-6">
                <div className="w-16 h-16 rounded-full bg-emerald-50 border-2 border-emerald-500 flex items-center justify-center mx-auto text-emerald-600">
                  <CheckCircle2 className="w-10 h-10" />
                </div>

                <div>
                  <span className="text-[11px] tracking-[0.25em] text-[#8b6f38] uppercase font-semibold">
                    Appointment Pass Confirmed
                  </span>
                  <h3 className="font-serif-luxury text-3xl text-[#061325] font-normal mt-1">
                    We Look Forward to Welcoming You
                  </h3>
                  <p className="text-xs text-stone-600 max-w-md mx-auto mt-2">
                    A confirmation email and private calendar invitation have been dispatched to <strong>{confirmedBooking.customerEmail}</strong>.
                  </p>
                </div>

                {/* Luxury Pass Card */}
                <div className="max-w-md mx-auto bg-[#faf9f6] border border-[#c5a059]/50 p-6 text-left shadow-lg space-y-4">
                  <div className="flex items-center justify-between border-b border-stone-200 pb-3">
                    <span className="text-xs font-serif-luxury text-[#061325] font-bold tracking-widest uppercase">
                      ESTĒE LAUDER PASS
                    </span>
                    <span className="text-xs font-mono font-bold text-[#8b6f38]">
                      {confirmedBooking.id}
                    </span>
                  </div>

                  <div className="space-y-2 text-xs text-stone-700">
                    <p className="font-semibold text-stone-900 text-sm">{confirmedBooking.consultationTitle}</p>
                    <p className="flex items-center gap-1.5">
                      <CalendarIcon className="w-3.5 h-3.5 text-[#8b6f38]" />
                      <span>{confirmedBooking.date} at {confirmedBooking.timeSlot}</span>
                    </p>
                    <p className="flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-[#8b6f38]" />
                      <span>Advisor: {confirmedBooking.specialist.name}</span>
                    </p>
                    <p className="flex items-center gap-1.5">
                      {confirmedBooking.format === 'virtual' ? (
                        <Video className="w-3.5 h-3.5 text-[#8b6f38]" />
                      ) : (
                        <MapPin className="w-3.5 h-3.5 text-[#8b6f38]" />
                      )}
                      <span>{confirmedBooking.location}</span>
                    </p>
                  </div>

                  <div className="pt-3 border-t border-stone-200 flex items-center justify-between">
                    <span className="text-[10px] uppercase tracking-wider text-stone-500">
                      Skin Concerns: {confirmedBooking.concerns.join(', ')}
                    </span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
                  <button
                    onClick={() => handleDownloadCalendar(confirmedBooking)}
                    className="px-5 py-2.5 bg-[#061325] text-white hover:bg-[#c5a059] hover:text-[#061325] text-xs uppercase tracking-wider font-medium flex items-center gap-2 transition-colors"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Calendar (.ICS)</span>
                  </button>

                  <button
                    onClick={() => setActiveTabState('my-appointments')}
                    className="px-5 py-2.5 border border-stone-300 text-stone-800 text-xs uppercase tracking-wider font-medium hover:border-black transition-colors"
                  >
                    View In My Bookings
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );
}
