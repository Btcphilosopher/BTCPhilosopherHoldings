'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { ArrowRight, Check, ShieldCheck, Truck, Sparkles, MapPin } from 'lucide-react';

export default function Footer() {
  const { setActiveTab, setActiveCategory, showToast } = useApp();
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      showToast('Welcome to the Estée Lauder Society! Check your inbox for your 15% code.');
    }
  };

  return (
    <footer className="bg-[#030b14] text-white border-t border-[#c5a059]/25 mt-16 font-sans-refined">
      {/* 3 Value Pillars */}
      <div className="border-b border-[#c5a059]/15 py-10 bg-[#051120]">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left">
          <div className="flex flex-col md:flex-row items-center gap-4">
            <div className="w-12 h-12 bg-[#092243] border border-[#c5a059]/30 flex items-center justify-center text-[#c5a059] flex-shrink-0">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-serif-luxury text-base text-white">Complimentary Delivery</h4>
              <p className="text-xs text-stone-400 mt-0.5">Carbon-neutral worldwide shipping on all orders over £100.</p>
            </div>
          </div>

          <div className="flex flex-col md:flex-row items-center gap-4">
            <div className="w-12 h-12 bg-[#092243] border border-[#c5a059]/30 flex items-center justify-center text-[#c5a059] flex-shrink-0">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-serif-luxury text-base text-white">2 Deluxe Samples</h4>
              <p className="text-xs text-stone-400 mt-0.5">Select up to two luxury travel miniatures with every purchase.</p>
            </div>
          </div>

          <div className="flex flex-col md:flex-row items-center gap-4">
            <div className="w-12 h-12 bg-[#092243] border border-[#c5a059]/30 flex items-center justify-center text-[#c5a059] flex-shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-serif-luxury text-base text-white">Expert Artistry</h4>
              <p className="text-xs text-stone-400 mt-0.5">Complimentary 1-on-1 virtual and in-counter consultations.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links & Newsletter */}
      <div className="max-w-7xl mx-auto px-6 py-14 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
        {/* Brand Legacy Quote */}
        <div className="lg:col-span-2 space-y-4">
          <span className="font-serif-luxury text-2xl tracking-[0.2em] uppercase block">
            ESTĒE LAUDER
          </span>
          <p className="font-serif-luxury italic text-stone-300 text-sm leading-relaxed max-w-sm">
            &quot;I didn&apos;t get there by wishing for it or hoping for it, but by working for it. Every woman can be beautiful.&quot;
          </p>
          <span className="text-[11px] uppercase tracking-widest text-[#c5a059] block">
            — Mrs. Estée Lauder, Founder
          </span>

          <div className="pt-2">
            <p className="text-xs text-stone-400 mb-2">Receive exclusive invitations & a 15% welcome privilege:</p>
            {subscribed ? (
              <p className="text-xs text-emerald-400 flex items-center gap-1.5 font-medium">
                <Check className="w-4 h-4" /> Thank you for subscribing. Welcome to the Estée E-List.
              </p>
            ) : (
              <form onSubmit={handleSubscribe} className="flex max-w-sm">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email address"
                  className="bg-[#0b1f38] border border-[#c5a059]/30 px-3 py-2 text-xs text-white placeholder:text-stone-500 flex-1 focus:outline-none focus:border-[#c5a059]"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#c5a059] text-[#061325] hover:bg-white text-xs uppercase tracking-wider font-semibold transition-colors flex items-center justify-center"
                >
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Collections */}
        <div className="space-y-3">
          <h4 className="text-xs uppercase tracking-[0.2em] text-[#c5a059] font-semibold">
            Collections
          </h4>
          <ul className="space-y-2 text-xs text-stone-400">
            <li>
              <button
                onClick={() => { setActiveTab('catalog'); setActiveCategory('Skincare'); }}
                className="hover:text-white transition-colors"
              >
                Advanced Night Repair
              </button>
            </li>
            <li>
              <button
                onClick={() => { setActiveTab('catalog'); setActiveCategory('Makeup'); }}
                className="hover:text-white transition-colors"
              >
                Double Wear Makeup
              </button>
            </li>
            <li>
              <button
                onClick={() => { setActiveTab('catalog'); setActiveCategory('Re-Nutriv'); }}
                className="hover:text-white transition-colors"
              >
                Re-Nutriv Haute Skincare
              </button>
            </li>
            <li>
              <button
                onClick={() => { setActiveTab('catalog'); setActiveCategory('Fragrance'); }}
                className="hover:text-white transition-colors"
              >
                Beautiful Magnolia
              </button>
            </li>
            <li>
              <button
                onClick={() => { setActiveTab('catalog'); setActiveCategory('Gifts'); }}
                className="hover:text-white transition-colors"
              >
                Holiday Keepsake Vaults
              </button>
            </li>
          </ul>
        </div>

        {/* Client Services */}
        <div className="space-y-3">
          <h4 className="text-xs uppercase tracking-[0.2em] text-[#c5a059] font-semibold">
            Client Services
          </h4>
          <ul className="space-y-2 text-xs text-stone-400">
            <li>
              <button
                onClick={() => setActiveTab('consultations')}
                className="hover:text-white transition-colors"
              >
                Book Private Consultation
              </button>
            </li>
            <li>
              <button
                onClick={() => setActiveTab('try-on')}
                className="hover:text-white transition-colors"
              >
                Virtual Shade Match & Try-On
              </button>
            </li>
            <li>
              <button
                onClick={() => setActiveTab('loyalty')}
                className="hover:text-white transition-colors"
              >
                The Estée E-List Rewards
              </button>
            </li>
            <li>
              <span className="text-stone-500">Complimentary Returns</span>
            </li>
            <li>
              <span className="text-stone-500">Track An Order</span>
            </li>
          </ul>
        </div>

        {/* Boutiques & Heritage */}
        <div className="space-y-3">
          <h4 className="text-xs uppercase tracking-[0.2em] text-[#c5a059] font-semibold">
            Flagships & Boutiques
          </h4>
          <ul className="space-y-2 text-xs text-stone-400">
            <li className="flex items-start gap-1.5">
              <MapPin className="w-3 h-3 text-[#c5a059] flex-shrink-0 mt-0.5" />
              <span>Regent St, London</span>
            </li>
            <li className="flex items-start gap-1.5">
              <MapPin className="w-3 h-3 text-[#c5a059] flex-shrink-0 mt-0.5" />
              <span>Fifth Avenue, New York</span>
            </li>
            <li className="flex items-start gap-1.5">
              <MapPin className="w-3 h-3 text-[#c5a059] flex-shrink-0 mt-0.5" />
              <span>Rue Saint-Honoré, Paris</span>
            </li>
            <li className="flex items-start gap-1.5">
              <MapPin className="w-3 h-3 text-[#c5a059] flex-shrink-0 mt-0.5" />
              <span>Galleria, Milan</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Copyright & Disclaimer Hairline */}
      <div className="border-t border-[#c5a059]/15 py-6 bg-[#02070e] text-center text-[11px] text-stone-500">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© {new Date().getFullYear()} Estée Lauder Inc. All Worldwide Rights Reserved.</p>
          <div className="flex items-center gap-4 text-stone-400">
            <span>Privacy Policy</span>
            <span>·</span>
            <span>Terms & Conditions</span>
            <span>·</span>
            <span>Supply Chain Transparency</span>
            <span>·</span>
            <span>Cookie Settings</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
