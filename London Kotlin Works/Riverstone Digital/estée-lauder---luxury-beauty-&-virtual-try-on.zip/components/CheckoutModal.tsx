'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { X, Check, ShieldCheck, Gift, CreditCard, Lock, Sparkles, CheckCircle2, ArrowRight, Truck } from 'lucide-react';

export default function CheckoutModal() {
  const {
    isCheckoutOpen,
    setIsCheckoutOpen,
    cart,
    cartSubtotal,
    appliedVoucherDiscount,
    selectedSamples,
    clearCart,
    addPoints,
    userTier,
    showToast,
  } = useApp();

  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Step 1: Shipping Details
  const [fullName, setFullName] = useState('Victoria Hastings');
  const [email, setEmail] = useState('victoria.hastings@luxury-client.com');
  const [address, setAddress] = useState('14 Berkeley Square, Mayfair');
  const [city, setCity] = useState('London');
  const [postalCode, setPostalCode] = useState('W1J 5AW');
  const [country, setCountry] = useState('United Kingdom');
  const [phone, setPhone] = useState('+44 7700 900821');
  const [shippingMethod, setShippingMethod] = useState<'standard' | 'express'>('standard');

  // Step 2: Gift Packaging & Card
  const [giftWrap, setGiftWrap] = useState(true);
  const [giftMessage, setGiftMessage] = useState('With timeless love and endless radiance. Happy Celebration.');

  // Step 3: Payment
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'applepay' | 'klarna'>('card');
  const [cardNumber, setCardNumber] = useState('4532 •••• •••• 8912');
  const [cardExpiry, setCardExpiry] = useState('11/29');
  const [cardCvc, setCardCvc] = useState('384');
  const [cardName, setCardName] = useState('VICTORIA HASTINGS');

  // Step 4: Confirmed State
  const [confirmedOrderId, setConfirmedOrderId] = useState<string | null>(null);

  if (!isCheckoutOpen) return null;

  const shippingCost = shippingMethod === 'express' ? 6.50 : 0.00;
  const total = Math.max(0, cartSubtotal - appliedVoucherDiscount + shippingCost);
  const pointsToEarn = Math.round(total * (userTier === 'Be Envied' ? 1.5 : userTier === 'Be Enthusiastic' ? 1.25 : 1.0));

  const handlePlaceOrder = () => {
    const orderId = `EL-2026-${Math.floor(10000 + Math.random() * 90000)}`;
    setConfirmedOrderId(orderId);
    setStep(4);
    addPoints(pointsToEarn);
    clearCart();
    showToast(`Order ${orderId} confirmed! +${pointsToEarn} E-List points added.`);
  };

  const handleClose = () => {
    setIsCheckoutOpen(false);
    setStep(1);
    setConfirmedOrderId(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div
        className="relative w-full max-w-3xl max-h-[92vh] overflow-y-auto bg-[#faf9f6] text-[#121820] border border-[#c5a059]/40 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-stone-200 bg-[#061325] text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="font-serif-luxury text-xl tracking-widest uppercase">
              ESTĒE LAUDER CHECKOUT
            </span>
            <span className="text-xs text-[#c5a059] border-l border-[#c5a059]/40 pl-3 hidden sm:inline">
              Private Client Portal
            </span>
          </div>

          <button
            onClick={handleClose}
            className="text-stone-400 hover:text-white p-1"
            aria-label="Close checkout"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Indicator (Steps 1-3) */}
        {step < 4 && (
          <div className="grid grid-cols-3 border-b border-stone-200 bg-[#f4efe8] text-xs font-semibold uppercase tracking-wider text-center">
            <div
              className={`py-3 flex items-center justify-center gap-2 border-r border-stone-200 ${
                step === 1 ? 'bg-white text-[#061325] border-b-2 border-b-[#c5a059]' : 'text-stone-500'
              }`}
            >
              <span className="w-5 h-5 rounded-full bg-[#061325] text-white text-[10px] flex items-center justify-center">1</span>
              <span className="hidden sm:inline">Delivery Details</span>
            </div>

            <div
              className={`py-3 flex items-center justify-center gap-2 border-r border-stone-200 ${
                step === 2 ? 'bg-white text-[#061325] border-b-2 border-b-[#c5a059]' : 'text-stone-500'
              }`}
            >
              <span className="w-5 h-5 rounded-full bg-[#061325] text-white text-[10px] flex items-center justify-center">2</span>
              <span className="hidden sm:inline">Gift Packaging</span>
            </div>

            <div
              className={`py-3 flex items-center justify-center gap-2 ${
                step === 3 ? 'bg-white text-[#061325] border-b-2 border-b-[#c5a059]' : 'text-stone-500'
              }`}
            >
              <span className="w-5 h-5 rounded-full bg-[#061325] text-white text-[10px] flex items-center justify-center">3</span>
              <span className="hidden sm:inline">Payment & Review</span>
            </div>
          </div>
        )}

        <div className="p-6 sm:p-8">
          {/* STEP 1: Shipping Address & Delivery Option */}
          {step === 1 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider mb-3">
                  Recipient Contact & Address
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[11px] text-stone-600 block mb-1">Full Name</label>
                    <input
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      className="w-full bg-white border border-stone-300 p-2 text-xs text-stone-800 focus:outline-none focus:border-[#061325]"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-stone-600 block mb-1">Email Address</label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-white border border-stone-300 p-2 text-xs text-stone-800 focus:outline-none focus:border-[#061325]"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="text-[11px] text-stone-600 block mb-1">Street Address</label>
                    <input
                      type="text"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      className="w-full bg-white border border-stone-300 p-2 text-xs text-stone-800 focus:outline-none focus:border-[#061325]"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-stone-600 block mb-1">City / Town</label>
                    <input
                      type="text"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      className="w-full bg-white border border-stone-300 p-2 text-xs text-stone-800 focus:outline-none focus:border-[#061325]"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-stone-600 block mb-1">Postal Code</label>
                    <input
                      type="text"
                      value={postalCode}
                      onChange={(e) => setPostalCode(e.target.value)}
                      className="w-full bg-white border border-stone-300 p-2 text-xs text-stone-800 focus:outline-none focus:border-[#061325]"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-stone-600 block mb-1">Country</label>
                    <select
                      value={country}
                      onChange={(e) => setCountry(e.target.value)}
                      className="w-full bg-white border border-stone-300 p-2 text-xs text-stone-800 focus:outline-none focus:border-[#061325]"
                    >
                      <option value="United Kingdom">United Kingdom</option>
                      <option value="United States">United States</option>
                      <option value="France">France</option>
                      <option value="Germany">Germany</option>
                      <option value="Italy">Italy</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[11px] text-stone-600 block mb-1">Mobile Telephone</label>
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full bg-white border border-stone-300 p-2 text-xs text-stone-800 focus:outline-none focus:border-[#061325]"
                    />
                  </div>
                </div>
              </div>

              {/* Delivery Speed Options */}
              <div className="pt-2 border-t border-stone-200">
                <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider mb-3">
                  Delivery Method
                </h3>
                <div className="space-y-2">
                  <div
                    onClick={() => setShippingMethod('standard')}
                    className={`p-3 border cursor-pointer flex items-center justify-between transition-colors ${
                      shippingMethod === 'standard'
                        ? 'border-[#061325] bg-[#fbf9f5] ring-1 ring-[#061325]'
                        : 'border-stone-200 bg-white hover:border-stone-400'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Truck className="w-4 h-4 text-[#8b6f38]" />
                      <div>
                        <p className="text-xs font-semibold text-stone-900">
                          Complimentary Carbon-Neutral Standard Delivery
                        </p>
                        <p className="text-[11px] text-stone-500">Delivered within 2–3 business days via Royal Mail Tracked</p>
                      </div>
                    </div>
                    <span className="text-xs font-mono font-bold text-emerald-800">FREE</span>
                  </div>

                  <div
                    onClick={() => setShippingMethod('express')}
                    className={`p-3 border cursor-pointer flex items-center justify-between transition-colors ${
                      shippingMethod === 'express'
                        ? 'border-[#061325] bg-[#fbf9f5] ring-1 ring-[#061325]'
                        : 'border-stone-200 bg-white hover:border-stone-400'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Sparkles className="w-4 h-4 text-[#8b6f38]" />
                      <div>
                        <p className="text-xs font-semibold text-stone-900">
                          Express Next-Day Guaranteed Priority Delivery
                        </p>
                        <p className="text-[11px] text-stone-500">Next morning before 12:00 PM signature required</p>
                      </div>
                    </div>
                    <span className="text-xs font-mono font-bold text-stone-900">£6.50</span>
                  </div>
                </div>
              </div>

              <div className="pt-4 flex justify-end">
                <button
                  onClick={() => setStep(2)}
                  className="px-6 py-2.5 bg-[#061325] text-white hover:bg-[#c5a059] hover:text-[#061325] text-xs uppercase tracking-wider font-semibold transition-colors flex items-center gap-2"
                >
                  <span>Continue to Gift Packaging</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: Estee Lauder Signature Gift Packaging & Message */}
          {step === 2 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider mb-2">
                  Estée Lauder Presentation Packaging
                </h3>
                <p className="text-xs text-stone-600 mb-4">
                  Every order is hand-inspected and wrapped with archival tissue and gold satin ribbon in our signature navy keepsake box.
                </p>

                <div className="p-4 border border-[#c5a059]/40 bg-[#faf7f2] flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#061325] text-[#c5a059] flex items-center justify-center flex-shrink-0 shadow">
                    <Gift className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-bold text-[#061325] uppercase tracking-wider">
                        Signature Navy & Gold Keepsake Box
                      </p>
                      <span className="text-[11px] font-mono font-bold text-emerald-800">COMPLIMENTARY</span>
                    </div>
                    <p className="text-[11px] text-stone-600 mt-1">
                      Our iconic navy presentation box with embossed gold logo and braided ribbon, perfect for gifting or preserving your treasures.
                    </p>

                    <label className="flex items-center gap-2 mt-3 cursor-pointer text-xs text-stone-800">
                      <input
                        type="checkbox"
                        checked={giftWrap}
                        onChange={(e) => setGiftWrap(e.target.checked)}
                        className="accent-[#061325]"
                      />
                      <span>Include complimentary gift packaging with this order</span>
                    </label>
                  </div>
                </div>
              </div>

              {giftWrap && (
                <div>
                  <label className="text-xs font-semibold text-stone-900 uppercase tracking-wider block mb-1.5">
                    Personalized Handwritten Gift Card Message
                  </label>
                  <textarea
                    rows={3}
                    value={giftMessage}
                    onChange={(e) => setGiftMessage(e.target.value)}
                    placeholder="Enter your private gift note to be printed on gold foil stationery..."
                    className="w-full bg-white border border-stone-300 p-2.5 text-xs text-stone-800 focus:outline-none focus:border-[#061325]"
                  />
                  <p className="text-[11px] text-stone-400 mt-1">
                    Printed on heavy weight cream cotton paper and sealed in an embossed gold envelope.
                  </p>
                </div>
              )}

              <div className="pt-4 flex justify-between">
                <button
                  onClick={() => setStep(1)}
                  className="px-4 py-2 text-xs uppercase tracking-wider text-stone-600 hover:text-black"
                >
                  ← Back
                </button>
                <button
                  onClick={() => setStep(3)}
                  className="px-6 py-2.5 bg-[#061325] text-white hover:bg-[#c5a059] hover:text-[#061325] text-xs uppercase tracking-wider font-semibold transition-colors flex items-center gap-2"
                >
                  <span>Continue to Payment</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: Payment Method & Order Summary */}
          {step === 3 && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Left: Payment Form */}
                <div className="space-y-4">
                  <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider">
                    Payment Method
                  </h3>

                  {/* Payment Tabs */}
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <button
                      onClick={() => setPaymentMethod('card')}
                      className={`py-2 px-1 border uppercase tracking-wider font-medium text-[11px] transition-colors ${
                        paymentMethod === 'card'
                          ? 'border-[#061325] bg-[#061325] text-white'
                          : 'border-stone-200 text-stone-600 hover:border-stone-400'
                      }`}
                    >
                      Card
                    </button>
                    <button
                      onClick={() => setPaymentMethod('applepay')}
                      className={`py-2 px-1 border uppercase tracking-wider font-medium text-[11px] transition-colors ${
                        paymentMethod === 'applepay'
                          ? 'border-[#061325] bg-[#061325] text-white'
                          : 'border-stone-200 text-stone-600 hover:border-stone-400'
                      }`}
                    >
                      Apple Pay
                    </button>
                    <button
                      onClick={() => setPaymentMethod('klarna')}
                      className={`py-2 px-1 border uppercase tracking-wider font-medium text-[11px] transition-colors ${
                        paymentMethod === 'klarna'
                          ? 'border-[#061325] bg-[#061325] text-white'
                          : 'border-stone-200 text-stone-600 hover:border-stone-400'
                      }`}
                    >
                      Klarna
                    </button>
                  </div>

                  {paymentMethod === 'card' && (
                    <div className="space-y-3">
                      {/* Luxury Metallic Visual Card */}
                      <div className="p-4 bg-gradient-to-tr from-[#061325] to-[#122e58] text-white rounded-none border border-[#c5a059]/40 shadow-lg relative overflow-hidden">
                        <div className="flex justify-between items-center mb-6">
                          <span className="font-serif-luxury tracking-widest text-xs uppercase text-[#c5a059]">
                            ESTĒE LAUDER PRIVILEGE
                          </span>
                          <span className="w-8 h-6 bg-[#c5a059]/80 rounded-xs block opacity-80" />
                        </div>
                        <p className="font-mono text-base tracking-widest mb-4">{cardNumber}</p>
                        <div className="flex justify-between text-[10px] uppercase font-mono text-stone-300">
                          <span>{cardName}</span>
                          <span>EXP: {cardExpiry}</span>
                        </div>
                      </div>

                      <div>
                        <label className="text-[11px] text-stone-600 block mb-1">Card Number</label>
                        <input
                          type="text"
                          value={cardNumber}
                          onChange={(e) => setCardNumber(e.target.value)}
                          className="w-full bg-white border border-stone-300 p-2 text-xs font-mono text-stone-800 focus:outline-none"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[11px] text-stone-600 block mb-1">Expiry (MM/YY)</label>
                          <input
                            type="text"
                            value={cardExpiry}
                            onChange={(e) => setCardExpiry(e.target.value)}
                            className="w-full bg-white border border-stone-300 p-2 text-xs font-mono text-stone-800 focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="text-[11px] text-stone-600 block mb-1">CVC Code</label>
                          <input
                            type="text"
                            value={cardCvc}
                            onChange={(e) => setCardCvc(e.target.value)}
                            className="w-full bg-white border border-stone-300 p-2 text-xs font-mono text-stone-800 focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {paymentMethod === 'applepay' && (
                    <div className="p-6 bg-black text-white text-center space-y-2">
                      <p className="text-xs uppercase tracking-wider text-stone-300">One-Touch Instant Pay</p>
                      <button
                        type="button"
                        onClick={handlePlaceOrder}
                        className="w-full py-3 bg-white text-black font-semibold text-xs uppercase tracking-wider hover:bg-stone-200 transition-colors"
                      >
                        Pay with Pay (£{total.toFixed(2)})
                      </button>
                    </div>
                  )}

                  {paymentMethod === 'klarna' && (
                    <div className="p-4 bg-[#fbeae7] border border-[#f5b8ad] text-xs space-y-2">
                      <p className="font-bold text-stone-900">Pay in 3 interest-free payments</p>
                      <p className="text-stone-700">
                        Pay £{(total / 3).toFixed(2)} today, and the rest in 2 automatic monthly installments.
                      </p>
                    </div>
                  )}
                </div>

                {/* Right: Order Summary */}
                <div className="bg-[#f5f1ea] p-5 border border-stone-300 flex flex-col justify-between">
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold text-stone-900 uppercase tracking-wider border-b border-stone-300 pb-2">
                      Order Summary ({cart.reduce((a, b) => a + b.quantity, 0)} Items)
                    </h4>

                    <div className="space-y-2 max-h-40 overflow-y-auto text-xs pr-1">
                      {cart.map((item) => (
                        <div key={item.id} className="flex justify-between items-start text-stone-800">
                          <div>
                            <span className="font-medium line-clamp-1">{item.product.name}</span>
                            <span className="text-[11px] text-stone-500 block">
                              Qty {item.quantity} {item.selectedShade ? `· ${item.selectedShade.name}` : ''}
                            </span>
                          </div>
                          <span className="font-mono font-medium">£{(item.product.price * item.quantity).toFixed(2)}</span>
                        </div>
                      ))}
                    </div>

                    {selectedSamples.length > 0 && (
                      <div className="pt-2 border-t border-stone-300 text-[11px] text-[#8b6f38]">
                        <p className="font-semibold uppercase tracking-wider">Complimentary Samples:</p>
                        {selectedSamples.map((s) => (
                          <p key={s.id} className="text-stone-700">· {s.name} ({s.size})</p>
                        ))}
                      </div>
                    )}

                    <div className="pt-2 border-t border-stone-300 space-y-1 text-xs">
                      <div className="flex justify-between text-stone-600">
                        <span>Subtotal</span>
                        <span className="font-mono">£{cartSubtotal.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-stone-600">
                        <span>Shipping ({shippingMethod})</span>
                        <span className="font-mono">{shippingCost === 0 ? 'FREE' : `£${shippingCost.toFixed(2)}`}</span>
                      </div>
                      {appliedVoucherDiscount > 0 && (
                        <div className="flex justify-between text-emerald-700">
                          <span>E-List Loyalty Discount</span>
                          <span className="font-mono">-£{appliedVoucherDiscount.toFixed(2)}</span>
                        </div>
                      )}
                      <div className="flex justify-between text-sm font-bold text-[#061325] pt-2 border-t border-stone-300">
                        <span>Final Total</span>
                        <span className="font-mono">£{total.toFixed(2)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-stone-300">
                    <div className="p-2.5 bg-[#faf7f2] border border-[#c5a059]/40 mb-3 text-[11px] text-stone-700 flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-[#8b6f38] flex-shrink-0" />
                      <span>You will earn <strong>+{pointsToEarn} E-List Points</strong> on this order.</span>
                    </div>

                    <button
                      onClick={handlePlaceOrder}
                      className="w-full py-3 bg-[#061325] text-white hover:bg-[#c5a059] hover:text-[#061325] text-xs uppercase tracking-[0.18em] font-semibold transition-colors flex items-center justify-center gap-2 shadow-md"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>Authorize Payment · £{total.toFixed(2)}</span>
                    </button>
                  </div>
                </div>
              </div>

              <div className="pt-2 flex justify-start">
                <button
                  onClick={() => setStep(2)}
                  className="text-xs uppercase tracking-wider text-stone-600 hover:text-black"
                >
                  ← Back to Packaging
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: Order Confirmed Success Screen */}
          {step === 4 && confirmedOrderId && (
            <div className="text-center py-6 space-y-6">
              <div className="w-16 h-16 rounded-full bg-emerald-50 border-2 border-emerald-500 flex items-center justify-center mx-auto text-emerald-600">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <span className="text-[11px] tracking-[0.25em] text-[#8b6f38] uppercase font-semibold">
                  Thank You for Your Order
                </span>
                <h3 className="font-serif-luxury text-3xl text-[#061325] font-normal mt-1">
                  Your Estée Lauder Treasures Are Being Prepared
                </h3>
                <p className="text-xs text-stone-600 max-w-md mx-auto mt-2">
                  Order <strong>{confirmedOrderId}</strong> has been received and is being hand-wrapped in our signature navy keepsake presentation box.
                </p>
              </div>

              {/* Receipt Summary Card */}
              <div className="max-w-md mx-auto bg-white border border-stone-300 p-6 text-left shadow-md space-y-3 text-xs">
                <div className="flex justify-between border-b border-stone-200 pb-2">
                  <span className="font-serif-luxury font-bold text-[#061325]">ORDER RECEIPT</span>
                  <span className="font-mono text-stone-500">{confirmedOrderId}</span>
                </div>

                <div className="space-y-1 text-stone-600">
                  <p><strong>Deliver To:</strong> {fullName}, {address}, {city} {postalCode}</p>
                  <p><strong>Dispatch Carrier:</strong> Royal Mail Tracked (Est. Delivery 2 business days)</p>
                  <p><strong>Payment Authorized:</strong> Card ending {cardNumber.slice(-4)}</p>
                </div>

                <div className="pt-2 border-t border-stone-200 text-[#8b6f38] font-semibold flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4" />
                  <span>+{pointsToEarn} E-List Loyalty Points Credited to Your Account</span>
                </div>
              </div>

              <div className="pt-2 flex justify-center">
                <button
                  onClick={handleClose}
                  className="px-8 py-3 bg-[#061325] text-white hover:bg-[#c5a059] hover:text-[#061325] text-xs uppercase tracking-[0.18em] font-semibold transition-colors shadow"
                >
                  Return to Estée Lauder Experience
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
