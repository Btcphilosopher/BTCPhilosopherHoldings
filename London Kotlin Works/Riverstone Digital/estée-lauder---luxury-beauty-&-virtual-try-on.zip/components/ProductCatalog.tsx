'use client';

import React, { useState, useMemo } from 'react';
import { useApp } from '@/context/AppContext';
import { ESTEE_PRODUCTS } from '@/data/catalog';
import { ProductCategory, Product } from '@/types';
import { Star, Sparkles, Heart, ShoppingBag, Eye, SlidersHorizontal, Check } from 'lucide-react';
import ProductModal from './ProductModal';

export default function ProductCatalog() {
  const {
    activeCategory,
    setActiveCategory,
    addToCart,
    launchTryOn,
    toggleWishlist,
    isInWishlist,
    selectedProductForModal,
    setSelectedProductForModal,
  } = useApp();

  const [selectedConcern, setSelectedConcern] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating'>('featured');

  const categories: ProductCategory[] = ['All', 'Skincare', 'Makeup', 'Fragrance', 'Re-Nutriv', 'Gifts'];
  const concerns = ['All', 'Anti-Aging', 'Hydration', 'Radiance', 'Long-Wear', 'Firming'];

  const filteredProducts = useMemo(() => {
    return ESTEE_PRODUCTS.filter((product) => {
      const matchesCategory = activeCategory === 'All' || product.category === activeCategory;
      const matchesConcern = selectedConcern === 'All' || product.concern === selectedConcern;
      return matchesCategory && matchesConcern;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      return 0; // featured default
    });
  }, [activeCategory, selectedConcern, sortBy]);

  return (
    <section id="luxury-catalog-section" className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
      {/* Editorial Header */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <span className="text-[11px] tracking-[0.3em] uppercase text-[#8b6f38] font-sans-refined font-semibold block mb-2">
          Curated Haute Parfumerie & Skincare
        </span>
        <h2 className="font-serif-luxury text-3xl sm:text-4xl text-[#061325] font-normal tracking-wide">
          The Estée Lauder Collection
        </h2>
        <div className="w-12 h-0.5 bg-[#c5a059] mx-auto my-3" />
        <p className="text-xs sm:text-sm text-stone-600 font-sans-refined font-light leading-relaxed">
          From the breakthrough longevity science of Advanced Night Repair and Re-Nutriv to the 24-hour perfection of Double Wear.
        </p>
      </div>

      {/* Filter and Category Controls */}
      <div className="flex flex-col lg:flex-row items-center justify-between gap-4 pb-6 border-b border-stone-200 mb-8">
        {/* Category Navigation Pills */}
        <div className="flex flex-wrap items-center justify-center gap-1.5 sm:gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 text-xs tracking-wider uppercase font-medium transition-all ${
                activeCategory === cat
                  ? 'bg-[#061325] text-white shadow-sm'
                  : 'bg-white border border-stone-200 text-stone-600 hover:text-black hover:border-stone-400'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Concern filter and Sorting */}
        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div className="flex items-center gap-2 bg-white border border-stone-200 px-3 py-1.5">
            <SlidersHorizontal className="w-3.5 h-3.5 text-[#8b6f38]" />
            <span className="text-stone-500 uppercase tracking-wider text-[11px]">Concern:</span>
            <select
              value={selectedConcern}
              onChange={(e) => setSelectedConcern(e.target.value)}
              className="bg-transparent text-stone-800 text-xs focus:outline-none cursor-pointer"
            >
              {concerns.map((c) => (
                <option key={c} value={c}>
                  {c === 'All' ? 'All Concerns' : c}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2 bg-white border border-stone-200 px-3 py-1.5">
            <span className="text-stone-500 uppercase tracking-wider text-[11px]">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-transparent text-stone-800 text-xs focus:outline-none cursor-pointer"
            >
              <option value="featured">Featured Curations</option>
              <option value="rating">Highest Rated</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
            </select>
          </div>
        </div>
      </div>

      {/* Product Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredProducts.map((product) => {
          const inWishlist = isInWishlist(product.id);

          return (
            <div
              key={product.id}
              className="group bg-white border border-stone-200 hover:border-[#c5a059]/60 hover:shadow-xl transition-all duration-300 flex flex-col justify-between overflow-hidden"
            >
              {/* Top Media Container */}
              <div className="relative bg-[#f7f5f0] p-6 flex flex-col items-center justify-center min-h-[290px] overflow-hidden">
                {/* Badge */}
                {product.badge && (
                  <span className="absolute top-3 left-3 z-10 bg-[#061325] text-[#c5a059] text-[9px] tracking-[0.2em] uppercase px-2.5 py-1 font-semibold">
                    {product.badge}
                  </span>
                )}

                {/* Wishlist Button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleWishlist(product.id);
                  }}
                  className="absolute top-3 right-3 z-10 p-2 bg-white/90 hover:bg-white border border-stone-200 text-stone-600 hover:text-black transition-colors rounded-none"
                  aria-label="Toggle wishlist"
                >
                  <Heart className={`w-3.5 h-3.5 ${inWishlist ? 'fill-red-500 text-red-500' : ''}`} />
                </button>

                {/* Product Image */}
                <div
                  onClick={() => setSelectedProductForModal(product)}
                  className="cursor-pointer relative w-full aspect-square max-w-[210px] flex items-center justify-center transition-transform duration-500 group-hover:scale-105"
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={product.imageUrl}
                    alt={product.name}
                    className="max-h-56 w-auto object-contain drop-shadow-md"
                  />
                </div>

                {/* Hover Quick Action Overlay */}
                <div className="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-black/60 to-transparent flex items-center justify-center gap-2 translate-y-full group-hover:translate-y-0 transition-transform duration-200">
                  <button
                    onClick={() => setSelectedProductForModal(product)}
                    className="px-3 py-1.5 bg-white text-[#061325] text-[11px] uppercase tracking-wider font-medium hover:bg-stone-100 flex items-center gap-1 shadow"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Quick View</span>
                  </button>

                  {product.canTryOn && (
                    <button
                      onClick={() => launchTryOn(product)}
                      className="px-3 py-1.5 bg-[#c5a059] text-[#061325] text-[11px] uppercase tracking-wider font-semibold hover:bg-white flex items-center gap-1 shadow"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Try On</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Product Info Section */}
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between text-[11px] text-stone-500 uppercase tracking-widest mb-1">
                    <span>{product.category}</span>
                    <div className="flex items-center gap-1 text-[#8b6f38]">
                      <Star className="w-3 h-3 fill-current" />
                      <span className="font-semibold text-stone-700">{product.rating}</span>
                      <span className="text-stone-400">({product.reviewCount})</span>
                    </div>
                  </div>

                  <h3
                    onClick={() => setSelectedProductForModal(product)}
                    className="font-serif-luxury text-lg text-[#061325] group-hover:text-[#8b6f38] transition-colors cursor-pointer leading-snug line-clamp-2"
                  >
                    {product.name}
                  </h3>

                  <p className="text-xs text-stone-500 mt-1 line-clamp-1 font-light">
                    {product.subtitle}
                  </p>

                  {/* Shades Preview Chips if available */}
                  {product.shades && (
                    <div className="flex items-center gap-1.5 mt-3">
                      <span className="text-[10px] text-stone-400 uppercase tracking-wider">
                        {product.shades.length} Shades:
                      </span>
                      <div className="flex -space-x-1 overflow-hidden">
                        {product.shades.slice(0, 5).map((s) => (
                          <span
                            key={s.id}
                            className="inline-block w-3.5 h-3.5 rounded-full border border-white shadow-xs"
                            style={{ backgroundColor: s.hex }}
                            title={`${s.code} ${s.name}`}
                          />
                        ))}
                      </div>
                      {product.shades.length > 5 && (
                        <span className="text-[10px] text-stone-500 font-mono">
                          +{product.shades.length - 5}
                        </span>
                      )}
                    </div>
                  )}
                </div>

                {/* Price and CTA */}
                <div className="mt-5 pt-4 border-t border-stone-100 flex items-center justify-between">
                  <div>
                    <div className="flex items-baseline gap-2">
                      <span className="font-serif-luxury text-xl font-semibold text-[#061325]">
                        £{product.price.toFixed(2)}
                      </span>
                      {product.originalPrice && (
                        <span className="text-xs text-stone-400 line-through">
                          £{product.originalPrice.toFixed(2)}
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-stone-400 uppercase tracking-wider block">
                      {product.size}
                    </span>
                  </div>

                  <button
                    onClick={() => addToCart(product, product.shades ? product.shades[0] : undefined)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#061325] text-white hover:bg-[#c5a059] hover:text-[#061325] text-xs uppercase tracking-wider font-medium transition-colors"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>Add</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredProducts.length === 0 && (
        <div className="text-center py-16 bg-white border border-stone-200">
          <p className="text-sm text-stone-500">No products match your selected criteria.</p>
          <button
            onClick={() => {
              setActiveCategory('All');
              setSelectedConcern('All');
            }}
            className="mt-3 px-4 py-2 text-xs uppercase tracking-wider border border-[#061325] text-[#061325] hover:bg-[#061325] hover:text-white transition-colors"
          >
            Reset Filters
          </button>
        </div>
      )}

      {/* Selected Product Detail Modal */}
      {selectedProductForModal && (
        <ProductModal
          product={selectedProductForModal}
          onClose={() => setSelectedProductForModal(null)}
        />
      )}
    </section>
  );
}
