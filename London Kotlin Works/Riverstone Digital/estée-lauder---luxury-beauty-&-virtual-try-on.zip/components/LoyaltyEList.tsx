'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { LOYALTY_TIERS, LOYALTY_REWARDS } from '@/data/catalog';
import { Award, Gift, Sparkles, Check, ChevronRight, Zap, Shield, ArrowUpRight, Crown } from 'lucide-react';
import { LoyaltyReward } from '@/types';

export default function LoyaltyEList() {
  const { userPoints, userTier, redeemReward, addPoints, redeemedRewards, setActiveTab } = useApp();
  const [selectedReward, setSelectedReward] = useState<LoyaltyReward | null>(null);

  const nextTierPoints = 650;
  const pointsToNextTier = Math.max(0, nextTierPoints - userPoints);
  const progressPercent = Math.min(100, Math.round((userPoints / nextTierPoints) * 100));

  const handleRedeem = (reward: LoyaltyReward) => {
    redeemReward(reward);
  };

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
      {/* Editorial Header */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <span className="text-[11px] tracking-[0.3em] uppercase text-[#8b6f38] font-sans-refined font-semibold block mb-2">
          Exclusive Membership Privileges
        </span>
        <h2 className="font-serif-luxury text-3xl sm:text-4xl text-[#061325] font-normal tracking-wide">
          The Estée E-List Loyalty Program
        </h2>
        <div className="w-12 h-0.5 bg-[#c5a059] mx-auto my-3" />
        <p className="text-xs sm:text-sm text-stone-600 font-sans-refined font-light leading-relaxed">
          Where beauty becomes extraordinary. Earn points with every purchase, consultation, and review to unlock complimentary deluxe miniatures, anniversary gifts, and private VIP access.
        </p>
      </div>

      {/* Member Loyalty Card Banner */}
      <div className="max-w-4xl mx-auto bg-gradient-to-r from-[#061325] via-[#092243] to-[#040e1b] border border-[#c5a059]/40 p-6 sm:p-10 text-white shadow-2xl relative overflow-hidden mb-12">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Crown className="w-5 h-5 text-[#c5a059]" />
              <span className="text-xs tracking-[0.25em] uppercase text-[#c5a059] font-semibold">
                Estée E-List Member Card
              </span>
            </div>

            <div className="flex items-baseline gap-3">
              <h3 className="font-serif-luxury text-3xl sm:text-4xl font-normal text-white">
                {userTier}
              </h3>
              <span className="text-xs text-stone-300 font-mono">
                Tier Multiplier: 1.25x Points
              </span>
            </div>

            <p className="text-xs text-stone-300 max-w-md font-light">
              You are currently enjoying elevated prestige privileges, complimentary express shipping, and exclusive masterclasses.
            </p>
          </div>

          <div className="bg-[#0b2447]/80 border border-[#c5a059]/40 p-5 min-w-[220px] text-center backdrop-blur-sm">
            <span className="text-[11px] uppercase tracking-wider text-stone-300 block">Available Points</span>
            <span className="font-serif-luxury text-4xl sm:text-5xl text-[#c5a059] font-bold block my-1">
              {userPoints}
            </span>
            <span className="text-[10px] text-stone-400 font-mono uppercase tracking-wider">
              Points Worth ~£{(userPoints * 0.05).toFixed(2)}
            </span>
          </div>
        </div>

        {/* Tier Progress Bar */}
        <div className="mt-8 pt-6 border-t border-[#c5a059]/20 relative z-10">
          <div className="flex items-center justify-between text-xs text-stone-300 mb-2">
            <span>Current Status: <strong className="text-white">{userTier}</strong></span>
            <span>
              {pointsToNextTier > 0 ? (
                <span><strong>{pointsToNextTier} points</strong> to reach <strong className="text-[#c5a059]">Be Envied</strong></span>
              ) : (
                <span className="text-[#c5a059] font-bold">Top Tier Achieved!</span>
              )}
            </span>
          </div>

          <div className="w-full h-2 bg-stone-800/80 rounded-full overflow-hidden border border-[#c5a059]/30">
            <div
              className="h-full bg-gradient-to-r from-[#8b6f38] to-[#c5a059] transition-all duration-700"
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          <div className="flex justify-between text-[10px] text-stone-400 mt-2 font-mono">
            <span>Be Excited (0 pts)</span>
            <span>Be Enthusiastic (250 pts)</span>
            <span>Be Envied (650 pts)</span>
          </div>
        </div>

        {/* Ambient luxury glow */}
        <div className="absolute -right-16 -top-16 w-64 h-64 bg-[#c5a059]/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Rewards Redemption Store */}
      <div className="mb-14">
        <div className="flex items-center justify-between mb-6 border-b border-stone-200 pb-3">
          <div>
            <h3 className="font-serif-luxury text-2xl text-[#061325]">
              Redeem E-List Rewards
            </h3>
            <p className="text-xs text-stone-500">
              Exchange your earned points for full-size vouchers and deluxe luxury miniatures.
            </p>
          </div>
          <span className="text-xs font-mono text-[#8b6f38] font-bold">
            Balance: {userPoints} Points
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {LOYALTY_REWARDS.map((reward) => {
            const canAfford = userPoints >= reward.pointsCost;

            return (
              <div
                key={reward.id}
                className="bg-white border border-stone-200 hover:border-[#c5a059]/60 transition-all p-5 flex flex-col justify-between shadow-xs hover:shadow-md"
              >
                <div>
                  <div className="relative aspect-square w-full bg-[#f8f6f2] mb-4 flex items-center justify-center p-4">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={reward.imageUrl}
                      alt={reward.name}
                      className="max-h-36 object-contain"
                    />
                    <span className="absolute top-2 right-2 text-[10px] bg-[#061325] text-[#c5a059] font-mono px-2 py-0.5">
                      {reward.worth}
                    </span>
                  </div>

                  <span className="text-[10px] text-[#8b6f38] uppercase tracking-wider font-semibold">
                    {reward.category}
                  </span>
                  <h4 className="font-serif-luxury text-base text-[#061325] font-normal mt-0.5 leading-snug">
                    {reward.name}
                  </h4>
                  <p className="text-xs text-stone-500 mt-1 line-clamp-2">
                    {reward.description}
                  </p>
                </div>

                <div className="mt-5 pt-3 border-t border-stone-100 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-serif-luxury font-bold text-[#061325] block">
                      {reward.pointsCost} PTS
                    </span>
                  </div>

                  <button
                    onClick={() => handleRedeem(reward)}
                    disabled={!canAfford}
                    className={`px-3 py-1.5 text-xs uppercase tracking-wider font-semibold transition-colors ${
                      canAfford
                        ? 'bg-[#061325] text-white hover:bg-[#c5a059] hover:text-[#061325]'
                        : 'bg-stone-200 text-stone-400 cursor-not-allowed'
                    }`}
                  >
                    {canAfford ? 'Redeem' : 'Need More Pts'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Tiers Comparison Matrix */}
      <div className="bg-white border border-stone-200 p-6 sm:p-8 mb-12 shadow-sm">
        <h3 className="font-serif-luxury text-2xl text-[#061325] text-center mb-2">
          Membership Tier Privileges
        </h3>
        <p className="text-xs text-stone-500 text-center mb-8 max-w-lg mx-auto">
          Every £1 spent earns points towards our three distinguished tiers of luxury care.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {LOYALTY_TIERS.map((tier) => {
            const isUserTier = userTier === tier.name;

            return (
              <div
                key={tier.id}
                className={`p-6 border relative flex flex-col justify-between ${
                  isUserTier
                    ? 'border-[#c5a059] bg-[#fbf9f5] ring-2 ring-[#c5a059]/40 shadow-md'
                    : 'border-stone-200 bg-white'
                }`}
              >
                {isUserTier && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#061325] text-[#c5a059] text-[10px] uppercase tracking-widest px-3 py-0.5 font-bold shadow-sm">
                    Your Current Tier
                  </span>
                )}

                <div>
                  <div className="text-center pb-4 border-b border-stone-200">
                    <h4 className="font-serif-luxury text-2xl text-[#061325]">{tier.name}</h4>
                    <p className="text-xs font-mono text-[#8b6f38] font-semibold mt-1">
                      {tier.maxPoints ? `${tier.minPoints} – ${tier.maxPoints} Points` : `${tier.minPoints}+ Points`}
                    </p>
                    <p className="text-[11px] text-stone-500 mt-1 italic">{tier.tagline}</p>
                  </div>

                  <ul className="mt-5 space-y-2.5 text-xs text-stone-600">
                    {tier.perks.map((perk, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <Check className="w-3.5 h-3.5 text-[#8b6f38] flex-shrink-0 mt-0.5" />
                        <span>{perk}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-6 pt-4 border-t border-stone-200 text-center">
                  <span className="text-[11px] text-stone-400 font-mono">
                    Points Earn Rate: {tier.multiplier}x / £1
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Ways to Earn Points Quick Interactive Bar */}
      <div className="bg-[#061325] text-white p-6 sm:p-8 border border-[#c5a059]/30">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center md:text-left">
            <span className="text-[10px] text-[#c5a059] uppercase tracking-widest font-semibold">
              Accelerate Your Privilege
            </span>
            <h4 className="font-serif-luxury text-xl sm:text-2xl font-normal text-white">
              Complimentary Ways to Earn E-List Points Today
            </h4>
            <p className="text-xs text-stone-400">
              Complete beauty profile, attend skin masterclasses, and explore virtual try-ons.
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => addPoints(50)}
              className="px-4 py-2 border border-[#c5a059]/50 hover:border-[#c5a059] bg-[#092243] text-stone-200 hover:text-white text-xs uppercase tracking-wider flex items-center gap-1.5 transition-colors"
            >
              <Zap className="w-3.5 h-3.5 text-[#c5a059]" />
              <span>Complete Profile (+50 Pts)</span>
            </button>

            <button
              onClick={() => setActiveTab('consultations')}
              className="px-4 py-2 bg-[#c5a059] text-[#061325] text-xs uppercase tracking-wider font-semibold hover:bg-white transition-colors flex items-center gap-1.5"
            >
              <Gift className="w-3.5 h-3.5" />
              <span>Book Consultation (+75 Pts)</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
