'use client';

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useApp } from '@/context/AppContext';
import { ESTEE_PRODUCTS } from '@/data/catalog';
import { Product, ProductShade } from '@/types';
import { Sparkles, Camera, Upload, RotateCcw, ShoppingBag, Sliders, Check, Download, Info } from 'lucide-react';

interface FacePreset {
  id: string;
  name: string;
  undertone: 'Fair Rosy' | 'Fair Neutral' | 'Medium Golden' | 'Olive' | 'Deep Amber' | 'Deep Espresso';
  imageUrl: string;
  // Lip coordinates in normalized 0-1 scale on the preset image
  lipCenter: { x: number; y: number; width: number; height: number };
}

const PRESET_MODELS: FacePreset[] = [
  {
    id: 'model-1',
    name: 'Isabelle (Fair Rosy)',
    undertone: 'Fair Rosy',
    imageUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=800&auto=format&fit=crop&q=80',
    lipCenter: { x: 0.50, y: 0.655, width: 0.22, height: 0.085 },
  },
  {
    id: 'model-2',
    name: 'Sophia (Fair Neutral)',
    undertone: 'Fair Neutral',
    imageUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80',
    lipCenter: { x: 0.50, y: 0.67, width: 0.24, height: 0.09 },
  },
  {
    id: 'model-3',
    name: 'Camila (Medium Golden)',
    undertone: 'Medium Golden',
    imageUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=800&auto=format&fit=crop&q=80',
    lipCenter: { x: 0.49, y: 0.65, width: 0.23, height: 0.088 },
  },
  {
    id: 'model-4',
    name: 'Zara (Deep Amber)',
    undertone: 'Deep Amber',
    imageUrl: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=800&auto=format&fit=crop&q=80',
    lipCenter: { x: 0.50, y: 0.66, width: 0.25, height: 0.092 },
  },
];

export default function VirtualTryOn() {
  const { tryOnProduct, tryOnShade, setTryOnShade, addToCart, showToast } = useApp();

  // Try-on category toggle: 'lipstick' or 'foundation'
  const [activeCategory, setActiveCategory] = useState<'lipstick' | 'foundation'>(
    tryOnProduct?.tryOnType === 'foundation' ? 'foundation' : 'lipstick'
  );

  const lipstickProduct = ESTEE_PRODUCTS.find((p) => p.id === 'pure-color-envy-lipstick') || ESTEE_PRODUCTS[2];
  const foundationProduct = ESTEE_PRODUCTS.find((p) => p.id === 'double-wear-foundation') || ESTEE_PRODUCTS[1];

  const currentProduct = activeCategory === 'lipstick' ? lipstickProduct : foundationProduct;
  const availableShades = currentProduct.shades || [];

  const [selectedShade, setSelectedShadeState] = useState<ProductShade>(() => {
    if (tryOnShade && currentProduct.shades?.some((s) => s.id === tryOnShade.id)) {
      return tryOnShade;
    }
    return availableShades[0];
  });

  // Selected Preset Model or User Upload
  const [selectedModel, setSelectedModel] = useState<FacePreset>(PRESET_MODELS[0]);
  const [userUploadedImage, setUserUploadedImage] = useState<string | null>(null);

  // Live Camera
  const [isCameraActive, setIsCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Settings
  const [intensity, setIntensity] = useState<number>(0.75);
  const [finish, setFinish] = useState<'Satin' | 'Matte' | 'Gloss'>('Satin');
  const [splitSliderPos, setSplitSliderPos] = useState<number>(50); // percentage 0-100
  const [isSplitActive, setIsSplitActive] = useState<boolean>(true);

  // Canvas
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const renderTryOn = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const sourceImage = new Image();
    sourceImage.crossOrigin = 'anonymous';
    sourceImage.src = userUploadedImage || selectedModel.imageUrl;

    sourceImage.onload = () => {
      canvas.width = sourceImage.naturalWidth || 800;
      canvas.height = sourceImage.naturalHeight || 1000;

      // 1. Draw original base portrait
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(sourceImage, 0, 0, canvas.width, canvas.height);

      // If split screen is active, we clip the makeup application to the right side of the split line
      const splitX = isSplitActive ? (canvas.width * splitSliderPos) / 100 : 0;

      ctx.save();
      if (isSplitActive) {
        ctx.beginPath();
        ctx.rect(splitX, 0, canvas.width - splitX, canvas.height);
        ctx.clip();
      }

      if (activeCategory === 'lipstick') {
        // Draw realistic contoured lips
        const { lipCenter } = selectedModel;
        const cx = canvas.width * lipCenter.x;
        const cy = canvas.height * lipCenter.y;
        const rx = (canvas.width * lipCenter.width) / 2;
        const ry = (canvas.height * lipCenter.height) / 2;

        ctx.save();

        // Lip contour path (upper & lower lip shape)
        ctx.beginPath();
        ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);

        // Fill with chosen shade hex
        ctx.fillStyle = selectedShade.hex;
        ctx.globalAlpha = intensity;
        ctx.globalCompositeOperation = finish === 'Matte' ? 'multiply' : 'source-over';
        ctx.fill();

        // Second pass: soft luminosity
        ctx.globalCompositeOperation = 'soft-light';
        ctx.fillStyle = selectedShade.hex;
        ctx.globalAlpha = 0.6;
        ctx.fill();

        // Finish highlight (Gloss or Satin sheen)
        if (finish === 'Gloss') {
          ctx.globalCompositeOperation = 'screen';
          ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
          ctx.beginPath();
          ctx.ellipse(cx, cy - ry * 0.2, rx * 0.45, ry * 0.25, 0, 0, Math.PI * 2);
          ctx.fill();
        } else if (finish === 'Satin') {
          ctx.globalCompositeOperation = 'screen';
          ctx.fillStyle = 'rgba(255, 255, 255, 0.18)';
          ctx.beginPath();
          ctx.ellipse(cx, cy - ry * 0.1, rx * 0.35, ry * 0.2, 0, 0, Math.PI * 2);
          ctx.fill();
        }

        ctx.restore();
      } else {
        // Foundation Complexion tint
        ctx.save();
        ctx.globalCompositeOperation = 'soft-light';
        ctx.fillStyle = selectedShade.hex;
        ctx.globalAlpha = intensity * 0.4;
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Radial face highlight for Double Wear perfection
        const grad = ctx.createRadialGradient(
          canvas.width * 0.5,
          canvas.height * 0.45,
          canvas.width * 0.1,
          canvas.width * 0.5,
          canvas.height * 0.45,
          canvas.width * 0.4
        );
        grad.addColorStop(0, 'rgba(255, 255, 255, 0.15)');
        grad.addColorStop(1, 'rgba(0, 0, 0, 0.05)');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        ctx.restore();
      }

      ctx.restore(); // Restore clip

      // If split screen is active, draw luxury gold divider line
      if (isSplitActive) {
        ctx.save();
        ctx.strokeStyle = '#c5a059';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(splitX, 0);
        ctx.lineTo(splitX, canvas.height);
        ctx.stroke();

        // Split badge labels
        ctx.font = 'bold 16px "Plus Jakarta Sans", sans-serif';
        ctx.fillStyle = 'rgba(6, 19, 37, 0.85)';
        ctx.fillRect(20, 20, 100, 32);
        ctx.fillStyle = '#ffffff';
        ctx.fillText('BEFORE', 36, 42);

        ctx.fillStyle = 'rgba(6, 19, 37, 0.85)';
        ctx.fillRect(canvas.width - 120, 20, 100, 32);
        ctx.fillStyle = '#c5a059';
        ctx.fillText('AFTER', canvas.width - 96, 42);

        ctx.restore();
      }
    };
  }, [
    userUploadedImage,
    selectedModel,
    isSplitActive,
    splitSliderPos,
    activeCategory,
    selectedShade,
    intensity,
    finish,
  ]);

  useEffect(() => {
    renderTryOn();
  }, [renderTryOn]);

  const handleShadeSelect = (shade: ProductShade) => {
    setSelectedShadeState(shade);
    setTryOnShade(shade);
    if (shade.finish && (shade.finish === 'Matte' || shade.finish === 'Satin' || shade.finish === 'Gloss')) {
      setFinish(shade.finish);
    }
  };

  const handleProductCategorySwitch = (cat: 'lipstick' | 'foundation') => {
    setActiveCategory(cat);
    const prod = cat === 'lipstick' ? lipstickProduct : foundationProduct;
    if (prod.shades && prod.shades.length > 0) {
      handleShadeSelect(prod.shades[0]);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setUserUploadedImage(event.target.result as string);
          showToast('Photo uploaded! Applying Estée Lauder virtual shades.');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDownloadSnapshot = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `Estee-Lauder-${currentProduct.name}-${selectedShade.name}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
    showToast('Look saved to your downloads!');
  };

  const handleStartCamera = async () => {
    try {
      if (isCameraActive) {
        setIsCameraActive(false);
        return;
      }
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
        setIsCameraActive(true);
        showToast('Live camera connected. Testing in real time.');
      }
    } catch {
      showToast('Camera access unavailable. Using high-resolution model studio.');
    }
  };

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
      {/* Studio Banner */}
      <div className="text-center max-w-2xl mx-auto mb-8">
        <span className="text-[11px] tracking-[0.3em] uppercase text-[#8b6f38] font-sans-refined font-semibold block mb-1">
          Augmented Reality Studio
        </span>
        <h2 className="font-serif-luxury text-3xl sm:text-4xl text-[#061325] font-normal tracking-wide">
          Estée Lauder Virtual Try-On
        </h2>
        <div className="w-12 h-0.5 bg-[#c5a059] mx-auto my-3" />
        <p className="text-xs sm:text-sm text-stone-600 font-sans-refined font-light leading-relaxed">
          Test our award-winning Pure Color Envy shades and 24-hour Double Wear foundation in real time. Compare Before & After in high definition.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Interactive Canvas Viewer (7 Cols) */}
        <div className="lg:col-span-7 bg-[#061325] p-4 sm:p-6 border border-[#c5a059]/30 shadow-2xl relative">
          <div className="relative aspect-[4/5] w-full max-h-[580px] bg-black overflow-hidden flex items-center justify-center">
            {isCameraActive ? (
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover transform scale-x-[-1]"
              />
            ) : (
              <canvas
                ref={canvasRef}
                className="w-full h-full object-cover"
              />
            )}

            {/* Live Camera notification banner if running */}
            {isCameraActive && (
              <div className="absolute top-4 left-4 bg-[#c5a059] text-[#061325] text-xs font-bold px-3 py-1 uppercase tracking-wider">
                Live Camera Mirror Active
              </div>
            )}
          </div>

          {/* Split Screen Slider Control Bar */}
          {isSplitActive && !isCameraActive && (
            <div className="mt-4 pt-3 border-t border-[#c5a059]/20 flex items-center gap-4 text-xs text-stone-300">
              <span className="text-stone-400 uppercase tracking-wider text-[10px]">Natural</span>
              <input
                type="range"
                min="0"
                max="100"
                value={splitSliderPos}
                onChange={(e) => setSplitSliderPos(Number(e.target.value))}
                className="flex-1 accent-[#c5a059] cursor-pointer"
              />
              <span className="text-[#c5a059] uppercase tracking-wider text-[10px] font-semibold">
                Estée Look ({splitSliderPos}%)
              </span>
            </div>
          )}

          {/* Model Preset Bar & Photo / Cam Upload Bar */}
          <div className="mt-5 pt-4 border-t border-[#c5a059]/20 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-stone-400 uppercase tracking-widest text-[10px]">Skin Profiles:</span>
              <div className="flex gap-1.5">
                {PRESET_MODELS.map((model) => (
                  <button
                    key={model.id}
                    onClick={() => {
                      setSelectedModel(model);
                      setUserUploadedImage(null);
                      if (isCameraActive) setIsCameraActive(false);
                    }}
                    className={`px-2.5 py-1 text-[11px] border transition-all ${
                      selectedModel.id === model.id && !userUploadedImage && !isCameraActive
                        ? 'border-[#c5a059] bg-[#c5a059] text-[#061325] font-semibold'
                        : 'border-stone-700 bg-black/40 text-stone-300 hover:border-stone-500'
                    }`}
                  >
                    {model.name.split(' ')[0]}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* Photo Upload */}
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileUpload}
                accept="image/*"
                className="hidden"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="px-2.5 py-1 border border-stone-600 bg-stone-900/60 text-stone-300 hover:text-white hover:border-[#c5a059] text-[11px] flex items-center gap-1.5 transition-colors"
                title="Upload Portrait"
              >
                <Upload className="w-3 h-3 text-[#c5a059]" />
                <span>Upload</span>
              </button>

              {/* Live Webcam Toggle */}
              <button
                onClick={handleStartCamera}
                className={`px-2.5 py-1 border text-[11px] flex items-center gap-1.5 transition-colors ${
                  isCameraActive
                    ? 'border-[#c5a059] bg-[#c5a059] text-[#061325] font-semibold'
                    : 'border-stone-600 bg-stone-900/60 text-stone-300 hover:border-[#c5a059]'
                }`}
                title="Use Live Camera"
              >
                <Camera className="w-3 h-3 text-[#c5a059]" />
                <span>{isCameraActive ? 'Stop Cam' : 'Live Mirror'}</span>
              </button>

              {/* Download / Share */}
              <button
                onClick={handleDownloadSnapshot}
                className="p-1.5 border border-stone-600 text-stone-300 hover:text-[#c5a059] hover:border-[#c5a059] transition-colors"
                title="Save Look"
              >
                <Download className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Right Shade Selector & Formula Customization Controls (5 Cols) */}
        <div className="lg:col-span-5 bg-white border border-stone-200 p-6 space-y-6 shadow-md">
          {/* Category Switcher: Lipstick vs Foundation */}
          <div className="grid grid-cols-2 gap-2 p-1 bg-stone-100 border border-stone-200">
            <button
              onClick={() => handleProductCategorySwitch('lipstick')}
              className={`py-2 text-xs uppercase tracking-wider font-semibold transition-all ${
                activeCategory === 'lipstick'
                  ? 'bg-[#061325] text-white shadow'
                  : 'text-stone-600 hover:text-black'
              }`}
            >
              Pure Color Envy Lip
            </button>
            <button
              onClick={() => handleProductCategorySwitch('foundation')}
              className={`py-2 text-xs uppercase tracking-wider font-semibold transition-all ${
                activeCategory === 'foundation'
                  ? 'bg-[#061325] text-white shadow'
                  : 'text-stone-600 hover:text-black'
              }`}
            >
              Double Wear Complexion
            </button>
          </div>

          {/* Current Product Title */}
          <div>
            <div className="flex items-center justify-between text-xs text-[#8b6f38] uppercase tracking-widest mb-1">
              <span>{currentProduct.category} · {currentProduct.size}</span>
              <span className="font-semibold text-stone-800">£{currentProduct.price.toFixed(2)}</span>
            </div>
            <h3 className="font-serif-luxury text-2xl text-[#061325] font-normal leading-tight">
              {currentProduct.name}
            </h3>
            <p className="text-xs text-stone-500 mt-1 font-light">
              {currentProduct.subtitle}
            </p>
          </div>

          {/* Shade Matrix & Swatches */}
          <div className="space-y-3 pt-2 border-t border-stone-200">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-stone-900 uppercase tracking-wider">
                Select Shade ({availableShades.length} Available)
              </span>
              <span className="text-[11px] text-stone-500">
                Undertone: <strong>{selectedShade.undertone}</strong>
              </span>
            </div>

            {/* Active Shade Highlight Banner */}
            <div className="flex items-center gap-3 p-3 bg-[#faf7f2] border border-[#c5a059]/40">
              <span
                className="w-8 h-8 rounded-full border border-black/20 shadow-inner flex-shrink-0"
                style={{ backgroundColor: selectedShade.hex }}
              />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-bold text-[#061325]">
                  {selectedShade.code} {selectedShade.name}
                </p>
                <p className="text-[11px] text-stone-600">
                  {selectedShade.description || `${selectedShade.finish} finish with ${selectedShade.undertone} undertone`}
                </p>
              </div>
              <Check className="w-4 h-4 text-[#8b6f38]" />
            </div>

            {/* Swatch Grid */}
            <div className="grid grid-cols-4 gap-2 pt-1">
              {availableShades.map((shade) => {
                const isSelected = selectedShade.id === shade.id;
                return (
                  <button
                    key={shade.id}
                    onClick={() => handleShadeSelect(shade)}
                    className={`flex flex-col items-center p-2 border transition-all text-center ${
                      isSelected
                        ? 'border-[#061325] bg-stone-50 shadow-sm ring-1 ring-[#061325]'
                        : 'border-stone-200 hover:border-stone-400 bg-white'
                    }`}
                  >
                    <span
                      className="w-6 h-6 rounded-full border border-black/20 shadow-xs mb-1"
                      style={{ backgroundColor: shade.hex }}
                    />
                    <span className="text-[11px] font-bold text-stone-900 leading-tight">
                      {shade.code}
                    </span>
                    <span className="text-[10px] text-stone-500 truncate w-full">
                      {shade.name}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Finish & Intensity Settings */}
          <div className="space-y-4 pt-3 border-t border-stone-200">
            {activeCategory === 'lipstick' && (
              <div>
                <span className="text-xs font-medium text-stone-700 uppercase tracking-wider block mb-2">
                  Texture & Finish
                </span>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  {(['Satin', 'Matte', 'Gloss'] as const).map((f) => (
                    <button
                      key={f}
                      onClick={() => setFinish(f)}
                      className={`py-1.5 border uppercase tracking-wider text-[11px] transition-colors ${
                        finish === f
                          ? 'border-[#8b6f38] bg-[#faf7f2] text-[#8b6f38] font-bold'
                          : 'border-stone-200 text-stone-600 hover:border-stone-400'
                      }`}
                    >
                      {f}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="text-stone-700 font-medium uppercase tracking-wider text-[11px]">
                  Application Opacity
                </span>
                <span className="font-mono text-stone-800">{Math.round(intensity * 100)}%</span>
              </div>
              <input
                type="range"
                min="0.3"
                max="1.0"
                step="0.05"
                value={intensity}
                onChange={(e) => setIntensity(Number(e.target.value))}
                className="w-full accent-[#8b6f38] cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between text-xs pt-1">
              <span className="text-stone-600">Split Comparison Mode</span>
              <button
                onClick={() => setIsSplitActive(!isSplitActive)}
                className={`px-3 py-1 text-xs border uppercase tracking-wider transition-colors ${
                  isSplitActive
                    ? 'border-[#061325] bg-[#061325] text-white'
                    : 'border-stone-300 text-stone-600'
                }`}
              >
                {isSplitActive ? 'Split On' : 'Split Off'}
              </button>
            </div>
          </div>

          {/* Buy Action Button */}
          <div className="pt-4 border-t border-stone-200">
            <button
              onClick={() => addToCart(currentProduct, selectedShade)}
              className="w-full flex items-center justify-center gap-2 py-3 px-6 bg-[#061325] text-white hover:bg-[#c5a059] hover:text-[#061325] text-xs uppercase tracking-[0.18em] font-semibold transition-all shadow-md group"
            >
              <ShoppingBag className="w-4 h-4 text-[#c5a059] group-hover:scale-110 transition-transform" />
              <span>Add Shade {selectedShade.code} to Bag · £{currentProduct.price.toFixed(2)}</span>
            </button>

            <p className="text-[11px] text-stone-500 text-center mt-2.5">
              Complimentary 2 luxury samples and signature gold gift packaging at checkout.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
