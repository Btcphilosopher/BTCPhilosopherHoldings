'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Product, ProductShade } from '@/types';
import { X, Star, Sparkles, Heart, ShoppingBag, ShieldCheck, Check, Clock, Droplets } from 'lucide-react';

interface ProductModalProps {
  product: Product;
  onClose: () => void;
}

export default function ProductModal({ product, onClose }: ProductModalProps) {
  const { addToCart, launchTryOn, toggleWishlist, isInWishlist } = useApp();
  const [selectedShade, setSelectedShade] = useState<ProductShade | undefined>(
    product.shades ? product.shades[0] : undefined
  );
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'benefits' | 'ingredients' | 'howTo'>('benefits');

  const inWishlist = isInWishlist(product.id);

  const handleAddToCart = () => {
    addToCart(product, selectedShade, product.size, quantity);
    onClose();
  };

  const handleLaunchTryOn = () => {
    launchTryOn(product, selectedShade);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
      <div
        className="relative w-full max-w-4xl max-h-[92vh] overflow-y-auto bg-[#faf9f6] text-[#121820] border border-[#c5a059]/40 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 text-stone-500 hover:text-black bg-white/80 border border-stone-200 transition-colors"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
          {/* Left Column: Imagery & Visual Presentation */}
          <div className="relative bg-[#f5f1ea] p-8 flex flex-col items-center justify-center border-b md:border-b-0 md:border-r border-stone-200 min-h-[360px]">
            {product.badge && (
              <span className="absolute top-4 left-4 bg-[#061325] text-[#c5a059] text-[10px] tracking-[0.2em] uppercase px-2.5 py-1 font-semibold">
                {product.badge}
              </span>
            )}

            <div className="relative w-full max-w-xs aspect-square flex items-center justify-center p-4">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={product.imageUrl}
                alt={product.name}
                className="max-h-72 w-auto object-contain drop-shadow-xl"
              />
            </div>

            {selectedShade && (
              <div className="mt-4 flex items-center gap-2 bg-white/90 border border-stone-200 px-3 py-1.5 text-xs text-stone-700">
                <span
                  className="w-4 h-4 rounded-full border border-black/20 shadow-inner"
                  style={{ backgroundColor: selectedShade.hex }}
                />
                <span className="font-semibold text-stone-900">{selectedShade.code} {selectedShade.name}</span>
                <span className="text-stone-400">·</span>
                <span className="text-stone-500">{selectedShade.finish}</span>
              </div>
            )}

            {product.canTryOn && (
              <button
                onClick={handleLaunchTryOn}
                className="mt-4 inline-flex items-center gap-2 px-4 py-2 border border-[#c5a059] bg-[#061325] text-[#c5a059] text-xs uppercase tracking-wider font-semibold hover:bg-[#c5a059] hover:text-[#061325] transition-all"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Launch Virtual Try-On</span>
              </button>
            )}
          </div>

          {/* Right Column: Product Details, Shade Matrix, and Purchasing Module */}
          <div className="p-6 sm:p-8 flex flex-col justify-between">
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between text-xs text-stone-500 uppercase tracking-widest mb-1">
                  <span>{product.category} {product.concern ? `· ${product.concern}` : ''}</span>
                  <div className="flex items-center gap-1 text-[#c5a059]">
                    <Star className="w-3.5 h-3.5 fill-current" />
                    <span className="font-semibold text-stone-800">{product.rating}</span>
                    <span className="text-stone-400">({product.reviewCount})</span>
                  </div>
                </div>

                <h2 className="font-serif-luxury text-2xl sm:text-3xl text-[#061325] font-normal leading-tight">
                  {product.name}
                </h2>
                <p className="text-xs text-stone-600 mt-1 font-light leading-relaxed">
                  {product.subtitle}
                </p>
              </div>

              {/* Price & Size */}
              <div className="flex items-baseline gap-3 pt-1 border-b border-stone-200 pb-3">
                <span className="text-2xl font-serif-luxury text-[#061325] font-semibold">
                  £{product.price.toFixed(2)}
                </span>
                {product.originalPrice && (
                  <span className="text-sm text-stone-400 line-through">
                    £{product.originalPrice.toFixed(2)}
                  </span>
                )}
                <span className="text-xs text-stone-500 uppercase tracking-wider font-sans-refined">
                  Standard Size: {product.size}
                </span>
              </div>

              {/* Description */}
              <p className="text-xs text-stone-700 leading-relaxed font-sans-refined">
                {product.description}
              </p>

              {/* Shade Selection (if available) */}
              {product.shades && product.shades.length > 0 && (
                <div className="space-y-2 pt-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-stone-700 font-medium tracking-wider uppercase text-[11px]">
                      Selected Shade: <strong className="text-black">{selectedShade?.name}</strong> ({selectedShade?.code})
                    </span>
                    <span className="text-[11px] text-stone-500">
                      Undertone: {selectedShade?.undertone}
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {product.shades.map((shade) => (
                      <button
                        key={shade.id}
                        onClick={() => setSelectedShade(shade)}
                        title={`${shade.code} ${shade.name} (${shade.undertone})`}
                        className={`group relative p-0.5 border-2 transition-all ${
                          selectedShade?.id === shade.id
                            ? 'border-[#061325] scale-110 shadow-md'
                            : 'border-transparent hover:border-stone-400'
                        }`}
                      >
                        <span
                          className="block w-6 h-6 rounded-sm border border-black/20"
                          style={{ backgroundColor: shade.hex }}
                        />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Tabs: Benefits / Ingredients / How to Use */}
              <div className="pt-2">
                <div className="flex border-b border-stone-200 text-xs">
                  <button
                    onClick={() => setActiveTab('benefits')}
                    className={`py-2 px-3 border-b-2 font-medium tracking-wider uppercase transition-colors ${
                      activeTab === 'benefits'
                        ? 'border-[#c5a059] text-[#061325]'
                        : 'border-transparent text-stone-400 hover:text-stone-700'
                    }`}
                  >
                    Proven Benefits
                  </button>
                  <button
                    onClick={() => setActiveTab('ingredients')}
                    className={`py-2 px-3 border-b-2 font-medium tracking-wider uppercase transition-colors ${
                      activeTab === 'ingredients'
                        ? 'border-[#c5a059] text-[#061325]'
                        : 'border-transparent text-stone-400 hover:text-stone-700'
                    }`}
                  >
                    Key Ingredients
                  </button>
                  <button
                    onClick={() => setActiveTab('howTo')}
                    className={`py-2 px-3 border-b-2 font-medium tracking-wider uppercase transition-colors ${
                      activeTab === 'howTo'
                        ? 'border-[#c5a059] text-[#061325]'
                        : 'border-transparent text-stone-400 hover:text-stone-700'
                    }`}
                  >
                    Application Ritual
                  </button>
                </div>

                <div className="py-3 text-xs text-stone-600 min-h-[90px]">
                  {activeTab === 'benefits' && (
                    <ul className="space-y-1.5">
                      {product.benefits.map((benefit, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <Check className="w-3.5 h-3.5 text-[#c5a059] flex-shrink-0 mt-0.5" />
                          <span>{benefit}</span>
                        </li>
                      ))}
                    </ul>
                  )}

                  {activeTab === 'ingredients' && (
                    <ul className="space-y-1.5">
                      {product.keyIngredients.map((ing, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <Droplets className="w-3.5 h-3.5 text-[#c5a059] flex-shrink-0 mt-0.5" />
                          <span>{ing}</span>
                        </li>
                      ))}
                    </ul>
                  )}

                  {activeTab === 'howTo' && (
                    <div className="flex items-start gap-2">
                      <Clock className="w-3.5 h-3.5 text-[#c5a059] flex-shrink-0 mt-0.5" />
                      <p className="leading-relaxed">{product.howToUse}</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Bottom Actions: Quantity + Add to Bag + Wishlist */}
            <div className="pt-4 border-t border-stone-200 space-y-3">
              <div className="flex items-center gap-3">
                {/* Quantity */}
                <div className="flex items-center border border-stone-300 bg-white">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-3 py-2 text-stone-600 hover:bg-stone-100 text-xs font-mono"
                  >
                    -
                  </button>
                  <span className="px-3 py-2 text-xs font-semibold font-mono text-stone-900 min-w-8 text-center">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-3 py-2 text-stone-600 hover:bg-stone-100 text-xs font-mono"
                  >
                    +
                  </button>
                </div>

                {/* Primary Add to Bag CTA */}
                <button
                  onClick={handleAddToCart}
                  className="flex-1 flex items-center justify-center gap-2 py-3 px-6 bg-[#061325] text-white hover:bg-[#0c2445] text-xs uppercase tracking-[0.16em] font-semibold transition-all shadow-md group"
                >
                  <ShoppingBag className="w-4 h-4 text-[#c5a059] group-hover:scale-110 transition-transform" />
                  <span>Add To Bag · £{(product.price * quantity).toFixed(2)}</span>
                </button>

                {/* Wishlist Button */}
                <button
                  onClick={() => toggleWishlist(product.id)}
                  className={`p-3 border transition-colors ${
                    inWishlist
                      ? 'border-red-400 bg-red-50 text-red-600'
                      : 'border-stone-300 bg-white text-stone-600 hover:text-black'
                  }`}
                  aria-label="Wishlist"
                >
                  <Heart className={`w-4 h-4 ${inWishlist ? 'fill-current' : ''}`} />
                </button>
              </div>

              <div className="flex items-center justify-center gap-4 text-[11px] text-stone-500 pt-1">
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#c5a059]" /> 100% Authentic Guaranteed
                </span>
                <span>·</span>
                <span>Includes 2 Free Deluxe Samples</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
