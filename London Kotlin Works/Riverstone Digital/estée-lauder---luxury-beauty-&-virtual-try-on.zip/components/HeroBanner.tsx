'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { ArrowRight, Sparkles, Calendar, ChevronRight } from 'lucide-react';
import { ProductCategory } from '@/types';

export default function HeroBanner() {
  const { setActiveTab, setActiveCategory, setSelectedProductForModal } = useApp();
  const [currentSlide, setCurrentSlide] = useState(1);

  const slides = [
    {
      id: 1,
      title: 'Timeless Beauty. A Brighter Tomorrow.',
      subtitle: 'Advanced skincare. Iconic makeup. A more radiant you.',
      ctaText: 'Discover Night Repair',
      category: 'Skincare' as ProductCategory,
    },
    {
      id: 2,
      title: 'Flawless All Day. 24-Hour Confidence.',
      subtitle: 'Double Wear Stay-in-Place Makeup with 56 true-to-skin shades.',
      ctaText: 'Explore Double Wear',
      category: 'Makeup' as ProductCategory,
    },
    {
      id: 3,
      title: 'Rare Luxury. Black Diamond Truffle.',
      subtitle: 'Re-Nutriv Haute Skincare — the pinnacle of cellular longevity.',
      ctaText: 'Experience Re-Nutriv',
      category: 'Re-Nutriv' as ProductCategory,
    },
  ];

  const handleSlideChange = (slideNum: number) => {
    setCurrentSlide(slideNum);
  };

  const handleCategoryExplore = (cat: ProductCategory) => {
    setActiveCategory(cat);
    setActiveTab('catalog');
    const catalogElem = document.getElementById('luxury-catalog-section');
    if (catalogElem) {
      catalogElem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative bg-[#061325] text-white overflow-hidden">
      {/* Primary Hero Stage with Image */}
      <div className="relative w-full overflow-hidden">
        {/* We display the authentic Estee Lauder campaign image provided by user */}
        <div className="relative w-full aspect-[16/9] max-h-[640px] min-h-[440px] bg-black">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/assets/aistudio/Estee_Lauder_54505d66.png"
            alt="Estée Lauder Timeless Beauty Campaign with Advanced Night Repair"
            className="w-full h-full object-cover object-top opacity-95"
          />

          {/* Luxury Gradient Overlay for crisp typographic contrast & responsive readability */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#061325]/90 via-[#061325]/45 to-transparent flex flex-col justify-between p-6 sm:p-12 lg:p-16">
            {/* Top Badge */}
            <div className="flex items-center gap-3">
              <span className="text-[11px] tracking-[0.3em] uppercase text-[#c5a059] font-sans-refined font-semibold border-b border-[#c5a059]/40 pb-0.5">
                The Estée Lauder Experience
              </span>
            </div>

            {/* Central Headline Content */}
            <div className="max-w-xl space-y-4 my-auto">
              <h1 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl tracking-wide font-normal leading-[1.15] text-white">
                {slides[currentSlide - 1].title}
              </h1>

              <p className="text-stone-300 font-sans-refined text-sm sm:text-base leading-relaxed font-light max-w-md">
                {slides[currentSlide - 1].subtitle}
              </p>

              {/* Action Buttons */}
              <div className="pt-2 flex flex-wrap items-center gap-4">
                <button
                  onClick={() => handleCategoryExplore(slides[currentSlide - 1].category)}
                  className="group inline-flex items-center gap-2.5 px-6 py-3 border border-[#c5a059] bg-[#c5a059] text-[#061325] text-xs uppercase tracking-[0.18em] font-semibold hover:bg-white hover:border-white transition-all shadow-lg"
                >
                  <span>{slides[currentSlide - 1].ctaText}</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </button>

                <button
                  onClick={() => setActiveTab('try-on')}
                  className="inline-flex items-center gap-2 px-5 py-3 border border-stone-400/60 bg-black/40 backdrop-blur-sm text-stone-200 text-xs uppercase tracking-[0.18em] hover:border-[#c5a059] hover:text-[#c5a059] transition-all"
                >
                  <Sparkles className="w-3.5 h-3.5 text-[#c5a059]" />
                  <span>Virtual Try-On</span>
                </button>
              </div>
            </div>

            {/* Slide Pagination & Next */}
            <div className="flex items-center justify-between text-xs text-stone-300 font-mono pt-4 border-t border-stone-500/20">
              <div className="flex items-center gap-3">
                <span className="text-white font-medium">{currentSlide} / 3</span>
                <div className="flex gap-1.5">
                  {[1, 2, 3].map((num) => (
                    <button
                      key={num}
                      onClick={() => handleSlideChange(num)}
                      className={`h-1 transition-all ${
                        currentSlide === num ? 'w-8 bg-[#c5a059]' : 'w-3 bg-stone-500/50 hover:bg-stone-400'
                      }`}
                      aria-label={`Slide ${num}`}
                    />
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-4 text-xs font-sans-refined tracking-wider uppercase text-stone-300">
                <button
                  onClick={() => setActiveTab('consultations')}
                  className="hover:text-[#c5a059] transition-colors flex items-center gap-1"
                >
                  <Calendar className="w-3.5 h-3.5 text-[#c5a059]" />
                  <span>Private Consultation Service</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 4 Iconic Category Jump Tiles directly below Hero (as shown in the authentic layout) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-[#c5a059]/20 border-t border-b border-[#c5a059]/30 bg-[#07172e]">
        {/* Re-Nutriv Card */}
        <div
          onClick={() => handleCategoryExplore('Re-Nutriv')}
          className="group relative p-6 sm:p-8 cursor-pointer hover:bg-[#0a203f] transition-all overflow-hidden"
        >
          <div className="relative z-10 flex flex-col justify-between h-36">
            <div>
              <span className="text-[10px] tracking-[0.25em] text-[#c5a059] uppercase block mb-1">Haute Skincare</span>
              <h3 className="font-serif-luxury text-xl sm:text-2xl text-white group-hover:text-[#c5a059] transition-colors">
                Re-Nutriv
              </h3>
              <p className="text-xs text-stone-400 mt-1 font-light">
                Ultimate Luxury Skincare infused with Black Diamond Truffle.
              </p>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-[#c5a059] uppercase tracking-wider font-medium group-hover:translate-x-1 transition-transform">
              <span>Explore Collection</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="absolute right-0 bottom-0 w-24 h-24 bg-gradient-to-tl from-[#c5a059]/15 to-transparent rounded-full blur-2xl group-hover:scale-150 transition-transform pointer-events-none" />
        </div>

        {/* Makeup Card */}
        <div
          onClick={() => handleCategoryExplore('Makeup')}
          className="group relative p-6 sm:p-8 cursor-pointer hover:bg-[#0a203f] transition-all overflow-hidden"
        >
          <div className="relative z-10 flex flex-col justify-between h-36">
            <div>
              <span className="text-[10px] tracking-[0.25em] text-[#c5a059] uppercase block mb-1">Iconic Artistry</span>
              <h3 className="font-serif-luxury text-xl sm:text-2xl text-white group-hover:text-[#c5a059] transition-colors">
                Makeup
              </h3>
              <p className="text-xs text-stone-400 mt-1 font-light">
                Radiant. Refined. You. Double Wear & Pure Color Envy.
              </p>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-[#c5a059] uppercase tracking-wider font-medium group-hover:translate-x-1 transition-transform">
              <span>Explore & Try-On</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="absolute right-0 bottom-0 w-24 h-24 bg-gradient-to-tl from-[#c5a059]/15 to-transparent rounded-full blur-2xl group-hover:scale-150 transition-transform pointer-events-none" />
        </div>

        {/* Fragrance Card */}
        <div
          onClick={() => handleCategoryExplore('Fragrance')}
          className="group relative p-6 sm:p-8 cursor-pointer hover:bg-[#0a203f] transition-all overflow-hidden"
        >
          <div className="relative z-10 flex flex-col justify-between h-36">
            <div>
              <span className="text-[10px] tracking-[0.25em] text-[#c5a059] uppercase block mb-1">Haute Parfumerie</span>
              <h3 className="font-serif-luxury text-xl sm:text-2xl text-white group-hover:text-[#c5a059] transition-colors">
                Fragrance
              </h3>
              <p className="text-xs text-stone-400 mt-1 font-light">
                A Scent for Every Story. Beautiful Magnolia & AERIN.
              </p>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-[#c5a059] uppercase tracking-wider font-medium group-hover:translate-x-1 transition-transform">
              <span>Discover Fragrances</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="absolute right-0 bottom-0 w-24 h-24 bg-gradient-to-tl from-[#c5a059]/15 to-transparent rounded-full blur-2xl group-hover:scale-150 transition-transform pointer-events-none" />
        </div>

        {/* Gifts Card */}
        <div
          onClick={() => handleCategoryExplore('Gifts')}
          className="group relative p-6 sm:p-8 cursor-pointer hover:bg-[#0a203f] transition-all overflow-hidden"
        >
          <div className="relative z-10 flex flex-col justify-between h-36">
            <div>
              <span className="text-[10px] tracking-[0.25em] text-[#c5a059] uppercase block mb-1">Keepsake Elegance</span>
              <h3 className="font-serif-luxury text-xl sm:text-2xl text-white group-hover:text-[#c5a059] transition-colors">
                Gifts & Vaults
              </h3>
              <p className="text-xs text-stone-400 mt-1 font-light">
                The Perfect Present wrapped in Navy & Gold Ribbon.
              </p>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-[#c5a059] uppercase tracking-wider font-medium group-hover:translate-x-1 transition-transform">
              <span>View Gift Sets</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="absolute right-0 bottom-0 w-24 h-24 bg-gradient-to-tl from-[#c5a059]/15 to-transparent rounded-full blur-2xl group-hover:scale-150 transition-transform pointer-events-none" />
        </div>
      </div>

      {/* Signature Brand Divider */}
      <div className="bg-[#030c17] py-3 text-center border-b border-[#c5a059]/20">
        <p className="text-[11px] tracking-[0.4em] uppercase text-stone-300 font-sans-refined font-light">
          ESTĒE LAUDER <span className="text-[#c5a059] mx-2">—</span> BEAUTY LIVES HERE
        </p>
      </div>
    </section>
  );
}
