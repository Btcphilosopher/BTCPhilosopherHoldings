'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { ESTEE_PRODUCTS } from '@/data/catalog';
import { Search, ShoppingBag, Heart, Sparkles, Calendar, Award, Menu, X, ChevronRight } from 'lucide-react';
import { ProductCategory } from '@/types';

export default function Header() {
  const {
    activeTab,
    setActiveTab,
    setActiveCategory,
    cartCount,
    setIsCartOpen,
    wishlist,
    userPoints,
    userTier,
    setSelectedProductForModal,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const searchResults = searchQuery.trim().length > 1
    ? ESTEE_PRODUCTS.filter(p =>
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.concern?.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  const handleNavClick = (tab: 'catalog' | 'try-on' | 'consultations' | 'loyalty', category?: ProductCategory) => {
    setActiveTab(tab);
    if (category) {
      setActiveCategory(category);
    }
    setIsMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-[#061325] text-white border-b border-[#c5a059]/25 shadow-md">
      {/* Top Banner Announcement Ticker */}
      <div className="bg-[#030b14] border-b border-[#c5a059]/15 px-4 py-2 text-[11px] font-sans-refined tracking-wider">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-stone-300">
          <div className="flex items-center gap-2 text-center sm:text-left">
            <span className="text-[#c5a059] font-medium tracking-widest uppercase">Privilege</span>
            <span className="hidden sm:inline text-stone-600">|</span>
            <span className="text-stone-200">
              FREE WORLDWIDE SHIPPING ON ORDERS OVER £100 · 2 DELUXE SAMPLES WITH EVERY PURCHASE
            </span>
          </div>

          <div className="flex items-center gap-4 text-stone-300">
            <div className="flex items-center gap-1.5 cursor-pointer hover:text-white transition-colors">
              <span className="text-stone-400">UK / GBP (£)</span>
            </div>
            <span className="text-stone-700">|</span>
            <button
              onClick={() => handleNavClick('loyalty')}
              className="flex items-center gap-1 text-[#c5a059] hover:text-[#e4be77] transition-colors"
            >
              <Award className="w-3 h-3 text-[#c5a059]" />
              <span>E-List: <strong className="font-semibold">{userPoints} pts</strong> ({userTier})</span>
            </button>
            <span className="text-stone-700">|</span>
            <button
              onClick={() => handleNavClick('catalog')}
              className="flex items-center gap-1 hover:text-white transition-colors"
              title="Wishlist"
            >
              <Heart className="w-3 h-3 text-[#c5a059]" />
              <span>Wishlist ({wishlist.length})</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Luxury Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-4">
        {/* Mobile menu hamburger */}
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="lg:hidden text-stone-200 hover:text-white p-1"
          aria-label="Toggle menu"
        >
          {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>

        {/* Brand Title: Signature Estee Lauder Serif Wordmark */}
        <div
          onClick={() => handleNavClick('catalog', 'All')}
          className="cursor-pointer text-center sm:text-left flex-1 lg:flex-initial"
        >
          <span className="font-serif-luxury text-2xl sm:text-3xl tracking-[0.22em] font-normal text-white uppercase block leading-none">
            ESTĒE LAUDER
          </span>
          <span className="text-[9px] tracking-[0.45em] text-[#c5a059] uppercase block mt-1 font-sans-refined">
            NEW YORK · PARIS · LONDON
          </span>
        </div>

        {/* Search Bar (Centered on Desktop) */}
        <div className="relative hidden md:block flex-1 max-w-sm mx-6">
          <div className="relative flex items-center">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => setIsSearchOpen(true)}
              placeholder="Search Advanced Night Repair, Double Wear, Lips..."
              className="w-full bg-[#0a1e38] border border-[#c5a059]/30 rounded-none px-3.5 py-2 pl-9 text-xs text-white placeholder-stone-400 focus:outline-none focus:border-[#c5a059] transition-colors"
            />
            <Search className="w-3.5 h-3.5 text-[#c5a059] absolute left-3 pointer-events-none" />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 text-stone-400 hover:text-white text-xs"
              >
                ✕
              </button>
            )}
          </div>

          {/* Search Dropdown Results */}
          {isSearchOpen && searchResults.length > 0 && (
            <div className="absolute left-0 right-0 top-full mt-1 bg-[#0b1f3a] border border-[#c5a059]/40 shadow-2xl z-50 p-2 max-h-80 overflow-y-auto">
              <div className="text-[10px] uppercase tracking-wider text-[#c5a059] px-2 py-1 font-semibold border-b border-[#c5a059]/20">
                Products Matching &quot;{searchQuery}&quot;
              </div>
              {searchResults.map((product) => (
                <div
                  key={product.id}
                  onClick={() => {
                    setSelectedProductForModal(product);
                    setIsSearchOpen(false);
                    setSearchQuery('');
                  }}
                  className="flex items-center gap-3 p-2 hover:bg-[#122b50] cursor-pointer transition-colors border-b border-stone-800/40 last:border-b-0"
                >
                  <div className="w-10 h-10 bg-black/40 border border-[#c5a059]/30 flex-shrink-0 flex items-center justify-center overflow-hidden">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-white font-medium truncate">{product.name}</p>
                    <p className="text-[11px] text-[#c5a059] font-mono">£{product.price.toFixed(2)} · {product.category}</p>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5 text-stone-400" />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right Action Icons: Virtual Try-On, Consultations, Shopping Bag */}
        <div className="flex items-center gap-3 sm:gap-5">
          <button
            onClick={() => handleNavClick('try-on')}
            className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 border text-xs tracking-wider uppercase transition-all ${
              activeTab === 'try-on'
                ? 'border-[#c5a059] bg-[#c5a059] text-[#061325] font-semibold'
                : 'border-[#c5a059]/40 text-stone-200 hover:border-[#c5a059] hover:text-[#c5a059]'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Virtual Try-On</span>
          </button>

          <button
            onClick={() => handleNavClick('consultations')}
            className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 border text-xs tracking-wider uppercase transition-all ${
              activeTab === 'consultations'
                ? 'border-[#c5a059] bg-[#c5a059] text-[#061325] font-semibold'
                : 'border-[#c5a059]/40 text-stone-200 hover:border-[#c5a059] hover:text-[#c5a059]'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Book Consultation</span>
          </button>

          {/* Shopping Bag Button with Badge */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="relative flex items-center gap-2 p-2 text-stone-200 hover:text-white transition-colors group"
            aria-label="Open Shopping Bag"
          >
            <div className="relative">
              <ShoppingBag className="w-5 h-5 text-[#c5a059] group-hover:scale-105 transition-transform" />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-[#c5a059] text-[#061325] text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center shadow-sm">
                  {cartCount}
                </span>
              )}
            </div>
            <span className="hidden xl:inline text-xs tracking-widest uppercase font-medium">
              Bag ({cartCount})
            </span>
          </button>
        </div>
      </div>

      {/* Primary Category Navigation Bar */}
      <div className="hidden lg:block border-t border-[#c5a059]/20 bg-[#07172e]">
        <nav className="max-w-7xl mx-auto px-6 flex items-center justify-center gap-8 py-2.5 text-xs font-sans-refined tracking-[0.16em] uppercase">
          <button
            onClick={() => handleNavClick('catalog', 'All')}
            className={`hover:text-[#c5a059] transition-colors py-1 relative ${
              activeTab === 'catalog' ? 'text-[#c5a059] font-medium' : 'text-stone-300'
            }`}
          >
            All Collections
          </button>
          <button
            onClick={() => handleNavClick('catalog', 'Skincare')}
            className="hover:text-[#c5a059] transition-colors py-1 text-stone-300"
          >
            Skincare
          </button>
          <button
            onClick={() => handleNavClick('catalog', 'Makeup')}
            className="hover:text-[#c5a059] transition-colors py-1 text-stone-300"
          >
            Makeup
          </button>
          <button
            onClick={() => handleNavClick('catalog', 'Fragrance')}
            className="hover:text-[#c5a059] transition-colors py-1 text-stone-300"
          >
            Fragrance
          </button>
          <button
            onClick={() => handleNavClick('catalog', 'Re-Nutriv')}
            className="hover:text-[#c5a059] transition-colors py-1 text-stone-300 flex items-center gap-1"
          >
            <span>Re-Nutriv</span>
            <span className="text-[9px] text-[#c5a059] tracking-normal font-sans-refined">Haute</span>
          </button>
          <button
            onClick={() => handleNavClick('catalog', 'Gifts')}
            className="hover:text-[#c5a059] transition-colors py-1 text-stone-300"
          >
            Gifts & Vaults
          </button>
          <span className="text-stone-700">|</span>
          <button
            onClick={() => handleNavClick('try-on')}
            className={`hover:text-[#c5a059] transition-colors py-1 flex items-center gap-1.5 ${
              activeTab === 'try-on' ? 'text-[#c5a059] font-semibold' : 'text-[#c5a059]'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Virtual Try-On</span>
          </button>
          <button
            onClick={() => handleNavClick('consultations')}
            className={`hover:text-[#c5a059] transition-colors py-1 flex items-center gap-1.5 ${
              activeTab === 'consultations' ? 'text-[#c5a059] font-semibold' : 'text-stone-300'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Beauty Consultations</span>
          </button>
          <button
            onClick={() => handleNavClick('loyalty')}
            className={`hover:text-[#c5a059] transition-colors py-1 flex items-center gap-1.5 ${
              activeTab === 'loyalty' ? 'text-[#c5a059] font-semibold' : 'text-stone-300'
            }`}
          >
            <Award className="w-3.5 h-3.5" />
            <span>The Estée E-List</span>
          </button>
        </nav>
      </div>

      {/* Mobile Drawer Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-[#07172e] border-t border-[#c5a059]/30 px-6 py-6 space-y-4">
          <div className="relative mb-4">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search products..."
              className="w-full bg-[#0a1e38] border border-[#c5a059]/30 px-3 py-2 text-xs text-white focus:outline-none"
            />
            <Search className="w-3.5 h-3.5 text-[#c5a059] absolute right-3 top-3 pointer-events-none" />
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs tracking-wider uppercase font-medium">
            <button
              onClick={() => handleNavClick('catalog', 'All')}
              className="text-left py-2 border-b border-stone-800 text-stone-200"
            >
              All Products
            </button>
            <button
              onClick={() => handleNavClick('catalog', 'Skincare')}
              className="text-left py-2 border-b border-stone-800 text-stone-200"
            >
              Skincare
            </button>
            <button
              onClick={() => handleNavClick('catalog', 'Makeup')}
              className="text-left py-2 border-b border-stone-800 text-stone-200"
            >
              Makeup
            </button>
            <button
              onClick={() => handleNavClick('catalog', 'Fragrance')}
              className="text-left py-2 border-b border-stone-800 text-stone-200"
            >
              Fragrance
            </button>
            <button
              onClick={() => handleNavClick('catalog', 'Re-Nutriv')}
              className="text-left py-2 border-b border-stone-800 text-[#c5a059]"
            >
              Re-Nutriv Haute
            </button>
            <button
              onClick={() => handleNavClick('catalog', 'Gifts')}
              className="text-left py-2 border-b border-stone-800 text-stone-200"
            >
              Gifts & Sets
            </button>
          </div>

          <div className="pt-2 space-y-2 border-t border-stone-800">
            <button
              onClick={() => handleNavClick('try-on')}
              className="w-full flex items-center justify-between p-2.5 bg-[#0b2140] text-[#c5a059] text-xs uppercase tracking-wider font-medium"
            >
              <span className="flex items-center gap-2">
                <Sparkles className="w-4 h-4" /> Virtual Try-On Studio
              </span>
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => handleNavClick('consultations')}
              className="w-full flex items-center justify-between p-2.5 bg-[#0b2140] text-stone-200 text-xs uppercase tracking-wider font-medium"
            >
              <span className="flex items-center gap-2">
                <Calendar className="w-4 h-4" /> Book Beauty Consultation
              </span>
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => handleNavClick('loyalty')}
              className="w-full flex items-center justify-between p-2.5 bg-[#0b2140] text-stone-200 text-xs uppercase tracking-wider font-medium"
            >
              <span className="flex items-center gap-2">
                <Award className="w-4 h-4 text-[#c5a059]" /> The Estée E-List Rewards ({userPoints} pts)
              </span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
