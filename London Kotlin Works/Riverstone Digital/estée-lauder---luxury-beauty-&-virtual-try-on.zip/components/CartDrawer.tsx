'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { COMPLIMENTARY_SAMPLES } from '@/data/catalog';
import { X, Trash2, ShoppingBag, ArrowRight, Sparkles, Check, Gift, ShieldCheck, Tag } from 'lucide-react';

export default function CartDrawer() {
  const {
    isCartOpen,
    setIsCartOpen,
    cart,
    removeFromCart,
    updateQuantity,
    cartSubtotal,
    freeShippingThreshold,
    selectedSamples,
    toggleSample,
    appliedVoucherDiscount,
    setIsCheckoutOpen,
    showToast,
  } = useApp();

  const [promoCodeInput, setPromoCodeInput] = useState('');
  const [promoApplied, setPromoApplied] = useState(false);

  if (!isCartOpen) return null;

  const freeShippingProgress = Math.min(100, (cartSubtotal / freeShippingThreshold) * 100);
  const remainingForFreeShipping = Math.max(0, freeShippingThreshold - cartSubtotal);

  const finalTotal = Math.max(0, cartSubtotal - appliedVoucherDiscount - (promoApplied ? 15 : 0));

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (promoCodeInput.trim().toUpperCase() === 'ESTEE15') {
      setPromoApplied(true);
      showToast('Promo code "ESTEE15" applied! 15% VIP welcome privilege.');
    } else {
      showToast('Invalid promo code. Try "ESTEE15" for 15% off.');
    }
  };

  const handleProceedToCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={() => setIsCartOpen(false)}
        className="absolute inset-0 bg-black/60 backdrop-blur-xs transition-opacity duration-300"
      />

      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#faf9f6] text-[#121820] shadow-2xl flex flex-col justify-between border-l border-[#c5a059]/40">
          {/* Header */}
          <div className="p-5 border-b border-stone-200 bg-[#061325] text-white flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#c5a059]" />
              <span className="font-serif-luxury text-xl tracking-wide uppercase">
                Shopping Bag ({cart.reduce((a, b) => a + b.quantity, 0)})
              </span>
            </div>
            <button
              onClick={() => setIsCartOpen(false)}
              className="text-stone-400 hover:text-white transition-colors p-1"
              aria-label="Close cart"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Shipping Progress Indicator */}
          <div className="bg-[#f2ede4] px-5 py-3 border-b border-stone-200 text-xs">
            <div className="flex items-center justify-between mb-1.5 font-sans-refined">
              <span className="text-stone-700">
                {remainingForFreeShipping > 0 ? (
                  <span>
                    Add <strong className="text-[#061325]">£{remainingForFreeShipping.toFixed(2)}</strong> for Free Worldwide Delivery
                  </span>
                ) : (
                  <span className="text-emerald-800 font-semibold flex items-center gap-1">
                    <Check className="w-3.5 h-3.5 text-emerald-600" /> Complimentary Worldwide Delivery Unlocked
                  </span>
                )}
              </span>
              <span className="text-stone-500 font-mono text-[11px]">
                {Math.round(freeShippingProgress)}%
              </span>
            </div>
            <div className="w-full h-1.5 bg-stone-300 rounded-full overflow-hidden">
              <div
                className="h-full bg-[#c5a059] transition-all duration-500"
                style={{ width: `${freeShippingProgress}%` }}
              />
            </div>
          </div>

          {/* Cart Item List Scrollable */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {cart.length === 0 ? (
              <div className="py-16 text-center text-stone-500 space-y-3">
                <ShoppingBag className="w-12 h-12 mx-auto text-stone-300" />
                <p className="font-serif-luxury text-lg text-stone-700">Your bag is currently empty.</p>
                <p className="text-xs text-stone-500">Discover our bestsellers to start your ritual.</p>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="mt-3 px-5 py-2 bg-[#061325] text-white text-xs uppercase tracking-wider font-medium hover:bg-[#c5a059] hover:text-[#061325] transition-colors"
                >
                  Explore Catalog
                </button>
              </div>
            ) : (
              cart.map((item) => (
                <div
                  key={item.id}
                  className="bg-white border border-stone-200 p-3.5 flex gap-3 shadow-2xs relative group"
                >
                  {/* Thumbnail */}
                  <div className="w-18 h-18 bg-[#f5f1ea] border border-stone-200 flex-shrink-0 flex items-center justify-center p-2">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={item.product.imageUrl}
                      alt={item.product.name}
                      className="max-h-full max-w-full object-contain"
                    />
                  </div>

                  {/* Details */}
                  <div className="flex-1 min-w-0 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between gap-1">
                        <h4 className="font-serif-luxury text-sm font-semibold text-[#061325] leading-snug line-clamp-1">
                          {item.product.name}
                        </h4>
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="text-stone-400 hover:text-red-600 transition-colors p-1"
                          aria-label="Remove item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {item.selectedShade && (
                        <div className="flex items-center gap-1.5 mt-1 text-[11px] text-stone-600">
                          <span
                            className="w-3 h-3 rounded-full border border-black/20"
                            style={{ backgroundColor: item.selectedShade.hex }}
                          />
                          <span>{item.selectedShade.code} {item.selectedShade.name}</span>
                        </div>
                      )}

                      <span className="text-[10px] text-stone-400 uppercase tracking-wider block mt-0.5">
                        Size: {item.selectedSize}
                      </span>
                    </div>

                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-stone-100">
                      {/* Quantity stepper */}
                      <div className="flex items-center border border-stone-300 bg-stone-50">
                        <button
                          onClick={() => updateQuantity(item.id, -1)}
                          className="px-2 py-0.5 text-stone-600 hover:bg-stone-200 text-xs font-mono"
                        >
                          -
                        </button>
                        <span className="px-2 py-0.5 text-xs font-mono font-semibold text-stone-900">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.id, 1)}
                          className="px-2 py-0.5 text-stone-600 hover:bg-stone-200 text-xs font-mono"
                        >
                          +
                        </button>
                      </div>

                      <span className="font-serif-luxury font-semibold text-sm text-[#061325]">
                        £{(item.product.price * item.quantity).toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}

            {/* Complimentary Luxury Samples Selector */}
            {cart.length > 0 && (
              <div className="mt-6 pt-4 border-t border-stone-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-serif-luxury font-bold text-[#061325] uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-[#8b6f38]" />
                    Select 2 Free Deluxe Samples ({selectedSamples.length}/2)
                  </span>
                </div>
                <p className="text-[11px] text-stone-500 mb-3">
                  Signature Estée Lauder luxury miniatures complimentary with every order.
                </p>

                <div className="grid grid-cols-2 gap-2">
                  {COMPLIMENTARY_SAMPLES.map((sample) => {
                    const isSelected = selectedSamples.some((s) => s.id === sample.id);

                    return (
                      <div
                        key={sample.id}
                        onClick={() => toggleSample(sample)}
                        className={`p-2 border cursor-pointer transition-all flex flex-col justify-between ${
                          isSelected
                            ? 'border-[#061325] bg-[#fbf9f5] ring-1 ring-[#061325]'
                            : 'border-stone-200 bg-white hover:border-stone-400'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between text-[10px] text-[#8b6f38] mb-1">
                            <span>{sample.size}</span>
                            {isSelected && <Check className="w-3 h-3 text-[#061325]" />}
                          </div>
                          <p className="text-xs font-medium text-stone-900 line-clamp-1">{sample.name}</p>
                        </div>
                        <span className="text-[10px] uppercase font-bold text-[#8b6f38] mt-2 block">
                          {isSelected ? 'Selected' : '+ Add Free'}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Promotional Code / Voucher Entry */}
            {cart.length > 0 && (
              <div className="mt-4 pt-3 border-t border-stone-200">
                <form onSubmit={handleApplyPromo} className="flex gap-2">
                  <div className="relative flex-1">
                    <input
                      type="text"
                      value={promoCodeInput}
                      onChange={(e) => setPromoCodeInput(e.target.value)}
                      placeholder="Promo Code (e.g. ESTEE15)"
                      className="w-full bg-white border border-stone-300 px-3 py-1.5 text-xs text-stone-900 uppercase placeholder:normal-case focus:outline-none focus:border-[#061325]"
                    />
                    <Tag className="w-3 h-3 text-stone-400 absolute right-2.5 top-2.5 pointer-events-none" />
                  </div>
                  <button
                    type="submit"
                    className="px-3 py-1.5 bg-stone-200 hover:bg-[#061325] hover:text-white text-xs uppercase font-medium tracking-wider transition-colors"
                  >
                    Apply
                  </button>
                </form>

                {promoApplied && (
                  <p className="text-[11px] text-emerald-700 mt-1 flex items-center gap-1 font-medium">
                    <Check className="w-3 h-3" /> 15% VIP Welcome Privilege Applied (-£15.00)
                  </p>
                )}

                {appliedVoucherDiscount > 0 && (
                  <p className="text-[11px] text-[#8b6f38] mt-1 flex items-center gap-1 font-medium">
                    <Sparkles className="w-3 h-3" /> E-List Loyalty Voucher Applied (-£{appliedVoucherDiscount.toFixed(2)})
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Footer Subtotal & Checkout Trigger */}
          {cart.length > 0 && (
            <div className="p-5 border-t border-stone-200 bg-white space-y-3">
              <div className="space-y-1.5 text-xs text-stone-600">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-mono text-stone-900">£{cartSubtotal.toFixed(2)}</span>
                </div>

                <div className="flex justify-between">
                  <span>Estimated Shipping</span>
                  <span className="font-mono text-stone-900">
                    {remainingForFreeShipping === 0 ? 'FREE' : '£4.50'}
                  </span>
                </div>

                {(promoApplied || appliedVoucherDiscount > 0) && (
                  <div className="flex justify-between text-emerald-700 font-medium">
                    <span>Discounts & E-List Vouchers</span>
                    <span className="font-mono">-£{(appliedVoucherDiscount + (promoApplied ? 15 : 0)).toFixed(2)}</span>
                  </div>
                )}

                <div className="flex justify-between text-base font-serif-luxury font-bold text-[#061325] pt-2 border-t border-stone-200">
                  <span>Estimated Total</span>
                  <span className="font-mono">£{finalTotal.toFixed(2)}</span>
                </div>
              </div>

              <button
                onClick={handleProceedToCheckout}
                className="w-full flex items-center justify-center gap-2 py-3.5 bg-[#061325] text-white hover:bg-[#c5a059] hover:text-[#061325] text-xs uppercase tracking-[0.2em] font-semibold transition-all shadow-md group"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <div className="flex items-center justify-center gap-4 text-[11px] text-stone-500 pt-1">
                <span className="flex items-center gap-1">
                  <Gift className="w-3.5 h-3.5 text-[#8b6f38]" /> Complimentary Navy Gift Wrap
                </span>
                <span>·</span>
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#8b6f38]" /> Secure SSL
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
