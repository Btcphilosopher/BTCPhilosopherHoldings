export interface Brand {
  id: number;
  name: string;
  slug: string;
  tagline: string;
  category_id: number;
  category_name: string;
  tier: 'Global Priority' | 'Regional Priority' | 'Local Priority';
  origin_country: string;
  origin_region: string;
  founded_year: number;
  abv: number; // percentage
  flavor_profile: string;
  tasting_notes: {
    nose: string;
    palate: string;
    finish: string;
  };
  heritage: string;
  color_hex: string;
  accent_color: string;
  bottle_badge: string;
  serving_suggestion: string;
  signature_cocktail_id: number;
  signature_cocktail_name: string;
  awards: string[];
}

export interface Category {
  id: number;
  name: string;
  slug: string;
  description: string;
  count: number;
}

export interface Cocktail {
  id: number;
  name: string;
  slug: string;
  brand_id: number;
  brand_name: string;
  tagline: string;
  glassware: string;
  difficulty: 'Easy' | 'Intermediate' | 'Master';
  occasion: string;
  ingredients: {
    name: string;
    amount: string;
    unit: string;
  }[];
  steps: string[];
  garnish: string;
  history: string;
}

export interface SustainabilityPillar {
  id: number;
  title: string;
  focus: string;
  metric: string;
  description: string;
  sdg_alignment: string;
}

export interface InvestorMetric {
  label: string;
  value: string;
  change: string;
  period: string;
  description: string;
}

export const CATEGORIES: Category[] = [
  { id: 1, name: 'Aperitifs & Bitters', slug: 'aperitifs-bitters', description: 'The beating heart of Italian aperitivo culture, balancing botanicals and bitter oranges.', count: 3 },
  { id: 2, name: 'Bourbon & Whiskey', slug: 'bourbon-whiskey', description: 'Legendary Kentucky straight bourbons and refined single malt Scotch.', count: 2 },
  { id: 3, name: 'Tequila & Agave', slug: 'tequila-agave', description: 'Handcrafted in Los Altos de Jalisco and Oaxaca with 100% blue Weber & espadín agave.', count: 2 },
  { id: 4, name: 'Vodka & Gin', slug: 'vodka-gin', description: 'Ultra-pure quadruple distilled vodka and exotic botanical-infused London dry gin.', count: 2 },
  { id: 5, name: 'Liqueurs & Digestifs', slug: 'liqueurs-digestifs', description: 'Centuries of herbal alchemy, historic monastic recipes, and French cognacs.', count: 3 },
  { id: 6, name: 'Rum & Cognac', slug: 'rum-cognac', description: 'Historic aged Jamaican pot-still rums and prestigious French cognac estates.', count: 2 },
  { id: 7, name: 'Wines & Sparkling', slug: 'wines-sparkling', description: 'Marlborough Marlborough terroir and historic Piedmontese vermouth & sparkling.', count: 2 },
];

export const BRANDS: Brand[] = [
  {
    id: 1,
    name: 'Campari',
    slug: 'campari',
    tagline: 'The Red Passion. The Inimitable Heart of Milan.',
    category_id: 1,
    category_name: 'Aperitifs & Bitters',
    tier: 'Global Priority',
    origin_country: 'Italy',
    origin_region: 'Milan, Lombardy',
    founded_year: 1860,
    abv: 25.0,
    flavor_profile: 'Bitter orange, gentian, rhubarb, wild herbs, and rich botanical complexity.',
    tasting_notes: {
      nose: 'Intensely aromatic with complex herbal notes, bittersweet orange peels, and crushed cloves.',
      palate: 'Bold and distinctively bitter, evolving into warm orange blossoms, gentian root, and subtle wood.',
      finish: 'Long, pleasantly dry, and refreshingly bitter with lingering citrus zest.',
    },
    heritage: 'Created in 1860 by Gaspare Campari in Novara, Italy. The top secret recipe of infused herbs, aromatic plants, and fruit in alcohol and water remains unchanged to this day. Campari inspired the birth of the Negroni in Florence in 1919 and has been immortalized by avant-garde Futurism artists including Fortunato Depero.',
    color_hex: '#DA251C',
    accent_color: 'rgba(218, 37, 28, 0.2)',
    bottle_badge: 'MILANO 1860',
    serving_suggestion: 'Over ice with tonic or in the classic equal-parts Negroni.',
    signature_cocktail_id: 1,
    signature_cocktail_name: 'The Negroni',
    awards: ['San Francisco World Spirits Gold', 'World’s Best-Selling Liqueur (Drinks Int.)', 'Iconic Design Award'],
  },
  {
    id: 2,
    name: 'Aperol',
    slug: 'aperol',
    tagline: 'Join the Joy. The Bright Orange Heart of the Aperitivo.',
    category_id: 1,
    category_name: 'Aperitifs & Bitters',
    tier: 'Global Priority',
    origin_country: 'Italy',
    origin_region: 'Padua, Veneto',
    founded_year: 1919,
    abv: 11.0,
    flavor_profile: 'Sweet zesty orange, herbal infusion, gentian root, and delicate cinchona.',
    tasting_notes: {
      nose: 'Bright, zesty orange aromas with subtle herbal scent and a touch of vanilla.',
      palate: 'Unique bittersweet balance; sweet citrus followed by herbaceous bitterness and round sweetness.',
      finish: 'Light, effervescent, and delightfully refreshing with a soft bitter-sweet tail.',
    },
    heritage: 'Created by the Barbieri brothers and launched at the Padua International Fair in 1919. With its luminous orange hue and low alcohol content (11% ABV), Aperol pioneered the modern sociable aperitivo ritual, crowned by the Aperol Spritz 3-2-1 ritual.',
    color_hex: '#FF5F00',
    accent_color: 'rgba(255, 95, 0, 0.2)',
    bottle_badge: 'PADOVA 1919',
    serving_suggestion: 'Aperol Spritz: 3 parts Prosecco, 2 parts Aperol, 1 dash of soda, ice, and an orange slice.',
    signature_cocktail_id: 2,
    signature_cocktail_name: 'Aperol Spritz',
    awards: ['Global Consumer Choice Award', 'Best Selling Aperitif (Drinks International 2024)'],
  },
  {
    id: 3,
    name: 'Wild Turkey',
    slug: 'wild-turkey',
    tagline: 'Real Kentucky Straight Bourbon. Undiluted Craftsmanship.',
    category_id: 2,
    category_name: 'Bourbon & Whiskey',
    tier: 'Global Priority',
    origin_country: 'United States',
    origin_region: 'Lawrenceburg, Kentucky',
    founded_year: 1869,
    abv: 50.5,
    flavor_profile: 'Deep charred American oak, spicy rye, Madagascar vanilla, and burnt caramel.',
    tasting_notes: {
      nose: 'Warm vanilla, seasoned oak, baking spice, cracked black pepper, and honey.',
      palate: 'Rich, bold, and full-bodied with notes of toffee, cinnamon, dried apricot, and dark tobacco.',
      finish: 'Long, warming, and distinctly spicy with sweet charred wood echoes.',
    },
    heritage: 'Distilled on the limestone hills of Lawrenceburg, Kentucky since 1869. Master Distiller Jimmy Russell has crafted bourbon for over 60 years, partnering with his son Eddie Russell to make Wild Turkey 101 legendary. Made with a heavy rye mash bill and aged in No. 4 “alligator” charred oak barrels.',
    color_hex: '#B87333',
    accent_color: 'rgba(184, 115, 51, 0.2)',
    bottle_badge: '101 PROOF BOURBON',
    serving_suggestion: 'Neat, with a large hand-cut ice sphere, or in an authentic Boulevardier.',
    signature_cocktail_id: 3,
    signature_cocktail_name: 'The Boulevardier',
    awards: ['Whisky Advocate 94 Points', 'Ultimate Spirits Challenge Chairman’s Trophy'],
  },
  {
    id: 4,
    name: 'SKYY Vodka',
    slug: 'skyy-vodka',
    tagline: 'Born in San Francisco. Quintessential Smoothness.',
    category_id: 4,
    category_name: 'Vodka & Gin',
    tier: 'Global Priority',
    origin_country: 'United States',
    origin_region: 'San Francisco, California',
    founded_year: 1992,
    abv: 40.0,
    flavor_profile: 'Exceptionally clean, crisp, with subtle salinity and Pacific mineral freshness.',
    tasting_notes: {
      nose: 'Neutral and pristine with faint hints of sweet grains and fresh sea mist.',
      palate: 'Silky smooth on the tongue, round and light with delicate mineral crispness.',
      finish: 'Ultra-clean finish without harsh alcohol burn.',
    },
    heritage: 'Invented in 1992 in San Francisco by an engineer who sought the cleanest possible martini experience. Quadruple-distilled and triple-filtered, enriched with Pacific minerals to deliver an elevated, velvet cocktail foundation in its iconic cobalt blue bottle.',
    color_hex: '#0047AB',
    accent_color: 'rgba(0, 71, 171, 0.2)',
    bottle_badge: 'SAN FRANCISCO 1992',
    serving_suggestion: 'Shaken ice-cold in a clean dry martini with a lemon twist or mixed with fresh citrus.',
    signature_cocktail_id: 4,
    signature_cocktail_name: 'SKYY Pacific Martini',
    awards: ['San Francisco World Spirits Double Gold', 'Beverage Tasting Institute 93 Points'],
  },
  {
    id: 5,
    name: 'Grand Marnier',
    slug: 'grand-marnier',
    tagline: 'L’Excellence Française. Cognac Infused with Bitter Orange.',
    category_id: 5,
    category_name: 'Liqueurs & Digestifs',
    tier: 'Global Priority',
    origin_country: 'France',
    origin_region: 'Paris / Bourg-Charente',
    founded_year: 1880,
    abv: 40.0,
    flavor_profile: 'Fine French cognac, bitter Citrus Bigaradia orange peel, hazelnut, and toasted wood.',
    tasting_notes: {
      nose: 'Complex scents of candied orange zest and floral orange blossom wrapped in aged oak cognac.',
      palate: 'Full and opulent; rich bitter orange marmalade softened by velvety cognac notes of hazelnut and toffee.',
      finish: 'Long, warm, harmonic finish with lingering aromatic orange essence.',
    },
    heritage: 'Created in 1880 by Louis-Alexandre Marnier Lapostolle, who disrupted French tradition by marrying fine aged cognac with rare bitter tropical green oranges from the Caribbean. César Ritz famously praised it: “A great name for a great liqueur—Grand Marnier!”',
    color_hex: '#C62828',
    accent_color: 'rgba(198, 40, 40, 0.2)',
    bottle_badge: 'PARIS 1880',
    serving_suggestion: 'Elevate the Grand Margarita or enjoy neat in a snifter after dinner.',
    signature_cocktail_id: 5,
    signature_cocktail_name: 'The Grand Margarita',
    awards: ['San Francisco World Spirits Double Gold', 'Paris Concours International Gold'],
  },
  {
    id: 6,
    name: 'Espolòn Tequila',
    slug: 'espolon-tequila',
    tagline: '100% Blue Weber Agave. The Soul & Grit of Mexico.',
    category_id: 3,
    category_name: 'Tequila & Agave',
    tier: 'Global Priority',
    origin_country: 'Mexico',
    origin_region: 'Los Altos de Jalisco',
    founded_year: 1998,
    abv: 40.0,
    flavor_profile: 'Sweet roasted agave, tropical pepper, grilled pineapple, and subtle vanilla oak.',
    tasting_notes: {
      nose: 'Delicate floral agave, cracked white peppercorn, and bright Meyer lemon zest.',
      palate: 'Medium-to-full body with rich roasted agave, sweet tropical fruit, and mild baking spices.',
      finish: 'Clean, spicy, and satisfying with lingering roasted agave sweetness.',
    },
    heritage: 'Crafted at Destiladora San Nicolas in the high altitudes of Los Altos de Jalisco. Maestro Tequilero Cirilo Oropeza pioneered playing classical music to the yeast during fermentation. Its labels feature artwork inspired by 19th-century master illustrator José Guadalupe Posada, featuring the iconic rooster Ramón.',
    color_hex: '#E53935',
    accent_color: 'rgba(229, 57, 53, 0.2)',
    bottle_badge: 'LOS ALTOS 100% AGAVE',
    serving_suggestion: 'Espolòn Paloma with fresh pink grapefruit juice, lime, and a pink salt rim.',
    signature_cocktail_id: 6,
    signature_cocktail_name: 'The Espolòn Paloma',
    awards: ['Ultimate Spirits Challenge 95 Points', 'San Francisco World Spirits Gold Medal'],
  },
  {
    id: 7,
    name: 'Cinzano 1757',
    slug: 'cinzano-1757',
    tagline: 'Master Vermouth di Torino. The Genesis of Italian Bitters.',
    category_id: 1,
    category_name: 'Aperitifs & Bitters',
    tier: 'Regional Priority',
    origin_country: 'Italy',
    origin_region: 'Turin, Piedmont',
    founded_year: 1757,
    abv: 16.0,
    flavor_profile: 'Macerated Piedmont botanicals, wormwood, sweet vanilla, and rich fortified wine.',
    tasting_notes: {
      nose: 'Spiced dried figs, vanilla pod, fragrant oregano, and bitter gentian.',
      palate: 'Silky and layered; dark fruits, caramelized orange, and bitter wormwood.',
      finish: 'Velvety with a harmonic bitter-sweet balance.',
    },
    heritage: 'Brothers Giovanni Giacomo and Carlo Stefano Cinzano opened their herbal workshop in Turin in 1757. Cinzano was appointed royal vermouth supplier to the House of Savoy and played a decisive role in shaping the Italian aperitivo century.',
    color_hex: '#8D021F',
    accent_color: 'rgba(141, 2, 31, 0.2)',
    bottle_badge: 'TORINO 1757',
    serving_suggestion: 'In an authentic 1919 Negroni or over ice with a strip of orange peel.',
    signature_cocktail_id: 7,
    signature_cocktail_name: 'The Americano Classico',
    awards: ['Vermouth Trophy Winner', 'IWSC 96 Points'],
  },
  {
    id: 8,
    name: 'Brancott Estate',
    slug: 'brancott-estate',
    tagline: 'Pioneers of Marlborough Sauvignon Blanc.',
    category_id: 7,
    category_name: 'Wines & Sparkling',
    tier: 'Regional Priority',
    origin_country: 'New Zealand',
    origin_region: 'Marlborough',
    founded_year: 1973,
    abv: 13.0,
    flavor_profile: 'Crisp green gooseberry, ripe passionfruit, fresh citrus, and vibrant herbal minerality.',
    tasting_notes: {
      nose: 'Explosive aromas of crushed lemongrass, pink grapefruit, and passionfruit vine.',
      palate: 'Lively acidity with concentrated flavors of melon, citrus zest, and stony flint.',
      finish: 'Clean, crisp, and persistent with refreshing mouthwatering minerality.',
    },
    heritage: 'In 1973, against all conventional wisdom, Brancott Estate planted the very first Sauvignon Blanc vines in Marlborough, New Zealand. The decision forever transformed world wine culture and created the benchmark style for Southern Hemisphere whites.',
    color_hex: '#2E7D32',
    accent_color: 'rgba(46, 125, 50, 0.2)',
    bottle_badge: 'MARLBOROUGH 1973',
    serving_suggestion: 'Chilled at 8°C alongside fresh oysters, goat cheese, or Mediterranean sea bass.',
    signature_cocktail_id: 8,
    signature_cocktail_name: 'Marlborough Spritz',
    awards: ['Air New Zealand Wine Awards Pure Gold', 'Decanter World Wine Platinum'],
  },
  {
    id: 9,
    name: 'Appleton Estate',
    slug: 'appleton-estate',
    tagline: 'Nassau Valley Jamaica. The Pinnacle of Aged Jamaican Rum.',
    category_id: 6,
    category_name: 'Rum & Cognac',
    tier: 'Regional Priority',
    origin_country: 'Jamaica',
    origin_region: 'Nassau Valley, St. Elizabeth',
    founded_year: 1749,
    abv: 43.0,
    flavor_profile: 'Aged tropical oak, Jamaican pot-still funk, dried apricot, nutmeg, and dark cocoa.',
    tasting_notes: {
      nose: 'Orange peel, golden raisins, toasted hazelnut, and rich vanilla bean.',
      palate: 'Full-bodied with notes of molasses, dark honey, allspice, and luscious roasted banana.',
      finish: 'Dry, spicy, and exceptionally smooth with lingering cocoa and oak tannins.',
    },
    heritage: 'Nestled in the lush limestone Nassau Valley in Jamaica since 1749. Master Blender Joy Spence made history here as the spirits industry’s first female Master Blender, hand-selecting rums matured under the tropical Caribbean sun in charred oak barrels.',
    color_hex: '#D97706',
    accent_color: 'rgba(217, 119, 6, 0.2)',
    bottle_badge: 'JAMAICA 1749',
    serving_suggestion: 'Sip neat, with a splash of spring water, or in a Jamaican Mai Tai.',
    signature_cocktail_id: 9,
    signature_cocktail_name: 'The Kingston Negroni',
    awards: ['San Francisco World Spirits Double Gold', 'World’s Best Rum Trophy'],
  },
  {
    id: 10,
    name: 'Courvoisier Cognac',
    slug: 'courvoisier-cognac',
    tagline: 'Maison Fondée en 1828. Le Cognac de Napoléon.',
    category_id: 6,
    category_name: 'Rum & Cognac',
    tier: 'Global Priority',
    origin_country: 'France',
    origin_region: 'Jarnac, Charente',
    founded_year: 1828,
    abv: 40.0,
    flavor_profile: 'Candied orange, crème brûlée, spring blossoms, iris, and French Limousin oak.',
    tasting_notes: {
      nose: 'Vibrant spring blossom, jasmine, ripe peach, and toasted brioche.',
      palate: 'Exquisitely balanced and velvety with layers of almond paste, vanilla, and gentle wood spice.',
      finish: 'Sublime, lingering with floral honey and toasted spice.',
    },
    heritage: 'Founded in 1828 in Paris by Félix Courvoisier and Louis Gallois, later establishing its grand chateau in Jarnac. Courvoisier was chosen by Emperor Napoleon III and toasted at the inauguration of the Eiffel Tower in 1889. Recently acquired by Campari Group to anchor its luxury portfolio.',
    color_hex: '#854D0E',
    accent_color: 'rgba(133, 77, 14, 0.2)',
    bottle_badge: 'JARNAC 1828',
    serving_suggestion: 'Sip in a tulip glass at room temperature or in a classic Sidecar.',
    signature_cocktail_id: 10,
    signature_cocktail_name: 'The French Sidecar',
    awards: ['Prestige de la France Award', 'San Francisco Spirits Double Gold'],
  },
  {
    id: 11,
    name: 'The GlenGrant',
    slug: 'the-glengrant',
    tagline: 'Speyside Single Malt Scotch Whisky. Pure Elegance.',
    category_id: 2,
    category_name: 'Bourbon & Whiskey',
    tier: 'Regional Priority',
    origin_country: 'Scotland',
    origin_region: 'Rothes, Speyside',
    founded_year: 1840,
    abv: 43.0,
    flavor_profile: 'Crisp orchard apples, blossom honey, vanilla malt, and fresh hazelnut.',
    tasting_notes: {
      nose: 'Bright green pear, lemon blossoms, heather honey, and gentle toasted malt.',
      palate: 'Delicate and refined; notes of sweet orchard fruits, butterscotch, and soft almond.',
      finish: 'Crisp and lingering with soft spice and sweet oak.',
    },
    heritage: 'Founded in 1840 in Rothes, Speyside by brothers John and James Grant. Later, “Major” James Grant designed the legendary tall, slender pot stills with innovative water-cooling purifiers, capturing only the lightest, most floral whisky vapors.',
    color_hex: '#CA8A04',
    accent_color: 'rgba(202, 138, 4, 0.2)',
    bottle_badge: 'SPEYSIDE 1840',
    serving_suggestion: 'Neat in a Glencairn glass with three drops of still Scottish spring water.',
    signature_cocktail_id: 11,
    signature_cocktail_name: 'Speyside Highball',
    awards: ['Jim Murray’s Whisky Bible Single Malt of the Year', 'IWSC Gold Outstanding'],
  },
  {
    id: 12,
    name: 'Averna',
    slug: 'averna',
    tagline: 'Amaro Siciliano. The Soul of Caltanissetta Since 1868.',
    category_id: 5,
    category_name: 'Liqueurs & Digestifs',
    tier: 'Local Priority',
    origin_country: 'Italy',
    origin_region: 'Caltanissetta, Sicily',
    founded_year: 1868,
    abv: 29.0,
    flavor_profile: 'Mediterranean herbs, bitter orange rind, pomegranate, myrtle, and licorice.',
    tasting_notes: {
      nose: 'Rich herbal depth, dark caramel, thyme, and sun-drenched Sicilian citrus peel.',
      palate: 'Full-bodied and velvety bittersweet, unfolding notes of dried fruit, cocoa, and sage.',
      finish: 'Warm, herbal, and clean finish with a touch of minty balsamic freshness.',
    },
    heritage: 'Given to Salvatore Averna in 1868 by the monks of the Abbey of Santo Spirito in Caltanissetta as a gesture of gratitude. Made through slow infusion of essential oils, bitter citrus, and Mediterranean botanicals.',
    color_hex: '#78350F',
    accent_color: 'rgba(120, 53, 15, 0.2)',
    bottle_badge: 'SICILIA 1868',
    serving_suggestion: 'Neat over ice with a twist of orange peel and a fresh sprig of rosemary.',
    signature_cocktail_id: 12,
    signature_cocktail_name: 'Black Manhattan',
    awards: ['Ultimate Spirits Challenge 94 Points', 'International Spirits Challenge Trophy'],
  },
  {
    id: 13,
    name: 'Cynar',
    slug: 'cynar',
    tagline: 'Artichoke Leaf & 13 Rare Herbs. Unapologetic Bittersweet.',
    category_id: 1,
    category_name: 'Aperitifs & Bitters',
    tier: 'Regional Priority',
    origin_country: 'Italy',
    origin_region: 'Venice / Padua',
    founded_year: 1952,
    abv: 16.5,
    flavor_profile: 'Earthy Cynarin, dark caramel, tea leaf, savory herbs, and warm wood.',
    tasting_notes: {
      nose: 'Savory herbal bouquet, roasted chicory, sweet molasses, and mint.',
      palate: 'Unexpectedly bittersweet; dark caramel giving way to vegetal artichoke complexity and herbs.',
      finish: 'Long, dry, and earthy with a delicate bittersweet tail.',
    },
    heritage: 'Created in 1952 by Venetian entrepreneur Peppino Dengo. Cynar takes its name from Cynara scolymus, the botanical name for the artichoke. A cult favorite of mixologists worldwide for adding unmatched savory depth to cocktails.',
    color_hex: '#15803D',
    accent_color: 'rgba(21, 128, 61, 0.2)',
    bottle_badge: 'CARCIOFO 1952',
    serving_suggestion: 'Cynar Spritz with Prosecco and soda, garnished with a slice of orange or olive.',
    signature_cocktail_id: 13,
    signature_cocktail_name: 'The Cynar Spritz',
    awards: ['Bartenders’ Choice Award Best Bitter', 'Spirits Innovation Trophy'],
  },
  {
    id: 14,
    name: 'Montelobos Mezcal',
    slug: 'montelobos-mezcal',
    tagline: 'Artisanal Espadín Mezcal. Smoked in Underground Conical Ovens.',
    category_id: 3,
    category_name: 'Tequila & Agave',
    tier: 'Regional Priority',
    origin_country: 'Mexico',
    origin_region: 'Santiago Matatlán, Oaxaca',
    founded_year: 2011,
    abv: 43.2,
    flavor_profile: 'Woodsmoke, roasted espadín agave, green pepper, nutmeg, and damp earth.',
    tasting_notes: {
      nose: 'Campfire smoke, fresh pine needles, and sweet caramelized agave hearts.',
      palate: 'Complex integration of gentle smoke, roasted agave, citrus peel, and white pepper.',
      finish: 'Sustained, warm, and lingering with gentle mineral ash and sweet smoke.',
    },
    heritage: 'Created by visionary botanist Dr. Iván Saldaña in Oaxaca. Montelobos is crafted sustainably from certified organic espadín agave, roasted for days over oak in stone conical pits and crushed by traditional horse-drawn tahona mills.',
    color_hex: '#475569',
    accent_color: 'rgba(71, 85, 105, 0.2)',
    bottle_badge: 'OAXACA ARTISANAL',
    serving_suggestion: 'Sipped neat from a traditional jícara with orange slices and sal de gusano.',
    signature_cocktail_id: 14,
    signature_cocktail_name: 'Smoky Mezcalita',
    awards: ['Certified 100% Organic Mezcal', 'San Francisco Spirits Gold'],
  },
  {
    id: 15,
    name: 'Bulldog Gin',
    slug: 'bulldog-gin',
    tagline: 'Modern London Dry. Dragon Eye, White Poppy & Lotus Leaf.',
    category_id: 4,
    category_name: 'Vodka & Gin',
    tier: 'Regional Priority',
    origin_country: 'United Kingdom',
    origin_region: 'London, England',
    founded_year: 2007,
    abv: 40.0,
    flavor_profile: 'Crisp juniper, dragon eye (longan), Turkish white poppy, lotus leaf, and fresh lavender.',
    tasting_notes: {
      nose: 'Fresh juniper berries harmonized with floral lavender and exotic citrus peel.',
      palate: 'Silky and rounded; crisp pine notes softened by floral sweetness and gentle botanical spice.',
      finish: 'Clean, warming, and distinctly sophisticated with hints of coriander.',
    },
    heritage: 'Crafted in historic copper pot stills in England using grain neutral spirit and 12 exotic botanicals gathered from 8 countries. Bulldog modernized the London dry profile by tempering intense pine with lush Asian botanicals.',
    color_hex: '#1E293B',
    accent_color: 'rgba(30, 41, 59, 0.2)',
    bottle_badge: 'LONDON DRY',
    serving_suggestion: 'Bulldog Supersonic Gin & Tonic with premium tonic water and fresh blackberry garnish.',
    signature_cocktail_id: 15,
    signature_cocktail_name: 'Bulldog G&T Botanica',
    awards: ['Gin Masters Gold Medal', 'Impact Hot Brand Award'],
  },
];

export const COCKTAILS: Cocktail[] = [
  {
    id: 1,
    name: 'The Negroni',
    slug: 'the-negroni',
    brand_id: 1,
    brand_name: 'Campari',
    tagline: 'The undisputed king of classic Italian cocktails.',
    glassware: 'Old Fashioned / Rocks Glass',
    difficulty: 'Easy',
    occasion: 'Aperitivo Hour & Pre-Dinner',
    ingredients: [
      { name: 'Campari', amount: '30', unit: 'ml (1 oz)' },
      { name: 'Sweet Red Vermouth (Cinzano 1757)', amount: '30', unit: 'ml (1 oz)' },
      { name: 'London Dry Gin (Bulldog Gin)', amount: '30', unit: 'ml (1 oz)' },
    ],
    steps: [
      'Fill a rocks glass to the brim with large solid ice cubes.',
      'Pour Campari, Cinzano 1757 Vermouth Rosso, and Bulldog Gin directly over the ice.',
      'Stir gently with a bar spoon for 20 seconds to achieve perfect chilling and dilution.',
      'Express the essential oils of a fresh orange peel over the surface and garnish with an orange slice.',
    ],
    garnish: 'Fresh orange wheel or expressed orange zest peel',
    history: 'Invented in Florence, Italy in 1919 at Caffè Casoni when Count Camillo Negroni asked bartender Fosco Scarselli to strengthen his favorite Americano by replacing the soda water with gin.',
  },
  {
    id: 2,
    name: 'The Aperol Spritz',
    slug: 'the-aperol-spritz',
    brand_id: 2,
    brand_name: 'Aperol',
    tagline: 'The world’s most famous sunset aperitivo.',
    glassware: 'Large Wine Glass',
    difficulty: 'Easy',
    occasion: 'Sunny Afternoon & Social Gatherings',
    ingredients: [
      { name: 'Prosecco D.O.C.', amount: '90', unit: 'ml (3 oz)' },
      { name: 'Aperol', amount: '60', unit: 'ml (2 oz)' },
      { name: 'Soda Water / Seltz', amount: '30', unit: 'ml (1 splash)' },
    ],
    steps: [
      'Fill a stemmed wine glass generously with cubed ice.',
      'Pour 3 parts of chilled Prosecco D.O.C. first.',
      'Follow with 2 parts of vibrant Aperol in a circular motion.',
      'Finish with 1 splash of soda water.',
      'Garnish with a juicy slice of fresh orange. Avoid stirring vigorously to preserve effervescence.',
    ],
    garnish: 'Fresh orange slice',
    history: 'Rooted in the Venetian tradition of splashing wine with sparkling water, Aperol Spritz became a worldwide cultural icon in the 1950s and remains the international symbol of celebration.',
  },
  {
    id: 3,
    name: 'The Boulevardier',
    slug: 'the-boulevardier',
    brand_id: 3,
    brand_name: 'Wild Turkey',
    tagline: 'The rich, dark, and sophisticated cousin of the Negroni.',
    glassware: 'Coupe or Rocks Glass',
    difficulty: 'Intermediate',
    occasion: 'Late Evening & Autumn Libations',
    ingredients: [
      { name: 'Wild Turkey 101 Bourbon', amount: '45', unit: 'ml (1.5 oz)' },
      { name: 'Campari', amount: '30', unit: 'ml (1 oz)' },
      { name: 'Sweet Red Vermouth (Cinzano 1757)', amount: '30', unit: 'ml (1 oz)' },
    ],
    steps: [
      'Add Wild Turkey 101, Campari, and Cinzano 1757 into a mixing glass with plenty of ice.',
      'Stir smoothly with a bar spoon for 30 seconds until well chilled.',
      'Strain into a chilled coupe or over a single large rock in an old-fashioned glass.',
      'Garnish with an expressed orange twist or a Luxardo maraschino cherry.',
    ],
    garnish: 'Expressed orange twist',
    history: 'Created in Paris in 1927 by Erskine Gwynne, an American writer who founded the Parisian literary magazine "The Boulevardier".',
  },
  {
    id: 4,
    name: 'SKYY Pacific Martini',
    slug: 'skyy-pacific-martini',
    brand_id: 4,
    brand_name: 'SKYY Vodka',
    tagline: 'Purity, crisp mineral salinity, and icy elegance.',
    glassware: 'Chilled Martini Glass',
    difficulty: 'Intermediate',
    occasion: 'Celebratory Toasts & Cocktail Soirées',
    ingredients: [
      { name: 'SKYY Vodka', amount: '60', unit: 'ml (2 oz)' },
      { name: 'Dry Vermouth', amount: '15', unit: 'ml (0.5 oz)' },
      { name: 'Saline Solution (10%)', amount: '2', unit: 'drops' },
    ],
    steps: [
      'Pre-chill the martini glass in the freezer.',
      'Add SKYY Vodka, dry vermouth, and saline drops to a mixing glass filled with solid ice.',
      'Stir vigorously for 40 revolutions until frosty cold.',
      'Fine-strain into the chilled glass.',
      'Twist a lemon peel over the surface to release aromatic citrus oils.',
    ],
    garnish: 'Lemon twist or Castelvetrano olive',
    history: 'Created to highlight the Pacific mineral profile of SKYY Vodka, yielding the silkiest dry martini texture possible.',
  },
  {
    id: 5,
    name: 'The Grand Margarita',
    slug: 'the-grand-margarita',
    brand_id: 5,
    brand_name: 'Grand Marnier',
    tagline: 'Cognac elegance meets Los Altos agave passion.',
    glassware: 'Margarita or Rocks Glass',
    difficulty: 'Intermediate',
    occasion: 'Gourmet Dinners & Festive Gatherings',
    ingredients: [
      { name: 'Grand Marnier Cordon Rouge', amount: '30', unit: 'ml (1 oz)' },
      { name: 'Espolòn Tequila Blanco', amount: '45', unit: 'ml (1.5 oz)' },
      { name: 'Fresh Lime Juice', amount: '25', unit: 'ml (0.8 oz)' },
      { name: 'Organic Agave Nectar', amount: '5', unit: 'ml (1 bar spoon)' },
    ],
    steps: [
      'Rub a lime wedge along half the rim of the glass and dip in coarse sea salt.',
      'In a cocktail shaker, combine Grand Marnier, Espolòn Blanco, fresh lime juice, and agave nectar.',
      'Fill shaker with ice and shake vigorously for 15 seconds.',
      'Strain over fresh ice into the prepared glass.',
      'Garnish with a dehydrated lime wheel.',
    ],
    garnish: 'Lime wheel and partial sea salt rim',
    history: 'Grand Marnier elevates the humble triple-sec margarita to an extraordinary gastronomic standard by infusing rich French oak cognac.',
  },
  {
    id: 6,
    name: 'The Espolòn Paloma',
    slug: 'the-espolon-paloma',
    brand_id: 6,
    brand_name: 'Espolòn Tequila',
    tagline: 'Mexico’s beloved effervescent national cocktail.',
    glassware: 'Highball / Collins Glass',
    difficulty: 'Easy',
    occasion: 'Summer Afternoons & Warm Evenings',
    ingredients: [
      { name: 'Espolòn Tequila Reposado', amount: '50', unit: 'ml (1.7 oz)' },
      { name: 'Fresh Pink Grapefruit Juice', amount: '60', unit: 'ml (2 oz)' },
      { name: 'Fresh Lime Juice', amount: '15', unit: 'ml (0.5 oz)' },
      { name: 'Sparkling Club Soda', amount: '45', unit: 'ml (1.5 oz)' },
      { name: 'Agave Syrup', amount: '10', unit: 'ml' },
    ],
    steps: [
      'Rim a highball glass with pink Himalayan salt.',
      'Fill the glass completely with clear ice cubes.',
      'Add Espolòn Reposado, fresh grapefruit juice, lime juice, and agave syrup.',
      'Stir gently to combine ingredients.',
      'Top with club soda and garnish with a fresh pink grapefruit wedge.',
    ],
    garnish: 'Pink grapefruit wedge & salted rim',
    history: 'While tourists drink margaritas, Mexicans drink Palomas. Espolòn Reposado’s roasted agave and light vanilla aging harmonize flawlessly with bitter-tart grapefruit.',
  },
  {
    id: 7,
    name: 'The Americano Classico',
    slug: 'the-americano-classico',
    brand_id: 7,
    brand_name: 'Cinzano 1757',
    tagline: 'The historic predecessor to the Negroni.',
    glassware: 'Highball or Tumbler',
    difficulty: 'Easy',
    occasion: 'Early Evening & Light Aperitivo',
    ingredients: [
      { name: 'Campari', amount: '35', unit: 'ml (1.2 oz)' },
      { name: 'Cinzano 1757 Vermouth Rosso', amount: '35', unit: 'ml (1.2 oz)' },
      { name: 'Chilled Club Soda', amount: '50', unit: 'ml (top)' },
    ],
    steps: [
      'Fill a highball glass with fresh ice.',
      'Pour equal parts Campari and Cinzano 1757 Vermouth.',
      'Top with a generous splash of sparkling soda water.',
      'Stir gently with a bar spoon.',
      'Garnish with an orange slice and a green Cerignola olive.',
    ],
    garnish: 'Orange slice and Cerignola olive',
    history: 'First served in the 1860s in Gaspare Campari’s bar Caffè Campari in Milan, originally dubbed "Milano-Torino", then named Americano due to its popularity among American travelers.',
  },
  {
    id: 8,
    name: 'The Kingston Negroni',
    slug: 'the-kingston-negroni',
    brand_id: 9,
    brand_name: 'Appleton Estate',
    tagline: 'The rich tropical Jamaican rum twist on the Italian master.',
    glassware: 'Rocks Glass',
    difficulty: 'Intermediate',
    occasion: 'Tasting Rooms & Evening Connoisseurs',
    ingredients: [
      { name: 'Appleton Estate 8YO Rare Casks Rum', amount: '30', unit: 'ml (1 oz)' },
      { name: 'Campari', amount: '30', unit: 'ml (1 oz)' },
      { name: 'Sweet Red Vermouth (Cinzano 1757)', amount: '30', unit: 'ml (1 oz)' },
    ],
    steps: [
      'Combine Appleton Estate 8YO, Campari, and Cinzano 1757 in a mixing glass with plenty of ice.',
      'Stir smoothly for 25 seconds until thoroughly chilled and diluted.',
      'Strain over a single pristine block of ice in an Old Fashioned glass.',
      'Express fresh orange peel across the drink and drop in.',
    ],
    garnish: 'Expressed orange twist and chocolate shaving',
    history: 'Created by bartender Joaquín Simó at Death & Co in New York, proving that the molasses funk and aged oak of Jamaican pot-still rum is a heavenly match for Campari.',
  },
];

export const SUSTAINABILITY_PILLARS: SustainabilityPillar[] = [
  {
    id: 1,
    title: 'Our People & Culture',
    focus: 'Diversity, Inclusion, and Well-being of 5,000+ Camparistas',
    metric: '44% Female Leadership',
    description: 'Fostering an inclusive, passionate global community across 27 countries. Championing equality, equal pay certification, continuous training through Campari Academy, and employee health.',
    sdg_alignment: 'UN SDG 5 & SDG 8',
  },
  {
    id: 2,
    title: 'Environment & Climate Action',
    focus: 'Decarbonization, Renewable Energy, and Water Stewardship',
    metric: '-48% GHG Emissions (Scope 1 & 2)',
    description: 'Committed to achieving Net Zero emissions by 2050. 100% renewable electricity achieved across our European manufacturing plants, with major solar arrays installed in Lawrenceburg and Canale.',
    sdg_alignment: 'UN SDG 7, SDG 12 & SDG 13',
  },
  {
    id: 3,
    title: 'Responsible Drinking & Marketing',
    focus: 'Moderation, Education, and Strict Marketing Standards',
    metric: '100% Compliance with Code of Commercial Ethics',
    description: 'Promoting moderation as a cultural norm through educational programs, clear on-pack nutritional and ABV labeling, and initiatives with the International Alliance for Responsible Drinking (IARD).',
    sdg_alignment: 'UN SDG 3 & SDG 12',
  },
  {
    id: 4,
    title: 'Community & Terroir Preservation',
    focus: 'Heritage Conservation and Local Agriculture Support',
    metric: '€12M+ Invested in Cultural & Social Initiatives',
    description: 'Protecting agricultural biodiversity in Jamaica (Nassau Valley aquifer), Mexico (sustainable agave farming), and Italy (preservation of historic art archives at Galleria Campari).',
    sdg_alignment: 'UN SDG 11 & SDG 15',
  },
];

export const INVESTOR_METRICS: InvestorMetric[] = [
  {
    label: 'Annual Net Sales',
    value: '€2,918.6M',
    change: '+10.8% Organic Growth',
    period: 'FY 2024 / 2025',
    description: 'Led by double-digit growth in Global Priorities (Aperol, Campari, Espolòn).',
  },
  {
    label: 'EBITDA Adjusted',
    value: '€728.9M',
    change: '25.0% Margin',
    period: 'Operating Profitability',
    description: 'Demonstrating pricing power and premiumization resilience worldwide.',
  },
  {
    label: 'Global Priority Contribution',
    value: '62%',
    change: '+240 bps',
    period: 'Of Total Group Revenue',
    description: 'Campari, Aperol, Wild Turkey, Skyy, Grand Marnier, Espolòn, and Courvoisier.',
  },
  {
    label: 'Global Distribution Footprint',
    value: '190+ Markets',
    change: '25 Own In-Market Companies',
    period: 'Worldwide Presence',
    description: 'Direct distribution in key markets accounting for 93% of group net sales.',
  },
];

// PHP & MySQL Relational Architecture Source Code Snippets
export const MYSQL_SCHEMA_SQL = `-- ========================================================
-- CAMPARI GROUP RELATIONAL DATABASE SCHEMA (MySQL 8.0+)
-- Engine: InnoDB | Charset: utf8mb4 | Collation: utf8mb4_unicode_ci
-- ========================================================

CREATE DATABASE IF NOT EXISTS \`campari_group_db\`
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE \`campari_group_db\`;

-- 1. Categories Table
CREATE TABLE IF NOT EXISTS \`categories\` (
  \`id\` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  \`name\` VARCHAR(100) NOT NULL,
  \`slug\` VARCHAR(100) NOT NULL UNIQUE,
  \`description\` TEXT,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (\`id\`),
  INDEX \`idx_category_slug\` (\`slug\`)
) ENGINE=InnoDB;

-- 2. Brands Table
CREATE TABLE IF NOT EXISTS \`brands\` (
  \`id\` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  \`name\` VARCHAR(100) NOT NULL,
  \`slug\` VARCHAR(100) NOT NULL UNIQUE,
  \`tagline\` VARCHAR(255) NOT NULL,
  \`category_id\` INT UNSIGNED NOT NULL,
  \`tier\` ENUM('Global Priority', 'Regional Priority', 'Local Priority') NOT NULL DEFAULT 'Global Priority',
  \`origin_country\` VARCHAR(80) NOT NULL,
  \`origin_region\` VARCHAR(120) NOT NULL,
  \`founded_year\` SMALLINT UNSIGNED NOT NULL,
  \`abv\` DECIMAL(4,1) NOT NULL,
  \`flavor_profile\` TEXT NOT NULL,
  \`nose_notes\` TEXT NOT NULL,
  \`palate_notes\` TEXT NOT NULL,
  \`finish_notes\` TEXT NOT NULL,
  \`heritage\` LONGTEXT NOT NULL,
  \`color_hex\` VARCHAR(7) NOT NULL DEFAULT '#DA251C',
  \`bottle_badge\` VARCHAR(80) NOT NULL,
  \`serving_suggestion\` TEXT NOT NULL,
  \`signature_cocktail_id\` INT UNSIGNED DEFAULT NULL,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (\`id\`),
  INDEX \`idx_brands_category\` (\`category_id\`),
  INDEX \`idx_brands_tier\` (\`tier\`),
  INDEX \`idx_brands_origin\` (\`origin_country\`),
  CONSTRAINT \`fk_brands_category\` FOREIGN KEY (\`category_id\`) REFERENCES \`categories\` (\`id\`) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- 3. Cocktails Table
CREATE TABLE IF NOT EXISTS \`cocktails\` (
  \`id\` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  \`name\` VARCHAR(120) NOT NULL,
  \`slug\` VARCHAR(120) NOT NULL UNIQUE,
  \`brand_id\` INT UNSIGNED NOT NULL,
  \`tagline\` VARCHAR(255) NOT NULL,
  \`glassware\` VARCHAR(80) NOT NULL,
  \`difficulty\` ENUM('Easy', 'Intermediate', 'Master') NOT NULL DEFAULT 'Easy',
  \`occasion\` VARCHAR(100) NOT NULL,
  \`garnish\` VARCHAR(120) NOT NULL,
  \`history\` TEXT NOT NULL,
  \`ingredients_json\` JSON NOT NULL,
  \`steps_json\` JSON NOT NULL,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (\`id\`),
  INDEX \`idx_cocktails_brand\` (\`brand_id\`),
  CONSTRAINT \`fk_cocktails_brand\` FOREIGN KEY (\`brand_id\`) REFERENCES \`brands\` (\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 4. Sustainability Initiatives Table
CREATE TABLE IF NOT EXISTS \`sustainability_initiatives\` (
  \`id\` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  \`pillar\` VARCHAR(100) NOT NULL,
  \`focus\` VARCHAR(255) NOT NULL,
  \`metric\` VARCHAR(100) NOT NULL,
  \`description\` TEXT NOT NULL,
  \`sdg_alignment\` VARCHAR(60) NOT NULL,
  PRIMARY KEY (\`id\`)
) ENGINE=InnoDB;
`;

export const PHP_DB_CONNECT_CODE = `<?php
/**
 * config/db_connect.php
 * Campari Group MySQL PDO Connection Service
 */
declare(strict_types=1);

class Database {
    private static ?PDO $instance = null;

    private string $host;
    private string $dbName;
    private string $user;
    private string $password;
    private int $port;

    public function __construct() {
        $this->host     = $_ENV['MYSQL_HOST'] ?? '127.0.0.1';
        $this->dbName   = $_ENV['MYSQL_DATABASE'] ?? 'campari_group_db';
        $this->user     = $_ENV['MYSQL_USER'] ?? 'campari_app';
        $this->password = $_ENV['MYSQL_PASSWORD'] ?? 'secret_token';
        $this->port     = (int)($_ENV['MYSQL_PORT'] ?? 3306);
    }

    public static function getConnection(): PDO {
        if (self::$instance === null) {
            $db = new self();
            $dsn = sprintf(
                'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
                $db->host,
                $db->port,
                $db->dbName
            );

            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
            ];

            try {
                self::$instance = new PDO($dsn, $db->user, $db->password, $options);
            } catch (PDOException $e) {
                http_response_code(500);
                echo json_encode([
                    'error' => 'MySQL Database Connection Failed',
                    'message' => $e->getMessage()
                ]);
                exit;
            }
        }

        return self::$instance;
    }
}
`;

export const PHP_BRANDS_API_CODE = `<?php
/**
 * api/v1/brands.php
 * Campari Group Premium Spirits Portfolio REST API
 * Handles listing, filtering, search, and category joins
 */
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

require_once __DIR__ . '/../../config/db_connect.php';

try {
    $pdo = Database::getConnection();

    // Query parameters
    $category = $_GET['category'] ?? null;
    $tier     = $_GET['tier'] ?? null;
    $search   = $_GET['q'] ?? null;
    $slug     = $_GET['slug'] ?? null;

    if ($slug) {
        $stmt = $pdo->prepare('
            SELECT 
                b.*,
                c.name AS category_name,
                c.slug AS category_slug,
                ck.name AS signature_cocktail_name,
                ck.slug AS signature_cocktail_slug
            FROM brands b
            INNER JOIN categories c ON b.category_id = c.id
            LEFT JOIN cocktails ck ON b.signature_cocktail_id = ck.id
            WHERE b.slug = :slug
            LIMIT 1
        ');
        $stmt->execute(['slug' => $slug]);
        $brand = $stmt->fetch();

        if (!$brand) {
            http_response_code(404);
            echo json_encode(['status' => 404, 'error' => 'Brand not found']);
            exit;
        }

        echo json_encode(['status' => 200, 'data' => $brand], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        exit;
    }

    // Dynamic Filter Query Builder
    $sql = '
        SELECT 
            b.id,
            b.name,
            b.slug,
            b.tagline,
            b.tier,
            b.origin_country,
            b.origin_region,
            b.founded_year,
            b.abv,
            b.flavor_profile,
            b.color_hex,
            b.bottle_badge,
            c.name AS category_name,
            c.slug AS category_slug,
            ck.name AS signature_cocktail_name
        FROM brands b
        INNER JOIN categories c ON b.category_id = c.id
        LEFT JOIN cocktails ck ON b.signature_cocktail_id = ck.id
        WHERE 1=1
    ';
    $params = [];

    if ($category) {
        $sql .= ' AND (c.slug = :category OR c.name = :category)';
        $params['category'] = $category;
    }

    if ($tier) {
        $sql .= ' AND b.tier = :tier';
        $params['tier'] = $tier;
    }

    if ($search) {
        $sql .= ' AND (b.name LIKE :search OR b.flavor_profile LIKE :search OR b.origin_country LIKE :search)';
        $params['search'] = '%' . $search . '%';
    }

    $sql .= ' ORDER BY FIELD(b.tier, "Global Priority", "Regional Priority", "Local Priority"), b.name ASC';

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $results = $stmt->fetchAll();

    echo json_encode([
        'status' => 200,
        'count' => count($results),
        'server' => 'PHP 8.2 / MySQL 8.0 PDO Engine',
        'execution_ms' => 0.42,
        'data' => $results
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 500,
        'error' => 'Internal Server Error',
        'details' => $e->getMessage()
    ]);
}
`;

// In-Memory MySQL Emulator for the Interactive SQL Runner
export function executeSimulatedQuery(sql: string): {
  columns: string[];
  rows: Record<string, unknown>[];
  rowCount: number;
  executionMs: number;
  query: string;
} {
  const start = performance.now();
  const trimmed = sql.trim().replace(/;$/, '');
  const lower = trimmed.toLowerCase();

  // Preset queries handler or parsing
  if (lower.startsWith('select')) {
    // Check if selecting from brands
    if (lower.includes('from brands')) {
      let filtered = [...BRANDS];

      // Filter by tier
      if (lower.includes("tier = 'global priority'")) {
        filtered = filtered.filter(b => b.tier === 'Global Priority');
      } else if (lower.includes("tier = 'regional priority'")) {
        filtered = filtered.filter(b => b.tier === 'Regional Priority');
      }

      // Filter by category
      if (lower.includes("category") && lower.includes("aperitif")) {
        filtered = filtered.filter(b => b.category_id === 1);
      } else if (lower.includes("category") && lower.includes("bourbon")) {
        filtered = filtered.filter(b => b.category_id === 2);
      } else if (lower.includes("category") && lower.includes("tequila")) {
        filtered = filtered.filter(b => b.category_id === 3);
      }

      // Filter by ABV
      if (lower.includes("abv > 40")) {
        filtered = filtered.filter(b => b.abv > 40);
      } else if (lower.includes("abv <= 25")) {
        filtered = filtered.filter(b => b.abv <= 25);
      }

      // Sort
      if (lower.includes("order by founded_year asc")) {
        filtered.sort((a, b) => a.founded_year - b.founded_year);
      } else if (lower.includes("order by founded_year desc")) {
        filtered.sort((a, b) => b.founded_year - a.founded_year);
      } else if (lower.includes("order by abv desc")) {
        filtered.sort((a, b) => b.abv - a.abv);
      }

      const rows = filtered.map(b => ({
        id: b.id,
        name: b.name,
        category: b.category_name,
        tier: b.tier,
        origin_country: b.origin_country,
        founded_year: b.founded_year,
        abv: `${b.abv}%`,
        signature_cocktail: b.signature_cocktail_name,
        flavor_profile: b.flavor_profile,
      }));

      const columns = ['id', 'name', 'category', 'tier', 'origin_country', 'founded_year', 'abv', 'signature_cocktail'];
      const end = performance.now();
      return {
        columns,
        rows,
        rowCount: rows.length,
        executionMs: Math.max(0.24, parseFloat((end - start).toFixed(2))),
        query: sql,
      };
    }

    // Check if selecting from cocktails
    if (lower.includes('from cocktails')) {
      const rows = COCKTAILS.map(c => ({
        id: c.id,
        name: c.name,
        brand: c.brand_name,
        glassware: c.glassware,
        difficulty: c.difficulty,
        occasion: c.occasion,
        garnish: c.garnish,
      }));
      const columns = ['id', 'name', 'brand', 'glassware', 'difficulty', 'occasion', 'garnish'];
      const end = performance.now();
      return {
        columns,
        rows,
        rowCount: rows.length,
        executionMs: 0.31,
        query: sql,
      };
    }

    // Check if selecting categories
    if (lower.includes('from categories')) {
      const rows = CATEGORIES.map(c => ({
        id: c.id,
        name: c.name,
        slug: c.slug,
        spirit_count: c.count,
        description: c.description,
      }));
      const columns = ['id', 'name', 'slug', 'spirit_count', 'description'];
      return {
        columns,
        rows,
        rowCount: rows.length,
        executionMs: 0.18,
        query: sql,
      };
    }

    // Check if selecting sustainability
    if (lower.includes('from sustainability')) {
      const rows = SUSTAINABILITY_PILLARS.map(s => ({
        id: s.id,
        title: s.title,
        metric: s.metric,
        focus: s.focus,
        sdg: s.sdg_alignment,
      }));
      const columns = ['id', 'title', 'metric', 'focus', 'sdg'];
      return {
        columns,
        rows,
        rowCount: rows.length,
        executionMs: 0.22,
        query: sql,
      };
    }
  }

  // Fallback default query response
  const rows = BRANDS.slice(0, 8).map(b => ({
    id: b.id,
    name: b.name,
    category: b.category_name,
    tier: b.tier,
    origin_country: b.origin_country,
    founded: b.founded_year,
    abv: `${b.abv}%`,
  }));
  const columns = ['id', 'name', 'category', 'tier', 'origin_country', 'founded', 'abv'];
  return {
    columns,
    rows,
    rowCount: rows.length,
    executionMs: 0.35,
    query: sql,
  };
}
