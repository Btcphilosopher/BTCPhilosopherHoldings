import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Campari Group - The World’s Most Iconic Spirits Company',
  description:
    'Showcase of Campari Group’s premium spirits portfolio: Campari, Aperol, Wild Turkey, Skyy Vodka, Grand Marnier, Espolòn, and more.',
  openGraph: {
    title: 'Campari Group - Iconic Brands. A Brighter Tomorrow.',
    description:
      'We bring people together through extraordinary brands, creating moments of pleasure, connection and celebration across the globe.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Campari Group - Iconic Brands. A Brighter Tomorrow.',
    description:
      'Explore Campari Group’s global spirits portfolio, heritage, sustainability, and signature cocktails.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark scroll-smooth">
      <body suppressHydrationWarning className="bg-[#0c0c0e] text-[#f4f4f5] antialiased selection:bg-[#da251c] selection:text-white">
        {children}
      </body>
    </html>
  );
}
