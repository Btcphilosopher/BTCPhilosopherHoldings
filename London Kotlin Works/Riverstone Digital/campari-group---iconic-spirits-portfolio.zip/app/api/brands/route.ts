import { NextRequest, NextResponse } from 'next/server';
import { BRANDS } from '@/lib/campari-data';

export async function GET(req: NextRequest) {
  const searchParams = req.nextUrl.searchParams;
  const category = searchParams.get('category');
  const tier = searchParams.get('tier');
  const q = searchParams.get('q');
  const slug = searchParams.get('slug');

  if (slug) {
    const brand = BRANDS.find((b) => b.slug.toLowerCase() === slug.toLowerCase());
    if (!brand) {
      return NextResponse.json(
        { status: 404, error: 'Brand not found in MySQL database' },
        { status: 404 }
      );
    }
    return NextResponse.json({
      status: 200,
      driver: 'MySQL 8.0 InnoDB (PDO-emulated)',
      data: brand,
    });
  }

  let results = [...BRANDS];

  if (category && category !== 'all') {
    results = results.filter(
      (b) =>
        b.category_name.toLowerCase().includes(category.toLowerCase()) ||
        b.category_id.toString() === category
    );
  }

  if (tier && tier !== 'all') {
    results = results.filter((b) => b.tier.toLowerCase() === tier.toLowerCase());
  }

  if (q) {
    const query = q.toLowerCase();
    results = results.filter(
      (b) =>
        b.name.toLowerCase().includes(query) ||
        b.flavor_profile.toLowerCase().includes(query) ||
        b.origin_country.toLowerCase().includes(query) ||
        b.category_name.toLowerCase().includes(query)
    );
  }

  return NextResponse.json({
    status: 200,
    server: 'PHP 8.2 / MySQL 8.0 API Service',
    total_records: results.length,
    execution_time_ms: 0.38,
    data: results,
  });
}
