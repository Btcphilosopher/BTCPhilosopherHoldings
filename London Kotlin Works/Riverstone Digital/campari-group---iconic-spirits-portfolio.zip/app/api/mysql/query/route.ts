import { NextRequest, NextResponse } from 'next/server';
import { executeSimulatedQuery } from '@/lib/campari-data';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { sql } = body;

    if (!sql || typeof sql !== 'string') {
      return NextResponse.json(
        { error: 'A valid SQL query string is required' },
        { status: 400 }
      );
    }

    const queryResult = executeSimulatedQuery(sql);

    return NextResponse.json({
      success: true,
      engine: 'MySQL 8.0.35 Community Server (InnoDB)',
      database: 'campari_group_db',
      ...queryResult,
    });
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'Unknown query execution error';
    return NextResponse.json(
      {
        success: false,
        error: errorMsg,
      },
      { status: 500 }
    );
  }
}
