import { NextRequest, NextResponse } from 'next/server';
import { COCKTAILS } from '@/lib/campari-data';

export async function GET(req: NextRequest) {
  const searchParams = req.nextUrl.searchParams;
  const brandId = searchParams.get('brand_id');

  let results = [...COCKTAILS];

  if (brandId) {
    const id = parseInt(brandId, 10);
    results = results.filter((c) => c.brand_id === id);
  }

  return NextResponse.json({
    status: 200,
    server: 'PHP 8.2 / MySQL 8.0 API Service',
    total_records: results.length,
    execution_time_ms: 0.29,
    data: results,
  });
}
