'use client';

import React, { useState } from 'react';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import BrandStrip from '@/components/BrandStrip';
import FeatureCards from '@/components/FeatureCards';
import PortfolioShowcase from '@/components/PortfolioShowcase';
import BrandDetailModal from '@/components/BrandDetailModal';
import CocktailStudio from '@/components/CocktailStudio';
import OurStory from '@/components/OurStory';
import SustainabilitySection from '@/components/SustainabilitySection';
import InvestorSection from '@/components/InvestorSection';
import SqlConsoleModal from '@/components/SqlConsoleModal';
import SearchModal from '@/components/SearchModal';
import AgeVerificationModal from '@/components/AgeVerificationModal';
import Footer from '@/components/Footer';
import { Brand, BRANDS } from '@/lib/campari-data';

export default function HomePage() {
  const [selectedBrand, setSelectedBrand] = useState<Brand | null>(null);
  const [activeCocktailName, setActiveCocktailName] = useState<string>('The Negroni');
  const [isSqlConsoleOpen, setIsSqlConsoleOpen] = useState<boolean>(false);
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [sqlInitialQuery, setSqlInitialQuery] = useState<string | undefined>(undefined);

  // Smooth scroll handler
  const handleNavigateSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectBrandSlug = (slug: string) => {
    const found = BRANDS.find((b) => b.slug.toLowerCase() === slug.toLowerCase());
    if (found) {
      setSelectedBrand(found);
    }
  };

  const handleOpenCocktail = (cocktailName: string) => {
    setActiveCocktailName(cocktailName);
    handleNavigateSection('cocktail-studio');
  };

  const handleInspectBrandSql = (brand: Brand) => {
    setSqlInitialQuery(
      `SELECT * FROM brands WHERE id = ${brand.id} /* ${brand.name} (${brand.origin_country}) */;`
    );
    setIsSqlConsoleOpen(true);
  };

  const handleFeatureSelect = (featureId: string) => {
    handleNavigateSection(featureId);
  };

  return (
    <div className="min-h-screen bg-[#0c0c0e] text-[#f4f4f5] flex flex-col font-sans selection:bg-[#da251c] selection:text-white">
      {/* Age Verification Compliance */}
      <AgeVerificationModal />

      {/* Main Top Header */}
      <Header
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenSqlConsole={() => {
          setSqlInitialQuery(undefined);
          setIsSqlConsoleOpen(true);
        }}
        onNavigateSection={handleNavigateSection}
      />

      <main className="flex-1 w-full">
        {/* Hero Section matching attachment */}
        <Hero
          onDiscoverClick={() => handleNavigateSection('portfolio')}
        />

        {/* Horizontal Brand Strip matching attachment */}
        <BrandStrip onSelectBrandSlug={handleSelectBrandSlug} />

        {/* 4 Feature Visual Cards matching attachment */}
        <FeatureCards onSelectFeature={handleFeatureSelect} />

        {/* Spirits Portfolio Showcase */}
        <PortfolioShowcase
          onSelectBrand={(brand) => setSelectedBrand(brand)}
          onOpenCocktail={handleOpenCocktail}
          onInspectBrandSql={handleInspectBrandSql}
        />

        {/* Cocktail Mixology Studio */}
        <CocktailStudio initialCocktailName={activeCocktailName} />

        {/* Heritage & Art Timeline */}
        <OurStory />

        {/* Sustainability & ESG Roadmap */}
        <SustainabilitySection />

        {/* Financials & Investor Relations */}
        <InvestorSection />
      </main>

      {/* Corporate Footer */}
      <Footer
        onOpenSqlConsole={() => {
          setSqlInitialQuery(undefined);
          setIsSqlConsoleOpen(true);
        }}
        onNavigateSection={handleNavigateSection}
      />

      {/* Brand Detail Modal */}
      <BrandDetailModal
        brand={selectedBrand}
        onClose={() => setSelectedBrand(null)}
        onOpenCocktail={handleOpenCocktail}
        onInspectSql={handleInspectBrandSql}
      />

      {/* Interactive MySQL & PHP Hub Modal */}
      <SqlConsoleModal
        isOpen={isSqlConsoleOpen}
        onClose={() => setIsSqlConsoleOpen(false)}
        initialQuery={sqlInitialQuery}
      />

      {/* Global Quick Search Overlay */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectBrand={(brand) => setSelectedBrand(brand)}
        onSelectCocktail={handleOpenCocktail}
      />
    </div>
  );
}
