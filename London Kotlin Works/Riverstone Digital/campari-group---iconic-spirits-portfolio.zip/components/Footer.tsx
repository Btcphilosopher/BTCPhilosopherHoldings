'use client';

import React from 'react';
import { Database, ShieldAlert } from 'lucide-react';

interface FooterProps {
  onOpenSqlConsole: () => void;
  onNavigateSection: (sectionId: string) => void;
}

export default function Footer({ onOpenSqlConsole, onNavigateSection }: FooterProps) {
  return (
    <footer className="w-full bg-[#08080a] border-t border-white/10 text-zinc-400 py-16 px-6">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Top Tier: Brand, Mission, Quick Links */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          <div className="lg:col-span-2 space-y-4">
            <span
              className="text-2xl font-bold tracking-[0.22em] text-white block"
              style={{ fontFamily: 'Cinzel, Georgia, serif' }}
            >
              CAMPARI GROUP
            </span>
            <p className="text-xs text-zinc-400 leading-relaxed font-light max-w-sm">
              Davide Campari-Milano N.V. — The world&apos;s leading spirit producer and purveyor of iconic Italian aperitifs, fine American bourbons, authentic tequilas, and aged rums.
            </p>
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={onOpenSqlConsole}
                className="inline-flex items-center gap-2 px-3 py-1.5 text-xs font-mono font-medium text-emerald-400 bg-emerald-950/40 border border-emerald-800/40 rounded hover:bg-emerald-900/50 transition-colors cursor-pointer"
              >
                <Database className="w-3.5 h-3.5" />
                <span>MySQL Database & PHP REST API Status: Active</span>
              </button>
            </div>
          </div>

          <div>
            <h4 className="text-xs font-semibold uppercase tracking-widest text-white mb-4">
              Our Brands
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => onNavigateSection('portfolio')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Global Priorities
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateSection('portfolio')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Regional Priorities
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateSection('cocktail-studio')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  The Campari Academy
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateSection('portfolio')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Spirits Catalog
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-semibold uppercase tracking-widest text-white mb-4">
              The Group
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => onNavigateSection('story')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Our Heritage & 1860 Roots
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateSection('story')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Camparino in Galleria
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateSection('sustainability')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Sustainability & ESG
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateSection('investors')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Investors (CPR.MI)
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-semibold uppercase tracking-widest text-white mb-4">
              Headquarters
            </h4>
            <address className="not-italic text-xs space-y-1.5 leading-relaxed text-zinc-400">
              <p className="text-zinc-200">Davide Campari-Milano N.V.</p>
              <p>Corporate Headquarters:</p>
              <p>Via F. Sacchetti 20</p>
              <p>20099 Sesto San Giovanni (Milan), Italy</p>
              <p className="pt-2 text-zinc-500 font-mono">TEL: +39 02 62251</p>
            </address>
          </div>
        </div>

        {/* Responsible Drinking Banner */}
        <div className="bg-[#121216] border border-white/10 rounded-xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-3">
            <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0" />
            <p className="text-zinc-300 font-light">
              <strong className="text-white font-medium">Enjoy Responsibly.</strong> Campari Group promotes responsible drinking as part of a conscious, balanced lifestyle. You must be of legal drinking age in your country of residence to enter this website.
            </p>
          </div>
          <span className="text-[11px] font-mono text-zinc-400 shrink-0">
            IARD Member · Respect 21+
          </span>
        </div>

        {/* Bottom Bar: Copyright & Terms */}
        <div className="pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-zinc-400">
          <div>
            © {new Date().getFullYear()} Davide Campari-Milano N.V. All rights reserved.
          </div>
          <div className="flex flex-wrap items-center gap-6">
            <span className="hover:text-zinc-200 cursor-pointer">Privacy Notice</span>
            <span className="hover:text-zinc-200 cursor-pointer">Cookie Policy</span>
            <span className="hover:text-zinc-200 cursor-pointer">Legal Information</span>
            <span className="hover:text-zinc-200 cursor-pointer">Code of Commercial Communications</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
