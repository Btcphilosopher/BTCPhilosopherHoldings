'use client';

import React, { useState, useMemo } from 'react';
import { Brand, CATEGORIES, BRANDS } from '@/lib/campari-data';
import { Search, Sparkles, GlassWater, Database, ChevronRight, Award } from 'lucide-react';

interface PortfolioShowcaseProps {
  onSelectBrand: (brand: Brand) => void;
  onOpenCocktail: (cocktailSlug: string) => void;
  onInspectBrandSql: (brand: Brand) => void;
}

export default function PortfolioShowcase({
  onSelectBrand,
  onOpenCocktail,
  onInspectBrandSql,
}: PortfolioShowcaseProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedTier, setSelectedTier] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredBrands = useMemo(() => {
    return BRANDS.filter((brand) => {
      // Category filter
      if (selectedCategory !== 'all' && brand.category_name !== selectedCategory) {
        return false;
      }
      // Tier filter
      if (selectedTier !== 'all' && brand.tier !== selectedTier) {
        return false;
      }
      // Search query
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase();
        const matchesName = brand.name.toLowerCase().includes(q);
        const matchesFlavor = brand.flavor_profile.toLowerCase().includes(q);
        const matchesCountry = brand.origin_country.toLowerCase().includes(q);
        const matchesCocktail = brand.signature_cocktail_name.toLowerCase().includes(q);
        if (!matchesName && !matchesFlavor && !matchesCountry && !matchesCocktail) {
          return false;
        }
      }
      return true;
    });
  }, [selectedCategory, selectedTier, searchQuery]);

  return (
    <section id="portfolio" className="w-full bg-[#0c0c0e] py-20 px-6 border-b border-white/10">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="text-xs font-semibold tracking-[0.25em] text-[#da251c] uppercase mb-2">
              GLOBAL SPIRITS PORTFOLIO
            </div>
            <h2
              className="text-3xl md:text-5xl font-serif text-white tracking-tight"
              style={{ fontFamily: 'Cormorant Garamond, Georgia, serif' }}
            >
              The House of Extraordinary Brands
            </h2>
          </div>
          <p className="text-sm text-zinc-400 max-w-md font-light leading-relaxed">
            From the crimson bitters of Milan to Kentucky straight bourbons and highland Jalisco agave, discover the artisans shaping worldwide cocktail culture.
          </p>
        </div>

        {/* Filter Controls Row */}
        <div className="bg-[#121216] border border-white/10 rounded-xl p-4 md:p-6 mb-10 space-y-4">
          {/* Top Search & Tier Filters */}
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            {/* Search Input */}
            <div className="relative w-full md:w-80">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
              <input
                type="text"
                placeholder="Search spirits, flavor notes, origins..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#0c0c0e] border border-white/10 rounded-lg pl-10 pr-4 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#da251c] transition-colors"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-zinc-400 hover:text-white"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Tier Segmented Tabs */}
            <div className="flex items-center gap-1 p-1 bg-[#0c0c0e] rounded-lg border border-white/10 overflow-x-auto max-w-full">
              {[
                { label: 'All Tiers', val: 'all' },
                { label: 'Global Priorities', val: 'Global Priority' },
                { label: 'Regional Priorities', val: 'Regional Priority' },
                { label: 'Local Priorities', val: 'Local Priority' },
              ].map((tier) => (
                <button
                  key={tier.val}
                  onClick={() => setSelectedTier(tier.val)}
                  className={`px-3 py-1.5 text-xs font-medium rounded transition-all whitespace-nowrap cursor-pointer ${
                    selectedTier === tier.val
                      ? 'bg-[#da251c] text-white shadow-sm'
                      : 'text-zinc-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {tier.label}
                </button>
              ))}
            </div>
          </div>

          {/* Category Filter Pills (Functional interactive buttons) */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-full transition-all whitespace-nowrap cursor-pointer border ${
                selectedCategory === 'all'
                  ? 'bg-white text-zinc-950 border-white'
                  : 'bg-transparent text-zinc-400 border-white/10 hover:border-white/30 hover:text-white'
              }`}
            >
              All Categories ({BRANDS.length})
            </button>
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.name)}
                className={`px-3.5 py-1.5 text-xs font-medium rounded-full transition-all whitespace-nowrap cursor-pointer border ${
                  selectedCategory === cat.name
                    ? 'bg-white text-zinc-950 border-white'
                    : 'bg-transparent text-zinc-400 border-white/10 hover:border-white/30 hover:text-white'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>
        </div>

        {/* Results Counter & Active Filter Indicators */}
        <div className="flex items-center justify-between text-xs text-zinc-400 mb-6">
          <div className="flex items-center gap-2">
            <span>Showing <strong className="text-white font-mono tabular-nums">{filteredBrands.length}</strong> spirits in database</span>
            {(selectedCategory !== 'all' || selectedTier !== 'all' || searchQuery) && (
              <button
                onClick={() => {
                  setSelectedCategory('all');
                  setSelectedTier('all');
                  setSearchQuery('');
                }}
                className="text-[#da251c] hover:underline ml-2 cursor-pointer"
              >
                Reset filters
              </button>
            )}
          </div>
          <span className="hidden sm:inline font-mono text-[11px] text-zinc-500">
            Source: MySQL Table `brands`
          </span>
        </div>

        {/* Brands Grid */}
        {filteredBrands.length === 0 ? (
          <div className="bg-[#121216] border border-white/10 rounded-xl p-12 text-center my-8">
            <Sparkles className="w-8 h-8 text-zinc-500 mx-auto mb-3" />
            <h3 className="text-lg font-serif text-white mb-2">No spirits match your criteria</h3>
            <p className="text-xs text-zinc-400 mb-4">Try clearing search terms or selecting &quot;All Categories&quot;.</p>
            <button
              onClick={() => {
                setSelectedCategory('all');
                setSelectedTier('all');
                setSearchQuery('');
              }}
              className="px-4 py-2 text-xs font-semibold bg-[#da251c] text-white rounded cursor-pointer"
            >
              Show All Spirits
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredBrands.map((brand) => (
              <div
                key={brand.id}
                className="group relative bg-[#121216] border border-white/10 hover:border-white/25 rounded-xl p-6 flex flex-col justify-between transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
              >
                {/* Brand Header */}
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="text-[11px] font-semibold tracking-wider uppercase text-zinc-400">
                      {brand.category_name}
                    </span>
                    <span
                      className="text-[10px] font-mono tracking-wider px-2 py-0.5 rounded border border-white/10 text-zinc-300"
                      style={{ borderColor: brand.color_hex + '40' }}
                    >
                      {brand.bottle_badge}
                    </span>
                  </div>

                  {/* Brand Name with custom typography */}
                  <h3
                    className="text-2xl font-serif text-white tracking-wide mb-1 group-hover:text-[#f4f4f5] transition-colors"
                    style={{ fontFamily: 'Cormorant Garamond, Georgia, serif' }}
                  >
                    {brand.name}
                  </h3>
                  <p className="text-xs text-zinc-400 font-light italic mb-4 line-clamp-1">
                    {brand.tagline}
                  </p>

                  {/* Origin & ABV Strip */}
                  <div className="flex items-center gap-3 text-xs text-zinc-400 mb-4 pb-4 border-b border-white/5">
                    <span>{brand.origin_country}</span>
                    <span aria-hidden="true">·</span>
                    <span>Est. <strong className="text-zinc-200 font-mono tabular-nums">{brand.founded_year}</strong></span>
                    <span aria-hidden="true">·</span>
                    <span><strong className="text-zinc-200 font-mono tabular-nums">{brand.abv}%</strong> ABV</span>
                  </div>

                  {/* Flavor Notes Summary */}
                  <div className="mb-6">
                    <div className="text-[11px] uppercase tracking-wider text-zinc-400 font-medium mb-1">
                      Tasting Profile
                    </div>
                    <p className="text-xs text-zinc-300 line-clamp-2 leading-relaxed">
                      {brand.flavor_profile}
                    </p>
                  </div>
                </div>

                {/* Card Actions & Cocktails */}
                <div className="pt-2 border-t border-white/5 space-y-3">
                  {/* Signature Cocktail Shortcut */}
                  <button
                    onClick={() => onOpenCocktail(brand.signature_cocktail_name)}
                    className="w-full flex items-center justify-between text-left px-3 py-2 rounded bg-white/5 hover:bg-white/10 text-xs text-zinc-300 hover:text-white transition-colors cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <GlassWater className="w-3.5 h-3.5 text-[#da251c]" />
                      <span>{brand.signature_cocktail_name}</span>
                    </span>
                    <ChevronRight className="w-3.5 h-3.5 text-zinc-400" />
                  </button>

                  {/* Primary & SQL Actions */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onSelectBrand(brand)}
                      className="flex-1 py-2 px-3 text-xs font-semibold text-white bg-zinc-900 border border-white/15 hover:border-[#da251c] hover:bg-[#da251c] rounded transition-all cursor-pointer text-center"
                    >
                      Brand Story & Notes
                    </button>
                    <button
                      onClick={() => onInspectBrandSql(brand)}
                      className="p-2 text-zinc-400 hover:text-white hover:bg-white/10 border border-white/10 rounded transition-colors cursor-pointer"
                      title="Inspect MySQL Row & Query"
                      aria-label="Inspect MySQL database record"
                    >
                      <Database className="w-3.5 h-3.5 text-emerald-400" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
