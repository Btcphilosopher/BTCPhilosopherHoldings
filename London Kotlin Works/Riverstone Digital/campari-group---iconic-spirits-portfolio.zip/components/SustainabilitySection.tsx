'use client';

import React from 'react';
import { SUSTAINABILITY_PILLARS } from '@/lib/campari-data';
import { Leaf, Users, ShieldCheck, HeartHandshake, CheckCircle2 } from 'lucide-react';

export default function SustainabilitySection() {
  const icons = [Users, Leaf, ShieldCheck, HeartHandshake];

  return (
    <section id="sustainability" className="w-full bg-[#08080a] py-20 px-6 border-b border-white/10">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <div className="text-xs font-semibold tracking-[0.25em] text-emerald-400 uppercase mb-2">
            SUSTAINABILITY & ESG ROADMAP
          </div>
          <h2
            className="text-3xl md:text-5xl font-serif text-white tracking-tight mb-4"
            style={{ fontFamily: 'Cormorant Garamond, Georgia, serif' }}
          >
            Nurturing Our Terroir and People
          </h2>
          <p className="text-sm md:text-base text-zinc-300 font-light leading-relaxed">
            Sustainability at Campari Group is rooted in respecting the land where our ingredients flourish, empowering the communities we touch, and advocating for mindful, responsible drinking.
          </p>
        </div>

        {/* 4 ESG Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {SUSTAINABILITY_PILLARS.map((pillar, idx) => {
            const Icon = icons[idx % icons.length];
            return (
              <div
                key={pillar.id}
                className="bg-[#121216] border border-white/10 hover:border-emerald-500/30 rounded-xl p-6 sm:p-8 flex flex-col justify-between transition-all duration-300"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-800/40 text-emerald-400">
                        <Icon className="w-5 h-5" />
                      </div>
                      <span className="text-xs font-mono text-zinc-400 uppercase tracking-wider">
                        {pillar.sdg_alignment}
                      </span>
                    </div>
                    <span className="text-xs font-mono font-semibold text-emerald-400 bg-emerald-950/50 px-2.5 py-1 rounded border border-emerald-800/30">
                      {pillar.metric}
                    </span>
                  </div>

                  <h3 className="text-xl font-serif text-white mb-2" style={{ fontFamily: 'Cormorant Garamond, Georgia, serif' }}>
                    {pillar.title}
                  </h3>
                  <div className="text-xs text-zinc-400 font-medium mb-3">
                    {pillar.focus}
                  </div>
                  <p className="text-xs text-zinc-300 font-light leading-relaxed">
                    {pillar.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Commitments Bar */}
        <div className="mt-12 p-6 bg-[#121216] border border-white/10 rounded-xl grid grid-cols-1 sm:grid-cols-3 gap-6 text-xs">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span className="text-zinc-300">100% Recyclable Packaging Goal across spirits bottles</span>
          </div>
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span className="text-zinc-300">Net Zero Carbon Operations Roadmap targeting 2050</span>
          </div>
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span className="text-zinc-300">Zero Plastic Straws & Bar Ware globally since 2018</span>
          </div>
        </div>
      </div>
    </section>
  );
}
