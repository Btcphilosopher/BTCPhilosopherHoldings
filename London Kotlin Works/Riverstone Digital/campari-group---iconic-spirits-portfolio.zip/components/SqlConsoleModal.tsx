'use client';

import React, { useState } from 'react';
import {
  MYSQL_SCHEMA_SQL,
  PHP_DB_CONNECT_CODE,
  PHP_BRANDS_API_CODE,
  executeSimulatedQuery,
  Brand,
} from '@/lib/campari-data';
import {
  X,
  Database,
  Terminal,
  FileCode,
  Play,
  Copy,
  Check,
  RotateCcw,
  Clock,
  Table as TableIcon,
  Server,
} from 'lucide-react';

interface SqlConsoleModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialQuery?: string;
}

export default function SqlConsoleModal({
  isOpen,
  onClose,
  initialQuery,
}: SqlConsoleModalProps) {
  const defaultQuery =
    initialQuery ||
    "SELECT id, name, category, tier, origin_country, founded_year, abv, signature_cocktail FROM brands WHERE tier = 'Global Priority' ORDER BY founded_year ASC;";

  const [activeTab, setActiveTab] = useState<'console' | 'schema' | 'php'>('console');
  const [currentSql, setCurrentSql] = useState<string>(defaultQuery);
  const [copied, setCopied] = useState<boolean>(false);
  const [isRunning, setIsRunning] = useState<boolean>(false);

  // Initial query execution state
  const [queryResult, setQueryResult] = useState(() =>
    executeSimulatedQuery(defaultQuery)
  );

  if (!isOpen) return null;

  const handleRunQuery = async (sqlToRun?: string) => {
    const query = sqlToRun || currentSql;
    setIsRunning(true);
    try {
      const res = await fetch('/api/mysql/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sql: query }),
      });
      const data = await res.json();
      if (data.columns && data.rows) {
        setQueryResult({
          columns: data.columns,
          rows: data.rows,
          rowCount: data.rowCount,
          executionMs: data.executionMs,
          query: data.query,
        });
      } else {
        // Fallback local runner
        setQueryResult(executeSimulatedQuery(query));
      }
    } catch {
      setQueryResult(executeSimulatedQuery(query));
    } finally {
      setIsRunning(false);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const presetQueries = [
    {
      title: 'Global Priority Spirits',
      sql: "SELECT id, name, category, tier, origin_country, founded_year, abv, signature_cocktail FROM brands WHERE tier = 'Global Priority' ORDER BY founded_year ASC;",
    },
    {
      title: 'Italian Aperitifs & Bitters',
      sql: "SELECT id, name, category, tier, origin_country, founded_year, abv, signature_cocktail FROM brands WHERE category = 'Aperitifs & Bitters' ORDER BY founded_year ASC;",
    },
    {
      title: 'High Proof Spirits (ABV > 40%)',
      sql: 'SELECT id, name, category, tier, origin_country, founded_year, abv, signature_cocktail FROM brands WHERE abv > 40 ORDER BY abv DESC;',
    },
    {
      title: 'All Signature Cocktails',
      sql: 'SELECT id, name, brand, glassware, difficulty, occasion, garnish FROM cocktails ORDER BY name ASC;',
    },
    {
      title: 'Brand Categories Taxonomy',
      sql: 'SELECT id, name, slug, spirit_count, description FROM categories ORDER BY id ASC;',
    },
    {
      title: 'Sustainability ESG Initiatives',
      sql: 'SELECT id, title, metric, focus, sdg FROM sustainability ORDER BY id ASC;',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-5xl h-[88vh] bg-[#0c0c0e] border border-white/20 rounded-2xl shadow-2xl flex flex-col overflow-hidden text-left"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header Bar */}
        <div className="px-6 py-4 bg-[#141418] border-b border-white/10 flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded bg-emerald-950/60 border border-emerald-800/40 text-emerald-400">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-serif font-bold text-white tracking-wide">
                  Campari Group MySQL & PHP Backend Hub
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  ONLINE
                </span>
              </div>
              <div className="text-xs text-zinc-400 font-mono">
                Engine: MySQL 8.0 (InnoDB) · API: PHP 8.2 PDO · Host: 127.0.0.1:3306
              </div>
            </div>
          </div>

          {/* Close button */}
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer"
            aria-label="Close SQL Console"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Controls Bar */}
        <div className="px-6 py-2.5 bg-[#101014] border-b border-white/10 flex items-center justify-between gap-4 shrink-0 overflow-x-auto">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('console')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                activeTab === 'console'
                  ? 'bg-[#da251c] text-white shadow-sm'
                  : 'text-zinc-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>Interactive SQL Query Runner</span>
            </button>
            <button
              onClick={() => setActiveTab('schema')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                activeTab === 'schema'
                  ? 'bg-[#da251c] text-white shadow-sm'
                  : 'text-zinc-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <TableIcon className="w-3.5 h-3.5" />
              <span>MySQL Relational DDL Schema</span>
            </button>
            <button
              onClick={() => setActiveTab('php')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                activeTab === 'php'
                  ? 'bg-[#da251c] text-white shadow-sm'
                  : 'text-zinc-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Server className="w-3.5 h-3.5" />
              <span>PHP 8.2 REST API Controller</span>
            </button>
          </div>
        </div>

        {/* Tab 1: Interactive SQL Query Runner */}
        {activeTab === 'console' && (
          <div className="flex-1 flex flex-col p-6 overflow-y-auto space-y-5">
            {/* Presets Row */}
            <div>
              <div className="text-[11px] font-semibold uppercase tracking-wider text-zinc-400 mb-2">
                Click a Query Preset or Type Custom SQL:
              </div>
              <div className="flex flex-wrap gap-2">
                {presetQueries.map((preset, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setCurrentSql(preset.sql);
                      handleRunQuery(preset.sql);
                    }}
                    className="text-xs font-mono px-3 py-1.5 rounded bg-white/5 hover:bg-white/10 text-zinc-300 hover:text-white border border-white/5 transition-colors cursor-pointer"
                  >
                    {preset.title}
                  </button>
                ))}
              </div>
            </div>

            {/* SQL Editor Box */}
            <div className="bg-[#08080a] border border-white/10 rounded-xl overflow-hidden">
              <div className="flex items-center justify-between px-4 py-2 bg-white/5 border-b border-white/5 text-xs text-zinc-400 font-mono">
                <span className="flex items-center gap-2">
                  <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                  <span>SQL Query Editor (`campari_group_db`)</span>
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setCurrentSql(defaultQuery)}
                    className="text-[11px] text-zinc-400 hover:text-white flex items-center gap-1 cursor-pointer"
                  >
                    <RotateCcw className="w-3 h-3" />
                    Reset
                  </button>
                </div>
              </div>
              <div className="p-3">
                <textarea
                  value={currentSql}
                  onChange={(e) => setCurrentSql(e.target.value)}
                  rows={3}
                  className="w-full bg-transparent font-mono text-xs sm:text-sm text-emerald-300 placeholder-zinc-600 focus:outline-none resize-none leading-relaxed"
                  placeholder="SELECT * FROM brands WHERE ..."
                />
              </div>
              <div className="px-4 py-2.5 bg-white/5 border-t border-white/5 flex items-center justify-between gap-4">
                <span className="text-[11px] text-zinc-500 font-mono">
                  Press &apos;Execute Query&apos; to run on MySQL InnoDB engine
                </span>
                <button
                  onClick={() => handleRunQuery()}
                  disabled={isRunning}
                  className="flex items-center gap-2 px-4 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold tracking-wide transition-colors cursor-pointer disabled:opacity-50"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>{isRunning ? 'Executing...' : 'Execute Query'}</span>
                </button>
              </div>
            </div>

            {/* Query Performance & Meta */}
            <div className="flex items-center justify-between text-xs font-mono text-zinc-400 px-1">
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1.5 text-emerald-400">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Execution time: {queryResult.executionMs} ms</span>
                </span>
                <span>Rows returned: <strong className="text-white">{queryResult.rowCount}</strong></span>
              </div>
              <span className="hidden sm:inline text-zinc-500">Charset: utf8mb4_unicode_ci</span>
            </div>

            {/* Results Table */}
            <div className="flex-1 min-h-[220px] bg-[#08080a] border border-white/10 rounded-xl overflow-hidden flex flex-col">
              <div className="overflow-x-auto flex-1">
                <table className="w-full text-left text-xs font-mono">
                  <thead>
                    <tr className="bg-white/5 border-b border-white/10 text-zinc-400 uppercase text-[10px] tracking-wider">
                      {queryResult.columns.map((col) => (
                        <th key={col} className="px-4 py-3 font-semibold whitespace-nowrap">
                          {col}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {queryResult.rows.map((row, rowIdx) => (
                      <tr
                        key={rowIdx}
                        className="hover:bg-white/[0.03] transition-colors"
                      >
                        {queryResult.columns.map((col) => (
                          <td
                            key={col}
                            className="px-4 py-2.5 text-zinc-300 whitespace-nowrap max-w-xs truncate"
                          >
                            {String(row[col] ?? '')}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: MySQL Relational DDL Schema */}
        {activeTab === 'schema' && (
          <div className="flex-1 p-6 overflow-y-auto space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-semibold text-white">
                  MySQL 8.0 Relational DDL Specification
                </h4>
                <p className="text-xs text-zinc-400">
                  Foreign key integrity between categories, brands, and cocktails with InnoDB indexing.
                </p>
              </div>
              <button
                onClick={() => handleCopy(MYSQL_SCHEMA_SQL)}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy DDL'}</span>
              </button>
            </div>
            <pre className="p-4 bg-[#08080a] border border-white/10 rounded-xl font-mono text-xs text-emerald-300/90 overflow-x-auto leading-relaxed">
              <code>{MYSQL_SCHEMA_SQL}</code>
            </pre>
          </div>
        )}

        {/* Tab 3: PHP 8.2 REST API Controller */}
        {activeTab === 'php' && (
          <div className="flex-1 p-6 overflow-y-auto space-y-6">
            <div>
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h4 className="text-sm font-semibold text-white flex items-center gap-2">
                    <FileCode className="w-4 h-4 text-[#da251c]" />
                    <span>api/v1/brands.php (PHP 8.2 Controller)</span>
                  </h4>
                  <p className="text-xs text-zinc-400">
                    Production REST endpoint with PDO prepared statements and dynamic category joins.
                  </p>
                </div>
                <button
                  onClick={() => handleCopy(PHP_BRANDS_API_CODE)}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy PHP'}</span>
                </button>
              </div>
              <pre className="p-4 bg-[#08080a] border border-white/10 rounded-xl font-mono text-xs text-sky-300/90 overflow-x-auto leading-relaxed">
                <code>{PHP_BRANDS_API_CODE}</code>
              </pre>
            </div>

            <div>
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h4 className="text-sm font-semibold text-white flex items-center gap-2">
                    <FileCode className="w-4 h-4 text-amber-500" />
                    <span>config/db_connect.php (MySQL PDO Singleton)</span>
                  </h4>
                  <p className="text-xs text-zinc-400">
                    Thread-safe PDO singleton with UTF8mb4 charset and error handling.
                  </p>
                </div>
                <button
                  onClick={() => handleCopy(PHP_DB_CONNECT_CODE)}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
              <pre className="p-4 bg-[#08080a] border border-white/10 rounded-xl font-mono text-xs text-amber-300/90 overflow-x-auto leading-relaxed">
                <code>{PHP_DB_CONNECT_CODE}</code>
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
