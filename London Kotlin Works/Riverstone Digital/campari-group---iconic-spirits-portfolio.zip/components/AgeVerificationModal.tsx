'use client';

import React, { useSyncExternalStore } from 'react';
import { ShieldAlert } from 'lucide-react';

function subscribe(callback: () => void) {
  window.addEventListener('storage', callback);
  return () => window.removeEventListener('storage', callback);
}

function getSnapshot() {
  if (typeof window === 'undefined') return true;
  return sessionStorage.getItem('campari_age_verified') === 'true';
}

function getServerSnapshot() {
  return true;
}

export default function AgeVerificationModal() {
  const isVerified = useSyncExternalStore(
    subscribe,
    getSnapshot,
    getServerSnapshot
  );

  const handleConfirmAge = () => {
    sessionStorage.setItem('campari_age_verified', 'true');
    window.dispatchEvent(new Event('storage'));
  };

  const handleDecline = () => {
    window.location.href = 'https://www.responsibility.org';
  };

  if (isVerified) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-300">
      <div className="relative w-full max-w-md bg-[#121216] border border-white/20 rounded-2xl p-8 text-center shadow-2xl">
        {/* Wordmark */}
        <h2
          className="text-2xl font-bold tracking-[0.25em] text-white mb-2"
          style={{ fontFamily: 'Cinzel, Georgia, serif' }}
        >
          CAMPARI GROUP
        </h2>
        <div className="text-[11px] font-mono tracking-widest text-[#da251c] uppercase mb-6">
          Iconic Brands. A Brighter Tomorrow.
        </div>

        <div className="p-3 rounded-full bg-white/5 w-12 h-12 flex items-center justify-center mx-auto mb-4 text-zinc-300">
          <ShieldAlert className="w-6 h-6 text-[#da251c]" />
        </div>

        <h3 className="text-lg font-serif text-white mb-2" style={{ fontFamily: 'Cormorant Garamond, Georgia, serif' }}>
          Age Verification
        </h3>
        <p className="text-xs text-zinc-300 leading-relaxed font-light mb-8">
          To enter the Campari Group website, you must be of legal purchase age for alcohol in your country of residence.
        </p>

        <div className="space-y-3">
          <button
            onClick={handleConfirmAge}
            className="w-full py-3 px-4 rounded bg-[#da251c] hover:bg-[#b51c14] text-white text-xs font-semibold tracking-widest uppercase transition-colors cursor-pointer shadow-lg shadow-[#da251c]/25"
          >
            I am of legal drinking age
          </button>
          <button
            onClick={handleDecline}
            className="w-full py-2.5 px-4 rounded bg-transparent hover:bg-white/5 text-zinc-400 hover:text-white text-xs tracking-wider transition-colors cursor-pointer"
          >
            I am not of legal age
          </button>
        </div>

        <div className="mt-6 pt-6 border-t border-white/10 text-[10px] text-zinc-500">
          By entering this website, you agree to our Terms of Use and Privacy Policy. Campari Group supports responsible drinking.
        </div>
      </div>
    </div>
  );
}
