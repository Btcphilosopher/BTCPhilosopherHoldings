'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';

interface HeroProps {
  onDiscoverClick: () => void;
}

export default function Hero({ onDiscoverClick }: HeroProps) {
  return (
    <section id="hero" className="relative w-full min-h-[90vh] md:min-h-[92vh] flex items-center justify-start overflow-hidden bg-black">
      {/* Background Hero Asset provided by user */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/assets/aistudio/Campari_Group_b11f5c40.png"
          alt="Campari Group iconic spirits sunset terrace over Rome with Campari bottle and spritz"
          fill
          priority
          sizes="100vw"
          className="object-cover object-center md:object-right"
          referrerPolicy="no-referrer"
        />
        {/* Cinematic gradient scrims ensuring WCAG AA contrast for text on photography */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/60 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0c0c0e] via-transparent to-black/30" />
      </div>

      {/* Content Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 py-20 w-full">
        <div className="max-w-2xl">
          {/* Subtle unboxed kicker metadata */}
          <div className="text-xs md:text-sm font-semibold tracking-[0.25em] text-zinc-300 uppercase mb-4">
            ICONIC BRANDS. A BRIGHTER TOMORROW.
          </div>

          {/* Main Headline */}
          <h1
            className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-serif text-white leading-[1.08] tracking-tight mb-6"
            style={{ fontFamily: 'Cormorant Garamond, Georgia, serif', textWrap: 'balance' }}
          >
            Campari Group.
            <br />
            The world’s most
            <br />
            iconic spirits company.
          </h1>

          {/* Subheading prose */}
          <p className="text-base sm:text-lg text-zinc-300 leading-relaxed font-light mb-10 max-w-xl">
            We bring people together through extraordinary brands, creating moments of pleasure, connection and celebration across the globe.
          </p>

          {/* Clean text CTA with arrow */}
          <div className="flex flex-wrap items-center gap-6">
            <button
              onClick={onDiscoverClick}
              className="group inline-flex items-center gap-3 text-sm font-semibold tracking-[0.2em] uppercase text-white hover:text-[#da251c] transition-all cursor-pointer pb-1 border-b-2 border-white hover:border-[#da251c]"
            >
              <span>DISCOVER OUR BRANDS</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1.5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
