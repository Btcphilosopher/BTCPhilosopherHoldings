'use client';

import React, { useState } from 'react';
import { Search, Database, Globe, ChevronDown, Menu, X } from 'lucide-react';

interface HeaderProps {
  onOpenSearch: () => void;
  onOpenSqlConsole: () => void;
  onNavigateSection: (sectionId: string) => void;
}

export default function Header({
  onOpenSearch,
  onOpenSqlConsole,
  onNavigateSection,
}: HeaderProps) {
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const [currentLang, setCurrentLang] = useState('EN');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const languages = ['EN', 'IT', 'FR', 'DE', 'ES'];

  const handleNavClick = (id: string) => {
    onNavigateSection(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0c0c0e]/95 backdrop-blur-md border-b border-white/10 transition-colors">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark (Single text element in classic tracked uppercase) */}
        <a
          href="#hero"
          onClick={(e) => {
            e.preventDefault();
            handleNavClick('hero');
          }}
          className="text-xl md:text-2xl font-bold tracking-[0.22em] text-white whitespace-nowrap shrink-0 hover:text-[#da251c] transition-colors"
          style={{ fontFamily: 'Cinzel, Georgia, serif' }}
        >
          CAMPARI GROUP
        </a>

        {/* Zone 2: 4–5 clean single-line navigation links */}
        <nav className="hidden lg:flex items-center gap-8 text-xs tracking-[0.16em] uppercase font-medium text-zinc-300">
          <button
            onClick={() => handleNavClick('portfolio')}
            className="hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0 py-1"
          >
            Our Brands
          </button>
          <button
            onClick={() => handleNavClick('story')}
            className="hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0 py-1"
          >
            Our Story
          </button>
          <button
            onClick={() => handleNavClick('sustainability')}
            className="hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0 py-1"
          >
            Sustainability
          </button>
          <button
            onClick={() => handleNavClick('investors')}
            className="hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0 py-1"
          >
            Investors
          </button>
          <button
            onClick={() => handleNavClick('cocktail-studio')}
            className="hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0 py-1"
          >
            Cocktail Studio
          </button>
        </nav>

        {/* Zone 3: Primary Action & Utilities */}
        <div className="flex items-center gap-3 md:gap-4 shrink-0">
          {/* Quick Search */}
          <button
            onClick={onOpenSearch}
            className="p-2 text-zinc-300 hover:text-white hover:bg-white/5 rounded-full transition-colors cursor-pointer"
            aria-label="Search brands and cocktails"
            title="Search portfolio"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Language Switcher Dropdown */}
          <div className="relative">
            <button
              onClick={() => setLangMenuOpen(!langMenuOpen)}
              className="flex items-center gap-1.5 text-xs font-semibold tracking-wider text-zinc-300 hover:text-white px-2 py-1.5 rounded hover:bg-white/5 transition-colors cursor-pointer"
            >
              <Globe className="w-3.5 h-3.5 text-zinc-400" />
              <span>{currentLang}</span>
              <ChevronDown className="w-3 h-3 text-zinc-400" />
            </button>

            {langMenuOpen && (
              <div className="absolute right-0 mt-2 w-28 bg-[#18181b] border border-white/10 rounded-md shadow-xl py-1 z-50">
                {languages.map((lang) => (
                  <button
                    key={lang}
                    onClick={() => {
                      setCurrentLang(lang);
                      setLangMenuOpen(false);
                    }}
                    className={`w-full text-left px-3 py-1.5 text-xs tracking-wider transition-colors cursor-pointer ${
                      currentLang === lang
                        ? 'bg-[#da251c] text-white font-semibold'
                        : 'text-zinc-300 hover:bg-white/10 hover:text-white'
                    }`}
                  >
                    {lang === 'EN' && 'English (EN)'}
                    {lang === 'IT' && 'Italiano (IT)'}
                    {lang === 'FR' && 'Français (FR)'}
                    {lang === 'DE' && 'Deutsch (DE)'}
                    {lang === 'ES' && 'Español (ES)'}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* MySQL & PHP Hub Primary Action */}
          <button
            onClick={onOpenSqlConsole}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold tracking-wider text-white bg-zinc-900 border border-zinc-700 hover:border-[#da251c] hover:bg-[#da251c]/10 rounded transition-all cursor-pointer whitespace-nowrap shrink-0 shadow-sm"
          >
            <Database className="w-3.5 h-3.5 text-[#da251c]" />
            <span className="hidden sm:inline">MySQL & PHP Hub</span>
            <span className="sm:hidden">DB Hub</span>
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-zinc-300 hover:text-white"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#121215] border-b border-white/10 px-6 py-6 flex flex-col gap-4 text-xs tracking-widest uppercase">
          <button
            onClick={() => handleNavClick('portfolio')}
            className="text-left py-2 text-zinc-300 hover:text-white border-b border-white/5"
          >
            Our Brands
          </button>
          <button
            onClick={() => handleNavClick('story')}
            className="text-left py-2 text-zinc-300 hover:text-white border-b border-white/5"
          >
            Our Story
          </button>
          <button
            onClick={() => handleNavClick('sustainability')}
            className="text-left py-2 text-zinc-300 hover:text-white border-b border-white/5"
          >
            Sustainability
          </button>
          <button
            onClick={() => handleNavClick('investors')}
            className="text-left py-2 text-zinc-300 hover:text-white border-b border-white/5"
          >
            Investors
          </button>
          <button
            onClick={() => handleNavClick('cocktail-studio')}
            className="text-left py-2 text-zinc-300 hover:text-white"
          >
            Cocktail Studio
          </button>
        </div>
      )}
    </header>
  );
}
