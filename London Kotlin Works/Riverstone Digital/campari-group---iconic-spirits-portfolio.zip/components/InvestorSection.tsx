'use client';

import React from 'react';
import { INVESTOR_METRICS } from '@/lib/campari-data';
import { TrendingUp, FileText, ExternalLink, PieChart } from 'lucide-react';

export default function InvestorSection() {
  const regions = [
    { name: 'Americas (US, Jamaica, Brazil, Canada, Mexico)', share: '44%', color: '#da251c' },
    { name: 'Southern Europe, Middle East & Africa (Italy core)', share: '28%', color: '#ea580c' },
    { name: 'North, Central & Eastern Europe (Germany, UK, France)', share: '19%', color: '#0284c7' },
    { name: 'Asia-Pacific (Australia, China, Japan, India)', share: '9%', color: '#10b981' },
  ];

  return (
    <section id="investors" className="w-full bg-[#0c0c0e] py-20 px-6 border-b border-white/10">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div>
            <div className="text-xs font-semibold tracking-[0.25em] text-[#38bdf8] uppercase mb-2">
              INVESTOR RELATIONS · BORSA ITALIANA: CPR.MI
            </div>
            <h2
              className="text-3xl md:text-5xl font-serif text-white tracking-tight"
              style={{ fontFamily: 'Cormorant Garamond, Georgia, serif' }}
            >
              Sustainable Long-Term Value Creation
            </h2>
          </div>
          <div className="flex items-center gap-4 text-xs font-mono text-zinc-400">
            <span>ISIN: NL0015435975</span>
            <span aria-hidden="true">·</span>
            <span>HQ: Milan, Italy</span>
          </div>
        </div>

        {/* 4 Financial Key Metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {INVESTOR_METRICS.map((metric, idx) => (
            <div
              key={idx}
              className="bg-[#121216] border border-white/10 rounded-xl p-6 flex flex-col justify-between"
            >
              <div>
                <span className="text-[11px] uppercase tracking-wider text-zinc-400 font-medium block mb-2">
                  {metric.label}
                </span>
                <div className="text-3xl font-serif font-bold text-white mb-2" style={{ fontFamily: 'Cormorant Garamond, Georgia, serif' }}>
                  {metric.value}
                </div>
                <div className="text-xs font-mono font-medium text-emerald-400 flex items-center gap-1.5 mb-3">
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>{metric.change}</span>
                </div>
              </div>
              <div className="text-[11px] text-zinc-400 font-light border-t border-white/5 pt-3">
                {metric.description}
              </div>
            </div>
          ))}
        </div>

        {/* Geographic Sales Breakdown & Reports */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Sales by Geography */}
          <div className="lg:col-span-7 bg-[#121216] border border-white/10 rounded-2xl p-6 sm:p-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-serif text-white flex items-center gap-2" style={{ fontFamily: 'Cormorant Garamond, Georgia, serif' }}>
                <PieChart className="w-5 h-5 text-[#38bdf8]" />
                Net Sales Geographic Contribution
              </h3>
              <span className="text-xs font-mono text-zinc-400">190+ Markets</span>
            </div>

            <div className="space-y-4">
              {regions.map((reg) => (
                <div key={reg.name} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-zinc-300">{reg.name}</span>
                    <span className="font-mono font-bold text-white tabular-nums">{reg.share}</span>
                  </div>
                  <div className="w-full h-2 bg-black/40 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{ width: reg.share, backgroundColor: reg.color }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Investor Resources & Governance */}
          <div className="lg:col-span-5 bg-[#121216] border border-white/10 rounded-2xl p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <h3 className="text-xl font-serif text-white mb-4" style={{ fontFamily: 'Cormorant Garamond, Georgia, serif' }}>
                Financial Publications & Governance
              </h3>
              <p className="text-xs text-zinc-300 font-light leading-relaxed mb-6">
                Access official financial statements, annual integrated reports, quarterly corporate presentations, and shareholder meeting agendas.
              </p>

              <div className="space-y-2.5">
                {[
                  'Annual Integrated Report & Consolidated Financial Statements',
                  'Quarterly Interim Financial Performance Presentation',
                  'Remuneration and Corporate Governance Report',
                  'Universal Registration Document (URD)',
                ].map((doc, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between p-3 rounded-lg bg-white/5 border border-white/5 text-xs text-zinc-300"
                  >
                    <div className="flex items-center gap-2.5 truncate pr-2">
                      <FileText className="w-4 h-4 text-[#da251c] shrink-0" />
                      <span className="truncate">{doc}</span>
                    </div>
                    <span className="text-[10px] font-mono text-zinc-400 shrink-0 uppercase">PDF</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between text-xs text-zinc-400">
              <span>Financial Year End: Dec 31</span>
              <a
                href="https://www.camparigroup.com"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 text-zinc-200 hover:text-white"
              >
                <span>Investor Center</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
