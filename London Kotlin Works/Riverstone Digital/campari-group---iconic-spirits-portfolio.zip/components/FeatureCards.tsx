'use client';

import React from 'react';
import { ArrowRight } from 'lucide-react';

interface FeatureCardsProps {
  onSelectFeature: (featureId: string) => void;
}

export default function FeatureCards({ onSelectFeature }: FeatureCardsProps) {
  const cards = [
    {
      id: 'portfolio',
      title: 'Our Brands',
      subtitle: 'Global, regional and local priorities',
      bgGradient: 'from-[#500000] via-[#2a0505] to-[#0e0202]',
      accentBorder: 'hover:border-[#da251c]/60',
      tag: 'Spirits Portfolio',
      visualElement: (
        <div className="absolute inset-0 opacity-40 mix-blend-screen bg-[radial-gradient(circle_at_70%_80%,#ff1100_0%,transparent_60%)] pointer-events-none" />
      ),
    },
    {
      id: 'story',
      title: 'Our Story',
      subtitle: 'From Milan 1860 to global icon',
      bgGradient: 'from-[#3b2110] via-[#1c1109] to-[#0c0806]',
      accentBorder: 'hover:border-[#d97706]/60',
      tag: 'Heritage & Art',
      visualElement: (
        <div className="absolute inset-0 opacity-30 mix-blend-screen bg-[radial-gradient(circle_at_60%_30%,#f59e0b_0%,transparent_60%)] pointer-events-none" />
      ),
    },
    {
      id: 'sustainability',
      title: 'Sustainability',
      subtitle: 'Environment, people and responsible drinking',
      bgGradient: 'from-[#14301e] via-[#0b1b11] to-[#050e09]',
      accentBorder: 'hover:border-[#10b981]/60',
      tag: 'ESG Roadmap',
      visualElement: (
        <div className="absolute inset-0 opacity-30 mix-blend-screen bg-[radial-gradient(circle_at_50%_70%,#10b981_0%,transparent_60%)] pointer-events-none" />
      ),
    },
    {
      id: 'investors',
      title: 'Investors',
      subtitle: 'Financial results, governance & reports',
      bgGradient: 'from-[#18233c] via-[#0c1322] to-[#060a12]',
      accentBorder: 'hover:border-[#38bdf8]/60',
      tag: 'CPR.MI Milan',
      visualElement: (
        <div className="absolute inset-0 opacity-30 mix-blend-screen bg-[radial-gradient(circle_at_80%_40%,#38bdf8_0%,transparent_60%)] pointer-events-none" />
      ),
    },
  ];

  return (
    <section className="w-full bg-[#0c0c0e] pt-6 pb-12 border-b border-white/10">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5">
          {cards.map((card) => (
            <button
              key={card.id}
              onClick={() => onSelectFeature(card.id)}
              className={`group relative h-64 md:h-72 w-full rounded-lg overflow-hidden bg-gradient-to-br ${card.bgGradient} p-6 flex flex-col justify-end text-left border border-white/10 ${card.accentBorder} transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl cursor-pointer`}
            >
              {card.visualElement}

              {/* Subtle top metadata */}
              <div className="absolute top-5 left-6 text-[11px] font-semibold tracking-[0.2em] text-zinc-400 uppercase">
                {card.tag}
              </div>

              {/* Title & Arrow matching attachment layout */}
              <div className="relative z-10">
                <div className="flex items-center justify-between gap-3 mb-1">
                  <h3
                    className="text-2xl md:text-3xl font-serif text-white group-hover:text-[#f4f4f5] transition-colors"
                    style={{ fontFamily: 'Cormorant Garamond, Georgia, serif' }}
                  >
                    {card.title}
                  </h3>
                  <ArrowRight className="w-4 h-4 text-zinc-400 group-hover:text-white group-hover:translate-x-1.5 transition-all shrink-0" />
                </div>
                <p className="text-xs text-zinc-400 line-clamp-1 font-light">
                  {card.subtitle}
                </p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
