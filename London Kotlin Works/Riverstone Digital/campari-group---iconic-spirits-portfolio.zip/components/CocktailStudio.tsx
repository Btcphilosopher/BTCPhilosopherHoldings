'use client';

import React, { useState } from 'react';
import { COCKTAILS, Cocktail } from '@/lib/campari-data';
import { GlassWater, Users, Sparkles, BookOpen } from 'lucide-react';

interface CocktailStudioProps {
  initialCocktailName?: string;
}

export default function CocktailStudio({ initialCocktailName }: CocktailStudioProps) {
  const initial = initialCocktailName
    ? COCKTAILS.find((c) => c.name.toLowerCase() === initialCocktailName.toLowerCase()) || COCKTAILS[0]
    : COCKTAILS[0];

  const [activeCocktail, setActiveCocktail] = useState<Cocktail>(initial);
  const [servings, setServings] = useState<number>(1);
  const [unitMode, setUnitMode] = useState<'ml' | 'oz'>('ml');

  // Convert measurement based on servings
  const formatAmount = (baseAmount: string) => {
    const num = parseFloat(baseAmount);
    if (isNaN(num)) return baseAmount;

    let multiplied = num * servings;
    if (unitMode === 'oz') {
      // 30ml is approximately 1 oz
      multiplied = Math.round((multiplied / 30) * 10) / 10;
      return `${multiplied} oz`;
    }
    return `${multiplied} ml`;
  };

  return (
    <section id="cocktail-studio" className="w-full bg-[#08080a] py-20 px-6 border-b border-white/10">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="text-xs font-semibold tracking-[0.25em] text-[#da251c] uppercase mb-2">
              THE CAMPARI ACADEMY
            </div>
            <h2
              className="text-3xl md:text-5xl font-serif text-white tracking-tight"
              style={{ fontFamily: 'Cormorant Garamond, Georgia, serif' }}
            >
              Cocktail Mastery & Mixology
            </h2>
          </div>
          <p className="text-sm text-zinc-400 max-w-md font-light leading-relaxed">
            From the birthplace of the Negroni in 1919 to the worldwide Aperol Spritz ritual, explore authentic recipes crafted by our master mixologists.
          </p>
        </div>

        {/* Cocktail Selector Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 scrollbar-none border-b border-white/10">
          {COCKTAILS.map((cocktail) => (
            <button
              key={cocktail.id}
              onClick={() => {
                setActiveCocktail(cocktail);
                setServings(1);
              }}
              className={`px-4 py-2.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer flex items-center gap-2 ${
                activeCocktail.id === cocktail.id
                  ? 'bg-[#da251c] text-white shadow-lg shadow-[#da251c]/20'
                  : 'bg-[#121216] text-zinc-400 hover:text-white hover:bg-white/10 border border-white/5'
              }`}
            >
              <GlassWater className="w-3.5 h-3.5" />
              <span>{cocktail.name}</span>
            </button>
          ))}
        </div>

        {/* Active Cocktail Showcase Deck */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 bg-[#121216] border border-white/10 rounded-2xl p-6 sm:p-10">
          {/* Left Column: Specs & Story (5 cols) */}
          <div className="lg:col-span-5 space-y-6 lg:border-r lg:border-white/10 lg:pr-8">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold tracking-wider text-[#da251c] uppercase mb-1">
                <span>{activeCocktail.brand_name} Spirit Base</span>
                <span className="text-zinc-600">·</span>
                <span className="text-zinc-400">{activeCocktail.difficulty} Difficulty</span>
              </div>
              <h3
                className="text-3xl sm:text-4xl font-serif text-white mb-2"
                style={{ fontFamily: 'Cormorant Garamond, Georgia, serif' }}
              >
                {activeCocktail.name}
              </h3>
              <p className="text-sm text-zinc-300 font-light italic leading-relaxed">
                {activeCocktail.tagline}
              </p>
            </div>

            {/* Serving Occasion & Glassware */}
            <div className="grid grid-cols-2 gap-4 text-xs py-4 border-y border-white/10">
              <div>
                <span className="text-[10px] uppercase tracking-wider text-zinc-400 font-medium block mb-1">
                  Recommended Glass
                </span>
                <span className="text-zinc-200 font-medium">{activeCocktail.glassware}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase tracking-wider text-zinc-400 font-medium block mb-1">
                  Occasion
                </span>
                <span className="text-zinc-200 font-medium">{activeCocktail.occasion}</span>
              </div>
            </div>

            {/* Garnish Callout */}
            <div className="bg-[#0c0c0e] p-4 rounded-xl border border-white/5">
              <span className="text-[10px] uppercase tracking-wider text-amber-400 font-medium block mb-1 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                Bartender Garnish
              </span>
              <p className="text-xs text-zinc-300">{activeCocktail.garnish}</p>
            </div>

            {/* Origin & Historical Heritage */}
            <div>
              <span className="text-xs uppercase tracking-wider text-zinc-400 font-semibold block mb-2 flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5 text-zinc-400" />
                Historic Provenance
              </span>
              <p className="text-xs text-zinc-300 font-light leading-relaxed">
                {activeCocktail.history}
              </p>
            </div>
          </div>

          {/* Right Column: Interactive Recipe & Mixology Steps (7 cols) */}
          <div className="lg:col-span-7 space-y-8">
            {/* Serving Controls Bar */}
            <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-[#0c0c0e] rounded-xl border border-white/10">
              {/* Servings Multiplier */}
              <div className="flex items-center gap-3">
                <span className="text-xs text-zinc-400 flex items-center gap-1.5 font-medium">
                  <Users className="w-3.5 h-3.5 text-zinc-400" />
                  Servings:
                </span>
                <div className="flex items-center gap-1">
                  {[1, 2, 4, 8].map((s) => (
                    <button
                      key={s}
                      onClick={() => setServings(s)}
                      className={`w-8 h-8 rounded text-xs font-mono font-semibold transition-colors cursor-pointer ${
                        servings === s
                          ? 'bg-[#da251c] text-white'
                          : 'bg-white/5 text-zinc-400 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              {/* Units Toggle */}
              <div className="flex items-center gap-1 bg-[#121216] p-1 rounded-lg border border-white/5">
                <button
                  onClick={() => setUnitMode('ml')}
                  className={`px-3 py-1 text-[11px] font-semibold rounded cursor-pointer transition-colors ${
                    unitMode === 'ml' ? 'bg-white text-zinc-950' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  Metric (ml)
                </button>
                <button
                  onClick={() => setUnitMode('oz')}
                  className={`px-3 py-1 text-[11px] font-semibold rounded cursor-pointer transition-colors ${
                    unitMode === 'oz' ? 'bg-white text-zinc-950' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  Imperial (oz)
                </button>
              </div>
            </div>

            {/* Ingredients Table */}
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-zinc-400 mb-3">
                Ingredients & Proportions ({servings} {servings === 1 ? 'Serve' : 'Serves'})
              </h4>
              <div className="divide-y divide-white/5 bg-[#0c0c0e] rounded-xl border border-white/10 overflow-hidden">
                {activeCocktail.ingredients.map((ing, i) => (
                  <div key={i} className="flex items-center justify-between px-5 py-3.5 text-xs">
                    <span className="text-zinc-200 font-medium">{ing.name}</span>
                    <span className="font-mono text-[#da251c] font-semibold tabular-nums text-sm">
                      {formatAmount(ing.amount)}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Preparation Steps */}
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-zinc-400 mb-3">
                Preparation Ritual
              </h4>
              <ol className="space-y-3">
                {activeCocktail.steps.map((step, idx) => (
                  <li
                    key={idx}
                    className="flex gap-4 p-3.5 bg-[#0c0c0e] rounded-xl border border-white/5 text-xs text-zinc-300 leading-relaxed"
                  >
                    <span className="w-5 h-5 rounded-full bg-white/10 text-white font-mono text-[11px] flex items-center justify-center shrink-0 font-semibold">
                      {idx + 1}
                    </span>
                    <span>{step}</span>
                  </li>
                ))}
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
