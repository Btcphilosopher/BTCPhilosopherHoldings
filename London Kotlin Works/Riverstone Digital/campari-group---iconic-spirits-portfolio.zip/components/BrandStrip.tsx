'use client';

import React from 'react';

interface BrandStripProps {
  onSelectBrandSlug: (slug: string) => void;
}

export default function BrandStrip({ onSelectBrandSlug }: BrandStripProps) {
  const brandLogos = [
    {
      name: 'CAMPARI',
      slug: 'campari',
      sub: '',
      style: 'font-serif font-black tracking-[0.25em] text-xl md:text-2xl',
    },
    {
      name: 'APEROL',
      slug: 'aperol',
      sub: '— 1919 —',
      style: 'font-sans font-black tracking-[0.18em] text-lg md:text-xl italic',
    },
    {
      name: 'SKYY',
      slug: 'skyy-vodka',
      sub: 'VODKA',
      style: 'font-sans font-black tracking-[0.2em] text-xl md:text-2xl',
    },
    {
      name: 'BRANCOTT',
      slug: 'brancott-estate',
      sub: 'ESTATE',
      style: 'font-serif tracking-[0.18em] text-sm md:text-base font-semibold',
    },
    {
      name: 'WILD TURKEY',
      slug: 'wild-turkey',
      sub: 'BOURBON',
      style: 'font-serif tracking-[0.14em] text-sm md:text-base font-bold',
    },
    {
      name: 'Grand Marnier',
      slug: 'grand-marnier',
      sub: '',
      style: 'font-serif italic font-medium tracking-wide text-lg md:text-xl',
    },
    {
      name: 'ESPOLÒN',
      slug: 'espolon-tequila',
      sub: 'TEQUILA',
      style: 'font-mono font-black tracking-[0.25em] text-base md:text-lg',
    },
    {
      name: 'CINZANO',
      slug: 'cinzano-1757',
      sub: '1757',
      style: 'font-serif font-bold tracking-[0.2em] text-base md:text-lg',
    },
  ];

  return (
    <section className="w-full bg-[#08080a] border-y border-white/10 py-7 overflow-x-auto scrollbar-none">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between gap-8 md:gap-12 min-w-max md:min-w-0">
          {brandLogos.map((brand) => (
            <button
              key={brand.slug}
              onClick={() => onSelectBrandSlug(brand.slug)}
              className="group flex flex-col items-center justify-center text-zinc-400 hover:text-white transition-all transform hover:-translate-y-0.5 cursor-pointer px-2"
              title={`View ${brand.name}`}
            >
              <span className={`${brand.style} text-zinc-300 group-hover:text-white transition-colors duration-200`}>
                {brand.name}
              </span>
              {brand.sub && (
                <span className="text-[10px] tracking-[0.25em] uppercase text-zinc-400 group-hover:text-zinc-200 transition-colors font-sans mt-0.5">
                  {brand.sub}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
