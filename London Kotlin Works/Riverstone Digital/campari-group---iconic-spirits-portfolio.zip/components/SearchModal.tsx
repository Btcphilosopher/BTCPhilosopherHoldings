'use client';

import React, { useState, useMemo } from 'react';
import { BRANDS, COCKTAILS, Brand, Cocktail } from '@/lib/campari-data';
import { Search, X, GlassWater, ArrowRight } from 'lucide-react';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectBrand: (brand: Brand) => void;
  onSelectCocktail: (cocktailName: string) => void;
}

export default function SearchModal({
  isOpen,
  onClose,
  onSelectBrand,
  onSelectCocktail,
}: SearchModalProps) {
  const [query, setQuery] = useState('');

  const brandResults = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    return BRANDS.filter(
      (b) =>
        b.name.toLowerCase().includes(q) ||
        b.category_name.toLowerCase().includes(q) ||
        b.origin_country.toLowerCase().includes(q) ||
        b.flavor_profile.toLowerCase().includes(q)
    ).slice(0, 5);
  }, [query]);

  const cocktailResults = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    return COCKTAILS.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.brand_name.toLowerCase().includes(q) ||
        c.ingredients.some((i) => i.name.toLowerCase().includes(q))
    ).slice(0, 4);
  }, [query]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-2xl bg-[#121216] border border-white/20 rounded-2xl shadow-2xl overflow-hidden text-left"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="relative px-5 py-4 border-b border-white/10 flex items-center gap-3">
          <Search className="w-5 h-5 text-zinc-400 shrink-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search Campari Group spirits, cocktails, flavors, or origins..."
            className="w-full bg-transparent text-sm sm:text-base text-white placeholder-zinc-500 focus:outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-zinc-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="text-xs font-mono text-zinc-400 hover:text-white px-2 py-1 rounded bg-white/5"
          >
            ESC
          </button>
        </div>

        {/* Results Container */}
        <div className="p-5 max-h-[60vh] overflow-y-auto space-y-6">
          {!query.trim() ? (
            <div className="py-6 text-center text-xs text-zinc-400 space-y-3">
              <p>Type to search across our global spirits collection.</p>
              <div className="flex flex-wrap items-center justify-center gap-2">
                {['Campari', 'Aperol', 'Negroni', 'Wild Turkey', 'Tequila', 'Paloma', 'Milan'].map((sample) => (
                  <button
                    key={sample}
                    onClick={() => setQuery(sample)}
                    className="px-2.5 py-1 rounded bg-white/5 hover:bg-white/10 text-zinc-300 text-xs transition-colors cursor-pointer"
                  >
                    {sample}
                  </button>
                ))}
              </div>
            </div>
          ) : brandResults.length === 0 && cocktailResults.length === 0 ? (
            <div className="py-8 text-center text-xs text-zinc-400">
              No results found for &ldquo;{query}&rdquo;.
            </div>
          ) : (
            <>
              {/* Brand Matches */}
              {brandResults.length > 0 && (
                <div>
                  <div className="text-[10px] uppercase font-semibold tracking-wider text-zinc-400 mb-2">
                    Spirits & Brands ({brandResults.length})
                  </div>
                  <div className="space-y-2">
                    {brandResults.map((brand) => (
                      <button
                        key={brand.id}
                        onClick={() => {
                          onSelectBrand(brand);
                          onClose();
                        }}
                        className="w-full flex items-center justify-between p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 transition-colors cursor-pointer text-left"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-serif font-bold text-white">
                              {brand.name}
                            </span>
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/10 text-zinc-300">
                              {brand.category_name}
                            </span>
                          </div>
                          <div className="text-xs text-zinc-400 line-clamp-1 mt-0.5">
                            {brand.origin_country} · {brand.abv}% ABV · {brand.flavor_profile}
                          </div>
                        </div>
                        <ArrowRight className="w-4 h-4 text-zinc-400 shrink-0" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Cocktail Matches */}
              {cocktailResults.length > 0 && (
                <div>
                  <div className="text-[10px] uppercase font-semibold tracking-wider text-zinc-400 mb-2">
                    Cocktail Recipes ({cocktailResults.length})
                  </div>
                  <div className="space-y-2">
                    {cocktailResults.map((cocktail) => (
                      <button
                        key={cocktail.id}
                        onClick={() => {
                          onSelectCocktail(cocktail.name);
                          onClose();
                        }}
                        className="w-full flex items-center justify-between p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 transition-colors cursor-pointer text-left"
                      >
                        <div className="flex items-center gap-3">
                          <GlassWater className="w-4 h-4 text-[#da251c] shrink-0" />
                          <div>
                            <span className="text-sm font-serif font-bold text-white">
                              {cocktail.name}
                            </span>
                            <div className="text-xs text-zinc-400 line-clamp-1">
                              Base: {cocktail.brand_name} · {cocktail.glassware} · {cocktail.occasion}
                            </div>
                          </div>
                        </div>
                        <ArrowRight className="w-4 h-4 text-zinc-400 shrink-0" />
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
