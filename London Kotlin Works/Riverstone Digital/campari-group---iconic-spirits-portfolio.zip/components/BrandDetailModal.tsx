'use client';

import React from 'react';
import { Brand } from '@/lib/campari-data';
import { X, Award, MapPin, Calendar, Percent, Sparkles, GlassWater, Database, ArrowRight } from 'lucide-react';

interface BrandDetailModalProps {
  brand: Brand | null;
  onClose: () => void;
  onOpenCocktail: (cocktailName: string) => void;
  onInspectSql: (brand: Brand) => void;
}

export default function BrandDetailModal({
  brand,
  onClose,
  onOpenCocktail,
  onInspectSql,
}: BrandDetailModalProps) {
  if (!brand) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-3xl max-h-[90vh] overflow-y-auto bg-[#121216] border border-white/20 rounded-2xl shadow-2xl text-left"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Banner with brand color accent */}
        <div
          className="relative px-6 py-8 border-b border-white/10"
          style={{
            background: `linear-gradient(135deg, ${brand.color_hex}25 0%, #121216 100%)`,
          }}
        >
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-5 right-5 p-2 rounded-full bg-black/40 hover:bg-black/80 text-zinc-400 hover:text-white transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex flex-wrap items-center gap-3 text-xs font-semibold tracking-widest uppercase mb-2">
            <span className="text-[#da251c]">{brand.category_name}</span>
            <span className="text-zinc-500">·</span>
            <span className="text-zinc-300">{brand.tier}</span>
          </div>

          <h2
            className="text-3xl sm:text-4xl font-serif text-white mb-2"
            style={{ fontFamily: 'Cormorant Garamond, Georgia, serif' }}
          >
            {brand.name}
          </h2>
          <p className="text-sm text-zinc-300 italic font-light max-w-xl">
            {brand.tagline}
          </p>

          {/* Quick Metrics Bar */}
          <div className="flex flex-wrap items-center gap-6 mt-6 pt-6 border-t border-white/10 text-xs text-zinc-300">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#da251c]" />
              <span>{brand.origin_region}, {brand.origin_country}</span>
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-amber-500" />
              <span>Founded <strong className="text-white font-mono">{brand.founded_year}</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <Percent className="w-4 h-4 text-emerald-400" />
              <span><strong className="text-white font-mono">{brand.abv}%</strong> Alcohol by Volume</span>
            </div>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8 space-y-8">
          {/* Heritage Story */}
          <div>
            <h3 className="text-xs font-semibold tracking-widest uppercase text-zinc-400 mb-3">
              Heritage & Craftsmanship
            </h3>
            <p className="text-sm text-zinc-300 leading-relaxed font-light">
              {brand.heritage}
            </p>
          </div>

          {/* Tasting Notes Breakdown */}
          <div className="bg-[#0c0c0e] border border-white/10 rounded-xl p-5">
            <h3 className="text-xs font-semibold tracking-widest uppercase text-[#da251c] mb-4 flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              Tasting Profile
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="p-3 bg-white/5 rounded-lg border border-white/5">
                <span className="block font-semibold text-zinc-200 uppercase tracking-wider mb-1">Nose</span>
                <span className="text-zinc-400 leading-relaxed">{brand.tasting_notes.nose}</span>
              </div>
              <div className="p-3 bg-white/5 rounded-lg border border-white/5">
                <span className="block font-semibold text-zinc-200 uppercase tracking-wider mb-1">Palate</span>
                <span className="text-zinc-400 leading-relaxed">{brand.tasting_notes.palate}</span>
              </div>
              <div className="p-3 bg-white/5 rounded-lg border border-white/5">
                <span className="block font-semibold text-zinc-200 uppercase tracking-wider mb-1">Finish</span>
                <span className="text-zinc-400 leading-relaxed">{brand.tasting_notes.finish}</span>
              </div>
            </div>
          </div>

          {/* Signature Cocktail & Serving Recommendation */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-[#18181d] border border-white/10 rounded-xl p-5 flex flex-col justify-between">
              <div>
                <span className="text-[11px] font-semibold tracking-widest uppercase text-zinc-400 block mb-1">
                  Serving Suggestion
                </span>
                <p className="text-xs text-zinc-300 leading-relaxed">
                  {brand.serving_suggestion}
                </p>
              </div>
            </div>

            <div className="bg-[#18181d] border border-white/10 rounded-xl p-5 flex flex-col justify-between">
              <div>
                <span className="text-[11px] font-semibold tracking-widest uppercase text-zinc-400 block mb-1">
                  Signature Cocktail
                </span>
                <h4 className="text-base font-serif text-white mb-2" style={{ fontFamily: 'Cormorant Garamond, Georgia, serif' }}>
                  {brand.signature_cocktail_name}
                </h4>
              </div>
              <button
                onClick={() => {
                  onClose();
                  onOpenCocktail(brand.signature_cocktail_name);
                }}
                className="inline-flex items-center gap-2 text-xs font-semibold text-[#da251c] hover:text-white transition-colors cursor-pointer mt-2"
              >
                <GlassWater className="w-3.5 h-3.5" />
                <span>View Full Recipe in Studio</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Accolades & Awards */}
          {brand.awards && brand.awards.length > 0 && (
            <div>
              <h3 className="text-xs font-semibold tracking-widest uppercase text-zinc-400 mb-3 flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-500" />
                Distinctions & Global Awards
              </h3>
              <div className="flex flex-wrap gap-2">
                {brand.awards.map((award, idx) => (
                  <span
                    key={idx}
                    className="text-xs text-zinc-300 bg-white/5 border border-white/10 px-3 py-1.5 rounded-md"
                  >
                    {award}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* MySQL & PHP Inspection Callout */}
          <div className="pt-4 border-t border-white/10 flex items-center justify-between">
            <div className="text-xs text-zinc-400">
              Database Record: <code className="text-emerald-400 font-mono">brands.id = {brand.id}</code>
            </div>
            <button
              onClick={() => {
                onClose();
                onInspectSql(brand);
              }}
              className="flex items-center gap-2 px-3 py-1.5 text-xs font-mono font-medium text-emerald-400 bg-emerald-950/40 border border-emerald-800/60 rounded hover:bg-emerald-900/50 transition-colors cursor-pointer"
            >
              <Database className="w-3.5 h-3.5" />
              <span>Query via MySQL Console</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
