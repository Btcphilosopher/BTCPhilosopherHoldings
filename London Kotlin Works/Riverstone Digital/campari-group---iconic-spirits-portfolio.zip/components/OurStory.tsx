'use client';

import React from 'react';
import { History, Palette, Compass, Building2 } from 'lucide-react';

export default function OurStory() {
  const milestones = [
    {
      year: '1860',
      title: 'The Secret Milanese Elixir',
      location: 'Milan & Novara, Italy',
      description:
        'Gaspare Campari invents the legendary red aperitivo recipe, an unchanged secret infusion of bitter herbs, aromatic plants, and fruit.',
      icon: History,
    },
    {
      year: '1915',
      title: 'Camparino in Galleria',
      location: 'Galleria Vittorio Emanuele II, Milan',
      description:
        'Davide Campari inaugurates Camparino right in front of the Duomo. With an innovative hydraulic system pumping cold seltz directly from the basement, it becomes the beating heart of Milanese intellectuals.',
      icon: Building2,
    },
    {
      year: '1932',
      title: 'Futurism & Fortunato Depero',
      location: 'Milan / Rovereto',
      description:
        'Campari introduces Campari Soda—the world’s first ready-to-drink cocktail—in an iconic conical bottle sculpted by Futurist master Fortunato Depero, merging fine art with commercial passion.',
      icon: Palette,
    },
    {
      year: 'Today',
      title: '6th Global Spirits Powerhouse',
      location: '190+ Markets Worldwide',
      description:
        'With 23 world-class production facilities and a prestigious portfolio encompassing Aperol, Wild Turkey, Grand Marnier, Espolòn, and Courvoisier, Campari Group champions toast-worthy celebrations globally.',
      icon: Compass,
    },
  ];

  return (
    <section id="story" className="w-full bg-[#0c0c0e] py-20 px-6 border-b border-white/10">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <div className="text-xs font-semibold tracking-[0.25em] text-[#da251c] uppercase mb-2">
            HERITAGE & ARTISTRY
          </div>
          <h2
            className="text-3xl md:text-5xl font-serif text-white tracking-tight mb-4"
            style={{ fontFamily: 'Cormorant Garamond, Georgia, serif' }}
          >
            Over 160 Years of Passion, Art and Celebration
          </h2>
          <p className="text-sm md:text-base text-zinc-300 font-light leading-relaxed">
            The story of Campari Group is an extraordinary Italian journey of visionaries, masters of blending, and groundbreaking avant-garde artists who redefined modern aesthetics.
          </p>
        </div>

        {/* Milestone Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {milestones.map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.year}
                className="bg-[#121216] border border-white/10 hover:border-white/20 rounded-xl p-6 flex flex-col justify-between transition-all duration-300"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-3xl font-serif text-[#da251c] font-bold" style={{ fontFamily: 'Cormorant Garamond, Georgia, serif' }}>
                      {item.year}
                    </span>
                    <Icon className="w-5 h-5 text-zinc-400" />
                  </div>
                  <h3 className="text-lg font-serif text-white mb-1" style={{ fontFamily: 'Cormorant Garamond, Georgia, serif' }}>
                    {item.title}
                  </h3>
                  <div className="text-[11px] font-mono text-zinc-400 uppercase tracking-wider mb-3">
                    {item.location}
                  </div>
                  <p className="text-xs text-zinc-300 leading-relaxed font-light">
                    {item.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Galleria Campari Highlight Quote */}
        <div className="mt-12 bg-gradient-to-r from-[#1c0808] to-[#121216] border border-white/10 rounded-2xl p-8 sm:p-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="max-w-2xl">
            <span className="text-[11px] uppercase tracking-widest text-[#da251c] font-semibold block mb-2">
              Galleria Campari · Sesto San Giovanni (Milan)
            </span>
            <p className="text-base sm:text-lg font-serif italic text-zinc-200" style={{ fontFamily: 'Cormorant Garamond, Georgia, serif' }}>
              &ldquo;Campari has never been just a drink; it is a canvas where Italian lifestyle, contemporary art, and the ritual of connection converge.&rdquo;
            </p>
          </div>
          <div className="text-xs text-zinc-400 font-mono shrink-0 text-right">
            <span>Corporate Archives & Museum</span>
            <div className="text-zinc-200 mt-1">Open to Cultural Visitors & Scholars</div>
          </div>
        </div>
      </div>
    </section>
  );
}
