/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Product, ProductVariant, CartItem, SavedOutfit, Order, AuditLogEntry, OutfitItem } from './types';
import { mockProducts, mockStores, mockOutfits, mockOrders, mockAuditLogs } from './data/mockData';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { Hero } from './components/Hero';
import { CatalogueView } from './components/CatalogueView';
import { ProductDetailView } from './components/ProductDetailView';
import { OutfitBuilderView } from './components/OutfitBuilderView';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutView } from './components/CheckoutView';
import { OrderConfirmationView } from './components/OrderConfirmationView';
import { AccountView } from './components/AccountView';
import { StoreFinderView } from './components/StoreFinderView';
import { AdminDashboard } from './components/AdminDashboard';
import { DemoWalkthroughModal } from './components/DemoWalkthroughModal';
import { Search, X, Heart, ShoppingBag, Trash2 } from 'lucide-react';

export default function App() {
  const [currentView, setCurrentView] = useState<string>('home');
  const [selectedGender, setSelectedGender] = useState<string>('All');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeProduct, setActiveProduct] = useState<Product | null>(null);
  const [activeOrder, setActiveOrder] = useState<Order | null>(mockOrders[0]);

  // Data states
  const [products, setProducts] = useState<Product[]>(mockProducts);
  const [stores] = useState(mockStores);
  const [outfits, setOutfits] = useState<SavedOutfit[]>(mockOutfits);
  const [orders, setOrders] = useState<Order[]>(mockOrders);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(mockAuditLogs);
  const [cartItems, setCartItems] = useState<CartItem[]>([
    {
      id: 'cart-1',
      productId: 'prod-1',
      sku: 'AF-DEN-001-BLU-26-REG',
      title: 'Ultra High Rise 90s Straight Jean',
      colour: 'Medium Vintage Wash',
      size: '26',
      length: 'Regular',
      fit: 'Straight',
      price: 90.00,
      quantity: 1,
      image: '/public/assets/aistudio/16968c28-5025-4d42-b15d-3c1cb83c9f45_f8e84f2c.png',
      maxAvailable: 13
    }
  ]);
  const [wishlist, setWishlist] = useState<string[]>(['prod-1', 'prod-2']);

  // Modals
  const [cartOpen, setCartOpen] = useState<boolean>(false);
  const [wishlistModalOpen, setWishlistModalOpen] = useState<boolean>(false);
  const [searchModalOpen, setSearchModalOpen] = useState<boolean>(false);
  const [demoModalOpen, setDemoModalOpen] = useState<boolean>(false);
  const [searchQueryInput, setSearchQueryInput] = useState<string>('');

  // Cart actions
  const handleAddToCart = (product: Product, variant: ProductVariant, quantity: number) => {
    setCartItems(prev => {
      const existingIndex = prev.findIndex(item => item.sku === variant.sku);
      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex].quantity += quantity;
        return updated;
      } else {
        return [
          ...prev,
          {
            id: `cart-${Date.now()}-${Math.random()}`,
            productId: product.id,
            sku: variant.sku,
            title: product.title,
            colour: variant.colour,
            size: variant.size,
            length: variant.length,
            fit: variant.fit,
            price: variant.price,
            quantity,
            image: product.images[0],
            maxAvailable: variant.availableStock
          }
        ];
      }
    });
    setCartOpen(true);
  };

  const handleUpdateCartQuantity = (sku: string, qty: number) => {
    if (qty <= 0) {
      handleRemoveCartItem(sku);
      return;
    }
    setCartItems(prev => prev.map(item => item.sku === sku ? { ...item, quantity: qty } : item));
  };

  const handleRemoveCartItem = (sku: string) => {
    setCartItems(prev => prev.filter(item => item.sku !== sku));
  };

  const handleAddOutfitToCart = (items: OutfitItem[]) => {
    items.forEach(it => {
      const prod = products.find(p => p.id === it.productId);
      const varnt = prod?.variants.find(v => v.sku === it.sku);
      if (prod && varnt) {
        handleAddToCart(prod, varnt, 1);
      }
    });
  };

  const handleToggleWishlist = (productId: string) => {
    setWishlist(prev => prev.includes(productId) ? prev.filter(id => id !== productId) : [...prev, productId]);
  };

  const handleOrderPlaced = (newOrder: Order) => {
    setOrders(prev => [newOrder, ...prev]);
    setActiveOrder(newOrder);
    setCurrentView('order-confirmation');
    setAuditLogs(prev => [
      {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
        user: 'sarah.jenkins@example.com',
        action: 'ORDER_PLACED',
        details: `Successfully placed order ${newOrder.orderNumber} for $${newOrder.total.toFixed(2)}.`,
        severity: 'success'
      },
      ...prev
    ]);
  };

  const handleRequestReturn = (orderId: string, reason: string) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, returnRequested: true, returnStatus: 'Requested', returnReason: reason } : o));
    setAuditLogs(prev => [
      {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
        user: 'sarah.jenkins@example.com',
        action: 'RETURN_REQUESTED',
        details: `Requested return for order ID ${orderId} due to: ${reason}`,
        severity: 'warning'
      },
      ...prev
    ]);
    alert('Return request successfully submitted. A prepaid shipping label has been dispatched to your email.');
  };

  const handleRequestCancel = (orderId: string) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: 'Cancelled' } : o));
    alert('Order cancellation request processed successfully.');
  };

  const handleUpdateInventory = (sku: string, newStock: number) => {
    setProducts(prev => prev.map(p => ({
      ...p,
      variants: p.variants.map(v => v.sku === sku ? { ...v, onHandStock: newStock, availableStock: newStock - v.reservedStock } : v)
    })));
  };

  const handleUpdateOrderStatus = (orderId: string, newStatus: Order['status']) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: newStatus } : o));
  };

  // Search results in modal
  const searchResults = products.filter(p => {
    if (!searchQueryInput.trim()) return false;
    const q = searchQueryInput.toLowerCase();
    return p.title.toLowerCase().includes(q) || p.description.toLowerCase().includes(q) || p.category.toLowerCase().includes(q);
  });

  return (
    <div className="min-h-screen bg-[#F9F6F0] flex flex-col font-sans selection:bg-[#C8A97E] selection:text-[#241E1C]">
      {/* Header */}
      <Header
        currentView={currentView}
        setCurrentView={setCurrentView}
        selectedGender={selectedGender}
        setSelectedGender={setSelectedGender}
        cartCount={cartItems.reduce((a, b) => a + b.quantity, 0)}
        wishlistCount={wishlist.length}
        onOpenCart={() => setCartOpen(true)}
        onOpenWishlist={() => setWishlistModalOpen(true)}
        onOpenSearch={() => setSearchModalOpen(true)}
        onOpenDemoModal={() => setDemoModalOpen(true)}
      />

      {/* Main Content Router */}
      <main className="flex-1">
        {currentView === 'home' && (
          <Hero
            onSelectCategory={(cat) => { setSelectedCategory(cat); setCurrentView('catalogue'); }}
            onSelectGender={(gen) => { setSelectedGender(gen); setCurrentView('catalogue'); }}
            onExploreNewArrivals={() => { setSelectedCategory('All'); setSelectedGender('All'); setCurrentView('catalogue'); }}
          />
        )}

        {currentView === 'catalogue' && (
          <CatalogueView
            products={products}
            selectedGender={selectedGender}
            setSelectedGender={setSelectedGender}
            selectedCategory={selectedCategory}
            setSelectedCategory={setSelectedCategory}
            wishlist={wishlist}
            onToggleWishlist={handleToggleWishlist}
            onSelectProduct={(prod) => { setActiveProduct(prod); setCurrentView('product-detail'); }}
          />
        )}

        {currentView === 'product-detail' && activeProduct && (
          <ProductDetailView
            product={activeProduct}
            onBack={() => setCurrentView('catalogue')}
            onAddToCart={handleAddToCart}
            isWishlisted={wishlist.includes(activeProduct.id)}
            onToggleWishlist={handleToggleWishlist}
          />
        )}

        {currentView === 'outfit-builder' && (
          <OutfitBuilderView
            products={products}
            savedOutfits={outfits}
            onAddOutfitToCart={handleAddOutfitToCart}
            onSaveNewOutfit={(newOutfit) => setOutfits(prev => [newOutfit, ...prev])}
          />
        )}

        {currentView === 'checkout' && (
          <CheckoutView
            cartItems={cartItems}
            stores={stores}
            onBackToCatalogue={() => setCurrentView('catalogue')}
            onOrderPlaced={handleOrderPlaced}
            onClearCart={() => setCartItems([])}
          />
        )}

        {currentView === 'order-confirmation' && activeOrder && (
          <OrderConfirmationView
            order={activeOrder}
            onReturnToStore={() => setCurrentView('home')}
            onRequestReturn={handleRequestReturn}
            onRequestCancel={handleRequestCancel}
          />
        )}

        {currentView === 'account' && (
          <AccountView
            orders={orders}
            savedOutfits={outfits}
            wishlistCount={wishlist.length}
            onBackToStore={() => setCurrentView('home')}
            onSelectOrder={(ord) => { setActiveOrder(ord); setCurrentView('order-confirmation'); }}
          />
        )}

        {currentView === 'stores' && (
          <StoreFinderView
            stores={stores}
            onBackToStore={() => setCurrentView('home')}
          />
        )}

        {currentView === 'admin' && (
          <AdminDashboard
            products={products}
            orders={orders}
            auditLogs={auditLogs}
            onBackToStore={() => setCurrentView('home')}
            onUpdateInventory={handleUpdateInventory}
            onUpdateOrderStatus={handleUpdateOrderStatus}
          />
        )}
      </main>

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onProceedToCheckout={() => { setCartOpen(false); setCurrentView('checkout'); }}
      />

      {/* Wishlist Modal */}
      {wishlistModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-[#FBF9F5] rounded-xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-[#E6E0D5] space-y-6 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-[#E6E0D5]">
              <h3 className="font-serif text-2xl text-[#241E1C]">Saved Wishlist ({wishlist.length})</h3>
              <button onClick={() => setWishlistModalOpen(false)} className="text-[#786D65] hover:text-[#241E1C]">
                <X className="w-5 h-5" />
              </button>
            </div>

            {wishlist.length === 0 ? (
              <p className="text-xs text-[#786D65] text-center py-12">Your wishlist is empty. Tap the heart icon on any product to save it here.</p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {products.filter(p => wishlist.includes(p.id)).map(prod => (
                  <div key={prod.id} className="bg-white rounded-lg border border-[#E6E0D5] p-4 flex gap-4 items-center">
                    <div className="w-16 h-20 bg-[#EFECE6] rounded overflow-hidden shrink-0 cursor-pointer" onClick={() => { setActiveProduct(prod); setCurrentView('product-detail'); setWishlistModalOpen(false); }}>
                      <img src={prod.images[0]} alt="" className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-serif text-sm text-[#241E1C] cursor-pointer hover:text-[#C8A97E]" onClick={() => { setActiveProduct(prod); setCurrentView('product-detail'); setWishlistModalOpen(false); }}>
                        {prod.title}
                      </h4>
                      <span className="text-xs font-semibold text-[#241E1C]">${prod.basePrice.toFixed(2)}</span>
                    </div>
                    <button onClick={() => handleToggleWishlist(prod.id)} className="text-rose-600 hover:text-rose-800 p-2">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Search Modal */}
      {searchModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-start justify-center pt-24 p-4 backdrop-blur-sm">
          <div className="bg-[#FBF9F5] rounded-xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-[#E6E0D5] space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-[#E6E0D5]">
              <div className="flex items-center gap-3 flex-1 mr-4">
                <Search className="w-5 h-5 text-[#786D65]" />
                <input
                  type="text"
                  autoFocus
                  placeholder="Search styles, categories, fabrics..."
                  value={searchQueryInput}
                  onChange={(e) => setSearchQueryInput(e.target.value)}
                  className="w-full bg-transparent text-sm focus:outline-none text-[#241E1C]"
                />
              </div>
              <button onClick={() => setSearchModalOpen(false)} className="text-[#786D65] hover:text-[#241E1C]">
                <X className="w-5 h-5" />
              </button>
            </div>

            {searchQueryInput.trim() && (
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {searchResults.length === 0 ? (
                  <p className="text-xs text-[#786D65] text-center py-6">No matching products found.</p>
                ) : (
                  searchResults.map(prod => (
                    <div
                      key={prod.id}
                      onClick={() => {
                        setActiveProduct(prod);
                        setCurrentView('product-detail');
                        setSearchModalOpen(false);
                      }}
                      className="bg-white rounded-lg border border-[#E6E0D5] p-3 flex gap-3 items-center cursor-pointer hover:border-[#241E1C] transition-colors"
                    >
                      <div className="w-12 h-16 bg-[#EFECE6] rounded overflow-hidden shrink-0">
                        <img src={prod.images[0]} alt="" className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-serif text-sm text-[#241E1C]">{prod.title}</h4>
                        <span className="text-xs text-[#786D65]">{prod.category} · ${prod.basePrice.toFixed(2)}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Demo Walkthrough Modal */}
      <DemoWalkthroughModal
        isOpen={demoModalOpen}
        onClose={() => setDemoModalOpen(false)}
        onJumpToView={(view) => setCurrentView(view)}
      />

      {/* Footer */}
      <Footer setCurrentView={setCurrentView} />
    </div>
  );
}
