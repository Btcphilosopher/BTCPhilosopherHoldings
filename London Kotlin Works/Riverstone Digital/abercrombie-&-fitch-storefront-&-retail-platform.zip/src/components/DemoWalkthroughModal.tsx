import React, { useState } from 'react';
import { Sparkles, X, Check, ArrowRight, ArrowLeft } from 'lucide-react';

interface DemoWalkthroughModalProps {
  isOpen: boolean;
  onClose: () => void;
  onJumpToView: (view: string) => void;
}

export const DemoWalkthroughModal: React.FC<DemoWalkthroughModalProps> = ({
  isOpen,
  onClose,
  onJumpToView
}) => {
  const [currentStep, setCurrentStep] = useState<number>(1);

  if (!isOpen) return null;

  const steps = [
    {
      title: '1. Reference-Based Homepage',
      description: 'Experience the warm ivory backgrounds, espresso typography, serif headlines, and full-width editorial fashion photography.',
      actionView: 'home'
    },
    {
      title: '2. Browse Denim Collection',
      description: 'Explore curated categories and authentic rigid denim with vintage washes.',
      actionView: 'catalogue'
    },
    {
      title: '3. Filter by Fit and Size',
      description: 'Use sidebar filters to refine by straight fit, waist sizes, and lengths.',
      actionView: 'catalogue'
    },
    {
      title: '4. Select Colour and Length',
      description: 'On product detail pages, choosing a colourway updates valid size choices and inventory status.',
      actionView: 'catalogue'
    },
    {
      title: '5. Save Product to Wishlist',
      description: 'Click the heart icon to save products to your personal wishlist.',
      actionView: 'catalogue'
    },
    {
      title: '6. Add Exact Variant to Bag',
      description: 'Select an exact sellable SKU and add it to your persistent shopping bag.',
      actionView: 'catalogue'
    },
    {
      title: '7. Build a Two-Item Outfit',
      description: 'Use the Outfit Builder capsule creator to combine top and bottom variants.',
      actionView: 'outfit-builder'
    },
    {
      title: '8. Review Delivery and Taxes',
      description: 'At checkout, review merchandise subtotal, calculated shipping, and state taxes separately.',
      actionView: 'checkout'
    },
    {
      title: '9. Complete Simulated Payment',
      description: 'Authorize secure payment using our local payment simulator and sandbox adapter.',
      actionView: 'checkout'
    },
    {
      title: '10. View Confirmed Order & Receipt',
      description: 'Access order confirmation, historical snapshot receipts, and tracking status.',
      actionView: 'account'
    },
    {
      title: '11. Advance Fulfilment in Administration',
      description: 'Switch to the protected staff dashboard to update order status to Shipped or Ready for Pickup.',
      actionView: 'admin'
    },
    {
      title: '12. Submit Return Request',
      description: 'Initiate a return request with reason selection directly from your order history.',
      actionView: 'account'
    },
    {
      title: '13. Unavailable Variant Handling',
      description: 'Observe out-of-stock SKUs clearly crossed out to prevent silent substitutions.',
      actionView: 'catalogue'
    },
    {
      title: '14. Payment & Reservation Exception Test',
      description: 'Test simulated payment failures and expired stock reservations in the checkout view.',
      actionView: 'checkout'
    }
  ];

  const current = steps[currentStep - 1];

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4 backdrop-blur-sm">
      <div className="bg-[#FBF9F5] rounded-xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-[#E6E0D5] space-y-6">
        <div className="flex items-center justify-between pb-4 border-b border-[#E6E0D5]">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#C8A97E]" />
            <h3 className="font-serif text-xl text-[#241E1C]">Interactive 14-Step Demonstration</h3>
          </div>
          <button onClick={onClose} className="text-[#786D65] hover:text-[#241E1C]">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div className="flex justify-between text-xs text-[#786D65] font-semibold uppercase tracking-wider">
            <span>Step {currentStep} of {steps.length}</span>
            <span>{Math.round((currentStep / steps.length) * 100)}% Complete</span>
          </div>
          <div className="w-full bg-[#EFECE6] h-2 rounded-full overflow-hidden">
            <div className="bg-[#241E1C] h-full transition-all duration-300" style={{ width: `${(currentStep / steps.length) * 100}%` }} />
          </div>

          <div className="bg-white p-6 rounded-lg border border-[#E6E0D5] space-y-3">
            <h4 className="font-serif text-xl text-[#241E1C]">{current.title}</h4>
            <p className="text-sm text-[#594B42] leading-relaxed">{current.description}</p>
          </div>
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-[#E6E0D5]">
          <button
            onClick={() => setCurrentStep(Math.max(1, currentStep - 1))}
            disabled={currentStep === 1}
            className="px-4 py-2 text-xs bg-[#EFECE6] text-[#241E1C] rounded disabled:opacity-50 flex items-center gap-1"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Previous
          </button>

          <button
            onClick={() => {
              onJumpToView(current.actionView);
              onClose();
            }}
            className="px-5 py-2.5 text-xs bg-[#C8A97E] text-[#1C1715] hover:bg-[#241E1C] hover:text-white font-semibold rounded transition-colors"
          >
            Go to Feature View Now
          </button>

          <button
            onClick={() => setCurrentStep(Math.min(steps.length, currentStep + 1))}
            disabled={currentStep === steps.length}
            className="px-4 py-2 text-xs bg-[#241E1C] text-white rounded disabled:opacity-50 flex items-center gap-1"
          >
            Next
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
