import React, { useState, useMemo } from 'react';
import { Product, ProductVariant } from '../types';
import { Heart, ShoppingBag, ShieldCheck, Truck, Store, Ruler, Check, AlertCircle, ArrowLeft, Star } from 'lucide-react';

interface ProductDetailViewProps {
  product: Product;
  onBack: () => void;
  onAddToCart: (product: Product, variant: ProductVariant, quantity: number) => void;
  isWishlisted: boolean;
  onToggleWishlist: (productId: string) => void;
}

export const ProductDetailView: React.FC<ProductDetailViewProps> = ({
  product,
  onBack,
  onAddToCart,
  isWishlisted,
  onToggleWishlist
}) => {
  // Unique available colours
  const availableColours = useMemo(() => {
    const map = new Map<string, { colour: string; colourCode?: string; image?: string }>();
    product.variants.forEach(v => {
      if (!map.has(v.colour)) {
        map.set(v.colour, { colour: v.colour, colourCode: v.colourCode });
      }
    });
    return Array.from(map.values());
  }, [product]);

  const [selectedColour, setSelectedColour] = useState<string>(availableColours[0]?.colour || '');
  
  // Available sizes for the selected colour
  const availableSizesForColour = useMemo(() => {
    return product.variants.filter(v => v.colour === selectedColour);
  }, [product, selectedColour]);

  const [selectedVariant, setSelectedVariant] = useState<ProductVariant | null>(
    availableSizesForColour[0] || null
  );

  const [quantity, setQuantity] = useState<number>(1);
  const [activeImageIndex, setActiveImageIndex] = useState<number>(0);
  const [sizeGuideOpen, setSizeGuideOpen] = useState<boolean>(false);
  const [addedSuccess, setAddedSuccess] = useState<boolean>(false);

  // When colour changes, pick first available size for that colour
  const handleColourChange = (colour: string) => {
    setSelectedColour(colour);
    const firstMatching = product.variants.find(v => v.colour === colour);
    setSelectedVariant(firstMatching || null);
  };

  const handleAddToCartClick = () => {
    if (!selectedVariant || !selectedVariant.isAvailable) return;
    onAddToCart(product, selectedVariant, quantity);
    setAddedSuccess(true);
    setTimeout(() => setAddedSuccess(false), 3000);
  };

  return (
    <div className="bg-[#F9F6F0] min-h-screen py-8 px-4 sm:px-6 lg:px-8 text-[#241E1C]">
      <div className="max-w-7xl mx-auto">
        {/* Back Button */}
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-[#786D65] hover:text-[#241E1C] mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Catalogue
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Image Gallery (Left 7 Cols) */}
          <div className="lg:col-span-7 space-y-4">
            <div className="aspect-[3/4] bg-[#EFECE6] rounded-lg overflow-hidden border border-[#E6E0D5] relative">
              <img
                src={product.images[activeImageIndex] || product.images[0]}
                alt={product.title}
                className="w-full h-full object-cover object-center"
              />
              {product.isNewArrival && (
                <span className="absolute top-4 left-4 bg-[#241E1C] text-white text-xs uppercase tracking-wider px-3 py-1">
                  New Arrival
                </span>
              )}
            </div>

            {/* Thumbnails */}
            {product.images.length > 1 && (
              <div className="grid grid-cols-4 gap-4">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`aspect-[3/4] rounded-lg overflow-hidden border-2 transition-all ${activeImageIndex === idx ? 'border-[#241E1C]' : 'border-transparent opacity-70 hover:opacity-100'}`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Details & Selection (Right 5 Cols) */}
          <div className="lg:col-span-5 space-y-8">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs uppercase tracking-widest text-[#786D65]">
                  {product.category} · {product.gender} · Style {product.styleId}
                </span>
                <div className="flex items-center gap-1 text-xs text-[#594B42]">
                  <Star className="w-4 h-4 fill-current text-[#C8A97E]" />
                  <span className="font-semibold">{product.rating}</span>
                  <span>({product.reviewsCount} reviews)</span>
                </div>
              </div>

              <h1 className="font-serif text-3xl sm:text-4xl text-[#241E1C] mb-2">
                {product.title}
              </h1>
              <p className="text-sm font-serif italic text-[#594B42] mb-4">
                {product.subtitle}
              </p>

              <div className="text-2xl font-medium text-[#241E1C] mb-6">
                ${selectedVariant ? selectedVariant.price.toFixed(2) : product.basePrice.toFixed(2)}
              </div>

              <p className="text-sm text-[#594B42] leading-relaxed">
                {product.description}
              </p>
            </div>

            {/* Colour Selector */}
            <div className="space-y-3">
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#786D65]">
                Colour: <span className="text-[#241E1C] font-bold">{selectedColour}</span>
              </label>
              <div className="flex flex-wrap gap-3">
                {availableColours.map(c => (
                  <button
                    key={c.colour}
                    onClick={() => handleColourChange(c.colour)}
                    className={`px-4 py-2 border text-xs rounded transition-all flex items-center gap-2 ${selectedColour === c.colour ? 'border-[#241E1C] bg-[#241E1C] text-white font-medium shadow-sm' : 'border-[#DCD3C9] bg-white text-[#241E1C] hover:border-[#241E1C]'}`}
                  >
                    {c.colourCode && (
                      <span className="w-3 h-3 rounded-full border border-black/20" style={{ backgroundColor: c.colourCode }} />
                    )}
                    {c.colour}
                  </button>
                ))}
              </div>
            </div>

            {/* Size & Length Selector */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#786D65]">
                  Size & Length Selection
                </label>
                <button
                  onClick={() => setSizeGuideOpen(true)}
                  className="text-xs text-[#C8A97E] hover:underline flex items-center gap-1 font-medium"
                >
                  <Ruler className="w-3.5 h-3.5" />
                  Size Guide & Fit Assistance
                </button>
              </div>

              <div className="grid grid-cols-3 gap-2.5">
                {availableSizesForColour.map(v => {
                  const isSelected = selectedVariant?.sku === v.sku;
                  return (
                    <button
                      key={v.sku}
                      onClick={() => setSelectedVariant(v)}
                      disabled={!v.isAvailable}
                      className={`py-3 px-2 border text-xs text-center rounded transition-all flex flex-col items-center justify-center gap-1 ${isSelected ? 'border-[#241E1C] bg-[#241E1C] text-white font-bold shadow-sm' : v.isAvailable ? 'border-[#DCD3C9] bg-white text-[#241E1C] hover:border-[#241E1C]' : 'border-[#E6E0D5] bg-[#EFECE6] text-[#A8988D] cursor-not-allowed line-through'}`}
                    >
                      <span>{v.size} {v.length ? `(${v.length})` : ''}</span>
                      <span className="text-[10px] opacity-80">{v.fit}</span>
                    </button>
                  );
                })}
              </div>

              {selectedVariant && (
                <div className="text-xs pt-1 flex items-center gap-2">
                  {selectedVariant.availableStock > 0 ? (
                    <span className="text-emerald-700 font-medium flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" />
                      In stock ({selectedVariant.availableStock} available at fulfillment center)
                    </span>
                  ) : (
                    <span className="text-rose-600 font-medium flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      Currently unavailable in this exact variant.
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* Quantity Selector */}
            <div className="space-y-2">
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#786D65]">Quantity</label>
              <div className="flex items-center w-32 border border-[#DCD3C9] rounded bg-white">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3 py-2 text-sm text-[#786D65] hover:text-[#241E1C]"
                >
                  -
                </button>
                <span className="flex-1 text-center text-xs font-semibold">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-3 py-2 text-sm text-[#786D65] hover:text-[#241E1C]"
                >
                  +
                </button>
              </div>
            </div>

            {/* Actions: Add to Bag & Save */}
            <div className="space-y-3 pt-4 border-t border-[#E6E0D5]">
              <div className="flex gap-4">
                <button
                  onClick={handleAddToCartClick}
                  disabled={!selectedVariant || !selectedVariant.isAvailable}
                  className={`flex-1 py-4 text-sm font-medium tracking-wide flex items-center justify-center gap-2 transition-all shadow-sm ${selectedVariant && selectedVariant.isAvailable ? 'bg-[#1C1715] hover:bg-[#C8A97E] hover:text-[#1C1715] text-white' : 'bg-[#DCD3C9] text-[#786D65] cursor-not-allowed'}`}
                >
                  <ShoppingBag className="w-4 h-4" />
                  {addedSuccess ? 'Added to Bag Successfully!' : 'Add to Bag'}
                </button>

                <button
                  onClick={() => onToggleWishlist(product.id)}
                  className={`p-4 border rounded transition-colors flex items-center justify-center ${isWishlisted ? 'bg-[#241E1C] text-[#C8A97E] border-[#241E1C]' : 'border-[#DCD3C9] bg-white text-[#241E1C] hover:border-[#241E1C]'}`}
                  title="Save to Wishlist"
                >
                  <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-current' : ''}`} />
                </button>
              </div>

              {addedSuccess && (
                <div className="bg-[#EAE3DC] text-[#241E1C] p-3 rounded text-xs text-center animate-fadeIn font-medium">
                  Exact variant SKU <span className="font-bold">{selectedVariant?.sku}</span> added to your shopping bag.
                </div>
              )}
            </div>

            {/* Delivery & Collection Eligibility */}
            <div className="space-y-3 pt-6 border-t border-[#E6E0D5] text-xs text-[#594B42]">
              <div className="flex items-start gap-3">
                <Truck className="w-4 h-4 text-[#C8A97E] mt-0.5 shrink-0" />
                <div>
                  <span className="font-semibold text-[#241E1C]">Standard & Express Delivery:</span> Available for home delivery within 2-4 business days. Free shipping on orders over $75.
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Store className="w-4 h-4 text-[#C8A97E] mt-0.5 shrink-0" />
                <div>
                  <span className="font-semibold text-[#241E1C]">Buy Online Pick Up In Store:</span> Available at Fifth Avenue Flagship and nearby retail locations in 2 hours.
                </div>
              </div>
              <div className="flex items-start gap-3">
                <ShieldCheck className="w-4 h-4 text-[#C8A97E] mt-0.5 shrink-0" />
                <div>
                  <span className="font-semibold text-[#241E1C]">Fabric & Care:</span> {product.fabricComposition}. {product.careInstructions}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Size Guide Modal */}
      {sizeGuideOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-[#FBF9F5] rounded-xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-[#E6E0D5] relative space-y-6">
            <h3 className="font-serif text-2xl text-[#241E1C]">Size Guide & Fit Assistance</h3>
            <p className="text-xs text-[#594B42]">
              Reference specifications for <span className="font-bold">{product.title}</span> ({product.sizeChartReference}).
            </p>

            <div className="border border-[#DCD3C9] rounded overflow-hidden text-xs">
              <table className="w-full text-left">
                <thead className="bg-[#EFECE6] text-[#241E1C] font-semibold border-b border-[#DCD3C9]">
                  <tr>
                    <th className="p-3">Size</th>
                    <th className="p-3">Chest / Waist (in)</th>
                    <th className="p-3">Hips (in)</th>
                    <th className="p-3">Fit Profile</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#DCD3C9]">
                  <tr><td className="p-3 font-semibold">XS</td><td className="p-3">32 - 33</td><td className="p-3">35 - 36</td><td className="p-3">{selectedVariant?.fit}</td></tr>
                  <tr><td className="p-3 font-semibold">S</td><td className="p-3">34 - 35</td><td className="p-3">37 - 38</td><td className="p-3">{selectedVariant?.fit}</td></tr>
                  <tr><td className="p-3 font-semibold">M</td><td className="p-3">36 - 37</td><td className="p-3">39 - 40</td><td className="p-3">{selectedVariant?.fit}</td></tr>
                  <tr><td className="p-3 font-semibold">L</td><td className="p-3">38 - 39.5</td><td className="p-3">41.5 - 43</td><td className="p-3">{selectedVariant?.fit}</td></tr>
                  <tr><td className="p-3 font-semibold">XL</td><td className="p-3">41 - 42.5</td><td className="p-3">44.5 - 46</td><td className="p-3">{selectedVariant?.fit}</td></tr>
                </tbody>
              </table>
            </div>

            <div className="bg-[#F4EFEB] p-4 rounded text-xs text-[#594B42]">
              <span className="font-semibold text-[#241E1C]">Note:</span> All items are crafted with considered tolerances. If you are between sizes, we recommend sizing up for a relaxed drape.
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setSizeGuideOpen(false)}
                className="bg-[#241E1C] text-white text-xs px-6 py-2.5 hover:bg-[#C8A97E] hover:text-[#241E1C] transition-colors"
              >
                Close Guide
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
