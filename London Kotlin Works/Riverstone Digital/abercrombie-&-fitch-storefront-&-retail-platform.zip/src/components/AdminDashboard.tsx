import React, { useState } from 'react';
import { Product, Order, AuditLogEntry } from '../types';
import { ShieldCheck, Package, ShoppingCart, RefreshCw, FileText, ArrowLeft, Check, AlertCircle } from 'lucide-react';

interface AdminDashboardProps {
  products: Product[];
  orders: Order[];
  auditLogs: AuditLogEntry[];
  onBackToStore: () => void;
  onUpdateInventory: (sku: string, newStock: number) => void;
  onUpdateOrderStatus: (orderId: string, newStatus: Order['status']) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  products,
  orders,
  auditLogs,
  onBackToStore,
  onUpdateInventory,
  onUpdateOrderStatus
}) => {
  const [activeTab, setActiveTab] = useState<'products' | 'inventory' | 'orders' | 'returns' | 'audit'>('products');
  const [successMsg, setSuccessMsg] = useState<string>('');

  return (
    <div className="bg-[#F9F6F0] min-h-screen py-12 px-4 sm:px-6 lg:px-8 text-[#241E1C]">
      <div className="max-w-7xl mx-auto space-y-8">
        <button
          onClick={onBackToStore}
          className="inline-flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-[#786D65] hover:text-[#241E1C] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Exit to Storefront
        </button>

        {/* Header */}
        <div className="bg-[#241E1C] text-[#FBF9F5] p-8 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-sm">
          <div>
            <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-[#C8A97E] mb-2">
              <ShieldCheck className="w-4 h-4" />
              Protected Staff Administration & ERP Control
            </div>
            <h1 className="font-serif text-3xl">Retail Operations Dashboard</h1>
          </div>
          <div className="text-xs text-[#D8C5B2] bg-[#3D312A] px-4 py-2.5 rounded font-mono">
            Role: Store Manager / System Admin (Authenticated)
          </div>
        </div>

        {successMsg && (
          <div className="bg-[#EAE3DC] text-[#241E1C] p-4 rounded-lg text-xs font-medium border border-[#DCD3C9] flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-700" />
            {successMsg}
          </div>
        )}

        {/* Tabs */}
        <div className="flex border-b border-[#E6E0D5] gap-8 text-sm font-medium overflow-x-auto">
          {[
            { id: 'products', label: 'Products & Variants' },
            { id: 'inventory', label: 'Inventory & ATP' },
            { id: 'orders', label: 'Orders & Fulfilment' },
            { id: 'returns', label: 'Returns & Refunds' },
            { id: 'audit', label: 'Audit History' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`pb-3 border-b-2 transition-colors whitespace-nowrap ${activeTab === tab.id ? 'border-[#241E1C] text-[#241E1C] font-semibold' : 'border-transparent text-[#786D65] hover:text-[#241E1C]'}`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="space-y-6">
          {activeTab === 'products' && (
            <div className="bg-white rounded-xl border border-[#E6E0D5] p-8 shadow-sm space-y-6">
              <h3 className="font-serif text-xl text-[#241E1C]">Catalogue & Variant Management</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#EFECE6] text-[#241E1C] font-semibold uppercase tracking-wider border-b border-[#DCD3C9]">
                    <tr>
                      <th className="p-3">Style ID</th>
                      <th className="p-3">Title</th>
                      <th className="p-3">Category</th>
                      <th className="p-3">Gender</th>
                      <th className="p-3">Base Price</th>
                      <th className="p-3">Variants Count</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#DCD3C9]">
                    {products.map(p => (
                      <tr key={p.id} className="hover:bg-[#F9F6F0]">
                        <td className="p-3 font-mono font-bold">{p.styleId}</td>
                        <td className="p-3 font-medium">{p.title}</td>
                        <td className="p-3">{p.category}</td>
                        <td className="p-3">{p.gender}</td>
                        <td className="p-3">${p.basePrice.toFixed(2)}</td>
                        <td className="p-3">{p.variants.length} sellable SKUs</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'inventory' && (
            <div className="bg-white rounded-xl border border-[#E6E0D5] p-8 shadow-sm space-y-6">
              <h3 className="font-serif text-xl text-[#241E1C]">SKU Inventory & Available-to-Promise (ATP)</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#EFECE6] text-[#241E1C] font-semibold uppercase tracking-wider border-b border-[#DCD3C9]">
                    <tr>
                      <th className="p-3">SKU</th>
                      <th className="p-3">Colour / Size / Fit</th>
                      <th className="p-3">On Hand</th>
                      <th className="p-3">Reserved</th>
                      <th className="p-3">Available ATP</th>
                      <th className="p-3">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#DCD3C9]">
                    {products.flatMap(p => p.variants).map(v => (
                      <tr key={v.sku} className="hover:bg-[#F9F6F0]">
                        <td className="p-3 font-mono text-[11px] font-bold">{v.sku}</td>
                        <td className="p-3">{v.colour} / Size {v.size} / {v.fit}</td>
                        <td className="p-3 font-semibold">{v.onHandStock}</td>
                        <td className="p-3 text-[#786D65]">{v.reservedStock}</td>
                        <td className="p-3 font-bold text-emerald-700">{v.availableStock}</td>
                        <td className="p-3">
                          <button
                            onClick={() => {
                              onUpdateInventory(v.sku, v.onHandStock + 5);
                              setSuccessMsg(`Restocked SKU ${v.sku} by +5 units.`);
                              setTimeout(() => setSuccessMsg(''), 3000);
                            }}
                            className="bg-[#241E1C] text-white px-3 py-1.5 rounded hover:bg-[#C8A97E] hover:text-[#241E1C] transition-colors"
                          >
                            Restock +5
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'orders' && (
            <div className="bg-white rounded-xl border border-[#E6E0D5] p-8 shadow-sm space-y-6">
              <h3 className="font-serif text-xl text-[#241E1C]">Order Processing & Fulfilment Dashboard</h3>
              <div className="space-y-4">
                {orders.map(ord => (
                  <div key={ord.id} className="border border-[#DCD3C9] rounded-lg p-6 space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div>
                        <div className="flex items-center gap-3">
                          <span className="font-serif text-lg font-bold text-[#241E1C]">{ord.orderNumber}</span>
                          <span className="text-xs bg-[#EFECE6] px-2.5 py-1 rounded font-medium">{ord.status}</span>
                        </div>
                        <p className="text-xs text-[#786D65]">Created {ord.createdAt} · {ord.fulfillmentType}</p>
                      </div>

                      <div className="flex items-center gap-3">
                        <select
                          value={ord.status}
                          onChange={(e) => {
                            onUpdateOrderStatus(ord.id, e.target.value as any);
                            setSuccessMsg(`Updated order ${ord.orderNumber} status to ${e.target.value}.`);
                            setTimeout(() => setSuccessMsg(''), 3000);
                          }}
                          className="bg-[#F9F6F0] border border-[#DCD3C9] text-xs p-2 rounded focus:outline-none"
                        >
                          <option value="Processing">Processing</option>
                          <option value="Ready for Pickup">Ready for Pickup</option>
                          <option value="Shipped">Shipped</option>
                          <option value="Delivered">Delivered</option>
                          <option value="Cancelled">Cancelled</option>
                        </select>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'returns' && (
            <div className="bg-white rounded-xl border border-[#E6E0D5] p-8 shadow-sm space-y-6">
              <h3 className="font-serif text-xl text-[#241E1C]">Returns, Exchanges & Refund Processing</h3>
              <p className="text-xs text-[#594B42]">
                Manage customer return requests, inspect returned item condition, and issue refunds or trigger replacement stock reservations.
              </p>
              <div className="border border-[#DCD3C9] rounded-lg p-6 text-center text-xs text-[#786D65]">
                No pending return authorisations requiring manual review at this time.
              </div>
            </div>
          )}

          {activeTab === 'audit' && (
            <div className="bg-white rounded-xl border border-[#E6E0D5] p-8 shadow-sm space-y-6">
              <h3 className="font-serif text-xl text-[#241E1C]">System Audit History & Security Log</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#EFECE6] text-[#241E1C] font-semibold uppercase tracking-wider border-b border-[#DCD3C9]">
                    <tr>
                      <th className="p-3">Timestamp</th>
                      <th className="p-3">User / System</th>
                      <th className="p-3">Action</th>
                      <th className="p-3">Details</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#DCD3C9]">
                    {auditLogs.map(log => (
                      <tr key={log.id} className="hover:bg-[#F9F6F0]">
                        <td className="p-3 font-mono text-[11px]">{log.timestamp}</td>
                        <td className="p-3 font-medium">{log.user}</td>
                        <td className="p-3 font-mono text-emerald-800">{log.action}</td>
                        <td className="p-3 text-[#594B42]">{log.details}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
