import React, { useState } from 'react';
import { Search, Heart, ShoppingBag, Menu, X, ShieldCheck, MapPin, Sparkles } from 'lucide-react';

interface HeaderProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  selectedGender: string;
  setSelectedGender: (gender: string) => void;
  cartCount: number;
  wishlistCount: number;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onOpenSearch: () => void;
  onOpenDemoModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  setCurrentView,
  selectedGender,
  setSelectedGender,
  cartCount,
  wishlistCount,
  onOpenCart,
  onOpenWishlist,
  onOpenSearch,
  onOpenDemoModal
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-[#FBF9F5]/95 backdrop-blur-md border-b border-[#E6E0D5]">
      {/* Announcement Strip */}
      <div className="bg-[#241E1C] text-[#FBF9F5] text-xs font-medium py-2 px-4 text-center tracking-wider flex items-center justify-center gap-3">
        <span>Your everyday wardrobe, elevated.</span>
        <span className="hidden md:inline-block text-[#C8A97E]">•</span>
        <button
          onClick={onOpenDemoModal}
          className="hidden md:flex items-center gap-1.5 text-xs bg-[#C8A97E] text-[#241E1C] px-2.5 py-0.5 rounded font-semibold hover:bg-white transition-colors"
        >
          <Sparkles className="w-3.5 h-3.5" />
          Interactive 14-Step Demo
        </button>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Mobile Menu Button & Left Nav */}
        <div className="flex items-center gap-6">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden text-[#241E1C] hover:text-[#C8A97E]"
            aria-label="Toggle Menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>

          <nav className="hidden md:flex items-center gap-8 text-sm tracking-wide font-medium text-[#241E1C]">
            <button
              onClick={() => { setSelectedGender('Women'); setCurrentView('catalogue'); }}
              className={`hover:text-[#C8A97E] transition-colors pb-1 border-b-2 ${selectedGender === 'Women' && currentView === 'catalogue' ? 'border-[#241E1C]' : 'border-transparent'}`}
            >
              Women
            </button>
            <button
              onClick={() => { setSelectedGender('Men'); setCurrentView('catalogue'); }}
              className={`hover:text-[#C8A97E] transition-colors pb-1 border-b-2 ${selectedGender === 'Men' && currentView === 'catalogue' ? 'border-[#241E1C]' : 'border-transparent'}`}
            >
              Men
            </button>
            <button
              onClick={() => setCurrentView('catalogue')}
              className={`hover:text-[#C8A97E] transition-colors pb-1 border-b-2 ${currentView === 'catalogue' ? 'border-transparent' : 'border-transparent'}`}
            >
              New arrivals
            </button>
            <button
              onClick={() => setCurrentView('outfit-builder')}
              className={`hover:text-[#C8A97E] transition-colors pb-1 flex items-center gap-1 ${currentView === 'outfit-builder' ? 'font-bold text-[#C8A97E]' : ''}`}
            >
              <Sparkles className="w-3.5 h-3.5 text-[#C8A97E]" />
              Outfit Builder
            </button>
            <button
              onClick={() => setCurrentView('stores')}
              className={`hover:text-[#C8A97E] transition-colors pb-1 flex items-center gap-1 ${currentView === 'stores' ? 'font-bold text-[#C8A97E]' : ''}`}
            >
              <MapPin className="w-3.5 h-3.5" />
              Stores
            </button>
          </nav>
        </div>

        {/* Centered Wordmark */}
        <div className="absolute left-1/2 -translate-x-1/2 text-center cursor-pointer" onClick={() => setCurrentView('home')}>
          <h1 className="font-serif text-2xl sm:text-3xl tracking-tight text-[#241E1C] font-normal">
            Abercrombie & Fitch
          </h1>
          <span className="text-[10px] tracking-widest text-[#786D65] uppercase block -mt-1 font-sans">
            Independent Concept Storefront
          </span>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-5">
          <button
            onClick={onOpenSearch}
            className="text-[#241E1C] hover:text-[#C8A97E] transition-colors p-1"
            title="Search Catalogue"
          >
            <Search className="w-5 h-5" />
          </button>
          <button
            onClick={onOpenWishlist}
            className="text-[#241E1C] hover:text-[#C8A97E] transition-colors p-1 relative"
            title="Saved Items"
          >
            <Heart className="w-5 h-5" />
            {wishlistCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#241E1C] text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                {wishlistCount}
              </span>
            )}
          </button>
          <button
            onClick={onOpenCart}
            className="text-[#241E1C] hover:text-[#C8A97E] transition-colors p-1 relative"
            title="Shopping Bag"
          >
            <ShoppingBag className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#C8A97E] text-[#241E1C] text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                {cartCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setCurrentView('admin')}
            className="hidden lg:flex items-center gap-1.5 text-xs text-[#786D65] hover:text-[#241E1C] bg-[#EFECE6] px-3 py-1.5 rounded transition-colors"
            title="Staff Administration"
          >
            <ShieldCheck className="w-4 h-4" />
            Staff Admin
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#FBF9F5] border-b border-[#E6E0D5] px-6 py-4 space-y-4 shadow-lg animate-fadeIn">
          <div className="flex flex-col space-y-3 text-base font-medium text-[#241E1C]">
            <button
              onClick={() => { setSelectedGender('Women'); setCurrentView('catalogue'); setMobileMenuOpen(false); }}
              className="text-left py-1 hover:text-[#C8A97E]"
            >
              Women's Collection
            </button>
            <button
              onClick={() => { setSelectedGender('Men'); setCurrentView('catalogue'); setMobileMenuOpen(false); }}
              className="text-left py-1 hover:text-[#C8A97E]"
            >
              Men's Collection
            </button>
            <button
              onClick={() => { setCurrentView('catalogue'); setMobileMenuOpen(false); }}
              className="text-left py-1 hover:text-[#C8A97E]"
            >
              New Arrivals
            </button>
            <button
              onClick={() => { setCurrentView('outfit-builder'); setMobileMenuOpen(false); }}
              className="text-left py-1 hover:text-[#C8A97E] flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-[#C8A97E]" />
              Outfit Builder
            </button>
            <button
              onClick={() => { setCurrentView('stores'); setMobileMenuOpen(false); }}
              className="text-left py-1 hover:text-[#C8A97E] flex items-center gap-2"
            >
              <MapPin className="w-4 h-4" />
              Store Finder
            </button>
            <button
              onClick={() => { setCurrentView('account'); setMobileMenuOpen(false); }}
              className="text-left py-1 hover:text-[#C8A97E]"
            >
              My Account & Orders
            </button>
            <button
              onClick={() => { setCurrentView('admin'); setMobileMenuOpen(false); }}
              className="text-left py-1 text-[#C8A97E] flex items-center gap-2 font-semibold pt-2 border-t border-[#E6E0D5]"
            >
              <ShieldCheck className="w-4 h-4" />
              Staff Administration
            </button>
            <button
              onClick={() => { onOpenDemoModal(); setMobileMenuOpen(false); }}
              className="text-left py-1 text-[#241E1C] bg-[#C8A97E]/25 px-3 py-2 rounded flex items-center gap-2 font-semibold"
            >
              <Sparkles className="w-4 h-4 text-[#C8A97E]" />
              Interactive 14-Step Demo
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
