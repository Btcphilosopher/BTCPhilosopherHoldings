import React, { useState, useMemo } from 'react';
import { Product } from '../types';
import { Heart, SlidersHorizontal, Eye, Check } from 'lucide-react';

interface CatalogueViewProps {
  products: Product[];
  selectedGender: string;
  setSelectedGender: (gender: string) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  wishlist: string[];
  onToggleWishlist: (productId: string) => void;
  onSelectProduct: (product: Product) => void;
}

export const CatalogueView: React.FC<CatalogueViewProps> = ({
  products,
  selectedGender,
  setSelectedGender,
  selectedCategory,
  setSelectedCategory,
  wishlist,
  onToggleWishlist,
  onSelectProduct
}) => {
  const [selectedFit, setSelectedFit] = useState<string>('All');
  const [selectedSize, setSelectedSize] = useState<string>('All');
  const [selectedColour, setSelectedColour] = useState<string>('All');
  const [sortBy, setSortBy] = useState<string>('featured');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  const categories = ['All', 'Denim', 'Linen', 'Dresses', 'Polos & tees', 'Knitwear', 'Outerwear'];

  // Extract unique filter options
  const allFits = useMemo(() => {
    const fits = new Set<string>();
    products.forEach(p => p.variants.forEach(v => fits.add(v.fit)));
    return ['All', ...Array.from(fits)];
  }, [products]);

  const allSizes = useMemo(() => {
    const sizes = new Set<string>();
    products.forEach(p => p.variants.forEach(v => sizes.add(v.size)));
    return ['All', ...Array.from(sizes)];
  }, [products]);

  const allColours = useMemo(() => {
    const colours = new Set<string>();
    products.forEach(p => p.variants.forEach(v => colours.add(v.colour)));
    return ['All', ...Array.from(colours)];
  }, [products]);

  // Filter & Sort logic
  const filteredProducts = useMemo(() => {
    return products.filter(product => {
      if (selectedGender !== 'All' && product.gender !== selectedGender && product.gender !== 'Unisex') {
        return false;
      }
      if (selectedCategory !== 'All' && product.category !== selectedCategory) {
        return false;
      }
      if (searchQuery.trim() !== '') {
        const query = searchQuery.toLowerCase();
        const matchesTitle = product.title.toLowerCase().includes(query);
        const matchesDesc = product.description.toLowerCase().includes(query);
        const matchesCat = product.category.toLowerCase().includes(query);
        if (!matchesTitle && !matchesDesc && !matchesCat) return false;
      }
      if (selectedFit !== 'All') {
        const hasFit = product.variants.some(v => v.fit === selectedFit);
        if (!hasFit) return false;
      }
      if (selectedSize !== 'All') {
        const hasSize = product.variants.some(v => v.size === selectedSize);
        if (!hasSize) return false;
      }
      if (selectedColour !== 'All') {
        const hasColour = product.variants.some(v => v.colour === selectedColour);
        if (!hasColour) return false;
      }
      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-low') return a.basePrice - b.basePrice;
      if (sortBy === 'price-high') return b.basePrice - a.basePrice;
      if (sortBy === 'newest') return (b.isNewArrival ? 1 : 0) - (a.isNewArrival ? 1 : 0);
      return 0; // featured
    });
  }, [products, selectedGender, selectedCategory, searchQuery, selectedFit, selectedSize, selectedColour, sortBy]);

  return (
    <div className="bg-[#F9F6F0] min-h-screen py-12 px-4 sm:px-6 lg:px-8 text-[#241E1C]">
      <div className="max-w-7xl mx-auto">
        {/* Header Title & Breadcrumb */}
        <div className="mb-8 border-b border-[#E6E0D5] pb-6">
          <div className="text-xs uppercase tracking-widest text-[#786D65] mb-2">
            Collection / {selectedGender} / {selectedCategory}
          </div>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <h1 className="font-serif text-3xl sm:text-4xl text-[#241E1C]">
              {selectedGender === 'All' ? 'All Collections' : `${selectedGender}'s ${selectedCategory === 'All' ? 'Wardrobe' : selectedCategory}`}
            </h1>
            <div className="flex items-center gap-3">
              <span className="text-xs text-[#786D65]">{filteredProducts.length} items</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="bg-white border border-[#DCD3C9] text-xs px-3 py-2 rounded focus:outline-none focus:border-[#241E1C]"
              >
                <option value="featured">Featured</option>
                <option value="newest">Newest Arrivals</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
              </select>
              <button
                onClick={() => setMobileFiltersOpen(!mobileFiltersOpen)}
                className="md:hidden bg-white border border-[#DCD3C9] p-2 rounded flex items-center gap-1 text-xs"
              >
                <SlidersHorizontal className="w-4 h-4" />
                Filters
              </button>
            </div>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar Filters */}
          <div className={`lg:block ${mobileFiltersOpen ? 'block' : 'hidden'} space-y-6 bg-white p-6 rounded-lg border border-[#E6E0D5] h-fit shadow-sm`}>
            <div className="flex items-center justify-between pb-4 border-b border-[#E6E0D5]">
              <h3 className="font-serif text-lg text-[#241E1C]">Filters</h3>
              <button
                onClick={() => {
                  setSelectedGender('All');
                  setSelectedCategory('All');
                  setSelectedFit('All');
                  setSelectedSize('All');
                  setSelectedColour('All');
                  setSearchQuery('');
                }}
                className="text-xs text-[#C8A97E] hover:underline"
              >
                Reset all
              </button>
            </div>

            {/* Search within catalogue */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#786D65] mb-2">Search</label>
              <input
                type="text"
                placeholder="Search styles, fabric..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#F9F6F0] border border-[#DCD3C9] text-xs px-3 py-2 rounded focus:outline-none focus:border-[#241E1C]"
              />
            </div>

            {/* Gender filter */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#786D65] mb-2">Gender</label>
              <div className="flex gap-2">
                {['All', 'Women', 'Men'].map(g => (
                  <button
                    key={g}
                    onClick={() => setSelectedGender(g)}
                    className={`flex-1 text-xs py-1.5 border rounded transition-colors ${selectedGender === g ? 'bg-[#241E1C] text-white border-[#241E1C]' : 'bg-[#F9F6F0] text-[#241E1C] border-[#DCD3C9] hover:border-[#241E1C]'}`}
                  >
                    {g}
                  </button>
                ))}
              </div>
            </div>

            {/* Category filter */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#786D65] mb-2">Category</label>
              <div className="space-y-1.5">
                {categories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`w-full text-left text-xs py-1 px-2 rounded transition-colors flex items-center justify-between ${selectedCategory === cat ? 'bg-[#241E1C] text-white font-medium' : 'text-[#594B42] hover:bg-[#F4EFEB]'}`}
                  >
                    <span>{cat}</span>
                    {selectedCategory === cat && <Check className="w-3.5 h-3.5" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Fit filter */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#786D65] mb-2">Fit</label>
              <select
                value={selectedFit}
                onChange={(e) => setSelectedFit(e.target.value)}
                className="w-full bg-[#F9F6F0] border border-[#DCD3C9] text-xs px-3 py-2 rounded focus:outline-none focus:border-[#241E1C]"
              >
                {allFits.map(fit => (
                  <option key={fit} value={fit}>{fit}</option>
                ))}
              </select>
            </div>

            {/* Size filter */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#786D65] mb-2">Size</label>
              <select
                value={selectedSize}
                onChange={(e) => setSelectedSize(e.target.value)}
                className="w-full bg-[#F9F6F0] border border-[#DCD3C9] text-xs px-3 py-2 rounded focus:outline-none focus:border-[#241E1C]"
              >
                {allSizes.map(sz => (
                  <option key={sz} value={sz}>{sz}</option>
                ))}
              </select>
            </div>

            {/* Colour filter */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#786D65] mb-2">Colour</label>
              <select
                value={selectedColour}
                onChange={(e) => setSelectedColour(e.target.value)}
                className="w-full bg-[#F9F6F0] border border-[#DCD3C9] text-xs px-3 py-2 rounded focus:outline-none focus:border-[#241E1C]"
              >
                {allColours.map(col => (
                  <option key={col} value={col}>{col}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Product Grid */}
          <div className="lg:col-span-3">
            {filteredProducts.length === 0 ? (
              <div className="text-center py-24 bg-white rounded-lg border border-[#E6E0D5]">
                <p className="font-serif text-xl text-[#241E1C] mb-2">No products found</p>
                <p className="text-xs text-[#786D65] mb-6">Try adjusting your filters or search terms.</p>
                <button
                  onClick={() => {
                    setSelectedGender('All');
                    setSelectedCategory('All');
                    setSelectedFit('All');
                    setSelectedSize('All');
                    setSelectedColour('All');
                    setSearchQuery('');
                  }}
                  className="bg-[#241E1C] text-white text-xs px-6 py-2.5 hover:bg-[#C8A97E] hover:text-[#241E1C] transition-colors"
                >
                  Clear All Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts.map(product => {
                  const isWishlisted = wishlist.includes(product.id);
                  const minPrice = Math.min(...product.variants.map(v => v.price));

                  return (
                    <div
                      key={product.id}
                      className="group bg-white rounded-lg overflow-hidden border border-[#E6E0D5] hover:shadow-md transition-all duration-300 flex flex-col"
                    >
                      {/* Image Container */}
                      <div className="relative aspect-[3/4] bg-[#EFECE6] overflow-hidden cursor-pointer" onClick={() => onSelectProduct(product)}>
                        <img
                          src={product.images[0]}
                          alt={product.title}
                          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                        />
                        {product.isNewArrival && (
                          <span className="absolute top-3 left-3 bg-[#241E1C] text-white text-[10px] uppercase tracking-wider px-2.5 py-1">
                            New Arrival
                          </span>
                        )}
                        <button
                          onClick={(e) => { e.stopPropagation(); onToggleWishlist(product.id); }}
                          className={`absolute top-3 right-3 p-2 rounded-full transition-colors ${isWishlisted ? 'bg-[#241E1C] text-[#C8A97E]' : 'bg-white/80 text-[#241E1C] hover:bg-white'}`}
                          title="Save to Wishlist"
                        >
                          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
                        </button>

                        <div className="absolute inset-x-0 bottom-3 px-3 opacity-0 group-hover:opacity-100 transition-opacity flex gap-2">
                          <button
                            onClick={() => onSelectProduct(product)}
                            className="flex-1 bg-white/95 text-[#241E1C] hover:bg-[#241E1C] hover:text-white py-2 text-xs font-medium tracking-wide shadow transition-colors flex items-center justify-center gap-1.5"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            Select Options
                          </button>
                        </div>
                      </div>

                      {/* Content */}
                      <div className="p-4 flex flex-col flex-1 justify-between">
                        <div>
                          <div className="text-[10px] uppercase tracking-widest text-[#786D65] mb-1">
                            {product.category} · {product.gender}
                          </div>
                          <h3
                            onClick={() => onSelectProduct(product)}
                            className="font-serif text-base text-[#241E1C] hover:text-[#C8A97E] transition-colors cursor-pointer line-clamp-1"
                          >
                            {product.title}
                          </h3>
                          <p className="text-xs text-[#594B42] line-clamp-1 mt-0.5">
                            {product.subtitle}
                          </p>
                        </div>

                        <div className="mt-4 pt-3 border-t border-[#F4EFEB] flex items-center justify-between">
                          <span className="text-sm font-medium text-[#241E1C]">
                            ${minPrice.toFixed(2)}
                          </span>
                          <span className="text-[10px] text-[#786D65]">
                            {product.variants.length} variants available
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
