import React, { useState } from 'react';
import { Order } from '../types';
import { CheckCircle2, Package, Truck, Store, ArrowLeft, RefreshCw, XCircle } from 'lucide-react';

interface OrderConfirmationViewProps {
  order: Order;
  onReturnToStore: () => void;
  onRequestReturn: (orderId: string, reason: string) => void;
  onRequestCancel: (orderId: string) => void;
}

export const OrderConfirmationView: React.FC<OrderConfirmationViewProps> = ({
  order,
  onReturnToStore,
  onRequestReturn,
  onRequestCancel
}) => {
  const [returnReason, setReturnReason] = useState<string>('Incorrect size / fit');
  const [returnModalOpen, setReturnModalOpen] = useState<boolean>(false);

  return (
    <div className="bg-[#F9F6F0] min-h-screen py-12 px-4 sm:px-6 lg:px-8 text-[#241E1C]">
      <div className="max-w-4xl mx-auto space-y-8">
        <button
          onClick={onReturnToStore}
          className="inline-flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-[#786D65] hover:text-[#241E1C] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Continue Shopping
        </button>

        {/* Success Banner */}
        <div className="bg-white rounded-xl border border-[#E6E0D5] p-8 sm:p-12 text-center shadow-sm space-y-4">
          <CheckCircle2 className="w-16 h-16 text-emerald-700 mx-auto" />
          <h1 className="font-serif text-3xl sm:text-4xl text-[#241E1C]">
            Thank you for your order.
          </h1>
          <p className="text-sm text-[#594B42]">
            Order confirmation <span className="font-bold text-[#241E1C]">{order.orderNumber}</span> has been securely placed and recorded.
          </p>
          <div className="inline-flex items-center gap-2 bg-[#EFECE6] px-4 py-2 rounded text-xs font-semibold text-[#241E1C]">
            Status: {order.status}
          </div>
        </div>

        {/* Order Details & Items */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-2 bg-white rounded-xl border border-[#E6E0D5] p-6 sm:p-8 space-y-6 shadow-sm">
            <h3 className="font-serif text-xl text-[#241E1C] pb-4 border-b border-[#E6E0D5]">
              Purchased Item Snapshots
            </h3>

            <div className="space-y-4 divide-y divide-[#F4EFEB]">
              {order.items.map((item, idx) => (
                <div key={idx} className="pt-4 first:pt-0 flex gap-4 text-xs">
                  <div className="w-16 h-20 bg-[#EFECE6] rounded overflow-hidden shrink-0">
                    <img src={item.image} alt="" className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-serif text-sm text-[#241E1C]">{item.title}</h4>
                    <p className="text-[#786D65]">Colour: {item.colour} · Size: {item.size}</p>
                    <p className="font-mono text-[10px] text-[#A8988D]">SKU: {item.sku}</p>
                    <p className="text-[#786D65]">Qty: {item.quantity}</p>
                  </div>
                  <span className="font-semibold text-sm text-[#241E1C]">
                    ${(item.price * item.quantity).toFixed(2)}
                  </span>
                </div>
              ))}
            </div>

            <div className="pt-4 border-t border-[#E6E0D5] space-y-2 text-xs text-[#594B42]">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-semibold text-[#241E1C]">${order.subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Shipping ({order.fulfillmentType})</span>
                <span className="font-semibold text-[#241E1C]">${order.shippingFee.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Tax</span>
                <span className="font-semibold text-[#241E1C]">${order.tax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-base font-semibold text-[#241E1C] pt-2 border-t border-[#E6E0D5]">
                <span>Total Paid</span>
                <span>${order.total.toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Fulfilment & Actions */}
          <div className="space-y-6">
            <div className="bg-white rounded-xl border border-[#E6E0D5] p-6 space-y-4 shadow-sm">
              <h3 className="font-serif text-lg text-[#241E1C]">Fulfilment Details</h3>
              <div className="text-xs text-[#594B42] space-y-2">
                <div className="flex items-center gap-2">
                  {order.fulfillmentType === 'Delivery' ? <Truck className="w-4 h-4 text-[#C8A97E]" /> : <Store className="w-4 h-4 text-[#C8A97E]" />}
                  <span className="font-semibold text-[#241E1C]">{order.fulfillmentType}</span>
                </div>
                {order.shippingAddress ? (
                  <p>
                    {order.shippingAddress.fullName}<br />
                    {order.shippingAddress.line1}<br />
                    {order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.postalCode}
                  </p>
                ) : (
                  <p>Store Pickup at Flagship Location. Please bring order confirmation and photo ID.</p>
                )}
                {order.trackingNumber && (
                  <p className="font-mono text-[11px] pt-2 border-t border-[#E6E0D5]">
                    Tracking: <span className="font-bold">{order.trackingNumber}</span>
                  </p>
                )}
              </div>
            </div>

            {/* Actions for Returns / Cancel */}
            <div className="bg-white rounded-xl border border-[#E6E0D5] p-6 space-y-4 shadow-sm">
              <h3 className="font-serif text-lg text-[#241E1C]">Manage Order</h3>
              <div className="space-y-3">
                {order.status === 'Processing' && (
                  <button
                    onClick={() => onRequestCancel(order.id)}
                    className="w-full bg-rose-50 text-rose-700 hover:bg-rose-100 text-xs py-2.5 rounded font-medium transition-colors flex items-center justify-center gap-1.5"
                  >
                    <XCircle className="w-4 h-4" />
                    Request Order Cancellation
                  </button>
                )}

                <button
                  onClick={() => setReturnModalOpen(true)}
                  className="w-full bg-[#EFECE6] text-[#241E1C] hover:bg-[#241E1C] hover:text-white text-xs py-2.5 rounded font-medium transition-colors flex items-center justify-center gap-1.5"
                >
                  <RefreshCw className="w-4 h-4" />
                  Request Return / Exchange
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Return Request Modal */}
      {returnModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-[#FBF9F5] rounded-xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-[#E6E0D5] space-y-6">
            <h3 className="font-serif text-2xl text-[#241E1C]">Submit Return Request</h3>
            <p className="text-xs text-[#594B42]">
              Select a reason for returning items from order <span className="font-bold">{order.orderNumber}</span>.
            </p>

            <div className="space-y-2">
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#786D65]">Reason for Return</label>
              <select
                value={returnReason}
                onChange={(e) => setReturnReason(e.target.value)}
                className="w-full bg-white border border-[#DCD3C9] text-xs p-3 rounded focus:outline-none focus:border-[#241E1C]"
              >
                <option value="Incorrect size / fit">Incorrect size / fit</option>
                <option value="Colour differs from expectations">Colour differs from expectations</option>
                <option value="Fabric quality or texture mismatch">Fabric quality or texture mismatch</option>
                <option value="Damaged upon arrival">Damaged upon arrival</option>
              </select>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t border-[#E6E0D5]">
              <button
                onClick={() => setReturnModalOpen(false)}
                className="px-4 py-2 text-xs bg-[#EFECE6] text-[#241E1C]"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onRequestReturn(order.id, returnReason);
                  setReturnModalOpen(false);
                }}
                className="px-5 py-2 text-xs bg-[#241E1C] text-white hover:bg-[#C8A97E] hover:text-[#241E1C]"
              >
                Confirm Return Request
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
