import React, { useState } from 'react';
import { StoreLocation } from '../types';
import { MapPin, Clock, Phone, Store, ArrowLeft, Check } from 'lucide-react';

interface StoreFinderViewProps {
  stores: StoreLocation[];
  onBackToStore: () => void;
}

export const StoreFinderView: React.FC<StoreFinderViewProps> = ({ stores, onBackToStore }) => {
  const [selectedCity, setSelectedCity] = useState<string>('All');

  const cities = ['All', 'New York, NY', 'Los Angeles, CA', 'London, UK', 'Chicago, IL'];

  const filteredStores = stores.filter(s => selectedCity === 'All' || s.city === selectedCity);

  return (
    <div className="bg-[#F9F6F0] min-h-screen py-12 px-4 sm:px-6 lg:px-8 text-[#241E1C]">
      <div className="max-w-7xl mx-auto space-y-8">
        <button
          onClick={onBackToStore}
          className="inline-flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-[#786D65] hover:text-[#241E1C] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Storefront
        </button>

        <div className="border-b border-[#E6E0D5] pb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="text-xs uppercase tracking-widest text-[#786D65] mb-2 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#C8A97E]" />
              Retail Presence & Collection Hubs
            </div>
            <h1 className="font-serif text-3xl sm:text-4xl text-[#241E1C]">
              Store Locator & In-Store Pickup
            </h1>
          </div>

          <div className="flex gap-2">
            {cities.map(c => (
              <button
                key={c}
                onClick={() => setSelectedCity(c)}
                className={`text-xs px-3.5 py-2 border rounded transition-colors ${selectedCity === c ? 'bg-[#241E1C] text-white border-[#241E1C]' : 'bg-white text-[#241E1C] border-[#DCD3C9] hover:border-[#241E1C]'}`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredStores.map(store => (
            <div key={store.id} className="bg-white rounded-xl border border-[#E6E0D5] p-8 shadow-sm space-y-6 flex flex-col justify-between">
              <div className="space-y-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-serif text-xl text-[#241E1C]">{store.name}</h3>
                    <p className="text-xs text-[#786D65]">{store.city}</p>
                  </div>
                  {store.collectionEligible && (
                    <span className="bg-[#EFECE6] text-[#241E1C] text-[10px] uppercase tracking-wider px-2.5 py-1 rounded font-medium flex items-center gap-1">
                      <Check className="w-3 h-3 text-emerald-700" />
                      Pickup Eligible
                    </span>
                  )}
                </div>

                <div className="space-y-2 text-xs text-[#594B42]">
                  <div className="flex items-start gap-2">
                    <MapPin className="w-4 h-4 text-[#C8A97E] shrink-0 mt-0.5" />
                    <span>{store.address}</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Clock className="w-4 h-4 text-[#C8A97E] shrink-0 mt-0.5" />
                    <span>{store.hours}</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Phone className="w-4 h-4 text-[#C8A97E] shrink-0 mt-0.5" />
                    <span>{store.phone}</span>
                  </div>
                </div>

                <div className="pt-4 border-t border-[#F4EFEB]">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-[#786D65] mb-2">Available Services</h4>
                  <div className="flex flex-wrap gap-2">
                    {store.services.map((svc, idx) => (
                      <span key={idx} className="bg-[#F9F6F0] border border-[#DCD3C9] text-[10px] px-2.5 py-1 rounded text-[#241E1C]">
                        {svc}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <button
                onClick={() => alert(`Selected ${store.name} for collection or appointment booking.`)}
                className="w-full bg-[#241E1C] text-white hover:bg-[#C8A97E] hover:text-[#241E1C] text-xs py-3 font-medium transition-colors"
              >
                Select Store for Pickup
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
