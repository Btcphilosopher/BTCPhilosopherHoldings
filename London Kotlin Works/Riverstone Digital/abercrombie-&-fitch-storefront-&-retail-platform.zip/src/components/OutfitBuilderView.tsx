import React, { useState } from 'react';
import { Product, ProductVariant, SavedOutfit, OutfitItem } from '../types';
import { Sparkles, ShoppingBag, Plus, Trash2, Check, AlertCircle } from 'lucide-react';

interface OutfitBuilderViewProps {
  products: Product[];
  savedOutfits: SavedOutfit[];
  onAddOutfitToCart: (items: OutfitItem[]) => void;
  onSaveNewOutfit: (outfit: SavedOutfit) => void;
}

export const OutfitBuilderView: React.FC<OutfitBuilderViewProps> = ({
  products,
  savedOutfits,
  onAddOutfitToCart,
  onSaveNewOutfit
}) => {
  const [outfitName, setOutfitName] = useState<string>('My Custom Capsule Outfit');
  const [selectedSlots, setSelectedSlots] = useState<{
    Top?: { product: Product; variant: ProductVariant };
    Bottom?: { product: Product; variant: ProductVariant };
    Footwear?: { product: Product; variant: ProductVariant };
    Accessory?: { product: Product; variant: ProductVariant };
  }>({});

  const [activeSlotModal, setActiveSlotModal] = useState<'Top' | 'Bottom' | 'Footwear' | 'Accessory' | null>(null);
  const [successMessage, setSuccessMessage] = useState<string>('');

  // Filter products by slot
  const slotFilteredProducts = products.filter(p => {
    if (!activeSlotModal) return false;
    if (activeSlotModal === 'Top') return p.category === 'Linen' || p.category === 'Polos & tees' || p.category === 'Knitwear';
    if (activeSlotModal === 'Bottom') return p.category === 'Denim';
    if (activeSlotModal === 'Footwear') return p.category === 'Outerwear' || p.category === 'Dresses'; // illustrative mapping
    if (activeSlotModal === 'Accessory') return p.category === 'Outerwear';
    return true;
  });

  const [selectedModalProduct, setSelectedModalProduct] = useState<Product | null>(null);
  const [selectedModalVariant, setSelectedModalVariant] = useState<ProductVariant | null>(null);

  const handleOpenSlot = (slot: 'Top' | 'Bottom' | 'Footwear' | 'Accessory') => {
    setActiveSlotModal(slot);
    setSelectedModalProduct(null);
    setSelectedModalVariant(null);
  };

  const handleConfirmSlotSelection = () => {
    if (!activeSlotModal || !selectedModalProduct || !selectedModalVariant) return;
    setSelectedSlots(prev => ({
      ...prev,
      [activeSlotModal]: { product: selectedModalProduct, variant: selectedModalVariant }
    }));
    setActiveSlotModal(null);
  };

  const handleRemoveSlot = (slot: 'Top' | 'Bottom' | 'Footwear' | 'Accessory') => {
    setSelectedSlots(prev => {
      const copy = { ...prev };
      delete copy[slot];
      return copy;
    });
  };

  const currentItemsList: OutfitItem[] = Object.entries(selectedSlots).map(([slot, data]) => ({
    slot: slot as any,
    productId: data.product.id,
    sku: data.variant.sku,
    title: data.product.title,
    colour: data.variant.colour,
    size: data.variant.size,
    price: data.variant.price,
    image: data.product.images[0]
  }));

  const combinedTotal = currentItemsList.reduce((acc, item) => acc + item.price, 0);

  const handleAddOutfitToBag = () => {
    if (currentItemsList.length === 0) return;
    onAddOutfitToCart(currentItemsList);
    setSuccessMessage('Successfully added all exact outfit variants to your shopping bag!');
    setTimeout(() => setSuccessMessage(''), 4000);
  };

  const handleSaveOutfit = () => {
    if (currentItemsList.length === 0) return;
    const newOutfit: SavedOutfit = {
      id: `outfit-${Date.now()}`,
      name: outfitName,
      createdAt: new Date().toISOString().split('T')[0],
      items: currentItemsList
    };
    onSaveNewOutfit(newOutfit);
    setSuccessMessage('Outfit saved successfully to your account profile!');
    setTimeout(() => setSuccessMessage(''), 4000);
  };

  return (
    <div className="bg-[#F9F6F0] min-h-screen py-12 px-4 sm:px-6 lg:px-8 text-[#241E1C]">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Title & Header */}
        <div className="border-b border-[#E6E0D5] pb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="text-xs uppercase tracking-widest text-[#786D65] mb-2 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#C8A97E]" />
              Interactive Capsule Studio
            </div>
            <h1 className="font-serif text-3xl sm:text-4xl text-[#241E1C]">
              Outfit Builder & Capsule Creator
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <input
              type="text"
              value={outfitName}
              onChange={(e) => setOutfitName(e.target.value)}
              className="bg-white border border-[#DCD3C9] text-xs px-3 py-2 rounded focus:outline-none focus:border-[#241E1C] font-medium"
              placeholder="Outfit Name"
            />
            <button
              onClick={handleSaveOutfit}
              disabled={currentItemsList.length === 0}
              className="bg-[#241E1C] text-white text-xs px-5 py-2.5 hover:bg-[#C8A97E] hover:text-[#241E1C] transition-colors disabled:opacity-50"
            >
              Save Outfit
            </button>
          </div>
        </div>

        {successMessage && (
          <div className="bg-[#EAE3DC] text-[#241E1C] p-4 rounded-lg text-xs font-medium border border-[#DCD3C9] flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-700" />
            {successMessage}
          </div>
        )}

        {/* Builder Canvas Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Slots (Left 8 Cols) */}
          <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-6">
            {(['Top', 'Bottom', 'Footwear', 'Accessory'] as const).map(slot => {
              const slotData = selectedSlots[slot];
              return (
                <div
                  key={slot}
                  className="bg-white rounded-xl border border-[#E6E0D5] p-6 shadow-sm flex flex-col justify-between min-h-[320px]"
                >
                  <div className="flex items-center justify-between pb-4 border-b border-[#E6E0D5]">
                    <span className="text-xs font-semibold uppercase tracking-wider text-[#786D65]">{slot}</span>
                    {slotData && (
                      <button
                        onClick={() => handleRemoveSlot(slot)}
                        className="text-rose-600 hover:text-rose-800 text-xs flex items-center gap-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        Remove
                      </button>
                    )}
                  </div>

                  {slotData ? (
                    <div className="py-4 space-y-3">
                      <div className="aspect-[4/3] bg-[#EFECE6] rounded overflow-hidden">
                        <img src={slotData.product.images[0]} alt="" className="w-full h-full object-cover" />
                      </div>
                      <div>
                        <h4 className="font-serif text-base text-[#241E1C]">{slotData.product.title}</h4>
                        <p className="text-xs text-[#594B42]">Colour: {slotData.variant.colour} · Size: {slotData.variant.size}</p>
                        <div className="text-sm font-semibold text-[#241E1C] mt-1">${slotData.variant.price.toFixed(2)}</div>
                      </div>
                    </div>
                  ) : (
                    <div className="py-12 text-center flex flex-col items-center justify-center space-y-3">
                      <div className="w-12 h-12 rounded-full bg-[#F9F6F0] border border-[#DCD3C9] flex items-center justify-center text-[#786D65]">
                        <Plus className="w-6 h-6" />
                      </div>
                      <p className="text-xs text-[#786D65]">No {slot.toLowerCase()} selected yet</p>
                    </div>
                  )}

                  <button
                    onClick={() => handleOpenSlot(slot)}
                    className="w-full bg-[#241E1C] text-white hover:bg-[#C8A97E] hover:text-[#241E1C] text-xs py-2.5 transition-colors font-medium mt-4"
                  >
                    {slotData ? 'Change Selection' : `Select ${slot}`}
                  </button>
                </div>
              );
            })}
          </div>

          {/* Summary Sidebar (Right 4 Cols) */}
          <div className="lg:col-span-4 bg-white rounded-xl border border-[#E6E0D5] p-6 shadow-sm h-fit space-y-6">
            <h3 className="font-serif text-xl text-[#241E1C] pb-4 border-b border-[#E6E0D5]">
              Outfit Summary
            </h3>

            <div className="space-y-4">
              {currentItemsList.length === 0 ? (
                <p className="text-xs text-[#786D65] italic py-6 text-center">
                  Select items across slots to build your complete outfit capsule.
                </p>
              ) : (
                currentItemsList.map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs py-2 border-b border-[#F4EFEB]">
                    <div>
                      <span className="font-bold block">{item.slot}: {item.title}</span>
                      <span className="text-[#786D65]">{item.colour} / {item.size}</span>
                    </div>
                    <span className="font-semibold">${item.price.toFixed(2)}</span>
                  </div>
                ))
              )}
            </div>

            <div className="pt-4 border-t border-[#E6E0D5] space-y-2">
              <div className="flex justify-between text-sm font-semibold text-[#241E1C]">
                <span>Combined Total</span>
                <span>${combinedTotal.toFixed(2)}</span>
              </div>
              <p className="text-[10px] text-[#786D65]">
                Prices reflect exact variant selections. Stock is verified transactionally upon adding to bag.
              </p>
            </div>

            <button
              onClick={handleAddOutfitToBag}
              disabled={currentItemsList.length === 0}
              className="w-full bg-[#1C1715] text-white hover:bg-[#C8A97E] hover:text-[#1C1715] text-sm py-3.5 font-medium transition-colors flex items-center justify-center gap-2 shadow-sm disabled:opacity-50"
            >
              <ShoppingBag className="w-4 h-4" />
              Add Entire Outfit to Bag
            </button>
          </div>
        </div>

        {/* Previously Saved Outfits Section */}
        {savedOutfits.length > 0 && (
          <div className="pt-12 border-t border-[#E6E0D5] space-y-6">
            <h3 className="font-serif text-2xl text-[#241E1C]">Your Saved Outfits</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {savedOutfits.map(outfit => (
                <div key={outfit.id} className="bg-white rounded-lg border border-[#E6E0D5] p-6 space-y-4 shadow-sm">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-serif text-lg text-[#241E1C]">{outfit.name}</h4>
                      <span className="text-xs text-[#786D65]">Created {outfit.createdAt}</span>
                    </div>
                    <span className="text-xs bg-[#EFECE6] px-2.5 py-1 rounded font-medium">
                      {outfit.items.length} items
                    </span>
                  </div>
                  <div className="flex gap-2">
                    {outfit.items.map((it, idx) => (
                      <div key={idx} className="w-12 h-16 bg-[#EFECE6] rounded overflow-hidden">
                        <img src={it.image} alt="" className="w-full h-full object-cover" />
                      </div>
                    ))}
                  </div>
                  <button
                    onClick={() => onAddOutfitToCart(outfit.items)}
                    className="w-full bg-[#241E1C] text-white hover:bg-[#C8A97E] hover:text-[#1C1715] text-xs py-2.5 transition-colors"
                  >
                    Add Outfit to Bag
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Slot Selection Modal */}
      {activeSlotModal && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-[#FBF9F5] rounded-xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-[#E6E0D5] space-y-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-[#E6E0D5]">
              <h3 className="font-serif text-2xl text-[#241E1C]">Select {activeSlotModal}</h3>
              <button
                onClick={() => setActiveSlotModal(null)}
                className="text-xs uppercase tracking-wider text-[#786D65] hover:text-[#241E1C]"
              >
                Cancel
              </button>
            </div>

            {/* Product selection for slot */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {slotFilteredProducts.map(product => {
                const isSelectedProd = selectedModalProduct?.id === product.id;
                return (
                  <div
                    key={product.id}
                    onClick={() => {
                      setSelectedModalProduct(product);
                      setSelectedModalVariant(product.variants[0] || null);
                    }}
                    className={`bg-white rounded-lg border p-4 cursor-pointer transition-all flex gap-4 items-center ${isSelectedProd ? 'border-[#241E1C] ring-2 ring-[#C8A97E]' : 'border-[#E6E0D5] hover:border-[#241E1C]'}`}
                  >
                    <div className="w-16 h-20 bg-[#EFECE6] rounded overflow-hidden shrink-0">
                      <img src={product.images[0]} alt="" className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-serif text-sm text-[#241E1C]">{product.title}</h4>
                      <p className="text-xs text-[#786D65]">${product.basePrice.toFixed(2)}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Variant selection for chosen product */}
            {selectedModalProduct && (
              <div className="space-y-4 pt-4 border-t border-[#E6E0D5]">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-[#786D65]">
                  Select Variant for {selectedModalProduct.title}
                </h4>
                <div className="grid grid-cols-3 gap-2">
                  {selectedModalProduct.variants.map(v => {
                    const isSelectedVar = selectedModalVariant?.sku === v.sku;
                    return (
                      <button
                        key={v.sku}
                        onClick={() => setSelectedModalVariant(v)}
                        disabled={!v.isAvailable}
                        className={`p-2.5 border text-xs text-center rounded transition-all ${isSelectedVar ? 'bg-[#241E1C] text-white border-[#241E1C] font-bold' : v.isAvailable ? 'bg-white text-[#241E1C] border-[#DCD3C9]' : 'bg-[#EFECE6] text-[#A8988D] line-through'}`}
                      >
                        {v.colour} / {v.size} (${v.price})
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            <div className="flex justify-end gap-3 pt-4 border-t border-[#E6E0D5]">
              <button
                onClick={() => setActiveSlotModal(null)}
                className="px-5 py-2.5 text-xs bg-[#EFECE6] text-[#241E1C]"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmSlotSelection}
                disabled={!selectedModalProduct || !selectedModalVariant}
                className="px-6 py-2.5 text-xs bg-[#241E1C] text-white hover:bg-[#C8A97E] hover:text-[#241E1C] disabled:opacity-50"
              >
                Confirm {activeSlotModal} Selection
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
