import React from 'react';
import { CartItem } from '../types';
import { X, Trash2, ShoppingBag, ArrowRight } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (sku: string, qty: number) => void;
  onRemoveItem: (sku: string) => void;
  onProceedToCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout
}) => {
  if (!isOpen) return null;

  const subtotal = cartItems.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const freeShippingThreshold = 75.00;
  const progressToFreeShipping = Math.min(100, (subtotal / freeShippingThreshold) * 100);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm transition-opacity" onClick={onClose} />

      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#FBF9F5] shadow-2xl flex flex-col border-l border-[#E6E0D5]">
          {/* Header */}
          <div className="p-6 border-b border-[#E6E0D5] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#241E1C]" />
              <h2 className="font-serif text-xl text-[#241E1C]">Shopping Bag ({cartItems.reduce((a, b) => a + b.quantity, 0)})</h2>
            </div>
            <button onClick={onClose} className="text-[#786D65] hover:text-[#241E1C]">
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Free Shipping Progress */}
          <div className="bg-[#EFECE6] p-4 border-b border-[#E6E0D5]">
            <div className="flex justify-between text-xs text-[#594B42] mb-1.5 font-medium">
              <span>{subtotal >= freeShippingThreshold ? 'You qualify for Free Standard Shipping!' : `Add $${(freeShippingThreshold - subtotal).toFixed(2)} more for Free Shipping`}</span>
              <span>{progressToFreeShipping.toFixed(0)}%</span>
            </div>
            <div className="w-full bg-[#DCD3C9] h-1.5 rounded-full overflow-hidden">
              <div className="bg-[#241E1C] h-full transition-all duration-300" style={{ width: `${progressToFreeShipping}%` }} />
            </div>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6 divide-y divide-[#E6E0D5]">
            {cartItems.length === 0 ? (
              <div className="text-center py-24 space-y-4">
                <ShoppingBag className="w-12 h-12 text-[#DCD3C9] mx-auto" />
                <p className="font-serif text-lg text-[#241E1C]">Your bag is currently empty.</p>
                <p className="text-xs text-[#786D65]">Explore our collections and add your everyday essentials.</p>
                <button
                  onClick={onClose}
                  className="bg-[#241E1C] text-white text-xs px-6 py-2.5 hover:bg-[#C8A97E] hover:text-[#241E1C] transition-colors"
                >
                  Start Shopping
                </button>
              </div>
            ) : (
              cartItems.map((item) => (
                <div key={item.sku} className="pt-6 first:pt-0 flex gap-4">
                  <div className="w-20 h-24 bg-[#EFECE6] rounded overflow-hidden shrink-0">
                    <img src={item.image} alt="" className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-start">
                        <h4 className="font-serif text-sm text-[#241E1C]">{item.title}</h4>
                        <button
                          onClick={() => onRemoveItem(item.sku)}
                          className="text-[#786D65] hover:text-rose-600 transition-colors"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <p className="text-xs text-[#786D65] mt-0.5">
                        Colour: {item.colour} · Size: {item.size} {item.length ? `(${item.length})` : ''}
                      </p>
                      <span className="text-[10px] text-[#A8988D] block font-mono">SKU: {item.sku}</span>
                    </div>

                    <div className="flex items-center justify-between mt-4">
                      <div className="flex items-center border border-[#DCD3C9] rounded bg-white">
                        <button
                          onClick={() => onUpdateQuantity(item.sku, item.quantity - 1)}
                          className="px-2 py-1 text-xs text-[#786D65] hover:text-[#241E1C]"
                        >
                          -
                        </button>
                        <span className="px-3 py-1 text-xs font-semibold">{item.quantity}</span>
                        <button
                          onClick={() => onUpdateQuantity(item.sku, item.quantity + 1)}
                          className="px-2 py-1 text-xs text-[#786D65] hover:text-[#241E1C]"
                        >
                          +
                        </button>
                      </div>
                      <span className="text-sm font-semibold text-[#241E1C]">
                        ${(item.price * item.quantity).toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer Subtotal & Checkout */}
          {cartItems.length > 0 && (
            <div className="p-6 bg-white border-t border-[#E6E0D5] space-y-4">
              <div className="space-y-2 text-xs">
                <div className="flex justify-between text-[#594B42]">
                  <span>Merchandise Subtotal</span>
                  <span className="font-semibold text-[#241E1C]">${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-[#594B42]">
                  <span>Estimated Shipping</span>
                  <span className="font-semibold text-[#241E1C]">{subtotal >= freeShippingThreshold ? 'FREE' : '$8.00'}</span>
                </div>
                <div className="flex justify-between text-base font-semibold text-[#241E1C] pt-2 border-t border-[#E6E0D5]">
                  <span>Estimated Total</span>
                  <span>${(subtotal + (subtotal >= freeShippingThreshold ? 0 : 8.00)).toFixed(2)}</span>
                </div>
              </div>

              <button
                onClick={() => { onClose(); onProceedToCheckout(); }}
                className="w-full bg-[#1C1715] text-white hover:bg-[#C8A97E] hover:text-[#1C1715] text-sm py-4 font-medium transition-colors flex items-center justify-center gap-2 shadow-sm"
              >
                <span>Proceed to Secure Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
