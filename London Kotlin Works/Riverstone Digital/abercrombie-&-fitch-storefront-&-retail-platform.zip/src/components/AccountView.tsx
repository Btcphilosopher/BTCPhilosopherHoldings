import React, { useState } from 'react';
import { Order, SavedOutfit } from '../types';
import { User, Package, Heart, Shield, Download, Trash2, ArrowLeft, Check } from 'lucide-react';

interface AccountViewProps {
  orders: Order[];
  savedOutfits: SavedOutfit[];
  wishlistCount: number;
  onBackToStore: () => void;
  onSelectOrder: (order: Order) => void;
}

export const AccountView: React.FC<AccountViewProps> = ({
  orders,
  savedOutfits,
  wishlistCount,
  onBackToStore,
  onSelectOrder
}) => {
  const [activeTab, setActiveTab] = useState<'orders' | 'outfits' | 'preferences' | 'privacy'>('orders');
  const [exportSuccess, setExportSuccess] = useState(false);
  const [deleteRequested, setDeleteRequested] = useState(false);

  const handleExportData = () => {
    setExportSuccess(true);
    setTimeout(() => setExportSuccess(false), 4000);
  };

  const handleDeleteAccountRequest = () => {
    setDeleteRequested(true);
  };

  return (
    <div className="bg-[#F9F6F0] min-h-screen py-12 px-4 sm:px-6 lg:px-8 text-[#241E1C]">
      <div className="max-w-7xl mx-auto space-y-8">
        <button
          onClick={onBackToStore}
          className="inline-flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-[#786D65] hover:text-[#241E1C] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Storefront
        </button>

        {/* Profile Header */}
        <div className="bg-white rounded-xl border border-[#E6E0D5] p-8 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-[#EFECE6] flex items-center justify-center text-[#241E1C]">
              <User className="w-8 h-8" />
            </div>
            <div>
              <h1 className="font-serif text-2xl text-[#241E1C]">Sarah Jenkins</h1>
              <p className="text-xs text-[#786D65]">sarah.jenkins@example.com · VIP Tier Member</p>
            </div>
          </div>

          <div className="flex gap-4 text-xs font-medium">
            <div className="bg-[#F9F6F0] px-4 py-3 rounded border border-[#DCD3C9] text-center">
              <span className="block font-bold text-base text-[#241E1C]">{orders.length}</span>
              <span className="text-[#786D65]">Orders Placed</span>
            </div>
            <div className="bg-[#F9F6F0] px-4 py-3 rounded border border-[#DCD3C9] text-center">
              <span className="block font-bold text-base text-[#241E1C]">{savedOutfits.length}</span>
              <span className="text-[#786D65]">Saved Outfits</span>
            </div>
            <div className="bg-[#F9F6F0] px-4 py-3 rounded border border-[#DCD3C9] text-center">
              <span className="block font-bold text-base text-[#241E1C]">{wishlistCount}</span>
              <span className="text-[#786D65]">Saved Items</span>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-[#E6E0D5] gap-8 text-sm font-medium">
          {[
            { id: 'orders', label: 'Order History & Receipts' },
            { id: 'outfits', label: 'Saved Outfits & Capsules' },
            { id: 'preferences', label: 'Communication Preferences' },
            { id: 'privacy', label: 'Data Privacy & Export' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`pb-3 border-b-2 transition-colors ${activeTab === tab.id ? 'border-[#241E1C] text-[#241E1C] font-semibold' : 'border-transparent text-[#786D65] hover:text-[#241E1C]'}`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="space-y-6">
          {activeTab === 'orders' && (
            <div className="space-y-4">
              <h3 className="font-serif text-xl text-[#241E1C]">Order History</h3>
              {orders.length === 0 ? (
                <p className="text-xs text-[#786D65] bg-white p-8 rounded-lg border border-[#E6E0D5]">No orders placed yet.</p>
              ) : (
                <div className="space-y-4">
                  {orders.map(ord => (
                    <div
                      key={ord.id}
                      onClick={() => onSelectOrder(ord)}
                      className="bg-white rounded-xl border border-[#E6E0D5] p-6 shadow-sm hover:border-[#241E1C] cursor-pointer transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-3">
                          <span className="font-serif text-lg font-bold text-[#241E1C]">{ord.orderNumber}</span>
                          <span className="text-xs bg-[#EFECE6] px-2.5 py-1 rounded font-medium">{ord.status}</span>
                        </div>
                        <p className="text-xs text-[#786D65]">Placed on {ord.createdAt} · {ord.fulfillmentType}</p>
                        <p className="text-xs text-[#594B42]">{ord.items.length} items</p>
                      </div>

                      <div className="flex items-center gap-4">
                        <span className="text-base font-semibold text-[#241E1C]">${ord.total.toFixed(2)}</span>
                        <span className="text-xs text-[#C8A97E] font-medium underline">View Receipt & Details →</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'outfits' && (
            <div className="space-y-4">
              <h3 className="font-serif text-xl text-[#241E1C]">Saved Outfits & Capsules</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {savedOutfits.map(outfit => (
                  <div key={outfit.id} className="bg-white rounded-lg border border-[#E6E0D5] p-6 space-y-4 shadow-sm">
                    <h4 className="font-serif text-lg text-[#241E1C]">{outfit.name}</h4>
                    <span className="text-xs text-[#786D65]">Created {outfit.createdAt}</span>
                    <div className="flex gap-2">
                      {outfit.items.map((it, idx) => (
                        <div key={idx} className="w-12 h-16 bg-[#EFECE6] rounded overflow-hidden">
                          <img src={it.image} alt="" className="w-full h-full object-cover" />
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'preferences' && (
            <div className="bg-white rounded-xl border border-[#E6E0D5] p-8 space-y-6 shadow-sm max-w-2xl">
              <h3 className="font-serif text-xl text-[#241E1C]">Communication & Styling Preferences</h3>
              <div className="space-y-4 text-xs text-[#594B42]">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input type="checkbox" defaultChecked className="rounded border-[#DCD3C9]" />
                  <span>Receive email alerts for new capsule drops and private seasonal sales.</span>
                </label>
                <label className="flex items-center gap-3 cursor-pointer">
                  <input type="checkbox" defaultChecked className="rounded border-[#DCD3C9]" />
                  <span>SMS notifications for in-store pickup ready status and delivery tracking.</span>
                </label>
                <label className="flex items-center gap-3 cursor-pointer">
                  <input type="checkbox" className="rounded border-[#DCD3C9]" />
                  <span>Personalised editorial styling recommendations based on saved items.</span>
                </label>
              </div>
              <button className="bg-[#241E1C] text-white text-xs px-6 py-2.5 hover:bg-[#C8A97E] hover:text-[#241E1C] transition-colors">
                Save Preferences
              </button>
            </div>
          )}

          {activeTab === 'privacy' && (
            <div className="bg-white rounded-xl border border-[#E6E0D5] p-8 space-y-6 shadow-sm max-w-2xl">
              <h3 className="font-serif text-xl text-[#241E1C]">Data Export & Account Deletion Requests</h3>
              <p className="text-xs text-[#594B42] leading-relaxed">
                In compliance with privacy regulations, you may request a complete export of your account data (orders, saved outfits, preferences) or request permanent deletion of your customer profile.
              </p>

              {exportSuccess && (
                <div className="bg-[#EAE3DC] text-[#241E1C] p-3 rounded text-xs flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-700" />
                  Your account data archive (JSON format) has been successfully generated and downloaded.
                </div>
              )}

              <div className="flex flex-col sm:flex-row gap-4 pt-4 border-t border-[#E6E0D5]">
                <button
                  onClick={handleExportData}
                  className="bg-[#241E1C] text-white text-xs px-6 py-3 font-medium flex items-center justify-center gap-2 hover:bg-[#C8A97E] hover:text-[#241E1C] transition-colors"
                >
                  <Download className="w-4 h-4" />
                  Export Account Data (GDPR / CCPA)
                </button>
                <button
                  onClick={handleDeleteAccountRequest}
                  className="bg-rose-50 text-rose-700 hover:bg-rose-100 text-xs px-6 py-3 font-medium flex items-center justify-center gap-2 transition-colors border border-rose-200"
                >
                  <Trash2 className="w-4 h-4" />
                  Request Account Deletion
                </button>
              </div>

              {deleteRequested && (
                <div className="bg-rose-50 text-rose-800 p-4 rounded text-xs border border-rose-200">
                  Account deletion request logged. A secure verification link has been sent to sarah.jenkins@example.com.
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
