import React, { useState } from 'react';
import { CartItem, StoreLocation, Order } from '../types';
import { ShieldCheck, Truck, Store, CreditCard, Check, AlertCircle, ArrowLeft, Sparkles } from 'lucide-react';

interface CheckoutViewProps {
  cartItems: CartItem[];
  stores: StoreLocation[];
  onBackToCatalogue: () => void;
  onOrderPlaced: (order: Order) => void;
  onClearCart: () => void;
}

export const CheckoutView: React.FC<CheckoutViewProps> = ({
  cartItems,
  stores,
  onBackToCatalogue,
  onOrderPlaced,
  onClearCart
}) => {
  const [fulfillmentType, setFulfillmentType] = useState<'Delivery' | 'Collection'>('Delivery');
  const [selectedStoreId, setSelectedStoreId] = useState<string>(stores[0]?.id || '');
  
  const [fullName, setFullName] = useState<string>('Sarah Jenkins');
  const [email, setEmail] = useState<string>('sarah.jenkins@example.com');
  const [line1, setLine1] = useState<string>('450 West 33rd Street');
  const [city, setCity] = useState<string>('New York');
  const [state, setState] = useState<string>('NY');
  const [postalCode, setPostalCode] = useState<string>('10001');
  const [country, setCountry] = useState<string>('United States');

  const [paymentMethod, setPaymentMethod] = useState<string>('Credit Card (•••• 4242)');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Demo simulation triggers for evaluation
  const [simulatePaymentFailure, setSimulatePaymentFailure] = useState<boolean>(false);
  const [simulatePriceChange, setSimulatePriceChange] = useState<boolean>(false);
  const [simulateExpiredReservation, setSimulateExpiredReservation] = useState<boolean>(false);

  const subtotal = cartItems.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const shippingFee = fulfillmentType === 'Delivery' ? (subtotal >= 75 ? 0 : 8.00) : 0;
  const tax = Number((subtotal * 0.08875).toFixed(2)); // NYC tax rate
  const total = Number((subtotal + shippingFee + tax).toFixed(2));

  const handlePlaceOrder = () => {
    setErrorMessage(null);

    if (simulateExpiredReservation) {
      setErrorMessage('Stock Reservation Expired: Your 15-minute cart hold has expired due to inactivity. Please review updated availability.');
      return;
    }

    if (simulatePaymentFailure) {
      setErrorMessage('Payment Authorization Failed: Card issuer declined transaction (insufficient funds or security check failed). Please try another payment method.');
      return;
    }

    setIsProcessing(true);

    setTimeout(() => {
      setIsProcessing(false);

      const newOrder: Order = {
        id: `ord-${Date.now()}`,
        orderNumber: `AF-${Math.floor(100000 + Math.random() * 900000)}`,
        createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
        status: fulfillmentType === 'Delivery' ? 'Processing' : 'Ready for Pickup',
        fulfillmentType,
        storeId: fulfillmentType === 'Collection' ? selectedStoreId : undefined,
        shippingAddress: fulfillmentType === 'Delivery' ? {
          fullName,
          line1,
          city,
          state,
          postalCode,
          country
        } : undefined,
        items: cartItems.map(ci => ({
          sku: ci.sku,
          productId: ci.productId,
          title: ci.title,
          colour: ci.colour,
          size: ci.size,
          length: ci.length,
          fit: 'Standard',
          price: simulatePriceChange ? ci.price * 1.1 : ci.price,
          quantity: ci.quantity,
          image: ci.image
        })),
        subtotal,
        discount: 0,
        shippingFee,
        tax,
        total: simulatePriceChange ? total * 1.1 : total,
        paymentMethod,
        paymentStatus: 'Paid',
        trackingNumber: fulfillmentType === 'Delivery' ? `1Z${Math.floor(100000000000000 + Math.random() * 900000000000000)}` : undefined
      };

      onOrderPlaced(newOrder);
      onClearCart();
    }, 1500);
  };

  return (
    <div className="bg-[#F9F6F0] min-h-screen py-12 px-4 sm:px-6 lg:px-8 text-[#241E1C]">
      <div className="max-w-7xl mx-auto">
        <button
          onClick={onBackToCatalogue}
          className="inline-flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-[#786D65] hover:text-[#241E1C] mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Return to Storefront
        </button>

        <h1 className="font-serif text-3xl sm:text-4xl text-[#241E1C] mb-8">
          Secure Checkout & Fulfilment
        </h1>

        {/* Demo Simulation Controls Box */}
        <div className="bg-[#EAE3DC] border border-[#DCD3C9] p-4 rounded-lg mb-8 space-y-3">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#241E1C] uppercase tracking-wider">
            <Sparkles className="w-4 h-4 text-[#C8A97E]" />
            Demo Evaluation Scenarios (Interactive Test Toggles)
          </div>
          <div className="flex flex-wrap gap-4 text-xs text-[#594B42]">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={simulatePaymentFailure}
                onChange={(e) => setSimulatePaymentFailure(e.target.checked)}
                className="rounded border-[#DCD3C9]"
              />
              Simulate Payment Failure
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={simulatePriceChange}
                onChange={(e) => setSimulatePriceChange(e.target.checked)}
                className="rounded border-[#DCD3C9]"
              />
              Simulate Price Revalidation Change (+10%)
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={simulateExpiredReservation}
                onChange={(e) => setSimulateExpiredReservation(e.target.checked)}
                className="rounded border-[#DCD3C9]"
              />
              Simulate Expired Stock Reservation
            </label>
          </div>
        </div>

        {errorMessage && (
          <div className="bg-rose-50 border border-rose-200 text-rose-800 p-4 rounded-lg mb-8 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            {errorMessage}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Form Section (Left 7 Cols) */}
          <div className="lg:col-span-7 space-y-8">
            {/* 1. Fulfilment Method */}
            <div className="bg-white p-6 sm:p-8 rounded-xl border border-[#E6E0D5] shadow-sm space-y-6">
              <h3 className="font-serif text-xl text-[#241E1C]">1. Select Fulfilment Method</h3>
              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => setFulfillmentType('Delivery')}
                  className={`p-4 border rounded-lg text-left transition-all flex flex-col gap-2 ${fulfillmentType === 'Delivery' ? 'border-[#241E1C] bg-[#241E1C] text-white shadow-sm' : 'border-[#DCD3C9] bg-white text-[#241E1C] hover:border-[#241E1C]'}`}
                >
                  <Truck className="w-5 h-5" />
                  <span className="font-semibold text-sm">Home Delivery</span>
                  <span className="text-[10px] opacity-80">Shipped from central warehouse (2-4 days)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setFulfillmentType('Collection')}
                  className={`p-4 border rounded-lg text-left transition-all flex flex-col gap-2 ${fulfillmentType === 'Collection' ? 'border-[#241E1C] bg-[#241E1C] text-white shadow-sm' : 'border-[#DCD3C9] bg-white text-[#241E1C] hover:border-[#241E1C]'}`}
                >
                  <Store className="w-5 h-5" />
                  <span className="font-semibold text-sm">Store Pickup</span>
                  <span className="text-[10px] opacity-80">Ready in 2 hours at selected store</span>
                </button>
              </div>

              {fulfillmentType === 'Collection' && (
                <div className="pt-4 space-y-3">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#786D65]">Select Pickup Location</label>
                  <select
                    value={selectedStoreId}
                    onChange={(e) => setSelectedStoreId(e.target.value)}
                    className="w-full bg-[#F9F6F0] border border-[#DCD3C9] text-xs p-3 rounded focus:outline-none focus:border-[#241E1C]"
                  >
                    {stores.map(st => (
                      <option key={st.id} value={st.id}>{st.name} — {st.address}</option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            {/* 2. Customer & Delivery Address */}
            <div className="bg-white p-6 sm:p-8 rounded-xl border border-[#E6E0D5] shadow-sm space-y-6">
              <h3 className="font-serif text-xl text-[#241E1C]">2. Customer & Shipping Details</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block font-semibold uppercase tracking-wider text-[#786D65] mb-1">Full Name</label>
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full bg-[#F9F6F0] border border-[#DCD3C9] p-3 rounded focus:outline-none focus:border-[#241E1C]"
                  />
                </div>
                <div>
                  <label className="block font-semibold uppercase tracking-wider text-[#786D65] mb-1">Email Address</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-[#F9F6F0] border border-[#DCD3C9] p-3 rounded focus:outline-none focus:border-[#241E1C]"
                  />
                </div>

                {fulfillmentType === 'Delivery' && (
                  <>
                    <div className="sm:col-span-2">
                      <label className="block font-semibold uppercase tracking-wider text-[#786D65] mb-1">Street Address</label>
                      <input
                        type="text"
                        value={line1}
                        onChange={(e) => setLine1(e.target.value)}
                        className="w-full bg-[#F9F6F0] border border-[#DCD3C9] p-3 rounded focus:outline-none focus:border-[#241E1C]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold uppercase tracking-wider text-[#786D65] mb-1">City</label>
                      <input
                        type="text"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        className="w-full bg-[#F9F6F0] border border-[#DCD3C9] p-3 rounded focus:outline-none focus:border-[#241E1C]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold uppercase tracking-wider text-[#786D65] mb-1">State / Province</label>
                      <input
                        type="text"
                        value={state}
                        onChange={(e) => setState(e.target.value)}
                        className="w-full bg-[#F9F6F0] border border-[#DCD3C9] p-3 rounded focus:outline-none focus:border-[#241E1C]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold uppercase tracking-wider text-[#786D65] mb-1">Postal Code</label>
                      <input
                        type="text"
                        value={postalCode}
                        onChange={(e) => setPostalCode(e.target.value)}
                        className="w-full bg-[#F9F6F0] border border-[#DCD3C9] p-3 rounded focus:outline-none focus:border-[#241E1C]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold uppercase tracking-wider text-[#786D65] mb-1">Country</label>
                      <input
                        type="text"
                        value={country}
                        onChange={(e) => setCountry(e.target.value)}
                        className="w-full bg-[#F9F6F0] border border-[#DCD3C9] p-3 rounded focus:outline-none focus:border-[#241E1C]"
                      />
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* 3. Payment Simulator */}
            <div className="bg-white p-6 sm:p-8 rounded-xl border border-[#E6E0D5] shadow-sm space-y-6">
              <h3 className="font-serif text-xl text-[#241E1C]">3. Secure Payment</h3>
              <div className="space-y-3">
                {['Credit Card (•••• 4242)', 'Apple Pay', 'PayPal Sandbox'].map(method => (
                  <label key={method} className="flex items-center gap-3 p-3 border border-[#DCD3C9] rounded cursor-pointer text-xs">
                    <input
                      type="radio"
                      name="paymentMethod"
                      checked={paymentMethod === method}
                      onChange={() => setPaymentMethod(method)}
                      className="text-[#241E1C]"
                    />
                    <CreditCard className="w-4 h-4 text-[#786D65]" />
                    <span className="font-semibold text-[#241E1C]">{method}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>

          {/* Order Summary Sidebar (Right 5 Cols) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white p-6 sm:p-8 rounded-xl border border-[#E6E0D5] shadow-sm space-y-6">
              <h3 className="font-serif text-xl text-[#241E1C] pb-4 border-b border-[#E6E0D5]">
                Order Summary ({cartItems.reduce((a, b) => a + b.quantity, 0)} items)
              </h3>

              <div className="space-y-4 max-h-80 overflow-y-auto divide-y divide-[#F4EFEB]">
                {cartItems.map(item => (
                  <div key={item.sku} className="pt-4 first:pt-0 flex gap-4 text-xs">
                    <div className="w-14 h-18 bg-[#EFECE6] rounded overflow-hidden shrink-0">
                      <img src={item.image} alt="" className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-serif text-sm text-[#241E1C]">{item.title}</h4>
                      <p className="text-[#786D65]">Colour: {item.colour} · Size: {item.size}</p>
                      <p className="text-[#786D65]">Qty: {item.quantity}</p>
                    </div>
                    <span className="font-semibold text-sm text-[#241E1C]">
                      ${(item.price * item.quantity).toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>

              <div className="pt-4 border-t border-[#E6E0D5] space-y-2.5 text-xs text-[#594B42]">
                <div className="flex justify-between">
                  <span>Merchandise Subtotal</span>
                  <span className="font-semibold text-[#241E1C]">${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Estimated Shipping ({fulfillmentType})</span>
                  <span className="font-semibold text-[#241E1C]">{shippingFee === 0 ? 'FREE' : `$${shippingFee.toFixed(2)}`}</span>
                </div>
                <div className="flex justify-between">
                  <span>Estimated Tax (NY State)</span>
                  <span className="font-semibold text-[#241E1C]">${tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-base font-semibold text-[#241E1C] pt-3 border-t border-[#E6E0D5]">
                  <span>Total</span>
                  <span>${total.toFixed(2)}</span>
                </div>
              </div>

              <button
                onClick={handlePlaceOrder}
                disabled={isProcessing || cartItems.length === 0}
                className="w-full bg-[#1C1715] hover:bg-[#C8A97E] hover:text-[#1C1715] text-white text-sm py-4 font-medium transition-colors flex items-center justify-center gap-2 shadow-sm disabled:opacity-50"
              >
                {isProcessing ? (
                  <span>Processing Secure Payment...</span>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>Pay ${total.toFixed(2)} & Place Order</span>
                  </>
                )}
              </button>

              <div className="text-[10px] text-center text-[#786D65]">
                By placing your order, you agree to our Terms of Use and Return Policy. Stock is transactionally reserved upon authorization.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
