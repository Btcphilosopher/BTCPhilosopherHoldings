import React from 'react';
import { ArrowRight } from 'lucide-react';

interface HeroProps {
  onSelectCategory: (category: string) => void;
  onSelectGender: (gender: string) => void;
  onExploreNewArrivals: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  onSelectCategory,
  onSelectGender,
  onExploreNewArrivals
}) => {
  return (
    <div className="bg-[#F9F6F0] min-h-screen text-[#241E1C]">
      {/* Hero Banner matching the exact reference design */}
      <section className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-[#F4EFEB] rounded-xl overflow-hidden shadow-sm border border-[#E6E0D5]">
          {/* Left Text Content */}
          <div className="lg:col-span-5 p-8 sm:p-12 lg:p-16 flex flex-col justify-center">
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl tracking-tight text-[#241E1C] leading-[1.1] mb-6">
              Made for the everyday.
            </h1>
            <p className="text-lg sm:text-xl font-light italic text-[#594B42] mb-8 font-serif">
              Considered fits. Effortless style.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={() => { onSelectGender('Women'); onSelectCategory('All'); }}
                className="bg-[#1C1715] hover:bg-[#C8A97E] hover:text-[#1C1715] text-white px-8 py-3.5 text-sm font-medium tracking-wide transition-all duration-200 text-center rounded-none shadow-sm"
              >
                Shop Women
              </button>
              <button
                onClick={() => { onSelectGender('Men'); onSelectCategory('All'); }}
                className="bg-[#1C1715] hover:bg-[#C8A97E] hover:text-[#1C1715] text-white px-8 py-3.5 text-sm font-medium tracking-wide transition-all duration-200 text-center rounded-none shadow-sm"
              >
                Shop Men
              </button>
            </div>
          </div>

          {/* Right Editorial Image matching attached screenshot */}
          <div className="lg:col-span-7 h-[420px] sm:h-[540px] lg:h-[600px] relative overflow-hidden">
            <img
              src="/public/assets/aistudio/16968c28-5025-4d42-b15d-3c1cb83c9f45_f8e84f2c.png"
              alt="Abercrombie & Fitch Editorial - Made for the everyday"
              className="w-full h-full object-cover object-center transform hover:scale-105 transition-transform duration-700"
            />
          </div>
        </div>
      </section>

      {/* Category Section: Find your perfect fit */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="font-serif text-3xl sm:text-4xl tracking-tight text-[#241E1C]">
            Find your perfect fit.
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Denim Card */}
          <div
            onClick={() => onSelectCategory('Denim')}
            className="group relative h-[380px] sm:h-[440px] rounded-lg overflow-hidden cursor-pointer shadow-sm bg-[#EFECE6]"
          >
            <img
              src="https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=800&q=80"
              alt="Denim Collection"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent flex items-end p-6">
              <h3 className="text-white font-serif text-2xl tracking-wide group-hover:text-[#C8A97E] transition-colors">
                Denim
              </h3>
            </div>
          </div>

          {/* Linen Card */}
          <div
            onClick={() => onSelectCategory('Linen')}
            className="group relative h-[380px] sm:h-[440px] rounded-lg overflow-hidden cursor-pointer shadow-sm bg-[#EFECE6]"
          >
            <img
              src="https://images.unsplash.com/photo-1598554747436-c9293d6a588f?auto=format&fit=crop&w=800&q=80"
              alt="Linen Collection"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent flex items-end p-6">
              <h3 className="text-white font-serif text-2xl tracking-wide group-hover:text-[#C8A97E] transition-colors">
                Linen
              </h3>
            </div>
          </div>

          {/* Dresses Card */}
          <div
            onClick={() => onSelectCategory('Dresses')}
            className="group relative h-[380px] sm:h-[440px] rounded-lg overflow-hidden cursor-pointer shadow-sm bg-[#EFECE6]"
          >
            <img
              src="https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?auto=format&fit=crop&w=800&q=80"
              alt="Dresses Collection"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent flex items-end p-6">
              <h3 className="text-white font-serif text-2xl tracking-wide group-hover:text-[#C8A97E] transition-colors">
                Dresses
              </h3>
            </div>
          </div>

          {/* Polos & tees Card */}
          <div
            onClick={() => onSelectCategory('Polos & tees')}
            className="group relative h-[380px] sm:h-[440px] rounded-lg overflow-hidden cursor-pointer shadow-sm bg-[#EFECE6]"
          >
            <img
              src="https://images.unsplash.com/photo-1625910513411-5ed0f550436a?auto=format&fit=crop&w=800&q=80"
              alt="Polos & tees Collection"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent flex items-end p-6">
              <h3 className="text-white font-serif text-2xl tracking-wide group-hover:text-[#C8A97E] transition-colors">
                Polos & tees
              </h3>
            </div>
          </div>
        </div>
      </section>

      {/* New Arrivals Editorial Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="relative rounded-xl overflow-hidden bg-[#EAE3DC] p-10 sm:p-16 text-center border border-[#DCD3C9]">
          <div className="absolute inset-0 opacity-20">
            <img
              src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1600&q=80"
              alt="Background texture"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="relative z-10 max-w-2xl mx-auto space-y-6">
            <h3 className="font-serif text-3xl sm:text-4xl text-[#241E1C]">
              The pieces you’ll wear on repeat.
            </h3>
            <p className="text-sm sm:text-base text-[#594B42]">
              Explore our newest arrivals crafted for effortless layering, enduring quality, and everyday refinement.
            </p>
            <div>
              <button
                onClick={onExploreNewArrivals}
                className="inline-flex items-center gap-2 bg-[#1C1715] text-white hover:bg-[#C8A97E] hover:text-[#1C1715] px-8 py-3.5 text-sm font-medium tracking-wide transition-colors shadow-sm"
              >
                <span>Explore new arrivals</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
