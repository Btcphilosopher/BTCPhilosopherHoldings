import React from 'react';

interface FooterProps {
  setCurrentView: (view: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ setCurrentView }) => {
  return (
    <footer className="bg-[#241E1C] text-[#FBF9F5] pt-16 pb-12 border-t border-[#3D312A]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
        <div>
          <h3 className="font-serif text-xl tracking-tight mb-4">Abercrombie & Fitch</h3>
          <p className="text-sm text-[#D8C5B2] leading-relaxed mb-6">
            Considered fits. Effortless style. Your everyday wardrobe, elevated with premium fabrics and timeless tailoring.
          </p>
          <div className="text-xs text-[#A8988D]">
            Independent website concept demonstrating retail systems architecture and editorial storefront design.
          </div>
        </div>

        <div>
          <h4 className="text-xs font-semibold uppercase tracking-widest text-[#C8A97E] mb-4">Help & Support</h4>
          <ul className="space-y-3 text-sm text-[#D8C5B2]">
            <li><button onClick={() => setCurrentView('account')} className="hover:text-white transition-colors">Order Status & Tracking</button></li>
            <li><button onClick={() => setCurrentView('account')} className="hover:text-white transition-colors">Returns & Exchanges</button></li>
            <li><button onClick={() => setCurrentView('stores')} className="hover:text-white transition-colors">Store Locator & Pickup</button></li>
            <li><button onClick={() => setCurrentView('account')} className="hover:text-white transition-colors">Size Guide & Fit Assistance</button></li>
          </ul>
        </div>

        <div>
          <h4 className="text-xs font-semibold uppercase tracking-widest text-[#C8A97E] mb-4">Collections</h4>
          <ul className="space-y-3 text-sm text-[#D8C5B2]">
            <li><button onClick={() => setCurrentView('catalogue')} className="hover:text-white transition-colors">Women's Denim & Linen</button></li>
            <li><button onClick={() => setCurrentView('catalogue')} className="hover:text-white transition-colors">Men's Polos & Knitwear</button></li>
            <li><button onClick={() => setCurrentView('outfit-builder')} className="hover:text-white transition-colors">Outfit Builder</button></li>
            <li><button onClick={() => setCurrentView('catalogue')} className="hover:text-white transition-colors">New Arrivals</button></li>
          </ul>
        </div>

        <div>
          <h4 className="text-xs font-semibold uppercase tracking-widest text-[#C8A97E] mb-4">Staff & Systems</h4>
          <ul className="space-y-3 text-sm text-[#D8C5B2]">
            <li><button onClick={() => setCurrentView('admin')} className="hover:text-white transition-colors font-medium text-white">Staff Administration Dashboard</button></li>
            <li><span className="text-xs text-[#88786D]">PostgreSQL & FastAPI Backend Architecture</span></li>
            <li><span className="text-xs text-[#88786D]">Transactional Stock Reservations</span></li>
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 border-t border-[#3D312A] flex flex-col sm:flex-row items-center justify-between text-xs text-[#A8988D]">
        <p>© 2026 Independent Concept Storefront. All rights reserved.</p>
        <div className="flex gap-6 mt-4 sm:mt-0">
          <span className="hover:text-white cursor-pointer">Privacy Notice</span>
          <span className="hover:text-white cursor-pointer">Terms of Use</span>
          <span className="hover:text-white cursor-pointer">Cookie Preferences</span>
        </div>
      </div>
    </footer>
  );
};
