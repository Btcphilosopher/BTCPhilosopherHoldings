export interface ProductVariant {
  sku: string;
  colour: string;
  colourCode?: string;
  size: string;
  length?: string;
  fit: string;
  price: number;
  compareAtPrice?: number;
  onHandStock: number;
  reservedStock: number;
  availableStock: number;
  isAvailable: boolean;
}

export interface Product {
  id: string;
  styleId: string;
  title: string;
  subtitle: string;
  description: string;
  category: 'Denim' | 'Linen' | 'Dresses' | 'Polos & tees' | 'Knitwear' | 'Outerwear' | 'Activewear';
  gender: 'Women' | 'Men' | 'Unisex';
  fabricComposition: string;
  careInstructions: string;
  images: string[];
  sizeChartReference: string;
  basePrice: number;
  rating: number;
  reviewsCount: number;
  isNewArrival?: boolean;
  isFeatured?: boolean;
  variants: ProductVariant[];
}

export interface CartItem {
  id: string;
  productId: string;
  sku: string;
  title: string;
  colour: string;
  size: string;
  length?: string;
  fit: string;
  price: number;
  quantity: number;
  image: string;
  maxAvailable: number;
}

export interface OutfitItem {
  slot: 'Top' | 'Bottom' | 'Footwear' | 'Accessory';
  productId: string;
  sku: string;
  title: string;
  colour: string;
  size: string;
  price: number;
  image: string;
}

export interface SavedOutfit {
  id: string;
  name: string;
  createdAt: string;
  items: OutfitItem[];
}

export interface OrderItemSnapshot {
  sku: string;
  productId: string;
  title: string;
  colour: string;
  size: string;
  length?: string;
  fit: string;
  price: number;
  quantity: number;
  image: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  createdAt: string;
  status: 'Pending Payment' | 'Paid' | 'Processing' | 'Ready for Pickup' | 'Shipped' | 'Delivered' | 'Cancelled' | 'Refunded';
  fulfillmentType: 'Delivery' | 'Collection';
  storeId?: string;
  shippingAddress?: {
    fullName: string;
    line1: string;
    line2?: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
  };
  items: OrderItemSnapshot[];
  subtotal: number;
  discount: number;
  shippingFee: number;
  tax: number;
  total: number;
  paymentMethod: string;
  paymentStatus: 'Authorized' | 'Paid' | 'Failed' | 'Refunded';
  trackingNumber?: string;
  returnRequested?: boolean;
  returnStatus?: 'None' | 'Requested' | 'Approved' | 'Received' | 'Refunded';
  returnReason?: string;
}

export interface StoreLocation {
  id: string;
  name: string;
  city: string;
  address: string;
  hours: string;
  phone: string;
  services: string[];
  collectionEligible: boolean;
  lat: number;
  lng: number;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  details: string;
  severity: 'info' | 'warning' | 'success';
}
