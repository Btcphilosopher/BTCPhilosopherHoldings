import { Product, StoreLocation, Order, SavedOutfit, AuditLogEntry } from '../types';

export const mockStores: StoreLocation[] = [
  {
    id: 'store-1',
    name: 'Abercrombie & Fitch Flagship - Fifth Avenue',
    city: 'New York, NY',
    address: '668 5th Ave, New York, NY 10019',
    hours: 'Mon - Sat: 10:00 AM - 9:00 PM, Sun: 11:00 AM - 7:00 PM',
    phone: '(212) 555-0192',
    services: ['Buy Online Pick Up In Store', 'Styling Appointments', 'Tailoring', 'Same-Day Pickup'],
    collectionEligible: true,
    lat: 40.7589,
    lng: -73.9772
  },
  {
    id: 'store-2',
    name: 'Abercrombie & Fitch - The Grove',
    city: 'Los Angeles, CA',
    address: '189 The Grove Dr, Los Angeles, CA 90036',
    hours: 'Mon - Sun: 10:00 AM - 9:00 PM',
    phone: '(323) 555-0144',
    services: ['Buy Online Pick Up In Store', 'Curbside Pickup', 'Express Returns'],
    collectionEligible: true,
    lat: 34.0718,
    lng: -118.3587
  },
  {
    id: 'store-3',
    name: 'Abercrombie & Fitch - Regent Street',
    city: 'London, UK',
    address: '321 Regent St, London W1B 4JH',
    hours: 'Mon - Sat: 10:00 AM - 8:00 PM, Sun: 12:00 PM - 6:00 PM',
    phone: '+44 20 7555 0188',
    services: ['Buy Online Pick Up In Store', 'Global Tax-Free Shopping', 'Personal Shopping'],
    collectionEligible: true,
    lat: 51.5154,
    lng: -0.1411
  },
  {
    id: 'store-4',
    name: 'Abercrombie & Fitch - Michigan Avenue',
    city: 'Chicago, IL',
    address: '600 N Michigan Ave, Chicago, IL 60611',
    hours: 'Mon - Sat: 10:00 AM - 8:00 PM, Sun: 11:00 AM - 6:00 PM',
    phone: '(312) 555-0163',
    services: ['Buy Online Pick Up In Store', 'Gift Wrapping'],
    collectionEligible: true,
    lat: 41.8923,
    lng: -87.6242
  }
];

export const mockProducts: Product[] = [
  // 1. Featured Hero Denim & Linen (matching the attached design aesthetic)
  {
    id: 'prod-1',
    styleId: 'AF-DEN-001',
    title: 'Ultra High Rise 90s Straight Jean',
    subtitle: 'Classic Rigid Denim with Vintage Wash',
    description: 'Crafted from authentic low-stretch denim with a flattering ultra-high rise and relaxed straight leg. Designed for effortless everyday styling, complete with classic five-pocket construction and vintage distressing.',
    category: 'Denim',
    gender: 'Women',
    fabricComposition: '99% Cotton, 1% Elastane',
    careInstructions: 'Machine wash cold inside out with like colors. Tumble dry low.',
    images: [
      '/public/assets/aistudio/16968c28-5025-4d42-b15d-3c1cb83c9f45_f8e84f2c.png',
      'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1582533561751-ef6f6cc90a0a?auto=format&fit=crop&w=1200&q=80'
    ],
    sizeChartReference: 'Women’s Bottoms - Straight Fit (Waist 23-32, Lengths Short/Regular/Long)',
    basePrice: 90.00,
    rating: 4.8,
    reviewsCount: 342,
    isNewArrival: true,
    isFeatured: true,
    variants: [
      { sku: 'AF-DEN-001-BLU-24-REG', colour: 'Medium Vintage Wash', colourCode: '#6A819E', size: '24', length: 'Regular', fit: 'Straight', price: 90.00, onHandStock: 12, reservedStock: 0, availableStock: 12, isAvailable: true },
      { sku: 'AF-DEN-001-BLU-25-REG', colour: 'Medium Vintage Wash', colourCode: '#6A819E', size: '25', length: 'Regular', fit: 'Straight', price: 90.00, onHandStock: 8, reservedStock: 1, availableStock: 7, isAvailable: true },
      { sku: 'AF-DEN-001-BLU-26-SHT', colour: 'Medium Vintage Wash', colourCode: '#6A819E', size: '26', length: 'Short', fit: 'Straight', price: 90.00, onHandStock: 5, reservedStock: 0, availableStock: 5, isAvailable: true },
      { sku: 'AF-DEN-001-BLU-26-REG', colour: 'Medium Vintage Wash', colourCode: '#6A819E', size: '26', length: 'Regular', fit: 'Straight', price: 90.00, onHandStock: 15, reservedStock: 2, availableStock: 13, isAvailable: true },
      { sku: 'AF-DEN-001-BLU-26-LNG', colour: 'Medium Vintage Wash', colourCode: '#6A819E', size: '26', length: 'Long', fit: 'Straight', price: 90.00, onHandStock: 4, reservedStock: 0, availableStock: 4, isAvailable: true },
      { sku: 'AF-DEN-001-BLU-27-REG', colour: 'Medium Vintage Wash', colourCode: '#6A819E', size: '27', length: 'Regular', fit: 'Straight', price: 90.00, onHandStock: 19, reservedStock: 3, availableStock: 16, isAvailable: true },
      { sku: 'AF-DEN-001-BLU-28-REG', colour: 'Medium Vintage Wash', colourCode: '#6A819E', size: '28', length: 'Regular', fit: 'Straight', price: 90.00, onHandStock: 10, reservedStock: 0, availableStock: 10, isAvailable: true },
      { sku: 'AF-DEN-001-WHT-26-REG', colour: 'Ecru / Off White', colourCode: '#F4F1EA', size: '26', length: 'Regular', fit: 'Straight', price: 90.00, onHandStock: 6, reservedStock: 0, availableStock: 6, isAvailable: true },
      { sku: 'AF-DEN-001-WHT-28-REG', colour: 'Ecru / Off White', colourCode: '#F4F1EA', size: '28', length: 'Regular', fit: 'Straight', price: 90.00, onHandStock: 0, reservedStock: 0, availableStock: 0, isAvailable: false }
    ]
  },
  {
    id: 'prod-2',
    styleId: 'AF-LIN-002',
    title: 'The Signature Linen Button-Up Shirt',
    subtitle: 'Breathable European Flax Linen',
    description: 'Woven from premium 100% European flax linen. Features a relaxed collar, dropped shoulders, and a beautifully airy drape that softens with every wash. Perfect for coastal getaways or warm urban days.',
    category: 'Linen',
    gender: 'Women',
    fabricComposition: '100% European Flax Linen',
    careInstructions: 'Machine wash gentle in cold water. Line dry in shade.',
    images: [
      'https://images.unsplash.com/photo-1598554747436-c9293d6a588f?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1200&q=80'
    ],
    sizeChartReference: 'Women’s Tops - Relaxed Fit (XS to XL)',
    basePrice: 75.00,
    rating: 4.9,
    reviewsCount: 218,
    isNewArrival: true,
    isFeatured: true,
    variants: [
      { sku: 'AF-LIN-002-CRM-XS', colour: 'Cream', colourCode: '#F7F4EE', size: 'XS', fit: 'Relaxed', price: 75.00, onHandStock: 8, reservedStock: 0, availableStock: 8, isAvailable: true },
      { sku: 'AF-LIN-002-CRM-S', colour: 'Cream', colourCode: '#F7F4EE', size: 'S', fit: 'Relaxed', price: 75.00, onHandStock: 14, reservedStock: 1, availableStock: 13, isAvailable: true },
      { sku: 'AF-LIN-002-CRM-M', colour: 'Cream', colourCode: '#F7F4EE', size: 'M', fit: 'Relaxed', price: 75.00, onHandStock: 10, reservedStock: 0, availableStock: 10, isAvailable: true },
      { sku: 'AF-LIN-002-CRM-L', colour: 'Cream', colourCode: '#F7F4EE', size: 'L', fit: 'Relaxed', price: 75.00, onHandStock: 5, reservedStock: 0, availableStock: 5, isAvailable: true },
      { sku: 'AF-LIN-002-OLV-S', colour: 'Olive Drab', colourCode: '#555D50', size: 'S', fit: 'Relaxed', price: 75.00, onHandStock: 7, reservedStock: 0, availableStock: 7, isAvailable: true },
      { sku: 'AF-LIN-002-OLV-M', colour: 'Olive Drab', colourCode: '#555D50', size: 'M', fit: 'Relaxed', price: 75.00, onHandStock: 9, reservedStock: 0, availableStock: 9, isAvailable: true }
    ]
  },
  {
    id: 'prod-3',
    styleId: 'AF-POL-003',
    title: 'Seamless Ribbed Knit Polo',
    subtitle: 'Textured Cotton Blend Heritage Knit',
    description: 'An elevated take on the classic tennis polo. Engineered with a seamless textured stitch, open placket, and a sculpted silhouette that pairs effortlessly with tailored trousers or denim.',
    category: 'Polos & tees',
    gender: 'Men',
    fabricComposition: '65% Cotton, 35% Recycled Nylon',
    careInstructions: 'Hand wash cold or gentle machine wash in mesh bag. Dry flat.',
    images: [
      'https://images.unsplash.com/photo-1625910513411-5ed0f550436a?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1617137984095-74e4e5e3613f?auto=format&fit=crop&w=1200&q=80'
    ],
    sizeChartReference: 'Men’s Tops - Tailored Fit (S to XXL)',
    basePrice: 65.00,
    rating: 4.7,
    reviewsCount: 156,
    isNewArrival: true,
    isFeatured: true,
    variants: [
      { sku: 'AF-POL-003-OAT-S', colour: 'Oatmeal', colourCode: '#E6E0D5', size: 'S', fit: 'Tailored', price: 65.00, onHandStock: 10, reservedStock: 0, availableStock: 10, isAvailable: true },
      { sku: 'AF-POL-003-OAT-M', colour: 'Oatmeal', colourCode: '#E6E0D5', size: 'M', fit: 'Tailored', price: 65.00, onHandStock: 18, reservedStock: 2, availableStock: 16, isAvailable: true },
      { sku: 'AF-POL-003-OAT-L', colour: 'Oatmeal', colourCode: '#E6E0D5', size: 'L', fit: 'Tailored', price: 65.00, onHandStock: 12, reservedStock: 0, availableStock: 12, isAvailable: true },
      { sku: 'AF-POL-003-OAT-XL', colour: 'Oatmeal', colourCode: '#E6E0D5', size: 'XL', fit: 'Tailored', price: 65.00, onHandStock: 4, reservedStock: 0, availableStock: 4, isAvailable: true },
      { sku: 'AF-POL-003-BRN-M', colour: 'Dark Brown', colourCode: '#3D312A', size: 'M', fit: 'Tailored', price: 65.00, onHandStock: 8, reservedStock: 0, availableStock: 8, isAvailable: true },
      { sku: 'AF-POL-003-BRN-L', colour: 'Dark Brown', colourCode: '#3D312A', size: 'L', fit: 'Tailored', price: 65.00, onHandStock: 6, reservedStock: 0, availableStock: 6, isAvailable: true }
    ]
  },
  {
    id: 'prod-4',
    styleId: 'AF-DRS-004',
    title: 'Embossed Smocked Midi Dress',
    subtitle: 'Romantic Sweetneck Silhouette',
    description: 'Designed with a beautifully fitted smocked bodice that flows into an effortless A-line midi skirt. Crafted from washed cotton poplin with delicate adjustable straps.',
    category: 'Dresses',
    gender: 'Women',
    fabricComposition: '100% Cotton Poplin',
    careInstructions: 'Machine wash cold. Line dry or tumble dry low.',
    images: [
      'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1200&q=80'
    ],
    sizeChartReference: 'Women’s Dresses - Fitted Bodice (XS to L)',
    basePrice: 120.00,
    rating: 4.9,
    reviewsCount: 89,
    isNewArrival: true,
    isFeatured: true,
    variants: [
      { sku: 'AF-DRS-004-CHO-XS', colour: 'Rich Chocolate', colourCode: '#4A3B32', size: 'XS', fit: 'Fitted', price: 120.00, onHandStock: 5, reservedStock: 0, availableStock: 5, isAvailable: true },
      { sku: 'AF-DRS-004-CHO-S', colour: 'Rich Chocolate', colourCode: '#4A3B32', size: 'S', fit: 'Fitted', price: 120.00, onHandStock: 11, reservedStock: 1, availableStock: 10, isAvailable: true },
      { sku: 'AF-DRS-004-CHO-M', colour: 'Rich Chocolate', colourCode: '#4A3B32', size: 'M', fit: 'Fitted', price: 120.00, onHandStock: 7, reservedStock: 0, availableStock: 7, isAvailable: true },
      { sku: 'AF-DRS-004-CHO-L', colour: 'Rich Chocolate', colourCode: '#4A3B32', size: 'L', fit: 'Fitted', price: 120.00, onHandStock: 3, reservedStock: 0, availableStock: 3, isAvailable: true }
    ]
  },

  // 2. Additional Denim Products
  {
    id: 'prod-5',
    styleId: 'AF-DEN-005',
    title: 'Wide Leg Loose Jean',
    subtitle: 'Effortless Full-Length Drape',
    description: 'A relaxed mid-rise waist with an exaggerated wide leg. Made from soft non-stretch cotton denim for that quintessential relaxed 90s aesthetic.',
    category: 'Denim',
    gender: 'Women',
    fabricComposition: '100% Cotton',
    careInstructions: 'Machine wash cold, hang dry.',
    images: [
      'https://images.unsplash.com/photo-1560243563-062bfc111d68?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&w=1200&q=80'
    ],
    sizeChartReference: 'Women’s Bottoms - Wide Leg (Waist 24-31)',
    basePrice: 95.00,
    rating: 4.6,
    reviewsCount: 112,
    isNewArrival: false,
    isFeatured: false,
    variants: [
      { sku: 'AF-DEN-005-LBL-25-REG', colour: 'Light Indigo', colourCode: '#9BB0C1', size: '25', length: 'Regular', fit: 'Wide', price: 95.00, onHandStock: 6, reservedStock: 0, availableStock: 6, isAvailable: true },
      { sku: 'AF-DEN-005-LBL-27-REG', colour: 'Light Indigo', colourCode: '#9BB0C1', size: '27', length: 'Regular', fit: 'Wide', price: 95.00, onHandStock: 10, reservedStock: 0, availableStock: 10, isAvailable: true },
      { sku: 'AF-DEN-005-LBL-29-REG', colour: 'Light Indigo', colourCode: '#9BB0C1', size: '29', length: 'Regular', fit: 'Wide', price: 95.00, onHandStock: 5, reservedStock: 0, availableStock: 5, isAvailable: true }
    ]
  },
  {
    id: 'prod-6',
    styleId: 'AF-DEN-006',
    title: 'Mens Athletic Slim Jean',
    subtitle: 'Performance Stretch Denim',
    description: 'Designed with extra room through the hip and thigh and a tailored tapered leg. Engineered with advanced stretch for all-day comfort without losing its shape.',
    category: 'Denim',
    gender: 'Men',
    fabricComposition: '98% Cotton, 2% Elastane',
    careInstructions: 'Machine wash cold.',
    images: [
      'https://images.unsplash.com/photo-1542272454-17d5402d415e?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1516257984-b1b4d707412e?auto=format&fit=crop&w=1200&q=80'
    ],
    sizeChartReference: 'Men’s Denim - Athletic Slim (Waist 30-36)',
    basePrice: 95.00,
    rating: 4.8,
    reviewsCount: 230,
    isNewArrival: false,
    isFeatured: false,
    variants: [
      { sku: 'AF-DEN-006-DRK-31-32', colour: 'Dark Wash', colourCode: '#2B3747', size: '31', length: '32', fit: 'Athletic Slim', price: 95.00, onHandStock: 14, reservedStock: 0, availableStock: 14, isAvailable: true },
      { sku: 'AF-DEN-006-DRK-32-32', colour: 'Dark Wash', colourCode: '#2B3747', size: '32', length: '32', fit: 'Athletic Slim', price: 95.00, onHandStock: 20, reservedStock: 1, availableStock: 19, isAvailable: true },
      { sku: 'AF-DEN-006-DRK-34-32', colour: 'Dark Wash', colourCode: '#2B3747', size: '34', length: '32', fit: 'Athletic Slim', price: 95.00, onHandStock: 12, reservedStock: 0, availableStock: 12, isAvailable: true }
    ]
  },

  // 3. Additional Linen Products
  {
    id: 'prod-7',
    styleId: 'AF-LIN-007',
    title: 'Linen Blend Drawstring Trousers',
    subtitle: 'Effortless Warm-Weather Tailoring',
    description: 'Easy pull-on trousers featuring a comfortable elasticated drawstring waist and a relaxed wide leg. Perfect for beach strolls or warm evenings.',
    category: 'Linen',
    gender: 'Women',
    fabricComposition: '55% Linen, 45% Organic Cotton',
    careInstructions: 'Machine wash gentle, hang to dry.',
    images: [
      'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1598554747436-c9293d6a588f?auto=format&fit=crop&w=1200&q=80'
    ],
    sizeChartReference: 'Women’s Trousers - Relaxed (XS to XL)',
    basePrice: 85.00,
    rating: 4.7,
    reviewsCount: 94,
    isNewArrival: true,
    isFeatured: false,
    variants: [
      { sku: 'AF-LIN-007-WHT-XS', colour: 'Pure White', colourCode: '#FAFAFA', size: 'XS', fit: 'Relaxed', price: 85.00, onHandStock: 8, reservedStock: 0, availableStock: 8, isAvailable: true },
      { sku: 'AF-LIN-007-WHT-S', colour: 'Pure White', colourCode: '#FAFAFA', size: 'S', fit: 'Relaxed', price: 85.00, onHandStock: 15, reservedStock: 0, availableStock: 15, isAvailable: true },
      { sku: 'AF-LIN-007-WHT-M', colour: 'Pure White', colourCode: '#FAFAFA', size: 'M', fit: 'Relaxed', price: 85.00, onHandStock: 12, reservedStock: 1, availableStock: 11, isAvailable: true },
      { sku: 'AF-LIN-007-WHT-L', colour: 'Pure White', colourCode: '#FAFAFA', size: 'L', fit: 'Relaxed', price: 85.00, onHandStock: 4, reservedStock: 0, availableStock: 4, isAvailable: true }
    ]
  },
  {
    id: 'prod-8',
    styleId: 'AF-LIN-008',
    title: 'Mens Linen Vacation Shirt',
    subtitle: 'Camp Collar Short-Sleeve',
    description: 'An airy resort-ready shirt with an open camp collar and straight hem. Tailored for breathable comfort in high temperatures.',
    category: 'Linen',
    gender: 'Men',
    fabricComposition: '100% Linen',
    careInstructions: 'Machine wash cold, tumble dry low.',
    images: [
      'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=1200&q=80'
    ],
    sizeChartReference: 'Men’s Shirts - Regular Fit (S to XXL)',
    basePrice: 70.00,
    rating: 4.8,
    reviewsCount: 140,
    isNewArrival: true,
    isFeatured: false,
    variants: [
      { sku: 'AF-LIN-008-NVY-S', colour: 'Navy', colourCode: '#1A2b3C', size: 'S', fit: 'Regular', price: 70.00, onHandStock: 9, reservedStock: 0, availableStock: 9, isAvailable: true },
      { sku: 'AF-LIN-008-NVY-M', colour: 'Navy', colourCode: '#1A2b3C', size: 'M', fit: 'Regular', price: 70.00, onHandStock: 14, reservedStock: 0, availableStock: 14, isAvailable: true },
      { sku: 'AF-LIN-008-NVY-L', colour: 'Navy', colourCode: '#1A2b3C', size: 'L', fit: 'Regular', price: 70.00, onHandStock: 11, reservedStock: 0, availableStock: 11, isAvailable: true },
      { sku: 'AF-LIN-008-SND-M', colour: 'Sand Dune', colourCode: '#D8C5B2', size: 'M', fit: 'Regular', price: 70.00, onHandStock: 7, reservedStock: 0, availableStock: 7, isAvailable: true }
    ]
  },

  // 4. Dresses & Jumpsuits
  {
    id: 'prod-9',
    styleId: 'AF-DRS-009',
    title: 'Satin Slip Midi Dress',
    subtitle: 'Lustrous Bias-Cut Silhouette',
    description: 'Effortlessly elegant bias-cut midi dress crafted from fluid satin with a subtle sheen. Features delicate V-neckline and adjustable spaghetti straps.',
    category: 'Dresses',
    gender: 'Women',
    fabricComposition: '52% Recycled Polyester, 48% Polyester',
    careInstructions: 'Hand wash cold or dry clean.',
    images: [
      'https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=1200&q=80'
    ],
    sizeChartReference: 'Women’s Slip Dress - Bias Cut (XS to XL)',
    basePrice: 110.00,
    rating: 4.9,
    reviewsCount: 175,
    isNewArrival: false,
    isFeatured: true,
    variants: [
      { sku: 'AF-DRS-009-BLK-XS', colour: 'Black', colourCode: '#111111', size: 'XS', fit: 'Bias Cut', price: 110.00, onHandStock: 8, reservedStock: 0, availableStock: 8, isAvailable: true },
      { sku: 'AF-DRS-009-BLK-S', colour: 'Black', colourCode: '#111111', size: 'S', fit: 'Bias Cut', price: 110.00, onHandStock: 16, reservedStock: 1, availableStock: 15, isAvailable: true },
      { sku: 'AF-DRS-009-BLK-M', colour: 'Black', colourCode: '#111111', size: 'M', fit: 'Bias Cut', price: 110.00, onHandStock: 12, reservedStock: 0, availableStock: 12, isAvailable: true },
      { sku: 'AF-DRS-009-EMP-S', colour: 'Emerald', colourCode: '#1B4D3E', size: 'S', fit: 'Bias Cut', price: 110.00, onHandStock: 6, reservedStock: 0, availableStock: 6, isAvailable: true }
    ]
  },
  {
    id: 'prod-10',
    styleId: 'AF-DRS-010',
    title: 'Tiered Cotton Poplin Maxi Dress',
    subtitle: 'Voluminous Summer Statement',
    description: 'A striking tiered maxi dress made from crisp cotton poplin. Features pockets, halter neckline, and a breezy silhouette for effortless day-to-night styling.',
    category: 'Dresses',
    gender: 'Women',
    fabricComposition: '100% Organic Cotton',
    careInstructions: 'Machine wash cold. Line dry.',
    images: [
      'https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1200&q=80'
    ],
    sizeChartReference: 'Women’s Maxi Dress (XS to L)',
    basePrice: 140.00,
    rating: 4.8,
    reviewsCount: 64,
    isNewArrival: true,
    isFeatured: false,
    variants: [
      { sku: 'AF-DRS-010-WHT-XS', colour: 'Crisp White', colourCode: '#FFFFFF', size: 'XS', fit: 'Relaxed Maxi', price: 140.00, onHandStock: 5, reservedStock: 0, availableStock: 5, isAvailable: true },
      { sku: 'AF-DRS-010-WHT-S', colour: 'Crisp White', colourCode: '#FFFFFF', size: 'S', fit: 'Relaxed Maxi', price: 140.00, onHandStock: 9, reservedStock: 0, availableStock: 9, isAvailable: true },
      { sku: 'AF-DRS-010-WHT-M', colour: 'Crisp White', colourCode: '#FFFFFF', size: 'M', fit: 'Relaxed Maxi', price: 140.00, onHandStock: 7, reservedStock: 0, availableStock: 7, isAvailable: true }
    ]
  },

  // 5. Polos & Tees
  {
    id: 'prod-11',
    styleId: 'AF-POL-011',
    title: 'Essential Heavyweight Crew Tee',
    subtitle: 'Vintage Washed Cotton Jersey',
    description: 'Built from a sturdy 240gsm cotton jersey with a vintage garment wash for an ultra-soft lived-in feel from day one. Classic crew neckline and relaxed boxy cut.',
    category: 'Polos & tees',
    gender: 'Men',
    fabricComposition: '100% Heavyweight Cotton',
    careInstructions: 'Machine wash cold with like colors.',
    images: [
      'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=1200&q=80'
    ],
    sizeChartReference: 'Men’s Tees - Relaxed Fit (S to XXL)',
    basePrice: 35.00,
    rating: 4.9,
    reviewsCount: 512,
    isNewArrival: false,
    isFeatured: false,
    variants: [
      { sku: 'AF-POL-011-WHT-S', colour: 'White', colourCode: '#FFFFFF', size: 'S', fit: 'Relaxed Tee', price: 35.00, onHandStock: 25, reservedStock: 0, availableStock: 25, isAvailable: true },
      { sku: 'AF-POL-011-WHT-M', colour: 'White', colourCode: '#FFFFFF', size: 'M', fit: 'Relaxed Tee', price: 35.00, onHandStock: 30, reservedStock: 2, availableStock: 28, isAvailable: true },
      { sku: 'AF-POL-011-WHT-L', colour: 'White', colourCode: '#FFFFFF', size: 'L', fit: 'Relaxed Tee', price: 35.00, onHandStock: 22, reservedStock: 1, availableStock: 21, isAvailable: true },
      { sku: 'AF-POL-011-BLK-M', colour: 'Washed Black', colourCode: '#222222', size: 'M', fit: 'Relaxed Tee', price: 35.00, onHandStock: 18, reservedStock: 0, availableStock: 18, isAvailable: true },
      { sku: 'AF-POL-011-BLK-L', colour: 'Washed Black', colourCode: '#222222', size: 'L', fit: 'Relaxed Tee', price: 35.00, onHandStock: 15, reservedStock: 0, availableStock: 15, isAvailable: true }
    ]
  },
  {
    id: 'prod-12',
    styleId: 'AF-POL-012',
    title: 'Women’s Signature Ribbed Tee',
    subtitle: 'Ultra-Soft Modal Cotton Blend',
    description: 'A versatile everyday staple featuring a fitted silhouette and fine ribbed texture. Cut with a flattering crew neckline that layers effortlessly.',
    category: 'Polos & tees',
    gender: 'Women',
    fabricComposition: '58% Cotton, 39% Modal, 3% Elastane',
    careInstructions: 'Machine wash cold, lay flat to dry.',
    images: [
      'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=1200&q=80'
    ],
    sizeChartReference: 'Women’s Tops - Fitted (XS to XL)',
    basePrice: 32.00,
    rating: 4.8,
    reviewsCount: 310,
    isNewArrival: false,
    isFeatured: false,
    variants: [
      { sku: 'AF-POL-012-OTH-XS', colour: 'Oatmeal Heather', colourCode: '#E3DFD5', size: 'XS', fit: 'Fitted', price: 32.00, onHandStock: 14, reservedStock: 0, availableStock: 14, isAvailable: true },
      { sku: 'AF-POL-012-OTH-S', colour: 'Oatmeal Heather', colourCode: '#E3DFD5', size: 'S', fit: 'Fitted', price: 32.00, onHandStock: 20, reservedStock: 1, availableStock: 19, isAvailable: true },
      { sku: 'AF-POL-012-OTH-M', colour: 'Oatmeal Heather', colourCode: '#E3DFD5', size: 'M', fit: 'Fitted', price: 32.00, onHandStock: 16, reservedStock: 0, availableStock: 16, isAvailable: true },
      { sku: 'AF-POL-012-BLK-S', colour: 'Black', colourCode: '#111111', size: 'S', fit: 'Fitted', price: 32.00, onHandStock: 19, reservedStock: 0, availableStock: 19, isAvailable: true }
    ]
  },

  // 6. Knitwear & Sweaters
  {
    id: 'prod-13',
    styleId: 'AF-KNT-013',
    title: 'Cable Knit Cashmere-Blend Crew',
    subtitle: 'Luxurious Soft-Touch Texture',
    description: 'Expertly knitted with a timeless cable pattern using a plush wool and recycled cashmere yarn. Designed with ribbed trims and a comfortable relaxed drape.',
    category: 'Knitwear',
    gender: 'Women',
    fabricComposition: '47% Wool, 30% Recycled Nylon, 20% Acrylic, 3% Cashmere',
    careInstructions: 'Hand wash cold or dry clean. Dry flat.',
    images: [
      'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=1200&q=80'
    ],
    sizeChartReference: 'Women’s Knitwear - Relaxed (XS to XL)',
    basePrice: 110.00,
    rating: 4.9,
    reviewsCount: 198,
    isNewArrival: true,
    isFeatured: true,
    variants: [
      { sku: 'AF-KNT-013-CRM-XS', colour: 'Cream', colourCode: '#F5F2EB', size: 'XS', fit: 'Relaxed', price: 110.00, onHandStock: 6, reservedStock: 0, availableStock: 6, isAvailable: true },
      { sku: 'AF-KNT-013-CRM-S', colour: 'Cream', colourCode: '#F5F2EB', size: 'S', fit: 'Relaxed', price: 110.00, onHandStock: 12, reservedStock: 1, availableStock: 11, isAvailable: true },
      { sku: 'AF-KNT-013-CRM-M', colour: 'Cream', colourCode: '#F5F2EB', size: 'M', fit: 'Relaxed', price: 110.00, onHandStock: 10, reservedStock: 0, availableStock: 10, isAvailable: true },
      { sku: 'AF-KNT-013-CRM-L', colour: 'Cream', colourCode: '#F5F2EB', size: 'L', fit: 'Relaxed', price: 110.00, onHandStock: 4, reservedStock: 0, availableStock: 4, isAvailable: true }
    ]
  },
  {
    id: 'prod-14',
    styleId: 'AF-KNT-014',
    title: 'Mens Half-Zip Mockneck Pullover',
    subtitle: 'Ribbed Cotton Knit Heritage Sweater',
    description: 'A refined transitional sweater featuring a metal hardware half-zip placket and structured ribbed collar. Layer it over a crisp tee or wear on its own.',
    category: 'Knitwear',
    gender: 'Men',
    fabricComposition: '100% Organic Cotton',
    careInstructions: 'Machine wash cold on gentle cycle. Dry flat.',
    images: [
      'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1617137984095-74e4e5e3613f?auto=format&fit=crop&w=1200&q=80'
    ],
    sizeChartReference: 'Men’s Knitwear - Regular Fit (S to XXL)',
    basePrice: 90.00,
    rating: 4.8,
    reviewsCount: 142,
    isNewArrival: false,
    isFeatured: false,
    variants: [
      { sku: 'AF-KNT-014-CAM-S', colour: 'Camel', colourCode: '#C49A6C', size: 'S', fit: 'Regular', price: 90.00, onHandStock: 8, reservedStock: 0, availableStock: 8, isAvailable: true },
      { sku: 'AF-KNT-014-CAM-M', colour: 'Camel', colourCode: '#C49A6C', size: 'M', fit: 'Regular', price: 90.00, onHandStock: 14, reservedStock: 0, availableStock: 14, isAvailable: true },
      { sku: 'AF-KNT-014-CAM-L', colour: 'Camel', colourCode: '#C49A6C', size: 'L', fit: 'Regular', price: 90.00, onHandStock: 9, reservedStock: 0, availableStock: 9, isAvailable: true },
      { sku: 'AF-KNT-014-BLK-L', colour: 'Black', colourCode: '#111111', size: 'L', fit: 'Regular', price: 90.00, onHandStock: 7, reservedStock: 0, availableStock: 7, isAvailable: true }
    ]
  },

  // 7. Outerwear
  {
    id: 'prod-15',
    styleId: 'AF-OUT-015',
    title: 'Tailored Trench Coat',
    subtitle: 'Classic Double-Breasted Silhouette',
    description: 'An enduring outerwear staple crafted from water-resistant cotton twill. Features epaulets, belted waist, storm flap, and horn-effect buttons.',
    category: 'Outerwear',
    gender: 'Women',
    fabricComposition: '65% Cotton, 35% Polyester; Lining: 100% Recycled Viscose',
    careInstructions: 'Dry clean only.',
    images: [
      'https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=1200&q=80'
    ],
    sizeChartReference: 'Women’s Outerwear - Tailored (XS to XL)',
    basePrice: 180.00,
    rating: 4.9,
    reviewsCount: 88,
    isNewArrival: true,
    isFeatured: true,
    variants: [
      { sku: 'AF-OUT-015-TNT-XS', colour: 'Classic Trench', colourCode: '#C8A97E', size: 'XS', fit: 'Tailored', price: 180.00, onHandStock: 4, reservedStock: 0, availableStock: 4, isAvailable: true },
      { sku: 'AF-OUT-015-TNT-S', colour: 'Classic Trench', colourCode: '#C8A97E', size: 'S', fit: 'Tailored', price: 180.00, onHandStock: 9, reservedStock: 1, availableStock: 8, isAvailable: true },
      { sku: 'AF-OUT-015-TNT-M', colour: 'Classic Trench', colourCode: '#C8A97E', size: 'M', fit: 'Tailored', price: 180.00, onHandStock: 7, reservedStock: 0, availableStock: 7, isAvailable: true },
      { sku: 'AF-OUT-015-TNT-L', colour: 'Classic Trench', colourCode: '#C8A97E', size: 'L', fit: 'Tailored', price: 180.00, onHandStock: 3, reservedStock: 0, availableStock: 3, isAvailable: true }
    ]
  },
  {
    id: 'prod-16',
    styleId: 'AF-OUT-016',
    title: 'Mens Suede Bomber Jacket',
    subtitle: 'Premium Goat Suede Finish',
    description: 'Luxurious soft goat suede jacket featuring ribbed collar, cuffs, and hem, zip front closure, and sleek interior lining. A timeless investment piece.',
    category: 'Outerwear',
    gender: 'Men',
    fabricComposition: '100% Genuine Goat Suede',
    careInstructions: 'Specialist leather clean only.',
    images: [
      'https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1488161628813-04466f872be2?auto=format&fit=crop&w=1200&q=80'
    ],
    sizeChartReference: 'Men’s Outerwear - Slim Fit (S to XXL)',
    basePrice: 320.00,
    rating: 5.0,
    reviewsCount: 45,
    isNewArrival: true,
    isFeatured: true,
    variants: [
      { sku: 'AF-OUT-016-BRN-S', colour: 'Cognac Brown', colourCode: '#8B5A2B', size: 'S', fit: 'Slim Bomber', price: 320.00, onHandStock: 3, reservedStock: 0, availableStock: 3, isAvailable: true },
      { sku: 'AF-OUT-016-BRN-M', colour: 'Cognac Brown', colourCode: '#8B5A2B', size: 'M', fit: 'Slim Bomber', price: 320.00, onHandStock: 6, reservedStock: 0, availableStock: 6, isAvailable: true },
      { sku: 'AF-OUT-016-BRN-L', colour: 'Cognac Brown', colourCode: '#8B5A2B', size: 'L', fit: 'Slim Bomber', price: 320.00, onHandStock: 5, reservedStock: 1, availableStock: 4, isAvailable: true },
      { sku: 'AF-OUT-016-BRN-XL', colour: 'Cognac Brown', colourCode: '#8B5A2B', size: 'XL', fit: 'Slim Bomber', price: 320.00, onHandStock: 2, reservedStock: 0, availableStock: 2, isAvailable: true }
    ]
  }
];

export const mockOutfits: SavedOutfit[] = [
  {
    id: 'outfit-1',
    name: 'Effortless Coastal Weekend',
    createdAt: '2026-11-20',
    items: [
      {
        slot: 'Top',
        productId: 'prod-2',
        sku: 'AF-LIN-002-CRM-S',
        title: 'The Signature Linen Button-Up Shirt',
        colour: 'Cream',
        size: 'S',
        price: 75.00,
        image: 'https://images.unsplash.com/photo-1598554747436-c9293d6a588f?auto=format&fit=crop&w=600&q=80'
      },
      {
        slot: 'Bottom',
        productId: 'prod-1',
        sku: 'AF-DEN-001-BLU-26-REG',
        title: 'Ultra High Rise 90s Straight Jean',
        colour: 'Medium Vintage Wash',
        size: '26',
        price: 90.00,
        image: '/public/assets/aistudio/16968c28-5025-4d42-b15d-3c1cb83c9f45_f8e84f2c.png'
      }
    ]
  },
  {
    id: 'outfit-2',
    name: 'Modern Heritage Tailored',
    createdAt: '2026-11-22',
    items: [
      {
        slot: 'Top',
        productId: 'prod-3',
        sku: 'AF-POL-003-OAT-M',
        title: 'Seamless Ribbed Knit Polo',
        colour: 'Oatmeal',
        size: 'M',
        price: 65.00,
        image: 'https://images.unsplash.com/photo-1625910513411-5ed0f550436a?auto=format&fit=crop&w=600&q=80'
      },
      {
        slot: 'Bottom',
        productId: 'prod-6',
        sku: 'AF-DEN-006-DRK-32-32',
        title: 'Mens Athletic Slim Jean',
        colour: 'Dark Wash',
        size: '32',
        price: 95.00,
        image: 'https://images.unsplash.com/photo-1542272454-17d5402d415e?auto=format&fit=crop&w=600&q=80'
      }
    ]
  }
];

export const mockOrders: Order[] = [
  {
    id: 'ord-1001',
    orderNumber: 'AF-984210',
    createdAt: '2026-11-24 14:22',
    status: 'Shipped',
    fulfillmentType: 'Delivery',
    shippingAddress: {
      fullName: 'Sarah Jenkins',
      line1: '450 West 33rd Street',
      city: 'New York',
      state: 'NY',
      postalCode: '10001',
      country: 'United States'
    },
    items: [
      {
        sku: 'AF-DEN-001-BLU-26-REG',
        productId: 'prod-1',
        title: 'Ultra High Rise 90s Straight Jean',
        colour: 'Medium Vintage Wash',
        size: '26',
        length: 'Regular',
        fit: 'Straight',
        price: 90.00,
        quantity: 1,
        image: '/public/assets/aistudio/16968c28-5025-4d42-b15d-3c1cb83c9f45_f8e84f2c.png'
      }
    ],
    subtotal: 90.00,
    discount: 0,
    shippingFee: 0.00,
    tax: 7.88,
    total: 97.88,
    paymentMethod: 'Simulated Credit Card (•••• 4242)',
    paymentStatus: 'Paid',
    trackingNumber: '1Z9999999999999999'
  },
  {
    id: 'ord-1002',
    orderNumber: 'AF-984211',
    createdAt: '2026-11-25 09:15',
    status: 'Ready for Pickup',
    fulfillmentType: 'Collection',
    storeId: 'store-1',
    items: [
      {
        sku: 'AF-LIN-002-CRM-S',
        productId: 'prod-2',
        title: 'The Signature Linen Button-Up Shirt',
        colour: 'Cream',
        size: 'S',
        fit: 'Relaxed',
        price: 75.00,
        quantity: 1,
        image: 'https://images.unsplash.com/photo-1598554747436-c9293d6a588f?auto=format&fit=crop&w=600&q=80'
      }
    ],
    subtotal: 75.00,
    discount: 0,
    shippingFee: 0.00,
    tax: 6.56,
    total: 81.56,
    paymentMethod: 'Simulated Apple Pay',
    paymentStatus: 'Paid'
  }
];

export const mockAuditLogs: AuditLogEntry[] = [
  {
    id: 'log-1',
    timestamp: '2026-11-26 10:15:22',
    user: 'admin@abercrombie-concept.internal',
    action: 'INVENTORY_ADJUSTMENT',
    details: 'Adjusted onHandStock for SKU AF-DEN-001-BLU-26-REG from 14 to 15.',
    severity: 'success'
  },
  {
    id: 'log-2',
    timestamp: '2026-11-26 09:40:10',
    user: 'system@abercrombie-concept.internal',
    action: 'RESERVATION_EXPIRY_WORKER',
    details: 'Released 1 expired cart reservation for SKU AF-LIN-002-CRM-S.',
    severity: 'info'
  },
  {
    id: 'log-3',
    timestamp: '2026-11-25 18:05:00',
    user: 'staff_nyc@abercrombie-concept.internal',
    action: 'FULFILLMENT_UPDATE',
    details: 'Marked Order AF-984211 as Ready for Pickup at Fifth Avenue Flagship.',
    severity: 'success'
  }
];
