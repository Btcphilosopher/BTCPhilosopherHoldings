-- Hermès Paris Haute Maroquinerie Database Schema
-- Optimized for high-throughput client data storage, B-Tree indexes, and referential integrity

CREATE DATABASE IF NOT EXISTS hermes_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hermes_db;

-- 1. Clients / Users Table (Efficiently indexed on email and full name)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(191) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    salutation VARCHAR(20) DEFAULT 'Madame/Monsieur',
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    phone VARCHAR(50) DEFAULT NULL,
    preferred_boutique VARCHAR(150) DEFAULT 'Paris - 24 Faubourg Saint-Honoré',
    client_tier VARCHAR(50) DEFAULT 'VIP Privileged Client',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_users_email (email),
    KEY idx_users_name (last_name, first_name),
    KEY idx_users_boutique (preferred_boutique)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Boutique Appointments & Consultations Table
CREATE TABLE IF NOT EXISTS boutique_appointments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    guest_name VARCHAR(150) NOT NULL,
    guest_email VARCHAR(191) NOT NULL,
    guest_phone VARCHAR(50) NOT NULL,
    boutique VARCHAR(150) NOT NULL,
    service_type VARCHAR(100) NOT NULL,
    appointment_date DATE NOT NULL,
    appointment_time VARCHAR(20) NOT NULL,
    special_requests TEXT NULL,
    status ENUM('CONFIRMED', 'PENDING', 'COMPLETED', 'CANCELLED') DEFAULT 'CONFIRMED',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_appt_boutique_date (boutique, appointment_date),
    KEY idx_appt_guest_email (guest_email),
    CONSTRAINT fk_appt_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Client Wishlist & Reservations
CREATE TABLE IF NOT EXISTS client_wishlist (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    session_id VARCHAR(100) NOT NULL,
    item_key VARCHAR(50) NOT NULL,
    item_name VARCHAR(150) NOT NULL,
    leather_finish VARCHAR(100) NOT NULL,
    colorway VARCHAR(100) NOT NULL,
    hardware VARCHAR(50) NOT NULL,
    price_eur DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_wishlist_session (session_id),
    KEY idx_wishlist_user (user_id),
    KEY idx_wishlist_item (item_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Newsletter Subscribers (Optimized with duplicate-key protection)
CREATE TABLE IF NOT EXISTS newsletter_subscribers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(191) NOT NULL,
    interests VARCHAR(255) DEFAULT 'Haute Maroquinerie, Soie, Horlogerie',
    status ENUM('ACTIVE', 'UNSUBSCRIBED') DEFAULT 'ACTIVE',
    subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_newsletter_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Concierge Inquiries & Private Client Requests
CREATE TABLE IF NOT EXISTS client_inquiries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(191) NOT NULL,
    subject VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    status VARCHAR(50) DEFAULT 'Assigned to Concierge',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_inquiry_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed an initial demonstration client (password: hermes1837)
INSERT INTO users (email, password_hash, salutation, first_name, last_name, phone, preferred_boutique, client_tier)
VALUES (
    'claire.devalmont@elysee.fr',
    '$2y$10$wN1qGk0w/F2y4mOqTfM0w.mFqf9zP60Bf2P5E7M1I8rT5O2C6eIqu',
    'Madame',
    'Claire',
    'de Valmont',
    '+33 6 42 18 37 00',
    'Paris - 24 Faubourg Saint-Honoré',
    'VIP Privileged Client'
) ON DUPLICATE KEY UPDATE first_name = VALUES(first_name);

-- Seed initial appointment
INSERT INTO boutique_appointments (guest_name, guest_email, guest_phone, boutique, service_type, appointment_date, appointment_time, special_requests, status)
VALUES (
    'Claire de Valmont',
    'claire.devalmont@elysee.fr',
    '+33 6 42 18 37 00',
    'Paris - 24 Faubourg Saint-Honoré',
    'Haute Maroquinerie Consultation (Birkin 25 Togo)',
    DATE_ADD(CURRENT_DATE(), INTERVAL 3 DAY),
    '15:30',
    'Desires private viewing of Gold and Craie leather swatch palettes in the private VIP salon.',
    'CONFIRMED'
) ON DUPLICATE KEY UPDATE guest_name = VALUES(guest_name);
