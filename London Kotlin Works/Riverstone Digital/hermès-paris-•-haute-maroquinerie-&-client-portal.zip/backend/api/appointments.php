<?php
/**
 * Hermès Paris Boutique Appointments & Consultations API
 * Handles VIP salon bookings, consultations, and status management.
 */

require_once __DIR__ . '/../config/db.php';

$action = $_GET['action'] ?? 'list';
$data = getRequestData();

switch ($action) {
    case 'book':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            jsonResponse(['status' => 'error', 'message' => 'Method not allowed'], 405);
        }

        $userId = !empty($data['user_id']) ? (int)$data['user_id'] : null;
        $guestName = trim($data['guest_name'] ?? '');
        $guestEmail = trim($data['guest_email'] ?? '');
        $guestPhone = trim($data['guest_phone'] ?? '');
        $boutique = trim($data['boutique'] ?? 'Paris - 24 Faubourg Saint-Honoré');
        $serviceType = trim($data['service_type'] ?? 'Haute Maroquinerie Consultation');
        $appointmentDate = trim($data['appointment_date'] ?? '');
        $appointmentTime = trim($data['appointment_time'] ?? '14:00');
        $specialRequests = trim($data['special_requests'] ?? '');

        if (empty($guestName) || empty($guestEmail) || empty($appointmentDate)) {
            jsonResponse(['status' => 'error', 'message' => 'Name, email, and date are required.'], 422);
        }

        // Verify slot availability (max 4 private salon appointments per slot)
        $slotCheck = $pdo->prepare("
            SELECT COUNT(*) AS total
            FROM boutique_appointments
            WHERE boutique = :boutique
              AND appointment_date = :appointment_date
              AND appointment_time = :appointment_time
              AND status != 'CANCELLED'
        ");
        $slotCheck->execute([
            ':boutique'         => $boutique,
            ':appointment_date' => $appointmentDate,
            ':appointment_time' => $appointmentTime
        ]);
        $count = (int)$slotCheck->fetchColumn();

        if ($count >= 4) {
            jsonResponse(['status' => 'error', 'message' => 'The selected private salon time is fully booked. Please select an alternate time.'], 409);
        }

        // Insert appointment with transaction
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("
                INSERT INTO boutique_appointments (
                    user_id, guest_name, guest_email, guest_phone,
                    boutique, service_type, appointment_date, appointment_time,
                    special_requests, status
                ) VALUES (
                    :user_id, :guest_name, :guest_email, :guest_phone,
                    :boutique, :service_type, :appointment_date, :appointment_time,
                    :special_requests, 'CONFIRMED'
                )
            ");
            $stmt->execute([
                ':user_id'          => $userId,
                ':guest_name'       => $guestName,
                ':guest_email'      => $guestEmail,
                ':guest_phone'      => $guestPhone,
                ':boutique'         => $boutique,
                ':service_type'     => $serviceType,
                ':appointment_date' => $appointmentDate,
                ':appointment_time' => $appointmentTime,
                ':special_requests' => $specialRequests
            ]);
            $apptId = (int)$pdo->lastInsertId();
            $pdo->commit();

            jsonResponse([
                'status'  => 'success',
                'message' => 'Your private boutique consultation has been confirmed.',
                'appointment' => [
                    'id'               => $apptId,
                    'confirmation_ref' => 'H-PARIS-' . str_pad((string)$apptId, 6, '0', STR_PAD_LEFT),
                    'guest_name'       => $guestName,
                    'guest_email'      => $guestEmail,
                    'boutique'         => $boutique,
                    'service_type'     => $serviceType,
                    'appointment_date' => $appointmentDate,
                    'appointment_time' => $appointmentTime,
                    'status'           => 'CONFIRMED'
                ]
            ], 201);
        } catch (Exception $e) {
            $pdo->rollBack();
            jsonResponse(['status' => 'error', 'message' => 'Could not save appointment: ' . $e->getMessage()], 500);
        }
        break;

    case 'list':
        $userEmail = trim($_GET['email'] ?? '');
        $userId = !empty($_GET['user_id']) ? (int)$_GET['user_id'] : null;

        if ($userId) {
            $stmt = $pdo->prepare("
                SELECT id, user_id, guest_name, guest_email, guest_phone,
                       boutique, service_type, appointment_date, appointment_time,
                       special_requests, status, created_at
                FROM boutique_appointments
                WHERE user_id = :user_id
                ORDER BY appointment_date DESC, appointment_time ASC
                LIMIT 50
            ");
            $stmt->execute([':user_id' => $userId]);
        } elseif (!empty($userEmail)) {
            $stmt = $pdo->prepare("
                SELECT id, user_id, guest_name, guest_email, guest_phone,
                       boutique, service_type, appointment_date, appointment_time,
                       special_requests, status, created_at
                FROM boutique_appointments
                WHERE guest_email = :email
                ORDER BY appointment_date DESC, appointment_time ASC
                LIMIT 50
            ");
            $stmt->execute([':email' => $userEmail]);
        } else {
            // General latest for concierge
            $stmt = $pdo->query("
                SELECT id, user_id, guest_name, guest_email, guest_phone,
                       boutique, service_type, appointment_date, appointment_time,
                       special_requests, status, created_at
                FROM boutique_appointments
                ORDER BY created_at DESC
                LIMIT 30
            ");
        }

        $appointments = $stmt->fetchAll();
        jsonResponse([
            'status'        => 'success',
            'count'         => count($appointments),
            'appointments'  => $appointments
        ]);
        break;

    default:
        jsonResponse(['status' => 'error', 'message' => 'Invalid action'], 400);
        break;
}
