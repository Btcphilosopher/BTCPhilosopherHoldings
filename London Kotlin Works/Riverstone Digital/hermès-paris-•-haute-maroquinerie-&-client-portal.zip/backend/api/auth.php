<?php
/**
 * Hermès Paris Client Authentication & Profile API
 * Handles user registration, login, and profile fetching with bcrypt hashing
 */

require_once __DIR__ . '/../config/db.php';

$action = $_GET['action'] ?? 'status';
$data = getRequestData();

switch ($action) {
    case 'register':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            jsonResponse(['status' => 'error', 'message' => 'Method not allowed'], 405);
        }

        $email = trim($data['email'] ?? '');
        $password = $data['password'] ?? '';
        $firstName = trim($data['first_name'] ?? '');
        $lastName = trim($data['last_name'] ?? '');
        $salutation = trim($data['salutation'] ?? 'Madame/Monsieur');
        $phone = trim($data['phone'] ?? '');
        $preferredBoutique = trim($data['preferred_boutique'] ?? 'Paris - 24 Faubourg Saint-Honoré');

        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            jsonResponse(['status' => 'error', 'message' => 'Please provide a valid client email address'], 422);
        }
        if (strlen($password) < 6) {
            jsonResponse(['status' => 'error', 'message' => 'Password must be at least 6 characters'], 422);
        }
        if (empty($firstName) || empty($lastName)) {
            jsonResponse(['status' => 'error', 'message' => 'First and last name are required for client registration'], 422);
        }

        // Check if user already exists (utilizing unique B-tree index on email)
        $checkStmt = $pdo->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
        $checkStmt->execute([':email' => $email]);
        if ($checkStmt->fetch()) {
            jsonResponse(['status' => 'error', 'message' => 'An Hermès client account already exists with this email'], 409);
        }

        $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]);

        // Insert into users table
        $insertStmt = $pdo->prepare("
            INSERT INTO users (email, password_hash, salutation, first_name, last_name, phone, preferred_boutique, client_tier)
            VALUES (:email, :password_hash, :salutation, :first_name, :last_name, :phone, :preferred_boutique, 'Privileged Client')
        ");

        $insertStmt->execute([
            ':email'             => $email,
            ':password_hash'     => $hash,
            ':salutation'        => $salutation,
            ':first_name'        => $firstName,
            ':last_name'         => $lastName,
            ':phone'             => $phone,
            ':preferred_boutique'=> $preferredBoutique
        ]);

        $newId = (int)$pdo->lastInsertId();

        jsonResponse([
            'status'  => 'success',
            'message' => 'Welcome to the World of Hermès. Your client account has been created.',
            'user'    => [
                'id'                => $newId,
                'email'             => $email,
                'salutation'        => $salutation,
                'first_name'        => $firstName,
                'last_name'         => $lastName,
                'phone'             => $phone,
                'preferred_boutique'=> $preferredBoutique,
                'client_tier'       => 'Privileged Client'
            ]
        ], 201);
        break;

    case 'login':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            jsonResponse(['status' => 'error', 'message' => 'Method not allowed'], 405);
        }

        $email = trim($data['email'] ?? '');
        $password = $data['password'] ?? '';

        if (empty($email) || empty($password)) {
            jsonResponse(['status' => 'error', 'message' => 'Please provide email and password'], 422);
        }

        // Fast index lookup
        $stmt = $pdo->prepare("
            SELECT id, email, password_hash, salutation, first_name, last_name, phone, preferred_boutique, client_tier, created_at
            FROM users
            WHERE email = :email
            LIMIT 1
        ");
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();

        // Check demo password or hashed password
        $isValid = false;
        if ($user) {
            if ($password === 'hermes1837' || password_verify($password, $user['password_hash'])) {
                $isValid = true;
            }
        }

        if (!$isValid) {
            jsonResponse(['status' => 'error', 'message' => 'Invalid credentials. (Hint: demo user is claire.devalmont@elysee.fr / hermes1837)'], 401);
        }

        unset($user['password_hash']);

        jsonResponse([
            'status'  => 'success',
            'message' => 'Authentication successful',
            'user'    => $user
        ]);
        break;

    case 'profile':
        $userId = (int)($_GET['id'] ?? 0);
        if ($userId <= 0) {
            jsonResponse(['status' => 'error', 'message' => 'Missing user ID'], 400);
        }

        $stmt = $pdo->prepare("
            SELECT id, email, salutation, first_name, last_name, phone, preferred_boutique, client_tier, created_at
            FROM users
            WHERE id = :id
            LIMIT 1
        ");
        $stmt->execute([':id' => $userId]);
        $user = $stmt->fetch();

        if (!$user) {
            jsonResponse(['status' => 'error', 'message' => 'Client not found'], 404);
        }

        jsonResponse(['status' => 'success', 'user' => $user]);
        break;

    default:
        jsonResponse([
            'status'  => 'ok',
            'service' => 'Hermès Paris Client Authentication Service (PHP 8.2 & MySQL)',
            'time'    => date('c')
        ]);
        break;
}
