<?php
/**
 * Hermès Paris Newsletter Subscription API
 * Uses INSERT ... ON DUPLICATE KEY UPDATE for idempotent, efficient writes
 */

require_once __DIR__ . '/../config/db.php';

$data = getRequestData();
$email = trim($data['email'] ?? '');
$interests = trim($data['interests'] ?? 'Haute Maroquinerie, Soie, Horlogerie');

if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    jsonResponse(['status' => 'error', 'message' => 'Please enter a valid email address.'], 422);
}

try {
    // Highly efficient MySQL upsert
    $stmt = $pdo->prepare("
        INSERT INTO newsletter_subscribers (email, interests, status, subscribed_at)
        VALUES (:email, :interests, 'ACTIVE', CURRENT_TIMESTAMP)
        ON DUPLICATE KEY UPDATE
            status = 'ACTIVE',
            interests = :interests_update
    ");
    $stmt->execute([
        ':email'            => $email,
        ':interests'        => $interests,
        ':interests_update' => $interests
    ]);

    jsonResponse([
        'status'  => 'success',
        'message' => 'Thank you. You are now subscribed to Hermès Paris publications and invitations.',
        'email'   => $email
    ]);
} catch (Exception $e) {
    jsonResponse(['status' => 'error', 'message' => 'Subscription failed: ' . $e->getMessage()], 500);
}
