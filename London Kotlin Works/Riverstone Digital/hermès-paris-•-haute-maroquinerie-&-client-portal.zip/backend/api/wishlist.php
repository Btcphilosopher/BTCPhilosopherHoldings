<?php
/**
 * Hermès Paris Client Wishlist API
 * Supports saving iconic pieces (Birkin, Kelly, Scarves, Watches) with customized leather & hardware
 */

require_once __DIR__ . '/../config/db.php';

$action = $_GET['action'] ?? 'list';
$data = getRequestData();

switch ($action) {
    case 'add':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            jsonResponse(['status' => 'error', 'message' => 'Method not allowed'], 405);
        }

        $userId = !empty($data['user_id']) ? (int)$data['user_id'] : null;
        $sessionId = trim($data['session_id'] ?? 'hermes_guest_' . substr(md5(session_id() ?: 'guest'), 0, 12));
        $itemKey = trim($data['item_key'] ?? 'birkin');
        $itemName = trim($data['item_name'] ?? 'Birkin 25');
        $leatherFinish = trim($data['leather_finish'] ?? 'Togo Calfskin');
        $colorway = trim($data['colorway'] ?? 'Gold (Tanned Caramel)');
        $hardware = trim($data['hardware'] ?? 'Gold-plated Permabrass');
        $priceEur = (float)($data['price_eur'] ?? 11500.00);

        $stmt = $pdo->prepare("
            INSERT INTO client_wishlist (
                user_id, session_id, item_key, item_name, leather_finish, colorway, hardware, price_eur
            ) VALUES (
                :user_id, :session_id, :item_key, :item_name, :leather_finish, :colorway, :hardware, :price_eur
            )
        ");
        $stmt->execute([
            ':user_id'        => $userId,
            ':session_id'     => $sessionId,
            ':item_key'       => $itemKey,
            ':item_name'      => $itemName,
            ':leather_finish' => $leatherFinish,
            ':colorway'       => $colorway,
            ':hardware'       => $hardware,
            ':price_eur'      => $priceEur
        ]);

        jsonResponse([
            'status'  => 'success',
            'message' => 'Item added to your private Hermès wishlist.',
            'id'      => (int)$pdo->lastInsertId()
        ], 201);
        break;

    case 'list':
        $sessionId = trim($_GET['session_id'] ?? '');
        $userId = !empty($_GET['user_id']) ? (int)$_GET['user_id'] : null;

        if ($userId) {
            $stmt = $pdo->prepare("
                SELECT id, user_id, session_id, item_key, item_name, leather_finish, colorway, hardware, price_eur, created_at
                FROM client_wishlist
                WHERE user_id = :user_id OR session_id = :session_id
                ORDER BY created_at DESC
            ");
            $stmt->execute([':user_id' => $userId, ':session_id' => $sessionId]);
        } else {
            $stmt = $pdo->prepare("
                SELECT id, user_id, session_id, item_key, item_name, leather_finish, colorway, hardware, price_eur, created_at
                FROM client_wishlist
                WHERE session_id = :session_id
                ORDER BY created_at DESC
            ");
            $stmt->execute([':session_id' => $sessionId]);
        }

        $items = $stmt->fetchAll();
        jsonResponse([
            'status' => 'success',
            'count'  => count($items),
            'items'  => $items
        ]);
        break;

    case 'remove':
        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) {
            jsonResponse(['status' => 'error', 'message' => 'Invalid ID'], 400);
        }
        $stmt = $pdo->prepare("DELETE FROM client_wishlist WHERE id = :id");
        $stmt->execute([':id' => $id]);
        jsonResponse(['status' => 'success', 'message' => 'Item removed from wishlist']);
        break;

    default:
        jsonResponse(['status' => 'error', 'message' => 'Invalid action'], 400);
        break;
}
