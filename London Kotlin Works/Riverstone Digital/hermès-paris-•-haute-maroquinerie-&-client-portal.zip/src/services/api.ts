import { User, BoutiqueAppointment, WishlistItem, DbOverview, TableDetail, ExplainResult } from '../types';

export const api = {
  // Authentication & Users
  async login(email: string, password: string):Promise<{ status: string; user: User; message: string }> {
    const res = await fetch('/api/php/auth.php?action=login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Login failed');
    return data;
  },

  async register(payload: {
    email: string;
    password: string;
    salutation: string;
    first_name: string;
    last_name: string;
    phone?: string;
    preferred_boutique: string;
  }): Promise<{ status: string; user: User; message: string }> {
    const res = await fetch('/api/php/auth.php?action=register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Registration failed');
    return data;
  },

  async getProfile(id: number): Promise<{ status: string; user: User }> {
    const res = await fetch(`/api/php/auth.php?action=profile&id=${id}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Profile fetch failed');
    return data;
  },

  // Appointments
  async bookAppointment(payload: {
    user_id?: number | null;
    guest_name: string;
    guest_email: string;
    guest_phone: string;
    boutique: string;
    service_type: string;
    appointment_date: string;
    appointment_time: string;
    special_requests?: string;
  }): Promise<{ status: string; message: string; appointment: BoutiqueAppointment }> {
    const res = await fetch('/api/php/appointments.php?action=book', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Booking failed');
    return data;
  },

  async listAppointments(email?: string, userId?: number): Promise<BoutiqueAppointment[]> {
    let url = '/api/php/appointments.php?action=list';
    if (userId) url += `&user_id=${userId}`;
    else if (email) url += `&email=${encodeURIComponent(email)}`;

    const res = await fetch(url);
    const data = await res.json();
    return data.appointments || [];
  },

  // Wishlist
  async addToWishlist(payload: {
    user_id?: number | null;
    session_id: string;
    item_key: string;
    item_name: string;
    leather_finish: string;
    colorway: string;
    hardware: string;
    price_eur: number;
  }): Promise<{ status: string; id: number; message: string }> {
    const res = await fetch('/api/php/wishlist.php?action=add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Could not add to wishlist');
    return data;
  },

  async getWishlist(sessionId: string, userId?: number): Promise<WishlistItem[]> {
    let url = `/api/php/wishlist.php?action=list&session_id=${encodeURIComponent(sessionId)}`;
    if (userId) url += `&user_id=${userId}`;

    const res = await fetch(url);
    const data = await res.json();
    return data.items || [];
  },

  async removeFromWishlist(id: number): Promise<void> {
    await fetch(`/api/php/wishlist.php?action=remove&id=${id}`);
  },

  // Newsletter
  async subscribeNewsletter(email: string, interests?: string): Promise<{ status: string; message: string }> {
    const res = await fetch('/api/php/newsletter.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, interests }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Subscription failed');
    return data;
  },

  // Database & PHP Architecture Inspector
  async getDbOverview(): Promise<DbOverview> {
    const res = await fetch('/api/php/db_inspector.php?action=summary');
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Failed to fetch DB telemetry');
    return data;
  },

  async getTableDetail(tableName: string): Promise<TableDetail> {
    const res = await fetch(`/api/php/db_inspector.php?action=table_detail&table=${tableName}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Failed to fetch table details');
    return data;
  },

  async getExplainQuery(queryType: string): Promise<ExplainResult> {
    const res = await fetch(`/api/php/db_inspector.php?action=explain_query&type=${queryType}`);
    const data = await res.json();
    return data;
  },

  async getSourceCode(filename: string): Promise<{ status: string; filename: string; code: string; language: string }> {
    const res = await fetch(`/api/php/db_inspector.php?action=source_code&file=${filename}`);
    const data = await res.json();
    return data;
  },

  // Direct MySQL query execution for console
  async executeSqlQuery(sql: string): Promise<{
    sql: string;
    durationMs: string;
    rowCount: number;
    headers: string[];
    rows: any[];
    error?: string;
  }> {
    const res = await fetch('/api/mysql/query', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sql }),
    });
    return await res.json();
  }
};
