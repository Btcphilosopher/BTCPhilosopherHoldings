export interface User {
  id: number;
  email: string;
  salutation: string;
  first_name: string;
  last_name: string;
  phone?: string;
  preferred_boutique: string;
  client_tier: string;
  created_at?: string;
}

export interface BoutiqueAppointment {
  id: number;
  user_id?: number | null;
  guest_name: string;
  guest_email: string;
  guest_phone: string;
  boutique: string;
  service_type: string;
  appointment_date: string;
  appointment_time: string;
  special_requests?: string;
  status: 'CONFIRMED' | 'PENDING' | 'COMPLETED' | 'CANCELLED';
  created_at?: string;
  confirmation_ref?: string;
}

export interface WishlistItem {
  id: number;
  user_id?: number | null;
  session_id: string;
  item_key: string;
  item_name: string;
  leather_finish: string;
  colorway: string;
  hardware: string;
  price_eur: number;
  created_at?: string;
}

export interface ProductItem {
  id: string;
  name: string;
  subtitle: string;
  category: string;
  image: string;
  price: number;
  description: string;
  leatherOptions: string[];
  colorways: { name: string; hex: string }[];
  hardwareOptions: string[];
  dimensions?: string;
  craftTimeHours?: number;
}

export interface DbTableSummary {
  table_name: string;
  engine: string;
  approx_rows: number;
  exact_rows: number;
  data_bytes: number;
  index_bytes: number;
  created_at: string;
}

export interface DbOverview {
  database: string;
  engine: string;
  version: string;
  php_version: string;
  tables: DbTableSummary[];
  efficiency_features: string[];
}

export interface TableDetail {
  table: string;
  columns: {
    COLUMN_NAME: string;
    COLUMN_TYPE: string;
    IS_NULLABLE: string;
    COLUMN_KEY: string;
    COLUMN_DEFAULT: string | null;
    EXTRA: string;
  }[];
  indexes: {
    Table: string;
    Non_unique: number;
    Key_name: string;
    Seq_in_index: number;
    Column_name: string;
    Index_type: string;
  }[];
  rows: Record<string, any>[];
}

export interface ExplainResult {
  sql_explained: string;
  execution_plan: Record<string, any>[];
  analysis: string;
}
