/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Heritage } from './components/Heritage';
import { IconsShowcase, ICONS_PRODUCTS } from './components/IconsShowcase';
import { WorldBanner } from './components/WorldBanner';
import { Footer } from './components/Footer';
import { AppointmentModal } from './components/AppointmentModal';
import { ProductDetailModal } from './components/ProductDetailModal';
import { AccountModal } from './components/AccountModal';
import { ShoppingBagDrawer, BagItem } from './components/ShoppingBagDrawer';
import { SearchModal } from './components/SearchModal';
import { DatabaseConsole } from './components/DatabaseConsole';
import { User, ProductItem, BoutiqueAppointment } from './types';
import { api } from './services/api';
import { X, CheckCircle2, MessageSquare, Phone, Mail, Clock } from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('hermes_active_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [bagItems, setBagItems] = useState<BagItem[]>(() => {
    const saved = localStorage.getItem('hermes_bag_items');
    return saved ? JSON.parse(saved) : [];
  });

  const [selectedProduct, setSelectedProduct] = useState<ProductItem | null>(null);

  // Modals & Drawers state
  const [appointmentModalOpen, setAppointmentModalOpen] = useState(false);
  const [accountModalOpen, setAccountModalOpen] = useState(false);
  const [bagDrawerOpen, setBagDrawerOpen] = useState(false);
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [dbInspectorOpen, setDbInspectorOpen] = useState(false);
  const [customerServiceOpen, setCustomerServiceOpen] = useState(false);

  // Toast notifications
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((curr) => (curr === msg ? null : curr));
    }, 3500);
  };

  useEffect(() => {
    if (user) {
      localStorage.setItem('hermes_active_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('hermes_active_user');
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem('hermes_bag_items', JSON.stringify(bagItems));
  }, [bagItems]);

  const handleLoginSuccess = (loggedInUser: User) => {
    setUser(loggedInUser);
    showToast(`Welcome, ${loggedInUser.salutation || ''} ${loggedInUser.last_name}. Signed in via MySQL backend.`);
  };

  const handleLogout = () => {
    setUser(null);
    showToast('Signed out of Hermès Client Portal.');
  };

  const handleAddToBag = (item: { product: ProductItem; leather: string; color: string; hardware: string }) => {
    const newItemId = `${item.product.id}-${Date.now()}`;
    const newBagItem: BagItem = {
      id: newItemId,
      product: item.product,
      leather: item.leather,
      color: item.color,
      hardware: item.hardware,
      quantity: 1,
    };
    setBagItems((prev) => [...prev, newBagItem]);
    showToast(`Added ${item.product.name} to your Hermès Bag.`);
  };

  const handleRemoveFromBag = (id: string) => {
    setBagItems((prev) => prev.filter((i) => i.id !== id));
  };

  const handleAddToWishlist = async (item: {
    product: ProductItem;
    leather: string;
    color: string;
    hardware: string;
  }) => {
    try {
      const sessionId = 'session_' + (user ? user.id : 'guest_visitor');
      await api.addToWishlist({
        user_id: user?.id || null,
        session_id: sessionId,
        item_key: item.product.id,
        item_name: item.product.name,
        leather_finish: item.leather,
        colorway: item.color,
        hardware: item.hardware,
        price_eur: item.product.price,
      });
      showToast(`Saved ${item.product.name} to your MySQL Wishlist (hermes_db.client_wishlist).`);
    } catch (err: any) {
      showToast(`Wishlist error: ${err.message}`);
    }
  };

  const handleQuickWishlist = async (product: ProductItem) => {
    await handleAddToWishlist({
      product,
      leather: product.leatherOptions[0],
      color: product.colorways[0]?.name || 'Standard',
      hardware: product.hardwareOptions[0],
    });
  };

  const handleAppointmentBooked = (appt: BoutiqueAppointment) => {
    showToast(`Appointment confirmed at ${appt.boutique} for ${appt.appointment_date}.`);
  };

  const handleCategorySelect = (catId: string) => {
    if (catId === 'leather-goods' || catId === 'women' || catId === 'men') {
      const el = document.getElementById('icons');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    } else if (catId === 'world') {
      window.scrollTo({ top: document.body.scrollHeight / 2, behavior: 'smooth' });
    } else {
      setSearchModalOpen(true);
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-[#211E1C] flex flex-col font-sans selection:bg-[#E26928]/20 selection:text-[#111111]">
      {/* Toast notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#181614] text-white px-5 py-3 border border-[#3C352E] shadow-2xl rounded-xs flex items-center gap-3 text-xs animate-in fade-in slide-in-from-bottom-3 duration-300">
          <CheckCircle2 className="w-4 h-4 text-[#E26928] shrink-0" />
          <span className="font-medium">{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <Header
        user={user}
        bagCount={bagItems.length}
        onOpenSearch={() => setSearchModalOpen(true)}
        onOpenAccount={() => setAccountModalOpen(true)}
        onOpenBag={() => setBagDrawerOpen(true)}
        onOpenDbInspector={() => setDbInspectorOpen(true)}
        onSelectCategory={handleCategorySelect}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero
          onDiscoverClick={() => {
            const el = document.getElementById('icons');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          onBookAppointment={() => setAppointmentModalOpen(true)}
        />

        {/* Heritage Section ("The Art of the Hand") */}
        <Heritage />

        {/* Icons Section ("Timeless Creations") */}
        <IconsShowcase
          onSelectProduct={(p) => setSelectedProduct(p)}
          onQuickWishlist={handleQuickWishlist}
        />

        {/* World Banner ("Beyond the Atelier") */}
        <WorldBanner
          onExploreWorld={() => setAppointmentModalOpen(true)}
        />
      </main>

      {/* Footer */}
      <Footer
        onOpenDbInspector={() => setDbInspectorOpen(true)}
        onBookAppointment={() => setAppointmentModalOpen(true)}
        onOpenCustomerService={() => setCustomerServiceOpen(true)}
      />

      {/* Modals & Drawers */}
      <AppointmentModal
        isOpen={appointmentModalOpen}
        onClose={() => setAppointmentModalOpen(false)}
        user={user}
        onAppointmentBooked={handleAppointmentBooked}
      />

      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToBag={handleAddToBag}
        onAddToWishlist={handleAddToWishlist}
        onBookConsultation={() => {
          setSelectedProduct(null);
          setAppointmentModalOpen(true);
        }}
      />

      <AccountModal
        isOpen={accountModalOpen}
        onClose={() => setAccountModalOpen(false)}
        user={user}
        onLoginSuccess={handleLoginSuccess}
        onLogout={handleLogout}
        onOpenBookAppointment={() => setAppointmentModalOpen(true)}
      />

      <ShoppingBagDrawer
        isOpen={bagDrawerOpen}
        onClose={() => setBagDrawerOpen(false)}
        items={bagItems}
        onRemoveItem={handleRemoveFromBag}
        onCheckout={() => {
          setBagDrawerOpen(false);
          setAppointmentModalOpen(true);
          showToast('Our Concierge will finalize your order during your reserved appointment or private phone consultation.');
        }}
      />

      <SearchModal
        isOpen={searchModalOpen}
        onClose={() => setSearchModalOpen(false)}
        onSelectProduct={(p) => setSelectedProduct(p)}
      />

      <DatabaseConsole
        isOpen={dbInspectorOpen}
        onClose={() => setDbInspectorOpen(false)}
      />

      {/* Customer Service / Boutique Inquiries Modal */}
      {customerServiceOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-[#FAF8F5] max-w-lg w-full border border-[#DDD3C5] p-6 sm:p-8 shadow-2xl relative text-[#211E1C]">
            <button
              onClick={() => setCustomerServiceOpen(false)}
              className="absolute top-5 right-5 p-2 text-[#7A7168] hover:text-[#181614] cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
            <span className="text-[11px] font-sans tracking-[0.24em] uppercase text-[#E26928] font-medium block mb-2">
              Concierge Services
            </span>
            <h3 className="font-serif text-2xl text-[#181614] mb-3">
              Maison Hermès Customer Care
            </h3>
            <p className="text-xs text-[#5C544B] leading-relaxed mb-6 font-light">
              Our Paris ambassadors and master artisans are at your service for care recommendations,
              bespoke inquiries, and boutique private appointments.
            </p>
            <div className="space-y-3 text-xs mb-6">
              <div className="flex items-center gap-3 p-3 bg-white border border-[#E8DFD3]">
                <Phone className="w-4 h-4 text-[#E26928]" />
                <div>
                  <span className="font-medium text-[#181614] block">Direct Telephone Concierge</span>
                  <span className="text-[#7A7168] font-mono">+33 (0)1 40 17 44 33 (Monday - Saturday, 10am - 7pm CET)</span>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-white border border-[#E8DFD3]">
                <Mail className="w-4 h-4 text-[#E26928]" />
                <div>
                  <span className="font-medium text-[#181614] block">Private Client Correspondence</span>
                  <span className="text-[#7A7168]">contact.paris@hermes.com</span>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-white border border-[#E8DFD3]">
                <Clock className="w-4 h-4 text-[#E26928]" />
                <div>
                  <span className="font-medium text-[#181614] block">Artisan Restoration &amp; Spa</span>
                  <span className="text-[#7A7168]">Leather spa inspection available at all global flagships</span>
                </div>
              </div>
            </div>
            <div className="flex justify-between items-center pt-4 border-t border-[#E8DFD3]">
              <button
                onClick={() => {
                  setCustomerServiceOpen(false);
                  setAppointmentModalOpen(true);
                }}
                className="text-xs text-[#E26928] hover:underline font-medium cursor-pointer"
              >
                Schedule an in-store appointment →
              </button>
              <button
                onClick={() => setCustomerServiceOpen(false)}
                className="px-5 py-2 bg-[#181614] text-white text-xs uppercase tracking-widest hover:bg-[#E26928] transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
