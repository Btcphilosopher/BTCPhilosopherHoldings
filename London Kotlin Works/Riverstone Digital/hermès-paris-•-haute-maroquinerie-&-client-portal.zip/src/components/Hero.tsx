import React, { useState } from 'react';
import { ArrowRight, ChevronRight, ChevronLeft } from 'lucide-react';

interface HeroProps {
  onDiscoverClick: () => void;
  onBookAppointment: () => void;
}

interface Slide {
  id: number;
  kicker: string;
  title: string;
  subtitle: string;
  buttonText: string;
  image: string;
}

export const Hero: React.FC<HeroProps> = ({ onDiscoverClick, onBookAppointment }) => {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);

  const slides: Slide[] = [
    {
      id: 1,
      kicker: 'SINCE 1837',
      title: 'A Legacy\nof Craftsmanship',
      subtitle: 'Exceptional objects for a more beautiful tomorrow.',
      buttonText: 'DISCOVER THE COLLECTIONS',
      image: '/assets/hermes/hero_full.jpg',
    },
    {
      id: 2,
      kicker: 'HAUTE MAROQUINERIE',
      title: 'The Kelly\nGeometry & Grace',
      subtitle: 'Purity of line, trapezoid silhouette, and timeless elegance.',
      buttonText: 'EXPLORE THE KELLY',
      image: '/assets/hermes/hero_full.jpg',
    },
    {
      id: 3,
      kicker: 'METIERS D’ART',
      title: 'Silk Carre\nPoetry in Motion',
      subtitle: 'A vibrant symphony of pigments hand-rolled by Lyon artisans.',
      buttonText: 'VIEW SILK CREATIONS',
      image: '/assets/hermes/hero_full.jpg',
    },
    {
      id: 4,
      kicker: 'EQUESTRIAN ROOTS',
      title: 'Mastery of Saddle\n& Waxed Thread',
      subtitle: 'Two needles, one thread, and the inimitable saddle stitch.',
      buttonText: 'BOOK A CONSULTATION',
      image: '/assets/hermes/hero_full.jpg',
    },
  ];

  const current = slides[currentSlideIndex];

  const nextSlide = () => {
    setCurrentSlideIndex((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlideIndex((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const handleCtaClick = () => {
    if (currentSlideIndex === 3) {
      onBookAppointment();
    } else {
      onDiscoverClick();
    }
  };

  return (
    <section className="relative w-full min-h-[580px] lg:min-h-[720px] bg-[#161412] flex items-center overflow-hidden">
      {/* Background Image Container */}
      <div className="absolute inset-0 z-0">
        <img
          src={current.image}
          alt="Hermès Craftsmanship and Birkin Bag"
          className="w-full h-full object-cover object-top sm:object-center brightness-[0.92] contrast-[1.02] transition-opacity duration-700"
          referrerPolicy="no-referrer"
        />
        {/* Measured Luxury Scrim: Ensures WCAG AA contrast for text */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/65 via-black/35 to-black/15" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-black/20" />
      </div>

      {/* Content Container */}
      <div className="relative z-10 max-w-[1500px] w-full mx-auto px-6 sm:px-12 lg:px-16 py-16 sm:py-24 flex flex-col justify-between">
        <div className="max-w-xl text-white pt-8 sm:pt-12">
          {/* Spaced Kicker */}
          <p className="text-[11px] sm:text-[12px] font-sans tracking-[0.28em] uppercase text-[#E5DCD0]/90 mb-4 sm:mb-6 font-medium">
            {current.kicker}
          </p>

          {/* Luxury Serif Headline */}
          <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-normal leading-[1.12] tracking-tight mb-5 sm:mb-6 whitespace-pre-line text-balance text-[#FFFDFB]">
            {current.title}
          </h1>

          {/* Subtitle */}
          <p className="text-base sm:text-lg text-[#E8DFD3]/90 font-light leading-relaxed mb-8 sm:mb-10 max-w-md">
            {current.subtitle}
          </p>

          {/* CTA Button matching the outline button from the screenshot */}
          <div>
            <button
              onClick={handleCtaClick}
              className="group inline-flex items-center gap-3 px-6 py-3.5 border border-white/80 hover:border-white text-white text-xs sm:text-[13px] font-medium tracking-[0.16em] uppercase transition-all duration-200 bg-black/15 hover:bg-white hover:text-[#181614] backdrop-blur-xs cursor-pointer"
            >
              <span>{current.buttonText}</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>
          </div>
        </div>

        {/* Bottom Slide Pagination Controls matching screenshot */}
        <div className="pt-16 sm:pt-24 flex items-center justify-between sm:justify-end gap-6 text-white text-xs tracking-widest font-mono">
          {/* Dash Indicators */}
          <div className="flex items-center gap-2">
            {slides.map((s, idx) => (
              <button
                key={s.id}
                onClick={() => setCurrentSlideIndex(idx)}
                className={`h-[2px] transition-all duration-300 cursor-pointer ${
                  currentSlideIndex === idx
                    ? 'w-8 bg-white'
                    : 'w-4 bg-white/40 hover:bg-white/70'
                }`}
                aria-label={`Go to slide ${idx + 1}`}
              />
            ))}
          </div>

          {/* Numerical Pagination & Arrow: '01 / 04 →' */}
          <div className="flex items-center gap-3 tabular-nums select-none">
            <span className="text-sm font-sans tracking-widest font-light text-white">
              0{currentSlideIndex + 1} / 0{slides.length}
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={prevSlide}
                className="p-1 hover:text-[#E26928] transition-colors cursor-pointer"
                aria-label="Previous slide"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={nextSlide}
                className="p-1 hover:text-[#E26928] transition-colors cursor-pointer"
                aria-label="Next slide"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
