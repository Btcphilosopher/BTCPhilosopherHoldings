import React from 'react';
import { X, Trash2, ArrowRight, ShieldCheck, ShoppingBag } from 'lucide-react';
import { ProductItem } from '../types';

export interface BagItem {
  id: string;
  product: ProductItem;
  leather: string;
  color: string;
  hardware: string;
  quantity: number;
}

interface ShoppingBagDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: BagItem[];
  onRemoveItem: (id: string) => void;
  onCheckout: () => void;
}

export const ShoppingBagDrawer: React.FC<ShoppingBagDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onRemoveItem,
  onCheckout,
}) => {
  if (!isOpen) return null;

  const total = items.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-xs" onClick={onClose} />

      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#FAF8F5] border-l border-[#DDD3C5] shadow-2xl flex flex-col justify-between text-[#211E1C]">
          {/* Header */}
          <div className="p-6 border-b border-[#E8DFD3] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-[#181614]" />
              <h3 className="font-serif text-xl text-[#181614]">
                Your Hermès Bag ({items.length})
              </h3>
            </div>
            <button
              onClick={onClose}
              className="p-1 text-[#7A7168] hover:text-[#181614] cursor-pointer"
              aria-label="Close bag drawer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Items list */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {items.length === 0 ? (
              <div className="text-center py-16 text-[#7A7168]">
                <ShoppingBag className="w-10 h-10 mx-auto stroke-1 opacity-40 mb-3" />
                <p className="font-serif text-lg text-[#181614] mb-1">Your bag is empty</p>
                <p className="text-xs text-[#7A7168] max-w-xs mx-auto">
                  Explore our Haute Maroquinerie, Silk Carré, and Horlogerie collections.
                </p>
              </div>
            ) : (
              items.map((item) => (
                <div key={item.id} className="flex gap-4 pb-5 border-b border-[#EFE7DE]">
                  <div className="w-20 h-20 bg-[#EAE2D5] border border-[#EDE4D8] shrink-0 overflow-hidden">
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="flex-1 text-xs">
                    <div className="flex justify-between items-start mb-1">
                      <h4 className="font-sans font-semibold text-sm text-[#181614]">
                        {item.product.name}
                      </h4>
                      <button
                        onClick={() => onRemoveItem(item.id)}
                        className="text-[#998E82] hover:text-red-700 transition-colors p-0.5 cursor-pointer"
                        title="Remove item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <p className="text-[11px] text-[#7A7168] mb-0.5">
                      Leather: <span className="text-[#3E3832] font-medium">{item.leather}</span>
                    </p>
                    <p className="text-[11px] text-[#7A7168] mb-0.5">
                      Color: <span className="text-[#3E3832] font-medium">{item.color}</span>
                    </p>
                    <p className="text-[11px] text-[#7A7168] mb-2">
                      Hardware: <span className="text-[#3E3832] font-medium">{item.hardware}</span>
                    </p>

                    <div className="flex justify-between items-center pt-1">
                      <span className="text-[11px] text-[#8A7E72]">Qty: {item.quantity}</span>
                      <span className="font-medium text-sm text-[#181614] tabular-nums">
                        €{(item.product.price * item.quantity).toLocaleString('fr-FR', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer & Checkout Module */}
          {items.length > 0 && (
            <div className="p-6 bg-white border-t border-[#E8DFD3] space-y-4">
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between text-[#7A7168]">
                  <span>Subtotal</span>
                  <span className="tabular-nums font-medium text-[#181614]">
                    €{total.toLocaleString('fr-FR', { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="flex justify-between text-[#7A7168]">
                  <span>White-Glove Courier Delivery</span>
                  <span className="text-[#2E7D32] font-medium">Complimentary</span>
                </div>
                <div className="flex justify-between text-[#7A7168]">
                  <span>Signature Hermès Orange Box Packaging</span>
                  <span className="text-[#2E7D32] font-medium">Included</span>
                </div>
                <div className="flex justify-between text-sm font-semibold text-[#181614] pt-2 border-t border-[#EFE7DE]">
                  <span>Total</span>
                  <span className="tabular-nums text-base">
                    €{total.toLocaleString('fr-FR', { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              <button
                onClick={onCheckout}
                className="w-full flex items-center justify-center gap-2 py-3.5 bg-[#181614] text-white text-xs uppercase tracking-widest hover:bg-[#E26928] transition-colors cursor-pointer"
              >
                <span>Complete Concierge Order</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-center gap-2 text-[11px] text-[#7A7168]">
                <ShieldCheck className="w-3.5 h-3.5 text-[#2E7D32]" />
                <span>Authentic Hermès Atelier Warranty · Paris</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
