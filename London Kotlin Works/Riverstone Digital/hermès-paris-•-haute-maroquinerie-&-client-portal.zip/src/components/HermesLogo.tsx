import React from 'react';

interface HermesLogoProps {
  className?: string;
  theme?: 'dark' | 'light';
  size?: 'sm' | 'md' | 'lg';
}

export const HermesLogo: React.FC<HermesLogoProps> = ({
  className = '',
  theme = 'dark',
  size = 'md',
}) => {
  const isLight = theme === 'light';
  const textColor = isLight ? '#FFFFFF' : '#181614';
  const emblemColor = isLight ? '#FFFFFF' : '#181614';

  const scale = size === 'sm' ? 0.8 : size === 'lg' ? 1.3 : 1;

  return (
    <div className={`flex flex-col items-center justify-center select-none text-center ${className}`}>
      {/* Authentic Hermès Duc Carriage & Horse Silhouette */}
      <svg
        width={56 * scale}
        height={32 * scale}
        viewBox="0 0 120 70"
        fill={emblemColor}
        className="transition-colors duration-200"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
      >
        {/* Ground shadow hairline */}
        <path d="M5 64 Q60 67 115 64 Q60 65 5 64" fill={emblemColor} opacity="0.6" />

        {/* Carriage Chassis & Body */}
        <path d="M8 32 C12 28 20 28 24 30 C27 24 35 24 40 30 C43 32 44 38 43 45 C41 52 32 54 25 54 C16 54 8 48 8 38 Z" />
        {/* Carriage Hood Fold */}
        <path d="M12 28 C16 18 28 17 34 22 C36 24 35 28 32 29 C26 23 18 24 14 30 Z" />

        {/* Rear Wheel (large carriage spoke wheel) */}
        <circle cx="20" cy="50" r="14" stroke={emblemColor} strokeWidth="2.5" fill="none" />
        <circle cx="20" cy="50" r="3" fill={emblemColor} />
        {/* Spokes */}
        <line x1="20" y1="36" x2="20" y2="64" stroke={emblemColor} strokeWidth="1.2" />
        <line x1="6" y1="50" x2="34" y2="50" stroke={emblemColor} strokeWidth="1.2" />
        <line x1="10" y1="40" x2="30" y2="60" stroke={emblemColor} strokeWidth="1.2" />
        <line x1="10" y1="60" x2="30" y2="40" stroke={emblemColor} strokeWidth="1.2" />

        {/* Front Wheel (smaller) */}
        <circle cx="48" cy="53" r="10.5" stroke={emblemColor} strokeWidth="2.2" fill="none" />
        <circle cx="48" cy="53" r="2.5" fill={emblemColor} />
        <line x1="48" y1="42.5" x2="48" y2="63.5" stroke={emblemColor} strokeWidth="1" />
        <line x1="37.5" y1="53" x2="58.5" y2="53" stroke={emblemColor} strokeWidth="1" />
        <line x1="41" y1="46" x2="55" y2="60" stroke={emblemColor} strokeWidth="1" />
        <line x1="41" y1="60" x2="55" y2="46" stroke={emblemColor} strokeWidth="1" />

        {/* Carriage Shaft / Pole leading to Horse */}
        <path d="M42 48 L80 43" stroke={emblemColor} strokeWidth="2" strokeLinecap="round" />
        <path d="M30 46 L45 46" stroke={emblemColor} strokeWidth="2" />

        {/* Noble Thoroughbred Horse Silhouette */}
        {/* Horse Body, Neck, Head & Legs */}
        <path d="M72 40 C72 35 76 30 84 31 C89 25 93 18 97 12 C98 10 101 10 102 12 C101 15 99 20 102 21 C104 22 106 20 106 23 C105 27 101 28 97 32 C97 36 98 42 97 45 C94 48 88 47 84 46 C80 47 75 45 72 40 Z" />
        {/* Horse Legs */}
        {/* Front Legs */}
        <path d="M96 44 L98 62 L101 62 L100 45" />
        <path d="M92 45 L94 60 L96 60 L94 45" />
        {/* Hind Legs */}
        <path d="M75 41 C76 46 74 52 75 62 L78 62 C78 54 81 48 80 43 Z" />
        <path d="M80 43 L83 60 L85 60 L84 45" />
        {/* Horse Mane and Tail */}
        <path d="M94 15 C91 22 89 28 89 31 C87 31 87 28 92 18 Z" />
        <path d="M72 38 C68 44 67 52 69 57 C71 52 71 45 74 39 Z" />

        {/* Attendant / Groom Silhouette standing at horse's head */}
        <circle cx="109" cy="22" r="3" /> {/* Hat / Head */}
        <path d="M107 26 C105 32 106 44 107 50 C108 53 109 61 110 62 L112 62 C111 58 111 48 112 40 C114 36 114 28 110 26 Z" />
        <path d="M106 31 L102 24" stroke={emblemColor} strokeWidth="1.2" strokeLinecap="round" /> {/* Hand holding bridle */}
      </svg>

      {/* Brand Typography */}
      <div className="mt-1 flex flex-col items-center">
        <span
          className="font-serif tracking-[0.26em] text-lg sm:text-xl font-medium uppercase leading-tight"
          style={{ color: textColor }}
        >
          Hermès
        </span>
        <span
          className="text-[9px] sm:text-[10px] font-sans tracking-[0.34em] font-normal uppercase mt-0.5"
          style={{ color: textColor, opacity: 0.85 }}
        >
          Paris
        </span>
      </div>
    </div>
  );
};
