import React, { useState, useEffect } from 'react';
import { Search, User as UserIcon, ShoppingBag, Database, ChevronRight, Menu, X } from 'lucide-react';
import { HermesLogo } from './HermesLogo';
import { User } from '../types';

interface HeaderProps {
  user: User | null;
  bagCount: number;
  onOpenSearch: () => void;
  onOpenAccount: () => void;
  onOpenBag: () => void;
  onOpenDbInspector: () => void;
  onSelectCategory: (cat: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  bagCount,
  onOpenSearch,
  onOpenAccount,
  onOpenBag,
  onOpenDbInspector,
  onSelectCategory,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navCategories = [
    { label: 'Women', id: 'women' },
    { label: 'Men', id: 'men' },
    { label: 'Leather Goods', id: 'leather-goods' },
    { label: 'Home', id: 'home' },
    { label: 'The World of Hermès', id: 'world' },
  ];

  return (
    <>
      {/* Top Architecture & Backend Status Bar */}
      <div className="w-full bg-[#181614] text-[#E5DCD0] text-[11px] font-sans tracking-wide py-1 px-4 sm:px-8 border-b border-[#2C2723] flex items-center justify-between transition-colors">
        <div className="flex items-center gap-3 truncate">
          <span className="text-[#E26928] font-medium tracking-widest uppercase text-[10px]">Atelier Engine</span>
          <span className="text-[#8E867E] hidden sm:inline">·</span>
          <span className="text-[#C7BCAD] hidden sm:inline">PHP 8.2 &amp; MySQL 10.11 InnoDB Backend</span>
          <span className="text-[#8E867E] hidden md:inline">·</span>
          <span className="text-[#A29789] hidden md:inline">High-Efficiency B-Tree Indexed Persistence</span>
        </div>
        <button
          onClick={onOpenDbInspector}
          className="flex items-center gap-1.5 text-[#E5DCD0] hover:text-[#E26928] transition-colors py-0.5 px-2 rounded text-[11px] font-medium shrink-0 cursor-pointer"
          title="Open MySQL Database & PHP Architecture Inspector"
        >
          <Database className="w-3.5 h-3.5 text-[#E26928]" />
          <span>Inspect Architecture &amp; DB</span>
          <ChevronRight className="w-3 h-3 opacity-60" />
        </button>
      </div>

      {/* Main Luxury Header */}
      <header
        className={`sticky top-0 z-40 w-full transition-all duration-300 ${
          isScrolled
            ? 'bg-[#FAF8F5]/95 backdrop-blur-md text-[#181614] border-b border-[#E8DFD3] shadow-xs'
            : 'bg-gradient-to-b from-black/60 via-black/30 to-transparent text-white'
        }`}
      >
        <div className="max-w-[1500px] mx-auto px-4 sm:px-8 py-3.5 sm:py-4 flex items-center justify-between">
          {/* Mobile hamburger */}
          <div className="flex items-center lg:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-1.5 focus-visible:outline-hidden"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

          {/* Left Zone: Category Navigation */}
          <nav className="hidden lg:flex items-center gap-6 xl:gap-8 text-[13px] font-normal tracking-[0.04em]">
            {navCategories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className={`transition-colors py-1 cursor-pointer whitespace-nowrap ${
                  isScrolled
                    ? 'text-[#2B2724] hover:text-[#E26928]'
                    : 'text-[#F5EFEB] hover:text-white'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </nav>

          {/* Center Zone: Iconic Hermès Logo */}
          <div className="flex justify-center flex-1 lg:flex-none">
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="group focus-visible:outline-hidden block cursor-pointer"
            >
              <HermesLogo theme={isScrolled ? 'dark' : 'light'} size="md" />
            </a>
          </div>

          {/* Right Zone: Search, Account, Bag */}
          <div className="flex items-center gap-5 sm:gap-7 text-[13px] font-normal tracking-[0.03em]">
            {/* Search */}
            <button
              onClick={onOpenSearch}
              className={`flex items-center gap-2 transition-colors py-1 cursor-pointer whitespace-nowrap ${
                isScrolled ? 'text-[#2B2724] hover:text-[#E26928]' : 'text-[#F5EFEB] hover:text-white'
              }`}
            >
              <Search className="w-4 h-4" />
              <span className="hidden sm:inline">Search</span>
            </button>

            {/* Account */}
            <button
              onClick={onOpenAccount}
              className={`flex items-center gap-2 transition-colors py-1 cursor-pointer whitespace-nowrap ${
                isScrolled ? 'text-[#2B2724] hover:text-[#E26928]' : 'text-[#F5EFEB] hover:text-white'
              }`}
            >
              <UserIcon className="w-4 h-4" />
              <span className="hidden sm:inline">
                {user ? `${user.salutation ? user.salutation + ' ' : ''}${user.last_name}` : 'Account'}
              </span>
            </button>

            {/* Shopping Bag */}
            <button
              onClick={onOpenBag}
              className={`flex items-center gap-2 transition-colors py-1 cursor-pointer whitespace-nowrap relative ${
                isScrolled ? 'text-[#2B2724] hover:text-[#E26928]' : 'text-[#F5EFEB] hover:text-white'
              }`}
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Bag ({bagCount})</span>
            </button>
          </div>
        </div>

        {/* Mobile slide-down menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#FAF8F5] text-[#181614] border-b border-[#E8DFD3] px-6 py-6 space-y-4">
            <div className="space-y-3">
              {navCategories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => {
                    onSelectCategory(cat.id);
                    setMobileMenuOpen(false);
                  }}
                  className="block w-full text-left py-2 text-base font-serif text-[#2B2724] hover:text-[#E26928] border-b border-[#EFE7DE]"
                >
                  {cat.label}
                </button>
              ))}
            </div>
            <div className="pt-2 flex flex-col gap-2">
              <button
                onClick={() => {
                  onOpenDbInspector();
                  setMobileMenuOpen(false);
                }}
                className="w-full flex items-center justify-between text-xs py-2.5 px-3 bg-[#181614] text-[#FAF8F5] rounded"
              >
                <span className="flex items-center gap-2">
                  <Database className="w-4 h-4 text-[#E26928]" />
                  MySQL &amp; PHP Architecture Console
                </span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
