import React, { useState } from 'react';
import { ArrowRight, CheckCircle2, Instagram, Facebook, Youtube, Compass, Database } from 'lucide-react';
import { HermesLogo } from './HermesLogo';
import { api } from '../services/api';

interface FooterProps {
  onOpenDbInspector: () => void;
  onBookAppointment: () => void;
  onOpenCustomerService: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onOpenDbInspector,
  onBookAppointment,
  onOpenCustomerService,
}) => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribing, setSubscribing] = useState(false);
  const [subscribeSuccess, setSubscribeSuccess] = useState(false);
  const [subscribeMessage, setSubscribeMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail || !newsletterEmail.includes('@')) {
      setErrorMessage('Please enter a valid email address.');
      return;
    }
    setSubscribing(true);
    setErrorMessage('');
    try {
      const res = await api.subscribeNewsletter(newsletterEmail);
      setSubscribeSuccess(true);
      setSubscribeMessage(res.message || 'Subscribed successfully.');
      setNewsletterEmail('');
    } catch (err: any) {
      setErrorMessage(err.message || 'Subscription failed');
    } finally {
      setSubscribing(false);
    }
  };

  return (
    <footer className="w-full bg-[#FAF8F5] border-t border-[#E8DFD3] pt-14 pb-12 text-[#211E1C]">
      <div className="max-w-[1500px] mx-auto px-6 sm:px-12 lg:px-16">
        {/* Main Footer Row matching the screenshot */}
        <div className="flex flex-col lg:flex-row items-center lg:items-center justify-between gap-10 pb-12 border-b border-[#E8DFD3]">
          {/* Left: Hermès Paris Logo */}
          <div className="flex flex-col items-center lg:items-start shrink-0">
            <HermesLogo theme="dark" size="sm" />
          </div>

          {/* Center Links: Customer Service, Boutiques, Sustainability, News */}
          <nav className="flex flex-wrap items-center justify-center gap-6 sm:gap-10 text-xs sm:text-[13px] tracking-[0.05em] text-[#3E3832]">
            <button
              onClick={onOpenCustomerService}
              className="hover:text-[#E26928] transition-colors cursor-pointer"
            >
              Customer Service
            </button>
            <button
              onClick={onBookAppointment}
              className="hover:text-[#E26928] transition-colors cursor-pointer"
            >
              Boutiques &amp; Appointments
            </button>
            <button
              onClick={onOpenCustomerService}
              className="hover:text-[#E26928] transition-colors cursor-pointer"
            >
              Sustainability
            </button>
            <button
              onClick={onOpenCustomerService}
              className="hover:text-[#E26928] transition-colors cursor-pointer"
            >
              News &amp; Events
            </button>
          </nav>

          {/* Right: Join our newsletter + Social icons */}
          <div className="flex flex-col sm:flex-row items-center gap-8 w-full lg:w-auto justify-end">
            {/* Newsletter input form */}
            <form onSubmit={handleSubscribe} className="relative w-full max-w-xs">
              {subscribeSuccess ? (
                <div className="flex items-center gap-2 text-xs text-[#2E7D32] py-2">
                  <CheckCircle2 className="w-4 h-4 text-[#2E7D32]" />
                  <span>Subscribed to MySQL (Hermès Publications)</span>
                </div>
              ) : (
                <div className="relative">
                  <input
                    type="email"
                    value={newsletterEmail}
                    onChange={(e) => {
                      setNewsletterEmail(e.target.value);
                      if (errorMessage) setErrorMessage('');
                    }}
                    placeholder="Join our newsletter"
                    disabled={subscribing}
                    className="w-full bg-transparent border-b border-[#181614] pb-1.5 pr-8 text-xs placeholder:text-[#7A7168] focus:outline-hidden focus:border-[#E26928] transition-colors"
                  />
                  <button
                    type="submit"
                    disabled={subscribing}
                    className="absolute right-0 bottom-2 text-[#181614] hover:text-[#E26928] transition-colors cursor-pointer disabled:opacity-50"
                    aria-label="Submit newsletter subscription"
                  >
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  {errorMessage && (
                    <p className="text-[11px] text-red-600 mt-1 absolute -bottom-5 left-0">
                      {errorMessage}
                    </p>
                  )}
                </div>
              )}
            </form>

            {/* Social Icons matching screenshot */}
            <div className="flex items-center gap-4 text-[#3E3832]">
              <a
                href="https://www.instagram.com"
                target="_blank"
                rel="noreferrer"
                className="hover:text-[#E26928] transition-colors"
                aria-label="Hermès Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://www.facebook.com"
                target="_blank"
                rel="noreferrer"
                className="hover:text-[#E26928] transition-colors"
                aria-label="Hermès Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="https://www.youtube.com"
                target="_blank"
                rel="noreferrer"
                className="hover:text-[#E26928] transition-colors"
                aria-label="Hermès YouTube"
              >
                <Youtube className="w-4 h-4" />
              </a>
              <a
                href="https://www.pinterest.com"
                target="_blank"
                rel="noreferrer"
                className="hover:text-[#E26928] transition-colors"
                aria-label="Hermès Pinterest"
              >
                <Compass className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Technical & Copyright Row */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-[11px] text-[#7A7168] gap-4">
          <p>© 2026 Hermès Paris. All rights reserved. Maison fondée en 1837.</p>
          <div className="flex items-center gap-4">
            <button
              onClick={onOpenDbInspector}
              className="flex items-center gap-1.5 text-[#181614] hover:text-[#E26928] transition-colors font-medium cursor-pointer"
            >
              <Database className="w-3.5 h-3.5 text-[#E26928]" />
              <span>Inspect MySQL Data Architecture &amp; PHP 8.2 Engine</span>
            </button>
            <span>·</span>
            <span>24, rue du Faubourg Saint-Honoré, 75008 Paris</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
