import React, { useState, useEffect } from 'react';
import { X, User as UserIcon, ShieldCheck, Calendar, Heart, LogOut, CheckCircle2, Lock } from 'lucide-react';
import { User, BoutiqueAppointment, WishlistItem } from '../types';
import { api } from '../services/api';
import { BOUTIQUES } from './AppointmentModal';

interface AccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
  onLoginSuccess: (user: User) => void;
  onLogout: () => void;
  onOpenBookAppointment: () => void;
}

export const AccountModal: React.FC<AccountModalProps> = ({
  isOpen,
  onClose,
  user,
  onLoginSuccess,
  onLogout,
  onOpenBookAppointment,
}) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('claire.devalmont@elysee.fr');
  const [password, setPassword] = useState('hermes1837');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [salutation, setSalutation] = useState('Madame');
  const [phone, setPhone] = useState('');
  const [preferredBoutique, setPreferredBoutique] = useState(BOUTIQUES[0].name);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [appointments, setAppointments] = useState<BoutiqueAppointment[]>([]);
  const [loadingAppts, setLoadingAppts] = useState(false);

  useEffect(() => {
    if (user && isOpen) {
      setLoadingAppts(true);
      api.listAppointments(user.email, user.id)
        .then(setAppointments)
        .catch(console.error)
        .finally(() => setLoadingAppts(false));
    }
  }, [user, isOpen]);

  if (!isOpen) return null;

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (mode === 'login') {
        const res = await api.login(email, password);
        onLoginSuccess(res.user);
      } else {
        const res = await api.register({
          email,
          password,
          salutation,
          first_name: firstName,
          last_name: lastName,
          phone,
          preferred_boutique: preferredBoutique,
        });
        onLoginSuccess(res.user);
      }
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-[#FAF8F5] max-w-xl w-full border border-[#DDD3C5] shadow-2xl relative text-[#211E1C] max-h-[92vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-[#7A7168] hover:text-[#181614] cursor-pointer"
          aria-label="Close client portal"
        >
          <X className="w-5 h-5" />
        </button>

        {user ? (
          /* Client Profile Dashboard */
          <div className="p-6 sm:p-10">
            <div className="flex items-center justify-between pb-6 border-b border-[#E8DFD3] mb-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-[#181614] text-white flex items-center justify-center text-lg font-serif">
                  {user.first_name[0]}{user.last_name[0]}
                </div>
                <div>
                  <h3 className="font-serif text-2xl text-[#181614]">
                    {user.salutation ? user.salutation + ' ' : ''}{user.first_name} {user.last_name}
                  </h3>
                  <div className="flex items-center gap-2 text-xs text-[#7A7168]">
                    <span>{user.email}</span>
                    <span>·</span>
                    <span className="text-[#E26928] font-medium">{user.client_tier}</span>
                  </div>
                </div>
              </div>

              <button
                onClick={onLogout}
                className="text-xs text-[#7A7168] hover:text-red-700 flex items-center gap-1 cursor-pointer"
                title="Log out"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Logout</span>
              </button>
            </div>

            {/* Profile Information Summary */}
            <div className="bg-white p-4 border border-[#E8DFD3] text-xs space-y-2 mb-6">
              <div className="flex justify-between">
                <span className="text-[#7A7168]">Preferred Maison</span>
                <span className="font-medium text-[#181614]">{user.preferred_boutique}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#7A7168]">Database Record</span>
                <span className="font-mono text-[#181614]">hermes_db.users (ID: #{user.id})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#7A7168]">Storage Security</span>
                <span className="text-[#2E7D32] font-medium">B-Tree Unique Index · BCrypt Hashed</span>
              </div>
            </div>

            {/* Client Appointments List */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-[#3E3832]">
                  Your Boutique Reservations ({appointments.length})
                </h4>
                <button
                  onClick={() => {
                    onClose();
                    onOpenBookAppointment();
                  }}
                  className="text-xs text-[#E26928] hover:underline font-medium cursor-pointer"
                >
                  + Book New
                </button>
              </div>

              {loadingAppts ? (
                <p className="text-xs text-[#7A7168] py-4">Loading appointments from MySQL...</p>
              ) : appointments.length === 0 ? (
                <div className="text-center py-6 bg-white border border-[#EDE6DC]">
                  <p className="text-xs text-[#7A7168] mb-2">No active boutique appointments.</p>
                  <button
                    onClick={() => {
                      onClose();
                      onOpenBookAppointment();
                    }}
                    className="text-xs font-medium text-[#181614] hover:text-[#E26928] underline cursor-pointer"
                  >
                    Schedule a private viewing
                  </button>
                </div>
              ) : (
                <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
                  {appointments.map((appt) => (
                    <div
                      key={appt.id}
                      className="p-3 bg-white border border-[#E8DFD3] text-xs flex items-center justify-between"
                    >
                      <div>
                        <p className="font-medium text-[#181614]">{appt.service_type}</p>
                        <p className="text-[#7A7168] text-[11px]">{appt.boutique}</p>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] bg-[#EAE2D5] px-2 py-0.5 rounded-xs font-mono block mb-1">
                          {appt.appointment_date} · {appt.appointment_time}
                        </span>
                        <span className="text-[10px] text-[#2E7D32] font-medium">{appt.status}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-[#E8DFD3] flex justify-end">
              <button
                onClick={onClose}
                className="px-6 py-2.5 bg-[#181614] text-white text-xs uppercase tracking-widest hover:bg-[#E26928] transition-colors cursor-pointer"
              >
                Close Portal
              </button>
            </div>
          </div>
        ) : (
          /* Login / Register Form */
          <form onSubmit={handleAuth} className="p-6 sm:p-10">
            <div className="mb-6">
              <span className="text-[11px] tracking-[0.24em] uppercase text-[#E26928] font-medium block mb-1.5">
                Client Portal · Maison Hermès
              </span>
              <h3 className="font-serif text-2xl sm:text-3xl text-[#181614] mb-2">
                {mode === 'login' ? 'Sign In to Your Account' : 'Create an Hermès Client Profile'}
              </h3>
              <p className="text-xs sm:text-sm text-[#696055] font-light">
                {mode === 'login'
                  ? 'Access your private boutique appointments, bespoke wishlist, and concierge inquiries.'
                  : 'Register your details to enjoy bespoke private salon appointments and atelier updates.'}
              </p>
            </div>

            {error && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded">
                {error}
              </div>
            )}

            {mode === 'login' && (
              <div className="mb-4 p-3 bg-[#F0EBE1] border border-[#DDD3C5] text-[11px] text-[#5C544B] space-y-1">
                <span className="font-semibold block text-[#181614]">Demonstration Client Account:</span>
                <div>Email: <code className="font-mono text-[#181614]">claire.devalmont@elysee.fr</code></div>
                <div>Password: <code className="font-mono text-[#181614]">hermes1837</code></div>
              </div>
            )}

            <div className="space-y-4 text-xs">
              {mode === 'register' && (
                <>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[#4A433B] font-medium mb-1">Salutation</label>
                      <select
                        value={salutation}
                        onChange={(e) => setSalutation(e.target.value)}
                        className="w-full bg-white border border-[#DDD3C5] px-3 py-2 text-xs text-[#181614]"
                      >
                        <option value="Madame">Madame</option>
                        <option value="Monsieur">Monsieur</option>
                        <option value="Dr.">Dr.</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[#4A433B] font-medium mb-1">First Name *</label>
                      <input
                        type="text"
                        required
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        placeholder="Claire"
                        className="w-full bg-white border border-[#DDD3C5] px-3 py-2 text-xs text-[#181614]"
                      />
                    </div>
                    <div>
                      <label className="block text-[#4A433B] font-medium mb-1">Last Name *</label>
                      <input
                        type="text"
                        required
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        placeholder="de Valmont"
                        className="w-full bg-white border border-[#DDD3C5] px-3 py-2 text-xs text-[#181614]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[#4A433B] font-medium mb-1">Telephone</label>
                      <input
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="+33 6 42 18 37 00"
                        className="w-full bg-white border border-[#DDD3C5] px-3 py-2 text-xs text-[#181614]"
                      />
                    </div>
                    <div>
                      <label className="block text-[#4A433B] font-medium mb-1">Preferred Boutique</label>
                      <select
                        value={preferredBoutique}
                        onChange={(e) => setPreferredBoutique(e.target.value)}
                        className="w-full bg-white border border-[#DDD3C5] px-3 py-2 text-xs text-[#181614]"
                      >
                        {BOUTIQUES.map((b) => (
                          <option key={b.id} value={b.name}>
                            {b.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </>
              )}

              <div>
                <label className="block text-[#4A433B] font-medium mb-1">Email Address *</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="client@hermes.paris"
                  className="w-full bg-white border border-[#DDD3C5] px-3 py-2 text-xs text-[#181614]"
                />
              </div>

              <div>
                <label className="block text-[#4A433B] font-medium mb-1">Password *</label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-white border border-[#DDD3C5] px-3 py-2 text-xs text-[#181614]"
                />
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-[#E8DFD3] flex items-center justify-between">
              <button
                type="button"
                onClick={() => {
                  setError('');
                  setMode(mode === 'login' ? 'register' : 'login');
                }}
                className="text-xs text-[#696055] hover:text-[#E26928] underline cursor-pointer"
              >
                {mode === 'login' ? 'New client? Create an account' : 'Already registered? Sign in'}
              </button>

              <button
                type="submit"
                disabled={loading}
                className="px-6 py-2.5 bg-[#181614] text-white text-xs uppercase tracking-widest hover:bg-[#E26928] transition-colors cursor-pointer disabled:opacity-50"
              >
                {loading ? 'Processing with PHP...' : mode === 'login' ? 'Sign In' : 'Register Profile'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
