import React, { useState } from 'react';
import { X, Heart, ShoppingBag, Calendar, ShieldCheck, Check } from 'lucide-react';
import { ProductItem } from '../types';

interface ProductDetailModalProps {
  product: ProductItem | null;
  onClose: () => void;
  onAddToBag: (item: { product: ProductItem; leather: string; color: string; hardware: string }) => void;
  onAddToWishlist: (item: { product: ProductItem; leather: string; color: string; hardware: string }) => void;
  onBookConsultation: (product: ProductItem) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onAddToBag,
  onAddToWishlist,
  onBookConsultation,
}) => {
  if (!product) return null;

  const [selectedLeather, setSelectedLeather] = useState(product.leatherOptions[0] || '');
  const [selectedColor, setSelectedColor] = useState(product.colorways[0]?.name || '');
  const [selectedHardware, setSelectedHardware] = useState(product.hardwareOptions[0] || '');
  const [addedWishlist, setAddedWishlist] = useState(false);
  const [addedBag, setAddedBag] = useState(false);

  const handleWishlist = () => {
    onAddToWishlist({
      product,
      leather: selectedLeather,
      color: selectedColor,
      hardware: selectedHardware,
    });
    setAddedWishlist(true);
    setTimeout(() => setAddedWishlist(false), 2500);
  };

  const handleBag = () => {
    onAddToBag({
      product,
      leather: selectedLeather,
      color: selectedColor,
      hardware: selectedHardware,
    });
    setAddedBag(true);
    setTimeout(() => setAddedBag(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-[#FAF8F5] max-w-4xl w-full border border-[#DDD3C5] shadow-2xl relative text-[#211E1C] max-h-[92vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-[#7A7168] hover:text-[#181614] z-10 cursor-pointer"
          aria-label="Close product detail"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-6 sm:p-10">
          {/* Left Column: High-Res Image & Visual Details */}
          <div className="flex flex-col">
            <div className="relative aspect-[4/3] sm:aspect-square w-full bg-[#EAE2D5] overflow-hidden border border-[#EDE4D8] mb-4">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover object-center"
                referrerPolicy="no-referrer"
              />
              <span className="absolute bottom-3 left-3 bg-[#181614]/80 text-white text-[10px] tracking-widest uppercase px-2.5 py-1 backdrop-blur-xs">
                Maison Hermès Paris
              </span>
            </div>

            {/* Specifications Strip */}
            <div className="grid grid-cols-2 gap-3 text-xs bg-white p-4 border border-[#E8DFD3]">
              <div>
                <span className="text-[#8A7E72] block text-[10px] uppercase tracking-wider">Dimensions</span>
                <span className="font-medium text-[#181614]">{product.dimensions || 'Classic Proportion'}</span>
              </div>
              <div>
                <span className="text-[#8A7E72] block text-[10px] uppercase tracking-wider">Atelier Craft</span>
                <span className="font-medium text-[#181614]">{product.craftTimeHours || 20} Hours Hand-Stitched</span>
              </div>
            </div>
          </div>

          {/* Right Column: Contiguous Purchase Module */}
          <div className="flex flex-col justify-between">
            <div>
              <p className="text-[11px] font-sans tracking-[0.24em] uppercase text-[#8A7E72] mb-1.5 font-medium">
                {product.category}
              </p>
              <h2 className="font-serif text-3xl sm:text-4xl font-normal text-[#181614] mb-2">
                {product.name}
              </h2>
              <div className="flex items-center gap-3 mb-4">
                <span className="text-xl font-sans font-medium text-[#181614] tabular-nums">
                  €{product.price.toLocaleString('fr-FR', { minimumFractionDigits: 2 })}
                </span>
                <span className="text-xs text-[#7A7168]">Tax included</span>
              </div>

              <p className="text-xs sm:text-sm text-[#5C544B] leading-relaxed mb-6 font-light">
                {product.description}
              </p>

              {/* Leather selection */}
              <div className="mb-5">
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#3E3832] mb-2">
                  Leather / Material: <span className="font-normal text-[#8A7E72]">{selectedLeather}</span>
                </label>
                <div className="flex flex-wrap gap-2">
                  {product.leatherOptions.map((opt) => (
                    <button
                      key={opt}
                      onClick={() => setSelectedLeather(opt)}
                      className={`text-xs px-3 py-1.5 border transition-all cursor-pointer ${
                        selectedLeather === opt
                          ? 'border-[#181614] bg-[#181614] text-white'
                          : 'border-[#DDD3C5] bg-white text-[#4A433B] hover:border-[#181614]'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              {/* Colorway selection */}
              <div className="mb-5">
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#3E3832] mb-2">
                  Colorway: <span className="font-normal text-[#8A7E72]">{selectedColor}</span>
                </label>
                <div className="flex flex-wrap gap-2.5">
                  {product.colorways.map((c) => (
                    <button
                      key={c.name}
                      onClick={() => setSelectedColor(c.name)}
                      className={`flex items-center gap-2 text-xs px-2.5 py-1 border transition-all cursor-pointer ${
                        selectedColor === c.name
                          ? 'border-[#181614] bg-white ring-1 ring-[#181614]'
                          : 'border-[#DDD3C5] bg-white hover:border-[#8A7E72]'
                      }`}
                    >
                      <span
                        className="w-3.5 h-3.5 rounded-full border border-black/20"
                        style={{ backgroundColor: c.hex }}
                      />
                      <span>{c.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Hardware selection */}
              <div className="mb-6">
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#3E3832] mb-2">
                  Hardware &amp; Finish: <span className="font-normal text-[#8A7E72]">{selectedHardware}</span>
                </label>
                <div className="flex flex-wrap gap-2">
                  {product.hardwareOptions.map((hw) => (
                    <button
                      key={hw}
                      onClick={() => setSelectedHardware(hw)}
                      className={`text-xs px-3 py-1.5 border transition-all cursor-pointer ${
                        selectedHardware === hw
                          ? 'border-[#181614] bg-[#181614] text-white'
                          : 'border-[#DDD3C5] bg-white text-[#4A433B] hover:border-[#181614]'
                      }`}
                    >
                      {hw}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Action buttons */}
            <div className="pt-4 border-t border-[#E8DFD3] space-y-2.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <button
                  onClick={handleBag}
                  className="flex items-center justify-center gap-2 py-3 bg-[#181614] text-white text-xs uppercase tracking-widest hover:bg-[#E26928] transition-colors cursor-pointer"
                >
                  {addedBag ? <Check className="w-4 h-4 text-green-400" /> : <ShoppingBag className="w-4 h-4" />}
                  <span>{addedBag ? 'Added to Bag' : 'Add to Bag'}</span>
                </button>

                <button
                  onClick={handleWishlist}
                  className="flex items-center justify-center gap-2 py-3 border border-[#181614] text-[#181614] text-xs uppercase tracking-widest hover:bg-[#181614] hover:text-white transition-colors cursor-pointer bg-white"
                >
                  <Heart className={`w-4 h-4 ${addedWishlist ? 'fill-red-500 text-red-500' : ''}`} />
                  <span>{addedWishlist ? 'Saved in MySQL' : 'Save to Wishlist'}</span>
                </button>
              </div>

              <button
                onClick={() => {
                  onClose();
                  onBookConsultation(product);
                }}
                className="w-full flex items-center justify-center gap-2 py-2.5 text-xs text-[#5C544B] hover:text-[#E26928] border border-transparent hover:border-[#E8DFD3] transition-colors cursor-pointer font-medium"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>Book a Boutique Private Salon Viewing for this Piece</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
