import React, { useState, useEffect } from 'react';
import {
  X,
  Database,
  Server,
  Zap,
  Code2,
  Table as TableIcon,
  Play,
  RefreshCw,
  CheckCircle2,
  Cpu,
  Layers,
  ArrowRight,
} from 'lucide-react';
import { DbOverview, TableDetail, ExplainResult } from '../types';
import { api } from '../services/api';

interface DatabaseConsoleProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DatabaseConsole: React.FC<DatabaseConsoleProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'tables' | 'query' | 'php-code'>('overview');
  const [overview, setOverview] = useState<DbOverview | null>(null);
  const [selectedTable, setSelectedTable] = useState('users');
  const [tableDetail, setTableDetail] = useState<TableDetail | null>(null);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  // SQL Runner state
  const [sqlQuery, setSqlQuery] = useState("EXPLAIN SELECT id, first_name, last_name, preferred_boutique FROM users WHERE email = 'claire.devalmont@elysee.fr';");
  const [queryResult, setQueryResult] = useState<any>(null);
  const [runningQuery, setRunningQuery] = useState(false);

  // PHP Code Viewer state
  const [selectedFile, setSelectedFile] = useState('db.php');
  const [codeContent, setCodeContent] = useState('');
  const [loadingCode, setLoadingCode] = useState(false);

  const fetchOverview = async () => {
    try {
      setRefreshing(true);
      const data = await api.getDbOverview();
      setOverview(data);
    } catch (err) {
      console.error(err);
    } finally {
      setRefreshing(false);
    }
  };

  const fetchTableDetail = async (table: string) => {
    try {
      setLoading(true);
      const detail = await api.getTableDetail(table);
      setTableDetail(detail);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const fetchCode = async (file: string) => {
    try {
      setLoadingCode(true);
      const res = await api.getSourceCode(file);
      setCodeContent(res.code);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingCode(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchOverview();
      fetchTableDetail(selectedTable);
      fetchCode(selectedFile);
    }
  }, [isOpen]);

  const handleRunSql = async (queryToRun?: string) => {
    const q = queryToRun || sqlQuery;
    setRunningQuery(true);
    try {
      const res = await api.executeSqlQuery(q);
      setQueryResult(res);
    } catch (err: any) {
      setQueryResult({ error: err.message });
    } finally {
      setRunningQuery(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm">
      <div className="bg-[#181614] text-[#EFE7DE] max-w-5xl w-full h-[90vh] border border-[#3C352E] shadow-2xl relative flex flex-col overflow-hidden font-sans">
        {/* Top Header */}
        <div className="px-6 py-4 bg-[#211E1A] border-b border-[#352F28] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#E26928]/20 text-[#E26928] rounded">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-white tracking-wide flex items-center gap-2">
                <span>MySQL &amp; PHP 8.2 Architecture Console</span>
                <span className="text-[10px] bg-[#E26928] text-white px-2 py-0.5 rounded uppercase tracking-wider font-mono">
                  Live Engine
                </span>
              </h2>
              <p className="text-xs text-[#A69B8D]">
                InnoDB Storage Engine · B-Tree Index Optimization · Native PDO Prepared Statements
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={fetchOverview}
              className="p-1.5 text-[#A69B8D] hover:text-white transition-colors cursor-pointer"
              title="Refresh Telemetry"
            >
              <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-[#A69B8D] hover:text-white transition-colors cursor-pointer"
              aria-label="Close inspector"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-[#352F28] bg-[#1C1916] text-xs font-medium shrink-0 px-6">
          <button
            onClick={() => setActiveTab('overview')}
            className={`py-3 px-4 border-b-2 transition-colors flex items-center gap-2 cursor-pointer ${
              activeTab === 'overview'
                ? 'border-[#E26928] text-white font-semibold'
                : 'border-transparent text-[#998E82] hover:text-[#DDD3C5]'
            }`}
          >
            <Cpu className="w-3.5 h-3.5 text-[#E26928]" />
            <span>Architecture &amp; Efficiency</span>
          </button>

          <button
            onClick={() => setActiveTab('tables')}
            className={`py-3 px-4 border-b-2 transition-colors flex items-center gap-2 cursor-pointer ${
              activeTab === 'tables'
                ? 'border-[#E26928] text-white font-semibold'
                : 'border-transparent text-[#998E82] hover:text-[#DDD3C5]'
            }`}
          >
            <TableIcon className="w-3.5 h-3.5 text-[#E26928]" />
            <span>Live Tables &amp; Data</span>
          </button>

          <button
            onClick={() => setActiveTab('query')}
            className={`py-3 px-4 border-b-2 transition-colors flex items-center gap-2 cursor-pointer ${
              activeTab === 'query'
                ? 'border-[#E26928] text-white font-semibold'
                : 'border-transparent text-[#998E82] hover:text-[#DDD3C5]'
            }`}
          >
            <Play className="w-3.5 h-3.5 text-[#E26928]" />
            <span>EXPLAIN &amp; SQL Runner</span>
          </button>

          <button
            onClick={() => setActiveTab('php-code')}
            className={`py-3 px-4 border-b-2 transition-colors flex items-center gap-2 cursor-pointer ${
              activeTab === 'php-code'
                ? 'border-[#E26928] text-white font-semibold'
                : 'border-transparent text-[#998E82] hover:text-[#DDD3C5]'
            }`}
          >
            <Code2 className="w-3.5 h-3.5 text-[#E26928]" />
            <span>PHP Backend Source</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto p-6 text-xs text-[#DDD3C5]">
          {/* TAB 1: OVERVIEW & EFFICIENCY */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Top KPI Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="bg-[#211E1A] p-4 border border-[#352F28] rounded">
                  <span className="text-[#8E8376] text-[10px] uppercase tracking-wider block mb-1">Database Engine</span>
                  <span className="text-lg font-semibold text-white font-mono">
                    {overview?.engine || 'InnoDB'}
                  </span>
                  <p className="text-[11px] text-[#A69B8D] mt-1">ACID &amp; Row-Level Locks</p>
                </div>

                <div className="bg-[#211E1A] p-4 border border-[#352F28] rounded">
                  <span className="text-[#8E8376] text-[10px] uppercase tracking-wider block mb-1">MySQL Version</span>
                  <span className="text-lg font-semibold text-white font-mono truncate block">
                    {overview?.version ? overview.version.split('-')[0] : '10.11'}
                  </span>
                  <p className="text-[11px] text-[#A69B8D] mt-1">MariaDB Server active</p>
                </div>

                <div className="bg-[#211E1A] p-4 border border-[#352F28] rounded">
                  <span className="text-[#8E8376] text-[10px] uppercase tracking-wider block mb-1">PHP Runtime</span>
                  <span className="text-lg font-semibold text-white font-mono">
                    PHP {overview?.php_version || '8.2'}
                  </span>
                  <p className="text-[11px] text-[#A69B8D] mt-1">PDO MySQL Driver</p>
                </div>

                <div className="bg-[#211E1A] p-4 border border-[#352F28] rounded">
                  <span className="text-[#8E8376] text-[10px] uppercase tracking-wider block mb-1">Total Tables</span>
                  <span className="text-lg font-semibold text-white font-mono tabular-nums">
                    {overview?.tables?.length || 5} Tables
                  </span>
                  <p className="text-[11px] text-[#2E7D32] mt-1">All Schemas Synced</p>
                </div>
              </div>

              {/* Efficiency Architecture Explanations */}
              <div className="bg-[#211E1A] p-5 border border-[#352F28] rounded">
                <div className="flex items-center gap-2 mb-3">
                  <Zap className="w-4 h-4 text-[#E26928]" />
                  <h3 className="text-sm font-semibold text-white">
                    Why This Architecture Stores User Data Efficiently:
                  </h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-3.5 bg-[#181614] border border-[#2E2822] rounded space-y-1">
                    <strong className="text-white block font-medium">1. B-Tree Clustered &amp; Secondary Indexing</strong>
                    <p className="text-[#A69B8D] text-[11px] leading-relaxed">
                      The <code className="text-[#E26928] font-mono">users.email</code> column has a unique B-Tree index,
                      reducing client lookup complexity from <code className="font-mono">O(n)</code> full-table scan to
                      <code className="text-green-400 font-mono"> O(log n)</code> root-to-leaf binary traversal.
                    </p>
                  </div>

                  <div className="p-3.5 bg-[#181614] border border-[#2E2822] rounded space-y-1">
                    <strong className="text-white block font-medium">2. Composite Index on Boutique Reservations</strong>
                    <p className="text-[#A69B8D] text-[11px] leading-relaxed">
                      Appointments use composite index <code className="text-[#E26928] font-mono">(boutique, appointment_date)</code>.
                      Slot conflicts are evaluated instantly without scanning dates from other boutique locations.
                    </p>
                  </div>

                  <div className="p-3.5 bg-[#181614] border border-[#2E2822] rounded space-y-1">
                    <strong className="text-white block font-medium">3. Idempotent Upserts (ON DUPLICATE KEY UPDATE)</strong>
                    <p className="text-[#A69B8D] text-[11px] leading-relaxed">
                      Subscriptions and user profile updates use atomic MySQL upserts in a single round-trip, preventing race conditions
                      and duplicate email entries under high concurrency.
                    </p>
                  </div>

                  <div className="p-3.5 bg-[#181614] border border-[#2E2822] rounded space-y-1">
                    <strong className="text-white block font-medium">4. Native PDO Prepared Statements</strong>
                    <p className="text-[#A69B8D] text-[11px] leading-relaxed">
                      Emulation is disabled (<code className="font-mono">PDO::ATTR_EMULATE_PREPARES =&gt; false</code>).
                      Queries are pre-compiled and cached by MySQL, completely immunizing against SQL injections while reusing execution plans.
                    </p>
                  </div>
                </div>
              </div>

              {/* Table Metrics Summary */}
              <div className="bg-[#211E1A] p-5 border border-[#352F28] rounded">
                <h3 className="text-sm font-semibold text-white mb-3">
                  Database Tables Storage Metrics (hermes_db)
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-left font-mono text-[11px]">
                    <thead>
                      <tr className="border-b border-[#352F28] text-[#8E8376]">
                        <th className="pb-2">Table Name</th>
                        <th className="pb-2">Engine</th>
                        <th className="pb-2 text-right">Exact Rows</th>
                        <th className="pb-2 text-right">Data Size</th>
                        <th className="pb-2 text-right">Index Size</th>
                        <th className="pb-2 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#2B2520]">
                      {overview?.tables?.map((tbl) => (
                        <tr key={tbl.table_name} className="hover:bg-[#28231E]">
                          <td className="py-2.5 font-medium text-white">{tbl.table_name}</td>
                          <td className="py-2.5 text-[#A69B8D]">{tbl.engine}</td>
                          <td className="py-2.5 text-right tabular-nums text-[#E26928] font-semibold">
                            {tbl.exact_rows}
                          </td>
                          <td className="py-2.5 text-right tabular-nums text-[#DDD3C5]">
                            {(tbl.data_bytes / 1024).toFixed(1)} KB
                          </td>
                          <td className="py-2.5 text-right tabular-nums text-[#DDD3C5]">
                            {(tbl.index_bytes / 1024).toFixed(1)} KB
                          </td>
                          <td className="py-2.5 text-right">
                            <button
                              onClick={() => {
                                setSelectedTable(tbl.table_name);
                                fetchTableDetail(tbl.table_name);
                                setActiveTab('tables');
                              }}
                              className="text-[#E26928] hover:underline cursor-pointer"
                            >
                              Inspect →
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: LIVE TABLES & DATA */}
          {activeTab === 'tables' && (
            <div className="space-y-6">
              {/* Table Selector */}
              <div className="flex flex-wrap gap-2">
                {['users', 'boutique_appointments', 'client_wishlist', 'newsletter_subscribers', 'client_inquiries'].map(
                  (tbl) => (
                    <button
                      key={tbl}
                      onClick={() => {
                        setSelectedTable(tbl);
                        fetchTableDetail(tbl);
                      }}
                      className={`px-3 py-1.5 rounded text-xs font-mono transition-colors cursor-pointer ${
                        selectedTable === tbl
                          ? 'bg-[#E26928] text-white font-semibold'
                          : 'bg-[#211E1A] text-[#A69B8D] hover:text-white border border-[#352F28]'
                      }`}
                    >
                      {tbl}
                    </button>
                  )
                )}
              </div>

              {loading ? (
                <div className="p-8 text-center text-[#A69B8D]">Loading table metadata &amp; live rows...</div>
              ) : tableDetail ? (
                <div className="space-y-6">
                  {/* Columns Definition */}
                  <div className="bg-[#211E1A] p-4 border border-[#352F28] rounded">
                    <h4 className="text-xs font-semibold text-white uppercase tracking-wider mb-2">
                      Table Schema: <code className="text-[#E26928]">{selectedTable}</code>
                    </h4>
                    <div className="overflow-x-auto max-h-48 overflow-y-auto">
                      <table className="w-full text-left font-mono text-[11px]">
                        <thead>
                          <tr className="border-b border-[#352F28] text-[#8E8376]">
                            <th className="pb-1.5">Column</th>
                            <th className="pb-1.5">Type</th>
                            <th className="pb-1.5">Key</th>
                            <th className="pb-1.5">Nullable</th>
                            <th className="pb-1.5">Default</th>
                            <th className="pb-1.5">Extra</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#2B2520]">
                          {tableDetail.columns.map((c) => (
                            <tr key={c.COLUMN_NAME}>
                              <td className="py-1 text-white font-medium">{c.COLUMN_NAME}</td>
                              <td className="py-1 text-[#A69B8D]">{c.COLUMN_TYPE}</td>
                              <td className="py-1">
                                {c.COLUMN_KEY ? (
                                  <span className="text-[10px] px-1.5 py-0.2 bg-[#E26928]/30 text-[#E26928] rounded font-semibold">
                                    {c.COLUMN_KEY}
                                  </span>
                                ) : (
                                  '-'
                                )}
                              </td>
                              <td className="py-1 text-[#A69B8D]">{c.IS_NULLABLE}</td>
                              <td className="py-1 text-[#A69B8D]">{c.COLUMN_DEFAULT ?? 'NULL'}</td>
                              <td className="py-1 text-[#A69B8D]">{c.EXTRA || '-'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Indexes */}
                  <div className="bg-[#211E1A] p-4 border border-[#352F28] rounded">
                    <h4 className="text-xs font-semibold text-white uppercase tracking-wider mb-2">
                      B-Tree Indexes ({tableDetail.indexes.length})
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {tableDetail.indexes.map((idx, i) => (
                        <div
                          key={i}
                          className="p-2 bg-[#181614] border border-[#352F28] rounded text-[11px] font-mono space-y-0.5"
                        >
                          <span className="text-[#E26928] font-semibold">{idx.Key_name}</span>
                          <div className="text-[#A69B8D]">
                            Col: {idx.Column_name} ({idx.Index_type})
                          </div>
                          <div className="text-[10px] text-[#7A7168]">
                            Unique: {idx.Non_unique === 0 ? 'YES' : 'NO'}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Live Rows */}
                  <div className="bg-[#211E1A] p-4 border border-[#352F28] rounded">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-xs font-semibold text-white uppercase tracking-wider">
                        Live Data in MySQL ({tableDetail.rows.length} rows)
                      </h4>
                      <button
                        onClick={() => fetchTableDetail(selectedTable)}
                        className="text-xs text-[#E26928] hover:underline flex items-center gap-1 cursor-pointer"
                      >
                        <RefreshCw className="w-3 h-3" /> Refresh Data
                      </button>
                    </div>

                    {tableDetail.rows.length === 0 ? (
                      <p className="text-[#8E8376] italic py-4">No records currently stored in this table.</p>
                    ) : (
                      <div className="overflow-x-auto max-h-64 overflow-y-auto">
                        <table className="w-full text-left font-mono text-[11px]">
                          <thead>
                            <tr className="border-b border-[#352F28] text-[#8E8376]">
                              {Object.keys(tableDetail.rows[0]).map((k) => (
                                <th key={k} className="pb-1.5 px-2">
                                  {k}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-[#2B2520]">
                            {tableDetail.rows.map((r, ri) => (
                              <tr key={ri} className="hover:bg-[#28231E]">
                                {Object.values(r).map((v: any, vi) => (
                                  <td key={vi} className="py-1 px-2 text-[#DDD3C5] max-w-[200px] truncate">
                                    {v === null ? <span className="text-[#665D53]">NULL</span> : String(v)}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                </div>
              ) : null}
            </div>
          )}

          {/* TAB 3: EXPLAIN & SQL RUNNER */}
          {activeTab === 'query' && (
            <div className="space-y-5">
              <div className="bg-[#211E1A] p-4 border border-[#352F28] rounded space-y-3">
                <span className="text-xs font-semibold text-white block">Interactive Query Shortcuts:</span>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => {
                      const q = "EXPLAIN SELECT id, first_name, last_name FROM users WHERE email = 'claire.devalmont@elysee.fr';";
                      setSqlQuery(q);
                      handleRunSql(q);
                    }}
                    className="px-2.5 py-1 bg-[#181614] hover:bg-[#2E2822] border border-[#352F28] rounded text-[11px] font-mono text-[#E26928] cursor-pointer"
                  >
                    EXPLAIN User Lookup (Index Const)
                  </button>

                  <button
                    onClick={() => {
                      const q = "EXPLAIN SELECT * FROM boutique_appointments WHERE boutique = 'Paris - 24 Faubourg Saint-Honoré' AND appointment_date = CURRENT_DATE();";
                      setSqlQuery(q);
                      handleRunSql(q);
                    }}
                    className="px-2.5 py-1 bg-[#181614] hover:bg-[#2E2822] border border-[#352F28] rounded text-[11px] font-mono text-[#E26928] cursor-pointer"
                  >
                    EXPLAIN Appointment Composite Index
                  </button>

                  <button
                    onClick={() => {
                      const q = "SELECT id, email, first_name, last_name, preferred_boutique, client_tier FROM users;";
                      setSqlQuery(q);
                      handleRunSql(q);
                    }}
                    className="px-2.5 py-1 bg-[#181614] hover:bg-[#2E2822] border border-[#352F28] rounded text-[11px] font-mono text-[#A69B8D] cursor-pointer"
                  >
                    SELECT * FROM users
                  </button>

                  <button
                    onClick={() => {
                      const q = "SELECT id, guest_name, guest_email, boutique, service_type, appointment_date, appointment_time, status FROM boutique_appointments;";
                      setSqlQuery(q);
                      handleRunSql(q);
                    }}
                    className="px-2.5 py-1 bg-[#181614] hover:bg-[#2E2822] border border-[#352F28] rounded text-[11px] font-mono text-[#A69B8D] cursor-pointer"
                  >
                    SELECT * FROM boutique_appointments
                  </button>

                  <button
                    onClick={() => {
                      const q = "SELECT id, email, interests, status, subscribed_at FROM newsletter_subscribers;";
                      setSqlQuery(q);
                      handleRunSql(q);
                    }}
                    className="px-2.5 py-1 bg-[#181614] hover:bg-[#2E2822] border border-[#352F28] rounded text-[11px] font-mono text-[#A69B8D] cursor-pointer"
                  >
                    SELECT * FROM newsletter_subscribers
                  </button>
                </div>

                <div className="relative mt-2">
                  <textarea
                    rows={3}
                    value={sqlQuery}
                    onChange={(e) => setSqlQuery(e.target.value)}
                    className="w-full bg-[#181614] border border-[#352F28] p-3 text-xs font-mono text-green-400 focus:outline-hidden focus:border-[#E26928]"
                    placeholder="Enter SQL statement to execute against hermes_db..."
                  />
                  <button
                    onClick={() => handleRunSql()}
                    disabled={runningQuery}
                    className="absolute right-3 bottom-4 px-4 py-1.5 bg-[#E26928] hover:bg-[#c9581d] text-white text-xs font-semibold uppercase tracking-wider rounded transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    <Play className="w-3 h-3 fill-current" />
                    <span>{runningQuery ? 'Executing...' : 'Run Query'}</span>
                  </button>
                </div>
              </div>

              {/* Query Result Display */}
              {queryResult && (
                <div className="bg-[#211E1A] p-4 border border-[#352F28] rounded space-y-3">
                  <div className="flex items-center justify-between border-b border-[#352F28] pb-2 text-[11px]">
                    <span className="text-[#8E8376]">
                      Status:{' '}
                      <strong className={queryResult.error ? 'text-red-400' : 'text-green-400'}>
                        {queryResult.error ? 'Error' : 'Executed Successfully'}
                      </strong>
                    </span>
                    {queryResult.durationMs && (
                      <span className="font-mono text-[#E26928]">
                        Latency: {queryResult.durationMs} · Rows: {queryResult.rowCount}
                      </span>
                    )}
                  </div>

                  {queryResult.error ? (
                    <div className="p-3 bg-red-900/30 border border-red-700/50 text-red-200 font-mono text-xs">
                      {queryResult.error}
                    </div>
                  ) : (
                    <div className="overflow-x-auto max-h-72 overflow-y-auto">
                      <table className="w-full text-left font-mono text-[11px]">
                        <thead>
                          <tr className="border-b border-[#352F28] text-[#8E8376]">
                            {queryResult.headers?.map((h: string) => (
                              <th key={h} className="pb-1.5 px-2">
                                {h}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#2B2520]">
                          {queryResult.rows?.map((row: any, ri: number) => (
                            <tr key={ri} className="hover:bg-[#28231E]">
                              {queryResult.headers?.map((h: string) => (
                                <td key={h} className="py-1 px-2 text-[#DDD3C5]">
                                  {row[h] === null ? <span className="text-[#665D53]">NULL</span> : String(row[h])}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: PHP BACKEND SOURCE */}
          {activeTab === 'php-code' && (
            <div className="space-y-4">
              <div className="flex flex-wrap gap-2">
                {[
                  { file: 'db.php', label: 'config/db.php (PDO Connection)' },
                  { file: 'auth.php', label: 'api/auth.php (Bcrypt & Auth)' },
                  { file: 'appointments.php', label: 'api/appointments.php (Transactions)' },
                  { file: 'wishlist.php', label: 'api/wishlist.php (Customization)' },
                  { file: 'newsletter.php', label: 'api/newsletter.php (Upsert)' },
                  { file: 'schema.sql', label: 'schema.sql (MySQL DDL & Indexes)' },
                ].map((item) => (
                  <button
                    key={item.file}
                    onClick={() => {
                      setSelectedFile(item.file);
                      fetchCode(item.file);
                    }}
                    className={`px-3 py-1.5 rounded text-xs font-mono transition-colors cursor-pointer ${
                      selectedFile === item.file
                        ? 'bg-[#E26928] text-white font-semibold'
                        : 'bg-[#211E1A] text-[#A69B8D] hover:text-white border border-[#352F28]'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              <div className="bg-[#141210] p-4 border border-[#352F28] rounded font-mono text-xs overflow-x-auto max-h-[60vh] overflow-y-auto">
                {loadingCode ? (
                  <p className="text-[#8E8376]">Loading file contents...</p>
                ) : (
                  <pre className="text-[#E5DCD0] leading-relaxed whitespace-pre font-mono">
                    {codeContent}
                  </pre>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
