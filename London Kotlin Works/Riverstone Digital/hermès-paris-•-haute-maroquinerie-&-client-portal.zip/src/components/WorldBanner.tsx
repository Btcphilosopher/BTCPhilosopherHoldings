import React from 'react';
import { ArrowRight } from 'lucide-react';

interface WorldBannerProps {
  onExploreWorld: () => void;
}

export const WorldBanner: React.FC<WorldBannerProps> = ({ onExploreWorld }) => {
  return (
    <section className="relative w-full min-h-[360px] sm:min-h-[440px] flex items-center overflow-hidden bg-[#1D1B18]">
      {/* Background panoramic image with thoroughbred horse */}
      <div className="absolute inset-0 z-0">
        <img
          src="/assets/hermes/equestrian_banner.jpg"
          alt="Equestrian heritage of Hermès with noble horse overlooking misted landscape"
          className="w-full h-full object-cover object-center brightness-[0.88] contrast-[1.04]"
          referrerPolicy="no-referrer"
        />
        {/* Subtle text gradient */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/75 via-black/40 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-[1500px] w-full mx-auto px-6 sm:px-12 lg:px-16 py-14 sm:py-20 text-white">
        <div className="max-w-xl">
          <p className="text-[11px] sm:text-[12px] font-sans tracking-[0.28em] uppercase text-[#E5DCD0]/90 mb-3 font-medium">
            THE WORLD OF HERMÈS
          </p>

          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-normal leading-tight tracking-tight mb-4 text-[#FFFDFB]">
            Beyond the Atelier
          </h2>

          <p className="text-sm sm:text-base text-[#E5DCD0]/90 font-light leading-relaxed mb-8 max-w-lg">
            From equestrian heritage to contemporary art, Hermès is a universe of creation,
            culture and exceptional encounters.
          </p>

          <div>
            <button
              onClick={onExploreWorld}
              className="group inline-flex items-center gap-3 text-xs sm:text-[13px] font-medium tracking-[0.16em] uppercase text-white hover:text-[#E26928] pb-1 border-b border-white/60 hover:border-[#E26928] transition-colors cursor-pointer"
            >
              <span>EXPLORE THE WORLD OF HERMÈS</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
