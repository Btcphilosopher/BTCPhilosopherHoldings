import React, { useState } from 'react';
import { X, Search as SearchIcon, ArrowRight } from 'lucide-react';
import { ProductItem } from '../types';
import { ICONS_PRODUCTS } from './IconsShowcase';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectProduct: (product: ProductItem) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectProduct,
}) => {
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const filtered = ICONS_PRODUCTS.filter((p) => {
    const q = query.toLowerCase();
    return (
      p.name.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      p.description.toLowerCase().includes(q) ||
      p.leatherOptions.some((l) => l.toLowerCase().includes(q))
    );
  });

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-[#FAF8F5] max-w-2xl w-full border border-[#DDD3C5] shadow-2xl relative text-[#211E1C] overflow-hidden">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-[#7A7168] hover:text-[#181614] cursor-pointer"
          aria-label="Close search"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Search input field */}
        <div className="p-6 border-b border-[#E8DFD3]">
          <span className="text-[11px] font-sans tracking-[0.24em] uppercase text-[#E26928] font-medium block mb-2">
            Maison Search
          </span>
          <div className="relative flex items-center">
            <SearchIcon className="w-5 h-5 text-[#8A7E72] absolute left-0" />
            <input
              type="text"
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search Birkin, Kelly, Silk Carré, Barénia leather..."
              className="w-full bg-transparent pl-8 pr-10 py-2 text-base font-serif text-[#181614] placeholder:font-sans placeholder:text-sm placeholder:text-[#998E82] focus:outline-hidden"
            />
          </div>
        </div>

        {/* Results */}
        <div className="p-6 max-h-96 overflow-y-auto">
          <p className="text-[11px] font-semibold uppercase tracking-wider text-[#7A7168] mb-3">
            {query ? `Results (${filtered.length})` : 'Popular Creations & Icons'}
          </p>

          <div className="space-y-3">
            {filtered.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  onClose();
                  onSelectProduct(item);
                }}
                className="group flex items-center justify-between p-3 bg-white border border-[#E8DFD3] hover:border-[#181614] transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 bg-[#EAE2D5] border border-[#E8DFD3] shrink-0 overflow-hidden">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div>
                    <h4 className="font-semibold text-xs tracking-wider uppercase text-[#181614] group-hover:text-[#E26928] transition-colors">
                      {item.name}
                    </h4>
                    <p className="text-[11px] text-[#7A7168]">{item.subtitle}</p>
                    <span className="text-[11px] font-medium text-[#181614]">
                      €{item.price.toLocaleString('fr-FR')}
                    </span>
                  </div>
                </div>

                <ArrowRight className="w-4 h-4 text-[#7A7168] group-hover:text-[#181614] group-hover:translate-x-1 transition-all" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
