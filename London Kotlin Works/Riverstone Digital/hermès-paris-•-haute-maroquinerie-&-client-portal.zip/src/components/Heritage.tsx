import React, { useState } from 'react';
import { ArrowRight, X, Sparkles, CheckCircle2 } from 'lucide-react';

export const Heritage: React.FC = () => {
  const [craftsmanshipModalOpen, setCraftsmanshipModalOpen] = useState(false);

  return (
    <section className="w-full bg-[#FAF8F5] py-16 sm:py-24 border-b border-[#EDE6DC]">
      <div className="max-w-[1500px] mx-auto px-6 sm:px-12 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Black & White Artisan Hands Stitching (Col 5) */}
          <div className="lg:col-span-5 relative group overflow-hidden bg-[#ECE4D8]">
            <div className="aspect-[4/3] sm:aspect-[5/4] w-full overflow-hidden">
              <img
                src="/assets/hermes/artisan_hands.jpg"
                alt="Hermès artisan saddle stitching leather by hand"
                className="w-full h-full object-cover object-center grayscale contrast-110 transition-transform duration-700 group-hover:scale-102"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="p-4 bg-[#FAF8F5] border-t border-[#EDE6DC] flex items-center justify-between text-xs text-[#7A7168]">
              <span className="font-serif italic text-sm text-[#2E2925]">The Saddle Stitch (Point Sellier)</span>
              <span className="font-mono text-[11px] uppercase tracking-wider">Pantin Atelier</span>
            </div>
          </div>

          {/* Center Column: Editorial Craftsmanship Prose (Col 4) */}
          <div className="lg:col-span-4 flex flex-col justify-center py-4 lg:py-0 px-2 lg:px-4">
            <p className="text-[11px] sm:text-[12px] font-sans tracking-[0.26em] uppercase text-[#8A7E72] mb-3 sm:mb-4 font-medium">
              OUR HERITAGE
            </p>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-[42px] font-normal text-[#1A1815] leading-[1.18] mb-5 sm:mb-6">
              The Art<br />of the Hand
            </h2>
            <p className="text-sm sm:text-base text-[#5C544B] leading-relaxed font-light mb-8 max-w-md">
              Since 1837, Hermès has perpetuated a unique know-how, passed down through generations
              of artisans. Each creation is the result of meticulous craftsmanship, where time, precision
              and passion shape exceptional objects.
            </p>
            <div>
              <button
                onClick={() => setCraftsmanshipModalOpen(true)}
                className="group inline-flex items-center gap-2 text-xs font-semibold tracking-[0.18em] uppercase text-[#1A1815] hover:text-[#E26928] pb-1 border-b border-[#1A1815]/30 hover:border-[#E26928] transition-colors cursor-pointer"
              >
                <span>OUR CRAFTSMANSHIP</span>
                <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          </div>

          {/* Right Column: Leather Hot-Stamp Close-up (Col 3) */}
          <div className="lg:col-span-3 flex flex-col items-center sm:items-start group overflow-hidden bg-[#ECE4D8]">
            <div className="aspect-[3/4] w-full overflow-hidden shadow-xs">
              <img
                src="/assets/hermes/leather_stamp.jpg"
                alt="Hermès Paris Made in France gold hot stamp on amber leather"
                className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-103"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="w-full p-3 bg-[#FAF8F5] border-t border-[#EDE6DC] text-right text-[11px] text-[#7A7168] tracking-widest uppercase font-mono">
              Fait Main en France
            </div>
          </div>
        </div>
      </div>

      {/* Craftsmanship Interactive Story Modal */}
      {craftsmanshipModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-[#FAF8F5] max-w-2xl w-full p-6 sm:p-10 border border-[#DDD3C5] shadow-2xl relative text-[#211E1C] max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setCraftsmanshipModalOpen(false)}
              className="absolute top-5 right-5 p-2 text-[#7A7168] hover:text-[#181614] cursor-pointer"
              aria-label="Close craftsmanship story"
            >
              <X className="w-5 h-5" />
            </button>

            <span className="text-[11px] tracking-[0.24em] uppercase text-[#E26928] font-medium block mb-2">
              Atelier Secrets
            </span>
            <h3 className="font-serif text-3xl font-normal mb-4 text-[#181614]">
              The Four Pillars of Haute Maroquinerie
            </h3>
            <p className="text-sm text-[#5C544B] leading-relaxed mb-6 font-light">
              Unlike industrial luxury goods assembled on conveyor belts, every single Hermès Birkin and Kelly bag
              is crafted from start to finish by a single master artisan, requiring over 18 to 24 hours of focused work.
            </p>

            <div className="space-y-4 text-xs sm:text-sm text-[#3E3832]">
              <div className="p-3.5 bg-white border border-[#E8DFD3] rounded-xs flex items-start gap-3">
                <CheckCircle2 className="w-4 h-4 text-[#E26928] shrink-0 mt-0.5" />
                <div>
                  <strong className="font-serif text-sm block text-[#181614]">Le Point Sellier (Two Needles, One Thread)</strong>
                  A hand saddle stitch that can never unravel. Even if one stitch is cut, the rest remains perfectly intact.
                </div>
              </div>
              <div className="p-3.5 bg-white border border-[#E8DFD3] rounded-xs flex items-start gap-3">
                <CheckCircle2 className="w-4 h-4 text-[#E26928] shrink-0 mt-0.5" />
                <div>
                  <strong className="font-serif text-sm block text-[#181614]">Astray-Glazing &amp; Edge Inking</strong>
                  Edge wax is heated with an electric iron, repeatedly sanded with fine emery cloth, and hand-inked in up to seven successive layers.
                </div>
              </div>
              <div className="p-3.5 bg-white border border-[#E8DFD3] rounded-xs flex items-start gap-3">
                <CheckCircle2 className="w-4 h-4 text-[#E26928] shrink-0 mt-0.5" />
                <div>
                  <strong className="font-serif text-sm block text-[#181614]">Pearling the Rivets (Le Perlée)</strong>
                  Metal hardware studs are individually hand-hammered with a concave punch, forming tiny, luminous pearls of solid brass.
                </div>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-[#E8DFD3] flex items-center justify-between">
              <span className="text-xs text-[#8E8376] italic font-serif">
                "One artisan. One creation. A lifetime companion."
              </span>
              <button
                onClick={() => setCraftsmanshipModalOpen(false)}
                className="px-5 py-2.5 bg-[#181614] text-white text-xs uppercase tracking-widest hover:bg-[#E26928] transition-colors cursor-pointer"
              >
                Close Story
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
