import React, { useState } from 'react';
import { X, Calendar, Clock, MapPin, Sparkles, CheckCircle2, ShieldCheck } from 'lucide-react';
import { User, BoutiqueAppointment } from '../types';
import { api } from '../services/api';

interface AppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
  onAppointmentBooked: (appt: BoutiqueAppointment) => void;
}

export const BOUTIQUES = [
  { id: 'paris-faubourg', name: 'Paris - 24 Faubourg Saint-Honoré', address: '24, rue du Faubourg Saint-Honoré, 75008 Paris' },
  { id: 'paris-sevres', name: 'Paris - Rue de Sèvres', address: '17, rue de Sèvres, 75006 Paris' },
  { id: 'nyc-madison', name: 'New York - Madison Avenue Flagship', address: '706 Madison Ave, New York, NY 10065' },
  { id: 'london-bond', name: 'London - New Bond Street', address: '155 New Bond St, London W1S 2UA' },
  { id: 'tokyo-ginza', name: 'Tokyo - Maison Hermès Ginza', address: '5-4-1 Ginza, Chuo City, Tokyo 104-0061' },
];

export const SERVICE_TYPES = [
  'Haute Maroquinerie Consultation (Birkin & Kelly)',
  'Special Bespoke Order Advisory (Sur-Mesure)',
  'Private Salon Leather Goods Fitting',
  'Maison de la Soie & Scarf Styling',
  'Horlogerie & Haute Joaillerie Viewing',
];

export const AppointmentModal: React.FC<AppointmentModalProps> = ({
  isOpen,
  onClose,
  user,
  onAppointmentBooked,
}) => {
  const [guestName, setGuestName] = useState(user ? `${user.first_name} ${user.last_name}` : '');
  const [guestEmail, setGuestEmail] = useState(user ? user.email : '');
  const [guestPhone, setGuestPhone] = useState(user?.phone || '');
  const [boutique, setBoutique] = useState(user?.preferred_boutique || BOUTIQUES[0].name);
  const [serviceType, setServiceType] = useState(SERVICE_TYPES[0]);
  const [appointmentDate, setAppointmentDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 3);
    return d.toISOString().split('T')[0];
  });
  const [appointmentTime, setAppointmentTime] = useState('14:30');
  const [specialRequests, setSpecialRequests] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [confirmedAppt, setConfirmedAppt] = useState<BoutiqueAppointment | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);

    try {
      const res = await api.bookAppointment({
        user_id: user?.id || null,
        guest_name: guestName,
        guest_email: guestEmail,
        guest_phone: guestPhone || '+33 1 40 17 44 33',
        boutique,
        service_type: serviceType,
        appointment_date: appointmentDate,
        appointment_time: appointmentTime,
        special_requests: specialRequests,
      });

      setConfirmedAppt(res.appointment);
      onAppointmentBooked(res.appointment);
    } catch (err: any) {
      setError(err.message || 'Could not confirm appointment');
    } finally {
      setSubmitting(false);
    }
  };

  const handleReset = () => {
    setConfirmedAppt(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-[#FAF8F5] max-w-2xl w-full border border-[#DDD3C5] shadow-2xl relative text-[#211E1C] max-h-[92vh] overflow-y-auto">
        <button
          onClick={handleReset}
          className="absolute top-5 right-5 p-2 text-[#7A7168] hover:text-[#181614] cursor-pointer"
          aria-label="Close appointment modal"
        >
          <X className="w-5 h-5" />
        </button>

        {confirmedAppt ? (
          <div className="p-8 sm:p-12 text-center">
            <div className="w-14 h-14 bg-[#E26928]/10 text-[#E26928] rounded-full flex items-center justify-center mx-auto mb-5">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <p className="text-xs font-sans tracking-[0.24em] uppercase text-[#E26928] font-semibold mb-2">
              Appointment Confirmed · Stored in MySQL
            </p>
            <h3 className="font-serif text-3xl sm:text-4xl text-[#181614] mb-3">
              We Await Your Visit
            </h3>
            <p className="text-sm text-[#5C544B] max-w-md mx-auto mb-6 font-light">
              Your private boutique appointment has been reserved and stored in our relational database.
              A concierge confirmation has been dispatched.
            </p>

            <div className="max-w-md mx-auto bg-white p-5 border border-[#E8DFD3] text-left text-xs space-y-2 mb-8">
              <div className="flex justify-between border-b border-[#F2ECE4] pb-2">
                <span className="text-[#7A7168]">Reference</span>
                <span className="font-mono font-semibold text-[#181614]">{confirmedAppt.confirmation_ref}</span>
              </div>
              <div className="flex justify-between border-b border-[#F2ECE4] pb-2">
                <span className="text-[#7A7168]">Client</span>
                <span className="font-medium text-[#181614]">{confirmedAppt.guest_name}</span>
              </div>
              <div className="flex justify-between border-b border-[#F2ECE4] pb-2">
                <span className="text-[#7A7168]">Boutique</span>
                <span className="font-medium text-[#181614]">{confirmedAppt.boutique}</span>
              </div>
              <div className="flex justify-between border-b border-[#F2ECE4] pb-2">
                <span className="text-[#7A7168]">Date &amp; Time</span>
                <span className="font-medium text-[#181614]">{confirmedAppt.appointment_date} at {confirmedAppt.appointment_time}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#7A7168]">Service</span>
                <span className="font-medium text-[#181614]">{confirmedAppt.service_type}</span>
              </div>
            </div>

            <button
              onClick={handleReset}
              className="px-8 py-3 bg-[#181614] text-white text-xs uppercase tracking-widest hover:bg-[#E26928] transition-colors cursor-pointer"
            >
              Return to Maison
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 sm:p-10">
            <div className="mb-6">
              <span className="text-[11px] tracking-[0.24em] uppercase text-[#E26928] font-medium block mb-1.5">
                Boutique Services
              </span>
              <h3 className="font-serif text-2xl sm:text-3xl text-[#181614] mb-2">
                Reserve a Private Salon Consultation
              </h3>
              <p className="text-xs sm:text-sm text-[#696055] font-light">
                Experience bespoke attention in our private salons. All reservations are securely and efficiently
                persisted in our MySQL database with B-Tree indexed date checking.
              </p>
            </div>

            {error && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded">
                {error}
              </div>
            )}

            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[#4A433B] font-medium mb-1">Client Full Name *</label>
                  <input
                    type="text"
                    required
                    value={guestName}
                    onChange={(e) => setGuestName(e.target.value)}
                    placeholder="e.g. Claire de Valmont"
                    className="w-full bg-white border border-[#DDD3C5] px-3 py-2 text-xs text-[#181614] focus:outline-hidden focus:border-[#E26928]"
                  />
                </div>
                <div>
                  <label className="block text-[#4A433B] font-medium mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={guestEmail}
                    onChange={(e) => setGuestEmail(e.target.value)}
                    placeholder="claire@elysee.fr"
                    className="w-full bg-white border border-[#DDD3C5] px-3 py-2 text-xs text-[#181614] focus:outline-hidden focus:border-[#E26928]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[#4A433B] font-medium mb-1">Phone Number</label>
                  <input
                    type="tel"
                    value={guestPhone}
                    onChange={(e) => setGuestPhone(e.target.value)}
                    placeholder="+33 6 42 18 37 00"
                    className="w-full bg-white border border-[#DDD3C5] px-3 py-2 text-xs text-[#181614] focus:outline-hidden focus:border-[#E26928]"
                  />
                </div>
                <div>
                  <label className="block text-[#4A433B] font-medium mb-1">Select Boutique *</label>
                  <select
                    value={boutique}
                    onChange={(e) => setBoutique(e.target.value)}
                    className="w-full bg-white border border-[#DDD3C5] px-3 py-2 text-xs text-[#181614] focus:outline-hidden focus:border-[#E26928]"
                  >
                    {BOUTIQUES.map((b) => (
                      <option key={b.id} value={b.name}>
                        {b.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[#4A433B] font-medium mb-1">Consultation Objective *</label>
                <select
                  value={serviceType}
                  onChange={(e) => setServiceType(e.target.value)}
                  className="w-full bg-white border border-[#DDD3C5] px-3 py-2 text-xs text-[#181614] focus:outline-hidden focus:border-[#E26928]"
                >
                  {SERVICE_TYPES.map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[#4A433B] font-medium mb-1">Desired Date *</label>
                  <input
                    type="date"
                    required
                    value={appointmentDate}
                    onChange={(e) => setAppointmentDate(e.target.value)}
                    className="w-full bg-white border border-[#DDD3C5] px-3 py-2 text-xs text-[#181614] focus:outline-hidden focus:border-[#E26928]"
                  />
                </div>
                <div>
                  <label className="block text-[#4A433B] font-medium mb-1">Preferred Time *</label>
                  <select
                    value={appointmentTime}
                    onChange={(e) => setAppointmentTime(e.target.value)}
                    className="w-full bg-white border border-[#DDD3C5] px-3 py-2 text-xs text-[#181614] focus:outline-hidden focus:border-[#E26928]"
                  >
                    <option value="10:30">10:30 - Morning Salon</option>
                    <option value="11:45">11:45 - Midday Viewing</option>
                    <option value="14:00">14:00 - Early Afternoon</option>
                    <option value="15:30">15:30 - Afternoon Tea &amp; Leather</option>
                    <option value="17:00">17:00 - Twilight Session</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[#4A433B] font-medium mb-1">Special Client Requests &amp; Leather Preferences</label>
                <textarea
                  rows={2}
                  value={specialRequests}
                  onChange={(e) => setSpecialRequests(e.target.value)}
                  placeholder="e.g. Interested in viewing Togo Gold vs Craie Sellier leather swatches..."
                  className="w-full bg-white border border-[#DDD3C5] px-3 py-2 text-xs text-[#181614] focus:outline-hidden focus:border-[#E26928]"
                />
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-[#E8DFD3] flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-[11px] text-[#7A7168]">
                <ShieldCheck className="w-4 h-4 text-[#2E7D32]" />
                <span>Indexed MySQL Persistence (InnoDB)</span>
              </div>
              <button
                type="submit"
                disabled={submitting}
                className="px-6 py-3 bg-[#181614] text-white text-xs uppercase tracking-widest hover:bg-[#E26928] transition-colors cursor-pointer disabled:opacity-50"
              >
                {submitting ? 'Confirming with PHP Backend...' : 'Confirm Reservation'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
