import React from 'react';
import { ArrowRight, Heart } from 'lucide-react';
import { ProductItem } from '../types';

interface IconsShowcaseProps {
  onSelectProduct: (product: ProductItem) => void;
  onQuickWishlist: (product: ProductItem) => void;
}

export const ICONS_PRODUCTS: ProductItem[] = [
  {
    id: 'birkin',
    name: 'BIRKIN',
    subtitle: 'The original. Always.',
    category: 'Haute Maroquinerie',
    image: '/assets/hermes/birkin_card.jpg',
    price: 11500,
    description:
      'Born from a chance airborne encounter between Jane Birkin and Jean-Louis Dumas in 1984. Spacious, functional, and held in equilibrium by two rolled handles, a flap, and signature sangles with touret turn-lock.',
    leatherOptions: ['Togo Calfskin', 'Clemence Bullcalf', 'Box Calf', 'Epsom Stamped'],
    colorways: [
      { name: 'Gold (Caramel)', hex: '#A86835' },
      { name: 'Noir (Black)', hex: '#1C1B1A' },
      { name: 'Craie (Chalk)', hex: '#EBE5D8' },
      { name: 'Etoupe (Warm Taupe)', hex: '#877B6F' },
    ],
    hardwareOptions: ['Gold Permabrass', 'Palladium Finish', 'Brushed Rose Gold'],
    dimensions: '25 × 20 × 13 cm',
    craftTimeHours: 24,
  },
  {
    id: 'kelly',
    name: 'KELLY',
    subtitle: 'Elegance in every detail.',
    category: 'Haute Maroquinerie',
    image: '/assets/hermes/kelly_card.jpg',
    price: 10800,
    description:
      'Created by Robert Dumas in the 1930s as the Sac à dépêches, then immortalized by Grace Kelly, Princess of Monaco. Renowned for its architectural trapezoid form, single top handle, and detachable shoulder strap.',
    leatherOptions: ['Epsom Calfskin', 'Box Calfskin', 'Chevre Mysore', 'Swift Calf'],
    colorways: [
      { name: 'Craie (Chalk White)', hex: '#EBE5D8' },
      { name: 'Noir (Black)', hex: '#1C1B1A' },
      { name: 'Rouge H (Heritage Red)', hex: '#631B20' },
      { name: 'Bleu Nuit (Midnight Navy)', hex: '#1E2530' },
    ],
    hardwareOptions: ['Palladium Finish', 'Gold Permabrass'],
    dimensions: '28 × 22 × 10 cm',
    craftTimeHours: 20,
  },
  {
    id: 'silk-scarves',
    name: 'SILK SCARVES',
    subtitle: 'A canvas for imagination.',
    category: 'Maison de la Soie',
    image: '/assets/hermes/scarf_card.jpg',
    price: 495,
    description:
      'The iconic Carré 90 twill silk scarf. Each design takes up to two years to engrave and print across 40 distinct color screens, finished with artisan hand-rolled and hand-stitched borders (roulotté).',
    leatherOptions: ['100% Mulberry Silk Twill (14 Momme)', 'Silk-Cashmere Blend'],
    colorways: [
      { name: 'Orange Hermès & Marron', hex: '#E26928' },
      { name: 'Ciel & Or', hex: '#5E8CA6' },
      { name: 'Émeraude & Ivoire', hex: '#264D3B' },
    ],
    hardwareOptions: ['Hand-rolled hem (Le Roulotté)'],
    dimensions: '90 × 90 cm',
    craftTimeHours: 6,
  },
  {
    id: 'watches',
    name: 'HERMÈS WATCHES',
    subtitle: 'Time, reimagined.',
    category: 'Horlogerie Suisse',
    image: '/assets/hermes/watch_card.jpg',
    price: 3600,
    description:
      'Precision Swiss Manufacture movement encased in an anchor-chain or stirrup-inspired silhouette. Paired with hand-stitched Barénia calfskin leather straps crafted in our maroquinerie workshops.',
    leatherOptions: ['Natural Barénia Calfskin', 'Smooth Alligator', 'Box Calf'],
    colorways: [
      { name: 'Fauve Barénia', hex: '#A26532' },
      { name: 'Noir Ébène', hex: '#1A1816' },
    ],
    hardwareOptions: ['316L Stainless Steel', '18K Yellow Gold'],
    dimensions: '23 × 30 mm Case',
    craftTimeHours: 12,
  },
];

export const IconsShowcase: React.FC<IconsShowcaseProps> = ({
  onSelectProduct,
  onQuickWishlist,
}) => {
  return (
    <section id="icons" className="w-full bg-[#FAF8F5] py-20 sm:py-28">
      <div className="max-w-[1500px] mx-auto px-6 sm:px-12 lg:px-16">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-14 sm:mb-20">
          <p className="text-[11px] sm:text-[12px] font-sans tracking-[0.28em] uppercase text-[#8A7E72] mb-3 font-medium">
            OUR ICONS
          </p>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-normal text-[#1A1815] tracking-tight">
            Timeless Creations
          </h2>
        </div>

        {/* 4-Item Showcase Grid matching the screenshot */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {ICONS_PRODUCTS.map((prod) => (
            <div
              key={prod.id}
              className="group flex flex-col items-center text-center cursor-pointer"
              onClick={() => onSelectProduct(prod)}
            >
              {/* Product Image Frame */}
              <div className="relative w-full aspect-[4/3] bg-[#EAE2D5] overflow-hidden mb-6 shadow-xs border border-[#EDE4D8]">
                <img
                  src={prod.image}
                  alt={prod.name}
                  className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-104"
                  referrerPolicy="no-referrer"
                />

                {/* Subtle Wishlist Quick Action button */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onQuickWishlist(prod);
                  }}
                  className="absolute top-3 right-3 p-2 rounded-full bg-white/80 hover:bg-white text-[#181614] hover:text-[#E26928] opacity-0 group-hover:opacity-100 transition-opacity duration-200 shadow-sm cursor-pointer"
                  title="Add to MySQL Wishlist"
                  aria-label={`Add ${prod.name} to wishlist`}
                >
                  <Heart className="w-4 h-4" />
                </button>
              </div>

              {/* Title */}
              <h3 className="font-sans text-sm font-semibold tracking-[0.16em] uppercase text-[#1A1815] mb-2">
                {prod.name}
              </h3>

              {/* Subtitle */}
              <p className="text-xs sm:text-[13px] text-[#696055] font-light mb-4">
                {prod.subtitle}
              </p>

              {/* Explore Link with arrow matching screenshot */}
              <div className="inline-flex items-center gap-2 text-[11px] sm:text-xs font-medium tracking-[0.18em] uppercase text-[#1A1815] group-hover:text-[#E26928] transition-colors pb-0.5 border-b border-transparent group-hover:border-[#E26928]">
                <span>EXPLORE</span>
                <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
