import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import { spawn, exec } from 'child_process';
import http from 'http';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;
const PHP_PORT = 8080;

// Ensure MariaDB daemon is running
function ensureMariaDB() {
  exec('mariadb -e "SELECT 1;"', (err) => {
    if (err) {
      console.log('[System] Starting MariaDB server daemon...');
      const mariadbProcess = spawn('mariadbd-safe', ['--user=root'], {
        detached: true,
        stdio: 'ignore'
      });
      mariadbProcess.unref();
    } else {
      console.log('[System] MariaDB server is active and responsive.');
    }
  });
}

// Ensure PHP built-in server is running on 127.0.0.1:8080
let phpServerProcess: any = null;
function ensurePhpServer() {
  const req = http.get(`http://127.0.0.1:${PHP_PORT}/api/db_inspector.php?action=summary`, () => {
    console.log(`[System] PHP 8.2 backend server is responding on port ${PHP_PORT}`);
  });
  req.on('error', () => {
    console.log(`[System] Spawning PHP 8.2 backend server on 127.0.0.1:${PHP_PORT}...`);
    phpServerProcess = spawn('php', ['-S', `127.0.0.1:${PHP_PORT}`, '-t', path.resolve(__dirname, 'backend')]);
    phpServerProcess.on('exit', (code: number) => {
      console.log(`[System] PHP server exited with code ${code}. Restarting in 1s...`);
      setTimeout(ensurePhpServer, 1000);
    });
  });
}

async function startApp() {
  ensureMariaDB();
  ensurePhpServer();

  const app = express();
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Proxy /api/php/:script to PHP server
  app.all('/api/php/:script', async (req: Request, res: Response) => {
    const script = req.params.script;
    const queryStr = req.url.includes('?') ? req.url.slice(req.url.indexOf('?')) : '';
    const targetUrl = `http://127.0.0.1:${PHP_PORT}/api/${script}${queryStr}`;

    try {
      const options: RequestInit = {
        method: req.method,
        headers: {
          'Content-Type': req.headers['content-type'] || 'application/json',
          'Accept': 'application/json',
        },
      };

      if (req.method !== 'GET' && req.method !== 'HEAD' && req.body) {
        options.body = JSON.stringify(req.body);
      }

      const phpRes = await fetch(targetUrl, options);
      const text = await phpRes.text();
      res.status(phpRes.status);
      res.setHeader('Content-Type', phpRes.headers.get('content-type') || 'application/json');
      res.send(text);
    } catch (err: any) {
      console.error('[PHP Proxy Error]', err.message);
      res.status(502).json({
        status: 'error',
        message: 'Could not communicate with PHP backend: ' + err.message,
        hint: 'Verify PHP process is running on 127.0.0.1:' + PHP_PORT,
      });
    }
  });

  // Direct MySQL query runner endpoint for the in-app Database Console
  app.post('/api/mysql/query', (req: Request, res: Response) => {
    const { sql } = req.body;
    if (!sql || typeof sql !== 'string') {
      res.status(400).json({ error: 'Missing SQL query' });
      return;
    }

    // Restrict dangerous statements for safety while allowing inspect, select, explain, show, insert, update
    const trimmed = sql.trim();
    const disallowed = [/DROP\s+DATABASE/i, /SHUTDOWN/i, /GRANT\s+ALL/i];
    for (const pat of disallowed) {
      if (pat.test(trimmed)) {
        res.status(403).json({ error: 'This operation is restricted in the interactive inspector.' });
        return;
      }
    }

    const start = performance.now();
    // Execute via mariadb CLI with batch and JSON-friendly table format
    const cmd = `mariadb hermes_db --batch --raw -e "${trimmed.replace(/"/g, '\\"')}"`;
    exec(cmd, { timeout: 5000 }, (err, stdout, stderr) => {
      const durationMs = (performance.now() - start).toFixed(2);
      if (err) {
        res.status(400).json({
          error: stderr || err.message,
          durationMs,
        });
        return;
      }

      // Parse TSV rows into objects
      const lines = stdout.trim().split('\n').filter(Boolean);
      let headers: string[] = [];
      let rows: any[] = [];

      if (lines.length > 0) {
        headers = lines[0].split('\t');
        rows = lines.slice(1).map((line) => {
          const cells = line.split('\t');
          const obj: any = {};
          headers.forEach((h, i) => {
            // Mask password hashes in query output
            if (h === 'password_hash' && cells[i]) {
              obj[h] = cells[i].slice(0, 10) + '...[bcrypt]';
            } else {
              obj[h] = cells[i];
            }
          });
          return obj;
        });
      }

      res.json({
        sql: trimmed,
        durationMs: `${durationMs}ms`,
        rowCount: rows.length,
        headers,
        rows,
      });
    });
  });

  // Health check endpoint
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      status: 'healthy',
      service: 'Hermès Paris Haute Maroquinerie Web & API',
      php: '8.2',
      mysql: 'MariaDB 10.11',
      timestamp: new Date().toISOString()
    });
  });

  // Vite development middleware
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Server] Hermès application running at http://0.0.0.0:${PORT}`);
  });
}

startApp().catch((err) => {
  console.error('[Server Error] Failed to start server:', err);
  process.exit(1);
});
