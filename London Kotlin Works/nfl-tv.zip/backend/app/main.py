from fastapi import FastAPI, HTTPException, status
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

app = FastAPI(
    title="DSCS Sports NFL TV API",
    version="1.0.0",
    description="Backend API for Duke Satoshi Cyberspace NFL TV"
)

# Pydantic Schemas
class TeamSchema(BaseModel):
    id: str
    name: str
    city: str
    abbreviation: str
    conference: str
    division: str
    wins: int
    losses: int

class GameSchema(BaseModel):
    id: str
    away_team_id: str
    home_team_id: str
    status: str
    away_score: int
    home_score: int
    quarter: int
    game_clock: str
    down: int
    distance: int
    yard_line: str
    broadcast_network: str
    stream_url: str

class PlaySchema(BaseModel):
    id: str
    game_id: str
    quarter: int
    clock: str
    down: int
    distance: int
    yard_line: str
    description: str
    yards_gained: int
    is_scoring: bool

class PlaybackSessionRequest(BaseModel):
    media_id: str
    device_type: str = "ANDROID_TV"
    quality_profile: str = "4K_HDR"

class PlaybackSessionResponse(BaseModel):
    session_id: str
    stream_url: str
    stream_type: str
    audio_tracks: List[str]
    subtitles_available: bool
    drm_entitlement_status: str

class AiChatRequest(BaseModel):
    prompt: str
    game_id: Optional[str] = "game_kc_sf"

class AiChatResponse(BaseModel):
    response: str
    tool_executed: str
    grounded_in_telemetry: bool
    timestamp: datetime

# Mock In-Memory Store for immediate running
MOCK_TEAMS = [
    TeamSchema(id="KC", name="Chiefs", city="Kansas City", abbreviation="KC", conference="AFC", division="West", wins=11, losses=2),
    TeamSchema(id="SF", name="49ers", city="San Francisco", abbreviation="SF", conference="NFC", division="West", wins=10, losses=3),
    TeamSchema(id="BAL", name="Ravens", city="Baltimore", abbreviation="BAL", conference="AFC", division="North", wins=10, losses=3),
    TeamSchema(id="DET", name="Lions", city="Detroit", abbreviation="DET", conference="NFC", division="North", wins=11, losses=2)
]

MOCK_GAMES = [
    GameSchema(
        id="game_kc_sf",
        away_team_id="SF",
        home_team_id="KC",
        status="LIVE",
        away_score=27,
        home_score=31,
        quarter=4,
        game_clock="03:42",
        down=3,
        distance=4,
        yard_line="SF 38",
        broadcast_network="DSCS LIVE 4K HDR",
        stream_url="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
    )
]

# API Endpoints
@app.get("/api/v1/health")
async def health_check():
    return {"status": "ok", "service": "DSCS Sports NFL TV API", "version": "1.0.0"}

@app.get("/api/v1/teams", response_model=List[TeamSchema])
async def get_teams():
    return MOCK_TEAMS

@app.get("/api/v1/schedule", response_model=List[GameSchema])
async def get_schedule():
    return MOCK_GAMES

@app.get("/api/v1/games/{game_id}", response_model=GameSchema)
async def get_game(game_id: str):
    for g in MOCK_GAMES:
        if g.id == game_id:
            return g
    raise HTTPException(status_code=404, detail="Game not found")

@app.get("/api/v1/games/{game_id}/play-by-play", response_model=List[PlaySchema])
async def get_play_by_play(game_id: str):
    return [
        PlaySchema(
            id="p1",
            game_id=game_id,
            quarter=4,
            clock="03:42",
            down=3,
            distance=4,
            yard_line="SF 38",
            description="I. Pacheco rush up the middle for 6 yards, FIRST DOWN.",
            yards_gained=6,
            is_scoring=False
        ),
        PlaySchema(
            id="p2",
            game_id=game_id,
            quarter=3,
            clock="01:14",
            down=1,
            distance=10,
            yard_line="SF 20",
            description="P. Mahomes pass deep middle to X. Worthy for 48 yards, TOUCHDOWN Chiefs!",
            yards_gained=48,
            is_scoring=True
        )
    ]

@app.post("/api/v1/playback/sessions", response_model=PlaybackSessionResponse)
async def create_playback_session(req: PlaybackSessionRequest):
    return PlaybackSessionResponse(
        session_id=f"sess_{int(datetime.utcnow().timestamp())}",
        stream_url="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
        stream_type="HLS_LIVE",
        audio_tracks=["English (Primary)", "Spanish", "Natural Sound"],
        subtitles_available=True,
        drm_entitlement_status="AUTHORIZED"
    )

@app.post("/api/v1/ai/chat", response_model=AiChatResponse)
async def ai_chat(req: AiChatRequest):
    prompt_lower = req.prompt.lower()
    if "4th" in prompt_lower or "fourth" in prompt_lower:
        ans = "4th Down Matrix: Situation 4th & 1 at SF 38. Expected Value shows +2.8 EP for conversion attempt. Go for it."
        tool = "get_fourth_down_analytics"
    elif "quarterback" in prompt_lower or "qb" in prompt_lower:
        ans = "Quarterback comparison: Mahomes 25/34, 298 YDS, 2 TD vs Purdy 22/31, 264 YDS, 2 TD, 1 INT."
        tool = "compare_players"
    else:
        ans = f"Analyzed '{req.prompt}'. Current game state Q4 03:42 KC leads SF 31-27."
        tool = "get_game_summary"

    return AiChatResponse(
        response=ans,
        tool_executed=tool,
        grounded_in_telemetry=True,
        timestamp=datetime.utcnow()
    )
