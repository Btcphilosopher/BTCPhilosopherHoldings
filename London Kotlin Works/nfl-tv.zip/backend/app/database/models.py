from datetime import datetime
from sqlalchemy import (
    Column, String, Integer, Float, Boolean, DateTime, ForeignKey, Text, JSON
)
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()

class TeamModel(Base):
    __tablename__ = "teams"

    id = Column(String(10), primary_key=True)
    name = Column(String(50), nullable=False)
    city = Column(String(50), nullable=False)
    abbreviation = Column(String(10), nullable=False, unique=True)
    conference = Column(String(10), nullable=False)
    division = Column(String(20), nullable=False)
    wins = Column(Integer, default=0)
    losses = Column(Integer, default=0)
    ties = Column(Integer, default=0)
    stadium = Column(String(100), nullable=False)

class GameModel(Base):
    __tablename__ = "games"

    id = Column(String(50), primary_key=True)
    away_team_id = Column(String(10), ForeignKey("teams.id"), nullable=False)
    home_team_id = Column(String(10), ForeignKey("teams.id"), nullable=False)
    status = Column(String(20), default="SCHEDULED") # SCHEDULED, LIVE, HALFTIME, FINAL
    away_score = Column(Integer, default=0)
    home_score = Column(Integer, default=0)
    quarter = Column(Integer, default=1)
    game_clock = Column(String(20), default="15:00")
    down = Column(Integer, default=1)
    distance = Column(Integer, default=10)
    yard_line = Column(String(20), default="MID 50")
    possession_team_id = Column(String(10))
    stadium = Column(String(100))
    kickoff_time = Column(DateTime)
    broadcast_network = Column(String(50), default="DSCS LIVE")
    stream_url = Column(String(255))

class PlayModel(Base):
    __tablename__ = "game_events"

    id = Column(String(50), primary_key=True)
    game_id = Column(String(50), ForeignKey("games.id"), nullable=False)
    quarter = Column(Integer, nullable=False)
    clock = Column(String(20), nullable=False)
    down = Column(Integer)
    distance = Column(Integer)
    yard_line = Column(String(20))
    description = Column(Text, nullable=False)
    yards_gained = Column(Integer, default=0)
    is_scoring = Column(Boolean, default=False)
    is_turnover = Column(Boolean, default=False)
    highlight_url = Column(String(255))
    possession_team_abbr = Column(String(10))

class MediaAssetModel(Base):
    __tablename__ = "media_assets"

    id = Column(String(50), primary_key=True)
    title = Column(String(200), nullable=False)
    subtitle = Column(String(255))
    category = Column(String(50), nullable=False)
    duration_seconds = Column(Integer, default=0)
    thumbnail_url = Column(String(255))
    video_url = Column(String(255), nullable=False)
    is_subscription_required = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class UserPreferenceModel(Base):
    __tablename__ = "user_preferences"

    user_id = Column(String(50), primary_key=True)
    favorite_teams = Column(JSON, default=list)
    spoiler_protection = Column(Boolean, default=False)
    commentary_language = Column(String(50), default="English")
    preferred_quality = Column(String(50), default="4K HDR")
