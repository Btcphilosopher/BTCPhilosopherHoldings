import pytest
from httpx import AsyncClient, ASGITransport
from app.main import app

@pytest.mark.asyncio
async def test_health_check():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        response = await ac.get("/api/v1/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

@pytest.mark.asyncio
async def test_get_teams():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        response = await ac.get("/api/v1/teams")
    assert response.status_code == 200
    teams = response.json()
    assert len(teams) >= 4
    assert any(t["id"] == "KC" for t in teams)

@pytest.mark.asyncio
async def test_get_schedule():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        response = await ac.get("/api/v1/schedule")
    assert response.status_code == 200
    games = response.json()
    assert len(games) >= 1
    assert games[0]["status"] == "LIVE"

@pytest.mark.asyncio
async def test_playback_session():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        response = await ac.post("/api/v1/playback/sessions", json={"media_id": "game_kc_sf"})
    assert response.status_code == 200
    data = response.json()
    assert data["drm_entitlement_status"] == "AUTHORIZED"
    assert "stream_url" in data

@pytest.mark.asyncio
async def test_ai_chat_fourth_down():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        response = await ac.post("/api/v1/ai/chat", json={"prompt": "Why did they go for it on 4th down?"})
    assert response.status_code == 200
    data = response.json()
    assert data["tool_executed"] == "get_fourth_down_analytics"
    assert "Expected Value" in data["response"]
