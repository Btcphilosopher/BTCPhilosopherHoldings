# DSCS Sports NFL TV — Backend Architecture

## Overview
This backend service powers **NFL TV by DukeSatoshiCyberSpace (DSCS)**, delivering real-time game schedules, live play-by-play telemetry, quarterback comparisons, video playback entitlement sessions, and ChatGPT-compatible football analytical assistant endpoints.

## Tech Stack
- **Language**: Python 3.12+
- **Framework**: FastAPI with Pydantic v2
- **ORM**: SQLAlchemy 2.x & AsyncPG
- **Database**: PostgreSQL 16
- **Caching**: Redis 7
- **Testing**: Pytest & HTTPX AsyncClient

## Running Locally with Docker Compose

```bash
cd backend
docker-compose up --build
```

The service will start at `http://localhost:8000` with interactive Swagger docs available at `http://localhost:8000/docs`.

## Running Directly with Python

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install .
uvicorn app.main:app --reload --port 8000
```

## Running Automated Tests

```bash
cd backend
pytest tests/ -v
```

## Key API Endpoints
- `GET  /api/v1/health` — Service health & version status
- `GET  /api/v1/schedule` — In-progress and scheduled NFL fixtures
- `GET  /api/v1/games/{game_id}` — Game telemetry and live scoreboard
- `GET  /api/v1/games/{game_id}/play-by-play` — Chronological down, distance, and yardage logs
- `GET  /api/v1/teams` — All NFL franchises with divisions and records
- `POST /api/v1/playback/sessions` — Issue authorized HLS/DASH streaming sessions
- `POST /api/v1/ai/chat` — ChatGPT-grounded football analysis with tool telemetry
