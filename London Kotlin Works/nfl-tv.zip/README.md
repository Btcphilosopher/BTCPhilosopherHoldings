# NFL TV by DukeSatoshiCyberSpace (DSCS)

A luxury sports television and mobile application delivering authentic broadcast command centre controls, real-time football telemetry, interactive game centres, multi-game split-screen viewing, and a ChatGPT-powered football analyst.

---

## Architecture Overview

### Android Application (Client)
- **Language & UI**: Kotlin, Jetpack Compose, Material Design 3 ("DSCS Sports" visual identity in Obsidian Black, Graphite surfaces, and Restrained Amber accents).
- **Navigation & Remote**: Dual mode — 10-foot TV D-pad focus indicators (`TvFocusableCard`, `TvNavigationRail`) and mobile/tablet responsive touch with predictive backstack handling (`BackHandler`).
- **Media Playback**: AndroidX Media3 / ExoPlayer supporting live 4K HDR streaming feeds, synchronized live edge, time-scrubbing for video-on-demand, in-game scorebug, telemetry overlays, and 2-panel/4-panel multi-game split view.
- **Game Centre**: Overview, Play-by-Play with interactive drive tracking, down & distance chips, team statistics comparisons, player box scores, drive summaries, and AI match analysis.
- **Sports Data Layer**: All 32 NFL franchises across AFC & NFC divisions, live in-progress matches, localized kickoff times, and conference standings with playoff clinching status.
- **ChatGPT Football Assistant**: Conversational analyst grounded in actual in-game telemetry, play-by-play logs, 4th down decision models, coverage breakdowns (Cover 2 vs Cover 3), quarterback comparisons, and rule explanations.
- **Persistence**: Room Database (`NflTvDatabase`) for Continue Watching (`WatchHistoryItem`) and Watchlist (`WatchlistItem`).

### Backend Service (`/backend`)
- **Framework**: Python 3.12+ with FastAPI and Pydantic v2.
- **Database & Cache**: SQLAlchemy 2.x, PostgreSQL 16, Redis 7.
- **Endpoints**: Schedule, Game telemetry, Play-by-play, Franchise directory, Standings, Entitled playback session tokens, and AI chat.
- **Docker Compose**: Pre-configured `docker-compose.yml` for turnkey local environment setup.

---

## Project Structure

```text
├── app/
│   ├── src/main/java/com/example/
│   │   ├── MainActivity.kt
│   │   ├── data/
│   │   │   ├── model/ (Game, Team, Play, Drive, GameStatistics, Player, Standings, MediaAsset)
│   │   │   ├── local/ (NflTvDatabase, WatchlistDao, WatchHistoryDao, Entities)
│   │   │   └── repository/ (SportsDataRepository, MediaRepository, AiAssistantRepository)
│   │   ├── player/ (NflBroadcastPlayer, telemetry HUD, scorebug)
│   │   ├── ui/
│   │   │   ├── components/ (TvFocusableCard, BroadcastGameCard, DscsSectionHeader)
│   │   │   ├── screens/ (HomeScreen, GameCentreScreen, ScheduleScreen, StandingsScreen, HighlightsScreen, TeamDetailScreen, AiAssistantScreen, PersonalizationScreen)
│   │   │   └── theme/ (Color, Theme, Type - DSCS Sports luxury palette)
│   └── src/test/ (NflTvUnitTests, Robolectric tests)
├── backend/
│   ├── app/
│   │   ├── main.py (FastAPI application & endpoints)
│   │   └── database/ (SQLAlchemy models)
│   ├── tests/ (test_api.py)
│   ├── docker-compose.yml
│   ├── Dockerfile
│   └── pyproject.toml
└── metadata.json
```
