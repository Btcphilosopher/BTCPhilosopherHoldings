package com.example

import com.example.data.model.GameStatus
import com.example.data.model.Score
import com.example.data.repository.AiAssistantRepository
import com.example.data.repository.MediaCatalogProvider
import com.example.data.repository.SportsDataRepository
import kotlinx.coroutines.flow.emptyFlow
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NflTvUnitTests {

  @Test
  fun testAll32TeamsLoaded() {
    val repo = SportsDataRepository()
    val teams = repo.getAllTeams()
    assertEquals("Should contain 32 NFL teams", 32, teams.size)

    val chiefs = repo.getTeamById("KC")
    assertNotNull("KC Chiefs should exist", chiefs)
    assertEquals("Chiefs", chiefs?.name)
    assertEquals("AFC", chiefs?.conference)
    assertEquals("West", chiefs?.division)
  }

  @Test
  fun testScoreCalculation() {
    val score = Score(
      awayQuarterScores = listOf(7, 10, 3, 7),
      homeQuarterScores = listOf(3, 14, 7, 7)
    )
    assertEquals(27, score.awayTotal)
    assertEquals(31, score.homeTotal)
  }

  @Test
  fun testDownAndDistanceFormatting() {
    val repo = SportsDataRepository()
    val game = repo.getGameById("game_kc_sf")
    assertNotNull("Game should exist", game)
    assertEquals(GameStatus.LIVE, game?.status)
    assertEquals("3rd & 4 at SF 38", game?.downAndDistanceString)
  }

  @Test
  fun testAiAssistantGroundedFourthDownTool() {
    val sportsRepo = SportsDataRepository()
    // Minimal mock for MediaCatalogProvider in unit test
    val mockMedia = object : MediaCatalogProvider {
      override fun getAllMedia() = emptyFlow<List<com.example.data.model.MediaAsset>>()
      override fun getMediaByCategory(category: com.example.data.model.MediaCategory) = emptyList<com.example.data.model.MediaAsset>()
      override fun getMediaById(id: String) = null
      override fun getWatchlist() = emptyFlow<List<com.example.data.local.WatchlistItem>>()
      override fun isInWatchlist(mediaId: String) = emptyFlow<Boolean>()
      override suspend fun toggleWatchlist(asset: com.example.data.model.MediaAsset) {}
      override fun getContinueWatching() = emptyFlow<List<com.example.data.local.WatchHistoryItem>>()
      override suspend fun recordProgress(asset: com.example.data.model.MediaAsset, positionMs: Long, durationMs: Long) {}
      override suspend fun clearHistory() {}
    }

    val aiRepo = AiAssistantRepository(sportsRepo, mockMedia)
    aiRepo.askQuestion("Why did the offense go for it on 4th down?", "game_kc_sf")

    val msgs = aiRepo.messages.value
    assertTrue("Should have at least 2 messages", msgs.size >= 2)
    val lastMsg = msgs.last()
    assertEquals("get_fourth_down_analytics", lastMsg.toolUsed)
    assertTrue("Response should contain analytical model", lastMsg.text.contains("Analytics Model"))
  }

  @Test
  fun testAiAssistantQuarterbackComparisonTool() {
    val sportsRepo = SportsDataRepository()
    val mockMedia = object : MediaCatalogProvider {
      override fun getAllMedia() = emptyFlow<List<com.example.data.model.MediaAsset>>()
      override fun getMediaByCategory(category: com.example.data.model.MediaCategory) = emptyList<com.example.data.model.MediaAsset>()
      override fun getMediaById(id: String) = null
      override fun getWatchlist() = emptyFlow<List<com.example.data.local.WatchlistItem>>()
      override fun isInWatchlist(mediaId: String) = emptyFlow<Boolean>()
      override suspend fun toggleWatchlist(asset: com.example.data.model.MediaAsset) {}
      override fun getContinueWatching() = emptyFlow<List<com.example.data.local.WatchHistoryItem>>()
      override suspend fun recordProgress(asset: com.example.data.model.MediaAsset, positionMs: Long, durationMs: Long) {}
      override suspend fun clearHistory() {}
    }

    val aiRepo = AiAssistantRepository(sportsRepo, mockMedia)
    aiRepo.askQuestion("Compare both quarterbacks tonight", "game_kc_sf")

    val lastMsg = aiRepo.messages.value.last()
    assertEquals("compare_players", lastMsg.toolUsed)
    assertTrue(lastMsg.text.contains("Mahomes"))
    assertTrue(lastMsg.text.contains("Purdy"))
  }
}
