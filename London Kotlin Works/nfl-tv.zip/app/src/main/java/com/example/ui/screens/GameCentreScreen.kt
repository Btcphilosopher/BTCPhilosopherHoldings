package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Drive
import com.example.data.model.Game
import com.example.data.model.GameStatistics
import com.example.data.model.GameStatus
import com.example.data.model.Play
import com.example.data.model.PlayerGameStat
import com.example.data.repository.SportsDataProvider
import com.example.ui.components.TvFocusableCard
import com.example.ui.theme.ChalkDim
import com.example.ui.theme.ChalkWhite
import com.example.ui.theme.FieldGreen
import com.example.ui.theme.FocusBorderAmber
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteElevated
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.LiveRed
import com.example.ui.theme.MutedBlue
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RestrainedAmber
import com.example.ui.theme.SteelDark
import com.example.ui.theme.SteelGrey

@Composable
fun GameCentreScreen(
  gameId: String,
  sportsRepository: SportsDataProvider,
  onBack: () -> Unit,
  onWatchBroadcast: (streamUrl: String, title: String, subtitle: String) -> Unit,
  onPlayClip: (clipUrl: String, title: String) -> Unit,
  onAskAi: (prompt: String) -> Unit,
  modifier: Modifier = Modifier
) {
  val game = remember(gameId) { sportsRepository.getGameById(gameId) }
  val plays = remember(gameId) { sportsRepository.getPlayByPlay(gameId) }
  val drives = remember(gameId) { sportsRepository.getDrives(gameId) }
  val stats = remember(gameId) { sportsRepository.getGameStatistics(gameId) }
  val playerStats = remember(gameId) { sportsRepository.getPlayerStats(gameId) }

  if (game == null) {
    Box(modifier = Modifier.fillMaxSize().background(ObsidianBlack), contentAlignment = Alignment.Center) {
      Text("Game not found", color = ChalkWhite)
    }
    return
  }

  var selectedTabIndex by remember { mutableIntStateOf(0) }
  val tabs = listOf("Overview", "Play-by-Play", "Drives", "Team Stats", "Player Stats", "AI Analysis")

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(ObsidianBlack)
      .testTag("game_centre_screen")
  ) {
    // Top Bar with Back and Watch Broadcast
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(
        onClick = onBack,
        modifier = Modifier.testTag("game_centre_back_btn")
      ) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = ChalkWhite)
      }

      Button(
        onClick = {
          onWatchBroadcast(
            game.streamUrl,
            "${game.awayTeam.name} @ ${game.homeTeam.name}",
            "${game.headline} • ${game.broadcastNetwork}"
          )
        },
        colors = ButtonDefaults.buttonColors(containerColor = RestrainedAmber, contentColor = ObsidianBlack),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.testTag("game_centre_watch_btn")
      ) {
        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = if (game.status == GameStatus.LIVE) "Watch Live Stream" else "Watch Broadcast",
          fontWeight = FontWeight.Bold,
          fontSize = 13.sp
        )
      }
    }

    // Comprehensive Game Scoreboard Header
    GameScoreboardHeader(game = game)

    // Tabs Row
    ScrollableTabRow(
      selectedTabIndex = selectedTabIndex,
      containerColor = GraphiteSurface,
      contentColor = RestrainedAmber,
      edgePadding = 16.dp,
      indicator = { tabPositions ->
        TabRowDefaults.SecondaryIndicator(
          modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
          color = RestrainedAmber,
          height = 3.dp
        )
      },
      divider = { HorizontalDivider(color = GraphiteBorder) }
    ) {
      tabs.forEachIndexed { index, tabTitle ->
        Tab(
          selected = selectedTabIndex == index,
          onClick = { selectedTabIndex = index },
          text = {
            Text(
              text = tabTitle,
              fontSize = 13.sp,
              fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
              color = if (selectedTabIndex == index) RestrainedAmber else ChalkDim
            )
          }
        )
      }
    }

    // Tab Contents
    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
      when (selectedTabIndex) {
        0 -> GameOverviewTab(game = game, stats = stats, onAskAi = onAskAi)
        1 -> PlayByPlayTab(plays = plays, onPlayClip = onPlayClip)
        2 -> DrivesTab(drives = drives)
        3 -> TeamStatsTab(stats = stats, awayTeam = game.awayTeam.name, homeTeam = game.homeTeam.name)
        4 -> PlayerStatsTab(playerStats = playerStats)
        5 -> AiAnalysisTab(game = game, onAskAi = onAskAi)
      }
    }
  }
}

@Composable
fun GameScoreboardHeader(game: Game) {
  Surface(
    color = GraphiteElevated,
    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
    shape = RoundedCornerShape(12.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      // Status & Clock Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          if (game.status == GameStatus.LIVE) {
            Box(modifier = Modifier.size(8.dp).background(LiveRed, CircleShape))
            Spacer(modifier = Modifier.width(6.dp))
            Text("LIVE", color = LiveRed, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(modifier = Modifier.width(10.dp))
            Text("Q${game.quarter} ${game.gameClock}", color = RestrainedAmber, fontSize = 13.sp, fontWeight = FontWeight.Bold)
          } else {
            Text(game.displayStatus, color = ChalkDim, fontSize = 13.sp, fontWeight = FontWeight.Bold)
          }
        }
        Text(game.stadium, color = SteelGrey, fontSize = 12.sp)
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Matchup scores with team emblems
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Away Team
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(game.awayTeam.logoEmoji, fontSize = 28.sp)
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(game.awayTeam.name, color = ChalkWhite, fontSize = 20.sp, fontWeight = FontWeight.Black)
            Text(game.awayTeam.recordString, color = SteelGrey, fontSize = 12.sp)
          }
        }

        // Score
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = if (game.status == GameStatus.UPCOMING) "-" else "${game.score.awayTotal}",
            color = ChalkWhite,
            fontSize = 32.sp,
            fontWeight = FontWeight.Black
          )
          Text(" — ", color = SteelDark, fontSize = 24.sp, fontWeight = FontWeight.Light)
          Text(
            text = if (game.status == GameStatus.UPCOMING) "-" else "${game.score.homeTotal}",
            color = ChalkWhite,
            fontSize = 32.sp,
            fontWeight = FontWeight.Black
          )
        }

        // Home Team
        Row(verticalAlignment = Alignment.CenterVertically) {
          Column(horizontalAlignment = Alignment.End) {
            Text(game.homeTeam.name, color = ChalkWhite, fontSize = 20.sp, fontWeight = FontWeight.Black)
            Text(game.homeTeam.recordString, color = SteelGrey, fontSize = 12.sp)
          }
          Spacer(modifier = Modifier.width(10.dp))
          Text(game.homeTeam.logoEmoji, fontSize = 28.sp)
        }
      }

      if (game.downAndDistanceString.isNotBlank()) {
        Spacer(modifier = Modifier.height(12.dp))
        Surface(
          color = FieldGreen.copy(alpha = 0.15f),
          shape = RoundedCornerShape(6.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("Ball on field: ", color = SteelGrey, fontSize = 12.sp)
            Text(game.downAndDistanceString, color = FieldGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun GameOverviewTab(
  game: Game,
  stats: GameStatistics?,
  onAskAi: (String) -> Unit
) {
  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Win Probability Bar
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("WIN PROBABILITY TELEMETRY", color = RestrainedAmber, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
          Spacer(modifier = Modifier.height(8.dp))
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${game.awayTeam.name} ${(game.awayWinProbability * 100).toInt()}%", color = ChalkWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text("${game.homeTeam.name} ${(game.homeWinProbability * 100).toInt()}%", color = ChalkWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
          }
          Spacer(modifier = Modifier.height(6.dp))
          Row(modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))) {
            Box(modifier = Modifier.weight(game.awayWinProbability).fillMaxSize().background(MutedBlue))
            Box(modifier = Modifier.weight(game.homeWinProbability).fillMaxSize().background(RestrainedAmber))
          }
        }
      }
    }

    // AI Coach Insight Card
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteElevated),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RestrainedAmber.copy(alpha = 0.4f)),
        modifier = Modifier.clickable {
          onAskAi("Give me a comprehensive tactical breakdown of this matchup's momentum and key matchups.")
        }
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = RestrainedAmber, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("DSCS AI In-Game Analysis", color = ChalkWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
          }
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Exploiting soft quarters coverage on 2nd down has allowed Kansas City to sustain 9+ play drives. San Francisco must dial up 5-man fire zones to force earlier releases.",
            color = ChalkDim,
            fontSize = 13.sp,
            lineHeight = 18.sp
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text("Tap to ask follow-up in AI Assistant ➔", color = RestrainedAmber, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
      }
    }

    // Key Stats Comparison Preview
    if (stats != null) {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
          shape = RoundedCornerShape(10.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text("KEY MATCHUP METRICS", color = SteelGrey, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))
            StatComparisonRow("Total Yards", stats.awayStats.totalYards.toString(), stats.homeStats.totalYards.toString())
            StatComparisonRow("Passing Yards", stats.awayStats.passingYards.toString(), stats.homeStats.passingYards.toString())
            StatComparisonRow("Rushing Yards", stats.awayStats.rushingYards.toString(), stats.homeStats.rushingYards.toString())
            StatComparisonRow("3rd Down Rate", stats.awayStats.thirdDownEfficiency, stats.homeStats.thirdDownEfficiency)
            StatComparisonRow("Time of Possession", stats.awayStats.timeOfPossession, stats.homeStats.timeOfPossession)
          }
        }
      }
    }
  }
}

@Composable
fun PlayByPlayTab(
  plays: List<Play>,
  onPlayClip: (clipUrl: String, title: String) -> Unit
) {
  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    items(plays) { play ->
      Surface(
        color = GraphiteSurface,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(
          1.dp,
          if (play.isScoringPlay) RestrainedAmber else if (play.isTurnover) LiveRed else GraphiteBorder
        ),
        modifier = Modifier.fillMaxWidth().testTag("play_row_${play.id}")
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          // Play header
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Surface(
                color = GraphiteElevated,
                shape = RoundedCornerShape(4.dp)
              ) {
                Text(
                  text = "Q${play.quarter} ${play.clock}",
                  color = RestrainedAmber,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "${play.down} & ${play.distance} at ${play.yardLine}",
                color = ChalkWhite,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
              )
            }

            if (play.isScoringPlay) {
              Surface(color = RestrainedAmber, shape = RoundedCornerShape(4.dp)) {
                Text(
                  "TOUCHDOWN",
                  color = ObsidianBlack,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Black,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            } else if (play.isTurnover) {
              Surface(color = LiveRed, shape = RoundedCornerShape(4.dp)) {
                Text(
                  "TURNOVER",
                  color = Color.White,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Black,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))
          Text(text = play.description, color = ChalkWhite, fontSize = 13.sp, lineHeight = 18.sp)

          // AI Insight if present
          if (play.aiInsight != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
              color = ObsidianBlack.copy(alpha = 0.5f),
              shape = RoundedCornerShape(4.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = RestrainedAmber, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = play.aiInsight, color = ChalkDim, fontSize = 11.sp)
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun DrivesTab(drives: List<Drive>) {
  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    items(drives) { drive ->
      Surface(
        color = GraphiteSurface,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (drive.isScore) RestrainedAmber else GraphiteBorder),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Drive #${drive.driveNumber} • ${drive.teamAbbreviation}",
              color = ChalkWhite,
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold
            )
            Surface(
              color = if (drive.isScore) RestrainedAmber else GraphiteElevated,
              shape = RoundedCornerShape(4.dp)
            ) {
              Text(
                text = drive.outcome,
                color = if (drive.isScore) ObsidianBlack else ChalkDim,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }
          Spacer(modifier = Modifier.height(8.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("Plays: ${drive.playsCount}", color = SteelGrey, fontSize = 12.sp)
            Text("Yards: ${drive.yardsCovered}", color = SteelGrey, fontSize = 12.sp)
            Text("TOP: ${drive.timeOfPossession}", color = SteelGrey, fontSize = 12.sp)
            Text("Start: ${drive.startYardLine}", color = SteelGrey, fontSize = 12.sp)
          }
        }
      }
    }
  }
}

@Composable
fun TeamStatsTab(stats: GameStatistics?, awayTeam: String, homeTeam: String) {
  if (stats == null) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
      Text("Stats not available yet", color = SteelGrey)
    }
    return
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(awayTeam, color = RestrainedAmber, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text("CATEGORY", color = SteelGrey, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Text(homeTeam, color = RestrainedAmber, fontWeight = FontWeight.Bold, fontSize = 14.sp)
      }
      HorizontalDivider(color = GraphiteBorder)
    }

    item { StatComparisonRow("First Downs", stats.awayStats.firstDowns.toString(), stats.homeStats.firstDowns.toString()) }
    item { StatComparisonRow("Total Yards", stats.awayStats.totalYards.toString(), stats.homeStats.totalYards.toString()) }
    item { StatComparisonRow("Passing Yards", stats.awayStats.passingYards.toString(), stats.homeStats.passingYards.toString()) }
    item { StatComparisonRow("Comp / Att", stats.awayStats.completionsAttempts, stats.homeStats.completionsAttempts) }
    item { StatComparisonRow("Rushing Yards", stats.awayStats.rushingYards.toString(), stats.homeStats.rushingYards.toString()) }
    item { StatComparisonRow("Rushing Attempts", stats.awayStats.rushingAttempts.toString(), stats.homeStats.rushingAttempts.toString()) }
    item { StatComparisonRow("Turnovers", stats.awayStats.turnovers.toString(), stats.homeStats.turnovers.toString()) }
    item { StatComparisonRow("3rd Down Efficiency", stats.awayStats.thirdDownEfficiency, stats.homeStats.thirdDownEfficiency) }
    item { StatComparisonRow("4th Down Efficiency", stats.awayStats.fourthDownEfficiency, stats.homeStats.fourthDownEfficiency) }
    item { StatComparisonRow("Red Zone Efficiency", stats.awayStats.redZoneEfficiency, stats.homeStats.redZoneEfficiency) }
    item { StatComparisonRow("Sacks Allowed", stats.awayStats.sacksAllowed.toString(), stats.homeStats.sacksAllowed.toString()) }
    item { StatComparisonRow("Penalties", stats.awayStats.penalties, stats.homeStats.penalties) }
    item { StatComparisonRow("Time of Possession", stats.awayStats.timeOfPossession, stats.homeStats.timeOfPossession) }
  }
}

@Composable
fun PlayerStatsTab(playerStats: List<PlayerGameStat>) {
  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    items(playerStats) { ps ->
      Surface(
        color = GraphiteSurface,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(ps.name, color = ChalkWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text("${ps.teamAbbr} • ${ps.position} • ${ps.statCategory}", color = SteelGrey, fontSize = 12.sp)
          }
          Text(ps.statLine, color = RestrainedAmber, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
fun AiAnalysisTab(game: Game, onAskAi: (String) -> Unit) {
  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Text(
        text = "TACTICAL AI MATCHUP DISPATCH",
        color = RestrainedAmber,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp
      )
    }

    val questions = listOf(
      "Why did the offense go for it on 4th down?" to "Detailed 4th down analytical model and expected points added.",
      "Compare both quarterbacks tonight" to "Passer rating, pressure rate and completion above expectation.",
      "Cover 2 vs Cover 3 schematic differences" to "How defense adapted coverage shells between halves.",
      "Explain the penalty in Q3" to "Rulebook clarification and spot foul enforcement analysis."
    )

    items(questions) { (q, desc) ->
      Surface(
        color = GraphiteSurface,
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder),
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onAskAi(q) }
      ) {
        Row(
          modifier = Modifier.padding(16.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(q, color = ChalkWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(desc, color = SteelGrey, fontSize = 12.sp)
          }
          Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = RestrainedAmber, modifier = Modifier.size(20.dp))
        }
      }
    }
  }
}

@Composable
fun StatComparisonRow(label: String, awayVal: String, homeVal: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 8.dp, horizontal = 12.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(awayVal, color = ChalkWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    Text(label, color = SteelGrey, fontSize = 12.sp)
    Text(homeVal, color = ChalkWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
  }
}
