package com.example.data.model

data class Team(
  val id: String,
  val name: String,
  val city: String,
  val abbreviation: String,
  val conference: String, // AFC, NFC
  val division: String,   // East, North, South, West
  val wins: Int,
  val losses: Int,
  val ties: Int = 0,
  val primaryColorHex: Long = 0xFF1E3A8A,
  val secondaryColorHex: Long = 0xFFF59E0B,
  val stadium: String,
  val logoEmoji: String = "🏈"
) {
  val recordString: String get() = if (ties > 0) "$wins-$losses-$ties" else "$wins-$losses"
  val fullName: String get() = "$city $name"
}

enum class GameStatus {
  UPCOMING,
  LIVE,
  HALFTIME,
  FINAL
}

data class Score(
  val awayQuarterScores: List<Int> = listOf(0, 0, 0, 0),
  val homeQuarterScores: List<Int> = listOf(0, 0, 0, 0)
) {
  val awayTotal: Int get() = awayQuarterScores.sum()
  val homeTotal: Int get() = homeQuarterScores.sum()
}

data class Game(
  val id: String,
  val awayTeam: Team,
  val homeTeam: Team,
  val status: GameStatus,
  val score: Score,
  val quarter: Int = 1, // 1, 2, 3, 4, 5 (OT)
  val gameClock: String = "15:00",
  val down: Int = 1, // 1 to 4
  val distance: Int = 10,
  val yardLine: String = "MID 50",
  val possessionTeamId: String = "",
  val stadium: String = "",
  val kickoffTime: String = "8:20 PM ET",
  val broadcastNetwork: String = "DSCS LIVE",
  val isNationalBroadcast: Boolean = true,
  val isRegionalBlackout: Boolean = false,
  val streamUrl: String = "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
  val streamType: String = "HLS_LIVE",
  val headline: String = "Primetime Showdown",
  val weatherCondition: String = "72°F Clear",
  val awayWinProbability: Float = 0.48f,
  val homeWinProbability: Float = 0.52f
) {
  val displayStatus: String
    get() = when (status) {
      GameStatus.UPCOMING -> kickoffTime
      GameStatus.LIVE -> "Q$quarter $gameClock"
      GameStatus.HALFTIME -> "HALFTIME"
      GameStatus.FINAL -> "FINAL"
    }

  val downAndDistanceString: String
    get() = when {
      status != GameStatus.LIVE -> ""
      down == 1 -> "1st & $distance at $yardLine"
      down == 2 -> "2nd & $distance at $yardLine"
      down == 3 -> "3rd & $distance at $yardLine"
      down == 4 -> "4th & $distance at $yardLine"
      else -> "At $yardLine"
    }
}
