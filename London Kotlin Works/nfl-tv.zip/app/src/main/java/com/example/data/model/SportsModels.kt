package com.example.data.model

data class Play(
  val id: String,
  val gameId: String,
  val quarter: Int,
  val clock: String,
  val down: Int,
  val distance: Int,
  val yardLine: String,
  val description: String,
  val yardsGained: Int,
  val isScoringPlay: Boolean = false,
  val isTurnover: Boolean = false,
  val isPenalty: Boolean = false,
  val highlightUrl: String? = null,
  val possessionTeamAbbreviation: String,
  val keyPlayerName: String? = null,
  val aiInsight: String? = null
)

data class Drive(
  val id: String,
  val gameId: String,
  val teamAbbreviation: String,
  val driveNumber: Int,
  val startQuarter: Int,
  val startYardLine: String,
  val endYardLine: String,
  val playsCount: Int,
  val yardsCovered: Int,
  val timeOfPossession: String,
  val outcome: String, // Touchdown, Field Goal, Punt, Turnover on downs, Interception
  val isScore: Boolean
)

data class TeamGameStats(
  val firstDowns: Int,
  val totalYards: Int,
  val passingYards: Int,
  val completionsAttempts: String,
  val rushingYards: Int,
  val rushingAttempts: Int,
  val turnovers: Int,
  val fumblesLost: Int,
  val interceptionsThrown: Int,
  val thirdDownEfficiency: String,
  val fourthDownEfficiency: String,
  val redZoneEfficiency: String,
  val sacksAllowed: Int,
  val penalties: String,
  val timeOfPossession: String
)

data class GameStatistics(
  val gameId: String,
  val awayStats: TeamGameStats,
  val homeStats: TeamGameStats
)

data class Player(
  val id: String,
  val name: String,
  val teamId: String,
  val jerseyNumber: Int,
  val position: String, // QB, RB, WR, TE, DE, LB, CB, S, K
  val college: String,
  val experienceYears: Int,
  val seasonStatsSummary: String,
  val rating: Float = 90.5f,
  val isInjured: Boolean = false,
  val injuryNote: String? = null,
  val headshotUrl: String? = null
)

data class PlayerGameStat(
  val playerId: String,
  val name: String,
  val teamAbbr: String,
  val position: String,
  val statCategory: String, // Passing, Rushing, Receiving, Defense
  val statLine: String
)

data class DivisionStandings(
  val divisionName: String,
  val conference: String, // AFC, NFC
  val teams: List<StandingsRow>
)

data class StandingsRow(
  val team: Team,
  val rank: Int,
  val wins: Int,
  val losses: Int,
  val ties: Int = 0,
  val winPct: Float,
  val pointsFor: Int,
  val pointsAgainst: Int,
  val pointDiff: Int,
  val streak: String,
  val divisionRecord: String,
  val conferenceRecord: String,
  val clinchStatus: String? = null // "z - Clinched Division", "x - Clinched Playoff", "e - Eliminated"
)

enum class MediaCategory {
  LIVE_STREAM,
  HIGHLIGHTS,
  FULL_REPLAY,
  TOUCHDOWNS,
  TACTICAL_BREAKDOWN,
  ORIGINALS,
  TOP_PLAYS
}

data class MediaAsset(
  val id: String,
  val title: String,
  val subtitle: String,
  val category: MediaCategory,
  val duration: String,
  val durationSeconds: Int,
  val thumbnailUrl: String,
  val videoUrl: String,
  val datePublished: String,
  val teamTags: List<String> = emptyList(),
  val relatedGameId: String? = null,
  val isSubscriptionRequired: Boolean = false,
  val isFreeTier: Boolean = true
)
