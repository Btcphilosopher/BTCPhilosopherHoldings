package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "watchlist")
data class WatchlistItem(
  @PrimaryKey val mediaId: String,
  val title: String,
  val subtitle: String,
  val category: String,
  val duration: String,
  val videoUrl: String,
  val addedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "watch_history")
data class WatchHistoryItem(
  @PrimaryKey val mediaId: String,
  val title: String,
  val subtitle: String,
  val videoUrl: String,
  val positionMs: Long,
  val durationMs: Long,
  val lastWatchedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_settings")
data class UserSettingsEntity(
  @PrimaryKey val id: Int = 1,
  val favoriteTeamIds: String = "KC,SF", // comma separated
  val spoilerProtection: Boolean = false,
  val commentaryLanguage: String = "English",
  val notificationsEnabled: Boolean = true,
  val preferredStreamQuality: String = "Auto (1080p60)"
)

@Dao
interface WatchlistDao {
  @Query("SELECT * FROM watchlist ORDER BY addedTimestamp DESC")
  fun getAll(): Flow<List<WatchlistItem>>

  @Query("SELECT EXISTS(SELECT 1 FROM watchlist WHERE mediaId = :mediaId)")
  fun isInWatchlist(mediaId: String): Flow<Boolean>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(item: WatchlistItem)

  @Query("DELETE FROM watchlist WHERE mediaId = :mediaId")
  suspend fun delete(mediaId: String)
}

@Dao
interface WatchHistoryDao {
  @Query("SELECT * FROM watch_history ORDER BY lastWatchedTimestamp DESC LIMIT 20")
  fun getRecentHistory(): Flow<List<WatchHistoryItem>>

  @Query("SELECT * FROM watch_history WHERE mediaId = :mediaId LIMIT 1")
  suspend fun getProgress(mediaId: String): WatchHistoryItem?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun updateProgress(item: WatchHistoryItem)

  @Query("DELETE FROM watch_history")
  suspend fun clearHistory()
}

@Dao
interface SettingsDao {
  @Query("SELECT * FROM user_settings WHERE id = 1")
  fun getSettings(): Flow<UserSettingsEntity?>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun saveSettings(settings: UserSettingsEntity)
}

@Database(
  entities = [WatchlistItem::class, WatchHistoryItem::class, UserSettingsEntity::class],
  version = 1,
  exportSchema = false
)
abstract class NflTvDatabase : RoomDatabase() {
  abstract fun watchlistDao(): WatchlistDao
  abstract fun watchHistoryDao(): WatchHistoryDao
  abstract fun settingsDao(): SettingsDao

  companion object {
    @Volatile
    private var INSTANCE: NflTvDatabase? = null

    fun getDatabase(context: Context): NflTvDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          NflTvDatabase::class.java,
          "nfl_tv_dscs.db"
        ).fallbackToDestructiveMigration().build()
        INSTANCE = instance
        instance
      }
    }
  }
}
