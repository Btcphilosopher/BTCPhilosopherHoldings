package com.example.data.repository

import com.example.data.local.NflTvDatabase
import com.example.data.local.WatchHistoryItem
import com.example.data.local.WatchlistItem
import com.example.data.model.MediaAsset
import com.example.data.model.MediaCategory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

interface MediaCatalogProvider {
  fun getAllMedia(): Flow<List<MediaAsset>>
  fun getMediaByCategory(category: MediaCategory): List<MediaAsset>
  fun getMediaById(id: String): MediaAsset?
  fun getWatchlist(): Flow<List<WatchlistItem>>
  fun isInWatchlist(mediaId: String): Flow<Boolean>
  suspend fun toggleWatchlist(asset: MediaAsset)
  fun getContinueWatching(): Flow<List<WatchHistoryItem>>
  suspend fun recordProgress(asset: MediaAsset, positionMs: Long, durationMs: Long)
  suspend fun clearHistory()
}

class MediaRepository(
  private val database: NflTvDatabase
) : MediaCatalogProvider {

  // Authorized demonstration media library (using standard Google Video streams for clean playback test)
  private val mediaAssets = listOf(
    MediaAsset(
      id = "m_chiefs_49ers_live",
      title = "Chiefs vs 49ers — Live Broadcast 4K HDR",
      subtitle = "Super Bowl Rematch • Arrowhead Stadium",
      category = MediaCategory.LIVE_STREAM,
      duration = "LIVE",
      durationSeconds = 0,
      thumbnailUrl = "https://images.unsplash.com/photo-1587280501635-68a0e82cd5ff?w=800&auto=format&fit=crop&q=80",
      videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      datePublished = "Live Now",
      teamTags = listOf("KC", "SF"),
      relatedGameId = "game_kc_sf"
    ),
    MediaAsset(
      id = "m_ravens_lions_live",
      title = "Ravens at Lions — Multi-Angle Feed",
      subtitle = "Primetime Interconference Battle • Ford Field",
      category = MediaCategory.LIVE_STREAM,
      duration = "LIVE",
      durationSeconds = 0,
      thumbnailUrl = "https://images.unsplash.com/photo-1566577739112-5180d4bf9390?w=800&auto=format&fit=crop&q=80",
      videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
      datePublished = "Live Now",
      teamTags = listOf("BAL", "DET"),
      relatedGameId = "game_bal_det"
    ),
    MediaAsset(
      id = "m_td_worthy_48yd",
      title = "Mahomes 48-Yard Touchdown Strike to Worthy",
      subtitle = "Q3 01:14 • Explosive Post-Corner Route",
      category = MediaCategory.TOUCHDOWNS,
      duration = "0:45",
      durationSeconds = 45,
      thumbnailUrl = "https://images.unsplash.com/photo-1587280501635-68a0e82cd5ff?w=800&auto=format&fit=crop&q=80",
      videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
      datePublished = "Today",
      teamTags = listOf("KC"),
      relatedGameId = "game_kc_sf"
    ),
    MediaAsset(
      id = "m_td_cmc_wheel",
      title = "McCaffrey 12-Yard Wheel Route Touchdown",
      subtitle = "Q4 05:52 • Purdy Pinpoint Red Zone Delivery",
      category = MediaCategory.TOUCHDOWNS,
      duration = "0:52",
      durationSeconds = 52,
      thumbnailUrl = "https://images.unsplash.com/photo-1566577739112-5180d4bf9390?w=800&auto=format&fit=crop&q=80",
      videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
      datePublished = "Today",
      teamTags = listOf("SF"),
      relatedGameId = "game_kc_sf"
    ),
    MediaAsset(
      id = "m_int_mcduffie",
      title = "Trent McDuffie Inverted Cover-2 Interception",
      subtitle = "Q2 08:30 • Critical Red Zone Defensive Stop",
      category = MediaCategory.HIGHLIGHTS,
      duration = "1:08",
      durationSeconds = 68,
      thumbnailUrl = "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=800&auto=format&fit=crop&q=80",
      videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
      datePublished = "Today",
      teamTags = listOf("KC"),
      relatedGameId = "game_kc_sf"
    ),
    MediaAsset(
      id = "m_tactical_shanahan_spagnuolo",
      title = "Tactical Breakdown: Spagnuolo Blitz vs Shanahan Motions",
      subtitle = "Film Room Analysis • All-22 Coaches Tape",
      category = MediaCategory.TACTICAL_BREAKDOWN,
      duration = "14:20",
      durationSeconds = 860,
      thumbnailUrl = "https://images.unsplash.com/photo-1517649763962-0c623266ddc0?w=800&auto=format&fit=crop&q=80",
      videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4",
      datePublished = "Yesterday",
      teamTags = listOf("KC", "SF")
    ),
    MediaAsset(
      id = "m_top_plays_week",
      title = "Top 10 Plays of the Week — Sacks, Hurdles & Hail Marys",
      subtitle = "Curated by DSCS Sports Editors",
      category = MediaCategory.TOP_PLAYS,
      duration = "8:35",
      durationSeconds = 515,
      thumbnailUrl = "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=800&auto=format&fit=crop&q=80",
      videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
      datePublished = "2 days ago"
    ),
    MediaAsset(
      id = "m_replay_cin_pit",
      title = "Bengals vs Steelers — Full Game Replay (Condensed)",
      subtitle = "Week 14 Primetime Classic in 42 Minutes",
      category = MediaCategory.FULL_REPLAY,
      duration = "42:10",
      durationSeconds = 2530,
      thumbnailUrl = "https://images.unsplash.com/photo-1486286701208-1d58e9338013?w=800&auto=format&fit=crop&q=80",
      videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4",
      datePublished = "3 days ago",
      teamTags = listOf("CIN", "PIT"),
      relatedGameId = "game_cin_pit"
    ),
    MediaAsset(
      id = "m_doc_gridiron_chronicle",
      title = "DSCS Originals: The Architecture of Arrowhead",
      subtitle = "Documentary Series • Sound, Decibels & Legacy",
      category = MediaCategory.ORIGINALS,
      duration = "26:45",
      durationSeconds = 1605,
      thumbnailUrl = "https://images.unsplash.com/photo-1518091043644-c1d4457512c6?w=800&auto=format&fit=crop&q=80",
      videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WhatCarCanYouGetForAGrand.mp4",
      datePublished = "This Week",
      teamTags = listOf("KC")
    )
  )

  private val mediaListFlow = MutableStateFlow(mediaAssets)

  override fun getAllMedia(): Flow<List<MediaAsset>> = mediaListFlow.asStateFlow()

  override fun getMediaByCategory(category: MediaCategory): List<MediaAsset> {
    return mediaAssets.filter { it.category == category }
  }

  override fun getMediaById(id: String): MediaAsset? {
    return mediaAssets.find { it.id == id }
  }

  override fun getWatchlist(): Flow<List<WatchlistItem>> {
    return database.watchlistDao().getAll()
  }

  override fun isInWatchlist(mediaId: String): Flow<Boolean> {
    return database.watchlistDao().isInWatchlist(mediaId)
  }

  override suspend fun toggleWatchlist(asset: MediaAsset) {
    val dao = database.watchlistDao()
    // Check if item exists in a simple transactional block
    try {
      dao.insert(
        WatchlistItem(
          mediaId = asset.id,
          title = asset.title,
          subtitle = asset.subtitle,
          category = asset.category.name,
          duration = asset.duration,
          videoUrl = asset.videoUrl
        )
      )
    } catch (_: Exception) {
      dao.delete(asset.id)
    }
  }

  override fun getContinueWatching(): Flow<List<WatchHistoryItem>> {
    return database.watchHistoryDao().getRecentHistory()
  }

  override suspend fun recordProgress(asset: MediaAsset, positionMs: Long, durationMs: Long) {
    if (positionMs <= 1000L) return
    database.watchHistoryDao().updateProgress(
      WatchHistoryItem(
        mediaId = asset.id,
        title = asset.title,
        subtitle = asset.subtitle,
        videoUrl = asset.videoUrl,
        positionMs = positionMs,
        durationMs = durationMs
      )
    )
  }

  override suspend fun clearHistory() {
    database.watchHistoryDao().clearHistory()
  }
}
