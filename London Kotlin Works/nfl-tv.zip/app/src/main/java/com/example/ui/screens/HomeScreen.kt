package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.WatchHistoryItem
import com.example.data.model.Game
import com.example.data.model.GameStatus
import com.example.data.model.MediaAsset
import com.example.data.model.MediaCategory
import com.example.data.model.Team
import com.example.data.repository.MediaCatalogProvider
import com.example.data.repository.SportsDataProvider
import com.example.ui.components.BroadcastGameCard
import com.example.ui.components.DscsSectionHeader
import com.example.ui.components.TvFocusableCard
import com.example.ui.theme.ChalkDim
import com.example.ui.theme.ChalkWhite
import com.example.ui.theme.FieldGreen
import com.example.ui.theme.FocusBorderAmber
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteElevated
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.LiveRed
import com.example.ui.theme.MutedBlue
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RestrainedAmber
import com.example.ui.theme.SteelDark
import com.example.ui.theme.SteelGrey

@Composable
fun HomeScreen(
  sportsRepository: SportsDataProvider,
  mediaRepository: MediaCatalogProvider,
  onOpenPlayer: (videoUrl: String, title: String, subtitle: String, gameId: String?) -> Unit,
  onOpenGameCentre: (gameId: String) -> Unit,
  onOpenTeamDetail: (teamId: String) -> Unit,
  onOpenAiWithPrompt: (prompt: String, gameId: String?) -> Unit,
  onOpenSchedule: () -> Unit,
  onOpenStandings: () -> Unit,
  modifier: Modifier = Modifier
) {
  val liveGames by sportsRepository.getLiveGames().collectAsState(initial = emptyList())
  val upcomingGames by sportsRepository.getUpcomingGames().collectAsState(initial = emptyList())
  val allMedia by mediaRepository.getAllMedia().collectAsState(initial = emptyList())
  val continueWatching by mediaRepository.getContinueWatching().collectAsState(initial = emptyList())

  val heroGame = liveGames.firstOrNull() ?: upcomingGames.firstOrNull()

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(ObsidianBlack)
      .testTag("home_screen_lazy_column"),
    contentPadding = PaddingValues(bottom = 60.dp)
  ) {
    // 1. Featured Broadcast Hero Banner
    item {
      if (heroGame != null) {
        HeroBroadcastPanel(
          game = heroGame,
          onWatchLive = {
            onOpenPlayer(
              heroGame.streamUrl,
              "${heroGame.awayTeam.name} @ ${heroGame.homeTeam.name}",
              "${heroGame.headline} • ${heroGame.broadcastNetwork}",
              heroGame.id
            )
          },
          onOpenGameCentre = { onOpenGameCentre(heroGame.id) },
          onAskAi = { onOpenAiWithPrompt("Summarise the game so far and explain key momentum shifts.", heroGame.id) }
        )
      }
    }

    // 2. Live Now Section
    if (liveGames.isNotEmpty()) {
      item {
        DscsSectionHeader(
          title = "Live Broadcasts",
          subtitle = "In-progress games with live telemetry and multi-angle feeds"
        )
        LazyRow(
          contentPadding = PaddingValues(horizontal = 24.dp),
          horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
          items(liveGames) { game ->
            BroadcastGameCard(
              game = game,
              onClick = { onOpenGameCentre(game.id) }
            )
          }
        }
      }
    }

    // 3. Continue Watching Section (if history exists)
    if (continueWatching.isNotEmpty()) {
      item {
        DscsSectionHeader(
          title = "Continue Watching",
          subtitle = "Resume your recent broadcasts and game breakdowns"
        )
        LazyRow(
          contentPadding = PaddingValues(horizontal = 24.dp),
          horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
          items(continueWatching) { item ->
            ContinueWatchingCard(
              item = item,
              onClick = {
                onOpenPlayer(item.videoUrl, item.title, item.subtitle, null)
              }
            )
          }
        }
      }
    }

    // 4. Ask AI Football Analyst Quick Launcher
    item {
      AiPromptShortcutsBar(
        onPromptClick = { prompt ->
          onOpenAiWithPrompt(prompt, heroGame?.id)
        }
      )
    }

    // 5. Upcoming Primetime Games
    item {
      DscsSectionHeader(
        title = "Upcoming Games",
        subtitle = "Week 14 scheduled kickoffs",
        actionLabel = "View Full Schedule",
        onActionClick = onOpenSchedule
      )
      LazyRow(
        contentPadding = PaddingValues(horizontal = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        items(upcomingGames) { game ->
          BroadcastGameCard(
            game = game,
            onClick = { onOpenGameCentre(game.id) }
          )
        }
      }
    }

    // 6. Latest Highlights & Touchdowns
    item {
      val highlights = allMedia.filter { it.category == MediaCategory.TOUCHDOWNS || it.category == MediaCategory.HIGHLIGHTS }
      DscsSectionHeader(
        title = "Latest Highlights & Scoring Plays",
        subtitle = "Verified authorized video clips with tactical play logs"
      )
      LazyRow(
        contentPadding = PaddingValues(horizontal = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        items(highlights) { media ->
          MediaItemCard(
            media = media,
            onClick = {
              onOpenPlayer(media.videoUrl, media.title, media.subtitle, media.relatedGameId)
            }
          )
        }
      }
    }

    // 7. Tactical Breakdown & Originals
    item {
      val originals = allMedia.filter { it.category == MediaCategory.TACTICAL_BREAKDOWN || it.category == MediaCategory.ORIGINALS }
      DscsSectionHeader(
        title = "DSCS Tactical Breakdown & Film Room",
        subtitle = "All-22 film study, scheme analysis, and originals"
      )
      LazyRow(
        contentPadding = PaddingValues(horizontal = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        items(originals) { media ->
          MediaItemCard(
            media = media,
            onClick = {
              onOpenPlayer(media.videoUrl, media.title, media.subtitle, null)
            }
          )
        }
      }
    }

    // 8. Followed Teams Quick Access
    item {
      val topTeams = sportsRepository.getAllTeams().take(8)
      DscsSectionHeader(
        title = "NFL Franchises",
        subtitle = "Team profiles, depth charts, rosters and upcoming schedules"
      )
      LazyRow(
        contentPadding = PaddingValues(horizontal = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        items(topTeams) { team ->
          TeamBadgeCard(
            team = team,
            onClick = { onOpenTeamDetail(team.id) }
          )
        }
      }
    }
  }
}

@Composable
fun HeroBroadcastPanel(
  game: Game,
  onWatchLive: () -> Unit,
  onOpenGameCentre: () -> Unit,
  onAskAi: () -> Unit
) {
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .height(340.dp)
      .testTag("hero_broadcast_panel")
  ) {
    // Stadium background image with gradient fade
    Image(
      painter = painterResource(id = R.drawable.img_hero_stadium),
      contentDescription = "Stadium Background",
      modifier = Modifier.fillMaxSize(),
      contentScale = ContentScale.Crop
    )

    // Cinematic Obsidian Gradients for 10-foot legibility
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(
          Brush.verticalGradient(
            colors = listOf(
              ObsidianBlack.copy(alpha = 0.5f),
              ObsidianBlack.copy(alpha = 0.85f),
              ObsidianBlack
            )
          )
        )
    )

    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(
          Brush.horizontalGradient(
            colors = listOf(
              ObsidianBlack.copy(alpha = 0.95f),
              ObsidianBlack.copy(alpha = 0.7f),
              Color.Transparent
            )
          )
        )
    )

    // Hero Content
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 24.dp, vertical = 20.dp),
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      // Top status badges
      Row(verticalAlignment = Alignment.CenterVertically) {
        if (game.status == GameStatus.LIVE) {
          Surface(
            color = LiveRed,
            shape = RoundedCornerShape(4.dp)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(6.dp)
                  .background(Color.White, CircleShape)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "LIVE ON DSCS",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
              )
            }
          }
          Spacer(modifier = Modifier.width(10.dp))
          Surface(
            color = ObsidianBlack.copy(alpha = 0.8f),
            shape = RoundedCornerShape(4.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder)
          ) {
            Text(
              text = "Q${game.quarter} ${game.gameClock} • ${game.downAndDistanceString}",
              color = RestrainedAmber,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
        } else {
          Surface(
            color = RestrainedAmber,
            shape = RoundedCornerShape(4.dp)
          ) {
            Text(
              text = "GAME OF THE WEEK",
              color = ObsidianBlack,
              fontSize = 11.sp,
              fontWeight = FontWeight.Black,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
        }

        Spacer(modifier = Modifier.width(12.dp))
        Text(
          text = "Authorized Broadcast • 4K HDR",
          color = SteelGrey,
          fontSize = 12.sp
        )
      }

      // Middle Matchup Title
      Column {
        Text(
          text = "${game.awayTeam.fullName} @ ${game.homeTeam.fullName}",
          color = ChalkWhite,
          fontSize = 28.sp,
          fontWeight = FontWeight.Black,
          lineHeight = 34.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "${game.headline} • ${game.stadium}",
          color = ChalkDim,
          fontSize = 14.sp,
          fontWeight = FontWeight.Medium
        )
        if (game.status == GameStatus.LIVE) {
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Score: ${game.awayTeam.abbreviation} ${game.score.awayTotal} — ${game.homeTeam.abbreviation} ${game.score.homeTotal}",
            color = RestrainedAmber,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black
          )
        }
      }

      // Action Buttons
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Button(
          onClick = onWatchLive,
          colors = ButtonDefaults.buttonColors(
            containerColor = RestrainedAmber,
            contentColor = ObsidianBlack
          ),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.testTag("hero_watch_live_btn")
        ) {
          Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (game.status == GameStatus.LIVE) "Watch Live Feed" else "Watch Preview",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
          )
        }

        OutlinedButton(
          onClick = onOpenGameCentre,
          colors = ButtonDefaults.outlinedButtonColors(contentColor = ChalkWhite),
          border = androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.testTag("hero_game_centre_btn")
        ) {
          Text(text = "Game Centre", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        }

        OutlinedButton(
          onClick = onAskAi,
          colors = ButtonDefaults.outlinedButtonColors(contentColor = ChalkWhite),
          border = androidx.compose.foundation.BorderStroke(1.dp, RestrainedAmber.copy(alpha = 0.5f)),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.testTag("hero_ask_ai_btn")
        ) {
          Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = RestrainedAmber, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = "AI Analysis", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = RestrainedAmber)
        }
      }
    }
  }
}

@Composable
fun AiPromptShortcutsBar(
  onPromptClick: (String) -> Unit
) {
  Surface(
    color = GraphiteElevated,
    shape = RoundedCornerShape(12.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder),
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 24.dp, vertical = 12.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = RestrainedAmber, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "DSCS AI Football Analyst",
          color = ChalkWhite,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "Grounded in Live Telemetry",
          color = SteelGrey,
          fontSize = 12.sp
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        val prompts = listOf(
          "Explain what just happened on that play" to "get_play_by_play",
          "Why did the offense go for it on 4th down?" to "get_fourth_down_analytics",
          "Compare both quarterbacks tonight" to "compare_players",
          "What is the difference between Cover 2 and Cover 3?" to "explain_football_rule",
          "Summarise the game so far" to "get_game_summary"
        )
        items(prompts) { (text, _) ->
          Surface(
            color = ObsidianBlack,
            shape = RoundedCornerShape(20.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder),
            modifier = Modifier.clickable { onPromptClick(text) }
          ) {
            Text(
              text = text,
              color = ChalkWhite,
              fontSize = 12.sp,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
            )
          }
        }
      }
    }
  }
}

@Composable
fun MediaItemCard(
  media: MediaAsset,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  TvFocusableCard(
    onClick = onClick,
    modifier = modifier.width(260.dp),
    testTag = "media_card_${media.id}"
  ) {
    Column {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(140.dp)
          .background(GraphiteElevated)
      ) {
        // Thumbnail placeholder banner with play icon
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.verticalGradient(
                listOf(ObsidianBlack.copy(alpha = 0.4f), ObsidianBlack.copy(alpha = 0.9f))
              )
            )
        )
        // Duration badge
        Surface(
          color = ObsidianBlack.copy(alpha = 0.85f),
          shape = RoundedCornerShape(4.dp),
          modifier = Modifier
            .align(Alignment.BottomEnd)
            .padding(8.dp)
        ) {
          Text(
            text = media.duration,
            color = ChalkWhite,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
          )
        }

        Icon(
          Icons.Default.PlayArrow,
          contentDescription = "Play",
          tint = RestrainedAmber,
          modifier = Modifier
            .size(36.dp)
            .align(Alignment.Center)
        )
      }

      Column(modifier = Modifier.padding(12.dp)) {
        Text(
          text = media.title,
          color = ChalkWhite,
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold,
          maxLines = 1
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = media.subtitle,
          color = SteelGrey,
          fontSize = 12.sp,
          maxLines = 1
        )
      }
    }
  }
}

@Composable
fun ContinueWatchingCard(
  item: WatchHistoryItem,
  onClick: () -> Unit
) {
  TvFocusableCard(
    onClick = onClick,
    modifier = Modifier.width(240.dp),
    testTag = "history_card_${item.mediaId}"
  ) {
    Column {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(110.dp)
          .background(GraphiteElevated),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = RestrainedAmber, modifier = Modifier.size(32.dp))
      }
      val progress = if (item.durationMs > 0) {
        (item.positionMs.toFloat() / item.durationMs.toFloat()).coerceIn(0.05f, 1.0f)
      } else 0.5f

      LinearProgressIndicator(
        progress = { progress },
        color = RestrainedAmber,
        trackColor = GraphiteBorder,
        modifier = Modifier.fillMaxWidth().height(3.dp)
      )

      Column(modifier = Modifier.padding(10.dp)) {
        Text(text = item.title, color = ChalkWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(text = "Resume playback", color = RestrainedAmber, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
      }
    }
  }
}

@Composable
fun TeamBadgeCard(
  team: Team,
  onClick: () -> Unit
) {
  TvFocusableCard(
    onClick = onClick,
    modifier = Modifier.width(130.dp),
    testTag = "team_badge_${team.id}"
  ) {
    Column(
      modifier = Modifier.padding(14.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Text(text = team.logoEmoji, fontSize = 28.sp)
      Spacer(modifier = Modifier.height(6.dp))
      Text(text = team.name, color = ChalkWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
      Text(text = team.recordString, color = SteelGrey, fontSize = 11.sp)
    }
  }
}
