package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MediaAsset
import com.example.data.model.MediaCategory
import com.example.data.repository.MediaCatalogProvider
import com.example.ui.components.DscsSectionHeader
import com.example.ui.components.TvFocusableCard
import com.example.ui.theme.ChalkDim
import com.example.ui.theme.ChalkWhite
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteElevated
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RestrainedAmber
import com.example.ui.theme.SteelGrey
import kotlinx.coroutines.launch

@Composable
fun HighlightsScreen(
  mediaRepository: MediaCatalogProvider,
  onOpenPlayer: (videoUrl: String, title: String, subtitle: String, gameId: String?) -> Unit,
  modifier: Modifier = Modifier
) {
  val allMedia by mediaRepository.getAllMedia().collectAsState(initial = emptyList())
  val watchlistItems by mediaRepository.getWatchlist().collectAsState(initial = emptyList())
  val scope = rememberCoroutineScope()

  var selectedCategory by remember { mutableStateOf<MediaCategory?>(null) }

  val filteredMedia = remember(allMedia, selectedCategory) {
    if (selectedCategory == null) allMedia else allMedia.filter { it.category == selectedCategory }
  }

  val watchlistIds = remember(watchlistItems) { watchlistItems.map { it.mediaId }.toSet() }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(ObsidianBlack)
      .testTag("highlights_screen")
  ) {
    DscsSectionHeader(
      title = "Video Library & Highlights",
      subtitle = "Authorized highlights, film breakdowns, game replays & originals"
    )

    // Category Selector
    LazyRow(
      contentPadding = PaddingValues(horizontal = 24.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      item {
        FilterPill(
          label = "All Videos",
          isSelected = selectedCategory == null,
          onClick = { selectedCategory = null }
        )
      }
      val categories = listOf(
        MediaCategory.TOUCHDOWNS to "Touchdowns",
        MediaCategory.HIGHLIGHTS to "Top Highlights",
        MediaCategory.TACTICAL_BREAKDOWN to "Film Room",
        MediaCategory.FULL_REPLAY to "Game Replays",
        MediaCategory.ORIGINALS to "DSCS Originals"
      )
      items(categories) { (cat, label) ->
        FilterPill(
          label = label,
          isSelected = selectedCategory == cat,
          onClick = { selectedCategory = cat }
        )
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Video Library List
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
      contentPadding = PaddingValues(bottom = 60.dp)
    ) {
      items(filteredMedia) { media ->
        val inWatchlist = watchlistIds.contains(media.id)
        VideoLibraryCard(
          media = media,
          inWatchlist = inWatchlist,
          onWatch = { onOpenPlayer(media.videoUrl, media.title, media.subtitle, media.relatedGameId) },
          onToggleWatchlist = {
            scope.launch { mediaRepository.toggleWatchlist(media) }
          }
        )
      }
    }
  }
}

@Composable
fun VideoLibraryCard(
  media: MediaAsset,
  inWatchlist: Boolean,
  onWatch: () -> Unit,
  onToggleWatchlist: () -> Unit
) {
  TvFocusableCard(
    onClick = onWatch,
    modifier = Modifier.fillMaxWidth(),
    testTag = "highlight_item_${media.id}"
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(14.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Left Thumbnail banner with play icon
      Box(
        modifier = Modifier
          .width(140.dp)
          .height(84.dp)
          .background(GraphiteElevated, RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center
      ) {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.verticalGradient(
                listOf(ObsidianBlack.copy(alpha = 0.3f), ObsidianBlack.copy(alpha = 0.8f))
              )
            )
        )
        Icon(
          Icons.Default.PlayArrow,
          contentDescription = null,
          tint = RestrainedAmber,
          modifier = Modifier.size(28.dp)
        )
        Surface(
          color = ObsidianBlack.copy(alpha = 0.85f),
          shape = RoundedCornerShape(4.dp),
          modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp)
        ) {
          Text(
            text = media.duration,
            color = ChalkWhite,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
          )
        }
      }

      Spacer(modifier = Modifier.width(14.dp))

      // Metadata
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = media.title,
          color = ChalkWhite,
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold,
          lineHeight = 18.sp,
          maxLines = 2
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "${media.subtitle} • ${media.datePublished}",
          color = SteelGrey,
          fontSize = 12.sp,
          maxLines = 1
        )
      }

      // Bookmark / Watchlist Action
      IconButton(onClick = onToggleWatchlist) {
        Icon(
          if (inWatchlist) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
          contentDescription = "Watchlist",
          tint = if (inWatchlist) RestrainedAmber else SteelGrey
        )
      }
    }
  }
}

@Composable
fun FilterPill(
  label: String,
  isSelected: Boolean,
  onClick: () -> Unit
) {
  Surface(
    color = if (isSelected) RestrainedAmber else GraphiteSurface,
    shape = RoundedCornerShape(20.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) RestrainedAmber else GraphiteBorder),
    modifier = Modifier.clickable { onClick() }
  ) {
    Text(
      text = label,
      color = if (isSelected) ObsidianBlack else ChalkWhite,
      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
      fontSize = 12.sp,
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
    )
  }
}
