package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DivisionStandings
import com.example.data.model.StandingsRow
import com.example.data.repository.SportsDataProvider
import com.example.ui.components.DscsSectionHeader
import com.example.ui.theme.ChalkDim
import com.example.ui.theme.ChalkWhite
import com.example.ui.theme.FieldGreen
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteElevated
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.LiveRed
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RestrainedAmber
import com.example.ui.theme.SteelGrey

@Composable
fun StandingsScreen(
  sportsRepository: SportsDataProvider,
  onOpenTeamDetail: (teamId: String) -> Unit,
  modifier: Modifier = Modifier
) {
  val allStandings = remember { sportsRepository.getStandings() }
  var selectedConfIndex by remember { mutableIntStateOf(0) } // 0: AFC, 1: NFC
  val confNames = listOf("AFC", "NFC")
  val currentConf = confNames[selectedConfIndex]

  val filteredDivisions = allStandings.filter { it.conference == currentConf }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(ObsidianBlack)
      .testTag("standings_screen")
  ) {
    DscsSectionHeader(
      title = "NFL Standings & Playoff Race",
      subtitle = "Division standings, point differentials, clinch clinching statuses"
    )

    // Conference Tab Switcher
    TabRow(
      selectedTabIndex = selectedConfIndex,
      containerColor = GraphiteSurface,
      contentColor = RestrainedAmber,
      indicator = { tabPositions ->
        TabRowDefaults.SecondaryIndicator(
          modifier = Modifier.tabIndicatorOffset(tabPositions[selectedConfIndex]),
          color = RestrainedAmber,
          height = 3.dp
        )
      },
      divider = { HorizontalDivider(color = GraphiteBorder) }
    ) {
      confNames.forEachIndexed { index, name ->
        Tab(
          selected = selectedConfIndex == index,
          onClick = { selectedConfIndex = index },
          text = {
            Text(
              text = "$name Conference",
              fontWeight = if (selectedConfIndex == index) FontWeight.Bold else FontWeight.Normal,
              fontSize = 14.sp
            )
          }
        )
      }
    }

    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
      contentPadding = PaddingValues(top = 16.dp, bottom = 60.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      items(filteredDivisions) { div ->
        DivisionTable(division = div, onTeamClick = onOpenTeamDetail)
      }
    }
  }
}

@Composable
fun DivisionTable(
  division: DivisionStandings,
  onTeamClick: (String) -> Unit
) {
  Surface(
    color = GraphiteSurface,
    shape = RoundedCornerShape(10.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(
        text = division.divisionName.uppercase(),
        color = RestrainedAmber,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp
      )
      Spacer(modifier = Modifier.height(10.dp))

      // Header row
      Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("TEAM", color = SteelGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(2.2f))
        Text("W", color = SteelGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.6f))
        Text("L", color = SteelGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.6f))
        Text("PCT", color = SteelGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.9f))
        Text("DIFF", color = SteelGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.9f))
        Text("STRK", color = SteelGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f))
      }

      HorizontalDivider(color = GraphiteBorder.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 6.dp))

      // Team Rows
      division.teams.forEach { row ->
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clickable { onTeamClick(row.team.id) }
            .padding(vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(modifier = Modifier.weight(2.2f), verticalAlignment = Alignment.CenterVertically) {
            Text(row.team.logoEmoji, fontSize = 18.sp)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(row.team.name, color = ChalkWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
              if (row.clinchStatus != null) {
                Text(
                  text = row.clinchStatus,
                  color = if (row.clinchStatus.startsWith("x") || row.clinchStatus.startsWith("z")) FieldGreen else LiveRed,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.SemiBold
                )
              }
            }
          }

          Text("${row.wins}", color = ChalkWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.6f))
          Text("${row.losses}", color = ChalkDim, fontSize = 13.sp, modifier = Modifier.weight(0.6f))
          Text("%.3f".format(row.winPct), color = ChalkDim, fontSize = 12.sp, modifier = Modifier.weight(0.9f))
          Text(
            text = (if (row.pointDiff > 0) "+${row.pointDiff}" else "${row.pointDiff}"),
            color = if (row.pointDiff > 0) FieldGreen else LiveRed,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(0.9f)
          )
          Text(row.streak, color = if (row.streak.startsWith("W")) FieldGreen else SteelGrey, fontSize = 12.sp, modifier = Modifier.weight(0.8f))
        }
      }
    }
  }
}
