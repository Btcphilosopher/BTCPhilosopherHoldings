package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GameStatus
import com.example.data.repository.SportsDataProvider
import com.example.ui.components.BroadcastGameCard
import com.example.ui.components.DscsSectionHeader
import com.example.ui.theme.ChalkDim
import com.example.ui.theme.ChalkWhite
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteElevated
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RestrainedAmber
import com.example.ui.theme.SteelGrey

@Composable
fun ScheduleScreen(
  sportsRepository: SportsDataProvider,
  onOpenGameCentre: (gameId: String) -> Unit,
  modifier: Modifier = Modifier
) {
  val liveGames by sportsRepository.getLiveGames().collectAsState(initial = emptyList())
  val upcomingGames by sportsRepository.getUpcomingGames().collectAsState(initial = emptyList())
  val completedGames by sportsRepository.getCompletedGames().collectAsState(initial = emptyList())

  var statusFilter by remember { mutableStateOf("ALL") } // ALL, LIVE, UPCOMING, FINAL
  var confFilter by remember { mutableStateOf("ALL") }   // ALL, AFC, NFC

  val allGames = (liveGames + upcomingGames + completedGames).filter { g ->
    val matchesStatus = when (statusFilter) {
      "LIVE" -> g.status == GameStatus.LIVE || g.status == GameStatus.HALFTIME
      "UPCOMING" -> g.status == GameStatus.UPCOMING
      "FINAL" -> g.status == GameStatus.FINAL
      else -> true
    }
    val matchesConf = when (confFilter) {
      "AFC" -> g.awayTeam.conference == "AFC" || g.homeTeam.conference == "AFC"
      "NFC" -> g.awayTeam.conference == "NFC" || g.homeTeam.conference == "NFC"
      else -> true
    }
    matchesStatus && matchesConf
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(ObsidianBlack)
      .testTag("schedule_screen")
  ) {
    DscsSectionHeader(
      title = "NFL Game Schedule & Scores",
      subtitle = "Week 14 • 2026 Season • Localized Broadcast Kickoff Times"
    )

    // Filter Chips Row
    LazyRow(
      contentPadding = PaddingValues(horizontal = 24.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      val statusOptions = listOf("ALL" to "All Status", "LIVE" to "Live Now", "UPCOMING" to "Upcoming", "FINAL" to "Final")
      items(statusOptions) { (key, label) ->
        val isSelected = statusFilter == key
        Surface(
          color = if (isSelected) RestrainedAmber else GraphiteSurface,
          shape = RoundedCornerShape(20.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) RestrainedAmber else GraphiteBorder),
          modifier = Modifier.clickable { statusFilter = key }
        ) {
          Text(
            text = label,
            color = if (isSelected) ObsidianBlack else ChalkWhite,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
          )
        }
      }

      val confOptions = listOf("ALL" to "All Conferences", "AFC" to "AFC", "NFC" to "NFC")
      items(confOptions) { (key, label) ->
        val isSelected = confFilter == key
        Surface(
          color = if (isSelected) GraphiteElevated else GraphiteSurface,
          shape = RoundedCornerShape(20.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) ChalkWhite else GraphiteBorder),
          modifier = Modifier.clickable { confFilter = key }
        ) {
          Text(
            text = label,
            color = if (isSelected) ChalkWhite else SteelGrey,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Games List
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
      contentPadding = PaddingValues(bottom = 60.dp)
    ) {
      items(allGames) { game ->
        BroadcastGameCard(
          game = game,
          onClick = { onOpenGameCentre(game.id) },
          modifier = Modifier.fillMaxWidth()
        )
      }
    }
  }
}
