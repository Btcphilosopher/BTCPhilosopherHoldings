package com.example.player

import android.content.Context
import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.example.data.model.Game
import com.example.ui.theme.ChalkWhite
import com.example.ui.theme.FieldGreen
import com.example.ui.theme.FocusBorderAmber
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.LiveRed
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RestrainedAmber
import com.example.ui.theme.SteelGrey
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
@Composable
fun NflBroadcastPlayer(
  videoUrl: String,
  title: String,
  subtitle: String,
  game: Game? = null,
  isLive: Boolean = true,
  onClose: () -> Unit,
  onOpenGameCentre: (() -> Unit)? = null,
  onToggleMultiView: (() -> Unit)? = null,
  isMultiViewActive: Boolean = false,
  secondaryVideoUrl: String? = null,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val exoPlayer = remember(videoUrl) {
    ExoPlayer.Builder(context).build().apply {
      val item = MediaItem.fromUri(Uri.parse(videoUrl))
      setMediaItem(item)
      prepare()
      playWhenReady = true
    }
  }

  // Secondary player if multi-view is enabled
  val secondaryPlayer = remember(secondaryVideoUrl, isMultiViewActive) {
    if (isMultiViewActive && secondaryVideoUrl != null) {
      ExoPlayer.Builder(context).build().apply {
        setMediaItem(MediaItem.fromUri(Uri.parse(secondaryVideoUrl)))
        prepare()
        playWhenReady = true
        volume = 0f // Muted secondary by default
      }
    } else null
  }

  var isPlaying by remember { mutableStateOf(true) }
  var isBuffering by remember { mutableStateOf(true) }
  var currentPosition by remember { mutableLongStateOf(0L) }
  var totalDuration by remember { mutableLongStateOf(0L) }
  var showControls by remember { mutableStateOf(true) }
  var activeAudioChannel by remember { mutableStateOf(1) } // 1: Main, 2: Secondary
  var subtitlesEnabled by remember { mutableStateOf(true) }
  var showLiveStatsOverlay by remember { mutableStateOf(false) }

  // Auto-hide controls after inactivity
  LaunchedEffect(showControls) {
    if (showControls) {
      delay(5000)
      showControls = false
    }
  }

  // Position tracking loop
  LaunchedEffect(exoPlayer) {
    while (true) {
      currentPosition = exoPlayer.currentPosition
      totalDuration = if (exoPlayer.duration > 0) exoPlayer.duration else 1000L
      isPlaying = exoPlayer.isPlaying
      isBuffering = exoPlayer.playbackState == Player.STATE_BUFFERING
      delay(500)
    }
  }

  DisposableEffect(exoPlayer, secondaryPlayer) {
    onDispose {
      exoPlayer.release()
      secondaryPlayer?.release()
    }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(ObsidianBlack)
      .clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null
      ) {
        showControls = !showControls
      }
      .testTag("nfl_broadcast_player_box")
  ) {
    if (isMultiViewActive && secondaryPlayer != null) {
      // Split Screen / Multi-Game layout
      Row(modifier = Modifier.fillMaxSize()) {
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxSize()
            .border(
              width = if (activeAudioChannel == 1) 2.dp else 1.dp,
              color = if (activeAudioChannel == 1) RestrainedAmber else GraphiteBorder
            )
            .clickable {
              activeAudioChannel = 1
              exoPlayer.volume = 1f
              secondaryPlayer.volume = 0f
            }
        ) {
          AndroidView(
            factory = { ctx ->
              PlayerView(ctx).apply {
                player = exoPlayer
                useController = false
                layoutParams = FrameLayout.LayoutParams(
                  ViewGroup.LayoutParams.MATCH_PARENT,
                  ViewGroup.LayoutParams.MATCH_PARENT
                )
              }
            },
            modifier = Modifier.fillMaxSize()
          )
          // Channel 1 tag
          Surface(
            color = ObsidianBlack.copy(alpha = 0.8f),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.padding(12.dp).align(Alignment.TopStart)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "FEED 1 • CHIEFS VS 49ERS",
                fontSize = 12.sp,
                color = if (activeAudioChannel == 1) RestrainedAmber else ChalkWhite,
                fontWeight = FontWeight.Bold
              )
              if (activeAudioChannel == 1) {
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                  Icons.Default.VolumeUp,
                  contentDescription = "Audio Active",
                  tint = RestrainedAmber,
                  modifier = Modifier.size(14.dp)
                )
              }
            }
          }
        }

        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxSize()
            .border(
              width = if (activeAudioChannel == 2) 2.dp else 1.dp,
              color = if (activeAudioChannel == 2) RestrainedAmber else GraphiteBorder
            )
            .clickable {
              activeAudioChannel = 2
              exoPlayer.volume = 0f
              secondaryPlayer.volume = 1f
            }
        ) {
          AndroidView(
            factory = { ctx ->
              PlayerView(ctx).apply {
                player = secondaryPlayer
                useController = false
                layoutParams = FrameLayout.LayoutParams(
                  ViewGroup.LayoutParams.MATCH_PARENT,
                  ViewGroup.LayoutParams.MATCH_PARENT
                )
              }
            },
            modifier = Modifier.fillMaxSize()
          )
          // Channel 2 tag
          Surface(
            color = ObsidianBlack.copy(alpha = 0.8f),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.padding(12.dp).align(Alignment.TopStart)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "FEED 2 • RAVENS AT LIONS",
                fontSize = 12.sp,
                color = if (activeAudioChannel == 2) RestrainedAmber else ChalkWhite,
                fontWeight = FontWeight.Bold
              )
              if (activeAudioChannel == 2) {
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                  Icons.Default.VolumeUp,
                  contentDescription = "Audio Active",
                  tint = RestrainedAmber,
                  modifier = Modifier.size(14.dp)
                )
              }
            }
          }
        }
      }
    } else {
      // Single Screen Playback
      AndroidView(
        factory = { ctx ->
          PlayerView(ctx).apply {
            player = exoPlayer
            useController = false
            layoutParams = FrameLayout.LayoutParams(
              ViewGroup.LayoutParams.MATCH_PARENT,
              ViewGroup.LayoutParams.MATCH_PARENT
            )
          }
        },
        modifier = Modifier.fillMaxSize()
      )
    }

    // Buffering indicator
    if (isBuffering) {
      CircularProgressIndicator(
        color = RestrainedAmber,
        strokeWidth = 3.dp,
        modifier = Modifier
          .size(48.dp)
          .align(Alignment.Center)
      )
    }

    // Broadcast HUD Overlay (Top & Bottom gradients)
    AnimatedVisibility(
      visible = showControls,
      enter = fadeIn(),
      exit = fadeOut(),
      modifier = Modifier.fillMaxSize()
    ) {
      Box(modifier = Modifier.fillMaxSize()) {
        // Top Broadcast Header
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .align(Alignment.TopCenter)
            .background(
              Brush.verticalGradient(
                colors = listOf(
                  ObsidianBlack.copy(alpha = 0.95f),
                  ObsidianBlack.copy(alpha = 0.6f),
                  Color.Transparent
                )
              )
            )
            .padding(16.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              IconButton(
                onClick = onClose,
                modifier = Modifier
                  .size(44.dp)
                  .background(GraphiteSurface.copy(alpha = 0.8f), CircleShape)
                  .testTag("player_close_button")
              ) {
                Icon(
                  Icons.Default.Close,
                  contentDescription = "Close Broadcast",
                  tint = ChalkWhite
                )
              }
              Spacer(modifier = Modifier.width(16.dp))
              Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  if (isLive) {
                    Box(
                      modifier = Modifier
                        .size(8.dp)
                        .background(LiveRed, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = "LIVE BROADCAST",
                      color = LiveRed,
                      fontWeight = FontWeight.Bold,
                      fontSize = 12.sp,
                      letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                      text = "4K ULTRA HD HDR",
                      color = SteelGrey,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.SemiBold
                    )
                  } else {
                    Text(
                      text = "ON DEMAND",
                      color = RestrainedAmber,
                      fontWeight = FontWeight.Bold,
                      fontSize = 12.sp
                    )
                  }
                }
                Text(
                  text = title,
                  color = ChalkWhite,
                  fontSize = 18.sp,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = subtitle,
                  color = SteelGrey,
                  fontSize = 13.sp
                )
              }
            }

            // Top action buttons
            Row(verticalAlignment = Alignment.CenterVertically) {
              if (onToggleMultiView != null) {
                PlayerControlButton(
                  icon = Icons.Default.GridView,
                  label = if (isMultiViewActive) "Single View" else "Multi-Game (2x)",
                  isActive = isMultiViewActive,
                  onClick = onToggleMultiView
                )
                Spacer(modifier = Modifier.width(8.dp))
              }

              PlayerControlButton(
                icon = Icons.Default.GraphicEq,
                label = "Telemetry",
                isActive = showLiveStatsOverlay,
                onClick = { showLiveStatsOverlay = !showLiveStatsOverlay }
              )
              Spacer(modifier = Modifier.width(8.dp))

              PlayerControlButton(
                icon = Icons.Default.Subtitles,
                label = "CC",
                isActive = subtitlesEnabled,
                onClick = { subtitlesEnabled = !subtitlesEnabled }
              )
            }
          }
        }

        // Live Telemetry Mini-Overlay (if toggled)
        if (showLiveStatsOverlay && game != null) {
          Surface(
            color = ObsidianBlack.copy(alpha = 0.9f),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder),
            modifier = Modifier
              .padding(top = 90.dp, end = 24.dp)
              .width(280.dp)
              .align(Alignment.TopEnd)
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text(
                text = "LIVE IN-GAME TELEMETRY",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = RestrainedAmber,
                letterSpacing = 1.sp
              )
              Spacer(modifier = Modifier.height(10.dp))
              TelemetryRow("Situation", game.downAndDistanceString)
              TelemetryRow("Quarter / Clock", "Q${game.quarter} ${game.gameClock}")
              TelemetryRow("Win Probability", "${game.homeTeam.name} ${(game.homeWinProbability * 100).toInt()}%")
              TelemetryRow("Venue", game.stadium)
              TelemetryRow("Weather", game.weatherCondition)
            }
          }
        }

        // Bottom Broadcast Controls & Score Bug
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .align(Alignment.BottomCenter)
            .background(
              Brush.verticalGradient(
                colors = listOf(
                  Color.Transparent,
                  ObsidianBlack.copy(alpha = 0.7f),
                  ObsidianBlack.copy(alpha = 0.98f)
                )
              )
            )
            .padding(20.dp)
        ) {
          Column {
            // Live Scorebug & Down/Distance Bar
            if (game != null) {
              Surface(
                color = GraphiteSurface.copy(alpha = 0.95f),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder),
                modifier = Modifier
                  .align(Alignment.CenterHorizontally)
                  .padding(bottom = 14.dp)
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  // Away Team
                  Text(
                    text = "${game.awayTeam.abbreviation} ${game.score.awayTotal}",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    color = ChalkWhite
                  )
                  Spacer(modifier = Modifier.width(12.dp))
                  Text(text = "vs", fontSize = 12.sp, color = SteelGrey)
                  Spacer(modifier = Modifier.width(12.dp))
                  // Home Team
                  Text(
                    text = "${game.homeTeam.abbreviation} ${game.score.homeTotal}",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    color = ChalkWhite
                  )
                  Spacer(modifier = Modifier.width(16.dp))
                  Box(
                    modifier = Modifier
                      .width(1.dp)
                      .height(20.dp)
                      .background(GraphiteBorder)
                  )
                  Spacer(modifier = Modifier.width(16.dp))
                  Text(
                    text = "Q${game.quarter} ${game.gameClock}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = RestrainedAmber
                  )
                  if (game.downAndDistanceString.isNotBlank()) {
                    Spacer(modifier = Modifier.width(12.dp))
                    Surface(
                      color = FieldGreen.copy(alpha = 0.2f),
                      shape = RoundedCornerShape(4.dp)
                    ) {
                      Text(
                        text = game.downAndDistanceString,
                        color = FieldGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                      )
                    }
                  }
                }
              }
            }

            // Timeline Scrubbing for VOD/Highlights
            if (!isLive && totalDuration > 0) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = formatTime(currentPosition),
                  color = SteelGrey,
                  fontSize = 12.sp
                )
                Slider(
                  value = (currentPosition.toFloat() / totalDuration.toFloat()).coerceIn(0f, 1f),
                  onValueChange = { frac ->
                    val targetMs = (frac * totalDuration).toLong()
                    exoPlayer.seekTo(targetMs)
                  },
                  colors = SliderDefaults.colors(
                    thumbColor = RestrainedAmber,
                    activeTrackColor = RestrainedAmber,
                    inactiveTrackColor = GraphiteBorder
                  ),
                  modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp)
                )
                Text(
                  text = formatTime(totalDuration),
                  color = SteelGrey,
                  fontSize = 12.sp
                )
              }
            }

            // Playback Buttons Bar
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                // Seek -10s
                IconButton(
                  onClick = { exoPlayer.seekTo((exoPlayer.currentPosition - 10000).coerceAtLeast(0)) },
                  modifier = Modifier.size(44.dp)
                ) {
                  Icon(Icons.Default.Replay10, contentDescription = "Back 10s", tint = ChalkWhite)
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Play / Pause
                IconButton(
                  onClick = {
                    if (exoPlayer.isPlaying) {
                      exoPlayer.pause()
                    } else {
                      exoPlayer.play()
                    }
                  },
                  modifier = Modifier
                    .size(54.dp)
                    .background(RestrainedAmber, CircleShape)
                    .testTag("play_pause_button")
                ) {
                  Icon(
                    if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    tint = ObsidianBlack,
                    modifier = Modifier.size(28.dp)
                  )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Seek +10s
                IconButton(
                  onClick = { exoPlayer.seekTo((exoPlayer.currentPosition + 10000).coerceAtMost(exoPlayer.duration)) },
                  modifier = Modifier.size(44.dp)
                ) {
                  Icon(Icons.Default.Forward10, contentDescription = "Forward 10s", tint = ChalkWhite)
                }

                if (isLive) {
                  Spacer(modifier = Modifier.width(16.dp))
                  Surface(
                    color = LiveRed.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(4.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, LiveRed.copy(alpha = 0.5f))
                  ) {
                    Text(
                      text = "SYNCED TO LIVE EDGE",
                      color = LiveRed,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                  }
                }
              }

              // Game Centre quick button
              if (onOpenGameCentre != null) {
                Surface(
                  color = GraphiteElevatedButtonColor(),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier
                    .clickable { onOpenGameCentre() }
                    .testTag("open_game_centre_btn")
                ) {
                  Text(
                    text = "Open Game Centre ➔",
                    color = RestrainedAmber,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun GraphiteElevatedButtonColor(): Color = GraphiteBorder

@Composable
private fun PlayerControlButton(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String,
  isActive: Boolean,
  onClick: () -> Unit
) {
  val interactionSource = remember { MutableInteractionSource() }
  val isFocused by interactionSource.collectIsFocusedAsState()

  Surface(
    color = if (isActive) RestrainedAmber.copy(alpha = 0.2f) else GraphiteSurface.copy(alpha = 0.8f),
    shape = RoundedCornerShape(6.dp),
    border = androidx.compose.foundation.BorderStroke(
      width = if (isFocused) 2.dp else 1.dp,
      color = if (isFocused) FocusBorderAmber else if (isActive) RestrainedAmber else GraphiteBorder
    ),
    modifier = Modifier
      .clickable(interactionSource = interactionSource, indication = null) { onClick() }
      .focusable(interactionSource = interactionSource)
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        icon,
        contentDescription = label,
        tint = if (isActive) RestrainedAmber else ChalkWhite,
        modifier = Modifier.size(16.dp)
      )
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = label,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        color = if (isActive) RestrainedAmber else ChalkWhite
      )
    }
  }
}

@Composable
private fun TelemetryRow(label: String, value: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(text = label, color = SteelGrey, fontSize = 12.sp)
    Text(text = value, color = ChalkWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
  }
}

private fun formatTime(ms: Long): String {
  val totalSec = (ms / 1000).toInt()
  val m = totalSec / 60
  val s = totalSec % 60
  return "%02d:%02d".format(m, s)
}
