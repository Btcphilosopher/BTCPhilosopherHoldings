package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.AiAssistantRepository
import com.example.data.repository.ChatMessage
import com.example.data.repository.MessageSender
import com.example.ui.components.DscsSectionHeader
import com.example.ui.theme.ChalkDim
import com.example.ui.theme.ChalkWhite
import com.example.ui.theme.FieldGreen
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteElevated
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.LiveRed
import com.example.ui.theme.MutedBlue
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RestrainedAmber
import com.example.ui.theme.SteelGrey

@Composable
fun AiAssistantScreen(
  aiRepository: AiAssistantRepository,
  currentGameId: String? = "game_kc_sf",
  onOpenHighlight: ((mediaId: String) -> Unit)? = null,
  modifier: Modifier = Modifier
) {
  val messages by aiRepository.messages.collectAsState()
  var inputQuery by remember { mutableStateOf("") }
  var isVoiceListening by remember { mutableStateOf(false) }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(ObsidianBlack)
      .testTag("ai_assistant_screen")
  ) {
    // Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 24.dp, vertical = 12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          Icons.Default.AutoAwesome,
          contentDescription = null,
          tint = RestrainedAmber,
          modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = "DSCS AI Football Analyst",
            color = ChalkWhite,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "Grounded in Live Telemetry & NFL Rulebook",
            color = SteelGrey,
            fontSize = 11.sp
          )
        }
      }

      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(
          onClick = { isVoiceListening = !isVoiceListening },
          modifier = Modifier.testTag("ai_voice_btn")
        ) {
          Icon(
            if (isVoiceListening) Icons.Default.Mic else Icons.Default.MicOff,
            contentDescription = "Voice Input",
            tint = if (isVoiceListening) LiveRed else SteelGrey
          )
        }
        IconButton(
          onClick = { aiRepository.clearChat() },
          modifier = Modifier.testTag("ai_clear_chat_btn")
        ) {
          Icon(Icons.Default.DeleteSweep, contentDescription = "Clear Chat", tint = SteelGrey)
        }
      }
    }

    // Voice indicator banner if listening
    if (isVoiceListening) {
      Surface(
        color = LiveRed.copy(alpha = 0.2f),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 4.dp),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, LiveRed)
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(modifier = Modifier.size(8.dp).background(LiveRed, CircleShape))
          Spacer(modifier = Modifier.width(8.dp))
          Text("Microphone active — Listening for football questions...", color = ChalkWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
      }
    }

    // Suggested Questions Chips Row
    val promptChips = listOf(
      "Explain what just happened on that play",
      "Why did the offense go for it on 4th down?",
      "Compare both quarterbacks tonight",
      "What is the difference between Cover 2 and Cover 3?",
      "Show me every touchdown from this game",
      "Summarise the game so far",
      "Which team has been more effective on third down?",
      "Explain the playoff implications of this result"
    )

    LazyRow(
      contentPadding = PaddingValues(horizontal = 24.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(promptChips) { chipText ->
        Surface(
          color = GraphiteSurface,
          shape = RoundedCornerShape(20.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder),
          modifier = Modifier.clickable {
            aiRepository.askQuestion(chipText, currentGameId)
          }
        ) {
          Text(
            text = chipText,
            color = ChalkDim,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
          )
        }
      }
    }

    // Message History List
    LazyColumn(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .padding(horizontal = 20.dp),
      contentPadding = PaddingValues(vertical = 12.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      items(messages) { msg ->
        ChatMessageBubble(
          message = msg,
          onOpenHighlight = onOpenHighlight
        )
      }
    }

    // Input Bar
    Surface(
      color = GraphiteSurface,
      modifier = Modifier.fillMaxWidth(),
      border = androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder)
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedTextField(
          value = inputQuery,
          onValueChange = { inputQuery = it },
          placeholder = { Text("Ask about plays, coverage schemes, 4th down decisions...", color = SteelGrey, fontSize = 13.sp) },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = RestrainedAmber,
            unfocusedBorderColor = GraphiteBorder,
            focusedTextColor = ChalkWhite,
            unfocusedTextColor = ChalkWhite
          ),
          modifier = Modifier.weight(1f).testTag("ai_input_text_field"),
          shape = RoundedCornerShape(24.dp),
          singleLine = true
        )

        Spacer(modifier = Modifier.width(8.dp))

        IconButton(
          onClick = {
            if (inputQuery.isNotBlank()) {
              aiRepository.askQuestion(inputQuery.trim(), currentGameId)
              inputQuery = ""
            }
          },
          modifier = Modifier
            .background(RestrainedAmber, CircleShape)
            .size(44.dp)
            .testTag("ai_send_btn")
        ) {
          Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = ObsidianBlack, modifier = Modifier.size(18.dp))
        }
      }
    }
  }
}

@Composable
fun ChatMessageBubble(
  message: ChatMessage,
  onOpenHighlight: ((mediaId: String) -> Unit)?
) {
  val isUser = message.sender == MessageSender.USER
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
  ) {
    if (!isUser) {
      Surface(
        color = RestrainedAmber.copy(alpha = 0.15f),
        shape = CircleShape,
        modifier = Modifier.size(32.dp).padding(top = 4.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = RestrainedAmber, modifier = Modifier.size(16.dp))
        }
      }
      Spacer(modifier = Modifier.width(8.dp))
    }

    Card(
      colors = CardDefaults.cardColors(
        containerColor = if (isUser) RestrainedAmber else GraphiteElevated
      ),
      shape = RoundedCornerShape(12.dp),
      border = if (isUser) null else androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder),
      modifier = Modifier.widthIn(max = 340.dp)
    ) {
      Column(modifier = Modifier.padding(12.dp)) {
        if (!isUser && message.toolUsed != null) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              color = ObsidianBlack.copy(alpha = 0.6f),
              shape = RoundedCornerShape(4.dp)
            ) {
              Text(
                text = "TOOL: ${message.toolUsed.uppercase()}",
                color = RestrainedAmber,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
              )
            }
          }
          Spacer(modifier = Modifier.height(6.dp))
        }

        Text(
          text = message.text,
          color = if (isUser) ObsidianBlack else ChalkWhite,
          fontSize = 13.sp,
          lineHeight = 18.sp,
          fontWeight = if (isUser) FontWeight.SemiBold else FontWeight.Normal
        )

        // Highlight link card inside AI message
        if (message.relatedHighlightId != null && onOpenHighlight != null) {
          Spacer(modifier = Modifier.height(10.dp))
          Surface(
            color = ObsidianBlack.copy(alpha = 0.8f),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { onOpenHighlight(message.relatedHighlightId) }
          ) {
            Row(
              modifier = Modifier.padding(8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.PlayCircle, contentDescription = null, tint = RestrainedAmber, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text("Watch Verified Replay Clip ➔", color = RestrainedAmber, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          }
        }

        if (!isUser && message.sourceAttribution != null) {
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = message.sourceAttribution,
            color = SteelGrey,
            fontSize = 10.sp
          )
        }
      }
    }
  }
}
