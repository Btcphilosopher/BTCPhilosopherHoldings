package com.example.data.repository

import com.example.data.model.DivisionStandings
import com.example.data.model.Drive
import com.example.data.model.Game
import com.example.data.model.GameStatistics
import com.example.data.model.GameStatus
import com.example.data.model.Play
import com.example.data.model.Player
import com.example.data.model.PlayerGameStat
import com.example.data.model.Score
import com.example.data.model.StandingsRow
import com.example.data.model.Team
import com.example.data.model.TeamGameStats
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

interface SportsDataProvider {
  fun getLiveGames(): Flow<List<Game>>
  fun getUpcomingGames(): Flow<List<Game>>
  fun getCompletedGames(): Flow<List<Game>>
  fun getGameById(id: String): Game?
  fun getPlayByPlay(gameId: String): List<Play>
  fun getDrives(gameId: String): List<Drive>
  fun getGameStatistics(gameId: String): GameStatistics?
  fun getPlayerStats(gameId: String): List<PlayerGameStat>
  fun getAllTeams(): List<Team>
  fun getTeamById(teamId: String): Team?
  fun getStandings(): List<DivisionStandings>
  fun getPlayersForTeam(teamId: String): List<Player>
  fun getPlayerById(playerId: String): Player?
}

class SportsDataRepository : SportsDataProvider {

  // 32 NFL Teams with real franchise data, primary/secondary colors
  private val teamsList = listOf(
    Team("KC", "Chiefs", "Kansas City", "KC", "AFC", "West", 11, 2, 0, 0xFFE31837, 0xFFFFB81C, "GEHA Field at Arrowhead Stadium", "🏹"),
    Team("SF", "49ers", "San Francisco", "SF", "NFC", "West", 10, 3, 0, 0xFFAA0000, 0xFFB3995D, "Levi's Stadium", "⛏️"),
    Team("BAL", "Ravens", "Baltimore", "BAL", "AFC", "North", 10, 3, 0, 0xFF241773, 0xFF000000, "M&T Bank Stadium", "🐦"),
    Team("DET", "Lions", "Detroit", "DET", "NFC", "North", 11, 2, 0, 0xFF0076B6, 0xFFB0B7BC, "Ford Field", "🦁"),
    Team("BUF", "Bills", "Buffalo", "BUF", "AFC", "East", 9, 4, 0, 0xFF00338D, 0xFFC60C30, "Highmark Stadium", "🦬"),
    Team("PHI", "Eagles", "Philadelphia", "PHI", "NFC", "East", 10, 3, 0, 0xFF004C54, 0xFFA5ACAF, "Lincoln Financial Field", "🦅"),
    Team("HOU", "Texans", "Houston", "HOU", "AFC", "South", 8, 5, 0, 0xFF03202F, 0xFFA71930, "NRG Stadium", "🐂"),
    Team("GB", "Packers", "Green Bay", "GB", "NFC", "North", 9, 4, 0, 0xFF203731, 0xFFFFB612, "Lambeau Field", "🧀"),
    Team("MIA", "Dolphins", "Miami", "MIA", "AFC", "East", 8, 5, 0, 0xFF008E97, 0xFFFC4C02, "Hard Rock Stadium", "🐬"),
    Team("DAL", "Cowboys", "Dallas", "DAL", "NFC", "East", 7, 6, 0, 0xFF041E42, 0xFF869397, "AT&T Stadium", "⭐"),
    Team("CIN", "Bengals", "Cincinnati", "CIN", "AFC", "North", 7, 6, 0, 0xFFFB4F14, 0xFF000000, "Paycor Stadium", "🐅"),
    Team("MIN", "Vikings", "Minnesota", "MIN", "NFC", "North", 9, 4, 0, 0xFF4F2683, 0xFFFFC62F, "U.S. Bank Stadium", "🛡️"),
    Team("PIT", "Steelers", "Pittsburgh", "PIT", "AFC", "North", 8, 5, 0, 0xFFFFB612, 0xFF101820, "Acrisure Stadium", "⚙️"),
    Team("TB", "Buccaneers", "Tampa Bay", "TB", "NFC", "South", 7, 6, 0, 0xFFD3BC8D, 0xFFD50A0A, "Raymond James Stadium", "🏴‍☠️"),
    Team("LAC", "Chargers", "Los Angeles", "LAC", "AFC", "West", 7, 6, 0, 0xFF0080C6, 0xFFFFC20E, "SoFi Stadium", "⚡"),
    Team("LAR", "Rams", "Los Angeles", "LAR", "NFC", "West", 7, 6, 0, 0xFF003594, 0xFFFFA300, "SoFi Stadium", "🐏"),
    Team("SEA", "Seahawks", "Seattle", "SEA", "NFC", "West", 7, 6, 0, 0xFF002244, 0xFF69BE28, "Lumen Field", "🦅"),
    Team("DEN", "Broncos", "Denver", "DEN", "AFC", "West", 7, 6, 0, 0xFFFB4F14, 0xFF002244, "Empower Field at Mile High", "🐎"),
    Team("ATL", "Falcons", "Atlanta", "ATL", "NFC", "South", 6, 7, 0, 0xFFA71930, 0xFF000000, "Mercedes-Benz Stadium", "🦅"),
    Team("IND", "Colts", "Indianapolis", "IND", "AFC", "South", 6, 7, 0, 0xFF002C5F, 0xFFA2AAAD, "Lucas Oil Stadium", "🐎"),
    Team("WAS", "Commanders", "Washington", "WAS", "NFC", "East", 8, 5, 0, 0xFF5A1414, 0xFFFFB612, "Northwest Stadium", "🎖️"),
    Team("ARI", "Cardinals", "Arizona", "ARI", "NFC", "West", 6, 7, 0, 0xFF97233F, 0xFF000000, "State Farm Stadium", "🐦"),
    Team("JAX", "Jaguars", "Jacksonville", "JAX", "AFC", "South", 4, 9, 0, 0xFF006778, 0xFFD7A22A, "EverBank Stadium", "🐆"),
    Team("NYJ", "Jets", "New York", "NYJ", "AFC", "East", 4, 9, 0, 0xFF125740, 0xFF000000, "MetLife Stadium", "✈️"),
    Team("NO", "Saints", "New Orleans", "NO", "NFC", "South", 4, 9, 0, 0xFFD3BC8D, 0xFF101820, "Caesars Superdome", "⚜️"),
    Team("CHI", "Bears", "Chicago", "CHI", "NFC", "North", 4, 9, 0, 0xFF0B162A, 0xFFC83803, "Soldier Field", "🐻"),
    Team("CLE", "Browns", "Cleveland", "CLE", "AFC", "North", 3, 10, 0, 0xFF311D00, 0xFFFF3C00, "Huntington Bank Field", "🟤"),
    Team("LV", "Raiders", "Las Vegas", "LV", "AFC", "West", 3, 10, 0, 0xFF000000, 0xFFA5ACAF, "Allegiant Stadium", "🏴‍☠️"),
    Team("TEN", "Titans", "Tennessee", "TEN", "AFC", "South", 3, 10, 0, 0xFF0C2340, 0xFF4B92DB, "Nissan Stadium", "⚔️"),
    Team("CAR", "Panthers", "Carolina", "CAR", "NFC", "South", 3, 10, 0, 0xFF0085CA, 0xFF101820, "Bank of America Stadium", "🐆"),
    Team("NE", "Patriots", "New England", "NE", "AFC", "East", 3, 10, 0, 0xFF002244, 0xFFC60C30, "Gillette Stadium", "🎖️"),
    Team("NYG", "Giants", "New York", "NYG", "NFC", "East", 2, 11, 0, 0xFF0B2265, 0xFFA71930, "MetLife Stadium", "🗽")
  )

  private val teamsMap = teamsList.associateBy { it.id }

  private val liveGamesFlow = MutableStateFlow(
    listOf(
      Game(
        id = "game_kc_sf",
        awayTeam = teamsMap["SF"]!!,
        homeTeam = teamsMap["KC"]!!,
        status = GameStatus.LIVE,
        score = Score(listOf(7, 10, 3, 7), listOf(3, 14, 7, 7)),
        quarter = 4,
        gameClock = "03:42",
        down = 3,
        distance = 4,
        yardLine = "SF 38",
        possessionTeamId = "KC",
        stadium = "GEHA Field at Arrowhead Stadium",
        kickoffTime = "8:20 PM ET",
        broadcastNetwork = "DSCS LIVE 4K HDR",
        streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
        headline = "Super Bowl Rematch: Mahomes on 4th Quarter March",
        weatherCondition = "44°F Crisp Winds 9 mph",
        awayWinProbability = 0.44f,
        homeWinProbability = 0.56f
      ),
      Game(
        id = "game_bal_det",
        awayTeam = teamsMap["BAL"]!!,
        homeTeam = teamsMap["DET"]!!,
        status = GameStatus.LIVE,
        score = Score(listOf(7, 7, 7, 0), listOf(10, 7, 3, 0)),
        quarter = 3,
        gameClock = "08:15",
        down = 2,
        distance = 8,
        yardLine = "DET 42",
        possessionTeamId = "BAL",
        stadium = "Ford Field",
        kickoffTime = "4:25 PM ET",
        broadcastNetwork = "DSCS MULTIVIEW",
        streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
        headline = "High-Powered Clash in Motor City",
        weatherCondition = "Indoors / Controlled 72°F",
        awayWinProbability = 0.51f,
        homeWinProbability = 0.49f
      ),
      Game(
        id = "game_buf_phi",
        awayTeam = teamsMap["BUF"]!!,
        homeTeam = teamsMap["PHI"]!!,
        status = GameStatus.HALFTIME,
        score = Score(listOf(7, 10, 0, 0), listOf(10, 7, 0, 0)),
        quarter = 2,
        gameClock = "00:00",
        down = 1,
        distance = 10,
        yardLine = "PHI 25",
        possessionTeamId = "PHI",
        stadium = "Lincoln Financial Field",
        kickoffTime = "4:05 PM ET",
        broadcastNetwork = "DSCS PRO SPORTS",
        streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
        headline = "All-Pro Battle in the Rain",
        weatherCondition = "50°F Light Rain",
        awayWinProbability = 0.49f,
        homeWinProbability = 0.51f
      )
    )
  )

  private val upcomingGamesFlow = MutableStateFlow(
    listOf(
      Game(
        id = "game_hou_dal",
        awayTeam = teamsMap["HOU"]!!,
        homeTeam = teamsMap["DAL"]!!,
        status = GameStatus.UPCOMING,
        score = Score(),
        stadium = "AT&T Stadium",
        kickoffTime = "Sun 8:15 PM ET",
        broadcastNetwork = "DSCS PRIMETIME",
        headline = "Texas Governor's Cup Showcase",
        weatherCondition = "Indoors",
        awayWinProbability = 0.54f,
        homeWinProbability = 0.46f
      ),
      Game(
        id = "game_gb_min",
        awayTeam = teamsMap["GB"]!!,
        homeTeam = teamsMap["MIN"]!!,
        status = GameStatus.UPCOMING,
        score = Score(),
        stadium = "U.S. Bank Stadium",
        kickoffTime = "Sun 1:00 PM ET",
        broadcastNetwork = "DSCS NORTH",
        headline = "NFC North Title Stakes",
        weatherCondition = "Indoors",
        awayWinProbability = 0.50f,
        homeWinProbability = 0.50f
      ),
      Game(
        id = "game_mia_nyj",
        awayTeam = teamsMap["MIA"]!!,
        homeTeam = teamsMap["NYJ"]!!,
        status = GameStatus.UPCOMING,
        score = Score(),
        stadium = "MetLife Stadium",
        kickoffTime = "Sun 1:00 PM ET",
        broadcastNetwork = "DSCS EAST",
        headline = "AFC East Rivalry Under New York Lights",
        weatherCondition = "55°F Partly Cloudy",
        awayWinProbability = 0.58f,
        homeWinProbability = 0.42f
      )
    )
  )

  private val completedGamesFlow = MutableStateFlow(
    listOf(
      Game(
        id = "game_cin_pit",
        awayTeam = teamsMap["CIN"]!!,
        homeTeam = teamsMap["PIT"]!!,
        status = GameStatus.FINAL,
        score = Score(listOf(7, 10, 7, 7), listOf(3, 7, 7, 10)),
        quarter = 4,
        gameClock = "00:00",
        stadium = "Acrisure Stadium",
        kickoffTime = "Thu 8:15 PM ET",
        broadcastNetwork = "DSCS REPLAY",
        headline = "Burrow Tosses 3 TDs in AFC North Thriller",
        weatherCondition = "38°F Chilly",
        awayWinProbability = 1.0f,
        homeWinProbability = 0.0f
      )
    )
  )

  private val playsDb = mapOf(
    "game_kc_sf" to listOf(
      Play(
        id = "p1",
        gameId = "game_kc_sf",
        quarter = 4,
        clock = "04:18",
        down = 2,
        distance = 11,
        yardLine = "SF 45",
        description = "P. Mahomes pass deep left to T. Kelce for 21 yards to the SF 24. Pushed out of bounds.",
        yardsGained = 21,
        possessionTeamAbbreviation = "KC",
        keyPlayerName = "Patrick Mahomes",
        aiInsight = "Chiefs exploited Cover-3 seam void using twin-tight-end bunch look."
      ),
      Play(
        id = "p2",
        gameId = "game_kc_sf",
        quarter = 4,
        clock = "03:42",
        down = 3,
        distance = 4,
        yardLine = "SF 38",
        description = "I. Pacheco rush up the middle for 6 yards, FIRST DOWN. Tackled by F. Warner.",
        yardsGained = 6,
        possessionTeamAbbreviation = "KC",
        keyPlayerName = "Isiah Pacheco",
        aiInsight = "Heavy 12-personnel trap block opened interior A-gap against 4-3 under front."
      ),
      Play(
        id = "p3",
        gameId = "game_kc_sf",
        quarter = 4,
        clock = "05:52",
        down = 3,
        distance = 8,
        yardLine = "SF 28",
        description = "B. Purdy pass short right to C. McCaffrey for 12 yards, TOUCHDOWN 49ers! J. Moody extra point GOOD.",
        yardsGained = 12,
        isScoringPlay = true,
        possessionTeamAbbreviation = "SF",
        keyPlayerName = "Christian McCaffrey",
        aiInsight = "Wheel route out of backfield matched against linebacker in single-high man coverage."
      ),
      Play(
        id = "p4",
        gameId = "game_kc_sf",
        quarter = 3,
        clock = "01:14",
        down = 1,
        distance = 10,
        yardLine = "SF 20",
        description = "P. Mahomes pass deep middle to X. Worthy for 48 yards, TOUCHDOWN Chiefs! H. Butker kick GOOD.",
        yardsGained = 48,
        isScoringPlay = true,
        possessionTeamAbbreviation = "KC",
        keyPlayerName = "Xavier Worthy",
        aiInsight = "Post-corner double move burned free safety with 4.21 vertical separation."
      ),
      Play(
        id = "p5",
        gameId = "game_kc_sf",
        quarter = 2,
        clock = "08:30",
        down = 3,
        distance = 14,
        yardLine = "KC 31",
        description = "B. Purdy pass intercepted by T. McDuffie at the KC 18, returned 15 yards to KC 33.",
        yardsGained = 0,
        isTurnover = true,
        possessionTeamAbbreviation = "SF",
        keyPlayerName = "Trent McDuffie",
        aiInsight = "Disguised inverted cover-2 trap caused quarterback to underthrow deep boundary out."
      )
    )
  )

  private val drivesDb = mapOf(
    "game_kc_sf" to listOf(
      Drive("d1", "game_kc_sf", "KC", 7, 4, "KC 25", "SF 18", 9, 57, "4:15", "Active Drive", false),
      Drive("d2", "game_kc_sf", "SF", 6, 4, "SF 20", "Endzone", 8, 80, "3:58", "Touchdown", true),
      Drive("d3", "game_kc_sf", "KC", 5, 3, "KC 30", "Endzone", 6, 70, "2:45", "Touchdown", true),
      Drive("d4", "game_kc_sf", "SF", 4, 3, "SF 25", "KC 24", 11, 51, "5:30", "Field Goal", true),
      Drive("d5", "game_kc_sf", "SF", 3, 2, "SF 35", "KC 31", 7, 34, "3:10", "Interception", false)
    )
  )

  private val statsDb = mapOf(
    "game_kc_sf" to GameStatistics(
      gameId = "game_kc_sf",
      awayStats = TeamGameStats(
        firstDowns = 22,
        totalYards = 378,
        passingYards = 264,
        completionsAttempts = "22/31",
        rushingYards = 114,
        rushingAttempts = 24,
        turnovers = 1,
        fumblesLost = 0,
        interceptionsThrown = 1,
        thirdDownEfficiency = "6/11 (55%)",
        fourthDownEfficiency = "1/1 (100%)",
        redZoneEfficiency = "3/4 (75%)",
        sacksAllowed = 2,
        penalties = "4-35 yds",
        timeOfPossession = "28:18"
      ),
      homeStats = TeamGameStats(
        firstDowns = 24,
        totalYards = 412,
        passingYards = 298,
        completionsAttempts = "25/34",
        rushingYards = 114,
        rushingAttempts = 22,
        turnovers = 0,
        fumblesLost = 0,
        interceptionsThrown = 0,
        thirdDownEfficiency = "8/13 (62%)",
        fourthDownEfficiency = "2/2 (100%)",
        redZoneEfficiency = "4/5 (80%)",
        sacksAllowed = 1,
        penalties = "3-20 yds",
        timeOfPossession = "31:42"
      )
    )
  )

  private val playerGameStatsDb = mapOf(
    "game_kc_sf" to listOf(
      PlayerGameStat("p_mahomes", "Patrick Mahomes", "KC", "QB", "Passing", "25/34, 298 YDS, 2 TD, 0 INT"),
      PlayerGameStat("p_purdy", "Brock Purdy", "SF", "QB", "Passing", "22/31, 264 YDS, 2 TD, 1 INT"),
      PlayerGameStat("p_pacheco", "Isiah Pacheco", "KC", "RB", "Rushing", "18 CAR, 82 YDS, 1 TD"),
      PlayerGameStat("p_cmc", "Christian McCaffrey", "SF", "RB", "Rushing", "19 CAR, 88 YDS, 1 TD, 6 REC 44 YDS"),
      PlayerGameStat("p_kelce", "Travis Kelce", "KC", "TE", "Receiving", "7 REC, 84 YDS, 1 TD"),
      PlayerGameStat("p_kittle", "George Kittle", "SF", "TE", "Receiving", "6 REC, 76 YDS, 0 TD"),
      PlayerGameStat("p_mcduffie", "Trent McDuffie", "KC", "CB", "Defense", "6 TCKL, 1 INT, 2 PBU"),
      PlayerGameStat("p_bosa", "Nick Bosa", "SF", "DE", "Defense", "5 TCKL, 1.0 SACK, 2 TFL")
    )
  )

  private val playersMap = mapOf(
    "p_mahomes" to Player("p_mahomes", "Patrick Mahomes", "KC", 15, "QB", "Texas Tech", 8, "3,842 YDS, 31 TD, 7 INT", 99.0f),
    "p_purdy" to Player("p_purdy", "Brock Purdy", "SF", 13, "QB", "Iowa State", 3, "3,510 YDS, 25 TD, 9 INT", 91.5f),
    "p_cmc" to Player("p_cmc", "Christian McCaffrey", "SF", 23, "RB", "Stanford", 8, "1,140 RUSH YDS, 14 TD", 98.0f),
    "p_kelce" to Player("p_kelce", "Travis Kelce", "KC", 87, "TE", "Cincinnati", 12, "82 REC, 910 YDS, 7 TD", 96.0f),
    "p_lamar" to Player("p_lamar", "Lamar Jackson", "BAL", 8, "QB", "Louisville", 7, "3,405 PASS YDS, 780 RUSH YDS, 35 TOT TD", 98.5f),
    "p_allen" to Player("p_allen", "Josh Allen", "BUF", 17, "QB", "Wyoming", 7, "3,612 PASS YDS, 450 RUSH YDS, 33 TOT TD", 97.0f),
    "p_goff" to Player("p_goff", "Jared Goff", "DET", 16, "QB", "California", 9, "3,750 PASS YDS, 28 TD, 8 INT", 92.0f)
  )

  override fun getLiveGames(): Flow<List<Game>> = liveGamesFlow.asStateFlow()
  override fun getUpcomingGames(): Flow<List<Game>> = upcomingGamesFlow.asStateFlow()
  override fun getCompletedGames(): Flow<List<Game>> = completedGamesFlow.asStateFlow()

  override fun getGameById(id: String): Game? {
    return liveGamesFlow.value.find { it.id == id }
      ?: upcomingGamesFlow.value.find { it.id == id }
      ?: completedGamesFlow.value.find { it.id == id }
  }

  override fun getPlayByPlay(gameId: String): List<Play> {
    return playsDb[gameId] ?: listOf(
      Play(
        id = "gen_1",
        gameId = gameId,
        quarter = 3,
        clock = "07:22",
        down = 2,
        distance = 6,
        yardLine = "OPP 41",
        description = "Quarterback pass completed short right for 9 yards, 1st Down.",
        yardsGained = 9,
        possessionTeamAbbreviation = "OFF",
        aiInsight = "Effective play action bootleg against zone coverage."
      )
    )
  }

  override fun getDrives(gameId: String): List<Drive> {
    return drivesDb[gameId] ?: listOf(
      Drive("gd1", gameId, "HOME", 1, 1, "OWN 25", "OPP 30", 8, 45, "3:40", "Field Goal", true),
      Drive("gd2", gameId, "AWAY", 1, 1, "OWN 20", "Endzone", 10, 80, "4:55", "Touchdown", true)
    )
  }

  override fun getGameStatistics(gameId: String): GameStatistics? {
    return statsDb[gameId] ?: statsDb["game_kc_sf"]
  }

  override fun getPlayerStats(gameId: String): List<PlayerGameStat> {
    return playerGameStatsDb[gameId] ?: playerGameStatsDb["game_kc_sf"].orEmpty()
  }

  override fun getAllTeams(): List<Team> = teamsList

  override fun getTeamById(teamId: String): Team? = teamsMap[teamId]

  override fun getStandings(): List<DivisionStandings> {
    // Generate realistic NFL divisions
    val divisions = listOf(
      "AFC West" to ("AFC" to listOf("KC", "LAC", "DEN", "LV")),
      "AFC North" to ("AFC" to listOf("BAL", "PIT", "CIN", "CLE")),
      "AFC East" to ("AFC" to listOf("BUF", "MIA", "NYJ", "NE")),
      "AFC South" to ("AFC" to listOf("HOU", "IND", "JAX", "TEN")),
      "NFC West" to ("NFC" to listOf("SF", "LAR", "SEA", "ARI")),
      "NFC North" to ("NFC" to listOf("DET", "MIN", "GB", "CHI")),
      "NFC East" to ("NFC" to listOf("PHI", "WAS", "DAL", "NYG")),
      "NFC South" to ("NFC" to listOf("TB", "ATL", "NO", "CAR"))
    )

    return divisions.map { (divName, confAndTeams) ->
      val (conf, teamIds) = confAndTeams
      val rows = teamIds.mapIndexed { idx, tid ->
        val t = teamsMap[tid] ?: Team(tid, tid, tid, tid, conf, divName, 8, 5, 0, 0, 0, "Stadium")
        val winPct = if (t.wins + t.losses > 0) t.wins.toFloat() / (t.wins + t.losses) else 0.5f
        val clinch = when {
          idx == 0 && t.wins >= 10 -> "x - Clinched Playoff"
          t.losses >= 10 -> "e - Eliminated"
          else -> null
        }
        StandingsRow(
          team = t,
          rank = idx + 1,
          wins = t.wins,
          losses = t.losses,
          ties = t.ties,
          winPct = winPct,
          pointsFor = t.wins * 26 + 14,
          pointsAgainst = t.losses * 24 + 10,
          pointDiff = (t.wins * 26 + 14) - (t.losses * 24 + 10),
          streak = if (t.wins > 8) "W3" else "L1",
          divisionRecord = "4-1",
          conferenceRecord = "7-3",
          clinchStatus = clinch
        )
      }
      DivisionStandings(divisionName = divName, conference = conf, teams = rows)
    }
  }

  override fun getPlayersForTeam(teamId: String): List<Player> {
    return playersMap.values.filter { it.teamId == teamId }.ifEmpty {
      listOf(
        Player("p_${teamId}_1", "Starting Quarterback", teamId, 12, "QB", "State Univ", 5, "2,980 YDS, 22 TD", 88.0f),
        Player("p_${teamId}_2", "Star Running Back", teamId, 24, "RB", "National Tech", 4, "950 YDS, 9 TD", 87.0f),
        Player("p_${teamId}_3", "Top Wide Receiver", teamId, 18, "WR", "Metropolitan", 3, "68 REC, 870 YDS, 6 TD", 89.0f)
      )
    }
  }

  override fun getPlayerById(playerId: String): Player? = playersMap[playerId]
}
