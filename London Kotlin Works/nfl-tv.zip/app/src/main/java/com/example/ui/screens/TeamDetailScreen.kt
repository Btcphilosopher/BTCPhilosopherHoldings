package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Player
import com.example.data.model.Team
import com.example.data.repository.SportsDataProvider
import com.example.ui.theme.ChalkDim
import com.example.ui.theme.ChalkWhite
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteElevated
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RestrainedAmber
import com.example.ui.theme.SteelGrey

@Composable
fun TeamDetailScreen(
  teamId: String,
  sportsRepository: SportsDataProvider,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  val team = remember(teamId) { sportsRepository.getTeamById(teamId) }
  val players = remember(teamId) { sportsRepository.getPlayersForTeam(teamId) }
  var isFollowing by remember { mutableStateOf(false) }

  if (team == null) {
    Box(modifier = Modifier.fillMaxSize().background(ObsidianBlack), contentAlignment = Alignment.Center) {
      Text("Team not found", color = ChalkWhite)
    }
    return
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(ObsidianBlack)
      .testTag("team_detail_screen")
  ) {
    // Top Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(onClick = onBack) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = ChalkWhite)
      }

      Button(
        onClick = { isFollowing = !isFollowing },
        colors = ButtonDefaults.buttonColors(
          containerColor = if (isFollowing) RestrainedAmber else GraphiteElevated,
          contentColor = if (isFollowing) ObsidianBlack else ChalkWhite
        ),
        shape = RoundedCornerShape(8.dp)
      ) {
        Icon(
          if (isFollowing) Icons.Default.Star else Icons.Default.StarBorder,
          contentDescription = null,
          modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(if (isFollowing) "Following" else "Follow Team", fontWeight = FontWeight.Bold, fontSize = 13.sp)
      }
    }

    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp),
      contentPadding = PaddingValues(bottom = 60.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Team Header
      item {
        Surface(
          color = GraphiteSurface,
          shape = RoundedCornerShape(12.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(team.logoEmoji, fontSize = 48.sp)
            Spacer(modifier = Modifier.width(16.dp))
            Column {
              Text(team.fullName, color = ChalkWhite, fontSize = 24.sp, fontWeight = FontWeight.Black)
              Spacer(modifier = Modifier.height(4.dp))
              Text("${team.conference} ${team.division} • Record: ${team.recordString}", color = RestrainedAmber, fontSize = 13.sp, fontWeight = FontWeight.Bold)
              Spacer(modifier = Modifier.height(4.dp))
              Text(team.stadium, color = SteelGrey, fontSize = 12.sp)
            }
          }
        }
      }

      // Roster section
      item {
        Text("KEY PLAYERS & ACTIVE ROSTER", color = RestrainedAmber, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
      }

      items(players) { player ->
        PlayerRowCard(player = player)
      }
    }
  }
}

@Composable
fun PlayerRowCard(player: Player) {
  Surface(
    color = GraphiteSurface,
    shape = RoundedCornerShape(8.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier.padding(14.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Surface(
          color = GraphiteElevated,
          shape = CircleShape,
          modifier = Modifier.size(36.dp)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Text("#${player.jerseyNumber}", color = RestrainedAmber, fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(player.name, color = ChalkWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
          Text("${player.position} • ${player.college} • ${player.experienceYears} yrs exp", color = SteelGrey, fontSize = 12.sp)
        }
      }

      Text(player.seasonStatsSummary, color = ChalkDim, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
  }
}
