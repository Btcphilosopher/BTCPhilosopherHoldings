package com.example

import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsFootball
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.NflTvDatabase
import com.example.data.repository.AiAssistantRepository
import com.example.data.repository.MediaRepository
import com.example.data.repository.SportsDataRepository
import com.example.player.NflBroadcastPlayer
import com.example.ui.screens.AiAssistantScreen
import com.example.ui.screens.GameCentreScreen
import com.example.ui.screens.HighlightsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PersonalizationScreen
import com.example.ui.screens.ScheduleScreen
import com.example.ui.screens.StandingsScreen
import com.example.ui.screens.TeamDetailScreen
import com.example.ui.theme.ChalkDim
import com.example.ui.theme.ChalkWhite
import com.example.ui.theme.FocusBorderAmber
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteElevated
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.LiveRed
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RestrainedAmber
import com.example.ui.theme.SteelGrey
import kotlinx.coroutines.launch

enum class AppDestination(val label: String, val icon: ImageVector) {
  HOME("Home", Icons.Default.Home),
  SCHEDULE("Schedule", Icons.Default.CalendarMonth),
  STANDINGS("Standings", Icons.Default.Leaderboard),
  HIGHLIGHTS("Videos", Icons.Default.VideoLibrary),
  AI_ASSISTANT("AI Analyst", Icons.Default.AutoAwesome),
  SETTINGS("Settings", Icons.Default.Settings)
}

data class PlayerState(
  val isOpen: Boolean = false,
  val videoUrl: String = "",
  val title: String = "",
  val subtitle: String = "",
  val gameId: String? = null,
  val isMultiView: Boolean = false
)

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    val database = NflTvDatabase.getDatabase(this)
    val sportsRepo = SportsDataRepository()
    val mediaRepo = MediaRepository(database)
    val aiRepo = AiAssistantRepository(sportsRepo, mediaRepo)

    setContent {
      MyApplicationTheme {
        NflTvMainContent(
          sportsRepo = sportsRepo,
          mediaRepo = mediaRepo,
          aiRepo = aiRepo
        )
      }
    }
  }
}

@Composable
fun NflTvMainContent(
  sportsRepo: SportsDataRepository,
  mediaRepo: MediaRepository,
  aiRepo: AiAssistantRepository
) {
  val configuration = LocalConfiguration.current
  val isWideScreen = configuration.screenWidthDp >= 720 || configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

  var currentDestination by remember { mutableStateOf(AppDestination.HOME) }
  var selectedGameId by remember { mutableStateOf<String?>(null) }
  var selectedTeamId by remember { mutableStateOf<String?>(null) }
  var playerState by remember { mutableStateOf(PlayerState()) }
  val scope = rememberCoroutineScope()

  // BackHandler to handle remote BACK button & device back navigation
  BackHandler(enabled = playerState.isOpen || selectedGameId != null || selectedTeamId != null || currentDestination != AppDestination.HOME) {
    when {
      playerState.isOpen -> playerState = playerState.copy(isOpen = false)
      selectedGameId != null -> selectedGameId = null
      selectedTeamId != null -> selectedTeamId = null
      currentDestination != AppDestination.HOME -> currentDestination = AppDestination.HOME
    }
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(ObsidianBlack)
      .testTag("app_root_container")
  ) {
    if (playerState.isOpen) {
      // Fullscreen Broadcast / Multi-Game Player
      val liveGame = playerState.gameId?.let { sportsRepo.getGameById(it) } ?: sportsRepo.getGameById("game_kc_sf")
      NflBroadcastPlayer(
        videoUrl = playerState.videoUrl,
        title = playerState.title,
        subtitle = playerState.subtitle,
        game = liveGame,
        isLive = liveGame?.status == com.example.data.model.GameStatus.LIVE,
        onClose = {
          // Record progress to Room database
          val asset = mediaRepo.getMediaById("m_chiefs_49ers_live")
          if (asset != null) {
            scope.launch { mediaRepo.recordProgress(asset, 45000L, 120000L) }
          }
          playerState = playerState.copy(isOpen = false)
        },
        onOpenGameCentre = {
          if (liveGame != null) {
            selectedGameId = liveGame.id
            playerState = playerState.copy(isOpen = false)
          }
        },
        onToggleMultiView = {
          playerState = playerState.copy(isMultiView = !playerState.isMultiView)
        },
        isMultiViewActive = playerState.isMultiView,
        secondaryVideoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"
      )
    } else {
      // Regular Application Navigation & Screens
      Row(modifier = Modifier.fillMaxSize()) {
        // Navigation Rail for TV, tablets & widescreen
        if (isWideScreen) {
          TvNavigationRail(
            currentDestination = currentDestination,
            onDestinationSelected = { dest ->
              selectedGameId = null
              selectedTeamId = null
              currentDestination = dest
            },
            onLiveBroadcastClick = {
              playerState = PlayerState(
                isOpen = true,
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                title = "SF 49ers @ KC Chiefs",
                subtitle = "Live Broadcast 4K HDR • Arrowhead Stadium",
                gameId = "game_kc_sf"
              )
            }
          )
        }

        // Main Content Area
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxHeight()
        ) {
          Scaffold(
            topBar = {
              DscsTopAppBar(
                onLiveQuickPlay = {
                  playerState = PlayerState(
                    isOpen = true,
                    videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                    title = "SF 49ers @ KC Chiefs",
                    subtitle = "Live Broadcast 4K HDR",
                    gameId = "game_kc_sf"
                  )
                },
                onOpenAi = {
                  selectedGameId = null
                  selectedTeamId = null
                  currentDestination = AppDestination.AI_ASSISTANT
                }
              )
            },
            bottomBar = {
              if (!isWideScreen) {
                DscsBottomNavigationBar(
                  currentDestination = currentDestination,
                  onDestinationSelected = { dest ->
                    selectedGameId = null
                    selectedTeamId = null
                    currentDestination = dest
                  }
                )
              }
            },
            containerColor = ObsidianBlack
          ) { innerPadding ->
            Box(
              modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
            ) {
              when {
                selectedGameId != null -> {
                  GameCentreScreen(
                    gameId = selectedGameId!!,
                    sportsRepository = sportsRepo,
                    onBack = { selectedGameId = null },
                    onWatchBroadcast = { url, title, sub ->
                      playerState = PlayerState(
                        isOpen = true,
                        videoUrl = url,
                        title = title,
                        subtitle = sub,
                        gameId = selectedGameId
                      )
                    },
                    onPlayClip = { url, title ->
                      playerState = PlayerState(
                        isOpen = true,
                        videoUrl = url,
                        title = title,
                        subtitle = "Verified Highlight Play",
                        gameId = selectedGameId
                      )
                    },
                    onAskAi = { prompt ->
                      aiRepo.askQuestion(prompt, selectedGameId)
                      currentDestination = AppDestination.AI_ASSISTANT
                      selectedGameId = null
                    }
                  )
                }

                selectedTeamId != null -> {
                  TeamDetailScreen(
                    teamId = selectedTeamId!!,
                    sportsRepository = sportsRepo,
                    onBack = { selectedTeamId = null }
                  )
                }

                else -> {
                  when (currentDestination) {
                    AppDestination.HOME -> {
                      HomeScreen(
                        sportsRepository = sportsRepo,
                        mediaRepository = mediaRepo,
                        onOpenPlayer = { url, title, sub, gid ->
                          playerState = PlayerState(
                            isOpen = true,
                            videoUrl = url,
                            title = title,
                            subtitle = sub,
                            gameId = gid
                          )
                        },
                        onOpenGameCentre = { gid -> selectedGameId = gid },
                        onOpenTeamDetail = { tid -> selectedTeamId = tid },
                        onOpenAiWithPrompt = { prompt, gid ->
                          aiRepo.askQuestion(prompt, gid)
                          currentDestination = AppDestination.AI_ASSISTANT
                        },
                        onOpenSchedule = { currentDestination = AppDestination.SCHEDULE },
                        onOpenStandings = { currentDestination = AppDestination.STANDINGS }
                      )
                    }

                    AppDestination.SCHEDULE -> {
                      ScheduleScreen(
                        sportsRepository = sportsRepo,
                        onOpenGameCentre = { gid -> selectedGameId = gid }
                      )
                    }

                    AppDestination.STANDINGS -> {
                      StandingsScreen(
                        sportsRepository = sportsRepo,
                        onOpenTeamDetail = { tid -> selectedTeamId = tid }
                      )
                    }

                    AppDestination.HIGHLIGHTS -> {
                      HighlightsScreen(
                        mediaRepository = mediaRepo,
                        onOpenPlayer = { url, title, sub, gid ->
                          playerState = PlayerState(
                            isOpen = true,
                            videoUrl = url,
                            title = title,
                            subtitle = sub,
                            gameId = gid
                          )
                        }
                      )
                    }

                    AppDestination.AI_ASSISTANT -> {
                      AiAssistantScreen(
                        aiRepository = aiRepo,
                        currentGameId = "game_kc_sf",
                        onOpenHighlight = { mediaId ->
                          val media = mediaRepo.getMediaById(mediaId)
                          if (media != null) {
                            playerState = PlayerState(
                              isOpen = true,
                              videoUrl = media.videoUrl,
                              title = media.title,
                              subtitle = media.subtitle,
                              gameId = media.relatedGameId
                            )
                          }
                        }
                      )
                    }

                    AppDestination.SETTINGS -> {
                      PersonalizationScreen(
                        sportsRepository = sportsRepo,
                        mediaRepository = mediaRepo
                      )
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun DscsTopAppBar(
  onLiveQuickPlay: () -> Unit,
  onOpenAi: () -> Unit
) {
  Surface(
    color = ObsidianBlack,
    modifier = Modifier
      .fillMaxWidth()
      .statusBarsPadding()
      .border(androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder.copy(alpha = 0.5f)))
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 24.dp, vertical = 12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Surface(
          color = RestrainedAmber,
          shape = RoundedCornerShape(6.dp)
        ) {
          Text(
            text = "DSCS",
            color = ObsidianBlack,
            fontSize = 12.sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
          )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "NFL TV",
          color = ChalkWhite,
          fontSize = 18.sp,
          fontWeight = FontWeight.Black,
          letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "COMMAND CENTRE",
          color = SteelGrey,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 1.sp
        )
      }

      Row(verticalAlignment = Alignment.CenterVertically) {
        // Quick Live Pill
        Surface(
          color = LiveRed.copy(alpha = 0.15f),
          shape = RoundedCornerShape(20.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, LiveRed.copy(alpha = 0.6f)),
          modifier = Modifier
            .clickable { onLiveQuickPlay() }
            .testTag("top_live_badge_btn")
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(modifier = Modifier.size(6.dp).background(LiveRed, CircleShape))
            Spacer(modifier = Modifier.width(6.dp))
            Text("LIVE (4K)", color = LiveRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }

        Spacer(modifier = Modifier.width(10.dp))

        // AI Assistant Quick Access Button
        Surface(
          color = GraphiteElevated,
          shape = RoundedCornerShape(20.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, RestrainedAmber.copy(alpha = 0.4f)),
          modifier = Modifier
            .clickable { onOpenAi() }
            .testTag("top_ai_badge_btn")
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = RestrainedAmber, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Ask AI", color = ChalkWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun TvNavigationRail(
  currentDestination: AppDestination,
  onDestinationSelected: (AppDestination) -> Unit,
  onLiveBroadcastClick: () -> Unit
) {
  NavigationRail(
    containerColor = GraphiteSurface,
    contentColor = ChalkWhite,
    modifier = Modifier
      .fillMaxHeight()
      .border(androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder)),
    header = {
      Column(
        modifier = Modifier.padding(top = 16.dp, bottom = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Surface(
          color = RestrainedAmber,
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.size(36.dp)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Text("🏈", fontSize = 18.sp)
          }
        }
      }
    }
  ) {
    AppDestination.values().forEach { destination ->
      val isSelected = currentDestination == destination
      val interactionSource = remember { MutableInteractionSource() }
      val isFocused by interactionSource.collectIsFocusedAsState()

      NavigationRailItem(
        selected = isSelected,
        onClick = { onDestinationSelected(destination) },
        icon = {
          Icon(
            destination.icon,
            contentDescription = destination.label,
            modifier = Modifier.size(24.dp)
          )
        },
        label = {
          Text(
            text = destination.label,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
          )
        },
        colors = NavigationRailItemDefaults.colors(
          selectedIconColor = ObsidianBlack,
          selectedTextColor = RestrainedAmber,
          indicatorColor = RestrainedAmber,
          unselectedIconColor = SteelGrey,
          unselectedTextColor = SteelGrey
        ),
        modifier = Modifier
          .padding(vertical = 4.dp)
          .focusable(interactionSource = interactionSource)
          .border(
            width = if (isFocused) 2.dp else 0.dp,
            color = if (isFocused) FocusBorderAmber else Color.Transparent,
            shape = RoundedCornerShape(12.dp)
          )
          .testTag("nav_rail_${destination.name.lowercase()}")
      )
    }
  }
}

@Composable
fun DscsBottomNavigationBar(
  currentDestination: AppDestination,
  onDestinationSelected: (AppDestination) -> Unit
) {
  NavigationBar(
    containerColor = GraphiteSurface,
    contentColor = ChalkWhite,
    modifier = Modifier
      .navigationBarsPadding()
      .border(androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder)),
    tonalElevation = 8.dp
  ) {
    AppDestination.values().forEach { destination ->
      val isSelected = currentDestination == destination
      NavigationBarItem(
        selected = isSelected,
        onClick = { onDestinationSelected(destination) },
        icon = {
          Icon(
            destination.icon,
            contentDescription = destination.label,
            modifier = Modifier.size(20.dp)
          )
        },
        label = {
          Text(
            text = destination.label,
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
          )
        },
        colors = NavigationBarItemDefaults.colors(
          selectedIconColor = ObsidianBlack,
          selectedTextColor = RestrainedAmber,
          indicatorColor = RestrainedAmber,
          unselectedIconColor = SteelGrey,
          unselectedTextColor = SteelGrey
        ),
        modifier = Modifier.testTag("bottom_nav_${destination.name.lowercase()}")
      )
    }
  }
}
