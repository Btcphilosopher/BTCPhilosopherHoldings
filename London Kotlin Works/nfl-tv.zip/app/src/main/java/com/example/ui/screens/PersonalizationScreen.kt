package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.MediaCatalogProvider
import com.example.data.repository.SportsDataProvider
import com.example.ui.components.DscsSectionHeader
import com.example.ui.theme.ChalkDim
import com.example.ui.theme.ChalkWhite
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteElevated
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.LiveRed
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RestrainedAmber
import com.example.ui.theme.SteelGrey
import kotlinx.coroutines.launch

@Composable
fun PersonalizationScreen(
  sportsRepository: SportsDataProvider,
  mediaRepository: MediaCatalogProvider,
  modifier: Modifier = Modifier
) {
  val scope = rememberCoroutineScope()
  val allTeams = remember { sportsRepository.getAllTeams() }

  var favoriteTeamIds by remember { mutableStateOf(setOf("KC", "SF", "DET")) }
  var spoilerProtection by remember { mutableStateOf(false) }
  var notificationsEnabled by remember { mutableStateOf(true) }
  var selectedCommentaryLanguage by remember { mutableStateOf("English (Natural Sound)") }
  var selectedQuality by remember { mutableStateOf("Auto 4K HDR (Recommended)") }
  var historyClearedMessage by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(ObsidianBlack)
      .padding(horizontal = 24.dp)
      .testTag("personalization_screen"),
    contentPadding = PaddingValues(top = 16.dp, bottom = 60.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      DscsSectionHeader(
        title = "Personalisation & Broadcast Settings",
        subtitle = "Tailor your home command centre, spoiler alerts & video quality"
      )
    }

    // Favorite Teams Picker
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "FAVOURITE NFL FRANCHISES",
            color = RestrainedAmber,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Followed teams appear first on the home screen and receive instant score updates",
            color = SteelGrey,
            fontSize = 12.sp
          )
          Spacer(modifier = Modifier.height(12.dp))

          LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(allTeams.take(12)) { team ->
              val isFav = favoriteTeamIds.contains(team.id)
              Surface(
                color = if (isFav) RestrainedAmber else GraphiteElevated,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isFav) RestrainedAmber else GraphiteBorder),
                modifier = Modifier.clickable {
                  favoriteTeamIds = if (isFav) favoriteTeamIds - team.id else favoriteTeamIds + team.id
                }
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(team.logoEmoji, fontSize = 16.sp)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = team.abbreviation,
                    color = if (isFav) ObsidianBlack else ChalkWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                  )
                  if (isFav) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(Icons.Default.Check, contentDescription = null, tint = ObsidianBlack, modifier = Modifier.size(14.dp))
                  }
                }
              }
            }
          }
        }
      }
    }

    // Spoiler Protection Toggle
    item {
      SettingSwitchRow(
        title = "Spoiler Protection Mode",
        description = "Hide live scores, play-by-play descriptions and final results for games you haven't watched yet",
        isChecked = spoilerProtection,
        onCheckedChange = { spoilerProtection = it }
      )
    }

    // Push Notifications Toggle
    item {
      SettingSwitchRow(
        title = "Game & Milestone Notifications",
        description = "Receive kickoff reminders, red zone alerts, and scoring turnover notifications",
        isChecked = notificationsEnabled,
        onCheckedChange = { notificationsEnabled = it }
      )
    }

    // Commentary Audio Language
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("COMMENTARY AUDIO FEED", color = RestrainedAmber, fontSize = 12.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(8.dp))
          val languages = listOf("English (Primary)", "English (Natural Sound)", "Spanish (En Español)", "Tactical Coach All-22 Audio")
          languages.forEach { lang ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clickable { selectedCommentaryLanguage = lang }
                .padding(vertical = 8.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(lang, color = ChalkWhite, fontSize = 13.sp)
              if (selectedCommentaryLanguage == lang) {
                Icon(Icons.Default.Check, contentDescription = null, tint = RestrainedAmber, modifier = Modifier.size(18.dp))
              }
            }
          }
        }
      }
    }

    // Preferred Video Streaming Quality
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("STREAMING QUALITY PROFILE", color = RestrainedAmber, fontSize = 12.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(8.dp))
          val qualities = listOf("Auto 4K HDR (Recommended)", "1080p60 High Frame Rate", "720p Mobile Data Saver")
          qualities.forEach { q ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clickable { selectedQuality = q }
                .padding(vertical = 8.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(q, color = ChalkWhite, fontSize = 13.sp)
              if (selectedQuality == q) {
                Icon(Icons.Default.Check, contentDescription = null, tint = RestrainedAmber, modifier = Modifier.size(18.dp))
              }
            }
          }
        }
      }
    }

    // Clear Watch History Action
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteElevated),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, LiveRed.copy(alpha = 0.5f))
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("PRIVACY & DATA CONTROLS", color = LiveRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            "Clear your local playback history, resume points, and recommendations profile.",
            color = SteelGrey,
            fontSize = 12.sp
          )
          Spacer(modifier = Modifier.height(12.dp))
          Button(
            onClick = {
              scope.launch {
                mediaRepository.clearHistory()
                historyClearedMessage = true
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = LiveRed, contentColor = ChalkWhite),
            shape = RoundedCornerShape(8.dp)
          ) {
            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Clear Playback History", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          }

          if (historyClearedMessage) {
            Spacer(modifier = Modifier.height(8.dp))
            Text("Playback history successfully cleared.", color = RestrainedAmber, fontSize = 12.sp)
          }
        }
      }
    }
  }
}

@Composable
fun SettingSwitchRow(
  title: String,
  description: String,
  isChecked: Boolean,
  onCheckedChange: (Boolean) -> Unit
) {
  Surface(
    color = GraphiteSurface,
    shape = RoundedCornerShape(12.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, GraphiteBorder)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(title, color = ChalkWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Text(description, color = SteelGrey, fontSize = 12.sp, lineHeight = 16.sp)
      }
      Spacer(modifier = Modifier.width(16.dp))
      Switch(
        checked = isChecked,
        onCheckedChange = onCheckedChange,
        colors = SwitchDefaults.colors(
          checkedThumbColor = ObsidianBlack,
          checkedTrackColor = RestrainedAmber,
          uncheckedThumbColor = SteelGrey,
          uncheckedTrackColor = GraphiteElevated
        )
      )
    }
  }
}
