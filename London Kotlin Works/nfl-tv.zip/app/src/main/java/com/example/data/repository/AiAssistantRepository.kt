package com.example.data.repository

import com.example.data.model.Game
import com.example.data.model.Play
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ChatMessage(
  val id: String,
  val sender: MessageSender,
  val text: String,
  val timestamp: Long = System.currentTimeMillis(),
  val toolUsed: String? = null,
  val playSnippet: Play? = null,
  val relatedHighlightId: String? = null,
  val sourceAttribution: String? = "DSCS Sports Telemetry • Live Game Feed"
)

enum class MessageSender {
  USER,
  ASSISTANT
}

class AiAssistantRepository(
  private val sportsRepository: SportsDataProvider,
  private val mediaRepository: MediaCatalogProvider
) {
  private val _messages = MutableStateFlow<List<ChatMessage>>(
    listOf(
      ChatMessage(
        id = "init_welcome",
        sender = MessageSender.ASSISTANT,
        text = "Welcome to DSCS Sports AI. I am your live football analyst, connected directly to in-game telemetry, play-by-play tracking, player tracking, and the NFL rulebook. Tap a prompt or ask any question about tonight's games."
      )
    )
  )
  val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

  fun askQuestion(query: String, currentGameId: String? = "game_kc_sf") {
    val userMsg = ChatMessage(
      id = "user_${System.currentTimeMillis()}",
      sender = MessageSender.USER,
      text = query
    )
    val updated = _messages.value.toMutableList().apply { add(userMsg) }
    _messages.value = updated

    // Generate grounded response using structured football intelligence tools
    val response = executeAiToolResponse(query.lowercase(), currentGameId)
    val assistantMsg = ChatMessage(
      id = "ai_${System.currentTimeMillis()}",
      sender = MessageSender.ASSISTANT,
      text = response.first,
      toolUsed = response.second,
      playSnippet = response.third,
      relatedHighlightId = response.fourth
    )
    _messages.value = _messages.value + assistantMsg
  }

  private fun executeAiToolResponse(
    q: String,
    gameId: String?
  ): Tuple4<String, String, Play?, String?> {
    val targetGame = gameId?.let { sportsRepository.getGameById(it) } ?: sportsRepository.getGameById("game_kc_sf")

    return when {
      q.contains("play") && (q.contains("explain") || q.contains("happened") || q.contains("last")) -> {
        val plays = targetGame?.let { sportsRepository.getPlayByPlay(it.id) }.orEmpty()
        val latestPlay = plays.firstOrNull() ?: plays.getOrNull(0)
        val text = if (latestPlay != null) {
          "**Play Telemetry Breakdown (Q${latestPlay.quarter} ${latestPlay.clock}):**\n" +
            "• **Down & Distance:** ${latestPlay.down} & ${latestPlay.distance} at ${latestPlay.yardLine}\n" +
            "• **Action:** ${latestPlay.description}\n" +
            "• **Tactical Insight:** ${latestPlay.aiInsight ?: "Execution beat standard shell coverage."}\n" +
            "• **Next Gen Telemetry:** Expected yards was +4.2; actual yardage gained was +${latestPlay.yardsGained}."
        } else {
          "The current drive is resetting between quarters. The offense is lined up in shotgun."
        }
        Tuple4(text, "get_play_by_play", latestPlay, latestPlay?.highlightUrl)
      }

      q.contains("fourth") || q.contains("4th") || q.contains("go for it") -> {
        val text = "**Analytics Model: 4th Down Decision Matrix**\n\n" +
          "• **Situation:** 4th & 1 at Opponent 34-yard line.\n" +
          "• **Go For It Expected Value:** +2.8 Expected Points (+4.1% Win Probability).\n" +
          "• **Punt Expected Value:** -0.9 Expected Points (touchback risk).\n" +
          "• **Field Goal Attempt:** 52-yard attempt (68% historical success at 44°F).\n" +
          "**Analytical Recommendation:** GO FOR IT. The analytics heavily favor converting with a heavy personnel sneak or quick dive, exploiting the defense's 2-deep umbrella alignment."
        Tuple4(text, "get_fourth_down_analytics", null, null)
      }

      q.contains("quarterback") || q.contains("qb") || q.contains("compare") -> {
        val stats = targetGame?.let { sportsRepository.getPlayerStats(it.id) }.orEmpty()
        val qbStats = stats.filter { it.position == "QB" }
        val sb = StringBuilder("**Quarterback Head-to-Head Comparison Tonight:**\n\n")
        qbStats.forEach { qb ->
          sb.append("• **${qb.name} (${qb.teamAbbr}):** ${qb.statLine}\n")
        }
        sb.append("\n**Key Difference:** Mahomes has been unhurried against the four-man rush with a 73.5% completion rate, while Purdy faces a 38% pressure rate on third downs.")
        Tuple4(sb.toString(), "compare_players", null, null)
      }

      q.contains("summar") || q.contains("game so far") || q.contains("score") -> {
        val g = targetGame
        val text = if (g != null) {
          "**Game Summary — ${g.awayTeam.name} @ ${g.homeTeam.name}:**\n\n" +
            "• **Score:** ${g.awayTeam.abbreviation} ${g.score.awayTotal} — ${g.homeTeam.abbreviation} ${g.score.homeTotal}\n" +
            "• **Current Status:** ${g.displayStatus} | ${g.downAndDistanceString}\n" +
            "• **Win Probability:** ${g.homeTeam.name} ${(g.homeWinProbability * 100).toInt()}% vs ${g.awayTeam.name} ${(g.awayWinProbability * 100).toInt()}%\n" +
            "• **Key Storyline:** ${g.headline}. Both defensive lines have generated high havoc rates, but explosive perimeter passing has broken open the second half."
        } else {
          "Game telemetry is loading. Score is tied 0-0."
        }
        Tuple4(text, "get_game_summary", null, null)
      }

      q.contains("third down") || q.contains("3rd down") || q.contains("efficiency") -> {
        val gStats = targetGame?.let { sportsRepository.getGameStatistics(it.id) }
        val text = if (gStats != null) {
          "**Third-Down Efficiency Analysis:**\n\n" +
            "• **${targetGame.awayTeam.name}:** ${gStats.awayStats.thirdDownEfficiency}\n" +
            "• **${targetGame.homeTeam.name}:** ${gStats.homeStats.thirdDownEfficiency}\n\n" +
            "The ${targetGame.homeTeam.name} offense has converted 8 of 13 third downs by utilizing high-percentage rub concepts and mesh routes across the middle to beat press-man."
        } else {
          "Third-down stats are currently level."
        }
        Tuple4(text, "get_team_statistics", null, null)
      }

      q.contains("cover 2") || q.contains("cover 3") || q.contains("defense") -> {
        val text = "**Cover 2 vs Cover 3 Tactical Breakdown:**\n\n" +
          "• **Cover 2:** Two deep safeties each cover half of the deep field (halves). Underneath, five defenders play zone (corners flat, linebackers hook/curl). *Vulnerability:* The deep middle 'hole' between safeties and sideline holes.\n\n" +
          "• **Cover 3:** Three deep defenders (free safety + two outside cornerbacks) each cover a deep third. Four underneath defenders cover flats and curls. *Vulnerability:* 4-verticals and seams.\n\n" +
          "Tonight, Kansas City switched to Cover 3 to bracket deep posts while deploying an 8-man box against early-down rushes."
        Tuple4(text, "explain_football_rule", null, null)
      }

      q.contains("touchdown") || q.contains("highlight") -> {
        val plays = targetGame?.let { sportsRepository.getPlayByPlay(it.id) }.orEmpty()
        val tdPlays = plays.filter { it.isScoringPlay }
        val sb = StringBuilder("**Scoring Plays & Highlights Recorded:**\n\n")
        tdPlays.forEach { play ->
          sb.append("• **Q${play.quarter} (${play.possessionTeamAbbreviation}):** ${play.description}\n")
        }
        sb.append("\nYou can select any scoring clip from the Highlights tab to view immediate video replay.")
        Tuple4(sb.toString(), "search_highlights", tdPlays.firstOrNull(), "m_td_worthy_48yd")
      }

      q.contains("playoff") || q.contains("standings") -> {
        val text = "**Playoff Implications Matrix:**\n\n" +
          "• A victory tonight clinches the #1 overall AFC seed for the Chiefs, securing a first-round bye and home-field advantage through Arrowhead Stadium.\n" +
          "• For the 49ers, a win keeps them tied atop the NFC West and within one game of the NFC #1 seed."
        Tuple4(text, "get_standings", null, null)
      }

      q.contains("rule") || q.contains("penalty") -> {
        val text = "**NFL Official Rule Reference:**\n\n" +
          "• **Pass Interference (Rule 8, Section 5):** Contact by a defender that occurs beyond the line of scrimmage while the ball is in flight that materially restricts an eligible receiver's opportunity to make a catch.\n" +
          "• **Enforcement:** Spot foul. 1st down at the point of infraction. If inside the 1-yard line, the ball is placed at the 1-yard line."
        Tuple4(text, "explain_football_rule", null, null)
      }

      else -> {
        Tuple4(
          "I analyzed your query: \"$q\". Current game telemetries show ${targetGame?.awayTeam?.abbreviation ?: "SF"} vs ${targetGame?.homeTeam?.abbreviation ?: "KC"} in Q${targetGame?.quarter ?: 4}. What tactical, statistical, or video replay breakdown would you like to explore next?",
          "general_analytics",
          null,
          null
        )
      }
    }
  }

  fun clearChat() {
    _messages.value = listOf(
      ChatMessage(
        id = "init_welcome_new",
        sender = MessageSender.ASSISTANT,
        text = "Chat cleared. Ask anything about live games, quarterback stats, third-down metrics, or rules."
      )
    )
  }
}

private data class Tuple4<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
