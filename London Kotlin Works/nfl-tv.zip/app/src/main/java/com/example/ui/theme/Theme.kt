package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DscsSportsColorScheme = darkColorScheme(
  primary = RestrainedAmber,
  onPrimary = ObsidianBlack,
  primaryContainer = GraphiteElevated,
  onPrimaryContainer = ChalkWhite,
  secondary = MutedBlue,
  onSecondary = Color.White,
  secondaryContainer = GraphiteSurface,
  onSecondaryContainer = ChalkWhite,
  tertiary = FieldGreen,
  onTertiary = Color.White,
  background = ObsidianBlack,
  onBackground = ChalkWhite,
  surface = GraphiteSurface,
  onSurface = ChalkWhite,
  surfaceVariant = GraphiteElevated,
  onSurfaceVariant = SteelGrey,
  outline = GraphiteBorder,
  error = LiveRed,
  onError = Color.White,
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false, // Keep consistent premium sports broadcast palette
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = DscsSportsColorScheme,
    typography = Typography,
    content = content
  )
}
