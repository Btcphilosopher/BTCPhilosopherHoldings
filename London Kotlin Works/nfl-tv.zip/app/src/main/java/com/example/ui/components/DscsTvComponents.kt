package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Game
import com.example.data.model.GameStatus
import com.example.data.model.Play
import com.example.ui.theme.ChalkDim
import com.example.ui.theme.ChalkWhite
import com.example.ui.theme.FieldGreen
import com.example.ui.theme.FocusBorderAmber
import com.example.ui.theme.FocusSurfaceHighlight
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteElevated
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.LiveRed
import com.example.ui.theme.MutedBlue
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RestrainedAmber
import com.example.ui.theme.SteelDark
import com.example.ui.theme.SteelGrey

/**
 * TV & Remote-optimized focusable Card component.
 * Expands slightly and illuminates border in Restrained Amber when selected via remote D-pad.
 */
@Composable
fun TvFocusableCard(
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  testTag: String = "tv_card",
  enabled: Boolean = true,
  content: @Composable () -> Unit
) {
  val interactionSource = remember { MutableInteractionSource() }
  val isFocused by interactionSource.collectIsFocusedAsState()

  val scale by animateFloatAsState(targetValue = if (isFocused) 1.04f else 1.0f, label = "card_scale")
  val borderColor by animateColorAsState(
    targetValue = if (isFocused) FocusBorderAmber else GraphiteBorder,
    label = "card_border"
  )
  val backgroundColor by animateColorAsState(
    targetValue = if (isFocused) FocusSurfaceHighlight else GraphiteSurface,
    label = "card_bg"
  )

  Card(
    modifier = modifier
      .scale(scale)
      .clip(RoundedCornerShape(12.dp))
      .border(
        border = BorderStroke(if (isFocused) 2.5.dp else 1.dp, borderColor),
        shape = RoundedCornerShape(12.dp)
      )
      .focusable(enabled = enabled, interactionSource = interactionSource)
      .clickable(
        interactionSource = interactionSource,
        indication = null,
        enabled = enabled,
        onClick = onClick
      )
      .testTag(testTag),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = backgroundColor),
    elevation = CardDefaults.cardElevation(defaultElevation = if (isFocused) 8.dp else 2.dp)
  ) {
    content()
  }
}

/**
 * High-contrast, 10-foot legibility Game Card.
 */
@Composable
fun BroadcastGameCard(
  game: Game,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  TvFocusableCard(
    onClick = onClick,
    modifier = modifier.width(320.dp),
    testTag = "game_card_${game.id}"
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      // Status header row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          if (game.status == GameStatus.LIVE) {
            Box(
              modifier = Modifier
                .size(8.dp)
                .background(LiveRed, CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "LIVE",
              color = LiveRed,
              fontWeight = FontWeight.Black,
              fontSize = 11.sp,
              letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Q${game.quarter} ${game.gameClock}",
              color = RestrainedAmber,
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp
            )
          } else if (game.status == GameStatus.HALFTIME) {
            Text(
              text = "HALFTIME",
              color = RestrainedAmber,
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp
            )
          } else if (game.status == GameStatus.FINAL) {
            Text(
              text = "FINAL",
              color = SteelGrey,
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp
            )
          } else {
            Text(
              text = game.kickoffTime,
              color = ChalkDim,
              fontWeight = FontWeight.SemiBold,
              fontSize = 12.sp
            )
          }
        }

        Text(
          text = game.broadcastNetwork,
          color = SteelDark,
          fontSize = 10.sp,
          fontWeight = FontWeight.Bold
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Matchup scores
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          // Away team
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = game.awayTeam.logoEmoji, fontSize = 20.sp)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = game.awayTeam.name,
                color = ChalkWhite,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = game.awayTeam.recordString,
                color = SteelGrey,
                fontSize = 11.sp
              )
            }
          }
          Spacer(modifier = Modifier.height(10.dp))
          // Home team
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = game.homeTeam.logoEmoji, fontSize = 20.sp)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = game.homeTeam.name,
                color = ChalkWhite,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = game.homeTeam.recordString,
                color = SteelGrey,
                fontSize = 11.sp
              )
            }
          }
        }

        // Scores
        Column(horizontalAlignment = Alignment.End) {
          Text(
            text = if (game.status == GameStatus.UPCOMING) "-" else "${game.score.awayTotal}",
            color = ChalkWhite,
            fontSize = 22.sp,
            fontWeight = FontWeight.Black
          )
          Spacer(modifier = Modifier.height(14.dp))
          Text(
            text = if (game.status == GameStatus.UPCOMING) "-" else "${game.score.homeTotal}",
            color = ChalkWhite,
            fontSize = 22.sp,
            fontWeight = FontWeight.Black
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Down & distance or stadium footer
      if (game.downAndDistanceString.isNotBlank()) {
        Surface(
          color = FieldGreen.copy(alpha = 0.15f),
          shape = RoundedCornerShape(4.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = game.downAndDistanceString,
            color = FieldGreen,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
          )
        }
      } else {
        Text(
          text = game.stadium,
          color = SteelGrey,
          fontSize = 11.sp,
          maxLines = 1
        )
      }
    }
  }
}

/**
 * Section Title Header with clean sports broadcast typography
 */
@Composable
fun DscsSectionHeader(
  title: String,
  subtitle: String? = null,
  actionLabel: String? = null,
  onActionClick: (() -> Unit)? = null,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 24.dp, vertical = 12.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.Bottom
  ) {
    Column {
      Text(
        text = title,
        color = ChalkWhite,
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 0.5.sp
      )
      if (subtitle != null) {
        Text(
          text = subtitle,
          color = SteelGrey,
          fontSize = 12.sp,
          modifier = Modifier.padding(top = 2.dp)
        )
      }
    }

    if (actionLabel != null && onActionClick != null) {
      Text(
        text = "$actionLabel ➔",
        color = RestrainedAmber,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier
          .clickable { onActionClick() }
          .padding(4.dp)
      )
    }
  }
}
