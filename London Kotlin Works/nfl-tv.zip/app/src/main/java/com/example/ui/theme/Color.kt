package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// DSCS Sports Premium Visual Identity
val ObsidianBlack = Color(0xFF07090E)
val ObsidianDeeper = Color(0xFF040508)
val GraphiteSurface = Color(0xFF131722)
val GraphiteBorder = Color(0xFF22283A)
val GraphiteElevated = Color(0xFF1B2131)

val ChalkWhite = Color(0xFFF3F5FA)
val ChalkDim = Color(0xFFD6DBE4)
val SteelGrey = Color(0xFF8B96A8)
val SteelDark = Color(0xFF4D5666)

// Accents
val RestrainedAmber = Color(0xFFF59E0B)
val AmberGlow = Color(0x33F59E0B)
val MutedBlue = Color(0xFF3B82F6)
val FieldGreen = Color(0xFF10B981)
val LiveRed = Color(0xFFEF4444)

// TV Focus State Colors
val FocusBorderAmber = Color(0xFFFBBF24)
val FocusSurfaceHighlight = Color(0xFF242C3F)
