package com.example

import com.example.supersportr.calibration.CalibrationOptimizer
import com.example.supersportr.calibration.OptimizerWeights
import com.example.supersportr.model.DriveModeCalibration
import com.example.supersportr.model.VehicleProfile
import com.example.supersportr.simulation.PacejkaTyreModel
import com.example.supersportr.simulation.PowertrainEngine
import com.example.supersportr.simulation.VehicleDynamicsEngine
import com.example.supersportr.telemetry.SyntheticScenarioGenerator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SuperSportREngineeringTest {

    private val vehicle = VehicleProfile()

    @Test
    fun testPowertrainTorquePlateauAndLimits() {
        val pwt = vehicle.powertrain
        // At 5000 RPM, ICE torque should be exactly at peak plateau (800 Nm)
        val iceTorque = PowertrainEngine.getPeakEngineTorque(5000.0, pwt)
        assertEquals(800.0, iceTorque, 0.01)

        // Motor torque at 2000 RPM should be at peak (180 Nm)
        val motorTorque = PowertrainEngine.getPeakElectricMotorTorque(2000.0, pwt)
        assertEquals(180.0, motorTorque, 0.01)

        // Total combined torque should never exceed 980 Nm
        assertTrue((iceTorque + motorTorque) <= 980.0)

        // Above redline, ICE torque drops to zero
        val overRevTorque = PowertrainEngine.getPeakEngineTorque(9000.0, pwt)
        assertEquals(0.0, overRevTorque, 0.01)
    }

    @Test
    fun testPedalResponseTransferShaping() {
        val cal = DriveModeCalibration.SUPERSPORT
        val pwt = vehicle.powertrain

        // Deadband check: zero pedal input gives zero torque request
        val zeroReq = PowertrainEngine.calculateRequestedTorque(0.005, 5000.0, cal, pwt)
        assertEquals(0.0, zeroReq, 0.01)

        // Full pedal input gives full capacity
        val fullReq = PowertrainEngine.calculateRequestedTorque(1.0, 5000.0, cal, pwt)
        assertTrue(fullReq >= 950.0)
    }

    @Test
    fun testPacejkaTyreFrictionAndThermalGrip() {
        // Optimal temperature grip factor should be 1.0
        val optFactor = PacejkaTyreModel.thermalGripFactor(92.0)
        assertEquals(1.0, optFactor, 0.01)

        // Cold tyre (30°C) should have degraded grip
        val coldFactor = PacejkaTyreModel.thermalGripFactor(30.0)
        assertTrue(coldFactor < 0.90)

        // Lateral force with zero slip angle should be 0.0 N
        val fyZero = PacejkaTyreModel.computeLateralForce(0.0, 4000.0, 92.0)
        assertEquals(0.0, fyZero, 0.01)

        // Lateral force with 5 degrees (0.087 rad) slip angle should be positive
        val fyTurn = PacejkaTyreModel.computeLateralForce(0.087, 4000.0, 92.0)
        assertTrue(fyTurn > 3000.0)
    }

    @Test
    fun testDeterministicSimulationAndSensorDropoutDetection() {
        val cal = DriveModeCalibration.SUPERSPORT
        val session1 = SyntheticScenarioGenerator.generateDeterministicSession(cal, vehicle)
        val session2 = SyntheticScenarioGenerator.generateDeterministicSession(cal, vehicle)

        // Check deterministic reproducibility
        assertEquals(session1.totalTimeS, session2.totalTimeS, 0.001)
        assertEquals(session1.samples.size, session2.samples.size)
        assertEquals(session1.samples.last().speedKmh, session2.samples.last().speedKmh, 0.01)

        // Verify missing sensor window is identified (not silently faked)
        assertTrue(session1.missingIntervalsCount > 0)
        val dropoutSamples = session1.samples.filter { !it.sensorQualityOk }
        assertTrue(dropoutSamples.isNotEmpty())
        // Dropout was programmed around 22.0s - 23.5s
        assertTrue(dropoutSamples.first().timestampS in 21.9..23.6)

        // Verify sector splits
        assertEquals(3, session1.sectorSummaries.size)
    }

    @Test
    fun testCalibrationOptimizerBoundsAndDeltas() {
        val weights = OptimizerWeights()
        val proposal = CalibrationOptimizer.optimizeSuperSport(
            baseline = DriveModeCalibration.SUPERSPORT,
            weights = weights,
            vehicle = vehicle
        )

        assertNotNull(proposal)
        // Verify candidate parameters remain strictly within bounded limits
        val candidate = proposal.candidate
        assertTrue(candidate.pedalResponseExponent in 0.70..1.30)
        assertTrue(candidate.maxTorqueRampNmPerSec in 800.0..3800.0)
        assertTrue(candidate.shiftDurationMs in 35.0..120.0)
        assertTrue(candidate.diffPowerLockupPct in 35.0..85.0)

        // Verify delta report contains parameters
        assertTrue(proposal.deltas.isNotEmpty())
        // Verify export scripts are generated
        assertTrue(proposal.exportJson.contains("McLAREN_SUPERSPORT_R_PROPOSAL"))
        assertTrue(proposal.exportRScript.contains("supersport_proposal"))
    }
}
