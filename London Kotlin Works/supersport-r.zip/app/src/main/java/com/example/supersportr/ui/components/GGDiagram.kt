package com.example.supersportr.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.supersportr.model.TelemetrySample
import com.example.ui.theme.DarkNavyGraphite
import com.example.ui.theme.McLarenPapaya
import com.example.ui.theme.SlateCardBorder
import com.example.ui.theme.SlateCardSurface
import com.example.ui.theme.TechnicalMuted
import com.example.ui.theme.TechnicalSubtle
import com.example.ui.theme.TechnicalWhite
import com.example.ui.theme.TelemetryAmber
import com.example.ui.theme.TelemetryCyan
import com.example.ui.theme.TelemetryGreen
import com.example.ui.theme.TelemetryRed
import kotlin.math.sqrt

@Composable
fun GGDiagram(
    currentSample: TelemetrySample?,
    recentTrail: List<TelemetrySample>,
    modifier: Modifier = Modifier
) {
    val ax = currentSample?.axG ?: 0.0
    val ay = currentSample?.ayG ?: 0.0
    val totalG = sqrt(ax * ax + ay * ay)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(SlateCardSurface)
            .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "G-G FRICTION CIRCLE",
                        color = TechnicalWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "LATERAL VS LONGITUDINAL ACCEL",
                        color = TechnicalSubtle,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Digital G Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(DarkNavyGraphite)
                        .border(1.dp, SlateCardBorder, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${String.format("%.2f", totalG)} G",
                        color = if (totalG > 1.6) TelemetryAmber else McLarenPapaya,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Canvas for drawing GG plot
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(170.dp)
            ) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val maxRadius = minOf(size.width, size.height) * 0.44f

                // Scale: 2.0 G maps to maxRadius
                val gScale = maxRadius / 2.0f

                // Concentric circles: 0.5G, 1.0G, 1.5G, 2.0G
                val ringGValues = listOf(0.5f, 1.0f, 1.5f, 2.0f)
                ringGValues.forEach { gVal ->
                    val r = gVal * gScale
                    drawCircle(
                        color = if (gVal == 1.5f) Color(0xFF334155) else Color(0xFF222F3E),
                        radius = r,
                        center = center,
                        style = Stroke(width = if (gVal == 1.5f) 1.5f else 1f)
                    )
                }

                // Crosshairs
                drawLine(
                    color = Color(0xFF334155),
                    start = Offset(center.x - maxRadius, center.y),
                    end = Offset(center.x + maxRadius, center.y),
                    strokeWidth = 1f
                )
                drawLine(
                    color = Color(0xFF334155),
                    start = Offset(center.x, center.y - maxRadius),
                    end = Offset(center.x, center.y + maxRadius),
                    strokeWidth = 1f
                )

                // Draw trail of previous points
                if (recentTrail.isNotEmpty()) {
                    val trailStep = maxOf(1, recentTrail.size / 40)
                    for (i in 0 until recentTrail.size step trailStep) {
                        val pt = recentTrail[i]
                        val px = center.x + (pt.ayG.toFloat() * gScale).coerceIn(-maxRadius, maxRadius)
                        val py = center.y - (pt.axG.toFloat() * gScale).coerceIn(-maxRadius, maxRadius)
                        val alpha = (i.toFloat() / recentTrail.size) * 0.4f
                        drawCircle(
                            color = TelemetryCyan.copy(alpha = alpha),
                            radius = 2.5f,
                            center = Offset(px, py)
                        )
                    }
                }

                // Draw current operating point
                val currentX = center.x + (ay.toFloat() * gScale).coerceIn(-maxRadius, maxRadius)
                val currentY = center.y - (ax.toFloat() * gScale).coerceIn(-maxRadius, maxRadius)

                // Outer halo
                drawCircle(
                    color = McLarenPapaya.copy(alpha = 0.35f),
                    radius = 9f,
                    center = Offset(currentX, currentY)
                )
                // Center dot
                drawCircle(
                    color = McLarenPapaya,
                    radius = 4.5f,
                    center = Offset(currentX, currentY)
                )
            }

            // Quick legend under diagram
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Ax: ${String.format("%+.2f", ax)}g",
                    color = TechnicalMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "Ay: ${String.format("%+.2f", ay)}g",
                    color = TechnicalMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
