package com.example.supersportr.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkNavyGraphite
import com.example.ui.theme.McLarenPapaya
import com.example.ui.theme.SlateCardBorder
import com.example.ui.theme.SlateCardSurface
import com.example.ui.theme.TechnicalMuted
import com.example.ui.theme.TechnicalSubtle
import com.example.ui.theme.TechnicalWhite
import com.example.ui.theme.TelemetryCyan
import com.example.ui.theme.TelemetryGreen

/**
 * Visualizer for the 5-step Liquid Hydrogen Flow:
 * From Fuel Cell (-253°C) -> 700 bar High-Pressure Pump -> Dual Port/Direct Injection ->
 * 10,000 RPM Combustion Chamber -> Pure Water Vapour Exhaust.
 */
@Composable
fun HydrogenFlowDiagram(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(SlateCardSurface)
            .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "THE HYDROGEN FLOW // FROM FUEL CELL TO COMBUSTION",
                        color = TechnicalWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Liquid Hydrogen (LH2) Injection Architecture // Up to 700 Bar",
                        color = TelemetryCyan,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF0F2538))
                        .border(1.dp, TelemetryCyan.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Text("H2 CRYOGENIC", color = TelemetryCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 5 Step Vertical/Horizontal Flow Stack
            HydrogenStepItem(
                stepNum = "1",
                title = "FUEL CELL & CRYOGENIC TANK",
                desc = "Electrolysis generates electricity; liquid hydrogen stored at -253°C in insulated tank.",
                spec = "-253°C CRYOGENIC",
                icon = Icons.Default.Thermostat,
                accent = TelemetryCyan
            )

            Spacer(modifier = Modifier.height(6.dp))

            HydrogenStepItem(
                stepNum = "2",
                title = "PRESSURE & HIGH-PRESSURE PUMP",
                desc = "Multi-stage cryogenic pump compresses liquid hydrogen to engine injection pressure up to 700 bar.",
                spec = "700 BAR RAIL",
                icon = Icons.Default.Speed,
                accent = TelemetryCyan
            )

            Spacer(modifier = Modifier.height(6.dp))

            HydrogenStepItem(
                stepNum = "3",
                title = "DUAL PORT & DIRECT INJECTION",
                desc = "Liquid hydrogen injected into intake ports and direct into combustion chambers, vaporizing instantly.",
                spec = "PORT + DIRECT",
                icon = Icons.Default.Science,
                accent = McLarenPapaya
            )

            Spacer(modifier = Modifier.height(6.dp))

            HydrogenStepItem(
                stepNum = "4",
                title = "10,000 RPM HIGH-ENERGY COMBUSTION",
                desc = "Cryogenic cooling effect enables higher compression ratio, cooler combustion temps, and 850 hp engine power.",
                spec = "850 HP / 1,000 NM",
                icon = Icons.Default.ElectricBolt,
                accent = McLarenPapaya
            )

            Spacer(modifier = Modifier.height(6.dp))

            HydrogenStepItem(
                stepNum = "5",
                title = "CLEAN EXHAUST (WATER VAPOUR)",
                desc = "Pure water vapour exits via lightweight exhaust. Near-zero emissions with zero CO2 and zero NOx.",
                spec = "ZERO CO2 (H2O ONLY)",
                icon = Icons.Default.WaterDrop,
                accent = TelemetryGreen
            )

            Spacer(modifier = Modifier.height(10.dp))

            // "Why Liquid Hydrogen?" Highlights
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                WhyH2Pill(title = "ENERGY DENSITY", desc = "Higher energy density, less weight", modifier = Modifier.weight(1f))
                WhyH2Pill(title = "COOLING EFFECT", desc = "Lowers temps, elevates knock limit", modifier = Modifier.weight(1f))
                WhyH2Pill(title = "HYBRID E-AXLE", desc = "Works with 200 hp electric motor", modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun HydrogenStepItem(
    stepNum: String,
    title: String,
    desc: String,
    spec: String,
    icon: ImageVector,
    accent: Color
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(DarkNavyGraphite)
            .border(1.dp, SlateCardBorder, RoundedCornerShape(6.dp))
            .padding(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(accent.copy(alpha = 0.2f))
                    .border(1.dp, accent, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(stepNum, color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(title, color = TechnicalWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Text(spec, color = accent, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
                Text(desc, color = TechnicalMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
private fun WhyH2Pill(
    title: String,
    desc: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xFF0F1722))
            .border(1.dp, SlateCardBorder, RoundedCornerShape(4.dp))
            .padding(6.dp)
    ) {
        Column {
            Text(title, color = TelemetryCyan, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text(desc, color = TechnicalSubtle, fontSize = 7.sp, fontFamily = FontFamily.Monospace)
        }
    }
}
