package com.example.supersportr.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.supersportr.calibration.CalibrationOptimizer
import com.example.supersportr.calibration.CalibrationProposal
import com.example.supersportr.calibration.OptimizerWeights
import com.example.supersportr.model.DriveModeCalibration
import com.example.supersportr.model.DriveModeType
import com.example.supersportr.model.LapSessionData
import com.example.supersportr.model.TelemetrySample
import com.example.supersportr.model.VehicleProfile
import com.example.supersportr.telemetry.SyntheticScenarioGenerator
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class DashboardTab(val label: String, val shortId: String) {
    OVERVIEW("Overview", "A: OVERVIEW"),
    POWERTRAIN("Powertrain", "B: POWERTRAIN"),
    CHASSIS("Chassis", "C: CHASSIS"),
    CALIBRATION_LAB("Calibration", "D: CALIBRATION"),
    TRACK_ANALYSIS("Track", "E: TRACK"),
    DATA_QUALITY("Data & Safety", "F: QUALITY")
}

data class EngineeringUiState(
    val currentTab: DashboardTab = DashboardTab.OVERVIEW,
    val selectedMode: DriveModeType = DriveModeType.SUPERSPORT,
    val vehicleProfile: VehicleProfile = VehicleProfile(),
    val activeCalibration: DriveModeCalibration = DriveModeCalibration.SUPERSPORT,
    val currentSession: LapSessionData = SyntheticScenarioGenerator.generateDeterministicSession(DriveModeCalibration.SUPERSPORT),
    val currentIndex: Int = 104, // default scrub point (~5.2s during launch/upshift)
    val isPlaying: Boolean = false,
    
    // Calibration Optimizer State
    val customCalibration: DriveModeCalibration = DriveModeCalibration.createCustom(),
    val optimizerWeights: OptimizerWeights = OptimizerWeights(),
    val latestProposal: CalibrationProposal? = null,
    val isOptimizing: Boolean = false,
    val exportModalContent: String? = null
) {
    val currentSample: TelemetrySample?
        get() = currentSession.samples.getOrNull(currentIndex)

    val currentTrail: List<TelemetrySample>
        get() {
            val start = maxOf(0, currentIndex - 40)
            return currentSession.samples.subList(start, minOf(currentIndex + 1, currentSession.samples.size))
        }

    val scrubRatio: Float
        get() {
            val total = currentSession.samples.size - 1
            return if (total > 0) (currentIndex.toFloat() / total).coerceIn(0f, 1f) else 0f
        }
}

class EngineeringViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(EngineeringUiState())
    val uiState: StateFlow<EngineeringUiState> = _uiState.asStateFlow()

    private var playbackJob: Job? = null

    init {
        // Run initial optimization baseline calculation
        runOptimization()
    }

    fun setTab(tab: DashboardTab) {
        _uiState.update { it.copy(currentTab = tab) }
    }

    fun selectMode(mode: DriveModeType) {
        val cal = when (mode) {
            DriveModeType.COMFORT -> DriveModeCalibration.COMFORT
            DriveModeType.SPORT -> DriveModeCalibration.SPORT
            DriveModeType.SUPERSPORT -> DriveModeCalibration.SUPERSPORT
            DriveModeType.TRACK -> DriveModeCalibration.TRACK
            DriveModeType.CUSTOM -> _uiState.value.customCalibration
        }
        val newSession = SyntheticScenarioGenerator.generateDeterministicSession(cal, _uiState.value.vehicleProfile)
        val clampedIndex = _uiState.value.currentIndex.coerceIn(0, newSession.samples.size - 1)
        _uiState.update {
            it.copy(
                selectedMode = mode,
                activeCalibration = cal,
                currentSession = newSession,
                currentIndex = clampedIndex
            )
        }
    }

    fun setScrubRatio(ratio: Float) {
        val maxIdx = _uiState.value.currentSession.samples.size - 1
        val newIdx = (ratio * maxIdx).toInt().coerceIn(0, maxIdx)
        _uiState.update { it.copy(currentIndex = newIdx) }
    }

    fun togglePlayback() {
        val currentlyPlaying = _uiState.value.isPlaying
        if (currentlyPlaying) {
            playbackJob?.cancel()
            _uiState.update { it.copy(isPlaying = false) }
        } else {
            _uiState.update { it.copy(isPlaying = true) }
            playbackJob = viewModelScope.launch {
                while (isActive) {
                    delay(50) // 20 Hz tick
                    val cur = _uiState.value.currentIndex
                    val maxIdx = _uiState.value.currentSession.samples.size - 1
                    val next = if (cur >= maxIdx) 0 else cur + 1
                    _uiState.update { it.copy(currentIndex = next) }
                }
            }
        }
    }

    fun updateCustomParam(
        pedalExponent: Double? = null,
        torqueRamp: Double? = null,
        shiftMs: Double? = null,
        dampingRatio: Double? = null,
        diffLockPct: Double? = null,
        wingDeg: Double? = null
    ) {
        val cur = _uiState.value.customCalibration
        val updated = cur.copy(
            pedalResponseExponent = pedalExponent ?: cur.pedalResponseExponent,
            maxTorqueRampNmPerSec = torqueRamp ?: cur.maxTorqueRampNmPerSec,
            shiftDurationMs = shiftMs ?: cur.shiftDurationMs,
            dampingStiffnessRatio = dampingRatio ?: cur.dampingStiffnessRatio,
            diffPowerLockupPct = diffLockPct ?: cur.diffPowerLockupPct,
            activeAeroWingDeg = wingDeg ?: cur.activeAeroWingDeg
        )
        _uiState.update { it.copy(customCalibration = updated) }
        if (_uiState.value.selectedMode == DriveModeType.CUSTOM) {
            selectMode(DriveModeType.CUSTOM)
        }
    }

    fun updateWeight(
        weightResponse: Double? = null,
        weightAccel: Double? = null,
        weightYaw: Double? = null,
        weightTraction: Double? = null,
        weightThermal: Double? = null
    ) {
        val cur = _uiState.value.optimizerWeights
        val updated = cur.copy(
            weightResponseTime = weightResponse ?: cur.weightResponseTime,
            weightAcceleration = weightAccel ?: cur.weightAcceleration,
            weightYawPrecision = weightYaw ?: cur.weightYawPrecision,
            weightCornerExitTraction = weightTraction ?: cur.weightCornerExitTraction,
            weightThermalSafety = weightThermal ?: cur.weightThermalSafety
        )
        _uiState.update { it.copy(optimizerWeights = updated) }
    }

    fun runOptimization() {
        viewModelScope.launch {
            _uiState.update { it.copy(isOptimizing = true) }
            val proposal = CalibrationOptimizer.optimizeSuperSport(
                baseline = DriveModeCalibration.SUPERSPORT,
                weights = _uiState.value.optimizerWeights,
                vehicle = _uiState.value.vehicleProfile
            )
            _uiState.update {
                it.copy(
                    isOptimizing = false,
                    latestProposal = proposal,
                    customCalibration = proposal.candidate
                )
            }
        }
    }

    fun setExportModal(content: String?) {
        _uiState.update { it.copy(exportModalContent = content) }
    }
}
