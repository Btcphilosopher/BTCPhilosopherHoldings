package com.example.supersportr.simulation

import com.example.supersportr.model.DriveModeCalibration
import com.example.supersportr.model.PowertrainConfig
import kotlin.math.PI
import kotlin.math.pow

data class PowertrainState(
    val requestedTorqueNm: Double,
    val deliveredEngineTorqueNm: Double,
    val deliveredMotorTorqueNm: Double,
    val combinedTorqueNm: Double,
    val combinedPowerKw: Double,
    val combinedPowerHp: Double,
    val batterySocPct: Double,
    val inverterTempC: Double,
    val lh2RailPressureBar: Double,
    val cryoIntakeTempDropC: Double,
    val constraintActive: Boolean,
    val constraintReason: String?
)

object PowertrainEngine {

    /**
     * McLaren 4.0L 90° V8 Twin-Turbo + Liquid Hydrogen Injection curve.
     * Peak Torque: 1,000 Nm @ 6,000 RPM.
     * Engine Power: 850 hp @ 9,000 RPM.
     * Redline: 10,000 RPM.
     */
    fun getPeakEngineTorque(rpm: Double, config: PowertrainConfig): Double {
        if (rpm < config.engineIdleRpm) return 0.0
        if (rpm > config.engineRedlineRpm) return 0.0
        return when {
            rpm < 2000.0 -> 450.0 + (rpm - config.engineIdleRpm) / 1050.0 * 250.0
            rpm < 4000.0 -> 700.0 + (rpm - 2000.0) / 2000.0 * 200.0
            rpm <= 6000.0 -> 900.0 + (rpm - 4000.0) / 2000.0 * 100.0 // Ramps to 1,000 Nm @ 6,000 RPM
            rpm <= 8000.0 -> 1000.0 - (rpm - 6000.0) / 2000.0 * 120.0 // 880 Nm @ 8,000 RPM (720 kW / 978 hp combined)
            rpm <= 9000.0 -> 880.0 - (rpm - 8000.0) / 1000.0 * 190.0  // 690 Nm @ 9,000 RPM -> 850 hp engine power
            else -> 690.0 - (rpm - 9000.0) / 1000.0 * 160.0          // Taper to 10,000 RPM redline
        }
    }

    /**
     * Hybrid electric e-axle assist:
     * 200 hp (147 kW) electric motor output, 200 Nm instant torque.
     */
    fun getPeakElectricMotorTorque(rpm: Double, config: PowertrainConfig): Double {
        val peakTorque = config.peakElectricMotorTorqueNm // 200 Nm
        val peakPowerWatts = config.electricMotorPowerKw * 1000.0 // 147 kW
        if (rpm <= 100.0) return peakTorque
        val omega = (rpm * 2.0 * PI) / 60.0
        val torqueAtPowerLimit = peakPowerWatts / omega
        return minOf(peakTorque, torqueAtPowerLimit)
    }

    /**
     * Map accelerator pedal input (0.0 to 1.0) through calibration shape to requested torque.
     */
    fun calculateRequestedTorque(
        pedalInput: Double,
        rpm: Double,
        cal: DriveModeCalibration,
        config: PowertrainConfig
    ): Double {
        val deadband = cal.pedalDeadbandPct / 100.0
        if (pedalInput <= deadband) return 0.0
        val effectivePedal = ((pedalInput - deadband) / (1.0 - deadband)).coerceIn(0.0, 1.0)
        
        // Non-linear pedal transfer curve
        val pedalFactor = effectivePedal.pow(cal.pedalResponseExponent)
        
        val maxAvailableTorque = getPeakEngineTorque(rpm, config) + getPeakElectricMotorTorque(rpm, config)
        return pedalFactor * maxAvailableTorque
    }

    /**
     * Step the powertrain delivery with cryogenic LH2 injection, torque ramping, hybrid blending, and thermal constraints.
     */
    fun calculateDelivery(
        requestedTorque: Double,
        previousCombinedTorque: Double,
        rpm: Double,
        isShifting: Boolean,
        batterySocPct: Double,
        inverterTempC: Double,
        dtSeconds: Double,
        cal: DriveModeCalibration,
        config: PowertrainConfig
    ): PowertrainState {
        // 1. Rate limiter on torque request
        val maxStepNm = cal.maxTorqueRampNmPerSec * dtSeconds
        val rampedTorque = previousCombinedTorque + (requestedTorque - previousCombinedTorque).coerceIn(-maxStepNm * 2.5, maxStepNm)
        
        // 2. Cryogenic Hydrogen Injection & Rail Pressure
        // 700 bar rail pressure modulated based on engine load & RPM
        val loadRatio = (rampedTorque / 1150.0).coerceIn(0.1, 1.0)
        val lh2RailPressure = (350.0 + loadRatio * 350.0).coerceIn(350.0, config.hydrogenSystem.maxRailPressureBar)
        val cryoTempDrop = 25.0 + loadRatio * config.hydrogenSystem.chargeCoolingTempDropC

        // 3. Peak capabilities with Cryogenic charge-cooling density gain (+12% air mass flow)
        val cryoDensityMultiplier = 1.0 + (cryoTempDrop / 300.0) * 0.4
        val maxEngineTq = getPeakEngineTorque(rpm, config) * minOf(1.08, cryoDensityMultiplier)
        var maxMotorTq = getPeakElectricMotorTorque(rpm, config)

        // 4. Thermal & SoC constraints
        var constraintActive = false
        var constraintReason: String? = null

        if (batterySocPct < 15.0) {
            val socDerate = (batterySocPct / 15.0).coerceIn(0.2, 1.0)
            maxMotorTq *= socDerate
            constraintActive = true
            constraintReason = "Battery SoC low (${String.format("%.1f", batterySocPct)}%): Hybrid derate active"
        }

        if (inverterTempC > cal.thermalLimitInverterC) {
            val thermalExceed = inverterTempC - cal.thermalLimitInverterC
            val thermalDerate = (1.0 - thermalExceed * 0.08).coerceIn(0.2, 1.0)
            maxMotorTq *= thermalDerate
            constraintActive = true
            constraintReason = "Inverter temperature high (${String.format("%.1f", inverterTempC)}°C): Hybrid derate active"
        }

        // 5. Handle gear shift torque-interruption vs hybrid torque fill
        val deliveredEngineTq: Double
        val deliveredMotorTq: Double

        if (isShifting) {
            deliveredEngineTq = 0.0
            val shiftFillTarget = rampedTorque * cal.hybridTorqueFillPct
            deliveredMotorTq = minOf(shiftFillTarget, maxMotorTq)
        } else {
            val desiredMotorTq = minOf(rampedTorque * 0.22, maxMotorTq)
            val desiredEngineTq = (rampedTorque - desiredMotorTq).coerceIn(0.0, maxEngineTq)
            
            deliveredEngineTq = desiredEngineTq
            val remainder = (rampedTorque - deliveredEngineTq).coerceIn(0.0, maxMotorTq)
            deliveredMotorTq = remainder
        }

        val totalCombinedTq = deliveredEngineTq + deliveredMotorTq
        if (rampedTorque > totalCombinedTq + 8.0 && !isShifting) {
            constraintActive = true
            if (constraintReason == null) {
                constraintReason = "Powertrain physical capacity clipped: Requested ${rampedTorque.toInt()} Nm > Feasible ${totalCombinedTq.toInt()} Nm"
            }
        }

        val omega = (rpm * 2.0 * PI) / 60.0
        val totalPowerKw = (totalCombinedTq * omega) / 1000.0
        val totalPowerHp = totalPowerKw * 1.35962

        return PowertrainState(
            requestedTorqueNm = requestedTorque,
            deliveredEngineTorqueNm = deliveredEngineTq,
            deliveredMotorTorqueNm = deliveredMotorTq,
            combinedTorqueNm = totalCombinedTq,
            combinedPowerKw = totalPowerKw,
            combinedPowerHp = totalPowerHp,
            batterySocPct = batterySocPct,
            inverterTempC = inverterTempC,
            lh2RailPressureBar = lh2RailPressure,
            cryoIntakeTempDropC = cryoTempDrop,
            constraintActive = constraintActive,
            constraintReason = constraintReason
        )
    }
}
