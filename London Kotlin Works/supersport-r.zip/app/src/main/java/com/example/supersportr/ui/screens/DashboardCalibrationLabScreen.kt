package com.example.supersportr.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.supersportr.model.DriveModeCalibration
import com.example.supersportr.model.DriveModeType
import com.example.supersportr.ui.viewmodel.EngineeringUiState
import com.example.ui.theme.CarbonDarkBlack
import com.example.ui.theme.DarkNavyGraphite
import com.example.ui.theme.McLarenPapaya
import com.example.ui.theme.SlateCardBorder
import com.example.ui.theme.SlateCardSurface
import com.example.ui.theme.TechnicalMuted
import com.example.ui.theme.TechnicalSubtle
import com.example.ui.theme.TechnicalWhite
import com.example.ui.theme.TelemetryAmber
import com.example.ui.theme.TelemetryCyan
import com.example.ui.theme.TelemetryGreen
import com.example.ui.theme.TelemetryRed

@Composable
fun DashboardCalibrationLabScreen(
    state: EngineeringUiState,
    onUpdateCustomParam: (Double?, Double?, Double?, Double?, Double?, Double?) -> Unit,
    onUpdateWeight: (Double?, Double?, Double?, Double?, Double?) -> Unit,
    onRunOptimization: () -> Unit,
    onOpenExport: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val proposal = state.latestProposal
    val custom = state.customCalibration

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CarbonDarkBlack)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Header Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SlateCardSurface)
                    .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "CALIBRATION & OPTIMISATION LABORATORY",
                                color = TechnicalWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Bounded Parameter Search & Multi-Objective Objective Evaluation",
                                color = McLarenPapaya,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Button(
                            onClick = onRunOptimization,
                            colors = ButtonDefaults.buttonColors(containerColor = McLarenPapaya),
                            shape = RoundedCornerShape(6.dp),
                            enabled = !state.isOptimizing,
                            modifier = Modifier.testTag("run_optimization_btn")
                        ) {
                            if (state.isOptimizing) {
                                CircularProgressIndicator(color = CarbonDarkBlack, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            } else {
                                Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = CarbonDarkBlack, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("OPTIMIZE", color = CarbonDarkBlack, fontSize = 11.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }

        // 2. Drive Modes Side-by-Side Comparison Matrix
        item {
            DriveModeComparisonMatrix(modifier = Modifier.fillMaxWidth())
        }

        // 3. Interactive Research Calibration Tuning Sliders
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SlateCardSurface)
                    .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Tune, contentDescription = null, tint = McLarenPapaya, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "INTERACTIVE PARAMETER TUNING // CUSTOM PROFILE",
                            color = TechnicalWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Slider 1: Pedal Exponent
                    CalibrationSliderRow(
                        label = "Pedal Response Exponent",
                        valueStr = String.format("%.2f", custom.pedalResponseExponent),
                        unit = "(0.70 - 1.30)",
                        value = custom.pedalResponseExponent.toFloat(),
                        range = 0.70f..1.30f,
                        onValueChange = { onUpdateCustomParam(it.toDouble(), null, null, null, null, null) }
                    )

                    // Slider 2: Max Torque Ramp
                    CalibrationSliderRow(
                        label = "Max Torque Ramp Rate",
                        valueStr = "${custom.maxTorqueRampNmPerSec.toInt()}",
                        unit = "Nm/s (800 - 3800)",
                        value = custom.maxTorqueRampNmPerSec.toFloat(),
                        range = 800f..3800f,
                        onValueChange = { onUpdateCustomParam(null, it.toDouble(), null, null, null, null) }
                    )

                    // Slider 3: Shift Duration
                    CalibrationSliderRow(
                        label = "Shift Duration Target",
                        valueStr = "${custom.shiftDurationMs.toInt()}",
                        unit = "ms (35 - 120)",
                        value = custom.shiftDurationMs.toFloat(),
                        range = 35f..120f,
                        onValueChange = { onUpdateCustomParam(null, null, it.toDouble(), null, null, null) }
                    )

                    // Slider 4: Damping Stiffness Ratio
                    CalibrationSliderRow(
                        label = "Damping Stiffness Multiplier",
                        valueStr = String.format("%.2f", custom.dampingStiffnessRatio),
                        unit = "x (0.75 - 1.60)",
                        value = custom.dampingStiffnessRatio.toFloat(),
                        range = 0.75f..1.60f,
                        onValueChange = { onUpdateCustomParam(null, null, null, it.toDouble(), null, null) }
                    )

                    // Slider 5: Exit Diff Lockup
                    CalibrationSliderRow(
                        label = "Corner Exit E-Diff Lockup",
                        valueStr = "${custom.diffPowerLockupPct.toInt()}",
                        unit = "% (35 - 85)",
                        value = custom.diffPowerLockupPct.toFloat(),
                        range = 35f..85f,
                        onValueChange = { onUpdateCustomParam(null, null, null, null, it.toDouble(), null) }
                    )

                    // Slider 6: Active Aero Wing
                    CalibrationSliderRow(
                        label = "Active Aero Wing Angle",
                        valueStr = "${custom.activeAeroWingDeg.toInt()}",
                        unit = "deg (0 - 28)",
                        value = custom.activeAeroWingDeg.toFloat(),
                        range = 0f..28f,
                        onValueChange = { onUpdateCustomParam(null, null, null, null, null, it.toDouble()) }
                    )
                }
            }
        }

        // 4. Optimization Proposal & Objective Breakdown (Baseline vs Candidate)
        if (proposal != null) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(SlateCardSurface)
                        .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "OPTIMIZED CANDIDATE DELTA REPORT",
                                color = TechnicalWhite,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Row {
                                OutlinedButton(
                                    onClick = { onOpenExport(proposal.exportJson) },
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.padding(end = 6.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(13.dp), tint = TelemetryCyan)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("JSON", color = TelemetryCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                }
                                OutlinedButton(
                                    onClick = { onOpenExport(proposal.exportRScript) },
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(13.dp), tint = McLarenPapaya)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("R SCRIPT", color = McLarenPapaya, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Parameter deltas
                        proposal.deltas.forEach { delta ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(delta.parameterName, color = TechnicalMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                Text(
                                    text = "${String.format("%.2f", delta.baselineValue)} -> ${String.format("%.2f", delta.candidateValue)} ${delta.unit} (${String.format("%+.1f", delta.deltaPct)}%)",
                                    color = if (delta.deltaPct != 0.0) McLarenPapaya else TechnicalWhite,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Score Comparison
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Baseline Score: ${String.format("%.1f", proposal.baselineScore.totalScore)}", color = TechnicalMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                Text("Constraint Violations: ${proposal.baselineScore.constraintViolations}", color = TechnicalMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Candidate Score: ${String.format("%.1f", proposal.candidateScore.totalScore)}", color = TelemetryGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text("Constraint Violations: ${proposal.candidateScore.constraintViolations}", color = if (proposal.candidateScore.constraintViolations > 0) TelemetryAmber else TelemetryGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }

            // 5. Sensitivity Analysis
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(SlateCardSurface)
                        .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = "LOCAL PARAMETER SENSITIVITY GRADIENT",
                            color = TechnicalWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        proposal.sensitivityMap.forEach { (name, sens) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(name, color = TechnicalMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(130.dp))
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(DarkNavyGraphite)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth(sens.toFloat())
                                            .height(6.dp)
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(McLarenPapaya)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(String.format("%.2f", sens), color = TechnicalWhite, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(14.dp))
        }
    }
}

@Composable
private fun CalibrationSliderRow(
    label: String,
    valueStr: String,
    unit: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = TechnicalWhite, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            Text("$valueStr $unit", color = McLarenPapaya, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = McLarenPapaya,
                activeTrackColor = McLarenPapaya,
                inactiveTrackColor = DarkNavyGraphite
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun DriveModeComparisonMatrix(modifier: Modifier = Modifier) {
    val modes = listOf(
        DriveModeCalibration.COMFORT,
        DriveModeCalibration.SPORT,
        DriveModeCalibration.SUPERSPORT,
        DriveModeCalibration.TRACK
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(SlateCardSurface)
            .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Column {
            Text(
                text = "DRIVE-MODE CALIBRATION ARCHITECTURE MATRIX",
                color = TechnicalWhite,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Headers
            Row(modifier = Modifier.fillMaxWidth()) {
                Text("MODE", color = TechnicalSubtle, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                Text("PEDAL", color = TechnicalSubtle, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                Text("RAMP", color = TechnicalSubtle, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                Text("SHIFT", color = TechnicalSubtle, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                Text("DIFF", color = TechnicalSubtle, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                Text("WING", color = TechnicalSubtle, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
            }
            Spacer(modifier = Modifier.height(4.dp))

            modes.forEach { m ->
                val isSS = m.type == DriveModeType.SUPERSPORT
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                ) {
                    Text(
                        text = m.type.label,
                        color = if (isSS) McLarenPapaya else TechnicalWhite,
                        fontWeight = if (isSS) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.weight(1.2f)
                    )
                    Text("${m.pedalResponseExponent}", color = TechnicalMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                    Text("${m.maxTorqueRampNmPerSec.toInt()}", color = TechnicalMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text("${m.shiftDurationMs.toInt()}ms", color = TechnicalMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                    Text("${m.diffPowerLockupPct.toInt()}%", color = TechnicalMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                    Text("${m.activeAeroWingDeg.toInt()}°", color = TechnicalMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                }
            }
        }
    }
}
