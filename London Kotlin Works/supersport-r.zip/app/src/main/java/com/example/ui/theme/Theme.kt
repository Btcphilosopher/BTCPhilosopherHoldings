package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val SuperSportColorScheme = darkColorScheme(
    primary = McLarenPapaya,
    onPrimary = CarbonDarkBlack,
    primaryContainer = McLarenPapayaDark,
    onPrimaryContainer = TechnicalWhite,
    secondary = TelemetryCyan,
    onSecondary = CarbonDarkBlack,
    secondaryContainer = DarkNavyGraphite,
    onSecondaryContainer = TechnicalWhite,
    tertiary = TelemetryGreen,
    onTertiary = CarbonDarkBlack,
    background = CarbonDarkBlack,
    onBackground = TechnicalWhite,
    surface = DarkNavyGraphite,
    onSurface = TechnicalWhite,
    surfaceVariant = SlateCardSurface,
    onSurfaceVariant = TechnicalMuted,
    outline = SlateCardBorder,
    error = TelemetryRed,
    onError = TechnicalWhite
)

@Composable
fun SuperSportRTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SuperSportColorScheme,
        typography = Typography,
        content = content
    )
}
