package com.example.supersportr.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkNavyGraphite
import com.example.ui.theme.McLarenPapaya
import com.example.ui.theme.SlateCardBorder
import com.example.ui.theme.SlateCardSurface
import com.example.ui.theme.TechnicalMuted
import com.example.ui.theme.TechnicalSubtle
import com.example.ui.theme.TechnicalWhite
import com.example.ui.theme.TelemetryCyan

data class WaveformSeries(
    val name: String,
    val color: Color,
    val values: List<Double>,
    val unit: String
)

@Composable
fun TelemetryWaveform(
    title: String,
    subtitle: String,
    series: List<WaveformSeries>,
    currentCursorRatio: Float, // 0.0 to 1.0 (corresponds to position in time)
    onScrubRatio: (Float) -> Unit,
    modifier: Modifier = Modifier,
    canvasHeight: Int = 130
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(SlateCardSurface)
            .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title.uppercase(),
                        color = TechnicalWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = subtitle.uppercase(),
                        color = TechnicalSubtle,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Series legend items
                Row(verticalAlignment = Alignment.CenterVertically) {
                    series.forEach { s ->
                        val curVal = if (s.values.isNotEmpty()) {
                            val idx = (currentCursorRatio * (s.values.size - 1)).toInt().coerceIn(0, s.values.size - 1)
                            s.values[idx]
                        } else 0.0

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(start = 10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(7.dp)
                                    .height(7.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(s.color)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${s.name}: ${String.format("%.1f", curVal)} ${s.unit}",
                                color = s.color,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Waveform canvas with touch scrubbing
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(canvasHeight.dp)
                    .pointerInput(Unit) {
                        detectTapGestures { offset ->
                            val ratio = (offset.x / size.width).coerceIn(0f, 1f)
                            onScrubRatio(ratio)
                        }
                    }
                    .pointerInput(Unit) {
                        detectDragGestures { change, _ ->
                            change.consume()
                            val ratio = (change.position.x / size.width).coerceIn(0f, 1f)
                            onScrubRatio(ratio)
                        }
                    }
            ) {
                val w = size.width
                val h = size.height

                // Draw background grid lines (horizontal 4 lines)
                val gridLines = 4
                for (g in 0..gridLines) {
                    val y = (h / gridLines) * g
                    drawLine(
                        color = Color(0xFF1E293B),
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 1f
                    )
                }

                // Draw vertical grid lines (every 25%)
                for (v in 1..3) {
                    val x = (w / 4f) * v
                    drawLine(
                        color = Color(0xFF1E293B),
                        start = Offset(x, 0f),
                        end = Offset(x, h),
                        strokeWidth = 1f
                    )
                }

                // Render each series curve
                series.forEach { s ->
                    if (s.values.size >= 2) {
                        val minV = s.values.minOrNull() ?: 0.0
                        val maxV = s.values.maxOrNull() ?: 1.0
                        val range = if (maxV - minV <= 0.001) 1.0 else maxV - minV

                        val path = Path()
                        val stepX = w / (s.values.size - 1).toFloat()

                        s.values.forEachIndexed { i, v ->
                            val normY = ((v - minV) / range).toFloat().coerceIn(0f, 1f)
                            val px = i * stepX
                            val py = h - (normY * (h - 10f) + 5f)

                            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                        }

                        drawPath(
                            path = path,
                            color = s.color,
                            style = Stroke(width = 2.2f)
                        )
                    }
                }

                // Draw interactive cursor line
                val cursorX = (currentCursorRatio * w).coerceIn(0f, w)
                drawLine(
                    color = TechnicalWhite.copy(alpha = 0.85f),
                    start = Offset(cursorX, 0f),
                    end = Offset(cursorX, h),
                    strokeWidth = 1.5f
                )
                drawCircle(
                    color = McLarenPapaya,
                    radius = 3.5f,
                    center = Offset(cursorX, h / 2f)
                )
            }
        }
    }
}
