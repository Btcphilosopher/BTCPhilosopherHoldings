package com.example.supersportr.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.supersportr.model.TelemetrySample
import com.example.ui.theme.DarkNavyGraphite
import com.example.ui.theme.McLarenPapaya
import com.example.ui.theme.SlateCardBorder
import com.example.ui.theme.SlateCardSurface
import com.example.ui.theme.TechnicalMuted
import com.example.ui.theme.TechnicalSubtle
import com.example.ui.theme.TechnicalWhite
import com.example.ui.theme.TelemetryAmber
import com.example.ui.theme.TelemetryCyan
import com.example.ui.theme.TelemetryGreen
import com.example.ui.theme.TelemetryRed

@Composable
fun TechnicalGauges(
    sample: TelemetrySample?,
    modifier: Modifier = Modifier
) {
    val speedKmh = sample?.speedKmh ?: 0.0
    val rpm = sample?.engineRpm ?: 900.0
    val gear = sample?.currentGear ?: 1
    val isShifting = sample?.shiftInProgress ?: false
    val powerKw = sample?.totalPowerKw ?: 0.0
    val powerHp = powerKw * 1.35962
    val soc = sample?.batterySocPct ?: 85.0
    val invTemp = sample?.inverterTempC ?: 60.0
    val tyreTemp = sample?.tyreTempAvgC ?: 75.0
    val brakeTemp = sample?.brakeTempAvgC ?: 180.0

    val rpmRatio = ((rpm - 900.0) / (8500.0 - 900.0)).coerceIn(0.0, 1.0).toFloat()
    val isNearRedline = rpm > 8100.0

    val tachColor by animateColorAsState(
        targetValue = when {
            isShifting -> TelemetryCyan
            isNearRedline -> TelemetryRed
            rpm > 6500.0 -> McLarenPapaya
            else -> TelemetryGreen
        }, label = "tachColor"
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(SlateCardSurface)
            .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Column {
            // Top Primary Metrics Row: Speed + Gear + Power
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Speed Digital Display
                Column {
                    Text(
                        text = "VELOCITY",
                        color = TechnicalSubtle,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = "${speedKmh.toInt()}",
                            color = TechnicalWhite,
                            fontSize = 34.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "KM/H",
                            color = McLarenPapaya,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }
                }

                // Gear Box Indicator
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(DarkNavyGraphite)
                        .border(
                            width = 1.5.dp,
                            color = if (isShifting) TelemetryCyan else McLarenPapaya,
                            shape = RoundedCornerShape(6.dp)
                        )
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (isShifting) "SHIFT" else "GEAR",
                            color = if (isShifting) TelemetryCyan else TechnicalSubtle,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = if (isShifting) ">>" else "$gear",
                            color = TechnicalWhite,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Power Display
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "DELIVERED POWER",
                        color = TechnicalSubtle,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = "${powerKw.toInt()}",
                            color = TechnicalWhite,
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "kW",
                            color = TelemetryCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                    }
                    Text(
                        text = "${powerHp.toInt()} BHP COMBINED",
                        color = TechnicalMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Tachometer RPM Bar
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "V8 ENGINE SPEED: ${rpm.toInt()} RPM",
                        color = TechnicalWhite,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "8500 REDLINE",
                        color = if (isNearRedline) TelemetryRed else TechnicalSubtle,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                // RPM Progress track
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(DarkNavyGraphite)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(rpmRatio)
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(tachColor)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Lower Status Grid: Hybrid Battery SoC, Inverter Temp, Tyre Temp, Brake Temp
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatusMetricPill(
                    label = "BATT SOC",
                    value = "${soc.toInt()}%",
                    color = if (soc < 20.0) TelemetryRed else TelemetryCyan,
                    modifier = Modifier.weight(1f)
                )
                StatusMetricPill(
                    label = "INV TEMP",
                    value = "${invTemp.toInt()}°C",
                    color = if (invTemp > 90.0) TelemetryRed else TechnicalWhite,
                    modifier = Modifier.weight(1f)
                )
                StatusMetricPill(
                    label = "TYRE TEMP",
                    value = "${tyreTemp.toInt()}°C",
                    color = if (tyreTemp in 85.0..105.0) TelemetryGreen else TelemetryAmber,
                    modifier = Modifier.weight(1f)
                )
                StatusMetricPill(
                    label = "BRAKE TEMP",
                    value = "${brakeTemp.toInt()}°C",
                    color = if (brakeTemp > 700.0) TelemetryRed else TechnicalWhite,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun StatusMetricPill(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(DarkNavyGraphite)
            .border(1.dp, SlateCardBorder, RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 6.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text(
                text = label,
                color = TechnicalSubtle,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                color = color,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
