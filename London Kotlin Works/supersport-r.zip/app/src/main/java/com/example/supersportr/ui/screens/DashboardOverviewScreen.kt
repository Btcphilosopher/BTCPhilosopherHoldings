package com.example.supersportr.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.supersportr.ui.components.GGDiagram
import com.example.supersportr.ui.components.TechnicalGauges
import com.example.supersportr.ui.components.TelemetryWaveform
import com.example.supersportr.ui.components.WaveformSeries
import com.example.supersportr.ui.viewmodel.EngineeringUiState
import com.example.ui.theme.CarbonDarkBlack
import com.example.ui.theme.DarkNavyGraphite
import com.example.ui.theme.McLarenPapaya
import com.example.ui.theme.SlateCardBorder
import com.example.ui.theme.SlateCardSurface
import com.example.ui.theme.TechnicalMuted
import com.example.ui.theme.TechnicalSubtle
import com.example.ui.theme.TechnicalWhite
import com.example.ui.theme.TelemetryAmber
import com.example.ui.theme.TelemetryCyan
import com.example.ui.theme.TelemetryGreen
import com.example.ui.theme.TelemetryRed

@Composable
fun DashboardOverviewScreen(
    state: EngineeringUiState,
    onScrubRatio: (Float) -> Unit,
    onTogglePlayback: () -> Unit,
    modifier: Modifier = Modifier
) {
    val sample = state.currentSample
    val session = state.currentSession

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CarbonDarkBlack)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Simulation Scrub & Playback Controller Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SlateCardSurface)
                    .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "SIMULATION TIMELINE // REPRODUCIBLE SCENARIO",
                                color = TechnicalWhite,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            val tS = sample?.timestampS ?: 0.0
                            val dist = sample?.distanceM ?: 0.0
                            Text(
                                text = "T+${String.format("%.2f", tS)}s / ${String.format("%.2f", session.totalTimeS)}s  |  DIST: ${dist.toInt()} m",
                                color = McLarenPapaya,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Button(
                            onClick = onTogglePlayback,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (state.isPlaying) TelemetryAmber else McLarenPapaya
                            ),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.testTag("playback_toggle_btn")
                        ) {
                            Icon(
                                imageVector = if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (state.isPlaying) "Pause" else "Play",
                                tint = CarbonDarkBlack,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (state.isPlaying) "PAUSE" else "PLAY",
                                color = CarbonDarkBlack,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Slider(
                        value = state.scrubRatio,
                        onValueChange = { onScrubRatio(it) },
                        colors = SliderDefaults.colors(
                            thumbColor = McLarenPapaya,
                            activeTrackColor = McLarenPapaya,
                            inactiveTrackColor = DarkNavyGraphite
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("timeline_scrub_slider")
                    )
                }
            }
        }

        // 2. Super-Sport Mode Circular Cockpit Cluster (from McLaren Titanium infographic)
        item {
            com.example.supersportr.ui.components.SuperSportCockpitCluster(
                sample = sample,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 3. Physical Feasibility / Constraint Alert Box
        item {
            val isConstraint = sample?.constraintActive == true
            val constraintMsg = sample?.constraintReason ?: "Powertrain & chassis operating within physical feasible envelope."

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isConstraint) Color(0xFF241515) else Color(0xFF101D1A))
                    .border(
                        width = 1.dp,
                        color = if (isConstraint) TelemetryRed else TelemetryGreen.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(8.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isConstraint) Icons.Default.Warning else Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = if (isConstraint) TelemetryRed else TelemetryGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (isConstraint) "PHYSICAL CONSTRAINT DETECTED // TORQUE / SLIP CLIPPED" else "PHYSICALLY FEASIBLE DYNAMICS // COHERENT DELIVERY",
                            color = if (isConstraint) TelemetryRed else TelemetryGreen,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = constraintMsg,
                            color = TechnicalMuted,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // 3. Technical Cockpit Gauges
        item {
            TechnicalGauges(
                sample = sample,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 4. G-G Friction Circle
        item {
            GGDiagram(
                currentSample = sample,
                recentTrail = state.currentTrail,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 5. Longitudinal Speed & Power Waveform
        item {
            val speedSeries = WaveformSeries(
                name = "SPEED",
                color = McLarenPapaya,
                values = session.samples.map { it.speedKmh },
                unit = "km/h"
            )
            val powerSeries = WaveformSeries(
                name = "POWER",
                color = TelemetryCyan,
                values = session.samples.map { it.totalPowerKw },
                unit = "kW"
            )

            TelemetryWaveform(
                title = "Longitudinal Performance Trace",
                subtitle = "Speed (km/h) & Combined Power Delivery (kW)",
                series = listOf(speedSeries, powerSeries),
                currentCursorRatio = state.scrubRatio,
                onScrubRatio = onScrubRatio,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 6. Accelerations & Yaw Rate Waveform
        item {
            val axSeries = WaveformSeries(
                name = "Ax (Long)",
                color = TelemetryGreen,
                values = session.samples.map { it.axG },
                unit = "G"
            )
            val aySeries = WaveformSeries(
                name = "Ay (Lat)",
                color = TelemetryAmber,
                values = session.samples.map { it.ayG },
                unit = "G"
            )
            val yawSeries = WaveformSeries(
                name = "Yaw Rate",
                color = TechnicalWhite,
                values = session.samples.map { it.yawRateDegS },
                unit = "°/s"
            )

            TelemetryWaveform(
                title = "Vehicle Kinematic Accelerations",
                subtitle = "Longitudinal G, Lateral G & Yaw Rate Response",
                series = listOf(axSeries, aySeries, yawSeries),
                currentCursorRatio = state.scrubRatio,
                onScrubRatio = onScrubRatio,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 7. Profile Quick Summary Footer Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SlateCardSurface)
                    .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "PROFILE TELEMETRY HEALTH SUMMARY",
                        color = TechnicalWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Mode: ${state.selectedMode.label}",
                            color = TechnicalMuted,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Constraint Events: ${session.constraintEventCount}",
                            color = if (session.constraintEventCount > 0) TelemetryAmber else TelemetryGreen,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Completeness: ${String.format("%.1f", session.dataCompletenessPct)}%",
                            color = TechnicalWhite,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }
    }
}
