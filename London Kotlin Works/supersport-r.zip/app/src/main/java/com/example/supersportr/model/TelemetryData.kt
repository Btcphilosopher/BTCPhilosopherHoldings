package com.example.supersportr.model

data class TelemetrySample(
    val timestampS: Double,
    val distanceM: Double,
    val speedKmh: Double,
    val speedMs: Double,
    val throttlePct: Double,
    val brakePressureBar: Double,
    val steeringAngleDeg: Double,
    val engineRpm: Double,
    val currentGear: Int,
    val shiftInProgress: Boolean,
    
    // Powertrain & Hybrid delivery
    val requestedTorqueNm: Double,
    val engineTorqueDeliveredNm: Double,
    val motorTorqueDeliveredNm: Double,
    val combinedTorqueDeliveredNm: Double,
    val totalPowerKw: Double,
    val totalPowerHp: Double, // Real-time calculated BHP
    val batterySocPct: Double,
    val inverterTempC: Double,
    
    // Liquid Hydrogen Injection Telemetry
    val lh2RailPressureBar: Double = 680.0, // up to 700 bar
    val lh2TankTempC: Double = -253.0,     // cryogenic liquid hydrogen
    val cryoIntakeTempDropC: Double = 38.0, // charge air temperature drop
    val exhaustWaterVapourGs: Double = 14.5, // pure water vapour
    val emissionsCo2GPerKm: Double = 0.0,
    
    // Dynamics & Acceleration
    val axG: Double,
    val ayG: Double,
    val yawRateDegS: Double,
    val rollAngleDeg: Double,
    val pitchAngleDeg: Double,
    
    // Tyre & Chassis
    val tyreSlipPct: Double,
    val flLoadN: Double,
    val frLoadN: Double,
    val rlLoadN: Double,
    val rrLoadN: Double,
    val tyreTempAvgC: Double,
    val brakeTempAvgC: Double,
    val diffLockPct: Double,
    
    // Aerodynamics
    val aeroDownforceN: Double,
    val aeroDragN: Double,
    val activeWingAngleDeg: Double,
    
    // Quality & Event Flags
    val constraintActive: Boolean,
    val constraintReason: String? = null,
    val sensorQualityOk: Boolean = true,
    val sectorId: Int = 1
)

data class LapSectorSummary(
    val sectorId: Int,
    val sectorName: String,
    val durationS: Double,
    val entrySpeedKmh: Double,
    val exitSpeedKmh: Double,
    val maxLatG: Double,
    val peakLongG: Double,
    val maxBrakeBar: Double,
    val energyUsedKwh: Double,
    val waterVapourProducedG: Double = 120.0
)

data class LapSessionData(
    val sessionId: String,
    val sessionTimestamp: String,
    val modeType: DriveModeType,
    val totalTimeS: Double,
    val totalDistanceM: Double,
    val samples: List<TelemetrySample>,
    val sectorSummaries: List<LapSectorSummary>,
    val constraintEventCount: Int,
    val dataCompletenessPct: Double,
    val missingIntervalsCount: Int
)
