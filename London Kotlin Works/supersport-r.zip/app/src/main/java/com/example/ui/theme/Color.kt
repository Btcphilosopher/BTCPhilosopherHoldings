package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Visual Identity: McLaren Motorsport Engineering (Carbon, Dark Navy, Restrained Papaya)
val McLarenPapaya = Color(0xFFFF7700)
val McLarenPapayaLight = Color(0xFFFFA040)
val McLarenPapayaDark = Color(0xFFCC5E00)

val CarbonDarkBlack = Color(0xFF090C10)
val DarkNavyGraphite = Color(0xFF101622)
val SlateCardSurface = Color(0xFF172030)
val SlateCardBorder = Color(0xFF26354A)

val TechnicalWhite = Color(0xFFF8FAFC)
val TechnicalMuted = Color(0xFF94A3B8)
val TechnicalSubtle = Color(0xFF64748B)

val TelemetryCyan = Color(0xFF38BDF8) // Electric / Hybrid
val TelemetryGreen = Color(0xFF10B981) // Feasible / OK
val TelemetryAmber = Color(0xFFF59E0B) // Warning / Slip
val TelemetryRed = Color(0xFFEF4444)   // Constraint / Thermal clip
val TelemetryPurple = Color(0xFFA855F7) // Aero downforce
