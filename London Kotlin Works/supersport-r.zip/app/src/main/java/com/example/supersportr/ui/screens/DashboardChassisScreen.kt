package com.example.supersportr.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.supersportr.ui.components.TelemetryWaveform
import com.example.supersportr.ui.components.WaveformSeries
import com.example.supersportr.ui.viewmodel.EngineeringUiState
import com.example.ui.theme.CarbonDarkBlack
import com.example.ui.theme.DarkNavyGraphite
import com.example.ui.theme.McLarenPapaya
import com.example.ui.theme.SlateCardBorder
import com.example.ui.theme.SlateCardSurface
import com.example.ui.theme.TechnicalMuted
import com.example.ui.theme.TechnicalSubtle
import com.example.ui.theme.TechnicalWhite
import com.example.ui.theme.TelemetryAmber
import com.example.ui.theme.TelemetryCyan
import com.example.ui.theme.TelemetryGreen
import com.example.ui.theme.TelemetryPurple
import com.example.ui.theme.TelemetryRed

@Composable
fun DashboardChassisScreen(
    state: EngineeringUiState,
    onScrubRatio: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val session = state.currentSession
    val curSample = state.currentSample
    val cal = state.activeCalibration

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CarbonDarkBlack)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Header Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SlateCardSurface)
                    .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "CHASSIS DYNAMICS & AERODYNAMIC LOAD BALANCE",
                        color = TechnicalWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Planar Bicycle Model // Pacejka Magic Formula // E-Diff Dynamic Lock",
                        color = McLarenPapaya,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // 2. Steering Angle vs Yaw Rate Response Waveform
        item {
            val steerSeries = WaveformSeries(
                name = "STEER INPUT",
                color = TechnicalWhite,
                values = session.samples.map { it.steeringAngleDeg },
                unit = "°"
            )
            val yawSeries = WaveformSeries(
                name = "YAW RATE",
                color = McLarenPapaya,
                values = session.samples.map { it.yawRateDegS },
                unit = "°/s"
            )
            val latGSeries = WaveformSeries(
                name = "LAT ACCEL",
                color = TelemetryAmber,
                values = session.samples.map { it.ayG },
                unit = "G"
            )

            TelemetryWaveform(
                title = "Steering Input & Planar Yaw Rate Response",
                subtitle = "Handwheel Angle (deg) vs Planar Yaw Rate (°/s) & Lat G",
                series = listOf(steerSeries, yawSeries, latGSeries),
                currentCursorRatio = state.scrubRatio,
                onScrubRatio = onScrubRatio,
                modifier = Modifier.fillMaxWidth(),
                canvasHeight = 140
            )
        }

        // 3. Dynamic 4-Wheel Vertical Load Distribution Card (FL, FR, RL, RR)
        item {
            val fl = curSample?.flLoadN ?: 3500.0
            val fr = curSample?.frLoadN ?: 3500.0
            val rl = curSample?.rlLoadN ?: 4800.0
            val rr = curSample?.rrLoadN ?: 4800.0

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SlateCardSurface)
                    .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "4-WHEEL DYNAMIC VERTICAL LOADS (Fz)",
                            color = TechnicalWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Total Downforce: ${curSample?.aeroDownforceN?.toInt() ?: 0} N",
                            color = TelemetryCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Front Axle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        WheelLoadBox(label = "FRONT LEFT (FL)", loadN = fl, tyreTempC = curSample?.tyreTempAvgC ?: 75.0, modifier = Modifier.weight(1f))
                        WheelLoadBox(label = "FRONT RIGHT (FR)", loadN = fr, tyreTempC = curSample?.tyreTempAvgC ?: 75.0, modifier = Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Rear Axle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        WheelLoadBox(label = "REAR LEFT (RL)", loadN = rl, tyreTempC = (curSample?.tyreTempAvgC ?: 75.0) + 4.0, modifier = Modifier.weight(1f))
                        WheelLoadBox(label = "REAR RIGHT (RR)", loadN = rr, tyreTempC = (curSample?.tyreTempAvgC ?: 75.0) + 4.0, modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        // 4. Pitch & Roll Body Motion Waveform
        item {
            val rollSeries = WaveformSeries(
                name = "ROLL ANGLE",
                color = TelemetryCyan,
                values = session.samples.map { it.rollAngleDeg },
                unit = "°"
            )
            val pitchSeries = WaveformSeries(
                name = "PITCH ANGLE",
                color = TelemetryAmber,
                values = session.samples.map { it.pitchAngleDeg },
                unit = "°"
            )

            TelemetryWaveform(
                title = "Body Transient Kinematics",
                subtitle = "Chassis Roll Gradient (°/g) & Anti-Dive Pitch Gradient",
                series = listOf(rollSeries, pitchSeries),
                currentCursorRatio = state.scrubRatio,
                onScrubRatio = onScrubRatio,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 5. Differential & Aerodynamic Status Summary Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SlateCardSurface)
                    .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "DIFFERENTIAL & ACTIVE AERO CONFIGURATION",
                        color = TechnicalWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Diff Coast Lockup: ${cal.diffCoastLockupPct}%", color = TechnicalMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text("Diff Power Lockup: ${cal.diffPowerLockupPct}%", color = McLarenPapaya, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text("Instantaneous Lock: ${curSample?.diffLockPct?.toInt() ?: 0}%", color = TechnicalWhite, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text("Active Wing Angle: ${curSample?.activeWingAngleDeg?.toInt() ?: 0}°", color = TelemetryCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text("Aero Balance (F/R): 44% / 56%", color = TechnicalMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text("Aero Drag Force: ${curSample?.aeroDragN?.toInt() ?: 0} N", color = TechnicalWhite, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }
    }
}

@Composable
private fun WheelLoadBox(
    label: String,
    loadN: Double,
    tyreTempC: Double,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(DarkNavyGraphite)
            .border(1.dp, SlateCardBorder, RoundedCornerShape(6.dp))
            .padding(10.dp)
    ) {
        Column {
            Text(label, color = TechnicalSubtle, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "${loadN.toInt()} N",
                color = TechnicalWhite,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "Temp: ${tyreTempC.toInt()}°C",
                color = if (tyreTempC in 85.0..105.0) TelemetryGreen else TelemetryAmber,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
