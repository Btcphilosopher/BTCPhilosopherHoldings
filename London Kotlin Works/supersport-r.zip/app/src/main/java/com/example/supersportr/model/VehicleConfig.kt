package com.example.supersportr.model

/**
 * Metadata descriptor for each engineering parameter.
 */
data class ParameterMeta<T>(
    val name: String,
    val value: T,
    val unit: String,
    val source: String,
    val confidencePct: Double,
    val permittedRange: String,
    val validationStatus: ValidationStatus
)

enum class ValidationStatus {
    CALIBRATED,
    ESTIMATED_BENCHMARK,
    SYNTHETIC_RESEARCH,
    SAFETY_BOUNDED
}

enum class TitaniumFinish(val label: String, val desc: String) {
    NATURAL("Natural Titanium", "Standard exposed raw titanium finish"),
    BRUSHED("Brushed Titanium", "Optional directional satin brushed titanium"),
    MATTE("Matte Titanium", "Optional bead-blasted anti-reflective titanium")
}

/**
 * McLaren Titanium Construction Architecture:
 * Ultra-lightweight 1,180 kg architecture with 100% titanium monocoque,
 * titanium subframes, and titanium & carbon hybrid suspension.
 */
data class TitaniumChassisStructure(
    val chassisType: String = "100% Titanium Monocoque",
    val bodyPanels: String = "Titanium (Exposed Bare Finish)",
    val subframe: String = "High-Strength Titanium",
    val suspensionWishbones: String = "Titanium & Carbon Hybrid",
    val selectedFinish: TitaniumFinish = TitaniumFinish.NATURAL,
    val totalWeightKg: Double = 1180.0, // 1,180 kg curb weight
    val powerToWeightHpPerTonne: Double = 889.8, // 1,050 hp / 1.18 tonnes
    val weightDistributionFrontPct: Double = 0.42 // 42% Front / 58% Rear
)

/**
 * Vehicle geometry (SI units).
 */
data class VehicleGeometry(
    val totalMassKg: Double = 1180.0, // Updated to 1,180 kg McLaren Titanium spec
    val frontMassDistribution: Double = 0.42,
    val wheelbaseM: Double = 2.67,
    val frontTrackM: Double = 1.68,
    val rearTrackM: Double = 1.62,
    val cgHeightM: Double = 0.36, // Ultra-low CG due to titanium architecture
    val yawInertiaKgm2: Double = 1480.0, // Reduced rotational inertia from 1,180 kg mass
    val frontTyreRadiusM: Double = 0.327, // 245/35 R19
    val rearTyreRadiusM: Double = 0.346,  // 305/30 R20
    val frontalAreaM2: Double = 2.05,
    val airDensityKgM3: Double = 1.225
) {
    val frontAxleToCgM: Double get() = wheelbaseM * (1.0 - frontMassDistribution)
    val rearAxleToCgM: Double get() = wheelbaseM * frontMassDistribution
}

/**
 * Liquid Hydrogen (LH2) Cryogenic Injection System specification:
 * Cryogenic LH2 at -253°C raised to 700 bar, injected into intake ports
 * and combustion chambers, generating cryogenic charge-cooling and zero CO2 emissions.
 */
data class HydrogenInjectionConfig(
    val storageType: String = "Cryogenic Liquid Hydrogen (LH2) Tank",
    val storageTempC: Double = -253.0,
    val maxRailPressureBar: Double = 700.0,
    val injectionType: String = "Dual Intake Port + Direct Combustion Chamber",
    val chargeCoolingTempDropC: Double = 42.0, // Cryogenic intake charge cooling benefit
    val octaneRatingEquivalent: Double = 130.0, // Research octane equivalent
    val emissionsCo2GPerKm: Double = 0.0,
    val emissionsNoxGPerKm: Double = 0.0,
    val exhaustByproduct: String = "Pure Water Vapour (H2O)"
)

data class PowertrainConfig(
    val engineName: String = "4.0L 90° V8 Twin-Turbo + Liquid Hydrogen Injection",
    val engineConfig: String = "4.0 litre 90° V8, Variable Geometry Twin Turbos",
    val engineIdleRpm: Double = 950.0,
    val engineRedlineRpm: Double = 10000.0, // 10,000 RPM Redline
    val peakEngineTorqueNm: Double = 1000.0, // 1,000 Nm @ 6,000 RPM
    val peakEngineTorqueRpm: Double = 6000.0,
    val peakEnginePowerHp: Double = 850.0, // 850 hp (engine only) @ 9,000 RPM
    val peakEnginePowerKw: Double = 625.0,
    val electricMotorName: String = "Hybrid E-Axle & Transmission Integrated Motor",
    val electricMotorPowerHp: Double = 200.0, // 200 hp electric assist
    val electricMotorPowerKw: Double = 147.0,
    val peakElectricMotorTorqueNm: Double = 200.0,
    val totalSystemPowerHp: Double = 1050.0, // 1,050 hp Total System Output
    val totalSystemPowerKw: Double = 772.0,
    val accel0To100KmhS: Double = 2.4, // 0-100 km/h in 2.4s
    val topSpeedKmh: Double = 450.0, // 450+ km/h top speed
    val batteryCapacityKwh: Double = 7.4,
    val batteryNominalVoltageV: Double = 800.0,
    val maxBatteryDischargeKw: Double = 160.0,
    val maxRegenKw: Double = 50.0,
    val gearRatios: List<Double> = listOf(3.98, 2.61, 1.90, 1.48, 1.16, 0.91, 0.69),
    val finalDriveRatio: Double = 3.31,
    val drivetrainEfficiency: Double = 0.94,
    val shiftDurationBaselineMs: Double = 80.0,
    val hydrogenSystem: HydrogenInjectionConfig = HydrogenInjectionConfig()
)

data class ChassisAeroConfig(
    val baselineCd: Double = 0.32,
    val baselineClDownforce: Double = 0.48,
    val aeroBalanceFrontPct: Double = 0.44,
    val activeRearWingAngleDeg: Double = 14.0,
    val brakeMaxTorqueNm: Double = 7200.0,
    val brakeBiasFrontPct: Double = 0.63,
    val steeringRatio: Double = 13.5,
    val suspensionBumpDampingNsM: Double = 6800.0,
    val suspensionReboundDampingNsM: Double = 8900.0,
    val rollStiffnessNmRad: Double = 152000.0,
    val pitchStiffnessNmRad: Double = 198000.0
)

data class VehicleProfile(
    val profileName: String = "McLaren Titanium Hypercar (LH2 Twin-Turbo V8)",
    val titaniumChassis: TitaniumChassisStructure = TitaniumChassisStructure(),
    val geometry: VehicleGeometry = VehicleGeometry(),
    val powertrain: PowertrainConfig = PowertrainConfig(),
    val chassisAero: ChassisAeroConfig = ChassisAeroConfig(),
    val isPlaceholderCalibration: Boolean = false,
    val disclaimer: String = "SIMULATED VEHICLE — McLAREN TITANIUM RESEARCH PLATFORM."
)
