package com.example.supersportr.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.supersportr.model.DriveModeType
import com.example.supersportr.simulation.PowertrainEngine
import com.example.supersportr.ui.components.TelemetryWaveform
import com.example.supersportr.ui.components.WaveformSeries
import com.example.supersportr.ui.viewmodel.EngineeringUiState
import com.example.ui.theme.CarbonDarkBlack
import com.example.ui.theme.DarkNavyGraphite
import com.example.ui.theme.McLarenPapaya
import com.example.ui.theme.SlateCardBorder
import com.example.ui.theme.SlateCardSurface
import com.example.ui.theme.TechnicalMuted
import com.example.ui.theme.TechnicalSubtle
import com.example.ui.theme.TechnicalWhite
import com.example.ui.theme.TelemetryAmber
import com.example.ui.theme.TelemetryCyan
import com.example.ui.theme.TelemetryGreen
import com.example.ui.theme.TelemetryPurple
import com.example.ui.theme.TelemetryRed
import kotlin.math.PI
import kotlin.math.pow

@Composable
fun DashboardPowertrainScreen(
    state: EngineeringUiState,
    onScrubRatio: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val session = state.currentSession
    val curSample = state.currentSample
    val pwt = state.vehicleProfile.powertrain

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CarbonDarkBlack)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Header Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SlateCardSurface)
                    .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "POWERTRAIN DYNAMICS // 4.0L V8 TWIN-TURBO + LIQUID HYDROGEN",
                        color = TechnicalWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "1,050 HP System Output  |  850 HP Engine @ 9,000 RPM  |  1,000 Nm @ 6,000 RPM  |  10,000 RPM Redline",
                        color = McLarenPapaya,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // 2. Liquid Hydrogen Flow & Cryogenic Injection Architecture Diagram (from Infographic)
        item {
            com.example.supersportr.ui.components.HydrogenFlowDiagram(
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 3. Torque vs RPM Characteristic Curve
        item {
            TorqueCharacteristicCanvas(
                pwt = pwt,
                currentRpm = curSample?.engineRpm ?: 950.0,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 3. Pedal Response Transfer Function Mapping (Pedal % vs Requested Torque Nm)
        item {
            PedalResponseFunctionCanvas(
                activeMode = state.selectedMode,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 4. Shift Timeline & Torque-Fill Telemetry Waveform
        item {
            val reqTqSeries = WaveformSeries(
                name = "REQUESTED TQ",
                color = TechnicalWhite,
                values = session.samples.map { it.requestedTorqueNm },
                unit = "Nm"
            )
            val iceTqSeries = WaveformSeries(
                name = "ICE DELIVERED",
                color = McLarenPapaya,
                values = session.samples.map { it.engineTorqueDeliveredNm },
                unit = "Nm"
            )
            val emTqSeries = WaveformSeries(
                name = "EM HYBRID FILL",
                color = TelemetryCyan,
                values = session.samples.map { it.motorTorqueDeliveredNm },
                unit = "Nm"
            )

            TelemetryWaveform(
                title = "Hybrid Torque Delivery & Shift Bridging",
                subtitle = "Driver Request vs V8 Combustion & Axial-Flux Motor Fill",
                series = listOf(reqTqSeries, iceTqSeries, emTqSeries),
                currentCursorRatio = state.scrubRatio,
                onScrubRatio = onScrubRatio,
                modifier = Modifier.fillMaxWidth(),
                canvasHeight = 140
            )
        }

        // 5. Thermal & State of Charge Trends
        item {
            val socSeries = WaveformSeries(
                name = "BATT SOC",
                color = TelemetryCyan,
                values = session.samples.map { it.batterySocPct },
                unit = "%"
            )
            val invTempSeries = WaveformSeries(
                name = "INV TEMP",
                color = TelemetryAmber,
                values = session.samples.map { it.inverterTempC },
                unit = "°C"
            )

            TelemetryWaveform(
                title = "Hybrid Energy & Thermal Status",
                subtitle = "High-Voltage Battery SoC (%) & Inverter Junction Temp (°C)",
                series = listOf(socSeries, invTempSeries),
                currentCursorRatio = state.scrubRatio,
                onScrubRatio = onScrubRatio,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 6. Powertrain Specification Summary Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SlateCardSurface)
                    .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "CALIBRATION SPECIFICATION // POWERTRAIN LIMITS",
                        color = TechnicalWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Peak Combined Power: 670 kW (910 PS)", color = TechnicalMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text("Engine Torque Plateau: 800 Nm (3000-6500 RPM)", color = TechnicalMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text("Axial Flux Motor: 180 Nm Instantaneous", color = TechnicalMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text("Shift Duration Target: ${state.activeCalibration.shiftDurationMs} ms", color = McLarenPapaya, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text("Hybrid Torque Fill: ${(state.activeCalibration.hybridTorqueFillPct * 100).toInt()}%", color = TelemetryCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text("Torque Ramp Rate: ${state.activeCalibration.maxTorqueRampNmPerSec.toInt()} Nm/s", color = TechnicalWhite, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }
    }
}

@Composable
private fun TorqueCharacteristicCanvas(
    pwt: com.example.supersportr.model.PowertrainConfig,
    currentRpm: Double,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(SlateCardSurface)
            .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "TORQUE & POWER ENVELOPE (10,000 RPM REDLINE)",
                        color = TechnicalWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "V8 LH2 (1,000 Nm @ 6,000 RPM) + E-AXLE (200 Nm) = 1,050 HP",
                        color = TechnicalSubtle,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Text(
                    text = "${currentRpm.toInt()} RPM",
                    color = McLarenPapaya,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
            ) {
                val w = size.width
                val h = size.height

                // Grid lines
                for (g in 0..3) {
                    val y = (h / 3f) * g
                    drawLine(color = Color(0xFF1E293B), start = Offset(0f, y), end = Offset(w, y), strokeWidth = 1f)
                }

                val icePath = Path()
                val motorPath = Path()
                val totalPath = Path()

                val minRpm = 950.0
                val maxRpm = 10000.0
                val maxTorqueScale = 1250.0 // Nm

                val steps = 60
                for (i in 0..steps) {
                    val rpm = minRpm + (i.toDouble() / steps) * (maxRpm - minRpm)
                    val px = ((rpm - minRpm) / (maxRpm - minRpm)).toFloat() * w

                    val iceTq = PowertrainEngine.getPeakEngineTorque(rpm, pwt)
                    val emTq = PowertrainEngine.getPeakElectricMotorTorque(rpm, pwt)
                    val combinedTq = iceTq + emTq

                    val pyIce = h - ((iceTq / maxTorqueScale) * (h - 10.0)).toFloat()
                    val pyEm = h - ((emTq / maxTorqueScale) * (h - 10.0)).toFloat()
                    val pyTotal = h - ((combinedTq / maxTorqueScale) * (h - 10.0)).toFloat()

                    if (i == 0) {
                        icePath.moveTo(px, pyIce)
                        motorPath.moveTo(px, pyEm)
                        totalPath.moveTo(px, pyTotal)
                    } else {
                        icePath.lineTo(px, pyIce)
                        motorPath.lineTo(px, pyEm)
                        totalPath.lineTo(px, pyTotal)
                    }
                }

                // Draw curves
                drawPath(path = motorPath, color = TelemetryCyan, style = Stroke(width = 1.8f))
                drawPath(path = icePath, color = McLarenPapaya, style = Stroke(width = 2.2f))
                drawPath(path = totalPath, color = TechnicalWhite, style = Stroke(width = 2.0f))

                // Current operating point vertical line
                val currentNormX = (((currentRpm - minRpm) / (maxRpm - minRpm)).toFloat() * w).coerceIn(0f, w)
                drawLine(
                    color = TelemetryGreen,
                    start = Offset(currentNormX, 0f),
                    end = Offset(currentNormX, h),
                    strokeWidth = 1.5f
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Orange: V8 Engine (1,000 Nm / 850 hp)", color = McLarenPapaya, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("Cyan: E-Axle (200 Nm)", color = TelemetryCyan, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("White: Total (1,050 hp)", color = TechnicalWhite, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            }
                Text("Orange: ICE (800 Nm)", color = McLarenPapaya, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text("Cyan: E-Motor (180 Nm)", color = TelemetryCyan, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text("White: Combined (980 Nm)", color = TechnicalWhite, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
private fun PedalResponseFunctionCanvas(
    activeMode: DriveModeType,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(SlateCardSurface)
            .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Column {
            Text(
                text = "ACCELERATOR PEDAL TRANSFER FUNCTION",
                color = TechnicalWhite,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "PEDAL DISPLACEMENT % VS TORQUE REQUEST %",
                color = TechnicalSubtle,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.height(10.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
            ) {
                val w = size.width
                val h = size.height

                // Draw diagonal linear reference
                drawLine(
                    color = Color(0xFF2C394B),
                    start = Offset(0f, h),
                    end = Offset(w, 0f),
                    strokeWidth = 1f
                )

                // Modes and exponents
                val modes = listOf(
                    Triple(DriveModeType.COMFORT, 1.25, Color(0xFF94A3B8)),
                    Triple(DriveModeType.SPORT, 1.00, TelemetryCyan),
                    Triple(DriveModeType.SUPERSPORT, 0.86, McLarenPapaya),
                    Triple(DriveModeType.TRACK, 0.78, TelemetryRed)
                )

                modes.forEach { (mode, exp, color) ->
                    val path = Path()
                    val isCurrent = mode == activeMode
                    for (i in 0..40) {
                        val pedal = i / 40.0
                        val tqFactor = pedal.pow(exp)
                        val px = (pedal * w).toFloat()
                        val py = (h - tqFactor * h).toFloat()
                        if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                    }
                    drawPath(
                        path = path,
                        color = color,
                        style = Stroke(width = if (isCurrent) 3f else 1.2f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Comfort: 1.25 (Soft)", color = Color(0xFF94A3B8), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text("Sport: 1.00 (Linear)", color = TelemetryCyan, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text("SuperSport: 0.86 (Convex)", color = McLarenPapaya, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text("Track: 0.78 (Sharp)", color = TelemetryRed, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}
