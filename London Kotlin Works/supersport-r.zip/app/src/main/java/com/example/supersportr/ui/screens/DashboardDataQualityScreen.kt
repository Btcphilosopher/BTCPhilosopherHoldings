package com.example.supersportr.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.supersportr.ui.viewmodel.EngineeringUiState
import com.example.ui.theme.CarbonDarkBlack
import com.example.ui.theme.DarkNavyGraphite
import com.example.ui.theme.McLarenPapaya
import com.example.ui.theme.SlateCardBorder
import com.example.ui.theme.SlateCardSurface
import com.example.ui.theme.TechnicalMuted
import com.example.ui.theme.TechnicalSubtle
import com.example.ui.theme.TechnicalWhite
import com.example.ui.theme.TelemetryAmber
import com.example.ui.theme.TelemetryCyan
import com.example.ui.theme.TelemetryGreen
import com.example.ui.theme.TelemetryRed

@Composable
fun DashboardDataQualityScreen(
    state: EngineeringUiState,
    onOpenExport: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val session = state.currentSession
    var selectedRFile by remember { mutableStateOf("DESCRIPTION") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CarbonDarkBlack)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Header Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SlateCardSurface)
                    .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "TELEMETRY INGESTION, DATA QUALITY & SAFETY",
                        color = TechnicalWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Signal Integrity Audit // ISO 26262 Systems Boundary",
                        color = McLarenPapaya,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // 2. Data Health & Completeness Metric Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SlateCardSurface)
                    .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "SIGNAL HEALTH & COMPLETENESS AUDIT",
                        color = TechnicalWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MetricAuditBox(
                            title = "COMPLETENESS",
                            value = "${String.format("%.1f", session.dataCompletenessPct)}%",
                            sub = "Total valid samples",
                            color = if (session.dataCompletenessPct > 98.0) TelemetryGreen else TelemetryAmber,
                            modifier = Modifier.weight(1f)
                        )
                        MetricAuditBox(
                            title = "MISSING WINDOWS",
                            value = "${session.missingIntervalsCount}",
                            sub = "Dropouts identified",
                            color = if (session.missingIntervalsCount > 0) TelemetryAmber else TelemetryGreen,
                            modifier = Modifier.weight(1f)
                        )
                        MetricAuditBox(
                            title = "CONSTRAINT EVENTS",
                            value = "${session.constraintEventCount}",
                            sub = "Physical clips",
                            color = if (session.constraintEventCount > 0) McLarenPapaya else TechnicalWhite,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Explicit Missing Sample Flagging Notice
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF241C12))
                            .border(1.dp, Color(0xFF6B4500), RoundedCornerShape(6.dp))
                            .padding(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = TelemetryAmber, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "EVENT DETECTED: Telemetry dropout at T=22.0s - 23.5s (30 samples). System flagged invalid state rather than silently fabricating fake sensor values.",
                                color = Color(0xFFFFB266),
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // 3. Sensor Boundary Range Validation Table
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SlateCardSurface)
                    .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "CANONICAL TELEMETRY CHANNELS & RANGE AUDIT",
                        color = TechnicalWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    SensorRow(channel = "SPEED_KMH", range = "0 .. 420 km/h", status = "VALID", ok = true)
                    SensorRow(channel = "ACCEL_PEDAL_POS", range = "0.0 .. 100.0 %", status = "VALID", ok = true)
                    SensorRow(channel = "BRAKE_PRESSURE_BAR", range = "0.0 .. 160.0 bar", status = "VALID", ok = true)
                    SensorRow(channel = "STEER_ANGLE_DEG", range = "-540.0 .. +540.0 °", status = "VALID", ok = true)
                    SensorRow(channel = "IMU_AX_LONG_G", range = "-3.0 .. +3.0 g", status = "VALID", ok = true)
                    SensorRow(channel = "IMU_AY_LAT_G", range = "-3.0 .. +3.0 g", status = "VALID", ok = true)
                    SensorRow(channel = "IMU_YAW_RATE", range = "-120.0 .. +120.0 °/s", status = "VALID", ok = true)
                    SensorRow(channel = "BMS_BATTERY_SOC", range = "0.0 .. 100.0 %", status = "VALID", ok = true)
                    SensorRow(channel = "INVERTER_TEMP_C", range = "20.0 .. 125.0 °C", status = "WARN (>90°C)", ok = false)
                }
            }
        }

        // 4. ISO 26262 Automotive Safety & Systems Boundary Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SlateCardSurface)
                    .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = TelemetryGreen, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ISO 26262 FUNCTIONAL SAFETY BOUNDARY",
                            color = TechnicalWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "1. AUTHORITY: This software is an offline research and dynamics calibration simulation platform. It has ZERO authority over vehicle actuators and contains NO CAN-write capabilities.",
                        color = TechnicalMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "2. SAFETY SYSTEMS: Factory stability controls (ESC), ABS, and traction management are never bypassed. Production calibration requires dedicated Dyno, HIL (Hardware-in-the-Loop), and track test approval.",
                        color = TechnicalMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "3. PROVENANCE: All outputs derive from deterministic numerical equations (Pacejka Magic Formula, planar bicycle model, and hybrid energy balance) with SI unit verification.",
                        color = TechnicalMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // 5. Embedded R Engineering Package Code Viewer
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SlateCardSurface)
                    .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Code, contentDescription = null, tint = McLarenPapaya, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "EMBEDDED R SOURCE PACKAGES",
                                color = TechnicalWhite,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                val content = getRFileContent(selectedRFile)
                                onOpenExport(content)
                            },
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text("EXPORT CODE", color = McLarenPapaya, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Buttons to select R file
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("DESCRIPTION", "powertrain_model.R", "vehicle_profile.yml", "app.R").forEach { name ->
                            val isSel = name == selectedRFile
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isSel) McLarenPapaya else DarkNavyGraphite)
                                    .border(1.dp, SlateCardBorder, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = name,
                                    color = if (isSel) CarbonDarkBlack else TechnicalMuted,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Code snippet preview
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(DarkNavyGraphite)
                            .border(1.dp, SlateCardBorder, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = getRFileContent(selectedRFile).take(400) + "\n... [Full file ready in assets / export]",
                            color = TechnicalWhite,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }
    }
}

@Composable
private fun MetricAuditBox(
    title: String,
    value: String,
    sub: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(DarkNavyGraphite)
            .border(1.dp, SlateCardBorder, RoundedCornerShape(6.dp))
            .padding(8.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text(title, color = TechnicalSubtle, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, color = color, fontSize = 14.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
            Text(sub, color = TechnicalMuted, fontSize = 7.sp, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
private fun SensorRow(channel: String, range: String, status: String, ok: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(channel, color = TechnicalWhite, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.4f))
        Text(range, color = TechnicalMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
        Text(
            text = status,
            color = if (ok) TelemetryGreen else TelemetryAmber,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

private fun getRFileContent(name: String): String {
    return when (name) {
        "DESCRIPTION" -> """
Package: mclaren.supersport.r
Title: Hypercar Drive-Mode Calibration & Simulation Platform
Version: 3.8.0
Imports: data.table, dplyr, ggplot2, plotly, shiny, bslib, deSolve, R6
License: Research Simulation Use Only
        """.trimIndent()
        "powertrain_model.R" -> """
# Powertrain & Hybrid R6 Class Model
PowertrainModel <- R6Class("PowertrainModel",
  public = list(
    get_peak_ice_torque = function(rpm) { ... },
    step = function(pedal, cal, dt) { ... }
  )
)
        """.trimIndent()
        "vehicle_profile.yml" -> """
geometry:
  mass_kg: 1450.0
  front_weight_distribution: 0.42
  wheelbase_m: 2.67
powertrain:
  engine_torque_nm: 800.0
  hybrid_motor_torque_nm: 180.0
        """.trimIndent()
        else -> """
# Shiny Dashboard Module (app/app.R)
ui <- page_navbar(
  title = "McLAREN SUPERSPORT R",
  theme = bs_theme(bg = "#0B0E14", primary = "#FF7700")
)
        """.trimIndent()
    }
}
