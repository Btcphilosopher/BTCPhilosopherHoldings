package com.example.supersportr.telemetry

import com.example.supersportr.model.DriveModeCalibration
import com.example.supersportr.model.LapSectorSummary
import com.example.supersportr.model.LapSessionData
import com.example.supersportr.model.TelemetrySample
import com.example.supersportr.model.VehicleProfile
import com.example.supersportr.simulation.VehicleDynamicsEngine
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SyntheticScenarioGenerator {

    /**
     * Generate a deterministic simulated session for a given DriveModeCalibration.
     * Fixed time step (dt = 0.05s, 20Hz), fixed sequence of driver inputs.
     */
    fun generateDeterministicSession(
        cal: DriveModeCalibration,
        vehicle: VehicleProfile = VehicleProfile()
    ): LapSessionData {
        val engine = VehicleDynamicsEngine(vehicle)
        engine.reset(initialSpeedKmh = 10.0, initialSocPct = 85.0)

        val dt = 0.05 // 20 Hz telemetry recording
        val totalDurationS = 28.0
        val numSteps = (totalDurationS / dt).toInt()
        val samples = ArrayList<TelemetrySample>(numSteps)

        var constraintEvents = 0
        var missingIntervals = 0
        var inMissingWindow = false

        for (i in 0 until numSteps) {
            val t = i * dt

            // Driver input profile synthesis (Deterministic Grand Prix circuit sector)
            val throttle: Double
            val brake: Double
            val steerDeg: Double
            val sensorDropout: Boolean

            when {
                // Phase 1: 0 - 6.0s -> Standing launch & full acceleration sprint (Straight 1)
                t < 6.0 -> {
                    throttle = 1.0
                    brake = 0.0
                    steerDeg = 0.0
                    sensorDropout = false
                }
                // Phase 2: 6.0 - 8.5s -> Heavy threshold braking into Turn 1 hairpin
                t < 8.5 -> {
                    throttle = 0.0
                    val brakeProgress = ((t - 6.0) / 0.4).coerceIn(0.0, 1.0)
                    brake = 0.95 * brakeProgress
                    steerDeg = 0.0
                    sensorDropout = false
                }
                // Phase 3: 8.5 - 12.0s -> Turn 1 corner entry, trail-braking, apex sustained lateral G
                t < 12.0 -> {
                    throttle = if (t > 10.2) ((t - 10.2) / 1.8) * 0.65 else 0.05
                    brake = if (t < 9.4) 0.35 * (1.0 - (t - 8.5) / 0.9) else 0.0
                    steerDeg = 48.0 // right hand hairpin
                    sensorDropout = false
                }
                // Phase 4: 12.0 - 15.0s -> Corner exit power-down, traction-limited acceleration
                t < 15.0 -> {
                    val exitProgress = (t - 12.0) / 3.0
                    throttle = (0.65 + exitProgress * 0.35).coerceIn(0.0, 1.0)
                    brake = 0.0
                    steerDeg = (48.0 * (1.0 - exitProgress)).coerceAtLeast(0.0)
                    sensorDropout = false
                }
                // Phase 5: 15.0 - 19.0s -> High-speed esses / chicane transition (Turn 2-3)
                t < 19.0 -> {
                    throttle = 0.85
                    brake = if (t in 16.5..17.0) 0.4 else 0.0
                    val chicanePhase = (t - 15.0) / 4.0
                    steerDeg = kotlin.math.sin(chicanePhase * Math.PI * 2.0) * -38.0
                    sensorDropout = false
                }
                // Phase 6: 19.0 - 22.0s -> Powertrain constraint event (high power under warm temps)
                t < 22.0 -> {
                    throttle = 1.0
                    brake = 0.0
                    steerDeg = 0.0
                    sensorDropout = false
                }
                // Phase 7: 22.0 - 23.5s -> Deterministic missing sensor window (telemetry dropout test)
                t < 23.5 -> {
                    throttle = 0.95
                    brake = 0.0
                    steerDeg = 5.0
                    sensorDropout = true
                }
                // Phase 8: 23.5 - 28.0s -> High-speed straight to finish line
                else -> {
                    throttle = 1.0
                    brake = 0.0
                    steerDeg = 0.0
                    sensorDropout = false
                }
            }

            if (sensorDropout) {
                if (!inMissingWindow) {
                    missingIntervals++
                    inMissingWindow = true
                }
            } else {
                inMissingWindow = false
            }

            val sample = engine.step(
                dtSeconds = dt,
                throttleInput = throttle,
                brakeInput = brake,
                steeringInputDeg = steerDeg,
                cal = cal,
                sensorDropout = sensorDropout
            )

            if (sample.constraintActive) {
                constraintEvents++
            }

            samples.add(sample)
        }

        // Generate sector summaries
        val s1Samples = samples.filter { it.sectorId == 1 }
        val s2Samples = samples.filter { it.sectorId == 2 }
        val s3Samples = samples.filter { it.sectorId == 3 }

        val sectorSummaries = listOf(
            computeSectorSummary(1, "Sector 1 (High Speed & Hairpin)", s1Samples),
            computeSectorSummary(2, "Sector 2 (Technical Infield)", s2Samples),
            computeSectorSummary(3, "Sector 3 (Sprint to Finish)", s3Samples)
        )

        val totalTime = samples.last().timestampS
        val totalDistance = samples.last().distanceM
        val validCount = samples.count { it.sensorQualityOk }
        val completenessPct = (validCount.toDouble() / samples.size) * 100.0

        val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())

        return LapSessionData(
            sessionId = "SIM-SESSION-${cal.type.name}-001",
            sessionTimestamp = dateStr,
            modeType = cal.type,
            totalTimeS = totalTime,
            totalDistanceM = totalDistance,
            samples = samples,
            sectorSummaries = sectorSummaries,
            constraintEventCount = constraintEvents,
            dataCompletenessPct = completenessPct,
            missingIntervalsCount = missingIntervals
        )
    }

    private fun computeSectorSummary(
        sectorId: Int,
        sectorName: String,
        sectorSamples: List<TelemetrySample>
    ): LapSectorSummary {
        if (sectorSamples.isEmpty()) {
            return LapSectorSummary(sectorId, sectorName, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        }
        val duration = sectorSamples.last().timestampS - sectorSamples.first().timestampS
        val entrySpeed = sectorSamples.first().speedKmh
        val exitSpeed = sectorSamples.last().speedKmh
        val maxLatG = sectorSamples.maxOf { kotlin.math.abs(it.ayG) }
        val peakLongG = sectorSamples.maxOf { it.axG }
        val maxBrakeBar = sectorSamples.maxOf { it.brakePressureBar }
        val energyUsedKwh = sectorSamples.sumOf { (it.totalPowerKw * 0.05) / 3600.0 }

        return LapSectorSummary(
            sectorId = sectorId,
            sectorName = sectorName,
            durationS = duration,
            entrySpeedKmh = entrySpeed,
            exitSpeedKmh = exitSpeed,
            maxLatG = maxLatG,
            peakLongG = peakLongG,
            maxBrakeBar = maxBrakeBar,
            energyUsedKwh = energyUsedKwh
        )
    }
}
