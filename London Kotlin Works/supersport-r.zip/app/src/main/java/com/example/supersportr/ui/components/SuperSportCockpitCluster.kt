package com.example.supersportr.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.supersportr.model.TelemetrySample
import com.example.ui.theme.CarbonDarkBlack
import com.example.ui.theme.DarkNavyGraphite
import com.example.ui.theme.McLarenPapaya
import com.example.ui.theme.SlateCardBorder
import com.example.ui.theme.SlateCardSurface
import com.example.ui.theme.TechnicalMuted
import com.example.ui.theme.TechnicalSubtle
import com.example.ui.theme.TechnicalWhite
import com.example.ui.theme.TelemetryAmber
import com.example.ui.theme.TelemetryCyan
import com.example.ui.theme.TelemetryGreen
import com.example.ui.theme.TelemetryRed
import kotlin.math.sqrt

/**
 * McLaren Titanium Cockpit Instrument Cluster:
 * Authentic implementation of the "OPTIONAL DASHBOARD - SUPER-SPORT MODE"
 * featured in the McLaren Titanium engineering specification.
 * Shows centered circular tachometer dial, large central gear numeral,
 * velocity readout (e.g. 350 km/h), G-meter, and cryogenic LH2 status.
 */
@Composable
fun SuperSportCockpitCluster(
    sample: TelemetrySample?,
    modifier: Modifier = Modifier
) {
    val speedKmh = sample?.speedKmh ?: 350.0
    val rpm = sample?.engineRpm ?: 9200.0
    val gear = sample?.currentGear ?: 7
    val isShifting = sample?.shiftInProgress ?: false
    val powerHp = sample?.totalPowerHp ?: 1050.0
    val ax = sample?.axG ?: 0.0
    val ay = sample?.ayG ?: 0.0
    val gTotal = sqrt(ax * ax + ay * ay)
    val railBar = sample?.lh2RailPressureBar ?: 680.0
    val tempDrop = sample?.cryoIntakeTempDropC ?: 38.0

    val rpmRatio = ((rpm - 950.0) / (10000.0 - 950.0)).coerceIn(0.0, 1.0).toFloat()
    val isNearRedline = rpm > 9400.0

    val dialAccentColor by animateColorAsState(
        targetValue = when {
            isShifting -> TelemetryCyan
            isNearRedline -> TelemetryRed
            rpm > 7500.0 -> McLarenPapaya
            else -> TelemetryGreen
        }, label = "dialColor"
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF070A0F))
            .border(1.2.dp, Color(0xFF223044), RoundedCornerShape(10.dp))
            .padding(12.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            // Header bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(McLarenPapaya)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "SUPER-SPORT DIGITAL COCKPIT",
                        color = TechnicalWhite,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                }

                Text(
                    text = "McLAREN TITANIUM // 1,180 KG",
                    color = TechnicalSubtle,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Main 3-Pane Cockpit: Left Telemetry | Center Round Super-Sport Dial | Right Powertrain
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Left Wing: G-Force Vector & Track Status
                Column(
                    modifier = Modifier.weight(0.9f),
                    horizontalAlignment = Alignment.Start
                ) {
                    Text("LATERAL G", color = TechnicalSubtle, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                    Text(
                        text = "${String.format("%+.2f", ay)} G",
                        color = if (kotlin.math.abs(ay) > 1.4) TelemetryAmber else TechnicalWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("BRAKE FORCE", color = TechnicalSubtle, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                    Text(
                        text = "${sample?.brakePressureBar?.toInt() ?: 0} BAR",
                        color = if ((sample?.brakePressureBar ?: 0.0) > 40.0) TelemetryRed else TechnicalWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("TOTAL G-LOAD", color = TechnicalSubtle, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                    Text(
                        text = "${String.format("%.2f", gTotal)} G",
                        color = McLarenPapaya,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Center: Distinctive Round Super-Sport Mode Dial (as in Titanium infographic)
                Box(
                    modifier = Modifier
                        .size(150.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF0D131C))
                        .border(1.5.dp, Color(0xFF283A52), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    // Tachometer Arc Canvas (10,000 RPM)
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val strokeW = 7.dp.toPx()
                        val inset = strokeW / 2f + 4.dp.toPx()
                        val arcSize = Size(size.width - inset * 2, size.height - inset * 2)

                        // Background Track: 240 degrees arc (from 150° to 390°)
                        drawArc(
                            color = Color(0xFF1A2332),
                            startAngle = 150f,
                            sweepAngle = 240f,
                            useCenter = false,
                            topLeft = Offset(inset, inset),
                            size = arcSize,
                            style = Stroke(width = strokeW, cap = StrokeCap.Round)
                        )

                        // Active Sweep Arc
                        drawArc(
                            color = dialAccentColor,
                            startAngle = 150f,
                            sweepAngle = 240f * rpmRatio,
                            useCenter = false,
                            topLeft = Offset(inset, inset),
                            size = arcSize,
                            style = Stroke(width = strokeW, cap = StrokeCap.Round)
                        )
                    }

                    // Centered Numbers: Gear ("8") & Velocity ("350")
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = if (isShifting) ">>" else "$gear",
                            color = TechnicalWhite,
                            fontSize = 38.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = "${speedKmh.toInt()}",
                                color = McLarenPapaya,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = "km/h",
                                color = TechnicalSubtle,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(bottom = 2.dp)
                            )
                        }
                        Text(
                            text = "${rpm.toInt()} RPM",
                            color = if (isNearRedline) TelemetryRed else TechnicalMuted,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Right Wing: Liquid Hydrogen & Hybrid E-Axle Status
                Column(
                    modifier = Modifier.weight(0.9f),
                    horizontalAlignment = Alignment.End
                ) {
                    Text("SYSTEM POWER", color = TechnicalSubtle, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                    Text(
                        text = "${powerHp.toInt()} HP",
                        color = TechnicalWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("LH2 INJECTION", color = TechnicalSubtle, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                    Text(
                        text = "${railBar.toInt()} BAR",
                        color = TelemetryCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("CRYO TEMP DROP", color = TechnicalSubtle, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                    Text(
                        text = "-${tempDrop.toInt()}°C",
                        color = TelemetryCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Sub-bar: Zero Emissions & Liquid Hydrogen Cryogenic badge
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(DarkNavyGraphite)
                    .border(1.dp, SlateCardBorder, RoundedCornerShape(6.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.WaterDrop, contentDescription = null, tint = TelemetryCyan, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("EXHAUST: PURE WATER VAPOUR (ZERO CO2 / ZERO NOx)", color = TelemetryCyan, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
                Text("TANK: -253°C LH2", color = TechnicalWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
        }
    }
}
