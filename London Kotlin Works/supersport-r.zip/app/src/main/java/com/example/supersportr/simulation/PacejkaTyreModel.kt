package com.example.supersportr.simulation

import kotlin.math.PI
import kotlin.math.atan
import kotlin.math.sin

/**
 * Pacejka Magic Formula tyre model with thermal grip factor.
 * Computes lateral tyre force and slip limits based on vertical load Fz and slip angle alpha.
 */
object PacejkaTyreModel {

    // Magic Formula coefficients for hypercar ultra-high performance slick/cup tyre
    private const val B = 10.2   // Stiffness factor
    private const val C = 1.65   // Shape factor
    private const val D_MU_PEAK = 1.55 // Peak friction coefficient at optimal temp
    private const val E = -0.15  // Curvature factor
    private const val OPTIMAL_TEMP_C = 92.0 // Optimal tyre operating temperature
    private const val TEMP_SENSITIVITY = 0.00045 // Thermal degradation coefficient

    /**
     * Thermal grip multiplier: Peak at ~90-95°C, drops if cold (<60°C) or overheated (>115°C).
     */
    fun thermalGripFactor(tyreTempC: Double): Double {
        val delta = tyreTempC - OPTIMAL_TEMP_C
        val factor = 1.0 - TEMP_SENSITIVITY * (delta * delta)
        return factor.coerceIn(0.72, 1.0)
    }

    /**
     * Compute lateral force Fy (Newtons) given slip angle alpha (radians), vertical load Fz (Newtons),
     * and current tyre temperature (°C).
     */
    fun computeLateralForce(
        slipAngleRad: Double,
        fzNormalLoadN: Double,
        tyreTempC: Double
    ): Double {
        if (fzNormalLoadN <= 0.0) return 0.0
        val mu = D_MU_PEAK * thermalGripFactor(tyreTempC)
        val d = mu * fzNormalLoadN
        val bx = B * slipAngleRad
        val fLateral = d * sin(C * atan(bx - E * (bx - atan(bx))))
        return fLateral
    }

    /**
     * Peak available longitudinal tractive force for a driven tyre.
     */
    fun peakLongitudinalForce(
        fzNormalLoadN: Double,
        tyreTempC: Double,
        slipRatioPct: Double
    ): Double {
        val mu = D_MU_PEAK * thermalGripFactor(tyreTempC)
        // Slip curve: rises to peak at ~12% slip ratio, then plateaus/decays slightly
        val slipNormalized = (slipRatioPct / 12.0).coerceIn(0.0, 2.5)
        val slipFactor = if (slipNormalized <= 1.0) {
            sin(slipNormalized * (PI / 2.0))
        } else {
            1.0 - 0.08 * (slipNormalized - 1.0)
        }
        return fzNormalLoadN * mu * slipFactor.coerceIn(0.1, 1.0)
    }
}
