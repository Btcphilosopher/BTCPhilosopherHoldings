package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.supersportr.ui.components.ExportModalDialog
import com.example.supersportr.ui.components.TelemetryHeader
import com.example.supersportr.ui.screens.DashboardCalibrationLabScreen
import com.example.supersportr.ui.screens.DashboardChassisScreen
import com.example.supersportr.ui.screens.DashboardDataQualityScreen
import com.example.supersportr.ui.screens.DashboardOverviewScreen
import com.example.supersportr.ui.screens.DashboardPowertrainScreen
import com.example.supersportr.ui.screens.DashboardTrackAnalysisScreen
import com.example.supersportr.ui.viewmodel.DashboardTab
import com.example.supersportr.ui.viewmodel.EngineeringViewModel
import com.example.ui.theme.CarbonDarkBlack
import com.example.ui.theme.DarkNavyGraphite
import com.example.ui.theme.McLarenPapaya
import com.example.ui.theme.SlateCardBorder
import com.example.ui.theme.SlateCardSurface
import com.example.ui.theme.SuperSportRTheme
import com.example.ui.theme.TechnicalMuted
import com.example.ui.theme.TechnicalWhite

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SuperSportRTheme {
                EngineeringAppContent()
            }
        }
    }
}

@Composable
fun EngineeringAppContent(
    vm: EngineeringViewModel = viewModel()
) {
    val state by vm.uiState.collectAsState()

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars)
            .background(CarbonDarkBlack),
        containerColor = CarbonDarkBlack,
        topBar = {
            TelemetryHeader(
                selectedMode = state.selectedMode,
                onSelectMode = { vm.selectMode(it) }
            )
        },
        bottomBar = {
            EngineeringBottomBar(
                currentTab = state.currentTab,
                onSelectTab = { vm.setTab(it) },
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(CarbonDarkBlack)
        ) {
            when (state.currentTab) {
                DashboardTab.OVERVIEW -> {
                    DashboardOverviewScreen(
                        state = state,
                        onScrubRatio = { vm.setScrubRatio(it) },
                        onTogglePlayback = { vm.togglePlayback() }
                    )
                }
                DashboardTab.POWERTRAIN -> {
                    DashboardPowertrainScreen(
                        state = state,
                        onScrubRatio = { vm.setScrubRatio(it) }
                    )
                }
                DashboardTab.CHASSIS -> {
                    DashboardChassisScreen(
                        state = state,
                        onScrubRatio = { vm.setScrubRatio(it) }
                    )
                }
                DashboardTab.CALIBRATION_LAB -> {
                    DashboardCalibrationLabScreen(
                        state = state,
                        onUpdateCustomParam = { pe, tr, sd, ds, dl, aw ->
                            vm.updateCustomParam(pe, tr, sd, ds, dl, aw)
                        },
                        onUpdateWeight = { wr, wa, wy, wt, wth ->
                            vm.updateWeight(wr, wa, wy, wt, wth)
                        },
                        onRunOptimization = { vm.runOptimization() },
                        onOpenExport = { vm.setExportModal(it) }
                    )
                }
                DashboardTab.TRACK_ANALYSIS -> {
                    DashboardTrackAnalysisScreen(
                        state = state,
                        onScrubRatio = { vm.setScrubRatio(it) }
                    )
                }
                DashboardTab.DATA_QUALITY -> {
                    DashboardDataQualityScreen(
                        state = state,
                        onOpenExport = { vm.setExportModal(it) }
                    )
                }
            }

            // Export Modal Dialog if active
            state.exportModalContent?.let { content ->
                ExportModalDialog(
                    content = content,
                    onDismiss = { vm.setExportModal(null) }
                )
            }
        }
    }
}

@Composable
fun EngineeringBottomBar(
    currentTab: DashboardTab,
    onSelectTab: (DashboardTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(DarkNavyGraphite)
            .border(width = 1.dp, color = SlateCardBorder)
            .padding(vertical = 6.dp, horizontal = 8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            DashboardTab.values().forEach { tab ->
                val isSelected = tab == currentTab
                val itemBg = if (isSelected) SlateCardSurface else DarkNavyGraphite
                val itemBorder = if (isSelected) McLarenPapaya else SlateCardBorder
                val textColor = if (isSelected) McLarenPapaya else TechnicalMuted

                val icon: ImageVector = when (tab) {
                    DashboardTab.OVERVIEW -> Icons.Default.Speed
                    DashboardTab.POWERTRAIN -> Icons.Default.ElectricBolt
                    DashboardTab.CHASSIS -> Icons.Default.DirectionsCar
                    DashboardTab.CALIBRATION_LAB -> Icons.Default.Tune
                    DashboardTab.TRACK_ANALYSIS -> Icons.Default.Flag
                    DashboardTab.DATA_QUALITY -> Icons.Default.Assessment
                }

                Box(
                    modifier = Modifier
                        .testTag("nav_tab_${tab.name.lowercase()}")
                        .clip(RoundedCornerShape(6.dp))
                        .background(itemBg)
                        .border(1.dp, itemBorder, RoundedCornerShape(6.dp))
                        .clickable { onSelectTab(tab) }
                        .padding(horizontal = 10.dp, vertical = 7.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = icon,
                            contentDescription = tab.label,
                            tint = textColor,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = tab.shortId,
                            color = textColor,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
