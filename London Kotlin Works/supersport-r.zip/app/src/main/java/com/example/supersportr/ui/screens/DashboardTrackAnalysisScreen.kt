package com.example.supersportr.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.supersportr.ui.components.TelemetryWaveform
import com.example.supersportr.ui.components.WaveformSeries
import com.example.supersportr.ui.viewmodel.EngineeringUiState
import com.example.ui.theme.CarbonDarkBlack
import com.example.ui.theme.McLarenPapaya
import com.example.ui.theme.SlateCardBorder
import com.example.ui.theme.SlateCardSurface
import com.example.ui.theme.TechnicalMuted
import com.example.ui.theme.TechnicalSubtle
import com.example.ui.theme.TechnicalWhite
import com.example.ui.theme.TelemetryAmber
import com.example.ui.theme.TelemetryCyan
import com.example.ui.theme.TelemetryGreen
import com.example.ui.theme.TelemetryRed

@Composable
fun DashboardTrackAnalysisScreen(
    state: EngineeringUiState,
    onScrubRatio: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val session = state.currentSession

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CarbonDarkBlack)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Header Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SlateCardSurface)
                    .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "TRACK TELEMETRY // SECTOR ANALYSIS",
                        color = TechnicalWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Lap Reference: Grand Prix Circuit Sector Simulation (4.8 km)",
                        color = McLarenPapaya,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // 2. Sector 1, 2, 3 Breakdown Matrix
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SlateCardSurface)
                    .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "CIRCUIT SECTOR SPLITS & PEAK METRICS",
                        color = TechnicalWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Text("SECTOR", color = TechnicalSubtle, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                        Text("TIME", color = TechnicalSubtle, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                        Text("V-MAX", color = TechnicalSubtle, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                        Text("LAT-G", color = TechnicalSubtle, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                        Text("ENERGY", color = TechnicalSubtle, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    }
                    Spacer(modifier = Modifier.height(4.dp))

                    session.sectorSummaries.forEach { s ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("S${s.sectorId} (${s.sectorName.substringBefore(' ')})", color = McLarenPapaya, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                            Text("${String.format("%.2f", s.durationS)}s", color = TechnicalWhite, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                            Text("${s.exitSpeedKmh.toInt()} km/h", color = TechnicalWhite, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                            Text("${String.format("%.2f", s.maxLatG)}g", color = TelemetryAmber, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                            Text("${String.format("%.2f", s.energyUsedKwh)} kWh", color = TelemetryCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        // 3. Driver Input Trace: Speed + Throttle % + Brake Bar
        item {
            val speedSeries = WaveformSeries(
                name = "SPEED",
                color = TechnicalWhite,
                values = session.samples.map { it.speedKmh },
                unit = "km/h"
            )
            val throttleSeries = WaveformSeries(
                name = "THROTTLE",
                color = McLarenPapaya,
                values = session.samples.map { it.throttlePct },
                unit = "%"
            )
            val brakeSeries = WaveformSeries(
                name = "BRAKE",
                color = TelemetryRed,
                values = session.samples.map { it.brakePressureBar },
                unit = "bar"
            )

            TelemetryWaveform(
                title = "Driver Control Telemetry Trace",
                subtitle = "Speed Trace vs Pedal Inputs (Throttle % & Carbon Ceramic Brake Bar)",
                series = listOf(speedSeries, throttleSeries, brakeSeries),
                currentCursorRatio = state.scrubRatio,
                onScrubRatio = onScrubRatio,
                modifier = Modifier.fillMaxWidth(),
                canvasHeight = 140
            )
        }

        // 4. Tyre & Brake Thermal Saturation Trace
        item {
            val tyreSeries = WaveformSeries(
                name = "TYRE BULK",
                color = TelemetryAmber,
                values = session.samples.map { it.tyreTempAvgC },
                unit = "°C"
            )
            val brakeSeries = WaveformSeries(
                name = "ROTOR TEMP",
                color = TelemetryRed,
                values = session.samples.map { it.brakeTempAvgC },
                unit = "°C"
            )

            TelemetryWaveform(
                title = "Thermal Evolution Over Lap",
                subtitle = "Pirelli Trofeo Bulk Temp (°C) vs 390mm Carbon-Ceramic Discs (°C)",
                series = listOf(tyreSeries, brakeSeries),
                currentCursorRatio = state.scrubRatio,
                onScrubRatio = onScrubRatio,
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Spacer(modifier = Modifier.height(14.dp))
        }
    }
}
