package com.example.supersportr.model

enum class DriveModeType(val label: String, val shortDesc: String) {
    COMFORT("Comfort", "Grand Touring smoothness & compliance"),
    SPORT("Sport", "Dynamic road response & sharpened feedback"),
    SUPERSPORT("SuperSport", "Coordinated hypercar balance & hybrid torque-fill"),
    TRACK("Track", "Circuit telemetry focus & maximum aero loading"),
    CUSTOM("Custom", "Configurable research calibration parameters")
}

data class DriveModeCalibration(
    val type: DriveModeType,
    val name: String,
    val version: String = "v3.8-cal",
    // Powertrain & pedal shaping
    val pedalResponseExponent: Double, // 1.0 = linear, 0.75 = aggressive tip-in, 0.88 = progressive convex
    val pedalDeadbandPct: Double,
    val maxTorqueRampNmPerSec: Double,
    val hybridTorqueFillPct: Double, // 0.0 to 1.0
    val shiftDurationMs: Double,
    val aggressiveDownshiftBlip: Boolean,
    
    // Chassis & Damping
    val dampingStiffnessRatio: Double, // 0.7x to 1.6x baseline
    val rollResistanceRatio: Double,
    val antiDiveCompensationPct: Double,
    
    // Differential & Traction
    val diffCoastLockupPct: Double, // Entry yaw stabilization (20% - 60%)
    val diffPowerLockupPct: Double, // Corner exit traction lockup (30% - 85%)
    val tractionSlipTargetPct: Double, // Feasible slip ratio target before traction clip
    
    // Aerodynamics
    val activeAeroWingDeg: Double,
    val drsAutoDeploySpeedKmh: Double,
    
    // Safety & Stability
    val stabilityYawMarginDegSec: Double,
    val thermalLimitInverterC: Double,
    val thermalLimitBrakesC: Double
) {
    companion object {
        val COMFORT = DriveModeCalibration(
            type = DriveModeType.COMFORT,
            name = "Comfort Touring",
            pedalResponseExponent = 1.25, // Soft progressive initial travel
            pedalDeadbandPct = 4.0,
            maxTorqueRampNmPerSec = 750.0,
            hybridTorqueFillPct = 0.40,
            shiftDurationMs = 140.0,
            aggressiveDownshiftBlip = false,
            dampingStiffnessRatio = 0.72,
            rollResistanceRatio = 0.80,
            antiDiveCompensationPct = 40.0,
            diffCoastLockupPct = 25.0,
            diffPowerLockupPct = 38.0,
            tractionSlipTargetPct = 6.0,
            activeAeroWingDeg = 4.0,
            drsAutoDeploySpeedKmh = 140.0,
            stabilityYawMarginDegSec = 8.0,
            thermalLimitInverterC = 85.0,
            thermalLimitBrakesC = 600.0
        )

        val SPORT = DriveModeCalibration(
            type = DriveModeType.SPORT,
            name = "Sport Dynamic",
            pedalResponseExponent = 1.00, // Direct linear response
            pedalDeadbandPct = 2.0,
            maxTorqueRampNmPerSec = 1400.0,
            hybridTorqueFillPct = 0.70,
            shiftDurationMs = 85.0,
            aggressiveDownshiftBlip = true,
            dampingStiffnessRatio = 1.05,
            rollResistanceRatio = 1.05,
            antiDiveCompensationPct = 65.0,
            diffCoastLockupPct = 38.0,
            diffPowerLockupPct = 55.0,
            tractionSlipTargetPct = 9.5,
            activeAeroWingDeg = 10.0,
            drsAutoDeploySpeedKmh = 180.0,
            stabilityYawMarginDegSec = 12.0,
            thermalLimitInverterC = 92.0,
            thermalLimitBrakesC = 680.0
        )

        val SUPERSPORT = DriveModeCalibration(
            type = DriveModeType.SUPERSPORT,
            name = "SuperSport R Primary Target",
            // Immediate yet highly controllable: slight convex tip-in for connected feel, broad mid-pedal resolution
            pedalResponseExponent = 0.86,
            pedalDeadbandPct = 1.0,
            maxTorqueRampNmPerSec = 2400.0,
            hybridTorqueFillPct = 0.95, // Near seamless torque bridging via axial flux motor
            shiftDurationMs = 48.0,
            aggressiveDownshiftBlip = true,
            dampingStiffnessRatio = 1.28,
            rollResistanceRatio = 1.30,
            antiDiveCompensationPct = 82.0,
            diffCoastLockupPct = 48.0, // High entry stability without understeer
            diffPowerLockupPct = 72.0, // Aggressive corner exit traction lock
            tractionSlipTargetPct = 13.5, // Controlled high-slip angle threshold
            activeAeroWingDeg = 18.0, // High dynamic downforce balance
            drsAutoDeploySpeedKmh = 210.0,
            stabilityYawMarginDegSec = 16.0,
            thermalLimitInverterC = 98.0,
            thermalLimitBrakesC = 750.0
        )

        val TRACK = DriveModeCalibration(
            type = DriveModeType.TRACK,
            name = "Track Circuit Calibration",
            pedalResponseExponent = 0.78, // Razor sharp instant throttle response
            pedalDeadbandPct = 0.5,
            maxTorqueRampNmPerSec = 3800.0,
            hybridTorqueFillPct = 1.00,
            shiftDurationMs = 35.0,
            aggressiveDownshiftBlip = true,
            dampingStiffnessRatio = 1.55,
            rollResistanceRatio = 1.50,
            antiDiveCompensationPct = 95.0,
            diffCoastLockupPct = 58.0,
            diffPowerLockupPct = 85.0,
            tractionSlipTargetPct = 17.0,
            activeAeroWingDeg = 26.0, // Maximum circuit downforce
            drsAutoDeploySpeedKmh = 230.0,
            stabilityYawMarginDegSec = 22.0,
            thermalLimitInverterC = 105.0,
            thermalLimitBrakesC = 820.0
        )

        fun createCustom(base: DriveModeCalibration = SUPERSPORT): DriveModeCalibration {
            return base.copy(type = DriveModeType.CUSTOM, name = "Custom Research Profile")
        }
    }
}
