package com.example.supersportr.simulation

import com.example.supersportr.model.DriveModeCalibration
import com.example.supersportr.model.TelemetrySample
import com.example.supersportr.model.VehicleProfile
import kotlin.math.PI
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class VehicleDynamicsEngine(val vehicle: VehicleProfile) {

    var timeS: Double = 0.0
    var distanceM: Double = 0.0
    var vxMs: Double = 0.01
    var vyMs: Double = 0.0
    var yawRateRadS: Double = 0.0
    var currentGear: Int = 1
    var shiftTimerMs: Double = 0.0
    var isShifting: Boolean = false
    
    var lastCombinedTorqueNm: Double = 0.0
    var tyreTempAvgC: Double = 75.0
    var brakeTempAvgC: Double = 180.0
    var batterySocPct: Double = 88.0
    var inverterTempC: Double = 62.0

    private val g = 9.80665
    private val crr = 0.015

    fun reset(initialSpeedKmh: Double = 0.0, initialSocPct: Double = 90.0) {
        timeS = 0.0
        distanceM = 0.0
        vxMs = maxOf(0.01, initialSpeedKmh / 3.6)
        vyMs = 0.0
        yawRateRadS = 0.0
        currentGear = 1
        shiftTimerMs = 0.0
        isShifting = false
        lastCombinedTorqueNm = 0.0
        tyreTempAvgC = 75.0
        brakeTempAvgC = 180.0
        batterySocPct = initialSocPct
        inverterTempC = 62.0
    }

    fun computeEngineRpm(vx: Double, gear: Int): Double {
        val gearRatio = vehicle.powertrain.gearRatios.getOrElse(gear - 1) { 1.0 }
        val finalDrive = vehicle.powertrain.finalDriveRatio
        val rw = vehicle.geometry.rearTyreRadiusM
        val wheelOmega = vx / rw
        val engineOmega = wheelOmega * gearRatio * finalDrive
        val rpm = (engineOmega * 60.0) / (2.0 * PI)
        return rpm.coerceIn(vehicle.powertrain.engineIdleRpm, vehicle.powertrain.engineRedlineRpm)
    }

    fun step(
        dtSeconds: Double,
        throttleInput: Double,
        brakeInput: Double,
        steeringInputDeg: Double,
        cal: DriveModeCalibration,
        sensorDropout: Boolean = false
    ): TelemetrySample {
        timeS += dtSeconds
        val geom = vehicle.geometry
        val pwt = vehicle.powertrain
        val aero = vehicle.chassisAero

        // 1. Shift logic (adapted for 10,000 RPM redline)
        val engineRpm = computeEngineRpm(vxMs, currentGear)
        if (!isShifting) {
            if (engineRpm > 9600.0 && currentGear < pwt.gearRatios.size && throttleInput > 0.3) {
                isShifting = true
                shiftTimerMs = cal.shiftDurationMs
            } else if (engineRpm < 3000.0 && currentGear > 1 && brakeInput > 0.1) {
                currentGear--
            }
        } else {
            shiftTimerMs -= dtSeconds * 1000.0
            if (shiftTimerMs <= 0.0) {
                isShifting = false
                if (currentGear < pwt.gearRatios.size) currentGear++
            }
        }

        // 2. Powertrain delivery (with LH2 injection & hybrid assist)
        val currentGearRatio = pwt.gearRatios.getOrElse(currentGear - 1) { 1.0 }
        val totalDriveRatio = currentGearRatio * pwt.finalDriveRatio

        val requestedTorque = PowertrainEngine.calculateRequestedTorque(throttleInput, engineRpm, cal, pwt)
        val pwtState = PowertrainEngine.calculateDelivery(
            requestedTorque = requestedTorque,
            previousCombinedTorque = lastCombinedTorqueNm,
            rpm = engineRpm,
            isShifting = isShifting,
            batterySocPct = batterySocPct,
            inverterTempC = inverterTempC,
            dtSeconds = dtSeconds,
            cal = cal,
            config = pwt
        )
        lastCombinedTorqueNm = pwtState.combinedTorqueNm

        // Energy consumption
        val motorPowerKw = (pwtState.deliveredMotorTorqueNm * (engineRpm * 2.0 * PI / 60.0)) / 1000.0
        val socDelta = (motorPowerKw * (dtSeconds / 3600.0) / pwt.batteryCapacityKwh) * 100.0
        batterySocPct = (batterySocPct - socDelta).coerceIn(5.0, 100.0)
        inverterTempC += (motorPowerKw * 0.0030 * dtSeconds) - (inverterTempC - 35.0) * 0.009 * dtSeconds

        // 3. Aerodynamics (Top speed 450+ km/h capable)
        val wingAngleDeg = cal.activeAeroWingDeg
        val wingFactor = 1.0 + (wingAngleDeg / 15.0) * 0.32
        val cdEffective = aero.baselineCd * (if (vxMs * 3.6 > cal.drsAutoDeploySpeedKmh && throttleInput > 0.8) 0.82 else wingFactor)
        val clEffective = aero.baselineClDownforce * wingFactor

        val qDynamic = 0.5 * geom.airDensityKgM3 * vxMs * vxMs * geom.frontalAreaM2
        val aeroDragN = qDynamic * cdEffective
        val aeroDownforceN = qDynamic * clEffective

        // 4. Vertical Load Transfer (1,180 kg Titanium mass)
        val m = geom.totalMassKg // 1,180 kg!
        val staticFzFront = m * g * (1.0 - geom.frontMassDistribution)
        val staticFzRear = m * g * geom.frontMassDistribution

        val aeroDownforceFront = aeroDownforceN * aero.aeroBalanceFrontPct
        val aeroDownforceRear = aeroDownforceN * (1.0 - aero.aeroBalanceFrontPct)

        val currentAxMps2 = (lastCombinedTorqueNm * totalDriveRatio / geom.rearTyreRadiusM - aeroDragN) / m
        val deltaFzPitch = (m * currentAxMps2 * geom.cgHeightM) / geom.wheelbaseM

        val totalFzFront = maxOf(200.0, staticFzFront + aeroDownforceFront - deltaFzPitch)
        val totalFzRear = maxOf(200.0, staticFzRear + aeroDownforceRear + deltaFzPitch)

        // 5. Tractive / Braking Force & Slip
        val driveWheelTorque = pwtState.combinedTorqueNm * totalDriveRatio * pwt.drivetrainEfficiency
        val potentialTractiveForce = driveWheelTorque / geom.rearTyreRadiusM

        val maxRearTraction = PacejkaTyreModel.peakLongitudinalForce(totalFzRear, tyreTempAvgC, cal.tractionSlipTargetPct)
        var constraintActive = pwtState.constraintActive
        var constraintReason = pwtState.constraintReason

        val actualTractiveForce: Double
        val tyreSlipPct: Double

        if (potentialTractiveForce > maxRearTraction) {
            actualTractiveForce = maxRearTraction
            tyreSlipPct = cal.tractionSlipTargetPct * 1.18
            constraintActive = true
            if (constraintReason == null) {
                constraintReason = "Traction limit: Rear slip saturation (${String.format("%.1f", tyreSlipPct)}%)"
            }
        } else {
            actualTractiveForce = potentialTractiveForce
            tyreSlipPct = (potentialTractiveForce / maxRearTraction * cal.tractionSlipTargetPct).coerceIn(0.0, 20.0)
        }

        // Braking force (Titanium & carbon ceramic package)
        val totalBrakeTorque = brakeInput * aero.brakeMaxTorqueNm
        val brakeForceFront = (totalBrakeTorque * aero.brakeBiasFrontPct) / geom.frontTyreRadiusM
        val brakeForceRear = (totalBrakeTorque * (1.0 - aero.brakeBiasFrontPct)) / geom.rearTyreRadiusM
        val totalBrakeForce = brakeForceFront + brakeForceRear

        val fRollingResistance = crr * m * g
        val netFx = actualTractiveForce - totalBrakeForce - aeroDragN - fRollingResistance
        val axMps2 = netFx / m

        // 6. Planar Bicycle Dynamics
        val roadWheelAngleRad = (steeringInputDeg / aero.steeringRatio) * (PI / 180.0)
        val lf = geom.frontAxleToCgM
        val lr = geom.rearAxleToCgM

        val alphaFrontRad = roadWheelAngleRad - atan((vyMs + lf * yawRateRadS) / maxOf(0.5, vxMs))
        val alphaRearRad = -atan((vyMs - lr * yawRateRadS) / maxOf(0.5, vxMs))

        val fyFront = PacejkaTyreModel.computeLateralForce(alphaFrontRad, totalFzFront, tyreTempAvgC)
        val fyRear = PacejkaTyreModel.computeLateralForce(alphaRearRad, totalFzRear, tyreTempAvgC)

        val diffLockFactor = if (throttleInput > 0.2) cal.diffPowerLockupPct / 100.0 else cal.diffCoastLockupPct / 100.0
        val diffYawTorqueNm = -yawRateRadS * (diffLockFactor * 480.0)

        val yawAccRadS2 = ((lf * fyFront * cos(roadWheelAngleRad) - lr * fyRear) + diffYawTorqueNm) / geom.yawInertiaKgm2
        yawRateRadS += yawAccRadS2 * dtSeconds
        val ayMps2 = vxMs * yawRateRadS + ((fyFront * cos(roadWheelAngleRad) + fyRear) / m)

        val rollAngleDeg = (m * ayMps2 * geom.cgHeightM / aero.rollStiffnessNmRad) * (180.0 / PI) * (1.0 / cal.rollResistanceRatio)
        val pitchAngleDeg = (m * axMps2 * geom.cgHeightM / aero.pitchStiffnessNmRad) * (180.0 / PI) * (1.0 - cal.antiDiveCompensationPct / 200.0)

        vxMs = maxOf(0.01, vxMs + axMps2 * dtSeconds)
        vyMs = (vyMs + ((fyFront + fyRear) / m - vxMs * yawRateRadS) * dtSeconds).coerceIn(-12.0, 12.0)
        distanceM += vxMs * dtSeconds

        // 7. Thermal & Hydrogen Exhaust
        val tyreWorkPower = (actualTractiveForce * (tyreSlipPct / 100.0) + (fyFront + fyRear) * 0.05) * 0.007
        val tyreCooling = (tyreTempAvgC - 30.0) * (0.012 * sqrt(vxMs))
        tyreTempAvgC = (tyreTempAvgC + (tyreWorkPower - tyreCooling) * dtSeconds).coerceIn(30.0, 150.0)

        val brakePowerKw = (totalBrakeForce * vxMs) / 1000.0
        val brakeCooling = (brakeTempAvgC - 35.0) * (0.006 * sqrt(vxMs))
        brakeTempAvgC = (brakeTempAvgC + (brakePowerKw * 0.040 - brakeCooling) * dtSeconds).coerceIn(35.0, 950.0)

        if (brakeTempAvgC > cal.thermalLimitBrakesC) {
            constraintActive = true
            if (constraintReason == null) {
                constraintReason = "Brake temperature high (${brakeTempAvgC.toInt()}°C): Fade margin threshold"
            }
        }

        val sectorId = when {
            distanceM < 1600.0 -> 1
            distanceM < 3600.0 -> 2
            else -> 3
        }

        val speedKmh = vxMs * 3.6
        val axG = axMps2 / g
        val ayG = ayMps2 / g

        // Clean water vapour exhaust generation (g/s)
        val waterVapourRateGs = (pwtState.combinedPowerKw / 772.0) * 18.5

        return TelemetrySample(
            timestampS = timeS,
            distanceM = distanceM,
            speedKmh = speedKmh,
            speedMs = vxMs,
            throttlePct = throttleInput * 100.0,
            brakePressureBar = brakeInput * 140.0,
            steeringAngleDeg = steeringInputDeg,
            engineRpm = engineRpm,
            currentGear = currentGear,
            shiftInProgress = isShifting,
            requestedTorqueNm = requestedTorque,
            engineTorqueDeliveredNm = pwtState.deliveredEngineTorqueNm,
            motorTorqueDeliveredNm = pwtState.deliveredMotorTorqueNm,
            combinedTorqueDeliveredNm = pwtState.combinedTorqueNm,
            totalPowerKw = pwtState.combinedPowerKw,
            totalPowerHp = pwtState.combinedPowerHp,
            batterySocPct = batterySocPct,
            inverterTempC = inverterTempC,
            lh2RailPressureBar = pwtState.lh2RailPressureBar,
            lh2TankTempC = -253.0,
            cryoIntakeTempDropC = pwtState.cryoIntakeTempDropC,
            exhaustWaterVapourGs = waterVapourRateGs,
            emissionsCo2GPerKm = 0.0,
            axG = axG,
            ayG = ayG,
            yawRateDegS = yawRateRadS * (180.0 / PI),
            rollAngleDeg = rollAngleDeg,
            pitchAngleDeg = pitchAngleDeg,
            tyreSlipPct = tyreSlipPct,
            flLoadN = totalFzFront * 0.5 - (totalFzFront * ayG * 0.2),
            frLoadN = totalFzFront * 0.5 + (totalFzFront * ayG * 0.2),
            rlLoadN = totalFzRear * 0.5 - (totalFzRear * ayG * 0.2),
            rrLoadN = totalFzRear * 0.5 + (totalFzRear * ayG * 0.2),
            tyreTempAvgC = tyreTempAvgC,
            brakeTempAvgC = brakeTempAvgC,
            diffLockPct = diffLockFactor * 100.0,
            aeroDownforceN = aeroDownforceN,
            aeroDragN = aeroDragN,
            activeWingAngleDeg = wingAngleDeg,
            constraintActive = constraintActive,
            constraintReason = constraintReason,
            sensorQualityOk = !sensorDropout,
            sectorId = sectorId
        )
    }
}
