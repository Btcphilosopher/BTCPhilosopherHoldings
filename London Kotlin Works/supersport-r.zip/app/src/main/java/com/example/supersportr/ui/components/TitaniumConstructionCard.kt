package com.example.supersportr.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.supersportr.model.TitaniumFinish
import com.example.ui.theme.DarkNavyGraphite
import com.example.ui.theme.McLarenPapaya
import com.example.ui.theme.SlateCardBorder
import com.example.ui.theme.SlateCardSurface
import com.example.ui.theme.TechnicalMuted
import com.example.ui.theme.TechnicalSubtle
import com.example.ui.theme.TechnicalWhite
import com.example.ui.theme.TelemetryCyan

/**
 * Visual card displaying the McLaren Titanium construction architecture,
 * metallurgy properties, and finish options from the McLaren Titanium infographic.
 */
@Composable
fun TitaniumConstructionCard(modifier: Modifier = Modifier) {
    var selectedFinish by remember { mutableStateOf(TitaniumFinish.NATURAL) }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(SlateCardSurface)
            .border(1.dp, SlateCardBorder, RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "TITANIUM CONSTRUCTION // LESS WEIGHT. MORE SOUL.",
                        color = TechnicalWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Total Curb Weight: 1,180 kg  |  Power: 1,050 hp  |  0-100: 2.4s",
                        color = McLarenPapaya,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF222B38))
                        .border(1.dp, SlateCardBorder, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Text("1,180 KG", color = TechnicalWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Titanium Component Hierarchy
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                TitaniumRowItem(part = "Monocoque Chassis", material = "100% Titanium", highlight = "Ultra-rigid tub")
                TitaniumRowItem(part = "Body Panels", material = "Titanium (Exposed Finish)", highlight = "Bare metal finish")
                TitaniumRowItem(part = "Subframes", material = "Aerospace Titanium", highlight = "Direct engine mounting")
                TitaniumRowItem(part = "Suspension Components", material = "Titanium & Carbon Hybrid", highlight = "Unsprung mass reduction")
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Material Advantage Badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TitaniumAdvantageBadge(icon = Icons.Default.Speed, title = "HIGH STRENGTH", desc = "Optimal ratio", modifier = Modifier.weight(1f))
                TitaniumAdvantageBadge(icon = Icons.Default.Shield, title = "CORROSION RESIST", desc = "Zero oxidation", modifier = Modifier.weight(1f))
                TitaniumAdvantageBadge(icon = Icons.Default.Thermostat, title = "EXTREME TEMP", desc = "Tolerance", modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Color & Finish Options (Natural, Brushed, Matte)
            Text(
                text = "COLOUR & FINISH OPTIONS: PURE TITANIUM. NOTHING ELSE.",
                color = TechnicalSubtle,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TitaniumFinish.values().forEach { finish ->
                    val isSelected = finish == selectedFinish
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSelected) Color(0xFF2D3B4E) else DarkNavyGraphite)
                            .border(1.dp, if (isSelected) McLarenPapaya else SlateCardBorder, RoundedCornerShape(4.dp))
                            .clickable { selectedFinish = finish }
                            .padding(vertical = 5.dp, horizontal = 6.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = finish.label.uppercase(),
                                color = if (isSelected) McLarenPapaya else TechnicalWhite,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = if (finish == TitaniumFinish.NATURAL) "(Standard)" else "(Optional)",
                                color = TechnicalSubtle,
                                fontSize = 7.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TitaniumRowItem(part: String, material: String, highlight: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(DarkNavyGraphite)
            .border(1.dp, SlateCardBorder, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(part, color = TechnicalWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text(highlight, color = TechnicalSubtle, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        }
        Text(material, color = McLarenPapaya, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun TitaniumAdvantageBadge(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    desc: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xFF0F1622))
            .border(1.dp, SlateCardBorder, RoundedCornerShape(4.dp))
            .padding(6.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Icon(imageVector = icon, contentDescription = null, tint = TelemetryCyan, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.height(2.dp))
            Text(title, color = TechnicalWhite, fontSize = 7.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text(desc, color = TechnicalSubtle, fontSize = 7.sp, fontFamily = FontFamily.Monospace)
        }
    }
}
