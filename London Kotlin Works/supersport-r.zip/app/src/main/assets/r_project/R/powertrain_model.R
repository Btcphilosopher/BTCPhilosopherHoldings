# ==============================================================================
# McLAREN SUPERSPORT R: POWERTRAIN & HYBRID MODEL (R6 CLASS)
# ==============================================================================

library(R6)

PowertrainModel <- R6Class("PowertrainModel",
  public = list(
    config = NULL,
    current_rpm = 900,
    current_gear = 1,
    battery_soc = 85.0,
    inverter_temp = 62.0,
    last_torque = 0.0,

    initialize = function(config) {
      self$config <- config
    },

    get_peak_ice_torque = function(rpm) {
      if (rpm < self$config$powertrain$idle_rpm || rpm > self$config$powertrain$redline_rpm) return(0)
      if (rpm < 3000) {
        return(350 + (rpm - 900) / 2100 * 450)
      } else if (rpm <= 6500) {
        return(self$config$powertrain$peak_engine_torque_nm)
      } else {
        return(self$config$powertrain$peak_engine_torque_nm - (rpm - 6500) / 2000 * 180)
      }
    },

    get_peak_motor_torque = function(rpm) {
      peak_tq <- self$config$powertrain$peak_motor_torque_nm
      max_watts <- self$config$powertrain$peak_motor_power_kw * 1000
      omega <- max(1, (rpm * 2 * pi) / 60)
      return(min(peak_tq, max_watts / omega))
    },

    step = function(pedal_input, cal, dt = 0.05, is_shifting = FALSE) {
      deadband <- cal$pedal_deadband_pct / 100
      eff_pedal <- max(0, min(1, (pedal_input - deadband) / (1 - deadband)))
      pedal_factor <- eff_pedal ^ cal$pedal_response_exponent

      ice_max <- self$get_peak_ice_torque(self$current_rpm)
      em_max <- self$get_peak_motor_torque(self$current_rpm)
      total_capacity <- ice_max + em_max

      requested_torque <- pedal_factor * total_capacity

      # Torque rate ramp
      max_step <- cal$max_torque_ramp * dt
      ramped_tq <- self$last_torque + pmax(-max_step * 2.5, pmin(max_step, requested_torque - self$last_torque))

      # Thermal and SoC derate
      if (self$battery_soc < 15.0) em_max <- em_max * (self$battery_soc / 15.0)
      if (self$inverter_temp > cal$thermal_limit_inverter) em_max <- em_max * 0.7

      # Shift fill
      if (is_shifting) {
        ice_deliv <- 0
        em_deliv <- min(ramped_tq * cal$hybrid_torque_fill, em_max)
      } else {
        em_deliv <- min(ramped_tq * 0.25, em_max)
        ice_deliv <- min(ramped_tq - em_deliv, ice_max)
      }

      combined_tq <- ice_deliv + em_deliv
      self$last_torque <- combined_tq

      list(
        requested = requested_torque,
        ice_delivered = ice_deliv,
        em_delivered = em_deliv,
        combined = combined_tq,
        power_kw = (combined_tq * (self$current_rpm * 2 * pi / 60)) / 1000
      )
    }
  )
)
