package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.domain.DiggingOptimizer
import com.example.domain.GroundModel
import com.example.domain.KinematicsEngine
import com.example.domain.MachinePose
import com.example.domain.VolumeEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read app string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("JCB DIGITWIN", appName)
  }

  @Test
  fun `test kinematic forward and inverse kinematics`() {
    val pose = MachinePose(boomAngleDeg = 45f, dipperAngleDeg = -60f, bucketAngleDeg = -30f, slewAngleDeg = 0f)
    val result = KinematicsEngine.calculateForwardKinematics(pose)
    assertTrue("Reach should be positive", result.reachMeters > 0)

    val ikPose = KinematicsEngine.solveInverseKinematics(6.5f, 0f, -2.0f)
    assertTrue("Boom angle in valid range", ikPose.boomAngleDeg in 10f..75f)
  }

  @Test
  fun `test volume engine calculation`() {
    val voxels = GroundModel.createDefaultVoxelGrid()
    val stats = VolumeEngine.calculateStats(voxels)
    assertTrue("Target volume should be positive", stats.totalTargetM3 > 0)
    assertTrue("Completion percentage should be 0..100", stats.completionPct in 0..100)
  }

  @Test
  fun `test candidate optimization strategies`() {
    val strategies = DiggingOptimizer.generateCandidateStrategies()
    assertEquals(4, strategies.size)
    assertTrue("PATH_A strategy exists", strategies.any { it.code == "PATH_A" })
  }
}
