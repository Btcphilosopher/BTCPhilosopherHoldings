package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface DigitwinDao {
    @Query("SELECT * FROM machines WHERE id = :id")
    fun getMachineFlow(id: String): Flow<MachineEntity?>

    @Query("SELECT * FROM machines")
    fun getAllMachines(): Flow<List<MachineEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateMachine(machine: MachineEntity)

    @Query("SELECT * FROM sites WHERE id = :id")
    fun getSiteFlow(id: String): Flow<SiteEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateSite(site: SiteEntity)

    @Query("SELECT * FROM dig_cycles ORDER BY cycleNumber DESC LIMIT 100")
    fun getRecentCyclesFlow(): Flow<List<DigCycleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCycle(cycle: DigCycleEntity)

    @Query("DELETE FROM dig_cycles")
    suspend fun clearCycles()

    @Query("SELECT * FROM subsurface_layers ORDER BY depthStartM ASC")
    fun getSubsurfaceLayersFlow(): Flow<List<SubsurfaceLayerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLayers(layers: List<SubsurfaceLayerEntity>)
}

@Database(
    entities = [
        MachineEntity::class,
        SiteEntity::class,
        DigCycleEntity::class,
        SubsurfaceLayerEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun digitwinDao(): DigitwinDao
}
