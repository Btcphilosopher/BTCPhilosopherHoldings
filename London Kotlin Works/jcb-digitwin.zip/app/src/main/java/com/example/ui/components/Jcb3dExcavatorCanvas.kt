package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.KinematicsEngine
import com.example.domain.MachinePose
import com.example.ui.theme.*
import kotlin.math.*

@Composable
fun Jcb3dExcavatorCanvas(
    pose: MachinePose = MachinePose(42f, -65f, -25f, 15f),
    selectedComponent: String = "BUCKET",
    onSelectComponent: (String) -> Unit = {},
    bucketFillPct: Int = 92,
    hydraulicPressureBar: Float = 312f,
    modifier: Modifier = Modifier
) {
    var cameraRotX by remember { mutableFloatStateOf(20f) }
    var cameraRotY by remember { mutableFloatStateOf(35f) }
    var isWireframeMode by remember { mutableStateOf(false) }

    val kinematicResult = remember(pose) {
        KinematicsEngine.calculateForwardKinematics(pose)
    }

    Box(
        modifier = modifier
            .background(JcbBlack)
            .border(1.dp, JcbGraphite)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    cameraRotY += dragAmount.x * 0.4f
                    cameraRotX = (cameraRotX - dragAmount.y * 0.4f).coerceIn(-10f, 60f)
                }
            }
            .testTag("3d_excavator_canvas")
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height
            val center = Offset(canvasWidth / 2f, canvasHeight / 2f + 60f)

            draw3dGrid(center, cameraRotX, cameraRotY)

            fun project3D(x: Float, y: Float, z: Float): Offset {
                val radY = Math.toRadians(cameraRotY.toDouble())
                val radX = Math.toRadians(cameraRotX.toDouble())

                val rx = (x * cos(radY) - y * sin(radY)).toFloat()
                val ry = (x * sin(radY) + y * cos(radY)).toFloat()
                val rz = (z * cos(radX) - ry * sin(radX)).toFloat()

                val scale = 22f
                val screenX = center.x + rx * scale
                val screenY = center.y - rz * scale
                return Offset(screenX, screenY)
            }

            drawUndercarriage3D(::project3D, selectedComponent == "TRACKS", isWireframeMode)

            drawUpperStructure3D(
                ::project3D,
                pose.slewAngleDeg,
                selectedComponent == "CABIN" || selectedComponent == "ENGINE",
                isWireframeMode
            )

            val boomBase = project3D(0.8f, 0f, 2.3f)
            val dipperJoint = project3D(
                kinematicResult.dipperJoint.x,
                kinematicResult.dipperJoint.y,
                kinematicResult.dipperJoint.z
            )
            drawComponentArmSegment(
                from = boomBase,
                to = dipperJoint,
                color = if (selectedComponent == "BOOM") JcbYellow else DeepYellow,
                strokeWidth = 24f,
                isSelected = selectedComponent == "BOOM"
            )

            val boomCylMid = Offset((boomBase.x + dipperJoint.x) / 2f, (boomBase.y + dipperJoint.y) / 2f + 15f)
            drawLine(
                color = if (selectedComponent == "HYDRAULICS") JcbYellow else MachineAluminium,
                start = Offset(boomBase.x + 10f, boomBase.y - 10f),
                end = boomCylMid,
                strokeWidth = 10f
            )

            val bucketJoint = project3D(
                kinematicResult.bucketJoint.x,
                kinematicResult.bucketJoint.y,
                kinematicResult.bucketJoint.z
            )
            drawComponentArmSegment(
                from = dipperJoint,
                to = bucketJoint,
                color = if (selectedComponent == "DIPPER") JcbYellow else DeepYellow,
                strokeWidth = 18f,
                isSelected = selectedComponent == "DIPPER"
            )

            val bucketTip = project3D(
                kinematicResult.bucketTip.x,
                kinematicResult.bucketTip.y,
                kinematicResult.bucketTip.z
            )
            drawBucket3D(
                joint = bucketJoint,
                tip = bucketTip,
                fillPct = bucketFillPct,
                isSelected = selectedComponent == "BUCKET"
            )
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = JcbGraphite.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.border(1.dp, EngineeringGrey, RoundedCornerShape(4.dp))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.RotateRight, contentDescription = null, tint = JcbYellow, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("3D ROTATABLE TWIN", color = Paper, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                FilterChip(
                    selected = isWireframeMode,
                    onClick = { isWireframeMode = !isWireframeMode },
                    label = { Text("WIREFRAME", fontSize = 10.sp) },
                    modifier = Modifier.height(28.dp)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "ROT X: ${cameraRotX.toInt()}°  ROT Y: ${cameraRotY.toInt()}° | DRAG TO ROTATE",
                color = MachineAluminium,
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium
            )
        }

        Row(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf("BOOM", "DIPPER", "BUCKET", "HYDRAULICS", "CABIN", "TRACKS").forEach { comp ->
                Box(
                    modifier = Modifier
                        .background(if (selectedComponent == comp) JcbYellow else JcbGraphite, RoundedCornerShape(2.dp))
                        .border(1.dp, if (selectedComponent == comp) JcbYellow else EngineeringGrey, RoundedCornerShape(2.dp))
                        .clickable { onSelectComponent(comp) }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = comp,
                        color = if (selectedComponent == comp) JcbBlack else Paper,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

private fun DrawScope.draw3dGrid(center: Offset, rotX: Float, rotY: Float) {
    val gridColor = EngineeringGrey.copy(alpha = 0.25f)
    for (i in -8..8) {
        val step = i * 25f
        drawLine(gridColor, Offset(center.x - 300f, center.y + step), Offset(center.x + 300f, center.y + step), strokeWidth = 1f)
        drawLine(gridColor, Offset(center.x + step, center.y - 150f), Offset(center.x + step, center.y + 150f), strokeWidth = 1f)
    }
}

private fun DrawScope.drawUndercarriage3D(
    project: (Float, Float, Float) -> Offset,
    isSelected: Boolean,
    isWireframe: Boolean
) {
    val trackColor = if (isSelected) JcbYellow else JcbGraphite
    val p1 = project(-2.2f, -1.4f, 0f)

    drawRect(
        color = trackColor,
        topLeft = Offset(p1.x - 20f, p1.y - 15f),
        size = Size(180f, 30f),
        style = if (isWireframe) Stroke(2f) else androidx.compose.ui.graphics.drawscope.Fill
    )
}

private fun DrawScope.drawUpperStructure3D(
    project: (Float, Float, Float) -> Offset,
    slewAngleDeg: Float,
    isSelected: Boolean,
    isWireframe: Boolean
) {
    val cabinPos = project(0.2f, 0f, 1.8f)
    val cabColor = if (isSelected) JcbYellow else JcbGraphite

    drawCircle(
        color = DeepYellow,
        center = cabinPos,
        radius = 28f,
        style = Stroke(4f)
    )

    drawRect(
        color = cabColor,
        topLeft = Offset(cabinPos.x - 35f, cabinPos.y - 35f),
        size = Size(70f, 50f)
    )
}

private fun DrawScope.drawComponentArmSegment(
    from: Offset,
    to: Offset,
    color: Color,
    strokeWidth: Float,
    isSelected: Boolean
) {
    drawLine(
        color = if (isSelected) JcbYellow else color,
        start = from,
        end = to,
        strokeWidth = strokeWidth,
        cap = StrokeCap.Round
    )

    drawCircle(
        color = Paper,
        center = to,
        radius = strokeWidth / 2.5f
    )
}

private fun DrawScope.drawBucket3D(
    joint: Offset,
    tip: Offset,
    fillPct: Int,
    isSelected: Boolean
) {
    val bucketPath = Path().apply {
        moveTo(joint.x, joint.y)
        lineTo(joint.x + 25f, joint.y + 20f)
        lineTo(tip.x, tip.y)
        lineTo(joint.x - 15f, joint.y + 30f)
        close()
    }

    drawPath(
        path = bucketPath,
        color = if (isSelected) JcbYellow else DeepYellow,
        style = androidx.compose.ui.graphics.drawscope.Fill
    )

    drawPath(
        path = bucketPath,
        color = Paper,
        style = Stroke(2f)
    )

    if (fillPct > 0) {
        val fillHeight = (fillPct / 100f) * 20f
        drawCircle(
            color = EarthClay,
            center = Offset((joint.x + tip.x) / 2f, (joint.y + tip.y) / 2f),
            radius = fillHeight
        )
    }
}
