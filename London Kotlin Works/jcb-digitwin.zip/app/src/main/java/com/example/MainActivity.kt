package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.room.Room
import com.example.data.AppDatabase
import com.example.data.DigitalTwinRepository
import com.example.ui.DigitwinViewModel
import com.example.ui.StudioTab
import com.example.ui.components.JcbHeaderBar
import com.example.ui.screens.*
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {

    private lateinit var database: AppDatabase
    private lateinit var repository: DigitalTwinRepository
    private lateinit var viewModel: DigitwinViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "jcb_digitwin_db"
        ).fallbackToDestructiveMigration().build()

        repository = DigitalTwinRepository(database.digitwinDao())
        viewModel = DigitwinViewModel(repository)

        setContent {
            JcbDigitwinTheme(darkTheme = true) {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()

                if (uiState.activeTab != StudioTab.OVERVIEW) {
                    BackHandler {
                        viewModel.selectTab(StudioTab.OVERVIEW)
                    }
                }

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("jcb_root_scaffold"),
                    bottomBar = {
                        StudioBottomNavigationBar(
                            activeTab = uiState.activeTab,
                            onSelectTab = { viewModel.selectTab(it) }
                        )
                    }
                ) { innerPadding ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(JcbBlack)
                    ) {
                        JcbHeaderBar(
                            activeSiteName = uiState.siteInfo?.siteName ?: "SITE / 04 / ACTIVE",
                            activeMachineModel = uiState.simState.activeMachineModel,
                            isSimulating = uiState.simState.isRunning,
                            simulationSpeed = uiState.simState.simulationSpeed,
                            onToggleSimulation = { viewModel.toggleSimulation() },
                            onSelectSpeed = { viewModel.setSimulationSpeed(it) },
                            onOpenAiClick = { viewModel.selectTab(StudioTab.GEMINI_AI) }
                        )

                        Box(modifier = Modifier.weight(1f)) {
                            when (uiState.activeTab) {
                                StudioTab.OVERVIEW -> OverviewScreen(
                                    uiState = uiState,
                                    onSelectTab = { viewModel.selectTab(it) },
                                    onToggleSim = { viewModel.toggleSimulation() },
                                    onSelectComponent = { viewModel.selectComponent(it) }
                                )
                                StudioTab.MACHINE_TWIN -> MachineTwinScreen(
                                    uiState = uiState,
                                    onSelectComponent = { viewModel.selectComponent(it) }
                                )
                                StudioTab.SITE_GROUND -> SiteGroundScreen(
                                    uiState = uiState
                                )
                                StudioTab.DIG_PLAN -> DigPlanScreen(
                                    uiState = uiState
                                )
                                StudioTab.EXCAVATION -> ExcavatorCycleScreen(
                                    uiState = uiState,
                                    onSelectStrategy = { viewModel.selectStrategy(it) }
                                )
                                StudioTab.AUTONOMY -> AutonomyLabScreen(
                                    uiState = uiState
                                )
                                StudioTab.REPLAY -> ReplayAnalyticsScreen(
                                    uiState = uiState,
                                    onSetSpeed = { viewModel.setSimulationSpeed(it) }
                                )
                                StudioTab.FLEET -> FleetOperatorScreen(
                                    uiState = uiState,
                                    onSelectMachineModel = { viewModel.selectMachineModel(it) },
                                    onSelectAttachment = { viewModel.selectAttachment(it) }
                                )
                                StudioTab.GEMINI_AI -> GeminiIntelligenceScreen(
                                    uiState = uiState,
                                    onRunAiAnalysis = { viewModel.runGeminiAiAnalysis() }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StudioBottomNavigationBar(
    activeTab: StudioTab,
    onSelectTab: (StudioTab) -> Unit
) {
    Surface(
        color = JcbBlack,
        modifier = Modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = EngineeringGrey.copy(alpha = 0.4f))
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            StudioTab.entries.forEach { tab ->
                val isSelected = tab == activeTab

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(2.dp))
                        .background(if (isSelected) JcbYellow else JcbGraphite)
                        .border(
                            width = 1.dp,
                            color = if (isSelected) JcbYellow else EngineeringGrey.copy(alpha = 0.4f),
                            shape = RoundedCornerShape(2.dp)
                        )
                        .clickable { onSelectTab(tab) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("tab_${tab.name.lowercase()}")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (tab == StudioTab.GEMINI_AI) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = if (isSelected) JcbBlack else JcbYellow,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                        Text(
                            text = tab.title,
                            color = if (isSelected) JcbBlack else Paper,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }
        }
    }
}
