package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun JcbSubsurfaceSliceView(
    currentDepthM: Float = 2.91f,
    targetDepthM: Float = 3.20f,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(JcbBlack)
            .border(1.dp, JcbGraphite, RoundedCornerShape(4.dp))
            .padding(12.dp)
            .testTag("subsurface_slice_view")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SIGNATURE SUBSURFACE GEOTECHNICAL SLICE",
                color = JcbYellow,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "CUT DEPTH: ${"%.2f".format(currentDepthM)}m / TARGET ${"%.2f".format(targetDepthM)}m",
                color = Paper,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .background(JcbGraphite)
        ) {
            val width = size.width
            val height = size.height

            // Layer Depths
            val topsoilY = height * 0.12f
            val clayY = height * 0.45f
            val sandY = height * 0.68f
            val rockY = height * 0.88f

            // Topsoil
            drawRect(EarthTopsoil, Offset(0f, 0f), Size(width, topsoilY))
            // Clay
            drawRect(EarthClay, Offset(0f, topsoilY), Size(width, clayY - topsoilY))
            // Sand
            drawRect(EarthSand, Offset(0f, clayY), Size(width, sandY - clayY))
            // Soft Rock
            drawRect(EarthRock, Offset(0f, sandY), Size(width, height - sandY))

            // Draw Buried Water Pipe at 1.8m
            val pipeY = height * 0.52f
            drawCircle(SignalAmber, center = Offset(width * 0.72f, pipeY), radius = 12f)
            drawCircle(Paper, center = Offset(width * 0.72f, pipeY), radius = 12f, style = androidx.compose.ui.graphics.drawscope.Stroke(2f))

            // Draw Target Trench Line (Target 3.2m)
            val targetLineY = height * (targetDepthM / 4.0f)
            drawLine(
                color = JcbYellow,
                start = Offset(width * 0.15f, targetLineY),
                end = Offset(width * 0.85f, targetLineY),
                strokeWidth = 3f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))
            )

            // Draw Actual Cut Line (Current 2.91m)
            val currentCutY = height * (currentDepthM / 4.0f)
            drawLine(
                color = Paper,
                start = Offset(width * 0.15f, currentCutY),
                end = Offset(width * 0.85f, currentCutY),
                strokeWidth = 4f
            )

            // Bucket Tip Position Marker
            drawCircle(
                color = JcbYellow,
                center = Offset(width * 0.45f, currentCutY),
                radius = 8f
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            SoilLegendItem("TOPSOIL (0-0.5m)", EarthTopsoil)
            SoilLegendItem("CLAY (0.5-1.8m)", EarthClay)
            SoilLegendItem("SAND (1.8-2.6m)", EarthSand)
            SoilLegendItem("ROCK (>2.6m)", EarthRock)
            SoilLegendItem("PIPE 300mm", SignalAmber)
        }
    }
}

@Composable
private fun SoilLegendItem(name: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = name,
            color = WarmConcrete,
            fontSize = 8.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}
