package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.KinematicsEngine
import com.example.domain.MachinePose
import com.example.ui.theme.*

@Composable
fun JcbArmKinematicsCanvas(
    pose: MachinePose = MachinePose(42f, -65f, -25f, 0f),
    modifier: Modifier = Modifier
) {
    val kinematicResult = KinematicsEngine.calculateForwardKinematics(pose)

    Box(
        modifier = modifier
            .background(JcbBlack)
            .border(1.dp, JcbGraphite)
            .padding(8.dp)
            .testTag("arm_kinematics_canvas")
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            val origin = Offset(width * 0.25f, height * 0.60f)
            val scale = 18f

            drawLine(
                color = EngineeringGrey.copy(alpha = 0.5f),
                start = Offset(0f, origin.y),
                end = Offset(width, origin.y),
                strokeWidth = 2f
            )

            val boomEnd = Offset(
                origin.x + KinematicsEngine.BOOM_LENGTH * scale * kotlin.math.cos(Math.toRadians(pose.boomAngleDeg.toDouble())).toFloat(),
                origin.y - KinematicsEngine.BOOM_LENGTH * scale * kotlin.math.sin(Math.toRadians(pose.boomAngleDeg.toDouble())).toFloat()
            )

            val dipperRad = Math.toRadians((pose.boomAngleDeg + pose.dipperAngleDeg).toDouble()).toFloat()
            val dipperEnd = Offset(
                boomEnd.x + KinematicsEngine.DIPPER_LENGTH * scale * kotlin.math.cos(dipperRad),
                boomEnd.y - KinematicsEngine.DIPPER_LENGTH * scale * kotlin.math.sin(dipperRad)
            )

            val bucketRad = Math.toRadians((pose.boomAngleDeg + pose.dipperAngleDeg + pose.bucketAngleDeg).toDouble()).toFloat()
            val bucketTip = Offset(
                dipperEnd.x + KinematicsEngine.BUCKET_LENGTH * scale * kotlin.math.cos(bucketRad),
                dipperEnd.y - KinematicsEngine.BUCKET_LENGTH * scale * kotlin.math.sin(bucketRad)
            )

            drawLine(JcbYellow, origin, boomEnd, strokeWidth = 14f)
            drawLine(DeepYellow, boomEnd, dipperEnd, strokeWidth = 10f)
            drawLine(Paper, dipperEnd, bucketTip, strokeWidth = 6f)

            drawCircle(color = Paper, radius = 8f, center = origin)
            drawCircle(color = Paper, radius = 6f, center = boomEnd)
            drawCircle(color = Paper, radius = 5f, center = dipperEnd)
            drawCircle(color = JcbYellow, radius = 6f, center = bucketTip)

            drawLine(
                color = EngineeringGrey,
                start = Offset(origin.x, origin.y + 25f),
                end = Offset(bucketTip.x, origin.y + 25f),
                strokeWidth = 1f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
            )
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .background(JcbGraphite.copy(alpha = 0.85f))
                .padding(8.dp)
        ) {
            Text("KINEMATIC METRICS", color = JcbYellow, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text("REACH: ${"%.2f".format(kinematicResult.reachMeters)} m", color = Paper, fontSize = 9.sp)
            Text("DIG DEPTH: ${"%.2f".format(kinematicResult.depthMeters)} m", color = Paper, fontSize = 9.sp)
            Text("DUMP HEIGHT: ${"%.2f".format(kinematicResult.dumpHeightMeters)} m", color = Paper, fontSize = 9.sp)
            Text("BOOM ANGLE: ${pose.boomAngleDeg.toInt()}°", color = WarmConcrete, fontSize = 9.sp)
            Text("DIPPER ANGLE: ${pose.dipperAngleDeg.toInt()}°", color = WarmConcrete, fontSize = 9.sp)
            Text("BUCKET ANGLE: ${pose.bucketAngleDeg.toInt()}°", color = WarmConcrete, fontSize = 9.sp)
        }
    }
}
