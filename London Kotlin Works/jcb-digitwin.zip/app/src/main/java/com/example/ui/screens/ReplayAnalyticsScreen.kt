package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.MachineHealthEngine
import com.example.ui.StudioUiState
import com.example.ui.theme.*

@Composable
fun ReplayAnalyticsScreen(
    uiState: StudioUiState,
    onSetSpeed: (Float) -> Unit
) {
    var replayProgress by remember { mutableFloatStateOf(0.67f) }
    val healthSummary = remember { MachineHealthEngine.generateHealthSummary() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JcbBlack)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("replay_analytics_screen")
    ) {
        Text(
            text = "EXCAVATION REPLAY & PREDICTIVE MAINTENANCE ANALYTICS",
            color = JcbYellow,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Excavation Replay Timeline Slider
        Card(
            colors = CardDefaults.cardColors(containerColor = JcbSurfaceDark),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, JcbYellow)
                .padding(12.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("TIMELINE REPLAY PLAYER", color = JcbYellow, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("${(replayProgress * 100).toInt()}% TIMELINE (CYCLE 184)", color = Paper, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(8.dp))

                Slider(
                    value = replayProgress,
                    onValueChange = { replayProgress = it },
                    valueRange = 0f..1f,
                    colors = SliderDefaults.colors(thumbColor = JcbYellow, activeTrackColor = JcbYellow)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("00:00 START", color = EngineeringGrey, fontSize = 9.sp)
                    Text("SPEED: ${uiState.simState.simulationSpeed.toInt()}X", color = JcbYellow, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text("03:45 END", color = EngineeringGrey, fontSize = 9.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Digital Twin Calibration & Model Error Validation Card
        Card(
            colors = CardDefaults.cardColors(containerColor = JcbSurfaceDark),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, JcbGraphite)
                .padding(12.dp)
        ) {
            Column {
                Text("DIGITAL TWIN MODEL ACCURACY CALIBRATION", color = Paper, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("OBSERVED TELEMETRY DEPTH", color = MachineAluminium, fontSize = 9.sp)
                        Text("2.91 m", color = Paper, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("MODEL PREDICTED DEPTH", color = MachineAluminium, fontSize = 9.sp)
                        Text("2.88 m", color = JcbYellow, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("MODEL ERROR DELTA", color = MachineAluminium, fontSize = 9.sp)
                        Text("0.03 m (1.0%)", color = EngineeringGreen, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Machine Health & Predictive Maintenance Table
        Card(
            colors = CardDefaults.cardColors(containerColor = JcbSurfaceDark),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, JcbGraphite)
                .padding(12.dp)
        ) {
            Column {
                Text("PREDICTIVE MAINTENANCE & COMPONENT DIAGNOSTICS", color = JcbYellow, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(8.dp))

                healthSummary.diagnostics.forEach { diag ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(diag.name, color = Paper, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(diag.predictedIssue, color = WarmConcrete, fontSize = 8.sp)
                        }
                        Text("${diag.healthPct}%", color = if (diag.healthPct > 90) EngineeringGreen else SignalAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Divider(color = EngineeringGrey.copy(alpha = 0.2f))
                }
            }
        }
    }
}
