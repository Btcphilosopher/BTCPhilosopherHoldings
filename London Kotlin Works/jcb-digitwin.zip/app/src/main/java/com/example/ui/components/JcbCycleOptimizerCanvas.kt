package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.DiggingOptimizer
import com.example.domain.OptimizedStrategy
import com.example.ui.theme.*

@Composable
fun JcbCycleOptimizerCanvas(
    selectedStrategyCode: String = "PATH_B",
    onSelectStrategy: (OptimizedStrategy) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val candidateStrategies = DiggingOptimizer.generateCandidateStrategies()

    Column(
        modifier = modifier
            .background(JcbBlack)
            .border(1.dp, JcbGraphite)
            .padding(12.dp)
            .testTag("cycle_optimizer_canvas")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "DIG TRAJECTORY OPTIMISER & STRATEGY COMPARISON",
                color = JcbYellow,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "OBJECTIVE: MINIMISE FUEL + MAXIMISE FILL",
                color = MachineAluminium,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            candidateStrategies.forEach { strategy ->
                val isSelected = strategy.code == selectedStrategyCode

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) JcbGraphite else JcbSurfaceDark
                    ),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            if (isSelected) JcbYellow else EngineeringGrey.copy(alpha = 0.4f),
                            RoundedCornerShape(4.dp)
                        )
                        .clickable { onSelectStrategy(strategy) }
                        .padding(8.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .background(if (isSelected) JcbYellow else EngineeringGrey)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = strategy.name,
                                    color = Paper,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Text(
                                text = "${strategy.productivityM3PerHour} m³/hr",
                                color = JcbYellow,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Metric bars
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            MetricPill("DURATION", "${strategy.durationSec}s", WarmConcrete)
                            MetricPill("FUEL RATE", "${strategy.fuelLitersPerHour} L/hr", SignalAmber)
                            MetricPill("BUCKET FILL", "${strategy.bucketFillPct}%", EngineeringGreen)
                            MetricPill("PEAK BAR", "${strategy.hydraulicPeakBar.toInt()} bar", SiteBlue)
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = strategy.recommendationSummary,
                            color = MachineAluminium,
                            fontSize = 9.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricPill(label: String, value: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(text = "$label: ", color = EngineeringGrey, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(text = value, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}
