package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "machines")
data class MachineEntity(
    @PrimaryKey val id: String,
    val modelName: String,
    val serialNumber: String,
    val engineHours: Double,
    val fuelLevelPct: Int,
    val hydraulicTempC: Double,
    val hydraulicPressureBar: Double,
    val engineLoadPct: Int,
    val slewSpeedRpm: Double,
    val trackSpeedKmh: Double,
    val boomAngleDeg: Double,
    val dipperAngleDeg: Double,
    val bucketAngleDeg: Double,
    val slewAngleDeg: Double,
    val healthPct: Int,
    val activeAttachment: String
)

@Entity(tableName = "sites")
data class SiteEntity(
    @PrimaryKey val id: String,
    val siteName: String,
    val targetVolumeM3: Double,
    val excavatedVolumeM3: Double,
    val targetDepthM: Double,
    val currentDepthM: Double,
    val overdigM: Double,
    val underdigM: Double,
    val lengthM: Double,
    val widthM: Double,
    val status: String,
    val soilType: String
)

@Entity(tableName = "dig_cycles")
data class DigCycleEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val cycleNumber: Int,
    val timestamp: Long,
    val durationSeconds: Double,
    val volumeM3: Double,
    val bucketFillPct: Int,
    val fuelLiters: Double,
    val productivityM3Hr: Double,
    val swingAngleDeg: Double,
    val digDepthM: Double,
    val optimizationMode: String
)

@Entity(tableName = "subsurface_layers")
data class SubsurfaceLayerEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val layerName: String,
    val depthStartM: Double,
    val depthEndM: Double,
    val hardnessRating: Int,
    val colorHex: String
)
