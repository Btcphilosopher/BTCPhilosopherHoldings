package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val JcbDarkColorScheme = darkColorScheme(
    primary = JcbYellow,
    onPrimary = JcbBlack,
    primaryContainer = DeepYellow,
    onPrimaryContainer = JcbBlack,
    secondary = MachineAluminium,
    onSecondary = JcbBlack,
    secondaryContainer = JcbGraphite,
    onSecondaryContainer = WarmConcrete,
    tertiary = SiteBlue,
    onTertiary = Paper,
    background = JcbBlack,
    onBackground = Paper,
    surface = JcbSurfaceDark,
    onSurface = Paper,
    surfaceVariant = JcbGraphite,
    onSurfaceVariant = WarmConcrete,
    outline = EngineeringGrey,
    error = SignalRed,
    onError = Paper
)

private val JcbLightColorScheme = lightColorScheme(
    primary = DeepYellow,
    onPrimary = JcbBlack,
    primaryContainer = JcbYellow,
    onPrimaryContainer = JcbBlack,
    secondary = EngineeringGrey,
    onSecondary = Paper,
    secondaryContainer = WarmConcrete,
    onSecondaryContainer = JcbBlack,
    tertiary = SiteBlue,
    onTertiary = Paper,
    background = Paper,
    onBackground = JcbBlack,
    surface = WarmConcrete,
    onSurface = JcbBlack,
    surfaceVariant = MachineAluminium,
    onSurfaceVariant = JcbBlack,
    outline = EngineeringGrey,
    error = SignalRed,
    onError = Paper
)

@Composable
fun JcbDigitwinTheme(
    darkTheme: Boolean = true, // Default to industrial dark studio palette
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) JcbDarkColorScheme else JcbLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Alias for compatibility
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    JcbDigitwinTheme(darkTheme = darkTheme, content = content)
}
