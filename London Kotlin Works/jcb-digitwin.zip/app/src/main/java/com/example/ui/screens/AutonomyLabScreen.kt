package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.PerceptionEngine
import com.example.ui.StudioUiState
import com.example.ui.theme.*

@Composable
fun AutonomyLabScreen(
    uiState: StudioUiState
) {
    val safetyStatus = remember(uiState.detectedObjects) {
        PerceptionEngine.evaluateSafety(uiState.detectedObjects)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JcbBlack)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("autonomy_lab_screen")
    ) {
        Text(
            text = "AUTONOMY RESEARCH LAB & SAFETY ENVELOPES",
            color = JcbYellow,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(10.dp))

        // IntelliSense Pedestrian Intrusion Warning Banner
        if (safetyStatus.isPedestrianInWorkingEnvelope) {
            Card(
                colors = CardDefaults.cardColors(containerColor = SignalRed.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SignalRed)
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = SignalRed, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "INTELLISENSE SAFETY ALERT — PEDESTRIAN INTRUSION",
                            color = SignalRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = safetyStatus.warningMessage ?: "Pedestrian in swing radius. Auto-hold active.",
                            color = Paper,
                            fontSize = 10.sp
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        // Autonomous Digging Pipeline Loop Card
        Card(
            colors = CardDefaults.cardColors(containerColor = JcbSurfaceDark),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, JcbYellow)
                .padding(12.dp)
        ) {
            Column {
                Text("AUTONOMOUS CONTROL PIPELINE LOOP", color = JcbYellow, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    PipelineStep("SENSE", "Camera/LiDAR", true)
                    PipelineStep("UNDERSTAND", "Voxel World", true)
                    PipelineStep("PLAN", "IK Trajectory", true)
                    PipelineStep("SIMULATE", "Digital Twin", true)
                    PipelineStep("MEASURE", "Laser Profile", true)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Perception Detected Objects Table
        Card(
            colors = CardDefaults.cardColors(containerColor = JcbSurfaceDark),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, JcbGraphite)
                .padding(12.dp)
        ) {
            Column {
                Text("3D PERCEPTION SENSOR OBJECT DETECTION", color = Paper, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(8.dp))

                uiState.detectedObjects.forEach { obj ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(obj.id, color = JcbYellow, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(obj.type, color = Paper, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text("Dist: ${"%.1f".format(obj.distanceToExcavatorM)}m", color = WarmConcrete, fontSize = 10.sp)
                        Text("Conf: ${obj.confidencePct}%", color = EngineeringGreen, fontSize = 10.sp)
                    }
                    Divider(color = EngineeringGrey.copy(alpha = 0.2f))
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Truck Loading Coordination Twin
        Card(
            colors = CardDefaults.cardColors(containerColor = JcbSurfaceDark),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SiteBlue)
                .padding(12.dp)
        ) {
            Column {
                Text("TRUCK LOADOUT COORDINATION TWIN", color = SiteBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(6.dp))

                Text("TARGET DUMPER TRUCK: TRK-08 (24 Tonne Capacity)", color = Paper, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text("PASSES COMPLETED: 4 / 6 PASSES (14.2 tonnes loaded)", color = WarmConcrete, fontSize = 10.sp)

                Spacer(modifier = Modifier.height(6.dp))

                LinearProgressIndicator(
                    progress = { 4f / 6f },
                    color = SiteBlue,
                    trackColor = JcbGraphite,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                )
            }
        }
    }
}

@Composable
private fun PipelineStep(name: String, sub: String, isActive: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .background(if (isActive) JcbYellow else EngineeringGrey)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(name, color = Paper, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(sub, color = MachineAluminium, fontSize = 7.sp)
    }
}
