package com.example.domain

import kotlin.math.cos
import kotlin.math.sin

data class SoilLayerInfo(
    val name: String,
    val startDepthM: Float,
    val endDepthM: Float,
    val densityKgM3: Int,
    val moisturePct: Int,
    val hardnessIndex: Int,
    val colorHex: String,
    val excavability: String
)

data class BuriedService(
    val serviceType: String,
    val xM: Float,
    val yM: Float,
    val depthM: Float,
    val diameterMm: Int,
    val safetyBufferM: Float = 1.5f,
    val confidencePct: Int = 94
)

data class GroundVoxel(
    val gridX: Int,
    val gridY: Int,
    val currentElevationM: Float,
    val targetElevationM: Float,
    val initialElevationM: Float = 0.0f,
    val primaryMaterial: String
)

object GroundModel {
    val DefaultLayers = listOf(
        SoilLayerInfo("TOPSOIL", 0.0f, 0.5f, 1300, 18, 2, "#5D4037", "EASY"),
        SoilLayerInfo("CLAY", 0.5f, 1.8f, 1800, 24, 5, "#9E6132", "MEDIUM"),
        SoilLayerInfo("SAND", 1.8f, 2.6f, 1600, 12, 3, "#C49A48", "EASY"),
        SoilLayerInfo("GRAVEL", 2.6f, 3.1f, 2000, 10, 6, "#808588", "MEDIUM"),
        SoilLayerInfo("SOFT ROCK", 3.1f, 4.0f, 2400, 5, 8, "#42474A", "HARD"),
        SoilLayerInfo("HARD ROCK", 4.0f, 6.0f, 2700, 2, 10, "#2B2D2F", "REQUIRES BREAKER")
    )

    val DefaultServices = listOf(
        BuriedService("WATER PIPE 300mm", 12.0f, 4.0f, 1.8f, 300),
        BuriedService("HIGH VOLTAGE CABLE", 18.5f, 2.5f, 1.2f, 120, 2.0f, 98)
    )

    fun createDefaultVoxelGrid(cols: Int = 16, rows: Int = 12, targetDepth: Float = 3.2f): List<GroundVoxel> {
        val list = mutableListOf<GroundVoxel>()
        for (y in 0 until rows) {
            for (x in 0 until cols) {
                val initialZ = (sin(x * 0.3) * 0.15 + cos(y * 0.4) * 0.10).toFloat()
                val isExcavationTarget = x in 3..12 && y in 2..9
                val targetZ = if (isExcavationTarget) -targetDepth else initialZ

                val currentZ = if (isExcavationTarget) {
                    val progressRatio = if (x < 8) 0.9f else 0.4f
                    initialZ - (targetDepth - initialZ) * progressRatio
                } else initialZ

                val layer = when {
                    currentZ >= -0.5f -> "TOPSOIL"
                    currentZ >= -1.8f -> "CLAY"
                    currentZ >= -2.6f -> "SAND"
                    else -> "SOFT ROCK"
                }

                list.add(GroundVoxel(x, y, currentZ, targetZ, initialZ, layer))
            }
        }
        return list
    }
}
