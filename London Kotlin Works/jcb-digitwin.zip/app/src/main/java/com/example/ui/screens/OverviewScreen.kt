package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.StudioTab
import com.example.ui.StudioUiState
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun OverviewScreen(
    uiState: StudioUiState,
    onSelectTab: (StudioTab) -> Unit,
    onToggleSim: () -> Unit,
    onSelectComponent: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JcbBlack)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("overview_screen")
    ) {
        // Top 3D Digital Twin Hero Canvas
        Jcb3dExcavatorCanvas(
            pose = uiState.simState.activePose,
            selectedComponent = uiState.selectedComponent,
            onSelectComponent = onSelectComponent,
            bucketFillPct = uiState.simState.currentBucketFillPct,
            hydraulicPressureBar = 312f,
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Main Studio Metrics Grid (Excavation Progress + Live Telemetry)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Excavation Progress Card
            Card(
                colors = CardDefaults.cardColors(containerColor = JcbSurfaceDark),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, JcbGraphite)
                    .padding(12.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("EXCAVATION PROGRESS", color = EngineeringGrey, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text("67% COMPLETE", color = JcbYellow, fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text("1,904 / 2,840 m³", color = Paper, fontSize = 20.sp, fontWeight = FontWeight.Black)
                    Text("REMAINING: 936 m³", color = WarmConcrete, fontSize = 10.sp)

                    Spacer(modifier = Modifier.height(8.dp))

                    LinearProgressIndicator(
                        progress = { 0.67f },
                        color = JcbYellow,
                        trackColor = JcbGraphite,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("TARGET DEPTH: 3.20m", color = MachineAluminium, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text("CURRENT: 2.91m", color = JcbYellow, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Live Machine Telemetry Card
            Card(
                colors = CardDefaults.cardColors(containerColor = JcbSurfaceDark),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, JcbGraphite)
                    .padding(12.dp)
            ) {
                Column {
                    Text("MACHINE STATUS (${uiState.simState.activeMachineModel})", color = EngineeringGrey, fontSize = 10.sp, fontWeight = FontWeight.Bold)

                    Spacer(modifier = Modifier.height(6.dp))

                    TelemetryRow("HYDRAULICS", "312 bar / 68°C", JcbYellow)
                    TelemetryRow("ENGINE LOAD", "64%", EngineeringGreen)
                    TelemetryRow("FUEL LEVEL", "78% (18.2 L/hr)", SiteBlue)
                    TelemetryRow("MACHINE HEALTH", "94% OPTIMAL", JcbYellow)
                    TelemetryRow("ATTACHMENT", uiState.simState.activeAttachment, MachineAluminium)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Signature Subsurface Geotechnical Slice View
        JcbSubsurfaceSliceView(
            currentDepthM = 2.91f,
            targetDepthM = 3.20f,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Live Cycle Bar
        Surface(
            color = JcbGraphite,
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, JcbYellow.copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("ACTIVE DIG CYCLE #184", color = JcbYellow, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("32.4 SEC DURATION • 1.68 m³ BUCKET • 18.6 m³/HR", color = Paper, fontSize = 10.sp)
                }

                Button(
                    onClick = { onSelectTab(StudioTab.EXCAVATION) },
                    colors = ButtonDefaults.buttonColors(containerColor = JcbYellow, contentColor = JcbBlack),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Text("VIEW CYCLE OPTIMISER", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Quick Navigation Studio Hub
        Text("STUDIO MODULES", color = EngineeringGrey, fontSize = 10.sp, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StudioModuleCard("MACHINE TWIN", "3D & Kinematics", Icons.Default.Build, Modifier.weight(1f)) { onSelectTab(StudioTab.MACHINE_TWIN) }
            StudioModuleCard("SITE & GROUND", "3D Voxels & Subsurface", Icons.Default.Terrain, Modifier.weight(1f)) { onSelectTab(StudioTab.SITE_GROUND) }
            StudioModuleCard("DIG PLANNER", "Target Cut & Volume", Icons.Default.Architecture, Modifier.weight(1f)) { onSelectTab(StudioTab.DIG_PLAN) }
            StudioModuleCard("AUTONOMY LAB", "Sense & Safety Envelopes", Icons.Default.SmartToy, Modifier.weight(1f)) { onSelectTab(StudioTab.AUTONOMY) }
        }
    }
}

@Composable
private fun TelemetryRow(label: String, value: String, color: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = WarmConcrete, fontSize = 10.sp)
        Text(text = value, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun StudioModuleCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = JcbSurfaceDark),
        shape = RoundedCornerShape(4.dp),
        modifier = modifier
            .border(1.dp, EngineeringGrey.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(8.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = title, tint = JcbYellow, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(title, color = Paper, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = MachineAluminium, fontSize = 8.sp)
        }
    }
}
