package com.example.data

import com.example.domain.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class SimulationState(
    val isRunning: Boolean = true,
    val simulationSpeed: Float = 1.0f, // 1x, 5x, 10x, 50x
    val activeScenarioName: String = "SIGNATURE DEMO — FOUNDATION EXCAVATION",
    val activeMachineModel: String = "JCB 370X",
    val activeAttachment: String = "HD 1.8m³ Rock Bucket",
    val activeOptimizationMode: String = "BALANCED",
    val weatherCondition: String = "DRY / GROUND FIRM",
    val currentCycleTimeSec: Float = 18.4f,
    val currentBucketFillPct: Int = 92,
    val currentProductivityM3Hr: Float = 18.4f,
    val currentFuelLitersHr: Float = 18.2f,
    val currentCycleNumber: Int = 184,
    val activePose: MachinePose = MachinePose(42f, -65f, -25f, 15f),
    val safetyStatus: SafetyStatus = SafetyStatus(
        isPedestrianInWorkingEnvelope = false,
        isNearUtilityPipe = false,
        closestPedestrianDistanceM = 14.2f,
        warningMessage = null,
        isSimulationPausedForSafety = false
    ),
    val observedVsModelErrorM: Float = 0.03f
)

class DigitalTwinRepository(
    private val dao: DigitwinDao,
    private val externalScope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) {
    private val _simState = MutableStateFlow(SimulationState())
    val simState: StateFlow<SimulationState> = _simState.asStateFlow()

    private val _voxels = MutableStateFlow<List<GroundVoxel>>(GroundModel.createDefaultVoxelGrid())
    val voxels: StateFlow<List<GroundVoxel>> = _voxels.asStateFlow()

    private val _objects = MutableStateFlow<List<DetectedObject3D>>(PerceptionEngine.generateDefaultObjects())
    val detectedObjects: StateFlow<List<DetectedObject3D>> = _objects.asStateFlow()

    val activeMachine: Flow<MachineEntity?> = dao.getMachineFlow("JCB-370X-01")
    val activeSite: Flow<SiteEntity?> = dao.getSiteFlow("SITE-04")
    val recentCycles: Flow<List<DigCycleEntity>> = dao.getRecentCyclesFlow()
    val subsurfaceLayers: Flow<List<SubsurfaceLayerEntity>> = dao.getSubsurfaceLayersFlow()

    init {
        seedInitialData()
    }

    private fun seedInitialData() {
        externalScope.launch {
            dao.insertOrUpdateMachine(
                MachineEntity(
                    id = "JCB-370X-01",
                    modelName = "JCB 370X",
                    serialNumber = "JCB370X-2026-8842",
                    engineHours = 1482.5,
                    fuelLevelPct = 78,
                    hydraulicTempC = 68.4,
                    hydraulicPressureBar = 312.0,
                    engineLoadPct = 64,
                    slewSpeedRpm = 10.2,
                    trackSpeedKmh = 3.4,
                    boomAngleDeg = 42.0,
                    dipperAngleDeg = -65.0,
                    bucketAngleDeg = -25.0,
                    slewAngleDeg = 15.0,
                    healthPct = 94,
                    activeAttachment = "HD 1.8m³ Rock Bucket"
                )
            )

            dao.insertOrUpdateSite(
                SiteEntity(
                    id = "SITE-04",
                    siteName = "HS2 Section 4 — Foundation & Utility Trench",
                    targetVolumeM3 = 2840.0,
                    excavatedVolumeM3 = 1904.0,
                    targetDepthM = 3.20,
                    currentDepthM = 2.91,
                    overdigM = 0.04,
                    underdigM = 0.25,
                    lengthM = 24.0,
                    widthM = 8.0,
                    status = "ACTIVE — 67% COMPLETE",
                    soilType = "Clay over Soft Rock"
                )
            )

            val sampleCycles = listOf(
                DigCycleEntity(cycleNumber = 184, timestamp = System.currentTimeMillis() - 30000, durationSeconds = 32.4, volumeM3 = 1.68, bucketFillPct = 93, fuelLiters = 0.16, productivityM3Hr = 18.6, swingAngleDeg = 65.0, digDepthM = 2.91, optimizationMode = "BALANCED"),
                DigCycleEntity(cycleNumber = 183, timestamp = System.currentTimeMillis() - 65000, durationSeconds = 31.0, volumeM3 = 1.72, bucketFillPct = 95, fuelLiters = 0.15, productivityM3Hr = 19.2, swingAngleDeg = 60.0, digDepthM = 2.88, optimizationMode = "BALANCED"),
                DigCycleEntity(cycleNumber = 182, timestamp = System.currentTimeMillis() - 100000, durationSeconds = 34.2, volumeM3 = 1.62, bucketFillPct = 89, fuelLiters = 0.18, productivityM3Hr = 17.1, swingAngleDeg = 75.0, digDepthM = 2.85, optimizationMode = "BALANCED"),
                DigCycleEntity(cycleNumber = 181, timestamp = System.currentTimeMillis() - 135000, durationSeconds = 29.8, volumeM3 = 1.75, bucketFillPct = 97, fuelLiters = 0.14, productivityM3Hr = 20.1, swingAngleDeg = 55.0, digDepthM = 2.82, optimizationMode = "BALANCED")
            )
            sampleCycles.forEach { dao.insertCycle(it) }

            val layers = GroundModel.DefaultLayers.mapIndexed { idx, soil ->
                SubsurfaceLayerEntity(
                    layerName = soil.name,
                    depthStartM = soil.startDepthM.toDouble(),
                    depthEndM = soil.endDepthM.toDouble(),
                    hardnessRating = soil.hardnessIndex,
                    colorHex = soil.colorHex
                )
            }
            dao.insertLayers(layers)
        }
    }

    fun toggleSimulation() {
        _simState.update { it.copy(isRunning = !it.isRunning) }
    }

    fun setSimulationSpeed(speed: Float) {
        _simState.update { it.copy(simulationSpeed = speed) }
    }

    fun updateMachinePose(pose: MachinePose) {
        _simState.update { it.copy(activePose = pose) }
    }

    fun setMachineModel(model: String) {
        _simState.update { it.copy(activeMachineModel = model) }
    }

    fun setAttachment(attachment: String) {
        _simState.update { it.copy(activeAttachment = attachment) }
    }

    fun setOptimizationMode(mode: String) {
        _simState.update { it.copy(activeOptimizationMode = mode) }
    }

    fun setScenario(scenario: String) {
        _simState.update { it.copy(activeScenarioName = scenario) }
    }

    fun simulateBucketDigCycleStep(stepProgress: Float) {
        // Animate joint angles through dig cycle
        val boom = 25f + 30f * kotlin.math.sin(stepProgress * kotlin.math.PI.toFloat())
        val dipper = -80f + 40f * kotlin.math.cos(stepProgress * kotlin.math.PI.toFloat())
        val bucket = -50f + 80f * stepProgress
        val slew = 15f + 45f * stepProgress

        _simState.update {
            it.copy(
                activePose = MachinePose(boom, dipper, bucket, slew),
                currentBucketFillPct = (stepProgress * 95).toInt().coerceIn(0, 98)
            )
        }
    }
}
