package com.example.domain

data class TrajectoryPoint(
    val stepName: String, // "POSITION", "LOWER", "CUT", "FILL", "LIFT", "SWING", "DUMP", "RETURN"
    val timeSec: Float,
    val boomDeg: Float,
    val dipperDeg: Float,
    val bucketDeg: Float,
    val slewDeg: Float,
    val bucketFillPct: Int,
    val hydraulicPressureBar: Float
)

data class OptimizedStrategy(
    val name: String,
    val code: String, // "PATH_A", "PATH_B", "PATH_C", "PATH_D"
    val durationSec: Float,
    val fuelLitersPerHour: Float,
    val bucketFillPct: Int,
    val productivityM3PerHour: Float,
    val hydraulicPeakBar: Float,
    val machineStressRating: String, // "LOW", "MODERATE", "HIGH"
    val trajectory: List<TrajectoryPoint>,
    val recommendationSummary: String
)

object DiggingOptimizer {

    fun generateCandidateStrategies(): List<OptimizedStrategy> {
        return listOf(
            OptimizedStrategy(
                name = "PATH A — SHORT CYCLE",
                code = "PATH_A",
                durationSec = 26.2f,
                fuelLitersPerHour = 22.4f,
                bucketFillPct = 86,
                productivityM3PerHour = 18.6f,
                hydraulicPeakBar = 330f,
                machineStressRating = "HIGH",
                trajectory = createSampleTrajectory(26.2f, 86, 330f, 90f),
                recommendationSummary = "Best for tight deadlines when truck queue is waiting. Higher fuel burn."
            ),
            OptimizedStrategy(
                name = "PATH B — LOW ENERGY / MIN FUEL",
                code = "PATH_B",
                durationSec = 34.0f,
                fuelLitersPerHour = 16.2f,
                bucketFillPct = 92,
                productivityM3PerHour = 16.2f,
                hydraulicPeakBar = 240f,
                machineStressRating = "LOW",
                trajectory = createSampleTrajectory(34.0f, 92, 240f, 85f),
                recommendationSummary = "Saves 28% fuel per m³. Smooth hydraulic profile reduces pump wear."
            ),
            OptimizedStrategy(
                name = "PATH C — MINIMUM SWING ANGLE",
                code = "PATH_C",
                durationSec = 28.5f,
                fuelLitersPerHour = 18.8f,
                bucketFillPct = 89,
                productivityM3PerHour = 17.5f,
                hydraulicPeakBar = 270f,
                machineStressRating = "LOW",
                trajectory = createSampleTrajectory(28.5f, 89, 270f, 45f),
                recommendationSummary = "Re-orientates truck loading position to 45° slew. Reduces cycle time."
            ),
            OptimizedStrategy(
                name = "PATH D — MAXIMUM BUCKET FILL",
                code = "PATH_D",
                durationSec = 31.0f,
                fuelLitersPerHour = 19.5f,
                bucketFillPct = 98,
                productivityM3PerHour = 19.1f,
                hydraulicPeakBar = 290f,
                machineStressRating = "MODERATE",
                trajectory = createSampleTrajectory(31.0f, 98, 290f, 80f),
                recommendationSummary = "Deep curved penetration path maximizes bucket heap volume in cohesive clay."
            )
        )
    }

    private fun createSampleTrajectory(
        totalTime: Float,
        fillPct: Int,
        peakPressureBar: Float,
        maxSlew: Float
    ): List<TrajectoryPoint> {
        val dt = totalTime / 7f
        return listOf(
            TrajectoryPoint("POSITION", 0.0f * dt, 45f, -60f, -20f, 0f, 0, 120f),
            TrajectoryPoint("LOWER", 1.0f * dt, 25f, -80f, -40f, 0f, 5, 180f),
            TrajectoryPoint("CUT", 2.0f * dt, 15f, -95f, -60f, 0f, 35, peakPressureBar),
            TrajectoryPoint("FILL", 3.0f * dt, 20f, -70f, 15f, 0f, fillPct, peakPressureBar * 0.9f),
            TrajectoryPoint("LIFT", 4.0f * dt, 55f, -40f, 30f, 0f, fillPct, 220f),
            TrajectoryPoint("SWING", 5.0f * dt, 50f, -30f, 30f, maxSlew, fillPct, 190f),
            TrajectoryPoint("DUMP", 6.0f * dt, 45f, -25f, -70f, maxSlew, 0, 150f),
            TrajectoryPoint("RETURN", 7.0f * dt, 45f, -60f, -20f, 0f, 0, 130f)
        )
    }
}
