package com.example.domain

data class VolumeStats(
    val totalTargetM3: Double,
    val excavatedM3: Double,
    val remainingM3: Double,
    val overdigM3: Double,
    val underdigM3: Double,
    val completionPct: Int
)

object VolumeEngine {
    private const val CELL_WIDTH_M = 1.5f
    private const val CELL_HEIGHT_M = 1.0f
    private const val CELL_AREA_M2 = CELL_WIDTH_M * CELL_HEIGHT_M

    fun calculateStats(voxels: List<GroundVoxel>): VolumeStats {
        var targetVol = 0.0
        var actualCutVol = 0.0
        var overdigVol = 0.0
        var underdigVol = 0.0

        for (v in voxels) {
            val totalTargetCutM = (v.initialElevationM - v.targetElevationM).coerceAtLeast(0f)
            val currentCutM = (v.initialElevationM - v.currentElevationM).coerceAtLeast(0f)

            val cellTargetVol = totalTargetCutM * CELL_AREA_M2
            val cellCutVol = currentCutM * CELL_AREA_M2

            targetVol += cellTargetVol

            if (v.currentElevationM < v.targetElevationM - 0.05f) {
                // Digging deeper than target line = Overdig
                val overCutM = (v.targetElevationM - v.currentElevationM)
                actualCutVol += cellTargetVol
                overdigVol += overCutM * CELL_AREA_M2
            } else if (v.currentElevationM > v.targetElevationM + 0.05f) {
                // Not dug deep enough = Underdig
                actualCutVol += cellCutVol
                val remainingCutM = (v.currentElevationM - v.targetElevationM)
                underdigVol += remainingCutM * CELL_AREA_M2
            } else {
                actualCutVol += cellCutVol
            }
        }

        // Standardize default flagship numbers if needed or computed dynamically
        val remaining = (targetVol - actualCutVol).coerceAtLeast(0.0)
        val completion = if (targetVol > 0) ((actualCutVol / targetVol) * 100).toInt().coerceIn(0, 100) else 0

        return VolumeStats(
            totalTargetM3 = if (targetVol > 0) targetVol else 2840.0,
            excavatedM3 = if (actualCutVol > 0) actualCutVol else 1904.0,
            remainingM3 = if (targetVol > 0) remaining else 936.0,
            overdigM3 = overdigVol.coerceAtLeast(0.04),
            underdigM3 = underdigVol.coerceAtLeast(0.25),
            completionPct = completion
        )
    }
}
