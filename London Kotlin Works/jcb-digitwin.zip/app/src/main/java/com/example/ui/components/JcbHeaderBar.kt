package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun JcbHeaderBar(
    activeSiteName: String = "SITE / 04 / ACTIVE",
    activeMachineModel: String = "JCB 370X",
    isSimulating: Boolean = true,
    simulationSpeed: Float = 1.0f,
    onToggleSimulation: () -> Unit = {},
    onSelectSpeed: (Float) -> Unit = {},
    onOpenAiClick: () -> Unit = {}
) {
    Surface(
        color = JcbBlack,
        tonalElevation = 4.dp,
        modifier = Modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = EngineeringGrey.copy(alpha = 0.4f))
            .testTag("jcb_header_bar")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(JcbYellow, RoundedCornerShape(2.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "JCB",
                            color = JcbBlack,
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            letterSpacing = 1.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Column {
                        Text(
                            text = "DIGITWIN STUDIO",
                            color = Paper,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            letterSpacing = 1.2.sp
                        )
                        Text(
                            text = "EXCAVATION INTELLIGENCE • EVERY CYCLE COUNTS",
                            color = MachineAluminium,
                            fontWeight = FontWeight.Medium,
                            fontSize = 9.sp,
                            letterSpacing = 0.8.sp
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = JcbGraphite,
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .clickable { onOpenAiClick() }
                            .border(width = 1.dp, color = JcbYellow.copy(alpha = 0.6f), shape = RoundedCornerShape(4.dp))
                            .testTag("gemini_ai_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Gemini AI Intelligence",
                                tint = JcbYellow,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "GEMINI 3.6 AI",
                                color = JcbYellow,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Box(
                        modifier = Modifier
                            .background(JcbGraphite, RoundedCornerShape(4.dp))
                            .border(width = 1.dp, color = EngineeringGrey, shape = RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = activeSiteName,
                            color = WarmConcrete,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(EngineeringGreen.copy(alpha = 0.2f), RoundedCornerShape(2.dp))
                        .border(width = 1.dp, color = EngineeringGreen.copy(alpha = 0.6f), shape = RoundedCornerShape(2.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(EngineeringGreen, RoundedCornerShape(3.dp))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "SAFETY MODE: SIMULATION / READ-ONLY TELEMETRY",
                        color = Paper,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onToggleSimulation,
                        modifier = Modifier
                            .size(28.dp)
                            .testTag("toggle_simulation_button")
                    ) {
                        Icon(
                            imageVector = if (isSimulating) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Toggle Simulation",
                            tint = JcbYellow,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    listOf(1f, 5f, 10f, 50f).forEach { speed ->
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 2.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(if (simulationSpeed == speed) JcbYellow else JcbGraphite)
                                .clickable { onSelectSpeed(speed) }
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "${speed.toInt()}x",
                                color = if (simulationSpeed == speed) JcbBlack else WarmConcrete,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
