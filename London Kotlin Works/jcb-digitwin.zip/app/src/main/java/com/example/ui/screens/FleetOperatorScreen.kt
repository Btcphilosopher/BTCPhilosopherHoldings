package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.StudioUiState
import com.example.ui.theme.*

@Composable
fun FleetOperatorScreen(
    uiState: StudioUiState,
    onSelectMachineModel: (String) -> Unit,
    onSelectAttachment: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JcbBlack)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("fleet_operator_screen")
    ) {
        Text(
            text = "FLEET MANAGEMENT & ATTACHMENT DIGITAL TWIN",
            color = JcbYellow,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(10.dp))

        // JCB X-Series Fleet Machine Selector
        Text("JCB X-SERIES EXCAVATOR FLEET PROFILES", color = EngineeringGrey, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("JCB 145X", "JCB 220X", "JCB 245X", "JCB 370X", "JCB 420X", "JCB 520X").forEach { model ->
                FilterChip(
                    selected = uiState.simState.activeMachineModel == model,
                    onClick = { onSelectMachineModel(model) },
                    label = { Text(model, fontSize = 10.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Attachment Digital Twin Switcher
        Text("ATTACHMENT DIGITAL TWIN SELECTION", color = EngineeringGrey, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("HD 1.8m³ Rock Bucket", "HM380 Hydraulic Breaker", "Heavy Grapple", "Hydraulic Thumb", "Auger 600mm").forEach { att ->
                FilterChip(
                    selected = uiState.simState.activeAttachment == att,
                    onClick = { onSelectAttachment(att) },
                    label = { Text(att, fontSize = 9.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Active Machine Profile Card
        Card(
            colors = CardDefaults.cardColors(containerColor = JcbSurfaceDark),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, JcbYellow)
                .padding(12.dp)
        ) {
            Column {
                Text(
                    text = "ACTIVE PROFILE: ${uiState.simState.activeMachineModel}",
                    color = JcbYellow,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("OPERATING WEIGHT: 38,200 kg", color = Paper, fontSize = 10.sp)
                    Text("ENGINE POWER: 240 kW (Stage V)", color = Paper, fontSize = 10.sp)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("ATTACHMENT: ${uiState.simState.activeAttachment}", color = WarmConcrete, fontSize = 10.sp)
                    Text("SERIAL: JCB370X-2026-8842", color = WarmConcrete, fontSize = 10.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Operator Skill & Training Scenarios Card
        Card(
            colors = CardDefaults.cardColors(containerColor = JcbSurfaceDark),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, JcbGraphite)
                .padding(12.dp)
        ) {
            Column {
                Text("OPERATOR PROFILE & TRAINING SCENARIOS", color = Paper, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(6.dp))

                Text("OPERATOR: James Davies (Senior Machine Specialist)", color = WarmConcrete, fontSize = 10.sp)
                Text("EXCAVATION ACCURACY SCORE: 98.2%", color = EngineeringGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text("FUEL EFFICIENCY RATING: Grade A+", color = JcbYellow, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
