package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.DiggingOptimizer
import com.example.ui.StudioUiState
import com.example.ui.components.JcbCycleOptimizerCanvas
import com.example.ui.theme.*

@Composable
fun ExcavatorCycleScreen(
    uiState: StudioUiState,
    onSelectStrategy: (String) -> Unit
) {
    var isCycleSimulating by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JcbBlack)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("excavator_cycle_screen")
    ) {
        Text(
            text = "DIGGING CYCLE SIMULATOR & BUCKET TWIN",
            color = JcbYellow,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Active Cycle Step Animation Banner
        Card(
            colors = CardDefaults.cardColors(containerColor = JcbSurfaceDark),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, JcbYellow)
                .padding(12.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("ACTIVE DIG CYCLE #184", color = JcbYellow, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("32.4 SEC DURATION", color = Paper, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Cycle steps pill sequence
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    listOf("POSITION", "LOWER", "CUT", "FILL", "LIFT", "SWING", "DUMP", "RETURN").forEachIndexed { idx, step ->
                        val isActive = idx == 3 // Currently in FILL step
                        Box(
                            modifier = Modifier
                                .background(if (isActive) JcbYellow else JcbGraphite, RoundedCornerShape(2.dp))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = step,
                                color = if (isActive) JcbBlack else WarmConcrete,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Bucket Twin Capacity Card
        Card(
            colors = CardDefaults.cardColors(containerColor = JcbSurfaceDark),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, JcbGraphite)
                .padding(12.dp)
        ) {
            Column {
                Text("BUCKET DIGITAL TWIN SIMULATION", color = Paper, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("CAPACITY: 1.80 m³", color = WarmConcrete, fontSize = 10.sp)
                    Text("FILL LEVEL: ${uiState.simState.currentBucketFillPct}%", color = JcbYellow, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("MATERIAL MASS: 3,120 kg", color = Paper, fontSize = 10.sp)
                }

                Spacer(modifier = Modifier.height(6.dp))

                LinearProgressIndicator(
                    progress = { uiState.simState.currentBucketFillPct / 100f },
                    color = JcbYellow,
                    trackColor = JcbGraphite,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Strategy Optimizer Canvas Comparison
        JcbCycleOptimizerCanvas(
            selectedStrategyCode = uiState.selectedStrategyCode,
            onSelectStrategy = { onSelectStrategy(it.code) },
            modifier = Modifier.fillMaxWidth()
        )
    }
}
