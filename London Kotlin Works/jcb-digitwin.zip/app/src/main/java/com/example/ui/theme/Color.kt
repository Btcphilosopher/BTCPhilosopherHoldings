package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// JCB Industrial Color Palette
val JcbBlack = Color(0xFF17191A)
val JcbGraphite = Color(0xFF292D2E)
val JcbSurfaceDark = Color(0xFF202324)
val EngineeringGrey = Color(0xFF646B6B)
val MachineAluminium = Color(0xFFAEB2AF)
val WarmConcrete = Color(0xFFD7D3C9)
val Paper = Color(0xFFF1EEE6)

val JcbYellow = Color(0xFFF2C300)
val DeepYellow = Color(0xFFC89D00)

val SiteBlue = Color(0xFF365B6B)
val EngineeringGreen = Color(0xFF4F654E)

val SignalRed = Color(0xFFA4483E)
val SignalAmber = Color(0xFFC18B32)

// Ground & Subsurface Soil Layers
val EarthTopsoil = Color(0xFF5D4037)
val EarthClay = Color(0xFF9E6132)
val EarthSand = Color(0xFFC49A48)
val EarthGravel = Color(0xFF808588)
val EarthRock = Color(0xFF42474A)
val EarthFill = Color(0xFF6E6356)
