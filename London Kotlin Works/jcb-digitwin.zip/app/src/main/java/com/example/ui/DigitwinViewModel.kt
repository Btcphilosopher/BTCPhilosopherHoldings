package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.domain.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class StudioTab(val title: String) {
    OVERVIEW("OVERVIEW"),
    MACHINE_TWIN("MACHINE TWIN"),
    SITE_GROUND("SITE & GROUND"),
    DIG_PLAN("DIG PLAN"),
    EXCAVATION("EXCAVATION"),
    AUTONOMY("AUTONOMY LAB"),
    REPLAY("REPLAY & ANALYTICS"),
    FLEET("FLEET & OPERATOR"),
    GEMINI_AI("GEMINI AI")
}

data class StudioUiState(
    val activeTab: StudioTab = StudioTab.OVERVIEW,
    val simState: SimulationState = SimulationState(),
    val siteInfo: SiteEntity? = null,
    val machineInfo: MachineEntity? = null,
    val cyclesHistory: List<DigCycleEntity> = emptyList(),
    val subsurfaceLayers: List<SubsurfaceLayerEntity> = emptyList(),
    val voxelsGrid: List<GroundVoxel> = emptyList(),
    val detectedObjects: List<DetectedObject3D> = emptyList(),
    val selectedComponent: String = "BUCKET",
    val selectedStrategyCode: String = "PATH_B",
    val geminiAnalysisText: String? = null,
    val isGeminiLoading: Boolean = false
)

class DigitwinViewModel(
    private val repository: DigitalTwinRepository
) : ViewModel() {

    private val _activeTab = MutableStateFlow(StudioTab.OVERVIEW)
    private val _selectedComponent = MutableStateFlow("BUCKET")
    private val _selectedStrategyCode = MutableStateFlow("PATH_B")
    private val _geminiText = MutableStateFlow<String?>(null)
    private val _isGeminiLoading = MutableStateFlow(false)

    // Combine local UI selections
    private val _localSelectionFlow = combine(
        _activeTab,
        _selectedComponent,
        _selectedStrategyCode,
        _geminiText,
        _isGeminiLoading
    ) { tab, comp, stratCode, gText, isLoading ->
        LocalSelection(tab, comp, stratCode, gText, isLoading)
    }

    // Combine repository state
    private val _repoStateFlow = combine(
        repository.simState,
        repository.activeSite,
        repository.activeMachine,
        repository.recentCycles,
        repository.subsurfaceLayers
    ) { sim, site, machine, cycles, layers ->
        RepoState(sim, site, machine, cycles, layers)
    }

    val uiState: StateFlow<StudioUiState> = combine(
        _localSelectionFlow,
        _repoStateFlow,
        repository.voxels,
        repository.detectedObjects
    ) { local, repo, voxels, objects ->
        StudioUiState(
            activeTab = local.tab,
            simState = repo.sim,
            siteInfo = repo.site,
            machineInfo = repo.machine,
            cyclesHistory = repo.cycles,
            subsurfaceLayers = repo.layers,
            voxelsGrid = voxels,
            detectedObjects = objects,
            selectedComponent = local.comp,
            selectedStrategyCode = local.stratCode,
            geminiAnalysisText = local.gText,
            isGeminiLoading = local.isLoading
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = StudioUiState()
    )

    fun selectTab(tab: StudioTab) {
        _activeTab.value = tab
    }

    fun toggleSimulation() {
        repository.toggleSimulation()
    }

    fun setSimulationSpeed(speed: Float) {
        repository.setSimulationSpeed(speed)
    }

    fun selectComponent(comp: String) {
        _selectedComponent.value = comp
    }

    fun selectStrategy(code: String) {
        _selectedStrategyCode.value = code
        repository.setOptimizationMode(code)
    }

    fun selectMachineModel(model: String) {
        repository.setMachineModel(model)
    }

    fun selectAttachment(attachment: String) {
        repository.setAttachment(attachment)
    }

    fun runGeminiAiAnalysis() {
        viewModelScope.launch {
            _isGeminiLoading.value = true
            val currentState = uiState.value
            val analysis = GeminiExcavationAi.analyzeExcavationSite(
                machineModel = currentState.simState.activeMachineModel,
                siteName = currentState.siteInfo?.siteName ?: "HS2 Section 4",
                soilType = currentState.siteInfo?.soilType ?: "Clay over Soft Rock",
                targetVolumeM3 = currentState.siteInfo?.targetVolumeM3 ?: 2840.0,
                currentDepthM = currentState.siteInfo?.currentDepthM ?: 2.91,
                targetDepthM = currentState.siteInfo?.targetDepthM ?: 3.20,
                activeAttachment = currentState.simState.activeAttachment
            )
            _geminiText.value = analysis
            _isGeminiLoading.value = false
        }
    }

    private data class LocalSelection(
        val tab: StudioTab,
        val comp: String,
        val stratCode: String,
        val gText: String?,
        val isLoading: Boolean
    )

    private data class RepoState(
        val sim: SimulationState,
        val site: SiteEntity?,
        val machine: MachineEntity?,
        val cycles: List<DigCycleEntity>,
        val layers: List<SubsurfaceLayerEntity>
    )
}
