package com.example.domain

data class ComponentDiagnostic(
    val name: String, // "MAIN HYDRAULIC PUMP", "SLEW BEARING", "ENGINE TURBO", "BOOM CYLINDER SEALS", "TRACK UNDERCARRIAGE", "BUCKET TEETH"
    val healthPct: Int,
    val status: String, // "OPTIMAL", "ATTENTION", "SERVICE REQUIRED"
    val hoursRemaining: Int,
    val primaryMetric: String,
    val predictedIssue: String
)

data class MachineHealthSummary(
    val overallHealthPct: Int,
    val nextServiceHours: Int,
    val hydraulicPumpPressureTrendBar: Float,
    val oilConditionPct: Int,
    val filterLifePct: Int,
    val diagnostics: List<ComponentDiagnostic>
)

object MachineHealthEngine {
    fun generateHealthSummary(engineHours: Double = 1482.0): MachineHealthSummary {
        val diagnostics = listOf(
            ComponentDiagnostic(
                name = "MAIN HYDRAULIC PUMP",
                healthPct = 92,
                status = "OPTIMAL",
                hoursRemaining = 518,
                primaryMetric = "348 bar / 0.82 l/min slip",
                predictedIssue = "Hydraulic pressure trend stable. Normal cavitation limits."
            ),
            ComponentDiagnostic(
                name = "SLEW BEARING & GEARBOX",
                healthPct = 96,
                status = "OPTIMAL",
                hoursRemaining = 820,
                primaryMetric = "0.04 mm backlash",
                predictedIssue = "Zero gear slip detected during 90° load swing."
            ),
            ComponentDiagnostic(
                name = "ENGINE & COOLING",
                healthPct = 94,
                status = "OPTIMAL",
                hoursRemaining = 184,
                primaryMetric = "88°C coolant / 2.4 bar turbo",
                predictedIssue = "DPF soot filter loading at 68%. Regenerate in 45 hrs."
            ),
            ComponentDiagnostic(
                name = "BOOM & DIPPER SEALS",
                healthPct = 88,
                status = "ATTENTION",
                hoursRemaining = 120,
                primaryMetric = "1.2 bar drift/min",
                predictedIssue = "Minor pressure drift on boom cylinder head seal during holding."
            ),
            ComponentDiagnostic(
                name = "TRACK UNDERCARRIAGE",
                healthPct = 91,
                status = "OPTIMAL",
                hoursRemaining = 650,
                primaryMetric = "18mm chain stretch",
                predictedIssue = "Sprocket tooth wear within factory limits."
            ),
            ComponentDiagnostic(
                name = "BUCKET CUTTING EDGE & TEETH",
                healthPct = 82,
                status = "ATTENTION",
                hoursRemaining = 95,
                primaryMetric = "14mm tip wear",
                predictedIssue = "Replace center teeth prior to hard rock excavation phase."
            )
        )

        return MachineHealthSummary(
            overallHealthPct = 91,
            nextServiceHours = 184,
            hydraulicPumpPressureTrendBar = 348.0f,
            oilConditionPct = 89,
            filterLifePct = 76,
            diagnostics = diagnostics
        )
    }
}
