package com.example.domain

import kotlin.math.sqrt

data class DetectedObject3D(
    val id: String,
    val type: String, // "PEDESTRIAN", "DUMP_TRUCK", "PIPE_UTILITY", "BARRIER", "STOCKPILE"
    val xM: Float,
    val yM: Float,
    val zM: Float,
    val sizeX: Float = 1.0f,
    val sizeY: Float = 1.0f,
    val confidencePct: Int = 96,
    val distanceToExcavatorM: Float
)

data class SafetyStatus(
    val isPedestrianInWorkingEnvelope: Boolean,
    val isNearUtilityPipe: Boolean,
    val closestPedestrianDistanceM: Float,
    val warningMessage: String?,
    val isSimulationPausedForSafety: Boolean
)

object PerceptionEngine {

    fun generateDefaultObjects(machineX: Float = 0f, machineY: Float = 0f): List<DetectedObject3D> {
        return listOf(
            DetectedObject3D(
                id = "PED-01",
                type = "PEDESTRIAN",
                xM = 6.2f,
                yM = 4.8f,
                zM = 0.0f,
                distanceToExcavatorM = sqrt(6.2f * 6.2f + 4.8f * 4.8f),
                confidencePct = 98
            ),
            DetectedObject3D(
                id = "TRK-08",
                type = "DUMP_TRUCK",
                xM = -8.5f,
                yM = 3.0f,
                zM = 0.0f,
                sizeX = 6.5f,
                sizeY = 2.8f,
                distanceToExcavatorM = sqrt(8.5f * 8.5f + 3.0f * 3.0f),
                confidencePct = 99
            ),
            DetectedObject3D(
                id = "UTIL-02",
                type = "PIPE_UTILITY",
                xM = 12.0f,
                yM = 4.0f,
                zM = -1.8f,
                distanceToExcavatorM = sqrt(12f * 12f + 4f * 4f),
                confidencePct = 94
            )
        )
    }

    fun evaluateSafety(objects: List<DetectedObject3D>, swingRadiusM: Float = 10.8f): SafetyStatus {
        val pedestrians = objects.filter { it.type == "PEDESTRIAN" }
        val closestPed = pedestrians.minByOrNull { it.distanceToExcavatorM }

        val isIntrusion = closestPed != null && closestPed.distanceToExcavatorM < swingRadiusM
        val isUtilityNear = objects.any { it.type == "PIPE_UTILITY" && it.distanceToExcavatorM < 5.0f }

        val warning = when {
            isIntrusion -> "WARNING: PEDESTRIAN DETECTED IN WORKING ENVELOPE (${"%.1f".format(closestPed?.distanceToExcavatorM ?: 0f)}m)! INTELLISENSE AUTO-HOLD ACTIVE."
            isUtilityNear -> "CAUTION: BURIED UTILITY PIPE DETECTED WITHIN 5M. DEPTH CONTROL ACTIVE."
            else -> null
        }

        return SafetyStatus(
            isPedestrianInWorkingEnvelope = isIntrusion,
            isNearUtilityPipe = isUtilityNear,
            closestPedestrianDistanceM = closestPed?.distanceToExcavatorM ?: 99f,
            warningMessage = warning,
            isSimulationPausedForSafety = isIntrusion
        )
    }
}
