package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.KinematicsEngine
import com.example.domain.MachinePose
import com.example.ui.StudioUiState
import com.example.ui.components.Jcb3dExcavatorCanvas
import com.example.ui.components.JcbArmKinematicsCanvas
import com.example.ui.theme.*

@Composable
fun MachineTwinScreen(
    uiState: StudioUiState,
    onSelectComponent: (String) -> Unit
) {
    var ikTargetX by remember { mutableFloatStateOf(6.5f) }
    var ikTargetZ by remember { mutableFloatStateOf(-2.0f) }

    val calculatedPose = remember(ikTargetX, ikTargetZ) {
        KinematicsEngine.solveInverseKinematics(ikTargetX, 0f, ikTargetZ)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JcbBlack)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("machine_twin_screen")
    ) {
        Text(
            text = "MASTER MACHINE DIGITAL TWIN — ${uiState.simState.activeMachineModel}",
            color = JcbYellow,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Main 3D Twin View
        Jcb3dExcavatorCanvas(
            pose = calculatedPose,
            selectedComponent = uiState.selectedComponent,
            onSelectComponent = onSelectComponent,
            bucketFillPct = uiState.simState.currentBucketFillPct,
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Selected Component Inspector Card
        Card(
            colors = CardDefaults.cardColors(containerColor = JcbSurfaceDark),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, JcbYellow.copy(alpha = 0.6f))
                .padding(12.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "COMPONENT INSPECTOR: ${uiState.selectedComponent}",
                        color = JcbYellow,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "HEALTH: 94% OPTIMAL",
                        color = EngineeringGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                when (uiState.selectedComponent) {
                    "BOOM" -> ComponentDetailView("BOOM CYLINDER & STRUCTURE", "Length: 6.45m", "Angle: ${calculatedPose.boomAngleDeg.toInt()}°", "Hydraulic Pressure: 312 bar", "Stress Load: 64% Nominal")
                    "DIPPER" -> ComponentDetailView("DIPPER ARM ASSEMBLY", "Length: 3.20m", "Angle: ${calculatedPose.dipperAngleDeg.toInt()}°", "Cylinder Velocity: 0.42 m/s", "Pin Bushing Wear: 0.04mm")
                    "BUCKET" -> ComponentDetailView("HD 1.8m³ ROCK BUCKET", "Width: 1.45m", "Capacity: 1.80 m³", "Fill Level: ${uiState.simState.currentBucketFillPct}%", "Tooth Wear: 14mm remaining")
                    "HYDRAULICS" -> ComponentDetailView("MAIN LOAD SENSING PUMP", "Max Pressure: 350 bar", "Current Flow: 348 L/min", "Fluid Temp: 68.4°C", "Filter Life: 76%")
                    else -> ComponentDetailView("CABIN & SLEW RING", "Slew Angle: ${calculatedPose.slewAngleDeg.toInt()}°", "Slew Speed: 10.2 rpm", "Engine Load: 64%", "Track Speed: 3.4 km/h")
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Inverse Kinematics (IK) Interactive Target Solver
        Card(
            colors = CardDefaults.cardColors(containerColor = JcbSurfaceDark),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, JcbGraphite)
                .padding(12.dp)
        ) {
            Column {
                Text(
                    text = "INVERSE KINEMATICS (IK) REAL-TIME SOLVER",
                    color = JcbYellow,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Set target bucket tip 3D coordinates (X, Z) to compute valid hydraulic cylinder joint angles.",
                    color = MachineAluminium,
                    fontSize = 9.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("TARGET REACH (X): ${"%.1f".format(ikTargetX)}m", color = Paper, fontSize = 10.sp, modifier = Modifier.width(150.dp))
                    Slider(
                        value = ikTargetX,
                        onValueChange = { ikTargetX = it },
                        valueRange = 3.0f..9.5f,
                        colors = SliderDefaults.colors(thumbColor = JcbYellow, activeTrackColor = JcbYellow),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("TARGET DEPTH (Z): ${"%.1f".format(ikTargetZ)}m", color = Paper, fontSize = 10.sp, modifier = Modifier.width(150.dp))
                    Slider(
                        value = ikTargetZ,
                        onValueChange = { ikTargetZ = it },
                        valueRange = -5.0f..2.0f,
                        colors = SliderDefaults.colors(thumbColor = JcbYellow, activeTrackColor = JcbYellow),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 2D Technical Arm Kinematics Diagram
        JcbArmKinematicsCanvas(
            pose = calculatedPose,
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
        )
    }
}

@Composable
private fun ComponentDetailView(name: String, p1: String, p2: String, p3: String, p4: String) {
    Column {
        Text(name, color = Paper, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(p1, color = WarmConcrete, fontSize = 10.sp)
            Text(p2, color = WarmConcrete, fontSize = 10.sp)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(p3, color = WarmConcrete, fontSize = 10.sp)
            Text(p4, color = WarmConcrete, fontSize = 10.sp)
        }
    }
}
