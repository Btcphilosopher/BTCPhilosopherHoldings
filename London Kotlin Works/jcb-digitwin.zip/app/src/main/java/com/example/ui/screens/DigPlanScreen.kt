package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.VolumeEngine
import com.example.ui.StudioUiState
import com.example.ui.theme.*

@Composable
fun DigPlanScreen(
    uiState: StudioUiState
) {
    var selectedPlanType by remember { mutableStateOf("FOUNDATION") }
    var targetLengthM by remember { mutableFloatStateOf(24.0f) }
    var targetWidthM by remember { mutableFloatStateOf(8.0f) }
    var targetDepthM by remember { mutableFloatStateOf(3.2f) }

    val volumeStats = remember(uiState.voxelsGrid) {
        VolumeEngine.calculateStats(uiState.voxelsGrid)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JcbBlack)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("dig_plan_screen")
    ) {
        Text(
            text = "EXCAVATION PLANNER & TARGET SURFACE ENGINE",
            color = JcbYellow,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Plan Type Selector
        Text("SELECT EXCAVATION TYPE", color = EngineeringGrey, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("FOUNDATION", "UTILITY TRENCH", "BASEMENT", "QUARRY").forEach { plan ->
                FilterChip(
                    selected = selectedPlanType == plan,
                    onClick = { selectedPlanType = plan },
                    label = { Text(plan, fontSize = 10.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Dynamic Volume Engine Metrics Display
        Card(
            colors = CardDefaults.cardColors(containerColor = JcbSurfaceDark),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, JcbYellow)
                .padding(12.dp)
        ) {
            Column {
                Text("EXCAVATION VOLUME CALCULATOR", color = JcbYellow, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    VolumeMetricCard("TARGET", "${volumeStats.totalTargetM3.toInt()} m³", Paper)
                    VolumeMetricCard("EXCAVATED", "${volumeStats.excavatedM3.toInt()} m³", JcbYellow)
                    VolumeMetricCard("REMAINING", "${volumeStats.remainingM3.toInt()} m³", WarmConcrete)
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("OVERDIG: ${volumeStats.overdigM3} m³", color = SignalRed, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("UNDERDIG: ${volumeStats.underdigM3} m³", color = SignalAmber, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Target Geometry Slider Adjuster Form
        Card(
            colors = CardDefaults.cardColors(containerColor = JcbSurfaceDark),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, JcbGraphite)
                .padding(12.dp)
        ) {
            Column {
                Text("EXCAVATION GEOMETRY FORM", color = Paper, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("LENGTH: ${targetLengthM.toInt()} m", color = WarmConcrete, fontSize = 10.sp, modifier = Modifier.width(110.dp))
                    Slider(
                        value = targetLengthM,
                        onValueChange = { targetLengthM = it },
                        valueRange = 10f..100f,
                        colors = SliderDefaults.colors(thumbColor = JcbYellow, activeTrackColor = JcbYellow),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("WIDTH: ${targetWidthM.toInt()} m", color = WarmConcrete, fontSize = 10.sp, modifier = Modifier.width(110.dp))
                    Slider(
                        value = targetWidthM,
                        onValueChange = { targetWidthM = it },
                        valueRange = 1f..30f,
                        colors = SliderDefaults.colors(thumbColor = JcbYellow, activeTrackColor = JcbYellow),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("DEPTH: ${"%.1f".format(targetDepthM)} m", color = WarmConcrete, fontSize = 10.sp, modifier = Modifier.width(110.dp))
                    Slider(
                        value = targetDepthM,
                        onValueChange = { targetDepthM = it },
                        valueRange = 0.5f..8.0f,
                        colors = SliderDefaults.colors(thumbColor = JcbYellow, activeTrackColor = JcbYellow),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun VolumeMetricCard(label: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Column {
        Text(label, color = EngineeringGrey, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(value, color = color, fontSize = 16.sp, fontWeight = FontWeight.Black)
    }
}
