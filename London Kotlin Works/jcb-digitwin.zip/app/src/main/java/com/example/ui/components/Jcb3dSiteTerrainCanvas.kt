package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.DetectedObject3D
import com.example.domain.GroundVoxel
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun Jcb3dSiteTerrainCanvas(
    voxels: List<GroundVoxel>,
    detectedObjects: List<DetectedObject3D> = emptyList(),
    showSubsurfaceSlice: Boolean = false,
    selectedVoxel: GroundVoxel? = null,
    onSelectVoxel: (GroundVoxel) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var tiltAngleX by remember { mutableStateOf(35f) }
    var panAngleY by remember { mutableStateOf(45f) }

    var showPointCloud by remember { mutableStateOf(false) }
    var showPipes by remember { mutableStateOf(true) }
    var showTargetHeatmap by remember { mutableStateOf(true) }

    Box(
        modifier = modifier
            .background(JcbBlack)
            .border(1.dp, JcbGraphite)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    panAngleY += dragAmount.x * 0.4f
                    tiltAngleX = (tiltAngleX - dragAmount.y * 0.4f).coerceIn(10f, 75f)
                }
            }
            .testTag("3d_site_terrain_canvas")
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f + 40f)

            fun project3D(x: Float, y: Float, z: Float): Offset {
                val radY = Math.toRadians(panAngleY.toDouble())
                val radX = Math.toRadians(tiltAngleX.toDouble())

                val rx = (x * cos(radY) - y * sin(radY)).toFloat()
                val ry = (x * sin(radY) + y * cos(radY)).toFloat()
                val rz = (z * cos(radX) - ry * sin(radX)).toFloat()

                val scale = 24f
                return Offset(center.x + rx * scale, center.y - rz * scale)
            }

            // Draw Voxel Terrain Cells
            voxels.forEach { v ->
                val originX = (v.gridX - 8) * 1.2f
                val originY = (v.gridY - 6) * 1.2f

                val p1 = project3D(originX, originY, v.currentElevationM)
                val p2 = project3D(originX + 1.1f, originY, v.currentElevationM)
                val p3 = project3D(originX + 1.1f, originY + 1.1f, v.currentElevationM)
                val p4 = project3D(originX, originY + 1.1f, v.currentElevationM)

                val cellColor = when {
                    showTargetHeatmap && v.currentElevationM <= v.targetElevationM + 0.05f -> EngineeringGreen.copy(alpha = 0.8f)
                    showTargetHeatmap && v.currentElevationM < v.targetElevationM - 0.05f -> SignalRed.copy(alpha = 0.8f)
                    v.primaryMaterial == "TOPSOIL" -> EarthTopsoil
                    v.primaryMaterial == "CLAY" -> EarthClay
                    v.primaryMaterial == "SAND" -> EarthSand
                    else -> EarthRock
                }

                val polyPath = Path().apply {
                    moveTo(p1.x, p1.y)
                    lineTo(p2.x, p2.y)
                    lineTo(p3.x, p3.y)
                    lineTo(p4.x, p4.y)
                    close()
                }

                drawPath(polyPath, color = cellColor)
                drawPath(polyPath, color = EngineeringGrey.copy(alpha = 0.3f), style = Stroke(1f))

                // Point cloud mode dots
                if (showPointCloud) {
                    drawCircle(color = Paper, center = p1, radius = 2f)
                }
            }

            // Draw Buried Service Pipe
            if (showPipes) {
                val pipeStart = project3D(-6f, 2f, -1.8f)
                val pipeEnd = project3D(8f, 2f, -1.8f)

                drawLine(
                    color = SignalAmber,
                    start = pipeStart,
                    end = pipeEnd,
                    strokeWidth = 8f
                )

                // Safety Buffer Zone Circle
                drawCircle(
                    color = SignalAmber.copy(alpha = 0.25f),
                    center = Offset((pipeStart.x + pipeEnd.x) / 2f, (pipeStart.y + pipeEnd.y) / 2f),
                    radius = 45f,
                    style = Stroke(2f)
                )
            }

            // Draw Detected Objects (e.g. Pedestrians & Dump Trucks)
            detectedObjects.forEach { obj ->
                val pos = project3D(obj.xM, obj.yM, obj.zM)
                val objColor = if (obj.type == "PEDESTRIAN") SignalRed else SiteBlue

                drawCircle(color = objColor, center = pos, radius = 12f)
                drawCircle(color = Paper, center = pos, radius = 12f, style = Stroke(2f))
            }
        }

        // Layer Toggles Overlay
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
        ) {
            Text(
                text = "SITE & TERRAIN DIGITAL TWIN",
                color = Paper,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                FilterChip(
                    selected = showTargetHeatmap,
                    onClick = { showTargetHeatmap = !showTargetHeatmap },
                    label = { Text("CUT/FILL HEATMAP", fontSize = 10.sp) }
                )
                FilterChip(
                    selected = showPipes,
                    onClick = { showPipes = !showPipes },
                    label = { Text("BURIED PIPES", fontSize = 10.sp) }
                )
                FilterChip(
                    selected = showPointCloud,
                    onClick = { showPointCloud = !showPointCloud },
                    label = { Text("POINT CLOUD", fontSize = 10.sp) }
                )
            }
        }
    }
}
