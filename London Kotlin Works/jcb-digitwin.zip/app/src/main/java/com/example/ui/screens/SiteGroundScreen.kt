package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.GroundModel
import com.example.ui.StudioUiState
import com.example.ui.components.Jcb3dSiteTerrainCanvas
import com.example.ui.components.JcbSubsurfaceSliceView
import com.example.ui.theme.*

@Composable
fun SiteGroundScreen(
    uiState: StudioUiState
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JcbBlack)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("site_ground_screen")
    ) {
        Text(
            text = "SITE & SUBSURFACE GROUND DIGITAL TWIN",
            color = JcbYellow,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        // 3D Voxel Terrain View
        Jcb3dSiteTerrainCanvas(
            voxels = uiState.voxelsGrid,
            detectedObjects = uiState.detectedObjects,
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Subsurface Cross-Section Slice
        JcbSubsurfaceSliceView(
            currentDepthM = 2.91f,
            targetDepthM = 3.20f,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Soil Layer Geotechnical Properties Card
        Card(
            colors = CardDefaults.cardColors(containerColor = JcbSurfaceDark),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, JcbGraphite)
                .padding(12.dp)
        ) {
            Column {
                Text(
                    text = "GEOTECHNICAL SOIL LAYER CLASSIFICATION",
                    color = JcbYellow,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                GroundModel.DefaultLayers.forEach { soil ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${soil.name} (${soil.startDepthM}-${soil.endDepthM}m)",
                            color = Paper,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${soil.densityKgM3} kg/m³ | ${soil.moisturePct}% H₂O | ${soil.excavability}",
                            color = WarmConcrete,
                            fontSize = 10.sp
                        )
                    }
                    Divider(color = EngineeringGrey.copy(alpha = 0.2f))
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Buried Utilities & Services Safety Card
        Card(
            colors = CardDefaults.cardColors(containerColor = JcbSurfaceDark),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SignalAmber.copy(alpha = 0.6f))
                .padding(12.dp)
        ) {
            Column {
                Text(
                    text = "BURIED UTILITIES & SUBSURFACE HAZARDS",
                    color = SignalAmber,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                GroundModel.DefaultServices.forEach { pipe ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(pipe.serviceType, color = Paper, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "Depth: ${pipe.depthM}m | Buffer: ${pipe.safetyBufferM}m | Conf: ${pipe.confidencePct}%",
                            color = SignalAmber,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}
