package com.example.domain

import kotlin.math.*

data class Joint3D(
    val x: Float,
    val y: Float,
    val z: Float
)

data class MachinePose(
    val boomAngleDeg: Float,   // 0 to 80 deg
    val dipperAngleDeg: Float, // -120 to 10 deg relative to boom
    val bucketAngleDeg: Float, // -150 to 50 deg relative to dipper
    val slewAngleDeg: Float    // -180 to 180 deg
)

data class KinematicResult(
    val cabinPos: Joint3D,
    val boomJoint: Joint3D,
    val dipperJoint: Joint3D,
    val bucketJoint: Joint3D,
    val bucketTip: Joint3D,
    val reachMeters: Float,
    val depthMeters: Float,
    val dumpHeightMeters: Float,
    val tipVelocityMps: Float = 1.2f,
    val isValidPose: Boolean = true
)

object KinematicsEngine {
    const val BOOM_LENGTH = 6.45f
    const val DIPPER_LENGTH = 3.20f
    const val BUCKET_LENGTH = 1.65f
    const val CABIN_HEIGHT = 1.80f

    fun calculateForwardKinematics(pose: MachinePose): KinematicResult {
        val slewRad = Math.toRadians(pose.slewAngleDeg.toDouble()).toFloat()
        val boomRad = Math.toRadians(pose.boomAngleDeg.toDouble()).toFloat()
        val dipperRad = Math.toRadians((pose.boomAngleDeg + pose.dipperAngleDeg).toDouble()).toFloat()
        val bucketRad = Math.toRadians((pose.boomAngleDeg + pose.dipperAngleDeg + pose.bucketAngleDeg).toDouble()).toFloat()

        val cabin = Joint3D(0f, 0f, CABIN_HEIGHT)
        val boomBase = Joint3D(0.8f * cos(slewRad), 0.8f * sin(slewRad), CABIN_HEIGHT + 0.5f)

        val r1 = BOOM_LENGTH * cos(boomRad)
        val z1 = boomBase.z + BOOM_LENGTH * sin(boomRad)

        val r2 = r1 + DIPPER_LENGTH * cos(dipperRad)
        val z2 = z1 + DIPPER_LENGTH * sin(dipperRad)

        val r3 = r2 + BUCKET_LENGTH * cos(bucketRad)
        val z3 = z2 + BUCKET_LENGTH * sin(bucketRad)

        val boomJoint = Joint3D(r1 * cos(slewRad), r1 * sin(slewRad), z1)
        val dipperJoint = Joint3D(r2 * cos(slewRad), r2 * sin(slewRad), z2)
        val bucketTip = Joint3D(r3 * cos(slewRad), r3 * sin(slewRad), z3)

        val totalReach = sqrt(bucketTip.x * bucketTip.x + bucketTip.y * bucketTip.y)
        val depth = max(0f, -bucketTip.z)
        val dumpHeight = max(0f, bucketTip.z)

        return KinematicResult(
            cabinPos = cabin,
            boomJoint = boomBase,
            dipperJoint = boomJoint,
            bucketJoint = dipperJoint,
            bucketTip = bucketTip,
            reachMeters = totalReach,
            depthMeters = depth,
            dumpHeightMeters = dumpHeight,
            isValidPose = totalReach <= (BOOM_LENGTH + DIPPER_LENGTH + BUCKET_LENGTH)
        )
    }

    fun solveInverseKinematics(targetX: Float, targetY: Float, targetZ: Float): MachinePose {
        val slewDeg = Math.toDegrees(atan2(targetY.toDouble(), targetX.toDouble())).toFloat()
        val reach2D = sqrt(targetX * targetX + targetY * targetY)

        val targetZRel = targetZ - CABIN_HEIGHT
        val distToTarget = sqrt(reach2D * reach2D + targetZRel * targetZRel)

        val clampedDist = distToTarget.coerceIn(2.0f, (BOOM_LENGTH + DIPPER_LENGTH - 0.2f))

        val cosDipper = (clampedDist * clampedDist - BOOM_LENGTH * BOOM_LENGTH - DIPPER_LENGTH * DIPPER_LENGTH) /
                (2 * BOOM_LENGTH * DIPPER_LENGTH)
        val dipperAngleRel = Math.toDegrees(acos(cosDipper.coerceIn(-1.0f, 1.0f).toDouble())).toFloat() - 180f

        val alpha = atan2(targetZRel.toDouble(), reach2D.toDouble())
        val cosBoom = (BOOM_LENGTH * BOOM_LENGTH + clampedDist * clampedDist - DIPPER_LENGTH * DIPPER_LENGTH) /
                (2 * BOOM_LENGTH * clampedDist)
        val beta = acos(cosBoom.coerceIn(-1.0f, 1.0f).toDouble())

        val boomDeg = Math.toDegrees(alpha + beta).toFloat().coerceIn(10f, 75f)
        val dipperDeg = dipperAngleRel.coerceIn(-110f, -10f)
        val bucketDeg = -45f

        return MachinePose(
            boomAngleDeg = boomDeg,
            dipperAngleDeg = dipperDeg,
            bucketAngleDeg = bucketDeg,
            slewAngleDeg = slewDeg
        )
    }
}
