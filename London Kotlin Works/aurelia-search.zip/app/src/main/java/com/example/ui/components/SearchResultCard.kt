package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SearchResultItem
import com.example.ui.theme.*

@Composable
fun SearchResultCard(
    result: SearchResultItem,
    isSelectedForTrace: Boolean,
    onTraceClick: () -> Unit,
    onSaveClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = AureliaDeepGraphite,
        shape = MaterialTheme.shapes.extraSmall,
        modifier = modifier
            .fillMaxWidth()
            .border(
                width = 0.5.dp,
                color = if (isSelectedForTrace) AureliaBlue else AureliaCardBorder,
                shape = MaterialTheme.shapes.extraSmall
            )
            .testTag("result_card_${result.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Source & Meta Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = result.source,
                        style = MaterialTheme.typography.labelSmall,
                        color = AureliaGold,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .height(8.dp)
                            .width(1.dp)
                            .background(AureliaCardBorder)
                    )
                    Text(
                        text = result.category,
                        style = MaterialTheme.typography.labelSmall,
                        color = AureliaDimText
                    )
                    Box(
                        modifier = Modifier
                            .height(8.dp)
                            .width(1.dp)
                            .background(AureliaCardBorder)
                    )
                    Text(
                        text = result.date,
                        style = MaterialTheme.typography.labelSmall,
                        color = AureliaDimText
                    )
                }

                // Relevance & Confidence tag
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "RELEVANCE ${result.relevance}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = AureliaCyan
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Title
            Text(
                text = result.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = AureliaWarmWhite,
                lineHeight = 19.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Snippet
            Text(
                text = result.snippet,
                style = MaterialTheme.typography.bodyMedium,
                color = AureliaMutedWhite,
                lineHeight = 17.sp
            )

            // Key metric if available
            result.keyMetric?.let { metric ->
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(AureliaBase, MaterialTheme.shapes.extraSmall)
                        .border(0.5.dp, AureliaCardBorderSubtle, MaterialTheme.shapes.extraSmall)
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Key Metric",
                        tint = AureliaSuccess,
                        modifier = Modifier.size(12.dp)
                    )
                    Text(
                        text = metric,
                        style = MaterialTheme.typography.labelSmall,
                        color = AureliaWarmWhite
                    )
                }
            }

            // Disagreement warning flag if present
            result.disagreement?.let { conflict ->
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(AureliaDeepNavy, MaterialTheme.shapes.extraSmall)
                        .border(0.5.dp, AureliaWarning, MaterialTheme.shapes.extraSmall)
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.WarningAmber,
                        contentDescription = "Contradiction Detected",
                        tint = AureliaWarning,
                        modifier = Modifier.size(13.dp)
                    )
                    Column {
                        Text(
                            text = "EMPIRICAL CONTRADICTION DETECTED",
                            style = MaterialTheme.typography.labelSmall,
                            color = AureliaWarning,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${conflict.metricOrTopic}: ${conflict.sourceA.first} (${conflict.sourceA.second}) vs ${conflict.sourceB.first} (${conflict.sourceB.second})",
                            style = MaterialTheme.typography.labelSmall,
                            color = AureliaMutedWhite
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Toolbar (OPEN, SUMMARISE, COMPARE, TRACE SOURCE, CITE)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ActionPill(
                        label = "TRACE PROVENANCE",
                        icon = Icons.Default.AccountTree,
                        isActive = isSelectedForTrace,
                        onClick = onTraceClick,
                        tag = "btn_trace_${result.id}"
                    )
                    ActionPill(
                        label = "SAVE TO DOSSIER",
                        icon = Icons.Default.BookmarkBorder,
                        isActive = false,
                        onClick = onSaveClick,
                        tag = "btn_save_${result.id}"
                    )
                }

                Text(
                    text = "${result.sourceCount} SOURCES VERIFIED",
                    style = MaterialTheme.typography.labelSmall,
                    color = AureliaDimText
                )
            }
        }
    }
}

@Composable
private fun ActionPill(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isActive: Boolean,
    onClick: () -> Unit,
    tag: String
) {
    Surface(
        color = if (isActive) AureliaDeepNavy else AureliaBase,
        shape = MaterialTheme.shapes.extraSmall,
        modifier = Modifier
            .border(
                0.5.dp,
                if (isActive) AureliaBlue else AureliaCardBorderSubtle,
                MaterialTheme.shapes.extraSmall
            )
            .clickable { onClick() }
            .testTag(tag)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isActive) AureliaBlue else AureliaDimText,
                modifier = Modifier.size(11.dp)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = if (isActive) AureliaWarmWhite else AureliaDimText,
                fontSize = 8.5.sp
            )
        }
    }
}
