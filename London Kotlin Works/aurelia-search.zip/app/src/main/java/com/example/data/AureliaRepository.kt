package com.example.data

import com.example.model.*

object AureliaRepository {

    val defaultMarkets = listOf(
        MarketInstrument("FTSE 100", "London Stock Exchange", "8,274.32", "+0.76%", true, listOf(0.2f, 0.3f, 0.25f, 0.6f, 0.55f, 0.8f, 0.95f)),
        MarketInstrument("GBP / USD", "British Pound Sterling", "1.3421", "+0.23%", true, listOf(0.4f, 0.5f, 0.45f, 0.48f, 0.62f, 0.7f, 0.68f)),
        MarketInstrument("EUR / GBP", "Euro Sterling Cross", "0.8524", "-0.15%", false, listOf(0.7f, 0.65f, 0.6f, 0.58f, 0.52f, 0.45f, 0.4f)),
        MarketInstrument("BRENT CRUDE", "ICE Brent Futures", "86.45", "-0.41%", false, listOf(0.8f, 0.75f, 0.68f, 0.72f, 0.6f, 0.55f, 0.5f)),
        MarketInstrument("GOLD / OUNCE", "London Bullion", "2,654.20", "+0.38%", true, listOf(0.3f, 0.35f, 0.4f, 0.55f, 0.65f, 0.8f, 0.85f)),
        MarketInstrument("BTC / USD", "Bitcoin Spot Index", "94,180.00", "+2.14%", true, listOf(0.1f, 0.25f, 0.4f, 0.38f, 0.7f, 0.82f, 0.98f))
    )

    val defaultLiveIntelligence = listOf(
        LiveIntelligenceItem("16:38", "UK economy expands 0.3% in Q3 exceeding ONS baseline forecasts", "ONS / HM Treasury", "ECONOMY", "HIGH"),
        LiveIntelligenceItem("16:24", "Bank of England holds benchmark base rate at 4.00% in split MPC vote", "Reuters London", "FINANCE", "HIGH"),
        LiveIntelligenceItem("16:12", "HS2 Curzon Street hub completes high-speed viaduct segment ahead of schedule", "Financial Times", "TRANSPORT", "MEDIUM"),
        LiveIntelligenceItem("15:47", "British industrial consortium backs £2.4B green steel direct reduction plant in Teesside", "The Guardian", "BUSINESS", "HIGH"),
        LiveIntelligenceItem("15:21", "UK National Quantum Computing Centre deploys 128-qubit neutral atom platform in Harwell", "UKRI Technology", "QUANTUM", "CRITICAL"),
        LiveIntelligenceItem("14:55", "North Sea wind cluster sets 18.2 GW offshore generation record during Arctic front", "National Grid ESO", "ENERGY", "MEDIUM")
    )

    val defaultWeather = listOf(
        CityWeather("London", "Partly cloudy", 16, 18, 9),
        CityWeather("Manchester", "Overcast drizzle", 13, 15, 8),
        CityWeather("Edinburgh", "Brisk clear", 11, 13, 6),
        CityWeather("New York", "Clear crisp", 17, 20, 11),
        CityWeather("Tokyo", "Night rain", 21, 23, 16)
    )

    val initialSavedResearch = listOf(
        SavedResearchItem("RES-01", "European Semiconductor Capacity & Fab Buildouts 2028", "SEMICONDUCTORS", "04 OCT 2026", 42, listOf("Chips", "EU Chips Act", "ASML", "Foundry")),
        SavedResearchItem("RES-02", "UK Grid Infrastructure & Small Modular Reactor Sites", "ENERGY", "02 OCT 2026", 28, listOf("Nuclear", "Rolls-Royce", "DESNZ")),
        SavedResearchItem("RES-03", "Global Steel Scrap & Electric Arc Transformation", "COMMODITIES", "28 SEP 2026", 19, listOf("Teesside", "Green Steel", "Port Talbot"))
    )

    fun queryKnowledge(rawQuery: String, mode: SearchMode): Pair<List<SearchResultItem>, SynthesisData> {
        val q = rawQuery.trim().lowercase()

        return when {
            q.contains("semiconductor") || q.contains("chip") || q.contains("fab") -> {
                val results = listOf(
                    SearchResultItem(
                        id = "SEMI-001",
                        source = "REUTERS LONDON",
                        title = "Global semiconductor capital expenditure accelerates with £48B in European fab projects",
                        date = "06 OCT 2026",
                        category = "BUSINESS / DEEP TECH",
                        relevance = 96.4,
                        snippet = "Semiconductor wafer investment has surged across Europe and the UK, with new silicon carbide and advanced sub-2nm packaging capacity concentrated in Dresden, Grenoble, Newport and Cambridge hubs.",
                        keyMetric = "£48.4B committed CAPEX across 14 EU/UK cluster nodes",
                        confidence = 97,
                        sourceCount = 38,
                        primarySources = listOf("UK Dept for Science, Innovation and Technology Filing #2026-88", "European Semiconductor Industry Association (ESIA) Q3 Report", "ASML Annual Strategy Disclosure"),
                        secondarySources = listOf("Reuters Technology Desk", "Financial Times Lex Column", "Nikkei Asia Silicon Watch"),
                        disagreement = SourceDisagreement(
                            metricOrTopic = "Projected 2028 European wafer share",
                            sourceA = Pair("ESIA Report", "12.4% global wafer fab share"),
                            sourceB = Pair("McKinsey Microelectronics", "10.1% constrained by cleanroom tooling lead times"),
                            sourceC = Pair("AURELIA Model", "11.3% median projection"),
                            likelyCause = "Differences in packaging-only facilities vs complete front-end silicon fabrication definitions."
                        )
                    ),
                    SearchResultItem(
                        id = "SEMI-002",
                        source = "FINANCIAL TIMES",
                        title = "Cambridge silicon cluster drives next-generation RISC-V edge accelerators",
                        date = "05 OCT 2026",
                        category = "SYSTEM ARCHITECTURE",
                        relevance = 93.8,
                        snippet = "Architectures developed along the Silicon Fen corridor achieve 4.2x inference efficiency per watt in sovereign automotive neural processors.",
                        keyMetric = "4.2x FLOP/watt efficiency verified at Millbrook Proving Ground",
                        confidence = 94,
                        sourceCount = 22,
                        primarySources = listOf("Arm Architecture Whitepaper v9.4", "UKRI EPSRC Semiconductor Grant Archive")
                    ),
                    SearchResultItem(
                        id = "SEMI-003",
                        source = "DEPARTMENT FOR SCIENCE & TECH",
                        title = "UK National Semiconductor Strategy: Phase III compound semiconductor foundry expansion",
                        date = "03 OCT 2026",
                        category = "GOVERNMENT / STRATEGIC ASSET",
                        relevance = 91.2,
                        snippet = "Treasury allocation confirms capital co-investment for compound wafer fabrication in South Wales cluster, targeting gallium nitride (GaN) and indium phosphide photonics.",
                        keyMetric = "£1.2B Co-investment tranche operational Q1 2027",
                        confidence = 99,
                        sourceCount = 14,
                        primarySources = listOf("Cabinet Office Infrastructure Directive 19/26", "National Wealth Fund Mandate Document")
                    )
                )

                val synthesis = SynthesisData(
                    query = rawQuery,
                    totalSourcesAnalysed = 142,
                    primaryCount = 38,
                    newsCount = 71,
                    researchCount = 21,
                    marketDataCount = 12,
                    sourceConsistency = 92.4,
                    overallConfidence = 95.8,
                    executiveSummary = "European and British semiconductor capacity is expanding at a CAGR of 18.4% through 2029, driven by high-reliability automotive silicon, photonics, and compound semiconductor sovereignty. Tooling constraints from lithography backlogs remain the primary variance factor across industry models.",
                    keyFacts = listOf(
                        "14 high-volume manufacturing fabs actively under construction or re-tooling in Western Europe.",
                        "UK compound semiconductor cluster (CSconnected) commands 28% of global photonics research pipeline.",
                        "Cleanroom operational costs averaged £4,800/sqm with energy supply hedging securing 10-year baseloads."
                    ),
                    timeline = listOf(
                        Pair("2024 Q2", "Ratification of UK Sovereign Semiconductor Accord"),
                        Pair("2025 Q4", "Breaking ground on Newport compound expansion"),
                        Pair("2026 Q3", "Dresden TSMC JV cleanroom qualification completed"),
                        Pair("2027 Q4", "Target for 2nm pilot wafer runs across EU consortium")
                    ),
                    contradictions = listOf(
                        SourceDisagreement(
                            metricOrTopic = "Global Foundry Share (2028)",
                            sourceA = Pair("ESIA Brussels", "Targeting 12.5% global foundry output"),
                            sourceB = Pair("Gartner Research", "Capped at 9.8% due to litho supply delivery windows"),
                            sourceC = null,
                            likelyCause = "Variations in whether packaging-only facilities are counted as foundry capacity."
                        )
                    )
                )
                Pair(results, synthesis)
            }

            q.contains("bitcoin") || q.contains("market") || q.contains("crypto") || q.contains("btc") -> {
                val results = listOf(
                    SearchResultItem(
                        id = "MKT-001",
                        source = "BLOOMBERG TERMINAL FEED",
                        title = "Institutional crypto spot volumes settle at £18.2B daily amid London clearing approval",
                        date = "06 OCT 2026",
                        category = "FINANCIAL INFRASTRUCTURE",
                        relevance = 98.1,
                        snippet = "FCA-registered digital asset clearing platforms record institutional record inflows. Tier-1 British investment banks expand custody reserve rails into primary gilt collateral pools.",
                        keyMetric = "BTC Index: \$94,180.00 (+2.14% 24h) | 24h UK Institutional Volume: £2.4B",
                        confidence = 96,
                        sourceCount = 44,
                        primarySources = listOf("Bank of England Financial Stability Paper #84", "FCA Regulatory Register 2026", "LCH Digital Clearing Telemetry"),
                        secondarySources = listOf("Bloomberg Markets", "Financial Times Banking Desk")
                    ),
                    SearchResultItem(
                        id = "MKT-002",
                        source = "BANK OF ENGLAND",
                        title = "Wholesale Digital Pound: Real-time settlement pilot between 7 clearing banks",
                        date = "04 OCT 2026",
                        category = "CENTRAL BANK MONETARY SYSTEM",
                        relevance = 94.5,
                        snippet = "Project Rosalind Phase 4 integrates distributed ledger interbank liquidity with existing RTGS core architecture, lowering cross-border settlement duration to 420 milliseconds.",
                        keyMetric = "Latency: 420ms | Liquidity Pool: £50B pilot cap",
                        confidence = 99,
                        sourceCount = 19,
                        primarySources = listOf("BoE / BIS Innovation Hub Joint Publication", "HM Treasury Consultation Paper")
                    )
                )

                val synthesis = SynthesisData(
                    query = rawQuery,
                    totalSourcesAnalysed = 98,
                    primaryCount = 29,
                    newsCount = 45,
                    researchCount = 14,
                    marketDataCount = 10,
                    sourceConsistency = 95.1,
                    overallConfidence = 97.2,
                    executiveSummary = "Digital asset liquidity has consolidated within institutional custodians following clear FCA regulatory taxonomies in London. BTC and digital sovereign gilts trade alongside conventional sterling instruments with sub-second clearing integration.",
                    keyFacts = listOf(
                        "Over 72% of institutional digital asset flows now route through insured UK custodial trusts.",
                        "Wholesale digital sterling rails operating at 99.999% uptime in multi-bank sandbox.",
                        "Cross-margining between FTSE derivatives and digital assets reduces capital drag by 14%."
                    ),
                    timeline = listOf(
                        Pair("2024", "UK Digital Securities Sandbox (DSS) statutory launch"),
                        Pair("2025", "First gilt issuance tokenised and cleared in London"),
                        Pair("2026", "Expansion to 24/7 cross-currency institutional settlement")
                    ),
                    contradictions = emptyList()
                )
                Pair(results, synthesis)
            }

            q.contains("construction") || q.contains("housing") || q.contains("cost") || q.contains("steel") -> {
                val results = listOf(
                    SearchResultItem(
                        id = "ENG-001",
                        source = "ROYAL INSTITUTION OF CHARTERED SURVEYORS (RICS)",
                        title = "UK Construction Cost Index Q3: Material inflation stabilises at 1.8% as green steel scales",
                        date = "05 OCT 2026",
                        category = "INFRASTRUCTURE & ENGINEERING",
                        relevance = 97.2,
                        snippet = "Structural engineering costs across Manchester, Birmingham and London indicate moderate price stabilisation. Domestic supply from electric arc furnace modernisation in South Wales and Teesside reduces import vulnerability.",
                        keyMetric = "Cost index +1.8% YoY | Structural section steel -4.2% QoQ",
                        confidence = 98,
                        sourceCount = 31,
                        primarySources = listOf("RICS Building Cost Information Service (BCIS)", "Office for National Statistics Construction Output Stat #C9"),
                        disagreement = SourceDisagreement(
                            metricOrTopic = "Average commercial m² construction cost (London Zone 1)",
                            sourceA = Pair("BCIS Benchmark", "£3,850 per m²"),
                            sourceB = Pair("Mace Cost Consultancy", "£4,220 per m²"),
                            sourceC = Pair("Gleeds International", "£4,050 per m²"),
                            likelyCause = "BCIS excludes Cat B fit-out requirements and specialized BREEAM Outstanding HVAC specifications."
                        )
                    ),
                    SearchResultItem(
                        id = "ENG-002",
                        source = "NEW CIVIL ENGINEER",
                        title = "Lower Thames Crossing and Northern Powerhouse Rail accelerate procurement schedules",
                        date = "02 OCT 2026",
                        category = "CIVIL ENGINEERING",
                        relevance = 92.0,
                        snippet = "Tunnel boring machinery procurement contracts awarded with stringent UK content mandates exceeding 65% domestic steel and aggregate supply.",
                        keyMetric = "Domestic procurement threshold: 65% verified",
                        confidence = 95,
                        sourceCount = 18,
                        primarySources = listOf("National Infrastructure Commission Pipeline 2026-2035", "Highways England Major Projects Portal")
                    )
                )

                val synthesis = SynthesisData(
                    query = rawQuery,
                    totalSourcesAnalysed = 84,
                    primaryCount = 26,
                    newsCount = 39,
                    researchCount = 12,
                    marketDataCount = 7,
                    sourceConsistency = 89.6,
                    overallConfidence = 93.4,
                    executiveSummary = "British infrastructure and civil engineering costs have normalised following unprecedented electrification investments in steel and modular timber fabrication. London Grade-A commercial build costs remain sensitive to net-zero regulatory standards.",
                    keyFacts = listOf(
                        "Green steel from electric arc furnace refits now supplies 42% of domestic structural beams.",
                        "BCIS composite index tracks +1.8% annual inflation compared to +8.4% peak in 2023.",
                        "Regional infrastructure delivery speed improved 14% via reformed statutory planning fast-tracks."
                    ),
                    timeline = listOf(
                        Pair("2024", "National Planning Policy Framework modernised"),
                        Pair("2025", "Commissioning of Teesside and Port Talbot EAF facilities"),
                        Pair("2026 Q3", "Procurement awards on major transit rail links")
                    ),
                    contradictions = listOf(
                        SourceDisagreement(
                            metricOrTopic = "Zone 1 Build Cost per m²",
                            sourceA = Pair("RICS BCIS", "£3,850/m² base"),
                            sourceB = Pair("Mace Cost Model", "£4,220/m² including smart sensor mesh"),
                            sourceC = null,
                            likelyCause = "Differences in technology and high-density acoustic insulation specifications."
                        )
                    )
                )
                Pair(results, synthesis)
            }

            else -> {
                // Default / Generic High-Intelligence Synthesis
                val results = listOf(
                    SearchResultItem(
                        id = "GEN-001",
                        source = "AURELIA REPUTATION & PROVENANCE GRAPH",
                        title = "Comprehensive intelligence assessment for: $rawQuery",
                        date = "06 OCT 2026",
                        category = "SYSTEM SYNTHESIS",
                        relevance = 95.0,
                        snippet = "Cross-referenced data streams across British and global institutional archives, financial registries, patents and high-velocity news wires indicate accelerating structural transition in this domain.",
                        keyMetric = "8,421M Documents searched | 41ms execution latency",
                        confidence = 95,
                        sourceCount = 52,
                        primarySources = listOf("National Archives Discovery Index", "House of Commons Library Research Briefing", "HM Treasury Open Registry"),
                        secondarySources = listOf("Financial Times Research", "BBC Archive", "Reuters Intelligence")
                    ),
                    SearchResultItem(
                        id = "GEN-002",
                        source = "THE ECONOMIST LONDON",
                        title = "Technological sovereignty and the new geography of European research",
                        date = "04 OCT 2026",
                        category = "STRATEGIC ANALYSIS",
                        relevance = 91.5,
                        snippet = "How British universities, City capital allocators, and advanced engineering testbeds are compounding productivity dividends through targeted sovereign compute infrastructure.",
                        keyMetric = "R&D Intensity: 2.9% of GDP benchmark achieved",
                        confidence = 93,
                        sourceCount = 27,
                        primarySources = listOf("UKRI Research Portfolio 2026", "Royal Society Policy Brief")
                    )
                )

                val synthesis = SynthesisData(
                    query = rawQuery,
                    totalSourcesAnalysed = 112,
                    primaryCount = 31,
                    newsCount = 54,
                    researchCount = 18,
                    marketDataCount = 9,
                    sourceConsistency = 94.2,
                    overallConfidence = 96.1,
                    executiveSummary = "Aurelia multi-layer synthesis parsed 112 verified citations for '$rawQuery'. Data points indicate strong convergence across primary regulatory documentation and secondary analytical reports with minimal epistemic contradiction.",
                    keyFacts = listOf(
                        "Primary documentation accounts for 27.6% of verified evidence base.",
                        "Provenance audit confirmed zero synthetic hallucinations across referenced nodes.",
                        "Historical continuity verified across 10-year archive corpus."
                    ),
                    timeline = listOf(
                        Pair("2024", "Baseline legislative and empirical benchmark established"),
                        Pair("2025", "Operational transition and pilot deployment phase"),
                        Pair("2026", "Full-scale rollout across monitored institutional infrastructure")
                    ),
                    contradictions = emptyList()
                )
                Pair(results, synthesis)
            }
        }
    }
}
