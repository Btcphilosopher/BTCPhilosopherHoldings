package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SynthesisData
import com.example.model.SystemMetrics
import com.example.ui.theme.*

@Composable
fun DedicatedResearchWorkspaceView(
    synthesis: SynthesisData?,
    onExecuteSampleResearch: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("dedicated_research_workspace_view"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Science,
                    contentDescription = null,
                    tint = AureliaGold,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "AURELIA ADVANCED RESEARCH WORKSPACE",
                    style = MaterialTheme.typography.titleMedium,
                    color = AureliaWarmWhite,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = "MULTI-CORPUS DEEP TRACE",
                style = MaterialTheme.typography.labelSmall,
                color = AureliaDimText
            )
        }

        if (synthesis != null) {
            AureliaIntelligencePanel(
                synthesis = synthesis,
                onSaveResearch = {}
            )
        } else {
            Surface(
                color = AureliaDeepGraphite,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, AureliaCardBorderSubtle, MaterialTheme.shapes.extraSmall)
                    .padding(20.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Initialize deep investigation dossier",
                        style = MaterialTheme.typography.bodyMedium,
                        color = AureliaWarmWhite
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Button(
                        onClick = { onExecuteSampleResearch("European semiconductor capacity 2028") },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AureliaDeepNavy,
                            contentColor = AureliaCyan
                        ),
                        modifier = Modifier.border(0.5.dp, AureliaCyan, MaterialTheme.shapes.extraSmall)
                    ) {
                        Text(text = "LAUNCH: European Semiconductor 2028 Study")
                    }
                }
            }
        }
    }
}

@Composable
fun SystemDiagnosticsView(
    metrics: SystemMetrics,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("system_diagnostics_view"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Terminal,
                    contentDescription = null,
                    tint = AureliaCyan,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "AURELIA CORE INFRASTRUCTURE TELEMETRY",
                    style = MaterialTheme.typography.titleMedium,
                    color = AureliaWarmWhite,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = "FIPS-140-3 COMPLIANT",
                style = MaterialTheme.typography.labelSmall,
                color = AureliaDimText
            )
        }

        Surface(
            color = AureliaDeepGraphite,
            shape = MaterialTheme.shapes.extraSmall,
            modifier = Modifier
                .fillMaxWidth()
                .border(0.5.dp, AureliaCardBorderSubtle, MaterialTheme.shapes.extraSmall)
                .padding(14.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DiagnosticsLine("SEARCH CLUSTER NODES", "${metrics.searchNodes} Bare-Metal Bare-Silicon Nodes (UK/Europe)")
                DiagnosticsLine("INDEX PIPELINE STATUS", "${metrics.indexStatus} (Streaming Zero-Delay Ingestion)")
                DiagnosticsLine("QUERY ROUND-TRIP LATENCY", "${metrics.latencyMs}ms (Direct Fiber to London Internet Exchange)")
                DiagnosticsLine("INDEPENDENT DATA SOURCES", "${metrics.dataSources} Institutional, Regulatory & Financial Feeds")
                DiagnosticsLine("SYSTEM CLUSTER AVAILABILITY", "${metrics.uptimePercent}% Multi-Zone Redundancy")
                DiagnosticsLine("CURRENT CORPUS VOLUME", "${metrics.documentsIndexed} Deduplicated Documents")
                DiagnosticsLine("CRYPTOGRAPHIC PROTOCOL", "Quantum-Resistant Kyber/Dilithium Key Exchange Active")
            }
        }
    }
}

@Composable
private fun DiagnosticsLine(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = AureliaDimText
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall,
            color = AureliaWarmWhite,
            fontWeight = FontWeight.Medium
        )
    }
}
