package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*

@Composable
fun PrivacySessionDialog(
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            color = AureliaDeepGraphite,
            shape = MaterialTheme.shapes.small,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, AureliaBlue, MaterialTheme.shapes.small)
                .testTag("privacy_session_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = AureliaBlue,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "AURELIA PRIVACY PROTOCOL",
                            style = MaterialTheme.typography.titleMedium,
                            color = AureliaWarmWhite,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = AureliaDimText
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                PrivacyAttributeRow(title = "SEARCH HISTORY PERSISTENCE", value = "OFF / RAM-ONLY ISOLATED")
                PrivacyAttributeRow(title = "AD TARGETING & TELEMETRY", value = "DISABLED STRICTLY")
                PrivacyAttributeRow(title = "QUERY PERSONALISATION", value = "CONTROLLED LOCAL")
                PrivacyAttributeRow(title = "THIRD-PARTY DATA SHARING", value = "ZERO EXTERNAL BEACONS")
                PrivacyAttributeRow(title = "ENCRYPTION AT REST & TRANSIT", value = "POST-QUANTUM ML-KEM-1024")

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AureliaDeepNavy,
                        contentColor = AureliaBlue
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(0.5.dp, AureliaBlue, MaterialTheme.shapes.extraSmall)
                ) {
                    Text(text = "CONFIRM & CLOSE", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Composable
fun EnterpriseProDialog(
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            color = AureliaDeepGraphite,
            shape = MaterialTheme.shapes.small,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, AureliaGold, MaterialTheme.shapes.small)
                .testTag("enterprise_pro_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = AureliaGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "AURELIA PRO // ENTERPRISE",
                            style = MaterialTheme.typography.titleMedium,
                            color = AureliaGold,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = AureliaDimText
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                PrivacyAttributeRow(title = "ORGANISATIONAL INDEX", value = "ISOLATED ENCLAVE ONLINE")
                PrivacyAttributeRow(title = "CROSS-ORG AUDIT LOGGING", value = "COMPLIANT WITH FCA / PRA")
                PrivacyAttributeRow(title = "DEEP CONTRADICTION ENGINE", value = "UNRESTRICTED MULTI-MODEL")
                PrivacyAttributeRow(title = "PROVENANCE EXPORT", value = "BIBTEX / CSL-JSON / PDF BRIEF")

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AureliaBase,
                        contentColor = AureliaGold
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(0.5.dp, AureliaGold, MaterialTheme.shapes.extraSmall)
                ) {
                    Text(text = "ENTERPRISE WORKSPACE VERIFIED", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Composable
private fun PrivacyAttributeRow(title: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = AureliaDimText
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall,
            color = AureliaWarmWhite,
            fontWeight = FontWeight.Bold
        )
    }
}
