package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CityWeather
import com.example.model.LiveIntelligenceItem
import com.example.model.MarketInstrument
import com.example.model.SystemMetrics
import com.example.ui.theme.*

@Composable
fun RightIntelligenceColumn(
    liveIntelligence: List<LiveIntelligenceItem>,
    markets: List<MarketInstrument>,
    weather: List<CityWeather>,
    systemMetrics: SystemMetrics,
    onMarketItemClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = AureliaDeepGraphite,
        modifier = modifier
            .width(280.dp)
            .fillMaxHeight()
            .border(width = 0.5.dp, color = AureliaCardBorderSubtle)
            .testTag("right_intelligence_column")
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Section 1: LIVE INTELLIGENCE
            item {
                SectionHeader(title = "LIVE INTELLIGENCE", badge = "REALTIME")
            }

            items(liveIntelligence.take(4)) { item ->
                LiveNewsRow(item = item)
            }

            // Section 2: MARKETS
            item {
                Spacer(modifier = Modifier.height(4.dp))
                SectionHeader(title = "MARKETS TERMINAL", badge = "LSE / GILT")
            }

            items(markets) { instrument ->
                MarketRow(
                    instrument = instrument,
                    onClick = { onMarketItemClick(instrument.symbol) }
                )
            }

            // Section 3: WEATHER
            item {
                Spacer(modifier = Modifier.height(4.dp))
                SectionHeader(title = "METEOROLOGY", badge = "EUROPE")
            }

            item {
                WeatherPanel(weather = weather)
            }

            // Section 4: SYSTEM STATUS
            item {
                Spacer(modifier = Modifier.height(4.dp))
                SectionHeader(title = "SYSTEM INFRASTRUCTURE", badge = "UK CLUSTER")
            }

            item {
                SystemStatusBlock(metrics = systemMetrics)
            }
        }
    }
}

@Composable
fun SectionHeader(title: String, badge: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = AureliaGold,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
        Surface(
            color = AureliaBase,
            shape = MaterialTheme.shapes.extraSmall,
            modifier = Modifier.border(0.5.dp, AureliaCardBorderSubtle, MaterialTheme.shapes.extraSmall)
        ) {
            Text(
                text = badge,
                style = MaterialTheme.typography.labelSmall,
                color = AureliaDimText,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                fontSize = 8.sp
            )
        }
    }
}

@Composable
fun LiveNewsRow(item: LiveIntelligenceItem) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(AureliaBase, MaterialTheme.shapes.extraSmall)
            .border(0.5.dp, AureliaCardBorderSubtle, MaterialTheme.shapes.extraSmall)
            .padding(8.dp)
            .testTag("news_item_${item.timestamp}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = item.timestamp,
                style = MaterialTheme.typography.labelSmall,
                color = AureliaCyan,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = item.category,
                style = MaterialTheme.typography.labelSmall,
                color = AureliaDimText
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = item.title,
            style = MaterialTheme.typography.bodyMedium,
            color = AureliaWarmWhite,
            lineHeight = 15.sp
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = item.source,
            style = MaterialTheme.typography.labelSmall,
            color = AureliaDimText,
            fontSize = 8.5.sp
        )
    }
}

@Composable
fun MarketRow(
    instrument: MarketInstrument,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .background(AureliaBase, MaterialTheme.shapes.extraSmall)
            .border(0.5.dp, AureliaCardBorderSubtle, MaterialTheme.shapes.extraSmall)
            .padding(horizontal = 8.dp, vertical = 6.dp)
            .testTag("market_instrument_${instrument.symbol}"),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = instrument.symbol,
                style = MaterialTheme.typography.labelSmall,
                color = AureliaWarmWhite,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = instrument.name,
                style = MaterialTheme.typography.labelSmall,
                color = AureliaDimText,
                fontSize = 8.sp
            )
        }

        // Tiny Sparkline
        SparklineCanvas(
            points = instrument.sparklinePoints,
            isPositive = instrument.isPositive,
            modifier = Modifier
                .width(44.dp)
                .height(18.dp)
        )

        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = instrument.value,
                style = MaterialTheme.typography.labelSmall,
                color = AureliaWarmWhite,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = instrument.change,
                style = MaterialTheme.typography.labelSmall,
                color = if (instrument.isPositive) AureliaSuccess else AureliaNegative
            )
        }
    }
}

@Composable
fun SparklineCanvas(
    points: List<Float>,
    isPositive: Boolean,
    modifier: Modifier = Modifier
) {
    val lineColor = if (isPositive) AureliaSuccess else AureliaNegative

    Canvas(modifier = modifier) {
        if (points.size < 2) return@Canvas
        val path = Path()
        val stepX = size.width / (points.size - 1)

        points.forEachIndexed { i, pt ->
            val x = i * stepX
            val y = size.height * (1f - pt)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }

        drawPath(
            path = path,
            color = lineColor,
            style = Stroke(width = 1.2.dp.toPx())
        )
    }
}

@Composable
fun WeatherPanel(weather: List<CityWeather>) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(AureliaBase, MaterialTheme.shapes.extraSmall)
            .border(0.5.dp, AureliaCardBorderSubtle, MaterialTheme.shapes.extraSmall)
            .padding(8.dp)
    ) {
        weather.take(3).forEach { city ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = city.city,
                    style = MaterialTheme.typography.labelSmall,
                    color = AureliaWarmWhite
                )
                Text(
                    text = "${city.tempC}°C // ${city.condition}",
                    style = MaterialTheme.typography.labelSmall,
                    color = AureliaDimText
                )
            }
        }
    }
}

@Composable
fun SystemStatusBlock(metrics: SystemMetrics) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(AureliaBase, MaterialTheme.shapes.extraSmall)
            .border(0.5.dp, AureliaCardBorderSubtle, MaterialTheme.shapes.extraSmall)
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "INDEX STATUS", style = MaterialTheme.typography.labelSmall, color = AureliaDimText)
            Text(text = metrics.indexStatus, style = MaterialTheme.typography.labelSmall, color = AureliaCyan)
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "NODES ONLINE", style = MaterialTheme.typography.labelSmall, color = AureliaDimText)
            Text(text = "${metrics.searchNodes}", style = MaterialTheme.typography.labelSmall, color = AureliaWarmWhite)
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "LATENCY", style = MaterialTheme.typography.labelSmall, color = AureliaDimText)
            Text(text = "${metrics.latencyMs}ms", style = MaterialTheme.typography.labelSmall, color = AureliaCyan)
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "INDEXED CORPUS", style = MaterialTheme.typography.labelSmall, color = AureliaDimText)
            Text(text = "8.42B DOCS", style = MaterialTheme.typography.labelSmall, color = AureliaGold)
        }
    }
}
