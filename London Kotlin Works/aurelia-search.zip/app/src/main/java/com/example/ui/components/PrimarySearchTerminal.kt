package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SearchMode
import com.example.ui.theme.*

@Composable
fun PrimarySearchTerminal(
    query: String,
    onQueryChange: (String) -> Unit,
    onExecute: (String) -> Unit,
    activeMode: SearchMode,
    onModeSelect: (SearchMode) -> Unit,
    isComputing: Boolean,
    computingStep: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("primary_search_terminal_container"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Mode Selector Row
        SearchModeSelector(
            activeMode = activeMode,
            onModeSelect = onModeSelect
        )

        // Command Interface Box
        Surface(
            color = AureliaDeepGraphite,
            shape = MaterialTheme.shapes.small,
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 1.dp,
                    color = if (isComputing) AureliaCyan else AureliaCardBorder,
                    shape = MaterialTheme.shapes.small
                )
                .testTag("search_terminal_surface")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                // Terminal metadata banner
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "AURELIA QUERY INTERFACE",
                            style = MaterialTheme.typography.labelSmall,
                            color = AureliaGold
                        )
                        Text(
                            text = "v4.7 // LONDON",
                            style = MaterialTheme.typography.labelSmall,
                            color = AureliaDimText
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "⌘ K  SEARCH",
                            style = MaterialTheme.typography.labelSmall,
                            color = AureliaDimText
                        )
                        Text(
                            text = "↵ EXECUTE",
                            style = MaterialTheme.typography.labelSmall,
                            color = AureliaDimText
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Input Box with Prompt Sign
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = ">",
                        style = MaterialTheme.typography.titleLarge,
                        fontFamily = FontFamily.Monospace,
                        color = AureliaCyan,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(end = 8.dp)
                    )

                    BasicTextField(
                        value = query,
                        onValueChange = onQueryChange,
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { onExecute(query) }),
                        cursorBrush = SolidColor(AureliaCyan),
                        textStyle = MaterialTheme.typography.titleMedium.copy(
                            color = AureliaWarmWhite,
                            fontFamily = FontFamily.Monospace
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("search_query_input"),
                        decorationBox = { innerTextField ->
                            if (query.isEmpty()) {
                                Text(
                                    text = "Ask anything... or try /market bitcoin, /research UK construction",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        color = AureliaDimText,
                                        fontFamily = FontFamily.Monospace
                                    )
                                )
                            }
                            innerTextField()
                        }
                    )

                    // Accessory controls
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        IconButton(
                            onClick = { onExecute("semiconductor capacity Europe") },
                            modifier = Modifier
                                .size(32.dp)
                                .testTag("btn_search_mic")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Voice Input",
                                tint = AureliaDimText,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        IconButton(
                            onClick = { onExecute("London financial district") },
                            modifier = Modifier
                                .size(32.dp)
                                .testTag("btn_search_camera")
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = "Visual Query",
                                tint = AureliaDimText,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        // Execute button
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(32.dp)
                                .clip(MaterialTheme.shapes.extraSmall)
                                .background(AureliaDeepNavy)
                                .border(0.5.dp, AureliaBlue, MaterialTheme.shapes.extraSmall)
                                .clickable { onExecute(query) }
                                .testTag("btn_execute_search")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "Execute Query",
                                tint = AureliaBlue,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                // Computing State feedback
                AnimatedVisibility(
                    visible = isComputing,
                    enter = fadeIn(tween(150)),
                    exit = fadeOut(tween(150))
                ) {
                    Column(modifier = Modifier.padding(top = 10.dp)) {
                        LinearProgressIndicator(
                            color = AureliaCyan,
                            trackColor = AureliaCardBorder,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(2.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = computingStep,
                            style = MaterialTheme.typography.labelSmall,
                            color = AureliaCyan
                        )
                    }
                }
            }
        }

        // Quick Suggestion Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            val suggestions = listOf(
                "semiconductor capacity Europe",
                "/market bitcoin",
                "/research UK construction costs 2027",
                "/news global steel prices",
                "/map European semiconductor fabs",
                "/compare UK housing costs Germany"
            )
            items(suggestions) { item ->
                Surface(
                    color = AureliaDeepGraphite,
                    shape = MaterialTheme.shapes.extraSmall,
                    modifier = Modifier
                        .border(0.5.dp, AureliaCardBorderSubtle, MaterialTheme.shapes.extraSmall)
                        .clickable {
                            onQueryChange(item)
                            onExecute(item)
                        }
                        .testTag("suggestion_chip_$item")
                ) {
                    Text(
                        text = item,
                        style = MaterialTheme.typography.labelSmall,
                        color = AureliaMutedWhite,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun SearchModeSelector(
    activeMode: SearchMode,
    onModeSelect: (SearchMode) -> Unit
) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("search_mode_selector")
    ) {
        items(SearchMode.values()) { mode ->
            val isSelected = activeMode == mode
            Surface(
                color = if (isSelected) AureliaDeepNavy else AureliaBase,
                shape = MaterialTheme.shapes.extraSmall,
                modifier = Modifier
                    .border(
                        width = 0.5.dp,
                        color = if (isSelected) AureliaBlue else AureliaCardBorderSubtle,
                        shape = MaterialTheme.shapes.extraSmall
                    )
                    .clickable { onModeSelect(mode) }
                    .testTag("mode_chip_${mode.name}")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    if (isSelected) {
                        Box(
                            modifier = Modifier
                                .size(4.dp)
                                .clip(MaterialTheme.shapes.extraSmall)
                                .background(AureliaCyan)
                        )
                    }
                    Text(
                        text = mode.label.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (isSelected) AureliaWarmWhite else AureliaDimText
                    )
                }
            }
        }
    }
}
