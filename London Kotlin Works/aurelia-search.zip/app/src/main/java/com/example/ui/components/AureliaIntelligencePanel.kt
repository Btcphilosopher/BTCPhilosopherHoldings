package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CallSplit
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SynthesisData
import com.example.ui.theme.*

@Composable
fun AureliaIntelligencePanel(
    synthesis: SynthesisData,
    onSaveResearch: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = AureliaDeepGraphite,
        shape = MaterialTheme.shapes.extraSmall,
        modifier = modifier
            .fillMaxWidth()
            .border(width = 0.5.dp, color = AureliaCardBorder, shape = MaterialTheme.shapes.extraSmall)
            .testTag("aurelia_intelligence_panel")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header banner
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Aurelia Intelligence",
                        tint = AureliaGold,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "AURELIA INTELLIGENCE SYNTHESIS",
                        style = MaterialTheme.typography.labelSmall,
                        color = AureliaGold,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "CONSISTENCY ${synthesis.sourceConsistency}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = AureliaCyan
                    )
                    Text(
                        text = "CONFIDENCE ${synthesis.overallConfidence}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = AureliaBlue
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Metrics Breakdown Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(AureliaBase, MaterialTheme.shapes.extraSmall)
                    .border(0.5.dp, AureliaCardBorderSubtle, MaterialTheme.shapes.extraSmall)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MetricItem(label = "TOTAL SOURCES", value = "${synthesis.totalSourcesAnalysed}")
                MetricItem(label = "PRIMARY DOCS", value = "${synthesis.primaryCount}")
                MetricItem(label = "NEWS WIRES", value = "${synthesis.newsCount}")
                MetricItem(label = "RESEARCH PAPERS", value = "${synthesis.researchCount}")
                MetricItem(label = "MARKET DATA", value = "${synthesis.marketDataCount}")
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Executive Summary
            Text(
                text = synthesis.executiveSummary,
                style = MaterialTheme.typography.bodyMedium,
                color = AureliaWarmWhite,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Key Empirical Facts
            Text(
                text = "VERIFIED CORE FINDINGS",
                style = MaterialTheme.typography.labelSmall,
                color = AureliaDimText
            )
            Spacer(modifier = Modifier.height(4.dp))
            synthesis.keyFacts.forEach { fact ->
                Row(
                    modifier = Modifier.padding(vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(text = "•", color = AureliaCyan, style = MaterialTheme.typography.bodyMedium)
                    Text(
                        text = fact,
                        style = MaterialTheme.typography.bodyMedium,
                        color = AureliaMutedWhite
                    )
                }
            }

            // Timeline if available
            if (synthesis.timeline.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "EMPIRICAL TIMELINE & MILESTONES",
                    style = MaterialTheme.typography.labelSmall,
                    color = AureliaDimText
                )
                Spacer(modifier = Modifier.height(4.dp))
                synthesis.timeline.forEach { (date, event) ->
                    Row(
                        modifier = Modifier.padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = date,
                            style = MaterialTheme.typography.labelSmall,
                            color = AureliaGold,
                            modifier = Modifier.width(60.dp)
                        )
                        Text(
                            text = event,
                            style = MaterialTheme.typography.bodyMedium,
                            color = AureliaMutedWhite
                        )
                    }
                }
            }

            // Contradiction notice
            if (synthesis.contradictions.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(AureliaDeepNavy, MaterialTheme.shapes.extraSmall)
                        .border(0.5.dp, AureliaWarning, MaterialTheme.shapes.extraSmall)
                        .padding(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CallSplit,
                            contentDescription = "Contradiction",
                            tint = AureliaWarning,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = "CONTRADICTION ENGINE // DISAGREEMENT ISOLATED",
                            style = MaterialTheme.typography.labelSmall,
                            color = AureliaWarning,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    synthesis.contradictions.forEach { diff ->
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${diff.metricOrTopic}:",
                            style = MaterialTheme.typography.labelSmall,
                            color = AureliaWarmWhite,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "• ${diff.sourceA.first}: ${diff.sourceA.second}",
                            style = MaterialTheme.typography.labelSmall,
                            color = AureliaMutedWhite
                        )
                        Text(
                            text = "• ${diff.sourceB.first}: ${diff.sourceB.second}",
                            style = MaterialTheme.typography.labelSmall,
                            color = AureliaMutedWhite
                        )
                        Text(
                            text = "Cause: ${diff.likelyCause}",
                            style = MaterialTheme.typography.labelSmall,
                            color = AureliaCyan
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            color = AureliaWarmWhite,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = AureliaDimText,
            fontSize = 7.5.sp
        )
    }
}
