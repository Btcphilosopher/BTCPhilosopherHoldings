package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SearchResultItem
import com.example.ui.theme.*

@Composable
fun SourceTraceModal(
    result: SearchResultItem,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = AureliaDeepGraphite,
        shape = MaterialTheme.shapes.small,
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, AureliaBlue, MaterialTheme.shapes.small)
            .testTag("source_trace_modal")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Provenance",
                        tint = AureliaBlue,
                        modifier = Modifier.size(15.dp)
                    )
                    Text(
                        text = "SOURCE PROVENANCE & CITATION GRAPH",
                        style = MaterialTheme.typography.labelSmall,
                        color = AureliaBlue,
                        fontWeight = FontWeight.Bold
                    )
                }

                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(28.dp)
                        .testTag("btn_close_trace_modal")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = AureliaDimText,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = result.title,
                style = MaterialTheme.typography.titleMedium,
                color = AureliaWarmWhite,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Graph representation tree
            Text(
                text = "EPISTEMIC DERIVATION TREE",
                style = MaterialTheme.typography.labelSmall,
                color = AureliaDimText
            )
            Spacer(modifier = Modifier.height(6.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(AureliaBase, MaterialTheme.shapes.extraSmall)
                    .border(0.5.dp, AureliaCardBorderSubtle, MaterialTheme.shapes.extraSmall)
                    .padding(10.dp)
            ) {
                Text(
                    text = "PRIMARY LAYER [GROUND TRUTH]",
                    style = MaterialTheme.typography.labelSmall,
                    color = AureliaGold,
                    fontWeight = FontWeight.Bold
                )
                result.primarySources.ifEmpty { listOf("National Statistics Filing", "Company Regulatory Disclosure") }
                    .forEach { src ->
                        Text(
                            text = "  ├── $src",
                            style = MaterialTheme.typography.labelSmall,
                            color = AureliaWarmWhite
                        )
                    }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "SECONDARY LAYER [JOURNALISTIC & AUDIT]",
                    style = MaterialTheme.typography.labelSmall,
                    color = AureliaBlue,
                    fontWeight = FontWeight.Bold
                )
                result.secondarySources.ifEmpty { listOf("Reuters London Wire", "Financial Times Lex") }
                    .forEach { src ->
                        Text(
                            text = "  ├── $src",
                            style = MaterialTheme.typography.labelSmall,
                            color = AureliaMutedWhite
                        )
                    }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "ANALYSIS LAYER",
                    style = MaterialTheme.typography.labelSmall,
                    color = AureliaCyan,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "  └── AURELIA MULTI-MODEL SYNTHESIS (CONFIDENCE ${result.confidence}%)",
                    style = MaterialTheme.typography.labelSmall,
                    color = AureliaCyan
                )
            }
        }
    }
}
