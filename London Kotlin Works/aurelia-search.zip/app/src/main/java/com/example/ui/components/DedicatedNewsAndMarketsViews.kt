package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LiveIntelligenceItem
import com.example.model.MarketInstrument
import com.example.ui.theme.*

@Composable
fun DedicatedNewsStreamView(
    news: List<LiveIntelligenceItem>,
    onSelectNews: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("dedicated_news_stream_view"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Article,
                    contentDescription = null,
                    tint = AureliaCyan,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "AURELIA LIVE WIRE // VERIFIED DISPATCHES",
                    style = MaterialTheme.typography.titleMedium,
                    color = AureliaWarmWhite,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = "${news.size} ACTIVE DISPATCHES",
                style = MaterialTheme.typography.labelSmall,
                color = AureliaDimText
            )
        }

        news.forEach { item ->
            Surface(
                color = AureliaDeepGraphite,
                shape = MaterialTheme.shapes.extraSmall,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, AureliaCardBorderSubtle, MaterialTheme.shapes.extraSmall)
                    .clickable { onSelectNews(item.title) }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = item.timestamp,
                                style = MaterialTheme.typography.labelSmall,
                                color = AureliaCyan,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "// ${item.category}",
                                style = MaterialTheme.typography.labelSmall,
                                color = AureliaGold
                            )
                        }
                        Text(
                            text = item.importance,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (item.importance == "CRITICAL") AureliaWarning else AureliaDimText
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = AureliaWarmWhite,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Source wire: ${item.source} • Verified via Aurelia British Index",
                        style = MaterialTheme.typography.labelSmall,
                        color = AureliaDimText
                    )
                }
            }
        }
    }
}

@Composable
fun DedicatedMarketsView(
    markets: List<MarketInstrument>,
    onSelectInstrument: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("dedicated_markets_view"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.TrendingUp,
                    contentDescription = null,
                    tint = AureliaGold,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "AURELIA FINANCIAL & COMMODITY MATRIX",
                    style = MaterialTheme.typography.titleMedium,
                    color = AureliaWarmWhite,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = "REALTIME LSE / ICE / BULLION FEED",
                style = MaterialTheme.typography.labelSmall,
                color = AureliaDimText
            )
        }

        markets.forEach { item ->
            Surface(
                color = AureliaDeepGraphite,
                shape = MaterialTheme.shapes.extraSmall,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, AureliaCardBorderSubtle, MaterialTheme.shapes.extraSmall)
                    .clickable { onSelectInstrument(item.symbol) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = item.symbol,
                            style = MaterialTheme.typography.titleMedium,
                            color = AureliaGold,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = item.name,
                            style = MaterialTheme.typography.labelSmall,
                            color = AureliaDimText
                        )
                    }

                    SparklineCanvas(
                        points = item.sparklinePoints,
                        isPositive = item.isPositive,
                        modifier = Modifier
                            .width(80.dp)
                            .height(24.dp)
                    )

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = item.value,
                            style = MaterialTheme.typography.titleMedium,
                            color = AureliaWarmWhite,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = item.change,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (item.isPositive) AureliaSuccess else AureliaNegative
                        )
                    }
                }
            }
        }
    }
}
