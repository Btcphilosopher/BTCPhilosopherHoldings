package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.ui.components.AureliaMainScreen
import com.example.ui.theme.AureliaBase
import com.example.ui.theme.AureliaTheme
import com.example.viewmodel.AureliaViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: AureliaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AureliaTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = AureliaBase
                ) {
                    AureliaMainScreen(viewModel = viewModel)
                }
            }
        }
    }
}
