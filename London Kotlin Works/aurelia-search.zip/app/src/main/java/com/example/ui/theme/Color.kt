package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Aurelia British Terminal Color Palette
val AureliaBase = Color(0xFF05080C)
val AureliaDeepGraphite = Color(0xFF080D13)
val AureliaDeepNavy = Color(0xFF0A111A)
val AureliaGraphite = Color(0xFF111820)
val AureliaCardBorder = Color(0xFF1E2836)
val AureliaCardBorderSubtle = Color(0xFF141F2C)
val AureliaHoverSurface = Color(0xFF16212E)

val AureliaWarmWhite = Color(0xFFE8E8E3)
val AureliaMutedWhite = Color(0xFFB7BCC1)
val AureliaDimText = Color(0xFF6B7785)

val AureliaGold = Color(0xFFD6A84F)
val AureliaGoldDim = Color(0x33D6A84F)
val AureliaGoldSubtle = Color(0xFF9E7C35)

val AureliaBlue = Color(0xFF4CA6FF)
val AureliaBlueDim = Color(0x2B4CA6FF)

val AureliaCyan = Color(0xFF55E6D0)
val AureliaCyanDim = Color(0x2B55E6D0)

val AureliaWarning = Color(0xFFE3A84C)
val AureliaNegative = Color(0xFFD65C5C)
val AureliaSuccess = Color(0xFF4CD98B)
