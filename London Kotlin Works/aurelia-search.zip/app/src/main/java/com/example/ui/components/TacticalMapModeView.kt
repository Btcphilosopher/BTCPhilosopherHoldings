package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

data class GeographicNode(
    val name: String,
    val region: String,
    val type: String,
    val normalizedX: Float,
    val normalizedY: Float,
    val status: String
)

@Composable
fun TacticalMapModeView(
    onNodeSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val geoNodes = listOf(
        GeographicNode("Newport Wafer Fab", "South Wales, UK", "Compound Semiconductor", 0.32f, 0.48f, "ACTIVE FABRICATION"),
        GeographicNode("Silicon Fen Corridor", "Cambridge, UK", "RISC-V / Micro-architecture", 0.44f, 0.42f, "R&D CLUSTER"),
        GeographicNode("Culham Science Centre", "Oxfordshire, UK", "Fusion / Plasma Physics", 0.38f, 0.45f, "TOKAMAK ONLINE"),
        GeographicNode("Teesside Clean Energy", "North East, UK", "Green Steel EAF / Hydrogen", 0.40f, 0.28f, "CONSTRUCTION"),
        GeographicNode("Dresden Silicon Cluster", "Saxony, Germany", "Sub-2nm Foundry JV", 0.72f, 0.52f, "RE-TOOLING"),
        GeographicNode("Grenoble Microelectronics", "Auvergne-Rhône, France", "FD-SOI Semiconductor", 0.62f, 0.70f, "OPERATIONAL")
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("tactical_map_mode_view"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Place,
                    contentDescription = null,
                    tint = AureliaCyan,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "GEOGRAPHIC INTELLIGENCE // EUROPEAN SILICON & INFRASTRUCTURE",
                    style = MaterialTheme.typography.titleMedium,
                    color = AureliaWarmWhite,
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                text = "COORDINATE PROJECTION: MERCATOR 2028",
                style = MaterialTheme.typography.labelSmall,
                color = AureliaDimText
            )
        }

        // Tactical Vector Canvas
        Surface(
            color = AureliaDeepNavy,
            shape = MaterialTheme.shapes.extraSmall,
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
                .border(0.5.dp, AureliaCardBorder, MaterialTheme.shapes.extraSmall)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    // Draw fine grid coordinates
                    val gridCols = 8
                    val gridRows = 6
                    for (i in 0..gridCols) {
                        val x = i * (w / gridCols)
                        drawLine(
                            color = Color(0x144CA6FF),
                            start = Offset(x, 0f),
                            end = Offset(x, h),
                            strokeWidth = 1f
                        )
                    }
                    for (j in 0..gridRows) {
                        val y = j * (h / gridRows)
                        drawLine(
                            color = Color(0x144CA6FF),
                            start = Offset(0f, y),
                            end = Offset(w, y),
                            strokeWidth = 1f
                        )
                    }

                    // Connecting telemetry vector lines
                    val pNewport = Offset(0.32f * w, 0.48f * h)
                    val pCambridge = Offset(0.44f * w, 0.42f * h)
                    val pDresden = Offset(0.72f * w, 0.52f * h)
                    val pGrenoble = Offset(0.62f * w, 0.70f * h)

                    drawLine(color = Color(0x3355E6D0), start = pNewport, end = pCambridge, strokeWidth = 1.5f)
                    drawLine(color = Color(0x334CA6FF), start = pCambridge, end = pDresden, strokeWidth = 1.5f)
                    drawLine(color = Color(0x334CA6FF), start = pDresden, end = pGrenoble, strokeWidth = 1.5f)

                    // Draw geographic nodes
                    geoNodes.forEach { node ->
                        val nodePos = Offset(node.normalizedX * w, node.normalizedY * h)
                        drawCircle(color = Color(0x33D6A84F), radius = 10f, center = nodePos)
                        drawCircle(color = Color(0xFFD6A84F), radius = 4f, center = nodePos)
                    }
                }

                // Overlay Node Labels
                geoNodes.forEach { node ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(
                                start = (node.normalizedX * 260).dp,
                                top = (node.normalizedY * 220).dp
                            )
                    ) {
                        Surface(
                            color = AureliaBase.copy(alpha = 0.85f),
                            modifier = Modifier
                                .border(0.5.dp, AureliaCardBorder, MaterialTheme.shapes.extraSmall)
                                .clickable { onNodeSelect(node.name) }
                        ) {
                            Column(modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)) {
                                Text(
                                    text = node.name,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AureliaWarmWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 7.5.sp
                                )
                                Text(
                                    text = node.status,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AureliaCyan,
                                    fontSize = 6.5.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
