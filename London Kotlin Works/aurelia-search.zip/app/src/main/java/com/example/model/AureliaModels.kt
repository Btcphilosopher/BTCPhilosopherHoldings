package com.example.model

enum class SearchMode(val label: String, val commandPrefix: String) {
    WEB("Web", "/search"),
    NEWS("News", "/news"),
    MARKETS("Markets", "/market"),
    RESEARCH("Research", "/research"),
    COMPARE("Compare", "/compare"),
    MAPS("Maps", "/map"),
    IMAGES("Images", "/images"),
    KNOWLEDGE("Knowledge", "/knowledge")
}

data class SourceItem(
    val id: String,
    val name: String,
    val type: String, // PRIMARY, SECONDARY, ANALYSIS, REGULATORY
    val confidence: Int,
    val urlOrReference: String,
    val date: String
)

data class SourceDisagreement(
    val metricOrTopic: String,
    val sourceA: Pair<String, String>, // Source -> Claim
    val sourceB: Pair<String, String>,
    val sourceC: Pair<String, String>?,
    val likelyCause: String
)

data class SearchResultItem(
    val id: String,
    val source: String,
    val title: String,
    val date: String,
    val category: String,
    val relevance: Double,
    val snippet: String,
    val keyMetric: String? = null,
    val confidence: Int = 94,
    val sourceCount: Int = 18,
    val primarySources: List<String> = emptyList(),
    val secondarySources: List<String> = emptyList(),
    val citationRef: String = "REF-2026-UK",
    val disagreement: SourceDisagreement? = null
)

data class SynthesisData(
    val query: String,
    val totalSourcesAnalysed: Int,
    val primaryCount: Int,
    val newsCount: Int,
    val researchCount: Int,
    val marketDataCount: Int,
    val sourceConsistency: Double,
    val overallConfidence: Double,
    val executiveSummary: String,
    val keyFacts: List<String>,
    val timeline: List<Pair<String, String>>, // Date -> Event
    val contradictions: List<SourceDisagreement>
)

data class MarketInstrument(
    val symbol: String,
    val name: String,
    val value: String,
    val change: String,
    val isPositive: Boolean,
    val sparklinePoints: List<Float>
)

data class LiveIntelligenceItem(
    val timestamp: String,
    val title: String,
    val source: String,
    val category: String,
    val importance: String // HIGH, MEDIUM, CRITICAL
)

data class CityWeather(
    val city: String,
    val condition: String,
    val tempC: Int,
    val highC: Int,
    val lowC: Int
)

data class SystemMetrics(
    val indexStatus: String = "NOMINAL",
    val searchNodes: Int = 128,
    val latencyMs: Int = 41,
    val dataSources: Int = 14821,
    val uptimePercent: Double = 99.9987,
    val documentsIndexed: Long = 8421993221L
)

data class SavedResearchItem(
    val id: String,
    val title: String,
    val category: String,
    val timestamp: String,
    val sourceCount: Int,
    val tags: List<String>
)
