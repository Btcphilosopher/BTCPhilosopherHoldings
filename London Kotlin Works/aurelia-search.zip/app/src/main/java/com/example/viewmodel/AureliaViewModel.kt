package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AureliaRepository
import com.example.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class AppActiveTab {
    HOME,
    SEARCH_RESULTS,
    NEWS,
    MARKETS,
    RESEARCH,
    MAPS,
    SAVED,
    SYSTEM_DIAGNOSTICS
}

data class AureliaUiState(
    val activeTab: AppActiveTab = AppActiveTab.HOME,
    val currentMode: SearchMode = SearchMode.WEB,
    val searchQuery: String = "",
    val activeQuery: String = "semiconductor capacity Europe",
    val isComputing: Boolean = false,
    val computingStep: String = "",
    val searchResults: List<SearchResultItem> = emptyList(),
    val synthesisData: SynthesisData? = null,
    val selectedResultForTrace: SearchResultItem? = null,
    val markets: List<MarketInstrument> = AureliaRepository.defaultMarkets,
    val liveIntelligence: List<LiveIntelligenceItem> = AureliaRepository.defaultLiveIntelligence,
    val weatherList: List<CityWeather> = AureliaRepository.defaultWeather,
    val systemMetrics: SystemMetrics = SystemMetrics(),
    val savedResearch: List<SavedResearchItem> = AureliaRepository.initialSavedResearch,
    val isProEnterpriseActive: Boolean = true,
    val commandTerminalOpen: Boolean = false,
    val terminalLog: List<String> = listOf(
        "> system connected: AURELIA-CLUSTER-UK-NORTH",
        "> provenance index online: 8,421,993,221 documents",
        "> secure cryptographic session established",
        "> type /search, /news, /market, /research, /map to control terminal"
    ),
    val terminalInput: String = "",
    val showPrivacyDialog: Boolean = false,
    val showEnterpriseDialog: Boolean = false
)

class AureliaViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(AureliaUiState())
    val uiState: StateFlow<AureliaUiState> = _uiState.asStateFlow()

    init {
        // Pre-seed with default high-impact query
        executeSearch("semiconductor capacity Europe", SearchMode.WEB)
    }

    fun onQueryChange(newQuery: String) {
        _uiState.value = _uiState.value.copy(searchQuery = newQuery)
    }

    fun onModeSelect(mode: SearchMode) {
        _uiState.value = _uiState.value.copy(currentMode = mode)
        if (_uiState.value.activeQuery.isNotBlank()) {
            executeSearch(_uiState.value.activeQuery, mode)
        }
    }

    fun onTabSelect(tab: AppActiveTab) {
        _uiState.value = _uiState.value.copy(activeTab = tab)
    }

    fun toggleCommandTerminal() {
        _uiState.value = _uiState.value.copy(
            commandTerminalOpen = !_uiState.value.commandTerminalOpen
        )
    }

    fun onTerminalInputChange(input: String) {
        _uiState.value = _uiState.value.copy(terminalInput = input)
    }

    fun executeTerminalCommand(cmd: String) {
        val trimmed = cmd.trim()
        if (trimmed.isEmpty()) return

        val currentLogs = _uiState.value.terminalLog.toMutableList()
        currentLogs.add("> $trimmed")

        _uiState.value = _uiState.value.copy(
            terminalInput = "",
            terminalLog = currentLogs
        )

        val parts = trimmed.split(" ", limit = 2)
        val command = parts[0].lowercase()
        val arg = if (parts.size > 1) parts[1].trim() else ""

        when (command) {
            "/search" -> {
                val q = if (arg.isNotBlank()) arg else "British economy 2028"
                currentLogs.add("-> Switching to WEB search: $q")
                executeSearch(q, SearchMode.WEB)
            }
            "/market", "/markets" -> {
                val q = if (arg.isNotBlank()) arg else "bitcoin"
                currentLogs.add("-> Switching to MARKETS view: $q")
                executeSearch(q, SearchMode.MARKETS)
                _uiState.value = _uiState.value.copy(activeTab = AppActiveTab.MARKETS)
            }
            "/news" -> {
                val q = if (arg.isNotBlank()) arg else "global steel prices"
                currentLogs.add("-> Switching to NEWS stream: $q")
                executeSearch(q, SearchMode.NEWS)
                _uiState.value = _uiState.value.copy(activeTab = AppActiveTab.NEWS)
            }
            "/research" -> {
                val q = if (arg.isNotBlank()) arg else "UK construction costs 2027"
                currentLogs.add("-> Switching to DEEP RESEARCH: $q")
                executeSearch(q, SearchMode.RESEARCH)
                _uiState.value = _uiState.value.copy(activeTab = AppActiveTab.RESEARCH)
            }
            "/map", "/maps" -> {
                val q = if (arg.isNotBlank()) arg else "European semiconductor fabs"
                currentLogs.add("-> Initialising GEOGRAPHIC PROJECTION: $q")
                executeSearch(q, SearchMode.MAPS)
                _uiState.value = _uiState.value.copy(activeTab = AppActiveTab.MAPS)
            }
            "/compare" -> {
                val q = if (arg.isNotBlank()) arg else "UK housing costs Germany"
                currentLogs.add("-> Initialising COMPARATIVE SYNTHESIS: $q")
                executeSearch(q, SearchMode.COMPARE)
            }
            "/clear" -> {
                _uiState.value = _uiState.value.copy(
                    terminalLog = listOf("> terminal display cleared.")
                )
            }
            "/status" -> {
                currentLogs.add("-> Latency: 41ms | Nodes: 128 | Index: NOMINAL | Integrity: 100%")
                _uiState.value = _uiState.value.copy(terminalLog = currentLogs)
            }
            else -> {
                currentLogs.add("-> Unrecognized command. Available: /search, /news, /market, /research, /map, /compare, /status, /clear")
                _uiState.value = _uiState.value.copy(terminalLog = currentLogs)
            }
        }
    }

    fun executeSearch(query: String, mode: SearchMode = _uiState.value.currentMode) {
        val targetQuery = if (query.isNotBlank()) query else "semiconductor capacity Europe"

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isComputing = true,
                activeQuery = targetQuery,
                searchQuery = targetQuery,
                currentMode = mode,
                activeTab = AppActiveTab.SEARCH_RESULTS,
                computingStep = "RESOLVING QUERY CLUSTER..."
            )

            delay(220)
            _uiState.value = _uiState.value.copy(computingStep = "PARSING 142 SOURCES & PROVENANCE GRAPH...")
            delay(260)
            _uiState.value = _uiState.value.copy(computingStep = "SYNTHESISING EMPIRICAL CONTRADICTIONS...")
            delay(240)

            val (results, synthesis) = AureliaRepository.queryKnowledge(targetQuery, mode)

            _uiState.value = _uiState.value.copy(
                isComputing = false,
                computingStep = "",
                searchResults = results,
                synthesisData = synthesis,
                selectedResultForTrace = results.firstOrNull()
            )
        }
    }

    fun selectResultForTrace(item: SearchResultItem?) {
        _uiState.value = _uiState.value.copy(selectedResultForTrace = item)
    }

    fun saveCurrentResearch() {
        val currentSynthesis = _uiState.value.synthesisData ?: return
        val newItem = SavedResearchItem(
            id = "RES-${System.currentTimeMillis() % 10000}",
            title = currentSynthesis.query.replaceFirstChar { it.uppercase() },
            category = _uiState.value.currentMode.name,
            timestamp = "TODAY, 16:42",
            sourceCount = currentSynthesis.totalSourcesAnalysed,
            tags = listOf("Aurelia", "Computed", _uiState.value.currentMode.label)
        )
        val updated = listOf(newItem) + _uiState.value.savedResearch
        _uiState.value = _uiState.value.copy(savedResearch = updated)
    }

    fun setPrivacyDialog(visible: Boolean) {
        _uiState.value = _uiState.value.copy(showPrivacyDialog = visible)
    }

    fun setEnterpriseDialog(visible: Boolean) {
        _uiState.value = _uiState.value.copy(showEnterpriseDialog = visible)
    }
}
