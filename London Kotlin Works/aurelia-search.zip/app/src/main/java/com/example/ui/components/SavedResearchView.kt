package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SavedResearchItem
import com.example.ui.theme.*

@Composable
fun SavedResearchView(
    savedList: List<SavedResearchItem>,
    onSelectResearch: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("saved_research_view"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Bookmark,
                    contentDescription = null,
                    tint = AureliaGold,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "MY RESEARCH ARCHIVE & DOSSIERS",
                    style = MaterialTheme.typography.titleMedium,
                    color = AureliaWarmWhite,
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                text = "${savedList.size} DOSSIERS SAVED",
                style = MaterialTheme.typography.labelSmall,
                color = AureliaDimText
            )
        }

        if (savedList.isEmpty()) {
            Surface(
                color = AureliaDeepGraphite,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, AureliaCardBorderSubtle, MaterialTheme.shapes.extraSmall)
                    .padding(24.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "No saved dossiers in this session.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = AureliaDimText
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Execute queries and click 'SAVE TO DOSSIER' to compile research collections.",
                        style = MaterialTheme.typography.labelSmall,
                        color = AureliaMutedWhite
                    )
                }
            }
        } else {
            savedList.forEach { item ->
                Surface(
                    color = AureliaDeepGraphite,
                    shape = MaterialTheme.shapes.extraSmall,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(0.5.dp, AureliaCardBorderSubtle, MaterialTheme.shapes.extraSmall)
                        .clickable { onSelectResearch(item.title) }
                        .testTag("saved_dossier_${item.id}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = item.id,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AureliaGold,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "// ${item.category}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AureliaCyan
                                )
                                Text(
                                    text = item.timestamp,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AureliaDimText
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = AureliaWarmWhite,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                item.tags.forEach { tag ->
                                    Surface(
                                        color = AureliaBase,
                                        modifier = Modifier.border(0.5.dp, AureliaCardBorderSubtle, MaterialTheme.shapes.extraSmall)
                                    ) {
                                        Text(
                                            text = tag,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = AureliaMutedWhite,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                            fontSize = 8.sp
                                        )
                                    }
                                }
                            }
                        }

                        Icon(
                            imageVector = Icons.Default.OpenInNew,
                            contentDescription = "Open Dossier",
                            tint = AureliaBlue,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}
