package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.SearchMode
import com.example.ui.theme.*
import com.example.viewmodel.AppActiveTab
import com.example.viewmodel.AureliaUiState
import com.example.viewmodel.AureliaViewModel

@Composable
fun AureliaMainScreen(
    viewModel: AureliaViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollState = rememberLazyListState()

    // Dialogs
    if (uiState.showPrivacyDialog) {
        PrivacySessionDialog(onDismiss = { viewModel.setPrivacyDialog(false) })
    }
    if (uiState.showEnterpriseDialog) {
        EnterpriseProDialog(onDismiss = { viewModel.setEnterpriseDialog(false) })
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(AureliaBase)
            .testTag("aurelia_main_screen")
    ) {
        val isWideScreen = maxWidth > 840.dp
        val isMediumScreen = maxWidth > 600.dp

        Column(modifier = Modifier.fillMaxSize()) {
            // Upper System Bar
            TopSystemBar(
                onPrivacyClick = { viewModel.setPrivacyDialog(true) },
                onEnterpriseClick = { viewModel.setEnterpriseDialog(true) }
            )

            // Main Three-Zone Body
            Row(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                // Zone 1: Left Navigation Rail
                NavigationRail(
                    activeTab = uiState.activeTab,
                    onTabSelect = { viewModel.onTabSelect(it) }
                )

                // Zone 2: Centre Primary Search & Information Workspace
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    LazyColumn(
                        state = scrollState,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = if (isMediumScreen) 16.dp else 10.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Permanent Primary Search Terminal
                        item {
                            PrimarySearchTerminal(
                                query = uiState.searchQuery,
                                onQueryChange = { viewModel.onQueryChange(it) },
                                onExecute = { q -> viewModel.executeSearch(q) },
                                activeMode = uiState.currentMode,
                                onModeSelect = { m -> viewModel.onModeSelect(m) },
                                isComputing = uiState.isComputing,
                                computingStep = uiState.computingStep
                            )
                        }

                        // Collapsible Interactive Command Interpreter
                        item {
                            CommandTerminalBar(
                                isOpen = uiState.commandTerminalOpen,
                                onToggle = { viewModel.toggleCommandTerminal() },
                                logs = uiState.terminalLog,
                                input = uiState.terminalInput,
                                onInputChange = { viewModel.onTerminalInputChange(it) },
                                onExecute = { cmd -> viewModel.executeTerminalCommand(cmd) }
                            )
                        }

                        // Dynamic Workspace Content depending on active tab
                        item {
                            when (uiState.activeTab) {
                                AppActiveTab.HOME -> {
                                    LandingHeroView(
                                        onQuickSearch = { q, m ->
                                            viewModel.executeSearch(q, m)
                                        }
                                    )
                                }
                                AppActiveTab.SEARCH_RESULTS -> {
                                    SearchWorkspaceView(
                                        searchResults = uiState.searchResults,
                                        synthesis = uiState.synthesisData,
                                        selectedResultForTrace = uiState.selectedResultForTrace,
                                        onSelectForTrace = { item -> viewModel.selectResultForTrace(item) },
                                        onSaveResearch = { viewModel.saveCurrentResearch() }
                                    )
                                }
                                AppActiveTab.NEWS -> {
                                    DedicatedNewsStreamView(
                                        news = uiState.liveIntelligence,
                                        onSelectNews = { title ->
                                            viewModel.executeSearch(title, SearchMode.NEWS)
                                        }
                                    )
                                }
                                AppActiveTab.MARKETS -> {
                                    DedicatedMarketsView(
                                        markets = uiState.markets,
                                        onSelectInstrument = { sym ->
                                            viewModel.executeSearch(sym, SearchMode.MARKETS)
                                        }
                                    )
                                }
                                AppActiveTab.RESEARCH -> {
                                    DedicatedResearchWorkspaceView(
                                        synthesis = uiState.synthesisData,
                                        onExecuteSampleResearch = { q ->
                                            viewModel.executeSearch(q, SearchMode.RESEARCH)
                                        }
                                    )
                                }
                                AppActiveTab.MAPS -> {
                                    TacticalMapModeView(
                                        onNodeSelect = { loc ->
                                            viewModel.executeSearch("semiconductor facility $loc", SearchMode.MAPS)
                                        }
                                    )
                                }
                                AppActiveTab.SAVED -> {
                                    SavedResearchView(
                                        savedList = uiState.savedResearch,
                                        onSelectResearch = { title ->
                                            viewModel.executeSearch(title, SearchMode.RESEARCH)
                                        }
                                    )
                                }
                                AppActiveTab.SYSTEM_DIAGNOSTICS -> {
                                    SystemDiagnosticsView(metrics = uiState.systemMetrics)
                                }
                            }
                        }

                        // Extra bottom spacing for navigation clearance
                        item {
                            Spacer(modifier = Modifier.height(24.dp))
                        }
                    }
                }

                // Zone 3: Right Persistent Intelligence Column (Visible on Wide Desktop / Tablet Landscape)
                if (isWideScreen) {
                    RightIntelligenceColumn(
                        liveIntelligence = uiState.liveIntelligence,
                        markets = uiState.markets,
                        weather = uiState.weatherList,
                        systemMetrics = uiState.systemMetrics,
                        onMarketItemClick = { symbol ->
                            viewModel.executeSearch(symbol, SearchMode.MARKETS)
                        }
                    )
                }
            }
        }
    }
}
