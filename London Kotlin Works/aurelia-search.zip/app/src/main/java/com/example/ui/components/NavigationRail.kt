package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.AppActiveTab

@Composable
fun NavigationRail(
    activeTab: AppActiveTab,
    onTabSelect: (AppActiveTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = AureliaDeepGraphite,
        modifier = modifier
            .width(68.dp)
            .fillMaxHeight()
            .border(width = 0.5.dp, color = AureliaCardBorderSubtle)
            .testTag("navigation_rail")
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxSize()
                .padding(vertical = 12.dp)
        ) {
            // Main Top Nav Items
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Monogram mark
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(38.dp)
                        .background(AureliaBase, MaterialTheme.shapes.extraSmall)
                        .border(0.5.dp, AureliaGoldSubtle, MaterialTheme.shapes.extraSmall)
                        .clickable { onTabSelect(AppActiveTab.HOME) }
                        .testTag("nav_brand_mark")
                ) {
                    Text(
                        text = "A",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = AureliaGold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                NavRailItem(
                    label = "Home",
                    icon = Icons.Default.Home,
                    isSelected = activeTab == AppActiveTab.HOME,
                    onClick = { onTabSelect(AppActiveTab.HOME) },
                    tag = "nav_item_home"
                )

                NavRailItem(
                    label = "Search",
                    icon = Icons.Default.Search,
                    isSelected = activeTab == AppActiveTab.SEARCH_RESULTS,
                    onClick = { onTabSelect(AppActiveTab.SEARCH_RESULTS) },
                    tag = "nav_item_search"
                )

                NavRailItem(
                    label = "News",
                    icon = Icons.Default.Article,
                    isSelected = activeTab == AppActiveTab.NEWS,
                    onClick = { onTabSelect(AppActiveTab.NEWS) },
                    tag = "nav_item_news"
                )

                NavRailItem(
                    label = "Markets",
                    icon = Icons.Default.TrendingUp,
                    isSelected = activeTab == AppActiveTab.MARKETS,
                    onClick = { onTabSelect(AppActiveTab.MARKETS) },
                    tag = "nav_item_markets"
                )

                NavRailItem(
                    label = "Research",
                    icon = Icons.Default.MenuBook,
                    isSelected = activeTab == AppActiveTab.RESEARCH,
                    onClick = { onTabSelect(AppActiveTab.RESEARCH) },
                    tag = "nav_item_research"
                )

                NavRailItem(
                    label = "Maps",
                    icon = Icons.Default.Place,
                    isSelected = activeTab == AppActiveTab.MAPS,
                    onClick = { onTabSelect(AppActiveTab.MAPS) },
                    tag = "nav_item_maps"
                )

                NavRailItem(
                    label = "Saved",
                    icon = Icons.Default.Bookmark,
                    isSelected = activeTab == AppActiveTab.SAVED,
                    onClick = { onTabSelect(AppActiveTab.SAVED) },
                    tag = "nav_item_saved"
                )
            }

            // Bottom Nav Item: System diagnostics
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                NavRailItem(
                    label = "System",
                    icon = Icons.Default.Terminal,
                    isSelected = activeTab == AppActiveTab.SYSTEM_DIAGNOSTICS,
                    onClick = { onTabSelect(AppActiveTab.SYSTEM_DIAGNOSTICS) },
                    tag = "nav_item_system"
                )
            }
        }
    }
}

@Composable
private fun NavRailItem(
    label: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    tag: String
) {
    val indicatorColor by animateColorAsState(
        targetValue = if (isSelected) AureliaBlue else Color.Transparent,
        label = "nav_edge"
    )
    val iconColor by animateColorAsState(
        targetValue = if (isSelected) AureliaWarmWhite else AureliaDimText,
        label = "nav_icon"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .clickable { onClick() }
            .testTag(tag)
    ) {
        // Subtle left edge illumination
        Box(
            modifier = Modifier
                .width(2.dp)
                .fillMaxHeight()
                .background(indicatorColor)
                .align(Alignment.CenterStart)
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxSize()
                .padding(vertical = 4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = iconColor,
                modifier = Modifier.size(19.dp)
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = if (isSelected) AureliaWarmWhite else AureliaDimText,
                fontSize = 8.5.sp
            )
        }
    }
}
