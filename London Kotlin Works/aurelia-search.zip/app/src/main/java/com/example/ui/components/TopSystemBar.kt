package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun TopSystemBar(
    onPrivacyClick: () -> Unit,
    onEnterpriseClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = AureliaBase,
        modifier = modifier
            .fillMaxWidth()
            .height(44.dp)
            .border(width = 0.5.dp, color = AureliaCardBorderSubtle)
            .testTag("top_system_bar")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp)
        ) {
            // Left: Brand Title & Mode
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "AURELIA",
                    style = MaterialTheme.typography.labelLarge,
                    color = AureliaGold,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.8.sp
                )
                Text(
                    text = "SEARCH",
                    style = MaterialTheme.typography.labelLarge,
                    color = AureliaWarmWhite,
                    letterSpacing = 1.5.sp
                )
                Box(
                    modifier = Modifier
                        .height(12.dp)
                        .width(1.dp)
                        .background(AureliaCardBorder)
                )
                Text(
                    text = "PRIVATE INFORMATION SYSTEM",
                    style = MaterialTheme.typography.labelSmall,
                    color = AureliaDimText
                )
            }

            // Right: Status Badges
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Live pulse indicator
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(AureliaCyan)
                    )
                    Text(
                        text = "LIVE",
                        style = MaterialTheme.typography.labelSmall,
                        color = AureliaCyan
                    )
                }

                Text(
                    text = "LONDON",
                    style = MaterialTheme.typography.labelSmall,
                    color = AureliaMutedWhite
                )

                Text(
                    text = "41ms",
                    style = MaterialTheme.typography.labelSmall,
                    color = AureliaDimText
                )

                // Privacy Status Pill
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    modifier = Modifier
                        .clip(MaterialTheme.shapes.extraSmall)
                        .background(AureliaDeepNavy)
                        .border(0.5.dp, AureliaBlueDim, MaterialTheme.shapes.extraSmall)
                        .clickable { onPrivacyClick() }
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                        .testTag("privacy_status_pill")
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Secure Session",
                        tint = AureliaBlue,
                        modifier = Modifier.size(10.dp)
                    )
                    Text(
                        text = "SECURE",
                        style = MaterialTheme.typography.labelSmall,
                        color = AureliaBlue
                    )
                }

                // Enterprise Mode Pill
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(MaterialTheme.shapes.extraSmall)
                        .background(AureliaDeepGraphite)
                        .border(0.5.dp, AureliaGoldSubtle, MaterialTheme.shapes.extraSmall)
                        .clickable { onEnterpriseClick() }
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                        .testTag("enterprise_mode_pill")
                ) {
                    Text(
                        text = "PRO ENTERPRISE",
                        style = MaterialTheme.typography.labelSmall,
                        color = AureliaGold
                    )
                }
            }
        }
    }
}
