package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.SearchMode
import com.example.ui.theme.*

@Composable
fun LandingHeroView(
    onQuickSearch: (String, SearchMode) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("landing_hero_view"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Visual Billboard with London Night Atmosphere
        Surface(
            color = AureliaDeepGraphite,
            shape = MaterialTheme.shapes.small,
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .border(0.5.dp, AureliaCardBorder, MaterialTheme.shapes.small)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Background London night skyline image
                Image(
                    painter = painterResource(id = R.drawable.img_london_terminal),
                    contentDescription = "London Intelligence Terminal Environment",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                // Dark graphite gradient overlay to preserve contrast and serious terminal aesthetic
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    AureliaBase.copy(alpha = 0.92f),
                                    AureliaBase.copy(alpha = 0.70f),
                                    AureliaBase.copy(alpha = 0.40f)
                                )
                            )
                        )
                )

                // Hero Titles and Subheading
                Column(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .padding(start = 20.dp, end = 20.dp)
                ) {
                    Text(
                        text = "SEARCH",
                        style = MaterialTheme.typography.displayLarge,
                        color = AureliaWarmWhite,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "THE WORLD",
                        style = MaterialTheme.typography.displayLarge,
                        color = AureliaWarmWhite,
                        fontWeight = FontWeight.Normal,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "BEYOND",
                        style = MaterialTheme.typography.displayLarge,
                        color = AureliaGold,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Real-time information. Deeper context. One computational interface.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = AureliaMutedWhite
                    )
                }
            }
        }

        // 4 Curated Deep Intelligence Briefing Cards (Business, Tech, Travel, Science)
        Text(
            text = "SOVEREIGN INVESTIGATION DOSSIERS",
            style = MaterialTheme.typography.labelSmall,
            color = AureliaDimText
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DossierCard(
                category = "BUSINESS & EQUITY",
                title = "Global markets steady as tech stocks rally in London",
                snippet = "Institutional allocation into AI hardware drives FTSE outperformance.",
                tag = "dossier_card_1",
                modifier = Modifier.weight(1f),
                onClick = { onQuickSearch("global markets steady tech stocks rally", SearchMode.NEWS) }
            )
            DossierCard(
                category = "TECH & INNOVATION",
                title = "Next generation of autonomous agent clusters",
                snippet = "Sovereign compute fabrics in Oxfordshire set energy benchmarks.",
                tag = "dossier_card_2",
                modifier = Modifier.weight(1f),
                onClick = { onQuickSearch("autonomous AI agent clusters compute infrastructure", SearchMode.RESEARCH) }
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DossierCard(
                category = "ENERGY & MATERIALS",
                title = "Breakthrough in tokamak fusion plasma containment",
                snippet = "Culham Centre records 22-minute steady state magnetic equilibrium.",
                tag = "dossier_card_3",
                modifier = Modifier.weight(1f),
                onClick = { onQuickSearch("fusion energy tokamak Culham research UK", SearchMode.RESEARCH) }
            )
            DossierCard(
                category = "INFRASTRUCTURE",
                title = "European semiconductor wafer fabs and packaging",
                snippet = "Cross-border supply chains accelerate sub-2nm testbeds.",
                tag = "dossier_card_4",
                modifier = Modifier.weight(1f),
                onClick = { onQuickSearch("semiconductor capacity Europe", SearchMode.WEB) }
            )
        }
    }
}

@Composable
fun DossierCard(
    category: String,
    title: String,
    snippet: String,
    tag: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        color = AureliaDeepGraphite,
        shape = MaterialTheme.shapes.extraSmall,
        modifier = modifier
            .border(0.5.dp, AureliaCardBorderSubtle, MaterialTheme.shapes.extraSmall)
            .clickable { onClick() }
            .testTag(tag)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(
                text = category,
                style = MaterialTheme.typography.labelSmall,
                color = AureliaGold,
                fontSize = 8.5.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = AureliaWarmWhite,
                fontWeight = FontWeight.Medium,
                lineHeight = 16.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = snippet,
                style = MaterialTheme.typography.bodyMedium,
                color = AureliaDimText,
                fontSize = 10.5.sp,
                lineHeight = 14.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "ANALYSE",
                    style = MaterialTheme.typography.labelSmall,
                    color = AureliaCyan,
                    fontSize = 8.5.sp
                )
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = null,
                    tint = AureliaCyan,
                    modifier = Modifier.size(10.dp)
                )
            }
        }
    }
}
