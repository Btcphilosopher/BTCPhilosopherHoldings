package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val AureliaDarkColorScheme = darkColorScheme(
    primary = AureliaGold,
    onPrimary = AureliaBase,
    primaryContainer = AureliaGoldDim,
    onPrimaryContainer = AureliaWarmWhite,
    secondary = AureliaBlue,
    onSecondary = AureliaBase,
    secondaryContainer = AureliaBlueDim,
    onSecondaryContainer = AureliaWarmWhite,
    tertiary = AureliaCyan,
    onTertiary = AureliaBase,
    tertiaryContainer = AureliaCyanDim,
    onTertiaryContainer = AureliaWarmWhite,
    background = AureliaBase,
    onBackground = AureliaWarmWhite,
    surface = AureliaDeepGraphite,
    onSurface = AureliaWarmWhite,
    surfaceVariant = AureliaGraphite,
    onSurfaceVariant = AureliaMutedWhite,
    outline = AureliaCardBorder,
    outlineVariant = AureliaCardBorderSubtle
)

@Composable
fun AureliaTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = AureliaDarkColorScheme,
        typography = Typography,
        content = content
    )
}
