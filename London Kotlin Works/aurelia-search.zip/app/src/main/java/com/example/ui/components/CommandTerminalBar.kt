package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun CommandTerminalBar(
    isOpen: Boolean,
    onToggle: () -> Unit,
    logs: List<String>,
    input: String,
    onInputChange: (String) -> Unit,
    onExecute: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = AureliaDeepGraphite,
        shape = MaterialTheme.shapes.extraSmall,
        modifier = modifier
            .fillMaxWidth()
            .border(0.5.dp, AureliaCardBorder, MaterialTheme.shapes.extraSmall)
            .testTag("command_terminal_bar")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggle() }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = "Terminal",
                        tint = AureliaCyan,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "AURELIA TERMINAL v4.7 // COMMAND INTERPRETER",
                        style = MaterialTheme.typography.labelSmall,
                        color = AureliaWarmWhite,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = if (isOpen) "COLLAPSE" else "EXPAND CONSOLE",
                        style = MaterialTheme.typography.labelSmall,
                        color = AureliaDimText
                    )
                    Icon(
                        imageVector = if (isOpen) Icons.Default.KeyboardArrowDown else Icons.Default.KeyboardArrowUp,
                        contentDescription = "Toggle",
                        tint = AureliaDimText,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            AnimatedVisibility(visible = isOpen) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(AureliaBase)
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    // Logs list
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 120.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        items(logs) { log ->
                            Text(
                                text = log,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                color = if (log.startsWith("->")) AureliaCyan else AureliaDimText,
                                fontSize = 9.5.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Command input row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(AureliaDeepGraphite, MaterialTheme.shapes.extraSmall)
                            .border(0.5.dp, AureliaCardBorderSubtle, MaterialTheme.shapes.extraSmall)
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = ">",
                            style = MaterialTheme.typography.labelMedium,
                            fontFamily = FontFamily.Monospace,
                            color = AureliaCyan,
                            modifier = Modifier.padding(end = 6.dp)
                        )
                        BasicTextField(
                            value = input,
                            onValueChange = onInputChange,
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(onSend = { onExecute(input) }),
                            cursorBrush = SolidColor(AureliaCyan),
                            textStyle = MaterialTheme.typography.labelMedium.copy(
                                color = AureliaWarmWhite,
                                fontFamily = FontFamily.Monospace
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("terminal_input_field"),
                            decorationBox = { innerTextField ->
                                if (input.isEmpty()) {
                                    Text(
                                        text = "Type /search, /news, /market, /research, /map, /compare, /clear...",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = AureliaDimText,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    )
                                }
                                innerTextField()
                            }
                        )
                    }
                }
            }
        }
    }
}
