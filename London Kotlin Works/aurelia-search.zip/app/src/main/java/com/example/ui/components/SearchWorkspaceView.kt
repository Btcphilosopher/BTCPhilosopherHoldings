package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.SearchResultItem
import com.example.model.SynthesisData
import com.example.ui.theme.*

@Composable
fun SearchWorkspaceView(
    searchResults: List<SearchResultItem>,
    synthesis: SynthesisData?,
    selectedResultForTrace: SearchResultItem?,
    onSelectForTrace: (SearchResultItem?) -> Unit,
    onSaveResearch: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("search_workspace_view"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Intelligence synthesis panel if available
        synthesis?.let {
            AureliaIntelligencePanel(
                synthesis = it,
                onSaveResearch = onSaveResearch
            )
        }

        // Trace modal if an item is selected for provenance analysis
        selectedResultForTrace?.let { item ->
            SourceTraceModal(
                result = item,
                onClose = { onSelectForTrace(null) }
            )
        }

        // Search Results List (Research Records)
        Text(
            text = "VERIFIED RESEARCH RECORDS // CITATIONS",
            style = MaterialTheme.typography.labelSmall,
            color = AureliaDimText
        )

        searchResults.forEach { result ->
            SearchResultCard(
                result = result,
                isSelectedForTrace = selectedResultForTrace?.id == result.id,
                onTraceClick = {
                    if (selectedResultForTrace?.id == result.id) {
                        onSelectForTrace(null)
                    } else {
                        onSelectForTrace(result)
                    }
                },
                onSaveClick = onSaveResearch
            )
        }
    }
}
