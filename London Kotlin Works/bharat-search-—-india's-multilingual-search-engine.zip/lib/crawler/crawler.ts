import { indexDocument } from '../search/local-index';
import { detectScript } from '../languages';
import { CrawledPage, CrawlerStatus } from '../search/types';
import crypto from 'crypto';

const USER_AGENT = 'BharatSearchBot/1.0 (+https://bharatsearch.in/bot; bot@bharatsearch.in)';
const MAX_RESPONSE_SIZE = 2 * 1024 * 1024; // 2MB
const REQUEST_TIMEOUT_MS = 5000;

// SSRF Protection: Denylist private and reserved IP ranges & loopback
export function validateUrlForSSRF(rawUrl: string): { valid: boolean; reason?: string; url?: URL } {
  try {
    const parsed = new URL(rawUrl);

    // Only allow http and https
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return { valid: false, reason: 'Only HTTP and HTTPS protocols are permitted.' };
    }

    const hostname = parsed.hostname.toLowerCase();

    // Block localhost, link-local, loopback, cloud metadata
    const blockedHostnames = [
      'localhost',
      '127.0.0.1',
      '::1',
      '0.0.0.0',
      '169.254.169.254', // AWS/GCP/Azure metadata endpoint
      'metadata.google.internal',
      'metadata',
      'instance-data',
    ];

    if (blockedHostnames.includes(hostname)) {
      return { valid: false, reason: `Access to blocked host "${hostname}" is prohibited.` };
    }

    // IP address checks
    // Check IPv4
    const ipv4Regex = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
    const ipMatch = hostname.match(ipv4Regex);
    if (ipMatch) {
      const octet1 = parseInt(ipMatch[1], 10);
      const octet2 = parseInt(ipMatch[2], 10);

      // 127.0.0.0/8 Loopback
      if (octet1 === 127) return { valid: false, reason: 'Loopback IP addresses are prohibited.' };
      // 10.0.0.0/8 Private
      if (octet1 === 10) return { valid: false, reason: 'RFC1918 private network IPs are prohibited.' };
      // 172.16.0.0/12 Private
      if (octet1 === 172 && octet2 >= 16 && octet2 <= 31) return { valid: false, reason: 'RFC1918 private network IPs are prohibited.' };
      // 192.168.0.0/16 Private
      if (octet1 === 192 && octet2 === 168) return { valid: false, reason: 'RFC1918 private network IPs are prohibited.' };
      // 169.254.0.0/16 Link-Local
      if (octet1 === 169 && octet2 === 254) return { valid: false, reason: 'Link-local addresses are prohibited.' };
      // 0.0.0.0/8 Current network
      if (octet1 === 0) return { valid: false, reason: 'Invalid IP address.' };
    }

    return { valid: true, url: parsed };
  } catch (err: any) {
    return { valid: false, reason: `Malformed URL: ${err.message}` };
  }
}

// URL normalizer: strip tracking parameters, fragments, standardize trailing slashes
export function normalizeUrl(rawUrl: string): string {
  try {
    const url = new URL(rawUrl);
    url.hash = ''; // remove fragment

    // Strip tracking parameters
    const trackingParams = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'fbclid', 'gclid'];
    for (const p of trackingParams) {
      url.searchParams.delete(p);
    }

    // Lowercase host
    let clean = `${url.protocol}//${url.hostname.toLowerCase()}${url.pathname}`;
    if (url.search) {
      clean += url.search;
    }
    return clean;
  } catch {
    return rawUrl;
  }
}

// Robots.txt checker cache
const robotsCache: Map<string, { disallowedPaths: string[]; timestamp: number }> = new Map();

export async function checkRobotsTxt(targetUrl: URL): Promise<boolean> {
  const origin = targetUrl.origin;
  const now = Date.now();

  let entry = robotsCache.get(origin);
  if (!entry || now - entry.timestamp > 3600 * 1000) {
    // Fetch robots.txt
    const robotsUrl = `${origin}/robots.txt`;
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 3000);
      const res = await fetch(robotsUrl, {
        headers: { 'User-Agent': USER_AGENT },
        signal: controller.signal,
      });
      clearTimeout(timeout);

      if (res.ok) {
        const text = await res.text();
        const lines = text.split('\n');
        const disallowed: string[] = [];
        let isAppliesToUs = true;

        for (const line of lines) {
          const trimmed = line.trim();
          if (trimmed.toLowerCase().startsWith('user-agent:')) {
            const agent = trimmed.substring(11).trim();
            isAppliesToUs = agent === '*' || agent.toLowerCase().includes('bharatsearch');
          } else if (isAppliesToUs && trimmed.toLowerCase().startsWith('disallow:')) {
            const path = trimmed.substring(9).trim();
            if (path) disallowed.push(path);
          }
        }
        entry = { disallowedPaths: disallowed, timestamp: now };
        robotsCache.set(origin, entry);
      } else {
        entry = { disallowedPaths: [], timestamp: now };
        robotsCache.set(origin, entry);
      }
    } catch {
      entry = { disallowedPaths: [], timestamp: now };
      robotsCache.set(origin, entry);
    }
  }

  // Check path against disallowed paths
  const path = targetUrl.pathname;
  for (const dis of entry.disallowedPaths) {
    if (path.startsWith(dis)) {
      return false; // Disallowed
    }
  }
  return true; // Allowed
}

// Extract HTML metadata
export function parseHtmlContent(html: string, url: string): {
  title: string;
  headings: string[];
  snippet: string;
  text: string;
  language: string;
  ogImage?: string;
} {
  // Title
  const titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
  const title = titleMatch ? titleMatch[1].trim() : new URL(url).hostname;

  // Meta description
  const descMatch =
    html.match(/<meta[^>]*name=["']description["'][^>]*content=["']([^"']+)["']/i) ||
    html.match(/<meta[^>]*property=["']og:description["'][^>]*content=["']([^"']+)["']/i);
  let snippet = descMatch ? descMatch[1].trim() : '';

  // OG Image
  const ogImgMatch = html.match(/<meta[^>]*property=["']og:image["'][^>]*content=["']([^"']+)["']/i);
  const ogImage = ogImgMatch ? ogImgMatch[1].trim() : undefined;

  // Headings
  const headings: string[] = [];
  const hMatches = html.matchAll(/<h[123][^>]*>([^<]+)<\/h[123]>/gi);
  for (const m of hMatches) {
    if (m[1]) headings.push(m[1].trim());
  }

  // Clean body text
  let text = html
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, ' ')
    .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, ' ')
    .replace(/<noscript\b[^<]*(?:(?!<\/noscript>)<[^<]*)*<\/noscript>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();

  if (!snippet) {
    snippet = text.slice(0, 220) + '...';
  }

  // Detect language
  let language = 'en';
  const langMatch = html.match(/<html[^>]*lang=["']([a-zA-Z]{2})/i);
  if (langMatch) {
    language = langMatch[1].toLowerCase();
  } else {
    language = detectScript(title + ' ' + snippet);
  }

  return { title, headings, snippet, text: text.slice(0, 8000), language, ogImage };
}

// Crawler State & Log Store
const crawlLogs: Array<{
  timestamp: string;
  url: string;
  status: 'crawled' | 'indexed' | 'skipped' | 'blocked' | 'error';
  message: string;
}> = [
  {
    timestamp: new Date().toISOString(),
    url: 'https://isro.gov.in',
    status: 'indexed',
    message: 'Pre-indexed sovereign seed: ISRO official missions & space science.',
  },
  {
    timestamp: new Date().toISOString(),
    url: 'https://npci.org.in/what-we-do/upi',
    status: 'indexed',
    message: 'Pre-indexed sovereign seed: NPCI UPI digital payments infrastructure.',
  },
  {
    timestamp: new Date().toISOString(),
    url: 'https://varanasi.nic.in',
    status: 'indexed',
    message: 'Pre-indexed sovereign seed: Varanasi Heritage, Ghats & Kashi Vishwanath Dham.',
  },
];

let isCrawlRunning = false;
const crawledHashes: Set<string> = new Set();
let indexedPagesCount = 3;

export async function crawlSingleUrl(targetRawUrl: string): Promise<{
  success: boolean;
  message: string;
  page?: CrawledPage;
}> {
  const normalized = normalizeUrl(targetRawUrl);
  const ssrfCheck = validateUrlForSSRF(normalized);

  if (!ssrfCheck.valid || !ssrfCheck.url) {
    crawlLogs.unshift({
      timestamp: new Date().toISOString(),
      url: targetRawUrl,
      status: 'blocked',
      message: `SSRF Blocked: ${ssrfCheck.reason}`,
    });
    return { success: false, message: ssrfCheck.reason || 'Blocked by SSRF rules.' };
  }

  const urlObj = ssrfCheck.url;

  // Check robots.txt
  const robotsAllowed = await checkRobotsTxt(urlObj);
  if (!robotsAllowed) {
    crawlLogs.unshift({
      timestamp: new Date().toISOString(),
      url: normalized,
      status: 'skipped',
      message: 'Robots.txt Disallow rule matched.',
    });
    return { success: false, message: 'URL is disallowed by robots.txt rules.' };
  }

  // Fetch page with timeout & size cap
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

    const response = await fetch(normalized, {
      headers: {
        'User-Agent': USER_AGENT,
        Accept: 'text/html,application/xhtml+xml',
      },
      signal: controller.signal,
    });
    clearTimeout(timeout);

    if (!response.ok) {
      crawlLogs.unshift({
        timestamp: new Date().toISOString(),
        url: normalized,
        status: 'error',
        message: `HTTP error ${response.status} ${response.statusText}`,
      });
      return { success: false, message: `Server returned status ${response.status}` };
    }

    const contentType = response.headers.get('content-type') || '';
    if (!contentType.includes('text/html') && !contentType.includes('application/xhtml')) {
      crawlLogs.unshift({
        timestamp: new Date().toISOString(),
        url: normalized,
        status: 'skipped',
        message: `Skipped non-HTML content type: ${contentType}`,
      });
      return { success: false, message: 'Non-HTML resource skipped.' };
    }

    const html = await response.text();
    if (html.length > MAX_RESPONSE_SIZE) {
      crawlLogs.unshift({
        timestamp: new Date().toISOString(),
        url: normalized,
        status: 'skipped',
        message: 'Page exceeds maximum 2MB size limit.',
      });
      return { success: false, message: 'Page size exceeded 2MB limit.' };
    }

    // Deduplication via content hash
    const contentHash = crypto.createHash('sha256').update(html.slice(0, 5000)).digest('hex');
    if (crawledHashes.has(contentHash)) {
      crawlLogs.unshift({
        timestamp: new Date().toISOString(),
        url: normalized,
        status: 'skipped',
        message: 'Duplicate content hash detected, skipped.',
      });
      return { success: false, message: 'Duplicate content already indexed.' };
    }
    crawledHashes.add(contentHash);

    // Extract metadata
    const parsed = parseHtmlContent(html, normalized);

    const page: CrawledPage = {
      url: normalized,
      title: parsed.title,
      headings: parsed.headings,
      snippet: parsed.snippet,
      text: parsed.text,
      language: parsed.language,
      crawledAt: new Date().toISOString(),
      domain: urlObj.hostname,
      ogImage: parsed.ogImage,
      contentHash,
    };

    // Index into local search engine
    indexDocument({
      id: `crawled-${crypto.randomUUID()}`,
      title: page.title,
      url: page.url,
      displayUrl: `${page.domain} > ${urlObj.pathname.slice(1, 40) || 'home'}`,
      snippet: page.snippet,
      body: `${page.headings.join(' ')} ${page.text}`,
      domain: page.domain,
      category: 'web',
      language: page.language,
      publishedDate: new Date().toISOString().split('T')[0],
      thumbnail: page.ogImage,
      metadata: {
        isSovereignIndexed: true,
        crawledAt: page.crawledAt,
        author: 'BharatSearchBot Crawler',
      },
    });

    indexedPagesCount++;

    crawlLogs.unshift({
      timestamp: page.crawledAt,
      url: normalized,
      status: 'indexed',
      message: `Indexed: "${page.title.slice(0, 50)}" (${parsed.language.toUpperCase()})`,
    });

    return { success: true, message: 'Page crawled and indexed successfully.', page };
  } catch (err: any) {
    const errorMsg = err.name === 'AbortError' ? 'Request timed out after 5 seconds' : err.message;
    crawlLogs.unshift({
      timestamp: new Date().toISOString(),
      url: normalized,
      status: 'error',
      message: errorMsg,
    });
    return { success: false, message: errorMsg };
  }
}

export function getCrawlerStatus(): CrawlerStatus {
  return {
    isRunning: isCrawlRunning,
    indexedCount: indexedPagesCount,
    crawlHistoryCount: crawlLogs.length,
    activeSeeds: [
      'https://isro.gov.in',
      'https://pib.gov.in',
      'https://digitalindia.gov.in',
      'https://npci.org.in',
      'https://en.wikipedia.org/wiki/India',
    ],
    recentLogs: crawlLogs.slice(0, 20),
  };
}
