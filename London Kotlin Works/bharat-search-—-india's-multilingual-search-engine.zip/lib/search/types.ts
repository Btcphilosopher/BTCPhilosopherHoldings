export type SearchCategory = 'web' | 'news' | 'images' | 'videos' | 'maps' | 'shopping';

export interface SearchResultItem {
  id: string;
  title: string;
  url: string;
  displayUrl: string;
  snippet: string;
  domain: string;
  category: SearchCategory;
  publishedDate?: string;
  language?: string;
  thumbnail?: string;
  provider: 'local-index' | 'live-web' | 'crawler-engine' | 'demo-archive';
  score?: number;
  metadata?: {
    author?: string;
    imageWidth?: number;
    imageHeight?: number;
    videoDuration?: string;
    price?: string;
    currency?: string;
    rating?: number;
    reviewCount?: number;
    merchant?: string;
    address?: string;
    coordinates?: [number, number];
    isSovereignIndexed?: boolean;
    crawledAt?: string;
  };
}

export interface KnowledgeCard {
  title: string;
  subtitle: string;
  description: string;
  imageUrl?: string;
  sourceName: string;
  sourceUrl: string;
  attributes: { label: string; value: string }[];
  officialPortalUrl?: string;
}

export interface SearchQueryOptions {
  q: string;
  lang?: string;
  region?: 'in' | 'all';
  page?: number;
  pageSize?: number;
  safeSearch?: boolean;
  category?: SearchCategory;
  source?: 'auto' | 'local' | 'web';
  timeFilter?: 'all' | 'd' | 'w' | 'm' | 'y';
}

export interface SearchResponse {
  originalQuery: string;
  normalizedQuery: string;
  executionTimeMs: number;
  totalResults: number;
  page: number;
  pageSize: number;
  totalPages: number;
  results: SearchResultItem[];
  provider: string;
  lang: string;
  detectedLang: string;
  spellingSuggestion?: string;
  knowledgeCard?: KnowledgeCard;
  isFallback?: boolean;
}

export interface CrawlSeedRequest {
  url: string;
  maxPages?: number;
  depth?: number;
}

export interface CrawledPage {
  url: string;
  title: string;
  headings: string[];
  snippet: string;
  text: string;
  language: string;
  crawledAt: string;
  domain: string;
  ogImage?: string;
  contentHash: string;
}

export interface CrawlerStatus {
  isRunning: boolean;
  indexedCount: number;
  crawlHistoryCount: number;
  activeSeeds: string[];
  recentLogs: Array<{
    timestamp: string;
    url: string;
    status: 'crawled' | 'indexed' | 'skipped' | 'blocked' | 'error';
    message: string;
  }>;
}
