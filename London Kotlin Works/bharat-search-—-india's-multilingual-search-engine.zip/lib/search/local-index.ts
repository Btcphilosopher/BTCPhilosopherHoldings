import { SearchCategory, SearchResultItem, KnowledgeCard } from './types';
import { detectScript } from '../languages';

export interface IndexDocument {
  id: string;
  title: string;
  url: string;
  displayUrl: string;
  snippet: string;
  body: string;
  domain: string;
  category: SearchCategory;
  language: string;
  publishedDate?: string;
  thumbnail?: string;
  metadata?: Record<string, any>;
  terms?: Record<string, number>; // Term frequencies
  docLength?: number;
}

// In-memory persistent sovereign document store
let sovereignDocuments: IndexDocument[] = [];
let invertedIndex: Map<string, Array<{ docId: string; tf: number }>> = new Map();
let docLengthTable: Map<string, number> = new Map();
let avgDocLength = 50;

// Tokenizer & normalizer
export function tokenize(text: string): string[] {
  if (!text) return [];
  // Tokenize words, supporting Devanagari, Tamil, Telugu, Bengali, Arabic/Urdu, etc.
  return text
    .toLowerCase()
    .replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?"'’“”]/g, ' ')
    .split(/\s+/)
    .filter((t) => t.length > 1);
}

// Compute BM25 score
function scoreBM25(
  queryTokens: string[],
  doc: IndexDocument,
  totalDocs: number,
  k1 = 1.2,
  b = 0.75
): number {
  let score = 0;
  const docLen = docLengthTable.get(doc.id) || avgDocLength;
  const terms = doc.terms || {};

  for (const qToken of queryTokens) {
    // Exact or prefix match
    let tf = terms[qToken] || 0;
    if (tf === 0) {
      // Substring check for Indian scripts
      for (const term in terms) {
        if (term.includes(qToken) || qToken.includes(term)) {
          tf += terms[term] * 0.7;
        }
      }
    }

    if (tf > 0) {
      const postings = invertedIndex.get(qToken) || [];
      const df = postings.length || 1;
      const idf = Math.log((totalDocs - df + 0.5) / (df + 0.5) + 1);
      const numerator = tf * (k1 + 1);
      const denominator = tf + k1 * (1 - b + b * (docLen / (avgDocLength || 1)));
      score += idf * (numerator / denominator);
    }
  }

  // Field boosting
  const queryLower = queryTokens.join(' ');
  const titleLower = doc.title.toLowerCase();
  const snippetLower = doc.snippet.toLowerCase();

  // Title boost
  for (const qToken of queryTokens) {
    if (titleLower.includes(qToken)) {
      score += 3.5;
    }
  }

  // Exact phrase match bonus
  if (titleLower.includes(queryLower)) {
    score += 5.0;
  } else if (snippetLower.includes(queryLower)) {
    score += 2.5;
  }

  return score;
}

export function indexDocument(doc: Omit<IndexDocument, 'terms' | 'docLength'>) {
  const fullText = `${doc.title} ${doc.snippet} ${doc.body}`;
  const tokens = tokenize(fullText);
  const tfMap: Record<string, number> = {};

  for (const token of tokens) {
    tfMap[token] = (tfMap[token] || 0) + 1;
  }

  const completeDoc: IndexDocument = {
    ...doc,
    terms: tfMap,
    docLength: tokens.length,
  };

  // Remove existing if replacing
  sovereignDocuments = sovereignDocuments.filter((d) => d.id !== doc.id);
  sovereignDocuments.push(completeDoc);

  // Update inverted index
  docLengthTable.set(doc.id, tokens.length);
  const totalLength = Array.from(docLengthTable.values()).reduce((a, b) => a + b, 0);
  avgDocLength = totalLength / sovereignDocuments.length;

  for (const [term, tf] of Object.entries(tfMap)) {
    const list = invertedIndex.get(term) || [];
    list.push({ docId: doc.id, tf });
    invertedIndex.set(term, list);
  }
}

// Initial Sovereign Seed Corpus
const SEED_DOCUMENTS: Omit<IndexDocument, 'terms' | 'docLength'>[] = [
  // --- WEB & CIVIC INFRASTRUCTURE ---
  {
    id: 'gov-upi-npci',
    title: 'UPI - Unified Payments Interface | National Payments Corporation of India (NPCI)',
    url: 'https://www.npci.org.in/what-we-do/upi/product-overview',
    displayUrl: 'www.npci.org.in > what-we-do > upi',
    snippet: 'Unified Payments Interface (UPI) is an instant real-time payment system developed by NPCI facilitating inter-bank peer-to-peer and person-to-merchant transactions.',
    body: 'UPI instant payments digital public infrastructure digital india QR code transactions phonepe googlepay paytm bhim npci reserve bank of india banking 24x7 cashless economy fintech sovereign payment rails',
    domain: 'npci.org.in',
    category: 'web',
    language: 'en',
    publishedDate: '2026-03-15',
    metadata: { isSovereignIndexed: true, author: 'NPCI Digital India' },
  },
  {
    id: 'gov-digilocker',
    title: 'DigiLocker - Sovereign Digital Document Wallet | Digital India',
    url: 'https://www.digilocker.gov.in',
    displayUrl: 'www.digilocker.gov.in',
    snippet: 'DigiLocker provides secure cloud-based access to authentic digital documents including Driving License, Vehicle RC, Academic marksheets, and PAN cards.',
    body: 'DigiLocker paperless governance ministry of electronics and information technology MeitY digital locker identity aadhaar verification official certificates',
    domain: 'digilocker.gov.in',
    category: 'web',
    language: 'en',
    publishedDate: '2026-02-10',
    metadata: { isSovereignIndexed: true },
  },
  {
    id: 'gov-isro-chandrayaan3',
    title: 'Chandrayaan-3 Lunar Mission Overview & Science Results | ISRO',
    url: 'https://www.isro.gov.in/Chandrayaan3_Details.html',
    displayUrl: 'www.isro.gov.in > missions > chandrayaan3',
    snippet: 'Chandrayaan-3 achieved successful soft landing near the Moon South Pole on Shiv Shakti Point. Pragyan rover and Vikram lander conducted in-situ elemental analysis of lunar soil.',
    body: 'ISRO Chandrayaan-3 Vikram lander Pragyan rover moon south pole Shiv Shakti point Indian Space Research Organisation Sriharikota lunar exploration space science Aditya L1 Gaganyaan',
    domain: 'isro.gov.in',
    category: 'web',
    language: 'en',
    publishedDate: '2026-01-20',
    metadata: { isSovereignIndexed: true, author: 'ISRO Science Directorate' },
  },
  {
    id: 'gov-aadhaar-uidai',
    title: 'UIDAI - Unique Identification Authority of India | MyAadhaar Portal',
    url: 'https://uidai.gov.in',
    displayUrl: 'uidai.gov.in',
    snippet: 'Official portal of Unique Identification Authority of India (UIDAI). Download e-Aadhaar, check Aadhaar status, update demographic details, and locate enrollment centres.',
    body: 'UIDAI Aadhaar 12-digit unique identity biometric authentication iris fingerprint e-aadhaar government subsidies direct benefit transfer digital verification',
    domain: 'uidai.gov.in',
    category: 'web',
    language: 'en',
    publishedDate: '2026-04-01',
    metadata: { isSovereignIndexed: true },
  },
  {
    id: 'heritage-varanasi-ghats',
    title: 'Varanasi Ghats: History, Architecture and Kashi Vishwanath Corridor',
    url: 'https://varanasi.nic.in/kashi-vishwanath-dham/',
    displayUrl: 'varanasi.nic.in > tourism > ghats',
    snippet: 'Varanasi, also known as Kashi and Benares, is one of the oldest continuously inhabited cities on Earth. The Ghats along the Ganges river host sacred evening Ganga Aarti ceremonies.',
    body: 'Varanasi Kashi Vishwanath Ganga ghats Dashashwamedh Manikarnika Assi spiritual cultural heritage Uttar Pradesh ancient Indian civilization ghat sunset temples ghats of kashi',
    domain: 'varanasi.nic.in',
    category: 'web',
    language: 'en',
    publishedDate: '2026-03-01',
    metadata: { isSovereignIndexed: true },
  },

  // --- MULTILINGUAL SOVEREIGN PAGES (Hindi, Tamil, Telugu, Bengali, Urdu) ---
  {
    id: 'hi-isro-chandrayaan',
    title: 'चंद्रयान-3 मिशन: भारतीय अंतरिक्ष अनुसंधान संगठन (इसरो) की ऐतिहासिक उपलब्धि',
    url: 'https://www.isro.gov.in/hi/chandrayaan3.html',
    displayUrl: 'isro.gov.in > hi > chandrayaan3',
    snippet: 'इसरो के चंद्रयान-3 ने चंद्रमा के दक्षिणी ध्रुव पर शिव शक्ति बिंदु पर सफल सॉफ्ट लैंडिंग कर इतिहास रचा। विक्रम लैंडर और प्रज्ञान रोवर ने महत्वपूर्ण वैज्ञानिक डेटा भेजा।',
    body: 'चंद्रयान इसरो अंतरिक्ष चंद्रमा विक्रम लैंडर प्रज्ञान रोवर भारत विज्ञान तकनीक शिव शक्ति पॉइंट अंतरिक्ष अनुसंधान',
    domain: 'isro.gov.in',
    category: 'web',
    language: 'hi',
    publishedDate: '2026-02-18',
    metadata: { isSovereignIndexed: true },
  },
  {
    id: 'hi-varanasi-kashi',
    title: 'काशी विश्वनाथ धाम और वाराणसी के ऐतिहासिक घाट: संपूर्ण दर्शन एवं जानकारी',
    url: 'https://kashivishwanath.nic.in',
    displayUrl: 'kashivishwanath.nic.in',
    snippet: 'वाराणसी के 84 पवित्र घाटों और भव्य काशी विश्वनाथ धाम की ऐतिहासिक धरोहर। दशाश्वमेध घाट पर होने वाली गंगा आरती विश्व प्रसिद्ध है।',
    body: 'वाराणसी काशी विश्वनाथ गंगा आरती दशाश्वमेध घाट मणिकर्णिका घाट उत्तर प्रदेश प्राचीन भारत संस्कृति तीर्थ',
    domain: 'kashivishwanath.nic.in',
    category: 'web',
    language: 'hi',
    publishedDate: '2026-03-10',
    metadata: { isSovereignIndexed: true },
  },
  {
    id: 'ta-thirukkural',
    title: 'திருக்குறள் - திருவள்ளுவர் அருளிய உலகப் பொதுமறை | Tamil Virtual Academy',
    url: 'https://www.tamilvu.org/library/thirukkural',
    displayUrl: 'tamilvu.org > library > thirukkural',
    snippet: 'திருக்குறள் அறத்துப்பால், பொருட்பால், காமத்துப்பால் ஆகிய மூன்று பால்களையும் 1330 குறள்களையும் கொண்ட தமிழ் இலக்கியத்தின் தலைசிறந்த நீதி நூல் ஆகும்.',
    body: 'திருக்குறள் திருவள்ளுவர் தமிழ் இலக்கியம் நீதிநூல் சங்கத்தமிழ் பண்பாடு அறம் பொருள் இன்பம் வாழ்வியல் நெறி',
    domain: 'tamilvu.org',
    category: 'web',
    language: 'ta',
    publishedDate: '2026-01-15',
    metadata: { isSovereignIndexed: true },
  },
  {
    id: 'te-digital-india',
    title: 'డిజిటల్ ఇండియా: భారతీయ సాంకేతిక విప్లవం మరియు ప్రజారోగ్య సేవలు',
    url: 'https://digitalindia.gov.in/te',
    displayUrl: 'digitalindia.gov.in > te',
    snippet: 'డిజిటల్ ఇండియా కార్యక్రమం ద్వారా ప్రతి పౌరుడికి వేగవంతమైన ఇంటర్నెట్, యూపీఐ డిజిటల్ చెల్లింపులు, ఈ-సేవలు అందుబాటులోకి వచ్చాయి.',
    body: 'డిజిటల్ ఇండియా సాంకేతికత యూపీఐ ఆధార్ ఈ-సేవలు భారత్ ఇంటర్నెట్ పరిపాలన గవర్నెన్స్',
    domain: 'digitalindia.gov.in',
    category: 'web',
    language: 'te',
    publishedDate: '2026-02-22',
    metadata: { isSovereignIndexed: true },
  },
  {
    id: 'bn-tagore-gitanjali',
    title: 'রবীন্দ্রনাথ ঠাকুর এবং গীতাঞ্জলি: বাংলা সাহিত্যের নোবেল গৌরব',
    url: 'https://visvabharati.ac.in/tagore',
    displayUrl: 'visvabharati.ac.in > rabindranath-tagore',
    snippet: '১৯১৩ সালে গীতাঞ্জলি কাব্যগ্রন্থের জন্য সাহিত্যে প্রথম এশীয় হিসেবে নোবেল পুরস্কার পান রবীন্দ্রনাথ ঠাকুর। শান্তিনিকেতনে তাঁর বিশ্বভারতী বিশ্ববিদ্যালয় স্থাপিত হয়।',
    body: 'রবীন্দ্রনাথ ঠাকুর গীতাঞ্জলি নোবেল পুরস্কার শান্তিনিকেতন বিশ্বভারতী বাংলা সাহিত্য সংগীত কবিতা জাতীয় সংগীত',
    domain: 'visvabharati.ac.in',
    category: 'web',
    language: 'bn',
    publishedDate: '2026-03-05',
    metadata: { isSovereignIndexed: true },
  },
  {
    id: 'ur-ghalib-literature',
    title: 'مرزا اسد اللہ خان غالب: اردو شاعری اور دلی کے عظیم ادبی ورثے کی داستان',
    url: 'https://rekhta.org/poets/mirza-ghalib',
    displayUrl: 'rekhta.org > poets > mirza-ghalib',
    snippet: 'مرزا غالب برصغیر پاک و ہند کے سب سے عظیم اردو اور فارسی شاعر مانے جاتے ہیں۔ ان کے خطوط اور غزلیں اردو ادب کا شاہکار ہیں۔',
    body: 'مرزا اسد اللہ غالب اردو شاعری غزل دیوان غالب دلی ادب اردو ادب ہندوستان شاعری',
    domain: 'rekhta.org',
    category: 'web',
    language: 'ur',
    publishedDate: '2026-02-14',
    metadata: { isSovereignIndexed: true },
  },

  // --- NEWS CATEGORY ---
  {
    id: 'news-pib-semiconductor',
    title: 'India Semiconductor Mission Approves Commercial Fab in Gujarat and Dholera',
    url: 'https://pib.gov.in/PressReleasePage.aspx?PRID=2010892',
    displayUrl: 'pib.gov.in > press-release',
    snippet: 'The Union Cabinet approves three semiconductor units under India Semiconductor Mission (ISM) with total investment exceeding ₹1.26 lakh crore.',
    body: 'semiconductor chips electronics manufacturing Gujarat Dholera Tata Micron investment modern tech export high technology electronics',
    domain: 'pib.gov.in',
    category: 'news',
    language: 'en',
    publishedDate: '2026-04-12',
    thumbnail: 'https://picsum.photos/seed/semiconductor/400/250',
    metadata: { isSovereignIndexed: true, author: 'Press Information Bureau' },
  },
  {
    id: 'news-isro-aditya-l1',
    title: 'Aditya-L1 Completes Two Years of Solar Flare Observations at Sun-Earth L1 Point',
    url: 'https://isro.gov.in/adityal1_update.html',
    displayUrl: 'isro.gov.in > news',
    snippet: 'India’s maiden solar observatory Aditya-L1 captures high-resolution coronal mass ejections and solar coronal magnetic fields from halo orbit around Lagrangian point L1.',
    body: 'Aditya L1 solar mission Sun coronagraph halo orbit ISRO space physics astrophysics coronal mass ejection',
    domain: 'isro.gov.in',
    category: 'news',
    language: 'en',
    publishedDate: '2026-04-10',
    thumbnail: 'https://picsum.photos/seed/adityal1/400/250',
    metadata: { isSovereignIndexed: true, author: 'ISRO Media Bureau' },
  },
  {
    id: 'news-upi-global',
    title: 'UPI Expands Direct Cross-Border QR Payment Links with UAE, Singapore, France and Nepal',
    url: 'https://economictimes.indiatimes.com/tech/technology/upi-global-expansion',
    displayUrl: 'economictimes.indiatimes.com > tech',
    snippet: 'National Payments Corporation of India (NPCI International) records 45% increase in cross-border QR merchant transactions across international tourism hubs.',
    body: 'UPI international cross border remittances Singapore UAE France Nepal fintech digital payment currency exchange',
    domain: 'economictimes.indiatimes.com',
    category: 'news',
    language: 'en',
    publishedDate: '2026-04-15',
    thumbnail: 'https://picsum.photos/seed/upiglobal/400/250',
    metadata: { isSovereignIndexed: true, author: 'Economic Times Tech Desk' },
  },
  {
    id: 'news-green-energy-khavda',
    title: 'Khavda Renewable Energy Park in Gujarat Crosses 5,000 MW Operational Capacity',
    url: 'https://mnre.gov.in/khavda-energy-park-milestone',
    displayUrl: 'mnre.gov.in > green-energy',
    snippet: 'The world largest hybrid solar and wind energy park in the Rann of Kutch expands rapid clean electricity generation for the national grid.',
    body: 'Khavda Gujarat renewable clean green energy solar wind Rann of Kutch net zero emissions Ministry of New and Renewable Energy',
    domain: 'mnre.gov.in',
    category: 'news',
    language: 'en',
    publishedDate: '2026-04-08',
    thumbnail: 'https://picsum.photos/seed/khavda/400/250',
    metadata: { isSovereignIndexed: true, author: 'MNRE Press' },
  },

  // --- IMAGES CATEGORY ---
  {
    id: 'img-varanasi-sunset',
    title: 'Ancient Varanasi Riverfront Ghats at Golden Sunset',
    url: 'https://www.incredibleindia.org/content/incredibleindia/en/destinations/varanasi.html',
    displayUrl: 'incredibleindia.org > varanasi-sunset.jpg',
    snippet: 'Vibrant sunset over the holy river Ganga with traditional wooden pilgrim boats and temple spires in Varanasi, Uttar Pradesh.',
    body: 'varanasi ghats sunset ganga river temples boats golden hour kashi kashi vishwanath india heritage photo',
    domain: 'incredibleindia.org',
    category: 'images',
    language: 'en',
    thumbnail: '/bharat_hero_bg.jpg',
    metadata: {
      imageWidth: 1920,
      imageHeight: 1080,
      author: 'Incredible India Archives',
    },
  },
  {
    id: 'img-chandrayaan-landing',
    title: 'Chandrayaan-3 Vikram Lander Standing on Lunar Regolith at Shiv Shakti Point',
    url: 'https://isro.gov.in/chandrayaan3_gallery.html',
    displayUrl: 'isro.gov.in > gallery > vikram_lander.jpg',
    snippet: 'Historic high-resolution capture of Vikram lander on the southern polar surface of the Moon taken by Pragyan Navigation Camera (NavCam).',
    body: 'chandrayaan vikram lander pragyan rover moon south pole isro space photography astronomy',
    domain: 'isro.gov.in',
    category: 'images',
    language: 'en',
    thumbnail: 'https://picsum.photos/seed/chandrayaanlanding/800/600',
    metadata: { imageWidth: 2048, imageHeight: 1536, author: 'ISRO Science Data Hub' },
  },
  {
    id: 'img-taj-mahal-dawn',
    title: 'Taj Mahal at Sunrise with Pristine Water Garden Reflection',
    url: 'https://asi.nic.in/monuments/taj-mahal',
    displayUrl: 'asi.nic.in > taj-mahal-dawn.jpg',
    snippet: 'White marble mausoleum built by Mughal Emperor Shah Jahan on the banks of Yamuna river in Agra, a UNESCO World Heritage Site.',
    body: 'taj mahal agra marble architecture reflection pool yamuna wonder of the world unesco heritage',
    domain: 'asi.nic.in',
    category: 'images',
    language: 'en',
    thumbnail: 'https://picsum.photos/seed/tajmahaldawn/800/600',
    metadata: { imageWidth: 2400, imageHeight: 1600, author: 'Archaeological Survey of India' },
  },
  {
    id: 'img-hampi-stone-chariot',
    title: 'Iconic Monolithic Stone Chariot at Vijaya Vittala Temple, Hampi',
    url: 'https://karnatakatourism.org/destination/hampi',
    displayUrl: 'karnatakatourism.org > hampi-chariot.jpg',
    snippet: 'Intricately carved 16th-century stone chariot dedicated to Garuda inside the Vittala temple complex at Hampi, Karnataka.',
    body: 'hampi stone chariot vittala temple vijayanagara empire karnataka stone carving dravidian architecture unesco',
    domain: 'karnatakatourism.org',
    category: 'images',
    language: 'en',
    thumbnail: 'https://picsum.photos/seed/hampichariot/800/600',
    metadata: { imageWidth: 1920, imageHeight: 1280, author: 'Karnataka Tourism Board' },
  },

  // --- VIDEOS CATEGORY ---
  {
    id: 'vid-isro-softlanding',
    title: 'Live Telecast: Historic Landing of Chandrayaan-3 on the Moon',
    url: 'https://youtube.com/watch?v=DLA_64yz8Ss',
    displayUrl: 'youtube.com > ISRO Official Channel',
    snippet: 'Official replay of ISRO Mission Operations Complex (MOX) telemetry and descent thruster sequence during the soft landing on lunar south pole.',
    body: 'chandrayaan landing video stream isro scientists applause vikram touchdown lunar mission',
    domain: 'youtube.com',
    category: 'videos',
    language: 'en',
    thumbnail: 'https://picsum.photos/seed/isrovid/640/360',
    metadata: { videoDuration: '1:12:45', author: 'ISRO Official', reviewCount: 8400000 },
  },
  {
    id: 'vid-ganga-aarti',
    title: 'Divine Evening Ganga Aarti Ceremony at Dashashwamedh Ghat, Varanasi',
    url: 'https://youtube.com/watch?v=varanasi_aarti_4k',
    displayUrl: 'youtube.com > Incredible India Culture',
    snippet: 'Ultra-HD 4K documentary footage of Vedic chants, brass oil lamps, conch shells, and spiritual devotion at Dashashwamedh Ghat in Varanasi.',
    body: 'varanasi ganga aarti video dashashwamedh ghat vedic chants kashi tourism documentary',
    domain: 'youtube.com',
    category: 'videos',
    language: 'en',
    thumbnail: 'https://picsum.photos/seed/gangavideo/640/360',
    metadata: { videoDuration: '24:18', author: 'Incredible India Culture', reviewCount: 1200000 },
  },

  // --- MAPS CATEGORY ---
  {
    id: 'map-varanasi-ghats',
    title: 'Dashashwamedh Ghat & Kashi Vishwanath Corridor',
    url: 'https://www.openstreetmap.org/#map=16/25.3076/83.0107',
    displayUrl: 'maps.bharatsearch.in > varanasi',
    snippet: 'Prominent riverfront ghat on the holy Ganges in Varanasi, directly adjacent to the newly constructed Kashi Vishwanath Dham corridor.',
    body: 'varanasi kashi ghats dashashwamedh riverfront uttar pradesh map location coordinates',
    domain: 'openstreetmap.org',
    category: 'maps',
    language: 'en',
    metadata: {
      address: 'Dashashwamedh Ghat Rd, Godowlia, Varanasi, Uttar Pradesh 221001',
      coordinates: [25.3076, 83.0107],
    },
  },
  {
    id: 'map-isro-hq',
    title: 'ISRO Headquarters - Antariksh Bhavan',
    url: 'https://www.openstreetmap.org/#map=16/13.0336/77.5645',
    displayUrl: 'maps.bharatsearch.in > isro-hq',
    snippet: 'Central headquarters of the Indian Space Research Organisation (ISRO) and Department of Space, Government of India.',
    body: 'isro antariksh bhavan new bel road bengaluru karnataka space headquarters address',
    domain: 'openstreetmap.org',
    category: 'maps',
    language: 'en',
    metadata: {
      address: 'Antariksh Bhavan, New BEL Road, Bengaluru, Karnataka 560094',
      coordinates: [13.0336, 77.5645],
    },
  },

  // --- SHOPPING CATEGORY ---
  {
    id: 'shop-banarasi-saree',
    title: 'Authentic Handwoven Pure Katan Silk Banarasi Saree with Zari Motifs',
    url: 'https://www.khadiindia.gov.in/handloom/banarasi-silk',
    displayUrl: 'khadiindia.gov.in > handlooms > banarasi',
    snippet: 'Handcrafted by master weavers of Varanasi with GI tag certification. Pure mulberry katan silk with intricate golden zari floral jaal.',
    body: 'banarasi saree silk handloom zari traditional attire varanasi khadi india clothing ethnic wear',
    domain: 'khadiindia.gov.in',
    category: 'shopping',
    language: 'en',
    thumbnail: 'https://picsum.photos/seed/banarasisaree/400/400',
    metadata: {
      price: '14,850',
      currency: '₹',
      merchant: 'Khadi India & National Handloom Dev',
      rating: 4.8,
      reviewCount: 342,
    },
  },
  {
    id: 'shop-darjeeling-tea',
    title: 'Single Estate First Flush Darjeeling Organic Whole Leaf Black Tea (250g)',
    url: 'https://www.teaboard.gov.in/certified-darjeeling-tea',
    displayUrl: 'teaboard.gov.in > certified-tea',
    snippet: '100% Certified GI Tag Darjeeling Tea plucked from high-altitude Himalayan estates with signature muscatel flavor profile.',
    body: 'darjeeling tea organic whole leaf himalayan first flush tea board of india beverage gourmet',
    domain: 'teaboard.gov.in',
    category: 'shopping',
    language: 'en',
    thumbnail: 'https://picsum.photos/seed/darjeelingtea/400/400',
    metadata: {
      price: '1,250',
      currency: '₹',
      merchant: 'Tea Board of India Certified Estates',
      rating: 4.9,
      reviewCount: 890,
    },
  },
];

// Initialize index with seed documents
export function initializeIndex() {
  if (sovereignDocuments.length === 0) {
    for (const doc of SEED_DOCUMENTS) {
      indexDocument(doc);
    }
  }
}

// Knowledge Graph Cards for Instant Answers
const KNOWLEDGE_GRAPH: Record<string, KnowledgeCard> = {
  chandrayaan: {
    title: 'Chandrayaan-3',
    subtitle: 'Indian Lunar Exploration Mission · ISRO',
    description: 'Chandrayaan-3 was the third mission in the Chandrayaan programme, launched by the Indian Space Research Organisation (ISRO). On 23 August 2023, the Vikram lander and Pragyan rover successfully soft-landed near the lunar south pole, making India the first nation to land in this region.',
    imageUrl: 'https://picsum.photos/seed/chandrayaaninfo/600/400',
    sourceName: 'ISRO Official & Science Portal',
    sourceUrl: 'https://www.isro.gov.in/Chandrayaan3.html',
    officialPortalUrl: 'https://www.isro.gov.in',
    attributes: [
      { label: 'Agency', value: 'Indian Space Research Organisation (ISRO)' },
      { label: 'Launch Date', value: '14 July 2023, 14:35 IST' },
      { label: 'Landing Date', value: '23 August 2023, 18:04 IST' },
      { label: 'Landing Site', value: 'Statio Shiv Shakti (69.37°S 32.35°E)' },
      { label: 'Launch Vehicle', value: 'LVM3 M4' },
      { label: 'Payloads', value: 'ChaSTE, ILSA, LP, APXS, LIBS' },
    ],
  },
  upi: {
    title: 'Unified Payments Interface (UPI)',
    subtitle: 'Instant Real-time Payment System of India',
    description: 'UPI is an instant payment system developed by the National Payments Corporation of India (NPCI) and regulated by the Reserve Bank of India. It powers multiple bank accounts into a single mobile application, merging several banking features, seamless fund routing, and merchant payments into one hood.',
    imageUrl: 'https://picsum.photos/seed/upiinfo/600/400',
    sourceName: 'NPCI & Reserve Bank of India',
    sourceUrl: 'https://www.npci.org.in/what-we-do/upi/product-overview',
    officialPortalUrl: 'https://www.bhimupi.org.in',
    attributes: [
      { label: 'Developer', value: 'NPCI (National Payments Corporation of India)' },
      { label: 'Initial Launch', value: '11 April 2016' },
      { label: 'Monthly Volume', value: 'Over 13 Billion Transactions' },
      { label: 'Key Protocols', value: 'Virtual Payment Address (VPA), QR Code' },
      { label: 'Global Acceptance', value: 'UAE, Singapore, France, Nepal, Bhutan, Mauritius' },
    ],
  },
  varanasi: {
    title: 'Varanasi (Kashi / Benares)',
    subtitle: 'Sacred City on the Ganges River · Uttar Pradesh, India',
    description: 'Varanasi is one of the world oldest continuously inhabited cities and the spiritual capital of India. Located on the sacred river Ganges, it is celebrated for its 84 historic stone ghats, the revered Kashi Vishwanath Temple, Banarasi silk weaving, classical music, and the sacred evening Ganga Aarti.',
    imageUrl: '/bharat_hero_bg.jpg',
    sourceName: 'District Administration Varanasi & Ministry of Tourism',
    sourceUrl: 'https://varanasi.nic.in',
    officialPortalUrl: 'https://kashivishwanath.nic.in',
    attributes: [
      { label: 'State', value: 'Uttar Pradesh, India' },
      { label: 'Historical Names', value: 'Kashi, Benares, Anandavan' },
      { label: 'Sacred River', value: 'Ganga (Ganges)' },
      { label: 'Major Sites', value: 'Kashi Vishwanath Dham, Dashashwamedh Ghat, Sarnath' },
      { label: 'Culture & Craft', value: 'Banarasi Brocade Silk (GI Tag), Classical Music' },
    ],
  },
  isro: {
    title: 'Indian Space Research Organisation (ISRO)',
    subtitle: 'National Space Agency of India',
    description: 'ISRO is the national space agency of India, headquartered in Bengaluru. Operating under the Department of Space, ISRO has pioneered indigenous space launch vehicles (PSLV, GSLV, LVM3), planetary missions (Chandrayaan, Mars Orbiter Mission Mangalyaan, Aditya-L1), and the NavIC satellite navigation constellation.',
    imageUrl: 'https://picsum.photos/seed/isroinfo/600/400',
    sourceName: 'Department of Space, Government of India',
    sourceUrl: 'https://www.isro.gov.in',
    officialPortalUrl: 'https://www.isro.gov.in',
    attributes: [
      { label: 'Founded', value: '15 August 1969' },
      { label: 'Founder', value: 'Dr. Vikram Sarabhai' },
      { label: 'Headquarters', value: 'Antariksh Bhavan, Bengaluru, Karnataka' },
      { label: 'Primary Spaceport', value: 'Satish Dhawan Space Centre (SDSC), Sriharikota' },
      { label: 'Current Major Missions', value: 'Gaganyaan, Chandrayaan-4, Shukrayaan, NISAR' },
    ],
  },
  aadhaar: {
    title: 'Aadhaar (UIDAI)',
    subtitle: '12-Digit Biometric Identity System · Government of India',
    description: 'Aadhaar is a 12-digit unique identity number that can be obtained by citizens and resident foreign nationals based on their biometric and demographic data. It is the world largest biometric ID system, administered by the Unique Identification Authority of India (UIDAI).',
    imageUrl: 'https://picsum.photos/seed/aadhaarinfo/600/400',
    sourceName: 'Unique Identification Authority of India',
    sourceUrl: 'https://uidai.gov.in',
    officialPortalUrl: 'https://myaadhaar.uidai.gov.in',
    attributes: [
      { label: 'Authority', value: 'UIDAI (Ministry of Electronics & IT)' },
      { label: 'First Issued', value: '29 September 2010' },
      { label: 'Coverage', value: 'Over 1.38 Billion Verified Residents' },
      { label: 'Authentication', value: 'Biometric (Iris/Fingerprint) & OTP' },
      { label: 'Legal Framework', value: 'Aadhaar Act, 2016' },
    ],
  },
};

export function findKnowledgeCard(query: string): KnowledgeCard | undefined {
  const q = query.toLowerCase().trim();
  for (const [key, card] of Object.entries(KNOWLEDGE_GRAPH)) {
    if (q.includes(key) || key.includes(q)) {
      return card;
    }
  }
  return undefined;
}

export function searchLocalIndex(
  query: string,
  options: {
    category?: SearchCategory;
    lang?: string;
    region?: 'in' | 'all';
    limit?: number;
    offset?: number;
  } = {}
): { results: SearchResultItem[]; total: number } {
  initializeIndex();

  const { category = 'web', lang, limit = 10, offset = 0 } = options;
  const queryTokens = tokenize(query);

  if (queryTokens.length === 0) {
    // Return curated category items if empty query
    const filtered = sovereignDocuments.filter((d) => d.category === category);
    return {
      results: filtered.slice(offset, offset + limit).map((d) => ({
        id: d.id,
        title: d.title,
        url: d.url,
        displayUrl: d.displayUrl,
        snippet: d.snippet,
        domain: d.domain,
        category: d.category,
        publishedDate: d.publishedDate,
        language: d.language,
        thumbnail: d.thumbnail,
        provider: 'local-index',
        metadata: d.metadata,
      })),
      total: filtered.length,
    };
  }

  const scoredDocs: Array<{ doc: IndexDocument; score: number }> = [];

  for (const doc of sovereignDocuments) {
    // Category match
    if (category !== 'web' && doc.category !== category) {
      continue;
    }

    const bm25 = scoreBM25(queryTokens, doc, sovereignDocuments.length);
    if (bm25 > 0.05) {
      let finalScore = bm25;

      // Language affinity bonus
      if (lang && doc.language === lang) {
        finalScore *= 1.4;
      }

      // Sovereign verified boost
      if (doc.metadata?.isSovereignIndexed) {
        finalScore *= 1.25;
      }

      scoredDocs.push({ doc, score: finalScore });
    }
  }

  // Sort descending by score
  scoredDocs.sort((a, b) => b.score - a.score);

  const paginated = scoredDocs.slice(offset, offset + limit);

  return {
    results: paginated.map(({ doc, score }) => ({
      id: doc.id,
      title: doc.title,
      url: doc.url,
      displayUrl: doc.displayUrl,
      snippet: doc.snippet,
      domain: doc.domain,
      category: doc.category,
      publishedDate: doc.publishedDate,
      language: doc.language,
      thumbnail: doc.thumbnail,
      provider: 'local-index',
      score: Math.round(score * 100) / 100,
      metadata: doc.metadata,
    })),
    total: scoredDocs.length,
  };
}

export function getIndexStats() {
  initializeIndex();
  return {
    totalDocuments: sovereignDocuments.length,
    termsIndexed: invertedIndex.size,
    categories: {
      web: sovereignDocuments.filter((d) => d.category === 'web').length,
      news: sovereignDocuments.filter((d) => d.category === 'news').length,
      images: sovereignDocuments.filter((d) => d.category === 'images').length,
      videos: sovereignDocuments.filter((d) => d.category === 'videos').length,
      maps: sovereignDocuments.filter((d) => d.category === 'maps').length,
      shopping: sovereignDocuments.filter((d) => d.category === 'shopping').length,
    },
    languages: Array.from(new Set(sovereignDocuments.map((d) => d.language))),
  };
}
