import { SearchQueryOptions, SearchResponse, SearchResultItem } from './types';
import { searchLocalIndex, findKnowledgeCard } from './local-index';
import { detectScript, normalizeQuery } from '../languages';

export interface SearchProvider {
  name: string;
  search(options: SearchQueryOptions): Promise<{ results: SearchResultItem[]; total: number }>;
}

// 1. Local Sovereign Index Provider
export class LocalIndexProvider implements SearchProvider {
  name = 'Sovereign Local Index';

  async search(options: SearchQueryOptions) {
    const page = options.page || 1;
    const pageSize = options.pageSize || 10;
    const offset = (page - 1) * pageSize;

    return searchLocalIndex(options.q, {
      category: options.category || 'web',
      lang: options.lang,
      region: options.region,
      limit: pageSize,
      offset,
    });
  }
}

// 2. Live Web Search Provider (Using real Wikipedia & Open Access Web APIs)
export class LiveWebProvider implements SearchProvider {
  name = 'Live Web Gateway';

  async search(options: SearchQueryOptions): Promise<{ results: SearchResultItem[]; total: number }> {
    const query = options.q.trim();
    if (!query) return { results: [], total: 0 };

    try {
      // Use real Wikipedia Open Search API for encyclopedic & web results
      const endpoint = `https://en.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(
        query
      )}&limit=10&namespace=0&format=json&origin=*`;

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 4000);
      const res = await fetch(endpoint, { signal: controller.signal });
      clearTimeout(timeout);

      if (!res.ok) {
        throw new Error(`External provider error: ${res.status}`);
      }

      const data = await res.json();
      // data format: [query, [titles], [descriptions], [urls]]
      const titles: string[] = data[1] || [];
      const descriptions: string[] = data[2] || [];
      const urls: string[] = data[3] || [];

      const results: SearchResultItem[] = [];

      for (let i = 0; i < titles.length; i++) {
        const title = titles[i];
        const snippet = descriptions[i] || 'Encyclopedic overview and verified background information.';
        const url = urls[i] || `https://en.wikipedia.org/wiki/${encodeURIComponent(title)}`;
        const urlObj = new URL(url);

        results.push({
          id: `web-${i}-${title.slice(0, 15)}`,
          title: `${title} - Overview & Facts`,
          url,
          displayUrl: `${urlObj.hostname} > wiki > ${title.replace(/\s+/g, '_')}`,
          snippet,
          domain: urlObj.hostname,
          category: options.category || 'web',
          language: options.lang || 'en',
          provider: 'live-web',
          metadata: {
            author: 'Open Web & Knowledge Network',
          },
        });
      }

      return { results, total: results.length };
    } catch (err) {
      // Fallback gracefully without fabrication
      return { results: [], total: 0 };
    }
  }
}

// 3. Hybrid Provider (Blends sovereign index + live web results)
export class HybridProvider implements SearchProvider {
  name = 'Bharat Hybrid Engine';
  private local = new LocalIndexProvider();
  private web = new LiveWebProvider();

  async search(options: SearchQueryOptions): Promise<{ results: SearchResultItem[]; total: number }> {
    const [localResult, webResult] = await Promise.all([
      this.local.search(options),
      this.web.search(options),
    ]);

    // Sovereign results take precedence, followed by external web results
    const combinedMap = new Map<string, SearchResultItem>();

    for (const item of localResult.results) {
      combinedMap.set(item.url, item);
    }

    for (const item of webResult.results) {
      if (!combinedMap.has(item.url)) {
        combinedMap.set(item.url, item);
      }
    }

    const all = Array.from(combinedMap.values());
    const total = localResult.total + webResult.total;

    return { results: all, total: Math.max(total, all.length) };
  }
}

// Search Suggestions Corpus across English & Indian languages
const SUGGESTIONS_BANK: Record<string, string[]> = {
  isro: [
    'isro chandrayaan 3 lunar mission',
    'isro aditya l1 solar observatory',
    'isro gaganyaan astronaut training',
    'isro upcoming launches 2026',
    'isro antariksh bhavan bangalore',
  ],
  upi: [
    'upi instant payments overview',
    'upi qr code transaction limits',
    'upi international cross border payments',
    'upi npci customer support',
  ],
  varanasi: [
    'varanasi kashi vishwanath dham',
    'varanasi dashashwamedh ghat evening aarti',
    'varanasi silk saree handloom',
    'varanasi ancient temples and heritage',
  ],
  chandrayaan: [
    'chandrayaan 3 soft landing site shiv shakti',
    'chandrayaan vikram lander rover pragyan',
    'chandrayaan 3 science findings lunar soil',
  ],
  aadhaar: [
    'aadhaar uidai download e-aadhaar',
    'aadhaar mobile number link status',
    'aadhaar pvc card order online',
  ],
  digilocker: [
    'digilocker driving license download',
    'digilocker pan card verification',
    'digilocker academic marksheets cbse',
  ],
  हिन्दी: [
    'चंद्रयान 3 इसरो की ऐतिहासिक उपलब्धि',
    'काशी विश्वनाथ वाराणसी घाट गंगा आरती',
    'डिजिटल इंडिया यूपीआई भुगतान',
    'भारत के राष्ट्रीय उद्यान और धरोहर',
  ],
  தமிழ்: [
    'திருக்குறள் பொருள் விளக்கம்',
    'பாரதியார் கவிதைகள்',
    'இஸ்ரோ விண்வெளி சாதனைகள்',
    'தஞ்சை பெரிய கோவில் வரலாறு',
  ],
  తెలుగు: [
    'డిజిటల్ ఇండియా సేవలు',
    'తిరుపతి దేవస్థానం దర్శనం వివరాలు',
    'భారత అంతరిక్ష పరిశోధన సంస్థ విశేషాలు',
  ],
  বাংলা: [
    'রবীন্দ্রনাথ ঠাকুর গীতাঞ্জলি নোবেল জয়',
    'শান্তিনিকেতন বিশ্বভারতী বিশ্ববিদ্যালয়',
    'কলকাতার ঐতিহাসিক দর্শনীয় স্থান',
  ],
  اردو: [
    'مرزا غالب اردو غزلیں اور خطوط',
    'دہلی کے تاریخی یادگاریں',
    'اردو ادب اور شاعری کا سنہری دور',
  ],
};

export function getSearchSuggestions(query: string, lang = 'en'): string[] {
  const q = query.toLowerCase().trim();
  if (!q) {
    // Return trending queries
    return [
      'Chandrayaan-3 lunar mission findings',
      'UPI digital payment network India',
      'Varanasi Kashi Vishwanath ghats',
      'ISRO Aditya-L1 solar observations',
      'DigiLocker document services',
      'India Semiconductor Mission updates',
    ];
  }

  const results: string[] = [];

  // Match against bank
  for (const [key, suggestions] of Object.entries(SUGGESTIONS_BANK)) {
    if (key.includes(q) || q.includes(key)) {
      results.push(...suggestions);
    } else {
      for (const s of suggestions) {
        if (s.toLowerCase().includes(q)) {
          results.push(s);
        }
      }
    }
  }

  // Deduplicate and limit to 7
  return Array.from(new Set(results)).slice(0, 7);
}

// Main Orchestrator
export async function executeSearch(options: SearchQueryOptions): Promise<SearchResponse> {
  const startTime = Date.now();
  const q = options.q || '';
  const normalized = normalizeQuery(q);
  const detectedLang = detectScript(q);
  const effectiveLang = options.lang || detectedLang || 'en';

  // Determine provider
  let provider: SearchProvider;
  let providerName = 'Sovereign Local Index';

  if (options.source === 'web') {
    provider = new LiveWebProvider();
    providerName = 'Live Web Gateway';
  } else if (options.source === 'local') {
    provider = new LocalIndexProvider();
    providerName = 'Sovereign Local Index';
  } else {
    // Auto/hybrid
    provider = new HybridProvider();
    providerName = 'Bharat Hybrid Engine';
  }

  const { results, total } = await provider.search({
    ...options,
    q: normalized,
    lang: effectiveLang,
  });

  const executionTimeMs = Date.now() - startTime;
  const pageSize = options.pageSize || 10;
  const page = options.page || 1;
  const totalPages = Math.ceil(total / pageSize) || 1;

  // Check for knowledge card
  const knowledgeCard = findKnowledgeCard(q);

  return {
    originalQuery: q,
    normalizedQuery: normalized,
    executionTimeMs,
    totalResults: total,
    page,
    pageSize,
    totalPages,
    results,
    provider: providerName,
    lang: effectiveLang,
    detectedLang,
    knowledgeCard,
  };
}
