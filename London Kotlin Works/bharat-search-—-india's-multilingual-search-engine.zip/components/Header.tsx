'use client';

import React from 'react';
import { ShieldCheck, Leaf, Sun, Database, Info, Lock } from 'lucide-react';
import { NationalEmblem } from './Emblem';
import { getTranslation } from '@/lib/languages';

interface HeaderProps {
  lang: string;
  onHomeClick: () => void;
  onOpenAbout: () => void;
  onOpenPrivacy: () => void;
  onOpenCrawler: () => void;
}

export function Header({
  lang,
  onHomeClick,
  onOpenAbout,
  onOpenPrivacy,
  onOpenCrawler,
}: HeaderProps) {
  const t = getTranslation(lang);

  return (
    <header className="w-full flex flex-col sm:flex-row items-center justify-between px-4 sm:px-8 py-3.5 sm:py-5 z-20 relative">
      {/* Brand & National Emblem */}
      <button
        onClick={onHomeClick}
        className="flex items-center space-x-3.5 group focus:outline-none text-left"
      >
        <NationalEmblem className="w-9 h-11 text-amber-100 group-hover:text-amber-300 transition-colors drop-shadow" />
        <div className="flex flex-col">
          <div className="flex items-center space-x-2">
            <span className="text-xl sm:text-2xl font-bold tracking-tight text-white group-hover:text-amber-100 transition-colors">
              Bharat Search
            </span>
            <span className="text-[10px] uppercase font-semibold px-1.5 py-0.5 rounded bg-emerald-950/70 text-emerald-400 border border-emerald-500/40">
              India
            </span>
          </div>
          <span className="text-xs text-slate-300 tracking-wide">
            {t.smarterIndia}
          </span>
        </div>
      </button>

      {/* Top Right Badges & Tools */}
      <div className="flex items-center flex-wrap justify-center gap-3 sm:gap-4 mt-3 sm:mt-0">
        {/* Safe & Private Badge */}
        <div
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-slate-900/50 backdrop-blur-md border border-slate-700/50 text-xs text-slate-200"
          title="Zero user profiling, no search history retention by default"
        >
          <ShieldCheck className="w-3.5 h-3.5 text-sky-400" />
          <span>{t.safeAndPrivate}</span>
        </div>

        {/* Green Search Badge */}
        <div
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-slate-900/50 backdrop-blur-md border border-slate-700/50 text-xs text-slate-200"
          title="Optimized lightweight index powered by renewable data centers"
        >
          <Leaf className="w-3.5 h-3.5 text-emerald-400" />
          <span>{t.greenSearch}</span>
        </div>

        {/* Made in India Badge */}
        <div
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-slate-900/50 backdrop-blur-md border border-slate-700/50 text-xs text-slate-200"
          title="Indigenous sovereign search infrastructure designed for Bharat"
        >
          <Sun className="w-3.5 h-3.5 text-[#FF9933]" />
          <span>{t.madeInIndia}</span>
        </div>

        {/* Divider */}
        <div className="hidden md:block h-4 w-[1px] bg-slate-700/60" />

        {/* Crawler Engine Status & Admin */}
        <button
          onClick={onOpenCrawler}
          className="flex items-center space-x-1 text-xs text-slate-300 hover:text-white px-2.5 py-1.5 rounded-lg hover:bg-slate-800/60 transition-colors"
          title="Inspect crawler and sovereign index"
        >
          <Database className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden sm:inline">{t.crawlerAdmin}</span>
        </button>

        {/* About */}
        <button
          onClick={onOpenAbout}
          className="flex items-center space-x-1 text-xs text-slate-300 hover:text-white px-2 py-1.5 rounded-lg hover:bg-slate-800/60 transition-colors"
        >
          <Info className="w-3.5 h-3.5 text-slate-400" />
          <span className="hidden sm:inline">{t.about}</span>
        </button>

        {/* Privacy */}
        <button
          onClick={onOpenPrivacy}
          className="flex items-center space-x-1 text-xs text-slate-300 hover:text-white px-2 py-1.5 rounded-lg hover:bg-slate-800/60 transition-colors"
        >
          <Lock className="w-3.5 h-3.5 text-slate-400" />
          <span className="hidden sm:inline">{t.privacy}</span>
        </button>
      </div>
    </header>
  );
}
