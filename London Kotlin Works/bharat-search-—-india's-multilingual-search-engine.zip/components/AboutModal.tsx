'use client';

import React from 'react';
import { X, Layers, Globe, Shield, Cpu, BookOpen, Compass } from 'lucide-react';
import { BharatSearchLogo, NationalEmblem } from './Emblem';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AboutModal({ isOpen, onClose }: AboutModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl relative text-slate-800 max-h-[88vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center space-x-4 mb-6 pb-4 border-b border-slate-100">
          <BharatSearchLogo className="w-14 h-14" />
          <div>
            <h3 className="text-2xl font-bold text-[#071A2F]">Bharat Search</h3>
            <p className="text-xs font-semibold text-[#FF9933]">
              Find what matters. In your language.
            </p>
          </div>
        </div>

        {/* Narrative & Mission */}
        <div className="space-y-4 text-xs sm:text-sm text-slate-600 leading-relaxed">
          <p>
            <strong className="text-slate-900">Bharat Search</strong> is an indigenous, privacy-conscious search engine built specifically for India’s linguistic, cultural, and digital diversity.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 my-4">
            <div className="p-3.5 rounded-xl bg-orange-50/60 border border-orange-200">
              <Globe className="w-5 h-5 text-[#FF9933] mb-1.5" />
              <h4 className="font-bold text-xs text-slate-900">10 Official Languages</h4>
              <p className="text-[11px] text-slate-600 mt-0.5">
                Native Unicode processing, script-aware ranking, and right-to-left UI for Urdu.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-emerald-50/60 border border-emerald-200">
              <Shield className="w-5 h-5 text-emerald-600 mb-1.5" />
              <h4 className="font-bold text-xs text-slate-900">Privacy by Design</h4>
              <p className="text-[11px] text-slate-600 mt-0.5">
                No personalized ad trackers, no persistent IP log histories, and clean zero-cookie search.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-sky-50/60 border border-sky-200">
              <Cpu className="w-5 h-5 text-sky-600 mb-1.5" />
              <h4 className="font-bold text-xs text-slate-900">Sovereign Local Index</h4>
              <p className="text-[11px] text-slate-600 mt-0.5">
                Independent BM25 retrieval engine seeded with authentic Indian civic, science, and cultural documents.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-purple-50/60 border border-purple-200">
              <Compass className="w-5 h-5 text-purple-600 mb-1.5" />
              <h4 className="font-bold text-xs text-slate-900">Controlled Web Crawler</h4>
              <p className="text-[11px] text-slate-600 mt-0.5">
                Autonomous indexing bot with SSRF security shields, robots.txt compliance, and rate limiting.
              </p>
            </div>
          </div>

          <h4 className="font-bold text-xs uppercase tracking-wider text-slate-900 pt-2">
            Architectural Roadmap
          </h4>
          <ol className="list-decimal list-inside space-y-1.5 text-xs text-slate-600">
            <li>
              <strong>Stage 1 (Current MVP):</strong> Hybrid search blending sovereign Indian index with live web gateways across 10 languages.
            </li>
            <li>
              <strong>Stage 2 (Independent Search):</strong> Continuous crawler indexing Indian governmental, educational, and public domain web corpora.
            </li>
            <li>
              <strong>Stage 3 (National-Scale Platform):</strong> Distributed OpenSearch cluster, Indian-language LLM grounding, and regional datacenter peering.
            </li>
          </ol>
        </div>

        <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
          <span>Version 1.0.0-mvp</span>
          <span className="font-semibold text-slate-700">Digital India Initiative</span>
        </div>
      </div>
    </div>
  );
}
