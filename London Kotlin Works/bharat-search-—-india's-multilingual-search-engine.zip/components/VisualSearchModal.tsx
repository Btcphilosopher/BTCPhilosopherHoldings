'use client';

import React, { useState } from 'react';
import { Camera, Upload, Link, X, Sparkles, Check } from 'lucide-react';
import { getTranslation } from '@/lib/languages';

interface VisualSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSearch: (visualQuery: string) => void;
  lang: string;
}

export function VisualSearchModal({
  isOpen,
  onClose,
  onSearch,
  lang,
}: VisualSearchModalProps) {
  const [imageUrl, setImageUrl] = useState('');
  const [dragActive, setDragActive] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);

  const t = getTranslation(lang);

  const sampleLandmarks = [
    {
      name: 'Varanasi Sacred Riverfront Ghats',
      query: 'Varanasi Ghats Kashi Vishwanath Ganga',
      image: '/bharat_hero_bg.jpg',
    },
    {
      name: 'Chandrayaan-3 Vikram Lander',
      query: 'Chandrayaan 3 Vikram Lander Moon south pole',
      image: 'https://picsum.photos/seed/chandrayaanlanding/400/300',
    },
    {
      name: 'Taj Mahal Monument of Love',
      query: 'Taj Mahal Agra Yamuna River',
      image: 'https://picsum.photos/seed/tajmahaldawn/400/300',
    },
    {
      name: 'Hampi Monolithic Stone Chariot',
      query: 'Hampi Vijaya Vittala Temple Stone Chariot',
      image: 'https://picsum.photos/seed/hampichariot/400/300',
    },
  ];

  if (!isOpen) return null;

  const handleSelectSample = (query: string) => {
    setAnalyzing(true);
    setTimeout(() => {
      setAnalyzing(false);
      onSearch(query);
      onClose();
    }, 400);
  };

  const handleUrlSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!imageUrl.trim()) return;

    setAnalyzing(true);
    // Extract keywords from filename or query
    const urlParts = imageUrl.split('/');
    const lastPart = urlParts[urlParts.length - 1] || 'image search';
    const cleanQuery = decodeURIComponent(lastPart).replace(/[._-]/g, ' ');

    setTimeout(() => {
      setAnalyzing(false);
      onSearch(cleanQuery || 'visual entity query');
      onClose();
    }, 500);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setAnalyzing(true);
    const fileNameQuery = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');

    setTimeout(() => {
      setAnalyzing(false);
      onSearch(fileNameQuery || 'visual search');
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-7 shadow-2xl relative text-slate-800">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-emerald-50 text-emerald-600 rounded-xl">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">{t.visualSearchTitle}</h3>
              <p className="text-xs text-slate-500">{t.visualSearchDesc}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drag & Drop / Upload Box */}
        <div className="mt-5">
          <label className="border-2 border-dashed border-slate-300 hover:border-emerald-500 rounded-2xl p-6 flex flex-col items-center justify-center cursor-pointer bg-slate-50 hover:bg-emerald-50/30 transition-all group">
            <Upload className="w-8 h-8 text-slate-400 group-hover:text-emerald-600 transition-colors mb-2" />
            <span className="text-sm font-semibold text-slate-700">
              Drag an image here or click to browse
            </span>
            <span className="text-xs text-slate-400 mt-1">Supports JPG, PNG, WEBP</span>
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileUpload}
            />
          </label>
        </div>

        {/* Paste URL */}
        <form onSubmit={handleUrlSubmit} className="mt-4 flex space-x-2">
          <div className="relative flex-1">
            <Link className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="url"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              placeholder="Paste image link URL..."
              className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold"
          >
            Search
          </button>
        </form>

        {/* Sample Indian Heritage & Objects */}
        <div className="mt-6">
          <div className="flex items-center space-x-1.5 text-xs font-semibold text-slate-700 mb-2.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>Or try these Indian heritage & science visual queries:</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {sampleLandmarks.map((item, idx) => (
              <button
                key={idx}
                onClick={() => handleSelectSample(item.query)}
                className="group text-left rounded-xl overflow-hidden border border-slate-200 hover:border-emerald-500 hover:shadow-md transition-all focus:outline-none"
              >
                <div className="h-20 bg-slate-100 overflow-hidden relative">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="p-1.5 bg-white">
                  <div className="text-[11px] font-medium text-slate-800 line-clamp-1 group-hover:text-emerald-700">
                    {item.name}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {analyzing && (
          <div className="absolute inset-0 bg-white/90 backdrop-blur-xs rounded-3xl flex flex-col items-center justify-center z-10">
            <div className="w-10 h-10 border-3 border-emerald-500 border-t-transparent rounded-full animate-spin mb-3" />
            <p className="text-sm font-semibold text-slate-800">
              Analyzing visual features & landmarks...
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
