'use client';

import React, { useState } from 'react';
import {
  Globe,
  Newspaper,
  Image as ImageIcon,
  Video,
  MapPin,
  ShoppingBag,
  ExternalLink,
  Clock,
  Shield,
  Layers,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  Filter,
  CheckCircle2,
  AlertCircle,
  Eye,
  Star,
} from 'lucide-react';
import { SearchCategory, SearchResponse, SearchResultItem } from '@/lib/search/types';
import { getTranslation, SUPPORTED_LANGUAGES } from '@/lib/languages';
import { SearchBar } from './SearchBar';
import { NationalEmblem } from './Emblem';

interface SearchResultsProps {
  response: SearchResponse | null;
  isLoading: boolean;
  error: string | null;
  currentQuery: string;
  currentCategory: SearchCategory;
  currentLang: string;
  onSearch: (q: string, category?: SearchCategory, page?: number) => void;
  onCategoryChange: (category: SearchCategory) => void;
  onLangChange: (lang: string) => void;
  onGoHome: () => void;
  onOpenVoice: () => void;
  onOpenVisual: () => void;
}

export function SearchResults({
  response,
  isLoading,
  error,
  currentQuery,
  currentCategory,
  currentLang,
  onSearch,
  onCategoryChange,
  onLangChange,
  onGoHome,
  onOpenVoice,
  onOpenVisual,
}: SearchResultsProps) {
  const t = getTranslation(currentLang);
  const [selectedImage, setSelectedImage] = useState<SearchResultItem | null>(null);

  // Filters state
  const [regionFilter, setRegionFilter] = useState<'in' | 'all'>('in');
  const [safeSearch, setSafeSearch] = useState<boolean>(true);
  const [sourceProvider, setSourceProvider] = useState<'auto' | 'local' | 'web'>('auto');

  const categories = [
    { id: 'web' as const, label: t.webSearch, icon: Globe },
    { id: 'news' as const, label: t.news, icon: Newspaper },
    { id: 'images' as const, label: t.images, icon: ImageIcon },
    { id: 'videos' as const, label: t.videos, icon: Video },
    { id: 'maps' as const, label: t.maps, icon: MapPin },
    { id: 'shopping' as const, label: t.shopping, icon: ShoppingBag },
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      {/* Top Search Bar & Navigation Header */}
      <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200/90 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-3.5 pb-2">
          <div className="flex items-center space-x-4 sm:space-x-6">
            {/* Logo Link to Home */}
            <button
              onClick={onGoHome}
              className="flex items-center space-x-2.5 focus:outline-none flex-shrink-0"
              title="Return to Bharat Search Home"
            >
              <NationalEmblem className="w-7 h-9 text-[#071A2F]" />
              <div className="hidden sm:block text-left">
                <span className="text-lg font-bold tracking-tight text-[#071A2F]">
                  Bharat Search
                </span>
                <span className="block text-[9px] uppercase font-semibold text-emerald-700">
                  India
                </span>
              </div>
            </button>

            {/* Compact Search Bar */}
            <div className="flex-1 max-w-3xl">
              <SearchBar
                initialQuery={currentQuery}
                lang={currentLang}
                isCompact
                onSearch={(q) => onSearch(q, currentCategory, 1)}
                onOpenVoice={onOpenVoice}
                onOpenVisual={onOpenVisual}
              />
            </div>

            {/* Language Quick Dropdown */}
            <div className="hidden md:flex items-center space-x-2">
              <select
                value={currentLang}
                onChange={(e) => onLangChange(e.target.value)}
                className="text-xs bg-slate-100 hover:bg-slate-200/70 border border-slate-300 rounded-lg px-2.5 py-2 font-medium text-slate-700 focus:outline-none"
                aria-label="Select search language"
              >
                {SUPPORTED_LANGUAGES.map((l) => (
                  <option key={l.code} value={l.code}>
                    {l.nativeName} ({l.englishName})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Category Tabs */}
          <div className="flex items-center space-x-1 sm:space-x-6 mt-3 overflow-x-auto no-scrollbar border-t border-slate-100 pt-1.5">
            {categories.map((cat) => {
              const Icon = cat.icon;
              const isActive = currentCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => onCategoryChange(cat.id)}
                  className={`flex items-center space-x-1.5 px-3 py-2 text-xs sm:text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                    isActive
                      ? 'border-[#FF9933] text-[#071A2F] font-semibold'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-[#FF9933]' : 'text-slate-400'}`} />
                  <span>{cat.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Filter and Stats Bar */}
      <div className="bg-slate-100/70 border-b border-slate-200/60 px-4 sm:px-6 py-2">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between text-xs text-slate-500 gap-2">
          {/* Result Count and Timing */}
          <div className="flex items-center space-x-2">
            {response && !isLoading && (
              <span>
                {t.aboutCountResults.replace('{count}', response.totalResults.toLocaleString())} ({((response.executionTimeMs || 35) / 1000).toFixed(3)} {t.seconds})
              </span>
            )}
            {response?.provider && (
              <span className="hidden sm:inline-flex items-center space-x-1 px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 font-medium">
                <CheckCircle2 className="w-3 h-3" />
                <span>{response.provider}</span>
              </span>
            )}
          </div>

          {/* Filter Toggles */}
          <div className="flex items-center space-x-3">
            {/* Region Filter */}
            <button
              onClick={() => {
                const next = regionFilter === 'in' ? 'all' : 'in';
                setRegionFilter(next);
                onSearch(currentQuery, currentCategory, 1);
              }}
              className={`px-2.5 py-1 rounded-md text-xs font-medium border transition-colors ${
                regionFilter === 'in'
                  ? 'bg-amber-50 text-amber-900 border-amber-300'
                  : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
              }`}
            >
              {regionFilter === 'in' ? t.indiaOnly : t.allRegions}
            </button>

            {/* SafeSearch Toggle */}
            <button
              onClick={() => setSafeSearch(!safeSearch)}
              className={`px-2 py-1 rounded-md text-xs font-medium border transition-colors ${
                safeSearch
                  ? 'bg-sky-50 text-sky-800 border-sky-300'
                  : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
              }`}
            >
              {safeSearch ? t.safeSearchOn : t.safeSearchOff}
            </button>

            {/* Provider Source */}
            <select
              value={sourceProvider}
              onChange={(e) => {
                setSourceProvider(e.target.value as any);
                onSearch(currentQuery, currentCategory, 1);
              }}
              className="bg-white border border-slate-200 text-slate-700 rounded-md px-2 py-1 text-xs focus:outline-none"
            >
              <option value="auto">Hybrid (Index + Web)</option>
              <option value="local">Sovereign Local Index</option>
              <option value="web">Live Web Gateway</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Results Column */}
      <main className="max-w-7xl mx-auto w-full px-4 sm:px-6 py-6 flex-1">
        {/* Loading State */}
        {isLoading && (
          <div className="space-y-6 max-w-3xl">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="animate-pulse space-y-2.5">
                <div className="h-4 bg-slate-200 rounded w-1/4" />
                <div className="h-6 bg-slate-300 rounded w-3/4" />
                <div className="h-4 bg-slate-200 rounded w-full" />
                <div className="h-4 bg-slate-200 rounded w-5/6" />
              </div>
            ))}
          </div>
        )}

        {/* Error State */}
        {error && !isLoading && (
          <div className="max-w-2xl bg-rose-50 border border-rose-200 rounded-xl p-5 text-rose-900 my-4">
            <div className="flex items-start space-x-3">
              <AlertCircle className="w-5 h-5 text-rose-600 mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-sm">Search Request Failed</h3>
                <p className="text-xs text-rose-700 mt-1">{error}</p>
                <button
                  onClick={() => onSearch(currentQuery, currentCategory, 1)}
                  className="mt-3 px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-medium transition-colors"
                >
                  {t.retry}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Empty State */}
        {!isLoading && !error && response && response.results.length === 0 && (
          <div className="max-w-2xl py-12">
            <h2 className="text-lg font-semibold text-slate-800">
              {t.noResultsTitle} &quot;{currentQuery}&quot;
            </h2>
            <p className="text-sm text-slate-600 mt-1">{t.noResultsDesc}</p>
            <div className="mt-4 p-4 rounded-xl bg-slate-100/80 border border-slate-200 text-xs text-slate-600 space-y-1">
              <div className="font-medium text-slate-800">{t.searchTips}:</div>
              <div>• Make sure all words are spelled correctly.</div>
              <div>• Try different keywords or more general Indian search terms.</div>
              <div>• Try switching between &quot;Sovereign Local Index&quot; and &quot;Hybrid&quot; provider.</div>
              <div>• Try querying for popular sovereign topics: &quot;ISRO&quot;, &quot;UPI&quot;, &quot;Varanasi&quot;, &quot;Chandrayaan-3&quot;.</div>
            </div>
          </div>
        )}

        {/* Results Layout Grid: Main Content + Right Knowledge Card */}
        {!isLoading && !error && response && response.results.length > 0 && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Primary Results Column */}
            <div className="lg:col-span-8 space-y-7">
              {/* CATEGORY: WEB RESULTS */}
              {currentCategory === 'web' && (
                <div className="space-y-6">
                  {response.results.map((result) => (
                    <article key={result.id} className="group">
                      {/* Domain Breadcrumb */}
                      <div className="flex items-center space-x-2 text-xs text-slate-500 mb-1">
                        <span className="font-medium text-slate-700 truncate max-w-sm">
                          {result.displayUrl}
                        </span>
                        {result.metadata?.isSovereignIndexed && (
                          <span className="px-1.5 py-0.2 rounded bg-amber-50 text-amber-800 border border-amber-200 text-[10px] font-medium">
                            Sovereign Index
                          </span>
                        )}
                        {result.language && (
                          <span className="uppercase text-[10px] px-1 py-0.2 bg-slate-100 rounded text-slate-600">
                            {result.language}
                          </span>
                        )}
                      </div>

                      {/* Title */}
                      <h2 className="text-lg sm:text-xl font-medium text-blue-800 group-hover:underline">
                        <a
                          href={result.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center space-x-1.5"
                        >
                          <span>{result.title}</span>
                          <ExternalLink className="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-800 inline" />
                        </a>
                      </h2>

                      {/* Snippet */}
                      <p className="text-sm text-slate-700 leading-relaxed mt-1 line-clamp-3">
                        {result.publishedDate && (
                          <span className="text-slate-500 font-normal mr-2">
                            {result.publishedDate} —
                          </span>
                        )}
                        {result.snippet}
                      </p>
                    </article>
                  ))}
                </div>
              )}

              {/* CATEGORY: NEWS RESULTS */}
              {currentCategory === 'news' && (
                <div className="space-y-4">
                  {response.results.map((item) => (
                    <a
                      key={item.id}
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex flex-col sm:flex-row items-start space-y-3 sm:space-y-0 sm:space-x-4 p-4 rounded-xl border border-slate-200 bg-white hover:border-[#FF9933]/50 hover:shadow-md transition-all group"
                    >
                      {item.thumbnail && (
                        <div className="w-full sm:w-44 h-28 flex-shrink-0 bg-slate-100 rounded-lg overflow-hidden relative">
                          <img
                            src={item.thumbnail}
                            alt={item.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                      )}
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 text-xs text-slate-500 mb-1">
                          <span className="font-semibold text-slate-800">{item.domain}</span>
                          {item.publishedDate && (
                            <>
                              <span>•</span>
                              <span>{item.publishedDate}</span>
                            </>
                          )}
                        </div>
                        <h3 className="text-base font-semibold text-slate-900 group-hover:text-blue-700 transition-colors">
                          {item.title}
                        </h3>
                        <p className="text-xs sm:text-sm text-slate-600 mt-1 line-clamp-2">
                          {item.snippet}
                        </p>
                      </div>
                    </a>
                  ))}
                </div>
              )}

              {/* CATEGORY: IMAGES RESULTS */}
              {currentCategory === 'images' && (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4">
                  {response.results.map((img) => (
                    <div
                      key={img.id}
                      onClick={() => setSelectedImage(img)}
                      className="group cursor-pointer rounded-xl overflow-hidden border border-slate-200 bg-white hover:shadow-lg transition-all"
                    >
                      <div className="aspect-4/3 w-full bg-slate-100 overflow-hidden relative">
                        <img
                          src={img.thumbnail || img.url}
                          alt={img.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          referrerPolicy="no-referrer"
                        />
                        {img.metadata?.imageWidth && (
                          <div className="absolute bottom-1 right-1 px-1.5 py-0.5 rounded bg-black/70 text-white text-[10px] font-mono">
                            {img.metadata.imageWidth}×{img.metadata.imageHeight}
                          </div>
                        )}
                      </div>
                      <div className="p-2.5">
                        <p className="text-xs font-medium text-slate-800 truncate">{img.title}</p>
                        <p className="text-[11px] text-slate-400 truncate">{img.domain}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* CATEGORY: VIDEOS RESULTS */}
              {currentCategory === 'videos' && (
                <div className="space-y-4">
                  {response.results.map((vid) => (
                    <a
                      key={vid.id}
                      href={vid.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex flex-col sm:flex-row items-start space-y-3 sm:space-y-0 sm:space-x-4 p-4 rounded-xl border border-slate-200 bg-white hover:border-[#FF9933]/50 hover:shadow-md transition-all group"
                    >
                      <div className="w-full sm:w-48 h-28 flex-shrink-0 bg-slate-900 rounded-lg overflow-hidden relative">
                        <img
                          src={vid.thumbnail}
                          alt={vid.title}
                          className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform"
                          referrerPolicy="no-referrer"
                        />
                        {vid.metadata?.videoDuration && (
                          <div className="absolute bottom-1.5 right-1.5 px-1.5 py-0.5 rounded bg-black/80 text-white text-[11px] font-semibold">
                            {vid.metadata.videoDuration}
                          </div>
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="text-xs text-slate-500 mb-1">{vid.domain}</div>
                        <h3 className="text-base font-semibold text-slate-900 group-hover:text-blue-700">
                          {vid.title}
                        </h3>
                        <p className="text-xs text-slate-600 mt-1 line-clamp-2">{vid.snippet}</p>
                      </div>
                    </a>
                  ))}
                </div>
              )}

              {/* CATEGORY: MAPS RESULTS */}
              {currentCategory === 'maps' && (
                <div className="space-y-4">
                  {response.results.map((mapItem) => (
                    <div
                      key={mapItem.id}
                      className="p-5 rounded-xl border border-slate-200 bg-white hover:border-sky-300 transition-all flex flex-col sm:flex-row items-start justify-between gap-4"
                    >
                      <div className="space-y-1.5">
                        <div className="flex items-center space-x-2">
                          <MapPin className="w-5 h-5 text-rose-500" />
                          <h3 className="text-base font-bold text-slate-900">{mapItem.title}</h3>
                        </div>
                        {mapItem.metadata?.address && (
                          <p className="text-xs sm:text-sm text-slate-600">
                            {mapItem.metadata.address}
                          </p>
                        )}
                        <p className="text-xs text-slate-500">{mapItem.snippet}</p>
                      </div>
                      <a
                        href={mapItem.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold flex items-center space-x-1.5 whitespace-nowrap shadow-xs"
                      >
                        <span>View on Map</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  ))}
                </div>
              )}

              {/* CATEGORY: SHOPPING RESULTS */}
              {currentCategory === 'shopping' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {response.results.map((prod) => (
                    <div
                      key={prod.id}
                      className="p-4 rounded-xl border border-slate-200 bg-white flex space-x-4 hover:shadow-md transition-all"
                    >
                      {prod.thumbnail && (
                        <div className="w-28 h-28 flex-shrink-0 bg-slate-100 rounded-lg overflow-hidden">
                          <img
                            src={prod.thumbnail}
                            alt={prod.title}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                      )}
                      <div className="flex-1 flex flex-col justify-between">
                        <div>
                          <div className="text-[11px] text-slate-400 font-medium">
                            {prod.metadata?.merchant || prod.domain}
                          </div>
                          <h4 className="text-sm font-semibold text-slate-800 line-clamp-2 mt-0.5">
                            {prod.title}
                          </h4>
                          {prod.metadata?.rating && (
                            <div className="flex items-center space-x-1 mt-1 text-xs text-amber-500 font-medium">
                              <Star className="w-3.5 h-3.5 fill-amber-400" />
                              <span>{prod.metadata.rating}</span>
                              <span className="text-slate-400 text-[10px]">
                                ({prod.metadata.reviewCount})
                              </span>
                            </div>
                          )}
                        </div>
                        <div className="flex items-center justify-between mt-3">
                          <div className="text-base font-bold text-slate-900">
                            {prod.metadata?.currency || '₹'}
                            {prod.metadata?.price}
                          </div>
                          <a
                            href={prod.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md font-medium"
                          >
                            Buy
                          </a>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Pagination Controls */}
              {response.totalPages > 1 && (
                <div className="flex items-center justify-center space-x-2 pt-6 border-t border-slate-200">
                  <button
                    disabled={response.page <= 1}
                    onClick={() => onSearch(currentQuery, currentCategory, response.page - 1)}
                    className="p-2 rounded-lg border border-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-100"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <span className="text-xs text-slate-600 font-medium px-3">
                    Page {response.page} of {response.totalPages}
                  </span>
                  <button
                    disabled={response.page >= response.totalPages}
                    onClick={() => onSearch(currentQuery, currentCategory, response.page + 1)}
                    className="p-2 rounded-lg border border-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-100"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>

            {/* Right Column: Knowledge Graph Fact Card */}
            {response.knowledgeCard && (
              <div className="lg:col-span-4">
                <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs sticky top-36">
                  {response.knowledgeCard.imageUrl && (
                    <div className="w-full h-44 rounded-xl overflow-hidden mb-4 bg-slate-100">
                      <img
                        src={response.knowledgeCard.imageUrl}
                        alt={response.knowledgeCard.title}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  )}

                  <div className="space-y-1">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-[#FF9933]">
                      {t.knowledgeFact}
                    </span>
                    <h3 className="text-xl font-bold text-slate-900">
                      {response.knowledgeCard.title}
                    </h3>
                    <p className="text-xs text-slate-500 font-medium">
                      {response.knowledgeCard.subtitle}
                    </p>
                  </div>

                  <p className="text-xs text-slate-700 mt-3 leading-relaxed border-t border-slate-100 pt-3">
                    {response.knowledgeCard.description}
                  </p>

                  {/* Key Fact Attributes */}
                  <div className="mt-4 space-y-2 border-t border-slate-100 pt-3">
                    {response.knowledgeCard.attributes.map((attr, idx) => (
                      <div key={idx} className="flex justify-between text-xs">
                        <span className="text-slate-500 font-medium">{attr.label}</span>
                        <span className="text-slate-800 font-semibold text-right max-w-[55%] truncate">
                          {attr.value}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Official Portal Link */}
                  {response.knowledgeCard.officialPortalUrl && (
                    <div className="mt-5 pt-3 border-t border-slate-100">
                      <a
                        href={response.knowledgeCard.officialPortalUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-center space-x-1.5 w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold transition-colors"
                      >
                        <span>Official Government Portal</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Image Lightbox Modal */}
      {selectedImage && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setSelectedImage(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-3xl w-full overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 border-b border-slate-200 flex items-center justify-between">
              <h4 className="text-sm font-bold text-slate-900 truncate">
                {selectedImage.title}
              </h4>
              <button
                onClick={() => setSelectedImage(null)}
                className="text-slate-400 hover:text-slate-700 text-sm font-semibold px-2 py-1"
              >
                ✕ Close
              </button>
            </div>
            <div className="max-h-[65vh] bg-slate-950 flex items-center justify-center overflow-hidden">
              <img
                src={selectedImage.thumbnail || selectedImage.url}
                alt={selectedImage.title}
                className="max-h-[65vh] w-auto object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="p-4 bg-slate-50 flex items-center justify-between text-xs">
              <div>
                <span className="text-slate-500">Source: </span>
                <span className="font-semibold text-slate-800">{selectedImage.domain}</span>
              </div>
              <a
                href={selectedImage.url}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 bg-blue-600 text-white rounded-md font-medium flex items-center space-x-1"
              >
                <span>Visit Source Page</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
