import React from 'react';

// National Emblem of India SVG (Ashoka Lion Capital + Satyameva Jayate)
export function NationalEmblem({ className = 'w-10 h-12' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="National Emblem of India - Lion Capital of Ashoka"
    >
      {/* Three Lions stylized silhouette */}
      <g stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" fill="currentColor" fillOpacity="0.15">
        {/* Central Lion Head */}
        <path d="M42 22 C42 12, 58 12, 58 22 C64 24, 66 32, 60 38 C56 42, 44 42, 40 38 C34 32, 36 24, 42 22 Z" />
        <circle cx="46" cy="27" r="1.5" fill="currentColor" />
        <circle cx="54" cy="27" r="1.5" fill="currentColor" />
        <path d="M47 33 Q50 36 53 33" stroke="currentColor" strokeWidth="1.5" fill="none" />
        
        {/* Left Lion Head */}
        <path d="M22 28 C20 18, 34 16, 38 24 C38 32, 30 38, 24 38 C18 34, 18 28, 22 28 Z" />
        <circle cx="27" cy="28" r="1.5" fill="currentColor" />

        {/* Right Lion Head */}
        <path d="M78 28 C80 18, 66 16, 62 24 C62 32, 70 38, 76 38 C82 34, 82 28, 78 28 Z" />
        <circle cx="73" cy="28" r="1.5" fill="currentColor" />

        {/* Lion Mane and Pillar Torso */}
        <path d="M30 40 C34 46, 66 46, 70 40 L72 65 C68 70, 32 70, 28 65 Z" />
        <path d="M38 46 L38 65 M50 44 L50 67 M62 46 L62 65" stroke="currentColor" strokeWidth="1.5" />

        {/* Abacus / Base with Ashoka Chakra */}
        <rect x="20" y="68" width="60" height="18" rx="2" stroke="currentColor" strokeWidth="2" fill="currentColor" fillOpacity="0.3" />
        <circle cx="50" cy="77" r="6" stroke="currentColor" strokeWidth="1.5" fill="none" />
        {/* Bull on left, Horse on right */}
        <path d="M26 77 Q30 73 34 77" stroke="currentColor" strokeWidth="1.5" fill="none" />
        <path d="M66 77 Q70 73 74 77" stroke="currentColor" strokeWidth="1.5" fill="none" />

        {/* Lotus base petals */}
        <path d="M22 88 C32 94, 68 94, 78 88 L80 94 C68 100, 32 100, 20 94 Z" stroke="currentColor" strokeWidth="1.8" />
      </g>

      {/* Satyameva Jayate text underneath */}
      <text
        x="50"
        y="112"
        textAnchor="middle"
        fill="currentColor"
        fontSize="8.5"
        fontWeight="600"
        letterSpacing="0.8"
        fontFamily="sans-serif"
      >
        सत्यमेव जयते
      </text>
    </svg>
  );
}

// Bharat Search Tricolor Logo (Peacock swoop with 24-spoke Ashoka Chakra)
export function BharatSearchLogo({ className = 'w-16 h-16' }: { className?: string }) {
  // 24 spoke coordinates for the Ashoka Chakra
  const spokes = Array.from({ length: 24 }).map((_, i) => {
    const angle = (i * 360) / 24;
    const rad = (angle * Math.PI) / 180;
    const x1 = 50 + 4 * Math.cos(rad);
    const y1 = 50 + 4 * Math.sin(rad);
    const x2 = 50 + 17 * Math.cos(rad);
    const y2 = 50 + 17 * Math.sin(rad);
    return { x1, y1, x2, y2, angle };
  });

  return (
    <svg
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="Bharat Search Tricolor Emblem"
    >
      <defs>
        {/* Saffron Gradient */}
        <linearGradient id="saffronGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FFA726" />
          <stop offset="50%" stopColor="#FF9933" />
          <stop offset="100%" stopColor="#E65100" />
        </linearGradient>

        {/* Green Gradient */}
        <linearGradient id="greenGrad" x1="0%" y1="100%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#0B6623" />
          <stop offset="50%" stopColor="#138808" />
          <stop offset="100%" stopColor="#2E7D32" />
        </linearGradient>

        {/* White Glow / Shading */}
        <radialGradient id="centerWhite" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="85%" stopColor="#F8FAFC" />
          <stop offset="100%" stopColor="#E2E8F0" />
        </radialGradient>
      </defs>

      {/* Outer peacock swoosh: Indian Saffron top wing */}
      <path
        d="M20 75 C10 45, 30 10, 68 8 C88 8, 98 25, 92 42 C85 55, 68 56, 58 45 C48 35, 42 38, 38 48 C34 58, 36 68, 20 75 Z"
        fill="url(#saffronGrad)"
      />

      {/* Lower peacock flourish: Indian Green sweep */}
      <path
        d="M18 70 C14 82, 30 96, 55 94 C78 92, 92 78, 88 64 C82 66, 74 68, 64 66 C52 64, 42 72, 34 76 C26 80, 20 76, 18 70 Z"
        fill="url(#greenGrad)"
      />

      {/* Peacock eye/beak detail accent */}
      <circle cx="22" cy="74" r="3.5" fill="#008080" />
      <circle cx="22" cy="74" r="1.5" fill="#FFFFFF" />

      {/* Central circular white shield container */}
      <circle cx="50" cy="50" r="23" fill="url(#centerWhite)" stroke="#071A2F" strokeWidth="1" />

      {/* Ashoka Chakra (Navy Blue #000080 / #0A2540) */}
      <g>
        {/* Outer Wheel Rim */}
        <circle cx="50" cy="50" r="19" stroke="#071A2F" strokeWidth="2.5" fill="none" />
        <circle cx="50" cy="50" r="17.2" stroke="#003366" strokeWidth="0.8" fill="none" />

        {/* Center Hub */}
        <circle cx="50" cy="50" r="4.5" fill="#071A2F" />
        <circle cx="50" cy="50" r="2" fill="#FFFFFF" />

        {/* 24 Radial Spokes */}
        {spokes.map((s, idx) => (
          <line
            key={idx}
            x1={s.x1}
            y1={s.y1}
            x2={s.x2}
            y2={s.y2}
            stroke="#071A2F"
            strokeWidth="1.2"
            strokeLinecap="round"
          />
        ))}
      </g>
    </svg>
  );
}
