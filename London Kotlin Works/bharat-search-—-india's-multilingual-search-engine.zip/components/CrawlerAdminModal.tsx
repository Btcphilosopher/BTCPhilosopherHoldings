'use client';

import React, { useState, useEffect } from 'react';
import {
  Database,
  Play,
  ShieldAlert,
  CheckCircle2,
  AlertTriangle,
  X,
  RefreshCw,
  Server,
  Layers,
  FileText,
  Clock,
} from 'lucide-react';
import { CrawlerStatus } from '@/lib/search/types';

interface CrawlerAdminModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CrawlerAdminModal({ isOpen, onClose }: CrawlerAdminModalProps) {
  const [status, setStatus] = useState<CrawlerStatus | null>(null);
  const [indexStats, setIndexStats] = useState<any>(null);
  const [targetUrl, setTargetUrl] = useState('');
  const [isCrawling, setIsCrawling] = useState(false);
  const [feedback, setFeedback] = useState<{ success: boolean; message: string } | null>(null);

  const fetchStatus = React.useCallback(async () => {
    try {
      const res = await fetch('/api/v1/crawl');
      if (res.ok) {
        const data = await res.json();
        setStatus(data);
        setIndexStats(data.indexStats);
      }
    } catch {}
  }, []);

  useEffect(() => {
    if (!isOpen) return;

    const timer = setTimeout(fetchStatus, 0);
    const interval = setInterval(fetchStatus, 6000);

    return () => {
      clearTimeout(timer);
      clearInterval(interval);
    };
  }, [isOpen, fetchStatus]);

  if (!isOpen) return null;

  const handleStartCrawl = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetUrl.trim()) return;

    setIsCrawling(true);
    setFeedback(null);

    try {
      const res = await fetch('/api/v1/crawl', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: targetUrl.trim() }),
      });

      const data = await res.json();
      setFeedback({ success: data.success, message: data.message });
      fetchStatus();
    } catch (err: any) {
      setFeedback({ success: false, message: err.message || 'Crawl failed.' });
    } finally {
      setIsCrawling(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-3xl w-full p-6 sm:p-7 shadow-2xl relative text-slate-800 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-4 flex-shrink-0">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-amber-50 text-amber-700 rounded-xl">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-lg font-bold text-slate-900">
                  Bharat Sovereign Index & Crawler Engine
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                  Active
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Controlled crawler pipeline respecting robots.txt, rate limits, and SSRF restrictions
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="overflow-y-auto space-y-6 pt-5 pr-1 flex-1">
          {/* Index Stats Metrics */}
          {indexStats && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-xs text-slate-500 font-medium">Sovereign Documents</div>
                <div className="text-xl font-bold text-slate-900 mt-0.5">
                  {indexStats.totalDocuments}
                </div>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-xs text-slate-500 font-medium">Indexed Terms</div>
                <div className="text-xl font-bold text-amber-600 mt-0.5">
                  {indexStats.termsIndexed?.toLocaleString()}
                </div>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-xs text-slate-500 font-medium">Crawl Audit Records</div>
                <div className="text-xl font-bold text-blue-600 mt-0.5">
                  {status?.crawlHistoryCount || 0}
                </div>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-xs text-slate-500 font-medium">Supported Languages</div>
                <div className="text-xl font-bold text-emerald-600 mt-0.5">
                  10+
                </div>
              </div>
            </div>
          )}

          {/* Trigger Seed Crawl Form */}
          <div className="p-4 rounded-2xl bg-amber-50/50 border border-amber-200/80">
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-900 mb-1 flex items-center space-x-1.5">
              <Server className="w-4 h-4 text-amber-700" />
              <span>Controlled Web Crawler Trigger</span>
            </h4>
            <p className="text-xs text-slate-600 mb-3">
              Enter an approved public URL to fetch, verify robots.txt, parse HTML, and index into the BM25 sovereign catalog.
            </p>

            <form onSubmit={handleStartCrawl} className="flex flex-col sm:flex-row gap-2">
              <input
                type="url"
                value={targetUrl}
                onChange={(e) => setTargetUrl(e.target.value)}
                placeholder="e.g. https://isro.gov.in or https://pib.gov.in"
                className="flex-1 px-3.5 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white"
                required
              />
              <button
                type="submit"
                disabled={isCrawling}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white rounded-xl text-xs font-semibold flex items-center justify-center space-x-1.5"
              >
                {isCrawling ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Crawling...</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Start Crawl</span>
                  </>
                )}
              </button>
            </form>

            {/* Quick Seed Buttons */}
            <div className="flex flex-wrap gap-1.5 mt-2.5">
              <span className="text-[11px] text-slate-500 font-medium mr-1 self-center">
                Permitted seeds:
              </span>
              {[
                'https://isro.gov.in',
                'https://pib.gov.in',
                'https://digitalindia.gov.in',
                'https://npci.org.in',
              ].map((seed) => (
                <button
                  key={seed}
                  type="button"
                  onClick={() => setTargetUrl(seed)}
                  className="text-[11px] px-2 py-0.5 rounded bg-white hover:bg-amber-100 text-slate-700 border border-slate-200"
                >
                  {seed.replace('https://', '')}
                </button>
              ))}
            </div>

            {/* SSRF Tester Quick Button */}
            <div className="mt-2 pt-2 border-t border-amber-200/60 flex items-center justify-between text-[11px]">
              <span className="text-slate-500">Security test: Verify SSRF Protection block</span>
              <button
                type="button"
                onClick={() => setTargetUrl('http://169.254.169.254/latest/meta-data/')}
                className="text-rose-700 hover:underline font-semibold"
              >
                Test AWS/GCP Metadata Block
              </button>
            </div>

            {/* Feedback alert */}
            {feedback && (
              <div
                className={`mt-3 p-3 rounded-xl text-xs flex items-start space-x-2 ${
                  feedback.success
                    ? 'bg-emerald-50 text-emerald-900 border border-emerald-300'
                    : 'bg-rose-50 text-rose-900 border border-rose-300'
                }`}
              >
                {feedback.success ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                ) : (
                  <ShieldAlert className="w-4 h-4 text-rose-600 mt-0.5 flex-shrink-0" />
                )}
                <span>{feedback.message}</span>
              </div>
            )}
          </div>

          {/* Crawler Logs Table */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center space-x-1.5">
                <Clock className="w-3.5 h-3.5 text-slate-500" />
                <span>Recent Crawler Execution Logs</span>
              </h4>
              <button
                onClick={fetchStatus}
                className="text-xs text-slate-500 hover:text-slate-800 flex items-center space-x-1"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Refresh</span>
              </button>
            </div>

            <div className="border border-slate-200 rounded-xl overflow-hidden bg-slate-50 text-xs">
              <div className="divide-y divide-slate-200 max-h-56 overflow-y-auto">
                {status?.recentLogs && status.recentLogs.length > 0 ? (
                  status.recentLogs.map((log, i) => (
                    <div key={i} className="p-3 flex items-start justify-between space-x-3 bg-white">
                      <div className="space-y-0.5">
                        <div className="flex items-center space-x-2">
                          <span
                            className={`px-1.5 py-0.2 rounded text-[10px] uppercase font-bold ${
                              log.status === 'indexed'
                                ? 'bg-emerald-100 text-emerald-800'
                                : log.status === 'blocked'
                                ? 'bg-rose-100 text-rose-800'
                                : log.status === 'skipped'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {log.status}
                          </span>
                          <span className="font-mono text-slate-700 truncate max-w-sm">
                            {log.url}
                          </span>
                        </div>
                        <p className="text-slate-500 text-[11px]">{log.message}</p>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono whitespace-nowrap">
                        {new Date(log.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                  ))
                ) : (
                  <div className="p-4 text-center text-slate-400">No logs yet.</div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
