'use client';

import React, { useState, useEffect } from 'react';
import { Mic, MicOff, X, Volume2, AlertCircle } from 'lucide-react';
import { getTranslation, SUPPORTED_LANGUAGES } from '@/lib/languages';

interface VoiceSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSearch: (transcript: string) => void;
  lang: string;
}

export function VoiceSearchModal({
  isOpen,
  onClose,
  onSearch,
  lang,
}: VoiceSearchModalProps) {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [isSupported] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return Boolean((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);
    }
    return false;
  });
  const [errorMessage, setErrorMessage] = useState('');

  const t = getTranslation(lang);
  const langConfig = SUPPORTED_LANGUAGES.find((l) => l.code === lang) || SUPPORTED_LANGUAGES[0];

  useEffect(() => {
    if (!isOpen || !isSupported) return;

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    let recognition: any = null;

    const timer = setTimeout(() => {
      try {
        recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = true;
        recognition.lang = langConfig.speechLocale || 'en-IN';

        recognition.onstart = () => {
          setIsListening(true);
          setErrorMessage('');
        };

        recognition.onresult = (event: any) => {
          const current = event.resultIndex;
          const text = event.results[current][0].transcript;
          setTranscript(text);

          if (event.results[current].isFinal) {
            setTimeout(() => {
              onSearch(text);
              onClose();
            }, 800);
          }
        };

        recognition.onerror = (event: any) => {
          setIsListening(false);
          setErrorMessage(`Microphone: ${event.error || 'Permission denied or timed out'}`);
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        recognition.start();
      } catch (err: any) {
        setErrorMessage(err.message || 'Microphone initialization failed.');
      }
    }, 0);

    return () => {
      clearTimeout(timer);
      try {
        if (recognition) {
          recognition.abort();
        }
      } catch {}
    };
  }, [isOpen, isSupported, langConfig.speechLocale, onClose, onSearch]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl relative text-center">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Pulse / Mic Visualizer */}
        <div className="relative mx-auto my-6 flex items-center justify-center">
          {isListening && (
            <div className="absolute w-28 h-28 rounded-full bg-orange-400/25 animate-ping" />
          )}
          <div
            className={`w-20 h-20 rounded-full flex items-center justify-center transition-colors shadow-lg ${
              isListening
                ? 'bg-gradient-to-tr from-[#FF9933] to-amber-500 text-white'
                : 'bg-slate-100 text-slate-500'
            }`}
          >
            {isListening ? <Mic className="w-9 h-9" /> : <MicOff className="w-9 h-9" />}
          </div>
        </div>

        {/* Status text */}
        <h3 className="text-xl font-bold text-slate-900">
          {isListening ? t.voiceListening : 'Voice Search'}
        </h3>
        <p className="text-xs text-slate-500 mt-1">
          Language: <span className="font-semibold text-slate-700">{langConfig.nativeName} ({langConfig.englishName})</span>
        </p>

        {/* Live Transcript */}
        <div className="min-h-16 mt-4 p-3 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-center text-sm font-medium text-slate-800">
          {transcript ? (
            <span className="text-base text-[#071A2F] font-semibold">{transcript}</span>
          ) : (
            <span className="text-slate-400 italic">
              {isListening ? 'Speak now into your microphone...' : 'Say a search query'}
            </span>
          )}
        </div>

        {/* If unsupported or error, provide test sample queries */}
        {(!isSupported || errorMessage) && (
          <div className="mt-4 p-3 bg-amber-50 rounded-xl border border-amber-200 text-left">
            <div className="flex items-center space-x-2 text-xs font-semibold text-amber-900 mb-1">
              <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0" />
              <span>Voice Speech Simulation</span>
            </div>
            <p className="text-[11px] text-amber-700">
              Web Speech recognition requires microphone permission. You can also select a sample voice query below:
            </p>
            <div className="flex flex-wrap gap-1.5 mt-2">
              {['Chandrayaan 3 lunar mission', 'UPI payments network', 'Varanasi Ganga Aarti'].map(
                (sample) => (
                  <button
                    key={sample}
                    onClick={() => {
                      onSearch(sample);
                      onClose();
                    }}
                    className="text-xs px-2.5 py-1 bg-white hover:bg-amber-100 text-slate-800 border border-amber-300 rounded-md font-medium"
                  >
                    &ldquo;{sample}&rdquo;
                  </button>
                )
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
