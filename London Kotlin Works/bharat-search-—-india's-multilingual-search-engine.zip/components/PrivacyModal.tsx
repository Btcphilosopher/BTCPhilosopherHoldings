'use client';

import React from 'react';
import { X, ShieldCheck, Lock, EyeOff, Database, Check } from 'lucide-react';

interface PrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function PrivacyModal({ isOpen, onClose }: PrivacyModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl relative text-slate-800 max-h-[88vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-3 mb-5 pb-4 border-b border-slate-100">
          <div className="p-2.5 bg-sky-50 text-sky-700 rounded-xl">
            <Lock className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-slate-900">Privacy & Data Governance</h3>
            <p className="text-xs text-slate-500">
              Clear, transparent privacy principles for all Indian citizens
            </p>
          </div>
        </div>

        <div className="space-y-4 text-xs sm:text-sm text-slate-600 leading-relaxed">
          <div className="flex items-start space-x-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
            <EyeOff className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-semibold text-slate-900 text-xs">No Personal Search Profiling</h4>
              <p className="text-[11px] text-slate-600 mt-0.5">
                Bharat Search does not construct behavioral profiles, tracking cookies, or saleable advertising cohorts from your search queries.
              </p>
            </div>
          </div>

          <div className="flex items-start space-x-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
            <ShieldCheck className="w-5 h-5 text-sky-600 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-semibold text-slate-900 text-xs">Zero Client IP Retention</h4>
              <p className="text-[11px] text-slate-600 mt-0.5">
                Query logs are processed ephemerally. User IP addresses are stripped or anonymized at the edge before any telemetry aggregation.
              </p>
            </div>
          </div>

          <div className="flex items-start space-x-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
            <Database className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-semibold text-slate-900 text-xs">Sovereign Data Storage</h4>
              <p className="text-[11px] text-slate-600 mt-0.5">
                The search index, crawler states, and cache layers operate strictly within Indian jurisdiction under national data protection norms.
              </p>
            </div>
          </div>

          <div className="p-3 bg-blue-50 rounded-xl border border-blue-200 text-xs text-blue-900">
            <strong>Compliance Note:</strong> All external links open with strict{' '}
            <code className="font-mono text-[11px] bg-blue-100 px-1 py-0.5 rounded">rel=&quot;noopener noreferrer&quot;</code>{' '}
            protection to ensure your destination websites receive no session referrer leaks.
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold"
          >
            I Understand
          </button>
        </div>
      </div>
    </div>
  );
}
