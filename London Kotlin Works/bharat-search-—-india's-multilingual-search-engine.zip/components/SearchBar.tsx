'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Search, Mic, Camera, X, Loader2 } from 'lucide-react';
import { getTranslation } from '@/lib/languages';

interface SearchBarProps {
  initialQuery?: string;
  lang?: string;
  onSearch: (query: string) => void;
  onOpenVoice: () => void;
  onOpenVisual: () => void;
  isCompact?: boolean;
}

export function SearchBar({
  initialQuery = '',
  lang = 'en',
  onSearch,
  onOpenVoice,
  onOpenVisual,
  isCompact = false,
}: SearchBarProps) {
  const [query, setQuery] = useState(initialQuery);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const t = getTranslation(lang);

  const [prevInitial, setPrevInitial] = useState(initialQuery);
  if (initialQuery !== prevInitial) {
    setPrevInitial(initialQuery);
    setQuery(initialQuery);
  }

  // Fetch suggestions when query changes
  useEffect(() => {
    if (!query.trim()) return;

    const timer = setTimeout(async () => {
      setIsLoadingSuggestions(true);
      try {
        const res = await fetch(`/api/v1/suggest?q=${encodeURIComponent(query)}&lang=${lang}`);
        if (res.ok) {
          const data = await res.json();
          setSuggestions(data.suggestions || []);
        }
      } catch {
        // Silently ignore
      } finally {
        setIsLoadingSuggestions(false);
      }
    }, 180);

    return () => clearTimeout(timer);
  }, [query, lang]);

  // Click outside listener
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setShowSuggestions(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!query.trim()) return;
    setShowSuggestions(false);
    onSearch(query.trim());
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev < suggestions.length - 1 ? prev + 1 : 0));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev > 0 ? prev - 1 : suggestions.length - 1));
    } else if (e.key === 'Enter') {
      if (selectedIndex >= 0 && suggestions[selectedIndex]) {
        e.preventDefault();
        const selected = suggestions[selectedIndex];
        setQuery(selected);
        setShowSuggestions(false);
        onSearch(selected);
      } else {
        handleSubmit(e);
      }
    } else if (e.key === 'Escape') {
      setShowSuggestions(false);
    }
  };

  return (
    <div
      ref={containerRef}
      className={`relative w-full ${isCompact ? 'max-w-3xl' : 'max-w-3xl mx-auto'}`}
    >
      <form
        onSubmit={handleSubmit}
        className={`flex items-center w-full bg-white text-slate-800 rounded-full transition-all duration-200 ${
          isCompact
            ? 'h-11 px-4 shadow-sm border border-slate-200/80 hover:shadow-md'
            : 'h-14 sm:h-16 px-5 sm:px-6 shadow-[0_8px_30px_rgb(0,0,0,0.24)] hover:shadow-[0_12px_40px_rgb(0,0,0,0.3)]'
        } ${showSuggestions && suggestions.length > 0 ? 'rounded-b-none border-b-transparent' : ''}`}
      >
        {/* Search Icon */}
        <button
          type="submit"
          aria-label={t.webSearch}
          className="text-slate-400 hover:text-[#071A2F] transition-colors pr-3 sm:pr-4 flex items-center justify-center focus:outline-none"
        >
          <Search className={isCompact ? 'w-4 h-4' : 'w-5 h-5 sm:w-6 sm:h-6 text-slate-500'} />
        </button>

        {/* Query Input */}
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setShowSuggestions(true);
            setSelectedIndex(-1);
          }}
          onFocus={() => setShowSuggestions(true)}
          onKeyDown={handleKeyDown}
          placeholder={t.searchPlaceholder}
          className={`w-full bg-transparent text-slate-800 placeholder-slate-400 focus:outline-none font-normal ${
            isCompact ? 'text-sm sm:text-base' : 'text-base sm:text-lg'
          }`}
          autoComplete="off"
          spellCheck="false"
        />

        {/* Clear Button */}
        {query && (
          <button
            type="button"
            onClick={() => {
              setQuery('');
              setSuggestions([]);
              inputRef.current?.focus();
            }}
            aria-label={t.clear}
            className="p-1 mr-1 text-slate-400 hover:text-slate-600 transition-colors rounded-full hover:bg-slate-100"
          >
            <X className="w-4 h-4" />
          </button>
        )}

        {/* Divider */}
        <div className="h-5 w-[1px] bg-slate-200 mx-1.5" />

        {/* Voice Input Button */}
        <button
          type="button"
          onClick={onOpenVoice}
          aria-label="Voice Search"
          title="Search by voice"
          className="p-2 text-slate-600 hover:text-[#FF9933] transition-colors rounded-full hover:bg-orange-50 focus:outline-none"
        >
          <Mic className={isCompact ? 'w-4 h-4' : 'w-5 h-5'} />
        </button>

        {/* Visual / Image Search Button */}
        <button
          type="button"
          onClick={onOpenVisual}
          aria-label="Search by image"
          title="Search by image or visual landmark"
          className="p-2 text-slate-600 hover:text-[#138808] transition-colors rounded-full hover:bg-emerald-50 focus:outline-none"
        >
          <Camera className={isCompact ? 'w-4 h-4' : 'w-5 h-5'} />
        </button>
      </form>

      {/* Suggestion Dropdown */}
      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute left-0 right-0 top-full bg-white rounded-b-2xl shadow-xl border border-t-0 border-slate-200 overflow-hidden z-50">
          <ul className="py-2">
            {suggestions.map((suggestion, idx) => (
              <li
                key={idx}
                onMouseEnter={() => setSelectedIndex(idx)}
                onClick={() => {
                  setQuery(suggestion);
                  setShowSuggestions(false);
                  onSearch(suggestion);
                }}
                className={`flex items-center px-5 py-2.5 text-sm sm:text-base cursor-pointer transition-colors ${
                  selectedIndex === idx
                    ? 'bg-slate-100 text-[#071A2F] font-medium'
                    : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Search className="w-4 h-4 text-slate-400 mr-3 flex-shrink-0" />
                <span className="truncate">{suggestion}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
