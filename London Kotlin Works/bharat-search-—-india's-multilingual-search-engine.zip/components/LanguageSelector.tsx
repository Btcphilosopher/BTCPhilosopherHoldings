'use client';

import React from 'react';
import { SUPPORTED_LANGUAGES, LanguageConfig } from '@/lib/languages';

interface LanguageSelectorProps {
  currentLang: string;
  onSelectLang: (langCode: string) => void;
}

export function LanguageSelector({ currentLang, onSelectLang }: LanguageSelectorProps) {
  return (
    <div className="w-full max-w-6xl mx-auto px-4 mt-6">
      <div className="grid grid-cols-2 sm:grid-cols-5 md:grid-cols-10 gap-2 sm:gap-2.5">
        {SUPPORTED_LANGUAGES.map((lang: LanguageConfig) => {
          const isActive = currentLang === lang.code;
          return (
            <button
              key={lang.code}
              onClick={() => onSelectLang(lang.code)}
              className={`group relative flex flex-col items-center justify-center py-2.5 px-2 rounded-xl transition-all duration-200 border ${
                isActive
                  ? 'bg-slate-900/80 border-slate-600/80 shadow-lg scale-105'
                  : 'bg-slate-950/40 hover:bg-slate-900/60 border-slate-700/40 hover:border-slate-600/60'
              } backdrop-blur-md`}
              title={`Switch language to ${lang.englishName} (${lang.nativeName})`}
            >
              {/* Native Script Title */}
              <span
                className={`text-sm sm:text-base font-semibold tracking-wide transition-colors ${
                  isActive ? 'text-white' : 'text-slate-200 group-hover:text-white'
                }`}
              >
                {lang.nativeName}
              </span>

              {/* English Transliteration */}
              <span className="text-[11px] text-slate-400 group-hover:text-slate-300 font-normal mt-0.5">
                {lang.englishName}
              </span>

              {/* Accent colored indicator bar */}
              <div
                className={`h-1 w-7 rounded-full mt-1.5 transition-all duration-200 ${
                  isActive
                    ? 'opacity-100 scale-100'
                    : 'opacity-40 group-hover:opacity-80 scale-75 group-hover:scale-90'
                }`}
                style={{ backgroundColor: lang.accentHex }}
              />
            </button>
          );
        })}
      </div>
    </div>
  );
}
