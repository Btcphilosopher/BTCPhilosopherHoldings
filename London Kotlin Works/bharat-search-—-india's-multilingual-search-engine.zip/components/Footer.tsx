'use client';

import React from 'react';
import { getTranslation } from '@/lib/languages';

interface FooterProps {
  lang: string;
  onOpenAbout: () => void;
  onOpenPrivacy: () => void;
  onOpenCrawler: () => void;
}

export function Footer({
  lang,
  onOpenAbout,
  onOpenPrivacy,
  onOpenCrawler,
}: FooterProps) {
  const t = getTranslation(lang);

  return (
    <footer className="w-full mt-auto py-8 sm:py-10 px-4 text-center z-10 relative">
      {/* Centered Tricolor Divider */}
      <div className="flex flex-col items-center justify-center mb-6">
        <div className="flex items-center space-x-3 w-full max-w-xs justify-center">
          <div className="h-[1px] flex-1 bg-gradient-to-r from-transparent to-slate-400/40" />
          <span className="text-[11px] sm:text-xs uppercase tracking-[0.25em] font-semibold text-slate-300 whitespace-nowrap">
            {t.indiasSearchEngine}
          </span>
          <div className="h-[1px] flex-1 bg-gradient-to-l from-transparent to-slate-400/40" />
        </div>

        {/* Indian Tricolor Pill Line */}
        <div className="flex items-center space-x-1 mt-2">
          <div className="h-1 w-6 rounded-full bg-[#FF9933]" />
          <div className="h-1 w-6 rounded-full bg-white shadow-xs" />
          <div className="h-1 w-6 rounded-full bg-[#138808]" />
        </div>
      </div>

      {/* Footer Navigation Links */}
      <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-8 text-xs text-slate-300">
        <button
          onClick={onOpenAbout}
          className="hover:text-white transition-colors hover:underline"
        >
          {t.about} Bharat Search
        </button>
        <button
          onClick={onOpenPrivacy}
          className="hover:text-white transition-colors hover:underline"
        >
          {t.privacy}
        </button>
        <button
          onClick={onOpenCrawler}
          className="hover:text-white transition-colors hover:underline"
        >
          {t.crawlerAdmin}
        </button>
        <a
          href="/api/v1/health"
          target="_blank"
          rel="noopener noreferrer"
          className="hover:text-white transition-colors hover:underline"
        >
          API Status & Docs
        </a>
      </div>

      <p className="text-[11px] text-slate-400 mt-3 font-light">
        Empowering 1.4 Billion Citizens with Open Multilingual Information Access
      </p>
    </footer>
  );
}
