'use client';

import React from 'react';
import { Globe, Newspaper, Image as ImageIcon, LayoutGrid } from 'lucide-react';
import { getTranslation } from '@/lib/languages';
import { SearchCategory } from '@/lib/search/types';

interface CategoryNavProps {
  lang: string;
  activeCategory: SearchCategory | 'more';
  onSelectCategory: (cat: SearchCategory | 'more') => void;
}

export function CategoryNav({ lang, activeCategory, onSelectCategory }: CategoryNavProps) {
  const t = getTranslation(lang);

  const categories = [
    {
      id: 'web' as const,
      icon: Globe,
      title: t.webSearch,
      subtitle: t.webSearchSubtitle,
    },
    {
      id: 'news' as const,
      icon: Newspaper,
      title: t.news,
      subtitle: t.newsSubtitle,
    },
    {
      id: 'images' as const,
      icon: ImageIcon,
      title: t.images,
      subtitle: t.imagesSubtitle,
    },
    {
      id: 'more' as const,
      icon: LayoutGrid,
      title: t.more,
      subtitle: t.moreSubtitle,
    },
  ];

  return (
    <div className="w-full max-w-5xl mx-auto px-4 mt-8 sm:mt-12">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
        {categories.map((item) => {
          const Icon = item.icon;
          const isActive = activeCategory === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onSelectCategory(item.id)}
              className={`flex items-center space-x-3.5 p-3 sm:p-4 rounded-xl border transition-all duration-200 text-left ${
                isActive
                  ? 'bg-slate-900/85 border-[#FF9933]/60 shadow-lg shadow-black/40'
                  : 'bg-slate-950/40 hover:bg-slate-900/60 border-slate-700/40 hover:border-slate-600/60'
              } backdrop-blur-md group`}
            >
              <div
                className={`p-2.5 rounded-lg transition-colors ${
                  isActive
                    ? 'bg-[#FF9933]/20 text-[#FF9933]'
                    : 'bg-slate-800/60 text-slate-300 group-hover:text-white group-hover:bg-slate-700/60'
                }`}
              >
                <Icon className="w-5 h-5 sm:w-6 sm:h-6" />
              </div>
              <div className="overflow-hidden">
                <div
                  className={`text-sm sm:text-base font-semibold truncate ${
                    isActive ? 'text-white' : 'text-slate-100 group-hover:text-white'
                  }`}
                >
                  {item.title}
                </div>
                <div className="text-[11px] sm:text-xs text-slate-400 group-hover:text-slate-300 truncate">
                  {item.subtitle}
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
