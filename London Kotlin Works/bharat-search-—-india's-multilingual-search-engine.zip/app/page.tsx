'use client';

import React, { useState, useEffect } from 'react';
import { Header } from '@/components/Header';
import { BharatSearchLogo } from '@/components/Emblem';
import { SearchBar } from '@/components/SearchBar';
import { LanguageSelector } from '@/components/LanguageSelector';
import { CategoryNav } from '@/components/CategoryNav';
import { Footer } from '@/components/Footer';
import { SearchResults } from '@/components/SearchResults';
import { VoiceSearchModal } from '@/components/VoiceSearchModal';
import { VisualSearchModal } from '@/components/VisualSearchModal';
import { CrawlerAdminModal } from '@/components/CrawlerAdminModal';
import { AboutModal } from '@/components/AboutModal';
import { PrivacyModal } from '@/components/PrivacyModal';
import { SearchCategory, SearchResponse } from '@/lib/search/types';
import { getTranslation, SUPPORTED_LANGUAGES } from '@/lib/languages';

export default function HomePage() {
  // Initialize language preference from localStorage
  const [currentLang, setCurrentLang] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      try {
        const savedLang = localStorage.getItem('bharat_search_lang');
        if (savedLang && SUPPORTED_LANGUAGES.some((l) => l.code === savedLang)) {
          return savedLang;
        }
      } catch {}
    }
    return 'en';
  });
  const [viewMode, setViewMode] = useState<'home' | 'results'>('home');
  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<SearchCategory>('web');

  // Search Results State
  const [searchResponse, setSearchResponse] = useState<SearchResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);

  // Modals
  const [isVoiceOpen, setIsVoiceOpen] = useState(false);
  const [isVisualOpen, setIsVisualOpen] = useState(false);
  const [isCrawlerOpen, setIsCrawlerOpen] = useState(false);
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);

  const handleSelectLang = (code: string) => {
    setCurrentLang(code);
    try {
      localStorage.setItem('bharat_search_lang', code);
    } catch {}

    // If on results page, re-query with new language
    if (viewMode === 'results' && query) {
      triggerSearch(query, activeCategory, 1, code);
    }
  };

  const triggerSearch = async (
    q: string,
    category: SearchCategory = 'web',
    page = 1,
    lang = currentLang
  ) => {
    if (!q.trim()) return;

    setQuery(q);
    setActiveCategory(category);
    setViewMode('results');
    setIsLoading(true);
    setSearchError(null);

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });

    try {
      const params = new URLSearchParams({
        q,
        category,
        page: page.toString(),
        lang,
      });

      const res = await fetch(`/api/v1/search?${params.toString()}`);
      if (!res.ok) {
        throw new Error(`Search service error (${res.status})`);
      }

      const data: SearchResponse = await res.json();
      setSearchResponse(data);
    } catch (err: any) {
      setSearchError(err.message || 'Failed to retrieve search results.');
    } finally {
      setIsLoading(false);
    }
  };

  const currentLangConfig =
    SUPPORTED_LANGUAGES.find((l) => l.code === currentLang) || SUPPORTED_LANGUAGES[0];
  const isRTL = currentLangConfig.dir === 'rtl';
  const t = getTranslation(currentLang);

  return (
    <div
      dir={isRTL ? 'rtl' : 'ltr'}
      className={`min-h-screen font-sans ${currentLangConfig.fontClass}`}
    >
      {viewMode === 'home' ? (
        /* HOMEPAGE VIEW - MATCHING THE BHARAT SEARCH DESIGN */
        <div className="relative min-h-screen flex flex-col justify-between overflow-x-hidden bg-[#071A2F]">
          {/* Panoramic Indian Heritage & Futuristic Sunset Backdrop */}
          <div
            className="absolute inset-0 bg-cover bg-center bg-no-repeat z-0"
            style={{
              backgroundImage: `url('/bharat_hero_bg.jpg')`,
            }}
          >
            {/* Multi-layered atmospheric gradients for readability */}
            <div className="absolute inset-0 bg-gradient-to-b from-[#071A2F]/85 via-[#071A2F]/40 to-[#071A2F]/90" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#071A2F] via-transparent to-transparent opacity-95" />
          </div>

          {/* Top Header */}
          <Header
            lang={currentLang}
            onHomeClick={() => setViewMode('home')}
            onOpenAbout={() => setIsAboutOpen(true)}
            onOpenPrivacy={() => setIsPrivacyOpen(true)}
            onOpenCrawler={() => setIsCrawlerOpen(true)}
          />

          {/* Central Search Section */}
          <main className="relative z-10 w-full flex-1 flex flex-col items-center justify-center px-4 my-auto py-8">
            {/* Center Brand: Tricolor Peacock & Ashoka Chakra Logo */}
            <div className="flex flex-col items-center text-center mb-7 sm:mb-8">
              <div className="flex items-center justify-center space-x-3 sm:space-x-4 mb-2">
                <BharatSearchLogo className="w-16 h-16 sm:w-20 sm:h-20 drop-shadow-[0_10px_25px_rgba(0,0,0,0.5)] transition-transform hover:scale-105" />
                <h1 className="text-4xl sm:text-6xl md:text-7xl font-bold tracking-tight text-white drop-shadow-[0_4px_16px_rgba(0,0,0,0.6)]">
                  Bharat Search
                </h1>
              </div>

              {/* Tagline */}
              <p className="text-sm sm:text-lg text-slate-200/90 font-medium tracking-wide drop-shadow-md max-w-xl">
                {t.tagline}
              </p>
            </div>

            {/* Central Search Bar */}
            <SearchBar
              initialQuery={query}
              lang={currentLang}
              onSearch={(q) => triggerSearch(q, 'web', 1)}
              onOpenVoice={() => setIsVoiceOpen(true)}
              onOpenVisual={() => setIsVisualOpen(true)}
            />

            {/* 10 Indian Language Selector Cards */}
            <LanguageSelector
              currentLang={currentLang}
              onSelectLang={handleSelectLang}
            />

            {/* Bottom Category Cards: Web, News, Images, More */}
            <CategoryNav
              lang={currentLang}
              activeCategory={activeCategory}
              onSelectCategory={(cat) => {
                if (cat === 'more') {
                  setIsCrawlerOpen(true);
                } else {
                  setActiveCategory(cat as SearchCategory);
                  if (query) {
                    triggerSearch(query, cat as SearchCategory, 1);
                  } else {
                    // Seed initial category query
                    triggerSearch('India', cat as SearchCategory, 1);
                  }
                }
              }}
            />
          </main>

          {/* Footer with Centered Tricolor Divider */}
          <Footer
            lang={currentLang}
            onOpenAbout={() => setIsAboutOpen(true)}
            onOpenPrivacy={() => setIsPrivacyOpen(true)}
            onOpenCrawler={() => setIsCrawlerOpen(true)}
          />
        </div>
      ) : (
        /* SEARCH RESULTS VIEW */
        <SearchResults
          response={searchResponse}
          isLoading={isLoading}
          error={searchError}
          currentQuery={query}
          currentCategory={activeCategory}
          currentLang={currentLang}
          onSearch={(q, cat, page) => triggerSearch(q, cat || activeCategory, page || 1)}
          onCategoryChange={(cat) => triggerSearch(query, cat, 1)}
          onLangChange={handleSelectLang}
          onGoHome={() => setViewMode('home')}
          onOpenVoice={() => setIsVoiceOpen(true)}
          onOpenVisual={() => setIsVisualOpen(true)}
        />
      )}

      {/* Interactive Modals */}
      <VoiceSearchModal
        isOpen={isVoiceOpen}
        onClose={() => setIsVoiceOpen(false)}
        onSearch={(transcript) => triggerSearch(transcript, 'web', 1)}
        lang={currentLang}
      />

      <VisualSearchModal
        isOpen={isVisualOpen}
        onClose={() => setIsVisualOpen(false)}
        onSearch={(visualQuery) => triggerSearch(visualQuery, 'images', 1)}
        lang={currentLang}
      />

      <CrawlerAdminModal
        isOpen={isCrawlerOpen}
        onClose={() => setIsCrawlerOpen(false)}
      />

      <AboutModal
        isOpen={isAboutOpen}
        onClose={() => setIsAboutOpen(false)}
      />

      <PrivacyModal
        isOpen={isPrivacyOpen}
        onClose={() => setIsPrivacyOpen(false)}
      />
    </div>
  );
}
