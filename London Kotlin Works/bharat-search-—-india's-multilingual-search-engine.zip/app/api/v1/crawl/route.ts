import { NextRequest, NextResponse } from 'next/server';
import { crawlSingleUrl, getCrawlerStatus } from '@/lib/crawler/crawler';
import { getIndexStats } from '@/lib/search/local-index';

export const dynamic = 'force-dynamic';

export async function GET() {
  const status = getCrawlerStatus();
  const indexStats = getIndexStats();

  return NextResponse.json({
    ...status,
    indexStats,
  });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const url = body.url;

    if (!url || typeof url !== 'string') {
      return NextResponse.json(
        { success: false, message: 'URL string is required in JSON body.' },
        { status: 400 }
      );
    }

    const result = await crawlSingleUrl(url);

    return NextResponse.json(result, {
      status: result.success ? 200 : 422,
    });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, message: error.message || 'Crawl execution error' },
      { status: 500 }
    );
  }
}
