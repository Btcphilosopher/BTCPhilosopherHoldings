import { GET } from '@/app/health/route';

export { GET };
export const dynamic = 'force-dynamic';
