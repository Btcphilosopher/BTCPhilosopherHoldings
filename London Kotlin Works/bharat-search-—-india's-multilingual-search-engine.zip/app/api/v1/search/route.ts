import { NextRequest, NextResponse } from 'next/server';
import { executeSearch } from '@/lib/search/search-service';
import { SearchCategory } from '@/lib/search/types';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);

    const q = searchParams.get('q') || '';
    const lang = searchParams.get('lang') || undefined;
    const regionParam = searchParams.get('region');
    const region = regionParam === 'all' ? 'all' : 'in';
    const page = parseInt(searchParams.get('page') || '1', 10);
    const pageSize = parseInt(searchParams.get('page_size') || '10', 10);
    const safeSearch = searchParams.get('safe_search') !== 'false';
    const category = (searchParams.get('category') || 'web') as SearchCategory;
    const sourceParam = searchParams.get('source');
    const source = sourceParam === 'local' ? 'local' : sourceParam === 'web' ? 'web' : 'auto';
    const timeFilter = (searchParams.get('time') || 'all') as any;

    const validatedPage = isNaN(page) || page < 1 ? 1 : page;
    const validatedPageSize = isNaN(pageSize) || pageSize < 1 || pageSize > 50 ? 10 : pageSize;

    const response = await executeSearch({
      q,
      lang,
      region,
      page: validatedPage,
      pageSize: validatedPageSize,
      safeSearch,
      category,
      source,
      timeFilter,
    });

    return NextResponse.json(response, {
      status: 200,
      headers: {
        'Cache-Control': 'public, s-maxage=60, stale-while-revalidate=120',
        'X-Content-Type-Options': 'nosniff',
        'X-Frame-Options': 'SAMEORIGIN',
      },
    });
  } catch (error: any) {
    return NextResponse.json(
      {
        error: 'Failed to execute search query',
        message: error.message || 'Internal server error',
        executionTimeMs: 0,
      },
      { status: 500 }
    );
  }
}
