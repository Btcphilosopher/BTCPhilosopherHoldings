import { NextRequest, NextResponse } from 'next/server';
import { getSearchSuggestions } from '@/lib/search/search-service';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const q = searchParams.get('q') || '';
  const lang = searchParams.get('lang') || 'en';

  const suggestions = getSearchSuggestions(q, lang);

  return NextResponse.json(
    {
      query: q,
      suggestions,
    },
    {
      status: 200,
      headers: {
        'Cache-Control': 'public, s-maxage=300',
      },
    }
  );
}
