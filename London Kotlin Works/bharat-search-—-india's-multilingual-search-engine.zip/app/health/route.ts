import { NextResponse } from 'next/server';
import { getIndexStats } from '@/lib/search/local-index';
import { getCrawlerStatus } from '@/lib/crawler/crawler';

export const dynamic = 'force-dynamic';

export async function GET() {
  const indexStats = getIndexStats();
  const crawler = getCrawlerStatus();

  return NextResponse.json({
    status: 'healthy',
    engine: 'Bharat Search Sovereign Engine',
    version: '1.0.0-mvp',
    timestamp: new Date().toISOString(),
    indexStats,
    crawler: {
      isRunning: crawler.isRunning,
      indexedCount: crawler.indexedCount,
    },
    services: {
      localIndex: 'online',
      crawlerEngine: 'online',
      webGateway: 'online',
    },
  });
}
