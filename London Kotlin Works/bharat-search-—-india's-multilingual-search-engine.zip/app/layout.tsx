import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Bharat Search — India\'s Multilingual Search Engine',
  description: 'Find what matters. In your language. A sovereign, multilingual, privacy-conscious search engine for India supporting 10+ official languages.',
  keywords: [
    'Bharat Search',
    'India search engine',
    'multilingual search',
    'Hindi search',
    'Tamil search',
    'Telugu search',
    'Bengali search',
    'sovereign search engine',
    'Digital India',
  ],
  authors: [{ name: 'Bharat Search Sovereign Project' }],
  openGraph: {
    title: 'Bharat Search — India\'s Multilingual Search Engine',
    description: 'Find what matters. In your language. Sovereign multilingual search engine built for India.',
    type: 'website',
    locale: 'en_IN',
    siteName: 'Bharat Search',
    images: [
      {
        url: '/bharat_hero_bg.jpg',
        width: 1920,
        height: 1080,
        alt: 'Bharat Search - Sovereign Search Engine for India',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Bharat Search — India\'s Multilingual Search Engine',
    description: 'Find what matters. In your language. Built for India.',
    images: ['/bharat_hero_bg.jpg'],
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="bg-[#071A2F] text-slate-100 antialiased selection:bg-[#FF9933]/30 selection:text-white" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
