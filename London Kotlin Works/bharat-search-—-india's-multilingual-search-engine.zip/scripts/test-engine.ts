/**
 * Bharat Search - Automated Test Suite
 * Validates BM25 ranking, Crawler, SSRF Protections, Language System & Search Pipeline
 */

import { searchLocalIndex, getIndexStats, indexDocument, tokenize } from '../lib/search/local-index';
import { validateUrlForSSRF, normalizeUrl, parseHtmlContent } from '../lib/crawler/crawler';
import { executeSearch, getSearchSuggestions } from '../lib/search/search-service';
import { detectScript, SUPPORTED_LANGUAGES, getTranslation } from '../lib/languages';

let passed = 0;
let failed = 0;

function assert(condition: boolean, message: string) {
  if (condition) {
    console.log(`  ✓ ${message}`);
    passed++;
  } else {
    console.error(`  ✗ FAIL: ${message}`);
    failed++;
  }
}

async function runTests() {
  console.log('\n========================================');
  console.log('   BHARAT SEARCH AUTOMATED TEST SUITE   ');
  console.log('========================================\n');

  // TEST SUITE 1: Language System & Script Detection
  console.log('1. Testing Language System & Multi-Script Detection...');
  assert(SUPPORTED_LANGUAGES.length === 10, 'Supports exactly 10 official Indian languages');
  
  const urduLang = SUPPORTED_LANGUAGES.find((l) => l.code === 'ur');
  assert(urduLang?.dir === 'rtl', 'Urdu is configured with RTL direction');

  assert(detectScript('चंद्रयान 3') === 'hi', 'Detects Devanagari script (Hindi)');
  assert(detectScript('திருக்குறள்') === 'ta', 'Detects Tamil script');
  assert(detectScript('డిజిటల్ ఇండియా') === 'te', 'Detects Telugu script');
  assert(detectScript('গীতাঞ্জলি') === 'bn', 'Detects Bengali script');
  assert(detectScript('مرزا غالب') === 'ur', 'Detects Perso-Arabic script (Urdu)');
  assert(detectScript('Chandrayaan 3') === 'en', 'Detects Latin script (English)');

  const hiTrans = getTranslation('hi');
  assert(Boolean(hiTrans.tagline && hiTrans.searchPlaceholder), 'Hindi translation dictionary complete');

  // TEST SUITE 2: SSRF & Security Protections
  console.log('\n2. Testing Crawler SSRF & Network Security...');
  assert(!validateUrlForSSRF('http://localhost:3000').valid, 'Rejects localhost target');
  assert(!validateUrlForSSRF('http://127.0.0.1/admin').valid, 'Rejects 127.0.0.1 loopback');
  assert(!validateUrlForSSRF('http://169.254.169.254/latest/meta-data/').valid, 'Rejects Cloud Metadata IP (169.254.169.254)');
  assert(!validateUrlForSSRF('http://10.0.0.1/internal').valid, 'Rejects RFC1918 10.0.0.0/8 private network');
  assert(!validateUrlForSSRF('http://192.168.1.1/router').valid, 'Rejects RFC1918 192.168.0.0/16 private network');
  assert(!validateUrlForSSRF('ftp://isro.gov.in').valid, 'Rejects non-HTTP(S) protocols');
  assert(validateUrlForSSRF('https://isro.gov.in').valid, 'Permits valid public HTTPS website');

  // TEST SUITE 3: Crawler Normalization & HTML Extraction
  console.log('\n3. Testing URL Normalization & Content Extraction...');
  const normalized = normalizeUrl('https://isro.gov.in/page/?utm_source=twitter&utm_medium=social#overview');
  assert(!normalized.includes('utm_source') && !normalized.includes('#overview'), 'Strips tracking params and fragments');

  const sampleHtml = `
    <!DOCTYPE html>
    <html lang="hi">
      <head>
        <title>इसरो चंद्रयान मिशन</title>
        <meta name="description" content="भारत का ऐतिहासिक चंद्र मिशन" />
      </head>
      <body>
        <h1>मुख्य उपलब्धियां</h1>
        <p>विक्रम लैंडर ने चंद्रमा के दक्षिणी ध्रुव पर सफल लैंडिंग की।</p>
      </body>
    </html>
  `;
  const parsed = parseHtmlContent(sampleHtml, 'https://isro.gov.in');
  assert(parsed.title === 'इसरो चंद्रयान मिशन', 'Extracts page title correctly');
  assert(parsed.snippet === 'भारत का ऐतिहासिक चंद्र मिशन', 'Extracts meta description snippet');
  assert(parsed.headings.includes('मुख्य उपलब्धियां'), 'Extracts h1/h2 headings');
  assert(parsed.language === 'hi', 'Detects Hindi language tag from HTML');

  // TEST SUITE 4: BM25 Sovereign Local Index
  console.log('\n4. Testing BM25 Scoring & Sovereign Retrieval...');
  const stats = getIndexStats();
  assert(stats.totalDocuments >= 10, `Index initialized with seed documents (${stats.totalDocuments} docs)`);

  const searchRes1 = searchLocalIndex('Chandrayaan', { category: 'web' });
  assert(searchRes1.results.length > 0, 'Retrieves documents matching "Chandrayaan"');
  assert(searchRes1.results[0].title.toLowerCase().includes('chandrayaan'), 'Top result has Chandrayaan in title');
  assert(searchRes1.results[0].provider === 'local-index', 'Source provider is local-index');

  const searchRes2 = searchLocalIndex('UPI payments', { category: 'web' });
  assert(searchRes2.results.length > 0, 'Retrieves documents matching "UPI payments"');
  assert(searchRes2.results[0].domain.includes('npci.org.in'), 'Top result for UPI is from npci.org.in');

  // Multilingual query search
  const hindiSearch = searchLocalIndex('वाराणसी घाट', { category: 'web' });
  assert(hindiSearch.results.length > 0, 'Retrieves documents for Hindi query "वाराणसी घाट"');

  // TEST SUITE 5: Search Suggestions & Knowledge Graph
  console.log('\n5. Testing Search Suggestions & Knowledge Graph...');
  const suggestions = getSearchSuggestions('isro');
  assert(suggestions.length > 0, 'Returns suggestions for query "isro"');
  assert(suggestions.some((s) => s.includes('chandrayaan')), 'Suggestions include relevant topics');

  // TEST SUITE 6: End-to-End Search Orchestrator
  console.log('\n6. Testing End-to-End Search Execution...');
  const executionRes = await executeSearch({
    q: 'Varanasi',
    category: 'web',
    lang: 'en',
    pageSize: 10,
  });

  assert(executionRes.originalQuery === 'Varanasi', 'Maintains original query');
  assert(executionRes.executionTimeMs >= 0, 'Records execution latency in ms');
  assert(Boolean(executionRes.knowledgeCard), 'Returns instant Knowledge Card for Varanasi');
  assert(executionRes.results.length > 0, 'Returns structured results');
  assert(executionRes.results[0].url.startsWith('http'), 'Result contains valid external URL');

  // Categories test
  const newsRes = await executeSearch({ q: 'Semiconductor', category: 'news' });
  assert(newsRes.results.length > 0, 'Returns news items for Semiconductor');

  const imgRes = await executeSearch({ q: 'sunset', category: 'images' });
  assert(imgRes.results.length > 0, 'Returns image items with dimensions');

  console.log('\n========================================');
  console.log(`TEST RUN COMPLETE: ${passed} PASSED, ${failed} FAILED`);
  console.log('========================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runTests().catch((err) => {
  console.error('Unhandled test failure:', err);
  process.exit(1);
});
