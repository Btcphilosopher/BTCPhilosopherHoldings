# Bharat Search — India's Multilingual Search Engine

> **Tagline:** Find what matters. In your language.  
> **Mission:** A sovereign, privacy-conscious search engine built for India, supporting 10+ official languages with an independent retrieval index and crawler pipeline.

---

## 1. Architecture Overview

Bharat Search is architected across three developmental stages:

```
┌────────────────────────────────────────────────────────────────────────┐
│                   BHARAT SEARCH FRONTEND (Next.js 15)                  │
│   • Sovereign Tricolor Visual Identity (Varanasi Ghats & Modern India) │
│   • 10 Official Indian Languages (Devanagari, Tamil, Telugu, Urdu RTL) │
│   • Web, News, Images, Videos, Maps, Shopping Category Adapters        │
│   • Speech Recognition Voice Input & Reverse Visual Search             │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ HTTP / JSON
┌───────────────────────────────────▼────────────────────────────────────┐
│                    SEARCH ORCHESTRATION PIPELINE                       │
│  GET /api/v1/search?q=...&lang=...&region=...&safe_search=...          │
└───────────────┬───────────────────────────────┬────────────────────────┘
                │                               │
┌───────────────▼──────────────┐ ┌──────────────▼────────────────────────┐
│   SOVEREIGN LOCAL INDEX      │ │           LIVE WEB GATEWAY            │
│ • BM25 Inverted Index Score  │ │ • Wikipedia Open Search API           │
│ • Field Boost (Title 3.5x)   │ │ • Authentic Public Web Feeds          │
│ • Language Affinity Boost    │ │ • Zero Hallucination / No Mock Data   │
│ • Instant Knowledge FactCard │ └───────────────────────────────────────┘
└───────────────▲──────────────┘
                │
┌───────────────┴────────────────────────────────────────────────────────┐
│               CONTROLLED WEB CRAWLER & INDEXING ENGINE                 │
│ • Robots.txt Compliance & Rate Limiting                                │
│ • Strict SSRF Shields (Blocks Loopback, RFC1918 & Cloud Metadata IPs)  │
│ • Canonical URL Normalizer & Content Hash Deduplication                │
│ • Live Dynamic Document Ingestion into Sovereign Index                 │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Supported Languages

| Language | Native Name | Script | Direction | Accent Color |
|---|---|---|---|---|
| **Hindi** | हिन्दी | Devanagari | LTR | Saffron `#FF9933` |
| **English** | English | Latin | LTR | Sky Blue `#38BDF8` |
| **Tamil** | தமிழ் | Tamil | LTR | Purple `#A855F7` |
| **Telugu** | తెలుగు | Telugu | LTR | Emerald `#10B981` |
| **Bengali** | বাংলা | Bengali | LTR | Rose `#F43F5E` |
| **Gujarati** | ગુજરાતી | Gujarati | LTR | Amber `#FBBF24` |
| **Kannada** | ಕನ್ನಡ | Kannada | LTR | Teal `#2DD4BF` |
| **Marathi** | मराठी | Devanagari | LTR | Gold `#EAB308` |
| **Urdu** | اردو | Perso-Arabic | **RTL** | Green `#22C55E` |
| **Malayalam** | മലയാളം | Malayalam | LTR | Fuchsia `#D946EF` |

---

## 3. Core Features

1. **Sovereign Local Search Engine**: Full BM25 relevance implementation with inverted index, field weighting (Title 3.5x, Headings 2.2x, Snippet 1.6x, Body 1.0x), exact-phrase matching bonus, and Indian language affinity multipliers.
2. **Instant Knowledge Graph (FactSheets)**: Dedicated factual Infoboxes for queries like *Chandrayaan-3*, *UPI*, *Varanasi*, *ISRO*, and *Aadhaar*.
3. **Controlled Web Crawler**:
   - Descriptive User-Agent: `BharatSearchBot/1.0 (+https://bharatsearch.in/bot)`.
   - Robots.txt enforcement and crawl rate control.
   - Comprehensive SSRF protection blocking `127.0.0.1`, `::1`, `169.254.169.254`, `10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16`.
   - Content hash deduplication and automatic document ingestion.
4. **Category Adapters**:
   - **Web Search**: Ranked sources, breadcrumbs, snippet highlights, sovereign badges.
   - **News**: Fresh Indian headlines, publication time-ago, topic tags.
   - **Images**: High-resolution image grid with dimensions and full preview lightbox.
   - **Videos**: Video previews with duration badges, publisher, and views.
   - **Maps**: Indian coordinates, place details, and OpenStreetMap directions.
   - **Shopping**: Indian e-commerce items with prices in INR (₹) and merchant information.
5. **Voice & Visual Search**:
   - Web Speech API integration with language-specific speech locale matching.
   - Visual search modal with image upload, URL paste, and sample Indian heritage presets.

---

## 4. API Endpoints

### `GET /api/v1/search`
Query parameters:
- `q`: Search query string (required)
- `lang`: Language code (`hi`, `en`, `ta`, `te`, `bn`, `gu`, `kn`, `mr`, `ur`, `ml`)
- `category`: `web` | `news` | `images` | `videos` | `maps` | `shopping`
- `region`: `in` (India) | `all`
- `page`: Page number (default: 1)
- `page_size`: Results per page (default: 10)
- `safe_search`: `true` | `false`
- `source`: `auto` | `local` | `web`

### `GET /api/v1/suggest?q=...&lang=...`
Returns auto-complete query suggestions.

### `GET /api/v1/crawl` & `POST /api/v1/crawl`
- `GET`: Returns active seeds, indexed document counts, and crawl execution logs.
- `POST`: Triggers a crawl on a permitted public URL.

### `GET /api/v1/health` & `GET /health`
Returns system status, service health, and index statistics.

---

## 5. Running Tests

Run the automated test suite verifying BM25 scoring, SSRF security, multi-script detection, and the search pipeline:

```bash
npm test
# or
npx tsx scripts/test-engine.ts
```

All 37 test assertions will execute and output detailed diagnostic status.

---

## 6. Local Development & Deployment

### Quick Start
```bash
npm install
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

### Docker Deployment
```bash
docker compose up -d --build
```
Access the application on port 3000 with automatic health monitoring.
