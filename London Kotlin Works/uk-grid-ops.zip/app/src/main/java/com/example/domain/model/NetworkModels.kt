package com.example.domain.model

enum class VoltageLevel(val kv: Double, val label: String, val classification: String) {
    KV_400(400.0, "400 kV", "Transmission Supergrid"),
    KV_275(275.0, "275 kV", "Transmission Grid"),
    KV_132(132.0, "132 kV", "E&W Distribution / NI HV"),
    KV_33(33.0, "33 kV", "Primary Distribution"),
    KV_11(11.0, "11 kV", "Secondary Distribution")
}

enum class AssetType(val label: String) {
    SUBSTATION("Substation"),
    BUSBAR("Busbar"),
    TRANSFORMER("Transformer"),
    OVERHEAD_LINE("Overhead Line"),
    UNDERGROUND_CABLE("Underground Cable"),
    CIRCUIT_BREAKER("Circuit Breaker"),
    DISCONNECTOR("Disconnector"),
    LOAD("Demand Group"),
    GENERATOR("Generator"),
    STORAGE("Battery Storage (BESS)"),
    INTERCONNECTOR("Interconnector"),
    NETWORK_BOUNDARY("Network Boundary")
}

enum class LifecycleStatus(val label: String) {
    IN_SERVICE("In Service"),
    OUT_OF_SERVICE("Out of Service"),
    PROPOSED("Proposed / Planned"),
    DECOMMISSIONED("Decommissioned")
}

enum class VerificationStatus(val label: String) {
    VERIFIED_2026("Verified (Field Audit 2026)"),
    PROVISIONAL("Provisional (Unverified)"),
    SYNTHETIC_DEMO("Synthetic Demonstrator Baseline")
}

enum class SwitchStatus(val label: String) {
    CLOSED("CLOSED"),
    OPEN("OPEN"),
    UNKNOWN("UNKNOWN")
}

data class CoordinatePair(
    val latitude: Double,
    val longitude: Double,
    val crs: String = "EPSG:4326 (WGS84)",
    val osgbEasting: Int,
    val osgbNorthing: Int,
    val schematicX: Float, // Independent normalized 0f..1f SLD position
    val schematicY: Float
)

data class NetworkSnapshot(
    val snapshotId: String,
    val modelVersion: String,
    val createdUtc: String,
    val authorOrg: UkOrganisation,
    val description: String,
    val integrityHash: String,
    val isImmutable: Boolean = true
)

data class BusNode(
    val id: String,
    val name: String,
    val substationId: String,
    val ownerOrg: UkOrganisation,
    val operatorOrg: UkOrganisation,
    val dataAuthority: UkOrganisation,
    val nominalKv: Double,
    val voltageLevel: VoltageLevel,
    val systemArea: SystemArea,
    val coords: CoordinatePair,
    val isSlack: Boolean = false,
    val isGeneratorBus: Boolean = false,
    val targetVoltagePu: Double = 1.0,
    val baseLoadMw: Double = 0.0,
    val baseLoadMvar: Double = 0.0,
    val scheduledGenMw: Double = 0.0,
    val minQPu: Double = -1.5,
    val maxQPu: Double = 1.5,
    val lifecycleStatus: LifecycleStatus = LifecycleStatus.IN_SERVICE,
    val verificationStatus: VerificationStatus = VerificationStatus.SYNTHETIC_DEMO,
    val lastInspectionDate: String = "2026-08-14",
    val conditionScore: Int = 86 // 0..100
)

data class BranchAsset(
    val id: String,
    val name: String,
    val assetType: AssetType,
    val fromBusId: String,
    val toBusId: String,
    val ownerOrg: UkOrganisation,
    val operatorOrg: UkOrganisation,
    val approvalAuthority: UkOrganisation,
    val nominalKv: Double,
    val rPu: Double,
    val xPu: Double,
    val bPu: Double,
    val ratingSummerMva: Double,
    val ratingWinterMva: Double,
    val postFaultRatingMva: Double,
    val ratingConditions: String,
    val lengthKm: Double,
    val tapRatio: Double = 1.0,
    val breakerStatus: SwitchStatus = SwitchStatus.CLOSED,
    val disconnectorStatus: SwitchStatus = SwitchStatus.CLOSED,
    val energisationKnown: Boolean = true,
    val lifecycleStatus: LifecycleStatus = LifecycleStatus.IN_SERVICE,
    val verificationStatus: VerificationStatus = VerificationStatus.SYNTHETIC_DEMO,
    val lastInspectionDate: String = "2026-09-02",
    val conditionScore: Int = 82,
    val isBoundaryLink: Boolean = false
)

data class GenerationStorageUnit(
    val id: String,
    val name: String,
    val assetType: AssetType,
    val busId: String,
    val ownerOrg: UkOrganisation,
    val operatorOrg: UkOrganisation,
    val fuelOrTech: String,
    val installedCapacityMw: Double,
    val availableCapacityMw: Double,
    val scheduledMw: Double,
    val forecastMw: Double,
    val measuredMw: Double,
    val forecastProvenance: String,
    val forecastHorizonHours: Int,
    val forecastModelVersion: String,
    val forecastUncertaintyPct: Double,
    // Battery storage fields (null for non-storage)
    val energyCapacityMwh: Double? = null,
    val roundTripEfficiencyPct: Double? = null,
    val stateOfChargePct: Double? = null,
    val minSocPct: Double? = null,
    val maxSocPct: Double? = null,
    val allocatedService: String? = null,
    val preventDoubleAllocation: Boolean = true
)

data class DemandGroup(
    val id: String,
    val name: String,
    val busId: String,
    val ownerOrg: UkOrganisation,
    val customerType: String,
    val forecastPeakMw: Double,
    val measuredMw: Double,
    val measuredMvar: Double,
    val powerFactor: Double,
    val forecastHorizonHours: Int,
    val forecastUncertaintyPct: Double
)
