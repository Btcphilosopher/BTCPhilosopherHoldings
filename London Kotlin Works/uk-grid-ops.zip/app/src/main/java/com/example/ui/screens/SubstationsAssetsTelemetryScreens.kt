package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.AssetEntity
import com.example.domain.model.*
import com.example.ui.components.*
import com.example.ui.viewmodel.GridUiState

@Composable
fun SubstationsScreen(
    uiState: GridUiState,
    onInspectBusAndOpenMap: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            SectionHeaderCard(
                title = "Substations Directory",
                subtitle = "Physical bay hierarchy, ownership boundaries & SLD deep-links",
                rightBadge = "${uiState.buses.size} Substations"
            )
        }
        items(uiState.buses.size) { idx ->
            val bus = uiState.buses[idx]
            val connectedBranches = uiState.branches.filter { it.fromBusId == bus.id || it.toBusId == bus.id }
            val hasUnknownSwitch = connectedBranches.any { it.breakerStatus == SwitchStatus.UNKNOWN }
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(bus.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        VoltageChip(bus.nominalKv, bus.systemArea == SystemArea.NI)
                    }
                    Text(
                        text = "Substation ID: ${bus.substationId} • Owner: ${bus.ownerOrg.shortName} • Operator: ${bus.operatorOrg.shortName}\nBays Connected: ${connectedBranches.size} • Condition Score: ${bus.conditionScore}/100",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (hasUnknownSwitch) {
                            StatusPill("SWITCH STATE UNKNOWN", StatusTone.UNKNOWN)
                        } else {
                            StatusPill("BAYS TELEMETERED", StatusTone.HEALTHY)
                        }
                        OutlinedButton(
                            onClick = { onInspectBusAndOpenMap(bus.id) },
                            modifier = Modifier.testTag("inspect_sub_${bus.id}")
                        ) {
                            Text("Open in SLD")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AssetsScreen(
    uiState: GridUiState,
    persistedAssets: List<AssetEntity>,
    onAttemptRestrictedExport: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            SectionHeaderCard(
                title = "Persistent Asset Register",
                subtitle = "Room SQLite persisted • Model ${uiState.snapshot.modelVersion} (${uiState.snapshot.integrityHash})",
                rightBadge = "${persistedAssets.size} Records"
            )
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Includes ratings, verification status & ownership.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = onAttemptRestrictedExport,
                    modifier = Modifier.testTag("export_cni_assets_btn")
                ) {
                    Text("Export CNI Package")
                }
            }
        }
        items(persistedAssets.size) { idx ->
            val a = persistedAssets[idx]
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(a.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        VoltageChip(a.nominalKv, a.ownerOrgCode == "SONI")
                    }
                    Text(
                        text = "${a.id} • ${a.assetCategory} • v${a.version}\nOwner: ${a.ownerOrgCode} | Operator: ${a.operatorOrgCode} | Rating: ${if (a.ratingSummerMva > 0) "${a.ratingSummerMva} MVA" else "Busbar Node"}\nStatus: ${a.lifecycleStatus} • Verification: ${a.verificationStatus}\nLast Inspected: ${a.lastInspectionDate} • Condition: ${a.conditionScore}/100",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun TelemetryScreen(
    uiState: GridUiState,
    onSetOperatingMode: (OperatingMode) -> Unit
) {
    var selectedLayer by remember { mutableStateOf<TelemetryLayer?>(null) }
    val filteredObs = uiState.observations.filter { selectedLayer == null || it.layer == selectedLayer }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            SectionHeaderCard(
                title = "Telemetry Ingestion & Quality",
                subtitle = "Separates Raw Observations, Validated Measurements, State Estimator & Forecasts",
                rightBadge = uiState.operatingMode.badgeText
            )
        }

        // Operating mode switcher
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OperatingMode.entries.forEach { m ->
                    FilterChip(
                        selected = uiState.operatingMode == m,
                        onClick = { onSetOperatingMode(m) },
                        label = { Text(m.label) },
                        modifier = Modifier.testTag("telemetry_mode_${m.name}")
                    )
                }
            }
        }

        // Ingestion Diagnostics Summary
        item {
            val d = uiState.diagnostics
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Ingestion Pipeline Diagnostics", style = MaterialTheme.typography.titleSmall)
                        StatusPill(
                            text = if (d.sourceOutages > 0) "DISCONNECTED" else if (d.staleSensors > 0) "1 STALE SENSOR" else "HEALTHY",
                            tone = if (d.sourceOutages > 0) StatusTone.CRITICAL else if (d.staleSensors > 0) StatusTone.AMBER else StatusTone.HEALTHY
                        )
                    }
                    Text(
                        text = "Connection: ${d.connectionHealth}\nPackets: ${d.packetsProcessed} • Duplicates Dropped: ${d.duplicatesDropped} • NTP Skew Fixed: ${d.clockSkewCorrected} • Invalid Range Rejected: ${d.invalidRejected}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Layer Filter Chips
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(
                    selected = selectedLayer == null,
                    onClick = { selectedLayer = null },
                    label = { Text("All Layers") }
                )
                TelemetryLayer.entries.forEach { layer ->
                    FilterChip(
                        selected = selectedLayer == layer,
                        onClick = { selectedLayer = layer },
                        label = { Text(layer.label.substringBefore(" ")) }
                    )
                }
            }
        }

        items(filteredObs.size) { idx ->
            val obs = filteredObs[idx]
            val tone = when {
                obs.qualityFlag.isCritical -> StatusTone.CRITICAL
                obs.qualityFlag.isWarning -> StatusTone.AMBER
                else -> StatusTone.HEALTHY
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.testTag("telemetry_row_${obs.id}")
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(obs.equipmentName, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        StatusPill(obs.qualityFlag.label, tone)
                    }
                    Text(
                        text = "${obs.metricName}: ${obs.value?.let { "%.2f".format(it) } ?: "MISSING"} ${obs.unit}  (${obs.uncertainty})",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Layer: ${obs.layer.label} • Source: ${obs.sourceId} • Owner: ${obs.ownerOrg.code}\nObs Time: ${obs.observationTimeIso} | Ingested: ${obs.ingestionTimeIso} | Age: ${obs.dataAgeSeconds}s",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Documented External OT Adapters
        item {
            Text(
                text = "Replaceable External Monitoring Adapter Interfaces",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
        items(uiState.adapterSpecs.size) { idx ->
            val spec = uiState.adapterSpecs[idx]
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(spec.adapterName, style = MaterialTheme.typography.titleSmall)
                    Text(
                        text = "Protocol: ${spec.protocol}\nAuth: ${spec.authRequirement}\nStatus: ${spec.status}\nBoundary: ${spec.boundaryNote}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
