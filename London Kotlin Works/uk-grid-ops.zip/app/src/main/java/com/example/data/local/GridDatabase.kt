package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        AssetEntity::class,
        OutageEntity::class,
        WorkOrderEntity::class,
        AlertEntity::class,
        ReportEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class GridDatabase : RoomDatabase() {
    abstract fun gridDao(): GridDao

    companion object {
        @Volatile
        private var INSTANCE: GridDatabase? = null

        fun getInstance(context: Context): GridDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    GridDatabase::class.java,
                    "uk_grid_ops_pennine.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
