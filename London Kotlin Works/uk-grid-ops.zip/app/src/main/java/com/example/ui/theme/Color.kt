package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary British Infrastructure & Control Room Palette
val GridNavy950 = Color(0xFF071326)
val GridNavy900 = Color(0xFF0B1B36)
val GridNavy800 = Color(0xFF13294B)
val GridNavy700 = Color(0xFF1D3B6C)
val GridSlate600 = Color(0xFF475569)
val GridSlate500 = Color(0xFF64748B)
val GridSlate200 = Color(0xFFE2E8F0)
val GridWorkspaceBg = Color(0xFFF3F6FA)
val GridCardSurface = Color(0xFFFFFFFF)
val GridSurfaceAlt = Color(0xFFEAF0F6)

// Restrained Electricity-Yellow Accents
val ElectricYellow500 = Color(0xFFF2C200)
val ElectricYellow700 = Color(0xFFB38600)
val ElectricYellow100 = Color(0xFFFFF6CC)

// Semantic Operational Status (Always paired with text in UI)
val StatusHealthy = Color(0xFF047857)
val StatusHealthyBg = Color(0xFFD1FAE5)
val StatusAmber = Color(0xFFB45309)
val StatusAmberBg = Color(0xFFFEF3C7)
val StatusCritical = Color(0xFFB91C1C)
val StatusCriticalBg = Color(0xFFFEE2E2)
val StatusUnknown = Color(0xFF4338CA)
val StatusUnknownBg = Color(0xFFE0E7FF)

// UK Nominal Voltage Level Identification Colours
val Voltage400Kv = Color(0xFF005EA5) // Supergrid Blue
val Voltage275Kv = Color(0xFFD97706) // Amber-Orange
val Voltage132Kv = Color(0xFF059669) // Distribution Emerald
val Voltage33Kv = Color(0xFF7C3AED)  // Primary Violet
val VoltageSoniNi = Color(0xFF0F766E) // Northern Ireland SONI Teal
