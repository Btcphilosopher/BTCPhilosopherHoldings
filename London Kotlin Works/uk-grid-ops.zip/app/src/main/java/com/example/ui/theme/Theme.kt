package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val GridLightColorScheme = lightColorScheme(
    primary = GridNavy900,
    onPrimary = Color.White,
    primaryContainer = GridSurfaceAlt,
    onPrimaryContainer = GridNavy900,
    secondary = ElectricYellow500,
    onSecondary = GridNavy950,
    secondaryContainer = ElectricYellow100,
    onSecondaryContainer = GridNavy950,
    tertiary = Voltage400Kv,
    onTertiary = Color.White,
    background = GridWorkspaceBg,
    onBackground = GridNavy950,
    surface = GridCardSurface,
    onSurface = GridNavy950,
    surfaceVariant = GridSurfaceAlt,
    onSurfaceVariant = GridSlate600,
    outline = GridSlate200,
    error = StatusCritical,
    onError = Color.White,
    errorContainer = StatusCriticalBg,
    onErrorContainer = StatusCritical
)

private val GridDarkControlScheme = darkColorScheme(
    primary = ElectricYellow500,
    onPrimary = GridNavy950,
    primaryContainer = GridNavy800,
    onPrimaryContainer = Color.White,
    secondary = Voltage400Kv,
    onSecondary = Color.White,
    secondaryContainer = GridNavy700,
    onSecondaryContainer = ElectricYellow100,
    background = GridNavy950,
    onBackground = Color(0xFFF1F5F9),
    surface = GridNavy900,
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = GridNavy800,
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = Color(0xFF28436F),
    error = Color(0xFFF87171),
    onError = GridNavy950,
    errorContainer = Color(0xFF7F1D1D),
    onErrorContainer = Color(0xFFFEE2E2)
)

val GridShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(6.dp),
    medium = RoundedCornerShape(8.dp),
    large = RoundedCornerShape(12.dp),
    extraLarge = RoundedCornerShape(16.dp)
)

@Composable
fun UkGridOpsTheme(
    darkControlRoom: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkControlRoom) GridDarkControlScheme else GridLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = GridTypography,
        shapes = GridShapes,
        content = content
    )
}
