package com.example.domain.engine

import com.example.domain.model.*
import kotlin.math.sin

object TelemetryService {

    fun generateObservations(
        mode: OperatingMode,
        tick: Int,
        replayHour: Float,
        studyResult: PowerFlowResult
    ): Pair<List<TelemetryObservation>, IngestionDiagnostics> {
        val timeLabel = when (mode) {
            OperatingMode.REPLAY -> {
                val hh = replayHour.toInt().coerceIn(0, 23)
                val mm = ((replayHour - hh) * 60).toInt().coerceIn(0, 59)
                "2026-11-23T%02d:%02d:00Z".format(hh, mm)
            }
            OperatingMode.SIMULATION -> {
                val sec = (tick * 2) % 60
                val min = 48 + ((tick * 2) / 60) % 10
                "2026-11-24T08:%02d:%02dZ".format(min, sec)
            }
            OperatingMode.READ_ONLY_MONITORING -> "NO LIVE STREAM (ADAPTER DISCONNECTED)"
        }

        if (mode == OperatingMode.READ_ONLY_MONITORING) {
            val missing = listOf(
                TelemetryObservation(
                    id = "OBS-RO-01",
                    equipmentId = "PENN_N_400",
                    equipmentName = "Pennine North 400 kV Bus",
                    ownerOrg = UkOrganisation.NGET,
                    metricName = "External ICCP Frequency",
                    value = null,
                    unit = "Hz",
                    sourceId = "ICCP-DMZ-READONLY",
                    observationTimeIso = "N/A",
                    ingestionTimeIso = "2026-11-24T08:50:00Z",
                    dataAgeSeconds = 9999,
                    qualityFlag = QualityFlag.MISSING,
                    uncertainty = "No authorised OT credentials provisioned",
                    layer = TelemetryLayer.RAW_OBSERVATION
                )
            )
            return missing to IngestionDiagnostics(
                packetsProcessed = 0,
                duplicatesDropped = 0,
                clockSkewCorrected = 0,
                invalidRejected = 0,
                staleSensors = 0,
                sourceOutages = 1,
                connectionHealth = "DISCONNECTED — Awaiting Authorised Read-Only OT Credentials"
            )
        }

        val freqDrift = if (mode == OperatingMode.REPLAY && replayHour in 17.0f..18.5f) {
            -0.11 // Evening ramp frequency dip in replay
        } else {
            0.03 * sin(tick * 0.6)
        }
        val gbFreq = 50.00 + freqDrift
        val niFreq = 50.00 + 0.02 * sin(tick * 0.45 + 1.2)

        val pennBus = studyResult.busResults.firstOrNull { it.busId == "PENN_N_400" }
        val calderBus = studyResult.busResults.firstOrNull { it.busId == "CALDER_400" }
        val millBus = studyResult.busResults.firstOrNull { it.busId == "MILL_33" }
        val calderSgt = studyResult.branchResults.firstOrNull { it.branchId == "BR_CALDER_BRAD_SGT" }

        val obs = listOf(
            TelemetryObservation(
                id = "OBS-FREQ-GB",
                equipmentId = "PENN_N_400",
                equipmentName = "GB Synchronous Frequency (Pennine PMU)",
                ownerOrg = UkOrganisation.NESO,
                metricName = "System Frequency",
                value = gbFreq,
                unit = "Hz",
                sourceId = "PMU-PENN-01",
                observationTimeIso = timeLabel,
                ingestionTimeIso = timeLabel,
                dataAgeSeconds = 1,
                qualityFlag = QualityFlag.GOOD,
                uncertainty = "±0.002 Hz",
                layer = TelemetryLayer.VALIDATED_MEASUREMENT
            ),
            TelemetryObservation(
                id = "OBS-FREQ-NI",
                equipmentId = "MOYLE_NI_275",
                equipmentName = "NI All-Island Frequency (SONI Boundary)",
                ownerOrg = UkOrganisation.SONI,
                metricName = "NI System Frequency",
                value = niFreq,
                unit = "Hz",
                sourceId = "SONI-ICCP-RO",
                observationTimeIso = timeLabel,
                ingestionTimeIso = timeLabel,
                dataAgeSeconds = 3,
                qualityFlag = QualityFlag.GOOD,
                uncertainty = "±0.005 Hz",
                layer = TelemetryLayer.VALIDATED_MEASUREMENT
            ),
            TelemetryObservation(
                id = "OBS-V-CALDER",
                equipmentId = "CALDER_400",
                equipmentName = "Calder Valley 400 kV Bus Voltage",
                ownerOrg = UkOrganisation.NGET,
                metricName = "Line-to-Line Voltage",
                value = calderBus?.voltageKv ?: 396.4,
                unit = "kV",
                sourceId = "RTU-CALDER-01",
                observationTimeIso = timeLabel,
                ingestionTimeIso = timeLabel,
                dataAgeSeconds = 2,
                qualityFlag = QualityFlag.GOOD,
                uncertainty = "±0.4 kV",
                layer = TelemetryLayer.VALIDATED_MEASUREMENT
            ),
            TelemetryObservation(
                id = "OBS-SE-CALDER",
                equipmentId = "CALDER_400",
                equipmentName = "Calder Valley State Estimator Output",
                ownerOrg = UkOrganisation.NESO,
                metricName = "Estimated Bus Magnitude",
                value = calderBus?.voltagePu ?: 0.991,
                unit = "pu",
                sourceId = "SE-ENGINE-GB",
                observationTimeIso = timeLabel,
                ingestionTimeIso = timeLabel,
                dataAgeSeconds = 4,
                qualityFlag = QualityFlag.GOOD,
                uncertainty = "±0.003 pu (WLS SE)",
                layer = TelemetryLayer.ESTIMATED_STATE
            ),
            TelemetryObservation(
                id = "OBS-STALE-TX1B",
                equipmentId = "BR_WHARFE_AIRE_SGT",
                equipmentName = "PENN-400-TX1B Winding Hot-Spot Temp",
                ownerOrg = UkOrganisation.NGET,
                metricName = "Winding Temperature",
                value = 68.4,
                unit = "°C",
                sourceId = "RTU-WHARFE-02",
                observationTimeIso = "2026-11-24T08:41:12Z",
                ingestionTimeIso = timeLabel,
                dataAgeSeconds = 428 + (tick * 2L),
                qualityFlag = QualityFlag.STALE,
                uncertainty = "UNKNOWN (Frozen > 420s)",
                layer = TelemetryLayer.RAW_OBSERVATION
            ),
            TelemetryObservation(
                id = "OBS-SKEW-BRAD",
                equipmentId = "BRAD_132",
                equipmentName = "Bradford West 132 kV Active Power",
                ownerOrg = UkOrganisation.NGED,
                metricName = "GSP Demand P",
                value = 124.0 + 1.8 * sin(tick * 0.4),
                unit = "MW",
                sourceId = "DNO-RTU-BRAD-09",
                observationTimeIso = timeLabel,
                ingestionTimeIso = timeLabel,
                dataAgeSeconds = 16,
                qualityFlag = QualityFlag.CLOCK_SKEW_CORRECTED,
                uncertainty = "±1.5 MW (NTP +14s offset fixed)",
                layer = TelemetryLayer.VALIDATED_MEASUREMENT
            ),
            TelemetryObservation(
                id = "OBS-LOAD-SGT1",
                equipmentId = "BR_CALDER_BRAD_SGT",
                equipmentName = "Calder Valley SGT1 Apparent Power",
                ownerOrg = UkOrganisation.NGET,
                metricName = "Transformer Loading",
                value = calderSgt?.apparentMva ?: 182.0,
                unit = "MVA",
                sourceId = "RTU-CALDER-02",
                observationTimeIso = timeLabel,
                ingestionTimeIso = timeLabel,
                dataAgeSeconds = 2,
                qualityFlag = QualityFlag.GOOD,
                uncertainty = "±1.2 MVA",
                layer = TelemetryLayer.VALIDATED_MEASUREMENT
            ),
            TelemetryObservation(
                id = "OBS-INV-WIND",
                equipmentId = "GEN_PENN_WIND",
                equipmentName = "Pennine Moor Wind (Rejected Spike)",
                ownerOrg = UkOrganisation.NGET,
                metricName = "Raw Reactive Spike",
                value = -9999.0,
                unit = "MVAr",
                sourceId = "WIND-MODBUS-04",
                observationTimeIso = timeLabel,
                ingestionTimeIso = timeLabel,
                dataAgeSeconds = 5,
                qualityFlag = QualityFlag.INVALID,
                uncertainty = "Rejected: Out of physical bounds (-200..200)",
                layer = TelemetryLayer.RAW_OBSERVATION
            ),
            TelemetryObservation(
                id = "OBS-FCST-PENN",
                equipmentId = "PENN_N_400",
                equipmentName = "Pennine Wind 4h Forecast",
                ownerOrg = UkOrganisation.NESO,
                metricName = "Forecast Output",
                value = 138.0 + (if (mode == OperatingMode.REPLAY) (replayHour - 12.0) * 1.4 else 0.0),
                unit = "MW",
                sourceId = "WindCast-GB-v4.2",
                observationTimeIso = timeLabel,
                ingestionTimeIso = timeLabel,
                dataAgeSeconds = 60,
                qualityFlag = QualityFlag.GOOD,
                uncertainty = "±11.5% (90% CI)",
                layer = TelemetryLayer.FORECAST
            ),
            TelemetryObservation(
                id = "OBS-OUTAGE-MILL",
                equipmentId = "MILL_33",
                equipmentName = "Milltown 33 kV Substation Voltage",
                ownerOrg = UkOrganisation.NGED,
                metricName = "33 kV Bus Voltage",
                value = if (millBus?.energised == true) millBus.voltageKv else 0.0,
                unit = "kV",
                sourceId = "DNO-RTU-MILL-01",
                observationTimeIso = timeLabel,
                ingestionTimeIso = timeLabel,
                dataAgeSeconds = 3,
                qualityFlag = if (millBus?.energised == true) QualityFlag.GOOD else QualityFlag.SUSPECT,
                uncertainty = "±0.2 kV",
                layer = TelemetryLayer.VALIDATED_MEASUREMENT
            )
        )

        val diag = IngestionDiagnostics(
            packetsProcessed = 1420 + tick * 12,
            duplicatesDropped = 18 + (tick / 3),
            clockSkewCorrected = 6 + (tick / 5),
            invalidRejected = 4 + (tick / 7),
            staleSensors = 1,
            sourceOutages = 0,
            connectionHealth = if (mode == OperatingMode.SIMULATION) {
                "HEALTHY (Synthetic Stream • 1 Stale Sensor)"
            } else {
                "REPLAY ACTIVE (Historian Frame ${"%.1f".format(replayHour)}h)"
            }
        )
        return obs to diag
    }
}
