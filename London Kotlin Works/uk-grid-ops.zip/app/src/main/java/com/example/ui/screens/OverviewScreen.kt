package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.engine.ConvergenceStatus
import com.example.domain.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.GridNavDestination
import com.example.ui.viewmodel.GridUiState

@Composable
fun OverviewScreen(
    uiState: GridUiState,
    outages: List<OutageRecord>,
    workOrders: List<MaintenanceWorkOrder>,
    alerts: List<GridAlert>,
    reports: List<EngineeringReport>,
    onNavigate: (GridNavDestination) -> Unit,
    onAcknowledgeAlert: (GridAlert) -> Unit
) {
    val org = uiState.activeOrg
    // Filter strictly to selected organisation's coverage (unless NESO GB-wide coordination)
    val scopedBuses = uiState.buses.filter {
        when (org) {
            UkOrganisation.NESO -> it.systemArea == SystemArea.GB
            UkOrganisation.PUBLIC_OBSERVER -> it.systemArea == SystemArea.GB
            else -> it.ownerOrg == org || it.operatorOrg == org
        }
    }
    val scopedBranches = uiState.branches.filter {
        when (org) {
            UkOrganisation.NESO -> it.operatorOrg == UkOrganisation.NESO
            UkOrganisation.PUBLIC_OBSERVER -> true
            else -> it.ownerOrg == org || it.operatorOrg == org
        }
    }
    val scopedDemandMw = scopedBuses.sumOf { it.baseLoadMw } * uiState.demandScaleFactor
    val scopedGenMw = scopedBuses.sumOf { it.scheduledGenMw }
    val scopedOutages = outages.filter {
        org == UkOrganisation.NESO && it.ownerOrg.systemArea == SystemArea.GB ||
            it.ownerOrg == org || it.coordinatingOrg == org
    }
    val scopedWos = workOrders.filter { org == UkOrganisation.NESO || it.ownerOrg == org }
    val scopedAlerts = alerts.filter { org == UkOrganisation.NESO || it.ownerOrg == org }
    val scopedConns = uiState.connections.filter { org == UkOrganisation.NESO || it.ownerOrg == org }

    val peakBranch = uiState.currentStudyResult.branchResults
        .filter { brRes -> scopedBranches.any { it.id == brRes.branchId } }
        .maxByOrNull { it.loadingPct }

    val completedSteps = uiState.demoSteps.count { it.completed }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeaderCard(
                title = "Network Overview",
                subtitle = "${org.displayName} • ${org.networkArea}",
                rightBadge = "SNAPSHOT ${uiState.snapshot.snapshotId}"
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Image(
                        painter = painterResource(id = R.drawable.img_control_room_banner),
                        contentDescription = "Pennine UK grid network blueprint banner",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .clip(MaterialTheme.shapes.medium),
                        contentScale = ContentScale.Crop
                    )
                    Text(
                        text = "Organisational Coverage & Scope Boundary",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Ownership: ${org.assetOwnershipScope}\nOperations: ${org.operationalResponsibility}\nNote: Organisation figures below are strictly scoped to ${org.shortName} and are NOT aggregated with ${if (org.systemArea == SystemArea.GB) "Northern Ireland (SONI)" else "Great Britain (GB)"} totals.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Pennine 10-Step Demonstrator: $completedSteps / 10 completed",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Button(
                            onClick = { onNavigate(GridNavDestination.UK_NETWORK) },
                            modifier = Modifier.testTag("overview_open_map_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Open Network Map")
                        }
                    }
                }
            }
        }

        // Row 1 KPIs: Demand & Generation + Loading & Voltage
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                EngineeringKpiCard(
                    title = "Scoped Demand / Gen",
                    value = "${"%.0f".format(scopedDemandMw)} / ${"%.0f".format(scopedGenMw)} MW",
                    unitOrSub = "Coverage: ${scopedBuses.size} buses (${org.systemArea.name})",
                    sourceLinkLabel = "Source: Telemetry",
                    tone = StatusTone.HEALTHY,
                    testTag = "kpi_demand_gen",
                    onClickSource = { onNavigate(GridNavDestination.TELEMETRY) },
                    modifier = Modifier.weight(1f)
                )
                EngineeringKpiCard(
                    title = "Peak Branch Loading",
                    value = "${"%.1f".format(peakBranch?.loadingPct ?: 0.0)}%",
                    unitOrSub = peakBranch?.branchName ?: "No active branch in scope",
                    sourceLinkLabel = if ((peakBranch?.loadingPct ?: 0.0) > 85.0) "Amber Constraint" else "Study AC PF",
                    tone = if ((peakBranch?.loadingPct ?: 0.0) > 85.0) StatusTone.AMBER else StatusTone.HEALTHY,
                    testTag = "kpi_peak_loading",
                    onClickSource = { onNavigate(GridNavDestination.STUDIES) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Row 2 KPIs: Outages + Maintenance/Defects
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                EngineeringKpiCard(
                    title = "Active & Planned Outages",
                    value = "${scopedOutages.size}",
                    unitOrSub = scopedOutages.firstOrNull()?.let { "${it.id}: ${it.stage.label}" } ?: "No outages in org scope",
                    sourceLinkLabel = "Outage Register",
                    tone = StatusTone.NEUTRAL,
                    testTag = "kpi_outages",
                    onClickSource = { onNavigate(GridNavDestination.OUTAGES) },
                    modifier = Modifier.weight(1f)
                )
                val conflictCount = scopedWos.count { it.syncStatus != SyncStatus.SYNCED }
                EngineeringKpiCard(
                    title = "Maintenance & Defects",
                    value = "${scopedWos.size} WOs",
                    unitOrSub = if (conflictCount > 0) "$conflictCount sync conflict / offline draft" else "All tablet records synced",
                    sourceLinkLabel = if (conflictCount > 0) "Conflict Pending" else "Work Orders",
                    tone = if (conflictCount > 0) StatusTone.AMBER else StatusTone.HEALTHY,
                    testTag = "kpi_maintenance",
                    onClickSource = { onNavigate(GridNavDestination.MAINTENANCE) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Row 3 KPIs: Telemetry Issues + Connections & Reinforcement
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                EngineeringKpiCard(
                    title = "Telemetry Quality Issues",
                    value = "${uiState.diagnostics.staleSensors} Stale",
                    unitOrSub = "${uiState.diagnostics.duplicatesDropped} dupes dropped • ${uiState.diagnostics.clockSkewCorrected} skew fixed",
                    sourceLinkLabel = "Inspect Telemetry",
                    tone = if (uiState.diagnostics.staleSensors > 0) StatusTone.AMBER else StatusTone.HEALTHY,
                    testTag = "kpi_telemetry_issues",
                    onClickSource = { onNavigate(GridNavDestination.TELEMETRY) },
                    modifier = Modifier.weight(1f)
                )
                EngineeringKpiCard(
                    title = "Connections & Studies",
                    value = "${scopedConns.size} Apps",
                    unitOrSub = "${uiState.reinforcementOptions.size} reinforcement options • ${reports.size} reports",
                    sourceLinkLabel = "Connections Queue",
                    tone = StatusTone.NEUTRAL,
                    testTag = "kpi_connections",
                    onClickSource = { onNavigate(GridNavDestination.CONNECTIONS) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Solver & Engineering Decisions Card
        item {
            val pendingReports = reports.count { it.approvalStatus.startsWith("Draft") }
            val solverTone = when (uiState.currentStudyResult.convergenceStatus) {
                ConvergenceStatus.CONVERGED -> StatusTone.HEALTHY
                ConvergenceStatus.INCOMPLETE_ISLANDED -> StatusTone.AMBER
                ConvergenceStatus.FAILED_TO_CONVERGE -> StatusTone.CRITICAL
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Outstanding Engineering Decisions", style = MaterialTheme.typography.titleMedium)
                        StatusPill(uiState.currentStudyResult.convergenceStatus.label, solverTone)
                    }
                    Text(
                        text = "• $pendingReports report(s) awaiting engineering approval\n• Active study: ${uiState.currentStudyResult.scenario.label}\n• ${uiState.currentStudyResult.engineeringNotice}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { onNavigate(GridNavDestination.REINFORCEMENT) },
                            modifier = Modifier.testTag("overview_reinforcement_btn")
                        ) {
                            Text("Compare Reinforcements")
                        }
                        Button(
                            onClick = { onNavigate(GridNavDestination.REPORTS) },
                            modifier = Modifier.testTag("overview_reports_btn")
                        ) {
                            Icon(Icons.Default.Assessment, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Reports & Demo Guide")
                        }
                    }
                }
            }
        }

        // Active Alerts list (acknowledgement never clears condition!)
        item {
            Text(
                text = "Active Operational & Data-Quality Alerts (${scopedAlerts.size})",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
        items(scopedAlerts.size) { idx ->
            val alert = scopedAlerts[idx]
            val tone = when (alert.severity) {
                AlertSeverity.CRITICAL -> StatusTone.CRITICAL
                AlertSeverity.WARNING -> StatusTone.AMBER
                AlertSeverity.INFO -> StatusTone.NEUTRAL
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${alert.id}: ${alert.title}",
                            style = MaterialTheme.typography.titleSmall,
                            modifier = Modifier.weight(1f)
                        )
                        StatusPill(alert.severity.label, tone)
                    }
                    Text(
                        text = "${alert.severityRationale}\nThreshold: ${alert.thresholdSource} (Effective ${alert.effectiveDate})",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatusPill(
                            text = if (alert.conditionActive) "CONDITION ACTIVE" else "CLEARED",
                            tone = if (alert.conditionActive) StatusTone.AMBER else StatusTone.HEALTHY
                        )
                        if (!alert.acknowledged) {
                            OutlinedButton(
                                onClick = { onAcknowledgeAlert(alert) },
                                modifier = Modifier.testTag("ack_alert_${alert.id}")
                            ) {
                                Text("Acknowledge")
                            }
                        } else {
                            Text(
                                text = "Ack: ${alert.acknowledgedBy}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
