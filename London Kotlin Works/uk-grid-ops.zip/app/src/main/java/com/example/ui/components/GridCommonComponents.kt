package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.model.*
import com.example.ui.theme.*

@Composable
fun StatusPill(
    text: String,
    tone: StatusTone,
    modifier: Modifier = Modifier
) {
    val (bg, fg, icon) = when (tone) {
        StatusTone.HEALTHY -> Triple(StatusHealthyBg, StatusHealthy, Icons.Default.CheckCircle)
        StatusTone.AMBER -> Triple(StatusAmberBg, StatusAmber, Icons.Default.Warning)
        StatusTone.CRITICAL -> Triple(StatusCriticalBg, StatusCritical, Icons.Default.Error)
        StatusTone.UNKNOWN -> Triple(StatusUnknownBg, StatusUnknown, Icons.Default.HelpOutline)
        StatusTone.NEUTRAL -> Triple(GridSurfaceAlt, GridNavy800, Icons.Default.Info)
    }
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bg)
            .border(1.dp, fg.copy(alpha = 0.25f), RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(13.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = fg,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

enum class StatusTone { HEALTHY, AMBER, CRITICAL, UNKNOWN, NEUTRAL }

@Composable
fun VoltageChip(kv: Double, isSoni: Boolean = false) {
    val color = when {
        isSoni -> VoltageSoniNi
        kv >= 380.0 -> Voltage400Kv
        kv >= 250.0 -> Voltage275Kv
        kv >= 100.0 -> Voltage132Kv
        else -> Voltage33Kv
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(color.copy(alpha = 0.12f))
            .border(1.dp, color.copy(alpha = 0.45f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = "${kv.toInt()} kV",
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun SectionHeaderCard(
    title: String,
    subtitle: String,
    rightBadge: String? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (rightBadge != null) {
            StatusPill(text = rightBadge, tone = StatusTone.NEUTRAL)
        }
    }
}

@Composable
fun EngineeringKpiCard(
    title: String,
    value: String,
    unitOrSub: String,
    sourceLinkLabel: String,
    tone: StatusTone = StatusTone.NEUTRAL,
    testTag: String,
    onClickSource: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .testTag(testTag)
            .clickable(onClick = onClickSource),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = value,
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontFamily = JetBrainsMonoFontFamily
                    ),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Text(
                text = unitOrSub,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusPill(text = sourceLinkLabel, tone = tone)
            }
        }
    }
}

@Composable
fun TelemetryProvenanceStrip(
    operatingMode: OperatingMode,
    activeOrg: UkOrganisation,
    brandingPreset: BrandingPreset,
    diagnostics: IngestionDiagnostics,
    observationTime: String,
    dataAgeSec: Long,
    onOpenModeSwitch: () -> Unit,
    onOpenOrgSwitch: () -> Unit
) {
    Surface(
        color = GridNavy900,
        contentColor = Color.White,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = brandingPreset.title,
                        style = MaterialTheme.typography.titleSmall,
                        color = ElectricYellow500,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = brandingPreset.subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFCBD5E1),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(
                        color = GridNavy700,
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .testTag("header_mode_chip")
                            .clickable(onClick = onOpenModeSwitch)
                    ) {
                        Text(
                            text = "MODE: ${operatingMode.badgeText}",
                            style = MaterialTheme.typography.labelSmall,
                            color = ElectricYellow500,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                        )
                    }
                    Surface(
                        color = GridNavy800,
                        border = BorderStroke(1.dp, Color(0xFF33568C)),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .testTag("header_org_chip")
                            .clickable(onClick = onOpenOrgSwitch)
                    ) {
                        Text(
                            text = "${activeOrg.code} (${activeOrg.systemArea.name})",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                        )
                    }
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SRC: ${if (operatingMode == OperatingMode.READ_ONLY_MONITORING) "OT-ADAPTER-STUB" else "PENNINE-SYNTH"}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF94A3B8)
                )
                Text(
                    text = "OBS: $observationTime",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF94A3B8),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "AGE: ${if (dataAgeSec > 900) "N/A" else "${dataAgeSec}s"} | ${diagnostics.staleSensors} STALE",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (diagnostics.staleSensors > 0) ElectricYellow500 else Color(0xFF6EE7B7)
                )
            }
        }
    }
}

@Composable
fun SafetyBannerNotice(text: String, isWarning: Boolean = true) {
    val bg = if (isWarning) StatusAmberBg else GridSurfaceAlt
    val fg = if (isWarning) StatusAmber else GridNavy800
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .border(1.dp, fg.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
            .padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (isWarning) Icons.Default.Warning else Icons.Default.Info,
            contentDescription = null,
            tint = fg,
            modifier = Modifier.size(18.dp)
        )
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = fg,
            fontWeight = FontWeight.Medium
        )
    }
}
