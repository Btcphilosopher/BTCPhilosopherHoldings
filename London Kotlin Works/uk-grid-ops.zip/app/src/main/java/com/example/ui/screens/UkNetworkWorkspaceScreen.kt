package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.GridUiState
import com.example.ui.viewmodel.NetworkViewMode

@Composable
fun UkNetworkWorkspaceScreen(
    uiState: GridUiState,
    onSetViewMode: (NetworkViewMode) -> Unit,
    onSetVoltageFilter: (Double?) -> Unit,
    onToggleLoadingOverlay: () -> Unit,
    onToggleOutageOverlay: () -> Unit,
    onSearchChange: (String) -> Unit,
    onSelectBus: (String) -> Unit,
    onSelectBranch: (String) -> Unit,
    onSimulateSwitchStatus: (String, SwitchStatus) -> Unit,
    onReplayHourChange: (Float) -> Unit,
    onToggleReplayPlaying: () -> Unit
) {
    val selectedBus = uiState.buses.firstOrNull { it.id == uiState.selectedBusId }
    val selectedBranch = uiState.branches.firstOrNull { it.id == uiState.selectedBranchId }

    val matchingBuses = uiState.buses.filter {
        uiState.networkSearchQuery.isBlank() ||
            it.name.contains(uiState.networkSearchQuery, ignoreCase = true) ||
            it.id.contains(uiState.networkSearchQuery, ignoreCase = true)
    }.filter {
        uiState.selectedVoltageFilterKv == null || it.nominalKv == uiState.selectedVoltageFilterKv
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeaderCard(
                title = "UK Network Map & Single-Line Workspace",
                subtitle = "Tap any substation busbar or branch corridor to inspect electrical parameters & status",
                rightBadge = "${uiState.buses.size} Buses • ${uiState.branches.size} Branches"
            )
        }

        // View mode + overlay filter toolbar
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = uiState.networkViewMode == NetworkViewMode.SINGLE_LINE_DIAGRAM,
                        onClick = { onSetViewMode(NetworkViewMode.SINGLE_LINE_DIAGRAM) },
                        label = { Text("Single-Line Diagram") },
                        modifier = Modifier.testTag("mode_sld_chip")
                    )
                    FilterChip(
                        selected = uiState.networkViewMode == NetworkViewMode.GEOGRAPHIC_MAP,
                        onClick = { onSetViewMode(NetworkViewMode.GEOGRAPHIC_MAP) },
                        label = { Text("UK Geographic Map") },
                        modifier = Modifier.testTag("mode_geo_chip")
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(null to "All kV", 400.0 to "400 kV", 275.0 to "275 kV", 132.0 to "132 kV", 33.0 to "33 kV").forEach { (kv, lbl) ->
                        FilterChip(
                            selected = uiState.selectedVoltageFilterKv == kv,
                            onClick = { onSetVoltageFilter(kv) },
                            label = { Text(lbl) },
                            modifier = Modifier.testTag("filter_kv_${kv?.toInt() ?: "all"}")
                        )
                    }
                    FilterChip(
                        selected = uiState.showLoadingOverlay,
                        onClick = onToggleLoadingOverlay,
                        label = { Text("Loading %") }
                    )
                    FilterChip(
                        selected = uiState.showOutageOverlay,
                        onClick = onToggleOutageOverlay,
                        label = { Text("Outages") }
                    )
                }

                OutlinedTextField(
                    value = uiState.networkSearchQuery,
                    onValueChange = onSearchChange,
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search assets") },
                    placeholder = { Text("Search Pennine substations, lines, SONI boundary...") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("network_search_input")
                )
            }
        }

        // Historical Playback Scrubber if in Replay Mode
        if (uiState.operatingMode == OperatingMode.REPLAY) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = ElectricYellow100),
                    border = BorderStroke(1.dp, ElectricYellow700)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Historical Playback: 2026-11-23 ${"%02d".format(uiState.replayHour.toInt())}:${if ((uiState.replayHour % 1f) >= 0.5f) "30" else "00"} UTC",
                                style = MaterialTheme.typography.titleSmall
                            )
                            IconButton(onClick = onToggleReplayPlaying) {
                                Icon(
                                    imageVector = if (uiState.isReplayPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Play/Pause Replay"
                                )
                            }
                        }
                        Slider(
                            value = uiState.replayHour,
                            onValueChange = onReplayHourChange,
                            valueRange = 6f..22f,
                            steps = 31
                        )
                    }
                }
            }
        }

        // Interactive Canvas
        item {
            InteractiveNetworkCanvas(
                viewMode = uiState.networkViewMode,
                buses = matchingBuses,
                branches = uiState.branches,
                studyResult = uiState.currentStudyResult,
                voltageFilterKv = uiState.selectedVoltageFilterKv,
                showLoadingOverlay = uiState.showLoadingOverlay,
                showOutageOverlay = uiState.showOutageOverlay,
                selectedBusId = uiState.selectedBusId,
                selectedBranchId = uiState.selectedBranchId,
                activeOrg = uiState.activeOrg,
                onSelectBus = onSelectBus,
                onSelectBranch = onSelectBranch
            )
        }

        // Selectable Equipment Inspector
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
                modifier = Modifier.testTag("equipment_inspector_card")
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Equipment Inspector",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )

                    if (selectedBranch != null) {
                        val brStudy = uiState.currentStudyResult.branchResults.firstOrNull { it.branchId == selectedBranch.id }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(selectedBranch.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                            VoltageChip(selectedBranch.nominalKv, selectedBranch.ownerOrg == UkOrganisation.SONI)
                        }
                        Text(
                            text = "ID: ${selectedBranch.id} • Type: ${selectedBranch.assetType.label}\nOwner: ${selectedBranch.ownerOrg.shortName} • Operator: ${selectedBranch.operatorOrg.shortName} • Approval Auth: ${selectedBranch.approvalAuthority.code}\nParameters: R=${selectedBranch.rPu} pu, X=${selectedBranch.xPu} pu, B=${selectedBranch.bPu} pu (${selectedBranch.lengthKm} km)\nRatings: Summer ${selectedBranch.ratingSummerMva} MVA / Winter ${selectedBranch.ratingWinterMva} MVA / Post-Fault ${selectedBranch.postFaultRatingMva} MVA (${selectedBranch.ratingConditions})",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (brStudy != null) {
                            StatusPill(
                                text = if (brStudy.inService) {
                                    "FLOW: ${"%.1f".format(brStudy.pFromMw)} MW (${"%.1f".format(brStudy.loadingPct)}%)"
                                } else "OUT OF SERVICE / OPEN",
                                tone = when {
                                    !brStudy.inService -> StatusTone.CRITICAL
                                    brStudy.loadingPct > 90.0 -> StatusTone.CRITICAL
                                    brStudy.loadingPct > 75.0 -> StatusTone.AMBER
                                    else -> StatusTone.HEALTHY
                                }
                            )
                        }
                        SafetyBannerNotice(
                            text = "Breaker Observed: ${selectedBranch.breakerStatus.label} | Disconnector: ${selectedBranch.disconnectorStatus.label} | Energisation Known: ${selectedBranch.energisationKnown}. A reported breaker position alone never confirms equipment is isolated or safe to work on.",
                            isWarning = selectedBranch.breakerStatus != SwitchStatus.CLOSED
                        )
                        Text(
                            text = "Simulate Telemetry Observation State (Non-Control):",
                            style = MaterialTheme.typography.labelLarge
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SwitchStatus.entries.forEach { st ->
                                OutlinedButton(
                                    onClick = { onSimulateSwitchStatus(selectedBranch.id, st) },
                                    modifier = Modifier.testTag("sim_switch_${st.name}")
                                ) {
                                    Text(st.label, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    } else if (selectedBus != null) {
                        val busStudy = uiState.currentStudyResult.busResults.firstOrNull { it.busId == selectedBus.id }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(selectedBus.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                            VoltageChip(selectedBus.nominalKv, selectedBus.systemArea == SystemArea.NI)
                        }
                        val coordDisplay = if (uiState.activeOrg.canViewRestrictedCoords) {
                            "WGS84 (${selectedBus.coords.latitude}, ${selectedBus.coords.longitude}) • OSGB36 E:${selectedBus.coords.osgbEasting} N:${selectedBus.coords.osgbNorthing}"
                        } else {
                            "REDACTED (External Observer lacks CNI coordinate clearance)"
                        }
                        Text(
                            text = "ID: ${selectedBus.id} • System: ${selectedBus.systemArea.label}\nOwner: ${selectedBus.ownerOrg.shortName} • Data Authority: ${selectedBus.dataAuthority.shortName}\nCoordinates: $coordDisplay\nBase Load: ${selectedBus.baseLoadMw} MW / ${selectedBus.baseLoadMvar} MVAr • Scheduled Gen: ${selectedBus.scheduledGenMw} MW\nCondition Score: ${selectedBus.conditionScore}/100 • Last Inspection: ${selectedBus.lastInspectionDate}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (busStudy != null) {
                            StatusPill(
                                text = if (busStudy.energised) {
                                    "MODELLED V: ${"%.3f".format(busStudy.voltagePu)} pu (${"%.1f".format(busStudy.voltageKv)} kV) ∠${"%.2f".format(busStudy.angleDeg)}°"
                                } else {
                                    "DISCONNECTED ISLAND (0.0 kV)"
                                },
                                tone = if (!busStudy.energised) StatusTone.CRITICAL else StatusTone.HEALTHY
                            )
                        }
                    }
                }
            }
        }

        // Accessible tabular view alongside Map/SLD
        item {
            Text(
                text = "Accessible Busbar & Circuit Table (${matchingBuses.size} buses)",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
        items(matchingBuses.size) { idx ->
            val bus = matchingBuses[idx]
            val res = uiState.currentStudyResult.busResults.firstOrNull { it.busId == bus.id }
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier
                    .testTag("bus_table_row_${bus.id}")
                    .clickable { onSelectBus(bus.id) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(bus.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = "${bus.ownerOrg.code} • Load ${bus.baseLoadMw.toInt()} MW • Gen ${bus.scheduledGenMw.toInt()} MW",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        VoltageChip(bus.nominalKv, bus.systemArea == SystemArea.NI)
                        Text(
                            text = if (res != null && res.energised) "${"%.3f".format(res.voltagePu)} pu" else if (bus.systemArea == SystemArea.NI) "NI Sync" else "ISLAND",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (res != null && !res.energised) StatusCritical else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}
