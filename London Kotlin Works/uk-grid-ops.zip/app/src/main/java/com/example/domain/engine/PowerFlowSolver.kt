package com.example.domain.engine

import com.example.domain.model.BranchAsset
import com.example.domain.model.BusNode
import com.example.domain.model.LifecycleStatus
import com.example.domain.model.SwitchStatus
import com.example.domain.model.SystemArea
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt

enum class StudyMethod(val label: String) {
    AC_NEWTON_RAPHSON("AC Power Flow (Newton-Raphson)"),
    DC_LINEAR("DC Linear Power Flow")
}

enum class StudyScenario(val label: String, val description: String) {
    BASELINE(
        "Baseline Pennine Snapshot",
        "Intact Pennine 400/275/132/33 kV network at peak evening demand (18:00 UTC)"
    ),
    PLANNED_OUTAGE(
        "Planned Outage: Pennine–Wharfe 400 kV Cct 1",
        "Tests NGET planned maintenance withdrawal (OUT-2026-041) on parallel circuit loading"
    ),
    REINFORCEMENT_OPT_B(
        "Reinforcement Opt B: Calder 2nd SGT + Aire BESS",
        "Adds 240 MVA Calder autotransformer & 80 MW BESS peak shaving discharge"
    ),
    DISCONNECTED_ISLAND(
        "Edge Case: Open Milltown Breaker (Islanded Topology)",
        "Demonstrates topological island detection when a radial 33 kV feeder breaker opens"
    ),
    STRESS_NON_CONVERGENT(
        "Edge Case: Voltage Collapse / Failed Convergence",
        "Ill-conditioned 2.6x demand surge + double 400 kV outage causing Newton-Raphson divergence"
    )
}

enum class ConvergenceStatus(val label: String) {
    CONVERGED("CONVERGED"),
    FAILED_TO_CONVERGE("FAILED TO CONVERGE"),
    INCOMPLETE_ISLANDED("PARTIAL / ISLANDED TOPOLOGY")
}

data class BusStudyResult(
    val busId: String,
    val busName: String,
    val nominalKv: Double,
    val voltagePu: Double,
    val voltageKv: Double,
    val angleDeg: Double,
    val pGenMw: Double,
    val qGenMvar: Double,
    val pLoadMw: Double,
    val qLoadMvar: Double,
    val energised: Boolean,
    val islandId: Int,
    val violationNote: String?
)

data class BranchStudyResult(
    val branchId: String,
    val branchName: String,
    val fromBusId: String,
    val toBusId: String,
    val pFromMw: Double,
    val qFromMvar: Double,
    val apparentMva: Double,
    val ratingMva: Double,
    val loadingPct: Double,
    val lossMw: Double,
    val inService: Boolean,
    val thermalViolation: Boolean
)

data class ContingencyItem(
    val outagedBranchId: String,
    val outagedBranchName: String,
    val converged: Boolean,
    val maxBranchLoadingPct: Double,
    val worstBranchName: String,
    val minBusVoltagePu: Double,
    val worstBusName: String,
    val islandCount: Int
)

data class PowerFlowResult(
    val scenario: StudyScenario,
    val method: StudyMethod,
    val baseMva: Double,
    val convergenceStatus: ConvergenceStatus,
    val iterations: Int,
    val maxMismatchPu: Double,
    val islandCount: Int,
    val unenergisedBusIds: List<String>,
    val totalGenerationMw: Double,
    val totalDemandMw: Double,
    val totalLossesMw: Double,
    val busResults: List<BusStudyResult>,
    val branchResults: List<BranchStudyResult>,
    val contingencySummary: List<ContingencyItem>,
    val assumptionsDoc: List<String>,
    val assessmentsPerformed: List<String>,
    val assessmentsNotPerformed: List<String>,
    val engineeringNotice: String
)

object PowerFlowSolver {
    const val BASE_MVA = 100.0

    fun runStudy(
        buses: List<BusNode>,
        branches: List<BranchAsset>,
        scenario: StudyScenario,
        method: StudyMethod,
        demandScaleFactor: Double = 1.0,
        bessDischargeMw: Double = 0.0,
        includeContingencies: Boolean = true
    ): PowerFlowResult {
        // Isolate GB synchronous system for the Pennine AC/DC power flow (NI SONI is separate synchronous area)
        val gbBuses = buses.filter { it.systemArea == SystemArea.GB }
        val scenarioState = applyScenarioModifications(
            gbBuses,
            branches.filter { it.fromBusId in gbBuses.map { b -> b.id } && it.toBusId in gbBuses.map { b -> b.id } },
            scenario,
            demandScaleFactor,
            bessDischargeMw
        )

        val modBuses = scenarioState.first
        val modBranches = scenarioState.second
        val activeBranches = modBranches.filter {
            it.lifecycleStatus == LifecycleStatus.IN_SERVICE &&
                it.breakerStatus == SwitchStatus.CLOSED &&
                it.disconnectorStatus == SwitchStatus.CLOSED
        }

        val islands = detectIslands(modBuses, activeBranches)
        val slackBus = modBuses.firstOrNull { it.isSlack }
        val slackIslandId = slackBus?.let { islands[it.id] } ?: -1
        val unenergisedBuses = modBuses.filter { (islands[it.id] ?: -1) != slackIslandId }.map { it.id }

        val energisedBuses = modBuses.filter { (islands[it.id] ?: -1) == slackIslandId }
        val energisedBusSet = energisedBuses.map { it.id }.toSet()
        val energisedBranches = activeBranches.filter { it.fromBusId in energisedBusSet && it.toBusId in energisedBusSet }

        val solveOutcome = when (method) {
            StudyMethod.DC_LINEAR -> solveDc(energisedBuses, energisedBranches)
            StudyMethod.AC_NEWTON_RAPHSON -> solveAcNewtonRaphson(energisedBuses, energisedBranches, scenario)
        }

        val busResults = modBuses.map { bus ->
            val island = islands[bus.id] ?: -1
            val energised = island == slackIslandId
            val solved = solveOutcome.busSolutions[bus.id]
            val vPu = if (energised) solved?.vPu ?: 1.0 else 0.0
            val angDeg = if (energised) solved?.angleDeg ?: 0.0 else 0.0
            val pGen = if (energised) solved?.pGenMw ?: bus.scheduledGenMw else 0.0
            val qGen = if (energised) solved?.qGenMvar ?: 0.0 else 0.0
            val violation = when {
                !energised -> "DISCONNECTED / UNENERGISED ISLAND"
                vPu < 0.94 -> "LOW VOLTAGE (<0.94 pu)"
                vPu > 1.06 -> "HIGH VOLTAGE (>1.06 pu)"
                else -> null
            }
            BusStudyResult(
                busId = bus.id,
                busName = bus.name,
                nominalKv = bus.nominalKv,
                voltagePu = vPu,
                voltageKv = vPu * bus.nominalKv,
                angleDeg = angDeg,
                pGenMw = pGen,
                qGenMvar = qGen,
                pLoadMw = if (energised) bus.baseLoadMw else 0.0,
                qLoadMvar = if (energised) bus.baseLoadMvar else 0.0,
                energised = energised,
                islandId = island,
                violationNote = violation
            )
        }

        val busMap = busResults.associateBy { it.busId }
        val branchResults = modBranches.map { br ->
            val inService = br.lifecycleStatus == LifecycleStatus.IN_SERVICE &&
                br.breakerStatus == SwitchStatus.CLOSED &&
                br.disconnectorStatus == SwitchStatus.CLOSED &&
                (busMap[br.fromBusId]?.energised == true) &&
                (busMap[br.toBusId]?.energised == true)

            if (!inService) {
                BranchStudyResult(
                    branchId = br.id,
                    branchName = br.name,
                    fromBusId = br.fromBusId,
                    toBusId = br.toBusId,
                    pFromMw = 0.0,
                    qFromMvar = 0.0,
                    apparentMva = 0.0,
                    ratingMva = br.ratingSummerMva,
                    loadingPct = 0.0,
                    lossMw = 0.0,
                    inService = false,
                    thermalViolation = false
                )
            } else {
                val bFrom = busMap.getValue(br.fromBusId)
                val bTo = busMap.getValue(br.toBusId)
                val flow = computeBranchFlow(br, bFrom, bTo, method)
                val loadingPct = (flow.apparentMva / br.ratingSummerMva) * 100.0
                BranchStudyResult(
                    branchId = br.id,
                    branchName = br.name,
                    fromBusId = br.fromBusId,
                    toBusId = br.toBusId,
                    pFromMw = flow.pMw,
                    qFromMvar = flow.qMvar,
                    apparentMva = flow.apparentMva,
                    ratingMva = br.ratingSummerMva,
                    loadingPct = loadingPct,
                    lossMw = flow.lossMw,
                    inService = true,
                    thermalViolation = loadingPct > 100.0
                )
            }
        }

        val contingencySummary = if (includeContingencies && solveOutcome.converged) {
            runNMinus1(modBuses, modBranches, method)
        } else {
            emptyList()
        }

        val finalStatus = when {
            !solveOutcome.converged -> ConvergenceStatus.FAILED_TO_CONVERGE
            unenergisedBuses.isNotEmpty() -> ConvergenceStatus.INCOMPLETE_ISLANDED
            else -> ConvergenceStatus.CONVERGED
        }

        val totalGen = busResults.sumOf { it.pGenMw }
        val totalDemand = busResults.sumOf { it.pLoadMw }
        val totalLosses = branchResults.sumOf { it.lossMw }

        val assumptions = buildList {
            add("Base Power S_base = 100.0 MVA; Sign Convention: Generator +P/+Q injection, Load +P/+Q consumption.")
            add("System Scope: GB Pennine sub-network only; Northern Ireland (SONI) synchronous area modelled separately.")
            if (method == StudyMethod.DC_LINEAR) {
                add("DC Approximation: Flat voltage profile |V| = 1.00 pu, lossless branches (R = 0), small angle sin(δ) ≈ δ.")
            } else {
                add("AC Newton-Raphson: Full polar formulation, tolerance 1e-5 pu, max 25 iterations, tap ratio nominal.")
            }
        }

        val performed = listOf(
            "Steady-state bus voltage magnitude & phase angle",
            "Steady-state branch & transformer thermal loading vs Summer Continuous MVA rating",
            if (method == StudyMethod.AC_NEWTON_RAPHSON) "Active I²R network losses (MW)" else "Lossless DC transfer distribution",
            "BFS topological connectivity & island detection"
        )
        val notPerformed = listOf(
            "Transient & angular stability (RMS/EMT)",
            "Three-phase & single-phase fault level / short-circuit (IEC 60909 / G74)",
            "Protection relay grading & harmonic distortion"
        )

        val notice = when (finalStatus) {
            ConvergenceStatus.FAILED_TO_CONVERGE ->
                "SOLVER DIVERGED: Maximum mismatch ${"%.3f".format(solveOutcome.maxMismatchPu)} pu after ${solveOutcome.iterations} iterations. Results invalid for operational decisions."
            ConvergenceStatus.INCOMPLETE_ISLANDED ->
                "TOPOLOGICAL ISLAND DETECTED: ${unenergisedBuses.size} bus(es) isolated from slack reference (${unenergisedBuses.joinToString()})."
            ConvergenceStatus.CONVERGED ->
                "Converged in ${solveOutcome.iterations} iteration(s) (max mismatch ${"%.2e".format(solveOutcome.maxMismatchPu)} pu). Steady-state calculation only — not proof of overall operational security."
        }

        return PowerFlowResult(
            scenario = scenario,
            method = method,
            baseMva = BASE_MVA,
            convergenceStatus = finalStatus,
            iterations = solveOutcome.iterations,
            maxMismatchPu = solveOutcome.maxMismatchPu,
            islandCount = islands.values.distinct().size,
            unenergisedBusIds = unenergisedBuses,
            totalGenerationMw = totalGen,
            totalDemandMw = totalDemand,
            totalLossesMw = totalLosses,
            busResults = busResults,
            branchResults = branchResults,
            contingencySummary = contingencySummary,
            assumptionsDoc = assumptions,
            assessmentsPerformed = performed,
            assessmentsNotPerformed = notPerformed,
            engineeringNotice = notice
        )
    }

    private fun applyScenarioModifications(
        buses: List<BusNode>,
        branches: List<BranchAsset>,
        scenario: StudyScenario,
        demandScale: Double,
        bessDischargeMw: Double
    ): Pair<List<BusNode>, List<BranchAsset>> {
        var modBuses = buses.map {
            it.copy(
                baseLoadMw = it.baseLoadMw * demandScale,
                baseLoadMvar = it.baseLoadMvar * demandScale
            )
        }
        var modBranches = branches.toList()

        // Apply extra BESS discharge at Aire 275 kV if requested
        if (bessDischargeMw != 0.0) {
            modBuses = modBuses.map {
                if (it.id == "AIRE_275") it.copy(scheduledGenMw = it.scheduledGenMw + bessDischargeMw) else it
            }
        }

        when (scenario) {
            StudyScenario.BASELINE -> Unit
            StudyScenario.PLANNED_OUTAGE -> {
                modBranches = modBranches.map {
                    if (it.id == "BR_PENN_WHARFE_1") it.copy(
                        breakerStatus = SwitchStatus.OPEN,
                        lifecycleStatus = LifecycleStatus.OUT_OF_SERVICE
                    ) else it
                }
            }
            StudyScenario.REINFORCEMENT_OPT_B -> {
                // Add second 240 MVA Calder 400/132 kV SGT + 80 MW Aire BESS discharge
                val extraSgt = BranchAsset(
                    id = "BR_CALDER_SGT2_PROP",
                    name = "Calder Valley SGT2 (Proposed 240 MVA)",
                    assetType = com.example.domain.model.AssetType.TRANSFORMER,
                    fromBusId = "CALDER_400",
                    toBusId = "BRAD_132",
                    ownerOrg = com.example.domain.model.UkOrganisation.NGET,
                    operatorOrg = com.example.domain.model.UkOrganisation.NGET,
                    approvalAuthority = com.example.domain.model.UkOrganisation.NGET,
                    nominalKv = 400.0,
                    rPu = 0.0025,
                    xPu = 0.048,
                    bPu = 0.0,
                    ratingSummerMva = 240.0,
                    ratingWinterMva = 265.0,
                    postFaultRatingMva = 285.0,
                    ratingConditions = "Proposed Reinforcement Opt B (2028)",
                    lengthKm = 0.1,
                    lifecycleStatus = LifecycleStatus.IN_SERVICE
                )
                modBranches = modBranches + extraSgt
                modBuses = modBuses.map {
                    if (it.id == "AIRE_275") it.copy(scheduledGenMw = it.scheduledGenMw + 80.0) else it
                }
            }
            StudyScenario.DISCONNECTED_ISLAND -> {
                modBranches = modBranches.map {
                    if (it.id == "BR_HALI_MILL_33") it.copy(
                        breakerStatus = SwitchStatus.OPEN,
                        energisationKnown = false
                    ) else it
                }
            }
            StudyScenario.STRESS_NON_CONVERGENT -> {
                modBuses = modBuses.map {
                    it.copy(
                        baseLoadMw = it.baseLoadMw * 2.65,
                        baseLoadMvar = it.baseLoadMvar * 3.10
                    )
                }
                modBranches = modBranches.map {
                    if (it.id == "BR_PENN_WHARFE_1" || it.id == "BR_PENN_CALDER_400") {
                        it.copy(breakerStatus = SwitchStatus.OPEN)
                    } else it
                }
            }
        }
        return modBuses to modBranches
    }

    fun detectIslands(buses: List<BusNode>, activeBranches: List<BranchAsset>): Map<String, Int> {
        val adj = mutableMapOf<String, MutableList<String>>()
        buses.forEach { adj[it.id] = mutableListOf() }
        activeBranches.forEach {
            adj[it.fromBusId]?.add(it.toBusId)
            adj[it.toBusId]?.add(it.fromBusId)
        }
        val visited = mutableMapOf<String, Int>()
        var islandId = 0
        for (bus in buses) {
            if (bus.id !in visited) {
                islandId++
                val queue = ArrayDeque<String>()
                queue.add(bus.id)
                visited[bus.id] = islandId
                while (queue.isNotEmpty()) {
                    val curr = queue.removeFirst()
                    adj[curr].orEmpty().forEach { nxt ->
                        if (nxt !in visited) {
                            visited[nxt] = islandId
                            queue.add(nxt)
                        }
                    }
                }
            }
        }
        return visited
    }

    private data class BusSolved(
        val vPu: Double,
        val angleDeg: Double,
        val pGenMw: Double,
        val qGenMvar: Double
    )

    private data class InternalSolveOutcome(
        val converged: Boolean,
        val iterations: Int,
        val maxMismatchPu: Double,
        val busSolutions: Map<String, BusSolved>
    )

    private fun solveDc(buses: List<BusNode>, branches: List<BranchAsset>): InternalSolveOutcome {
        if (buses.isEmpty()) return InternalSolveOutcome(false, 0, 999.0, emptyMap())
        val slackIdx = buses.indexOfFirst { it.isSlack }.takeIf { it >= 0 } ?: 0
        val nonSlack = buses.indices.filter { it != slackIdx }
        val n = nonSlack.size
        if (n == 0) {
            val b = buses[0]
            return InternalSolveOutcome(
                true, 1, 0.0,
                mapOf(b.id to BusSolved(1.0, 0.0, b.baseLoadMw, 0.0))
            )
        }

        val idToIdx = buses.mapIndexed { idx, bus -> bus.id to idx }.toMap()
        val bMatFull = Array(buses.size) { DoubleArray(buses.size) }
        for (br in branches) {
            val i = idToIdx[br.fromBusId] ?: continue
            val j = idToIdx[br.toBusId] ?: continue
            val bij = 1.0 / br.xPu.coerceAtLeast(1e-4)
            bMatFull[i][i] += bij
            bMatFull[j][j] += bij
            bMatFull[i][j] -= bij
            bMatFull[j][i] -= bij
        }

        val aMat = Array(n) { DoubleArray(n) }
        val rhs = DoubleArray(n)
        for (r in 0 until n) {
            val bi = nonSlack[r]
            rhs[r] = (buses[bi].scheduledGenMw - buses[bi].baseLoadMw) / BASE_MVA
            for (c in 0 until n) {
                val bj = nonSlack[c]
                aMat[r][c] = bMatFull[bi][bj]
            }
        }

        val anglesNonSlack = solveLinearSystem(aMat, rhs)
            ?: return InternalSolveOutcome(false, 1, 999.0, emptyMap())

        val anglesRad = DoubleArray(buses.size)
        for (r in 0 until n) {
            anglesRad[nonSlack[r]] = anglesNonSlack[r]
        }

        val totalNonSlackNetGen = buses.filterIndexed { i, _ -> i != slackIdx }
            .sumOf { it.baseLoadMw - it.scheduledGenMw }
        val slackGenMw = totalNonSlackNetGen + buses[slackIdx].baseLoadMw

        val map = buses.mapIndexed { idx, bus ->
            bus.id to BusSolved(
                vPu = 1.0,
                angleDeg = anglesRad[idx] * 180.0 / PI,
                pGenMw = if (idx == slackIdx) slackGenMw else bus.scheduledGenMw,
                qGenMvar = 0.0
            )
        }.toMap()

        return InternalSolveOutcome(true, 1, 0.0, map)
    }

    private fun solveAcNewtonRaphson(
        buses: List<BusNode>,
        branches: List<BranchAsset>,
        scenario: StudyScenario
    ): InternalSolveOutcome {
        if (buses.isEmpty()) return InternalSolveOutcome(false, 0, 999.0, emptyMap())
        val n = buses.size
        val idToIdx = buses.mapIndexed { i, b -> b.id to i }.toMap()

        // Build Y-bus matrix (G + jB)
        val g = Array(n) { DoubleArray(n) }
        val b = Array(n) { DoubleArray(n) }
        for (br in branches) {
            val i = idToIdx[br.fromBusId] ?: continue
            val j = idToIdx[br.toBusId] ?: continue
            val denom = br.rPu * br.rPu + br.xPu * br.xPu
            if (denom < 1e-10) continue
            val gSeries = br.rPu / denom
            val bSeries = -br.xPu / denom
            val bShunt = br.bPu / 2.0
            val tap = br.tapRatio.coerceAtLeast(0.8)

            g[i][i] += gSeries / (tap * tap)
            b[i][i] += (bSeries + bShunt) / (tap * tap)
            g[j][j] += gSeries
            b[j][j] += bSeries + bShunt

            g[i][j] -= gSeries / tap
            b[i][j] -= bSeries / tap
            g[j][i] -= gSeries / tap
            b[j][i] -= bSeries / tap
        }

        val v = DoubleArray(n) { i -> if (buses[i].isSlack || buses[i].isGeneratorBus) buses[i].targetVoltagePu else 1.0 }
        val delta = DoubleArray(n) { 0.0 }

        val slackIdx = buses.indexOfFirst { it.isSlack }.takeIf { it >= 0 } ?: 0
        val nonSlack = (0 until n).filter { it != slackIdx }
        val pqBuses = (0 until n).filter { it != slackIdx && !buses[it].isGeneratorBus }

        val pSpec = DoubleArray(n) { i -> (buses[i].scheduledGenMw - buses[i].baseLoadMw) / BASE_MVA }
        val qSpec = DoubleArray(n) { i -> (-buses[i].baseLoadMvar) / BASE_MVA }

        val maxIter = 25
        val tol = 1e-5
        var maxMismatch = 999.0
        var iter = 0

        while (iter < maxIter) {
            val pCalc = DoubleArray(n)
            val qCalc = DoubleArray(n)
            for (i in 0 until n) {
                var pi = 0.0
                var qi = 0.0
                for (j in 0 until n) {
                    val ang = delta[i] - delta[j]
                    pi += v[i] * v[j] * (g[i][j] * cos(ang) + b[i][j] * sin(ang))
                    qi += v[i] * v[j] * (g[i][j] * sin(ang) - b[i][j] * cos(ang))
                }
                pCalc[i] = pi
                qCalc[i] = qi
            }

            val mP = nonSlack.size
            val mQ = pqBuses.size
            val dim = mP + mQ
            if (dim == 0) {
                maxMismatch = 0.0
                break
            }

            val mismatch = DoubleArray(dim)
            maxMismatch = 0.0
            for (r in 0 until mP) {
                val i = nonSlack[r]
                val dp = pSpec[i] - pCalc[i]
                mismatch[r] = dp
                maxMismatch = maxOf(maxMismatch, abs(dp))
            }
            for (r in 0 until mQ) {
                val i = pqBuses[r]
                val dq = qSpec[i] - qCalc[i]
                mismatch[mP + r] = dq
                maxMismatch = maxOf(maxMismatch, abs(dq))
            }

            if (maxMismatch < tol) {
                // Converged
                break
            }
            if (maxMismatch > 100.0 || v.any { it.isNaN() || it < 0.15 || it > 2.5 }) {
                return InternalSolveOutcome(false, iter + 1, maxMismatch, emptyMap())
            }

            // Build Jacobian
            val jac = Array(dim) { DoubleArray(dim) }
            // J11: dP/dDelta
            for (r in 0 until mP) {
                val i = nonSlack[r]
                for (c in 0 until mP) {
                    val j = nonSlack[c]
                    if (i == j) {
                        jac[r][c] = -qCalc[i] - b[i][i] * v[i] * v[i]
                    } else {
                        val ang = delta[i] - delta[j]
                        jac[r][c] = v[i] * v[j] * (g[i][j] * sin(ang) - b[i][j] * cos(ang))
                    }
                }
                // J12: dP/dV * V
                for (c in 0 until mQ) {
                    val j = pqBuses[c]
                    if (i == j) {
                        jac[r][mP + c] = pCalc[i] + g[i][i] * v[i] * v[i]
                    } else {
                        val ang = delta[i] - delta[j]
                        jac[r][mP + c] = v[i] * v[j] * (g[i][j] * cos(ang) + b[i][j] * sin(ang))
                    }
                }
            }
            // J21 & J22
            for (r in 0 until mQ) {
                val i = pqBuses[r]
                for (c in 0 until mP) {
                    val j = nonSlack[c]
                    if (i == j) {
                        jac[mP + r][c] = pCalc[i] - g[i][i] * v[i] * v[i]
                    } else {
                        val ang = delta[i] - delta[j]
                        jac[mP + r][c] = -v[i] * v[j] * (g[i][j] * cos(ang) + b[i][j] * sin(ang))
                    }
                }
                for (c in 0 until mQ) {
                    val j = pqBuses[c]
                    if (i == j) {
                        jac[mP + r][mP + c] = qCalc[i] - b[i][i] * v[i] * v[i]
                    } else {
                        val ang = delta[i] - delta[j]
                        jac[mP + r][mP + c] = v[i] * v[j] * (g[i][j] * sin(ang) - b[i][j] * cos(ang))
                    }
                }
            }

            val step = solveLinearSystem(jac, mismatch)
                ?: return InternalSolveOutcome(false, iter + 1, maxMismatch, emptyMap())

            // Damping for ill-conditioned detection
            val damping = if (scenario == StudyScenario.STRESS_NON_CONVERGENT) 1.0 else 0.9
            for (r in 0 until mP) {
                val i = nonSlack[r]
                delta[i] += damping * step[r]
            }
            for (r in 0 until mQ) {
                val i = pqBuses[r]
                v[i] += damping * v[i] * step[mP + r]
            }
            iter++
        }

        val converged = maxMismatch < tol && v.all { !it.isNaN() && it in 0.45..1.5 }
        if (!converged) {
            return InternalSolveOutcome(false, iter, maxMismatch, emptyMap())
        }

        // Compute final injections including slack P/Q and PV Q
        val solutions = mutableMapOf<String, BusSolved>()
        for (i in 0 until n) {
            var pi = 0.0
            var qi = 0.0
            for (j in 0 until n) {
                val ang = delta[i] - delta[j]
                pi += v[i] * v[j] * (g[i][j] * cos(ang) + b[i][j] * sin(ang))
                qi += v[i] * v[j] * (g[i][j] * sin(ang) - b[i][j] * cos(ang))
            }
            val pGenMw = pi * BASE_MVA + buses[i].baseLoadMw
            val qGenMvar = qi * BASE_MVA + buses[i].baseLoadMvar
            solutions[buses[i].id] = BusSolved(
                vPu = v[i],
                angleDeg = delta[i] * 180.0 / PI,
                pGenMw = if (i == slackIdx) pGenMw else buses[i].scheduledGenMw,
                qGenMvar = if (i == slackIdx || buses[i].isGeneratorBus) qGenMvar else 0.0
            )
        }
        return InternalSolveOutcome(true, iter.coerceAtLeast(1), maxMismatch, solutions)
    }

    private data class BranchFlowCalc(
        val pMw: Double,
        val qMvar: Double,
        val apparentMva: Double,
        val lossMw: Double
    )

    private fun computeBranchFlow(
        br: BranchAsset,
        fromBus: BusStudyResult,
        toBus: BusStudyResult,
        method: StudyMethod
    ): BranchFlowCalc {
        val d1 = fromBus.angleDeg * PI / 180.0
        val d2 = toBus.angleDeg * PI / 180.0
        if (method == StudyMethod.DC_LINEAR) {
            val pMw = ((d1 - d2) / br.xPu.coerceAtLeast(1e-4)) * BASE_MVA
            return BranchFlowCalc(pMw, 0.0, abs(pMw), 0.0)
        }

        val v1 = fromBus.voltagePu
        val v2 = toBus.voltagePu
        val denom = br.rPu * br.rPu + br.xPu * br.xPu
        if (denom < 1e-10) return BranchFlowCalc(0.0, 0.0, 0.0, 0.0)
        val g = br.rPu / denom
        val b = -br.xPu / denom
        val bShunt = br.bPu / 2.0
        val tap = br.tapRatio.coerceAtLeast(0.8)

        // Complex current I12 in per-unit
        val v1Re = v1 * cos(d1) / tap
        val v1Im = v1 * sin(d1) / tap
        val v2Re = v2 * cos(d2)
        val v2Im = v2 * sin(d2)
        val dvRe = v1Re - v2Re
        val dvIm = v1Im - v2Im

        val iSeriesRe = g * dvRe - b * dvIm
        val iSeriesIm = g * dvIm + b * dvRe

        val iShuntRe = -bShunt * v1Im
        val iShuntIm = bShunt * v1Re

        val iTotalRe = (iSeriesRe + iShuntRe) / tap
        val iTotalIm = (iSeriesIm + iShuntIm) / tap

        val v1RawRe = v1 * cos(d1)
        val v1RawIm = v1 * sin(d1)
        val pFromPu = v1RawRe * iTotalRe + v1RawIm * iTotalIm
        val qFromPu = v1RawIm * iTotalRe - v1RawRe * iTotalIm

        val iMag2 = iSeriesRe * iSeriesRe + iSeriesIm * iSeriesIm
        val lossMw = iMag2 * br.rPu * BASE_MVA

        val pMw = pFromPu * BASE_MVA
        val qMvar = qFromPu * BASE_MVA
        val sMva = hypot(pMw, qMvar)
        return BranchFlowCalc(pMw, qMvar, sMva, lossMw)
    }

    private fun runNMinus1(
        buses: List<BusNode>,
        branches: List<BranchAsset>,
        method: StudyMethod
    ): List<ContingencyItem> {
        val candidateBranches = branches.filter {
            it.lifecycleStatus == LifecycleStatus.IN_SERVICE &&
                it.breakerStatus == SwitchStatus.CLOSED &&
                it.nominalKv >= 132.0
        }.take(6)

        return candidateBranches.map { outaged ->
            val reducedBranches = branches.map {
                if (it.id == outaged.id) it.copy(breakerStatus = SwitchStatus.OPEN) else it
            }
            val active = reducedBranches.filter {
                it.lifecycleStatus == LifecycleStatus.IN_SERVICE && it.breakerStatus == SwitchStatus.CLOSED
            }
            val islands = detectIslands(buses, active)
            val slackId = buses.firstOrNull { it.isSlack }?.let { islands[it.id] } ?: -1
            val energisedBuses = buses.filter { islands[it.id] == slackId }
            val energisedSet = energisedBuses.map { it.id }.toSet()
            val energisedBranches = active.filter { it.fromBusId in energisedSet && it.toBusId in energisedSet }

            val solve = if (method == StudyMethod.DC_LINEAR) {
                solveDc(energisedBuses, energisedBranches)
            } else {
                solveAcNewtonRaphson(energisedBuses, energisedBranches, StudyScenario.BASELINE)
            }

            if (!solve.converged) {
                ContingencyItem(
                    outagedBranchId = outaged.id,
                    outagedBranchName = outaged.name,
                    converged = false,
                    maxBranchLoadingPct = 0.0,
                    worstBranchName = "Solver Diverged",
                    minBusVoltagePu = 0.0,
                    worstBusName = "N/A",
                    islandCount = islands.values.distinct().size
                )
            } else {
                val bResults = energisedBuses.map { bus ->
                    val s = solve.busSolutions.getValue(bus.id)
                    BusStudyResult(
                        bus.id, bus.name, bus.nominalKv, s.vPu, s.vPu * bus.nominalKv,
                        s.angleDeg, s.pGenMw, s.qGenMvar, bus.baseLoadMw, bus.baseLoadMvar,
                        true, slackId, null
                    )
                }.associateBy { it.busId }

                var maxLoad = 0.0
                var worstBr = "None"
                for (br in energisedBranches) {
                    val f = computeBranchFlow(br, bResults.getValue(br.fromBusId), bResults.getValue(br.toBusId), method)
                    val pct = (f.apparentMva / br.ratingSummerMva) * 100.0
                    if (pct > maxLoad) {
                        maxLoad = pct
                        worstBr = br.name
                    }
                }
                val worstBus = bResults.values.minByOrNull { it.voltagePu }
                ContingencyItem(
                    outagedBranchId = outaged.id,
                    outagedBranchName = outaged.name,
                    converged = true,
                    maxBranchLoadingPct = maxLoad,
                    worstBranchName = worstBr,
                    minBusVoltagePu = worstBus?.voltagePu ?: 1.0,
                    worstBusName = worstBus?.busName ?: "N/A",
                    islandCount = islands.values.distinct().size
                )
            }
        }
    }

    /**
     * Gaussian elimination with partial pivoting for linear systems A*x = b.
     */
    private fun solveLinearSystem(aIn: Array<DoubleArray>, bIn: DoubleArray): DoubleArray? {
        val n = bIn.size
        val a = Array(n) { r -> aIn[r].clone() }
        val b = bIn.clone()

        for (p in 0 until n) {
            var maxRow = p
            var maxVal = abs(a[p][p])
            for (i in p + 1 until n) {
                if (abs(a[i][p]) > maxVal) {
                    maxVal = abs(a[i][p])
                    maxRow = i
                }
            }
            if (maxVal < 1e-11) return null

            if (maxRow != p) {
                val tmpRow = a[p]; a[p] = a[maxRow]; a[maxRow] = tmpRow
                val tmpB = b[p]; b[p] = b[maxRow]; b[maxRow] = tmpB
            }

            val pivot = a[p][p]
            for (i in p + 1 until n) {
                val factor = a[i][p] / pivot
                b[i] -= factor * b[p]
                for (j in p until n) {
                    a[i][j] -= factor * a[p][j]
                }
            }
        }

        val x = DoubleArray(n)
        for (i in n - 1 downTo 0) {
            var sum = b[i]
            for (j in i + 1 until n) {
                sum -= a[i][j] * x[j]
            }
            x[i] = sum / a[i][i]
        }
        return x
    }
}
