package com.example.data.local

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "assets")
data class AssetEntity(
    @PrimaryKey val id: String,
    val name: String,
    val assetCategory: String,
    val ownerOrgCode: String,
    val operatorOrgCode: String,
    val nominalKv: Double,
    val ratingSummerMva: Double,
    val lifecycleStatus: String,
    val verificationStatus: String,
    val lastInspectionDate: String,
    val conditionScore: Int,
    val version: Int
)

@Entity(tableName = "outages")
data class OutageEntity(
    @PrimaryKey val id: String,
    val title: String,
    val affectedEquipmentId: String,
    val affectedEquipmentName: String,
    val ownerOrgCode: String,
    val coordinatingOrgCode: String,
    val stageName: String,
    val startWindow: String,
    val endWindow: String,
    val dependencies: String,
    val conflictingWork: String,
    val studyEvidenceSummary: String,
    val approvalHistoryJoined: String
)

@Entity(tableName = "work_orders")
data class WorkOrderEntity(
    @PrimaryKey val id: String,
    val equipmentId: String,
    val equipmentName: String,
    val ownerOrgCode: String,
    val title: String,
    val defectSummary: String,
    val priorityScore: Int,
    val prioritisationRuleExplanation: String,
    val predictiveEvidence: String,
    val sparePartsRequired: String,
    val assignedContractor: String,
    val hasPhotoEvidence: Boolean,
    val completionEvidence: String,
    val statusName: String,
    val version: Int,
    val serverVersion: Int,
    val syncStatusName: String,
    val updatedBy: String,
    val updatedAtIso: String,
    val conflictingServerNote: String?
)

@Entity(tableName = "alerts")
data class AlertEntity(
    @PrimaryKey val id: String,
    val title: String,
    val equipmentId: String,
    val ownerOrgCode: String,
    val severityName: String,
    val severityRationale: String,
    val thresholdSource: String,
    val effectiveDate: String,
    val acknowledged: Boolean,
    val acknowledgedBy: String?,
    val assignedTo: String?,
    val escalationStatus: String,
    val conditionActive: Boolean,
    val chronologyJoined: String
)

@Entity(tableName = "reports")
data class ReportEntity(
    @PrimaryKey val id: String,
    val title: String,
    val snapshotId: String,
    val scenarioName: String,
    val authorOrgCode: String,
    val createdUtc: String,
    val dataSources: String,
    val assumptions: String,
    val solverStatusSummary: String,
    val findings: String,
    val limitations: String,
    val capexGbpMillions: Double,
    val opexGbpMillions: Double,
    val committedGbpMillions: Double,
    val actualGbpMillions: Double,
    val forecastGbpMillions: Double,
    val priceBaseDate: String,
    val approvalStatus: String,
    val approvalHistoryJoined: String
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey val id: String,
    val timestampUtc: String,
    val actorOrgCode: String,
    val action: String,
    val targetId: String,
    val outcome: String,
    val details: String
)

@Dao
interface GridDao {
    @Query("SELECT * FROM assets ORDER BY nominalKv DESC, name ASC")
    fun observeAssets(): Flow<List<AssetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAssets(items: List<AssetEntity>)

    @Update
    suspend fun updateAsset(item: AssetEntity)

    @Query("SELECT * FROM outages ORDER BY id ASC")
    fun observeOutages(): Flow<List<OutageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOutages(items: List<OutageEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertOutage(item: OutageEntity)

    @Query("SELECT * FROM work_orders ORDER BY priorityScore DESC")
    fun observeWorkOrders(): Flow<List<WorkOrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkOrders(items: List<WorkOrderEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWorkOrder(item: WorkOrderEntity)

    @Query("SELECT * FROM alerts ORDER BY id ASC")
    fun observeAlerts(): Flow<List<AlertEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlerts(items: List<AlertEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAlert(item: AlertEntity)

    @Query("SELECT * FROM reports ORDER BY createdUtc DESC")
    fun observeReports(): Flow<List<ReportEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReports(items: List<ReportEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertReport(item: ReportEntity)

    @Query("SELECT * FROM audit_logs ORDER BY timestampUtc DESC LIMIT 80")
    fun observeAuditLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(item: AuditLogEntity)

    @Query("SELECT COUNT(*) FROM assets")
    suspend fun assetCount(): Int
}
