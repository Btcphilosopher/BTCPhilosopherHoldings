package com.example.domain.model

enum class TelemetryLayer(val label: String) {
    RAW_OBSERVATION("Raw Observation"),
    VALIDATED_MEASUREMENT("Validated Measurement"),
    ESTIMATED_STATE("State Estimator"),
    FORECAST("Short-Term Forecast")
}

enum class QualityFlag(val label: String, val isWarning: Boolean, val isCritical: Boolean) {
    GOOD("GOOD", false, false),
    STALE("STALE (>300s)", true, false),
    SUSPECT("SUSPECT (Drift)", true, false),
    INVALID("INVALID (Range)", false, true),
    DUPLICATE_DROPPED("DUPLICATE DROPPED", true, false),
    CLOCK_SKEW_CORRECTED("CLOCK SKEW (+14s)", true, false),
    MISSING("MISSING / OUTAGE", false, true)
}

data class TelemetryObservation(
    val id: String,
    val equipmentId: String,
    val equipmentName: String,
    val ownerOrg: UkOrganisation,
    val metricName: String,
    val value: Double?,
    val unit: String,
    val sourceId: String,
    val observationTimeIso: String,
    val ingestionTimeIso: String,
    val dataAgeSeconds: Long,
    val qualityFlag: QualityFlag,
    val uncertainty: String,
    val layer: TelemetryLayer
)

data class IngestionDiagnostics(
    val packetsProcessed: Int,
    val duplicatesDropped: Int,
    val clockSkewCorrected: Int,
    val invalidRejected: Int,
    val staleSensors: Int,
    val sourceOutages: Int,
    val connectionHealth: String
)

data class AdapterInterfaceSpec(
    val adapterName: String,
    val protocol: String,
    val authRequirement: String,
    val status: String,
    val boundaryNote: String
)
