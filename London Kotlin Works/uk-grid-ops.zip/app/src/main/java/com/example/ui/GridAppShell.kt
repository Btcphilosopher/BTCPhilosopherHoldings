package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.engine.StudyScenario
import com.example.ui.components.SafetyBannerNotice
import com.example.ui.components.TelemetryProvenanceStrip
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.GridNavDestination
import com.example.ui.viewmodel.GridViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GridAppShell(viewModel: GridViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val persistedAssets by viewModel.persistedAssets.collectAsStateWithLifecycle()
    val outages by viewModel.outages.collectAsStateWithLifecycle()
    val workOrders by viewModel.workOrders.collectAsStateWithLifecycle()
    val alerts by viewModel.alerts.collectAsStateWithLifecycle()
    val reports by viewModel.reports.collectAsStateWithLifecycle()
    val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()

    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    if (uiState.activeDestination != GridNavDestination.OVERVIEW) {
        BackHandler {
            viewModel.navigateTo(GridNavDestination.OVERVIEW)
        }
    }

    val latestObs = uiState.observations.firstOrNull()
    val obsTime = latestObs?.observationTimeIso ?: "N/A"
    val dataAge = latestObs?.dataAgeSeconds ?: 0L

    UkGridOpsTheme(darkControlRoom = uiState.darkControlRoom) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isWideScreen = maxWidth >= 840.dp

            if (isWideScreen) {
                // Tablet / Laptop / Control-Room Sidebar + Main Workspace
                Scaffold(
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        DeepNavySidebar(
                            active = uiState.activeDestination,
                            onSelect = { viewModel.navigateTo(it) },
                            modifier = Modifier
                                .width(220.dp)
                                .fillMaxHeight()
                        )
                        Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
                            TelemetryProvenanceStrip(
                                operatingMode = uiState.operatingMode,
                                activeOrg = uiState.activeOrg,
                                brandingPreset = uiState.brandingPreset,
                                diagnostics = uiState.diagnostics,
                                observationTime = obsTime,
                                dataAgeSec = dataAge,
                                onOpenModeSwitch = { viewModel.navigateTo(GridNavDestination.TELEMETRY) },
                                onOpenOrgSwitch = { viewModel.navigateTo(GridNavDestination.ADMINISTRATION) }
                            )
                            BannerArea(uiState.bannerFeedback, uiState.bannerIsError, viewModel::clearBanner)
                            Box(modifier = Modifier.weight(1f)) {
                                GridDestinationContent(
                                    viewModel = viewModel,
                                    uiState = uiState,
                                    persistedAssets = persistedAssets,
                                    outages = outages,
                                    workOrders = workOrders,
                                    alerts = alerts,
                                    reports = reports,
                                    auditLogs = auditLogs
                                )
                            }
                        }
                    }
                }
            } else {
                // Compact Handheld / Portrait Tablet with Modal Drawer (all 12 modules) + 5-item Bottom Bar
                ModalNavigationDrawer(
                    drawerState = drawerState,
                    drawerContent = {
                        ModalDrawerSheet(
                            drawerContainerColor = GridNavy900,
                            drawerContentColor = Color.White,
                            modifier = Modifier.width(270.dp)
                        ) {
                            DeepNavySidebar(
                                active = uiState.activeDestination,
                                onSelect = {
                                    viewModel.navigateTo(it)
                                    scope.launch { drawerState.close() }
                                },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                ) {
                    Scaffold(
                        topBar = {
                            Column(modifier = Modifier.windowInsetsPadding(WindowInsets.statusBars)) {
                                TelemetryProvenanceStrip(
                                    operatingMode = uiState.operatingMode,
                                    activeOrg = uiState.activeOrg,
                                    brandingPreset = uiState.brandingPreset,
                                    diagnostics = uiState.diagnostics,
                                    observationTime = obsTime,
                                    dataAgeSec = dataAge,
                                    onOpenModeSwitch = { viewModel.navigateTo(GridNavDestination.TELEMETRY) },
                                    onOpenOrgSwitch = { viewModel.navigateTo(GridNavDestination.ADMINISTRATION) }
                                )
                                Surface(color = GridNavy800, contentColor = Color.White) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            IconButton(
                                                onClick = { scope.launch { drawerState.open() } },
                                                modifier = Modifier.testTag("open_nav_drawer_btn")
                                            ) {
                                                Icon(Icons.Default.Menu, contentDescription = "Open all 12 modules")
                                            }
                                            Text(
                                                text = uiState.activeDestination.label,
                                                style = MaterialTheme.typography.titleMedium,
                                                color = Color.White
                                            )
                                        }
                                        TextButton(
                                            onClick = { viewModel.navigateTo(GridNavDestination.REPORTS) },
                                            modifier = Modifier.testTag("topbar_demo_guide_btn")
                                        ) {
                                            Text(
                                                text = "Demo ${uiState.demoSteps.count { it.completed }}/10",
                                                color = ElectricYellow500,
                                                style = MaterialTheme.typography.labelLarge
                                            )
                                        }
                                    }
                                }
                            }
                        },
                        bottomBar = {
                            NavigationBar(
                                containerColor = GridNavy900,
                                contentColor = Color.White
                            ) {
                                val quickItems = listOf(
                                    GridNavDestination.OVERVIEW,
                                    GridNavDestination.UK_NETWORK,
                                    GridNavDestination.STUDIES,
                                    GridNavDestination.OUTAGES,
                                    GridNavDestination.MAINTENANCE
                                )
                                quickItems.forEach { dest ->
                                    val selected = uiState.activeDestination == dest
                                    NavigationBarItem(
                                        selected = selected,
                                        onClick = { viewModel.navigateTo(dest) },
                                        icon = {
                                            Icon(
                                                imageVector = iconForDest(dest),
                                                contentDescription = dest.label
                                            )
                                        },
                                        label = {
                                            Text(
                                                text = dest.label.substringAfter(" "),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                style = MaterialTheme.typography.labelSmall
                                            )
                                        },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = GridNavy950,
                                            selectedTextColor = ElectricYellow500,
                                            indicatorColor = ElectricYellow500,
                                            unselectedIconColor = Color(0xFF94A3B8),
                                            unselectedTextColor = Color(0xFF94A3B8)
                                        ),
                                        modifier = Modifier.testTag("bottom_nav_${dest.name}")
                                    )
                                }
                            }
                        }
                    ) { innerPadding ->
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            BannerArea(uiState.bannerFeedback, uiState.bannerIsError, viewModel::clearBanner)
                            Box(modifier = Modifier.weight(1f)) {
                                GridDestinationContent(
                                    viewModel = viewModel,
                                    uiState = uiState,
                                    persistedAssets = persistedAssets,
                                    outages = outages,
                                    workOrders = workOrders,
                                    alerts = alerts,
                                    reports = reports,
                                    auditLogs = auditLogs
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BannerArea(
    feedback: String?,
    isError: Boolean,
    onDismiss: () -> Unit
) {
    if (feedback != null) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .clickable(onClick = onDismiss)
        ) {
            SafetyBannerNotice(text = feedback, isWarning = isError)
        }
    }
}

@Composable
private fun DeepNavySidebar(
    active: GridNavDestination,
    onSelect: (GridNavDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(GridNavy900)
            .padding(vertical = 12.dp, horizontal = 8.dp)
    ) {
        Text(
            text = "NATIONAL INFRASTRUCTURE\nCONCEPT WORKSPACE",
            style = MaterialTheme.typography.labelSmall,
            color = ElectricYellow500,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            items(GridNavDestination.entries.size) { idx ->
                val dest = GridNavDestination.entries[idx]
                val selected = dest == active
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (selected) ElectricYellow500 else Color.Transparent)
                        .clickable { onSelect(dest) }
                        .padding(horizontal = 10.dp, vertical = 10.dp)
                        .testTag("drawer_nav_${dest.name}"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = iconForDest(dest),
                        contentDescription = dest.label,
                        tint = if (selected) GridNavy950 else Color(0xFFCBD5E1),
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = dest.label,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        color = if (selected) GridNavy950 else Color(0xFFE2E8F0)
                    )
                }
            }
        }
    }
}

@Composable
private fun GridDestinationContent(
    viewModel: GridViewModel,
    uiState: com.example.ui.viewmodel.GridUiState,
    persistedAssets: List<com.example.data.local.AssetEntity>,
    outages: List<com.example.domain.model.OutageRecord>,
    workOrders: List<com.example.domain.model.MaintenanceWorkOrder>,
    alerts: List<com.example.domain.model.GridAlert>,
    reports: List<com.example.domain.model.EngineeringReport>,
    auditLogs: List<com.example.domain.model.AuditLogEntry>
) {
    when (uiState.activeDestination) {
        GridNavDestination.OVERVIEW -> OverviewScreen(
            uiState = uiState,
            outages = outages,
            workOrders = workOrders,
            alerts = alerts,
            reports = reports,
            onNavigate = viewModel::navigateTo,
            onAcknowledgeAlert = viewModel::acknowledgeAlert
        )
        GridNavDestination.UK_NETWORK -> UkNetworkWorkspaceScreen(
            uiState = uiState,
            onSetViewMode = viewModel::setNetworkViewMode,
            onSetVoltageFilter = viewModel::setVoltageFilter,
            onToggleLoadingOverlay = viewModel::toggleLoadingOverlay,
            onToggleOutageOverlay = viewModel::toggleOutageOverlay,
            onSearchChange = viewModel::updateSearchQuery,
            onSelectBus = viewModel::selectBus,
            onSelectBranch = viewModel::selectBranch,
            onSimulateSwitchStatus = viewModel::simulateSwitchStatus,
            onReplayHourChange = viewModel::setReplayHour,
            onToggleReplayPlaying = viewModel::toggleReplayPlaying
        )
        GridNavDestination.SUBSTATIONS -> SubstationsScreen(
            uiState = uiState,
            onInspectBusAndOpenMap = { busId ->
                viewModel.selectBus(busId)
                viewModel.navigateTo(GridNavDestination.UK_NETWORK)
            }
        )
        GridNavDestination.ASSETS -> AssetsScreen(
            uiState = uiState,
            persistedAssets = persistedAssets,
            onAttemptRestrictedExport = viewModel::attemptRestrictedExport
        )
        GridNavDestination.TELEMETRY -> TelemetryScreen(
            uiState = uiState,
            onSetOperatingMode = viewModel::setOperatingMode
        )
        GridNavDestination.STUDIES -> StudiesScreen(
            uiState = uiState,
            onSelectScenario = viewModel::setStudyScenario,
            onSelectMethod = viewModel::setStudyMethod,
            onDemandScaleChange = viewModel::setDemandScale,
            onBessProposalChange = viewModel::setBessDispatchProposal,
            onRunComparison = viewModel::runComparisonStudy
        )
        GridNavDestination.OUTAGES -> OutagesScreen(
            uiState = uiState,
            outages = outages,
            onAdvanceStage = viewModel::advanceOutageStage,
            onCancelOutage = viewModel::cancelOutage
        )
        GridNavDestination.MAINTENANCE -> MaintenanceScreen(
            uiState = uiState,
            workOrders = workOrders,
            onResolveConflict = viewModel::resolveWorkOrderConflict,
            onCreateOfflineDraft = viewModel::createOfflineWorkOrder,
            onSyncOfflineDraft = viewModel::syncOfflineDraft
        )
        GridNavDestination.CONNECTIONS -> ConnectionsScreen(
            uiState = uiState,
            onAdvanceConnectionStage = viewModel::advanceConnectionStage
        )
        GridNavDestination.REINFORCEMENT -> ReinforcementScreen(
            uiState = uiState,
            onRunOptBStudy = {
                viewModel.setStudyScenario(StudyScenario.REINFORCEMENT_OPT_B)
                viewModel.markDemoStepCompleted(7)
                viewModel.navigateTo(GridNavDestination.STUDIES)
            }
        )
        GridNavDestination.REPORTS -> ReportsScreen(
            uiState = uiState,
            reports = reports,
            onGenerateReport = viewModel::generateEngineeringReport,
            onApproveReport = viewModel::approveReport,
            onJumpToDemoStep = viewModel::jumpToDemoStep
        )
        GridNavDestination.ADMINISTRATION -> AdministrationScreen(
            uiState = uiState,
            auditLogs = auditLogs,
            onSelectOrg = viewModel::selectOrganisation,
            onSetBranding = viewModel::setBrandingPreset,
            onToggleDarkControlRoom = viewModel::toggleDarkControlRoom,
            onAttemptRestrictedExport = viewModel::attemptRestrictedExport
        )
    }
}

private fun iconForDest(dest: GridNavDestination): ImageVector = when (dest) {
    GridNavDestination.OVERVIEW -> Icons.Default.Dashboard
    GridNavDestination.UK_NETWORK -> Icons.Default.Hub
    GridNavDestination.SUBSTATIONS -> Icons.Default.ElectricalServices
    GridNavDestination.ASSETS -> Icons.Default.Inventory2
    GridNavDestination.TELEMETRY -> Icons.Default.Sensors
    GridNavDestination.STUDIES -> Icons.Default.Analytics
    GridNavDestination.OUTAGES -> Icons.Default.EventBusy
    GridNavDestination.MAINTENANCE -> Icons.Default.Build
    GridNavDestination.CONNECTIONS -> Icons.Default.Power
    GridNavDestination.REINFORCEMENT -> Icons.Default.TrendingUp
    GridNavDestination.REPORTS -> Icons.Default.Description
    GridNavDestination.ADMINISTRATION -> Icons.Default.AdminPanelSettings
}
