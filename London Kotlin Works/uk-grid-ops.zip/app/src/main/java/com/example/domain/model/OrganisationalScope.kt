package com.example.domain.model

enum class SystemArea(val label: String, val nominalFreqHz: Double) {
    GB("Great Britain (GB Synchronous Area)", 50.00),
    NI("Northern Ireland (All-Island Synchronous Area)", 50.00)
}

enum class UkOrganisation(
    val code: String,
    val displayName: String,
    val shortName: String,
    val systemArea: SystemArea,
    val networkArea: String,
    val assetOwnershipScope: String,
    val operationalResponsibility: String,
    val dataAuthority: String,
    val approvalAuthority: String,
    val canViewRestrictedCoords: Boolean
) {
    NGET(
        code = "NGET",
        displayName = "National Grid Electricity Transmission",
        shortName = "NGET (E&W TO)",
        systemArea = SystemArea.GB,
        networkArea = "England & Wales 400 kV / 275 kV — Pennine Spine",
        assetOwnershipScope = "Owns England & Wales transmission lines, cables & supergrid substations",
        operationalResponsibility = "Transmission asset management & TO outage planning (no GB system dispatch)",
        dataAuthority = "Authoritative owner for NGET asset register, ratings & inspection records",
        approvalAuthority = "Planning approval for NGET assets; requires NESO system coordination",
        canViewRestrictedCoords = true
    ),
    NGED(
        code = "NGED",
        displayName = "National Grid Electricity Distribution",
        shortName = "NGED (DNO)",
        systemArea = SystemArea.GB,
        networkArea = "Pennine South & Midlands 132 kV / 33 kV / 11 kV",
        assetOwnershipScope = "Owns regional distribution substations, 132/33/11 kV feeders & GSP interfaces",
        operationalResponsibility = "DNO network operations, distribution outage scheduling & connections",
        dataAuthority = "Authoritative owner for NGED distribution assets & DNO telemetry",
        approvalAuthority = "Approval authority strictly for NGED distribution assets only",
        canViewRestrictedCoords = true
    ),
    NESO(
        code = "NESO",
        displayName = "National Energy System Operator",
        shortName = "NESO (GB SO)",
        systemArea = SystemArea.GB,
        networkArea = "Great Britain Transmission System Operation",
        assetOwnershipScope = "Zero physical transmission asset ownership (independent system operator)",
        operationalResponsibility = "GB transmission outage coordination, boundary limits & system studies",
        dataAuthority = "Authoritative for GB system schedules, boundary transfers & constraint studies",
        approvalAuthority = "System-wide outage coordination review & boundary security sign-off",
        canViewRestrictedCoords = true
    ),
    SPEN(
        code = "SPEN",
        displayName = "SP Energy Networks",
        shortName = "SPEN (TO/DNO)",
        systemArea = SystemArea.GB,
        networkArea = "Southern Scotland & Cheshire/North Wales Boundary",
        assetOwnershipScope = "Owns SPT transmission & SPM/SPD distribution networks",
        operationalResponsibility = "Boundary interface coordination at Harker–Pennine 400 kV",
        dataAuthority = "Authoritative for SPEN boundary equipment & northern transfer limits",
        approvalAuthority = "Approval authority strictly for SPEN assets",
        canViewRestrictedCoords = true
    ),
    SSEN_T(
        code = "SSEN-T",
        displayName = "SSEN Transmission",
        shortName = "SSEN-T (North Scot.)",
        systemArea = SystemArea.GB,
        networkArea = "North of Scotland 400 kV / 275 kV / 132 kV",
        assetOwnershipScope = "Owns North of Scotland transmission assets (separate TO governance)",
        operationalResponsibility = "TO planning in North of Scotland; read-only boundary visibility here",
        dataAuthority = "Authoritative for SSEN-T assets only",
        approvalAuthority = "Approval authority strictly for SSEN-T assets",
        canViewRestrictedCoords = true
    ),
    SONI(
        code = "SONI",
        displayName = "System Operator for Northern Ireland",
        shortName = "SONI (NI TSO)",
        systemArea = SystemArea.NI,
        networkArea = "Northern Ireland 275 kV / 110 kV (NIE Networks Owner)",
        assetOwnershipScope = "Independent NI TSO (physical NI transmission assets owned by NIE Networks)",
        operationalResponsibility = "NI system operation, Moyle HVDC interface & SONI Grid Code compliance",
        dataAuthority = "Authoritative for NI system telemetry, dispatch & SONI interface",
        approvalAuthority = "Approval authority strictly for SONI / NI operational coordination",
        canViewRestrictedCoords = true
    ),
    PUBLIC_OBSERVER(
        code = "EXT-OBS",
        displayName = "External Observer (Redacted Public View)",
        shortName = "External Observer",
        systemArea = SystemArea.GB,
        networkArea = "Public Summary View (CNI Coordinates Redacted)",
        assetOwnershipScope = "No asset ownership or operational privileges",
        operationalResponsibility = "Read-only public summary only",
        dataAuthority = "No data write authority",
        approvalAuthority = "No approval authority",
        canViewRestrictedCoords = false
    )
}

enum class OperatingMode(val label: String, val badgeText: String, val description: String) {
    SIMULATION(
        label = "Simulation",
        badgeText = "SIM",
        description = "Synthetic Pennine infrastructure, live simulated telemetry & engineering event injection"
    ),
    REPLAY(
        label = "Historical Replay",
        badgeText = "REPLAY",
        description = "Recorded synthetic observations, frequency excursions & workflow audit playback"
    ),
    READ_ONLY_MONITORING(
        label = "Read-Only Monitoring",
        badgeText = "MON (RO)",
        description = "External SCADA/Historian adapter boundary (disconnected in concept demonstrator; no switching)"
    )
}

enum class BrandingPreset(val title: String, val subtitle: String) {
    INDEPENDENT_CONCEPT(
        title = "UK GRID OPS — PENNINE DEMONSTRATOR",
        subtitle = "Independent Concept • Synthetic Infrastructure Data"
    ),
    MULTI_ORG_FEDERATION(
        title = "PENNINE JOINT NETWORK WORKSPACE",
        subtitle = "Configurable Utility Branding • Multi-TO/DNO/SO Boundary View"
    ),
    CONTROL_TRAINING_SIM(
        title = "GB & NI ENGINEERING SIMULATOR",
        subtitle = "Offline Training & Scenario Sandbox • Non-Operational"
    )
}

enum class GovernanceAction(val label: String) {
    APPROVE_NGET_OUTAGE("Approve NGET Transmission Outage"),
    APPROVE_NGED_OUTAGE("Approve NGED Distribution Outage"),
    NESO_COORDINATE_OUTAGE("NESO System Coordination Review"),
    APPROVE_SONI_INTERFACE("Approve SONI NI Boundary Schedule"),
    EDIT_PENNINE_ASSET("Modify Asset Register Record"),
    CREATE_WORK_ORDER("Create / Sync Maintenance Work Order"),
    SIGN_OFF_WORK_ORDER("Engineering Sign-Off on Maintenance Work"),
    APPROVE_ENGINEERING_REPORT("Approve Engineering Study Report"),
    EXPORT_RESTRICTED_INFRASTRUCTURE("Export Restricted CNI Coordinates")
}

data class PermissionDecision(
    val allowed: Boolean,
    val reason: String,
    val requiredAuthority: String
)

object RbacPolicy {
    fun evaluate(
        actorOrg: UkOrganisation,
        action: GovernanceAction,
        targetAssetOwner: UkOrganisation? = null
    ): PermissionDecision {
        if (actorOrg == UkOrganisation.PUBLIC_OBSERVER) {
            return PermissionDecision(
                allowed = false,
                reason = "External Observer account is strictly read-only and cannot perform '${action.label}' or access restricted CNI details.",
                requiredAuthority = "Authorised Engineer in owning/operating organisation"
            )
        }

        return when (action) {
            GovernanceAction.APPROVE_NGET_OUTAGE -> {
                if (actorOrg == UkOrganisation.NGET) {
                    PermissionDecision(true, "NGET holds Transmission Owner planning authority for E&W 400/275 kV assets.", "NGET")
                } else {
                    PermissionDecision(
                        false,
                        "${actorOrg.shortName} cannot approve NGET transmission outages. Ownership and planning authority are segregated.",
                        "National Grid Electricity Transmission (NGET)"
                    )
                }
            }
            GovernanceAction.APPROVE_NGED_OUTAGE -> {
                if (actorOrg == UkOrganisation.NGED) {
                    PermissionDecision(true, "NGED holds DNO planning authority for Pennine 132/33 kV distribution.", "NGED")
                } else {
                    PermissionDecision(
                        false,
                        "${actorOrg.shortName} cannot approve NGED distribution outages across the TO/DNO boundary.",
                        "National Grid Electricity Distribution (NGED)"
                    )
                }
            }
            GovernanceAction.NESO_COORDINATE_OUTAGE -> {
                if (actorOrg == UkOrganisation.NESO) {
                    PermissionDecision(true, "NESO holds GB system coordination review authority.", "NESO")
                } else {
                    PermissionDecision(
                        false,
                        "Only NESO may issue GB system coordination review sign-off; TO/DNOs cannot self-certify system security.",
                        "NESO (GB System Operator)"
                    )
                }
            }
            GovernanceAction.APPROVE_SONI_INTERFACE -> {
                if (actorOrg == UkOrganisation.SONI) {
                    PermissionDecision(true, "SONI holds Northern Ireland TSO operational coordination authority.", "SONI")
                } else {
                    PermissionDecision(
                        false,
                        "${actorOrg.shortName} operates in GB and has zero operational or approval authority in the Northern Ireland SONI system area.",
                        "SONI (Northern Ireland TSO)"
                    )
                }
            }
            GovernanceAction.EDIT_PENNINE_ASSET -> {
                if (targetAssetOwner == null || actorOrg == targetAssetOwner) {
                    PermissionDecision(true, "${actorOrg.shortName} is the authoritative data owner for this asset.", actorOrg.code)
                } else {
                    PermissionDecision(
                        false,
                        "Write blocked: ${actorOrg.shortName} cannot alter assets owned by ${targetAssetOwner.shortName}.",
                        targetAssetOwner.displayName
                    )
                }
            }
            GovernanceAction.CREATE_WORK_ORDER,
            GovernanceAction.SIGN_OFF_WORK_ORDER -> {
                if (targetAssetOwner == null || actorOrg == targetAssetOwner || actorOrg == UkOrganisation.NESO) {
                    if (actorOrg == UkOrganisation.NESO && action == GovernanceAction.SIGN_OFF_WORK_ORDER) {
                        PermissionDecision(false, "NESO does not own physical plant and cannot sign off field maintenance completion.", "Owning TO/DNO")
                    } else {
                        PermissionDecision(true, "Permitted within ${actorOrg.shortName} engineering scope.", actorOrg.code)
                    }
                } else {
                    PermissionDecision(
                        false,
                        "Cross-organisation maintenance mutation blocked: asset belongs to ${targetAssetOwner.shortName}.",
                        targetAssetOwner.displayName
                    )
                }
            }
            GovernanceAction.APPROVE_ENGINEERING_REPORT -> {
                if (actorOrg == UkOrganisation.NGET || actorOrg == UkOrganisation.NESO || actorOrg == UkOrganisation.NGED || actorOrg == UkOrganisation.SONI) {
                    PermissionDecision(true, "Authorised engineering approval by ${actorOrg.shortName}.", actorOrg.code)
                } else {
                    PermissionDecision(false, "${actorOrg.shortName} lacks Pennine report sign-off authority.", "NGET / NGED / NESO / SONI")
                }
            }
            GovernanceAction.EXPORT_RESTRICTED_INFRASTRUCTURE -> {
                if (actorOrg.canViewRestrictedCoords) {
                    PermissionDecision(true, "Authorised internal engineering export (audit logged).", "Internal Engineer")
                } else {
                    PermissionDecision(false, "Restricted CNI geographic coordinates cannot be exported by external accounts.", "Authorised Internal Engineer")
                }
            }
        }
    }
}
