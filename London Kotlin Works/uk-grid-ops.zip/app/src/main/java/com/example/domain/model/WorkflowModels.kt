package com.example.domain.model

enum class OutageStage(val label: String, val order: Int) {
    DRAFT("Draft", 0),
    ASSESSED("Assessed", 1),
    REVIEWED("Reviewed (NESO/Coord)", 2),
    APPROVED_FOR_PLANNING("Approved for Planning", 3),
    SCHEDULED("Scheduled", 4),
    IN_PROGRESS("In Progress", 5),
    COMPLETED("Completed", 6),
    CANCELLED("Cancelled", 7);

    fun nextStage(): OutageStage? = when (this) {
        DRAFT -> ASSESSED
        ASSESSED -> REVIEWED
        REVIEWED -> APPROVED_FOR_PLANNING
        APPROVED_FOR_PLANNING -> SCHEDULED
        SCHEDULED -> IN_PROGRESS
        IN_PROGRESS -> COMPLETED
        COMPLETED, CANCELLED -> null
    }
}

data class OutageRecord(
    val id: String,
    val title: String,
    val affectedEquipmentId: String,
    val affectedEquipmentName: String,
    val ownerOrg: UkOrganisation,
    val coordinatingOrg: UkOrganisation,
    val stage: OutageStage,
    val startWindow: String,
    val endWindow: String,
    val dependencies: String,
    val conflictingWork: String,
    val studyEvidenceSummary: String,
    val approvalHistory: List<String>,
    val switchingSafetyDisclaimer: String =
        "Planning approval only. Switching authorisation, isolation, earthing, and safety permits are excluded."
)

enum class SyncStatus(val label: String) {
    SYNCED("Synced"),
    OFFLINE_DRAFT("Offline Tablet Draft"),
    VERSION_CONFLICT("Version Conflict")
}

enum class WorkOrderStatus(val label: String) {
    OPEN("Open"),
    IN_PROGRESS("In Progress"),
    PENDING_SIGN_OFF("Pending Sign-Off"),
    SIGNED_OFF("Signed Off")
}

data class MaintenanceWorkOrder(
    val id: String,
    val equipmentId: String,
    val equipmentName: String,
    val ownerOrg: UkOrganisation,
    val title: String,
    val defectSummary: String,
    val priorityScore: Int, // 0..100
    val prioritisationRuleExplanation: String,
    val predictiveEvidence: String,
    val sparePartsRequired: String,
    val assignedContractor: String,
    val hasPhotoEvidence: Boolean,
    val completionEvidence: String,
    val status: WorkOrderStatus,
    val version: Int,
    val serverVersion: Int,
    val syncStatus: SyncStatus,
    val updatedBy: String,
    val updatedAtIso: String,
    val conflictingServerNote: String? = null
)

enum class ConnectionStage(val label: String) {
    PRELIMINARY_STUDY("Preliminary Study"),
    INFORMATION_REQUEST("Information Request (Mod App)"),
    OFFER_ISSUED("Formal Offer Issued"),
    OFFER_ACCEPTED("Offer Accepted"),
    DELIVERY_MILESTONES("Delivery Milestones")
}

data class ConnectionApplication(
    val id: String,
    val applicantName: String,
    val connectionType: String,
    val targetSubstationId: String,
    val targetSubstationName: String,
    val ownerOrg: UkOrganisation,
    val nominalKv: Double,
    val importExportMode: String,
    val indicativeCapacityMw: Double,
    val engineeredFindingMw: Double,
    val offeredCapacityMw: Double,
    val contractedCapacityMw: Double,
    val targetEnergisationDate: String,
    val operatingProfile: String,
    val stage: ConnectionStage,
    val constraintsSummary: String,
    val studyVersion: String,
    val processNote: String
)

data class ReinforcementOption(
    val id: String,
    val title: String,
    val scopeDescription: String,
    val targetCorridor: String,
    val ownerOrg: UkOrganisation,
    val capexGbpMillions: Double,
    val annualOpexGbpMillions: Double,
    val committedGbpMillions: Double,
    val actualSpentGbpMillions: Double,
    val priceBaseDate: String,
    val deliveryTimescaleMonths: Int,
    val modelledThermalReliefPct: Double,
    val modelledVoltageGainPu: Double,
    val technicalAssumptions: String,
    val recommended: Boolean = false
)

enum class AlertSeverity(val label: String) {
    INFO("Advisory"),
    WARNING("Amber Warning"),
    CRITICAL("Red Critical")
}

data class GridAlert(
    val id: String,
    val title: String,
    val equipmentId: String,
    val ownerOrg: UkOrganisation,
    val severity: AlertSeverity,
    val severityRationale: String,
    val thresholdSource: String,
    val effectiveDate: String,
    val acknowledged: Boolean,
    val acknowledgedBy: String?,
    val assignedTo: String?,
    val escalationStatus: String,
    val conditionActive: Boolean,
    val chronology: List<String>
)

data class EngineeringReport(
    val id: String,
    val title: String,
    val snapshotId: String,
    val scenarioName: String,
    val authorOrg: UkOrganisation,
    val createdUtc: String,
    val dataSources: String,
    val assumptions: String,
    val solverStatusSummary: String,
    val findings: String,
    val limitations: String,
    val capexGbpMillions: Double,
    val opexGbpMillions: Double,
    val committedGbpMillions: Double,
    val actualGbpMillions: Double,
    val forecastGbpMillions: Double,
    val priceBaseDate: String,
    val approvalStatus: String,
    val approvalHistory: List<String>
)

data class AuditLogEntry(
    val id: String,
    val timestampUtc: String,
    val actorOrg: UkOrganisation,
    val action: String,
    val targetId: String,
    val outcome: String, // ALLOWED / DENIED / CONFLICT
    val details: String
)

data class DemoStepItem(
    val stepNumber: Int,
    val title: String,
    val targetRouteName: String,
    val instruction: String,
    val completed: Boolean
)
