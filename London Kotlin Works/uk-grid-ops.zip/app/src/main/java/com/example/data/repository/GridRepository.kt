package com.example.data.repository

import com.example.data.local.*
import com.example.data.seed.PennineNetworkSeed
import com.example.domain.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class GridRepository(private val dao: GridDao) {

    suspend fun ensureSeeded() {
        if (dao.assetCount() > 0) return

        val assetEntities = PennineNetworkSeed.buses.map { bus ->
            AssetEntity(
                id = bus.id,
                name = bus.name,
                assetCategory = "Substation / Busbar (${bus.voltageLevel.label})",
                ownerOrgCode = bus.ownerOrg.code,
                operatorOrgCode = bus.operatorOrg.code,
                nominalKv = bus.nominalKv,
                ratingSummerMva = 0.0,
                lifecycleStatus = bus.lifecycleStatus.label,
                verificationStatus = bus.verificationStatus.label,
                lastInspectionDate = bus.lastInspectionDate,
                conditionScore = bus.conditionScore,
                version = 1
            )
        } + PennineNetworkSeed.branches.map { br ->
            AssetEntity(
                id = br.id,
                name = br.name,
                assetCategory = br.assetType.label,
                ownerOrgCode = br.ownerOrg.code,
                operatorOrgCode = br.operatorOrg.code,
                nominalKv = br.nominalKv,
                ratingSummerMva = br.ratingSummerMva,
                lifecycleStatus = br.lifecycleStatus.label,
                verificationStatus = br.verificationStatus.label,
                lastInspectionDate = br.lastInspectionDate,
                conditionScore = br.conditionScore,
                version = 1
            )
        }
        dao.insertAssets(assetEntities)

        dao.insertOutages(
            PennineNetworkSeed.outages.map { o ->
                OutageEntity(
                    id = o.id,
                    title = o.title,
                    affectedEquipmentId = o.affectedEquipmentId,
                    affectedEquipmentName = o.affectedEquipmentName,
                    ownerOrgCode = o.ownerOrg.code,
                    coordinatingOrgCode = o.coordinatingOrg.code,
                    stageName = o.stage.name,
                    startWindow = o.startWindow,
                    endWindow = o.endWindow,
                    dependencies = o.dependencies,
                    conflictingWork = o.conflictingWork,
                    studyEvidenceSummary = o.studyEvidenceSummary,
                    approvalHistoryJoined = o.approvalHistory.joinToString("\n")
                )
            }
        )

        dao.insertWorkOrders(
            PennineNetworkSeed.workOrders.map { w ->
                WorkOrderEntity(
                    id = w.id,
                    equipmentId = w.equipmentId,
                    equipmentName = w.equipmentName,
                    ownerOrgCode = w.ownerOrg.code,
                    title = w.title,
                    defectSummary = w.defectSummary,
                    priorityScore = w.priorityScore,
                    prioritisationRuleExplanation = w.prioritisationRuleExplanation,
                    predictiveEvidence = w.predictiveEvidence,
                    sparePartsRequired = w.sparePartsRequired,
                    assignedContractor = w.assignedContractor,
                    hasPhotoEvidence = w.hasPhotoEvidence,
                    completionEvidence = w.completionEvidence,
                    statusName = w.status.name,
                    version = w.version,
                    serverVersion = w.serverVersion,
                    syncStatusName = w.syncStatus.name,
                    updatedBy = w.updatedBy,
                    updatedAtIso = w.updatedAtIso,
                    conflictingServerNote = w.conflictingServerNote
                )
            }
        )

        dao.insertAlerts(
            PennineNetworkSeed.initialAlerts.map { a ->
                AlertEntity(
                    id = a.id,
                    title = a.title,
                    equipmentId = a.equipmentId,
                    ownerOrgCode = a.ownerOrg.code,
                    severityName = a.severity.name,
                    severityRationale = a.severityRationale,
                    thresholdSource = a.thresholdSource,
                    effectiveDate = a.effectiveDate,
                    acknowledged = a.acknowledged,
                    acknowledgedBy = a.acknowledgedBy,
                    assignedTo = a.assignedTo,
                    escalationStatus = a.escalationStatus,
                    conditionActive = a.conditionActive,
                    chronologyJoined = a.chronology.joinToString("\n")
                )
            }
        )

        dao.insertReports(
            PennineNetworkSeed.initialReports.map { r ->
                ReportEntity(
                    id = r.id,
                    title = r.title,
                    snapshotId = r.snapshotId,
                    scenarioName = r.scenarioName,
                    authorOrgCode = r.authorOrg.code,
                    createdUtc = r.createdUtc,
                    dataSources = r.dataSources,
                    assumptions = r.assumptions,
                    solverStatusSummary = r.solverStatusSummary,
                    findings = r.findings,
                    limitations = r.limitations,
                    capexGbpMillions = r.capexGbpMillions,
                    opexGbpMillions = r.opexGbpMillions,
                    committedGbpMillions = r.committedGbpMillions,
                    actualGbpMillions = r.actualGbpMillions,
                    forecastGbpMillions = r.forecastGbpMillions,
                    priceBaseDate = r.priceBaseDate,
                    approvalStatus = r.approvalStatus,
                    approvalHistoryJoined = r.approvalHistory.joinToString("\n")
                )
            }
        )

        dao.insertAuditLog(
            AuditLogEntity(
                id = "AUD-0001",
                timestampUtc = "2026-11-24T08:00:00Z",
                actorOrgCode = UkOrganisation.NGET.code,
                action = "LOAD_SNAPSHOT",
                targetId = PennineNetworkSeed.snapshot.snapshotId,
                outcome = "ALLOWED",
                details = "Initialised Pennine synthetic model snapshot in Room SQLite."
            )
        )
    }

    val assets: Flow<List<AssetEntity>> = dao.observeAssets()

    val outages: Flow<List<OutageRecord>> = dao.observeOutages().map { list ->
        list.map { e ->
            OutageRecord(
                id = e.id,
                title = e.title,
                affectedEquipmentId = e.affectedEquipmentId,
                affectedEquipmentName = e.affectedEquipmentName,
                ownerOrg = orgFromCode(e.ownerOrgCode),
                coordinatingOrg = orgFromCode(e.coordinatingOrgCode),
                stage = OutageStage.valueOf(e.stageName),
                startWindow = e.startWindow,
                endWindow = e.endWindow,
                dependencies = e.dependencies,
                conflictingWork = e.conflictingWork,
                studyEvidenceSummary = e.studyEvidenceSummary,
                approvalHistory = e.approvalHistoryJoined.split("\n").filter { it.isNotBlank() }
            )
        }
    }

    val workOrders: Flow<List<MaintenanceWorkOrder>> = dao.observeWorkOrders().map { list ->
        list.map { e ->
            MaintenanceWorkOrder(
                id = e.id,
                equipmentId = e.equipmentId,
                equipmentName = e.equipmentName,
                ownerOrg = orgFromCode(e.ownerOrgCode),
                title = e.title,
                defectSummary = e.defectSummary,
                priorityScore = e.priorityScore,
                prioritisationRuleExplanation = e.prioritisationRuleExplanation,
                predictiveEvidence = e.predictiveEvidence,
                sparePartsRequired = e.sparePartsRequired,
                assignedContractor = e.assignedContractor,
                hasPhotoEvidence = e.hasPhotoEvidence,
                completionEvidence = e.completionEvidence,
                status = WorkOrderStatus.valueOf(e.statusName),
                version = e.version,
                serverVersion = e.serverVersion,
                syncStatus = SyncStatus.valueOf(e.syncStatusName),
                updatedBy = e.updatedBy,
                updatedAtIso = e.updatedAtIso,
                conflictingServerNote = e.conflictingServerNote
            )
        }
    }

    val alerts: Flow<List<GridAlert>> = dao.observeAlerts().map { list ->
        list.map { e ->
            GridAlert(
                id = e.id,
                title = e.title,
                equipmentId = e.equipmentId,
                ownerOrg = orgFromCode(e.ownerOrgCode),
                severity = AlertSeverity.valueOf(e.severityName),
                severityRationale = e.severityRationale,
                thresholdSource = e.thresholdSource,
                effectiveDate = e.effectiveDate,
                acknowledged = e.acknowledged,
                acknowledgedBy = e.acknowledgedBy,
                assignedTo = e.assignedTo,
                escalationStatus = e.escalationStatus,
                conditionActive = e.conditionActive,
                chronology = e.chronologyJoined.split("\n").filter { it.isNotBlank() }
            )
        }
    }

    val reports: Flow<List<EngineeringReport>> = dao.observeReports().map { list ->
        list.map { e ->
            EngineeringReport(
                id = e.id,
                title = e.title,
                snapshotId = e.snapshotId,
                scenarioName = e.scenarioName,
                authorOrg = orgFromCode(e.authorOrgCode),
                createdUtc = e.createdUtc,
                dataSources = e.dataSources,
                assumptions = e.assumptions,
                solverStatusSummary = e.solverStatusSummary,
                findings = e.findings,
                limitations = e.limitations,
                capexGbpMillions = e.capexGbpMillions,
                opexGbpMillions = e.opexGbpMillions,
                committedGbpMillions = e.committedGbpMillions,
                actualGbpMillions = e.actualGbpMillions,
                forecastGbpMillions = e.forecastGbpMillions,
                priceBaseDate = e.priceBaseDate,
                approvalStatus = e.approvalStatus,
                approvalHistory = e.approvalHistoryJoined.split("\n").filter { it.isNotBlank() }
            )
        }
    }

    val auditLogs: Flow<List<AuditLogEntry>> = dao.observeAuditLogs().map { list ->
        list.map { e ->
            AuditLogEntry(
                id = e.id,
                timestampUtc = e.timestampUtc,
                actorOrg = orgFromCode(e.actorOrgCode),
                action = e.action,
                targetId = e.targetId,
                outcome = e.outcome,
                details = e.details
            )
        }
    }

    suspend fun saveOutage(record: OutageRecord) {
        dao.upsertOutage(
            OutageEntity(
                id = record.id,
                title = record.title,
                affectedEquipmentId = record.affectedEquipmentId,
                affectedEquipmentName = record.affectedEquipmentName,
                ownerOrgCode = record.ownerOrg.code,
                coordinatingOrgCode = record.coordinatingOrg.code,
                stageName = record.stage.name,
                startWindow = record.startWindow,
                endWindow = record.endWindow,
                dependencies = record.dependencies,
                conflictingWork = record.conflictingWork,
                studyEvidenceSummary = record.studyEvidenceSummary,
                approvalHistoryJoined = record.approvalHistory.joinToString("\n")
            )
        )
    }

    suspend fun saveWorkOrder(wo: MaintenanceWorkOrder) {
        dao.upsertWorkOrder(
            WorkOrderEntity(
                id = wo.id,
                equipmentId = wo.equipmentId,
                equipmentName = wo.equipmentName,
                ownerOrgCode = wo.ownerOrg.code,
                title = wo.title,
                defectSummary = wo.defectSummary,
                priorityScore = wo.priorityScore,
                prioritisationRuleExplanation = wo.prioritisationRuleExplanation,
                predictiveEvidence = wo.predictiveEvidence,
                sparePartsRequired = wo.sparePartsRequired,
                assignedContractor = wo.assignedContractor,
                hasPhotoEvidence = wo.hasPhotoEvidence,
                completionEvidence = wo.completionEvidence,
                statusName = wo.status.name,
                version = wo.version,
                serverVersion = wo.serverVersion,
                syncStatusName = wo.syncStatus.name,
                updatedBy = wo.updatedBy,
                updatedAtIso = wo.updatedAtIso,
                conflictingServerNote = wo.conflictingServerNote
            )
        )
    }

    suspend fun saveAlert(alert: GridAlert) {
        dao.upsertAlert(
            AlertEntity(
                id = alert.id,
                title = alert.title,
                equipmentId = alert.equipmentId,
                ownerOrgCode = alert.ownerOrg.code,
                severityName = alert.severity.name,
                severityRationale = alert.severityRationale,
                thresholdSource = alert.thresholdSource,
                effectiveDate = alert.effectiveDate,
                acknowledged = alert.acknowledged,
                acknowledgedBy = alert.acknowledgedBy,
                assignedTo = alert.assignedTo,
                escalationStatus = alert.escalationStatus,
                conditionActive = alert.conditionActive,
                chronologyJoined = alert.chronology.joinToString("\n")
            )
        )
    }

    suspend fun saveReport(report: EngineeringReport) {
        dao.upsertReport(
            ReportEntity(
                id = report.id,
                title = report.title,
                snapshotId = report.snapshotId,
                scenarioName = report.scenarioName,
                authorOrgCode = report.authorOrg.code,
                createdUtc = report.createdUtc,
                dataSources = report.dataSources,
                assumptions = report.assumptions,
                solverStatusSummary = report.solverStatusSummary,
                findings = report.findings,
                limitations = report.limitations,
                capexGbpMillions = report.capexGbpMillions,
                opexGbpMillions = report.opexGbpMillions,
                committedGbpMillions = report.committedGbpMillions,
                actualGbpMillions = report.actualGbpMillions,
                forecastGbpMillions = report.forecastGbpMillions,
                priceBaseDate = report.priceBaseDate,
                approvalStatus = report.approvalStatus,
                approvalHistoryJoined = report.approvalHistory.joinToString("\n")
            )
        )
    }

    suspend fun updateAssetVerification(asset: AssetEntity) {
        dao.updateAsset(asset)
    }

    suspend fun appendAuditLog(entry: AuditLogEntry) {
        dao.insertAuditLog(
            AuditLogEntity(
                id = entry.id,
                timestampUtc = entry.timestampUtc,
                actorOrgCode = entry.actorOrg.code,
                action = entry.action,
                targetId = entry.targetId,
                outcome = entry.outcome,
                details = entry.details
            )
        )
    }

    private fun orgFromCode(code: String): UkOrganisation =
        UkOrganisation.entries.firstOrNull { it.code == code } ?: UkOrganisation.NGET
}
