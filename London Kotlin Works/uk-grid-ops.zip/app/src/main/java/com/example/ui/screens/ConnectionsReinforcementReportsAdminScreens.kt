package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.GridUiState

@Composable
fun ConnectionsScreen(
    uiState: GridUiState,
    onAdvanceConnectionStage: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeaderCard(
                title = "Customer Connections & Grid Queue",
                subtitle = "Separates Indicative Capacity, Engineering Findings, Formal Offers & Contracted Capacity",
                rightBadge = "${uiState.connections.size} Applications"
            )
        }
        items(uiState.connections.size) { idx ->
            val c = uiState.connections[idx]
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.testTag("connection_card_${c.id}")
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${c.id}: ${c.applicantName}", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        StatusPill(c.stage.label, StatusTone.NEUTRAL)
                    }
                    Text(
                        text = "${c.connectionType} at ${c.targetSubstationName} (${c.nominalKv.toInt()} kV • ${c.ownerOrg.code})\nMode: ${c.importExportMode} • Target: ${c.targetEnergisationDate}\nProfile: ${c.operatingProfile}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StatusPill("Indicative: ${c.indicativeCapacityMw.toInt()} MW", StatusTone.NEUTRAL)
                        StatusPill("Engineered: ${c.engineeredFindingMw.toInt()} MW", StatusTone.AMBER)
                        StatusPill("Contracted: ${c.contractedCapacityMw.toInt()} MW", if (c.contractedCapacityMw > 0) StatusTone.HEALTHY else StatusTone.UNKNOWN)
                    }
                    Text(
                        text = "Constraints (${c.studyVersion}): ${c.constraintsSummary}\nProcess Note: ${c.processNote}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (c.stage != ConnectionStage.DELIVERY_MILESTONES) {
                        Button(
                            onClick = { onAdvanceConnectionStage(c.id) },
                            modifier = Modifier.testTag("advance_conn_${c.id}")
                        ) {
                            Text("Advance Connection Stage")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReinforcementScreen(
    uiState: GridUiState,
    onRunOptBStudy: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeaderCard(
                title = "Reinforcement Option Comparison",
                subtitle = "Costed in GBP (2026 Q4 Price Base) — separating CAPEX, OPEX, Committed & Actual spend",
                rightBadge = "${uiState.reinforcementOptions.size} Options"
            )
        }
        items(uiState.reinforcementOptions.size) { idx ->
            val opt = uiState.reinforcementOptions[idx]
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(if (opt.recommended) 2.dp else 1.dp, if (opt.recommended) StatusHealthy else MaterialTheme.colorScheme.outline),
                modifier = Modifier.testTag("reinforcement_${opt.id}")
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(opt.title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        if (opt.recommended) StatusPill("RECOMMENDED", StatusTone.HEALTHY)
                    }
                    Text(
                        text = "${opt.scopeDescription}\nCorridor: ${opt.targetCorridor} • Owner: ${opt.ownerOrg.shortName} • Delivery: ${opt.deliveryTimescaleMonths} months\nModelled Effect: -${opt.modelledThermalReliefPct}% Peak Loading | +${opt.modelledVoltageGainPu} pu Voltage\nFinancials (${opt.priceBaseDate}):\n  • CAPEX: £${opt.capexGbpMillions}M | Annual OPEX: £${opt.annualOpexGbpMillions}M/yr\n  • Committed: £${opt.committedGbpMillions}M | Actual Spent: £${opt.actualSpentGbpMillions}M\nAssumptions: ${opt.technicalAssumptions}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (opt.id == "REINF-OPT-B") {
                        Button(
                            onClick = onRunOptBStudy,
                            modifier = Modifier.testTag("model_opt_b_btn")
                        ) {
                            Text("Model Option B in Power Flow Study")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReportsScreen(
    uiState: GridUiState,
    reports: List<EngineeringReport>,
    onGenerateReport: () -> Unit,
    onApproveReport: (EngineeringReport) -> Unit,
    onJumpToDemoStep: (DemoStepItem) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeaderCard(
                title = "Engineering Reports & Pennine Demonstrator",
                subtitle = "Auditable study snapshots, GBP financial breakdown & 10-step walkthrough",
                rightBadge = "${reports.size} Reports"
            )
        }
        item {
            Button(
                onClick = onGenerateReport,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("generate_report_btn")
            ) {
                Text("Generate Engineering Report from Active Study (${uiState.currentStudyResult.scenario.label})")
            }
        }

        items(reports.size) { idx ->
            val r = reports[idx]
            val approved = r.approvalStatus.startsWith("APPROVED")
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.testTag("report_card_${r.id}")
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${r.id}: ${r.title}", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        StatusPill(if (approved) "APPROVED" else "DRAFT", if (approved) StatusTone.HEALTHY else StatusTone.AMBER)
                    }
                    Text(
                        text = "Snapshot: ${r.snapshotId} • Scenario: ${r.scenarioName}\nAuthor: ${r.authorOrg.shortName} • Created: ${r.createdUtc}\nData Sources: ${r.dataSources}\nAssumptions: ${r.assumptions}\nSolver Status: ${r.solverStatusSummary}\nFindings: ${r.findings}\nLimitations: ${r.limitations}\nFinancials (${r.priceBaseDate}): CAPEX £${r.capexGbpMillions}M | OPEX £${r.opexGbpMillions}M/yr | Committed £${r.committedGbpMillions}M | Actual £${r.actualGbpMillions}M | Forecast £${r.forecastGbpMillions}M",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text("Approval History:", style = MaterialTheme.typography.labelLarge)
                    r.approvalHistory.forEach { h ->
                        Text("• $h", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (!approved) {
                        Button(
                            onClick = { onApproveReport(r) },
                            modifier = Modifier.testTag("approve_report_${r.id}")
                        ) {
                            Text("Sign Off & Approve Report")
                        }
                    }
                }
            }
        }

        // 10-Step Pennine Network Engineering Demonstrator Checklist
        item {
            Text(
                text = "Pennine Network Engineering Demonstrator (10-Step Guide)",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
        items(uiState.demoSteps.size) { idx ->
            val step = uiState.demoSteps[idx]
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier
                    .testTag("demo_step_${step.stepNumber}")
                    .clickable { onJumpToDemoStep(step) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (step.completed) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                        contentDescription = if (step.completed) "Completed" else "Pending",
                        tint = if (step.completed) StatusHealthy else GridSlate500
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${step.stepNumber}. ${step.title} [${step.targetRouteName}]",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = step.instruction,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AdministrationScreen(
    uiState: GridUiState,
    auditLogs: List<AuditLogEntry>,
    onSelectOrg: (UkOrganisation) -> Unit,
    onSetBranding: (BrandingPreset) -> Unit,
    onToggleDarkControlRoom: () -> Unit,
    onAttemptRestrictedExport: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeaderCard(
                title = "Administration, UK Governance & Security Audit",
                subtitle = "Test organisational scope boundaries, configurable branding & unauthorised access controls",
                rightBadge = uiState.activeOrg.code
            )
        }

        // Organisation & RBAC Switcher
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Active Organisation / Role Context", style = MaterialTheme.typography.titleSmall)
                    Text(
                        text = "Switch organisations to verify strict segregation between NGET (E&W TO), NGED (DNO), NESO (GB SO), SPEN, SSEN-T, SONI (Northern Ireland), and External Observer.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    UkOrganisation.entries.forEach { org ->
                        val selected = uiState.activeOrg == org
                        OutlinedCard(
                            onClick = { onSelectOrg(org) },
                            border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline),
                            colors = CardDefaults.cardColors(containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("org_select_${org.code}")
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("${org.displayName} (${org.code})", style = MaterialTheme.typography.labelLarge)
                                    StatusPill(org.systemArea.name, if (org.systemArea == SystemArea.NI) StatusTone.AMBER else StatusTone.NEUTRAL)
                                }
                                Text(
                                    text = "Area: ${org.networkArea}\nApproval: ${org.approvalAuthority}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Configurable Branding & Control-Room Theme
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Configurable Branding & Display Theme", style = MaterialTheme.typography.titleSmall)
                    BrandingPreset.entries.forEach { preset ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSetBranding(preset) }
                        ) {
                            RadioButton(selected = uiState.brandingPreset == preset, onClick = { onSetBranding(preset) })
                            Column {
                                Text(preset.title, style = MaterialTheme.typography.labelLarge)
                                Text(preset.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Dark Control-Room Display Palette", style = MaterialTheme.typography.labelLarge)
                        Switch(
                            checked = uiState.darkControlRoom,
                            onCheckedChange = { onToggleDarkControlRoom() },
                            modifier = Modifier.testTag("dark_control_room_switch")
                        )
                    }
                    OutlinedButton(
                        onClick = onAttemptRestrictedExport,
                        modifier = Modifier.testTag("admin_test_export_btn")
                    ) {
                        Text("Test Restricted CNI Export Permission")
                    }
                }
            }
        }

        // Security & Governance Audit Log
        item {
            Text("Immutable Governance & Security Audit Log (${auditLogs.size})", style = MaterialTheme.typography.titleMedium)
        }
        items(auditLogs.size) { idx ->
            val log = auditLogs[idx]
            val tone = when (log.outcome) {
                "DENIED" -> StatusTone.CRITICAL
                "CONFLICT" -> StatusTone.AMBER
                else -> StatusTone.HEALTHY
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${log.actorOrg.code} • ${log.action}", style = MaterialTheme.typography.labelLarge)
                        StatusPill(log.outcome, tone)
                    }
                    Text(
                        text = "Target: ${log.targetId} • ${log.timestampUtc}\n${log.details}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
