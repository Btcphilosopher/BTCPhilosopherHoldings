package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.engine.PowerFlowResult
import com.example.domain.model.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.NetworkViewMode
import kotlin.math.hypot

@Composable
fun InteractiveNetworkCanvas(
    viewMode: NetworkViewMode,
    buses: List<BusNode>,
    branches: List<BranchAsset>,
    studyResult: PowerFlowResult,
    voltageFilterKv: Double?,
    showLoadingOverlay: Boolean,
    showOutageOverlay: Boolean,
    selectedBusId: String?,
    selectedBranchId: String?,
    activeOrg: UkOrganisation,
    onSelectBus: (String) -> Unit,
    onSelectBranch: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var zoom by remember { mutableFloatStateOf(1f) }
    val textMeasurer = rememberTextMeasurer()

    val filteredBuses = remember(buses, voltageFilterKv) {
        if (voltageFilterKv == null) buses else buses.filter { it.nominalKv == voltageFilterKv }
    }
    val busIds = remember(filteredBuses) { filteredBuses.map { it.id }.toSet() }
    val filteredBranches = remember(branches, busIds, voltageFilterKv) {
        if (voltageFilterKv == null) branches
        else branches.filter { it.fromBusId in busIds || it.toBusId in busIds }
    }

    val busResMap = remember(studyResult) { studyResult.busResults.associateBy { it.busId } }
    val branchResMap = remember(studyResult) { studyResult.branchResults.associateBy { it.branchId } }

    // Cache rendered screen positions for tap hit-testing
    val busPositions = remember { mutableStateMapOf<String, Offset>() }
    val branchMidpoints = remember { mutableStateMapOf<String, Offset>() }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 300.dp, max = 420.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFDFEFF)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("network_interactive_canvas")
                    .pointerInput(filteredBuses, filteredBranches, viewMode, zoom) {
                        detectTapGestures { tap ->
                            // Check closest bus within 34px first
                            val hitBus = busPositions.entries.minByOrNull {
                                hypot((it.value.x - tap.x).toDouble(), (it.value.y - tap.y).toDouble())
                            }
                            if (hitBus != null && hypot((hitBus.value.x - tap.x).toDouble(), (hitBus.value.y - tap.y).toDouble()) < 40.0) {
                                onSelectBus(hitBus.key)
                                return@detectTapGestures
                            }
                            val hitBranch = branchMidpoints.entries.minByOrNull {
                                hypot((it.value.x - tap.x).toDouble(), (it.value.y - tap.y).toDouble())
                            }
                            if (hitBranch != null && hypot((hitBranch.value.x - tap.x).toDouble(), (hitBranch.value.y - tap.y).toDouble()) < 42.0) {
                                onSelectBranch(hitBranch.key)
                            }
                        }
                    }
            ) {
                busPositions.clear()
                branchMidpoints.clear()
                val w = size.width
                val h = size.height

                // Draw engineering grid background
                val gridStep = 36f * zoom
                var gx = 0f
                while (gx < w) {
                    drawLine(Color(0xFFE9EFF6), Offset(gx, 0f), Offset(gx, h), strokeWidth = 1f)
                    gx += gridStep
                }
                var gy = 0f
                while (gy < h) {
                    drawLine(Color(0xFFE9EFF6), Offset(0f, gy), Offset(w, gy), strokeWidth = 1f)
                    gy += gridStep
                }

                if (viewMode == NetworkViewMode.GEOGRAPHIC_MAP) {
                    drawUkOutline(w, h)
                }

                fun projectBus(bus: BusNode): Offset {
                    return if (viewMode == NetworkViewMode.GEOGRAPHIC_MAP) {
                        // Project Pennine & NI region (lon -6.4..-0.7, lat 53.3..56.1)
                        val minLon = -6.5
                        val maxLon = -0.6
                        val minLat = 53.25
                        val maxLat = 56.15
                        val nx = ((bus.coords.longitude - minLon) / (maxLon - minLon)).toFloat().coerceIn(0.06f, 0.94f)
                        val ny = (1f - ((bus.coords.latitude - minLat) / (maxLat - minLat)).toFloat()).coerceIn(0.08f, 0.92f)
                        val cx = (nx - 0.5f) * zoom + 0.5f
                        val cy = (ny - 0.5f) * zoom + 0.5f
                        Offset(cx * w, cy * h)
                    } else {
                        val cx = (bus.coords.schematicX - 0.5f) * zoom + 0.5f
                        val cy = (bus.coords.schematicY - 0.5f) * zoom + 0.5f
                        Offset(cx * w, cy * h)
                    }
                }

                val allBusLookup = buses.associateBy { it.id }

                // Draw branches first
                for (br in filteredBranches) {
                    val bFrom = allBusLookup[br.fromBusId] ?: continue
                    val bTo = allBusLookup[br.toBusId] ?: continue
                    val p1 = projectBus(bFrom)
                    val p2 = projectBus(bTo)
                    val mid = Offset((p1.x + p2.x) / 2f, (p1.y + p2.y) / 2f)
                    branchMidpoints[br.id] = mid

                    val brRes = branchResMap[br.id]
                    val loadingPct = brRes?.loadingPct ?: 0.0
                    val isSelected = br.id == selectedBranchId
                    val isOutaged = br.lifecycleStatus != LifecycleStatus.IN_SERVICE || br.breakerStatus != SwitchStatus.CLOSED

                    val baseColor = when {
                        br.ownerOrg == UkOrganisation.SONI -> VoltageSoniNi
                        br.nominalKv >= 380.0 -> Voltage400Kv
                        br.nominalKv >= 250.0 -> Voltage275Kv
                        br.nominalKv >= 100.0 -> Voltage132Kv
                        else -> Voltage33Kv
                    }

                    val lineColor = when {
                        isOutaged && showOutageOverlay -> StatusCritical
                        showLoadingOverlay && loadingPct > 90.0 -> StatusCritical
                        showLoadingOverlay && loadingPct > 75.0 -> StatusAmber
                        else -> baseColor
                    }

                    val strokeW = if (isSelected) 7f else if (br.nominalKv >= 380.0) 4.5f else 3f
                    val dashEffect = if (isOutaged || br.isBoundaryLink) {
                        PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                    } else null

                    drawLine(
                        color = lineColor,
                        start = p1,
                        end = p2,
                        strokeWidth = strokeW,
                        pathEffect = dashEffect
                    )

                    // Single-line diagram equipment symbols
                    if (viewMode == NetworkViewMode.SINGLE_LINE_DIAGRAM) {
                        if (br.assetType == AssetType.TRANSFORMER) {
                            // Two overlapping transformer circles
                            val dx = (p2.x - p1.x)
                            val dy = (p2.y - p1.y)
                            val len = hypot(dx.toDouble(), dy.toDouble()).toFloat().coerceAtLeast(1f)
                            val ux = dx / len * 6f
                            val uy = dy / len * 6f
                            drawCircle(Color.White, radius = 9f, center = Offset(mid.x - ux, mid.y - uy))
                            drawCircle(lineColor, radius = 9f, center = Offset(mid.x - ux, mid.y - uy), style = Stroke(2.2f))
                            drawCircle(Color.White, radius = 9f, center = Offset(mid.x + ux, mid.y + uy))
                            drawCircle(lineColor, radius = 9f, center = Offset(mid.x + ux, mid.y + uy), style = Stroke(2.2f))
                        } else {
                            // Circuit breaker square indicator near midpoint
                            val sq = 11f
                            val brkColor = when (br.breakerStatus) {
                                SwitchStatus.CLOSED -> lineColor
                                SwitchStatus.OPEN -> Color.White
                                SwitchStatus.UNKNOWN -> StatusUnknown
                            }
                            drawRect(
                                color = brkColor,
                                topLeft = Offset(mid.x - sq / 2f, mid.y - sq / 2f),
                                size = Size(sq, sq)
                            )
                            drawRect(
                                color = GridNavy900,
                                topLeft = Offset(mid.x - sq / 2f, mid.y - sq / 2f),
                                size = Size(sq, sq),
                                style = Stroke(1.8f)
                            )
                        }

                        if (showLoadingOverlay && brRes != null && brRes.inService) {
                            drawCanvasLabel(
                                textMeasurer,
                                "${brRes.pFromMw.toInt()}MW (${loadingPct.toInt()}%)",
                                Offset(mid.x + 8f, mid.y - 14f),
                                if (loadingPct > 85.0) StatusCritical else GridNavy800
                            )
                        } else if (br.breakerStatus == SwitchStatus.UNKNOWN) {
                            drawCanvasLabel(textMeasurer, "STATE UNKNOWN?", Offset(mid.x + 8f, mid.y - 14f), StatusUnknown)
                        } else if (isOutaged) {
                            drawCanvasLabel(textMeasurer, "OPEN / OUTAGE", Offset(mid.x + 8f, mid.y - 14f), StatusCritical)
                        }
                    }
                }

                // Draw substations / buses
                for (bus in filteredBuses) {
                    val pos = projectBus(bus)
                    busPositions[bus.id] = pos
                    val res = busResMap[bus.id]
                    val energised = res?.energised ?: (bus.systemArea == SystemArea.NI)
                    val isSelected = bus.id == selectedBusId

                    val nodeColor = when {
                        !energised -> StatusCritical
                        bus.systemArea == SystemArea.NI -> VoltageSoniNi
                        bus.nominalKv >= 380.0 -> Voltage400Kv
                        bus.nominalKv >= 250.0 -> Voltage275Kv
                        bus.nominalKv >= 100.0 -> Voltage132Kv
                        else -> Voltage33Kv
                    }

                    if (isSelected) {
                        drawCircle(ElectricYellow500.copy(alpha = 0.38f), radius = 20f, center = pos)
                        drawCircle(ElectricYellow500, radius = 16f, center = pos, style = Stroke(3f))
                    }

                    if (viewMode == NetworkViewMode.SINGLE_LINE_DIAGRAM) {
                        // Crisp busbar rectangle
                        drawRect(
                            color = nodeColor,
                            topLeft = Offset(pos.x - 18f, pos.y - 4f),
                            size = Size(36f, 8f)
                        )
                        if (bus.isGeneratorBus) {
                            drawCircle(Color.White, radius = 7f, center = Offset(pos.x - 24f, pos.y))
                            drawCircle(StatusHealthy, radius = 7f, center = Offset(pos.x - 24f, pos.y), style = Stroke(2f))
                        }
                    } else {
                        drawCircle(Color.White, radius = 9f, center = pos)
                        drawCircle(nodeColor, radius = 9f, center = pos, style = Stroke(3.5f))
                    }

                    val shortTag = bus.name.substringBefore(" 400").substringBefore(" 275").substringBefore(" 132").substringBefore(" 33")
                    val puText = if (res != null && bus.systemArea == SystemArea.GB) {
                        if (res.energised) " ${"%.3f".format(res.voltagePu)}pu" else " ISLAND"
                    } else if (bus.systemArea == SystemArea.NI) " (SONI)" else ""
                    drawCanvasLabel(
                        textMeasurer,
                        "$shortTag$puText",
                        Offset(pos.x - 28f, pos.y + 10f),
                        if (!energised) StatusCritical else GridNavy900
                    )
                }
            }

            // Top-left mode & CRS badge
            Surface(
                color = GridNavy900.copy(alpha = 0.90f),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(10.dp)
            ) {
                val crsMsg = if (viewMode == NetworkViewMode.GEOGRAPHIC_MAP) {
                    if (activeOrg.canViewRestrictedCoords) "GEOGRAPHIC (EPSG:4326 / OSGB36)" else "GEOGRAPHIC (CNI COORDS REDACTED)"
                } else {
                    "SINGLE-LINE SCHEMATIC (TOPOLOGY INDEPENDENT OF MAP)"
                }
                Text(
                    text = crsMsg,
                    style = MaterialTheme.typography.labelSmall,
                    color = ElectricYellow500,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                )
            }

            // Zoom controls bottom-right
            Row(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.White.copy(alpha = 0.92f))
                    .padding(2.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                IconButton(
                    onClick = { zoom = (zoom - 0.15f).coerceAtLeast(0.75f) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(Icons.Default.Remove, contentDescription = "Zoom out", tint = GridNavy900)
                }
                IconButton(
                    onClick = { zoom = 1f },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Reset zoom", tint = GridNavy900)
                }
                IconButton(
                    onClick = { zoom = (zoom + 0.15f).coerceAtMost(1.8f) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Zoom in", tint = GridNavy900)
                }
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawUkOutline(w: Float, h: Float) {
    // Stylized Northern England / Scotland & Northern Ireland geographical boundary silhouettes
    val gbPath = Path().apply {
        moveTo(w * 0.44f, h * 0.04f)
        lineTo(w * 0.68f, h * 0.05f)
        lineTo(w * 0.84f, h * 0.42f)
        lineTo(w * 0.92f, h * 0.88f)
        lineTo(w * 0.56f, h * 0.95f)
        lineTo(w * 0.46f, h * 0.68f)
        lineTo(w * 0.36f, h * 0.44f)
        lineTo(w * 0.40f, h * 0.18f)
        close()
    }
    drawPath(gbPath, color = Color(0xFFEFF4FA))
    drawPath(gbPath, color = Color(0xFFCBD5E1), style = Stroke(2f))

    val niPath = Path().apply {
        moveTo(w * 0.04f, h * 0.24f)
        lineTo(w * 0.22f, h * 0.21f)
        lineTo(w * 0.26f, h * 0.48f)
        lineTo(w * 0.10f, h * 0.54f)
        lineTo(w * 0.03f, h * 0.40f)
        close()
    }
    drawPath(niPath, color = Color(0xFFE6F4F1))
    drawPath(niPath, color = VoltageSoniNi.copy(alpha = 0.5f), style = Stroke(2f))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawCanvasLabel(
    measurer: TextMeasurer,
    text: String,
    topLeft: Offset,
    color: Color
) {
    val result = measurer.measure(
        text = text,
        style = TextStyle(
            fontSize = 9.sp,
            fontWeight = FontWeight.SemiBold,
            color = color
        )
    )
    val clampedX = topLeft.x.coerceIn(4f, (size.width - result.size.width - 4f).coerceAtLeast(4f))
    val clampedY = topLeft.y.coerceIn(4f, (size.height - result.size.height - 4f).coerceAtLeast(4f))
    drawRect(
        color = Color.White.copy(alpha = 0.82f),
        topLeft = Offset(clampedX - 2f, clampedY - 1f),
        size = Size(result.size.width + 4f, result.size.height + 2f)
    )
    drawText(result, topLeft = Offset(clampedX, clampedY))
}
