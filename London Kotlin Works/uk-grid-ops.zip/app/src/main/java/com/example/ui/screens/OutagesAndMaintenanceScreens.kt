package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.model.*
import com.example.ui.components.*
import com.example.ui.viewmodel.GridUiState

@Composable
fun OutagesScreen(
    uiState: GridUiState,
    outages: List<OutageRecord>,
    onAdvanceStage: (OutageRecord) -> Unit,
    onCancelOutage: (OutageRecord) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeaderCard(
                title = "Outage Coordination Workflow",
                subtitle = "Draft → Assessed → Reviewed → Approved for Planning → Scheduled → In Progress → Completed",
                rightBadge = "${outages.size} Outages"
            )
        }
        item {
            SafetyBannerNotice(
                text = "Cross-organisation coordination enforced: ${uiState.activeOrg.shortName} cannot approve outages owned by another organisation. Planning approval is strictly separate from switching authorisation, isolation, earthing, and safety permits.",
                isWarning = false
            )
        }

        items(outages.size) { idx ->
            val o = outages[idx]
            val tone = when (o.stage) {
                OutageStage.COMPLETED, OutageStage.APPROVED_FOR_PLANNING, OutageStage.SCHEDULED -> StatusTone.HEALTHY
                OutageStage.CANCELLED -> StatusTone.CRITICAL
                OutageStage.IN_PROGRESS -> StatusTone.AMBER
                else -> StatusTone.NEUTRAL
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.testTag("outage_card_${o.id}")
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${o.id}: ${o.title}", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        StatusPill(o.stage.label, tone)
                    }
                    Text(
                        text = "Equipment: ${o.affectedEquipmentName}\nOwner: ${o.ownerOrg.shortName} • Coord: ${o.coordinatingOrg.shortName}\nWindow: ${o.startWindow} → ${o.endWindow}\nDependencies: ${o.dependencies}\nConflicts: ${o.conflictingWork}\nStudy Evidence: ${o.studyEvidenceSummary}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text("Approval History:", style = MaterialTheme.typography.labelLarge)
                    o.approvalHistory.forEach { h ->
                        Text("• $h", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        o.stage.nextStage()?.let { nxt ->
                            Button(
                                onClick = { onAdvanceStage(o) },
                                modifier = Modifier.testTag("advance_outage_${o.id}")
                            ) {
                                Text("Advance → ${nxt.label}")
                            }
                        }
                        if (o.stage != OutageStage.COMPLETED && o.stage != OutageStage.CANCELLED) {
                            OutlinedButton(
                                onClick = { onCancelOutage(o) },
                                modifier = Modifier.testTag("cancel_outage_${o.id}")
                            ) {
                                Text("Cancel")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MaintenanceScreen(
    uiState: GridUiState,
    workOrders: List<MaintenanceWorkOrder>,
    onResolveConflict: (MaintenanceWorkOrder, Boolean) -> Unit,
    onCreateOfflineDraft: (String, String, String) -> Unit,
    onSyncOfflineDraft: (MaintenanceWorkOrder) -> Unit
) {
    var newTitle by remember { mutableStateOf("400 kV Bushing Corona & Oil Sight Glass Check") }
    var newDefect by remember { mutableStateOf("Minor moisture ingress noted on silica gel breather during walkdown") }
    var selectedEq by remember { mutableStateOf("BR_PENN_CALDER_400") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeaderCard(
                title = "Maintenance & Field Tablet Work",
                subtitle = "Condition-based prioritisation, photographic evidence, offline drafts & version conflict resolution",
                rightBadge = "${workOrders.size} Orders"
            )
        }

        // Offline Tablet Form
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("New Field Tablet Work Order (Offline-Capable Draft)", style = MaterialTheme.typography.titleSmall)
                    OutlinedTextField(
                        value = newTitle,
                        onValueChange = { newTitle = it },
                        label = { Text("Work Order Title") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_wo_title_input")
                    )
                    OutlinedTextField(
                        value = newDefect,
                        onValueChange = { newDefect = it },
                        label = { Text("Defect / Inspection Observation") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("BR_PENN_CALDER_400" to "Pennine-Calder", "BR_HALI_MILL_33" to "Halifax-Milltown").forEach { (id, lbl) ->
                            FilterChip(
                                selected = selectedEq == id,
                                onClick = { selectedEq = id },
                                label = { Text(lbl) }
                            )
                        }
                    }
                    Button(
                        onClick = { onCreateOfflineDraft(selectedEq, newTitle, newDefect) },
                        modifier = Modifier.testTag("create_offline_wo_btn")
                    ) {
                        Text("Save Offline Tablet Draft")
                    }
                }
            }
        }

        items(workOrders.size) { idx ->
            val wo = workOrders[idx]
            val syncTone = when (wo.syncStatus) {
                SyncStatus.SYNCED -> StatusTone.HEALTHY
                SyncStatus.OFFLINE_DRAFT -> StatusTone.AMBER
                SyncStatus.VERSION_CONFLICT -> StatusTone.CRITICAL
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.testTag("wo_card_${wo.id}")
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${wo.id}: ${wo.title}", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        StatusPill("${wo.syncStatus.label} (v${wo.version})", syncTone)
                    }
                    Text(
                        text = "Asset: ${wo.equipmentName} (${wo.ownerOrg.code}) • Priority: ${wo.priorityScore}/100\nDefect: ${wo.defectSummary}\nPrioritisation Rule: ${wo.prioritisationRuleExplanation}\nPredictive Evidence: ${wo.predictiveEvidence}\nSpares: ${wo.sparePartsRequired} • Contractor: ${wo.assignedContractor}\nEvidence: ${wo.completionEvidence}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (wo.hasPhotoEvidence) {
                        Image(
                            painter = painterResource(id = R.drawable.img_substation_inspection),
                            contentDescription = "Substation transformer bushing field inspection photograph",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp)
                                .clip(MaterialTheme.shapes.medium),
                            contentScale = ContentScale.Crop
                        )
                    }
                    if (wo.syncStatus == SyncStatus.VERSION_CONFLICT) {
                        SafetyBannerNotice(
                            text = "VERSION CONFLICT (Local v${wo.version} vs Server v${wo.serverVersion}): ${wo.conflictingServerNote}",
                            isWarning = true
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { onResolveConflict(wo, true) },
                                modifier = Modifier.testTag("resolve_merge_${wo.id}")
                            ) {
                                Text("Merge Local + Server")
                            }
                            OutlinedButton(
                                onClick = { onResolveConflict(wo, false) },
                                modifier = Modifier.testTag("resolve_server_${wo.id}")
                            ) {
                                Text("Accept Server v${wo.serverVersion}")
                            }
                        }
                    } else if (wo.syncStatus == SyncStatus.OFFLINE_DRAFT) {
                        OutlinedButton(
                            onClick = { onSyncOfflineDraft(wo) },
                            modifier = Modifier.testTag("sync_draft_${wo.id}")
                        ) {
                            Text("Synchronise Offline Draft")
                        }
                    }
                }
            }
        }
    }
}
