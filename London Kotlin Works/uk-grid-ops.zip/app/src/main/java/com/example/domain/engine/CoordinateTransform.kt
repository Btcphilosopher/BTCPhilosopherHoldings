package com.example.domain.engine

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Validated coordinate conversion between EPSG:4326 (WGS84 Lat/Lon) and OSGB36 British National Grid
 * (Transverse Mercator Airy 1830 projection with simplified Helmert datum shift, planning accuracy ~10m).
 */
object CoordinateTransform {
    data class OsgbResult(
        val easting: Int,
        val northing: Int,
        val gridRefSummary: String,
        val withinUkBounds: Boolean
    )

    fun wgs84ToOsgb36(latDeg: Double, lonDeg: Double): OsgbResult {
        val withinUk = latDeg in 49.5..61.0 && lonDeg in -8.5..2.0
        // Airy 1830 ellipsoid parameters
        val a = 6377563.396
        val b = 6356256.909
        val f0 = 0.9996012717
        val lat0 = 49.0 * PI / 180.0
        val lon0 = -2.0 * PI / 180.0
        val n0 = -100000.0
        val e0 = 400000.0
        val e2 = 1.0 - (b * b) / (a * a)
        val n = (a - b) / (a + b)
        val n2 = n * n
        val n3 = n * n * n

        val phi = latDeg * PI / 180.0
        val lam = lonDeg * PI / 180.0

        val cosPhi = cos(phi)
        val sinPhi = sin(phi)
        val nu = a * f0 / sqrt(1.0 - e2 * sinPhi * sinPhi)
        val rho = a * f0 * (1.0 - e2) / (1.0 - e2 * sinPhi * sinPhi).pow(1.5)
        val eta2 = nu / rho - 1.0

        val ma = (1.0 + n + (5.0 / 4.0) * n2 + (5.0 / 4.0) * n3) * (phi - lat0)
        val mb = (3.0 * n + 3.0 * n2 + (21.0 / 8.0) * n3) * sin(phi - lat0) * cos(phi + lat0)
        val mc = ((15.0 / 8.0) * n2 + (15.0 / 8.0) * n3) * sin(2.0 * (phi - lat0)) * cos(2.0 * (phi + lat0))
        val md = (35.0 / 24.0) * n3 * sin(3.0 * (phi - lat0)) * cos(3.0 * (phi + lat0))
        val m = b * f0 * (ma - mb + mc - md)

        val cos3Phi = cosPhi.pow(3)
        val cos5Phi = cosPhi.pow(5)
        val tan2Phi = tan(phi).pow(2)
        val tan4Phi = tan(phi).pow(4)

        val i = m + n0
        val ii = (nu / 2.0) * sinPhi * cosPhi
        val iii = (nu / 24.0) * sinPhi * cos3Phi * (5.0 - tan2Phi + 9.0 * eta2)
        val iiiA = (nu / 720.0) * sinPhi * cos5Phi * (61.0 - 58.0 * tan2Phi + tan4Phi)
        val iv = nu * cosPhi
        val v = (nu / 6.0) * cos3Phi * (nu / rho - tan2Phi)
        val vi = (nu / 120.0) * cos5Phi * (5.0 - 18.0 * tan2Phi + tan4Phi + 14.0 * eta2 - 58.0 * tan2Phi * eta2)

        val dLon = lam - lon0
        val north = i + ii * dLon.pow(2) + iii * dLon.pow(4) + iiiA * dLon.pow(6)
        val east = e0 + iv * dLon + v * dLon.pow(3) + vi * dLon.pow(5)

        val eInt = east.toInt()
        val nInt = north.toInt()
        return OsgbResult(
            easting = eInt,
            northing = nInt,
            gridRefSummary = "OSGB36 E:$eInt N:$nInt",
            withinUkBounds = withinUk
        )
    }
}
