package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.engine.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.GridUiState

@Composable
fun StudiesScreen(
    uiState: GridUiState,
    onSelectScenario: (StudyScenario) -> Unit,
    onSelectMethod: (StudyMethod) -> Unit,
    onDemandScaleChange: (Double) -> Unit,
    onBessProposalChange: (Double) -> Unit,
    onRunComparison: (StudyScenario) -> Unit
) {
    val res = uiState.currentStudyResult
    val statusTone = when (res.convergenceStatus) {
        ConvergenceStatus.CONVERGED -> StatusTone.HEALTHY
        ConvergenceStatus.INCOMPLETE_ISLANDED -> StatusTone.AMBER
        ConvergenceStatus.FAILED_TO_CONVERGE -> StatusTone.CRITICAL
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeaderCard(
                title = "Engineering Power-Flow & Contingency Studies",
                subtitle = "Pure-Kotlin AC Newton-Raphson & DC Linear Solver • Base 100 MVA",
                rightBadge = res.convergenceStatus.label
            )
        }

        // Solver & Scenario Controls
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("1. Analysis Method", style = MaterialTheme.typography.titleSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StudyMethod.entries.forEach { method ->
                            FilterChip(
                                selected = uiState.activeStudyMethod == method,
                                onClick = { onSelectMethod(method) },
                                label = { Text(method.label) },
                                modifier = Modifier.testTag("study_method_${method.name}")
                            )
                        }
                    }

                    Text("2. Snapshot Scenario (Includes Edge Cases)", style = MaterialTheme.typography.titleSmall)
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        StudyScenario.entries.forEach { sc ->
                            val selected = uiState.activeScenario == sc
                            OutlinedCard(
                                onClick = { onSelectScenario(sc) },
                                border = BorderStroke(
                                    width = if (selected) 2.dp else 1.dp,
                                    color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                ),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("scenario_${sc.name}")
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(sc.label, style = MaterialTheme.typography.labelLarge)
                                    Text(sc.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }

                    Text(
                        text = "3. Digital Twin Demand Scale: ${"%.0f".format(uiState.demandScaleFactor * 100)}% | BESS Proposed Peak Shave: +${uiState.bessDispatchProposalMw.toInt()} MW (Non-Dispatch)",
                        style = MaterialTheme.typography.labelLarge
                    )
                    Slider(
                        value = uiState.demandScaleFactor.toFloat(),
                        onValueChange = { onDemandScaleChange(it.toDouble()) },
                        valueRange = 0.6f..1.6f
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0.0 to "BESS 0 MW", 30.0 to "BESS +30 MW", 60.0 to "BESS +60 MW").forEach { (mw, lbl) ->
                            FilterChip(
                                selected = uiState.bessDispatchProposalMw == mw,
                                onClick = { onBessProposalChange(mw) },
                                label = { Text(lbl) }
                            )
                        }
                    }
                }
            }
        }

        // Solver Convergence & Security Scope Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.testTag("solver_status_card")
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Solver Status & System Balance", style = MaterialTheme.typography.titleMedium)
                        StatusPill(res.convergenceStatus.label, statusTone)
                    }
                    Text(
                        text = res.engineeringNotice,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (res.convergenceStatus == ConvergenceStatus.FAILED_TO_CONVERGE) StatusCritical else MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Gen: ${"%.1f".format(res.totalGenerationMw)} MW | Demand: ${"%.1f".format(res.totalDemandMw)} MW | Active Losses: ${"%.2f".format(res.totalLossesMw)} MW | Islands: ${res.islandCount}",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text("Documented Assumptions:", style = MaterialTheme.typography.labelLarge)
                    res.assumptionsDoc.forEach { a ->
                        Text("• $a", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text("Assessments Performed vs NOT Performed:", style = MaterialTheme.typography.labelLarge)
                    Text(
                        text = "Performed: ${res.assessmentsPerformed.joinToString(" • ")}\nNOT Performed: ${res.assessmentsNotPerformed.joinToString(" • ")}",
                        style = MaterialTheme.typography.bodySmall,
                        color = StatusAmber
                    )
                }
            }
        }

        // Scenario Comparison Runner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Scenario Comparison (vs Active Study)", style = MaterialTheme.typography.titleSmall)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            StudyScenario.BASELINE to "Compare Baseline",
                            StudyScenario.PLANNED_OUTAGE to "Compare Outage",
                            StudyScenario.REINFORCEMENT_OPT_B to "Compare Opt B"
                        ).forEach { (sc, lbl) ->
                            OutlinedButton(
                                onClick = { onRunComparison(sc) },
                                modifier = Modifier.testTag("compare_${sc.name}")
                            ) {
                                Text(lbl)
                            }
                        }
                    }
                    uiState.comparisonStudyResult?.let { comp ->
                        val activePeak = res.branchResults.maxOfOrNull { it.loadingPct } ?: 0.0
                        val compPeak = comp.branchResults.maxOfOrNull { it.loadingPct } ?: 0.0
                        val deltaLoss = comp.totalLossesMw - res.totalLossesMw
                        Text(
                            text = "Comparison (${comp.scenario.label}):\n• Peak Branch Loading: ${"%.1f".format(activePeak)}% -> ${"%.1f".format(compPeak)}%\n• Network Losses Delta: ${"%+.2f".format(deltaLoss)} MW\n• Status: ${comp.convergenceStatus.label}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Generation, Storage (BESS) & Forecast Provenance
        item {
            Text("Generation, Battery Storage & Forecast Provenance", style = MaterialTheme.typography.titleMedium)
        }
        items(uiState.genStorageUnits.size) { idx ->
            val u = uiState.genStorageUnits[idx]
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(u.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        StatusPill(u.fuelOrTech, StatusTone.NEUTRAL)
                    }
                    Text(
                        text = "Installed: ${u.installedCapacityMw} MW | Available: ${u.availableCapacityMw} MW | Scheduled: ${u.scheduledMw} MW | Forecast: ${u.forecastMw} MW | Measured: ${u.measuredMw} MW\nProvenance: ${u.forecastProvenance} (Model ${u.forecastModelVersion}, ${u.forecastHorizonHours}h horizon, ±${u.forecastUncertaintyPct}%)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (u.energyCapacityMwh != null) {
                        Text(
                            text = "BESS Limits: ${u.energyCapacityMwh} MWh | η=${u.roundTripEfficiencyPct}% | SoC=${u.stateOfChargePct}% (Bounds ${u.minSocPct}%–${u.maxSocPct}%)\nAllocation Guard: ${u.allocatedService}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Branch & Transformer Loading Results
        item {
            Text("Branch & Transformer Loading Results", style = MaterialTheme.typography.titleMedium)
        }
        items(res.branchResults.size) { idx ->
            val br = res.branchResults[idx]
            val tone = when {
                !br.inService -> StatusTone.UNKNOWN
                br.loadingPct > 100.0 -> StatusTone.CRITICAL
                br.loadingPct > 80.0 -> StatusTone.AMBER
                else -> StatusTone.HEALTHY
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(br.branchName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = if (br.inService) {
                                "${"%.1f".format(br.pFromMw)} MW / ${"%.1f".format(br.apparentMva)} MVA (Limit ${br.ratingMva.toInt()} MVA) • Loss ${"%.2f".format(br.lossMw)} MW"
                            } else "OUT OF SERVICE / OPEN",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    StatusPill(
                        text = if (br.inService) "${"%.1f".format(br.loadingPct)}%" else "OPEN",
                        tone = tone
                    )
                }
            }
        }

        // N-1 Single-Component Contingency Results
        if (res.contingencySummary.isNotEmpty()) {
            item {
                Text("N-1 Single-Component Contingency Summary", style = MaterialTheme.typography.titleMedium)
            }
            items(res.contingencySummary.size) { idx ->
                val c = res.contingencySummary[idx]
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Trip: ${c.outagedBranchName}", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                            StatusPill(
                                text = if (!c.converged) "DIVERGED" else "${"%.1f".format(c.maxBranchLoadingPct)}% MAX",
                                tone = if (!c.converged || c.maxBranchLoadingPct > 95.0) StatusTone.CRITICAL else if (c.maxBranchLoadingPct > 80.0) StatusTone.AMBER else StatusTone.HEALTHY
                            )
                        }
                        Text(
                            text = "Worst Branch: ${c.worstBranchName} | Min Bus V: ${"%.3f".format(c.minBusVoltagePu)} pu (${c.worstBusName}) | Islands: ${c.islandCount}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
