package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AssetEntity
import com.example.data.local.GridDatabase
import com.example.data.repository.GridRepository
import com.example.data.seed.PennineNetworkSeed
import com.example.domain.engine.*
import com.example.domain.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class GridNavDestination(val label: String) {
    OVERVIEW("Overview"),
    UK_NETWORK("UK Network"),
    SUBSTATIONS("Substations"),
    ASSETS("Assets"),
    TELEMETRY("Telemetry"),
    STUDIES("Studies"),
    OUTAGES("Outages"),
    MAINTENANCE("Maintenance"),
    CONNECTIONS("Connections"),
    REINFORCEMENT("Reinforcement"),
    REPORTS("Reports"),
    ADMINISTRATION("Administration")
}

enum class NetworkViewMode { GEOGRAPHIC_MAP, SINGLE_LINE_DIAGRAM }

data class GridUiState(
    val activeDestination: GridNavDestination = GridNavDestination.OVERVIEW,
    val activeOrg: UkOrganisation = UkOrganisation.NGET,
    val operatingMode: OperatingMode = OperatingMode.SIMULATION,
    val brandingPreset: BrandingPreset = BrandingPreset.INDEPENDENT_CONCEPT,
    val darkControlRoom: Boolean = false,
    val replayHour: Float = 18.0f,
    val isReplayPlaying: Boolean = false,
    val telemetryTick: Int = 1,
    val buses: List<BusNode> = PennineNetworkSeed.buses,
    val branches: List<BranchAsset> = PennineNetworkSeed.branches,
    val genStorageUnits: List<GenerationStorageUnit> = PennineNetworkSeed.genStorageUnits,
    val demandGroups: List<DemandGroup> = PennineNetworkSeed.demandGroups,
    val connections: List<ConnectionApplication> = PennineNetworkSeed.connections,
    val reinforcementOptions: List<ReinforcementOption> = PennineNetworkSeed.reinforcementOptions,
    val adapterSpecs: List<AdapterInterfaceSpec> = PennineNetworkSeed.adapterSpecs,
    val snapshot: NetworkSnapshot = PennineNetworkSeed.snapshot,
    val networkViewMode: NetworkViewMode = NetworkViewMode.SINGLE_LINE_DIAGRAM,
    val selectedVoltageFilterKv: Double? = null, // null = All
    val showLoadingOverlay: Boolean = true,
    val showOutageOverlay: Boolean = true,
    val networkSearchQuery: String = "",
    val selectedBusId: String = "CALDER_400",
    val selectedBranchId: String? = "BR_CALDER_BRAD_SGT",
    val activeScenario: StudyScenario = StudyScenario.BASELINE,
    val activeStudyMethod: StudyMethod = StudyMethod.AC_NEWTON_RAPHSON,
    val demandScaleFactor: Double = 1.0,
    val bessDispatchProposalMw: Double = 0.0,
    val currentStudyResult: PowerFlowResult = PowerFlowSolver.runStudy(
        PennineNetworkSeed.buses,
        PennineNetworkSeed.branches,
        StudyScenario.BASELINE,
        StudyMethod.AC_NEWTON_RAPHSON
    ),
    val comparisonStudyResult: PowerFlowResult? = null,
    val observations: List<TelemetryObservation> = emptyList(),
    val diagnostics: IngestionDiagnostics = IngestionDiagnostics(0, 0, 0, 0, 1, 0, "Initialising"),
    val demoSteps: List<DemoStepItem> = PennineNetworkSeed.initialDemoSteps,
    val bannerFeedback: String? = null,
    val bannerIsError: Boolean = false
)

class GridViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = GridRepository(GridDatabase.getInstance(application).gridDao())

    private val _uiState = MutableStateFlow(GridUiState())
    val uiState: StateFlow<GridUiState> = _uiState.asStateFlow()

    val persistedAssets: StateFlow<List<AssetEntity>> = repository.assets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val outages: StateFlow<List<OutageRecord>> = repository.outages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val workOrders: StateFlow<List<MaintenanceWorkOrder>> = repository.workOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val alerts: StateFlow<List<GridAlert>> = repository.alerts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reports: StateFlow<List<EngineeringReport>> = repository.reports
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs: StateFlow<List<AuditLogEntry>> = repository.auditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            repository.ensureSeeded()
        }
        refreshTelemetry()
        viewModelScope.launch {
            while (true) {
                delay(3000)
                val current = _uiState.value
                if (current.operatingMode == OperatingMode.SIMULATION) {
                    _uiState.update { it.copy(telemetryTick = it.telemetryTick + 1) }
                    refreshTelemetry()
                } else if (current.operatingMode == OperatingMode.REPLAY && current.isReplayPlaying) {
                    val nextHour = if (current.replayHour >= 22.0f) 6.0f else current.replayHour + 0.5f
                    val scale = replayDemandMultiplier(nextHour)
                    _uiState.update { it.copy(replayHour = nextHour, demandScaleFactor = scale) }
                    runPowerFlowInternal()
                    refreshTelemetry()
                }
            }
        }
    }

    private fun replayDemandMultiplier(hour: Float): Double = when {
        hour < 8f -> 0.72
        hour < 16f -> 0.88
        hour in 16f..20f -> 1.06
        else -> 0.82
    }

    private fun refreshTelemetry() {
        val st = _uiState.value
        val (obs, diag) = TelemetryService.generateObservations(
            mode = st.operatingMode,
            tick = st.telemetryTick,
            replayHour = st.replayHour,
            studyResult = st.currentStudyResult
        )
        _uiState.update { it.copy(observations = obs, diagnostics = diag) }
    }

    fun navigateTo(dest: GridNavDestination) {
        _uiState.update { it.copy(activeDestination = dest, bannerFeedback = null) }
    }

    fun clearBanner() {
        _uiState.update { it.copy(bannerFeedback = null) }
    }

    fun selectOrganisation(org: UkOrganisation) {
        _uiState.update {
            it.copy(
                activeOrg = org,
                bannerFeedback = "Active session context switched to ${org.displayName} (${org.networkArea}).",
                bannerIsError = false
            )
        }
        markDemoStepCompleted(1)
        logAudit(org, "SWITCH_ORG_CONTEXT", org.code, "ALLOWED", "Session switched to ${org.shortName}.")
    }

    fun setOperatingMode(mode: OperatingMode) {
        _uiState.update { it.copy(operatingMode = mode, isReplayPlaying = false) }
        refreshTelemetry()
        logAudit(_uiState.value.activeOrg, "SET_OPERATING_MODE", mode.name, "ALLOWED", "Mode switched to ${mode.label}.")
    }

    fun setReplayHour(hour: Float) {
        val scale = replayDemandMultiplier(hour)
        _uiState.update { it.copy(replayHour = hour, demandScaleFactor = scale) }
        runPowerFlowInternal()
        refreshTelemetry()
    }

    fun toggleReplayPlaying() {
        _uiState.update { it.copy(isReplayPlaying = !it.isReplayPlaying) }
    }

    fun setBrandingPreset(preset: BrandingPreset) {
        _uiState.update { it.copy(brandingPreset = preset) }
    }

    fun toggleDarkControlRoom() {
        _uiState.update { it.copy(darkControlRoom = !it.darkControlRoom) }
    }

    fun setNetworkViewMode(mode: NetworkViewMode) {
        _uiState.update { it.copy(networkViewMode = mode) }
    }

    fun setVoltageFilter(kv: Double?) {
        _uiState.update { it.copy(selectedVoltageFilterKv = kv) }
    }

    fun toggleLoadingOverlay() {
        _uiState.update { it.copy(showLoadingOverlay = !it.showLoadingOverlay) }
    }

    fun toggleOutageOverlay() {
        _uiState.update { it.copy(showOutageOverlay = !it.showOutageOverlay) }
    }

    fun updateSearchQuery(q: String) {
        _uiState.update { it.copy(networkSearchQuery = q) }
    }

    fun selectBus(busId: String) {
        _uiState.update { it.copy(selectedBusId = busId, selectedBranchId = null) }
        markDemoStepCompleted(2)
    }

    fun selectBranch(branchId: String) {
        _uiState.update { it.copy(selectedBranchId = branchId) }
        markDemoStepCompleted(2)
    }

    fun simulateSwitchStatus(branchId: String, status: SwitchStatus) {
        // Simulates telemetry status observation (NOT an operational control command!)
        val updated = _uiState.value.branches.map { br ->
            if (br.id == branchId) {
                br.copy(
                    breakerStatus = status,
                    energisationKnown = status == SwitchStatus.CLOSED
                )
            } else br
        }
        _uiState.update {
            it.copy(
                branches = updated,
                bannerFeedback = "Simulated telemetry state updated to ${status.label}. Reminder: Breaker status alone does not verify isolation or safety.",
                bannerIsError = false
            )
        }
        runPowerFlowInternal()
        refreshTelemetry()
    }

    fun setStudyScenario(scenario: StudyScenario) {
        _uiState.update { it.copy(activeScenario = scenario) }
        runPowerFlowInternal()
        if (scenario == StudyScenario.BASELINE) markDemoStepCompleted(4)
        if (scenario == StudyScenario.PLANNED_OUTAGE) markDemoStepCompleted(6)
    }

    fun setStudyMethod(method: StudyMethod) {
        _uiState.update { it.copy(activeStudyMethod = method) }
        runPowerFlowInternal()
        markDemoStepCompleted(4)
    }

    fun setDemandScale(scale: Double) {
        _uiState.update { it.copy(demandScaleFactor = scale) }
        runPowerFlowInternal()
    }

    fun setBessDispatchProposal(mw: Double) {
        _uiState.update { it.copy(bessDispatchProposalMw = mw) }
        runPowerFlowInternal()
    }

    fun runComparisonStudy(compareScenario: StudyScenario) {
        val st = _uiState.value
        val comp = PowerFlowSolver.runStudy(
            buses = st.buses,
            branches = st.branches,
            scenario = compareScenario,
            method = st.activeStudyMethod,
            demandScaleFactor = st.demandScaleFactor,
            bessDischargeMw = st.bessDispatchProposalMw,
            includeContingencies = false
        )
        _uiState.update { it.copy(comparisonStudyResult = comp) }
    }

    private fun runPowerFlowInternal() {
        val st = _uiState.value
        val res = PowerFlowSolver.runStudy(
            buses = st.buses,
            branches = st.branches,
            scenario = st.activeScenario,
            method = st.activeStudyMethod,
            demandScaleFactor = st.demandScaleFactor,
            bessDischargeMw = st.bessDispatchProposalMw,
            includeContingencies = true
        )
        _uiState.update { it.copy(currentStudyResult = res) }
    }

    fun advanceOutageStage(outage: OutageRecord) {
        val next = outage.stage.nextStage() ?: return
        val actor = _uiState.value.activeOrg
        val requiredAction = when {
            outage.ownerOrg == UkOrganisation.SONI -> GovernanceAction.APPROVE_SONI_INTERFACE
            outage.stage == OutageStage.ASSESSED -> GovernanceAction.NESO_COORDINATE_OUTAGE
            outage.ownerOrg == UkOrganisation.NGED -> GovernanceAction.APPROVE_NGED_OUTAGE
            else -> GovernanceAction.APPROVE_NGET_OUTAGE
        }
        val decision = RbacPolicy.evaluate(actor, requiredAction, outage.ownerOrg)
        if (!decision.allowed) {
            _uiState.update {
                it.copy(
                    bannerFeedback = "ACCESS DENIED (${actor.shortName}): ${decision.reason}",
                    bannerIsError = true
                )
            }
            logAudit(actor, requiredAction.name, outage.id, "DENIED", decision.reason)
            return
        }

        val updated = outage.copy(
            stage = next,
            approvalHistory = outage.approvalHistory + "2026-11-24T09:05Z ${next.label} by ${actor.shortName}"
        )
        viewModelScope.launch {
            repository.saveOutage(updated)
            logAudit(actor, "ADVANCE_OUTAGE_${next.name}", outage.id, "ALLOWED", "Transitioned ${outage.id} -> ${next.label}")
        }
        markDemoStepCompleted(5)
        _uiState.update {
            it.copy(
                bannerFeedback = "${outage.id} transitioned to '${next.label}' by ${actor.shortName} (planning workflow only).",
                bannerIsError = false
            )
        }
    }

    fun cancelOutage(outage: OutageRecord) {
        val actor = _uiState.value.activeOrg
        val action = if (outage.ownerOrg == UkOrganisation.NGED) GovernanceAction.APPROVE_NGED_OUTAGE else GovernanceAction.APPROVE_NGET_OUTAGE
        val decision = RbacPolicy.evaluate(actor, action, outage.ownerOrg)
        if (!decision.allowed) {
            _uiState.update { it.copy(bannerFeedback = "ACCESS DENIED: ${decision.reason}", bannerIsError = true) }
            logAudit(actor, "CANCEL_OUTAGE", outage.id, "DENIED", decision.reason)
            return
        }
        viewModelScope.launch {
            repository.saveOutage(
                outage.copy(
                    stage = OutageStage.CANCELLED,
                    approvalHistory = outage.approvalHistory + "2026-11-24T09:10Z Cancelled by ${actor.shortName}"
                )
            )
            logAudit(actor, "CANCEL_OUTAGE", outage.id, "ALLOWED", "Outage cancelled.")
        }
    }

    fun resolveWorkOrderConflict(wo: MaintenanceWorkOrder, keepLocalDraft: Boolean) {
        val actor = _uiState.value.activeOrg
        val decision = RbacPolicy.evaluate(actor, GovernanceAction.CREATE_WORK_ORDER, wo.ownerOrg)
        if (!decision.allowed) {
            _uiState.update { it.copy(bannerFeedback = "ACCESS DENIED: ${decision.reason}", bannerIsError = true) }
            logAudit(actor, "RESOLVE_WO_CONFLICT", wo.id, "DENIED", decision.reason)
            return
        }
        val newVersion = maxOf(wo.version, wo.serverVersion) + 1
        val resolved = wo.copy(
            version = newVersion,
            serverVersion = newVersion,
            syncStatus = SyncStatus.SYNCED,
            completionEvidence = if (keepLocalDraft) {
                "${wo.completionEvidence} [Resolved: Tablet FT-19 + Server v${wo.serverVersion} merged]"
            } else {
                "Accepted Server v${wo.serverVersion} baseline (including NGET-REQ-22 containment check)"
            },
            conflictingServerNote = null,
            updatedBy = actor.shortName,
            updatedAtIso = "2026-11-24T09:12:00Z"
        )
        viewModelScope.launch {
            repository.saveWorkOrder(resolved)
            logAudit(actor, "RESOLVE_WO_CONFLICT", wo.id, "ALLOWED", "Version conflict resolved at v$newVersion.")
        }
        markDemoStepCompleted(8)
        _uiState.update {
            it.copy(
                bannerFeedback = "${wo.id} conflict resolved & synced at v$newVersion.",
                bannerIsError = false
            )
        }
    }

    fun createOfflineWorkOrder(equipmentId: String, title: String, defect: String) {
        val actor = _uiState.value.activeOrg
        val decision = RbacPolicy.evaluate(actor, GovernanceAction.CREATE_WORK_ORDER, actor)
        if (!decision.allowed) {
            _uiState.update { it.copy(bannerFeedback = "ACCESS DENIED: ${decision.reason}", bannerIsError = true) }
            logAudit(actor, "CREATE_OFFLINE_WO", equipmentId, "DENIED", decision.reason)
            return
        }
        val busOrBrName = _uiState.value.branches.firstOrNull { it.id == equipmentId }?.name
            ?: _uiState.value.buses.firstOrNull { it.id == equipmentId }?.name
            ?: equipmentId
        val newId = "WO-2026-${(110..999).random()}"
        val wo = MaintenanceWorkOrder(
            id = newId,
            equipmentId = equipmentId,
            equipmentName = busOrBrName,
            ownerOrg = actor,
            title = title.ifBlank { "Field Condition Inspection" },
            defectSummary = defect.ifBlank { "Routine thermography & oil level verification" },
            priorityScore = 64,
            prioritisationRuleExplanation = "Rule CBM-GEN-01: Field-raised defect (+40) + Asset criticality (+24) = 64/100.",
            predictiveEvidence = "Visual inspection logged on field tablet; no synthetic RUL extrapolated.",
            sparePartsRequired = "Standard Seal & Desiccant Kit",
            assignedContractor = "${actor.code} Field Crew",
            hasPhotoEvidence = true,
            completionEvidence = "Created offline on Field Tablet — queued for synchronisation.",
            status = WorkOrderStatus.OPEN,
            version = 1,
            serverVersion = 0,
            syncStatus = SyncStatus.OFFLINE_DRAFT,
            updatedBy = "${actor.code} Tablet",
            updatedAtIso = "2026-11-24T09:14:00Z"
        )
        viewModelScope.launch {
            repository.saveWorkOrder(wo)
            logAudit(actor, "CREATE_OFFLINE_WO", newId, "ALLOWED", "Created offline draft work order for $equipmentId.")
        }
        markDemoStepCompleted(8)
        _uiState.update {
            it.copy(
                bannerFeedback = "Offline tablet draft $newId saved locally in Room SQLite (queued for sync).",
                bannerIsError = false
            )
        }
    }

    fun syncOfflineDraft(wo: MaintenanceWorkOrder) {
        viewModelScope.launch {
            repository.saveWorkOrder(
                wo.copy(
                    syncStatus = SyncStatus.SYNCED,
                    serverVersion = wo.version,
                    completionEvidence = "${wo.completionEvidence} [Synced to central register]"
                )
            )
            logAudit(_uiState.value.activeOrg, "SYNC_WORK_ORDER", wo.id, "ALLOWED", "Offline draft synced at v${wo.version}.")
        }
    }

    fun acknowledgeAlert(alert: GridAlert) {
        val actor = _uiState.value.activeOrg
        if (actor == UkOrganisation.PUBLIC_OBSERVER) {
            _uiState.update {
                it.copy(
                    bannerFeedback = "ACCESS DENIED: External Observer cannot acknowledge operational alerts.",
                    bannerIsError = true
                )
            }
            logAudit(actor, "ACK_ALERT", alert.id, "DENIED", "Public observer blocked.")
            return
        }
        val updated = alert.copy(
            acknowledged = true,
            acknowledgedBy = actor.shortName,
            escalationStatus = "Acknowledged by ${actor.shortName} — Underlying Condition Still Active",
            conditionActive = true, // Acknowledging NEVER clears underlying condition!
            chronology = alert.chronology + "09:16:00Z Acknowledged by ${actor.shortName} (condition active)"
        )
        viewModelScope.launch {
            repository.saveAlert(updated)
            logAudit(actor, "ACK_ALERT", alert.id, "ALLOWED", "Alert acknowledged; physical condition remains active.")
        }
        markDemoStepCompleted(3)
    }

    fun advanceConnectionStage(connId: String) {
        val actor = _uiState.value.activeOrg
        if (actor == UkOrganisation.PUBLIC_OBSERVER) {
            _uiState.update { it.copy(bannerFeedback = "ACCESS DENIED: Read-only observer cannot modify connections.", bannerIsError = true) }
            logAudit(actor, "ADVANCE_CONNECTION", connId, "DENIED", "External observer blocked.")
            return
        }
        val updated = _uiState.value.connections.map { c ->
            if (c.id == connId) {
                val nextStage = when (c.stage) {
                    ConnectionStage.PRELIMINARY_STUDY -> ConnectionStage.INFORMATION_REQUEST
                    ConnectionStage.INFORMATION_REQUEST -> ConnectionStage.OFFER_ISSUED
                    ConnectionStage.OFFER_ISSUED -> ConnectionStage.OFFER_ACCEPTED
                    ConnectionStage.OFFER_ACCEPTED -> ConnectionStage.DELIVERY_MILESTONES
                    ConnectionStage.DELIVERY_MILESTONES -> ConnectionStage.DELIVERY_MILESTONES
                }
                val newContracted = if (nextStage == ConnectionStage.OFFER_ACCEPTED || nextStage == ConnectionStage.DELIVERY_MILESTONES) {
                    c.offeredCapacityMw
                } else {
                    c.contractedCapacityMw
                }
                c.copy(stage = nextStage, contractedCapacityMw = newContracted)
            } else c
        }
        _uiState.update {
            it.copy(
                connections = updated,
                bannerFeedback = "Connection $connId stage updated (indicative vs engineered vs contracted capacity preserved).",
                bannerIsError = false
            )
        }
        markDemoStepCompleted(9)
        logAudit(actor, "ADVANCE_CONNECTION", connId, "ALLOWED", "Updated connection stage.")
    }

    fun generateEngineeringReport() {
        val st = _uiState.value
        val actor = st.activeOrg
        val study = st.currentStudyResult
        val newId = "RPT-PENN-2026-${(10..99).random()}"
        val worstBranch = study.branchResults.maxByOrNull { it.loadingPct }
        val rpt = EngineeringReport(
            id = newId,
            title = "Study Report: ${study.scenario.label}",
            snapshotId = st.snapshot.snapshotId,
            scenarioName = "${study.scenario.label} (${study.method.label})",
            authorOrg = actor,
            createdUtc = "2026-11-24T09:20:00Z",
            dataSources = "Snapshot ${st.snapshot.snapshotId}; Mode=${st.operatingMode.label}; Synthetic Telemetry Tick #${st.telemetryTick}",
            assumptions = study.assumptionsDoc.joinToString(" | "),
            solverStatusSummary = "${study.convergenceStatus.label} (${study.iterations} iters, mismatch ${"%.2e".format(study.maxMismatchPu)} pu, islands=${study.islandCount})",
            findings = "Gen=${"%.1f".format(study.totalGenerationMw)} MW, Demand=${"%.1f".format(study.totalDemandMw)} MW, Losses=${"%.2f".format(study.totalLossesMw)} MW. Peak branch: ${worstBranch?.branchName ?: "N/A"} at ${"%.1f".format(worstBranch?.loadingPct ?: 0.0)}%.",
            limitations = "Not performed: ${study.assessmentsNotPerformed.joinToString("; ")}. Steady-state study is not proof of overall security.",
            capexGbpMillions = 29.80,
            opexGbpMillions = 1.45,
            committedGbpMillions = 1.80,
            actualGbpMillions = 0.75,
            forecastGbpMillions = 31.25,
            priceBaseDate = "GBP (2026 Q4 Price Base)",
            approvalStatus = "Draft — Pending Engineering Sign-Off",
            approvalHistory = listOf("2026-11-24T09:20Z Generated by ${actor.shortName}")
        )
        viewModelScope.launch {
            repository.saveReport(rpt)
            logAudit(actor, "GENERATE_REPORT", newId, "ALLOWED", "Generated engineering report from ${st.snapshot.snapshotId}.")
        }
        markDemoStepCompleted(10)
        _uiState.update { it.copy(bannerFeedback = "Generated auditable engineering report $newId.", bannerIsError = false) }
    }

    fun approveReport(report: EngineeringReport) {
        val actor = _uiState.value.activeOrg
        val decision = RbacPolicy.evaluate(actor, GovernanceAction.APPROVE_ENGINEERING_REPORT, report.authorOrg)
        if (!decision.allowed) {
            _uiState.update { it.copy(bannerFeedback = "ACCESS DENIED: ${decision.reason}", bannerIsError = true) }
            logAudit(actor, "APPROVE_REPORT", report.id, "DENIED", decision.reason)
            return
        }
        val approved = report.copy(
            approvalStatus = "APPROVED FOR PLANNING (${actor.code})",
            approvalHistory = report.approvalHistory + "2026-11-24T09:22Z Signed off by ${actor.shortName}"
        )
        viewModelScope.launch {
            repository.saveReport(approved)
            logAudit(actor, "APPROVE_REPORT", report.id, "ALLOWED", "Engineering report approved by ${actor.shortName}.")
        }
        markDemoStepCompleted(10)
        _uiState.update { it.copy(bannerFeedback = "${report.id} approved by ${actor.shortName}.", bannerIsError = false) }
    }

    fun attemptRestrictedExport() {
        val actor = _uiState.value.activeOrg
        val decision = RbacPolicy.evaluate(actor, GovernanceAction.EXPORT_RESTRICTED_INFRASTRUCTURE)
        if (!decision.allowed) {
            _uiState.update { it.copy(bannerFeedback = "EXPORT BLOCKED (${actor.shortName}): ${decision.reason}", bannerIsError = true) }
            logAudit(actor, "EXPORT_RESTRICTED_COORDS", "PENNINE_CNI_GEO", "DENIED", decision.reason)
        } else {
            _uiState.update {
                it.copy(
                    bannerFeedback = "Internal engineering export package prepared (WGS84 + OSGB36, logged to audit trail).",
                    bannerIsError = false
                )
            }
            logAudit(actor, "EXPORT_RESTRICTED_COORDS", "PENNINE_CNI_GEO", "ALLOWED", "Authorised export for ${actor.shortName}.")
        }
    }

    fun markDemoStepCompleted(stepNumber: Int) {
        _uiState.update { st ->
            st.copy(
                demoSteps = st.demoSteps.map {
                    if (it.stepNumber == stepNumber) it.copy(completed = true) else it
                }
            )
        }
    }

    fun jumpToDemoStep(step: DemoStepItem) {
        val dest = GridNavDestination.entries.firstOrNull { it.label == step.targetRouteName }
            ?: GridNavDestination.OVERVIEW
        navigateTo(dest)
    }

    private fun logAudit(
        actor: UkOrganisation,
        action: String,
        targetId: String,
        outcome: String,
        details: String
    ) {
        viewModelScope.launch {
            repository.appendAuditLog(
                AuditLogEntry(
                    id = "AUD-${System.currentTimeMillis() % 100000}",
                    timestampUtc = "2026-11-24T09:${(10..59).random()}:00Z",
                    actorOrg = actor,
                    action = action,
                    targetId = targetId,
                    outcome = outcome,
                    details = details
                )
            )
        }
    }
}
