package com.example

import com.example.data.seed.PennineNetworkSeed
import com.example.domain.engine.*
import com.example.domain.model.*
import org.junit.Assert.*
import org.junit.Test

class PowerFlowAndGovernanceUnitTest {

    @Test
    fun `baseline AC Newton-Raphson converges on Pennine network`() {
        val result = PowerFlowSolver.runStudy(
            buses = PennineNetworkSeed.buses,
            branches = PennineNetworkSeed.branches,
            scenario = StudyScenario.BASELINE,
            method = StudyMethod.AC_NEWTON_RAPHSON
        )
        assertEquals(ConvergenceStatus.CONVERGED, result.convergenceStatus)
        assertTrue("Expected losses > 0 MW in AC study", result.totalLossesMw > 0.0)
        assertTrue("Expected unenergised buses to be empty", result.unenergisedBusIds.isEmpty())
        assertTrue("Expected N-1 contingencies to be evaluated", result.contingencySummary.isNotEmpty())
    }

    @Test
    fun `reinforcement option B reduces peak loading compared to planned outage`() {
        val outageRes = PowerFlowSolver.runStudy(
            buses = PennineNetworkSeed.buses,
            branches = PennineNetworkSeed.branches,
            scenario = StudyScenario.PLANNED_OUTAGE,
            method = StudyMethod.AC_NEWTON_RAPHSON
        )
        val optBRes = PowerFlowSolver.runStudy(
            buses = PennineNetworkSeed.buses,
            branches = PennineNetworkSeed.branches,
            scenario = StudyScenario.REINFORCEMENT_OPT_B,
            method = StudyMethod.AC_NEWTON_RAPHSON
        )
        assertEquals(ConvergenceStatus.CONVERGED, outageRes.convergenceStatus)
        assertEquals(ConvergenceStatus.CONVERGED, optBRes.convergenceStatus)
        val calderOutage = outageRes.branchResults.first { it.branchId == "BR_CALDER_BRAD_SGT" }.loadingPct
        val calderOptB = optBRes.branchResults.first { it.branchId == "BR_CALDER_BRAD_SGT" }.loadingPct
        assertTrue("Expected Opt B ($calderOptB%) to relieve Calder SGT1 vs Outage ($calderOutage%)", calderOptB < calderOutage)
    }

    @Test
    fun `DC linear power flow converges with zero active losses`() {
        val result = PowerFlowSolver.runStudy(
            buses = PennineNetworkSeed.buses,
            branches = PennineNetworkSeed.branches,
            scenario = StudyScenario.BASELINE,
            method = StudyMethod.DC_LINEAR
        )
        assertEquals(ConvergenceStatus.CONVERGED, result.convergenceStatus)
        assertEquals(0.0, result.totalLossesMw, 1e-6)
    }

    @Test
    fun `disconnected topology scenario detects Milltown island`() {
        val result = PowerFlowSolver.runStudy(
            buses = PennineNetworkSeed.buses,
            branches = PennineNetworkSeed.branches,
            scenario = StudyScenario.DISCONNECTED_ISLAND,
            method = StudyMethod.AC_NEWTON_RAPHSON
        )
        assertEquals(ConvergenceStatus.INCOMPLETE_ISLANDED, result.convergenceStatus)
        assertTrue("Expected MILL_33 to be flagged unenergised", "MILL_33" in result.unenergisedBusIds)
        assertTrue("Expected >= 2 islands", result.islandCount >= 2)
    }

    @Test
    fun `extreme stress scenario triggers failed convergence`() {
        val result = PowerFlowSolver.runStudy(
            buses = PennineNetworkSeed.buses,
            branches = PennineNetworkSeed.branches,
            scenario = StudyScenario.STRESS_NON_CONVERGENT,
            method = StudyMethod.AC_NEWTON_RAPHSON
        )
        assertEquals(ConvergenceStatus.FAILED_TO_CONVERGE, result.convergenceStatus)
    }

    @Test
    fun `RBAC enforces separation across NGET NGED NESO SONI and External Observer`() {
        val ngedOnNget = RbacPolicy.evaluate(
            actorOrg = UkOrganisation.NGED,
            action = GovernanceAction.APPROVE_NGET_OUTAGE,
            targetAssetOwner = UkOrganisation.NGET
        )
        assertFalse(ngedOnNget.allowed)

        val ngetOnSoni = RbacPolicy.evaluate(
            actorOrg = UkOrganisation.NGET,
            action = GovernanceAction.APPROVE_SONI_INTERFACE,
            targetAssetOwner = UkOrganisation.SONI
        )
        assertFalse(ngetOnSoni.allowed)

        val extExport = RbacPolicy.evaluate(
            actorOrg = UkOrganisation.PUBLIC_OBSERVER,
            action = GovernanceAction.EXPORT_RESTRICTED_INFRASTRUCTURE
        )
        assertFalse(extExport.allowed)

        val nesoCoord = RbacPolicy.evaluate(UkOrganisation.NESO, GovernanceAction.NESO_COORDINATE_OUTAGE)
        assertTrue(nesoCoord.allowed)
        val nesoMaint = RbacPolicy.evaluate(UkOrganisation.NESO, GovernanceAction.SIGN_OFF_WORK_ORDER, UkOrganisation.NGET)
        assertFalse(nesoMaint.allowed)
    }

    @Test
    fun `telemetry ingestion flags stale sensor clock skew and invalid spikes`() {
        val study = PowerFlowSolver.runStudy(
            buses = PennineNetworkSeed.buses,
            branches = PennineNetworkSeed.branches,
            scenario = StudyScenario.BASELINE,
            method = StudyMethod.AC_NEWTON_RAPHSON
        )
        val (simObs, simDiag) = TelemetryService.generateObservations(OperatingMode.SIMULATION, 5, 18f, study)
        assertTrue(simObs.any { it.qualityFlag == QualityFlag.STALE && it.equipmentId == "BR_WHARFE_AIRE_SGT" })
        assertTrue(simObs.any { it.qualityFlag == QualityFlag.CLOCK_SKEW_CORRECTED })
        assertTrue(simObs.any { it.qualityFlag == QualityFlag.INVALID })
        assertTrue(simDiag.duplicatesDropped > 0)

        val (roObs, roDiag) = TelemetryService.generateObservations(OperatingMode.READ_ONLY_MONITORING, 5, 18f, study)
        assertEquals(QualityFlag.MISSING, roObs.first().qualityFlag)
        assertEquals(1, roDiag.sourceOutages)
    }

    @Test
    fun `outage stage transitions follow full UK planning lifecycle`() {
        val stages = mutableListOf(OutageStage.DRAFT)
        var curr: OutageStage? = OutageStage.DRAFT
        while (curr?.nextStage() != null) {
            curr = curr.nextStage()!!
            stages.add(curr)
        }
        assertEquals(
            listOf(
                OutageStage.DRAFT,
                OutageStage.ASSESSED,
                OutageStage.REVIEWED,
                OutageStage.APPROVED_FOR_PLANNING,
                OutageStage.SCHEDULED,
                OutageStage.IN_PROGRESS,
                OutageStage.COMPLETED
            ),
            stages
        )
    }

    @Test
    fun `WGS84 to OSGB36 transform validates Pennine UK coordinates`() {
        val res = CoordinateTransform.wgs84ToOsgb36(53.70, -1.86)
        assertTrue(res.withinUkBounds)
        assertTrue("Expected Pennine Easting around 409000", res.easting in 390000..430000)
        assertTrue("Expected Pennine Northing around 422000", res.northing in 400000..450000)
    }
}
