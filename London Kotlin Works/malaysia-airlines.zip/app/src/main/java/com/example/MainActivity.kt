package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.*
import com.example.ui.theme.MalaysiaAirlinesTheme
import com.example.viewmodel.AirlineViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MalaysiaAirlinesTheme {
                val viewModel: AirlineViewModel = viewModel()
                val currentScreen by viewModel.currentScreen.collectAsState()
                var showDemoPanel by remember { mutableStateOf(false) }

                val topBarTitle = when (currentScreen) {
                    "search" -> "Search Flights"
                    "offer_results" -> "Flight Offers"
                    "passenger_details" -> "Passenger & Seats"
                    "review_payment" -> "Review & Payment"
                    "confirmation" -> "Booking Confirmation"
                    "trips" -> "My Trips"
                    "check_in" -> "Flight Check-in"
                    "boarding_pass" -> "Mobile Boarding Pass"
                    "flight_status" -> "Flight Status"
                    "disruption" -> "Disruption Support"
                    "enrich" -> "Enrich Loyalty"
                    "profile" -> "Profile & Settings"
                    else -> "Malaysia Airlines"
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        MHTopBar(
                            title = topBarTitle,
                            viewModel = viewModel,
                            onOpenDemo = { showDemoPanel = true }
                        )
                    },
                    bottomBar = {
                        MalaysiaAirlinesBottomBar(viewModel = viewModel)
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (currentScreen) {
                            "home" -> HomeScreen(viewModel) { showDemoPanel = true }
                            "search" -> SearchScreen(viewModel)
                            "offer_results" -> OfferResultsScreen(viewModel)
                            "passenger_details" -> PassengerSeatScreen(viewModel)
                            "review_payment" -> ReviewPaymentScreen(viewModel)
                            "confirmation" -> ConfirmationScreen(viewModel)
                            "trips" -> TripsScreen(viewModel)
                            "check_in" -> CheckInScreen(viewModel)
                            "boarding_pass" -> BoardingPassScreen(viewModel)
                            "flight_status" -> FlightStatusScreen(viewModel)
                            "disruption" -> DisruptionScreen(viewModel)
                            "enrich" -> EnrichScreen(viewModel)
                            "profile" -> ProfileScreen(viewModel)
                            else -> HomeScreen(viewModel) { showDemoPanel = true }
                        }
                    }

                    if (showDemoPanel) {
                        DemoControlPanelModal(viewModel = viewModel) {
                            showDemoPanel = false
                        }
                    }
                }
            }
        }
    }
}
