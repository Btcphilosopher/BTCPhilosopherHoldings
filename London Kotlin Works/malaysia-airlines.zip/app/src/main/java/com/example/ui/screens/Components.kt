package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.viewmodel.AirlineViewModel

@Composable
fun MalaysiaAirlinesBottomBar(viewModel: AirlineViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val lang by viewModel.currentLanguage.collectAsState()

    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp
    ) {
        NavigationBarItem(
            icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
            label = { Text(if (lang == "ms") "Utama" else "Home") },
            selected = currentScreen == "home" || currentScreen == "search" || currentScreen == "offer_results" || currentScreen == "passenger_details" || currentScreen == "review_payment" || currentScreen == "confirmation",
            onClick = { viewModel.navigateTo("home") }
        )
        NavigationBarItem(
            icon = { Icon(Icons.Default.Flight, contentDescription = "Book") },
            label = { Text(if (lang == "ms") "Tempah" else "Book") },
            selected = currentScreen == "search",
            onClick = { viewModel.navigateTo("search") }
        )
        NavigationBarItem(
            icon = { Icon(Icons.Default.ConfirmationNumber, contentDescription = "Trips") },
            label = { Text(if (lang == "ms") "Perjalanan" else "Trips") },
            selected = currentScreen == "trips",
            onClick = { viewModel.navigateTo("trips") }
        )
        NavigationBarItem(
            icon = { Icon(Icons.Default.CardMembership, contentDescription = "Enrich") },
            label = { Text("Enrich") },
            selected = currentScreen == "enrich",
            onClick = { viewModel.navigateTo("enrich") }
        )
        NavigationBarItem(
            icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
            label = { Text(if (lang == "ms") "Profil" else "Profile") },
            selected = currentScreen == "profile",
            onClick = { viewModel.navigateTo("profile") }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MHTopBar(title: String, viewModel: AirlineViewModel, onOpenDemo: () -> Unit) {
    val lang by viewModel.currentLanguage.collectAsState()
    TopAppBar(
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = MaterialTheme.colorScheme.primary,
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier.padding(end = 8.dp)
                ) {
                    Text(
                        " MH ",
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(4.dp)
                    )
                }
                Text(title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            }
        },
        actions = {
            IconButton(onClick = onOpenDemo) {
                Icon(Icons.Default.Build, contentDescription = "Demo Scenarios", tint = MaterialTheme.colorScheme.primary)
            }
            IconButton(onClick = {
                viewModel.setLanguage(if (lang == "en") "ms" else "en")
            }) {
                Text(lang.uppercase(), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
    )
}
