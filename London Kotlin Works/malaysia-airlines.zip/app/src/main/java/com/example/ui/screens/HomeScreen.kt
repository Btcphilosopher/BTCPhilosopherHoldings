package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.AirlineViewModel

@Composable
fun HomeScreen(viewModel: AirlineViewModel, onOpenDemo: () -> Unit) {
    val lang by viewModel.currentLanguage.collectAsState()
    val trips by viewModel.trips.collectAsState()
    val disruption by viewModel.activeDisruption.collectAsState()
    val nextTrip = trips.firstOrNull { it.status == "CONFIRMED" || it.status == "TICKETED" }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Banner
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = if (lang == "ms") "Selamat Datang, Ahmad" else "Malaysian Hospitality",
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (lang == "ms") "Terokai dunia dengan keselesaan dan tradisi." else "Discover the world with grace and warmth.",
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                        fontSize = 14.sp
                    )
                }
            }
        }

        // Disruption Notice Alert if any
        if (disruption != null && disruption?.status == "PENDING") {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.navigateTo("disruption") }
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = "Alert", tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(disruption!!.title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                            Text(disruption!!.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.9f))
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = "View", tint = MaterialTheme.colorScheme.onErrorContainer)
                    }
                }
            }
        }

        // Next Upcoming Journey Card
        item {
            Text(
                text = if (lang == "ms") "Perjalanan Seterusnya" else "Next Upcoming Journey",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(8.dp))
            if (nextTrip != null) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.navigateTo("trips") }
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Booking Ref: ${nextTrip.bookingReference}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Surface(
                                color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(nextTrip.status, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(nextTrip.origin, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                                Text("Kuala Lumpur", fontSize = 12.sp, color = Color.Gray)
                            }
                            Icon(Icons.Default.FlightTakeoff, contentDescription = "Flight", tint = MaterialTheme.colorScheme.primary)
                            Column(horizontalAlignment = Alignment.End) {
                                Text(nextTrip.destination, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                                Text("Penang", fontSize = 12.sp, color = Color.Gray)
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Divider()
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Departure", fontSize = 11.sp, color = Color.Gray)
                                Text(nextTrip.departureDate, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = { viewModel.navigateTo("check_in") },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Icon(Icons.Default.QrCode, contentDescription = "Check-in", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (lang == "ms") "Daftar Masuk" else "Check-in")
                            }
                        }
                    }
                }
            } else {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.Flight, contentDescription = "No Trip", modifier = Modifier.size(48.dp), tint = Color.Gray)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(if (lang == "ms") "Tiada perjalanan aktif." else "No upcoming journeys booked.")
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(onClick = { viewModel.navigateTo("search") }) {
                            Text(if (lang == "ms") "Tempah Penerbangan" else "Book a Flight")
                        }
                    }
                }
            }
        }

        // Quick Actions Grid
        item {
            Text(
                text = if (lang == "ms") "Perkhidmatan Utama" else "Essential Services",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionCard(
                    title = if (lang == "ms") "Tempah" else "Book Flights",
                    icon = Icons.Default.Flight,
                    modifier = Modifier.weight(1f)
                ) { viewModel.navigateTo("search") }
                QuickActionCard(
                    title = if (lang == "ms") "Perjalanan" else "My Trips",
                    icon = Icons.Default.Luggage,
                    modifier = Modifier.weight(1f)
                ) { viewModel.navigateTo("trips") }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionCard(
                    title = if (lang == "ms") "Daftar Masuk" else "Check-in",
                    icon = Icons.Default.CheckCircle,
                    modifier = Modifier.weight(1f)
                ) { viewModel.navigateTo("check_in") }
                QuickActionCard(
                    title = if (lang == "ms") "Status" else "Flight Status",
                    icon = Icons.Default.Schedule,
                    modifier = Modifier.weight(1f)
                ) { viewModel.navigateTo("flight_status") }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionCard(
                    title = "Enrich Loyalty",
                    icon = Icons.Default.CardMembership,
                    modifier = Modifier.weight(1f)
                ) { viewModel.navigateTo("enrich") }
                QuickActionCard(
                    title = if (lang == "ms") "Pas Masuk" else "Boarding Pass",
                    icon = Icons.Default.QrCodeScanner,
                    modifier = Modifier.weight(1f)
                ) { viewModel.navigateTo("boarding_pass") }
            }
        }
    }
}

@Composable
fun QuickActionCard(title: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = title, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(title, fontWeight = FontWeight.Medium, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}
