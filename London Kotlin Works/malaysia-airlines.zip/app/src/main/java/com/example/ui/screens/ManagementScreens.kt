package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.AirlineViewModel

@Composable
fun TripsScreen(viewModel: AirlineViewModel) {
    val lang by viewModel.currentLanguage.collectAsState()
    val trips by viewModel.trips.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = if (lang == "ms") "Perjalanan Saya" else "My Trips & Itineraries",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        items(trips) { trip ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Ref: ${trip.bookingReference}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Surface(
                            color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(trip.status, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Ticket: ${trip.ticketNumber}", fontSize = 13.sp, color = Color.Gray)
                    Text("Route: ${trip.origin} ➔ ${trip.destination} (${trip.flightNumber})", fontWeight = FontWeight.SemiBold)
                    Text("Departure: ${trip.departureDate}", fontSize = 13.sp)
                    Text("Seat: ${trip.seatAssignments.values.firstOrNull() ?: "14C"} | Baggage: ${trip.selectedBaggage}", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.checkIn(trip.bookingReference); viewModel.navigateTo("boarding_pass") },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text(if (lang == "ms") "Daftar Masuk" else "Check-in")
                        }
                        OutlinedButton(
                            onClick = { viewModel.cancelBooking(trip.bookingReference) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (lang == "ms") "Batal" else "Cancel")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CheckInScreen(viewModel: AirlineViewModel) {
    val lang by viewModel.currentLanguage.collectAsState()
    val trips by viewModel.trips.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = if (lang == "ms") "Daftar Masuk Penerbangan" else "Flight Check-in",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text("Select booking to complete check-in and access boarding pass.", fontSize = 13.sp, color = Color.Gray)
        }

        items(trips) { trip ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Booking Ref: ${trip.bookingReference}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text("Flight ${trip.flightNumber} : ${trip.origin} to ${trip.destination}", fontWeight = FontWeight.SemiBold)
                    Text("Departure: ${trip.departureDate}", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            viewModel.checkIn(trip.bookingReference)
                            viewModel.navigateTo("boarding_pass")
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = "Check-in")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (lang == "ms") "Sahkan Daftar Masuk" else "Confirm Check-in & Get Boarding Pass")
                    }
                }
            }
        }
    }
}

@Composable
fun BoardingPassScreen(viewModel: AirlineViewModel) {
    val lang by viewModel.currentLanguage.collectAsState()
    val passes by viewModel.boardingPasses.collectAsState()
    val pass = passes.firstOrNull()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Text(
                text = if (lang == "ms") "Pas Masuk Mudah Alih" else "Mobile Boarding Pass",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text("Cached for offline access with verified version stamp.", fontSize = 12.sp, color = Color.Gray)
        }

        item {
            if (pass != null) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("MALAYSIA AIRLINES", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                            Text("MH FLIGHT", fontWeight = FontWeight.Bold)
                        }
                        Divider()
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("PASSENGER", fontSize = 11.sp, color = Color.Gray)
                                Text(pass.passengerName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("FLIGHT", fontSize = 11.sp, color = Color.Gray)
                                Text(pass.flightNumber, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("FROM", fontSize = 11.sp, color = Color.Gray)
                                Text(pass.origin, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("GATE", fontSize = 11.sp, color = Color.Gray)
                                Text(pass.gate, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.secondary)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("TO", fontSize = 11.sp, color = Color.Gray)
                                Text(pass.destination, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            }
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("BOARDING TIME", fontSize = 11.sp, color = Color.Gray)
                                Text(pass.boardingTime, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("SEAT", fontSize = 11.sp, color = Color.Gray)
                                Text(pass.seat, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("ZONE", fontSize = 11.sp, color = Color.Gray)
                                Text(pass.zone, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.QrCode, contentDescription = "Barcode", modifier = Modifier.size(100.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("DEMO BARCODE: ${pass.barcodeData}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                Text("Status: Verified & Cached Offline (Version ${pass.version})", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
                            }
                        }
                    }
                }
            } else {
                Text("No boarding pass available. Please check in for a flight.")
            }
        }
    }
}

@Composable
fun FlightStatusScreen(viewModel: AirlineViewModel) {
    val lang by viewModel.currentLanguage.collectAsState()
    var queryFlight by remember { mutableStateOf("MH 1142") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = if (lang == "ms") "Status Penerbangan" else "Flight Status Tracker",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = queryFlight,
                onValueChange = { queryFlight = it },
                label = { Text("Flight Number (e.g. MH 1142)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                trailingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") }
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(queryFlight, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
                        Surface(color = Color(0xFF2E7D32).copy(alpha = 0.2f), shape = RoundedCornerShape(8.dp)) {
                            Text("ON TIME", modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF2E7D32))
                        }
                    }
                    Divider()
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Kuala Lumpur (KUL)", fontSize = 12.sp, color = Color.Gray)
                            Text("Scheduled: 09:15", fontWeight = FontWeight.Bold)
                            Text("Estimated: 09:15", fontSize = 12.sp, color = Color(0xFF2E7D32))
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Penang (PEN)", fontSize = 12.sp, color = Color.Gray)
                            Text("Scheduled: 10:25", fontWeight = FontWeight.Bold)
                            Text("Estimated: 10:25", fontSize = 12.sp, color = Color(0xFF2E7D32))
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Terminal: T1 | Gate: C21 | Aircraft: Boeing 737-800", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
fun DisruptionScreen(viewModel: AirlineViewModel) {
    val lang by viewModel.currentLanguage.collectAsState()
    val disruption by viewModel.activeDisruption.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = if (lang == "ms") "Sokongan Gangguan Penerbangan" else "Disruption & Rebooking Support",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.error
            )
        }

        item {
            if (disruption != null) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(disruption!!.title, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
                        Text(disruption!!.description, fontSize = 14.sp)
                        Divider()
                        Text("Original Departure: ${disruption!!.originalDeparture}", fontSize = 13.sp, color = Color.Gray)
                        Text("Rescheduled Departure: ${disruption!!.newDeparture}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Alternative Replacement Flight Options:", fontWeight = FontWeight.Bold)
                        disruption!!.alternativeOptions.forEach { alt ->
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("${alt.flightNumber} • ${alt.origin} ➔ ${alt.destination}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                    Text("Departure: ${alt.departureTime}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { viewModel.acceptDisruptionReplacement() },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text(if (disruption!!.status == "ACCEPTED") "Replacement Accepted" else "Accept Replacement Itinerary")
                        }
                    }
                }
            } else {
                Text("No active flight disruptions.")
            }
        }
    }
}

@Composable
fun EnrichScreen(viewModel: AirlineViewModel) {
    val lang by viewModel.currentLanguage.collectAsState()
    val activities by viewModel.loyaltyActivities.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Malaysia Airlines Enrich", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Surface(color = MaterialTheme.colorScheme.tertiary, shape = RoundedCornerShape(8.dp)) {
                            Text("PLATINUM ELITE", modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Enrich Points Balance", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                    Text("48,920 pts", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Elite Miles: 24,500 | Tier Validity: 31 MAR 2027", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.9f))
                }
            }
        }

        item {
            Text(
                text = if (lang == "ms") "Buku Aktiviti Kesetiaan" else "Auditable Loyalty Activity Ledger",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        }

        items(activities) { act ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(act.description, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("${act.route} • ${act.date}", fontSize = 12.sp, color = Color.Gray)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("+${act.pointsEarned} pts", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text("+${act.eliteMilesEarned} elite miles", fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileScreen(viewModel: AirlineViewModel) {
    val lang by viewModel.currentLanguage.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = if (lang == "ms") "Profil & Tetapan" else "Profile & Settings",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Ahmad Razak", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
                    Text("Enrich ID: MH882910 | Tier: Platinum Elite")
                    Text("Email: ahmad.razak@malaysiaairlines.example")
                    Divider()
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(if (lang == "ms") "Bahasa Aplikasi (Language)" else "App Language")
                        Button(onClick = { viewModel.setLanguage(if (lang == "en") "ms" else "en") }) {
                            Text(if (lang == "en") "Bahasa Malaysia" else "English")
                        }
                    }
                }
            }
        }
    }
}
