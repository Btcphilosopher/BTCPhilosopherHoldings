package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MHNavy = Color(0xFF0A192F)
val MHDeepBlue = Color(0xFF00205B)
val MHRed = Color(0xFFD91424)
val MHTurquoise = Color(0xFF00A3A6)
val MHGold = Color(0xFFC5A059)
val MHWhite = Color(0xFFFFFFFF)
val MHSurfaceLight = Color(0xFFF8F9FA)
val MHCardLight = Color(0xFFFFFFFF)
val MHSurfaceDark = Color(0xFF111827)
val MHCardDark = Color(0xFF1F2937)
