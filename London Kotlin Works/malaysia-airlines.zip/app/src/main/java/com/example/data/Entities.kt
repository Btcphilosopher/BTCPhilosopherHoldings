package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trips")
data class TripEntity(
    @PrimaryKey val bookingReference: String,
    val ticketNumber: String,
    val origin: String,
    val destination: String,
    val flightNumber: String,
    val departureDate: String,
    val passengerNames: String,
    val fareFamily: String,
    val totalPriceMyr: Double,
    val status: String,
    val seatAssignments: String,
    val baggage: String,
    val meal: String,
    val createdAt: Long
)

@Entity(tableName = "boarding_passes")
data class BoardingPassEntity(
    @PrimaryKey val id: String,
    val bookingReference: String,
    val passengerName: String,
    val flightNumber: String,
    val origin: String,
    val destination: String,
    val seat: String,
    val boardingTime: String,
    val gate: String,
    val zone: String,
    val barcodeData: String,
    val isCheckedIn: Boolean,
    val version: Int,
    val cachedTimestamp: Long
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val message: String,
    val timestamp: String,
    val type: String,
    val isRead: Boolean
)

@Entity(tableName = "loyalty_activities")
data class LoyaltyActivityEntity(
    @PrimaryKey val id: String,
    val date: String,
    val description: String,
    val route: String,
    val pointsEarned: Int,
    val eliteMilesEarned: Int,
    val type: String
)
