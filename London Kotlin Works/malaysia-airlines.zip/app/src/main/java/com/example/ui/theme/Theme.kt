package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = MHRed,
    onPrimary = Color.White,
    primaryContainer = MHDeepBlue,
    onPrimaryContainer = Color.White,
    secondary = MHTurquoise,
    onSecondary = Color.White,
    tertiary = MHGold,
    background = MHSurfaceDark,
    surface = MHCardDark,
    onBackground = Color.White,
    onSurface = Color.White
  )

private val LightColorScheme =
  lightColorScheme(
    primary = MHDeepBlue,
    onPrimary = Color.White,
    primaryContainer = MHNavy,
    onPrimaryContainer = Color.White,
    secondary = MHRed,
    onSecondary = Color.White,
    tertiary = MHTurquoise,
    background = MHSurfaceLight,
    surface = MHCardLight,
    onBackground = Color(0xFF0A192F),
    onSurface = Color(0xFF0A192F)
  )

@Composable
fun MalaysiaAirlinesTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Keep false to respect MH brand colors
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }
      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
