package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.AirlineViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(viewModel: AirlineViewModel) {
    val lang by viewModel.currentLanguage.collectAsState()
    val origin by viewModel.searchOrigin.collectAsState()
    val dest by viewModel.searchDestination.collectAsState()
    val date by viewModel.searchDate.collectAsState()
    val tripType by viewModel.tripType.collectAsState()
    val cabin by viewModel.cabinClass.collectAsState()
    val pax by viewModel.passengerCount.collectAsState()

    var originExpanded by remember { mutableStateOf(false) }
    var destExpanded by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = if (lang == "ms") "Cari Penerbangan" else "Search Flights",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = tripType == "Return",
                    onClick = { viewModel.tripType.value = "Return" },
                    label = { Text(if (lang == "ms") "Pergi-Balik" else "Return") }
                )
                FilterChip(
                    selected = tripType == "One-way",
                    onClick = { viewModel.tripType.value = "One-way" },
                    label = { Text(if (lang == "ms") "Sehala" else "One-way") }
                )
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    // Origin
                    OutlinedTextField(
                        value = origin,
                        onValueChange = { viewModel.searchOrigin.value = it },
                        label = { Text(if (lang == "ms") "Dari (Asal)" else "From (Origin)") },
                        leadingIcon = { Icon(Icons.Default.FlightTakeoff, contentDescription = "Origin") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Destination
                    OutlinedTextField(
                        value = dest,
                        onValueChange = { viewModel.searchDestination.value = it },
                        label = { Text(if (lang == "ms") "Ke (Destinasi)" else "To (Destination)") },
                        leadingIcon = { Icon(Icons.Default.FlightLand, contentDescription = "Destination") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Date
                    OutlinedTextField(
                        value = date,
                        onValueChange = { viewModel.searchDate.value = it },
                        label = { Text(if (lang == "ms") "Tarikh Perlepasan" else "Departure Date") },
                        leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = "Date") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Passengers & Cabin
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = "$pax Passenger(s)",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Passengers") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        OutlinedTextField(
                            value = cabin,
                            onValueChange = { viewModel.cabinClass.value = it },
                            label = { Text("Cabin") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = { viewModel.searchFlights() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Search, contentDescription = "Search")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (lang == "ms") "Cari Tawaran Penerbangan" else "Search Available Flights", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
