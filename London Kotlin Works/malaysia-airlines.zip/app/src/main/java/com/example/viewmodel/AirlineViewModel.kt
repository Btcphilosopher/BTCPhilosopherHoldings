package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.AirlineRepository
import com.example.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class AirlineViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = AirlineRepository(application)

    // Localization state: "en" or "ms"
    private val _currentLanguage = MutableStateFlow("en")
    val currentLanguage: StateFlow<String> = _currentLanguage.asStateFlow()

    // Navigation state
    private val _currentScreen = MutableStateFlow("home")
    val currentScreen: StateFlow<String> = _currentScreen.asStateFlow()

    // Airports list
    val airports = listOf(
        Airport("KUL", "Kuala Lumpur Intl Airport", "Kuala Lumpur", "Malaysia"),
        Airport("PEN", "Penang International Airport", "Penang", "Malaysia"),
        Airport("BKI", "Kota Kinabalu Intl Airport", "Kota Kinabalu", "Malaysia"),
        Airport("KCH", "Kuching International Airport", "Kuching", "Malaysia"),
        Airport("SIN", "Changi Airport", "Singapore", "Singapore"),
        Airport("LHR", "Heathrow Airport", "London", "United Kingdom")
    )

    // Flight Search State
    val searchOrigin = MutableStateFlow("KUL")
    val searchDestination = MutableStateFlow("PEN")
    val searchDate = MutableStateFlow("28 NOV 2026")
    val returnDate = MutableStateFlow("05 DEC 2026")
    val passengerCount = MutableStateFlow(1)
    val tripType = MutableStateFlow("Return") // "One-way", "Return", "Multi-city"
    val cabinClass = MutableStateFlow("Economy")

    // Search Results / Offers
    private val _searchResults = MutableStateFlow<List<FlightOffer>>(emptyList())
    val searchResults: StateFlow<List<FlightOffer>> = _searchResults.asStateFlow()

    val selectedOffer = MutableStateFlow<FlightOffer?>(null)

    // Booking creation state
    val passengersList = MutableStateFlow(listOf(Passenger(title = "Mr", firstName = "Ahmad", lastName = "Razak", passportNumber = "A12345678", nationality = "Malaysia", enrichNumber = "MH882910")))
    val selectedSeat = MutableStateFlow("14C")
    val selectedBaggageOption = MutableStateFlow("30kg Checked Baggage (MYR 85)")
    val selectedMealOption = MutableStateFlow("Nasi Lemak with Rendang")

    // Payment & Ticketing simulation state
    val paymentState = MutableStateFlow("IDLE") // "IDLE", "PROCESSING", "SUCCESS", "TIMEOUT", "FAILED", "TICKET_PENDING"
    val lastCreatedBooking = MutableStateFlow<BookingRecord?>(null)

    // Database Flows
    val trips: StateFlow<List<BookingRecord>> = repository.allTrips
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val boardingPasses: StateFlow<List<BoardingPassItem>> = repository.allBoardingPasses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationItem>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val loyaltyActivities: StateFlow<List<LoyaltyActivityItem>> = repository.allLoyaltyActivities
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Disruption Notice State
    val activeDisruption = MutableStateFlow<DisruptionNotice?>(
        DisruptionNotice(
            id = "DISR-01",
            flightNumber = "MH 1142",
            title = "Schedule Change Notice",
            description = "Your flight MH 1142 from Kuala Lumpur to Penang has been rescheduled due to air traffic control regulations.",
            originalDeparture = "28 NOV 2026, 09:15",
            newDeparture = "28 NOV 2026, 11:30",
            alternativeOptions = listOf(
                FlightSegment("MH 1144", "KUL", "PEN", "28 NOV 2026, 13:00", "14:10", "1h 10m", "Boeing 737-800")
            ),
            deadline = "27 NOV 2026",
            status = "PENDING"
        )
    )

    init {
        viewModelScope.launch {
            repository.seedInitialDataIfNeeded()
        }
    }

    fun setLanguage(lang: String) {
        _currentLanguage.value = lang
    }

    fun navigateTo(screen: String) {
        _currentScreen.value = screen
    }

    fun searchFlights() {
        val origin = searchOrigin.value
        val dest = searchDestination.value
        // Generate synthetic fare family offers based on route
        val basePrice = if (dest == "LHR") 3850.0 else 320.0
        val offers = listOf(
            FlightOffer(
                id = "OFFER-ECO-BASIC-${System.currentTimeMillis()}",
                fareFamily = "Economy Basic",
                segments = listOf(FlightSegment("MH 701", origin, dest, searchDate.value, "08:00", "2h 15m", "Boeing 737-800")),
                priceMyr = basePrice,
                baggageIncluded = "7kg Cabin Luggage",
                conditions = "Non-refundable, Change fee applies"
            ),
            FlightOffer(
                id = "OFFER-ECO-FLEX-${System.currentTimeMillis()}",
                fareFamily = "Economy Flex",
                segments = listOf(FlightSegment("MH 703", origin, dest, searchDate.value, "11:30", "2h 15m", "Boeing 737-800")),
                priceMyr = basePrice * 1.35,
                baggageIncluded = "30kg Checked + 7kg Cabin",
                conditions = "Fully refundable, Free date changes"
            ),
            FlightOffer(
                id = "OFFER-BIZ-${System.currentTimeMillis()}",
                fareFamily = "Business Class",
                segments = listOf(FlightSegment("MH 705", origin, dest, searchDate.value, "15:00", "2h 15m", "Airbus A350")),
                priceMyr = basePrice * 2.8,
                baggageIncluded = "40kg Checked + Lounge Access",
                conditions = "Priority boarding, Premium dining"
            )
        )
        _searchResults.value = offers
        navigateTo("offer_results")
    }

    fun selectOffer(offer: FlightOffer) {
        selectedOffer.value = offer
        navigateTo("passenger_details")
    }

    fun proceedToPayment() {
        navigateTo("review_payment")
    }

    fun simulatePayment(scenario: String = "SUCCESS") {
        paymentState.value = "PROCESSING"
        viewModelScope.launch {
            kotlinx.coroutines.delay(1800)
            when (scenario) {
                "SUCCESS" -> {
                    paymentState.value = "SUCCESS"
                    val offer = selectedOffer.value
                    val ref = "MH" + (1000..9999).random()
                    val ticket = "232-" + (10000000..99999999).random()
                    val booking = BookingRecord(
                        bookingReference = ref,
                        ticketNumber = ticket,
                        passengers = passengersList.value,
                        segments = offer?.segments ?: emptyList(),
                        fareFamily = offer?.fareFamily ?: "Economy Flex",
                        totalPriceMyr = offer?.priceMyr ?: 450.0,
                        status = "TICKETED",
                        seatAssignments = mapOf(passengersList.value.first().let { "${it.firstName} ${it.lastName}" } to selectedSeat.value),
                        selectedBaggage = selectedBaggageOption.value,
                        selectedMeal = selectedMealOption.value
                    )
                    lastCreatedBooking.value = booking
                    repository.saveBooking(booking)
                    navigateTo("confirmation")
                }
                "TIMEOUT" -> {
                    paymentState.value = "TIMEOUT"
                }
                "FAILED" -> {
                    paymentState.value = "FAILED"
                }
                "TICKETING_RECOVERY" -> {
                    paymentState.value = "TICKET_PENDING"
                    kotlinx.coroutines.delay(1500)
                    paymentState.value = "SUCCESS"
                    simulatePayment("SUCCESS")
                }
            }
        }
    }

    fun checkIn(ref: String) {
        viewModelScope.launch {
            repository.checkInTrip(ref)
        }
    }

    fun cancelBooking(ref: String) {
        viewModelScope.launch {
            repository.cancelTrip(ref)
        }
    }

    fun acceptDisruptionReplacement() {
        activeDisruption.value = activeDisruption.value?.copy(status = "ACCEPTED")
    }

    // Demo Scenarios Trigger
    fun triggerDemoScenario(scenarioNumber: Int) {
        when (scenarioNumber) {
            1 -> { searchOrigin.value = "KUL"; searchDestination.value = "LHR"; tripType.value = "Return"; searchFlights() }
            2 -> { searchOrigin.value = "KUL"; searchDestination.value = "PEN"; searchFlights() }
            3 -> { passengersList.value = listOf(Passenger(title = "Mr", firstName = "Ahmad", lastName = "Razak", passportNumber = "A12345678", nationality = "Malaysia"), Passenger(title = "Ms", firstName = "Siti", lastName = "Nurhaliza", passportNumber = "B87654321", nationality = "Malaysia")); navigateTo("passenger_details") }
            4 -> { selectedSeat.value = "12A"; navigateTo("review_payment") }
            5 -> { simulatePayment("SUCCESS") }
            6 -> { navigateTo("confirmation") }
            7 -> { navigateTo("trips") }
            8 -> { navigateTo("check_in") }
            9 -> { navigateTo("boarding_pass") }
            10 -> { navigateTo("disruption") }
            11 -> { acceptDisruptionReplacement() }
            12 -> { navigateTo("enrich") }
            13 -> { simulatePayment("TIMEOUT") }
            14 -> { simulatePayment("FAILED") }
            15 -> { simulatePayment("TICKETING_RECOVERY") }
        }
    }
}
