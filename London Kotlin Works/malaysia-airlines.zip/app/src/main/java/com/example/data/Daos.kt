package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TripDao {
    @Query("SELECT * FROM trips ORDER BY createdAt DESC")
    fun getAllTrips(): Flow<List<TripEntity>>

    @Query("SELECT * FROM trips WHERE bookingReference = :ref")
    suspend fun getTripByRef(ref: String): TripEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrip(trip: TripEntity)

    @Query("UPDATE trips SET status = :status WHERE bookingReference = :ref")
    suspend fun updateTripStatus(ref: String, status: String)
}

@Dao
interface BoardingPassDao {
    @Query("SELECT * FROM boarding_passes")
    fun getAllBoardingPasses(): Flow<List<BoardingPassEntity>>

    @Query("SELECT * FROM boarding_passes WHERE bookingReference = :ref")
    suspend fun getBoardingPassByRef(ref: String): BoardingPassEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBoardingPass(pass: BoardingPassEntity)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: String)
}

@Dao
interface LoyaltyDao {
    @Query("SELECT * FROM loyalty_activities ORDER BY date DESC")
    fun getAllActivities(): Flow<List<LoyaltyActivityEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivity(activity: LoyaltyActivityEntity)
}
