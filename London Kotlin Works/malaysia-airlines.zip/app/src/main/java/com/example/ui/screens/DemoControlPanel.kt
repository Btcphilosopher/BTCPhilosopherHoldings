package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.AirlineViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DemoControlPanelModal(viewModel: AirlineViewModel, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .heightIn(max = 600.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Build, contentDescription = "Demo", tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Malaysia Airlines Demo Control", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }
            Text("Trigger any of the 15 demonstration workflows instantly:", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item { DemoButton(1, "1. Search Return Journey (KUL ➔ LHR)") { viewModel.triggerDemoScenario(1); onDismiss() } }
                item { DemoButton(2, "2. Compare Fare Options (KUL ➔ PEN)") { viewModel.triggerDemoScenario(2); onDismiss() } }
                item { DemoButton(3, "3. Add Multiple Travellers") { viewModel.triggerDemoScenario(3); onDismiss() } }
                item { DemoButton(4, "4. Select Seats & Extras") { viewModel.triggerDemoScenario(4); onDismiss() } }
                item { DemoButton(5, "5. Complete Simulated Payment") { viewModel.triggerDemoScenario(5); onDismiss() } }
                item { DemoButton(6, "6. Observe Reservation & Ticketing Confirmation") { viewModel.triggerDemoScenario(6); onDismiss() } }
                item { DemoButton(7, "7. Retrieve Itinerary (My Trips)") { viewModel.triggerDemoScenario(7); onDismiss() } }
                item { DemoButton(8, "8. Complete Simulated Check-in") { viewModel.triggerDemoScenario(8); onDismiss() } }
                item { DemoButton(9, "9. Open Offline Boarding Pass") { viewModel.triggerDemoScenario(9); onDismiss() } }
                item { DemoButton(10, "10. Receive Schedule Change Notice") { viewModel.triggerDemoScenario(10); onDismiss() } }
                item { DemoButton(11, "11. Accept Replacement Itinerary") { viewModel.triggerDemoScenario(11); onDismiss() } }
                item { DemoButton(12, "12. Review Enrich Loyalty Activity Ledger") { viewModel.triggerDemoScenario(12); onDismiss() } }
                item { DemoButton(13, "13. Test Payment Timeout Failure") { viewModel.triggerDemoScenario(13); onDismiss() } }
                item { DemoButton(14, "14. Test Payment Declined Failure") { viewModel.triggerDemoScenario(14); onDismiss() } }
                item { DemoButton(15, "15. Test Ticketing Recovery Workflow") { viewModel.triggerDemoScenario(15); onDismiss() } }
            }
        }
    }
}

@Composable
fun DemoButton(number: Int, label: String, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary)
    ) {
        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterStart) {
            Text(label, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
    }
}
