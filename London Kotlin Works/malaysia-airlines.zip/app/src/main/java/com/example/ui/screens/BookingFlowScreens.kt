package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.AirlineViewModel

@Composable
fun OfferResultsScreen(viewModel: AirlineViewModel) {
    val lang by viewModel.currentLanguage.collectAsState()
    val offers by viewModel.searchResults.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = if (lang == "ms") "Pilih Tawaran Penerbangan" else "Select Flight Offer",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "${offers.size} fares available for your journey",
                color = Color.Gray,
                fontSize = 14.sp
            )
        }

        items(offers) { offer ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.selectOffer(offer) }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(offer.fareFamily, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                        Text("MYR ${String.format("%.2f", offer.priceMyr)}", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = MaterialTheme.colorScheme.secondary)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    offer.segments.forEach { seg ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${seg.flightNumber} • ${seg.origin} ➔ ${seg.destination}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                            Text(seg.departureTime, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Divider()
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(offer.baggageIncluded, fontSize = 12.sp, color = Color.Gray)
                            Text(offer.conditions, fontSize = 11.sp, color = Color.Gray)
                        }
                        Button(
                            onClick = { viewModel.selectOffer(offer) },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("Select")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PassengerSeatScreen(viewModel: AirlineViewModel) {
    val lang by viewModel.currentLanguage.collectAsState()
    val passengers by viewModel.passengersList.collectAsState()
    val selectedSeat by viewModel.selectedSeat.collectAsState()
    val baggage by viewModel.selectedBaggageOption.collectAsState()
    val meal by viewModel.selectedMealOption.collectAsState()

    val seats = listOf("12A", "12B", "12C", "14A", "14B", "14C", "16A", "16B", "16C")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = if (lang == "ms") "Butiran Penumpang & Tempat Duduk" else "Passengers, Seats & Extras",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Passenger 1 (Primary Contact)", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = passengers.firstOrNull()?.firstName ?: "",
                        onValueChange = {},
                        label = { Text("Full Name") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = passengers.firstOrNull()?.passportNumber ?: "",
                        onValueChange = {},
                        label = { Text("Passport Number") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }
        }

        item {
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Seat Selection", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Selected Seat: $selectedSeat", fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        seats.take(6).forEach { seat ->
                            FilterChip(
                                selected = selectedSeat == seat,
                                onClick = { viewModel.selectedSeat.value = seat },
                                label = { Text(seat) }
                            )
                        }
                    }
                }
            }
        }

        item {
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Baggage & Dining Options", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Baggage: $baggage", fontSize = 13.sp)
                    Text("Meal: $meal", fontSize = 13.sp)
                }
            }
        }

        item {
            Button(
                onClick = { viewModel.proceedToPayment() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Proceed to Review & Payment", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun ReviewPaymentScreen(viewModel: AirlineViewModel) {
    val lang by viewModel.currentLanguage.collectAsState()
    val offer by viewModel.selectedOffer.collectAsState()
    val paymentState by viewModel.paymentState.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = if (lang == "ms") "Semakan & Pembayaran" else "Review & Payment",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Fare Summary", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(offer?.fareFamily ?: "Economy Flex")
                        Text("MYR ${String.format("%.2f", offer?.priceMyr ?: 450.0)}")
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Taxes & Carrier Surcharges")
                        Text("MYR 125.50")
                    }
                    Divider(modifier = Modifier.padding(vertical = 8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total Amount", fontWeight = FontWeight.Bold)
                        Text("MYR ${String.format("%.2f", (offer?.priceMyr ?: 450.0) + 125.50)}", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        item {
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Simulated Payment Method", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = "4111 2222 3333 4444 (Visa - Malaysian Hospitality Secure)",
                        onValueChange = {},
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        readOnly = true
                    )
                }
            }
        }

        if (paymentState == "PROCESSING") {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator()
                    Spacer(modifier = Modifier.width(16.dp))
                    Text("Processing secure transaction & issuing ticket...")
                }
            }
        } else if (paymentState == "TIMEOUT") {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Text("Payment Timeout: The transaction gateway did not respond in time. Please retry.", modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onErrorContainer)
                }
            }
        } else if (paymentState == "FAILED") {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Text("Payment Declined: Insufficient synthetic funds or authorization failure.", modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onErrorContainer)
                }
            }
        } else {
            item {
                Button(
                    onClick = { viewModel.simulatePayment("SUCCESS") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Lock, contentDescription = "Secure")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Complete Secure Payment", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ConfirmationScreen(viewModel: AirlineViewModel) {
    val lang by viewModel.currentLanguage.collectAsState()
    val booking by viewModel.lastCreatedBooking.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Icon(Icons.Default.CheckCircle, contentDescription = "Success", tint = Color(0xFF2E7D32), modifier = Modifier.size(64.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (lang == "ms") "Tempahan Berjaya Disahkan!" else "Booking & Ticketing Confirmed!",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text("Malaysian Hospitality welcomes you aboard.", color = Color.Gray, fontSize = 14.sp)
        }

        item {
            if (booking != null) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Booking Reference: ${booking!!.bookingReference}", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
                        Text("E-Ticket Number: ${booking!!.ticketNumber}", fontWeight = FontWeight.Medium)
                        Text("Fare Family: ${booking!!.fareFamily}")
                        Text("Total Paid: MYR ${String.format("%.2f", booking!!.totalPriceMyr)}")
                        Divider(modifier = Modifier.padding(vertical = 8.dp))
                        Button(
                            onClick = { viewModel.navigateTo("trips") },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("View My Trips & Boarding Pass")
                        }
                    }
                }
            }
        }
    }
}
