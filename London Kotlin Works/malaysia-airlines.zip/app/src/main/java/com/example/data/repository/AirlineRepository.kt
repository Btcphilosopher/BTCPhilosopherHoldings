package com.example.data.repository

import android.content.Context
import com.example.data.*
import com.example.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class AirlineRepository(context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val tripDao = db.tripDao()
    private val bpDao = db.boardingPassDao()
    private val notifDao = db.notificationDao()
    private val loyaltyDao = db.loyaltyDao()

    val allTrips: Flow<List<BookingRecord>> = tripDao.getAllTrips().map { entities ->
        entities.map { e ->
            BookingRecord(
                bookingReference = e.bookingReference,
                ticketNumber = e.ticketNumber,
                passengers = listOf(Passenger(title = "Mr", firstName = "Ahmad", lastName = "Razak", passportNumber = "A12345678", nationality = "Malaysia", enrichNumber = "MH882910")),
                segments = listOf(FlightSegment("MH 001", e.origin, e.destination, e.departureDate, "14:30", "1h 10m", "Boeing 737-800", "Malaysia Airlines")),
                fareFamily = e.fareFamily,
                totalPriceMyr = e.totalPriceMyr,
                status = e.status,
                seatAssignments = mapOf("Ahmad Razak" to e.seatAssignments),
                selectedBaggage = e.baggage,
                selectedMeal = e.meal,
                createdAt = e.createdAt
            )
        }
    }

    val allBoardingPasses: Flow<List<BoardingPassItem>> = bpDao.getAllBoardingPasses().map { entities ->
        entities.map { e ->
            BoardingPassItem(
                id = e.id,
                bookingReference = e.bookingReference,
                passengerName = e.passengerName,
                flightNumber = e.flightNumber,
                origin = e.origin,
                destination = e.destination,
                seat = e.seat,
                boardingTime = e.boardingTime,
                gate = e.gate,
                zone = e.zone,
                barcodeData = e.barcodeData,
                isCheckedIn = e.isCheckedIn,
                version = e.version,
                cachedTimestamp = e.cachedTimestamp
            )
        }
    }

    val allNotifications: Flow<List<NotificationItem>> = notifDao.getAllNotifications().map { entities ->
        entities.map { e ->
            NotificationItem(e.id, e.title, e.message, e.timestamp, e.type, e.isRead)
        }
    }

    val allLoyaltyActivities: Flow<List<LoyaltyActivityItem>> = loyaltyDao.getAllActivities().map { entities ->
        entities.map { e ->
            LoyaltyActivityItem(e.id, e.date, e.description, e.route, e.pointsEarned, e.eliteMilesEarned, e.type)
        }
    }

    suspend fun seedInitialDataIfNeeded() {
        // Seed initial sample booking if empty
        val sampleTrip = TripEntity(
            bookingReference = "MH7842",
            ticketNumber = "232-9988271102",
            origin = "KUL",
            destination = "PEN",
            flightNumber = "MH 1142",
            departureDate = "28 NOV 2026, 09:15",
            passengerNames = "Ahmad Razak",
            fareFamily = "Economy Flex",
            totalPriceMyr = 459.00,
            status = "CONFIRMED",
            seatAssignments = "12A",
            baggage = "30kg Checked Baggage",
            meal = "Nasi Lemak with Rendang",
            createdAt = System.currentTimeMillis() - 86400000
        )
        tripDao.insertTrip(sampleTrip)

        val sampleBp = BoardingPassEntity(
            id = "BP-MH7842",
            bookingReference = "MH7842",
            passengerName = "Ahmad Razak",
            flightNumber = "MH 1142",
            origin = "KUL",
            destination = "PEN",
            seat = "12A",
            boardingTime = "08:35",
            gate = "C21",
            zone = "Zone B",
            barcodeData = "MH-BOARDING-PASS-BARCODE-DEMO-7842",
            isCheckedIn = true,
            version = 1,
            cachedTimestamp = System.currentTimeMillis()
        )
        bpDao.insertBoardingPass(sampleBp)

        val sampleNotif = NotificationEntity(
            id = "NOTIF-1",
            title = "Check-in Reminder",
            message = "Check-in for flight MH 1142 (KUL to PEN) is now open. Access your mobile boarding pass.",
            timestamp = "2 hours ago",
            type = "CHECKIN",
            isRead = false
        )
        notifDao.insertNotification(sampleNotif)

        val sampleLoyalty = LoyaltyActivityEntity(
            id = "LOY-1",
            date = "15 NOV 2026",
            description = "Business Class Flight Redemption",
            route = "KUL - LHR",
            pointsEarned = 7850,
            eliteMilesEarned = 6580,
            type = "FLIGHT"
        )
        loyaltyDao.insertActivity(sampleLoyalty)
    }

    suspend fun saveBooking(booking: BookingRecord) {
        val entity = TripEntity(
            bookingReference = booking.bookingReference,
            ticketNumber = booking.ticketNumber,
            origin = booking.segments.firstOrNull()?.origin ?: "KUL",
            destination = booking.segments.lastOrNull()?.destination ?: "PEN",
            flightNumber = booking.segments.firstOrNull()?.flightNumber ?: "MH 001",
            departureDate = booking.segments.firstOrNull()?.departureTime ?: "29 NOV 2026",
            passengerNames = booking.passengers.joinToString(", ") { "${it.firstName} ${it.lastName}" },
            fareFamily = booking.fareFamily,
            totalPriceMyr = booking.totalPriceMyr,
            status = booking.status,
            seatAssignments = booking.seatAssignments.values.firstOrNull() ?: "14C",
            baggage = booking.selectedBaggage,
            meal = booking.selectedMeal,
            createdAt = booking.createdAt
        )
        tripDao.insertTrip(entity)

        // Also add boarding pass stub
        val bp = BoardingPassEntity(
            id = "BP-${booking.bookingReference}",
            bookingReference = booking.bookingReference,
            passengerName = booking.passengers.firstOrNull()?.let { "${it.firstName} ${it.lastName}" } ?: "Guest Passenger",
            flightNumber = booking.segments.firstOrNull()?.flightNumber ?: "MH 001",
            origin = booking.segments.firstOrNull()?.origin ?: "KUL",
            destination = booking.segments.lastOrNull()?.destination ?: "PEN",
            seat = booking.seatAssignments.values.firstOrNull() ?: "14C",
            boardingTime = "07:45",
            gate = "B12",
            zone = "Zone A",
            barcodeData = "MH-DEMO-BARCODE-${booking.bookingReference}",
            isCheckedIn = false,
            version = 1,
            cachedTimestamp = System.currentTimeMillis()
        )
        bpDao.insertBoardingPass(bp)

        // Add notification
        val notif = NotificationEntity(
            id = "NOTIF-${System.currentTimeMillis()}",
            title = "Booking Confirmed (${booking.bookingReference})",
            message = "Your ticket ${booking.ticketNumber} has been successfully issued. Malaysian Hospitality awaits you.",
            timestamp = "Just now",
            type = "BOOKING",
            isRead = false
        )
        notifDao.insertNotification(notif)
    }

    suspend fun checkInTrip(ref: String) {
        tripDao.updateTripStatus(ref, "CHECKED_IN")
    }

    suspend fun cancelTrip(ref: String) {
        tripDao.updateTripStatus(ref, "CANCELLED")
    }
}
