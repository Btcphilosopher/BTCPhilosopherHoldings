package com.example.model

data class Airport(
    val code: String,
    val name: String,
    val city: String,
    val country: String
)

data class FlightSegment(
    val flightNumber: String,
    val origin: String,
    val destination: String,
    val departureTime: String,
    val arrivalTime: String,
    val duration: String,
    val aircraft: String,
    val operatingCarrier: String = "Malaysia Airlines"
)

data class FlightOffer(
    val id: String,
    val fareFamily: String,
    val segments: List<FlightSegment>,
    val priceMyr: Double,
    val baggageIncluded: String,
    val conditions: String,
    val expiresAt: Long = System.currentTimeMillis() + 15 * 60 * 1000
)

data class Passenger(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val firstName: String,
    val lastName: String,
    val passportNumber: String,
    val nationality: String,
    val enrichNumber: String = ""
)

data class BookingRecord(
    val bookingReference: String,
    val ticketNumber: String,
    val passengers: List<Passenger>,
    val segments: List<FlightSegment>,
    val fareFamily: String,
    val totalPriceMyr: Double,
    val status: String,
    val seatAssignments: Map<String, String> = emptyMap(),
    val selectedBaggage: String = "20kg Checked Baggage",
    val selectedMeal: String = "Standard Malaysian Nasi Lemak",
    val createdAt: Long = System.currentTimeMillis()
) {
    val origin: String get() = segments.firstOrNull()?.origin ?: "KUL"
    val destination: String get() = segments.lastOrNull()?.destination ?: "PEN"
    val flightNumber: String get() = segments.firstOrNull()?.flightNumber ?: "MH 001"
    val departureDate: String get() = segments.firstOrNull()?.departureTime ?: "29 NOV 2026"
}

data class BoardingPassItem(
    val id: String,
    val bookingReference: String,
    val passengerName: String,
    val flightNumber: String,
    val origin: String,
    val destination: String,
    val seat: String,
    val boardingTime: String,
    val gate: String,
    val zone: String,
    val barcodeData: String,
    val isCheckedIn: Boolean,
    val version: Int = 1,
    val cachedTimestamp: Long = System.currentTimeMillis()
)

data class LoyaltyActivityItem(
    val id: String,
    val date: String,
    val description: String,
    val route: String,
    val pointsEarned: Int,
    val eliteMilesEarned: Int,
    val type: String
)

data class NotificationItem(
    val id: String,
    val title: String,
    val message: String,
    val timestamp: String,
    val type: String,
    val isRead: Boolean = false
)

data class DisruptionNotice(
    val id: String,
    val flightNumber: String,
    val title: String,
    val description: String,
    val originalDeparture: String,
    val newDeparture: String,
    val alternativeOptions: List<FlightSegment>,
    val deadline: String,
    val status: String
)
