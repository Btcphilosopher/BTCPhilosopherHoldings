package com.example

import com.example.data.adapter.AccessCheckResult
import com.example.data.adapter.ServerSignResult
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.repository.ClinicalRepository
import com.example.data.seed.SyntheticClinicalSeed
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

private class FakeClinicalDao : ClinicalDao {
  private val patientsFlow = MutableStateFlow<List<PatientEntity>>(emptyList())
  private val appointmentsFlow = MutableStateFlow<List<AppointmentEntity>>(emptyList())
  private val allergiesFlow = MutableStateFlow<List<AllergyEntity>>(emptyList())
  private val problemsFlow = MutableStateFlow<List<ProblemEntity>>(emptyList())
  private val encountersFlow = MutableStateFlow<List<EncounterEntity>>(emptyList())
  private val medicationsFlow = MutableStateFlow<List<MedicationEntity>>(emptyList())
  private val observationsFlow = MutableStateFlow<List<ObservationEntity>>(emptyList())
  private val labResultsFlow = MutableStateFlow<List<LabResultEntity>>(emptyList())
  private val notesFlow = MutableStateFlow<List<ClinicalNoteEntity>>(emptyList())
  private val noteVersionsFlow = MutableStateFlow<List<NoteVersionEntity>>(emptyList())
  private val noteAddendaFlow = MutableStateFlow<List<NoteAddendumEntity>>(emptyList())
  private val carePlansFlow = MutableStateFlow<List<CarePlanEntity>>(emptyList())
  private val tasksFlow = MutableStateFlow<List<ClinicalTaskEntity>>(emptyList())
  private val handoversFlow = MutableStateFlow<List<HandoverSbarEntity>>(emptyList())
  private val messagesFlow = MutableStateFlow<List<TeamMessageEntity>>(emptyList())
  private val strokesFlow = MutableStateFlow<List<BodyStrokeEntity>>(emptyList())
  private val toolsFlow = MutableStateFlow<List<ConsultationToolEntity>>(emptyList())
  private val auditsFlow = MutableStateFlow<List<AuditEventEntity>>(emptyList())
  private val syncFlow = MutableStateFlow<List<SyncQueueEntity>>(emptyList())

  override fun observePatients(): Flow<List<PatientEntity>> = patientsFlow
  override suspend fun countPatients(): Int = patientsFlow.value.size
  override suspend fun insertPatients(items: List<PatientEntity>) { patientsFlow.value = items }
  override suspend fun upsertPatient(item: PatientEntity) {
    patientsFlow.value = patientsFlow.value.filterNot { it.id == item.id } + item
  }

  override fun observeAppointments(): Flow<List<AppointmentEntity>> = appointmentsFlow
  override suspend fun insertAppointments(items: List<AppointmentEntity>) { appointmentsFlow.value = items }

  override fun observeAllergies(): Flow<List<AllergyEntity>> = allergiesFlow
  override suspend fun insertAllergies(items: List<AllergyEntity>) { allergiesFlow.value = items }
  override suspend fun upsertAllergy(item: AllergyEntity) {
    allergiesFlow.value = allergiesFlow.value.filterNot { it.id == item.id } + item
  }

  override fun observeProblems(): Flow<List<ProblemEntity>> = problemsFlow
  override suspend fun insertProblems(items: List<ProblemEntity>) { problemsFlow.value = items }

  override fun observeEncounters(): Flow<List<EncounterEntity>> = encountersFlow
  override suspend fun insertEncounters(items: List<EncounterEntity>) { encountersFlow.value = items }

  override fun observeMedications(): Flow<List<MedicationEntity>> = medicationsFlow
  override suspend fun insertMedications(items: List<MedicationEntity>) { medicationsFlow.value = items }
  override suspend fun upsertMedication(item: MedicationEntity) {
    medicationsFlow.value = medicationsFlow.value.filterNot { it.id == item.id } + item
  }

  override fun observeObservations(): Flow<List<ObservationEntity>> = observationsFlow
  override suspend fun insertObservations(items: List<ObservationEntity>) { observationsFlow.value = items }

  override fun observeLabResults(): Flow<List<LabResultEntity>> = labResultsFlow
  override suspend fun insertLabResults(items: List<LabResultEntity>) { labResultsFlow.value = items }
  override suspend fun upsertLabResult(item: LabResultEntity) {
    labResultsFlow.value = labResultsFlow.value.filterNot { it.id == item.id } + item
  }

  override fun observeNotes(): Flow<List<ClinicalNoteEntity>> = notesFlow
  override suspend fun insertNotes(items: List<ClinicalNoteEntity>) { notesFlow.value = items }
  override suspend fun upsertNote(item: ClinicalNoteEntity) {
    notesFlow.value = notesFlow.value.filterNot { it.id == item.id } + item
  }

  override fun observeNoteVersions(): Flow<List<NoteVersionEntity>> = noteVersionsFlow
  override suspend fun insertNoteVersions(items: List<NoteVersionEntity>) { noteVersionsFlow.value = items }
  override suspend fun insertNoteVersion(item: NoteVersionEntity) {
    noteVersionsFlow.value = noteVersionsFlow.value + item
  }

  override fun observeNoteAddenda(): Flow<List<NoteAddendumEntity>> = noteAddendaFlow
  override suspend fun insertNoteAddenda(items: List<NoteAddendumEntity>) { noteAddendaFlow.value = items }
  override suspend fun insertNoteAddendum(item: NoteAddendumEntity) {
    noteAddendaFlow.value = noteAddendaFlow.value + item
  }

  override fun observeCarePlans(): Flow<List<CarePlanEntity>> = carePlansFlow
  override suspend fun insertCarePlans(items: List<CarePlanEntity>) { carePlansFlow.value = items }
  override suspend fun upsertCarePlan(item: CarePlanEntity) {
    carePlansFlow.value = carePlansFlow.value.filterNot { it.id == item.id } + item
  }

  override fun observeTasks(): Flow<List<ClinicalTaskEntity>> = tasksFlow
  override suspend fun insertTasks(items: List<ClinicalTaskEntity>) { tasksFlow.value = items }
  override suspend fun upsertTask(item: ClinicalTaskEntity) {
    tasksFlow.value = tasksFlow.value.filterNot { it.id == item.id } + item
  }

  override fun observeHandovers(): Flow<List<HandoverSbarEntity>> = handoversFlow
  override suspend fun insertHandovers(items: List<HandoverSbarEntity>) { handoversFlow.value = items }
  override suspend fun upsertHandover(item: HandoverSbarEntity) {
    handoversFlow.value = handoversFlow.value.filterNot { it.id == item.id } + item
  }

  override fun observeMessages(): Flow<List<TeamMessageEntity>> = messagesFlow
  override suspend fun insertMessages(items: List<TeamMessageEntity>) { messagesFlow.value = items }
  override suspend fun upsertMessage(item: TeamMessageEntity) {
    messagesFlow.value = messagesFlow.value.filterNot { it.id == item.id } + item
  }

  override fun observeBodyStrokes(): Flow<List<BodyStrokeEntity>> = strokesFlow
  override suspend fun upsertBodyStroke(item: BodyStrokeEntity) { strokesFlow.value = strokesFlow.value + item }
  override suspend fun clearBodyStrokesForPatient(patientId: String) {
    strokesFlow.value = strokesFlow.value.filterNot { it.patientId == patientId }
  }

  override fun observeConsultationTools(): Flow<List<ConsultationToolEntity>> = toolsFlow
  override suspend fun insertConsultationTools(items: List<ConsultationToolEntity>) { toolsFlow.value = items }
  override suspend fun upsertConsultationTool(item: ConsultationToolEntity) {
    toolsFlow.value = toolsFlow.value.filterNot { it.patientId == item.patientId } + item
  }

  override fun observeAuditEvents(): Flow<List<AuditEventEntity>> = auditsFlow
  override suspend fun insertAuditEvents(items: List<AuditEventEntity>) { auditsFlow.value = items }
  override suspend fun insertAuditEvent(item: AuditEventEntity) {
    auditsFlow.value = listOf(item) + auditsFlow.value
  }

  override fun observeSyncQueue(): Flow<List<SyncQueueEntity>> = syncFlow
  override suspend fun upsertSyncItem(item: SyncQueueEntity) {
    syncFlow.value = syncFlow.value.filterNot { it.id == item.id } + item
  }
  override suspend fun deleteSyncItem(id: String) {
    syncFlow.value = syncFlow.value.filterNot { it.id == id }
  }
  override suspend fun clearSyncQueue() { syncFlow.value = emptyList() }
}

class ClinicalWorkspaceTest {

  private lateinit var repo: ClinicalRepository

  @Before
  fun setUp() {
    repo = ClinicalRepository(FakeClinicalDao())
  }

  @Test
  fun `seed loads synthetic patients and isolates clinician care context`() = runTest {
    repo.ensureSeeded()
    val patients = repo.patients.first()
    assertEquals(6, patients.size)

    val restrictedSession = repo.identityAdapter.signIn("np_bennett", "1234")!!
    val wardPatient = patients.first { it.id == "pat_02" }
    val clinicPatient = patients.first { it.id == "pat_06" }

    assertTrue(repo.evaluatePatientAccess(restrictedSession, clinicPatient) is AccessCheckResult.Granted)
    assertTrue(repo.evaluatePatientAccess(restrictedSession, wardPatient) is AccessCheckResult.DeniedCareContext)

    val breakGlassSession =
      restrictedSession.copy(
        breakGlassPatientIds = setOf(wardPatient.id),
        breakGlassReason = "Covering acute ward hyperkalaemia alert",
      )
    assertTrue(
      repo.evaluatePatientAccess(breakGlassSession, wardPatient) is AccessCheckResult.GrantedViaBreakGlass
    )
  }

  @Test
  fun `note signing blocks offline, locks signed note, preserves addenda and entered-in-error`() = runTest {
    repo.ensureSeeded()
    val clinician = SyntheticClinicalSeed.clinicianAccounts.first()
    val draft = repo.clinicalNotes.first().first { it.id == "note_01" }

    val offlineSaved = repo.saveDraftNote(draft.copy(freeText = "Offline edit"), clinician, "Margaret Holloway", isOnline = false)
    assertTrue(offlineSaved.isLocalOfflineDraft)
    assertTrue(repo.syncQueue.first().any { it.entityId == offlineSaved.id })

    val offlineSignAttempt = repo.signNote(offlineSaved, clinician, "Margaret Holloway", isOnline = false)
    assertTrue(offlineSignAttempt is ServerSignResult.RejectedOffline)

    val onlineSign = repo.signNote(offlineSaved, clinician, "Margaret Holloway", isOnline = true)
    assertTrue(onlineSign is ServerSignResult.Accepted)
    val signedNote = (onlineSign as ServerSignResult.Accepted).updatedNote
    assertEquals(NoteStatus.SIGNED, signedNote.status)
    assertFalse(signedNote.isLocalOfflineDraft)

    repo.addAddendum(signedNote, "Post-clinic echo slot confirmed", "Echo booked for Friday.", clinician, "Margaret Holloway")
    val amendedNote = repo.clinicalNotes.first().first { it.id == signedNote.id }
    assertEquals(NoteStatus.AMENDED, amendedNote.status)
    assertEquals(1, repo.noteAddenda.first().count { it.noteId == signedNote.id })
    assertTrue(repo.noteVersions.first().count { it.noteId == signedNote.id } >= 2)

    repo.markNoteEnteredInError(amendedNote, "Wrong encounter date selected", clinician, "Margaret Holloway")
    val errNote = repo.clinicalNotes.first().first { it.id == signedNote.id }
    assertEquals(NoteStatus.ENTERED_IN_ERROR, errNote.status)
    assertEquals("Wrong encounter date selected", errNote.enteredInErrorReason)
  }

  @Test
  fun `concurrent editing conflict blocks signing until explicitly resolved`() = runTest {
    repo.ensureSeeded()
    val clinician = SyntheticClinicalSeed.clinicianAccounts.first()
    val note = repo.clinicalNotes.first().first { it.id == "note_02" }
    assertTrue(note.hasConflict)

    val blocked = repo.signNote(note, clinician, "Priya Sharma", isOnline = true)
    assertTrue(blocked is ServerSignResult.ConflictDetected)

    val resolved = repo.resolveNoteConflict(note, "MERGE_BOTH", clinician, "Priya Sharma")
    assertFalse(resolved.hasConflict)
    assertTrue(resolved.freeText.contains("Merged Remote Edit"))

    val signedAfterMerge = repo.signNote(resolved, clinician, "Priya Sharma", isOnline = true)
    assertTrue(signedAfterMerge is ServerSignResult.Accepted)
  }

  @Test
  fun `lab result review separates viewed acknowledged and action completed states`() = runTest {
    repo.ensureSeeded()
    val clinician = SyntheticClinicalSeed.clinicianAccounts.first()
    val correctedK = repo.labResults.first().first { it.id == "lab_04" }
    assertEquals(LabReportStatus.CORRECTED, correctedK.reportStatus)
    assertEquals(ResultReviewState.UNVIEWED, correctedK.reviewState)

    val viewed = repo.transitionLabResultState(correctedK, ResultReviewState.VIEWED, clinician, "Priya Sharma")
    assertEquals(ResultReviewState.VIEWED, viewed.reviewState)
    assertNull(viewed.acknowledgedAt)

    val acknowledged = repo.transitionLabResultState(viewed, ResultReviewState.ACKNOWLEDGED, clinician, "Priya Sharma")
    assertEquals(ResultReviewState.ACKNOWLEDGED, acknowledged.reviewState)
    assertNotNull(acknowledged.acknowledgedAt)
    assertNull(acknowledged.actionCompletedAt)

    val completed = repo.transitionLabResultState(acknowledged, ResultReviewState.ACTION_COMPLETED, clinician, "Priya Sharma")
    assertEquals(ResultReviewState.ACTION_COMPLETED, completed.reviewState)
    assertNotNull(completed.actionCompletedAt)
  }

  @Test
  fun `patient identity resolution, sync flush, and audit history work end to end`() = runTest {
    repo.ensureSeeded()
    val clinician = SyntheticClinicalSeed.clinicianAccounts.first()
    val uncertain = repo.patients.first().first { it.id == "pat_05" }
    assertEquals(IdentityVerificationStatus.UNCERTAIN_IDENTITY, uncertain.identityStatus)

    val verified = repo.resolveUncertainIdentity(uncertain, clinician)
    assertEquals(IdentityVerificationStatus.VERIFIED, verified.identityStatus)

    repo.flushSyncQueue(repo.patients.first(), repo.clinicalNotes.first(), clinician)
    val audits = repo.auditEvents.first()
    assertTrue(audits.any { it.actionType == "PATIENT_IDENTITY_RESOLVED" })
    assertTrue(audits.any { it.actionType == "BACKGROUND_SYNC_COMPLETED" })
  }

  @Test
  fun `ai assistant blocks external transmission when org approval is disabled`() = runTest {
    repo.ensureSeeded()
    val patient = repo.patients.first().first { it.id == "pat_01" }
    val allergies = repo.allergies.first().filter { it.patientId == "pat_01" }
    val meds = repo.medications.first().filter { it.patientId == "pat_01" }
    val labs = repo.labResults.first().filter { it.patientId == "pat_01" }
    val tasks = repo.tasks.first().filter { it.patientId == "pat_01" }

    val assistant = com.example.data.ai.ClinicalAiAssistant()
    val res =
      assistant.generateProposal(
        task = com.example.data.ai.AiAssistTask.RECORD_SUMMARY,
        patient = patient,
        allergies = allergies,
        medications = meds,
        results = labs,
        activeNote = null,
        tasks = tasks,
        orgAiApprovalEnabled = false,
        isOnline = true,
      )
    assertTrue(res.isSuccess)
    val proposal = res.getOrThrow()
    assertFalse(proposal.usedExternalModel)
    assertTrue(proposal.statements.any { it.supportingRecordRef != null })
  }

  @Test
  fun `identity adapter rejects wrong pin and appointments adapter filters by authorised service`() = runTest {
    repo.ensureSeeded()
    assertNull(repo.identityAdapter.signIn("doc_vance", "9999"))
    val npSession = repo.identityAdapter.signIn("np_bennett", "1234")!!
    val scopedAppts =
      repo.appointmentsAdapter.filterAppointments(
        appointments = repo.appointments.first(),
        session = npSession,
        serviceFilter = null,
        clinicianFilter = null,
      )
    assertEquals(1, scopedAppts.size)
    assertEquals("pat_06", scopedAppts.first().patientId)
  }
}
