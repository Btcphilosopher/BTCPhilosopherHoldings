package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.firebase.configureAppCheck
import com.example.ui.screens.ClinicalWorkspaceApp
import com.example.ui.theme.NhsClinicalTheme
import com.example.ui.viewmodel.ClinicalWorkspaceViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)

    // Configure Firebase App Check with launch intent before Compose UI or ViewModels
    configureAppCheck(this, intent)

    enableEdgeToEdge()
    setContent {
      NhsClinicalTheme(darkTheme = false) {
        val workspaceViewModel: ClinicalWorkspaceViewModel = viewModel()
        ClinicalWorkspaceApp(viewModel = workspaceViewModel)
      }
    }
  }
}
