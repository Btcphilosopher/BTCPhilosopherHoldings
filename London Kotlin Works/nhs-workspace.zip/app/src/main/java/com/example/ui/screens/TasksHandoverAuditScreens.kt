package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.ui.components.StatusPill
import com.example.ui.theme.*

@Composable
fun TasksHandoverMessagesScreen(
  patient: PatientRecord,
  tasks: List<ClinicalTask>,
  handover: HandoverSbar?,
  messages: List<TeamMessage>,
  onCreateTask: (String, String, String, TaskPriority, String, String) -> Unit,
  onCompleteTask: (ClinicalTask, String) -> Unit,
  onSaveSbar: (HandoverSbar) -> Unit,
  onSendMessage: (String, String) -> Unit,
) {
  var showNewTaskDialog by remember { mutableStateOf(false) }
  var taskToComplete by remember { mutableStateOf<ClinicalTask?>(null) }

  var situation by remember(handover, patient.id) {
    mutableStateOf(handover?.situation ?: "${patient.fullName} (${patient.location}): ${patient.presentingProblem}")
  }
  var background by remember(handover, patient.id) {
    mutableStateOf(handover?.background ?: patient.historySummary.ifBlank { "See overview" })
  }
  var assessment by remember(handover, patient.id) {
    mutableStateOf(handover?.assessment ?: "Active assessment in progress.")
  }
  var recommendation by remember(handover, patient.id) {
    mutableStateOf(handover?.recommendation ?: "Follow up outstanding investigations & review symptoms.")
  }

  var recipientTeam by remember { mutableStateOf("Acute Medicine Duty Team") }
  var messageBody by remember { mutableStateOf("") }

  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          "Tasks, SBAR Handover & Team Messaging",
          style = MaterialTheme.typography.headlineMedium,
          modifier = Modifier.semantics { heading() },
        )
        Button(
          onClick = { showNewTaskDialog = true },
          modifier = Modifier.minimumInteractiveComponentSize().testTag("new_task_btn"),
        ) {
          Icon(Icons.Filled.AddTask, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(Modifier.width(6.dp))
          Text("Assign Follow-Up Task")
        }
      }
    }

    // Tasks
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = ClinicalWhite),
        border = BorderStroke(1.dp, ClinicalBorder),
      ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text("Patient-Linked Tasks (${tasks.size})", style = MaterialTheme.typography.titleLarge)
          if (tasks.isEmpty()) {
            Text("No tasks assigned for ${patient.fullName}.", style = MaterialTheme.typography.bodyMedium, color = ClinicalSecondaryInk)
          } else {
            tasks.forEach { task ->
              Surface(
                color = NhsIceSurface,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, ClinicalBorder),
                modifier = Modifier.fillMaxWidth().testTag("task_card_${task.id}"),
              ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Text(task.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    StatusPill(
                      text = "${task.priority.label} • ${task.status.label}",
                      icon = if (task.status == TaskStatus.COMPLETED) Icons.Filled.CheckCircle else Icons.Filled.Schedule,
                      containerColor = if (task.status == TaskStatus.COMPLETED) NhsGreenTint else NhsAmberTint,
                      contentColor = if (task.status == TaskStatus.COMPLETED) NhsGreen else NhsAmber,
                    )
                  }
                  Text("Owner: ${task.ownerName} (${task.ownerRole}) • Due: ${task.dueTime}", style = MaterialTheme.typography.bodySmall, color = ClinicalSecondaryInk)
                  Text("Context: ${task.supportingContext}", style = MaterialTheme.typography.bodyMedium)
                  if (task.completionEvidence != null) {
                    Text("Completion Evidence: ${task.completionEvidence}", style = MaterialTheme.typography.bodySmall, color = NhsGreen)
                  } else {
                    OutlinedButton(
                      onClick = { taskToComplete = task },
                      modifier = Modifier.minimumInteractiveComponentSize(),
                    ) {
                      Text("Record Completion Evidence")
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    // SBAR Handover
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = ClinicalWhite),
        border = BorderStroke(1.dp, ClinicalBorder),
      ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text("Structured SBAR Handover", style = MaterialTheme.typography.titleLarge)
          OutlinedTextField(value = situation, onValueChange = { situation = it }, label = { Text("S — Situation") }, minLines = 2, modifier = Modifier.fillMaxWidth())
          OutlinedTextField(value = background, onValueChange = { background = it }, label = { Text("B — Background") }, minLines = 2, modifier = Modifier.fillMaxWidth())
          OutlinedTextField(value = assessment, onValueChange = { assessment = it }, label = { Text("A — Assessment") }, minLines = 2, modifier = Modifier.fillMaxWidth())
          OutlinedTextField(value = recommendation, onValueChange = { recommendation = it }, label = { Text("R — Recommendation") }, minLines = 2, modifier = Modifier.fillMaxWidth())
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
              onClick = {
                onSaveSbar(
                  HandoverSbar(
                    id = handover?.id ?: "sbar_${patient.id}",
                    patientId = patient.id,
                    situation = situation,
                    background = background,
                    assessment = assessment,
                    recommendation = recommendation,
                    authorName = "",
                    updatedAt = "",
                    acknowledgedBy = handover?.acknowledgedBy,
                  )
                )
              },
              modifier = Modifier.minimumInteractiveComponentSize().testTag("save_sbar_btn"),
            ) {
              Text("Save SBAR Handover")
            }
          }
        }
      }
    }

    // Secure Team Messages + Separate Urgent Escalation Warning
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = ClinicalWhite),
        border = BorderStroke(1.dp, ClinicalBorder),
      ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text("Secure Team Messages", style = MaterialTheme.typography.titleLarge)
          Surface(color = NhsRedTint, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Filled.PhoneInTalk, contentDescription = null, tint = NhsRed)
              Text(
                "Clinical Escalation Pathway: Sending a team message does NOT transfer urgent clinical responsibility. For acute deterioration, call Crash / Medical Registrar Bleep #4422 directly.",
                style = MaterialTheme.typography.bodySmall,
                color = NhsRed,
              )
            }
          }
          messages.forEach { m ->
            Surface(color = NhsIceSurface, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
              Column(Modifier.padding(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text("${m.senderName} -> ${m.recipientTeam}", style = MaterialTheme.typography.labelLarge)
                  StatusPill(m.deliveryState.label, Icons.Outlined.DoneAll, NhsPaleBlue, NhsDarkBlue)
                }
                Text(m.body, style = MaterialTheme.typography.bodyMedium)
                Text(m.timestamp, style = MaterialTheme.typography.labelSmall, color = ClinicalSecondaryInk)
              }
            }
          }
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
              value = messageBody,
              onValueChange = { messageBody = it },
              label = { Text("Send non-urgent team message to $recipientTeam") },
              modifier = Modifier.weight(1f),
            )
            Button(
              onClick = {
                onSendMessage(recipientTeam, messageBody)
                messageBody = ""
              },
              enabled = messageBody.isNotBlank(),
              modifier = Modifier.minimumInteractiveComponentSize(),
            ) {
              Text("Send")
            }
          }
        }
      }
    }
  }

  if (showNewTaskDialog) {
    var title by remember { mutableStateOf("Arrange Repeat U&Es and Echo Follow-Up") }
    var owner by remember { mutableStateOf("Dr Tariq Mahmood") }
    var role by remember { mutableStateOf("Medical Registrar") }
    var due by remember { mutableStateOf("Within 48 hours") }
    var context by remember { mutableStateOf("Linked to outpatient consultation & result review.") }
    var priority by remember { mutableStateOf(TaskPriority.URGENT) }

    AlertDialog(
      onDismissRequest = { showNewTaskDialog = false },
      title = { Text("Assign Patient-Linked Task") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Task Title") }, modifier = Modifier.testTag("task_title_input"))
          OutlinedTextField(value = owner, onValueChange = { owner = it }, label = { Text("Owner Name") })
          OutlinedTextField(value = role, onValueChange = { role = it }, label = { Text("Owner Role") })
          OutlinedTextField(value = due, onValueChange = { due = it }, label = { Text("Due Time") })
          OutlinedTextField(value = context, onValueChange = { context = it }, label = { Text("Supporting Context") })
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            TaskPriority.entries.forEach { p ->
              FilterChip(selected = priority == p, onClick = { priority = p }, label = { Text(p.label) })
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            onCreateTask(title, owner, role, priority, due, context)
            showNewTaskDialog = false
          },
          enabled = title.isNotBlank() && owner.isNotBlank(),
          modifier = Modifier.testTag("confirm_create_task_btn"),
        ) {
          Text("Assign Task")
        }
      },
      dismissButton = { OutlinedButton(onClick = { showNewTaskDialog = false }) { Text("Cancel") } },
    )
  }

  taskToComplete?.let { t ->
    var evidence by remember { mutableStateOf("Reviewed and documented in chart") }
    AlertDialog(
      onDismissRequest = { taskToComplete = null },
      title = { Text("Complete Task") },
      text = {
        OutlinedTextField(
          value = evidence,
          onValueChange = { evidence = it },
          label = { Text("Completion Evidence") },
        )
      },
      confirmButton = {
        Button(
          onClick = {
            onCompleteTask(t, evidence)
            taskToComplete = null
          },
          enabled = evidence.isNotBlank(),
        ) {
          Text("Mark Completed")
        }
      },
      dismissButton = { OutlinedButton(onClick = { taskToComplete = null }) { Text("Cancel") } },
    )
  }
}

@Composable
fun AuditHistoryScreen(
  auditEvents: List<AuditEvent>,
) {
  var filterText by remember { mutableStateOf("") }
  val filtered =
    remember(auditEvents, filterText) {
      val q = filterText.trim()
      if (q.isEmpty()) auditEvents
      else {
        auditEvents.filter {
          it.actionType.contains(q, ignoreCase = true) ||
            it.patientName.contains(q, ignoreCase = true) ||
            it.actorName.contains(q, ignoreCase = true) ||
            it.detail.contains(q, ignoreCase = true)
        }
      }
    }

  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    item {
      Text(
        "Immutable Clinical Audit History (${filtered.size})",
        style = MaterialTheme.typography.headlineMedium,
        modifier = Modifier.semantics { heading() },
      )
      Text(
        "Tracks record access, edits, signing, amendments, break-glass overrides, AI review, and sync events.",
        style = MaterialTheme.typography.bodySmall,
        color = ClinicalSecondaryInk,
      )
      Spacer(Modifier.height(8.dp))
      OutlinedTextField(
        value = filterText,
        onValueChange = { filterText = it },
        label = { Text("Filter audit events by action, patient, or clinician") },
        leadingIcon = { Icon(Icons.Filled.FilterList, contentDescription = null) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("audit_filter_input"),
      )
    }

    items(filtered, key = { it.id }) { event ->
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = if (event.isBreakGlass) NhsRedTint else ClinicalWhite),
        border = BorderStroke(1.dp, if (event.isBreakGlass) NhsRed else ClinicalBorder),
        modifier = Modifier.fillMaxWidth().testTag("audit_event_${event.id}"),
      ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text("${event.actionType} • ${event.patientName}", style = MaterialTheme.typography.titleMedium)
            StatusPill(
              text = event.outcome,
              icon = if (event.isBreakGlass) Icons.Filled.GppMaybe else Icons.Outlined.History,
              containerColor = if (event.isBreakGlass) NhsRedTint else NhsPaleBlue,
              contentColor = if (event.isBreakGlass) NhsRed else NhsDarkBlue,
            )
          }
          Text("${event.actorName} (${event.actorRole}) • ${event.timestamp}", style = MaterialTheme.typography.labelSmall, color = ClinicalSecondaryInk)
          Text("${event.resourceSummary} — ${event.detail}", style = MaterialTheme.typography.bodySmall)
        }
      }
    }
  }
}
