package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
  entities =
    [
      PatientEntity::class,
      AppointmentEntity::class,
      AllergyEntity::class,
      ProblemEntity::class,
      EncounterEntity::class,
      MedicationEntity::class,
      ObservationEntity::class,
      LabResultEntity::class,
      ClinicalNoteEntity::class,
      NoteVersionEntity::class,
      NoteAddendumEntity::class,
      CarePlanEntity::class,
      ClinicalTaskEntity::class,
      HandoverSbarEntity::class,
      TeamMessageEntity::class,
      BodyStrokeEntity::class,
      ConsultationToolEntity::class,
      AuditEventEntity::class,
      SyncQueueEntity::class,
    ],
  version = 1,
  exportSchema = false,
)
@TypeConverters(ClinicalTypeConverters::class)
abstract class ClinicalDatabase : RoomDatabase() {
  abstract fun clinicalDao(): ClinicalDao

  companion object {
    @Volatile private var INSTANCE: ClinicalDatabase? = null

    fun getInstance(context: Context): ClinicalDatabase {
      return INSTANCE
        ?: synchronized(this) {
          INSTANCE
            ?: Room.databaseBuilder(
                context.applicationContext,
                ClinicalDatabase::class.java,
                "nhs_clinical_workspace.db",
              )
              .fallbackToDestructiveMigration()
              .build()
              .also { INSTANCE = it }
        }
    }
  }
}
