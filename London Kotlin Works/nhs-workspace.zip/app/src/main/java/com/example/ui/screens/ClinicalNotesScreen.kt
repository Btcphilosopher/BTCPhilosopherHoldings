package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.ui.components.StatusPill
import com.example.ui.theme.*

@Composable
fun ClinicalNotesScreen(
  patient: PatientRecord,
  notesForPatient: List<ClinicalNote>,
  activeNote: ClinicalNote?,
  versionsForActive: List<NoteVersion>,
  addendaForActive: List<NoteAddendum>,
  autosaveStatusLabel: String,
  isOnline: Boolean,
  onSelectTemplate: (NoteTemplateType) -> Unit,
  onSelectExistingNote: (ClinicalNote) -> Unit,
  onUpdateDraft: ((ClinicalNote) -> ClinicalNote) -> Unit,
  onSaveDraftNow: () -> Unit,
  onCarryForward: (ClinicalNote) -> Unit,
  onRequestSign: (ClinicalNote) -> Unit,
  onSimulateConflict: () -> Unit,
  onResolveConflict: (ClinicalNote, String) -> Unit,
  onAddAddendum: (ClinicalNote, String, String) -> Unit,
  onMarkEnteredInError: (ClinicalNote, String) -> Unit,
) {
  var showPreviewDialog by remember { mutableStateOf(false) }
  var showAddendumDialog by remember { mutableStateOf(false) }
  var showErrorMarkDialog by remember { mutableStateOf(false) }
  var showVersionHistory by remember { mutableStateOf(false) }

  val signedPriorNotes =
    remember(notesForPatient) {
      notesForPatient.filter { it.status == NoteStatus.SIGNED || it.status == NoteStatus.AMENDED }
    }

  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column {
          Text(
            "Clinical Documentation",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.semantics { heading() },
          )
          Text(
            "Autosave: $autosaveStatusLabel • Author & Encounter ${patient.encounterId} attributed",
            style = MaterialTheme.typography.bodySmall,
            color = ClinicalSecondaryInk,
          )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          if (activeNote != null && activeNote.status == NoteStatus.DRAFT) {
            OutlinedButton(
              onClick = onSimulateConflict,
              modifier = Modifier.minimumInteractiveComponentSize().testTag("simulate_conflict_btn"),
            ) {
              Icon(Icons.Outlined.MergeType, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(Modifier.width(4.dp))
              Text("Simulate Edit Conflict")
            }
          }
          OutlinedButton(
            onClick = { showVersionHistory = !showVersionHistory },
            modifier = Modifier.minimumInteractiveComponentSize(),
          ) {
            Icon(Icons.Outlined.History, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text("History (${versionsForActive.size})")
          }
        }
      }
    }

    // Template Selector Bar
    item {
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = ClinicalWhite),
        border = BorderStroke(1.dp, ClinicalBorder),
      ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("New / Switch Configurable Note Template:", style = MaterialTheme.typography.labelLarge)
          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            NoteTemplateType.entries.forEach { tmpl ->
              FilterChip(
                selected = activeNote?.templateType == tmpl,
                onClick = { onSelectTemplate(tmpl) },
                label = { Text(tmpl.label) },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("template_${tmpl.name}"),
              )
            }
          }

          if (notesForPatient.isNotEmpty()) {
            Text("Existing Notes for ${patient.fullName}:", style = MaterialTheme.typography.labelMedium, color = ClinicalSecondaryInk)
            Row(
              modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              notesForPatient.forEach { n ->
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = if (activeNote?.id == n.id) NhsPaleBlue else NhsIceSurface,
                  border = BorderStroke(1.dp, if (activeNote?.id == n.id) NhsBlue else ClinicalBorder),
                  modifier =
                    Modifier.minimumInteractiveComponentSize()
                      .clickable { onSelectExistingNote(n) }
                      .testTag("existing_note_${n.id}"),
                ) {
                  Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Text("${n.templateType.label} (${n.status.label})", style = MaterialTheme.typography.labelLarge)
                    Text("v${n.serverVersion} • ${n.authorName} • ${n.updatedAt}", style = MaterialTheme.typography.labelSmall, color = ClinicalSecondaryInk)
                  }
                }
              }
            }
          }
        }
      }
    }

    if (activeNote == null) {
      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = ClinicalWhite),
          border = BorderStroke(1.dp, ClinicalBorder),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(
            Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Icon(Icons.Outlined.Description, contentDescription = null, tint = NhsBlue, modifier = Modifier.size(36.dp))
            Text("Select a note template above or open an existing note to begin documentation.", style = MaterialTheme.typography.bodyLarge)
            Button(
              onClick = { onSelectTemplate(NoteTemplateType.CONSULTATION) },
              modifier = Modifier.testTag("start_consultation_note_btn"),
            ) {
              Text("Start Consultation Note")
            }
          }
        }
      }
    } else {
      // Conflict Resolution Card
      if (activeNote.hasConflict) {
        item {
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = NhsRedTint),
            border = BorderStroke(1.5.dp, NhsRed),
            modifier = Modifier.fillMaxWidth().testTag("conflict_resolution_panel"),
          ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.Warning, contentDescription = null, tint = NhsRed)
                Text("Simultaneous Editing Conflict Detected", style = MaterialTheme.typography.titleMedium, color = NhsRed)
              }
              Text(
                "Another clinician (${activeNote.remoteConflictEditor ?: "Remote Clinician"}) saved a newer version on the server. Resolve explicitly — neither version will be silently overwritten.",
                style = MaterialTheme.typography.bodyMedium,
              )
              Surface(color = ClinicalWhite, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                  Text("Remote Server Version:", style = MaterialTheme.typography.labelLarge, color = NhsDarkBlue)
                  Text(activeNote.remoteConflictSummary.orEmpty(), style = MaterialTheme.typography.bodySmall)
                }
              }
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                  onClick = { onResolveConflict(activeNote, "MERGE_BOTH") },
                  modifier = Modifier.testTag("resolve_conflict_merge_btn"),
                ) {
                  Text("Merge Both Safely")
                }
                OutlinedButton(onClick = { onResolveConflict(activeNote, "KEEP_MINE") }) {
                  Text("Keep Mine")
                }
                OutlinedButton(onClick = { onResolveConflict(activeNote, "ACCEPT_REMOTE") }) {
                  Text("Accept Remote")
                }
              }
            }
          }
        }
      }

      // Active Note Editor / Immutable Viewer
      item {
        val isEditable = activeNote.status == NoteStatus.DRAFT
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = ClinicalWhite),
          border = BorderStroke(1.dp, ClinicalBorder),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column {
                Text("${activeNote.templateType.label} — v${activeNote.serverVersion}", style = MaterialTheme.typography.titleLarge)
                Text(
                  "Author: ${activeNote.authorName} • Encounter: ${activeNote.encounterId} • Updated: ${activeNote.updatedAt}",
                  style = MaterialTheme.typography.bodySmall,
                  color = ClinicalSecondaryInk,
                )
              }
              Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                StatusPill(
                  text = activeNote.status.label,
                  icon =
                    when (activeNote.status) {
                      NoteStatus.DRAFT -> Icons.Filled.Edit
                      NoteStatus.SIGNED -> Icons.Filled.Lock
                      NoteStatus.AMENDED -> Icons.Filled.PostAdd
                      NoteStatus.ENTERED_IN_ERROR -> Icons.Filled.Cancel
                    },
                  containerColor =
                    when (activeNote.status) {
                      NoteStatus.DRAFT -> NhsPaleBlue
                      NoteStatus.SIGNED -> NhsGreenTint
                      NoteStatus.AMENDED -> NhsPurpleTint
                      NoteStatus.ENTERED_IN_ERROR -> NhsRedTint
                    },
                  contentColor =
                    when (activeNote.status) {
                      NoteStatus.DRAFT -> NhsDarkBlue
                      NoteStatus.SIGNED -> NhsGreen
                      NoteStatus.AMENDED -> NhsPurple
                      NoteStatus.ENTERED_IN_ERROR -> NhsRed
                    },
                )
                if (activeNote.isLocalOfflineDraft) {
                  StatusPill("Offline Local Draft", Icons.Filled.CloudOff, NhsAmberTint, NhsAmber)
                }
              }
            }

            if (activeNote.enteredInErrorReason != null) {
              Surface(color = NhsRedTint, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                Text(
                  "ENTERED IN ERROR (Record preserved for audit): ${activeNote.enteredInErrorReason}",
                  style = MaterialTheme.typography.labelLarge,
                  color = NhsRed,
                  modifier = Modifier.padding(10.dp),
                )
              }
            }

            if (activeNote.carriedForwardAttribution != null) {
              StatusPill(
                text = "Attributed Import: ${activeNote.carriedForwardAttribution}",
                icon = Icons.Outlined.ContentPaste,
                containerColor = NhsAmberTint,
                contentColor = NhsAmber,
              )
            }

            if (isEditable && signedPriorNotes.isNotEmpty()) {
              OutlinedButton(
                onClick = { onCarryForward(signedPriorNotes.first()) },
                modifier = Modifier.minimumInteractiveComponentSize(),
              ) {
                Icon(Icons.Outlined.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Carry Forward Signed Assessment (With Attribution)")
              }
            }

            OutlinedTextField(
              value = activeNote.historyText,
              onValueChange = { v -> onUpdateDraft { it.copy(historyText = v) } },
              label = { Text("History") },
              readOnly = !isEditable,
              minLines = 2,
              modifier = Modifier.fillMaxWidth().testTag("note_history_input"),
            )
            OutlinedTextField(
              value = activeNote.examinationText,
              onValueChange = { v -> onUpdateDraft { it.copy(examinationText = v) } },
              label = { Text("Examination") },
              readOnly = !isEditable,
              minLines = 2,
              modifier = Modifier.fillMaxWidth().testTag("note_exam_input"),
            )
            OutlinedTextField(
              value = activeNote.assessmentText,
              onValueChange = { v -> onUpdateDraft { it.copy(assessmentText = v) } },
              label = { Text("Assessment") },
              readOnly = !isEditable,
              minLines = 2,
              modifier = Modifier.fillMaxWidth().testTag("note_assessment_input"),
            )
            OutlinedTextField(
              value = activeNote.planText,
              onValueChange = { v -> onUpdateDraft { it.copy(planText = v) } },
              label = { Text("Plan") },
              readOnly = !isEditable,
              minLines = 3,
              modifier = Modifier.fillMaxWidth().testTag("note_plan_input"),
            )
            OutlinedTextField(
              value = activeNote.specialtyExtraText,
              onValueChange = { v -> onUpdateDraft { it.copy(specialtyExtraText = v) } },
              label = { Text(activeNote.templateType.extraFieldTitle) },
              readOnly = !isEditable,
              minLines = 2,
              modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
              value = activeNote.freeText,
              onValueChange = { v -> onUpdateDraft { it.copy(freeText = v) } },
              label = { Text("Additional Clinical Free Text") },
              readOnly = !isEditable,
              minLines = 2,
              modifier = Modifier.fillMaxWidth().testTag("note_freetext_input"),
            )

            // Action Buttons
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              if (isEditable) {
                OutlinedButton(
                  onClick = onSaveDraftNow,
                  modifier = Modifier.minimumInteractiveComponentSize().testTag("save_draft_btn"),
                ) {
                  Icon(Icons.Outlined.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                  Spacer(Modifier.width(6.dp))
                  Text("Save Draft")
                }
                Button(
                  onClick = { showPreviewDialog = true },
                  enabled = !activeNote.hasConflict,
                  modifier = Modifier.minimumInteractiveComponentSize().testTag("preview_and_sign_btn"),
                ) {
                  Icon(Icons.Filled.Preview, contentDescription = null, modifier = Modifier.size(18.dp))
                  Spacer(Modifier.width(6.dp))
                  Text(if (isOnline) "Preview & Sign" else "Preview (Sign Requires Online)")
                }
              } else if (activeNote.status == NoteStatus.SIGNED || activeNote.status == NoteStatus.AMENDED) {
                Button(
                  onClick = { showAddendumDialog = true },
                  modifier = Modifier.minimumInteractiveComponentSize().testTag("add_addendum_btn"),
                ) {
                  Icon(Icons.Filled.PostAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                  Spacer(Modifier.width(6.dp))
                  Text("Add Linked Addendum")
                }
                OutlinedButton(
                  onClick = { showErrorMarkDialog = true },
                  colors = ButtonDefaults.outlinedButtonColors(contentColor = NhsRed),
                  modifier = Modifier.minimumInteractiveComponentSize().testTag("mark_entered_in_error_btn"),
                ) {
                  Text("Mark Entered-in-Error")
                }
              }
            }
          }
        }
      }

      // Linked Addenda
      if (addendaForActive.isNotEmpty()) {
        item {
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = NhsPurpleTint),
            border = BorderStroke(1.dp, NhsPurple.copy(alpha = 0.3f)),
          ) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Text("Linked Addenda (Original Signed Note Preserved)", style = MaterialTheme.typography.titleMedium, color = NhsPurple)
              addendaForActive.forEach { add ->
                Surface(color = ClinicalWhite, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                  Column(Modifier.padding(10.dp)) {
                    Text("${add.reason} — ${add.authorName} (${add.timestamp})", style = MaterialTheme.typography.labelLarge)
                    Text(add.text, style = MaterialTheme.typography.bodyMedium)
                  }
                }
              }
            }
          }
        }
      }

      // Version History
      if (showVersionHistory) {
        item {
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = ClinicalWhite),
            border = BorderStroke(1.dp, ClinicalBorder),
          ) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Text("Note Version History", style = MaterialTheme.typography.titleMedium)
              versionsForActive.forEach { ver ->
                Text(
                  "v${ver.versionNumber} [${ver.status.label}] • ${ver.editorName} • ${ver.timestamp}\n${ver.changeSummary}: ${ver.snapshotText}",
                  style = MaterialTheme.typography.bodySmall,
                )
                HorizontalDivider(color = ClinicalBorder)
              }
            }
          }
        }
      }
    }
  }

  if (showPreviewDialog && activeNote != null) {
    AlertDialog(
      onDismissRequest = { showPreviewDialog = false },
      title = { Text("Preview Before Signing — ${activeNote.templateType.label}") },
      text = {
        Column(
          modifier = Modifier.verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Text("Patient: ${patient.fullName} (NHS ${patient.nhsNumber})", style = MaterialTheme.typography.labelLarge, color = NhsDarkBlue)
          Text("Author: ${activeNote.authorName} • Encounter: ${activeNote.encounterId}", style = MaterialTheme.typography.bodySmall)
          HorizontalDivider()
          Text("History:\n${activeNote.historyText}", style = MaterialTheme.typography.bodyMedium)
          Text("Examination:\n${activeNote.examinationText}", style = MaterialTheme.typography.bodyMedium)
          Text("Assessment:\n${activeNote.assessmentText}", style = MaterialTheme.typography.bodyMedium)
          Text("Plan:\n${activeNote.planText}", style = MaterialTheme.typography.bodyMedium)
          if (activeNote.freeText.isNotBlank()) {
            Text("Additional:\n${activeNote.freeText}", style = MaterialTheme.typography.bodyMedium)
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            showPreviewDialog = false
            onRequestSign(activeNote)
          },
          enabled = isOnline && !activeNote.hasConflict,
          modifier = Modifier.testTag("proceed_to_sign_btn"),
        ) {
          Text(if (isOnline) "Proceed to Patient Confirmation & Sign" else "Offline — Server Required")
        }
      },
      dismissButton = {
        OutlinedButton(onClick = { showPreviewDialog = false }) { Text("Back to Edit") }
      },
    )
  }

  if (showAddendumDialog && activeNote != null) {
    var reason by remember { mutableStateOf("Additional post-clinic clarification") }
    var text by remember { mutableStateOf("") }
    AlertDialog(
      onDismissRequest = { showAddendumDialog = false },
      title = { Text("Add Linked Addendum") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason for Addendum") })
          OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            label = { Text("Addendum text") },
            minLines = 3,
            modifier = Modifier.testTag("addendum_text_input"),
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            onAddAddendum(activeNote, reason, text)
            showAddendumDialog = false
          },
          enabled = text.isNotBlank(),
          modifier = Modifier.testTag("save_addendum_btn"),
        ) {
          Text("Append Addendum")
        }
      },
      dismissButton = { OutlinedButton(onClick = { showAddendumDialog = false }) { Text("Cancel") } },
    )
  }

  if (showErrorMarkDialog && activeNote != null) {
    var reason by remember { mutableStateOf("") }
    AlertDialog(
      onDismissRequest = { showErrorMarkDialog = false },
      title = { Text("Mark Note as Entered-in-Error") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("The original signed record will remain visible in audit history with an Entered-in-Error banner.")
          OutlinedTextField(
            value = reason,
            onValueChange = { reason = it },
            label = { Text("Reason (mandatory)") },
            modifier = Modifier.testTag("entered_in_error_reason_input"),
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            onMarkEnteredInError(activeNote, reason)
            showErrorMarkDialog = false
          },
          enabled = reason.trim().length >= 4,
          colors = ButtonDefaults.buttonColors(containerColor = NhsRed),
          modifier = Modifier.testTag("confirm_entered_in_error_btn"),
        ) {
          Text("Confirm Entered-in-Error")
        }
      },
      dismissButton = { OutlinedButton(onClick = { showErrorMarkDialog = false }) { Text("Cancel") } },
    )
  }
}
