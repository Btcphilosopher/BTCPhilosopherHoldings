package com.example.data.model

enum class IdentityVerificationStatus(val label: String) {
  VERIFIED("NHS Number & Demographics Verified"),
  UNVERIFIED_DEMOGRAPHICS("NHS Number Verified • Unverified Demographics"),
  UNCERTAIN_IDENTITY("Uncertain Identity — Verification Required"),
  DUPLICATE_SUSPECTED("Duplicate Record Warning"),
}

enum class AllergyAssessmentState(val label: String) {
  ASSESSED_WITH_REACTIONS("Allergies Documented"),
  NO_KNOWN_ALLERGIES("No Known Allergies (Assessed)"),
  NOT_ASSESSED("Allergy Status: Not Assessed"),
  INFORMATION_UNAVAILABLE("Allergy Status: Information Unavailable"),
}

enum class RecordAvailabilityState(val label: String) {
  DOCUMENTED("Documented"),
  NOT_ASSESSED("Not Assessed"),
  INFORMATION_UNAVAILABLE("Information Unavailable"),
}

enum class MedicationCategory(val label: String) {
  PRESCRIBED("Prescribed"),
  PATIENT_REPORTED("Patient-Reported"),
  DISPENSED("Dispensed (Community/Pharmacy)"),
  ADMINISTERED("Inpatient Administration (ePMA)"),
}

enum class ReconciliationStatus(val label: String) {
  RECONCILED("Reconciled"),
  DISCREPANCY("Discrepancy Identified"),
  UNRECONCILED("Awaiting Reconciliation"),
}

enum class LabReportStatus(val label: String) {
  PRELIMINARY("Preliminary"),
  FINAL("Final"),
  CORRECTED("Corrected"),
}

enum class LabCriticalFlag(val label: String) {
  NORMAL("Within Reference Interval"),
  ABNORMAL_HIGH("Above Reference Interval"),
  ABNORMAL_LOW("Below Reference Interval"),
  CRITICAL("Critical Flag (Lab Supplied)"),
  CORRECTED("Corrected Result — Review Required"),
}

enum class ResultReviewState(val label: String) {
  UNVIEWED("Unviewed"),
  VIEWED("Viewed"),
  ACKNOWLEDGED("Acknowledged (Action Outstanding)"),
  ACTION_COMPLETED("Action Completed"),
}

enum class NoteTemplateType(val label: String, val extraFieldTitle: String) {
  CONSULTATION("Outpatient Consultation", "Reason for Referral & Differential"),
  WARD_ROUND("Ward Round Review", "NEWS2 / Ward Safety Check & Escalation Plan"),
  ADMISSION("Acute Admission Assessment", "Collateral History & VTE / Sepsis Screen"),
  PROGRESS("Clinical Progress Note", "Interval Events & Pending Investigations"),
  PROCEDURE("Procedure Documentation", "Site, Laterality, Consent & Complications"),
  DISCHARGE("Discharge Summary", "GP Actions, Follow-Up & Red-Flag Advice"),
  HANDOVER("Clinical Handover Note", "SBAR Shift Transfer & Pending Jobs"),
}

enum class NoteStatus(val label: String) {
  DRAFT("Draft (Editable)"),
  SIGNED("Signed (Locked)"),
  AMENDED("Amended (With Addendum)"),
  ENTERED_IN_ERROR("Entered in Error (Preserved)"),
}

enum class TaskPriority(val label: String) {
  ROUTINE("Routine"),
  URGENT("Urgent"),
  STAT("Immediate / Urgent Escalation"),
}

enum class TaskStatus(val label: String) {
  OPEN("Open"),
  IN_PROGRESS("In Progress"),
  COMPLETED("Completed"),
}

enum class MessageDeliveryState(val label: String) {
  SENT("Sent"),
  DELIVERED("Delivered"),
  READ("Read by Recipient"),
}

enum class SyncStatus(val label: String) {
  SYNCED("Synced"),
  PENDING_SERVER_VALIDATION("Pending Server Validation"),
  CONFLICT_DETECTED("Conflict Detected"),
}

enum class WorkspaceModule(val title: String, val shortcutHint: String) {
  HOME("Home & Worklists", "Ctrl+1"),
  PATIENT_SEARCH("Patient Search & Identity", "Ctrl+2"),
  OVERVIEW("Patient Overview", "Ctrl+3"),
  NOTES("Clinical Notes", "Ctrl+4"),
  RESULTS("Observations & Results", "Ctrl+5"),
  MEDICATIONS("Medications & Allergies", "Ctrl+6"),
  CONSULTATION_TOOLS("Consultation Tools", "Ctrl+7"),
  CARE_PLAN("Patient Care Plan", "Ctrl+8"),
  TASKS_HANDOVER("Tasks, SBAR & Team", "Ctrl+9"),
  AUDIT_LOG("Audit History", "Ctrl+0"),
}

enum class InspectorTab(val title: String) {
  RESULTS("Results"),
  MEDS("Meds"),
  NOTES("Prior Notes"),
  AI_ASSISTANT("AI Assistant"),
  DEMO_GUIDE("Demo Guide"),
}

data class ClinicianAccount(
  val id: String,
  val displayName: String,
  val role: String,
  val gmcOrRegistration: String,
  val specialty: String,
  val authorisedServices: List<String>,
  val authorisedWards: List<String>,
  val authorisedClinics: List<String>,
  val identityAdapterLabel: String,
  val demoPin: String,
)

data class ClinicianSession(
  val clinician: ClinicianAccount,
  val signedInAt: Long,
  val isLocked: Boolean = false,
  val breakGlassPatientIds: Set<String> = emptySet(),
  val breakGlassReason: String? = null,
)

data class AppointmentSummary(
  val id: String,
  val patientId: String,
  val patientName: String,
  val timeSlot: String,
  val clinicName: String,
  val service: String,
  val clinicianId: String,
  val reason: String,
  val status: String,
)

data class PatientRecord(
  val id: String,
  val nhsNumber: String,
  val mrn: String,
  val nhsNumberVerified: Boolean,
  val demographicsVerified: Boolean,
  val identityStatus: IdentityVerificationStatus,
  val duplicateCandidateIds: List<String>,
  val fullName: String,
  val preferredName: String,
  val dateOfBirth: String,
  val sex: String,
  val address: String,
  val gpPractice: String,
  val encounterId: String,
  val encounterType: String,
  val location: String,
  val service: String,
  val ward: String,
  val clinic: String,
  val assignedClinicianId: String,
  val allergyStatus: AllergyAssessmentState,
  val recordAlerts: List<String>,
  val presentingProblem: String,
  val historySummary: String,
  val historyStatus: RecordAvailabilityState,
  val medicationHistoryStatus: RecordAvailabilityState,
  val observationsStatus: RecordAvailabilityState,
  val lastSyncedAt: Long,
)

data class AllergyEntry(
  val id: String,
  val patientId: String,
  val substance: String,
  val reaction: String,
  val severity: String,
  val verificationStatus: String,
  val source: String,
  val recordedBy: String,
  val recordedAt: String,
)

data class ProblemEntry(
  val id: String,
  val patientId: String,
  val title: String,
  val code: String,
  val status: String,
  val source: String,
  val author: String,
  val timestamp: String,
)

data class EncounterSummary(
  val id: String,
  val patientId: String,
  val encounterType: String,
  val location: String,
  val clinician: String,
  val dateLabel: String,
  val summary: String,
)

data class MedicationEntry(
  val id: String,
  val patientId: String,
  val drugName: String,
  val strength: String,
  val dose: String,
  val route: String,
  val frequency: String,
  val startDate: String,
  val endDate: String,
  val category: MedicationCategory,
  val prescriptionStatus: String,
  val informationSource: String,
  val reconciliationStatus: ReconciliationStatus,
  val notes: String,
)

data class ObservationPoint(
  val id: String,
  val patientId: String,
  val metricType: String,
  val displayName: String,
  val value: String,
  val numericValue: Double,
  val unit: String,
  val measuredAt: String,
  val provenance: String,
  val isAbnormal: Boolean,
)

data class LabResult(
  val id: String,
  val patientId: String,
  val testName: String,
  val panelName: String,
  val value: String,
  val unit: String,
  val referenceInterval: String,
  val criticalFlag: LabCriticalFlag,
  val requestStatus: String,
  val specimenCollectedAt: String,
  val resultTime: String,
  val reportStatus: LabReportStatus,
  val reviewState: ResultReviewState,
  val acknowledgedBy: String?,
  val acknowledgedAt: String?,
  val actionCompletedBy: String?,
  val actionCompletedAt: String?,
  val followUpOwner: String,
  val linkedTaskId: String?,
  val provenance: String,
  val previousValueIfCorrected: String?,
)

data class ClinicalNote(
  val id: String,
  val patientId: String,
  val encounterId: String,
  val templateType: NoteTemplateType,
  val status: NoteStatus,
  val authorId: String,
  val authorName: String,
  val createdAt: String,
  val updatedAt: String,
  val signedAt: String?,
  val serverVersion: Int,
  val historyText: String,
  val examinationText: String,
  val assessmentText: String,
  val planText: String,
  val specialtyExtraText: String,
  val freeText: String,
  val carriedForwardAttribution: String?,
  val isLocalOfflineDraft: Boolean,
  val hasConflict: Boolean,
  val remoteConflictEditor: String?,
  val remoteConflictSummary: String?,
  val enteredInErrorReason: String?,
)

data class NoteVersion(
  val id: String,
  val noteId: String,
  val versionNumber: Int,
  val status: NoteStatus,
  val editorName: String,
  val timestamp: String,
  val changeSummary: String,
  val snapshotText: String,
)

data class NoteAddendum(
  val id: String,
  val noteId: String,
  val authorName: String,
  val timestamp: String,
  val reason: String,
  val text: String,
)

data class CarePlanItem(
  val id: String,
  val patientId: String,
  val title: String,
  val patientFriendlyExplanation: String,
  val goals: String,
  val warningSigns: String,
  val followUpInstructions: String,
  val approvedByClinician: Boolean,
  val updatedAt: String,
)

data class ClinicalTask(
  val id: String,
  val patientId: String,
  val title: String,
  val ownerName: String,
  val ownerRole: String,
  val priority: TaskPriority,
  val dueTime: String,
  val status: TaskStatus,
  val supportingContext: String,
  val completionEvidence: String?,
  val linkedResultId: String?,
)

data class HandoverSbar(
  val id: String,
  val patientId: String,
  val situation: String,
  val background: String,
  val assessment: String,
  val recommendation: String,
  val authorName: String,
  val updatedAt: String,
  val acknowledgedBy: String?,
)

data class TeamMessage(
  val id: String,
  val patientId: String,
  val senderName: String,
  val senderRole: String,
  val recipientTeam: String,
  val body: String,
  val timestamp: String,
  val deliveryState: MessageDeliveryState,
)

data class BodyAnnotationStroke(
  val id: String,
  val patientId: String,
  val regionLabel: String,
  val pointsSerialized: String,
  val colorHex: Long,
  val strokeWidth: Float,
)

data class ConsultationToolState(
  val patientId: String,
  val consentDocumented: Boolean,
  val consentScope: String,
  val consentClinician: String,
  val consentTimestamp: String,
  val chaperoneName: String,
  val interpreterLanguage: String,
  val interpreterId: String,
  val sharedLeafletTitles: List<String>,
  val clinicalImageAttached: Boolean,
  val imageConsentConfirmed: Boolean,
  val imageAttribution: String,
  val referralDraftSummary: String,
)

data class AuditEvent(
  val id: String,
  val timestamp: String,
  val actorName: String,
  val actorRole: String,
  val actionType: String,
  val patientId: String,
  val patientName: String,
  val resourceSummary: String,
  val outcome: String,
  val isBreakGlass: Boolean,
  val detail: String,
)

data class SyncQueueItem(
  val id: String,
  val entityType: String,
  val entityId: String,
  val patientId: String,
  val summary: String,
  val queuedAt: String,
  val status: SyncStatus,
)

data class AiCitationStatement(
  val statement: String,
  val supportingRecordRef: String?,
  val isUnsupported: Boolean,
)

data class AiAssistantProposal(
  val mode: String,
  val usedExternalModel: Boolean,
  val provenanceNotice: String,
  val statements: List<AiCitationStatement>,
  val rawEditableText: String,
  val extractedTasks: List<String>,
)
