package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isCtrlPressed
import androidx.compose.ui.input.key.isShiftPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.ai.AiAssistTask
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.*

@Composable
fun ClinicalWorkspaceApp(viewModel: ClinicalWorkspaceViewModel) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val patients by viewModel.patients.collectAsStateWithLifecycle()
  val appointments by viewModel.appointments.collectAsStateWithLifecycle()
  val allergies by viewModel.allergies.collectAsStateWithLifecycle()
  val problems by viewModel.problems.collectAsStateWithLifecycle()
  val encounters by viewModel.encounters.collectAsStateWithLifecycle()
  val medications by viewModel.medications.collectAsStateWithLifecycle()
  val observations by viewModel.observations.collectAsStateWithLifecycle()
  val labResults by viewModel.labResults.collectAsStateWithLifecycle()
  val clinicalNotes by viewModel.clinicalNotes.collectAsStateWithLifecycle()
  val noteVersions by viewModel.noteVersions.collectAsStateWithLifecycle()
  val noteAddenda by viewModel.noteAddenda.collectAsStateWithLifecycle()
  val carePlans by viewModel.carePlans.collectAsStateWithLifecycle()
  val tasks by viewModel.tasks.collectAsStateWithLifecycle()
  val handovers by viewModel.handovers.collectAsStateWithLifecycle()
  val messages by viewModel.messages.collectAsStateWithLifecycle()
  val bodyStrokes by viewModel.bodyStrokes.collectAsStateWithLifecycle()
  val consultationTools by viewModel.consultationTools.collectAsStateWithLifecycle()
  val auditEvents by viewModel.auditEvents.collectAsStateWithLifecycle()
  val syncQueue by viewModel.syncQueue.collectAsStateWithLifecycle()

  val session = uiState.session
  if (session == null) {
    SignInScreen(
      accounts = uiState.availableAccounts,
      error = uiState.signInError,
      onSignIn = viewModel::signIn,
    )
    return
  }

  val activePatient = patients.firstOrNull { it.id == uiState.selectedPatientId }

  // System BackHandler for custom module navigation
  if (uiState.activeModule != WorkspaceModule.HOME) {
    BackHandler {
      if (activePatient != null && uiState.activeModule != WorkspaceModule.OVERVIEW) {
        viewModel.setModule(WorkspaceModule.OVERVIEW)
      } else {
        viewModel.setModule(WorkspaceModule.HOME)
      }
    }
  }

  val snackbarHostState = remember { SnackbarHostState() }
  LaunchedEffect(uiState.statusMessage) {
    val msg = uiState.statusMessage
    if (msg != null) {
      snackbarHostState.showSnackbar(msg)
      viewModel.clearStatusMessage()
    }
  }

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(NhsIceSurface)
        .onPreviewKeyEvent { event ->
          if (event.type == KeyEventType.KeyDown && event.isCtrlPressed) {
            when {
              event.isShiftPressed && event.key == Key.L -> {
                viewModel.lockSession()
                true
              }
              event.key == Key.S -> {
                viewModel.saveCurrentDraft("Saved via Ctrl+S shortcut")
                true
              }
              event.key == Key.One -> {
                viewModel.setModule(WorkspaceModule.HOME)
                true
              }
              event.key == Key.Two -> {
                viewModel.setModule(WorkspaceModule.PATIENT_SEARCH)
                true
              }
              event.key == Key.Three && activePatient != null -> {
                viewModel.setModule(WorkspaceModule.OVERVIEW)
                true
              }
              event.key == Key.Four && activePatient != null -> {
                viewModel.setModule(WorkspaceModule.NOTES)
                true
              }
              event.key == Key.Five && activePatient != null -> {
                viewModel.setModule(WorkspaceModule.RESULTS)
                true
              }
              event.key == Key.Six && activePatient != null -> {
                viewModel.setModule(WorkspaceModule.MEDICATIONS)
                true
              }
              event.key == Key.Seven && activePatient != null -> {
                viewModel.setModule(WorkspaceModule.CONSULTATION_TOOLS)
                true
              }
              event.key == Key.Eight && activePatient != null -> {
                viewModel.setModule(WorkspaceModule.CARE_PLAN)
                true
              }
              event.key == Key.Nine && activePatient != null -> {
                viewModel.setModule(WorkspaceModule.TASKS_HANDOVER)
                true
              }
              event.key == Key.Zero -> {
                viewModel.setModule(WorkspaceModule.AUDIT_LOG)
                true
              }
              else -> false
            }
          } else false
        }
  ) {
    Scaffold(
      snackbarHost = { SnackbarHost(snackbarHostState) },
      containerColor = NhsIceSurface,
      contentWindowInsets = WindowInsets.safeDrawing,
    ) { innerPadding ->
      Column(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
        PrototypeNoticeBar(
          isOnline = uiState.isOnline,
          lastSyncLabel = uiState.lastWorkspaceSyncLabel,
          pendingSyncCount = syncQueue.size,
          concealNotifications = uiState.concealNotifications,
          onToggleOnline = viewModel::toggleOnlineMode,
          onSyncNow = viewModel::syncNow,
          onToggleInspector = viewModel::toggleInspector,
          onLockSession = viewModel::lockSession,
        )

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
          val isWideTablet = maxWidth >= 960.dp
          val isMediumTablet = maxWidth in 600.dp..959.dp

          if (isWideTablet || isMediumTablet) {
            Row(modifier = Modifier.fillMaxSize()) {
              if (isWideTablet) {
                WorkspaceSidebar(
                  session = session,
                  activeModule = uiState.activeModule,
                  hasActivePatient = activePatient != null,
                  reducedMotion = uiState.reducedMotion,
                  concealNotifications = uiState.concealNotifications,
                  onSelectModule = viewModel::setModule,
                  onToggleReducedMotion = viewModel::toggleReducedMotion,
                  onToggleNotificationPrivacy = viewModel::toggleNotificationPrivacy,
                  onSignOut = viewModel::signOut,
                )
              } else {
                WorkspaceNavigationRail(
                  activeModule = uiState.activeModule,
                  hasActivePatient = activePatient != null,
                  onSelectModule = viewModel::setModule,
                  onSignOut = viewModel::signOut,
                )
              }

              // Center Patient Workspace
              Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
                if (activePatient != null) {
                  PersistentPatientBanner(
                    patient = activePatient,
                    allergies = allergies.filter { it.patientId == activePatient.id },
                    isIdentityConfirmed = uiState.confirmedPatientIds.contains(activePatient.id),
                    isOnline = uiState.isOnline,
                    onConfirmIdentity = { viewModel.confirmPatientIdentity(activePatient) },
                    onOpenSearch = { viewModel.setModule(WorkspaceModule.PATIENT_SEARCH) },
                  )
                }

                WorkspaceContentArea(
                  modifier = Modifier.weight(1f).fillMaxWidth(),
                  uiState = uiState,
                  session = session,
                  activePatient = activePatient,
                  patients = patients,
                  appointments = appointments,
                  allergies = allergies,
                  problems = problems,
                  encounters = encounters,
                  medications = medications,
                  observations = observations,
                  labResults = labResults,
                  clinicalNotes = clinicalNotes,
                  noteVersions = noteVersions,
                  noteAddenda = noteAddenda,
                  carePlans = carePlans,
                  tasks = tasks,
                  handovers = handovers,
                  messages = messages,
                  bodyStrokes = bodyStrokes,
                  consultationTools = consultationTools,
                  auditEvents = auditEvents,
                  syncQueue = syncQueue,
                  viewModel = viewModel,
                )
              }

              // Optional Right Detail Inspector (inline on wide tablet)
              if (isWideTablet && uiState.inspectorOpen) {
                DetailInspectorPanel(
                  modifier = Modifier.width(336.dp).fillMaxHeight(),
                  uiState = uiState,
                  activePatient = activePatient,
                  labResults = labResults.filter { it.patientId == activePatient?.id },
                  medications = medications.filter { it.patientId == activePatient?.id },
                  notes = clinicalNotes.filter { it.patientId == activePatient?.id },
                  onSelectTab = viewModel::selectInspectorTab,
                  onClose = viewModel::toggleInspector,
                  onToggleOrgAiApproval = viewModel::toggleOrgAiApproval,
                  onRunAi = viewModel::runAiAssistant,
                  onInsertAiDraft = viewModel::insertAiProposalIntoDraft,
                  onSelectModule = viewModel::setModule,
                  onTriggerScenario = viewModel::triggerDemoScenario,
                )
              }
            }
          } else {
            // Compact Portrait Layout
            Column(modifier = Modifier.fillMaxSize()) {
              Row(
                modifier =
                  Modifier.fillMaxWidth()
                    .background(ClinicalWhite)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
              ) {
                WorkspaceModule.entries.forEach { mod ->
                  val enabled =
                    activePatient != null ||
                      mod == WorkspaceModule.HOME ||
                      mod == WorkspaceModule.PATIENT_SEARCH ||
                      mod == WorkspaceModule.AUDIT_LOG
                  FilterChip(
                    selected = uiState.activeModule == mod,
                    onClick = { if (enabled) viewModel.setModule(mod) },
                    enabled = enabled,
                    label = { Text(mod.title) },
                  )
                }
              }
              if (activePatient != null) {
                PersistentPatientBanner(
                  patient = activePatient,
                  allergies = allergies.filter { it.patientId == activePatient.id },
                  isIdentityConfirmed = uiState.confirmedPatientIds.contains(activePatient.id),
                  isOnline = uiState.isOnline,
                  onConfirmIdentity = { viewModel.confirmPatientIdentity(activePatient) },
                  onOpenSearch = { viewModel.setModule(WorkspaceModule.PATIENT_SEARCH) },
                )
              }
              WorkspaceContentArea(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                uiState = uiState,
                session = session,
                activePatient = activePatient,
                patients = patients,
                appointments = appointments,
                allergies = allergies,
                problems = problems,
                encounters = encounters,
                medications = medications,
                observations = observations,
                labResults = labResults,
                clinicalNotes = clinicalNotes,
                noteVersions = noteVersions,
                noteAddenda = noteAddenda,
                carePlans = carePlans,
                tasks = tasks,
                handovers = handovers,
                messages = messages,
                bodyStrokes = bodyStrokes,
                consultationTools = consultationTools,
                auditEvents = auditEvents,
                syncQueue = syncQueue,
                viewModel = viewModel,
              )
            }
          }

          // Overlay Inspector for Medium/Compact widths when toggled open
          if (!isWideTablet && uiState.inspectorOpen) {
            Box(
              modifier = Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color(0x55000000)),
              contentAlignment = Alignment.CenterEnd,
            ) {
              DetailInspectorPanel(
                modifier = Modifier.widthIn(max = 360.dp).fillMaxHeight(),
                uiState = uiState,
                activePatient = activePatient,
                labResults = labResults.filter { it.patientId == activePatient?.id },
                medications = medications.filter { it.patientId == activePatient?.id },
                notes = clinicalNotes.filter { it.patientId == activePatient?.id },
                onSelectTab = viewModel::selectInspectorTab,
                onClose = viewModel::toggleInspector,
                onToggleOrgAiApproval = viewModel::toggleOrgAiApproval,
                onRunAi = viewModel::runAiAssistant,
                onInsertAiDraft = viewModel::insertAiProposalIntoDraft,
                onSelectModule = viewModel::setModule,
                onTriggerScenario = viewModel::triggerDemoScenario,
              )
            }
          }
        }
      }
    }

    // Safety & Security Modal Gates
    uiState.pendingPatientSwitch?.let { target ->
      PatientSwitchGuardDialog(
        targetPatient = target,
        onSaveAndSwitch = viewModel::confirmPatientSwitchSaveDraft,
        onDiscardAndSwitch = viewModel::confirmPatientSwitchDiscardDraft,
        onCancel = viewModel::cancelPatientSwitch,
      )
    }

    uiState.restrictedAccessPrompt?.let { (restrictedPatient, scope) ->
      BreakGlassDialog(
        patient = restrictedPatient,
        requiredScope = scope,
        onConfirmBreakGlass = viewModel::invokeBreakGlassAccess,
        onDismiss = viewModel::dismissRestrictedAccessPrompt,
      )
    }

    if (uiState.pendingSensitiveAction != null && activePatient != null) {
      SensitiveConfirmationDialog(
        patient = activePatient,
        action = uiState.pendingSensitiveAction!!,
        onConfirm = viewModel::executeConfirmedSensitiveAction,
        onDismiss = viewModel::cancelSensitiveConfirmation,
      )
    }

    if (session.isLocked) {
      SessionLockOverlay(
        clinician = session.clinician,
        error = uiState.lockError,
        onUnlock = viewModel::unlockSession,
        onSignOut = viewModel::signOut,
      )
    }
  }
}

@Composable
private fun WorkspaceSidebar(
  session: ClinicianSession,
  activeModule: WorkspaceModule,
  hasActivePatient: Boolean,
  reducedMotion: Boolean,
  concealNotifications: Boolean,
  onSelectModule: (WorkspaceModule) -> Unit,
  onToggleReducedMotion: () -> Unit,
  onToggleNotificationPrivacy: () -> Unit,
  onSignOut: () -> Unit,
) {
  Surface(
    color = ClinicalWhite,
    modifier = Modifier.width(248.dp).fillMaxHeight().border(1.dp, ClinicalBorder),
  ) {
    Column(
      modifier = Modifier.fillMaxSize().padding(12.dp),
      verticalArrangement = Arrangement.SpaceBetween,
    ) {
      Column(
        modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.padding(6.dp),
        ) {
          Image(
            painter = painterResource(id = R.drawable.img_clinician_avatar),
            contentDescription = stringResource(id = R.string.clinician_avatar_desc),
            modifier = Modifier.size(40.dp).clip(CircleShape),
            contentScale = ContentScale.Crop,
          )
          Column {
            Text(session.clinician.displayName, style = MaterialTheme.typography.titleMedium)
            Text(session.clinician.role, style = MaterialTheme.typography.bodySmall, color = ClinicalSecondaryInk)
          }
        }
        HorizontalDivider(color = ClinicalBorder)

        WorkspaceModule.entries.forEach { mod ->
          val enabled =
            hasActivePatient ||
              mod == WorkspaceModule.HOME ||
              mod == WorkspaceModule.PATIENT_SEARCH ||
              mod == WorkspaceModule.AUDIT_LOG
          val selected = activeModule == mod
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (selected) NhsPaleBlue else ClinicalWhite,
            modifier =
              Modifier.fillMaxWidth()
                .minimumInteractiveComponentSize()
                .clickable(enabled = enabled) { onSelectModule(mod) }
                .testTag("sidebar_${mod.name}"),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(
                  imageVector = moduleIcon(mod),
                  contentDescription = null,
                  tint = if (!enabled) ClinicalBorder else if (selected) NhsBlue else ClinicalSecondaryInk,
                  modifier = Modifier.size(18.dp),
                )
                Text(
                  text = mod.title,
                  style = MaterialTheme.typography.labelLarge,
                  color = if (!enabled) ClinicalBorder else if (selected) NhsDarkBlue else ClinicalInk,
                )
              }
              Text(mod.shortcutHint, style = MaterialTheme.typography.labelSmall, color = ClinicalSecondaryInk)
            }
          }
        }
      }

      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        HorizontalDivider(color = ClinicalBorder)
        Row(
          modifier = Modifier.fillMaxWidth().clickable { onToggleReducedMotion() }.padding(6.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text("Reduced Motion", style = MaterialTheme.typography.bodySmall)
          Switch(checked = reducedMotion, onCheckedChange = { onToggleReducedMotion() })
        }
        Row(
          modifier = Modifier.fillMaxWidth().clickable { onToggleNotificationPrivacy() }.padding(6.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text("Conceal Previews", style = MaterialTheme.typography.bodySmall)
          Switch(checked = concealNotifications, onCheckedChange = { onToggleNotificationPrivacy() })
        }
        OutlinedButton(
          onClick = onSignOut,
          modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize(),
        ) {
          Icon(Icons.Outlined.Logout, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(Modifier.width(6.dp))
          Text("End Shift / Sign Out")
        }
      }
    }
  }
}

@Composable
private fun WorkspaceNavigationRail(
  activeModule: WorkspaceModule,
  hasActivePatient: Boolean,
  onSelectModule: (WorkspaceModule) -> Unit,
  onSignOut: () -> Unit,
) {
  NavigationRail(containerColor = ClinicalWhite) {
    WorkspaceModule.entries.take(7).forEach { mod ->
      val enabled =
        hasActivePatient ||
          mod == WorkspaceModule.HOME ||
          mod == WorkspaceModule.PATIENT_SEARCH ||
          mod == WorkspaceModule.AUDIT_LOG
      NavigationRailItem(
        selected = activeModule == mod,
        enabled = enabled,
        onClick = { onSelectModule(mod) },
        icon = { Icon(moduleIcon(mod), contentDescription = mod.title) },
        label = { Text(mod.title.substringBefore(" ")) },
      )
    }
    Spacer(Modifier.weight(1f))
    IconButton(onClick = onSignOut) {
      Icon(Icons.Outlined.Logout, contentDescription = "Sign Out")
    }
  }
}

@Composable
private fun WorkspaceContentArea(
  modifier: Modifier,
  uiState: WorkspaceUiState,
  session: ClinicianSession,
  activePatient: PatientRecord?,
  patients: List<PatientRecord>,
  appointments: List<AppointmentSummary>,
  allergies: List<AllergyEntry>,
  problems: List<ProblemEntry>,
  encounters: List<EncounterSummary>,
  medications: List<MedicationEntry>,
  observations: List<ObservationPoint>,
  labResults: List<LabResult>,
  clinicalNotes: List<ClinicalNote>,
  noteVersions: List<NoteVersion>,
  noteAddenda: List<NoteAddendum>,
  carePlans: List<CarePlanItem>,
  tasks: List<ClinicalTask>,
  handovers: List<HandoverSbar>,
  messages: List<TeamMessage>,
  bodyStrokes: List<BodyAnnotationStroke>,
  consultationTools: List<ConsultationToolState>,
  auditEvents: List<AuditEvent>,
  syncQueue: List<SyncQueueItem>,
  viewModel: ClinicalWorkspaceViewModel,
) {
  Box(modifier = modifier) {
    when (uiState.activeModule) {
      WorkspaceModule.HOME ->
        HomeWorklistsScreen(
          session = session,
          patients = patients,
          appointments = appointments,
          tasks = tasks,
          labResults = labResults,
          notes = clinicalNotes,
          handovers = handovers,
          messages = messages,
          syncQueue = syncQueue,
          filters = uiState.homeFilters,
          isOnline = uiState.isOnline,
          concealNotifications = uiState.concealNotifications,
          evaluateAccess = { p -> viewModel.run { patients; ClinicalRepositoryAccessHelper(session, p) } },
          onUpdateFilters = viewModel::updateHomeFilters,
          onOpenPatient = viewModel::requestOpenPatient,
        )
      WorkspaceModule.PATIENT_SEARCH ->
        PatientSearchScreen(
          patients = patients,
          searchQuery = uiState.searchQuery,
          evaluateAccess = { p -> ClinicalRepositoryAccessHelper(session, p) },
          onQueryChange = viewModel::updateSearchQuery,
          onOpenPatient = { p -> viewModel.requestOpenPatient(p) },
          onResolveIdentity = { p -> viewModel.confirmPatientIdentity(p) },
        )
      WorkspaceModule.AUDIT_LOG -> AuditHistoryScreen(auditEvents = auditEvents)
      WorkspaceModule.OVERVIEW ->
        if (activePatient != null) {
          PatientOverviewScreen(
            patient = activePatient,
            allergies = allergies.filter { it.patientId == activePatient.id },
            problems = problems.filter { it.patientId == activePatient.id },
            medications = medications.filter { it.patientId == activePatient.id },
            observations = observations.filter { it.patientId == activePatient.id },
            labResults = labResults.filter { it.patientId == activePatient.id },
            carePlans = carePlans.filter { it.patientId == activePatient.id },
            encounters = encounters.filter { it.patientId == activePatient.id },
            tasks = tasks.filter { it.patientId == activePatient.id },
            onNavigateModule = viewModel::setModule,
          )
        }
      WorkspaceModule.NOTES ->
        if (activePatient != null) {
          val pNotes = clinicalNotes.filter { it.patientId == activePatient.id }
          val activeNote = uiState.activeDraftNote?.takeIf { it.patientId == activePatient.id }
          ClinicalNotesScreen(
            patient = activePatient,
            notesForPatient = pNotes,
            activeNote = activeNote,
            versionsForActive = noteVersions.filter { it.noteId == activeNote?.id },
            addendaForActive = noteAddenda.filter { it.noteId == activeNote?.id },
            autosaveStatusLabel = uiState.autosaveStatusLabel,
            isOnline = uiState.isOnline,
            onSelectTemplate = viewModel::startOrSelectDraftNote,
            onSelectExistingNote = viewModel::selectNoteForEditing,
            onUpdateDraft = viewModel::updateDraftField,
            onSaveDraftNow = { viewModel.saveCurrentDraft("Saved manually") },
            onCarryForward = viewModel::carryForwardFromSignedNote,
            onRequestSign = { note -> viewModel.requestSensitiveConfirmation(PendingSensitiveAction.SignNote(note)) },
            onSimulateConflict = viewModel::simulateConflictOnActiveNote,
            onResolveConflict = viewModel::resolveConflict,
            onAddAddendum = viewModel::addAddendumToNote,
            onMarkEnteredInError = viewModel::markEnteredInError,
          )
        }
      WorkspaceModule.RESULTS ->
        if (activePatient != null) {
          ObservationsAndResultsScreen(
            patient = activePatient,
            observations = observations.filter { it.patientId == activePatient.id },
            labResults = labResults.filter { it.patientId == activePatient.id },
            onTransitionResult = viewModel::transitionResultState,
            onCreateFollowUpTaskFromResult = { res ->
              viewModel.createOrUpdateTask(
                title = "Follow up ${res.testName} (${res.value} ${res.unit})",
                ownerName = session.clinician.displayName,
                ownerRole = session.clinician.role,
                priority = TaskPriority.URGENT,
                dueTime = "Within 24 hours",
                supportingContext = "Linked to ${res.reportStatus.label} result ${res.id}",
                linkedResultId = res.id,
              )
              viewModel.setModule(WorkspaceModule.TASKS_HANDOVER)
            },
          )
        }
      WorkspaceModule.MEDICATIONS ->
        if (activePatient != null) {
          MedicationsAndAllergiesScreen(
            patient = activePatient,
            allergies = allergies.filter { it.patientId == activePatient.id },
            medications = medications.filter { it.patientId == activePatient.id },
            onUpdateReconciliation = viewModel::updateMedicationReconciliation,
            onRequestSimulatedPrescription = { order -> viewModel.requestSensitiveConfirmation(order) },
            onUpdateAllergyStatus = viewModel::updateAllergyAssessment,
          )
        }
      WorkspaceModule.CONSULTATION_TOOLS ->
        if (activePatient != null) {
          ConsultationToolsScreen(
            patient = activePatient,
            toolState = consultationTools.firstOrNull { it.patientId == activePatient.id },
            strokes = bodyStrokes.filter { it.patientId == activePatient.id },
            activeNote = clinicalNotes.firstOrNull { it.patientId == activePatient.id },
            carePlan = carePlans.firstOrNull { it.patientId == activePatient.id },
            onAddStroke = viewModel::addBodyStroke,
            onClearStrokes = viewModel::clearBodyDiagram,
            onUpdateTools = viewModel::updateConsultationToolState,
            onRequestSendReferral = { ref -> viewModel.requestSensitiveConfirmation(ref) },
          )
        }
      WorkspaceModule.CARE_PLAN ->
        if (activePatient != null) {
          CarePlanScreen(
            patient = activePatient,
            existingPlan = carePlans.firstOrNull { it.patientId == activePatient.id },
            onSaveCarePlan = viewModel::saveCarePlan,
          )
        }
      WorkspaceModule.TASKS_HANDOVER ->
        if (activePatient != null) {
          TasksHandoverMessagesScreen(
            patient = activePatient,
            tasks = tasks.filter { it.patientId == activePatient.id },
            handover = handovers.firstOrNull { it.patientId == activePatient.id },
            messages = messages.filter { it.patientId == activePatient.id },
            onCreateTask = { t, o, r, p, d, c -> viewModel.createOrUpdateTask(t, o, r, p, d, c) },
            onCompleteTask = viewModel::completeTask,
            onSaveSbar = viewModel::saveSbarHandover,
            onSendMessage = viewModel::sendTeamMessage,
          )
        }
    }
  }
}

@Composable
private fun DetailInspectorPanel(
  modifier: Modifier,
  uiState: WorkspaceUiState,
  activePatient: PatientRecord?,
  labResults: List<LabResult>,
  medications: List<MedicationEntry>,
  notes: List<ClinicalNote>,
  onSelectTab: (InspectorTab) -> Unit,
  onClose: () -> Unit,
  onToggleOrgAiApproval: (Boolean) -> Unit,
  onRunAi: (AiAssistTask) -> Unit,
  onInsertAiDraft: (String) -> Unit,
  onSelectModule: (WorkspaceModule) -> Unit,
  onTriggerScenario: (String) -> Unit,
) {
  Surface(
    color = ClinicalWhite,
    modifier = modifier.border(1.dp, ClinicalBorder),
  ) {
    Column(Modifier.fillMaxSize()) {
      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text("Detail Inspector", style = MaterialTheme.typography.titleMedium, color = NhsDarkBlue)
        IconButton(onClick = onClose, modifier = Modifier.minimumInteractiveComponentSize()) {
          Icon(Icons.Filled.Close, contentDescription = "Close inspector")
        }
      }
      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        InspectorTab.entries.forEach { tab ->
          FilterChip(
            selected = uiState.activeInspectorTab == tab,
            onClick = { onSelectTab(tab) },
            label = { Text(tab.title) },
          )
        }
      }
      HorizontalDivider(color = ClinicalBorder)

      LazyColumn(
        modifier = Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        when (uiState.activeInspectorTab) {
          InspectorTab.RESULTS -> {
            item { Text("Quick Results Inspector", style = MaterialTheme.typography.titleMedium) }
            if (activePatient == null || labResults.isEmpty()) {
              item { Text("Select a patient with results to inspect intervals & review status.", style = MaterialTheme.typography.bodySmall) }
            } else {
              labResults.forEach { res ->
                item {
                  Surface(color = NhsIceSurface, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp)) {
                      Text("${res.testName}: ${res.value} ${res.unit}", style = MaterialTheme.typography.labelLarge)
                      Text("Ref: ${res.referenceInterval}", style = MaterialTheme.typography.bodySmall)
                      Text("${res.reportStatus.label} • ${res.reviewState.label}", style = MaterialTheme.typography.labelSmall, color = NhsDarkBlue)
                    }
                  }
                }
              }
            }
          }
          InspectorTab.MEDS -> {
            item { Text("Active Medications Quick View", style = MaterialTheme.typography.titleMedium) }
            if (activePatient == null || medications.isEmpty()) {
              item { Text("Select a patient to inspect medication sources.", style = MaterialTheme.typography.bodySmall) }
            } else {
              medications.forEach { med ->
                item {
                  Surface(color = NhsIceSurface, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp)) {
                      Text("${med.drugName} ${med.dose} ${med.frequency}", style = MaterialTheme.typography.labelLarge)
                      Text("${med.category.label} • ${med.reconciliationStatus.label}", style = MaterialTheme.typography.bodySmall)
                    }
                  }
                }
              }
            }
          }
          InspectorTab.NOTES -> {
            item { Text("Previous & Active Notes", style = MaterialTheme.typography.titleMedium) }
            if (activePatient == null || notes.isEmpty()) {
              item { Text("No notes loaded for current patient.", style = MaterialTheme.typography.bodySmall) }
            } else {
              notes.forEach { n ->
                item {
                  Surface(color = NhsIceSurface, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp)) {
                      Text("${n.templateType.label} (${n.status.label})", style = MaterialTheme.typography.labelLarge)
                      Text(n.assessmentText.ifBlank { n.historyText }.take(120), style = MaterialTheme.typography.bodySmall)
                    }
                  }
                }
              }
            }
          }
          InspectorTab.AI_ASSISTANT -> {
            item {
              Text("Optional Clinical Drafting Assistant", style = MaterialTheme.typography.titleMedium)
              Text(
                "Never diagnoses, prescribes, signs notes, or closes results. Clinician review is mandatory.",
                style = MaterialTheme.typography.bodySmall,
                color = ClinicalSecondaryInk,
              )
              Spacer(Modifier.height(6.dp))
              Surface(color = NhsPaleBlue, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                Row(
                  Modifier.padding(10.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  Column(Modifier.weight(1f)) {
                    Text("Org IG & AI Data Approval", style = MaterialTheme.typography.labelLarge)
                    Text(
                      if (uiState.orgAiApprovalEnabled) "ON — Firebase AI Logic (Synthetic Only)"
                      else "OFF — Local record-grounded templates only",
                      style = MaterialTheme.typography.bodySmall,
                    )
                  }
                  Switch(
                    checked = uiState.orgAiApprovalEnabled,
                    onCheckedChange = onToggleOrgAiApproval,
                    modifier = Modifier.testTag("org_ai_approval_switch"),
                  )
                }
              }
            }
            if (activePatient == null) {
              item { Text("Open a patient record first to use optional drafting assistance.", style = MaterialTheme.typography.bodySmall) }
            } else {
              AiAssistTask.entries.forEach { task ->
                item {
                  OutlinedButton(
                    onClick = { onRunAi(task) },
                    modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("ai_task_${task.name}"),
                  ) {
                    Text(task.title)
                  }
                }
              }
              item {
                when (val aiState = uiState.aiUiState) {
                  AiUiState.Idle -> Unit
                  AiUiState.Loading -> CircularProgressIndicator(modifier = Modifier.padding(8.dp))
                  is AiUiState.Error -> MissingInfoBanner("AI Error: ${aiState.message}")
                  is AiUiState.Ready -> {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                      StatusPill(
                        text = if (aiState.proposal.usedExternalModel) "External Gemini Draft" else "Local Grounded Draft",
                        icon = Icons.Filled.AutoAwesome,
                        containerColor = NhsPaleBlue,
                        contentColor = NhsDarkBlue,
                      )
                      Text(aiState.proposal.provenanceNotice, style = MaterialTheme.typography.bodySmall, color = ClinicalSecondaryInk)
                      aiState.proposal.statements.forEach { st ->
                        Surface(
                          color = if (st.isUnsupported) NhsAmberTint else NhsIceSurface,
                          shape = RoundedCornerShape(8.dp),
                          modifier = Modifier.fillMaxWidth(),
                        ) {
                          Column(Modifier.padding(8.dp)) {
                            Text(st.statement, style = MaterialTheme.typography.bodySmall)
                            Text(
                              if (st.isUnsupported || st.supportingRecordRef == null) "UNSUPPORTED — verify in chart"
                              else "Citation: ${st.supportingRecordRef}",
                              style = MaterialTheme.typography.labelSmall,
                              color = if (st.isUnsupported) NhsAmber else NhsGreen,
                            )
                          }
                        }
                      }
                      Button(
                        onClick = { onInsertAiDraft(aiState.proposal.rawEditableText) },
                        modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("insert_ai_draft_btn"),
                      ) {
                        Text("Insert into Draft (Clinician Reviewed)")
                      }
                    }
                  }
                }
              }
            }
          }
          InspectorTab.DEMO_GUIDE -> {
            item {
              Text("10-Step Clinical Workflow Demo", style = MaterialTheme.typography.titleMedium, color = NhsDarkBlue)
              val steps =
                listOf(
                  1 to "Sign in as a doctor",
                  2 to "Open today's clinic",
                  3 to "Confirm the selected patient",
                  4 to "Review allergies, meds & results",
                  5 to "Write & autosave consultation note",
                  6 to "Prepare patient-friendly care plan",
                  7 to "Review & sign the note",
                  8 to "Assign a follow-up task",
                  9 to "Acknowledge result (keep action open)",
                  10 to "Review the audit history",
                )
              steps.forEach { (num, label) ->
                val done = uiState.demoStepsCompleted.contains(num)
                Row(
                  modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                  Icon(
                    if (done) Icons.Filled.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
                    contentDescription = null,
                    tint = if (done) NhsGreen else ClinicalSecondaryInk,
                    modifier = Modifier.size(18.dp),
                  )
                  Text(
                    "$num. $label",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = if (done) FontWeight.SemiBold else FontWeight.Normal,
                  )
                }
              }
            }
            item {
              HorizontalDivider(color = ClinicalBorder)
              Spacer(Modifier.height(4.dp))
              Text("Edge-Case Clinical Scenarios", style = MaterialTheme.typography.titleMedium, color = NhsDarkBlue)
              Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { onTriggerScenario("UNCERTAIN_ALLERGY") }, modifier = Modifier.fillMaxWidth()) {
                  Text("1. Uncertain Allergy Status (Arthur)")
                }
                OutlinedButton(onClick = { onTriggerScenario("CORRECTED_RESULT") }, modifier = Modifier.fillMaxWidth()) {
                  Text("2. Corrected Result (Priya K+ 6.1 -> 5.4)")
                }
                OutlinedButton(onClick = { onTriggerScenario("PATIENT_SWITCH_GUARD") }, modifier = Modifier.fillMaxWidth()) {
                  Text("3. Patient Switch During Unsaved Draft")
                }
                OutlinedButton(onClick = { onTriggerScenario("OFFLINE_MODE") }, modifier = Modifier.fillMaxWidth()) {
                  Text("4. Lost Connectivity / Offline Mode")
                }
                OutlinedButton(onClick = { onTriggerScenario("CONCURRENT_CONFLICT") }, modifier = Modifier.fillMaxWidth()) {
                  Text("5. Simultaneous Editing Conflict")
                }
                TextButton(onClick = { onSelectModule(WorkspaceModule.AUDIT_LOG) }, modifier = Modifier.fillMaxWidth()) {
                  Text("Jump to Audit History ->")
                }
              }
            }
          }
        }
      }
    }
  }
}

private fun ClinicalRepositoryAccessHelper(
  session: ClinicianSession,
  patient: PatientRecord,
): com.example.data.adapter.AccessCheckResult {
  if (session.breakGlassPatientIds.contains(patient.id)) {
    return com.example.data.adapter.AccessCheckResult.GrantedViaBreakGlass(
      session.breakGlassReason ?: "Emergency access"
    )
  }
  val clinician = session.clinician
  val ok =
    clinician.authorisedServices.contains(patient.service) ||
      (patient.ward.isNotBlank() && clinician.authorisedWards.contains(patient.ward)) ||
      (patient.clinic.isNotBlank() && clinician.authorisedClinics.contains(patient.clinic))
  return if (ok) com.example.data.adapter.AccessCheckResult.Granted
  else com.example.data.adapter.AccessCheckResult.DeniedCareContext(
    "${patient.service} (${patient.ward.ifBlank { patient.clinic }})"
  )
}

private fun moduleIcon(mod: WorkspaceModule) =
  when (mod) {
    WorkspaceModule.HOME -> Icons.Outlined.Home
    WorkspaceModule.PATIENT_SEARCH -> Icons.Outlined.PersonSearch
    WorkspaceModule.OVERVIEW -> Icons.Outlined.Dashboard
    WorkspaceModule.NOTES -> Icons.Outlined.EditNote
    WorkspaceModule.RESULTS -> Icons.Outlined.Science
    WorkspaceModule.MEDICATIONS -> Icons.Outlined.Medication
    WorkspaceModule.CONSULTATION_TOOLS -> Icons.Outlined.Draw
    WorkspaceModule.CARE_PLAN -> Icons.Outlined.VolunteerActivism
    WorkspaceModule.TASKS_HANDOVER -> Icons.Outlined.AssignmentTurnedIn
    WorkspaceModule.AUDIT_LOG -> Icons.Outlined.Policy
  }
