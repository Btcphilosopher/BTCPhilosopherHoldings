package com.example.data.repository

import com.example.data.adapter.AccessCheckResult
import com.example.data.adapter.AppointmentsAdapter
import com.example.data.adapter.ClinicalRecordsAdapter
import com.example.data.adapter.IdentityProviderAdapter
import com.example.data.adapter.LaboratoryResultsAdapter
import com.example.data.adapter.LocalMockAppointmentsAdapter
import com.example.data.adapter.LocalMockClinicalRecordsAdapter
import com.example.data.adapter.LocalMockIdentityAdapter
import com.example.data.adapter.LocalMockLabResultsAdapter
import com.example.data.adapter.LocalMockPatientAdminAdapter
import com.example.data.adapter.PatientAdministrationAdapter
import com.example.data.adapter.ServerSignResult
import com.example.data.local.ClinicalDao
import com.example.data.local.toDomain
import com.example.data.local.toEntity
import com.example.data.model.*
import com.example.data.seed.SyntheticClinicalSeed
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class ClinicalRepository(
  private val dao: ClinicalDao,
  val identityAdapter: IdentityProviderAdapter =
    LocalMockIdentityAdapter(SyntheticClinicalSeed.clinicianAccounts),
  val patientAdminAdapter: PatientAdministrationAdapter = LocalMockPatientAdminAdapter(),
  val clinicalRecordsAdapter: ClinicalRecordsAdapter = LocalMockClinicalRecordsAdapter(),
  val labResultsAdapter: LaboratoryResultsAdapter = LocalMockLabResultsAdapter(),
  val appointmentsAdapter: AppointmentsAdapter = LocalMockAppointmentsAdapter(),
) {
  val patients: Flow<List<PatientRecord>> = dao.observePatients().map { it.map { e -> e.toDomain() } }
  val appointments: Flow<List<AppointmentSummary>> =
    dao.observeAppointments().map { it.map { e -> e.toDomain() } }
  val allergies: Flow<List<AllergyEntry>> = dao.observeAllergies().map { it.map { e -> e.toDomain() } }
  val problems: Flow<List<ProblemEntry>> = dao.observeProblems().map { it.map { e -> e.toDomain() } }
  val encounters: Flow<List<EncounterSummary>> =
    dao.observeEncounters().map { it.map { e -> e.toDomain() } }
  val medications: Flow<List<MedicationEntry>> =
    dao.observeMedications().map { it.map { e -> e.toDomain() } }
  val observations: Flow<List<ObservationPoint>> =
    dao.observeObservations().map { it.map { e -> e.toDomain() } }
  val labResults: Flow<List<LabResult>> = dao.observeLabResults().map { it.map { e -> e.toDomain() } }
  val clinicalNotes: Flow<List<ClinicalNote>> =
    dao.observeNotes().map { it.map { e -> e.toDomain() } }
  val noteVersions: Flow<List<NoteVersion>> =
    dao.observeNoteVersions().map { it.map { e -> e.toDomain() } }
  val noteAddenda: Flow<List<NoteAddendum>> =
    dao.observeNoteAddenda().map { it.map { e -> e.toDomain() } }
  val carePlans: Flow<List<CarePlanItem>> = dao.observeCarePlans().map { it.map { e -> e.toDomain() } }
  val tasks: Flow<List<ClinicalTask>> = dao.observeTasks().map { it.map { e -> e.toDomain() } }
  val handovers: Flow<List<HandoverSbar>> = dao.observeHandovers().map { it.map { e -> e.toDomain() } }
  val messages: Flow<List<TeamMessage>> = dao.observeMessages().map { it.map { e -> e.toDomain() } }
  val bodyStrokes: Flow<List<BodyAnnotationStroke>> =
    dao.observeBodyStrokes().map { it.map { e -> e.toDomain() } }
  val consultationTools: Flow<List<ConsultationToolState>> =
    dao.observeConsultationTools().map { it.map { e -> e.toDomain() } }
  val auditEvents: Flow<List<AuditEvent>> = dao.observeAuditEvents().map { it.map { e -> e.toDomain() } }
  val syncQueue: Flow<List<SyncQueueItem>> = dao.observeSyncQueue().map { it.map { e -> e.toDomain() } }

  suspend fun ensureSeeded() {
    if (dao.countPatients() > 0) return
    dao.insertPatients(SyntheticClinicalSeed.patients.map { it.toEntity() })
    dao.insertAppointments(SyntheticClinicalSeed.appointments.map { it.toEntity() })
    dao.insertAllergies(SyntheticClinicalSeed.allergies.map { it.toEntity() })
    dao.insertProblems(SyntheticClinicalSeed.problems.map { it.toEntity() })
    dao.insertEncounters(SyntheticClinicalSeed.encounters.map { it.toEntity() })
    dao.insertMedications(SyntheticClinicalSeed.medications.map { it.toEntity() })
    dao.insertObservations(SyntheticClinicalSeed.observations.map { it.toEntity() })
    dao.insertLabResults(SyntheticClinicalSeed.labResults.map { it.toEntity() })
    dao.insertNotes(SyntheticClinicalSeed.clinicalNotes.map { it.toEntity() })
    dao.insertNoteVersions(SyntheticClinicalSeed.noteVersions.map { it.toEntity() })
    dao.insertCarePlans(SyntheticClinicalSeed.carePlans.map { it.toEntity() })
    dao.insertTasks(SyntheticClinicalSeed.tasks.map { it.toEntity() })
    dao.insertHandovers(SyntheticClinicalSeed.handovers.map { it.toEntity() })
    dao.insertMessages(SyntheticClinicalSeed.messages.map { it.toEntity() })
    dao.insertConsultationTools(SyntheticClinicalSeed.consultationTools.map { it.toEntity() })
    dao.insertAuditEvents(SyntheticClinicalSeed.auditEvents.map { it.toEntity() })
  }

  fun evaluatePatientAccess(session: ClinicianSession, patient: PatientRecord): AccessCheckResult {
    return patientAdminAdapter.evaluateAccess(session, patient)
  }

  suspend fun recordAudit(
    clinician: ClinicianAccount,
    actionType: String,
    patientId: String,
    patientName: String,
    resourceSummary: String,
    outcome: String,
    isBreakGlass: Boolean = false,
    detail: String,
  ) {
    val event =
      AuditEvent(
        id = "aud_${UUID.randomUUID().toString().take(8)}",
        timestamp = nowFormatted(),
        actorName = clinician.displayName,
        actorRole = clinician.role,
        actionType = actionType,
        patientId = patientId,
        patientName = patientName,
        resourceSummary = resourceSummary,
        outcome = outcome,
        isBreakGlass = isBreakGlass,
        detail = detail,
      )
    dao.insertAuditEvent(event.toEntity())
  }

  suspend fun resolveUncertainIdentity(
    patient: PatientRecord,
    clinician: ClinicianAccount,
  ): PatientRecord {
    val resolved = patientAdminAdapter.resolveIdentityStatus(patient, clinician.displayName)
    dao.upsertPatient(resolved.toEntity())
    recordAudit(
      clinician = clinician,
      actionType = "PATIENT_IDENTITY_RESOLVED",
      patientId = patient.id,
      patientName = patient.fullName,
      resourceSummary = "PAS / Spine Identity Verification",
      outcome = "Verified",
      detail = "Confirmed demographics & resolved uncertain/duplicate flag",
    )
    return resolved
  }

  suspend fun saveDraftNote(
    note: ClinicalNote,
    clinician: ClinicianAccount,
    patientName: String,
    isOnline: Boolean,
    changeSummary: String = "Autosaved draft",
  ): ClinicalNote {
    if (note.status != NoteStatus.DRAFT) return note
    val ts = nowFormatted()
    val updated =
      note.copy(
        updatedAt = ts,
        isLocalOfflineDraft = !isOnline,
      )
    dao.upsertNote(updated.toEntity())
    dao.insertNoteVersion(
      NoteVersion(
        id = "ver_${UUID.randomUUID().toString().take(8)}",
        noteId = updated.id,
        versionNumber = updated.serverVersion,
        status = NoteStatus.DRAFT,
        editorName = clinician.displayName,
        timestamp = ts,
        changeSummary = if (isOnline) changeSummary else "$changeSummary (Offline local draft)",
        snapshotText = buildSnapshotSummary(updated),
      ).toEntity()
    )
    if (!isOnline) {
      dao.upsertSyncItem(
        SyncQueueItem(
          id = "sync_note_${updated.id}",
          entityType = "ClinicalNote",
          entityId = updated.id,
          patientId = updated.patientId,
          summary = "${updated.templateType.label} draft pending server sync",
          queuedAt = ts,
          status = SyncStatus.PENDING_SERVER_VALIDATION,
        ).toEntity()
      )
    }
    recordAudit(
      clinician = clinician,
      actionType = if (isOnline) "NOTE_DRAFT_SAVED" else "NOTE_OFFLINE_DRAFT_SAVED",
      patientId = updated.patientId,
      patientName = patientName,
      resourceSummary = "${updated.templateType.label} (${updated.id})",
      outcome = if (isOnline) "Saved" else "Queued Offline",
      detail = changeSummary,
    )
    return updated
  }

  suspend fun signNote(
    note: ClinicalNote,
    clinician: ClinicianAccount,
    patientName: String,
    isOnline: Boolean,
  ): ServerSignResult {
    val ts = nowFormatted()
    val result = clinicalRecordsAdapter.validateAndSignNote(note, clinician.displayName, isOnline, ts)
    when (result) {
      is ServerSignResult.Accepted -> {
        val signed = result.updatedNote
        dao.upsertNote(signed.toEntity())
        dao.deleteSyncItem("sync_note_${signed.id}")
        dao.insertNoteVersion(
          NoteVersion(
            id = "ver_${UUID.randomUUID().toString().take(8)}",
            noteId = signed.id,
            versionNumber = signed.serverVersion,
            status = NoteStatus.SIGNED,
            editorName = clinician.displayName,
            timestamp = ts,
            changeSummary = "Signed & locked after patient confirmation and preview",
            snapshotText = buildSnapshotSummary(signed),
          ).toEntity()
        )
        recordAudit(
          clinician = clinician,
          actionType = "NOTE_SIGNED",
          patientId = signed.patientId,
          patientName = patientName,
          resourceSummary = "${signed.templateType.label} v${signed.serverVersion}",
          outcome = "Signed & Locked",
          detail = "Signed by ${clinician.displayName} (${clinician.gmcOrRegistration})",
        )
      }
      is ServerSignResult.ConflictDetected -> {
        dao.upsertSyncItem(
          SyncQueueItem(
            id = "sync_conflict_${note.id}",
            entityType = "ClinicalNote",
            entityId = note.id,
            patientId = note.patientId,
            summary = "Concurrent edit conflict with ${result.remoteEditor}",
            queuedAt = ts,
            status = SyncStatus.CONFLICT_DETECTED,
          ).toEntity()
        )
        recordAudit(
          clinician = clinician,
          actionType = "NOTE_SIGN_CONFLICT_BLOCKED",
          patientId = note.patientId,
          patientName = patientName,
          resourceSummary = "${note.templateType.label} (${note.id})",
          outcome = "Blocked — Conflict",
          detail = "Server detected concurrent edit by ${result.remoteEditor}",
        )
      }
      is ServerSignResult.RejectedOffline -> {
        recordAudit(
          clinician = clinician,
          actionType = "NOTE_SIGN_OFFLINE_BLOCKED",
          patientId = note.patientId,
          patientName = patientName,
          resourceSummary = "${note.templateType.label} (${note.id})",
          outcome = "Blocked — Offline",
          detail = result.message,
        )
      }
    }
    return result
  }

  suspend fun simulateConflictOnNote(
    note: ClinicalNote,
    clinician: ClinicianAccount,
    patientName: String,
  ): ClinicalNote {
    val conflicted = clinicalRecordsAdapter.simulateRemoteEditConflict(note, "Dr Tariq Mahmood")
    dao.upsertNote(conflicted.toEntity())
    dao.upsertSyncItem(
      SyncQueueItem(
        id = "sync_conflict_${note.id}",
        entityType = "ClinicalNote",
        entityId = note.id,
        patientId = note.patientId,
        summary = "Simultaneous edit conflict with Dr Tariq Mahmood",
        queuedAt = nowFormatted(),
        status = SyncStatus.CONFLICT_DETECTED,
      ).toEntity()
    )
    recordAudit(
      clinician = clinician,
      actionType = "CONFLICT_SIMULATED",
      patientId = note.patientId,
      patientName = patientName,
      resourceSummary = note.templateType.label,
      outcome = "Conflict Flagged",
      detail = "Simulated concurrent server edit requiring explicit resolution",
    )
    return conflicted
  }

  suspend fun resolveNoteConflict(
    note: ClinicalNote,
    resolution: String, // "KEEP_MINE", "ACCEPT_REMOTE", "MERGE_BOTH"
    clinician: ClinicianAccount,
    patientName: String,
  ): ClinicalNote {
    val ts = nowFormatted()
    val mergedFreeText =
      when (resolution) {
        "ACCEPT_REMOTE" ->
          "[Accepted Remote Edit from ${note.remoteConflictEditor ?: "Remote Clinician"}]\n${note.remoteConflictSummary.orEmpty()}"
        "MERGE_BOTH" ->
          "${note.freeText}\n\n[Merged Remote Edit — ${note.remoteConflictEditor ?: "Remote Clinician"}]: ${note.remoteConflictSummary.orEmpty()}"
        else -> note.freeText
      }
    val resolved =
      note.copy(
        freeText = mergedFreeText,
        hasConflict = false,
        remoteConflictEditor = null,
        remoteConflictSummary = null,
        serverVersion = note.serverVersion + 1,
        updatedAt = ts,
      )
    dao.upsertNote(resolved.toEntity())
    dao.deleteSyncItem("sync_conflict_${note.id}")
    dao.insertNoteVersion(
      NoteVersion(
        id = "ver_${UUID.randomUUID().toString().take(8)}",
        noteId = resolved.id,
        versionNumber = resolved.serverVersion,
        status = resolved.status,
        editorName = clinician.displayName,
        timestamp = ts,
        changeSummary = "Conflict resolved ($resolution)",
        snapshotText = buildSnapshotSummary(resolved),
      ).toEntity()
    )
    recordAudit(
      clinician = clinician,
      actionType = "NOTE_CONFLICT_RESOLVED",
      patientId = note.patientId,
      patientName = patientName,
      resourceSummary = "${note.templateType.label} v${resolved.serverVersion}",
      outcome = "Resolved ($resolution)",
      detail = "Explicit conflict resolution applied without silent overwrite",
    )
    return resolved
  }

  suspend fun addAddendum(
    note: ClinicalNote,
    reason: String,
    text: String,
    clinician: ClinicianAccount,
    patientName: String,
  ) {
    if (note.status != NoteStatus.SIGNED && note.status != NoteStatus.AMENDED) return
    val ts = nowFormatted()
    val addendum =
      NoteAddendum(
        id = "add_${UUID.randomUUID().toString().take(8)}",
        noteId = note.id,
        authorName = clinician.displayName,
        timestamp = ts,
        reason = reason,
        text = text,
      )
    dao.insertNoteAddendum(addendum.toEntity())
    val amended =
      note.copy(
        status = NoteStatus.AMENDED,
        serverVersion = note.serverVersion + 1,
        updatedAt = ts,
      )
    dao.upsertNote(amended.toEntity())
    dao.insertNoteVersion(
      NoteVersion(
        id = "ver_${UUID.randomUUID().toString().take(8)}",
        noteId = amended.id,
        versionNumber = amended.serverVersion,
        status = NoteStatus.AMENDED,
        editorName = clinician.displayName,
        timestamp = ts,
        changeSummary = "Linked addendum added: $reason",
        snapshotText = "Addendum: $text",
      ).toEntity()
    )
    recordAudit(
      clinician = clinician,
      actionType = "NOTE_AMENDED_WITH_ADDENDUM",
      patientId = note.patientId,
      patientName = patientName,
      resourceSummary = "${note.templateType.label} v${amended.serverVersion}",
      outcome = "Amended",
      detail = "Original signed content preserved; addendum appended ($reason)",
    )
  }

  suspend fun markNoteEnteredInError(
    note: ClinicalNote,
    reason: String,
    clinician: ClinicianAccount,
    patientName: String,
  ) {
    val ts = nowFormatted()
    val updated =
      note.copy(
        status = NoteStatus.ENTERED_IN_ERROR,
        enteredInErrorReason = reason,
        serverVersion = note.serverVersion + 1,
        updatedAt = ts,
      )
    dao.upsertNote(updated.toEntity())
    dao.insertNoteVersion(
      NoteVersion(
        id = "ver_${UUID.randomUUID().toString().take(8)}",
        noteId = updated.id,
        versionNumber = updated.serverVersion,
        status = NoteStatus.ENTERED_IN_ERROR,
        editorName = clinician.displayName,
        timestamp = ts,
        changeSummary = "Marked Entered-in-Error: $reason",
        snapshotText = "Preserved historical note flagged as entered-in-error.",
      ).toEntity()
    )
    recordAudit(
      clinician = clinician,
      actionType = "NOTE_ENTERED_IN_ERROR",
      patientId = note.patientId,
      patientName = patientName,
      resourceSummary = "${note.templateType.label} (${note.id})",
      outcome = "Entered in Error (Preserved)",
      detail = reason,
    )
  }

  suspend fun transitionLabResultState(
    result: LabResult,
    newState: ResultReviewState,
    clinician: ClinicianAccount,
    patientName: String,
  ): LabResult {
    val ts = nowFormatted()
    val updated =
      when (newState) {
        ResultReviewState.UNVIEWED -> result
        ResultReviewState.VIEWED ->
          if (result.reviewState == ResultReviewState.UNVIEWED) {
            result.copy(reviewState = ResultReviewState.VIEWED)
          } else result
        ResultReviewState.ACKNOWLEDGED ->
          result.copy(
            reviewState = ResultReviewState.ACKNOWLEDGED,
            acknowledgedBy = clinician.displayName,
            acknowledgedAt = ts,
          )
        ResultReviewState.ACTION_COMPLETED ->
          result.copy(
            reviewState = ResultReviewState.ACTION_COMPLETED,
            acknowledgedBy = result.acknowledgedBy ?: clinician.displayName,
            acknowledgedAt = result.acknowledgedAt ?: ts,
            actionCompletedBy = clinician.displayName,
            actionCompletedAt = ts,
          )
      }
    dao.upsertLabResult(updated.toEntity())
    recordAudit(
      clinician = clinician,
      actionType = "RESULT_REVIEW_${newState.name}",
      patientId = result.patientId,
      patientName = patientName,
      resourceSummary = "${result.testName} (${result.value} ${result.unit})",
      outcome = newState.label,
      detail = "Report ${result.reportStatus.label} • Follow-up owner: ${result.followUpOwner}",
    )
    return updated
  }

  suspend fun updateMedicationReconciliation(
    med: MedicationEntry,
    newStatus: ReconciliationStatus,
    clinician: ClinicianAccount,
    patientName: String,
  ) {
    val updated = med.copy(reconciliationStatus = newStatus)
    dao.upsertMedication(updated.toEntity())
    recordAudit(
      clinician = clinician,
      actionType = "MEDICATION_RECONCILIATION",
      patientId = med.patientId,
      patientName = patientName,
      resourceSummary = "${med.drugName} ${med.strength}",
      outcome = newStatus.label,
      detail = "Category: ${med.category.label}",
    )
  }

  suspend fun addSimulatedPrescription(
    patientId: String,
    patientName: String,
    drugName: String,
    strength: String,
    dose: String,
    route: String,
    frequency: String,
    notes: String,
    clinician: ClinicianAccount,
  ) {
    val entry =
      MedicationEntry(
        id = "med_${UUID.randomUUID().toString().take(8)}",
        patientId = patientId,
        drugName = drugName,
        strength = strength,
        dose = dose,
        route = route,
        frequency = frequency,
        startDate = nowFormatted().substringBefore(" "),
        endDate = "Simulated Draft",
        category = MedicationCategory.PRESCRIBED,
        prescriptionStatus = "Simulated Order (Non-Clinical Prototype)",
        informationSource = "Simulated ePMA Order by ${clinician.displayName}",
        reconciliationStatus = ReconciliationStatus.RECONCILED,
        notes = notes,
      )
    dao.upsertMedication(entry.toEntity())
    recordAudit(
      clinician = clinician,
      actionType = "SIMULATED_ORDER_SUBMITTED",
      patientId = patientId,
      patientName = patientName,
      resourceSummary = "$drugName $dose $route $frequency",
      outcome = "Simulated Order Recorded",
      detail = "Patient confirmation verified; real prescribing requires NHS ePMA validation",
    )
  }

  suspend fun updateAllergyStatusAndEntry(
    patient: PatientRecord,
    newState: AllergyAssessmentState,
    newEntry: AllergyEntry?,
    clinician: ClinicianAccount,
  ) {
    dao.upsertPatient(patient.copy(allergyStatus = newState).toEntity())
    if (newEntry != null) {
      dao.upsertAllergy(newEntry.toEntity())
    }
    recordAudit(
      clinician = clinician,
      actionType = "ALLERGY_RECORD_UPDATED",
      patientId = patient.id,
      patientName = patient.fullName,
      resourceSummary = newEntry?.substance ?: newState.label,
      outcome = newState.label,
      detail = newEntry?.let { "${it.reaction} (${it.severity})" } ?: "Allergy assessment updated",
    )
  }

  suspend fun saveCarePlan(
    carePlan: CarePlanItem,
    clinician: ClinicianAccount,
    patientName: String,
  ) {
    val updated = carePlan.copy(updatedAt = nowFormatted())
    dao.upsertCarePlan(updated.toEntity())
    recordAudit(
      clinician = clinician,
      actionType = if (updated.approvedByClinician) "CARE_PLAN_APPROVED" else "CARE_PLAN_SAVED",
      patientId = updated.patientId,
      patientName = patientName,
      resourceSummary = updated.title,
      outcome = if (updated.approvedByClinician) "Approved for Patient View" else "Draft Saved",
      detail = "Patient-friendly care plan updated",
    )
  }

  suspend fun upsertTask(
    task: ClinicalTask,
    clinician: ClinicianAccount,
    patientName: String,
    isNew: Boolean,
  ) {
    dao.upsertTask(task.toEntity())
    recordAudit(
      clinician = clinician,
      actionType = if (isNew) "TASK_ASSIGNED" else "TASK_UPDATED",
      patientId = task.patientId,
      patientName = patientName,
      resourceSummary = task.title,
      outcome = task.status.label,
      detail = "Owner: ${task.ownerName} • Priority: ${task.priority.label} • Due: ${task.dueTime}",
    )
  }

  suspend fun saveHandoverSbar(
    sbar: HandoverSbar,
    clinician: ClinicianAccount,
    patientName: String,
  ) {
    val updated = sbar.copy(updatedAt = nowFormatted(), authorName = clinician.displayName)
    dao.upsertHandover(updated.toEntity())
    recordAudit(
      clinician = clinician,
      actionType = "SBAR_HANDOVER_UPDATED",
      patientId = sbar.patientId,
      patientName = patientName,
      resourceSummary = "SBAR Handover",
      outcome = if (updated.acknowledgedBy != null) "Acknowledged" else "Pending Handover",
      detail = updated.recommendation.take(90),
    )
  }

  suspend fun sendTeamMessage(
    patientId: String,
    patientName: String,
    recipientTeam: String,
    body: String,
    clinician: ClinicianAccount,
  ) {
    val msg =
      TeamMessage(
        id = "msg_${UUID.randomUUID().toString().take(8)}",
        patientId = patientId,
        senderName = clinician.displayName,
        senderRole = clinician.role,
        recipientTeam = recipientTeam,
        body = body,
        timestamp = nowFormatted(),
        deliveryState = MessageDeliveryState.DELIVERED,
      )
    dao.upsertMessage(msg.toEntity())
    recordAudit(
      clinician = clinician,
      actionType = "TEAM_MESSAGE_SENT",
      patientId = patientId,
      patientName = patientName,
      resourceSummary = "To $recipientTeam",
      outcome = "Delivered (Non-escalation channel)",
      detail = "Secure team message recorded; urgent clinical escalation remains separate",
    )
  }

  suspend fun saveBodyStroke(stroke: BodyAnnotationStroke) {
    dao.upsertBodyStroke(stroke.toEntity())
  }

  suspend fun clearBodyStrokes(patientId: String, clinician: ClinicianAccount, patientName: String) {
    dao.clearBodyStrokesForPatient(patientId)
    recordAudit(
      clinician = clinician,
      actionType = "BODY_DIAGRAM_CLEARED",
      patientId = patientId,
      patientName = patientName,
      resourceSummary = "Annotated Body Diagram",
      outcome = "Cleared",
      detail = "Clinician cleared body diagram annotations",
    )
  }

  suspend fun saveConsultationTools(
    state: ConsultationToolState,
    clinician: ClinicianAccount,
    patientName: String,
    actionNote: String,
  ) {
    dao.upsertConsultationTool(state.toEntity())
    recordAudit(
      clinician = clinician,
      actionType = "CONSULTATION_TOOL_UPDATED",
      patientId = state.patientId,
      patientName = patientName,
      resourceSummary = actionNote,
      outcome = "Recorded",
      detail = "Consent=${state.consentDocumented}, ImageAttached=${state.clinicalImageAttached}",
    )
  }

  suspend fun flushSyncQueue(
    patientsList: List<PatientRecord>,
    notesList: List<ClinicalNote>,
    clinician: ClinicianAccount,
  ) {
    val nowMillis = System.currentTimeMillis()
    val ts = nowFormatted()
    patientsList.forEach { p -> dao.upsertPatient(p.copy(lastSyncedAt = nowMillis).toEntity()) }
    notesList
      .filter { it.isLocalOfflineDraft && !it.hasConflict }
      .forEach { n -> dao.upsertNote(n.copy(isLocalOfflineDraft = false, updatedAt = ts).toEntity()) }
    dao.clearSyncQueue()
    recordAudit(
      clinician = clinician,
      actionType = "BACKGROUND_SYNC_COMPLETED",
      patientId = "SYSTEM",
      patientName = "Workspace Sync",
      resourceSummary = "Local Mock Backend Sync",
      outcome = "Synced",
      detail = "Validated queued offline drafts and refreshed record timestamps",
    )
  }

  fun nowFormatted(): String {
    return SimpleDateFormat("dd MMM yyyy HH:mm", Locale.UK).format(Date())
  }

  private fun buildSnapshotSummary(note: ClinicalNote): String {
    return buildString {
      if (note.historyText.isNotBlank()) append("Hx: ${note.historyText.take(80)} ")
      if (note.assessmentText.isNotBlank()) append("| Ax: ${note.assessmentText.take(80)} ")
      if (note.planText.isNotBlank()) append("| Plan: ${note.planText.take(80)}")
    }.ifBlank { "Structured clinical note snapshot" }
  }
}
