package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.ui.components.StatusPill
import com.example.ui.theme.*

@Composable
fun PatientOverviewScreen(
  patient: PatientRecord,
  allergies: List<AllergyEntry>,
  problems: List<ProblemEntry>,
  medications: List<MedicationEntry>,
  observations: List<ObservationPoint>,
  labResults: List<LabResult>,
  carePlans: List<CarePlanItem>,
  encounters: List<EncounterSummary>,
  tasks: List<ClinicalTask>,
  onNavigateModule: (WorkspaceModule) -> Unit,
) {
  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column {
          Text(
            "Patient Clinical Overview",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.semantics { heading() },
          )
          Text(
            "GP: ${patient.gpPractice} • Address: ${patient.address}",
            style = MaterialTheme.typography.bodySmall,
            color = ClinicalSecondaryInk,
          )
        }
        Button(
          onClick = { onNavigateModule(WorkspaceModule.NOTES) },
          modifier = Modifier.minimumInteractiveComponentSize(),
        ) {
          Icon(Icons.Filled.EditNote, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(Modifier.width(6.dp))
          Text("Open Consultation Note")
        }
      }
    }

    item {
      ExpandableClinicalSection(
        title = "1. Presenting Problem",
        icon = Icons.Filled.MedicalServices,
        statusBadge = "${patient.encounterType} • ${patient.location}",
        initiallyExpanded = true,
      ) {
        Text(patient.presentingProblem, style = MaterialTheme.typography.bodyLarge)
      }
    }

    item {
      ExpandableClinicalSection(
        title = "2. Active Diagnoses & Problem List (${problems.size})",
        icon = Icons.Filled.ListAlt,
        statusBadge = if (problems.isEmpty()) "None recorded" else "${problems.size} documented",
        initiallyExpanded = true,
      ) {
        if (problems.isEmpty()) {
          MissingInfoBanner("No active diagnoses documented yet in prototype record.")
        } else {
          problems.forEach { p ->
            Row(
              modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Column(Modifier.weight(1f)) {
                Text("${p.title} (${p.code})", style = MaterialTheme.typography.titleMedium)
                Text("Source: ${p.source} • Author: ${p.author} • ${p.timestamp}", style = MaterialTheme.typography.bodySmall, color = ClinicalSecondaryInk)
              }
              StatusPill(p.status, Icons.Outlined.Label, NhsPaleBlue, NhsDarkBlue)
            }
          }
        }
      }
    }

    item {
      ExpandableClinicalSection(
        title = "3. Relevant History",
        icon = Icons.Filled.HistoryEdu,
        statusBadge = patient.historyStatus.label,
        initiallyExpanded = true,
      ) {
        when (patient.historyStatus) {
          RecordAvailabilityState.DOCUMENTED ->
            Text(patient.historySummary, style = MaterialTheme.typography.bodyLarge)
          RecordAvailabilityState.NOT_ASSESSED ->
            MissingInfoBanner("Relevant history: Not Assessed during current encounter. Direct history taking required.")
          RecordAvailabilityState.INFORMATION_UNAVAILABLE ->
            MissingInfoBanner("Relevant history: Information Unavailable (external GP/Summary Care Record inaccessible or pending).")
        }
      }
    }

    item {
      ExpandableClinicalSection(
        title = "4. Allergies & Adverse Reactions",
        icon = Icons.Filled.WarningAmber,
        statusBadge = patient.allergyStatus.label,
        initiallyExpanded = true,
      ) {
        when (patient.allergyStatus) {
          AllergyAssessmentState.ASSESSED_WITH_REACTIONS -> {
            allergies.forEach { a ->
              Surface(
                color = NhsRedTint,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
              ) {
                Column(Modifier.padding(10.dp)) {
                  Text("${a.substance} — ${a.reaction}", style = MaterialTheme.typography.titleMedium, color = NhsRed)
                  Text("Severity: ${a.severity} • ${a.verificationStatus} • Source: ${a.source} (${a.recordedBy}, ${a.recordedAt})", style = MaterialTheme.typography.bodySmall)
                }
              }
            }
          }
          AllergyAssessmentState.NO_KNOWN_ALLERGIES ->
            StatusPill("No Known Allergies (Formally Assessed)", Icons.Filled.CheckCircle, NhsGreenTint, NhsGreen)
          AllergyAssessmentState.NOT_ASSESSED ->
            MissingInfoBanner("NOT ASSESSED: Allergy enquiry has not yet been completed for this patient. Do not assume No Known Allergies.")
          AllergyAssessmentState.INFORMATION_UNAVAILABLE ->
            MissingInfoBanner("INFORMATION UNAVAILABLE: Historical allergy source is unreachable or patient unable to confirm. Treat with clinical caution.")
        }
        Spacer(Modifier.height(6.dp))
        TextButton(onClick = { onNavigateModule(WorkspaceModule.MEDICATIONS) }) {
          Text("Manage Allergies & Reconciliation ->")
        }
      }
    }

    item {
      ExpandableClinicalSection(
        title = "5. Current Medications (${medications.size})",
        icon = Icons.Filled.Medication,
        statusBadge = patient.medicationHistoryStatus.label,
        initiallyExpanded = true,
      ) {
        if (patient.medicationHistoryStatus != RecordAvailabilityState.DOCUMENTED && medications.isEmpty()) {
          MissingInfoBanner("Medication history: ${patient.medicationHistoryStatus.label}")
        } else {
          medications.forEach { m ->
            Row(
              modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column(Modifier.weight(1f)) {
                Text("${m.drugName} ${m.strength} — ${m.dose} ${m.route} ${m.frequency}", style = MaterialTheme.typography.bodyLarge)
                Text("${m.category.label} • Source: ${m.informationSource}", style = MaterialTheme.typography.bodySmall, color = ClinicalSecondaryInk)
              }
              StatusPill(
                text = m.reconciliationStatus.label,
                icon = if (m.reconciliationStatus == ReconciliationStatus.DISCREPANCY) Icons.Filled.Warning else Icons.Filled.Check,
                containerColor = if (m.reconciliationStatus == ReconciliationStatus.DISCREPANCY) NhsAmberTint else NhsGreenTint,
                contentColor = if (m.reconciliationStatus == ReconciliationStatus.DISCREPANCY) NhsAmber else NhsGreen,
              )
            }
          }
        }
        TextButton(onClick = { onNavigateModule(WorkspaceModule.MEDICATIONS) }) {
          Text("Open Full Medication Reconciliation ->")
        }
      }
    }

    item {
      ExpandableClinicalSection(
        title = "6. Recent Observations (${observations.size})",
        icon = Icons.Filled.MonitorHeart,
        statusBadge = patient.observationsStatus.label,
        initiallyExpanded = false,
      ) {
        observations.forEach { o ->
          Text(
            "${o.displayName}: ${o.value} ${o.unit} (${o.measuredAt} • ${o.provenance})",
            style = MaterialTheme.typography.bodyMedium,
            color = if (o.isAbnormal) NhsRed else ClinicalInk,
          )
        }
      }
    }

    item {
      ExpandableClinicalSection(
        title = "7. Results (${labResults.size})",
        icon = Icons.Filled.Science,
        statusBadge = "${labResults.count { it.reviewState != ResultReviewState.ACTION_COMPLETED }} awaiting action",
        initiallyExpanded = true,
      ) {
        if (labResults.isEmpty()) {
          MissingInfoBanner("No laboratory results available in prototype record.")
        } else {
          labResults.forEach { r ->
            Row(
              modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Column(Modifier.weight(1f)) {
                Text("${r.testName}: ${r.value} ${r.unit} (Ref: ${r.referenceInterval})", style = MaterialTheme.typography.bodyLarge)
                Text("${r.reportStatus.label} • Reported ${r.resultTime} • ${r.provenance}", style = MaterialTheme.typography.bodySmall, color = ClinicalSecondaryInk)
              }
              StatusPill(r.reviewState.label, Icons.Outlined.FactCheck, NhsPaleBlue, NhsDarkBlue)
            }
          }
        }
        TextButton(onClick = { onNavigateModule(WorkspaceModule.RESULTS) }) {
          Text("Review & Acknowledge Results ->")
        }
      }
    }

    item {
      ExpandableClinicalSection(
        title = "8. Care Plans (${carePlans.size})",
        icon = Icons.Filled.VolunteerActivism,
        statusBadge = if (carePlans.any { it.approvedByClinician }) "Clinician Approved" else "Draft / Pending",
        initiallyExpanded = false,
      ) {
        if (carePlans.isEmpty()) {
          Text("No care plan drafted yet.", style = MaterialTheme.typography.bodyMedium, color = ClinicalSecondaryInk)
        } else {
          carePlans.forEach { cp ->
            Text(cp.title, style = MaterialTheme.typography.titleMedium)
            Text(cp.patientFriendlyExplanation, style = MaterialTheme.typography.bodyMedium)
          }
        }
        TextButton(onClick = { onNavigateModule(WorkspaceModule.CARE_PLAN) }) {
          Text("Open Patient Care Plan ->")
        }
      }
    }

    item {
      ExpandableClinicalSection(
        title = "9. Recent Encounters (${encounters.size})",
        icon = Icons.Filled.History,
        statusBadge = "${encounters.size} prior",
        initiallyExpanded = false,
      ) {
        if (encounters.isEmpty()) {
          Text("No prior encounters recorded.", style = MaterialTheme.typography.bodyMedium, color = ClinicalSecondaryInk)
        } else {
          encounters.forEach { e ->
            Text("${e.dateLabel} — ${e.encounterType} (${e.clinician}, ${e.location}): ${e.summary}", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(4.dp))
          }
        }
      }
    }

    item {
      ExpandableClinicalSection(
        title = "10. Outstanding Tasks (${tasks.count { it.status != TaskStatus.COMPLETED }})",
        icon = Icons.Filled.Assignment,
        statusBadge = "${tasks.size} total",
        initiallyExpanded = true,
      ) {
        if (tasks.isEmpty()) {
          Text("No tasks linked to this patient.", style = MaterialTheme.typography.bodyMedium, color = ClinicalSecondaryInk)
        } else {
          tasks.forEach { t ->
            Text("• [${t.status.label}] ${t.title} — Owner: ${t.ownerName} (Due ${t.dueTime})", style = MaterialTheme.typography.bodyMedium)
          }
        }
        TextButton(onClick = { onNavigateModule(WorkspaceModule.TASKS_HANDOVER) }) {
          Text("Manage Tasks & SBAR Handover ->")
        }
      }
    }
  }
}

@Composable
private fun ExpandableClinicalSection(
  title: String,
  icon: ImageVector,
  statusBadge: String,
  initiallyExpanded: Boolean,
  content: @Composable ColumnScope.() -> Unit,
) {
  var expanded by remember { mutableStateOf(initiallyExpanded) }
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = ClinicalWhite),
    border = BorderStroke(1.dp, ClinicalBorder),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(Modifier.fillMaxWidth()) {
      Row(
        modifier =
          Modifier.fillMaxWidth()
            .minimumInteractiveComponentSize()
            .clickable { expanded = !expanded }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Icon(icon, contentDescription = null, tint = NhsBlue)
          Text(title, style = MaterialTheme.typography.titleMedium, color = ClinicalInk)
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(statusBadge, style = MaterialTheme.typography.labelMedium, color = ClinicalSecondaryInk)
          Icon(
            if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
            contentDescription = if (expanded) "Collapse section" else "Expand section",
          )
        }
      }
      AnimatedVisibility(visible = expanded) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 14.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp),
          content = content,
        )
      }
    }
  }
}

@Composable
fun MissingInfoBanner(message: String) {
  Surface(
    color = NhsAmberTint,
    shape = RoundedCornerShape(10.dp),
    border = BorderStroke(1.dp, NhsAmber.copy(alpha = 0.4f)),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Row(
      modifier = Modifier.padding(10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Icon(Icons.Filled.Info, contentDescription = null, tint = NhsAmber)
      Text(message, style = MaterialTheme.typography.bodyMedium, color = NhsAmber)
    }
  }
}
