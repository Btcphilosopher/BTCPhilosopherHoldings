package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.*
import com.example.ui.components.StatusPill
import com.example.ui.theme.*
import com.example.ui.viewmodel.PendingSensitiveAction

@Composable
fun ConsultationToolsScreen(
  patient: PatientRecord,
  toolState: ConsultationToolState?,
  strokes: List<BodyAnnotationStroke>,
  activeNote: ClinicalNote?,
  carePlan: CarePlanItem?,
  onAddStroke: (String, String, Long, Float) -> Unit,
  onClearStrokes: () -> Unit,
  onUpdateTools: (String, (ConsultationToolState) -> ConsultationToolState) -> Unit,
  onRequestSendReferral: (PendingSensitiveAction.SendReferral) -> Unit,
) {
  val effectiveState =
    toolState
      ?: ConsultationToolState(
        patientId = patient.id,
        consentDocumented = false,
        consentScope = "Clinical examination & illustration review",
        consentClinician = "Active Clinician",
        consentTimestamp = "Today",
        chaperoneName = "Offered",
        interpreterLanguage = "English (No interpreter required)",
        interpreterId = "",
        sharedLeafletTitles = emptyList(),
        clinicalImageAttached = false,
        imageConsentConfirmed = false,
        imageAttribution = "Protected clinical workspace container only",
        referralDraftSummary = "",
      )

  var selectedRegion by remember { mutableStateOf("Lower Limbs / Ankles") }
  var strokeColorHex by remember { mutableLongStateOf(0xFFDA291C) }
  var livePoints by remember { mutableStateOf<List<Offset>>(emptyList()) }
  var showSummaryPreview by remember { mutableStateOf(false) }

  var chaperoneInput by remember(effectiveState.chaperoneName) { mutableStateOf(effectiveState.chaperoneName) }
  var interpreterLangInput by remember(effectiveState.interpreterLanguage) { mutableStateOf(effectiveState.interpreterLanguage) }
  var referralInput by remember(effectiveState.referralDraftSummary) { mutableStateOf(effectiveState.referralDraftSummary) }

  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column {
          Text(
            "Consultation Tools & Body Diagram",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.semantics { heading() },
          )
          Text(
            "Supports stylus & touch body diagram annotation, consent logging, protected clinical attachments, and consultation summary.",
            style = MaterialTheme.typography.bodySmall,
            color = ClinicalSecondaryInk,
          )
        }
        Button(
          onClick = { showSummaryPreview = true },
          modifier = Modifier.minimumInteractiveComponentSize().testTag("consultation_summary_preview_btn"),
        ) {
          Icon(Icons.Filled.Summarize, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(Modifier.width(6.dp))
          Text("Summary Preview")
        }
      }
    }

    // Annotatable Body Diagram
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = ClinicalWhite),
        border = BorderStroke(1.dp, ClinicalBorder),
      ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column {
              Text("Annotatable Clinical Body Diagram (Stylus & Touch)", style = MaterialTheme.typography.titleLarge)
              Text("Draw directly on anterior/posterior silhouette • Saved per patient (${strokes.size} strokes)", style = MaterialTheme.typography.bodySmall, color = ClinicalSecondaryInk)
            }
            OutlinedButton(
              onClick = onClearStrokes,
              modifier = Modifier.minimumInteractiveComponentSize().testTag("clear_diagram_btn"),
            ) {
              Text("Clear Diagram")
            }
          }

          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Lower Limbs / Ankles", "Chest / Precordium", "Right Forearm").forEach { reg ->
              FilterChip(
                selected = selectedRegion == reg,
                onClick = { selectedRegion = reg },
                label = { Text(reg) },
              )
            }
            FilterChip(
              selected = strokeColorHex == 0xFFDA291C,
              onClick = { strokeColorHex = 0xFFDA291C },
              label = { Text("Red Ink") },
            )
            FilterChip(
              selected = strokeColorHex == 0xFF005EB8,
              onClick = { strokeColorHex = 0xFF005EB8 },
              label = { Text("NHS Blue Ink") },
            )
          }

          Box(
            modifier =
              Modifier.fillMaxWidth()
                .height(280.dp)
                .background(NhsIceSurface, RoundedCornerShape(12.dp))
          ) {
            Canvas(
              modifier =
                Modifier.fillMaxSize()
                  .testTag("body_diagram_canvas")
                  .pointerInput(selectedRegion, strokeColorHex) {
                    detectDragGestures(
                      onDragStart = { offset -> livePoints = listOf(offset) },
                      onDrag = { change, _ ->
                        change.consume()
                        livePoints = livePoints + change.position
                      },
                      onDragEnd = {
                        if (livePoints.size >= 2) {
                          val serialized =
                            livePoints.joinToString(";") {
                              "${(it.x / size.width).coerceIn(0f, 1f)},${(it.y / size.height).coerceIn(0f, 1f)}"
                            }
                          onAddStroke(selectedRegion, serialized, strokeColorHex, 5f)
                        }
                        livePoints = emptyList()
                      },
                    )
                  }
            ) {
              // Draw clean schematic anterior & posterior anatomical silhouettes
              val cx1 = size.width * 0.30f
              val cx2 = size.width * 0.70f
              val bodyColor = Color(0xFF8FA6BA)
              val outline = Stroke(width = 3f)

              listOf(cx1, cx2).forEach { cx ->
                // Head
                drawCircle(color = bodyColor, radius = size.height * 0.08f, center = Offset(cx, size.height * 0.14f), style = outline)
                // Torso
                drawRect(
                  color = bodyColor,
                  topLeft = Offset(cx - size.width * 0.07f, size.height * 0.23f),
                  size = androidx.compose.ui.geometry.Size(size.width * 0.14f, size.height * 0.33f),
                  style = outline,
                )
                // Arms
                drawLine(bodyColor, Offset(cx - size.width * 0.07f, size.height * 0.25f), Offset(cx - size.width * 0.13f, size.height * 0.52f), strokeWidth = 3f)
                drawLine(bodyColor, Offset(cx + size.width * 0.07f, size.height * 0.25f), Offset(cx + size.width * 0.13f, size.height * 0.52f), strokeWidth = 3f)
                // Legs
                drawLine(bodyColor, Offset(cx - size.width * 0.04f, size.height * 0.56f), Offset(cx - size.width * 0.05f, size.height * 0.90f), strokeWidth = 3f)
                drawLine(bodyColor, Offset(cx + size.width * 0.04f, size.height * 0.56f), Offset(cx + size.width * 0.05f, size.height * 0.90f), strokeWidth = 3f)
              }

              // Render persisted normalized strokes
              strokes.forEach { stroke ->
                val pts =
                  stroke.pointsSerialized.split(";").mapNotNull { pair ->
                    val parts = pair.split(",")
                    if (parts.size == 2) {
                      Offset(parts[0].toFloat() * size.width, parts[1].toFloat() * size.height)
                    } else null
                  }
                if (pts.size >= 2) {
                  val path = Path().apply {
                    moveTo(pts.first().x, pts.first().y)
                    pts.drop(1).forEach { lineTo(it.x, it.y) }
                  }
                  drawPath(
                    path = path,
                    color = Color(stroke.colorHex),
                    style = Stroke(width = stroke.strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round),
                  )
                }
              }

              // Render current live stroke
              if (livePoints.size >= 2) {
                val path = Path().apply {
                  moveTo(livePoints.first().x, livePoints.first().y)
                  livePoints.drop(1).forEach { lineTo(it.x, it.y) }
                }
                drawPath(
                  path = path,
                  color = Color(strokeColorHex),
                  style = Stroke(width = 5f, cap = StrokeCap.Round, join = StrokeJoin.Round),
                )
              }
            }
          }
        }
      }
    }

    // Consent, Chaperone, Interpreter & Protected Clinical Image Attachment
    item {
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = ClinicalWhite),
          border = BorderStroke(1.dp, ClinicalBorder),
          modifier = Modifier.weight(1f),
        ) {
          Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Consent, Chaperone & Interpreter", style = MaterialTheme.typography.titleLarge)
            Row(verticalAlignment = Alignment.CenterVertically) {
              Checkbox(
                checked = effectiveState.consentDocumented,
                onCheckedChange = { checked ->
                  onUpdateTools("Consent documentation updated") { it.copy(consentDocumented = checked) }
                },
              )
              Text("Verbal / Written Consultation Consent Recorded")
            }
            OutlinedTextField(
              value = chaperoneInput,
              onValueChange = { chaperoneInput = it },
              label = { Text("Chaperone Status / Name") },
              modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
              value = interpreterLangInput,
              onValueChange = { interpreterLangInput = it },
              label = { Text("Interpreter Language & Booking ID") },
              modifier = Modifier.fillMaxWidth(),
            )
            Button(
              onClick = {
                onUpdateTools("Chaperone & Interpreter record saved") {
                  it.copy(chaperoneName = chaperoneInput, interpreterLanguage = interpreterLangInput)
                }
              },
              modifier = Modifier.minimumInteractiveComponentSize(),
            ) {
              Text("Save Consultation Governance")
            }
          }
        }

        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = ClinicalWhite),
          border = BorderStroke(1.dp, ClinicalBorder),
          modifier = Modifier.weight(1f),
        ) {
          Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Protected Clinical Image Attachment", style = MaterialTheme.typography.titleLarge)
            Text(
              "Stored exclusively within protected clinical workflow (never saved to personal device photo library).",
              style = MaterialTheme.typography.bodySmall,
              color = ClinicalSecondaryInk,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
              Checkbox(
                checked = effectiveState.imageConsentConfirmed,
                onCheckedChange = { checked ->
                  onUpdateTools("Clinical media consent updated") {
                    it.copy(imageConsentConfirmed = checked)
                  }
                },
                modifier = Modifier.testTag("image_consent_checkbox"),
              )
              Text("Explicit patient consent verified for clinical image")
            }
            if (effectiveState.clinicalImageAttached) {
              Image(
                painter = painterResource(id = R.drawable.img_synthetic_dermatology_lesion),
                contentDescription = stringResource(id = R.string.clinical_attachment_desc),
                modifier = Modifier.fillMaxWidth().height(150.dp),
                contentScale = ContentScale.Crop,
              )
              StatusPill("Protected Synthetic Clinical Image Attached", Icons.Filled.Lock, NhsGreenTint, NhsGreen)
            }
            Button(
              onClick = {
                onUpdateTools("Synthetic clinical image attached to protected encounter") {
                  it.copy(clinicalImageAttached = true)
                }
              },
              enabled = effectiveState.imageConsentConfirmed,
              modifier = Modifier.minimumInteractiveComponentSize().testTag("attach_synthetic_image_btn"),
            ) {
              Text(if (effectiveState.imageConsentConfirmed) "Attach Synthetic Clinical Diagram" else "Verify Consent First")
            }
          }
        }
      }
    }

    // Approved Leaflets & Referral Preparation
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = ClinicalWhite),
        border = BorderStroke(1.dp, ClinicalBorder),
      ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text("Approved Patient Leaflets & Referral Preparation", style = MaterialTheme.typography.titleLarge)
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(
              "Understanding Heart Failure (NHS Prototype)",
              "Safe Pain Relief With Kidney Conditions",
              "Anticoagulation Alert Card Guide",
            ).forEach { title ->
              val shared = effectiveState.sharedLeafletTitles.contains(title)
              FilterChip(
                selected = shared,
                onClick = {
                  onUpdateTools("Updated shared leaflets") { st ->
                    val next =
                      if (shared) st.sharedLeafletTitles - title else st.sharedLeafletTitles + title
                    st.copy(sharedLeafletTitles = next)
                  }
                },
                label = { Text(title) },
              )
            }
          }
          OutlinedTextField(
            value = referralInput,
            onValueChange = { referralInput = it },
            label = { Text("Referral & Follow-Up Draft") },
            minLines = 2,
            modifier = Modifier.fillMaxWidth(),
          )
          Button(
            onClick = { onRequestSendReferral(PendingSensitiveAction.SendReferral(referralInput)) },
            enabled = referralInput.isNotBlank(),
            modifier = Modifier.minimumInteractiveComponentSize(),
          ) {
            Text("Confirm Patient & Prepare Referral")
          }
        }
      }
    }
  }

  if (showSummaryPreview) {
    AlertDialog(
      onDismissRequest = { showSummaryPreview = false },
      title = { Text("Consultation Summary Preview — ${patient.fullName}") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text("NHS ${patient.nhsNumber} • ${patient.location}", style = MaterialTheme.typography.labelSmall)
          Text("Consent Documented: ${if (effectiveState.consentDocumented) "Yes" else "Pending"}")
          Text("Chaperone: ${effectiveState.chaperoneName}")
          Text("Body Diagram Annotations: ${strokes.size} stroke(s)")
          Text("Shared Leaflets: ${effectiveState.sharedLeafletTitles.joinToString().ifBlank { "None" }}")
          Text("Active Note Status: ${activeNote?.status?.label ?: "None"}")
          Text("Care Plan Approved: ${carePlan?.approvedByClinician ?: false}")
        }
      },
      confirmButton = { Button(onClick = { showSummaryPreview = false }) { Text("Close Preview") } },
    )
  }
}

@Composable
fun CarePlanScreen(
  patient: PatientRecord,
  existingPlan: CarePlanItem?,
  onSaveCarePlan: (CarePlanItem) -> Unit,
) {
  var patientFacingMode by remember { mutableStateOf(false) }
  var title by remember(existingPlan, patient.id) {
    mutableStateOf(existingPlan?.title ?: "Personalised Care & Follow-Up Plan")
  }
  var explanation by remember(existingPlan, patient.id) {
    mutableStateOf(
      existingPlan?.patientFriendlyExplanation
        ?: "Today we reviewed your symptoms, medicines, and recent tests. Here is your agreed plan in plain language."
    )
  }
  var goals by remember(existingPlan, patient.id) {
    mutableStateOf(existingPlan?.goals ?: "1. Take prescribed medicines as agreed.\n2. Attend scheduled blood tests.")
  }
  var warnings by remember(existingPlan, patient.id) {
    mutableStateOf(existingPlan?.warningSigns ?: "Seek urgent medical advice (111 / 999) if symptoms suddenly worsen.")
  }
  var followUp by remember(existingPlan, patient.id) {
    mutableStateOf(existingPlan?.followUpInstructions ?: "GP / Clinic follow-up in 2 weeks.")
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column {
          Text(
            "Patient-Friendly Care Plan",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.semantics { heading() },
          )
          Text(
            "Designed for bedside/clinic sharing with plain-English instructions and red-flag safety netting.",
            style = MaterialTheme.typography.bodySmall,
            color = ClinicalSecondaryInk,
          )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          FilterChip(
            selected = patientFacingMode,
            onClick = { patientFacingMode = !patientFacingMode },
            label = { Text(if (patientFacingMode) "Clinician Edit Mode" else "Patient-Facing View") },
            leadingIcon = { Icon(Icons.Outlined.Visibility, contentDescription = null) },
            modifier = Modifier.minimumInteractiveComponentSize().testTag("toggle_patient_careplan_view"),
          )
        }
      }
    }

    if (patientFacingMode) {
      item {
        Card(
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = ClinicalWhite),
          border = BorderStroke(2.dp, NhsBlue),
          modifier = Modifier.fillMaxWidth().testTag("patient_facing_careplan_card"),
        ) {
          Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            StatusPill("Your Care Plan — ${patient.fullName}", Icons.Filled.Favorite, NhsPaleBlue, NhsDarkBlue)
            Text(title, style = MaterialTheme.typography.headlineLarge, color = NhsDarkBlue)
            Text(explanation, style = MaterialTheme.typography.bodyLarge)
            HorizontalDivider(color = ClinicalBorder)
            Text("What to do next", style = MaterialTheme.typography.titleLarge, color = NhsBlue)
            Text(goals, style = MaterialTheme.typography.bodyLarge)
            Surface(color = NhsRedTint, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
              Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("When to get urgent help", style = MaterialTheme.typography.titleMedium, color = NhsRed)
                Text(warnings, style = MaterialTheme.typography.bodyLarge)
              }
            }
            Text("Follow-Up Appointments", style = MaterialTheme.typography.titleMedium, color = NhsDarkBlue)
            Text(followUp, style = MaterialTheme.typography.bodyLarge)
          }
        }
      }
    } else {
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = ClinicalWhite),
          border = BorderStroke(1.dp, ClinicalBorder),
        ) {
          Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Care Plan Title") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(
              value = explanation,
              onValueChange = { explanation = it },
              label = { Text("Plain-Language Summary for Patient") },
              minLines = 3,
              modifier = Modifier.fillMaxWidth().testTag("careplan_explanation_input"),
            )
            OutlinedTextField(value = goals, onValueChange = { goals = it }, label = { Text("Agreed Actions & Self-Care Goals") }, minLines = 3, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = warnings, onValueChange = { warnings = it }, label = { Text("Safety-Netting & Warning Signs") }, minLines = 2, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = followUp, onValueChange = { followUp = it }, label = { Text("Follow-Up Instructions") }, minLines = 2, modifier = Modifier.fillMaxWidth())

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
              OutlinedButton(
                onClick = {
                  onSaveCarePlan(
                    CarePlanItem(
                      id = existingPlan?.id ?: "cp_${patient.id}",
                      patientId = patient.id,
                      title = title,
                      patientFriendlyExplanation = explanation,
                      goals = goals,
                      warningSigns = warnings,
                      followUpInstructions = followUp,
                      approvedByClinician = false,
                      updatedAt = "",
                    )
                  )
                },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("save_careplan_draft_btn"),
              ) {
                Text("Save Draft")
              }
              Button(
                onClick = {
                  onSaveCarePlan(
                    CarePlanItem(
                      id = existingPlan?.id ?: "cp_${patient.id}",
                      patientId = patient.id,
                      title = title,
                      patientFriendlyExplanation = explanation,
                      goals = goals,
                      warningSigns = warnings,
                      followUpInstructions = followUp,
                      approvedByClinician = true,
                      updatedAt = "",
                    )
                  )
                },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("approve_careplan_btn"),
              ) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Approve Patient-Friendly Care Plan")
              }
            }
          }
        }
      }
    }
  }
}
