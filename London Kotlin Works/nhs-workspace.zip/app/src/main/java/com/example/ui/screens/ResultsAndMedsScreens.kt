package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.ui.components.StatusPill
import com.example.ui.theme.*
import com.example.ui.viewmodel.PendingSensitiveAction

@Composable
fun ObservationsAndResultsScreen(
  patient: PatientRecord,
  observations: List<ObservationPoint>,
  labResults: List<LabResult>,
  onTransitionResult: (LabResult, ResultReviewState) -> Unit,
  onCreateFollowUpTaskFromResult: (LabResult) -> Unit,
) {
  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    item {
      Text(
        "Observations & Laboratory Results",
        style = MaterialTheme.typography.headlineMedium,
        modifier = Modifier.semantics { heading() },
      )
      Text(
        "All reference intervals and critical flags shown below are supplied directly by the Trust LIMS / observation source.",
        style = MaterialTheme.typography.bodySmall,
        color = ClinicalSecondaryInk,
      )
    }

    // Observations & Trend Mini-Chart
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = ClinicalWhite),
        border = BorderStroke(1.dp, ClinicalBorder),
      ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text("Recent Observations (${observations.size})", style = MaterialTheme.typography.titleLarge)
          if (observations.isEmpty()) {
            MissingInfoBanner("No observations recorded in this encounter.")
          } else {
            observations.forEach { obs ->
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Column(Modifier.weight(1f)) {
                  Text("${obs.displayName}: ${obs.value} ${obs.unit}", style = MaterialTheme.typography.titleMedium, color = if (obs.isAbnormal) NhsRed else ClinicalInk)
                  Text("${obs.measuredAt} • Source: ${obs.provenance}", style = MaterialTheme.typography.bodySmall, color = ClinicalSecondaryInk)
                }
                StatusPill(
                  text = if (obs.isAbnormal) "Flagged by Source" else "Recorded",
                  icon = if (obs.isAbnormal) Icons.Filled.TrendingUp else Icons.Outlined.Check,
                  containerColor = if (obs.isAbnormal) NhsAmberTint else NhsGreenTint,
                  contentColor = if (obs.isAbnormal) NhsAmber else NhsGreen,
                )
              }
            }

            // Simple clinical trend sparkline for numeric observations
            val numericPoints = observations.map { it.numericValue.toFloat() }
            if (numericPoints.size >= 2) {
              Text("Encounter Observation Profile", style = MaterialTheme.typography.labelMedium, color = ClinicalSecondaryInk)
              Canvas(modifier = Modifier.fillMaxWidth().height(72.dp).padding(vertical = 4.dp)) {
                val minVal = numericPoints.minOrNull() ?: 0f
                val maxVal = (numericPoints.maxOrNull() ?: 1f).coerceAtLeast(minVal + 1f)
                val stepX = size.width / (numericPoints.size - 1).coerceAtLeast(1)
                val path = Path()
                numericPoints.forEachIndexed { idx, v ->
                  val x = idx * stepX
                  val norm = (v - minVal) / (maxVal - minVal)
                  val y = size.height - (norm * (size.height - 16f)) - 8f
                  if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
                  drawCircle(color = NhsBlue, radius = 6f, center = Offset(x, y))
                }
                drawPath(path = path, color = NhsBrightBlue, style = Stroke(width = 3.5f))
              }
            }
          }
        }
      }
    }

    // Lab Results
    items(labResults, key = { it.id }) { res ->
      val flagColors =
        when (res.criticalFlag) {
          LabCriticalFlag.NORMAL -> NhsGreenTint to NhsGreen
          LabCriticalFlag.ABNORMAL_HIGH,
          LabCriticalFlag.ABNORMAL_LOW,
          LabCriticalFlag.CORRECTED -> NhsAmberTint to NhsAmber
          LabCriticalFlag.CRITICAL -> NhsRedTint to NhsRed
        }

      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = ClinicalWhite),
        border = BorderStroke(if (res.reportStatus == LabReportStatus.CORRECTED) 1.5.dp else 1.dp, if (res.reportStatus == LabReportStatus.CORRECTED) NhsAmber else ClinicalBorder),
        modifier = Modifier.fillMaxWidth().testTag("lab_result_card_${res.id}"),
      ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(Modifier.weight(1f)) {
              Text("${res.testName} (${res.panelName})", style = MaterialTheme.typography.titleLarge)
              Text(
                "${res.value} ${res.unit}  •  Lab Ref: ${res.referenceInterval}",
                style = MaterialTheme.typography.titleMedium,
                color = flagColors.second,
              )
            }
            StatusPill(
              text = "${res.reportStatus.label} • ${res.criticalFlag.label}",
              icon = Icons.Filled.Science,
              containerColor = flagColors.first,
              contentColor = flagColors.second,
            )
          }

          if (res.previousValueIfCorrected != null) {
            Surface(color = NhsAmberTint, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
              Text(
                "CORRECTED REPORT — Previous value: ${res.previousValueIfCorrected}",
                style = MaterialTheme.typography.labelLarge,
                color = NhsAmber,
                modifier = Modifier.padding(10.dp),
              )
            }
          }

          Text(
            "Request: ${res.requestStatus} • Specimen: ${res.specimenCollectedAt} • Result Time: ${res.resultTime}",
            style = MaterialTheme.typography.bodySmall,
            color = ClinicalSecondaryInk,
          )
          Text(
            "Provenance: ${res.provenance} • Follow-Up Owner: ${res.followUpOwner}",
            style = MaterialTheme.typography.bodySmall,
            color = ClinicalSecondaryInk,
          )

          // Explicit 3-State Review Lifecycle
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            StatusPill(
              text = "State: ${res.reviewState.label}",
              icon = Icons.Outlined.FactCheck,
              containerColor = NhsPaleBlue,
              contentColor = NhsDarkBlue,
            )
            if (res.acknowledgedBy != null) {
              Text("Ack by ${res.acknowledgedBy} (${res.acknowledgedAt})", style = MaterialTheme.typography.labelSmall)
            }
            if (res.actionCompletedBy != null) {
              Text("Actioned by ${res.actionCompletedBy}", style = MaterialTheme.typography.labelSmall, color = NhsGreen)
            }
          }

          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (res.reviewState == ResultReviewState.UNVIEWED) {
              OutlinedButton(
                onClick = { onTransitionResult(res, ResultReviewState.VIEWED) },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("mark_viewed_${res.id}"),
              ) {
                Text("Mark Viewed")
              }
            }
            if (res.reviewState == ResultReviewState.UNVIEWED || res.reviewState == ResultReviewState.VIEWED) {
              Button(
                onClick = { onTransitionResult(res, ResultReviewState.ACKNOWLEDGED) },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("acknowledge_result_${res.id}"),
              ) {
                Text("Acknowledge (Keep Action Open)")
              }
            }
            if (res.reviewState != ResultReviewState.ACTION_COMPLETED) {
              FilledTonalButton(
                onClick = { onTransitionResult(res, ResultReviewState.ACTION_COMPLETED) },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("complete_action_${res.id}"),
              ) {
                Text("Mark Action Completed")
              }
            }
            OutlinedButton(
              onClick = { onCreateFollowUpTaskFromResult(res) },
              modifier = Modifier.minimumInteractiveComponentSize().testTag("assign_task_from_result_${res.id}"),
            ) {
              Icon(Icons.Outlined.AddTask, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(Modifier.width(4.dp))
              Text("Assign Task")
            }
          }
        }
      }
    }
  }
}

@Composable
fun MedicationsAndAllergiesScreen(
  patient: PatientRecord,
  allergies: List<AllergyEntry>,
  medications: List<MedicationEntry>,
  onUpdateReconciliation: (MedicationEntry, ReconciliationStatus) -> Unit,
  onRequestSimulatedPrescription: (PendingSensitiveAction.SubmitSimulatedOrder) -> Unit,
  onUpdateAllergyStatus: (AllergyAssessmentState, AllergyEntry?) -> Unit,
) {
  var showPrescribeDialog by remember { mutableStateOf(false) }
  var showAddAllergyDialog by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column {
          Text(
            "Medications & Allergy Reconciliation",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.semantics { heading() },
          )
          Text(
            "Prescribed, patient-reported, dispensed, and inpatient administration records are separated with explicit provenance.",
            style = MaterialTheme.typography.bodySmall,
            color = ClinicalSecondaryInk,
          )
        }
        Button(
          onClick = { showPrescribeDialog = true },
          modifier = Modifier.minimumInteractiveComponentSize().testTag("simulated_prescribe_btn"),
        ) {
          Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(Modifier.width(6.dp))
          Text("Simulated Order")
        }
      }
    }

    // Allergy Section
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = ClinicalWhite),
        border = BorderStroke(1.dp, ClinicalBorder),
      ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text("Allergies & Adverse Reactions", style = MaterialTheme.typography.titleLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              OutlinedButton(onClick = { onUpdateAllergyStatus(AllergyAssessmentState.NO_KNOWN_ALLERGIES, null) }) {
                Text("Mark NKA")
              }
              OutlinedButton(onClick = { showAddAllergyDialog = true }) {
                Text("Add Allergy")
              }
            }
          }
          StatusPill(
            text = patient.allergyStatus.label,
            icon = Icons.Filled.WarningAmber,
            containerColor =
              when (patient.allergyStatus) {
                AllergyAssessmentState.ASSESSED_WITH_REACTIONS -> NhsRedTint
                AllergyAssessmentState.NO_KNOWN_ALLERGIES -> NhsGreenTint
                else -> NhsAmberTint
              },
            contentColor =
              when (patient.allergyStatus) {
                AllergyAssessmentState.ASSESSED_WITH_REACTIONS -> NhsRed
                AllergyAssessmentState.NO_KNOWN_ALLERGIES -> NhsGreen
                else -> NhsAmber
              },
          )
          if (allergies.isEmpty() && patient.allergyStatus != AllergyAssessmentState.NO_KNOWN_ALLERGIES) {
            MissingInfoBanner(
              "Allergy information is ${patient.allergyStatus.label}. Clarify directly before simulated ordering."
            )
          } else {
            allergies.forEach { a ->
              Surface(color = NhsRedTint, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp)) {
                  Text("${a.substance} — ${a.reaction}", style = MaterialTheme.typography.titleMedium, color = NhsRed)
                  Text("Severity: ${a.severity} • Verification: ${a.verificationStatus} • Source: ${a.source} (${a.recordedBy}, ${a.recordedAt})", style = MaterialTheme.typography.bodySmall)
                }
              }
            }
          }
        }
      }
    }

    // Grouped Medication Categories
    MedicationCategory.entries.forEach { category ->
      val group = medications.filter { it.category == category }
      if (group.isNotEmpty()) {
        item {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = ClinicalWhite),
            border = BorderStroke(1.dp, ClinicalBorder),
          ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Text("${category.label} (${group.size})", style = MaterialTheme.typography.titleLarge, color = NhsDarkBlue)
              group.forEach { med ->
                Surface(
                  color = if (med.reconciliationStatus == ReconciliationStatus.DISCREPANCY) NhsAmberTint else NhsIceSurface,
                  shape = RoundedCornerShape(12.dp),
                  border = BorderStroke(1.dp, ClinicalBorder),
                  modifier = Modifier.fillMaxWidth(),
                ) {
                  Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically,
                    ) {
                      Text("${med.drugName} ${med.strength} — ${med.dose} ${med.route} ${med.frequency}", style = MaterialTheme.typography.titleMedium)
                      StatusPill(
                        text = med.reconciliationStatus.label,
                        icon = if (med.reconciliationStatus == ReconciliationStatus.DISCREPANCY) Icons.Filled.Warning else Icons.Filled.CheckCircle,
                        containerColor = if (med.reconciliationStatus == ReconciliationStatus.DISCREPANCY) NhsRedTint else NhsGreenTint,
                        contentColor = if (med.reconciliationStatus == ReconciliationStatus.DISCREPANCY) NhsRed else NhsGreen,
                      )
                    }
                    Text("Dates: ${med.startDate} to ${med.endDate} • Status: ${med.prescriptionStatus} • Source: ${med.informationSource}", style = MaterialTheme.typography.bodySmall, color = ClinicalSecondaryInk)
                    if (med.notes.isNotBlank()) {
                      Text("Note: ${med.notes}", style = MaterialTheme.typography.bodyMedium)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                      OutlinedButton(
                        onClick = { onUpdateReconciliation(med, ReconciliationStatus.RECONCILED) },
                        modifier = Modifier.minimumInteractiveComponentSize(),
                      ) {
                        Text("Mark Reconciled")
                      }
                      OutlinedButton(
                        onClick = { onUpdateReconciliation(med, ReconciliationStatus.DISCREPANCY) },
                        modifier = Modifier.minimumInteractiveComponentSize(),
                      ) {
                        Text("Flag Discrepancy")
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  if (showPrescribeDialog) {
    var drugName by remember { mutableStateOf("Furosemide") }
    var strength by remember { mutableStateOf("40 mg") }
    var dose by remember { mutableStateOf("40 mg") }
    var route by remember { mutableStateOf("Oral") }
    var frequency by remember { mutableStateOf("Once daily (morning)") }
    var notes by remember { mutableStateOf("Simulated prototype order — review U&Es in 7 days") }

    AlertDialog(
      onDismissRequest = { showPrescribeDialog = false },
      title = { Text("Simulated Medication Order (Prototype)") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          MissingInfoBanner("Simulated prescribing only. Real NHS prescribing requires an authorised ePMA integration and clinical validation.")
          OutlinedTextField(value = drugName, onValueChange = { drugName = it }, label = { Text("Drug Name") })
          OutlinedTextField(value = strength, onValueChange = { strength = it }, label = { Text("Strength") })
          OutlinedTextField(value = dose, onValueChange = { dose = it }, label = { Text("Dose") })
          OutlinedTextField(value = route, onValueChange = { route = it }, label = { Text("Route") })
          OutlinedTextField(value = frequency, onValueChange = { frequency = it }, label = { Text("Frequency") })
          OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Clinical Indication / Notes") })
        }
      },
      confirmButton = {
        Button(
          onClick = {
            showPrescribeDialog = false
            onRequestSimulatedPrescription(
              PendingSensitiveAction.SubmitSimulatedOrder(drugName, strength, dose, route, frequency, notes)
            )
          },
          enabled = drugName.isNotBlank(),
        ) {
          Text("Continue to Patient Confirmation")
        }
      },
      dismissButton = { OutlinedButton(onClick = { showPrescribeDialog = false }) { Text("Cancel") } },
    )
  }

  if (showAddAllergyDialog) {
    var substance by remember { mutableStateOf("") }
    var reaction by remember { mutableStateOf("") }
    var severity by remember { mutableStateOf("Moderate") }
    AlertDialog(
      onDismissRequest = { showAddAllergyDialog = false },
      title = { Text("Document Allergy / Adverse Reaction") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(value = substance, onValueChange = { substance = it }, label = { Text("Substance") })
          OutlinedTextField(value = reaction, onValueChange = { reaction = it }, label = { Text("Reaction") })
          OutlinedTextField(value = severity, onValueChange = { severity = it }, label = { Text("Severity (Mild/Moderate/Severe/Not documented)") })
        }
      },
      confirmButton = {
        Button(
          onClick = {
            onUpdateAllergyStatus(
              AllergyAssessmentState.ASSESSED_WITH_REACTIONS,
              AllergyEntry(
                id = "alg_${System.currentTimeMillis()}",
                patientId = patient.id,
                substance = substance,
                reaction = reaction,
                severity = severity,
                verificationStatus = "Confirmed with patient",
                source = "Clinician Consultation Assessment",
                recordedBy = "Active Clinician",
                recordedAt = "Today",
              ),
            )
            showAddAllergyDialog = false
          },
          enabled = substance.isNotBlank() && reaction.isNotBlank(),
        ) {
          Text("Save Allergy")
        }
      },
      dismissButton = { OutlinedButton(onClick = { showAddAllergyDialog = false }) { Text("Cancel") } },
    )
  }
}
