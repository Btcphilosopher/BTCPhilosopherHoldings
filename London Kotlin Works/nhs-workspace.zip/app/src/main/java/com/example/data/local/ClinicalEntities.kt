package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import com.example.data.model.AllergyAssessmentState
import com.example.data.model.IdentityVerificationStatus
import com.example.data.model.LabCriticalFlag
import com.example.data.model.LabReportStatus
import com.example.data.model.MedicationCategory
import com.example.data.model.MessageDeliveryState
import com.example.data.model.NoteStatus
import com.example.data.model.NoteTemplateType
import com.example.data.model.ReconciliationStatus
import com.example.data.model.RecordAvailabilityState
import com.example.data.model.ResultReviewState
import com.example.data.model.SyncStatus
import com.example.data.model.TaskPriority
import com.example.data.model.TaskStatus
import org.json.JSONArray

class ClinicalTypeConverters {
  @TypeConverter
  fun fromStringList(list: List<String>): String = JSONArray(list).toString()

  @TypeConverter
  fun toStringList(raw: String): List<String> {
    if (raw.isBlank()) return emptyList()
    val arr = JSONArray(raw)
    return (0 until arr.length()).map { arr.getString(it) }
  }
}

@Entity(tableName = "patients")
data class PatientEntity(
  @PrimaryKey val id: String,
  val nhsNumber: String,
  val mrn: String,
  val nhsNumberVerified: Boolean,
  val demographicsVerified: Boolean,
  val identityStatus: IdentityVerificationStatus,
  val duplicateCandidateIds: List<String>,
  val fullName: String,
  val preferredName: String,
  val dateOfBirth: String,
  val sex: String,
  val address: String,
  val gpPractice: String,
  val encounterId: String,
  val encounterType: String,
  val location: String,
  val service: String,
  val ward: String,
  val clinic: String,
  val assignedClinicianId: String,
  val allergyStatus: AllergyAssessmentState,
  val recordAlerts: List<String>,
  val presentingProblem: String,
  val historySummary: String,
  val historyStatus: RecordAvailabilityState,
  val medicationHistoryStatus: RecordAvailabilityState,
  val observationsStatus: RecordAvailabilityState,
  val lastSyncedAt: Long,
)

@Entity(tableName = "appointments")
data class AppointmentEntity(
  @PrimaryKey val id: String,
  val patientId: String,
  val patientName: String,
  val timeSlot: String,
  val clinicName: String,
  val service: String,
  val clinicianId: String,
  val reason: String,
  val status: String,
)

@Entity(tableName = "allergies")
data class AllergyEntity(
  @PrimaryKey val id: String,
  val patientId: String,
  val substance: String,
  val reaction: String,
  val severity: String,
  val verificationStatus: String,
  val source: String,
  val recordedBy: String,
  val recordedAt: String,
)

@Entity(tableName = "problems")
data class ProblemEntity(
  @PrimaryKey val id: String,
  val patientId: String,
  val title: String,
  val code: String,
  val status: String,
  val source: String,
  val author: String,
  val timestamp: String,
)

@Entity(tableName = "encounters")
data class EncounterEntity(
  @PrimaryKey val id: String,
  val patientId: String,
  val encounterType: String,
  val location: String,
  val clinician: String,
  val dateLabel: String,
  val summary: String,
)

@Entity(tableName = "medications")
data class MedicationEntity(
  @PrimaryKey val id: String,
  val patientId: String,
  val drugName: String,
  val strength: String,
  val dose: String,
  val route: String,
  val frequency: String,
  val startDate: String,
  val endDate: String,
  val category: MedicationCategory,
  val prescriptionStatus: String,
  val informationSource: String,
  val reconciliationStatus: ReconciliationStatus,
  val notes: String,
)

@Entity(tableName = "observations")
data class ObservationEntity(
  @PrimaryKey val id: String,
  val patientId: String,
  val metricType: String,
  val displayName: String,
  val value: String,
  val numericValue: Double,
  val unit: String,
  val measuredAt: String,
  val provenance: String,
  val isAbnormal: Boolean,
)

@Entity(tableName = "lab_results")
data class LabResultEntity(
  @PrimaryKey val id: String,
  val patientId: String,
  val testName: String,
  val panelName: String,
  val value: String,
  val unit: String,
  val referenceInterval: String,
  val criticalFlag: LabCriticalFlag,
  val requestStatus: String,
  val specimenCollectedAt: String,
  val resultTime: String,
  val reportStatus: LabReportStatus,
  val reviewState: ResultReviewState,
  val acknowledgedBy: String?,
  val acknowledgedAt: String?,
  val actionCompletedBy: String?,
  val actionCompletedAt: String?,
  val followUpOwner: String,
  val linkedTaskId: String?,
  val provenance: String,
  val previousValueIfCorrected: String?,
)

@Entity(tableName = "clinical_notes")
data class ClinicalNoteEntity(
  @PrimaryKey val id: String,
  val patientId: String,
  val encounterId: String,
  val templateType: NoteTemplateType,
  val status: NoteStatus,
  val authorId: String,
  val authorName: String,
  val createdAt: String,
  val updatedAt: String,
  val signedAt: String?,
  val serverVersion: Int,
  val historyText: String,
  val examinationText: String,
  val assessmentText: String,
  val planText: String,
  val specialtyExtraText: String,
  val freeText: String,
  val carriedForwardAttribution: String?,
  val isLocalOfflineDraft: Boolean,
  val hasConflict: Boolean,
  val remoteConflictEditor: String?,
  val remoteConflictSummary: String?,
  val enteredInErrorReason: String?,
)

@Entity(tableName = "note_versions")
data class NoteVersionEntity(
  @PrimaryKey val id: String,
  val noteId: String,
  val versionNumber: Int,
  val status: NoteStatus,
  val editorName: String,
  val timestamp: String,
  val changeSummary: String,
  val snapshotText: String,
)

@Entity(tableName = "note_addenda")
data class NoteAddendumEntity(
  @PrimaryKey val id: String,
  val noteId: String,
  val authorName: String,
  val timestamp: String,
  val reason: String,
  val text: String,
)

@Entity(tableName = "care_plans")
data class CarePlanEntity(
  @PrimaryKey val id: String,
  val patientId: String,
  val title: String,
  val patientFriendlyExplanation: String,
  val goals: String,
  val warningSigns: String,
  val followUpInstructions: String,
  val approvedByClinician: Boolean,
  val updatedAt: String,
)

@Entity(tableName = "clinical_tasks")
data class ClinicalTaskEntity(
  @PrimaryKey val id: String,
  val patientId: String,
  val title: String,
  val ownerName: String,
  val ownerRole: String,
  val priority: TaskPriority,
  val dueTime: String,
  val status: TaskStatus,
  val supportingContext: String,
  val completionEvidence: String?,
  val linkedResultId: String?,
)

@Entity(tableName = "handovers")
data class HandoverSbarEntity(
  @PrimaryKey val id: String,
  val patientId: String,
  val situation: String,
  val background: String,
  val assessment: String,
  val recommendation: String,
  val authorName: String,
  val updatedAt: String,
  val acknowledgedBy: String?,
)

@Entity(tableName = "team_messages")
data class TeamMessageEntity(
  @PrimaryKey val id: String,
  val patientId: String,
  val senderName: String,
  val senderRole: String,
  val recipientTeam: String,
  val body: String,
  val timestamp: String,
  val deliveryState: MessageDeliveryState,
)

@Entity(tableName = "body_strokes")
data class BodyStrokeEntity(
  @PrimaryKey val id: String,
  val patientId: String,
  val regionLabel: String,
  val pointsSerialized: String,
  val colorHex: Long,
  val strokeWidth: Float,
)

@Entity(tableName = "consultation_tools")
data class ConsultationToolEntity(
  @PrimaryKey val patientId: String,
  val consentDocumented: Boolean,
  val consentScope: String,
  val consentClinician: String,
  val consentTimestamp: String,
  val chaperoneName: String,
  val interpreterLanguage: String,
  val interpreterId: String,
  val sharedLeafletTitles: List<String>,
  val clinicalImageAttached: Boolean,
  val imageConsentConfirmed: Boolean,
  val imageAttribution: String,
  val referralDraftSummary: String,
)

@Entity(tableName = "audit_events")
data class AuditEventEntity(
  @PrimaryKey val id: String,
  val timestamp: String,
  val actorName: String,
  val actorRole: String,
  val actionType: String,
  val patientId: String,
  val patientName: String,
  val resourceSummary: String,
  val outcome: String,
  val isBreakGlass: Boolean,
  val detail: String,
)

@Entity(tableName = "sync_queue")
data class SyncQueueEntity(
  @PrimaryKey val id: String,
  val entityType: String,
  val entityId: String,
  val patientId: String,
  val summary: String,
  val queuedAt: String,
  val status: SyncStatus,
)
