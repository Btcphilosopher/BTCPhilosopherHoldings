package com.example.data.ai

import android.util.Log
import com.example.data.model.AiAssistantProposal
import com.example.data.model.AiCitationStatement
import com.example.data.model.AllergyEntry
import com.example.data.model.ClinicalNote
import com.example.data.model.ClinicalTask
import com.example.data.model.LabResult
import com.example.data.model.MedicationEntry
import com.example.data.model.PatientRecord
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

private const val TAG = "ClinicalAiAssistant"

enum class AiAssistTask(val title: String, val subtitle: String) {
  RECORD_SUMMARY("Prepare Draft Summary", "Summarise authorised chart with citations & missing-data preservation"),
  NOTE_STRUCTURE("Suggest Note Structure", "Propose structured headings from current encounter context"),
  EXTRACT_TASKS("Extract Proposed Tasks", "Identify candidate follow-up tasks from clinician draft"),
  PATIENT_EXPLANATION("Draft Patient-Friendly Explanation", "Plain-English summary for clinician review before sharing"),
}

class ClinicalAiAssistant {
  private val responseSchema =
    Schema.obj(
      properties =
        mapOf(
          "statements" to
            Schema.array(
              items =
                Schema.obj(
                  properties =
                    mapOf(
                      "statement" to
                        Schema.string(description = "Clinical draft statement preserving uncertainty and missing info"),
                      "supportingRecordRef" to
                        Schema.string(
                          description = "Exact record ID or source citation, or empty if unsupported",
                          nullable = true,
                        ),
                      "isUnsupported" to
                        Schema.boolean(description = "True if not directly backed by supplied records"),
                    )
                )
            ),
          "editableDraftText" to
            Schema.string(description = "Clean draft text ready for clinician review before saving"),
          "extractedTasks" to
            Schema.array(
              items = Schema.string(),
              description = "Proposed follow-up tasks for clinician confirmation",
            ),
        )
    )

  private val model by lazy {
    Firebase.ai.generativeModel(
      modelName = "gemini-3.8-flash",
      generationConfig =
        generationConfig {
          responseMimeType = "application/json"
          responseSchema = this@ClinicalAiAssistant.responseSchema
        },
    )
  }

  suspend fun generateProposal(
    task: AiAssistTask,
    patient: PatientRecord,
    allergies: List<AllergyEntry>,
    medications: List<MedicationEntry>,
    results: List<LabResult>,
    activeNote: ClinicalNote?,
    tasks: List<ClinicalTask>,
    orgAiApprovalEnabled: Boolean,
    isOnline: Boolean,
  ): Result<AiAssistantProposal> {
    if (!orgAiApprovalEnabled || !isOnline) {
      return Result.success(
        buildLocalRecordGroundedProposal(
          task = task,
          patient = patient,
          allergies = allergies,
          medications = medications,
          results = results,
          activeNote = activeNote,
          tasks = tasks,
          reason =
            if (!orgAiApprovalEnabled) {
              "External AI disabled: Organisational IG data arrangement approval is OFF. Generated locally from authorised synthetic chart without external transmission."
            } else {
              "Offline mode active: Generated locally from cached chart without external transmission."
            },
        )
      )
    }

    val prompt = buildString {
      appendLine("You are an NHS clinical documentation drafting assistant for an independent synthetic prototype.")
      appendLine("SAFETY RULES (MANDATORY):")
      appendLine("1. NEVER diagnose, prescribe, sign notes, submit orders, or close results.")
      appendLine("2. Cite exact record IDs (e.g., [lab_01], [med_04], [alg_01], [note_01]) for every clinical statement, or mark isUnsupported=true.")
      appendLine("3. Explicitly preserve uncertainty, contradictions (e.g. OTC medications vs prescribed), and missing data (Not Assessed / Information Unavailable).")
      appendLine("4. Output is a DRAFT proposal requiring clinician review before entering the record.")
      appendLine()
      appendLine("TASK: ${task.title} (${task.subtitle})")
      appendLine("PATIENT CONTEXT (Synthetic Record ID ${patient.id}):")
      appendLine("- Identity Status: ${patient.identityStatus.label}, Encounter: ${patient.encounterType} @ ${patient.location}")
      appendLine("- Presenting Problem: ${patient.presentingProblem}")
      appendLine("- History (${patient.historyStatus.label}): ${patient.historySummary.ifBlank { "None documented" }}")
      appendLine("- Allergy Status (${patient.allergyStatus.label}): " +
        if (allergies.isEmpty()) "No allergy entries recorded"
        else allergies.joinToString("; ") { "[${it.id}] ${it.substance}: ${it.reaction} (${it.severity}, ${it.verificationStatus})" })
      appendLine("- Medications (${patient.medicationHistoryStatus.label}): " +
        if (medications.isEmpty()) "No medication entries"
        else medications.joinToString("; ") { "[${it.id}] ${it.drugName} ${it.dose} ${it.frequency} [${it.category.label}, ${it.reconciliationStatus.label}]" })
      appendLine("- Lab Results: " +
        if (results.isEmpty()) "None"
        else results.joinToString("; ") { "[${it.id}] ${it.testName}=${it.value} ${it.unit} (Ref ${it.referenceInterval}, ${it.reportStatus.label}, ${it.reviewState.label}, prev=${it.previousValueIfCorrected ?: "none"})" })
      appendLine("- Existing Tasks: " + tasks.joinToString("; ") { "[${it.id}] ${it.title} (${it.status.label})" })
      if (activeNote != null) {
        appendLine("- Current Clinician Draft [${activeNote.id}]: Hx='${activeNote.historyText}', Exam='${activeNote.examinationText}', Ax='${activeNote.assessmentText}', Plan='${activeNote.planText}', Free='${activeNote.freeText}'")
      }
    }

    return try {
      val response = withTimeout(60_000L) { model.generateContent(prompt) }
      val raw = response.text ?: throw IllegalStateException("AI model returned empty text.")
      val json = JSONObject(raw)
      val stmtArray = json.getJSONArray("statements")
      val statements =
        (0 until stmtArray.length()).map { i ->
          val item = stmtArray.getJSONObject(i)
          val ref = item.optString("supportingRecordRef").takeIf { it.isNotBlank() && it != "null" }
          AiCitationStatement(
            statement = item.getString("statement"),
            supportingRecordRef = ref,
            isUnsupported = item.optBoolean("isUnsupported", ref == null),
          )
        }
      val taskArray = json.getJSONArray("extractedTasks")
      val extracted = (0 until taskArray.length()).map { taskArray.getString(it) }
      Result.success(
        AiAssistantProposal(
          mode = task.title,
          usedExternalModel = true,
          provenanceNotice =
            "Generated via Firebase AI Logic (gemini-3.8-flash) under Organisational Prototype IG Toggle • Clinician review required before saving.",
          statements = statements,
          rawEditableText = json.getString("editableDraftText"),
          extractedTasks = extracted,
        )
      )
    } catch (e: TimeoutCancellationException) {
      Log.e(TAG, "AI assistant generation timed out", e)
      Result.failure(IllegalStateException("AI assistant timed out after 60 seconds. Local clinical workspace remains unaffected."))
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      Log.e(TAG, "Firebase AI Logic generation failed", e)
      Result.failure(IllegalStateException(e.localizedMessage ?: "External AI request failed."))
    }
  }

  private fun buildLocalRecordGroundedProposal(
    task: AiAssistTask,
    patient: PatientRecord,
    allergies: List<AllergyEntry>,
    medications: List<MedicationEntry>,
    results: List<LabResult>,
    activeNote: ClinicalNote?,
    tasks: List<ClinicalTask>,
    reason: String,
  ): AiAssistantProposal {
    val statements = mutableListOf<AiCitationStatement>()
    statements +=
      AiCitationStatement(
        statement = "Presenting problem: ${patient.presentingProblem}",
        supportingRecordRef = "${patient.id} (${patient.encounterId})",
        isUnsupported = false,
      )
    statements +=
      AiCitationStatement(
        statement =
          if (allergies.isNotEmpty()) {
            "Allergies (${patient.allergyStatus.label}): " +
              allergies.joinToString("; ") { "${it.substance} (${it.reaction}, ${it.verificationStatus})" }
          } else {
            "Allergy assessment status: ${patient.allergyStatus.label} — verify directly with patient."
          },
        supportingRecordRef = allergies.firstOrNull()?.id ?: patient.id,
        isUnsupported = false,
      )

    val discrepancies = medications.filter { it.reconciliationStatus.name == "DISCREPANCY" }
    if (discrepancies.isNotEmpty()) {
      statements +=
        AiCitationStatement(
          statement =
            "Medication discrepancy flagged: " +
              discrepancies.joinToString { "${it.drugName} (${it.category.label}: ${it.notes})" },
          supportingRecordRef = discrepancies.first().id,
          isUnsupported = false,
        )
    }

    results.firstOrNull()?.let { lab ->
      statements +=
        AiCitationStatement(
          statement =
            "Key result: ${lab.testName} ${lab.value} ${lab.unit} (Ref ${lab.referenceInterval}, ${lab.reportStatus.label}, ${lab.reviewState.label}).",
          supportingRecordRef = lab.id,
          isUnsupported = false,
        )
    }

    val extractedTasks =
      when (task) {
        AiAssistTask.EXTRACT_TASKS -> {
          val fromPlan =
            activeNote?.planText
              ?.lines()
              ?.map { it.trim().trimStart('1', '2', '3', '.', '-', ' ') }
              ?.filter { it.isNotBlank() }
              .orEmpty()
          if (fromPlan.isNotEmpty()) fromPlan
          else listOf("Confirm medication reconciliation & review pending lab results for ${patient.fullName}")
        }
        else ->
          tasks.filter { it.status.name != "COMPLETED" }.map { "Existing: ${it.title} (${it.dueTime})" }
      }

    val editableText =
      when (task) {
        AiAssistTask.RECORD_SUMMARY ->
          statements.joinToString("\n") { "• ${it.statement} [${it.supportingRecordRef ?: "UNSUPPORTED"}]" }
        AiAssistTask.NOTE_STRUCTURE ->
          "Suggested Structure (${activeNote?.templateType?.label ?: "Consultation"}):\n" +
            "- History & Trigger: Document symptom timeline & OTC exposure.\n" +
            "- Allergy & Med Reconciliation: Confirm ${patient.allergyStatus.label}.\n" +
            "- Observations & Results Review: Address pending/corrected results.\n" +
            "- Assessment & Explicit Follow-Up Plan: Assign task owners."
        AiAssistTask.EXTRACT_TASKS ->
          "Candidate Follow-Up Tasks (Confirm before creating):\n" +
            extractedTasks.joinToString("\n") { "- $it" }
        AiAssistTask.PATIENT_EXPLANATION ->
          "Draft Patient Summary (Clinician Review Required):\n" +
            "Today we reviewed your symptoms (${patient.presentingProblem.lowercase()}). " +
            "We checked your current medicines and recent test results, and agreed next steps together. " +
            "Please contact your GP or attend urgent care if your symptoms worsen."
      }

    return AiAssistantProposal(
      mode = task.title,
      usedExternalModel = false,
      provenanceNotice = reason,
      statements = statements,
      rawEditableText = editableText,
      extractedTasks = extractedTasks,
    )
  }
}
