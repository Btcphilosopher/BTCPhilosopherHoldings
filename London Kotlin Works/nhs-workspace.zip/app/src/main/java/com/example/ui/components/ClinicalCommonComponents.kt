package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.PendingSensitiveAction
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun StatusPill(
  text: String,
  icon: ImageVector,
  containerColor: Color,
  contentColor: Color,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(999.dp),
    color = containerColor,
    border = BorderStroke(1.dp, contentColor.copy(alpha = 0.25f)),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = contentColor,
        modifier = Modifier.size(15.dp),
      )
      Text(
        text = text,
        style = MaterialTheme.typography.labelMedium,
        color = contentColor,
        fontWeight = FontWeight.SemiBold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
fun PrototypeNoticeBar(
  isOnline: Boolean,
  lastSyncLabel: String,
  pendingSyncCount: Int,
  concealNotifications: Boolean,
  onToggleOnline: () -> Unit,
  onSyncNow: () -> Unit,
  onToggleInspector: () -> Unit,
  onLockSession: () -> Unit,
) {
  Surface(
    color = MaterialTheme.colorScheme.surface,
    tonalElevation = 1.dp,
    modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outline),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.weight(1f),
      ) {
        StatusPill(
          text = "INDEPENDENT PROTOTYPE • SYNTHETIC DATA",
          icon = Icons.Filled.VerifiedUser,
          containerColor = NhsPaleBlue,
          contentColor = NhsDarkBlue,
        )
        if (concealNotifications) {
          StatusPill(
            text = "Previews Concealed",
            icon = Icons.Outlined.VisibilityOff,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        StatusPill(
          text =
            if (isOnline) "Online • $lastSyncLabel"
            else "Offline • Cached ($pendingSyncCount queued)",
          icon = if (isOnline) Icons.Filled.CloudDone else Icons.Filled.CloudOff,
          containerColor = if (isOnline) NhsGreenTint else NhsAmberTint,
          contentColor = if (isOnline) NhsGreen else NhsAmber,
        )
      }

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        OutlinedButton(
          onClick = onToggleOnline,
          modifier = Modifier.minimumInteractiveComponentSize().testTag("toggle_offline_btn"),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
        ) {
          Icon(
            imageVector = if (isOnline) Icons.Outlined.WifiOff else Icons.Outlined.Wifi,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
          )
          Spacer(Modifier.width(4.dp))
          Text(if (isOnline) "Simulate Offline" else "Reconnect", style = MaterialTheme.typography.labelMedium)
        }
        if (isOnline && pendingSyncCount > 0) {
          FilledTonalButton(
            onClick = onSyncNow,
            modifier = Modifier.minimumInteractiveComponentSize().testTag("sync_now_btn"),
          ) {
            Icon(Icons.Filled.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text("Sync ($pendingSyncCount)")
          }
        }
        IconButton(
          onClick = onToggleInspector,
          modifier = Modifier.minimumInteractiveComponentSize().testTag("toggle_inspector_btn"),
        ) {
          Icon(Icons.Outlined.ViewSidebar, contentDescription = "Toggle detail inspector")
        }
        IconButton(
          onClick = onLockSession,
          modifier = Modifier.minimumInteractiveComponentSize().testTag("lock_session_btn"),
        ) {
          Icon(Icons.Outlined.Lock, contentDescription = "Lock clinical session")
        }
      }
    }
  }
}

@Composable
fun PersistentPatientBanner(
  patient: PatientRecord,
  allergies: List<AllergyEntry>,
  isIdentityConfirmed: Boolean,
  isOnline: Boolean,
  onConfirmIdentity: () -> Unit,
  onOpenSearch: () -> Unit,
) {
  val isUrgentIdentityWarning =
    patient.identityStatus == IdentityVerificationStatus.UNCERTAIN_IDENTITY ||
      patient.identityStatus == IdentityVerificationStatus.DUPLICATE_SUSPECTED

  val allergyColors =
    when (patient.allergyStatus) {
      AllergyAssessmentState.ASSESSED_WITH_REACTIONS -> NhsRedTint to NhsRed
      AllergyAssessmentState.NO_KNOWN_ALLERGIES -> NhsGreenTint to NhsGreen
      AllergyAssessmentState.NOT_ASSESSED,
      AllergyAssessmentState.INFORMATION_UNAVAILABLE -> NhsAmberTint to NhsAmber
    }

  val allergyIcon =
    when (patient.allergyStatus) {
      AllergyAssessmentState.ASSESSED_WITH_REACTIONS -> Icons.Filled.Warning
      AllergyAssessmentState.NO_KNOWN_ALLERGIES -> Icons.Filled.CheckCircle
      AllergyAssessmentState.NOT_ASSESSED -> Icons.Filled.HelpOutline
      AllergyAssessmentState.INFORMATION_UNAVAILABLE -> Icons.Filled.Info
    }

  val allergySummaryText =
    when (patient.allergyStatus) {
      AllergyAssessmentState.ASSESSED_WITH_REACTIONS ->
        if (allergies.isEmpty()) "Allergies Documented"
        else "ALLERGY: " + allergies.joinToString("; ") { "${it.substance} (${it.severity})" }
      AllergyAssessmentState.NO_KNOWN_ALLERGIES -> "No Known Allergies (Assessed)"
      AllergyAssessmentState.NOT_ASSESSED -> "Allergy Status: Not Assessed"
      AllergyAssessmentState.INFORMATION_UNAVAILABLE -> "Allergy Status: Information Unavailable"
    }

  val syncTimeText = remember(patient.lastSyncedAt) {
    SimpleDateFormat("HH:mm", Locale.UK).format(Date(patient.lastSyncedAt))
  }

  Surface(
    color = if (isUrgentIdentityWarning) NhsAmberTint.copy(alpha = 0.55f) else ClinicalWhite,
    tonalElevation = 2.dp,
    border =
      BorderStroke(
        width = if (isUrgentIdentityWarning) 1.5.dp else 1.dp,
        color = if (isUrgentIdentityWarning) NhsAmber else ClinicalBorder,
      ),
    modifier = Modifier.fillMaxWidth().testTag("persistent_patient_banner"),
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Text(
              text = patient.fullName,
              style = MaterialTheme.typography.headlineMedium,
              color = ClinicalInk,
              modifier = Modifier.semantics { heading() },
            )
            if (patient.preferredName.isNotBlank() &&
              !patient.fullName.contains(patient.preferredName, ignoreCase = true)
            ) {
              Text(
                text = "Prefers \"${patient.preferredName}\"",
                style = MaterialTheme.typography.labelLarge,
                color = ClinicalSecondaryInk,
              )
            }
            StatusPill(
              text = patient.identityStatus.label,
              icon =
                when (patient.identityStatus) {
                  IdentityVerificationStatus.VERIFIED -> Icons.Filled.Verified
                  IdentityVerificationStatus.UNVERIFIED_DEMOGRAPHICS -> Icons.Filled.ReportProblem
                  IdentityVerificationStatus.UNCERTAIN_IDENTITY,
                  IdentityVerificationStatus.DUPLICATE_SUSPECTED -> Icons.Filled.ErrorOutline
                },
              containerColor =
                if (patient.identityStatus == IdentityVerificationStatus.VERIFIED) NhsGreenTint
                else NhsAmberTint,
              contentColor =
                if (patient.identityStatus == IdentityVerificationStatus.VERIFIED) NhsGreen
                else NhsAmber,
            )
          }

          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
          ) {
            Text(
              text = "DOB: ${patient.dateOfBirth} • ${patient.sex}",
              style = MaterialTheme.typography.bodyMedium,
              color = ClinicalInk,
            )
            Text(
              text =
                "NHS: ${patient.nhsNumber} (${if (patient.nhsNumberVerified) "Verified" else "Unverified"}) • MRN: ${patient.mrn}",
              style = MaterialTheme.typography.labelSmall,
              color = NhsDarkBlue,
            )
            Text(
              text = "${patient.encounterType} • ${patient.location}",
              style = MaterialTheme.typography.bodyMedium,
              color = ClinicalSecondaryInk,
            )
            if (!isOnline) {
              Text(
                text = "Cached $syncTimeText",
                style = MaterialTheme.typography.labelSmall,
                color = NhsAmber,
              )
            }
          }
        }

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          if (isIdentityConfirmed) {
            StatusPill(
              text = "Patient Confirmed",
              icon = Icons.Filled.CheckCircle,
              containerColor = NhsGreenTint,
              contentColor = NhsGreen,
            )
          } else {
            Button(
              onClick = onConfirmIdentity,
              colors =
                ButtonDefaults.buttonColors(
                  containerColor = if (isUrgentIdentityWarning) NhsAmber else NhsBlue
                ),
              modifier = Modifier.minimumInteractiveComponentSize().testTag("confirm_patient_button"),
            ) {
              Icon(Icons.Filled.HowToReg, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(Modifier.width(6.dp))
              Text(
                if (patient.identityStatus == IdentityVerificationStatus.VERIFIED)
                  "Confirm Patient"
                else "Verify & Resolve Identity"
              )
            }
          }
          OutlinedButton(
            onClick = onOpenSearch,
            modifier = Modifier.minimumInteractiveComponentSize().testTag("switch_patient_button"),
          ) {
            Icon(Icons.Outlined.SwapHoriz, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(4.dp))
            Text("Switch")
          }
        }
      }

      // Allergy & Alerts Strip
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        StatusPill(
          text = allergySummaryText,
          icon = allergyIcon,
          containerColor = allergyColors.first,
          contentColor = allergyColors.second,
        )
        patient.recordAlerts.forEach { alert ->
          StatusPill(
            text = alert,
            icon = Icons.Outlined.NotificationImportant,
            containerColor = NhsPaleBlue,
            contentColor = NhsDarkBlue,
          )
        }
      }
    }
  }
}

@Composable
fun PatientSwitchGuardDialog(
  targetPatient: PatientRecord,
  onSaveAndSwitch: () -> Unit,
  onDiscardAndSwitch: () -> Unit,
  onCancel: () -> Unit,
) {
  AlertDialog(
    onDismissRequest = onCancel,
    icon = { Icon(Icons.Filled.Shield, contentDescription = null, tint = NhsAmber) },
    title = { Text("Unsaved Clinical Draft Detected") },
    text = {
      Text(
        "You have unsaved edits in the current patient's consultation note. Switching directly to ${targetPatient.fullName} will NEVER silently reassign your draft.\n\nChoose how to handle your current draft before switching records:"
      )
    },
    confirmButton = {
      Button(
        onClick = onSaveAndSwitch,
        modifier = Modifier.testTag("switch_guard_save_btn"),
      ) {
        Text("Save Draft to Current Patient & Switch")
      }
    },
    dismissButton = {
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        TextButton(
          onClick = onDiscardAndSwitch,
          modifier = Modifier.testTag("switch_guard_discard_btn"),
        ) {
          Text("Discard Draft", color = NhsRed)
        }
        OutlinedButton(onClick = onCancel) { Text("Cancel") }
      }
    },
  )
}

@Composable
fun BreakGlassDialog(
  patient: PatientRecord,
  requiredScope: String,
  onConfirmBreakGlass: (String) -> Unit,
  onDismiss: () -> Unit,
) {
  var reason by remember { mutableStateOf("") }
  AlertDialog(
    onDismissRequest = onDismiss,
    icon = { Icon(Icons.Filled.GppMaybe, contentDescription = null, tint = NhsRed) },
    title = { Text("Restricted Care-Context Access") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          "Your active role scope does not include $requiredScope for ${patient.fullName}.",
          style = MaterialTheme.typography.bodyMedium,
        )
        Text(
          "To invoke audited Emergency Break-Glass access, record your clinical justification below. This override is logged immediately in the audit trail.",
          style = MaterialTheme.typography.bodySmall,
          color = ClinicalSecondaryInk,
        )
        OutlinedTextField(
          value = reason,
          onValueChange = { reason = it },
          label = { Text("Emergency access reason (mandatory)") },
          placeholder = { Text("e.g., Covering acute ward arrest / urgent potassium review") },
          modifier = Modifier.fillMaxWidth().testTag("break_glass_reason_input"),
          minLines = 2,
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { onConfirmBreakGlass(reason) },
        enabled = reason.trim().length >= 6,
        colors = ButtonDefaults.buttonColors(containerColor = NhsRed),
        modifier = Modifier.testTag("confirm_break_glass_btn"),
      ) {
        Text("Invoke Audited Break-Glass")
      }
    },
    dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Cancel") } },
  )
}

@Composable
fun SensitiveConfirmationDialog(
  patient: PatientRecord,
  action: PendingSensitiveAction,
  onConfirm: (String) -> Unit,
  onDismiss: () -> Unit,
) {
  var pin by remember { mutableStateOf("1234") }
  var checkedPatient by remember { mutableStateOf(false) }

  val actionTitle =
    when (action) {
      is PendingSensitiveAction.SignNote -> "Confirm Patient & Sign Clinical Note"
      is PendingSensitiveAction.SubmitSimulatedOrder -> "Confirm Patient & Submit Simulated Order"
      is PendingSensitiveAction.SendReferral -> "Confirm Patient & Prepare Referral"
    }

  val actionSummary =
    when (action) {
      is PendingSensitiveAction.SignNote ->
        "Signing ${action.note.templateType.label} will lock the record version and require an addendum for any future changes."
      is PendingSensitiveAction.SubmitSimulatedOrder ->
        "Simulated Order: ${action.drugName} ${action.strength} ${action.dose} ${action.route} ${action.frequency} (Prototype simulation only — not sent to NHS ePMA)."
      is PendingSensitiveAction.SendReferral -> "Referral draft: ${action.summary}"
    }

  AlertDialog(
    onDismissRequest = onDismiss,
    icon = { Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = NhsBlue) },
    title = { Text(actionTitle) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Surface(
          color = NhsPaleBlue,
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(patient.fullName, style = MaterialTheme.typography.titleMedium, color = NhsDarkBlue)
            Text("DOB: ${patient.dateOfBirth} • NHS: ${patient.nhsNumber}", style = MaterialTheme.typography.labelSmall)
            Text("Location: ${patient.location}", style = MaterialTheme.typography.bodySmall)
          }
        }
        Text(actionSummary, style = MaterialTheme.typography.bodyMedium)
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Checkbox(
            checked = checkedPatient,
            onCheckedChange = { checkedPatient = it },
            modifier = Modifier.testTag("confirm_patient_checkbox"),
          )
          Spacer(Modifier.width(6.dp))
          Text(
            "I confirm this action applies to ${patient.fullName} (${patient.nhsNumber}).",
            style = MaterialTheme.typography.bodyMedium,
          )
        }
        OutlinedTextField(
          value = pin,
          onValueChange = { pin = it },
          label = { Text("Clinician Reauthentication PIN (Demo: 1234)") },
          visualTransformation = PasswordVisualTransformation(),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("reauth_pin_input"),
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { onConfirm(pin) },
        enabled = checkedPatient && pin.isNotBlank(),
        modifier = Modifier.testTag("execute_confirmed_action_btn"),
      ) {
        Text("Confirm & Execute")
      }
    },
    dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Cancel") } },
  )
}

@Composable
fun SessionLockOverlay(
  clinician: ClinicianAccount,
  error: String?,
  onUnlock: (String) -> Unit,
  onSignOut: () -> Unit,
) {
  var pin by remember { mutableStateOf("") }
  Box(
    modifier = Modifier.fillMaxSize().background(Color(0xE60E1620)),
    contentAlignment = Alignment.Center,
  ) {
    Card(
      modifier = Modifier.widthIn(max = 440.dp).padding(24.dp),
      shape = RoundedCornerShape(20.dp),
    ) {
      Column(
        modifier = Modifier.padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        Icon(Icons.Filled.Lock, contentDescription = null, tint = NhsBlue, modifier = Modifier.size(40.dp))
        Text("Clinical Session Locked", style = MaterialTheme.typography.headlineMedium)
        Text(
          "Patient records are concealed during lock. Reauthenticate as ${clinician.displayName} (${clinician.role}).",
          style = MaterialTheme.typography.bodyMedium,
          color = ClinicalSecondaryInk,
        )
        OutlinedTextField(
          value = pin,
          onValueChange = { pin = it },
          label = { Text("Enter Demo PIN (1234)") },
          visualTransformation = PasswordVisualTransformation(),
          singleLine = true,
          isError = error != null,
          supportingText = { if (error != null) Text(error) },
          modifier = Modifier.fillMaxWidth().testTag("unlock_pin_input"),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
          OutlinedButton(onClick = onSignOut, modifier = Modifier.weight(1f)) { Text("Sign Out") }
          Button(
            onClick = { onUnlock(pin) },
            modifier = Modifier.weight(1f).testTag("unlock_session_btn"),
          ) {
            Text("Unlock")
          }
        }
      }
    }
  }
}
