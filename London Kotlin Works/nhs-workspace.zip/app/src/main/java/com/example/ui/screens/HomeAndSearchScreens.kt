package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.adapter.AccessCheckResult
import com.example.data.model.*
import com.example.ui.components.StatusPill
import com.example.ui.theme.*
import com.example.ui.viewmodel.HomeFilterState

@Composable
fun HomeWorklistsScreen(
  session: ClinicianSession,
  patients: List<PatientRecord>,
  appointments: List<AppointmentSummary>,
  tasks: List<ClinicalTask>,
  labResults: List<LabResult>,
  notes: List<ClinicalNote>,
  handovers: List<HandoverSbar>,
  messages: List<TeamMessage>,
  syncQueue: List<SyncQueueItem>,
  filters: HomeFilterState,
  isOnline: Boolean,
  concealNotifications: Boolean,
  evaluateAccess: (PatientRecord) -> AccessCheckResult,
  onUpdateFilters: ((HomeFilterState) -> HomeFilterState) -> Unit,
  onOpenPatient: (PatientRecord, WorkspaceModule) -> Unit,
) {
  val authorisedPatients =
    remember(patients, session, filters) {
      patients.filter { p ->
        val accessOk = evaluateAccess(p) !is AccessCheckResult.DeniedCareContext
        val serviceOk = filters.serviceFilter == "All" || p.service == filters.serviceFilter
        val wardOk = filters.wardFilter == "All" || p.ward == filters.wardFilter
        val clinicOk = filters.clinicFilter == "All" || p.clinic == filters.clinicFilter
        val clinOk =
          filters.clinicianFilter == "All" || p.assignedClinicianId == filters.clinicianFilter
        accessOk && serviceOk && wardOk && clinicOk && clinOk
      }
    }
  val authorisedIds = remember(authorisedPatients) { authorisedPatients.map { it.id }.toSet() }

  val visibleAppointments =
    remember(appointments, authorisedIds) {
      appointments.filter { it.patientId in authorisedIds }
    }
  val visibleTasks =
    remember(tasks, authorisedIds, filters.taskStatusFilter) {
      tasks.filter { t ->
        t.patientId in authorisedIds &&
          when (filters.taskStatusFilter) {
            "Outstanding" -> t.status != TaskStatus.COMPLETED
            "Completed" -> t.status == TaskStatus.COMPLETED
            else -> true
          }
      }
    }
  val awaitingResults =
    remember(labResults, authorisedIds) {
      labResults.filter {
        it.patientId in authorisedIds && it.reviewState != ResultReviewState.ACTION_COMPLETED
      }
    }
  val draftNotes =
    remember(notes, authorisedIds) {
      notes.filter { it.patientId in authorisedIds && it.status == NoteStatus.DRAFT }
    }
  val visibleHandovers =
    remember(handovers, authorisedIds) { handovers.filter { it.patientId in authorisedIds } }
  val actionMessages =
    remember(messages, authorisedIds) {
      messages.filter {
        it.patientId in authorisedIds && it.deliveryState != MessageDeliveryState.READ
      }
    }

  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    item {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = "Clinical Shift Overview — ${session.clinician.displayName}",
          style = MaterialTheme.typography.headlineLarge,
          color = ClinicalInk,
          modifier = Modifier.semantics { heading() },
        )
        Text(
          text =
            "${session.clinician.role} • Authorised Scope: ${session.clinician.authorisedServices.joinToString()}",
          style = MaterialTheme.typography.bodyMedium,
          color = ClinicalSecondaryInk,
        )

        // Worklist Filter Bar
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          FilterDropdownChip(
            label = "Service: ${filters.serviceFilter}",
            options = listOf("All", "Acute Medicine", "Diabetes & Endocrinology"),
            onSelect = { sel -> onUpdateFilters { it.copy(serviceFilter = sel) } },
          )
          FilterDropdownChip(
            label = "Ward: ${filters.wardFilter}",
            options = listOf("All", "Ward 4B", "Emergency Assessment Unit"),
            onSelect = { sel -> onUpdateFilters { it.copy(wardFilter = sel) } },
          )
          FilterDropdownChip(
            label = "Clinic: ${filters.clinicFilter}",
            options = listOf("All", "Acute Medicine Clinic Room 3", "Diabetes & Endocrine Clinic"),
            onSelect = { sel -> onUpdateFilters { it.copy(clinicFilter = sel) } },
          )
          FilterDropdownChip(
            label = "Clinician: ${if (filters.clinicianFilter == "All") "All" else filters.clinicianFilter}",
            options = listOf("All", "doc_vance", "doc_mahmood", "np_bennett"),
            onSelect = { sel -> onUpdateFilters { it.copy(clinicianFilter = sel) } },
          )
          FilterDropdownChip(
            label = "Tasks: ${filters.taskStatusFilter}",
            options = listOf("Outstanding", "All", "Completed"),
            onSelect = { sel -> onUpdateFilters { it.copy(taskStatusFilter = sel) } },
          )
        }
      }
    }

    // Top KPI Summary Cards
    item {
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        WorklistCountCard(
          title = "Today's Clinic",
          count = visibleAppointments.size,
          subtitle = "Appointments",
          icon = Icons.Filled.CalendarToday,
          accent = NhsBlue,
          modifier = Modifier.weight(1f),
        )
        WorklistCountCard(
          title = "Results to Review",
          count = awaitingResults.size,
          subtitle = "Unviewed / Action open",
          icon = Icons.Filled.Science,
          accent = NhsAmber,
          modifier = Modifier.weight(1f),
        )
        WorklistCountCard(
          title = "Draft Notes",
          count = draftNotes.size,
          subtitle = "Unsigned drafts",
          icon = Icons.Filled.EditNote,
          accent = NhsBrightBlue,
          modifier = Modifier.weight(1f),
        )
        WorklistCountCard(
          title = "Tasks & Sync",
          count = visibleTasks.size,
          subtitle = if (isOnline) "${syncQueue.size} queued" else "Offline cache active",
          icon = Icons.Filled.AssignmentTurnedIn,
          accent = NhsGreen,
          modifier = Modifier.weight(1f),
        )
      }
    }

    // Today's Appointments
    item {
      WorklistSectionCard(
        title = "Today's Clinic & Appointments",
        icon = Icons.Filled.EventAvailable,
        emptyText = "No appointments match the current authorised filters.",
        isEmpty = visibleAppointments.isEmpty(),
      ) {
        visibleAppointments.forEach { appt ->
          val pat = patients.firstOrNull { it.id == appt.patientId }
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = NhsIceSurface,
            border = BorderStroke(1.dp, ClinicalBorder),
            modifier =
              Modifier.fillMaxWidth()
                .minimumInteractiveComponentSize()
                .clickable(enabled = pat != null) {
                  pat?.let { onOpenPatient(it, WorkspaceModule.OVERVIEW) }
                }
                .testTag("appointment_item_${appt.patientId}"),
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                  Text(appt.timeSlot, style = MaterialTheme.typography.labelLarge, color = NhsBlue)
                  Text(appt.patientName, style = MaterialTheme.typography.titleMedium, color = ClinicalInk)
                  StatusPill(
                    text = appt.status,
                    icon = Icons.Outlined.Schedule,
                    containerColor = NhsPaleBlue,
                    contentColor = NhsDarkBlue,
                  )
                }
                Text(
                  text = "${appt.clinicName} • ${appt.reason}",
                  style = MaterialTheme.typography.bodySmall,
                  color = ClinicalSecondaryInk,
                )
              }
              Icon(Icons.Filled.ChevronRight, contentDescription = "Open patient record", tint = NhsBlue)
            }
          }
        }
      }
    }

    // Assigned Patients & Ward List
    item {
      WorklistSectionCard(
        title = "Assigned Patients & Authorised Ward / Clinic Lists",
        icon = Icons.Filled.People,
        emptyText = "No authorised patients match your filters.",
        isEmpty = authorisedPatients.isEmpty(),
      ) {
        authorisedPatients.forEach { patient ->
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = ClinicalWhite,
            border = BorderStroke(1.dp, ClinicalBorder),
            modifier =
              Modifier.fillMaxWidth()
                .minimumInteractiveComponentSize()
                .clickable { onOpenPatient(patient, WorkspaceModule.OVERVIEW) }
                .testTag("home_patient_${patient.id}"),
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                  Text(patient.fullName, style = MaterialTheme.typography.titleMedium, color = ClinicalInk)
                  Text("NHS ${patient.nhsNumber}", style = MaterialTheme.typography.labelSmall, color = NhsDarkBlue)
                }
                Text("${patient.location} • ${patient.presentingProblem}", style = MaterialTheme.typography.bodySmall, color = ClinicalSecondaryInk)
              }
              StatusPill(
                text = patient.allergyStatus.label,
                icon = Icons.Outlined.MedicalInformation,
                containerColor =
                  if (patient.allergyStatus == AllergyAssessmentState.ASSESSED_WITH_REACTIONS) NhsRedTint
                  else NhsPaleBlue,
                contentColor =
                  if (patient.allergyStatus == AllergyAssessmentState.ASSESSED_WITH_REACTIONS) NhsRed
                  else NhsDarkBlue,
              )
            }
          }
        }
      }
    }

    // Results Awaiting Review & Draft Notes side-by-side
    item {
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.weight(1f)) {
          WorklistSectionCard(
            title = "Results Awaiting Review",
            icon = Icons.Filled.Biotech,
            emptyText = "All results reviewed & actioned.",
            isEmpty = awaitingResults.isEmpty(),
          ) {
            awaitingResults.forEach { res ->
              val pat = patients.firstOrNull { it.id == res.patientId }
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (res.reportStatus == LabReportStatus.CORRECTED) NhsAmberTint else NhsIceSurface,
                modifier =
                  Modifier.fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .clickable(enabled = pat != null) {
                      pat?.let { onOpenPatient(it, WorkspaceModule.RESULTS) }
                    },
              ) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                  Text(
                    "${pat?.fullName ?: res.patientId}: ${res.testName} ${res.value} ${res.unit}",
                    style = MaterialTheme.typography.labelLarge,
                    color = ClinicalInk,
                  )
                  Text(
                    "${res.reportStatus.label} • ${res.reviewState.label} • Owner: ${res.followUpOwner}",
                    style = MaterialTheme.typography.bodySmall,
                    color = ClinicalSecondaryInk,
                  )
                }
              }
            }
          }
        }
        Box(Modifier.weight(1f)) {
          WorklistSectionCard(
            title = "Draft Notes & Handover Items",
            icon = Icons.Filled.EditNote,
            emptyText = "No pending draft notes or SBAR handovers.",
            isEmpty = draftNotes.isEmpty() && visibleHandovers.isEmpty(),
          ) {
            draftNotes.forEach { note ->
              val pat = patients.firstOrNull { it.id == note.patientId }
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = NhsIceSurface,
                modifier =
                  Modifier.fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .clickable(enabled = pat != null) {
                      pat?.let { onOpenPatient(it, WorkspaceModule.NOTES) }
                    },
              ) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                  Text(
                    "${pat?.fullName ?: note.patientId} — ${note.templateType.label}",
                    style = MaterialTheme.typography.labelLarge,
                  )
                  Text(
                    if (note.hasConflict) "CONFLICT DETECTED • Resolve before signing"
                    else if (note.isLocalOfflineDraft) "Local Offline Draft • Pending sync"
                    else "Updated ${note.updatedAt}",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (note.hasConflict) NhsRed else ClinicalSecondaryInk,
                  )
                }
              }
            }
            visibleHandovers.forEach { sbar ->
              val pat = patients.firstOrNull { it.id == sbar.patientId }
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = NhsPaleBlue,
                modifier =
                  Modifier.fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .clickable(enabled = pat != null) {
                      pat?.let { onOpenPatient(it, WorkspaceModule.TASKS_HANDOVER) }
                    },
              ) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                  Text("SBAR Handover: ${pat?.fullName ?: sbar.patientId}", style = MaterialTheme.typography.labelLarge)
                  Text(sbar.recommendation, style = MaterialTheme.typography.bodySmall, color = NhsDarkBlue)
                }
              }
            }
          }
        }
      }
    }

    // Outstanding Tasks & Messages Requiring Action
    item {
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.weight(1f)) {
          WorklistSectionCard(
            title = "Outstanding Clinical Tasks",
            icon = Icons.Filled.Checklist,
            emptyText = "No tasks matching filter.",
            isEmpty = visibleTasks.isEmpty(),
          ) {
            visibleTasks.forEach { task ->
              val pat = patients.firstOrNull { it.id == task.patientId }
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = NhsIceSurface,
                modifier =
                  Modifier.fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .clickable(enabled = pat != null) {
                      pat?.let { onOpenPatient(it, WorkspaceModule.TASKS_HANDOVER) }
                    },
              ) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                  Text(task.title, style = MaterialTheme.typography.labelLarge)
                  Text(
                    "${pat?.fullName ?: task.patientId} • Due ${task.dueTime} • Owner: ${task.ownerName}",
                    style = MaterialTheme.typography.bodySmall,
                    color = ClinicalSecondaryInk,
                  )
                }
              }
            }
          }
        }
        Box(Modifier.weight(1f)) {
          WorklistSectionCard(
            title = "Messages Requiring Action",
            icon = Icons.Filled.MarkUnreadChatAlt,
            emptyText = "No unread team messages.",
            isEmpty = actionMessages.isEmpty(),
          ) {
            actionMessages.forEach { msg ->
              val pat = patients.firstOrNull { it.id == msg.patientId }
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = NhsIceSurface,
                modifier =
                  Modifier.fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .clickable(enabled = pat != null) {
                      pat?.let { onOpenPatient(it, WorkspaceModule.TASKS_HANDOVER) }
                    },
              ) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                  Text(
                    if (concealNotifications) "Secure Team Message (${msg.recipientTeam}) — Tap inside chart"
                    else "${msg.senderName}: ${msg.body}",
                    style = MaterialTheme.typography.labelLarge,
                  )
                  Text(
                    "${msg.timestamp} • ${msg.deliveryState.label}",
                    style = MaterialTheme.typography.bodySmall,
                    color = ClinicalSecondaryInk,
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun PatientSearchScreen(
  patients: List<PatientRecord>,
  searchQuery: String,
  evaluateAccess: (PatientRecord) -> AccessCheckResult,
  onQueryChange: (String) -> Unit,
  onOpenPatient: (PatientRecord) -> Unit,
  onResolveIdentity: (PatientRecord) -> Unit,
) {
  val filtered =
    remember(patients, searchQuery) {
      val q = searchQuery.trim()
      if (q.isEmpty()) patients
      else {
        patients.filter {
          it.fullName.contains(q, ignoreCase = true) ||
            it.nhsNumber.contains(q, ignoreCase = true) ||
            it.mrn.contains(q, ignoreCase = true) ||
            it.location.contains(q, ignoreCase = true)
        }
      }
    }

  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
          "Patient Search, Duplicate Alerts & Identity Resolution",
          style = MaterialTheme.typography.headlineMedium,
          modifier = Modifier.semantics { heading() },
        )
        OutlinedTextField(
          value = searchQuery,
          onValueChange = onQueryChange,
          label = { Text("Search synthetic patients by name, NHS number, MRN, or ward") },
          leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("patient_search_input"),
        )
      }
    }

    items(filtered, key = { it.id }) { patient ->
      val access = evaluateAccess(patient)
      val isRestricted = access is AccessCheckResult.DeniedCareContext
      val hasIdentityIssue =
        patient.identityStatus != IdentityVerificationStatus.VERIFIED ||
          patient.duplicateCandidateIds.isNotEmpty()

      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = ClinicalWhite),
        border = BorderStroke(1.dp, if (hasIdentityIssue) NhsAmber else ClinicalBorder),
        modifier = Modifier.fillMaxWidth().testTag("search_patient_card_${patient.id}"),
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(Modifier.weight(1f)) {
              Text(patient.fullName, style = MaterialTheme.typography.titleLarge)
              Text(
                "DOB: ${patient.dateOfBirth} • NHS: ${patient.nhsNumber} • MRN: ${patient.mrn}",
                style = MaterialTheme.typography.labelSmall,
                color = NhsDarkBlue,
              )
              Text("${patient.service} • ${patient.location}", style = MaterialTheme.typography.bodySmall, color = ClinicalSecondaryInk)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              if (hasIdentityIssue && !isRestricted) {
                OutlinedButton(
                  onClick = { onResolveIdentity(patient) },
                  modifier = Modifier.minimumInteractiveComponentSize().testTag("resolve_identity_${patient.id}"),
                ) {
                  Text("Verify & Reconcile")
                }
              }
              Button(
                onClick = { onOpenPatient(patient) },
                colors =
                  ButtonDefaults.buttonColors(
                    containerColor = if (isRestricted) NhsAmber else NhsBlue
                  ),
                modifier = Modifier.minimumInteractiveComponentSize().testTag("open_patient_${patient.id}"),
              ) {
                Icon(
                  if (isRestricted) Icons.Filled.LockOpen else Icons.Filled.FolderOpen,
                  contentDescription = null,
                  modifier = Modifier.size(16.dp),
                )
                Spacer(Modifier.width(6.dp))
                Text(if (isRestricted) "Request Access" else "Open Record")
              }
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            StatusPill(
              text = patient.identityStatus.label,
              icon = if (patient.identityStatus == IdentityVerificationStatus.VERIFIED) Icons.Filled.Verified else Icons.Filled.Warning,
              containerColor = if (patient.identityStatus == IdentityVerificationStatus.VERIFIED) NhsGreenTint else NhsAmberTint,
              contentColor = if (patient.identityStatus == IdentityVerificationStatus.VERIFIED) NhsGreen else NhsAmber,
            )
            if (patient.duplicateCandidateIds.isNotEmpty()) {
              StatusPill(
                text = "Suspected Duplicate Candidate (${patient.duplicateCandidateIds.joinToString()})",
                icon = Icons.Filled.ContentCopy,
                containerColor = NhsAmberTint,
                contentColor = NhsAmber,
              )
            }
            if (isRestricted) {
              StatusPill(
                text = "Restricted Scope — Break-Glass Required",
                icon = Icons.Filled.Shield,
                containerColor = NhsRedTint,
                contentColor = NhsRed,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun FilterDropdownChip(
  label: String,
  options: List<String>,
  onSelect: (String) -> Unit,
) {
  var expanded by remember { mutableStateOf(false) }
  Box {
    FilterChip(
      selected = !label.endsWith("All"),
      onClick = { expanded = true },
      label = { Text(label) },
      trailingIcon = { Icon(Icons.Filled.ArrowDropDown, contentDescription = null) },
      modifier = Modifier.minimumInteractiveComponentSize(),
    )
    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
      options.forEach { opt ->
        DropdownMenuItem(
          text = { Text(opt) },
          onClick = {
            expanded = false
            onSelect(opt)
          },
        )
      }
    }
  }
}

@Composable
private fun WorklistCountCard(
  title: String,
  count: Int,
  subtitle: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  accent: androidx.compose.ui.graphics.Color,
  modifier: Modifier = Modifier,
) {
  Card(
    modifier = modifier,
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = ClinicalWhite),
    border = BorderStroke(1.dp, ClinicalBorder),
  ) {
    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(title, style = MaterialTheme.typography.labelLarge, color = ClinicalSecondaryInk)
        Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(18.dp))
      }
      Text(count.toString(), style = MaterialTheme.typography.headlineLarge, color = accent)
      Text(subtitle, style = MaterialTheme.typography.bodySmall, color = ClinicalSecondaryInk)
    }
  }
}

@Composable
private fun WorklistSectionCard(
  title: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  emptyText: String,
  isEmpty: Boolean,
  content: @Composable ColumnScope.() -> Unit,
) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = ClinicalWhite),
    border = BorderStroke(1.dp, ClinicalBorder),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(icon, contentDescription = null, tint = NhsBlue)
        Text(title, style = MaterialTheme.typography.titleLarge, color = ClinicalInk)
      }
      if (isEmpty) {
        Text(emptyText, style = MaterialTheme.typography.bodyMedium, color = ClinicalSecondaryInk)
      } else {
        content()
      }
    }
  }
}
