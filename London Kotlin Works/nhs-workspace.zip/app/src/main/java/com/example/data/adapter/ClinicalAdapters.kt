package com.example.data.adapter

import com.example.data.model.AppointmentSummary
import com.example.data.model.ClinicalNote
import com.example.data.model.ClinicianAccount
import com.example.data.model.ClinicianSession
import com.example.data.model.LabResult
import com.example.data.model.PatientRecord

sealed interface AccessCheckResult {
  data object Granted : AccessCheckResult

  data class GrantedViaBreakGlass(val reason: String) : AccessCheckResult

  data class DeniedCareContext(val requiredScope: String) : AccessCheckResult
}

sealed interface ServerSignResult {
  data class Accepted(val updatedNote: ClinicalNote) : ServerSignResult

  data class ConflictDetected(val remoteEditor: String, val remoteSummary: String) : ServerSignResult

  data class RejectedOffline(val message: String) : ServerSignResult
}

interface IdentityProviderAdapter {
  fun availableAccounts(): List<ClinicianAccount>

  fun signIn(accountId: String, pin: String): ClinicianSession?

  fun verifyReauthentication(session: ClinicianSession, pin: String): Boolean
}

interface PatientAdministrationAdapter {
  fun evaluateAccess(session: ClinicianSession, patient: PatientRecord): AccessCheckResult

  fun resolveIdentityStatus(patient: PatientRecord, verifiedBy: String): PatientRecord
}

interface ClinicalRecordsAdapter {
  fun validateAndSignNote(
    note: ClinicalNote,
    signerName: String,
    isOnline: Boolean,
    timestamp: String,
  ): ServerSignResult

  fun simulateRemoteEditConflict(note: ClinicalNote, remoteClinician: String): ClinicalNote
}

interface LaboratoryResultsAdapter {
  fun formatProvenanceSummary(result: LabResult): String
}

interface AppointmentsAdapter {
  fun filterAppointments(
    appointments: List<AppointmentSummary>,
    session: ClinicianSession,
    serviceFilter: String?,
    clinicianFilter: String?,
  ): List<AppointmentSummary>
}

class LocalMockIdentityAdapter(
  private val accounts: List<ClinicianAccount>
) : IdentityProviderAdapter {
  override fun availableAccounts(): List<ClinicianAccount> = accounts

  override fun signIn(accountId: String, pin: String): ClinicianSession? {
    val account = accounts.firstOrNull { it.id == accountId } ?: return null
    if (pin != account.demoPin) return null
    return ClinicianSession(
      clinician = account,
      signedInAt = System.currentTimeMillis(),
      isLocked = false,
    )
  }

  override fun verifyReauthentication(session: ClinicianSession, pin: String): Boolean {
    return pin == session.clinician.demoPin
  }
}

class LocalMockPatientAdminAdapter : PatientAdministrationAdapter {
  override fun evaluateAccess(session: ClinicianSession, patient: PatientRecord): AccessCheckResult {
    if (session.breakGlassPatientIds.contains(patient.id)) {
      return AccessCheckResult.GrantedViaBreakGlass(
        session.breakGlassReason ?: "Emergency clinical need"
      )
    }
    val clinician = session.clinician
    val hasService = clinician.authorisedServices.contains(patient.service)
    val hasWardOrClinic =
      (patient.ward.isNotBlank() && clinician.authorisedWards.contains(patient.ward)) ||
        (patient.clinic.isNotBlank() && clinician.authorisedClinics.contains(patient.clinic))
    return if (hasService || hasWardOrClinic) {
      AccessCheckResult.Granted
    } else {
      AccessCheckResult.DeniedCareContext(
        "${patient.service} (${patient.ward.ifBlank { patient.clinic }})"
      )
    }
  }

  override fun resolveIdentityStatus(patient: PatientRecord, verifiedBy: String): PatientRecord {
    return patient.copy(
      nhsNumberVerified = true,
      demographicsVerified = true,
      identityStatus = com.example.data.model.IdentityVerificationStatus.VERIFIED,
      duplicateCandidateIds = emptyList(),
      recordAlerts =
        patient.recordAlerts.filterNot {
          it.contains("Identity", ignoreCase = true) || it.contains("Duplicate", ignoreCase = true)
        } + "Identity confirmed & reconciled by $verifiedBy",
    )
  }
}

class LocalMockClinicalRecordsAdapter : ClinicalRecordsAdapter {
  override fun validateAndSignNote(
    note: ClinicalNote,
    signerName: String,
    isOnline: Boolean,
    timestamp: String,
  ): ServerSignResult {
    if (!isOnline) {
      return ServerSignResult.RejectedOffline(
        "Server validation required before signing. Local draft preserved safely for sync."
      )
    }
    if (note.hasConflict) {
      return ServerSignResult.ConflictDetected(
        remoteEditor = note.remoteConflictEditor ?: "Another clinician",
        remoteSummary =
          note.remoteConflictSummary ?: "Concurrent remote revision detected on server.",
      )
    }
    return ServerSignResult.Accepted(
      note.copy(
        status = com.example.data.model.NoteStatus.SIGNED,
        signedAt = timestamp,
        updatedAt = timestamp,
        serverVersion = note.serverVersion + 1,
        isLocalOfflineDraft = false,
        hasConflict = false,
      )
    )
  }

  override fun simulateRemoteEditConflict(note: ClinicalNote, remoteClinician: String): ClinicalNote {
    return note.copy(
      hasConflict = true,
      remoteConflictEditor = remoteClinician,
      remoteConflictSummary =
        "Remote server version v${note.serverVersion + 1} edited by $remoteClinician: " +
          "\"Patient advised to repeat U&Es in 48 hours; escalated fluid balance review.\"",
    )
  }
}

class LocalMockLabResultsAdapter : LaboratoryResultsAdapter {
  override fun formatProvenanceSummary(result: LabResult): String {
    return "${result.provenance} • Collected ${result.specimenCollectedAt} • Reported ${result.resultTime}"
  }
}

class LocalMockAppointmentsAdapter : AppointmentsAdapter {
  override fun filterAppointments(
    appointments: List<AppointmentSummary>,
    session: ClinicianSession,
    serviceFilter: String?,
    clinicianFilter: String?,
  ): List<AppointmentSummary> {
    return appointments.filter { appt ->
      val roleAuthorised = session.clinician.authorisedServices.contains(appt.service)
      val matchesService = serviceFilter.isNullOrBlank() || appt.service == serviceFilter
      val matchesClinician = clinicianFilter.isNullOrBlank() || appt.clinicianId == clinicianFilter
      roleAuthorised && matchesService && matchesClinician
    }
  }
}
