package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.adapter.AccessCheckResult
import com.example.data.adapter.ServerSignResult
import com.example.data.ai.AiAssistTask
import com.example.data.ai.ClinicalAiAssistant
import com.example.data.local.ClinicalDatabase
import com.example.data.model.*
import com.example.data.repository.ClinicalRepository
import com.example.data.seed.SyntheticClinicalSeed
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed interface AiUiState {
  data object Idle : AiUiState

  data object Loading : AiUiState

  data class Ready(val proposal: AiAssistantProposal) : AiUiState

  data class Error(val message: String) : AiUiState
}

sealed interface PendingSensitiveAction {
  data class SignNote(val note: ClinicalNote) : PendingSensitiveAction

  data class SubmitSimulatedOrder(
    val drugName: String,
    val strength: String,
    val dose: String,
    val route: String,
    val frequency: String,
    val notes: String,
  ) : PendingSensitiveAction

  data class SendReferral(val summary: String) : PendingSensitiveAction
}

data class HomeFilterState(
  val serviceFilter: String = "All",
  val wardFilter: String = "All",
  val clinicFilter: String = "All",
  val clinicianFilter: String = "All",
  val taskStatusFilter: String = "Outstanding",
)

data class WorkspaceUiState(
  val session: ClinicianSession? = null,
  val availableAccounts: List<ClinicianAccount> = SyntheticClinicalSeed.clinicianAccounts,
  val isOnline: Boolean = true,
  val orgAiApprovalEnabled: Boolean = false,
  val reducedMotion: Boolean = false,
  val concealNotifications: Boolean = true,
  val activeModule: WorkspaceModule = WorkspaceModule.HOME,
  val inspectorOpen: Boolean = true,
  val activeInspectorTab: InspectorTab = InspectorTab.DEMO_GUIDE,
  val selectedPatientId: String? = null,
  val confirmedPatientIds: Set<String> = emptySet(),
  val pendingPatientSwitch: PatientRecord? = null,
  val restrictedAccessPrompt: Pair<PatientRecord, String>? = null,
  val activeDraftNote: ClinicalNote? = null,
  val hasUnsavedDraftChanges: Boolean = false,
  val autosaveStatusLabel: String = "Ready",
  val pendingSensitiveAction: PendingSensitiveAction? = null,
  val searchQuery: String = "",
  val homeFilters: HomeFilterState = HomeFilterState(),
  val demoStepsCompleted: Set<Int> = emptySet(),
  val aiUiState: AiUiState = AiUiState.Idle,
  val statusMessage: String? = null,
  val signInError: String? = null,
  val lockError: String? = null,
  val lastWorkspaceSyncLabel: String = "Just now",
)

class ClinicalWorkspaceViewModel(application: Application) : AndroidViewModel(application) {
  private val repository =
    ClinicalRepository(ClinicalDatabase.getInstance(application).clinicalDao())
  private val aiAssistant = ClinicalAiAssistant()

  private val _uiState = MutableStateFlow(WorkspaceUiState())
  val uiState: StateFlow<WorkspaceUiState> = _uiState.asStateFlow()

  val patients: StateFlow<List<PatientRecord>> =
    repository.patients.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val appointments: StateFlow<List<AppointmentSummary>> =
    repository.appointments.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val allergies: StateFlow<List<AllergyEntry>> =
    repository.allergies.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val problems: StateFlow<List<ProblemEntry>> =
    repository.problems.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val encounters: StateFlow<List<EncounterSummary>> =
    repository.encounters.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val medications: StateFlow<List<MedicationEntry>> =
    repository.medications.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val observations: StateFlow<List<ObservationPoint>> =
    repository.observations.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val labResults: StateFlow<List<LabResult>> =
    repository.labResults.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val clinicalNotes: StateFlow<List<ClinicalNote>> =
    repository.clinicalNotes.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val noteVersions: StateFlow<List<NoteVersion>> =
    repository.noteVersions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val noteAddenda: StateFlow<List<NoteAddendum>> =
    repository.noteAddenda.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val carePlans: StateFlow<List<CarePlanItem>> =
    repository.carePlans.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val tasks: StateFlow<List<ClinicalTask>> =
    repository.tasks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val handovers: StateFlow<List<HandoverSbar>> =
    repository.handovers.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val messages: StateFlow<List<TeamMessage>> =
    repository.messages.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val bodyStrokes: StateFlow<List<BodyAnnotationStroke>> =
    repository.bodyStrokes.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val consultationTools: StateFlow<List<ConsultationToolState>> =
    repository.consultationTools.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val auditEvents: StateFlow<List<AuditEvent>> =
    repository.auditEvents.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val syncQueue: StateFlow<List<SyncQueueItem>> =
    repository.syncQueue.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private var autosaveJob: Job? = null

  init {
    viewModelScope.launch { repository.ensureSeeded() }
  }

  fun signIn(accountId: String, pin: String) {
    val session = repository.identityAdapter.signIn(accountId, pin)
    if (session == null) {
      _uiState.update { it.copy(signInError = "Invalid PIN for mock CIS2 adapter (demo PIN: 1234).") }
      return
    }
    _uiState.update {
      it.copy(
        session = session,
        signInError = null,
        activeModule = WorkspaceModule.HOME,
        selectedPatientId = null,
        activeDraftNote = null,
        hasUnsavedDraftChanges = false,
        demoStepsCompleted = it.demoStepsCompleted + 1,
        statusMessage = "Signed in as ${session.clinician.displayName} (${session.clinician.role})",
      )
    }
    viewModelScope.launch {
      repository.recordAudit(
        clinician = session.clinician,
        actionType = "SESSION_SIGN_IN",
        patientId = "SYSTEM",
        patientName = "Workspace",
        resourceSummary = session.clinician.identityAdapterLabel,
        outcome = "Authenticated",
        detail = "Authorised services: ${session.clinician.authorisedServices.joinToString()}",
      )
    }
  }

  fun signOut() {
    val clinician = _uiState.value.session?.clinician
    if (clinician != null) {
      viewModelScope.launch {
        repository.recordAudit(
          clinician = clinician,
          actionType = "SESSION_SIGN_OUT",
          patientId = "SYSTEM",
          patientName = "Workspace",
          resourceSummary = "CIS2 Session",
          outcome = "Signed Out",
          detail = "Clinician ended active session",
        )
      }
    }
    _uiState.value = WorkspaceUiState()
  }

  fun lockSession() {
    _uiState.update { state ->
      val current = state.session ?: return@update state
      state.copy(session = current.copy(isLocked = true), lockError = null)
    }
  }

  fun unlockSession(pin: String) {
    val current = _uiState.value.session ?: return
    if (repository.identityAdapter.verifyReauthentication(current, pin)) {
      _uiState.update {
        it.copy(session = current.copy(isLocked = false), lockError = null)
      }
    } else {
      _uiState.update { it.copy(lockError = "Incorrect PIN (demo PIN: 1234).") }
    }
  }

  fun toggleOnlineMode() {
    val nextOnline = !_uiState.value.isOnline
    _uiState.update {
      it.copy(
        isOnline = nextOnline,
        statusMessage =
          if (nextOnline) {
            "Connectivity restored — ready to validate and sync local drafts."
          } else {
            "Offline mode active — showing cached records; local drafts queued for server validation."
          },
      )
    }
    if (nextOnline) {
      syncNow()
    }
  }

  fun syncNow() {
    val clinician = _uiState.value.session?.clinician ?: return
    if (!_uiState.value.isOnline) {
      _uiState.update { it.copy(statusMessage = "Cannot sync while offline. Cached view remains active.") }
      return
    }
    viewModelScope.launch {
      repository.flushSyncQueue(patients.value, clinicalNotes.value, clinician)
      val ts = SimpleDateFormat("HH:mm", Locale.UK).format(Date())
      _uiState.update {
        it.copy(
          lastWorkspaceSyncLabel = "Synced $ts",
          statusMessage = "Synchronisation completed with local mock backend.",
        )
      }
    }
  }

  fun toggleOrgAiApproval(enabled: Boolean) {
    _uiState.update {
      it.copy(
        orgAiApprovalEnabled = enabled,
        statusMessage =
          if (enabled) {
            "Organisational AI Data Arrangement enabled (prototype synthetic records only)."
          } else {
            "External AI disabled — assistant uses local record-grounded templates only."
          },
      )
    }
  }

  fun toggleReducedMotion() {
    _uiState.update { it.copy(reducedMotion = !it.reducedMotion) }
  }

  fun toggleNotificationPrivacy() {
    _uiState.update { it.copy(concealNotifications = !it.concealNotifications) }
  }

  fun toggleInspector() {
    _uiState.update { it.copy(inspectorOpen = !it.inspectorOpen) }
  }

  fun selectInspectorTab(tab: InspectorTab) {
    _uiState.update { it.copy(inspectorOpen = true, activeInspectorTab = tab) }
  }

  fun setModule(module: WorkspaceModule) {
    val state = _uiState.value
    if (module == WorkspaceModule.HOME) {
      _uiState.update {
        it.copy(activeModule = module, demoStepsCompleted = it.demoStepsCompleted + 2)
      }
      return
    }
    if (module == WorkspaceModule.AUDIT_LOG) {
      _uiState.update {
        it.copy(activeModule = module, demoStepsCompleted = it.demoStepsCompleted + 10)
      }
      return
    }
    _uiState.update { it.copy(activeModule = module) }
    if (module == WorkspaceModule.MEDICATIONS || module == WorkspaceModule.RESULTS) {
      if (state.selectedPatientId != null) {
        _uiState.update { it.copy(demoStepsCompleted = it.demoStepsCompleted + 4) }
      }
    }
  }

  fun updateSearchQuery(q: String) {
    _uiState.update { it.copy(searchQuery = q) }
  }

  fun updateHomeFilters(transform: (HomeFilterState) -> HomeFilterState) {
    _uiState.update { it.copy(homeFilters = transform(it.homeFilters)) }
  }

  fun requestOpenPatient(
    patient: PatientRecord,
    targetModule: WorkspaceModule = WorkspaceModule.OVERVIEW,
  ) {
    val state = _uiState.value
    val session = state.session ?: return

    // 1. Draft isolation guard when switching records
    if (state.selectedPatientId != null &&
      state.selectedPatientId != patient.id &&
      state.hasUnsavedDraftChanges
    ) {
      _uiState.update { it.copy(pendingPatientSwitch = patient) }
      return
    }

    // 2. RBAC & Care-Context Check
    when (val access = repository.evaluatePatientAccess(session, patient)) {
      is AccessCheckResult.DeniedCareContext -> {
        _uiState.update { it.copy(restrictedAccessPrompt = patient to access.requiredScope) }
        viewModelScope.launch {
          repository.recordAudit(
            clinician = session.clinician,
            actionType = "ACCESS_DENIED_CARE_CONTEXT",
            patientId = patient.id,
            patientName = patient.fullName,
            resourceSummary = access.requiredScope,
            outcome = "Denied",
            detail = "Clinician scope lacks ${access.requiredScope}",
          )
        }
        return
      }
      is AccessCheckResult.GrantedViaBreakGlass,
      AccessCheckResult.Granted -> Unit
    }

    val patientDraft =
      clinicalNotes.value.firstOrNull {
        it.patientId == patient.id && it.status == NoteStatus.DRAFT
      }
    _uiState.update {
      it.copy(
        selectedPatientId = patient.id,
        activeModule = targetModule,
        activeDraftNote = patientDraft,
        hasUnsavedDraftChanges = false,
        aiUiState = AiUiState.Idle,
        demoStepsCompleted =
          it.demoStepsCompleted + 2 + if (targetModule == WorkspaceModule.RESULTS) setOf(4) else emptySet(),
      )
    }

    viewModelScope.launch {
      repository.recordAudit(
        clinician = session.clinician,
        actionType = "PATIENT_RECORD_VIEW",
        patientId = patient.id,
        patientName = patient.fullName,
        resourceSummary = "Encounter ${patient.encounterId}",
        outcome = "Granted",
        detail = "Opened ${patient.location}",
      )
    }
  }

  fun confirmPatientSwitchSaveDraft() {
    val pending = _uiState.value.pendingPatientSwitch ?: return
    val draft = _uiState.value.activeDraftNote
    val clinician = _uiState.value.session?.clinician ?: return
    val oldPatientName =
      patients.value.firstOrNull { it.id == _uiState.value.selectedPatientId }?.fullName ?: "Previous patient"
    viewModelScope.launch {
      if (draft != null) {
        repository.saveDraftNote(
          note = draft,
          clinician = clinician,
          patientName = oldPatientName,
          isOnline = _uiState.value.isOnline,
          changeSummary = "Saved to original patient before switching",
        )
      }
      _uiState.update {
        it.copy(pendingPatientSwitch = null, hasUnsavedDraftChanges = false, activeDraftNote = null)
      }
      requestOpenPatient(pending)
    }
  }

  fun confirmPatientSwitchDiscardDraft() {
    val pending = _uiState.value.pendingPatientSwitch ?: return
    _uiState.update {
      it.copy(pendingPatientSwitch = null, hasUnsavedDraftChanges = false, activeDraftNote = null)
    }
    requestOpenPatient(pending)
  }

  fun cancelPatientSwitch() {
    _uiState.update { it.copy(pendingPatientSwitch = null) }
  }

  fun invokeBreakGlassAccess(reason: String) {
    val (patient, scope) = _uiState.value.restrictedAccessPrompt ?: return
    val currentSession = _uiState.value.session ?: return
    if (reason.trim().length < 6) {
      _uiState.update { it.copy(statusMessage = "Please enter a clear clinical reason for Break-Glass access.") }
      return
    }
    val updatedSession =
      currentSession.copy(
        breakGlassPatientIds = currentSession.breakGlassPatientIds + patient.id,
        breakGlassReason = reason.trim(),
      )
    _uiState.update {
      it.copy(
        session = updatedSession,
        restrictedAccessPrompt = null,
        statusMessage = "Emergency Break-Glass access granted & audited for ${patient.fullName}.",
      )
    }
    viewModelScope.launch {
      repository.recordAudit(
        clinician = currentSession.clinician,
        actionType = "EMERGENCY_BREAK_GLASS_ACCESS",
        patientId = patient.id,
        patientName = patient.fullName,
        resourceSummary = scope,
        outcome = "Granted (Audited Override)",
        isBreakGlass = true,
        detail = "Reason: ${reason.trim()}",
      )
    }
    requestOpenPatient(patient)
  }

  fun dismissRestrictedAccessPrompt() {
    _uiState.update { it.copy(restrictedAccessPrompt = null) }
  }

  fun confirmPatientIdentity(patient: PatientRecord) {
    val clinician = _uiState.value.session?.clinician ?: return
    viewModelScope.launch {
      if (patient.identityStatus != IdentityVerificationStatus.VERIFIED) {
        repository.resolveUncertainIdentity(patient, clinician)
      } else {
        repository.recordAudit(
          clinician = clinician,
          actionType = "PATIENT_IDENTITY_CONFIRMED",
          patientId = patient.id,
          patientName = patient.fullName,
          resourceSummary = "NHS ${patient.nhsNumber} • DOB ${patient.dateOfBirth}",
          outcome = "Confirmed",
          detail = "Clinician confirmed active patient identity in banner",
        )
      }
      _uiState.update {
        it.copy(
          confirmedPatientIds = it.confirmedPatientIds + patient.id,
          demoStepsCompleted = it.demoStepsCompleted + 3,
          statusMessage = "Patient identity confirmed: ${patient.fullName} (NHS ${patient.nhsNumber}).",
        )
      }
    }
  }

  fun startOrSelectDraftNote(template: NoteTemplateType) {
    val patient = currentPatient() ?: return
    val clinician = _uiState.value.session?.clinician ?: return
    val existing =
      clinicalNotes.value.firstOrNull {
        it.patientId == patient.id && it.status == NoteStatus.DRAFT && it.templateType == template
      }
    if (existing != null) {
      _uiState.update { it.copy(activeDraftNote = existing, hasUnsavedDraftChanges = false) }
      return
    }
    val now = repository.nowFormatted()
    val newDraft =
      ClinicalNote(
        id = "note_${UUID.randomUUID().toString().take(8)}",
        patientId = patient.id,
        encounterId = patient.encounterId,
        templateType = template,
        status = NoteStatus.DRAFT,
        authorId = clinician.id,
        authorName = clinician.displayName,
        createdAt = now,
        updatedAt = now,
        signedAt = null,
        serverVersion = 1,
        historyText = "",
        examinationText = "",
        assessmentText = "",
        planText = "",
        specialtyExtraText = "",
        freeText = "",
        carriedForwardAttribution = null,
        isLocalOfflineDraft = !_uiState.value.isOnline,
        hasConflict = false,
        remoteConflictEditor = null,
        remoteConflictSummary = null,
        enteredInErrorReason = null,
      )
    _uiState.update {
      it.copy(
        activeDraftNote = newDraft,
        hasUnsavedDraftChanges = true,
        autosaveStatusLabel = "New ${template.label} draft",
      )
    }
  }

  fun selectNoteForEditing(note: ClinicalNote) {
    _uiState.update {
      it.copy(
        activeDraftNote = note,
        hasUnsavedDraftChanges = false,
        autosaveStatusLabel = if (note.status == NoteStatus.DRAFT) "Draft loaded" else note.status.label,
      )
    }
  }

  fun updateDraftField(transform: (ClinicalNote) -> ClinicalNote) {
    val current = _uiState.value.activeDraftNote ?: return
    if (current.status != NoteStatus.DRAFT) return
    val updated = transform(current)
    _uiState.update {
      it.copy(
        activeDraftNote = updated,
        hasUnsavedDraftChanges = true,
        autosaveStatusLabel = "Unsaved edits — autosaving…",
      )
    }
    autosaveJob?.cancel()
    autosaveJob =
      viewModelScope.launch {
        delay(900L)
        saveCurrentDraft(changeSummary = "Autosaved consultation draft")
      }
  }

  fun carryForwardFromSignedNote(sourceNote: ClinicalNote) {
    val current = _uiState.value.activeDraftNote ?: return
    if (current.status != NoteStatus.DRAFT) return
    val attribution =
      "Carried forward from ${sourceNote.templateType.label} by ${sourceNote.authorName} (${sourceNote.signedAt ?: sourceNote.updatedAt})"
    updateDraftField {
      it.copy(
        historyText =
          buildString {
            if (it.historyText.isNotBlank()) appendLine(it.historyText)
            append("[Carried forward ${sourceNote.signedAt ?: sourceNote.updatedAt}]: ${sourceNote.assessmentText}")
          },
        carriedForwardAttribution = attribution,
      )
    }
  }

  fun saveCurrentDraft(changeSummary: String = "Saved draft") {
    val note = _uiState.value.activeDraftNote ?: return
    val clinician = _uiState.value.session?.clinician ?: return
    val patient = currentPatient() ?: return
    viewModelScope.launch {
      val saved =
        repository.saveDraftNote(
          note = note,
          clinician = clinician,
          patientName = patient.fullName,
          isOnline = _uiState.value.isOnline,
          changeSummary = changeSummary,
        )
      _uiState.update {
        it.copy(
          activeDraftNote = saved,
          hasUnsavedDraftChanges = false,
          autosaveStatusLabel =
            if (saved.isLocalOfflineDraft) "Saved locally (Offline queue)" else "Autosaved ${saved.updatedAt}",
          demoStepsCompleted = it.demoStepsCompleted + 5,
        )
      }
    }
  }

  fun requestSensitiveConfirmation(action: PendingSensitiveAction) {
    val patient = currentPatient() ?: return
    if (patient.identityStatus == IdentityVerificationStatus.UNCERTAIN_IDENTITY) {
      _uiState.update {
        it.copy(
          statusMessage = "Blocked: Resolve Uncertain Identity in the patient banner before consequential actions."
        )
      }
      return
    }
    _uiState.update { it.copy(pendingSensitiveAction = action) }
  }

  fun cancelSensitiveConfirmation() {
    _uiState.update { it.copy(pendingSensitiveAction = null) }
  }

  fun executeConfirmedSensitiveAction(pin: String) {
    val action = _uiState.value.pendingSensitiveAction ?: return
    val session = _uiState.value.session ?: return
    val patient = currentPatient() ?: return
    if (!repository.identityAdapter.verifyReauthentication(session, pin)) {
      _uiState.update { it.copy(statusMessage = "Reauthentication PIN incorrect (demo PIN: 1234).") }
      return
    }

    _uiState.update {
      it.copy(
        pendingSensitiveAction = null,
        confirmedPatientIds = it.confirmedPatientIds + patient.id,
      )
    }

    viewModelScope.launch {
      when (action) {
        is PendingSensitiveAction.SignNote -> {
          val savedDraft =
            repository.saveDraftNote(
              note = action.note,
              clinician = session.clinician,
              patientName = patient.fullName,
              isOnline = _uiState.value.isOnline,
              changeSummary = "Pre-signing snapshot",
            )
          when (
            val signRes =
              repository.signNote(
                note = savedDraft,
                clinician = session.clinician,
                patientName = patient.fullName,
                isOnline = _uiState.value.isOnline,
              )
          ) {
            is ServerSignResult.Accepted -> {
              _uiState.update {
                it.copy(
                  activeDraftNote = signRes.updatedNote,
                  hasUnsavedDraftChanges = false,
                  autosaveStatusLabel = "Signed & Locked",
                  demoStepsCompleted = it.demoStepsCompleted + 7,
                  statusMessage = "Note signed and locked in record.",
                )
              }
            }
            is ServerSignResult.ConflictDetected -> {
              _uiState.update {
                it.copy(
                  activeDraftNote =
                    savedDraft.copy(
                      hasConflict = true,
                      remoteConflictEditor = signRes.remoteEditor,
                      remoteConflictSummary = signRes.remoteSummary,
                    ),
                  statusMessage = "Conflict detected with ${signRes.remoteEditor}. Resolve before signing.",
                )
              }
            }
            is ServerSignResult.RejectedOffline -> {
              _uiState.update { it.copy(statusMessage = signRes.message) }
            }
          }
        }
        is PendingSensitiveAction.SubmitSimulatedOrder -> {
          repository.addSimulatedPrescription(
            patientId = patient.id,
            patientName = patient.fullName,
            drugName = action.drugName,
            strength = action.strength,
            dose = action.dose,
            route = action.route,
            frequency = action.frequency,
            notes = action.notes,
            clinician = session.clinician,
          )
          _uiState.update {
            it.copy(statusMessage = "Simulated prescription recorded for ${patient.fullName}.")
          }
        }
        is PendingSensitiveAction.SendReferral -> {
          val existingTool =
            consultationTools.value.firstOrNull { it.patientId == patient.id }
              ?: defaultConsultationTools(patient.id, session.clinician.displayName)
          repository.saveConsultationTools(
            state = existingTool.copy(referralDraftSummary = "Sent (Prototype): ${action.summary}"),
            clinician = session.clinician,
            patientName = patient.fullName,
            actionNote = "Simulated Referral Submitted",
          )
          _uiState.update { it.copy(statusMessage = "Referral prepared and audited for ${patient.fullName}.") }
        }
      }
    }
  }

  fun simulateConflictOnActiveNote() {
    val note = _uiState.value.activeDraftNote ?: return
    val clinician = _uiState.value.session?.clinician ?: return
    val patient = currentPatient() ?: return
    viewModelScope.launch {
      val updated = repository.simulateConflictOnNote(note, clinician, patient.fullName)
      _uiState.update {
        it.copy(
          activeDraftNote = updated,
          statusMessage = "Simultaneous edit conflict triggered — explicit resolution required.",
        )
      }
    }
  }

  fun resolveConflict(note: ClinicalNote, resolution: String) {
    val clinician = _uiState.value.session?.clinician ?: return
    val patient = currentPatient() ?: return
    viewModelScope.launch {
      val resolved = repository.resolveNoteConflict(note, resolution, clinician, patient.fullName)
      _uiState.update {
        it.copy(
          activeDraftNote = resolved,
          hasUnsavedDraftChanges = false,
          statusMessage = "Conflict resolved ($resolution). You may now review and sign.",
        )
      }
    }
  }

  fun addAddendumToNote(note: ClinicalNote, reason: String, text: String) {
    val clinician = _uiState.value.session?.clinician ?: return
    val patient = currentPatient() ?: return
    viewModelScope.launch {
      repository.addAddendum(note, reason, text, clinician, patient.fullName)
      _uiState.update { it.copy(statusMessage = "Addendum appended; original signed note preserved.") }
    }
  }

  fun markEnteredInError(note: ClinicalNote, reason: String) {
    val clinician = _uiState.value.session?.clinician ?: return
    val patient = currentPatient() ?: return
    viewModelScope.launch {
      repository.markNoteEnteredInError(note, reason, clinician, patient.fullName)
      _uiState.update {
        it.copy(
          activeDraftNote = note.copy(status = NoteStatus.ENTERED_IN_ERROR, enteredInErrorReason = reason),
          statusMessage = "Note marked Entered-in-Error while preserving audit history.",
        )
      }
    }
  }

  fun transitionResultState(result: LabResult, targetState: ResultReviewState) {
    val clinician = _uiState.value.session?.clinician ?: return
    val patientName =
      patients.value.firstOrNull { it.id == result.patientId }?.fullName ?: result.patientId
    viewModelScope.launch {
      repository.transitionLabResultState(result, targetState, clinician, patientName)
      _uiState.update { state ->
        state.copy(
          demoStepsCompleted =
            state.demoStepsCompleted +
              4 +
              if (targetState == ResultReviewState.ACKNOWLEDGED) setOf(9) else emptySet(),
          statusMessage = "${result.testName}: ${targetState.label}",
        )
      }
    }
  }

  fun updateMedicationReconciliation(med: MedicationEntry, status: ReconciliationStatus) {
    val clinician = _uiState.value.session?.clinician ?: return
    val patientName = currentPatient()?.fullName ?: med.patientId
    viewModelScope.launch {
      repository.updateMedicationReconciliation(med, status, clinician, patientName)
      _uiState.update {
        it.copy(
          demoStepsCompleted = it.demoStepsCompleted + 4,
          statusMessage = "${med.drugName} marked ${status.label}.",
        )
      }
    }
  }

  fun updateAllergyAssessment(newState: AllergyAssessmentState, newEntry: AllergyEntry? = null) {
    val patient = currentPatient() ?: return
    val clinician = _uiState.value.session?.clinician ?: return
    viewModelScope.launch {
      repository.updateAllergyStatusAndEntry(patient, newState, newEntry, clinician)
      _uiState.update { it.copy(statusMessage = "Allergy status updated: ${newState.label}.") }
    }
  }

  fun saveCarePlan(carePlan: CarePlanItem) {
    val clinician = _uiState.value.session?.clinician ?: return
    val patient = currentPatient() ?: return
    viewModelScope.launch {
      repository.saveCarePlan(carePlan, clinician, patient.fullName)
      _uiState.update {
        it.copy(
          demoStepsCompleted = it.demoStepsCompleted + 6,
          statusMessage =
            if (carePlan.approvedByClinician) "Patient-friendly care plan approved."
            else "Care plan draft saved.",
        )
      }
    }
  }

  fun createOrUpdateTask(
    title: String,
    ownerName: String,
    ownerRole: String,
    priority: TaskPriority,
    dueTime: String,
    supportingContext: String,
    linkedResultId: String? = null,
  ) {
    val patient = currentPatient() ?: return
    val clinician = _uiState.value.session?.clinician ?: return
    val task =
      ClinicalTask(
        id = "task_${UUID.randomUUID().toString().take(8)}",
        patientId = patient.id,
        title = title,
        ownerName = ownerName,
        ownerRole = ownerRole,
        priority = priority,
        dueTime = dueTime,
        status = TaskStatus.OPEN,
        supportingContext = supportingContext,
        completionEvidence = null,
        linkedResultId = linkedResultId,
      )
    viewModelScope.launch {
      repository.upsertTask(task, clinician, patient.fullName, isNew = true)
      _uiState.update {
        it.copy(
          demoStepsCompleted = it.demoStepsCompleted + 8,
          statusMessage = "Follow-up task assigned to $ownerName.",
        )
      }
    }
  }

  fun completeTask(task: ClinicalTask, evidence: String) {
    val clinician = _uiState.value.session?.clinician ?: return
    val patientName = patients.value.firstOrNull { it.id == task.patientId }?.fullName ?: task.patientId
    viewModelScope.launch {
      repository.upsertTask(
        task.copy(status = TaskStatus.COMPLETED, completionEvidence = evidence),
        clinician,
        patientName,
        isNew = false,
      )
      _uiState.update { it.copy(statusMessage = "Task completed with evidence.") }
    }
  }

  fun saveSbarHandover(sbar: HandoverSbar) {
    val clinician = _uiState.value.session?.clinician ?: return
    val patientName = currentPatient()?.fullName ?: sbar.patientId
    viewModelScope.launch {
      repository.saveHandoverSbar(sbar, clinician, patientName)
      _uiState.update { it.copy(statusMessage = "SBAR handover saved.") }
    }
  }

  fun sendTeamMessage(recipientTeam: String, body: String) {
    val patient = currentPatient() ?: return
    val clinician = _uiState.value.session?.clinician ?: return
    viewModelScope.launch {
      repository.sendTeamMessage(patient.id, patient.fullName, recipientTeam, body, clinician)
      _uiState.update {
        it.copy(
          statusMessage =
            "Message delivered to $recipientTeam (note: urgent clinical escalation requires phone/bleep)."
        )
      }
    }
  }

  fun addBodyStroke(regionLabel: String, pointsSerialized: String, colorHex: Long, strokeWidth: Float) {
    val patient = currentPatient() ?: return
    viewModelScope.launch {
      repository.saveBodyStroke(
        BodyAnnotationStroke(
          id = "str_${UUID.randomUUID().toString().take(8)}",
          patientId = patient.id,
          regionLabel = regionLabel,
          pointsSerialized = pointsSerialized,
          colorHex = colorHex,
          strokeWidth = strokeWidth,
        )
      )
    }
  }

  fun clearBodyDiagram() {
    val patient = currentPatient() ?: return
    val clinician = _uiState.value.session?.clinician ?: return
    viewModelScope.launch {
      repository.clearBodyStrokes(patient.id, clinician, patient.fullName)
    }
  }

  fun updateConsultationToolState(actionNote: String, transform: (ConsultationToolState) -> ConsultationToolState) {
    val patient = currentPatient() ?: return
    val clinician = _uiState.value.session?.clinician ?: return
    val current =
      consultationTools.value.firstOrNull { it.patientId == patient.id }
        ?: defaultConsultationTools(patient.id, clinician.displayName)
    val updated = transform(current)
    viewModelScope.launch {
      repository.saveConsultationTools(updated, clinician, patient.fullName, actionNote)
      _uiState.update { it.copy(statusMessage = actionNote) }
    }
  }

  fun runAiAssistant(task: AiAssistTask) {
    val patient = currentPatient() ?: return
    val pAllergies = allergies.value.filter { it.patientId == patient.id }
    val pMeds = medications.value.filter { it.patientId == patient.id }
    val pResults = labResults.value.filter { it.patientId == patient.id }
    val pTasks = tasks.value.filter { it.patientId == patient.id }
    val draft = _uiState.value.activeDraftNote
    _uiState.update { it.copy(aiUiState = AiUiState.Loading) }
    viewModelScope.launch {
      val result =
        aiAssistant.generateProposal(
          task = task,
          patient = patient,
          allergies = pAllergies,
          medications = pMeds,
          results = pResults,
          activeNote = draft,
          tasks = pTasks,
          orgAiApprovalEnabled = _uiState.value.orgAiApprovalEnabled,
          isOnline = _uiState.value.isOnline,
        )
      result.fold(
        onSuccess = { proposal ->
          _uiState.update { it.copy(aiUiState = AiUiState.Ready(proposal)) }
        },
        onFailure = { error ->
          _uiState.update {
            it.copy(aiUiState = AiUiState.Error(error.localizedMessage ?: "AI generation failed."))
          }
        },
      )
    }
  }

  fun insertAiProposalIntoDraft(text: String) {
    val patient = currentPatient() ?: return
    val clinician = _uiState.value.session?.clinician ?: return
    if (_uiState.value.activeDraftNote == null) {
      startOrSelectDraftNote(NoteTemplateType.CONSULTATION)
    }
    updateDraftField {
      it.copy(
        freeText =
          buildString {
            if (it.freeText.isNotBlank()) appendLine(it.freeText)
            append("[Clinician-Reviewed Assistant Draft]:\n$text")
          }
      )
    }
    viewModelScope.launch {
      repository.recordAudit(
        clinician = clinician,
        actionType = "AI_DRAFT_REVIEWED_AND_INSERTED",
        patientId = patient.id,
        patientName = patient.fullName,
        resourceSummary = "Optional Clinical Assistant",
        outcome = "Clinician Reviewed",
        detail = "Inserted assistant draft into active clinical note after explicit review",
      )
    }
    _uiState.update {
      it.copy(
        activeModule = WorkspaceModule.NOTES,
        statusMessage = "Assistant draft inserted into clinical note after clinician review.",
      )
    }
  }

  fun triggerDemoScenario(scenarioId: String) {
    val patList = patients.value
    when (scenarioId) {
      "UNCERTAIN_ALLERGY" -> {
        patList.firstOrNull { it.id == "pat_03" }?.let { requestOpenPatient(it, WorkspaceModule.OVERVIEW) }
      }
      "CORRECTED_RESULT" -> {
        patList.firstOrNull { it.id == "pat_02" }?.let { requestOpenPatient(it, WorkspaceModule.RESULTS) }
      }
      "PATIENT_SWITCH_GUARD" -> {
        val p1 = patList.firstOrNull { it.id == "pat_01" } ?: return
        val p2 = patList.firstOrNull { it.id == "pat_02" } ?: return
        requestOpenPatient(p1, WorkspaceModule.NOTES)
        viewModelScope.launch {
          delay(120L)
          if (_uiState.value.activeDraftNote == null) startOrSelectDraftNote(NoteTemplateType.CONSULTATION)
          updateDraftField { it.copy(freeText = it.freeText + "\n[Unsaved draft edit before switching]") }
          delay(120L)
          requestOpenPatient(p2, WorkspaceModule.OVERVIEW)
        }
      }
      "OFFLINE_MODE" -> {
        if (_uiState.value.isOnline) toggleOnlineMode()
      }
      "CONCURRENT_CONFLICT" -> {
        val p2 = patList.firstOrNull { it.id == "pat_02" } ?: return
        requestOpenPatient(p2, WorkspaceModule.NOTES)
        viewModelScope.launch {
          delay(120L)
          val conflictNote = clinicalNotes.value.firstOrNull { it.patientId == "pat_02" }
          if (conflictNote != null) {
            selectNoteForEditing(conflictNote)
            if (!conflictNote.hasConflict) simulateConflictOnActiveNote()
          }
        }
      }
    }
  }

  fun clearStatusMessage() {
    _uiState.update { it.copy(statusMessage = null) }
  }

  private fun currentPatient(): PatientRecord? {
    val id = _uiState.value.selectedPatientId ?: return null
    return patients.value.firstOrNull { it.id == id }
  }

  private fun defaultConsultationTools(patientId: String, clinicianName: String) =
    ConsultationToolState(
      patientId = patientId,
      consentDocumented = false,
      consentScope = "Clinical examination & treatment discussion",
      consentClinician = clinicianName,
      consentTimestamp = repository.nowFormatted(),
      chaperoneName = "Not required / Declined",
      interpreterLanguage = "English (No interpreter required)",
      interpreterId = "",
      sharedLeafletTitles = emptyList(),
      clinicalImageAttached = false,
      imageConsentConfirmed = false,
      imageAttribution = "Protected clinical workspace container only",
      referralDraftSummary = "",
    )
}
