package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// NHS-inspired calm clinical palette paired with restrained Apple-style surfaces
val NhsBlue = Color(0xFF005EB8)
val NhsDarkBlue = Color(0xFF003087)
val NhsBrightBlue = Color(0xFF0072CE)
val NhsAquaBlue = Color(0xFF00A9CE)
val NhsPaleBlue = Color(0xFFE8F1FA)
val NhsIceSurface = Color(0xFFF4F7FA)

val ClinicalWhite = Color(0xFFFFFFFF)
val ClinicalBorder = Color(0xFFD8E2EC)
val ClinicalInk = Color(0xFF1A2530)
val ClinicalSecondaryInk = Color(0xFF4C6272)

val NhsGreen = Color(0xFF007F3B)
val NhsGreenTint = Color(0xFFE6F4EC)

val NhsAmber = Color(0xFF9A5B00)
val NhsAmberTint = Color(0xFFFFF4D6)

val NhsRed = Color(0xFFDA291C)
val NhsRedTint = Color(0xFFFDE8E6)

val NhsPurple = Color(0xFF330072)
val NhsPurpleTint = Color(0xFFF0EBF8)

// Dark mode clinical shift palette
val DarkClinicalBg = Color(0xFF0E1620)
val DarkClinicalSurface = Color(0xFF16212E)
val DarkClinicalSurfaceVariant = Color(0xFF1F2D3D)
val DarkClinicalBorder = Color(0xFF2D3F54)
val DarkClinicalInk = Color(0xFFEBF2F7)
val DarkNhsBlue = Color(0xFF5CAEFF)
