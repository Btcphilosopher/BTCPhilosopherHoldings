package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ClinicalDao {
  @Query("SELECT * FROM patients ORDER BY fullName ASC")
  fun observePatients(): Flow<List<PatientEntity>>

  @Query("SELECT COUNT(*) FROM patients")
  suspend fun countPatients(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPatients(items: List<PatientEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertPatient(item: PatientEntity)

  @Query("SELECT * FROM appointments ORDER BY timeSlot ASC")
  fun observeAppointments(): Flow<List<AppointmentEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAppointments(items: List<AppointmentEntity>)

  @Query("SELECT * FROM allergies")
  fun observeAllergies(): Flow<List<AllergyEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAllergies(items: List<AllergyEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertAllergy(item: AllergyEntity)

  @Query("SELECT * FROM problems")
  fun observeProblems(): Flow<List<ProblemEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertProblems(items: List<ProblemEntity>)

  @Query("SELECT * FROM encounters")
  fun observeEncounters(): Flow<List<EncounterEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertEncounters(items: List<EncounterEntity>)

  @Query("SELECT * FROM medications")
  fun observeMedications(): Flow<List<MedicationEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMedications(items: List<MedicationEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertMedication(item: MedicationEntity)

  @Query("SELECT * FROM observations")
  fun observeObservations(): Flow<List<ObservationEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertObservations(items: List<ObservationEntity>)

  @Query("SELECT * FROM lab_results")
  fun observeLabResults(): Flow<List<LabResultEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertLabResults(items: List<LabResultEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertLabResult(item: LabResultEntity)

  @Query("SELECT * FROM clinical_notes ORDER BY updatedAt DESC")
  fun observeNotes(): Flow<List<ClinicalNoteEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertNotes(items: List<ClinicalNoteEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertNote(item: ClinicalNoteEntity)

  @Query("SELECT * FROM note_versions ORDER BY versionNumber DESC")
  fun observeNoteVersions(): Flow<List<NoteVersionEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertNoteVersions(items: List<NoteVersionEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertNoteVersion(item: NoteVersionEntity)

  @Query("SELECT * FROM note_addenda")
  fun observeNoteAddenda(): Flow<List<NoteAddendumEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertNoteAddenda(items: List<NoteAddendumEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertNoteAddendum(item: NoteAddendumEntity)

  @Query("SELECT * FROM care_plans")
  fun observeCarePlans(): Flow<List<CarePlanEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCarePlans(items: List<CarePlanEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertCarePlan(item: CarePlanEntity)

  @Query("SELECT * FROM clinical_tasks ORDER BY dueTime ASC")
  fun observeTasks(): Flow<List<ClinicalTaskEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTasks(items: List<ClinicalTaskEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertTask(item: ClinicalTaskEntity)

  @Query("SELECT * FROM handovers")
  fun observeHandovers(): Flow<List<HandoverSbarEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertHandovers(items: List<HandoverSbarEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertHandover(item: HandoverSbarEntity)

  @Query("SELECT * FROM team_messages")
  fun observeMessages(): Flow<List<TeamMessageEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMessages(items: List<TeamMessageEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertMessage(item: TeamMessageEntity)

  @Query("SELECT * FROM body_strokes")
  fun observeBodyStrokes(): Flow<List<BodyStrokeEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertBodyStroke(item: BodyStrokeEntity)

  @Query("DELETE FROM body_strokes WHERE patientId = :patientId")
  suspend fun clearBodyStrokesForPatient(patientId: String)

  @Query("SELECT * FROM consultation_tools")
  fun observeConsultationTools(): Flow<List<ConsultationToolEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertConsultationTools(items: List<ConsultationToolEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertConsultationTool(item: ConsultationToolEntity)

  @Query("SELECT * FROM audit_events ORDER BY timestamp DESC")
  fun observeAuditEvents(): Flow<List<AuditEventEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAuditEvents(items: List<AuditEventEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAuditEvent(item: AuditEventEntity)

  @Query("SELECT * FROM sync_queue ORDER BY queuedAt DESC")
  fun observeSyncQueue(): Flow<List<SyncQueueEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertSyncItem(item: SyncQueueEntity)

  @Query("DELETE FROM sync_queue WHERE id = :id")
  suspend fun deleteSyncItem(id: String)

  @Query("DELETE FROM sync_queue")
  suspend fun clearSyncQueue()
}
