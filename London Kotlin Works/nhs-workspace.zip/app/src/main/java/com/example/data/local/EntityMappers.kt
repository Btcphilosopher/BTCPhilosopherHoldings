package com.example.data.local

import com.example.data.model.AllergyEntry
import com.example.data.model.AppointmentSummary
import com.example.data.model.AuditEvent
import com.example.data.model.BodyAnnotationStroke
import com.example.data.model.CarePlanItem
import com.example.data.model.ClinicalNote
import com.example.data.model.ClinicalTask
import com.example.data.model.ConsultationToolState
import com.example.data.model.EncounterSummary
import com.example.data.model.HandoverSbar
import com.example.data.model.LabResult
import com.example.data.model.MedicationEntry
import com.example.data.model.NoteAddendum
import com.example.data.model.NoteVersion
import com.example.data.model.ObservationPoint
import com.example.data.model.PatientRecord
import com.example.data.model.ProblemEntry
import com.example.data.model.SyncQueueItem
import com.example.data.model.TeamMessage

fun PatientEntity.toDomain() =
  PatientRecord(
    id, nhsNumber, mrn, nhsNumberVerified, demographicsVerified, identityStatus,
    duplicateCandidateIds, fullName, preferredName, dateOfBirth, sex, address, gpPractice,
    encounterId, encounterType, location, service, ward, clinic, assignedClinicianId,
    allergyStatus, recordAlerts, presentingProblem, historySummary, historyStatus,
    medicationHistoryStatus, observationsStatus, lastSyncedAt,
  )

fun PatientRecord.toEntity() =
  PatientEntity(
    id, nhsNumber, mrn, nhsNumberVerified, demographicsVerified, identityStatus,
    duplicateCandidateIds, fullName, preferredName, dateOfBirth, sex, address, gpPractice,
    encounterId, encounterType, location, service, ward, clinic, assignedClinicianId,
    allergyStatus, recordAlerts, presentingProblem, historySummary, historyStatus,
    medicationHistoryStatus, observationsStatus, lastSyncedAt,
  )

fun AppointmentEntity.toDomain() =
  AppointmentSummary(id, patientId, patientName, timeSlot, clinicName, service, clinicianId, reason, status)

fun AppointmentSummary.toEntity() =
  AppointmentEntity(id, patientId, patientName, timeSlot, clinicName, service, clinicianId, reason, status)

fun AllergyEntity.toDomain() =
  AllergyEntry(id, patientId, substance, reaction, severity, verificationStatus, source, recordedBy, recordedAt)

fun AllergyEntry.toEntity() =
  AllergyEntity(id, patientId, substance, reaction, severity, verificationStatus, source, recordedBy, recordedAt)

fun ProblemEntity.toDomain() =
  ProblemEntry(id, patientId, title, code, status, source, author, timestamp)

fun ProblemEntry.toEntity() =
  ProblemEntity(id, patientId, title, code, status, source, author, timestamp)

fun EncounterEntity.toDomain() =
  EncounterSummary(id, patientId, encounterType, location, clinician, dateLabel, summary)

fun EncounterSummary.toEntity() =
  EncounterEntity(id, patientId, encounterType, location, clinician, dateLabel, summary)

fun MedicationEntity.toDomain() =
  MedicationEntry(
    id, patientId, drugName, strength, dose, route, frequency, startDate, endDate,
    category, prescriptionStatus, informationSource, reconciliationStatus, notes,
  )

fun MedicationEntry.toEntity() =
  MedicationEntity(
    id, patientId, drugName, strength, dose, route, frequency, startDate, endDate,
    category, prescriptionStatus, informationSource, reconciliationStatus, notes,
  )

fun ObservationEntity.toDomain() =
  ObservationPoint(id, patientId, metricType, displayName, value, numericValue, unit, measuredAt, provenance, isAbnormal)

fun ObservationPoint.toEntity() =
  ObservationEntity(id, patientId, metricType, displayName, value, numericValue, unit, measuredAt, provenance, isAbnormal)

fun LabResultEntity.toDomain() =
  LabResult(
    id, patientId, testName, panelName, value, unit, referenceInterval, criticalFlag,
    requestStatus, specimenCollectedAt, resultTime, reportStatus, reviewState,
    acknowledgedBy, acknowledgedAt, actionCompletedBy, actionCompletedAt, followUpOwner,
    linkedTaskId, provenance, previousValueIfCorrected,
  )

fun LabResult.toEntity() =
  LabResultEntity(
    id, patientId, testName, panelName, value, unit, referenceInterval, criticalFlag,
    requestStatus, specimenCollectedAt, resultTime, reportStatus, reviewState,
    acknowledgedBy, acknowledgedAt, actionCompletedBy, actionCompletedAt, followUpOwner,
    linkedTaskId, provenance, previousValueIfCorrected,
  )

fun ClinicalNoteEntity.toDomain() =
  ClinicalNote(
    id, patientId, encounterId, templateType, status, authorId, authorName, createdAt, updatedAt,
    signedAt, serverVersion, historyText, examinationText, assessmentText, planText,
    specialtyExtraText, freeText, carriedForwardAttribution, isLocalOfflineDraft, hasConflict,
    remoteConflictEditor, remoteConflictSummary, enteredInErrorReason,
  )

fun ClinicalNote.toEntity() =
  ClinicalNoteEntity(
    id, patientId, encounterId, templateType, status, authorId, authorName, createdAt, updatedAt,
    signedAt, serverVersion, historyText, examinationText, assessmentText, planText,
    specialtyExtraText, freeText, carriedForwardAttribution, isLocalOfflineDraft, hasConflict,
    remoteConflictEditor, remoteConflictSummary, enteredInErrorReason,
  )

fun NoteVersionEntity.toDomain() =
  NoteVersion(id, noteId, versionNumber, status, editorName, timestamp, changeSummary, snapshotText)

fun NoteVersion.toEntity() =
  NoteVersionEntity(id, noteId, versionNumber, status, editorName, timestamp, changeSummary, snapshotText)

fun NoteAddendumEntity.toDomain() =
  NoteAddendum(id, noteId, authorName, timestamp, reason, text)

fun NoteAddendum.toEntity() =
  NoteAddendumEntity(id, noteId, authorName, timestamp, reason, text)

fun CarePlanEntity.toDomain() =
  CarePlanItem(id, patientId, title, patientFriendlyExplanation, goals, warningSigns, followUpInstructions, approvedByClinician, updatedAt)

fun CarePlanItem.toEntity() =
  CarePlanEntity(id, patientId, title, patientFriendlyExplanation, goals, warningSigns, followUpInstructions, approvedByClinician, updatedAt)

fun ClinicalTaskEntity.toDomain() =
  ClinicalTask(id, patientId, title, ownerName, ownerRole, priority, dueTime, status, supportingContext, completionEvidence, linkedResultId)

fun ClinicalTask.toEntity() =
  ClinicalTaskEntity(id, patientId, title, ownerName, ownerRole, priority, dueTime, status, supportingContext, completionEvidence, linkedResultId)

fun HandoverSbarEntity.toDomain() =
  HandoverSbar(id, patientId, situation, background, assessment, recommendation, authorName, updatedAt, acknowledgedBy)

fun HandoverSbar.toEntity() =
  HandoverSbarEntity(id, patientId, situation, background, assessment, recommendation, authorName, updatedAt, acknowledgedBy)

fun TeamMessageEntity.toDomain() =
  TeamMessage(id, patientId, senderName, senderRole, recipientTeam, body, timestamp, deliveryState)

fun TeamMessage.toEntity() =
  TeamMessageEntity(id, patientId, senderName, senderRole, recipientTeam, body, timestamp, deliveryState)

fun BodyStrokeEntity.toDomain() =
  BodyAnnotationStroke(id, patientId, regionLabel, pointsSerialized, colorHex, strokeWidth)

fun BodyAnnotationStroke.toEntity() =
  BodyStrokeEntity(id, patientId, regionLabel, pointsSerialized, colorHex, strokeWidth)

fun ConsultationToolEntity.toDomain() =
  ConsultationToolState(
    patientId, consentDocumented, consentScope, consentClinician, consentTimestamp,
    chaperoneName, interpreterLanguage, interpreterId, sharedLeafletTitles,
    clinicalImageAttached, imageConsentConfirmed, imageAttribution, referralDraftSummary,
  )

fun ConsultationToolState.toEntity() =
  ConsultationToolEntity(
    patientId, consentDocumented, consentScope, consentClinician, consentTimestamp,
    chaperoneName, interpreterLanguage, interpreterId, sharedLeafletTitles,
    clinicalImageAttached, imageConsentConfirmed, imageAttribution, referralDraftSummary,
  )

fun AuditEventEntity.toDomain() =
  AuditEvent(id, timestamp, actorName, actorRole, actionType, patientId, patientName, resourceSummary, outcome, isBreakGlass, detail)

fun AuditEvent.toEntity() =
  AuditEventEntity(id, timestamp, actorName, actorRole, actionType, patientId, patientName, resourceSummary, outcome, isBreakGlass, detail)

fun SyncQueueEntity.toDomain() =
  SyncQueueItem(id, entityType, entityId, patientId, summary, queuedAt, status)

fun SyncQueueItem.toEntity() =
  SyncQueueEntity(id, entityType, entityId, patientId, summary, queuedAt, status)
