package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.ClinicianAccount
import com.example.ui.components.StatusPill
import com.example.ui.theme.*

@Composable
fun SignInScreen(
  accounts: List<ClinicianAccount>,
  error: String?,
  onSignIn: (String, String) -> Unit,
) {
  var selectedAccountId by remember { mutableStateOf(accounts.firstOrNull()?.id ?: "") }
  var pin by remember { mutableStateOf("1234") }

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(NhsIceSurface)
        .windowInsetsPadding(WindowInsets.safeDrawing)
        .padding(24.dp),
    contentAlignment = Alignment.Center,
  ) {
    Card(
      modifier = Modifier.widthIn(max = 680.dp).fillMaxWidth(),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = ClinicalWhite),
      border = BorderStroke(1.dp, ClinicalBorder),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
      Column(
        modifier = Modifier.verticalScroll(rememberScrollState()).padding(28.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
          Image(
            painter = painterResource(id = R.drawable.img_clinician_avatar),
            contentDescription = stringResource(id = R.string.clinician_avatar_desc),
            modifier = Modifier.size(64.dp).clip(CircleShape),
            contentScale = ContentScale.Crop,
          )
          Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            StatusPill(
              text = "INDEPENDENT PROTOTYPE • SYNTHETIC DATA ONLY",
              icon = Icons.Filled.VerifiedUser,
              containerColor = NhsPaleBlue,
              contentColor = NhsDarkBlue,
            )
            Text(
              text = "NHS Clinical Workspace",
              style = MaterialTheme.typography.headlineLarge,
              color = NhsDarkBlue,
              modifier = Modifier.semantics { heading() },
            )
            Text(
              text = "Tablet-first clinical documentation, results review & care coordination demonstration",
              style = MaterialTheme.typography.bodyMedium,
              color = ClinicalSecondaryInk,
            )
          }
        }

        HorizontalDivider(color = ClinicalBorder)

        Text(
          text = "Select Clinician Profile (Replaceable Identity Adapter)",
          style = MaterialTheme.typography.titleMedium,
          color = ClinicalInk,
        )

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          accounts.forEach { account ->
            val selected = account.id == selectedAccountId
            Surface(
              shape = RoundedCornerShape(14.dp),
              color = if (selected) NhsPaleBlue else NhsIceSurface,
              border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) NhsBlue else ClinicalBorder),
              modifier =
                Modifier.fillMaxWidth()
                  .minimumInteractiveComponentSize()
                  .clickable { selectedAccountId = account.id }
                  .testTag("account_card_${account.id}"),
            ) {
              Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                  Text(
                    text = account.displayName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = ClinicalInk,
                  )
                  Text(
                    text = "${account.role} • ${account.specialty} • ${account.gmcOrRegistration}",
                    style = MaterialTheme.typography.bodySmall,
                    color = ClinicalSecondaryInk,
                  )
                  Text(
                    text =
                      "Authorised Services: ${account.authorisedServices.joinToString()}",
                    style = MaterialTheme.typography.labelSmall,
                    color = NhsDarkBlue,
                  )
                }
                RadioButton(
                  selected = selected,
                  onClick = { selectedAccountId = account.id },
                )
              }
            }
          }
        }

        OutlinedTextField(
          value = pin,
          onValueChange = { pin = it },
          label = { Text("Smartcard / CIS2 Prototype PIN (Demo: 1234)") },
          visualTransformation = PasswordVisualTransformation(),
          singleLine = true,
          isError = error != null,
          supportingText = { if (error != null) Text(error) },
          modifier = Modifier.fillMaxWidth().testTag("signin_pin_input"),
        )

        Button(
          onClick = { onSignIn(selectedAccountId, pin) },
          modifier =
            Modifier.fillMaxWidth().height(52.dp).testTag("signin_submit_button"),
          colors = ButtonDefaults.buttonColors(containerColor = NhsBlue),
        ) {
          Icon(Icons.Filled.Login, contentDescription = null)
          Spacer(Modifier.width(8.dp))
          Text("Sign In to Clinical Shift", style = MaterialTheme.typography.titleMedium)
        }

        Text(
          text =
            "Safety Notice: Independent prototype using synthetic records only. Not connected to live NHS Spine, PAS, or ePMA. Never enter real patient identifiable data.",
          style = MaterialTheme.typography.bodySmall,
          color = ClinicalSecondaryInk,
        )
      }
    }
  }
}
