package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val NhsLightColorScheme =
  lightColorScheme(
    primary = NhsBlue,
    onPrimary = ClinicalWhite,
    primaryContainer = NhsPaleBlue,
    onPrimaryContainer = NhsDarkBlue,
    secondary = NhsBrightBlue,
    onSecondary = ClinicalWhite,
    secondaryContainer = ColorTokens.SecondaryContainer,
    onSecondaryContainer = ClinicalInk,
    tertiary = NhsGreen,
    onTertiary = ClinicalWhite,
    tertiaryContainer = NhsGreenTint,
    onTertiaryContainer = NhsGreen,
    error = NhsRed,
    onError = ClinicalWhite,
    errorContainer = NhsRedTint,
    onErrorContainer = NhsRed,
    background = NhsIceSurface,
    onBackground = ClinicalInk,
    surface = ClinicalWhite,
    onSurface = ClinicalInk,
    surfaceVariant = NhsIceSurface,
    onSurfaceVariant = ClinicalSecondaryInk,
    outline = ClinicalBorder,
  )

private val NhsDarkColorScheme =
  darkColorScheme(
    primary = DarkNhsBlue,
    onPrimary = DarkClinicalBg,
    primaryContainer = ColorTokens.DarkPrimaryContainer,
    onPrimaryContainer = DarkClinicalInk,
    secondary = NhsAquaBlue,
    onSecondary = DarkClinicalBg,
    tertiary = ColorTokens.DarkGreen,
    onTertiary = DarkClinicalBg,
    error = ColorTokens.DarkRed,
    onError = DarkClinicalBg,
    background = DarkClinicalBg,
    onBackground = DarkClinicalInk,
    surface = DarkClinicalSurface,
    onSurface = DarkClinicalInk,
    surfaceVariant = DarkClinicalSurfaceVariant,
    onSurfaceVariant = ColorTokens.DarkSecondaryInk,
    outline = DarkClinicalBorder,
  )

private object ColorTokens {
  val SecondaryContainer = androidx.compose.ui.graphics.Color(0xFFEAF3FA)
  val DarkPrimaryContainer = androidx.compose.ui.graphics.Color(0xFF0A396B)
  val DarkSecondaryInk = androidx.compose.ui.graphics.Color(0xFFA8BACB)
  val DarkGreen = androidx.compose.ui.graphics.Color(0xFF56D48A)
  val DarkRed = androidx.compose.ui.graphics.Color(0xFFFF7D73)
}

val ClinicalShapes =
  Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(20.dp),
  )

@Composable
fun NhsClinicalTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) NhsDarkColorScheme else NhsLightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    shapes = ClinicalShapes,
    content = content,
  )
}
