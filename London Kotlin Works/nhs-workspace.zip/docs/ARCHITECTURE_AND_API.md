# NHS Clinical Workspace — Architecture, Schema, API Contracts & Governance

> **Prototype Disclaimer:** This is an **independent, non-certified prototype** built for native Android (Kotlin + Jetpack Compose, tablet-first adaptive split-view). All patient records, clinician accounts, NHS numbers, and laboratory reports are **100% synthetic**. It is not connected to live NHS Spine, CIS2, PAS, LIMS, or ePMA systems.

## 1. Platform & Environment Alignment
- **Client Runtime:** Native Android (Kotlin, Jetpack Compose, Material 3, Room SQLite + KSP, Firebase AI Logic + App Check).
- **Adaptive Form Factor:** Tablet-first 3-pane split view (`BoxWithConstraints` breakpoints: `>=960.dp` Sidebar + Workspace + Inspector; `600–959.dp` NavigationRail + Workspace + Modal Inspector; `<600.dp` Compact tab bar + Workspace + Modal Inspector).
- **Note on Original Multi-Stack Spec:** Because this workspace targets the Android Gradle/Compose execution environment and Streaming Android Emulator, the client UI, local Room persistence, and mock backend interoperability adapters are implemented natively in Kotlin on Android rather than Swift/SwiftUI/Xcode or an external Python/FastAPI/PostgreSQL host.

## 2. Screen Map
1. `SignInScreen` — Replaceable Identity Adapter (`LocalMockIdentityAdapter`), clinician persona selector, PIN entry, prototype disclosure.
2. `HomeWorklistsScreen` — Role-scoped Today's Clinic appointments, ward/clinic patient lists, tasks, results awaiting review, draft notes, SBAR handovers, team messages, and filter chips (Service, Ward, Clinic, Clinician, Task Status).
3. `PatientSearchScreen` — Search by name, NHS number, MRN, or location; displays duplicate-record warnings, unverified demographics, and uncertain-identity resolution controls.
4. `PatientOverviewScreen` — 10 expandable clinical sections with source/author/timestamp provenance and explicit distinction between `No Known Allergies`, `Not Assessed`, and `Information Unavailable`.
5. `ClinicalNotesScreen` — 7 configurable templates (`Consultation`, `Ward Round`, `Admission`, `Progress`, `Procedure`, `Discharge`, `Handover`), autosave, carried-forward attribution, preview-before-signing, immutable `Signed`/`Amended`/`Entered-in-Error` states, version history, linked addenda, and side-by-side concurrent edit conflict resolution.
6. `ObservationsAndResultsScreen` — Vital signs + Compose Canvas trendline; lab results with lab-supplied reference intervals, corrected report history, and separate `Unviewed` / `Viewed` / `Acknowledged` / `Action Completed` states.
7. `MedicationsAndAllergiesScreen` — Separated `Prescribed`, `Patient-Reported`, `Dispensed`, and `Administered` categories; reconciliation controls; simulated ordering behind patient confirmation; structured allergy documentation.
8. `ConsultationToolsScreen` — Stylus & touch annotatable body diagram (`Canvas` + `pointerInput`), consent/chaperone/interpreter logging, approved leaflets, protected synthetic clinical attachment (`R.drawable.img_synthetic_dermatology_lesion`), referral draft, and summary preview.
9. `CarePlanScreen` — Editable plain-language care plan with toggleable high-legibility `Patient-Facing View`.
10. `TasksHandoverMessagesScreen` — Patient-linked tasks with completion evidence, structured SBAR handover, and secure team messages with separate urgent escalation warning.
11. `AuditHistoryScreen` — Filterable immutable audit log of sign-in, views, edits, signing, addenda, break-glass overrides, AI review, and sync events.
12. `DetailInspectorPanel` — Results, Medications, Prior Notes, Optional AI Assistant (Organisational IG Approval toggle), and 10-Step Guided Demo / Edge-Case Scenarios.

## 3. Repository Structure
```
app/src/main/java/com/example/
├── MainActivity.kt                  # App Check wiring + Edge-to-Edge + NhsClinicalTheme
├── firebase/AppCheckInit.kt         # Firebase App Check debug/release setup
├── data/
│   ├── model/ClinicalModels.kt      # Domain models & clinical enums
│   ├── local/
│   │   ├── ClinicalEntities.kt      # Room @Entity definitions & TypeConverters
│   │   ├── ClinicalDao.kt           # Reactive Flow DAOs
│   │   ├── ClinicalDatabase.kt      # Room SQLite singleton
│   │   └── EntityMappers.kt         # Entity <-> Domain mappers
│   ├── adapter/ClinicalAdapters.kt  # Replaceable Identity, PAS, Notes, Lab, Appointments adapters
│   ├── seed/SyntheticClinicalSeed.kt# 6 synthetic patients, appointments, labs, notes, audit seed
│   ├── repository/ClinicalRepository.kt
│   └── ai/ClinicalAiAssistant.kt    # Optional Firebase AI Logic + local grounded fallback
└── ui/
    ├── theme/                       # NHS palette, Inter + JetBrains Mono typography, M3 shapes
    ├── components/ClinicalCommonComponents.kt
    ├── viewmodel/ClinicalWorkspaceViewModel.kt
    └── screens/                     # Modular Compose screens + adaptive split-view shell
```

## 4. Local Room Database Schema (19 Entities)
`patients`, `appointments`, `allergies`, `problems`, `encounters`, `medications`, `observations`, `lab_results`, `clinical_notes`, `note_versions`, `note_addenda`, `care_plans`, `clinical_tasks`, `handovers`, `team_messages`, `body_strokes`, `consultation_tools`, `audit_events`, `sync_queue`.

## 5. Backend & Interoperability Adapter Contracts
The `ClinicalAdapters.kt` layer isolates external system integration behind testable Kotlin interfaces:
- `IdentityProviderAdapter` -> Target NHS standard: **NHS CIS2 (Care Identity Service 2)** / OIDC with Smartcard/FIDO2 authenticator.
- `PatientAdministrationAdapter` -> Target NHS standard: **Personal Demographics Service (PDS) FHIR R4 API** & **FHIR UK Core** (`UKCore-Patient`, `UKCore-Encounter`, `UKCore-AllergyIntolerance`).
- `ClinicalRecordsAdapter` -> Target NHS standard: **FHIR UK Core** (`UKCore-Composition`, `UKCore-DocumentReference`) with optimistic concurrency (`If-Match` / `ETag` version checks).
- `LaboratoryResultsAdapter` -> Target NHS standard: **FHIR UK Core** (`UKCore-DiagnosticReport`, `UKCore-Observation`) preserving laboratory-supplied `referenceRange` and `status` (`preliminary`, `final`, `corrected`).
- `AppointmentsAdapter` -> Target NHS standard: **GP Connect / NHS Booking & Referral (BaRS) FHIR R4**.

> Note: Before implementing live FHIR UK Core integrations, exact profile URLs, SNOMED CT UK / dm+d ValueSet bindings, and NHS England Developer Portal onboarding scopes must be verified against current official NHS England Digital documentation (`digital.nhs.uk`).

## 6. Pre-Deployment NHS Governance & Clinical Safety Prerequisites
Before any real-world NHS deployment in England (or devolved nations under equivalent national frameworks):
1. **Applicable Organisation & Jurisdiction:** Commissioning NHS Trust / Integrated Care Board (ICB) / GP Federation under England & Wales law (UK GDPR, Data Protection Act 2018, Health and Social Care Act).
2. **Clinical Safety Assessment:** Mandatory compliance with **DCB0129** (manufacturer clinical risk management & Hazard Log signed by a qualified Clinical Safety Officer) and **DCB0160** (deploying NHS organisation clinical risk assessment).
3. **Information Governance & Cybersecurity:** **NHS Data Security and Protection Toolkit (DSPT)** annual assertion, **DPIA** (Data Protection Impact Assessment), **Cyber Essentials Plus**, and **DTAC** (Digital Technology Assessment Criteria).
4. **Medical Device Regulation:** Assessment with **MHRA** under UK Medical Devices Regulations 2002 (determining whether clinical decision support, prescribing, or result alerting triggers UKCA Class I/IIa Software as a Medical Device classification).
5. **National Integration Approvals:** NHS England **Supplier Conformance Assessment List (SCAL)**, **CIS2 onboarding**, **PDS / Spine IM1 / BaRS / ePMA** assurance, and explicit **IG data-processing agreements** before transmitting any data to external AI endpoints.

## 7. Implementation Status Account
- **Implemented Natively (Kotlin/Compose/Room):** Adaptive tablet split-view UI, custom NHS adaptive icon & Inter/JetBrains Mono typography, persistent patient banner, RBAC care-context checks, audited Break-Glass access, session lock & PIN reauthentication, patient-switch draft isolation guard, 7 configurable note templates with autosave/preview/signing/addenda/entered-in-error/version history, concurrent-edit conflict resolution, observations & lab result 3-state review workflow, medication category separation & reconciliation, stylus/touch body diagram, consent/chaperone/interpreter & synthetic image attachment, patient-friendly care plan view, SBAR handover, tasks, team messages with escalation warning, offline queue, searchable audit log, and 10-step interactive demo tracker.
- **Simulated Locally:** CIS2 identity provider, PAS/PDS trace, LIMS lab amendment feed, ePMA prescribing orders, remote concurrent edit simulation, and offline connectivity toggle via `LocalMock*` adapters and `SyntheticClinicalSeed`.
- **Integrated:** Firebase AI Logic (`gemini-3.8-flash`) + Firebase App Check (`configureAppCheck`), strictly gated behind the Organisational IG Approval toggle with a deterministic local record-grounded fallback when disabled or offline.
- **Tested:** Robolectric JVM tests covering UI rendering, patient isolation, RBAC & break-glass audit, note signing/amendments/conflicts, result state separation, and offline sync queue.
