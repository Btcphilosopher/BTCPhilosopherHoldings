'use client';

import React, { useState, useEffect } from 'react';
import { Navbar } from '../components/Navbar';
import { HeroSlider } from '../components/HeroSlider';
import { FeatureGrid } from '../components/FeatureGrid';
import { MenuModal } from '../components/MenuModal';
import { ThreeBurgerViewer } from '../components/ThreeBurgerViewer';
import { PixelArtMode } from '../components/PixelArtMode';
import { RestaurantLocatorModal } from '../components/RestaurantLocatorModal';
import { McCafeModal } from '../components/McCafeModal';
import { DeliveryModal } from '../components/DeliveryModal';
import { CartDrawer, CartItem } from '../components/CartDrawer';
import { SearchModal } from '../components/SearchModal';
import { ProfileModal } from '../components/ProfileModal';
import { InfoModal } from '../components/InfoModal';
import { Footer } from '../components/Footer';
import { MenuItem, RestaurantLocation } from '../data/menuData';

export default function HomePage() {
  // Navigation & Active View state
  const [activeTab, setActiveTab] = useState('food');

  // Modals state
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [is3DViewerOpen, setIs3DViewerOpen] = useState(false);
  const [isPixelModeOpen, setIsPixelModeOpen] = useState(false);
  const [isRestaurantsOpen, setIsRestaurantsOpen] = useState(false);
  const [isMcCafeOpen, setIsMcCafeOpen] = useState(false);
  const [isDeliveryOpen, setIsDeliveryOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [infoModalType, setInfoModalType] = useState<
    'careers' | 'sustainability' | 'accessibility' | 'terms' | null
  >(null);

  // Cart & Order State
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [orderMode, setOrderMode] = useState<'delivery' | 'pickup'>('delivery');
  const [deliveryAddress, setDeliveryAddress] = useState('10 Downing Street, London SW1A 2AA');
  const [rewardsPoints, setRewardsPoints] = useState(1450);

  // Keyboard shortcut: CMD+K to open Search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Add Item to Bag
  const handleAddToCart = (item: any, customizations?: string[]) => {
    setCartItems((prev) => {
      const existing = prev.find((it) => it.id === item.id);
      if (existing) {
        return prev.map((it) =>
          it.id === item.id ? { ...it, quantity: it.quantity + 1 } : it
        );
      }
      return [
        ...prev,
        {
          id: item.id || `item-${Date.now()}`,
          name: item.name,
          price: item.price,
          calories: item.calories,
          image: item.image,
          quantity: 1,
          customizations,
        },
      ];
    });
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((it) => {
          if (it.id === id) {
            const newQty = it.quantity + delta;
            return newQty > 0 ? { ...it, quantity: newQty } : null;
          }
          return it;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveItem = (id: string) => {
    setCartItems((prev) => prev.filter((it) => it.id !== id));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  // Tab routing
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    if (tab === 'food') {
      setIsMenuOpen(true);
    } else if (tab === 'restaurants') {
      setIsRestaurantsOpen(true);
    } else if (tab === 'mcdelivery') {
      setIsDeliveryOpen(true);
    } else if (tab === 'rewards') {
      setIsProfileOpen(true);
    } else if (tab === 'story') {
      setInfoModalType('sustainability');
    }
  };

  // Hero slide action triggers
  const handleHeroAction = (actionType: 'order' | 'mccafe' | 'delivery' | 'restaurants') => {
    if (actionType === 'order') {
      setIsMenuOpen(true);
    } else if (actionType === 'mccafe') {
      setIsMcCafeOpen(true);
    } else if (actionType === 'delivery') {
      setIsDeliveryOpen(true);
    } else if (actionType === 'restaurants') {
      setIsRestaurantsOpen(true);
    }
  };

  const handleSelectStore = (store: RestaurantLocation) => {
    setOrderMode('pickup');
    setIsMenuOpen(true);
  };

  const handleStartDelivery = (addr: string) => {
    setDeliveryAddress(addr);
    setOrderMode('delivery');
    setIsMenuOpen(true);
  };

  const handleRedeemReward = (rewardName: string, cost: number) => {
    setRewardsPoints((prev) => Math.max(0, prev - cost));
    handleAddToCart({
      id: `reward-${Date.now()}`,
      name: `${rewardName} (Reward)`,
      price: 0.0,
      calories: 300,
    });
    setIsProfileOpen(false);
    setIsCartOpen(true);
  };

  return (
    <main className="min-h-screen bg-[#0a0a0c] text-white flex flex-col justify-between">
      {/* Navigation Top Bar */}
      <Navbar
        activeTab={activeTab}
        onTabChange={handleTabChange}
        onOpenOrder={() => setIsMenuOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenProfile={() => setIsProfileOpen(true)}
        onOpenCart={() => setIsCartOpen(true)}
        onTogglePixelMode={() => setIsPixelModeOpen(!isPixelModeOpen)}
        isPixelMode={isPixelModeOpen}
        cartItemCount={cartItems.reduce((acc, it) => acc + it.quantity, 0)}
      />

      {/* Hero Section with Cinematic Slider matching screenshot */}
      <HeroSlider
        onAction={handleHeroAction}
        onOpen3DViewer={() => setIs3DViewerOpen(true)}
      />

      {/* 4 Feature Cards Grid matching screenshot bottom */}
      <FeatureGrid
        onOpenMenu={() => setIsMenuOpen(true)}
        onOpenMcCafe={() => setIsMcCafeOpen(true)}
        onOpenDelivery={() => setIsDeliveryOpen(true)}
        onOpenRestaurants={() => setIsRestaurantsOpen(true)}
      />

      {/* Footer matching screenshot */}
      <Footer
        onOpenSustainability={() => setInfoModalType('sustainability')}
        onOpenCareers={() => setInfoModalType('careers')}
        onOpenAccessibility={() => setInfoModalType('accessibility')}
        onOpenTerms={() => setInfoModalType('terms')}
      />

      {/* Interactive Modals & Drawers */}
      <MenuModal
        isOpen={isMenuOpen}
        onClose={() => setIsMenuOpen(false)}
        onAddToCart={handleAddToCart}
        onOpen3DViewer={() => {
          setIsMenuOpen(false);
          setIs3DViewerOpen(true);
        }}
      />

      {/* Three.js 3D Interactive Big Mac Layer Inspector */}
      <ThreeBurgerViewer
        isOpen={is3DViewerOpen}
        onClose={() => setIs3DViewerOpen(false)}
      />

      {/* Pure HTML & CSS Pixel Art Nostalgia Mode */}
      {isPixelModeOpen && (
        <PixelArtMode
          onClose={() => setIsPixelModeOpen(false)}
          onAddToCart={handleAddToCart}
        />
      )}

      {/* Restaurant Locator */}
      <RestaurantLocatorModal
        isOpen={isRestaurantsOpen}
        onClose={() => setIsRestaurantsOpen(false)}
        onSelectStore={handleSelectStore}
      />

      {/* McCafé Artisanal Roasts Modal */}
      <McCafeModal
        isOpen={isMcCafeOpen}
        onClose={() => setIsMcCafeOpen(false)}
        onAddToCart={handleAddToCart}
      />

      {/* McDelivery Address & Arrival Estimator */}
      <DeliveryModal
        isOpen={isDeliveryOpen}
        onClose={() => setIsDeliveryOpen(false)}
        onStartDeliveryOrder={handleStartDelivery}
      />

      {/* Cart & Order Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
        orderMode={orderMode}
        setOrderMode={setOrderMode}
        deliveryAddress={deliveryAddress}
      />

      {/* Search Modal (supports CMD+K) */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectItem={(item) => {
          handleAddToCart(item);
          setIsCartOpen(true);
        }}
      />

      {/* Member Profile & Rewards */}
      <ProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        points={rewardsPoints}
        onRedeem={handleRedeemReward}
      />

      {/* Information Modal (Careers, Sustainability, Accessibility, Terms) */}
      <InfoModal
        type={infoModalType}
        onClose={() => setInfoModalType(null)}
      />
    </main>
  );
}
