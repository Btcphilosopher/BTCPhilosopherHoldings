import type { Metadata } from 'next';
import { Playfair_Display, Plus_Jakarta_Sans } from 'next/font/google';
import './globals.css';

const playfair = Playfair_Display({
  subsets: ['latin'],
  variable: '--font-serif',
  display: 'swap',
});

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  variable: '--font-sans',
  display: 'swap',
});

export const metadata: Metadata = {
  title: "McDonald's — Good Food. A Brighter Future.",
  description:
    'Experience the iconic McDonald’s modern digital flagship: handcrafted burgers, McCafé artisanal roasts, McDelivery, and sustainability innovations.',
  openGraph: {
    title: "McDonald's — Good Food. A Brighter Future.",
    description:
      'Experience the iconic McDonald’s modern digital flagship: handcrafted burgers, McCafé artisanal roasts, McDelivery, and sustainability innovations.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: "McDonald's — Good Food. A Brighter Future.",
    description:
      'Experience the iconic McDonald’s modern digital flagship: handcrafted burgers, McCafé artisanal roasts, McDelivery, and sustainability innovations.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${playfair.variable} ${plusJakarta.variable}`}>
      <body className="bg-[#0a0a0c] text-white min-h-screen antialiased selection:bg-[#FFBC0D] selection:text-black">
        {children}
      </body>
    </html>
  );
}
