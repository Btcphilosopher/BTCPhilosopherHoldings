'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { ArrowRight, ChevronLeft, ChevronRight, Box } from 'lucide-react';
import { GoldenArchLogo } from './GoldenArchLogo';

interface Slide {
  kicker: string;
  titleLine1: string;
  titleLine2: string;
  description: string;
  ctaText: string;
  image: string;
  alt: string;
  actionType: 'order' | 'mccafe' | 'delivery' | 'restaurants';
  tagline: string;
}

const SLIDES: Slide[] = [
  {
    kicker: 'THE ICON RETURNS',
    titleLine1: 'Big flavour.',
    titleLine2: 'A brighter tomorrow.',
    description:
      'The legendary Big Mac® — made with better ingredients, for a tastier, more sustainable future.',
    ctaText: 'Order Now',
    image: '/images/hero_big_mac.jpg',
    alt: 'The iconic Big Mac burger meal with fries and iced drink against a sunset city skyline',
    actionType: 'order',
    tagline: 'BETTER FOOD BRIGHTER FUTURES',
  },
  {
    kicker: 'MCCAFÉ ARTISANAL',
    titleLine1: 'Crafted with care.',
    titleLine2: 'Roasted to perfection.',
    description:
      '100% Arabica beans, Rainforest Alliance certified. Freshly ground and steamed organic milk for every cup.',
    ctaText: 'Explore McCafé',
    image: '/images/card_mccafe_latte.jpg',
    alt: 'McCafé espresso mug with artisanal rosetta latte art foam',
    actionType: 'mccafe',
    tagline: 'ALWAYS FRESH ROASTED DAILY',
  },
  {
    kicker: 'DELIVERED TO YOUR DOOR',
    titleLine1: 'Hot & fresh.',
    titleLine2: 'Wherever you are.',
    description:
      'Your favourites delivered directly to your doorstep. Sealed for heat retention and maximum crispiness.',
    ctaText: 'Order McDelivery',
    image: '/images/card_mcdelivery.jpg',
    alt: 'McDelivery order bag on a stylish waterfront terrace at twilight',
    actionType: 'delivery',
    tagline: 'SPEED SERVICE TASTE FIRST',
  },
  {
    kicker: 'SUSTAINABLE ARCHITECTURE',
    titleLine1: 'Modern spaces.',
    titleLine2: 'Real connection.',
    description:
      'Eco-designed dining rooms powered by 100% renewable electricity, recycled wood furnishings, and digital convenience.',
    ctaText: 'Find Restaurant',
    image: '/images/card_modern_restaurant.jpg',
    alt: 'Ultra-modern McDonald’s restaurant interior with ambient architectural lighting',
    actionType: 'restaurants',
    tagline: 'DESIGN FOR HUMAN CONNECTION',
  },
];

interface HeroSliderProps {
  onAction: (actionType: Slide['actionType']) => void;
  onOpen3DViewer: () => void;
}

export const HeroSlider: React.FC<HeroSliderProps> = ({
  onAction,
  onOpen3DViewer,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  const currentSlide = SLIDES[currentIndex];

  const handleNext = React.useCallback(() => {
    if (isAnimating) return;
    setIsAnimating(true);
    setCurrentIndex((prev) => (prev + 1) % SLIDES.length);
    setTimeout(() => setIsAnimating(false), 500);
  }, [isAnimating]);

  const handlePrev = React.useCallback(() => {
    if (isAnimating) return;
    setIsAnimating(true);
    setCurrentIndex((prev) => (prev - 1 + SLIDES.length) % SLIDES.length);
    setTimeout(() => setIsAnimating(false), 500);
  }, [isAnimating]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') handleNext();
      if (e.key === 'ArrowLeft') handlePrev();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleNext, handlePrev]);

  return (
    <section className="relative w-full h-[620px] lg:h-[700px] xl:h-[740px] pt-20 overflow-hidden bg-[#0c0c0e] select-none">
      {/* Background Image with Cinematic Transition */}
      <div className="absolute inset-0 top-0 left-0 w-full h-full z-0">
        <Image
          src={currentSlide.image}
          alt={currentSlide.alt}
          fill
          priority
          sizes="100vw"
          className={`object-cover object-center transition-all duration-700 transform ${
            isAnimating ? 'scale-105 opacity-80' : 'scale-100 opacity-100'
          }`}
          referrerPolicy="no-referrer"
        />
        {/* Measured dark scrim for typography legibility */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/60 to-black/30 pointer-events-none" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0c] via-transparent to-black/40 pointer-events-none" />
      </div>

      {/* Main Content Layout */}
      <div className="relative z-10 max-w-[1440px] mx-auto h-full px-6 flex flex-col justify-center">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Text Block */}
          <div className="lg:col-span-6 xl:col-span-5 max-w-xl">
            {/* Kicker */}
            <div className="inline-flex items-center gap-2 mb-4">
              <span className="text-xs uppercase tracking-[0.25em] text-zinc-300 font-medium font-sans">
                {currentSlide.kicker}
              </span>
            </div>

            {/* Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-display font-medium text-white leading-[1.08] tracking-tight mb-6">
              <span className="block">{currentSlide.titleLine1}</span>
              <span className="block text-zinc-100">{currentSlide.titleLine2}</span>
            </h1>

            {/* Description */}
            <p className="text-base sm:text-lg text-zinc-300 font-normal leading-relaxed mb-8 max-w-md">
              {currentSlide.description}
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-4">
              <button
                onClick={() => onAction(currentSlide.actionType)}
                className="cursor-pointer group inline-flex items-center gap-2 px-7 py-3 rounded-full bg-[#FFBC0D] text-black font-semibold text-sm hover:bg-[#F5AB00] transition-all duration-200 shadow-[0_4px_20px_rgba(255,188,13,0.3)] hover:shadow-[0_6px_25px_rgba(255,188,13,0.45)] hover:scale-[1.02] active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
              >
                <span>{currentSlide.ctaText}</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>

              {/* 3D WebGL Explorer Trigger */}
              <button
                onClick={onOpen3DViewer}
                className="cursor-pointer group inline-flex items-center gap-2 px-5 py-3 rounded-full bg-white/10 hover:bg-white/20 border border-white/15 text-white font-medium text-sm transition-all duration-200 backdrop-blur-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#FFBC0D]"
              >
                <Box className="w-4 h-4 text-[#FFBC0D] transition-transform group-hover:rotate-12" />
                <span>Inspect in 3D</span>
              </button>
            </div>
          </div>

          {/* Right side spacer for desktop layout balance */}
          <div className="hidden lg:block lg:col-span-5 xl:col-span-6" />

          {/* Far Right Brand Slogan (Matching Screenshot) */}
          <div className="hidden xl:flex lg:col-span-1 flex-col items-center justify-center text-center absolute right-8 top-1/2 -translate-y-1/2">
            <div className="flex flex-col items-center gap-2 tracking-[0.3em] text-[10px] uppercase font-semibold text-zinc-300 py-4">
              <span>B E T T E R</span>
              <span>F O O D</span>
              <span>B R I G H T E R</span>
              <span>F U T U R E S</span>
            </div>
            <div className="w-[1px] h-10 bg-white/20 my-2" />
            <div className="mt-1">
              <GoldenArchLogo size={24} className="opacity-90" />
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Right Carousel Controls (Matching Screenshot 01 / 04 with arrows) */}
      <div className="absolute bottom-8 right-6 lg:right-16 z-20 flex items-center gap-6">
        {/* Index counter & progress indicator */}
        <div className="flex flex-col items-start gap-1">
          <div className="text-xs font-mono tracking-wider text-zinc-300">
            <span className="text-white font-bold">
              {String(currentIndex + 1).padStart(2, '0')}
            </span>
            <span className="text-zinc-500"> / </span>
            <span className="text-zinc-400">
              {String(SLIDES.length).padStart(2, '0')}
            </span>
          </div>
          <div className="w-14 h-[2px] bg-white/20 rounded-full overflow-hidden">
            <div
              className="h-full bg-[#FFBC0D] transition-all duration-300"
              style={{
                width: `${((currentIndex + 1) / SLIDES.length) * 100}%`,
              }}
            />
          </div>
        </div>

        {/* Navigation Arrows */}
        <div className="flex items-center gap-2">
          <button
            onClick={handlePrev}
            className="p-2 text-zinc-400 hover:text-white hover:bg-white/10 rounded-full transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#FFBC0D]"
            aria-label="Previous story slide"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={handleNext}
            className="p-2 text-zinc-400 hover:text-white hover:bg-white/10 rounded-full transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#FFBC0D]"
            aria-label="Next story slide"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </section>
  );
};
