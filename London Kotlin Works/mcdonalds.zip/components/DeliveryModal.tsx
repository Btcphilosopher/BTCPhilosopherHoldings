'use client';

import React, { useState } from 'react';
import { X, Bike, Clock, ShieldCheck, MapPin, ArrowRight } from 'lucide-react';

interface DeliveryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartDeliveryOrder: (address: string) => void;
}

export const DeliveryModal: React.FC<DeliveryModalProps> = ({
  isOpen,
  onClose,
  onStartDeliveryOrder,
}) => {
  const [address, setAddress] = useState('10 Downing Street, London SW1A 2AA');
  const [deliveryNote, setDeliveryNote] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!address.trim()) return;
    onStartDeliveryOrder(address);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xl flex items-center justify-center p-3 sm:p-6 select-none animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#0f0f13] border border-white/10 rounded-2xl flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="p-6 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-full bg-[#FFBC0D]/10 text-[#FFBC0D]">
              <Bike className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs uppercase tracking-widest text-[#FFBC0D] font-bold">
                Direct McDelivery®
              </span>
              <h2 className="text-xl font-display font-medium text-white">
                Your favourites. Delivered.
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div className="space-y-1.5">
            <label className="text-xs font-mono uppercase tracking-wider text-zinc-400 block">
              Enter Delivery Address or Postcode:
            </label>
            <div className="relative">
              <MapPin className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#FFBC0D]" />
              <input
                type="text"
                required
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="e.g. Flat 4, 25 High Street, London..."
                className="w-full pl-10 pr-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white text-sm focus:outline-none focus:border-[#FFBC0D]"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-mono uppercase tracking-wider text-zinc-400 block">
              Delivery Instructions (Optional):
            </label>
            <input
              type="text"
              value={deliveryNote}
              onChange={(e) => setDeliveryNote(e.target.value)}
              placeholder="e.g. Leave at front concierge, ring bell 4B..."
              className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-white text-xs focus:outline-none focus:border-[#FFBC0D]"
            />
          </div>

          {/* Guaranteed Hot & Fresh Trust Banner */}
          <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="flex items-center gap-1.5 text-zinc-300">
                <Clock className="w-3.5 h-3.5 text-[#FFBC0D]" />
                <span>Estimated Arrival</span>
              </span>
              <span className="font-mono font-bold text-[#FFBC0D]">18 – 25 mins</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="flex items-center gap-1.5 text-zinc-300">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Tamper-evident heat sealed</span>
              </span>
              <span className="text-emerald-400 font-semibold">Freshness Guaranteed</span>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-full bg-[#FFBC0D] text-black font-bold text-xs uppercase tracking-wider hover:bg-[#F5AB00] transition-colors shadow-lg cursor-pointer flex items-center justify-center gap-2 active:scale-95"
          >
            <span>Proceed to McDelivery Order</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
