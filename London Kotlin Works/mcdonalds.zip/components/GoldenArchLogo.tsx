import React from 'react';

interface GoldenArchLogoProps {
  className?: string;
  size?: number;
}

export const GoldenArchLogo: React.FC<GoldenArchLogoProps> = ({
  className = 'h-10 w-auto',
  size = 40,
}) => {
  return (
    <svg
      width={size * 1.15}
      height={size}
      viewBox="0 0 115 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="McDonald's Golden Arches"
    >
      <defs>
        <linearGradient id="mcdGoldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FFC72C" />
          <stop offset="50%" stopColor="#FFBC0D" />
          <stop offset="100%" stopColor="#E5A700" />
        </linearGradient>
        <filter id="goldGlow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="3" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
      </defs>
      <path
        d="M26.8 98.5H5.2C10.5 75.8 20.4 46.2 31.9 25.1C41.2 8.1 52.8 0 63.8 0C73.9 0 81.3 6.9 84.7 18.5C89.5 7 98.4 0 108.6 0C117.9 0 126.9 7.7 134.4 23.3C144.3 43.8 152.4 72.8 157.2 98.5H135.6C131.6 77.2 124.6 51.5 116.8 35.8C112.5 27.2 107.5 22.8 102.3 22.8C94.4 22.8 87.2 31.7 82.5 48.6C77.4 67.2 73.6 88.5 72.5 98.5H51.4C50.2 86.8 46.1 63.7 40.7 44.5C36.4 29.5 29.8 22.8 22.4 22.8C17.3 22.8 12.3 27.2 8.1 35.8C0.3 51.5 -6.7 77.2 -10.7 98.5H-32.3C-27.5 72.8 -19.4 43.8 -9.5 23.3C-2 7.7 7 0 16.3 0C26.5 0 35.4 7 40.2 18.5C43.6 6.9 51 0 61.1 0"
        transform="scale(0.58) translate(35, 8)"
        fill="url(#mcdGoldGrad)"
      />
    </svg>
  );
};
