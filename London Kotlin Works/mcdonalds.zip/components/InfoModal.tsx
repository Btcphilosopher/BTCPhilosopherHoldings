'use client';

import React from 'react';
import { X, CheckCircle2, Shield, Leaf, HeartHandshake, Briefcase } from 'lucide-react';
import { GoldenArchLogo } from './GoldenArchLogo';

interface InfoModalProps {
  type: 'careers' | 'sustainability' | 'accessibility' | 'terms' | null;
  onClose: () => void;
}

export const InfoModal: React.FC<InfoModalProps> = ({ type, onClose }) => {
  if (!type) return null;

  const contentMap = {
    careers: {
      title: "Careers at McDonald's",
      subtitle: 'Grow, Lead, and Belong in Our Global Family',
      icon: <Briefcase className="w-5 h-5 text-[#FFBC0D]" />,
      body: (
        <div className="space-y-4 text-xs text-zinc-300 leading-relaxed">
          <p>
            Whether you’re embarking on your first job, transitioning into restaurant management, or building corporate innovation solutions, McDonald’s invests in your growth through accredited culinary diplomas and funded university degrees.
          </p>
          <div className="grid grid-cols-2 gap-3 pt-2">
            <div className="p-3 rounded-xl bg-white/5 border border-white/10">
              <span className="font-bold text-white block mb-1">Crew Member Programs</span>
              <span className="text-zinc-400">Flexible hours, certified training, and career progression paths.</span>
            </div>
            <div className="p-3 rounded-xl bg-white/5 border border-white/10">
              <span className="font-bold text-white block mb-1">Degree Apprenticeships</span>
              <span className="text-zinc-400">Earn while you learn with 100% funded business management degrees.</span>
            </div>
          </div>
        </div>
      ),
    },
    sustainability: {
      title: 'Plan for Change',
      subtitle: 'Our Journey to Net Zero and Regenerative Agriculture',
      icon: <Leaf className="w-5 h-5 text-emerald-400" />,
      body: (
        <div className="space-y-4 text-xs text-zinc-300 leading-relaxed">
          <p>
            We are committed to reaching net zero greenhouse gas emissions across our UK and European operations by 2040. We champion regenerative agriculture, powering our entire restaurant fleet with 100% renewable electricity.
          </p>
          <div className="space-y-2 pt-2">
            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-800/60 text-emerald-200">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>100% of beef sourced from Red Tractor assured British & Irish farms.</span>
            </div>
            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-800/60 text-emerald-200">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>Used cooking oil converted into 100% biodiesel to power our delivery fleet.</span>
            </div>
            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-800/60 text-emerald-200">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>100% renewable electricity for all company restaurants.</span>
            </div>
          </div>
        </div>
      ),
    },
    accessibility: {
      title: 'Digital & Physical Accessibility',
      subtitle: 'An Inclusive Experience Designed for Everyone',
      icon: <HeartHandshake className="w-5 h-5 text-[#FFBC0D]" />,
      body: (
        <div className="space-y-4 text-xs text-zinc-300 leading-relaxed">
          <p>
            We adhere strictly to WCAG 2.1 AA standards across our digital kiosk software and web interfaces. Our restaurants feature step-free access, high-contrast digital order displays, tactile indicators, and hearing loop installations.
          </p>
          <div className="p-3 rounded-xl bg-white/5 border border-white/10">
            <span className="font-bold text-white block mb-1">Accessibility Support</span>
            <span className="text-zinc-400">
              Assistance is available at all order touchpoints. Table service is standard across our flagship locations for guests who need seated ordering.
            </span>
          </div>
        </div>
      ),
    },
    terms: {
      title: 'Terms of Service & Privacy',
      subtitle: 'Commitment to User Transparency and Security',
      icon: <Shield className="w-5 h-5 text-blue-400" />,
      body: (
        <div className="space-y-4 text-xs text-zinc-300 leading-relaxed">
          <p>
            McDonald&apos;s respects customer privacy. We encrypt transactional data and never sell personal identifiable information to third parties.
          </p>
          <p className="text-zinc-400">
            MyMcDonald&apos;s Rewards terms apply. Points expire after 12 months of inactivity. Participation subject to local restaurant terms.
          </p>
        </div>
      ),
    },
  };

  const current = contentMap[type];

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xl flex items-center justify-center p-4 select-none animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#0f0f13] border border-white/10 rounded-2xl flex flex-col overflow-hidden shadow-2xl">
        <div className="p-6 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {current.icon}
            <div>
              <span className="text-[10px] uppercase font-mono tracking-wider text-zinc-400">
                McDonald’s Official
              </span>
              <h3 className="text-lg font-bold text-white">{current.title}</h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">{current.body}</div>

        <div className="p-4 border-t border-white/10 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-full bg-[#FFBC0D] text-black text-xs font-bold hover:bg-[#F5AB00] transition-colors cursor-pointer"
          >
            Understood
          </button>
        </div>
      </div>
    </div>
  );
};
