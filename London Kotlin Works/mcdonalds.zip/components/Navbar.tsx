'use client';

import React from 'react';
import { Search, User, ShoppingBag, Sparkles, Gamepad2 } from 'lucide-react';
import { GoldenArchLogo } from './GoldenArchLogo';

interface NavbarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  onOpenOrder: () => void;
  onOpenSearch: () => void;
  onOpenProfile: () => void;
  onOpenCart: () => void;
  onTogglePixelMode: () => void;
  isPixelMode: boolean;
  cartItemCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onTabChange,
  onOpenOrder,
  onOpenSearch,
  onOpenProfile,
  onOpenCart,
  onTogglePixelMode,
  isPixelMode,
  cartItemCount,
}) => {
  const navItems = [
    { id: 'food', label: 'Food' },
    { id: 'restaurants', label: 'Restaurants' },
    { id: 'mcdelivery', label: 'McDelivery' },
    { id: 'rewards', label: 'Rewards' },
    { id: 'story', label: 'Our Story' },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-40 bg-[#0a0a0c]/85 backdrop-blur-md border-b border-white/5 transition-all">
      <div className="max-w-[1440px] mx-auto px-6 h-20 flex items-center justify-between">
        {/* Zone 1: Brand Wordmark / Golden Arches */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => onTabChange('food')}
            className="flex items-center gap-2 group cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#FFBC0D] rounded-lg p-1"
            aria-label="McDonald's Home"
          >
            <GoldenArchLogo size={42} className="transition-transform group-hover:scale-105" />
          </button>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-8 text-[15px] font-medium tracking-normal" aria-label="Main Navigation">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={`relative py-2 transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#FFBC0D] rounded px-1 ${
                  isActive
                    ? 'text-white font-semibold'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#FFBC0D] rounded-full shadow-[0_0_8px_rgba(255,188,13,0.6)]" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Actions (Search, Profile, Retro Pixel Toggle, Cart, Order Now) */}
        <div className="flex items-center gap-3">
          {/* Retro Pixel Art Mode Toggle */}
          <button
            onClick={onTogglePixelMode}
            className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded-full border transition-all cursor-pointer ${
              isPixelMode
                ? 'bg-[#FFBC0D] text-black border-[#FFBC0D] font-bold shadow-[0_0_12px_rgba(255,188,13,0.5)]'
                : 'bg-white/5 text-zinc-300 border-white/10 hover:border-white/20 hover:text-white'
            }`}
            title="Toggle HTML Pixel Art Nostalgia Mode"
            aria-label="Toggle Retro Pixel Mode"
          >
            <Gamepad2 className="w-3.5 h-3.5" />
            <span className="whitespace-nowrap">{isPixelMode ? 'Retro: ON' : 'Pixel Art'}</span>
          </button>

          {/* Search Button */}
          <button
            onClick={onOpenSearch}
            className="p-2 text-zinc-400 hover:text-white transition-colors cursor-pointer rounded-full hover:bg-white/5 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#FFBC0D]"
            aria-label="Search menu items and restaurants"
          >
            <Search className="w-5 h-5" />
          </button>

          {/* Profile / Rewards Button */}
          <button
            onClick={onOpenProfile}
            className="p-2 text-zinc-400 hover:text-white transition-colors cursor-pointer rounded-full hover:bg-white/5 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#FFBC0D]"
            aria-label="My McDonald's Rewards Account"
          >
            <User className="w-5 h-5" />
          </button>

          {/* Cart / Bag Button */}
          <button
            onClick={onOpenCart}
            className="relative p-2 text-zinc-400 hover:text-white transition-colors cursor-pointer rounded-full hover:bg-white/5 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#FFBC0D]"
            aria-label="View Shopping Bag"
          >
            <ShoppingBag className="w-5 h-5" />
            {cartItemCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#FFBC0D] text-black text-[11px] font-bold w-4 h-4 rounded-full flex items-center justify-center shadow-md">
                {cartItemCount}
              </span>
            )}
          </button>

          {/* Primary Action Button: Order Now */}
          <button
            onClick={onOpenOrder}
            className="cursor-pointer ml-1 px-5 py-2 text-sm font-medium tracking-wide text-white border border-white/30 rounded-full hover:border-[#FFBC0D] hover:text-[#FFBC0D] transition-all duration-200 hover:shadow-[0_0_15px_rgba(255,188,13,0.15)] whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#FFBC0D]"
          >
            Order Now
          </button>
        </div>
      </div>
    </header>
  );
};
