'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';

interface FeatureCardProps {
  tag: string;
  title: string;
  ctaText: string;
  imageSrc: string;
  alt: string;
  onClick: () => void;
}

const FeatureCard: React.FC<FeatureCardProps> = ({
  tag,
  title,
  ctaText,
  imageSrc,
  alt,
  onClick,
}) => {
  return (
    <div
      onClick={onClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onClick();
        }
      }}
      className="group relative h-[320px] sm:h-[340px] rounded-xl overflow-hidden cursor-pointer border border-white/10 hover:border-white/25 transition-all duration-300 transform hover:-translate-y-1 hover:shadow-[0_12px_30px_rgba(0,0,0,0.5)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#FFBC0D]"
    >
      {/* Background Image */}
      <Image
        src={imageSrc}
        alt={alt}
        fill
        sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 25vw"
        className="object-cover object-center transition-transform duration-700 ease-out group-hover:scale-105"
        referrerPolicy="no-referrer"
      />

      {/* Dark gradient overlay for text readability */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />

      {/* Content overlay */}
      <div className="absolute inset-0 p-6 flex flex-col justify-end">
        {/* Kicker tag */}
        <span className="text-[11px] uppercase tracking-[0.2em] font-medium text-zinc-400 mb-1 block">
          {tag}
        </span>

        {/* Card Title */}
        <h3 className="text-xl sm:text-2xl font-display font-medium text-white mb-4 leading-snug group-hover:text-zinc-100 transition-colors">
          {title}
        </h3>

        {/* Call to action text link with arrow */}
        <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-zinc-200 group-hover:text-[#FFBC0D] transition-colors">
          <span>{ctaText}</span>
          <ArrowRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-1" />
        </div>
      </div>
    </div>
  );
};

interface FeatureGridProps {
  onOpenMenu: () => void;
  onOpenMcCafe: () => void;
  onOpenDelivery: () => void;
  onOpenRestaurants: () => void;
}

export const FeatureGrid: React.FC<FeatureGridProps> = ({
  onOpenMenu,
  onOpenMcCafe,
  onOpenDelivery,
  onOpenRestaurants,
}) => {
  return (
    <section className="w-full bg-[#0a0a0c] py-12 px-6">
      <div className="max-w-[1440px] mx-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <FeatureCard
            tag="OUR MENU"
            title="Burgers, fries, & more"
            ctaText="Explore Menu"
            imageSrc="/images/card_double_cheeseburger.jpg"
            alt="Macro shot of delicious double cheeseburger with sesame seed bun"
            onClick={onOpenMenu}
          />

          <FeatureCard
            tag="MCCAFÉ"
            title="Great coffee. Anytime."
            ctaText="Explore McCafé"
            imageSrc="/images/card_mccafe_latte.jpg"
            alt="McCafé latte cup with beautiful heart shaped latte art"
            onClick={onOpenMcCafe}
          />

          <FeatureCard
            tag="MCDELIVERY"
            title="Your favourites. Delivered."
            ctaText="Order Now"
            imageSrc="/images/card_mcdelivery.jpg"
            alt="McDelivery kraft bag on table overlooking city waterfront at dusk"
            onClick={onOpenDelivery}
          />

          <FeatureCard
            tag="OUR RESTAURANTS"
            title="Modern spaces. Real connection."
            ctaText="Find a Restaurant"
            imageSrc="/images/card_modern_restaurant.jpg"
            alt="Architectural modern dining interior of McDonald’s with city views"
            onClick={onOpenRestaurants}
          />
        </div>
      </div>
    </section>
  );
};
