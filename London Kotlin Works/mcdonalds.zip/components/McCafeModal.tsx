'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { X, Coffee, Check, Plus, Award, ShieldCheck } from 'lucide-react';
import { MenuItem } from '../data/menuData';

interface McCafeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (item: any) => void;
}

const COFFEE_DRINKS = [
  {
    id: 'latte',
    name: 'McCafé® Velvet Latte',
    price: 2.89,
    calories: 145,
    description: 'Freshly ground 100% Arabica espresso paired with velvety steamed organic milk.',
  },
  {
    id: 'flat-white',
    name: 'McCafé® Artisan Flat White',
    price: 3.19,
    calories: 120,
    description: 'Expertly pulled double ristretto espresso with rich textured microfoam.',
  },
  {
    id: 'cappuccino',
    name: 'McCafé® Frosted Cappuccino',
    price: 2.89,
    calories: 130,
    description: 'Dark roasted Arabica espresso under a pillowy dome of frothed milk and cocoa dust.',
  },
  {
    id: 'iced-latte',
    name: 'McCafé® Iced Salted Caramel Frappé',
    price: 3.49,
    calories: 290,
    description: 'Cold blended coffee over crushed ice, finished with cream swirl and caramel drip.',
  },
];

export const McCafeModal: React.FC<McCafeModalProps> = ({
  isOpen,
  onClose,
  onAddToCart,
}) => {
  const [selectedDrink, setSelectedDrink] = useState(COFFEE_DRINKS[0]);
  const [selectedMilk, setSelectedMilk] = useState('Semi-Skimmed Organic Dairy');
  const [extraShot, setExtraShot] = useState(false);
  const [syrup, setSyrup] = useState('None');
  const [addedToast, setAddedToast] = useState(false);

  if (!isOpen) return null;

  const calculatedPrice = selectedDrink.price + (extraShot ? 0.60 : 0) + (syrup !== 'None' ? 0.40 : 0);

  const handleAdd = () => {
    onAddToCart({
      id: `${selectedDrink.id}-${Date.now()}`,
      name: `${selectedDrink.name} (${selectedMilk})`,
      price: calculatedPrice,
      calories: selectedDrink.calories + (extraShot ? 5 : 0) + (syrup !== 'None' ? 45 : 0),
      image: '/images/card_mccafe_latte.jpg',
      category: 'mccafe',
    });
    setAddedToast(true);
    setTimeout(() => {
      setAddedToast(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xl flex items-center justify-center p-3 sm:p-6 select-none animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl h-[88vh] bg-[#0f0f13] border border-white/10 rounded-2xl flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="p-6 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Coffee className="w-6 h-6 text-[#FFBC0D]" />
            <div>
              <span className="text-xs uppercase tracking-widest text-[#FFBC0D] font-bold">
                Artisanal Barista Roastery
              </span>
              <h2 className="text-2xl font-display font-medium text-white">
                McCafé® Great Coffee. Anytime.
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 md:grid-cols-12">
          {/* Left Column: Story & Drink Selection */}
          <div className="md:col-span-7 p-6 border-b md:border-b-0 md:border-r border-white/10 space-y-6">
            {/* Story Card */}
            <div className="p-4 rounded-xl bg-gradient-to-br from-[#1a1410] to-[#121217] border border-[#FFBC0D]/20">
              <div className="flex items-center gap-2 text-xs text-[#FFBC0D] font-semibold mb-1">
                <ShieldCheck className="w-4 h-4" />
                <span>100% Rainforest Alliance Certified</span>
              </div>
              <p className="text-xs text-zinc-300 leading-relaxed">
                Every bean in your McCafé cup is ethically harvested from certified sustainable coffee farms in South and Central America, roasted in small batches to preserve its natural chocolatey and nutty flavor notes.
              </p>
            </div>

            {/* Drink Selection */}
            <div>
              <h3 className="text-xs uppercase font-mono tracking-wider text-zinc-400 mb-3">
                Choose Coffee Creation:
              </h3>
              <div className="space-y-2.5">
                {COFFEE_DRINKS.map((drink) => {
                  const isSelected = selectedDrink.id === drink.id;
                  return (
                    <div
                      key={drink.id}
                      onClick={() => setSelectedDrink(drink)}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                        isSelected
                          ? 'bg-[#FFBC0D]/10 border-[#FFBC0D] text-white shadow-md'
                          : 'bg-[#15151c] border-white/5 text-zinc-300 hover:border-white/15'
                      }`}
                    >
                      <div>
                        <h4 className="text-sm font-bold">{drink.name}</h4>
                        <p className="text-xs text-zinc-400 line-clamp-1">{drink.description}</p>
                      </div>
                      <span className="font-mono text-xs font-semibold text-[#FFBC0D] shrink-0 ml-3">
                        £{drink.price.toFixed(2)}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right Column: Customization & Add */}
          <div className="md:col-span-5 p-6 flex flex-col justify-between space-y-6 bg-[#121218]">
            <div className="space-y-5">
              {/* Milk Option */}
              <div>
                <label className="text-xs font-mono uppercase tracking-wider text-zinc-400 block mb-2">
                  Select Milk Choice:
                </label>
                <div className="grid grid-cols-1 gap-2">
                  {[
                    'Semi-Skimmed Organic Dairy',
                    'Whole British Dairy',
                    'Barista Oat Milk (Plant-based)',
                    'Soya Milk (Plant-based)',
                  ].map((milk) => (
                    <button
                      key={milk}
                      onClick={() => setSelectedMilk(milk)}
                      className={`p-2.5 rounded-lg border text-left text-xs transition-colors cursor-pointer flex items-center justify-between ${
                        selectedMilk === milk
                          ? 'bg-[#FFBC0D] text-black font-bold border-[#FFBC0D]'
                          : 'bg-white/5 border-white/10 text-zinc-300 hover:bg-white/10'
                      }`}
                    >
                      <span>{milk}</span>
                      {selectedMilk === milk && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Extra Shot & Syrup */}
              <div>
                <label className="text-xs font-mono uppercase tracking-wider text-zinc-400 block mb-2">
                  Barista Extras:
                </label>
                <div className="space-y-2">
                  <button
                    onClick={() => setExtraShot(!extraShot)}
                    className={`w-full p-2.5 rounded-lg border text-left text-xs transition-colors cursor-pointer flex items-center justify-between ${
                      extraShot
                        ? 'bg-[#FFBC0D]/15 border-[#FFBC0D] text-white'
                        : 'bg-white/5 border-white/10 text-zinc-400'
                    }`}
                  >
                    <span>Extra Shot of Espresso (+£0.60)</span>
                    <div
                      className={`w-4 h-4 rounded flex items-center justify-center border ${
                        extraShot ? 'bg-[#FFBC0D] border-[#FFBC0D] text-black' : 'border-zinc-600'
                      }`}
                    >
                      {extraShot && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                  </button>

                  <div className="flex items-center gap-2 pt-1">
                    <span className="text-xs text-zinc-400 shrink-0">Flavour Syrup:</span>
                    <select
                      value={syrup}
                      onChange={(e) => setSyrup(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-lg py-1.5 px-2 text-xs text-white focus:outline-none focus:border-[#FFBC0D]"
                    >
                      <option value="None" className="bg-[#121218]">None</option>
                      <option value="Vanilla (+£0.40)" className="bg-[#121218]">Caramel (+£0.40)</option>
                      <option value="Hazelnut (+£0.40)" className="bg-[#121218]">Hazelnut (+£0.40)</option>
                      <option value="Vanilla (+£0.40)" className="bg-[#121218]">Vanilla (+£0.40)</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* Total & Action */}
            <div className="pt-4 border-t border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs text-zinc-400 block">Total</span>
                  <span className="font-mono text-xl font-bold text-[#FFBC0D]">
                    £{calculatedPrice.toFixed(2)}
                  </span>
                </div>
                <span className="text-[11px] font-mono text-zinc-400">
                  {selectedDrink.calories + (extraShot ? 5 : 0) + (syrup !== 'None' ? 45 : 0)} kcal
                </span>
              </div>

              <button
                onClick={handleAdd}
                className="w-full py-3 rounded-full bg-[#FFBC0D] text-black font-bold text-xs uppercase tracking-wider hover:bg-[#F5AB00] transition-colors shadow-lg cursor-pointer flex items-center justify-center gap-2 active:scale-95"
              >
                {addedToast ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Added to Bag!</span>
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4" />
                    <span>Add Coffee to Bag</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
