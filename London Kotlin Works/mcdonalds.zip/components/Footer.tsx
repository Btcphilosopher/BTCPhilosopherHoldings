'use client';

import React from 'react';
import { Instagram, Youtube, Linkedin } from 'lucide-react';
import { GoldenArchLogo } from './GoldenArchLogo';

interface FooterProps {
  onOpenSustainability?: () => void;
  onOpenCareers?: () => void;
  onOpenAccessibility?: () => void;
  onOpenTerms?: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onOpenSustainability,
  onOpenCareers,
  onOpenAccessibility,
  onOpenTerms,
}) => {
  return (
    <footer className="w-full bg-[#08080a] border-t border-white/5 py-8 px-6 text-xs text-zinc-400 select-none">
      <div className="max-w-[1440px] mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        {/* Left: Golden Arch Logo & Tagline */}
        <div className="flex items-center gap-3">
          <GoldenArchLogo size={28} className="opacity-95" />
          <span className="text-white font-medium text-sm tracking-tight">
            Good Food. A Brighter Future.
          </span>
        </div>

        {/* Center Links (Careers, Sustainability, Accessibility, Terms & Privacy) */}
        <div className="flex flex-wrap items-center justify-center gap-6 sm:gap-8 font-normal">
          <button
            onClick={onOpenCareers}
            className="hover:text-white transition-colors cursor-pointer"
          >
            Careers
          </button>
          <button
            onClick={onOpenSustainability}
            className="hover:text-white transition-colors cursor-pointer"
          >
            Sustainability
          </button>
          <button
            onClick={onOpenAccessibility}
            className="hover:text-white transition-colors cursor-pointer"
          >
            Accessibility
          </button>
          <button
            onClick={onOpenTerms}
            className="hover:text-white transition-colors cursor-pointer"
          >
            Terms & Privacy
          </button>
        </div>

        {/* Right Social Icons (Instagram, YouTube, X, LinkedIn) */}
        <div className="flex items-center gap-5 text-zinc-400">
          <a
            href="https://instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Instagram"
            className="hover:text-white transition-colors"
          >
            <Instagram className="w-4 h-4" />
          </a>
          <a
            href="https://youtube.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="YouTube"
            className="hover:text-white transition-colors"
          >
            <Youtube className="w-4 h-4" />
          </a>
          <a
            href="https://x.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="X (formerly Twitter)"
            className="hover:text-white transition-colors"
          >
            <svg
              className="w-3.5 h-3.5 fill-current"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
            </svg>
          </a>
          <a
            href="https://linkedin.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="LinkedIn"
            className="hover:text-white transition-colors"
          >
            <Linkedin className="w-4 h-4" />
          </a>
        </div>
      </div>
    </footer>
  );
};
