'use client';

import React, { useState, useMemo } from 'react';
import Image from 'next/image';
import { X, Plus, Check, SlidersHorizontal, Search, Flame, Leaf } from 'lucide-react';
import { MENU_ITEMS, MenuItem } from '../data/menuData';

interface MenuModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (item: MenuItem, customizations?: string[]) => void;
  onOpen3DViewer: () => void;
}

export const MenuModal: React.FC<MenuModalProps> = ({
  isOpen,
  onClose,
  onAddToCart,
  onOpen3DViewer,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [vegetarianOnly, setVegetarianOnly] = useState(false);
  const [under500Only, setUnder500Only] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [customizingItem, setCustomizingItem] = useState<MenuItem | null>(null);
  const [selectedCustomizations, setSelectedCustomizations] = useState<string[]>([]);
  const [addedItemToast, setAddedItemToast] = useState<string | null>(null);

  const categories = [
    { id: 'all', label: 'All Items' },
    { id: 'burgers', label: 'Burgers' },
    { id: 'chicken', label: 'Chicken' },
    { id: 'sides', label: 'Fries & Sides' },
    { id: 'mccafe', label: 'McCafé' },
    { id: 'desserts', label: 'Desserts' },
    { id: 'breakfast', label: 'Breakfast' },
  ];

  const filteredItems = useMemo(() => {
    return MENU_ITEMS.filter((item) => {
      if (selectedCategory !== 'all' && item.category !== selectedCategory) return false;
      if (vegetarianOnly && !item.isVegetarian) return false;
      if (under500Only && item.calories > 500) return false;
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        return (
          item.name.toLowerCase().includes(query) ||
          item.description.toLowerCase().includes(query)
        );
      }
      return true;
    });
  }, [selectedCategory, vegetarianOnly, under500Only, searchQuery]);

  const handleQuickAdd = (item: MenuItem) => {
    onAddToCart(item);
    setAddedItemToast(`${item.name} added to bag`);
    setTimeout(() => setAddedItemToast(null), 2500);
  };

  const handleOpenCustomize = (item: MenuItem) => {
    setCustomizingItem(item);
    setSelectedCustomizations([...item.ingredients]);
  };

  const toggleIngredient = (ing: string) => {
    if (selectedCustomizations.includes(ing)) {
      setSelectedCustomizations(selectedCustomizations.filter((i) => i !== ing));
    } else {
      setSelectedCustomizations([...selectedCustomizations, ing]);
    }
  };

  const handleConfirmCustomization = () => {
    if (!customizingItem) return;
    onAddToCart(customizingItem, selectedCustomizations);
    setAddedItemToast(`${customizingItem.name} (Customized) added to bag`);
    setCustomizingItem(null);
    setTimeout(() => setAddedItemToast(null), 2500);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xl flex items-center justify-center p-2 sm:p-4 md:p-6 select-none animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl h-[92vh] bg-[#0f0f13] border border-white/10 rounded-2xl flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="p-6 border-b border-white/10 flex items-center justify-between">
          <div>
            <span className="text-xs uppercase tracking-widest text-[#FFBC0D] font-bold">
              McDonald&apos;s Flagship Menu
            </span>
            <h2 className="text-2xl font-display font-medium text-white">
              Food & Drinks
            </h2>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onOpen3DViewer}
              className="cursor-pointer hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-[#FFBC0D] transition-colors"
            >
              <span>3D Ingredient Model</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter and Search Bar */}
        <div className="p-4 sm:px-6 bg-[#131318] border-b border-white/5 flex flex-wrap items-center justify-between gap-4">
          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-full transition-all cursor-pointer whitespace-nowrap ${
                  selectedCategory === cat.id
                    ? 'bg-[#FFBC0D] text-black font-semibold shadow-sm'
                    : 'bg-white/5 text-zinc-300 hover:bg-white/10 hover:text-white'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Quick Dietary Filters & Search */}
          <div className="flex items-center gap-3 flex-wrap">
            {/* Vegetarian Toggle */}
            <button
              onClick={() => setVegetarianOnly(!vegetarianOnly)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs transition-colors cursor-pointer border ${
                vegetarianOnly
                  ? 'bg-emerald-950/60 border-emerald-500 text-emerald-300 font-semibold'
                  : 'bg-white/5 border-white/10 text-zinc-400 hover:text-white'
              }`}
            >
              <Leaf className="w-3.5 h-3.5" />
              <span>Plant / Vegetarian</span>
            </button>

            {/* Under 500 kcal Toggle */}
            <button
              onClick={() => setUnder500Only(!under500Only)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs transition-colors cursor-pointer border ${
                under500Only
                  ? 'bg-amber-950/60 border-amber-500 text-amber-300 font-semibold'
                  : 'bg-white/5 border-white/10 text-zinc-400 hover:text-white'
              }`}
            >
              <Flame className="w-3.5 h-3.5" />
              <span>&lt; 500 kcal</span>
            </button>

            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-400 pointer-events-none" />
              <input
                type="text"
                placeholder="Search food..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1 text-xs bg-white/5 border border-white/10 rounded-full text-white placeholder-zinc-500 focus:outline-none focus:border-[#FFBC0D]"
              />
            </div>
          </div>
        </div>

        {/* Menu Items Grid */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="group bg-[#15151b] border border-white/10 hover:border-white/20 rounded-xl overflow-hidden flex flex-col justify-between transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg"
            >
              {/* Image & Badge */}
              <div className="relative h-44 w-full bg-zinc-900 overflow-hidden">
                <Image
                  src={item.image}
                  alt={item.name}
                  fill
                  sizes="(max-width: 768px) 100vw, 33vw"
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#15151b] via-transparent to-black/30" />

                {item.badge && (
                  <span className="absolute top-3 left-3 bg-[#FFBC0D] text-black text-[10px] font-bold px-2 py-0.5 rounded shadow-md uppercase tracking-wider">
                    {item.badge}
                  </span>
                )}

                <div className="absolute bottom-2 right-3 text-[11px] font-mono text-zinc-300 bg-black/60 backdrop-blur-sm px-2 py-0.5 rounded">
                  {item.calories} kcal
                </div>
              </div>

              {/* Item Info */}
              <div className="p-4 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <h3 className="text-base font-bold text-white group-hover:text-[#FFBC0D] transition-colors">
                      {item.name}
                    </h3>
                    <span className="font-mono text-sm font-semibold text-[#FFBC0D] shrink-0">
                      £{item.price.toFixed(2)}
                    </span>
                  </div>

                  <p className="text-xs text-zinc-400 line-clamp-2 leading-relaxed mb-4">
                    {item.description}
                  </p>
                </div>

                {/* Bottom Actions: Customize & Add to Bag */}
                <div className="pt-3 border-t border-white/5 flex items-center justify-between gap-2">
                  <button
                    onClick={() => handleOpenCustomize(item)}
                    className="cursor-pointer text-[11px] text-zinc-400 hover:text-white transition-colors underline underline-offset-2 flex items-center gap-1"
                  >
                    <SlidersHorizontal className="w-3 h-3" />
                    <span>Customize</span>
                  </button>

                  <button
                    onClick={() => handleQuickAdd(item)}
                    className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#FFBC0D] text-black font-semibold text-xs hover:bg-[#F5AB00] transition-colors shadow-sm active:scale-95"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add to Bag</span>
                  </button>
                </div>
              </div>
            </div>
          ))}

          {filteredItems.length === 0 && (
            <div className="col-span-full py-16 text-center text-zinc-500">
              <p className="text-base mb-2">No menu items found matching your filters.</p>
              <button
                onClick={() => {
                  setSelectedCategory('all');
                  setVegetarianOnly(false);
                  setUnder500Only(false);
                  setSearchQuery('');
                }}
                className="text-xs text-[#FFBC0D] underline cursor-pointer"
              >
                Reset all filters
              </button>
            </div>
          )}
        </div>

        {/* Customization Drawer Modal */}
        {customizingItem && (
          <div className="absolute inset-0 bg-black/90 backdrop-blur-md flex flex-col justify-between p-6 z-30 animate-in fade-in">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <span className="text-xs uppercase tracking-wider text-[#FFBC0D] font-bold">
                  Ingredient Customizer
                </span>
                <h3 className="text-xl font-bold text-white">
                  Customize {customizingItem.name}
                </h3>
              </div>
              <button
                onClick={() => setCustomizingItem(null)}
                className="p-2 rounded-full bg-white/10 text-zinc-300 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-6">
              <p className="text-xs text-zinc-400 mb-4">
                Personalize your sandwich. Toggle ingredients to include or omit:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {customizingItem.ingredients.map((ing) => {
                  const isIncluded = selectedCustomizations.includes(ing);
                  return (
                    <button
                      key={ing}
                      onClick={() => toggleIngredient(ing)}
                      className={`p-3.5 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                        isIncluded
                          ? 'bg-[#FFBC0D]/10 border-[#FFBC0D] text-white'
                          : 'bg-white/5 border-white/10 text-zinc-500 line-through'
                      }`}
                    >
                      <span className="text-xs font-medium">{ing}</span>
                      <div
                        className={`w-5 h-5 rounded-full flex items-center justify-center border ${
                          isIncluded
                            ? 'bg-[#FFBC0D] border-[#FFBC0D] text-black'
                            : 'border-zinc-600'
                        }`}
                      >
                        {isIncluded && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="pt-4 border-t border-white/10 flex items-center justify-between">
              <span className="font-mono text-base font-bold text-[#FFBC0D]">
                £{customizingItem.price.toFixed(2)}
              </span>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setCustomizingItem(null)}
                  className="px-4 py-2 text-xs font-semibold text-zinc-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleConfirmCustomization}
                  className="px-6 py-2.5 rounded-full bg-[#FFBC0D] text-black text-xs font-bold hover:bg-[#F5AB00] transition-colors cursor-pointer"
                >
                  Save & Add to Bag
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Added Toast Notification */}
        {addedItemToast && (
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-40 bg-[#FFBC0D] text-black font-semibold text-xs px-4 py-2 rounded-full shadow-lg flex items-center gap-2 animate-bounce">
            <Check className="w-4 h-4" />
            <span>{addedItemToast}</span>
          </div>
        )}
      </div>
    </div>
  );
};
