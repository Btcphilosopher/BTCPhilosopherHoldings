'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { Search, X, ArrowRight } from 'lucide-react';
import { MENU_ITEMS, MenuItem } from '../data/menuData';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectItem: (item: MenuItem) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectItem,
}) => {
  const [query, setQuery] = useState('');

  // Handle ESC key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const results = query.trim()
    ? MENU_ITEMS.filter(
        (it) =>
          it.name.toLowerCase().includes(query.toLowerCase()) ||
          it.description.toLowerCase().includes(query.toLowerCase()) ||
          it.ingredients.some((ing) => ing.toLowerCase().includes(query.toLowerCase()))
      )
    : MENU_ITEMS.slice(0, 4);

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-start justify-center pt-24 px-4 select-none animate-in fade-in duration-150">
      <div className="w-full max-w-2xl bg-[#121218] border border-white/15 rounded-2xl overflow-hidden shadow-2xl">
        {/* Search Bar */}
        <div className="p-4 border-b border-white/10 flex items-center gap-3">
          <Search className="w-5 h-5 text-[#FFBC0D]" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search burgers, McCafé roasts, fries, ingredients..."
            className="w-full bg-transparent text-white text-base placeholder-zinc-500 focus:outline-none"
          />
          <button
            onClick={onClose}
            className="p-1 rounded-full text-zinc-400 hover:text-white hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results */}
        <div className="max-h-[60vh] overflow-y-auto p-4 space-y-2">
          <span className="text-[10px] font-mono uppercase tracking-wider text-zinc-400 block px-2 mb-2">
            {query.trim() ? `Search Results (${results.length})` : 'Popular Recommendations'}
          </span>

          {results.map((item) => (
            <div
              key={item.id}
              onClick={() => {
                onSelectItem(item);
                onClose();
              }}
              className="p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 hover:border-white/15 transition-all cursor-pointer flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-lg bg-zinc-800 relative overflow-hidden shrink-0">
                  <Image
                    src={item.image}
                    alt={item.name}
                    fill
                    className="object-cover"
                    sizes="48px"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white group-hover:text-[#FFBC0D] transition-colors">
                    {item.name}
                  </h4>
                  <div className="flex items-center gap-2 text-xs text-zinc-400 font-mono">
                    <span>£{item.price.toFixed(2)}</span>
                    <span>·</span>
                    <span>{item.calories} kcal</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 text-xs text-[#FFBC0D] font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                <span>View item</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          ))}

          {results.length === 0 && (
            <div className="text-center py-8 text-zinc-500 text-xs">
              No matching items found for &quot;{query}&quot;.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
