'use client';

import React, { useState } from 'react';
import { X, Volume2, VolumeX, Sparkles, Trophy } from 'lucide-react';

interface PixelArtModeProps {
  onClose: () => void;
  onAddToCart: (item: any) => void;
}

// Web Audio API 8-bit chiptune sound generator
const playRetroBeep = (freq = 440, type: OscillatorType = 'square', duration = 0.1) => {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);
    gain.gain.setValueAtTime(0.08, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + duration);
  } catch {
    // audio context muted or restricted by browser
  }
};

export const PixelArtMode: React.FC<PixelArtModeProps> = ({ onClose, onAddToCart }) => {
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [score, setScore] = useState(1974);
  const [activeItem, setActiveItem] = useState<'burger' | 'fries' | 'coffee'>('burger');

  const handleItemClick = (type: 'burger' | 'fries' | 'coffee') => {
    setActiveItem(type);
    if (soundEnabled) {
      playRetroBeep(523.25, 'square', 0.08); // C5
      setTimeout(() => playRetroBeep(659.25, 'square', 0.1), 80); // E5
    }
  };

  const handleCollectPoints = () => {
    setScore((prev) => prev + 100);
    if (soundEnabled) {
      playRetroBeep(587.33, 'square', 0.08); // D5
      setTimeout(() => playRetroBeep(880.0, 'square', 0.15), 90); // A5
    }
  };

  // Pure HTML/CSS pixel art Big Mac representation (16x16 grid)
  // 0: transparent, 1: bun gold (#d89b34), 2: sesame white (#ffffff), 3: lettuce green (#4da82e), 4: patty brown (#5c341b), 5: cheese yellow (#ffc412)
  const burgerPixels = [
    [0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
    [0, 0, 1, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 1, 0, 0],
    [0, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [0, 3, 3, 0, 3, 3, 0, 3, 3, 0, 3, 3, 0, 3, 3, 0],
    [3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3],
    [4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4],
    [5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5],
    [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 3, 0, 3, 3, 0, 3, 3, 0, 3, 3, 0, 3, 0, 3, 0],
    [4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4],
    [5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  ];

  const getColor = (val: number) => {
    switch (val) {
      case 1:
        return '#C88B35'; // toasted bun
      case 2:
        return '#FFFFFF'; // sesame
      case 3:
        return '#4E9E2C'; // lettuce
      case 4:
        return '#5A321A'; // beef
      case 5:
        return '#FFBC0D'; // cheese
      default:
        return 'transparent';
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#08080a]/95 backdrop-blur-md flex items-center justify-center p-4 select-none font-mono">
      <div className="relative w-full max-w-3xl bg-[#101018] border-4 border-[#FFBC0D] rounded-xl p-6 shadow-[0_0_40px_rgba(255,188,13,0.3)]">
        {/* Retro Header Bar */}
        <div className="flex items-center justify-between border-b-2 border-white/10 pb-4 mb-6">
          <div className="flex items-center gap-3">
            <span className="text-xl">🕹️</span>
            <div>
              <h2 className="text-sm font-bold tracking-widest text-[#FFBC0D] uppercase">
                RETRO 1974 PIXEL ARCADE
              </h2>
              <span className="text-[10px] text-zinc-400">Pure HTML & CSS Pixel Art Engine</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="p-1.5 rounded bg-white/5 text-zinc-300 hover:text-white border border-white/10"
              title="Toggle 8-bit sound"
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-[#FFBC0D]" /> : <VolumeX className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded bg-white/5 text-zinc-300 hover:text-white border border-white/10 hover:border-red-500"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Arcade Screen Body */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center bg-[#07070b] p-6 rounded-lg border-2 border-white/5">
          {/* Left: Pixel Art Canvas */}
          <div className="flex flex-col items-center justify-center">
            {/* HTML Pixel Art Grid Display */}
            <div className="p-4 bg-[#14141d] rounded-lg border-2 border-[#FFBC0D]/40 shadow-inner flex flex-col items-center">
              <div
                className="grid gap-[2px] p-2 bg-black/60 rounded"
                style={{
                  gridTemplateColumns: `repeat(16, minmax(0, 1fr))`,
                  width: '240px',
                  height: '240px',
                }}
              >
                {burgerPixels.flat().map((pixel, idx) => (
                  <div
                    key={idx}
                    className="w-full h-full rounded-[1px] transition-colors duration-150"
                    style={{ backgroundColor: getColor(pixel) }}
                  />
                ))}
              </div>

              <div className="mt-3 text-center">
                <span className="text-xs font-bold text-white tracking-widest block uppercase">
                  8-Bit Pixel Big Mac®
                </span>
                <span className="text-[10px] text-zinc-400">Rendered via Pure HTML & CSS Matrix</span>
              </div>
            </div>
          </div>

          {/* Right: Arcade Stats & Interactive Controls */}
          <div className="flex flex-col justify-between h-full space-y-4">
            <div className="bg-[#14141e] p-4 rounded-lg border border-white/10">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="text-zinc-400">PLAYER SCORE:</span>
                <span className="text-[#FFBC0D] font-bold text-base tracking-wider">{score} PTS</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-zinc-400">CREDITS:</span>
                <span className="text-emerald-400 font-bold">UNLIMITED FREE PLAY</span>
              </div>
            </div>

            <div className="space-y-2">
              <span className="text-[11px] text-zinc-400 uppercase tracking-wider block">
                Select 8-Bit Nostalgia Item:
              </span>
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => handleItemClick('burger')}
                  className={`py-2 px-3 text-xs rounded border transition-all cursor-pointer ${
                    activeItem === 'burger'
                      ? 'bg-[#FFBC0D] text-black font-bold border-[#FFBC0D]'
                      : 'bg-white/5 text-zinc-300 border-white/10 hover:border-white/30'
                  }`}
                >
                  🍔 Big Mac
                </button>
                <button
                  onClick={() => handleItemClick('fries')}
                  className={`py-2 px-3 text-xs rounded border transition-all cursor-pointer ${
                    activeItem === 'fries'
                      ? 'bg-[#FFBC0D] text-black font-bold border-[#FFBC0D]'
                      : 'bg-white/5 text-zinc-300 border-white/10 hover:border-white/30'
                  }`}
                >
                  🍟 Fries
                </button>
                <button
                  onClick={() => handleItemClick('coffee')}
                  className={`py-2 px-3 text-xs rounded border transition-all cursor-pointer ${
                    activeItem === 'coffee'
                      ? 'bg-[#FFBC0D] text-black font-bold border-[#FFBC0D]'
                      : 'bg-white/5 text-zinc-300 border-white/10 hover:border-white/30'
                  }`}
                >
                  ☕ McCafé
                </button>
              </div>
            </div>

            <div className="pt-2 flex flex-col gap-2">
              <button
                onClick={handleCollectPoints}
                className="cursor-pointer w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider rounded border border-emerald-400 shadow-md active:translate-y-0.5 flex items-center justify-center gap-2"
              >
                <Trophy className="w-4 h-4" />
                <span>Earn +100 Rewards Points</span>
              </button>

              <button
                onClick={() => {
                  onAddToCart({
                    id: 'big-mac-retro',
                    name: '8-Bit Retro Big Mac® Combo',
                    price: 6.49,
                    calories: 508,
                  });
                  onClose();
                }}
                className="cursor-pointer w-full py-2.5 bg-[#FFBC0D] hover:bg-[#F5AB00] text-black font-bold text-xs uppercase tracking-wider rounded border border-[#FFBC0D] shadow-md active:translate-y-0.5 flex items-center justify-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                <span>Order Retro Meal to Bag (£6.49)</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer info */}
        <div className="mt-4 text-center">
          <span className="text-[10px] text-zinc-500 uppercase tracking-widest">
            ★ Genuinely Engineered with HTML & CSS Pixel Art Matrix ★
          </span>
        </div>
      </div>
    </div>
  );
};
