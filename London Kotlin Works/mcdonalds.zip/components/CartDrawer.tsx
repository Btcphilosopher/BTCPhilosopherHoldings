'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { X, Plus, Minus, Trash2, ShoppingBag, Sparkles, CheckCircle2, ArrowRight } from 'lucide-react';
import confetti from 'canvas-confetti';

export interface CartItem {
  id: string;
  name: string;
  price: number;
  calories: number;
  image?: string;
  quantity: number;
  customizations?: string[];
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
  orderMode: 'delivery' | 'pickup';
  setOrderMode: (mode: 'delivery' | 'pickup') => void;
  deliveryAddress?: string;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  orderMode,
  setOrderMode,
  deliveryAddress,
}) => {
  const [orderConfirmed, setOrderConfirmed] = useState(false);
  const [orderId, setOrderId] = useState('');

  if (!isOpen) return null;

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const deliveryFee = orderMode === 'delivery' && subtotal < 15 && items.length > 0 ? 1.99 : 0;
  const total = subtotal + deliveryFee;
  const pointsEarned = Math.round(total * 100);

  const handleCheckout = () => {
    const newOrderId = `MCD-${Math.floor(100000 + Math.random() * 900000)}`;
    setOrderId(newOrderId);
    setOrderConfirmed(true);

    try {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#FFBC0D', '#DA291C', '#FFFFFF'],
      });
    } catch {
      // safe fallback
    }
  };

  const handleCloseConfirmation = () => {
    setOrderConfirmed(false);
    onClearCart();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden select-none">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-black/75 backdrop-blur-sm transition-opacity"
      />

      {/* Drawer */}
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#0f0f13] border-l border-white/10 shadow-2xl flex flex-col justify-between">
          {/* Header */}
          <div className="p-6 border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <ShoppingBag className="w-5 h-5 text-[#FFBC0D]" />
              <h2 className="text-lg font-bold text-white">Your McDonald&apos;s Bag</h2>
              <span className="text-xs font-mono text-zinc-400">
                ({items.reduce((acc, it) => acc + it.quantity, 0)})
              </span>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Delivery or Pickup Toggle */}
          <div className="px-6 pt-4 pb-2">
            <div className="grid grid-cols-2 gap-1 p-1 bg-white/5 rounded-xl border border-white/10">
              <button
                onClick={() => setOrderMode('delivery')}
                className={`py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  orderMode === 'delivery'
                    ? 'bg-[#FFBC0D] text-black shadow-sm'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                McDelivery
              </button>
              <button
                onClick={() => setOrderMode('pickup')}
                className={`py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  orderMode === 'pickup'
                    ? 'bg-[#FFBC0D] text-black shadow-sm'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Restaurant Pickup
              </button>
            </div>

            {orderMode === 'delivery' && deliveryAddress && (
              <p className="text-[11px] text-zinc-400 mt-2 truncate">
                Delivering to: <span className="text-white">{deliveryAddress}</span>
              </p>
            )}
          </div>

          {/* Item List */}
          <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-16 text-zinc-500">
                <ShoppingBag className="w-12 h-12 stroke-1 mb-3 opacity-40" />
                <p className="text-sm font-medium text-white mb-1">Your bag is empty</p>
                <p className="text-xs text-zinc-400 max-w-xs mb-4">
                  Add fresh handcrafted burgers, fries, or McCafé roasts to start your order.
                </p>
              </div>
            ) : (
              items.map((item) => (
                <div
                  key={item.id}
                  className="p-3.5 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between gap-3"
                >
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm font-semibold text-white truncate">{item.name}</h4>
                    {item.customizations && item.customizations.length > 0 && (
                      <p className="text-[10px] text-zinc-400 truncate">
                        Customized ({item.customizations.length} items)
                      </p>
                    )}
                    <span className="font-mono text-xs font-bold text-[#FFBC0D] block mt-1">
                      £{(item.price * item.quantity).toFixed(2)}
                    </span>
                  </div>

                  {/* Quantity Stepper */}
                  <div className="flex items-center gap-2 shrink-0 bg-black/40 rounded-lg p-1 border border-white/10">
                    <button
                      onClick={() => onUpdateQuantity(item.id, -1)}
                      className="p-1 hover:bg-white/10 rounded text-zinc-300 hover:text-white transition-colors cursor-pointer"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="font-mono text-xs text-white px-1">{item.quantity}</span>
                    <button
                      onClick={() => onUpdateQuantity(item.id, 1)}
                      className="p-1 hover:bg-white/10 rounded text-zinc-300 hover:text-white transition-colors cursor-pointer"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>

                  {/* Delete button */}
                  <button
                    onClick={() => onRemoveItem(item.id)}
                    className="p-1.5 text-zinc-500 hover:text-red-400 transition-colors cursor-pointer"
                    title="Remove item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>

          {/* Footer Subtotal & Checkout */}
          {items.length > 0 && (
            <div className="p-6 border-t border-white/10 bg-[#121218] space-y-4">
              <div className="space-y-1.5 text-xs text-zinc-400">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-mono text-white font-medium">£{subtotal.toFixed(2)}</span>
                </div>
                {orderMode === 'delivery' && (
                  <div className="flex justify-between">
                    <span>Delivery Fee {subtotal >= 15 && '(Free over £15)'}</span>
                    <span className="font-mono text-white font-medium">
                      {deliveryFee === 0 ? 'FREE' : `£${deliveryFee.toFixed(2)}`}
                    </span>
                  </div>
                )}
                <div className="flex justify-between pt-2 border-t border-white/10 text-sm font-bold text-white">
                  <span>Total Amount</span>
                  <span className="font-mono text-base text-[#FFBC0D]">£{total.toFixed(2)}</span>
                </div>
              </div>

              {/* Rewards Points Banner */}
              <div className="p-2.5 rounded-lg bg-[#FFBC0D]/10 border border-[#FFBC0D]/20 flex items-center justify-between text-[11px]">
                <span className="flex items-center gap-1.5 text-zinc-300">
                  <Sparkles className="w-3.5 h-3.5 text-[#FFBC0D]" />
                  <span>MyMcDonald&apos;s Rewards</span>
                </span>
                <span className="font-mono font-bold text-[#FFBC0D]">+{pointsEarned} pts</span>
              </div>

              <button
                onClick={handleCheckout}
                className="w-full py-3.5 rounded-full bg-[#FFBC0D] text-black font-bold text-xs uppercase tracking-wider hover:bg-[#F5AB00] transition-colors shadow-lg cursor-pointer flex items-center justify-center gap-2 active:scale-95"
              >
                <span>Complete Order (£{total.toFixed(2)})</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Order Confirmed Modal */}
      {orderConfirmed && (
        <div className="fixed inset-0 z-60 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#121218] border border-white/20 rounded-2xl p-8 max-w-sm w-full text-center space-y-4 animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 rounded-full bg-[#FFBC0D]/10 text-[#FFBC0D] flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-10 h-10 text-[#FFBC0D]" />
            </div>

            <h3 className="text-xl font-bold text-white">Order Confirmed!</h3>
            <p className="text-xs text-zinc-300 leading-relaxed">
              Your kitchen ticket <span className="font-mono font-bold text-[#FFBC0D]">{orderId}</span> is being prepared with fresh, hot ingredients.
            </p>

            <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-xs font-mono text-zinc-400">
              Estimated Time: 15–20 minutes
            </div>

            <button
              onClick={handleCloseConfirmation}
              className="w-full py-2.5 rounded-full bg-[#FFBC0D] text-black font-bold text-xs uppercase tracking-wider hover:bg-[#F5AB00] transition-colors cursor-pointer"
            >
              Done & Return
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
