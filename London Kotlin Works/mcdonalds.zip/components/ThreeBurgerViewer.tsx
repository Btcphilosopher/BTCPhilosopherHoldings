'use client';

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { X, RotateCcw, Play, Pause, Layers, Info } from 'lucide-react';

interface ThreeBurgerViewerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface BurgerLayerInfo {
  name: string;
  description: string;
  calories: string;
  origin: string;
}

const LAYER_DETAILS: Record<string, BurgerLayerInfo> = {
  topBun: {
    name: 'Sesame Seed Crown Bun',
    description: 'Freshly baked brioche-style bun toasted to golden perfection and topped with toasted sesame seeds.',
    calories: '150 kcal',
    origin: '100% British wheat flour',
  },
  sauceTop: {
    name: 'Legendary Big Mac® Sauce',
    description: 'The iconic secret recipe blend of tangy mustard, dill relish, vinegar, garlic, and savory spices.',
    calories: '50 kcal',
    origin: 'Original 1968 secret recipe',
  },
  lettuce: {
    name: 'Crisp Shredded Iceberg Lettuce',
    description: 'Washed, chilled and shredded for optimal crunch with every bite.',
    calories: '5 kcal',
    origin: 'Red Tractor certified UK farms',
  },
  cheese: {
    name: 'Melted American Cheddar',
    description: 'Smooth, rich cheddar cheese slice melted over the hot grilled patty.',
    calories: '60 kcal',
    origin: 'British and Irish dairy',
  },
  beefTop: {
    name: '100% British & Irish Beef Patty',
    description: 'Pure beef seasoned solely with salt and pepper after searing on the flat-top grill.',
    calories: '110 kcal',
    origin: 'Farm-assured British & Irish beef',
  },
  middleBun: {
    name: 'Middle Club Bun',
    description: 'The signature architectural divider that provides balanced structural integrity.',
    calories: '110 kcal',
    origin: 'British wheat flour',
  },
  pickles: {
    name: 'Tangy Dill Pickles',
    description: 'Crisp pickled cucumbers infused with aromatic dill and mustard seed brine.',
    calories: '5 kcal',
    origin: 'European farms',
  },
  beefBottom: {
    name: 'Second 100% Pure Beef Patty',
    description: 'Seared to lock in natural juices and natural savoury flavours.',
    calories: '110 kcal',
    origin: 'Farm-assured British & Irish beef',
  },
  bottomBun: {
    name: 'Toasted Heel Bun',
    description: 'Specially toasted base bun engineered to hold sauces without sogginess.',
    calories: '100 kcal',
    origin: 'British wheat flour',
  },
};

export const ThreeBurgerViewer: React.FC<ThreeBurgerViewerProps> = ({
  isOpen,
  onClose,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [isExploded, setIsExploded] = useState(false);
  const [isAutoRotating, setIsAutoRotating] = useState(true);
  const [selectedLayer, setSelectedLayer] = useState<string>('topBun');

  // Three.js instances ref
  const sceneRef = useRef<{
    renderer: THREE.WebGLRenderer;
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    layersGroup: THREE.Group;
    layerMeshes: Map<string, THREE.Object3D>;
    originalY: Map<string, number>;
    explodedY: Map<string, number>;
    animationFrameId: number;
    isDragging: boolean;
    prevMouseX: number;
    prevMouseY: number;
  } | null>(null);

  useEffect(() => {
    if (!isOpen || !mountRef.current) return;

    const container = mountRef.current;
    const width = container.clientWidth;
    const height = container.clientHeight;

    // Scene & Camera
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0a0e);

    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 1000);
    camera.position.set(0, 3, 14);

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;

    container.appendChild(renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.9);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xfff0dd, 2.2);
    keyLight.position.set(6, 10, 8);
    keyLight.castShadow = true;
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0xaaccff, 0.8);
    fillLight.position.set(-8, 4, -4);
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xffc55a, 1.4);
    rimLight.position.set(0, -6, -6);
    scene.add(rimLight);

    // Group for burger layers
    const layersGroup = new THREE.Group();
    scene.add(layersGroup);

    // Materials
    const bunMaterial = new THREE.MeshStandardMaterial({
      color: 0xc48238,
      roughness: 0.6,
      metalness: 0.05,
    });

    const innerBunMaterial = new THREE.MeshStandardMaterial({
      color: 0xdfa662,
      roughness: 0.8,
    });

    const pattyMaterial = new THREE.MeshStandardMaterial({
      color: 0x482918,
      roughness: 0.9,
      metalness: 0.1,
    });

    const cheeseMaterial = new THREE.MeshStandardMaterial({
      color: 0xffa812,
      roughness: 0.35,
      metalness: 0.1,
    });

    const sauceMaterial = new THREE.MeshStandardMaterial({
      color: 0xdd8e52,
      roughness: 0.3,
    });

    const lettuceMaterial = new THREE.MeshStandardMaterial({
      color: 0x4e8d35,
      roughness: 0.6,
    });

    const pickleMaterial = new THREE.MeshStandardMaterial({
      color: 0x365824,
      roughness: 0.4,
    });

    const sesameMaterial = new THREE.MeshStandardMaterial({
      color: 0xf5ebd7,
      roughness: 0.4,
    });

    const layerMeshes = new Map<string, THREE.Object3D>();
    const originalY = new Map<string, number>();
    const explodedY = new Map<string, number>();

    // 1. Top Crown Bun
    const topBunGroup = new THREE.Group();
    const bunGeom = new THREE.SphereGeometry(2.3, 32, 16, 0, Math.PI * 2, 0, Math.PI * 0.45);
    bunGeom.scale(1, 0.55, 1);
    const topBunMesh = new THREE.Mesh(bunGeom, bunMaterial);
    topBunMesh.castShadow = true;
    topBunGroup.add(topBunMesh);

    // Add sesame seeds
    const seedGeom = new THREE.ConeGeometry(0.04, 0.1, 5);
    for (let i = 0; i < 45; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.random() * 0.6 + 0.1;
      const r = 2.28;
      const x = r * Math.sin(phi) * Math.cos(theta);
      const y = r * Math.cos(phi) * 0.55;
      const z = r * Math.sin(phi) * Math.sin(theta);
      const seed = new THREE.Mesh(seedGeom, sesameMaterial);
      seed.position.set(x, y, z);
      seed.rotation.set(Math.random(), Math.random(), Math.random());
      topBunGroup.add(seed);
    }

    // Register layers with relative stacked Y coordinates
    const layersConfig = [
      { id: 'topBun', mesh: topBunGroup, normalY: 2.2, expY: 5.5 },
      {
        id: 'sauceTop',
        mesh: new THREE.Mesh(new THREE.CylinderGeometry(2.0, 2.05, 0.1, 32), sauceMaterial),
        normalY: 1.8,
        expY: 4.2,
      },
      {
        id: 'lettuce',
        mesh: new THREE.Mesh(new THREE.TorusGeometry(1.8, 0.35, 12, 32), lettuceMaterial),
        normalY: 1.5,
        expY: 3.0,
      },
      {
        id: 'cheese',
        mesh: new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.08, 3.2), cheeseMaterial),
        normalY: 1.15,
        expY: 1.8,
      },
      {
        id: 'beefTop',
        mesh: new THREE.Mesh(new THREE.CylinderGeometry(2.1, 2.1, 0.35, 32), pattyMaterial),
        normalY: 0.8,
        expY: 0.6,
      },
      {
        id: 'middleBun',
        mesh: new THREE.Mesh(new THREE.CylinderGeometry(2.15, 2.15, 0.3, 32), innerBunMaterial),
        normalY: 0.35,
        expY: -0.6,
      },
      {
        id: 'pickles',
        mesh: new THREE.Mesh(new THREE.CylinderGeometry(1.8, 1.8, 0.1, 24), pickleMaterial),
        normalY: 0.05,
        expY: -1.8,
      },
      {
        id: 'beefBottom',
        mesh: new THREE.Mesh(new THREE.CylinderGeometry(2.1, 2.1, 0.35, 32), pattyMaterial),
        normalY: -0.3,
        expY: -3.0,
      },
      {
        id: 'bottomBun',
        mesh: new THREE.Mesh(new THREE.CylinderGeometry(2.2, 2.1, 0.45, 32), bunMaterial),
        normalY: -0.85,
        expY: -4.4,
      },
    ];

    layersConfig.forEach((cfg) => {
      cfg.mesh.position.y = cfg.normalY;
      cfg.mesh.castShadow = true;
      cfg.mesh.receiveShadow = true;
      layersGroup.add(cfg.mesh);
      layerMeshes.set(cfg.id, cfg.mesh);
      originalY.set(cfg.id, cfg.normalY);
      explodedY.set(cfg.id, cfg.expY);
    });

    // Subtle table base shadow
    const floorGeom = new THREE.PlaneGeometry(16, 16);
    const floorMat = new THREE.ShadowMaterial({ opacity: 0.35 });
    const floor = new THREE.Mesh(floorGeom, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -1.6;
    floor.receiveShadow = true;
    scene.add(floor);

    // Mouse Drag Controls
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const deltaX = e.clientX - prevMouseX;
      const deltaY = e.clientY - prevMouseY;
      layersGroup.rotation.y += deltaX * 0.01;
      layersGroup.rotation.x += deltaY * 0.01;
      // Clamp x tilt
      layersGroup.rotation.x = Math.max(-0.6, Math.min(0.6, layersGroup.rotation.x));
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseUp = () => {
      isDragging = false;
    };

    container.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);

    // Touch support for mobile devices
    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 1) {
        isDragging = true;
        prevMouseX = e.touches[0].clientX;
        prevMouseY = e.touches[0].clientY;
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      if (!isDragging || e.touches.length !== 1) return;
      const deltaX = e.touches[0].clientX - prevMouseX;
      const deltaY = e.touches[0].clientY - prevMouseY;
      layersGroup.rotation.y += deltaX * 0.01;
      layersGroup.rotation.x += deltaY * 0.01;
      layersGroup.rotation.x = Math.max(-0.6, Math.min(0.6, layersGroup.rotation.x));
      prevMouseX = e.touches[0].clientX;
      prevMouseY = e.touches[0].clientY;
    };

    const onTouchEnd = () => {
      isDragging = false;
    };

    container.addEventListener('touchstart', onTouchStart);
    window.addEventListener('touchmove', onTouchMove);
    window.addEventListener('touchend', onTouchEnd);

    // Resize Handler
    const handleResize = () => {
      if (!mountRef.current) return;
      const w = mountRef.current.clientWidth;
      const h = mountRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    // Animation Loop
    let animId: number;
    const animate = () => {
      animId = requestAnimationFrame(animate);

      // Auto rotation when enabled and not dragging
      if (isAutoRotating && !isDragging) {
        layersGroup.rotation.y += 0.005;
      }

      // Smooth layer interpolation for explode effect
      layerMeshes.forEach((mesh, id) => {
        const targetY = isExploded ? (explodedY.get(id) ?? 0) : (originalY.get(id) ?? 0);
        mesh.position.y += (targetY - mesh.position.y) * 0.1;
      });

      renderer.render(scene, camera);
    };

    animId = requestAnimationFrame(animate);

    sceneRef.current = {
      renderer,
      scene,
      camera,
      layersGroup,
      layerMeshes,
      originalY,
      explodedY,
      animationFrameId: animId,
      isDragging,
      prevMouseX,
      prevMouseY,
    };

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      container.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      container.removeEventListener('touchstart', onTouchStart);
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onTouchEnd);
      if (renderer.domElement && container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [isOpen, isExploded, isAutoRotating]);

  if (!isOpen) return null;

  const currentInfo = LAYER_DETAILS[selectedLayer] || LAYER_DETAILS['topBun'];

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-xl flex flex-col items-center justify-center p-4">
      {/* Top Header Controls */}
      <div className="w-full max-w-6xl flex items-center justify-between py-4 px-6 border-b border-white/10 z-20">
        <div>
          <span className="text-[11px] uppercase tracking-[0.2em] text-[#FFBC0D] font-bold block">
            Three.js WebGL Engine
          </span>
          <h2 className="text-xl sm:text-2xl font-display font-medium text-white">
            Big Mac® Architectural Breakdown
          </h2>
        </div>

        <div className="flex items-center gap-3">
          {/* Explode Layers Button */}
          <button
            onClick={() => setIsExploded(!isExploded)}
            className={`cursor-pointer inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold transition-all ${
              isExploded
                ? 'bg-[#FFBC0D] text-black shadow-[0_0_15px_rgba(255,188,13,0.4)]'
                : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>{isExploded ? 'Reassemble Layers' : 'Deconstruct / Explode Layers'}</span>
          </button>

          {/* Auto rotate toggle */}
          <button
            onClick={() => setIsAutoRotating(!isAutoRotating)}
            className="p-2.5 rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors cursor-pointer"
            title="Toggle Auto Rotation"
          >
            {isAutoRotating ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </button>

          {/* Close button */}
          <button
            onClick={onClose}
            className="p-2.5 rounded-full bg-white/10 text-zinc-300 hover:text-white hover:bg-white/20 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Visualizer Area */}
      <div className="w-full max-w-6xl flex-1 grid grid-cols-1 lg:grid-cols-12 relative overflow-hidden py-4">
        {/* 3D Canvas Mount */}
        <div
          ref={mountRef}
          className="lg:col-span-8 w-full h-[380px] sm:h-[480px] lg:h-full relative rounded-2xl overflow-hidden cursor-grab active:cursor-grabbing border border-white/5"
        >
          {/* Interactive hint overlay */}
          <div className="absolute top-4 left-4 z-10 pointer-events-none bg-black/40 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/10 text-[11px] text-zinc-300 flex items-center gap-2">
            <RotateCcw className="w-3.5 h-3.5 text-[#FFBC0D]" />
            <span>Drag to rotate 360° in 3D</span>
          </div>
        </div>

        {/* Right Layer Inspector & Nutrition Panel */}
        <div className="lg:col-span-4 p-6 flex flex-col justify-between overflow-y-auto max-h-full">
          <div>
            <h4 className="text-xs font-mono uppercase tracking-wider text-zinc-400 mb-3">
              Select Ingredient Layer
            </h4>

            {/* Layer Buttons */}
            <div className="flex flex-col gap-1.5 mb-6">
              {Object.entries(LAYER_DETAILS).map(([id, info]) => (
                <button
                  key={id}
                  onClick={() => setSelectedLayer(id)}
                  className={`text-left px-3 py-2 rounded-lg text-xs transition-all cursor-pointer flex items-center justify-between ${
                    selectedLayer === id
                      ? 'bg-[#FFBC0D] text-black font-bold shadow-md'
                      : 'bg-white/5 text-zinc-300 hover:bg-white/10'
                  }`}
                >
                  <span className="truncate">{info.name}</span>
                  <span className="font-mono text-[11px] opacity-75">{info.calories}</span>
                </button>
              ))}
            </div>

            {/* Selected Ingredient Card */}
            <div className="p-4 rounded-xl bg-white/5 border border-white/10 backdrop-blur-sm">
              <div className="flex items-center gap-2 mb-2 text-[#FFBC0D]">
                <Info className="w-4 h-4" />
                <span className="text-xs uppercase tracking-wider font-semibold">Ingredient Details</span>
              </div>
              <h3 className="text-base font-bold text-white mb-2">{currentInfo.name}</h3>
              <p className="text-xs text-zinc-300 leading-relaxed mb-4">{currentInfo.description}</p>

              <div className="grid grid-cols-2 gap-2 text-[11px] pt-2 border-t border-white/10">
                <div>
                  <span className="text-zinc-500 block">Energy</span>
                  <span className="font-mono font-semibold text-white">{currentInfo.calories}</span>
                </div>
                <div>
                  <span className="text-zinc-500 block">Sourcing</span>
                  <span className="font-medium text-white">{currentInfo.origin}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-white/10 flex items-center justify-between text-xs text-zinc-400">
            <span>Standard Big Mac® — 508 kcal</span>
            <span className="text-[#FFBC0D] font-mono">100% Quality Guaranteed</span>
          </div>
        </div>
      </div>
    </div>
  );
};
