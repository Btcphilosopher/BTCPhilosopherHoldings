'use client';

import React from 'react';
import { X, Sparkles, Award, Gift, ChevronRight, Check } from 'lucide-react';
import { GoldenArchLogo } from './GoldenArchLogo';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  points: number;
  onRedeem: (rewardName: string, cost: number) => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  points,
  onRedeem,
}) => {
  if (!isOpen) return null;

  const rewards = [
    { name: 'Free Regular McCafé Hot Drink', cost: 1500, tier: 'Level 1' },
    { name: 'Free Medium World Famous Fries®', cost: 1500, tier: 'Level 1' },
    { name: 'Free Double Cheeseburger', cost: 2500, tier: 'Level 2' },
    { name: 'Free Big Mac® or McPlant®', cost: 4000, tier: 'Gold Tier' },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xl flex items-center justify-center p-3 sm:p-6 select-none animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#0f0f13] border border-white/10 rounded-2xl flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="p-6 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <GoldenArchLogo size={28} />
            <div>
              <span className="text-xs uppercase tracking-widest text-[#FFBC0D] font-bold">
                MyMcDonald’s Rewards
              </span>
              <h2 className="text-xl font-display font-medium text-white">
                Member Profile
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Points Card */}
        <div className="p-6 space-y-6 overflow-y-auto">
          <div className="p-5 rounded-2xl bg-gradient-to-br from-[#1d1810] to-[#121218] border border-[#FFBC0D]/30 shadow-lg relative overflow-hidden">
            <div className="flex justify-between items-start mb-4">
              <div>
                <span className="text-xs uppercase font-mono tracking-wider text-zinc-400">
                  Current Balance
                </span>
                <div className="text-3xl font-extrabold text-[#FFBC0D] font-mono tracking-tight mt-0.5">
                  {points.toLocaleString()} PTS
                </div>
              </div>
              <div className="px-3 py-1 rounded-full bg-[#FFBC0D] text-black text-[11px] font-bold uppercase tracking-wider">
                Gold Member
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between text-[11px] text-zinc-400">
                <span>Next Milestone: Big Mac (4,000 pts)</span>
                <span className="font-mono text-white">{Math.min(100, Math.round((points / 4000) * 100))}%</span>
              </div>
              <div className="w-full h-2 bg-black/40 rounded-full overflow-hidden border border-white/10">
                <div
                  className="h-full bg-[#FFBC0D] transition-all duration-500"
                  style={{ width: `${Math.min(100, (points / 4000) * 100)}%` }}
                />
              </div>
            </div>
          </div>

          {/* Unlockable Rewards */}
          <div>
            <h3 className="text-xs font-mono uppercase tracking-wider text-zinc-400 mb-3 flex items-center gap-1.5">
              <Gift className="w-3.5 h-3.5 text-[#FFBC0D]" />
              <span>Available Rewards & Vouchers:</span>
            </h3>

            <div className="space-y-2.5">
              {rewards.map((reward) => {
                const canRedeem = points >= reward.cost;
                return (
                  <div
                    key={reward.name}
                    className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 transition-colors ${
                      canRedeem
                        ? 'bg-white/5 border-white/10 hover:border-[#FFBC0D]'
                        : 'bg-white/[0.02] border-white/5 opacity-60'
                    }`}
                  >
                    <div>
                      <h4 className="text-xs font-semibold text-white">{reward.name}</h4>
                      <span className="text-[11px] font-mono text-[#FFBC0D]">
                        {reward.cost.toLocaleString()} points
                      </span>
                    </div>

                    <button
                      disabled={!canRedeem}
                      onClick={() => onRedeem(reward.name, reward.cost)}
                      className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                        canRedeem
                          ? 'bg-[#FFBC0D] text-black hover:bg-[#F5AB00]'
                          : 'bg-white/10 text-zinc-500 cursor-not-allowed'
                      }`}
                    >
                      Redeem
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
