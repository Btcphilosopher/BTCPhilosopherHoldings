'use client';

import React, { useState } from 'react';
import { X, MapPin, Clock, Car, Coffee, Zap, Navigation, Check } from 'lucide-react';
import { RESTAURANT_LOCATIONS, RestaurantLocation } from '../data/menuData';

interface RestaurantLocatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectStore: (store: RestaurantLocation) => void;
}

export const RestaurantLocatorModal: React.FC<RestaurantLocatorModalProps> = ({
  isOpen,
  onClose,
  onSelectStore,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filter24h, setFilter24h] = useState(false);
  const [filterDriveThru, setFilterDriveThru] = useState(false);
  const [filterEV, setFilterEV] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState<RestaurantLocation | null>(null);

  if (!isOpen) return null;

  const filteredLocations = RESTAURANT_LOCATIONS.filter((loc) => {
    if (filter24h && !loc.isOpen24) return false;
    if (filterDriveThru && !loc.hasDriveThru) return false;
    if (filterEV && !loc.hasEVCharging) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      return (
        loc.name.toLowerCase().includes(q) ||
        loc.address.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xl flex items-center justify-center p-3 sm:p-6 select-none animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl h-[88vh] bg-[#0f0f13] border border-white/10 rounded-2xl flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="p-6 border-b border-white/10 flex items-center justify-between">
          <div>
            <span className="text-xs uppercase tracking-widest text-[#FFBC0D] font-bold">
              Modern Spaces · Real Connection
            </span>
            <h2 className="text-2xl font-display font-medium text-white">
              Find a Restaurant
            </h2>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Filters */}
        <div className="p-4 sm:px-6 bg-[#131318] border-b border-white/5 space-y-3">
          <div className="relative">
            <MapPin className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#FFBC0D]" />
            <input
              type="text"
              placeholder="Search by city, town, or postcode (e.g. WC2R 1JA, Oxford St, London)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white text-sm placeholder-zinc-500 focus:outline-none focus:border-[#FFBC0D]"
            />
          </div>

          {/* Filter options */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setFilter24h(!filter24h)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs transition-colors cursor-pointer border ${
                filter24h
                  ? 'bg-[#FFBC0D] text-black font-semibold border-[#FFBC0D]'
                  : 'bg-white/5 border-white/10 text-zinc-400 hover:text-white'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Open 24 Hours</span>
            </button>

            <button
              onClick={() => setFilterDriveThru(!filterDriveThru)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs transition-colors cursor-pointer border ${
                filterDriveThru
                  ? 'bg-[#FFBC0D] text-black font-semibold border-[#FFBC0D]'
                  : 'bg-white/5 border-white/10 text-zinc-400 hover:text-white'
              }`}
            >
              <Car className="w-3.5 h-3.5" />
              <span>Drive-Thru</span>
            </button>

            <button
              onClick={() => setFilterEV(!filterEV)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs transition-colors cursor-pointer border ${
                filterEV
                  ? 'bg-[#FFBC0D] text-black font-semibold border-[#FFBC0D]'
                  : 'bg-white/5 border-white/10 text-zinc-400 hover:text-white'
              }`}
            >
              <Zap className="w-3.5 h-3.5" />
              <span>EV Fast Charging</span>
            </button>
          </div>
        </div>

        {/* Locations List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {filteredLocations.map((loc) => {
            const isSelected = selectedLocation?.id === loc.id;
            return (
              <div
                key={loc.id}
                className={`p-5 rounded-xl border transition-all duration-200 cursor-pointer ${
                  isSelected
                    ? 'bg-[#181822] border-[#FFBC0D] shadow-lg'
                    : 'bg-[#14141a] border-white/10 hover:border-white/20'
                }`}
                onClick={() => setSelectedLocation(loc)}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-base font-bold text-white">{loc.name}</h3>
                      <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800">
                        {loc.status}
                      </span>
                    </div>

                    <p className="text-xs text-zinc-400 mb-2">{loc.address}</p>

                    {/* Feature tags */}
                    <div className="flex items-center gap-3 text-[11px] text-zinc-400 flex-wrap">
                      <span className="text-[#FFBC0D] font-mono">{loc.distance}</span>
                      {loc.isOpen24 && <span className="flex items-center gap-1">· 24/7</span>}
                      {loc.hasDriveThru && <span className="flex items-center gap-1">· Drive-Thru</span>}
                      {loc.hasMcCafe && <span className="flex items-center gap-1">· McCafé Counter</span>}
                      {loc.hasEVCharging && <span className="flex items-center gap-1">· 150kW EV Charging</span>}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectStore(loc);
                        onClose();
                      }}
                      className="cursor-pointer px-4 py-2 rounded-full bg-[#FFBC0D] text-black text-xs font-semibold hover:bg-[#F5AB00] transition-colors"
                    >
                      Select Store
                    </button>
                    <a
                      href={`https://maps.google.com/?q=${encodeURIComponent(loc.name + ' ' + loc.address)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-zinc-300 hover:text-white transition-colors"
                      title="Open in Maps"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Navigation className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              </div>
            );
          })}

          {filteredLocations.length === 0 && (
            <div className="text-center py-12 text-zinc-500">
              <p className="text-sm">No McDonald&apos;s restaurants found matching your criteria.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
