export interface MenuItem {
  id: string;
  name: string;
  category: 'burgers' | 'chicken' | 'sides' | 'mccafe' | 'desserts' | 'breakfast';
  price: number;
  calories: number;
  description: string;
  image: string;
  badge?: string;
  isVegetarian?: boolean;
  isGlutenFree?: boolean;
  ingredients: string[];
  nutrition: {
    protein: number;
    carbs: number;
    fat: number;
    sodium: number;
  };
}

export const MENU_ITEMS: MenuItem[] = [
  {
    id: 'big-mac',
    name: 'The Big Mac®',
    category: 'burgers',
    price: 5.49,
    calories: 508,
    badge: 'Iconic Favourite',
    description: 'Two 100% British & Irish beef patties, a slice of cheese, lettuce, onion, pickles and the legendary Big Mac sauce in a toasted sesame seed bun.',
    image: '/images/hero_big_mac.jpg',
    ingredients: [
      'Two 100% Pure Beef Patties',
      'Big Mac® Sauce',
      'Crisp Shredded Lettuce',
      'Processed Cheddar Cheese Slice',
      'Dill Pickle Slices',
      'Fresh Minced Onions',
      'Toasted Sesame Seed Bun'
    ],
    nutrition: {
      protein: 26,
      carbs: 42,
      fat: 25,
      sodium: 890
    }
  },
  {
    id: 'quarter-pounder-cheese',
    name: 'Quarter Pounder® with Cheese',
    category: 'burgers',
    price: 5.29,
    calories: 520,
    badge: '100% Fresh Beef',
    description: 'A 100% pure beef patty seasoned with just a pinch of salt and pepper, two slices of melted cheese, slivered onions and tangy pickles.',
    image: '/images/card_double_cheeseburger.jpg',
    ingredients: [
      '100% Pure Beef Quarter-Pound Patty',
      'Two Slices Melted Cheddar',
      'Crisp Slivered Onions',
      'Tangy Pickles',
      'Mustard & Ketchup',
      'Toasted Sesame Bun'
    ],
    nutrition: {
      protein: 30,
      carbs: 38,
      fat: 28,
      sodium: 950
    }
  },
  {
    id: 'double-cheeseburger',
    name: 'Double Cheeseburger',
    category: 'burgers',
    price: 3.29,
    calories: 440,
    description: 'Two 100% beef patties with melted cheddar cheese, pickles, onions, ketchup and mustard.',
    image: '/images/card_double_cheeseburger.jpg',
    ingredients: [
      'Two 100% Beef Patties',
      'Two Slices Cheddar',
      'Pickles & Onions',
      'Ketchup & Mustard'
    ],
    nutrition: {
      protein: 25,
      carbs: 34,
      fat: 23,
      sodium: 840
    }
  },
  {
    id: 'mcplant',
    name: 'The McPlant®',
    category: 'burgers',
    price: 5.39,
    calories: 429,
    badge: '100% Vegan Certified',
    isVegetarian: true,
    description: 'A juicy plant-based patty co-developed with Beyond Meat®, featuring vegan sandwich sauce, ketchup, mustard, onion, pickles, lettuce, tomato and vegan cheese in a toasted sesame bun.',
    image: '/images/hero_big_mac.jpg',
    ingredients: [
      'Beyond Meat® Plant Patty',
      'Vegan Sandwich Sauce',
      'Vegan Cheese Alternative',
      'Crisp Lettuce & Juicy Tomato',
      'Pickles & Onions'
    ],
    nutrition: {
      protein: 19,
      carbs: 46,
      fat: 18,
      sodium: 780
    }
  },
  {
    id: 'world-famous-fries',
    name: 'World Famous Fries®',
    category: 'sides',
    price: 2.19,
    calories: 337,
    badge: 'Golden & Crisp',
    isVegetarian: true,
    isGlutenFree: true,
    description: 'Our world-famous golden fries, crispy on the outside and fluffy on the inside. Specially sourced from Red Tractor assured British and European farms.',
    image: '/images/hero_big_mac.jpg',
    ingredients: [
      'Grade A Potatoes',
      'Vegetable Oil Blend',
      'Sea Salt'
    ],
    nutrition: {
      protein: 4,
      carbs: 44,
      fat: 16,
      sodium: 260
    }
  },
  {
    id: 'mcnuggets-9pc',
    name: 'Chicken McNuggets® (9 pc)',
    category: 'chicken',
    price: 5.19,
    calories: 388,
    badge: '100% Chicken Breast',
    description: 'Bite-sized pieces of tender 100% chicken breast meat in a crispy, golden tempura batter. Served with your choice of dip.',
    image: '/images/card_double_cheeseburger.jpg',
    ingredients: [
      '100% Chicken Breast Meat',
      'Crisp Tempura Coating',
      'Choice of Sweet & Sour or Smoky BBQ'
    ],
    nutrition: {
      protein: 23,
      carbs: 27,
      fat: 20,
      sodium: 540
    }
  },
  {
    id: 'mccafe-latte',
    name: 'McCafé® Velvet Latte',
    category: 'mccafe',
    price: 2.89,
    calories: 145,
    badge: 'Rainforest Alliance',
    isVegetarian: true,
    description: 'A smooth blend of espresso made with 100% Arabica beans and steamed fresh organic British milk for a rich, silky texture.',
    image: '/images/card_mccafe_latte.jpg',
    ingredients: [
      '100% Arabica Espresso',
      'Steamed Organic Semi-Skimmed Milk',
      'Microfoam Layer'
    ],
    nutrition: {
      protein: 8,
      carbs: 11,
      fat: 6,
      sodium: 110
    }
  },
  {
    id: 'mccafe-flat-white',
    name: 'McCafé® Artisan Flat White',
    category: 'mccafe',
    price: 3.19,
    calories: 120,
    badge: 'Double Ristretto',
    isVegetarian: true,
    description: 'Expertly extracted double shot of espresso topped with velvety micro-foamed milk for a pure, robust coffee punch.',
    image: '/images/card_mccafe_latte.jpg',
    ingredients: [
      'Double Shot Arabica Ristretto',
      'Velvety Micro-foamed Milk'
    ],
    nutrition: {
      protein: 7,
      carbs: 9,
      fat: 5,
      sodium: 95
    }
  },
  {
    id: 'mcflurry-oreo',
    name: 'Oreo® McFlurry®',
    category: 'desserts',
    price: 2.19,
    calories: 258,
    isVegetarian: true,
    description: 'Soft dairy vanilla ice cream swirled with crushed Oreo cookie crumbs and creamy chocolate drizzle.',
    image: '/images/card_mccafe_latte.jpg',
    ingredients: [
      'British Dairy Soft Serve',
      'Crunchy Oreo® Biscuit Pieces',
      'Rich Cocoa Sauce'
    ],
    nutrition: {
      protein: 5,
      carbs: 36,
      fat: 10,
      sodium: 170
    }
  },
  {
    id: 'egg-mcmuffin',
    name: 'Egg & Cheese McMuffin®',
    category: 'breakfast',
    price: 3.79,
    calories: 295,
    badge: 'Free Range Egg',
    isVegetarian: true,
    description: 'A freshly cracked British free-range egg, gently cooked and served with a slice of melted cheese in a toasted English muffin.',
    image: '/images/card_double_cheeseburger.jpg',
    ingredients: [
      'Fresh Free-Range Egg',
      'Toasted English Muffin',
      'Melted Cheddar Cheese',
      'Liquid Butter Spread'
    ],
    nutrition: {
      protein: 16,
      carbs: 29,
      fat: 12,
      sodium: 620
    }
  }
];

export interface RestaurantLocation {
  id: string;
  name: string;
  address: string;
  distance: string;
  isOpen24: boolean;
  hasDriveThru: boolean;
  hasMcCafe: boolean;
  hasTableService: boolean;
  hasEVCharging: boolean;
  status: 'Open Now' | 'Closes at Midnight';
}

export const RESTAURANT_LOCATIONS: RestaurantLocation[] = [
  {
    id: 'flagship-london-strand',
    name: "McDonald's Flagship The Strand",
    address: '155-157 The Strand, London WC2R 1JA',
    distance: '0.4 miles away',
    isOpen24: true,
    hasDriveThru: false,
    hasMcCafe: true,
    hasTableService: true,
    hasEVCharging: false,
    status: 'Open Now'
  },
  {
    id: 'london-canary-wharf',
    name: "McDonald's Canary Wharf Jubilee Place",
    address: 'Canary Wharf Mall, London E14 5NY',
    distance: '2.1 miles away',
    isOpen24: true,
    hasDriveThru: false,
    hasMcCafe: true,
    hasTableService: true,
    hasEVCharging: true,
    status: 'Open Now'
  },
  {
    id: 'london-oxford-street',
    name: "McDonald's Oxford Street West",
    address: '49-51 Oxford Street, London W1D 2DY',
    distance: '1.2 miles away',
    isOpen24: false,
    hasDriveThru: false,
    hasMcCafe: true,
    hasTableService: true,
    hasEVCharging: false,
    status: 'Closes at Midnight'
  },
  {
    id: 'london-greenwich-drive-thru',
    name: "McDonald's Millennium Way Drive-Thru",
    address: 'Millennium Way, Greenwich, London SE10 0AX',
    distance: '3.8 miles away',
    isOpen24: true,
    hasDriveThru: true,
    hasMcCafe: true,
    hasTableService: true,
    hasEVCharging: true,
    status: 'Open Now'
  }
];
