'use client';

const HISTORY_KEY = 'miyabi_search_history';
const MAX_HISTORY = 10;

export interface HistoryItem {
  query: string;
  timestamp: number;
}

export const searchHistory = {
  get(): string[] {
    if (typeof window === 'undefined') return [];
    try {
      const raw = localStorage.getItem(HISTORY_KEY);
      if (!raw) return [];
      const parsed: HistoryItem[] = JSON.parse(raw);
      return parsed.map((item) => item.query);
    } catch {
      return [];
    }
  },

  add(query: string) {
    if (typeof window === 'undefined' || !query.trim()) return;
    try {
      const current = this.get();
      const trimmed = query.trim();
      const filtered = current.filter((q) => q.toLowerCase() !== trimmed.toLowerCase());
      const updated: HistoryItem[] = [
        { query: trimmed, timestamp: Date.now() },
        ...filtered.map((q) => ({ query: q, timestamp: Date.now() })),
      ].slice(0, MAX_HISTORY);
      localStorage.setItem(HISTORY_KEY, JSON.stringify(updated));
    } catch {
      // Ignore
    }
  },

  remove(query: string) {
    if (typeof window === 'undefined') return;
    try {
      const current = this.get();
      const updated = current
        .filter((q) => q !== query)
        .map((q) => ({ query: q, timestamp: Date.now() }));
      localStorage.setItem(HISTORY_KEY, JSON.stringify(updated));
    } catch {
      // Ignore
    }
  },

  clear() {
    if (typeof window === 'undefined') return;
    try {
      localStorage.removeItem(HISTORY_KEY);
    } catch {
      // Ignore
    }
  },
};
