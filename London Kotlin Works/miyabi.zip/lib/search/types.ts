export type SearchCategory = 'all' | 'images' | 'news' | 'videos' | 'maps';

export interface SearchResult {
  id: string;
  title: string;
  url: string;
  displayUrl: string;
  snippet: string;
  publishedAt?: string;
  category: string;
  sourceName: string;
  relevanceScore?: number;
}

export interface ImageResult {
  id: string;
  title: string;
  url: string;
  thumbnailUrl: string;
  sourceDomain: string;
  sourceUrl: string;
  dimensions: {
    width: number;
    height: number;
  };
  altText: string;
}

export interface NewsResult {
  id: string;
  headline: string;
  publisher: string;
  publishedAt: string;
  summary: string;
  thumbnailUrl?: string;
  url: string;
  isJapanese: boolean;
  category: string;
}

export interface PlaceResult {
  id: string;
  name: string;
  japaneseName: string;
  category: string;
  address: string;
  rating: number;
  reviewsCount: number;
  coordinates: {
    lat: number;
    lng: number;
  };
  summary: string;
  image?: string;
  openStatus?: string;
}

export interface KnowledgeCard {
  title: string;
  subtitle: string;
  description: string;
  facts: Array<{
    label: string;
    value: string;
  }>;
  imageUrl?: string;
  sourceUrl: string;
  sourceName: string;
}

export interface SearchQuery {
  query: string;
  category?: SearchCategory;
  page?: number;
  pageSize?: number;
  locale?: 'ja' | 'en';
  timeFilter?: 'all' | '24h' | 'week' | 'month';
  regionFilter?: 'all' | 'jp';
}

export interface SearchResponse {
  query: string;
  totalCount: number;
  tookMs: number;
  results: SearchResult[];
  images: ImageResult[];
  news: NewsResult[];
  places: PlaceResult[];
  knowledgeCard?: KnowledgeCard;
  aiSummary?: string;
  relatedSearches: string[];
  providerName: string;
  page: number;
  pageSize: number;
}

export interface ISearchProvider {
  search(params: SearchQuery): Promise<SearchResponse>;
  suggest(prefix: string, locale?: string): Promise<string[]>;
}
