import { ISearchProvider, SearchQuery, SearchResponse } from './types';
import { DemoSearchProvider } from './demo-provider';
import { GoogleGenAI } from '@google/genai';

let geminiClient: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  try {
    geminiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  } catch (err) {
    console.error('Failed to initialize Gemini client in search provider:', err);
  }
}

export class SearchService {
  private primaryProvider: ISearchProvider;

  constructor() {
    this.primaryProvider = new DemoSearchProvider();
  }

  async search(params: SearchQuery): Promise<SearchResponse> {
    const response = await this.primaryProvider.search(params);

    // If query is informational and Gemini API key is configured, enrich with AI Overview
    if (geminiClient && params.query && params.query.length >= 2 && (!params.category || params.category === 'all')) {
      try {
        const prompt = `You are MIYABI (みやび), an elegant next-generation Japanese search engine.
Provide a concise, highly factual, beautiful 2-3 sentence overview answering the user query: "${params.query}".
Language: Respond in ${params.locale === 'en' ? 'English' : 'Japanese'}.
Format: Pure text only, no markdown bold asterisks, no bullets, just a clean, refined explanation suitable for an editorial search summary.`;

        const aiResult = await geminiClient.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
        });

        if (aiResult && aiResult.text) {
          response.aiSummary = aiResult.text.trim();
        }
      } catch (err) {
        // Fallback silently if AI summary fails or rates limit
        console.warn('AI summary generation skipped:', err);
      }
    }

    return response;
  }

  async suggest(prefix: string, locale: string = 'ja'): Promise<string[]> {
    return this.primaryProvider.suggest(prefix, locale);
  }
}

export const searchService = new SearchService();
