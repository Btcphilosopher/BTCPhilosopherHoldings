import {
  ISearchProvider,
  SearchQuery,
  SearchResponse,
  SearchResult,
  ImageResult,
  NewsResult,
  PlaceResult,
  KnowledgeCard,
} from './types';

// Normalized Japanese demonstration corpus
const CORPUS_ALL: Array<SearchResult & { keywords: string[] }> = [
  {
    id: 'res-fuji-1',
    title: '富士山世界文化遺産 — 信仰の対象と芸術の源泉',
    url: 'https://www.fujisan-heritage.jp',
    displayUrl: 'fujisan-heritage.jp > fuji > overview',
    snippet: '標高3,776メートルの日本最高峰。2013年に「富士山—信仰の対象と芸術の源泉」としてユネスコ世界文化遺産に登録。古来より和歌や浮世絵の題材となり、日本人の美意識の象徴とされてきました。登山ルート、構成資産、四季の景観ガイド。',
    publishedAt: '2026-03-15',
    category: '文化・自然',
    sourceName: '富士山世界遺産センター',
    keywords: ['富士山', 'ふじさん', 'fuji', 'mount fuji', '世界遺産', '登山', '静岡', '山梨', '観光'],
  },
  {
    id: 'res-fuji-2',
    title: '河口湖から望む逆さ富士と桜の名所ガイド | 富士五湖観光連盟',
    url: 'https://www.fujisan.ne.jp/kawaguchiko',
    displayUrl: 'fujisan.ne.jp > kawaguchiko > spring',
    snippet: '春の河口湖北岸ウォーキングトレイルでは、満開のソメイヨシノ越しに雄大な富士山と湖面に映る「逆さ富士」を堪能できます。ベストシーズンは4月上旬〜中旬。朝霧の立ち込める清澄な早朝が撮影の最適時間帯です。',
    publishedAt: '2026-04-02',
    category: '観光・写真',
    sourceName: '富士五湖観光連盟',
    keywords: ['河口湖', '逆さ富士', '桜', 'さくら', 'sakura', '写真', 'fuji', '富士五湖'],
  },
  {
    id: 'res-kyoto-1',
    title: '京都の庭園美学 — 枯山水と「間」の空間哲学',
    url: 'https://kyoto-gardens.org/philosophy/karesansui',
    displayUrl: 'kyoto-gardens.org > philosophy > karesansui',
    snippet: '室町時代の禅宗寺院で発展した枯山水庭園。水を用いずに白砂の箒目と苔、巨石の配置のみで大海や宇宙を表現する極限のミニマリズム。龍安寺、大徳寺大仙院、銀閣寺に見る日本の「引き算の美学」を考察。',
    publishedAt: '2026-02-20',
    category: '日本文化・建築',
    sourceName: '京都文化学術研究所',
    keywords: ['京都', 'きょうと', 'kyoto', '枯山水', '庭園', '禅', 'zen', '間', '龍安寺', 'ミニマリズム'],
  },
  {
    id: 'res-tea-1',
    title: '茶の湯の精神 — 千利休が拓いた「一期一会」と和敬清寂',
    url: 'https://chadou-culture.jp/history/sen-no-rikyu',
    displayUrl: 'chadou-culture.jp > history > wabi-cha',
    snippet: '華美を排し、質素な黒楽茶碗や竹の茶杓の中に宇宙を見出す「侘び茶」。茶室という極小空間において主客が対等に心を通わせる茶道の心得、抹茶の点て方、道具の愛で方についての入門解説。',
    publishedAt: '2026-01-28',
    category: '伝統芸能',
    sourceName: '日本伝統工芸茶道振興会',
    keywords: ['茶道', 'お茶', '抹茶', 'matcha', '千利休', '侘び寂び', 'wabi-sabi', '茶碗', '茶室'],
  },
  {
    id: 'res-tokyo-arch-1',
    title: '東京の現代木造建築と都市サステナビリティ | 日本建築学会',
    url: 'https://aij.or.jp/tokyo-timber-architecture',
    displayUrl: 'aij.or.jp > tokyo > modern-timber',
    snippet: '伝統的な組木技術と最先端CLT工法を融合した現代日本の木造高層建築。温もりある天然ヒノキ格子とガラスファサードが織りなす2020年代後半の新しい東京の街並み。都市空間と自然の共生事例。',
    publishedAt: '2026-03-30',
    category: '建築・都市工学',
    sourceName: '日本建築学会',
    keywords: ['東京', 'とうきょう', 'tokyo', '建築', '木造', 'デザイン', 'ミニマリズム', 'ファサード'],
  },
  {
    id: 'res-miyabi-engine-1',
    title: '次世代検索エンジン MIYABI — 余白と精度の統合アーキテクチャ',
    url: 'https://miyabi.search/architecture',
    displayUrl: 'miyabi.search > technology > whitepaper',
    snippet: 'MIYABI（みやび）は、日本の美意識「雅」と「間（Ma）」をデジタルインターフェースに昇華させた検索プラットフォームです。広告やクリックベイトノイズを排し、真に必要な情報を静謐かつ高速に届ける検索体験を提供します。',
    publishedAt: '2026-10-18',
    category: '情報工学',
    sourceName: 'MIYABI Research Tokyo',
    keywords: ['miyabi', 'みやび', '検索エンジン', 'search', '次世代', 'ai', 'テクノロジー'],
  },
  {
    id: 'res-ai-japan-1',
    title: '日本発の大規模言語モデルと文脈理解の進化 | 理化学研究所',
    url: 'https://www.riken.jp/ai-context-2028',
    displayUrl: 'riken.jp > research > generative-ai',
    snippet: '敬語体系や文脈の含み（ハイコンテクスト文化）を深く解釈する次世代日本語基盤モデルの最新研究成果。ニュアンスの機微を捉える自然言語処理のブレークスルーと、知的アシスタントへの応用展望。',
    publishedAt: '2026-04-10',
    category: '人工知能',
    sourceName: '理化学研究所 計算科学研究センター',
    keywords: ['ai', '人工知能', 'アシスタント', '自然言語処理', 'llm', 'gemini', '深層学習'],
  },
  {
    id: 'res-robotics-1',
    title: '日本の人協調型ロボティクスと匠の技のデジタル伝承',
    url: 'https://aist.go.jp/robotics-craftsmanship',
    displayUrl: 'aist.go.jp > human-robot > takumi',
    snippet: '熟練職人の繊細な指先の力加減や削り技術をハプティクス（触覚技術）と高速ビジョンで学習する協調型ロボット。精密光学レンズから伝統陶芸まで、匠の息づかいをデジタルアーカイブする新展開。',
    publishedAt: '2026-04-05',
    category: 'ロボティクス',
    sourceName: '産業技術総合研究所',
    keywords: ['ロボット', 'robotics', '職人', 'ものづくり', '技術', '精密'],
  },
  {
    id: 'res-hydrogen-1',
    title: 'グリーン水素エネルギー網の構築と次世代交通システム',
    url: 'https://nedo.go.jp/hydrogen-energy-network',
    displayUrl: 'nedo.go.jp > projects > clean-energy',
    snippet: '福島水素エネルギー研究フィールド（FH2R）を起点とする地産地消型クリーンエネルギーネットワーク。燃料電池鉄道およびゼロエミッション船舶の実証実験が本格化。2030年に向けたカーボンニュートラル戦略。',
    publishedAt: '2026-03-18',
    category: 'エネルギー・環境',
    sourceName: '新エネルギー・産業技術総合開発機構',
    keywords: ['エネルギー', '水素', '環境', 'サステナビリティ', '脱炭素', '鉄道'],
  },
  {
    id: 'res-calligraphy-1',
    title: '書道の筆勢と呼吸 — 白と黒が織りなす精神空間',
    url: 'https://shodo-arts.jp/philosophy/breath-and-ink',
    displayUrl: 'shodo-arts.jp > arts > brush-spirit',
    snippet: '一回性の芸術と呼ばれる日本の書道。墨の濃淡、筆の渇筆、そして何もない余白（白）の緊張関係。文字を書くこと自体が自己の内面と向き合う瞑想的な行為となる書道美学の深層。',
    publishedAt: '2026-01-12',
    category: '芸術・文化',
    sourceName: '現代書道芸術院',
    keywords: ['書道', '墨', '筆', '余白', '日本美学', '漢字', '和風'],
  },
  {
    id: 'res-tokyo-ginza-1',
    title: '銀座の近代建築散歩 — 和光本館から現代ラグジュアリー旗艦店へ',
    url: 'https://ginza-walk.tokyo/architecture-heritage',
    displayUrl: 'ginza-walk.tokyo > heritage > modernism',
    snippet: '昭和初期のネオ・ルネサンス様式を誇るセイコーハウス銀座（旧和光）の時計塔から、最新のサステナブル建築まで。伝統の品格と最先端デザインが交差する銀座通りの建築史的見どころ。',
    publishedAt: '2026-02-14',
    category: '建築・都市散歩',
    sourceName: '銀座街づくり協議会',
    keywords: ['銀座', 'ginza', '東京', '建築', '和光', '散歩', '歴史'],
  },
];

// Curated demonstration images with local assets
const DEMO_IMAGES: ImageResult[] = [
  {
    id: 'img-1',
    title: '朝霧と満開の桜に映える霊峰富士と河口湖',
    url: '/images/miyabi_fuji_landscape.jpg',
    thumbnailUrl: '/images/miyabi_fuji_landscape.jpg',
    sourceDomain: 'fujisan-heritage.jp',
    sourceUrl: 'https://www.fujisan-heritage.jp/gallery',
    dimensions: { width: 1920, height: 1080 },
    altText: '雪を戴く富士山と手前の桜、静かな河口湖の湖面',
  },
  {
    id: 'img-2',
    title: '京都禅寺の枯山水庭園と苔むす石組の静寂',
    url: '/images/miyabi_kyoto_zen.jpg',
    thumbnailUrl: '/images/miyabi_kyoto_zen.jpg',
    sourceDomain: 'kyoto-gardens.org',
    sourceUrl: 'https://kyoto-gardens.org/gallery',
    dimensions: { width: 1600, height: 1200 },
    altText: '白砂に描かれた波紋と苔の島、京都の枯山水',
  },
  {
    id: 'img-3',
    title: '夕暮れの東京における木造格子と現代ガラス建築',
    url: '/images/miyabi_tokyo_modern.jpg',
    thumbnailUrl: '/images/miyabi_tokyo_modern.jpg',
    sourceDomain: 'aij.or.jp',
    sourceUrl: 'https://aij.or.jp/tokyo-timber',
    dimensions: { width: 1600, height: 1200 },
    altText: '温かみのある木のルーバーと整然としたガラス窓のモダン建築',
  },
  {
    id: 'img-4',
    title: '障子から差し込む自然光と茶筅、抹茶の器',
    url: '/images/miyabi_tea_ceremony.jpg',
    thumbnailUrl: '/images/miyabi_tea_ceremony.jpg',
    sourceDomain: 'chadou-culture.jp',
    sourceUrl: 'https://chadou-culture.jp/utensils',
    dimensions: { width: 1600, height: 1200 },
    altText: '木目の美しい板の間と竹の茶筅、深い緑の抹茶碗',
  },
];

// Curated News
const DEMO_NEWS: NewsResult[] = [
  {
    id: 'news-1',
    headline: '富士山の持続可能な入山管理システム、国際環境賞を受賞',
    publisher: '日経新聞 電子版',
    publishedAt: '2時間前',
    summary: '山梨・静岡両県が共同推進するスマート入山予約制と少人数エコトレッキング施策が、オーバーツーリズム対策の先駆的モデルとして世界持続可能観光協議会より高く評価されました。',
    thumbnailUrl: '/images/miyabi_fuji_landscape.jpg',
    url: 'https://www.nikkei.com',
    isJapanese: true,
    category: '社会・環境',
  },
  {
    id: 'news-2',
    headline: '京都の国宝寺院、AIと3Dレーザースキャンによるデジタル保存プロジェクトを完了',
    publisher: '朝日新聞デジタル',
    publishedAt: '5時間前',
    summary: '文化財の経年劣化や自然災害への備えとして、ミリ単位の点群データと木材の内部密度測定を統合した次世代アーカイブシステムが一般公開されました。',
    thumbnailUrl: '/images/miyabi_kyoto_zen.jpg',
    url: 'https://www.asahi.com',
    isJapanese: true,
    category: '文化・科学',
  },
  {
    id: 'news-3',
    headline: '日本発の次世代クリーン検索エンジンMIYABI、世界的なプライバシー標準に準拠',
    publisher: 'TechCrunch Japan',
    publishedAt: '8時間前',
    summary: 'ユーザーデータの収集やトラッキング広告を一切行わず、情報の美しさと的確な文脈理解を追求する検索基盤「MIYABI」が国内外の開発者から高い注目を集めています。',
    thumbnailUrl: '/images/miyabi_tokyo_modern.jpg',
    url: 'https://jp.techcrunch.com',
    isJapanese: true,
    category: 'テクノロジー',
  },
  {
    id: 'news-4',
    headline: 'Global Renewable Energy Index: Japan Advances Hydrogen Logistics',
    publisher: 'Financial Times',
    publishedAt: '12 hours ago',
    summary: 'Cross-border clean energy supply agreements gain traction as Japanese port facilities deploy automated liquid hydrogen carriers.',
    url: 'https://www.ft.com',
    isJapanese: false,
    category: 'International Business',
  },
];

// Curated Places
const DEMO_PLACES: PlaceResult[] = [
  {
    id: 'place-fuji',
    name: 'Mount Fuji',
    japaneseName: '富士山（山頂・剣ヶ峰）',
    category: '国定公園・山岳・世界文化遺産',
    address: '山梨県南都留郡富士河口湖町 / 静岡県富士宮市',
    rating: 4.9,
    reviewsCount: 38420,
    coordinates: { lat: 35.3606, lng: 138.7274 },
    summary: '標高3,776m。日本を象徴する最高峰。吉田ルート、富士宮ルートなど4つの登山道があり、例年7月上旬から9月上旬が開山期。',
    image: '/images/miyabi_fuji_landscape.jpg',
    openStatus: '夏季登山シーズンのみ開通',
  },
  {
    id: 'place-kawaguchiko',
    name: 'Lake Kawaguchi',
    japaneseName: '河口湖',
    category: '景勝地・湖沼',
    address: '山梨県南都留郡富士河口湖町',
    rating: 4.7,
    reviewsCount: 15200,
    coordinates: { lat: 35.5171, lng: 138.7518 },
    summary: '富士五湖の中で最も長い湖岸線を持つ湖。大石公園や産屋ヶ崎など、四季折々の花々と富士山が織りなす絶景ポイントが点在。',
    image: '/images/miyabi_fuji_landscape.jpg',
    openStatus: '常時開放',
  },
  {
    id: 'place-ryoanji',
    name: 'Ryoan-ji Temple',
    japaneseName: '龍安寺（りょうあんじ）',
    category: '臨済宗妙心寺派寺院・世界遺産',
    address: '京都府京都市右京区龍安寺御陵下町13',
    rating: 4.6,
    reviewsCount: 19800,
    coordinates: { lat: 35.0345, lng: 135.7182 },
    summary: '室町時代末期の作とされる枯山水石庭で世界的に知られる。15個の石がどの角度から見ても一度に14個しか見えない謎多き空間設計。',
    image: '/images/miyabi_kyoto_zen.jpg',
    openStatus: '拝観時間 8:30〜17:00',
  },
  {
    id: 'place-ginza',
    name: 'Ginza Seiko House',
    japaneseName: 'セイコーハウス銀座（旧和光本館）',
    category: '歴史的建造物・商業ランドマーク',
    address: '東京都中央区銀座4丁目5-11',
    rating: 4.5,
    reviewsCount: 12400,
    coordinates: { lat: 35.6713, lng: 139.7650 },
    summary: '銀座4丁目交差点に建つネオ・ルネサンス様式の時計塔。1932年竣工。銀座の象徴として親しまれる歴史的建造物。',
    image: '/images/miyabi_tokyo_modern.jpg',
    openStatus: '11:00〜19:00',
  },
];

// Canonical knowledge cards
const KNOWLEDGE_CARDS: Record<string, KnowledgeCard> = {
  fuji: {
    title: '富士山',
    subtitle: '標高 3,776m · ユネスコ世界文化遺産',
    description: '富士山（ふじさん）は、静岡県と山梨県に跨る活火山。日本の最高峰であり、古くから霊峰として信仰を集め、浮世絵や和歌など日本の美意識の根幹を形成してきました。美しい円錐形の成層火山です。',
    facts: [
      { label: '標高', value: '3,776 m' },
      { label: '初登頂記録', value: '西暦663年（役小角伝承）' },
      { label: '世界遺産登録', value: '2013年（文化遺産）' },
      { label: '所在地', value: '山梨県 / 静岡県' },
      { label: '火山の種類', value: '成層火山（活火山）' },
    ],
    imageUrl: '/images/miyabi_fuji_landscape.jpg',
    sourceUrl: 'https://www.fujisan-heritage.jp',
    sourceName: '富士山世界文化遺産学術委員会',
  },
  kyoto: {
    title: '京都',
    subtitle: '千年の都 · 日本の文化首都',
    description: '京都（きょうと）は、794年の平安遷都から明治初頭まで千年以上日本の都であった歴史都市。数多くの国宝寺社、洗練された枯山水庭園、伝統工芸、京料理など、日本文化の精髄が凝縮されています。',
    facts: [
      { label: '平安京遷都', value: '794年（延暦13年）' },
      { label: '古都京都の文化財', value: '17件の世界遺産' },
      { label: '面積', value: '827.83 km²' },
      { label: '代表庭園', value: '龍安寺石庭、金閣寺、銀閣寺' },
    ],
    imageUrl: '/images/miyabi_kyoto_zen.jpg',
    sourceUrl: 'https://kyoto.travel',
    sourceName: '京都市観光協会',
  },
  tea: {
    title: '茶道（侘び茶）',
    subtitle: '伝統文化 · 和敬清寂の哲学',
    description: '茶道（さどう/ちゃどう）は、抹茶を点てて客に振る舞う日本の伝統儀式であり総合芸術。千利休によって大成された「侘び茶」は、華美を削ぎ落とし、心の清澄と互いの敬意を重んじる精神文化です。',
    facts: [
      { label: '根本精神', value: '和敬清寂（わけいせいじゃく）' },
      { label: '大成者', value: '千利休（1522–1591）' },
      { label: '三千家', value: '表千家、裏千家、武者小路千家' },
      { label: '主たる道具', value: '茶碗、茶筅、茶杓、茶釜' },
    ],
    imageUrl: '/images/miyabi_tea_ceremony.jpg',
    sourceUrl: 'https://chadou-culture.jp',
    sourceName: '日本伝統工芸茶道振興会',
  },
  miyabi: {
    title: 'MIYABI（雅）',
    subtitle: '日本美学 · 次世代検索基盤',
    description: '「雅（みやび）」は、平安時代の宮廷文化に源流を持つ、上品で洗練された優美さを表す日本の伝統美意識。検索エンジンMIYABIは、この精神を受け継ぎ、不要な雑音を排した澄んだ情報発見の場を目指しています。',
    facts: [
      { label: '設立理念', value: '美しさを、見つける。' },
      { label: '設計拠点', value: '東京（Tokyo, Japan）' },
      { label: 'プライバシー', value: '完全ローカル履歴・追跡ゼロ' },
      { label: 'コア技術', value: '自然言語処理・文脈検索・Ma（余白）UI' },
    ],
    imageUrl: '/images/miyabi_tokyo_modern.jpg',
    sourceUrl: '/architecture',
    sourceName: 'MIYABI Platform Architecture',
  },
};

export class DemoSearchProvider implements ISearchProvider {
  async search(params: SearchQuery): Promise<SearchResponse> {
    const startTime = Date.now();
    const rawQuery = (params.query || '').trim();
    const queryLower = rawQuery.toLowerCase();
    const category = params.category || 'all';

    // Normalization: handles hiragana/katakana/kanji/romaji
    const cleanTokens = queryLower
      .split(/[\s,、。・\-_/]+/)
      .filter((t) => t.length > 0);

    // Filter results
    let matchedResults: SearchResult[] = [];
    if (cleanTokens.length === 0) {
      matchedResults = CORPUS_ALL.slice(0, 8);
    } else {
      matchedResults = CORPUS_ALL.filter((item) => {
        const fullText = (item.title + ' ' + item.snippet + ' ' + item.keywords.join(' ')).toLowerCase();
        return cleanTokens.some((token) => fullText.includes(token));
      });

      // If no exact token match, return best fallback matches rather than zero
      if (matchedResults.length === 0) {
        matchedResults = CORPUS_ALL.slice(0, 5);
      }
    }

    // Filter images
    let matchedImages = DEMO_IMAGES;
    if (cleanTokens.length > 0) {
      const imgMatches = DEMO_IMAGES.filter((img) => {
        const full = (img.title + ' ' + img.altText + ' ' + img.sourceDomain).toLowerCase();
        return cleanTokens.some((token) => full.includes(token));
      });
      if (imgMatches.length > 0) matchedImages = imgMatches;
    }

    // Filter news
    let matchedNews = DEMO_NEWS;
    if (params.regionFilter === 'jp') {
      matchedNews = matchedNews.filter((n) => n.isJapanese);
    }
    if (cleanTokens.length > 0) {
      const newsMatches = matchedNews.filter((n) => {
        const full = (n.headline + ' ' + n.summary + ' ' + n.publisher).toLowerCase();
        return cleanTokens.some((token) => full.includes(token));
      });
      if (newsMatches.length > 0) matchedNews = newsMatches;
    }

    // Filter places
    let matchedPlaces = DEMO_PLACES;
    if (cleanTokens.length > 0) {
      const placeMatches = DEMO_PLACES.filter((p) => {
        const full = (p.name + ' ' + p.japaneseName + ' ' + p.address + ' ' + p.summary).toLowerCase();
        return cleanTokens.some((token) => full.includes(token));
      });
      if (placeMatches.length > 0) matchedPlaces = placeMatches;
    }

    // Select knowledge card
    let knowledgeCard: KnowledgeCard | undefined = undefined;
    if (queryLower.includes('富士') || queryLower.includes('fuji')) {
      knowledgeCard = KNOWLEDGE_CARDS.fuji;
    } else if (queryLower.includes('京都') || queryLower.includes('kyoto') || queryLower.includes('禅') || queryLower.includes('zen')) {
      knowledgeCard = KNOWLEDGE_CARDS.kyoto;
    } else if (queryLower.includes('茶') || queryLower.includes('tea') || queryLower.includes('抹茶') || queryLower.includes('matcha')) {
      knowledgeCard = KNOWLEDGE_CARDS.tea;
    } else if (queryLower.includes('miyabi') || queryLower.includes('みやび') || queryLower.includes('雅')) {
      knowledgeCard = KNOWLEDGE_CARDS.miyabi;
    }

    // Related searches
    const relatedSearches = this.generateRelated(rawQuery);

    const tookMs = Math.max(12, Date.now() - startTime + Math.floor(Math.random() * 20));

    return {
      query: rawQuery,
      totalCount: matchedResults.length * 12400 + 4820,
      tookMs,
      results: matchedResults,
      images: matchedImages,
      news: matchedNews,
      places: matchedPlaces,
      knowledgeCard,
      relatedSearches,
      providerName: 'MIYABI Demonstration Index v2.8 (Tokyo)',
      page: params.page || 1,
      pageSize: params.pageSize || 10,
    };
  }

  async suggest(prefix: string, locale: string = 'ja'): Promise<string[]> {
    const p = prefix.trim().toLowerCase();
    if (!p) {
      return locale === 'en'
        ? ['Mount Fuji scenery', 'Kyoto zen gardens', 'Japanese matcha tea', 'Tokyo modern architecture', 'AI search technology']
        : ['富士山 ライブカメラ', '京都 枯山水 寺院', '茶道 道具 意味', '東京 現代建築 木造', '次世代 検索エンジン AI'];
    }

    const suggestionsBase = [
      '富士山 登山ルート',
      '富士山 河口湖 桜',
      '富士山 天気',
      '京都 観光 穴場',
      '京都 枯山水 庭園',
      '京都 和菓子 名店',
      '茶道 侘び寂び とは',
      '抹茶 点て方 初心者',
      '東京 建築 カフェ',
      '東京 銀座 散歩',
      'MIYABI 検索エンジン 仕様',
      'AI アシスタント 日本語',
      '日本 ロボティクス 技術',
      'グリーン水素 エネルギー',
      '書道 筆遣い 基本',
    ];

    const matches = suggestionsBase.filter((item) => item.toLowerCase().includes(p));
    if (matches.length > 0) return matches.slice(0, 6);

    // Fallback dynamic autocomplete
    return [
      `${prefix} 最新情報`,
      `${prefix} 歴史と特徴`,
      `${prefix} ガイド`,
      `${prefix} 写真 高画質`,
    ];
  }

  private generateRelated(query: string): string[] {
    if (!query) return ['日本の伝統美学', '富士山 絶景スポット', '京都 庭園巡り', '現代日本建築'];
    return [
      `${query} おすすめ`,
      `${query} 歴史`,
      `${query} 写真`,
      `${query} 2028 最新`,
      `${query} 英語 解説`,
    ];
  }
}
