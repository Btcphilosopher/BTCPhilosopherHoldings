'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';

export type Locale = 'ja' | 'en';

export interface Translations {
  brandName: string;
  brandTagline: string;
  brandSubline: string;
  brandPhilosophy: string;
  searchPlaceholder: string;
  searchAction: string;
  all: string;
  images: string;
  news: string;
  videos: string;
  maps: string;
  assistant: string;
  more: string;
  settings: string;
  architecture: string;
  about: string;
  shortcuts: {
    images: string;
    news: string;
    maps: string;
    assistant: string;
  };
  footerMotto: string;
  footerRights: string;
  resultsCount: (count: number, seconds: string) => string;
  noResultsTitle: string;
  noResultsDesc: string;
  demoProviderNotice: string;
  privacyNotice: string;
  clearHistory: string;
  historyEmpty: string;
  recentSearches: string;
  trendingTopics: string;
  aiOverview: string;
  aiSynthesizing: string;
  sources: string;
  filterTime: string;
  filterAllTime: string;
  filterPast24h: string;
  filterPastWeek: string;
  filterPastMonth: string;
  filterRegion: string;
  filterAllRegions: string;
  filterJapanOnly: string;
  backToTop: string;
}

const translations: Record<Locale, Translations> = {
  ja: {
    brandName: 'MIYABI',
    brandTagline: '美しさを、見つける。',
    brandSubline: 'A CLEARER TOMORROW THROUGH BETTER SEARCH',
    brandPhilosophy: '見つける美しさ、確かな答え。',
    searchPlaceholder: '何をお探しですか？',
    searchAction: '検索',
    all: 'すべて',
    images: '画像',
    news: 'ニュース',
    videos: '動画',
    maps: '地図',
    assistant: 'AIアシスタント',
    more: 'もっと見る',
    settings: '設定',
    architecture: 'アーキテクチャ仕様書',
    about: 'MIYABIについて',
    shortcuts: {
      images: '画像検索',
      news: 'ニュース',
      maps: '地図',
      assistant: 'AIアシスタント',
    },
    footerMotto: 'より良い\n未来のために',
    footerRights: '© 2028 MIYABI Search. Tokyo, Japan.',
    resultsCount: (count: number, seconds: string) => `約 ${count.toLocaleString('ja-JP')} 件 （${seconds} 秒）`,
    noResultsTitle: '該当する結果が見つかりませんでした',
    noResultsDesc: 'キーワードのスペルを確認するか、別の一般的な単語でお試しください。',
    demoProviderNotice: 'デモンストレーション・インデックス稼働中（外部検索API未接続時は高精度検証用インデックスを提供しています）',
    privacyNotice: 'MIYABIはユーザーの追跡を行いません。検索履歴はブラウザ端末内にのみ保存され、外部サーバへ送信されません。',
    clearHistory: '履歴を消去',
    historyEmpty: '検索履歴はありません',
    recentSearches: '最近の検索',
    trendingTopics: '注目の話題',
    aiOverview: 'MIYABI AI 要約',
    aiSynthesizing: '回答を生成中...',
    sources: '参照元',
    filterTime: '期間',
    filterAllTime: '指定なし',
    filterPast24h: '24時間以内',
    filterPastWeek: '1週間以内',
    filterPastMonth: '1か月以内',
    filterRegion: '地域',
    filterAllRegions: 'すべての地域',
    filterJapanOnly: '日本国内のみ',
    backToTop: 'ページ上部へ戻る',
  },
  en: {
    brandName: 'MIYABI',
    brandTagline: 'Discover beauty in truth.',
    brandSubline: 'A CLEARER TOMORROW THROUGH BETTER SEARCH',
    brandPhilosophy: 'Find beauty in what you discover.',
    searchPlaceholder: 'What are you searching for?',
    searchAction: 'Search',
    all: 'All',
    images: 'Images',
    news: 'News',
    videos: 'Videos',
    maps: 'Maps',
    assistant: 'AI Assistant',
    more: 'More',
    settings: 'Settings',
    architecture: 'Architecture Specs',
    about: 'About MIYABI',
    shortcuts: {
      images: 'Image Search',
      news: 'News',
      maps: 'Maps',
      assistant: 'AI Assistant',
    },
    footerMotto: 'For a better\ntomorrow',
    footerRights: '© 2028 MIYABI Search. Tokyo, Japan.',
    resultsCount: (count: number, seconds: string) => `About ${count.toLocaleString('en-US')} results (${seconds} seconds)`,
    noResultsTitle: 'No results found',
    noResultsDesc: 'Check your spelling or try different, more general keywords.',
    demoProviderNotice: 'Demonstration Index active (providing verified local search dataset when external API is unconfigured)',
    privacyNotice: 'MIYABI respects your privacy. Search history remains strictly inside your local browser storage.',
    clearHistory: 'Clear History',
    historyEmpty: 'No search history',
    recentSearches: 'Recent Searches',
    trendingTopics: 'Trending Topics',
    aiOverview: 'MIYABI AI Overview',
    aiSynthesizing: 'Synthesizing response...',
    sources: 'Sources',
    filterTime: 'Time',
    filterAllTime: 'Any time',
    filterPast24h: 'Past 24 hours',
    filterPastWeek: 'Past week',
    filterPastMonth: 'Past month',
    filterRegion: 'Region',
    filterAllRegions: 'All regions',
    filterJapanOnly: 'Japan only',
    backToTop: 'Back to top',
  },
};

interface LanguageContextType {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  t: Translations;
}

const LanguageContext = createContext<LanguageContextType>({
  locale: 'ja',
  setLocale: () => {},
  t: translations.ja,
});

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('miyabi_locale') as Locale;
        if (saved === 'ja' || saved === 'en') {
          return saved;
        }
      } catch {
        // Ignore
      }
    }
    return 'ja';
  });

  const setLocale = (newLocale: Locale) => {
    setLocaleState(newLocale);
    try {
      localStorage.setItem('miyabi_locale', newLocale);
      document.documentElement.lang = newLocale;
    } catch {
      // Ignore
    }
  };

  return (
    <LanguageContext.Provider
      value={{
        locale,
        setLocale,
        t: translations[locale],
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  return useContext(LanguageContext);
}
