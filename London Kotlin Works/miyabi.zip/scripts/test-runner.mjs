// MIYABI Search Engine - Comprehensive QA Test Runner
import assert from 'node:assert';
import fs from 'node:fs';
import path from 'node:path';

console.log('====================================================');
console.log('MIYABI (みやび) AUTOMATED TEST SUITE');
console.log('Testing 15 Essential System Behaviors (Section 17)');
console.log('====================================================\n');

let passedTests = 0;
let totalTests = 15;

function runTest(name, fn) {
  try {
    fn();
    console.log(`[PASS] ${name}`);
    passedTests++;
  } catch (err) {
    console.error(`[FAIL] ${name}`);
    console.error(`       Error: ${err.message}`);
  }
}

// 1. Homepage renders successfully
runTest('1. Homepage structure and components exist', () => {
  assert(fs.existsSync('app/page.tsx'), 'app/page.tsx must exist');
  const pageSrc = fs.readFileSync('app/page.tsx', 'utf8');
  assert(pageSrc.includes('美しさを、'), 'Homepage must contain Japanese headline');
  assert(pageSrc.includes('SearchBar'), 'Homepage must include SearchBar');
  assert(pageSrc.includes('QuickShortcuts'), 'Homepage must include QuickShortcuts');
  assert(pageSrc.includes('miyabi_fuji_landscape'), 'Homepage must include Fuji landscape');
});

// 2. Search field accepts text
runTest('2. Search field accepts text', () => {
  const barSrc = fs.readFileSync('components/SearchBar.tsx', 'utf8');
  assert(barSrc.includes('setQuery') && barSrc.includes('e.target.value'), 'Must handle text input change');
  assert(barSrc.includes('handleClear'), 'Must handle text clear action');
});

// 3. Pressing Enter submits a query
runTest('3. Pressing Enter submits a query', () => {
  const barSrc = fs.readFileSync('components/SearchBar.tsx', 'utf8');
  assert(barSrc.includes('handleSubmit'), 'Must handle form submission');
  assert(barSrc.includes('/search?q='), 'Submitting must navigate to /search?q=');
});

// 4. Search URLs preserve query parameters
runTest('4. Search URLs preserve query parameters across routes', () => {
  const searchSrc = fs.readFileSync('app/search/page.tsx', 'utf8');
  assert(searchSrc.includes("searchParams.get('q')"), 'Must extract q parameter from searchParams');
  assert(searchSrc.includes("searchParams.get('category')"), 'Must extract category parameter');
  assert(searchSrc.includes("searchParams.get('page')"), 'Must extract page parameter');
});

// 5. Search results render correctly & data provider
runTest('5. Search results interface and corpus indexing', () => {
  const demoSrc = fs.readFileSync('lib/search/demo-provider.ts', 'utf8');
  assert(demoSrc.includes('CORPUS_ALL'), 'Corpus must exist');
  assert(demoSrc.includes('DEMO_IMAGES'), 'Demonstration images must exist');
  assert(demoSrc.includes('DEMO_NEWS'), 'Demonstration news must exist');
  assert(demoSrc.includes('DEMO_PLACES'), 'Demonstration places must exist');
  assert(demoSrc.includes('KNOWLEDGE_CARDS'), 'Knowledge cards must exist');
});

// 6. Empty queries are handled safely
runTest('6. Empty queries are handled safely without exceptions', () => {
  const demoSrc = fs.readFileSync('lib/search/demo-provider.ts', 'utf8');
  assert(demoSrc.includes('cleanTokens.length === 0'), 'Must handle empty query branch');
});

// 7. API failures produce useful messages
runTest('7. API route error handling produces safe messages', () => {
  const apiSrc = fs.readFileSync('app/api/search/route.ts', 'utf8');
  assert(apiSrc.includes('catch (error)'), 'Search API must have try-catch block');
  assert(apiSrc.includes('status: 500'), 'Must return 500 status on internal failure');
});

// 8. Navigation links work
runTest('8. Navigation links exist and point to valid destinations', () => {
  const headerSrc = fs.readFileSync('components/Header.tsx', 'utf8');
  assert(headerSrc.includes('href="/images"'), 'Images link must exist');
  assert(headerSrc.includes('href="/news"'), 'News link must exist');
  assert(headerSrc.includes('href="/maps"'), 'Maps link must exist');
  assert(headerSrc.includes('href="/assistant"'), 'Assistant link must exist');
  assert(headerSrc.includes('href="/settings"'), 'Settings link must exist');
});

// 9. Language switching works
runTest('9. Language switching supports Japanese and English with persistence', () => {
  const i18nSrc = fs.readFileSync('lib/i18n.tsx', 'utf8');
  assert(i18nSrc.includes("'ja'") && i18nSrc.includes("'en'"), 'Must support ja and en locales');
  assert(i18nSrc.includes('localStorage.setItem'), 'Must persist language choice');
  const footerSrc = fs.readFileSync('components/Footer.tsx', 'utf8');
  assert(footerSrc.includes("locale === 'ja'"), 'Footer must switch between Japanese and English');
});

// 10. Mobile layout does not overflow
runTest('10. Mobile layout safety and responsive overflow handling', () => {
  const homeSrc = fs.readFileSync('app/page.tsx', 'utf8');
  assert(homeSrc.includes('overflow-x-hidden'), 'Main wrapper must prevent horizontal overflow');
  const headerSrc = fs.readFileSync('components/Header.tsx', 'utf8');
  assert(headerSrc.includes('mobileMenuOpen'), 'Mobile drawer must exist');
});

// 11. Search suggestions support keyboard navigation
runTest('11. Search suggestions support ArrowDown, ArrowUp, and Escape', () => {
  const barSrc = fs.readFileSync('components/SearchBar.tsx', 'utf8');
  assert(barSrc.includes("e.key === 'ArrowDown'"), 'Must handle ArrowDown');
  assert(barSrc.includes("e.key === 'ArrowUp'"), 'Must handle ArrowUp');
  assert(barSrc.includes("e.key === 'Escape'"), 'Must handle Escape');
});

// 12. API credentials are not exposed to the browser
runTest('12. API credentials security verification (server-side only)', () => {
  const envExample = fs.readFileSync('.env.example', 'utf8');
  assert(!envExample.includes('NEXT_PUBLIC_GEMINI_API_KEY'), 'Gemini API key must NOT have NEXT_PUBLIC_ prefix');
  const clientSrcs = ['components/SearchBar.tsx', 'components/Header.tsx', 'app/page.tsx', 'app/search/page.tsx'];
  for (const file of clientSrcs) {
    const content = fs.readFileSync(file, 'utf8');
    assert(!content.includes('process.env.GEMINI_API_KEY'), `Client component ${file} must never access GEMINI_API_KEY directly`);
  }
});

// 13. Search provider responses are validated
runTest('13. Search provider schema adheres to SearchResponse types', () => {
  const typesSrc = fs.readFileSync('lib/search/types.ts', 'utf8');
  assert(typesSrc.includes('export interface SearchResponse'), 'SearchResponse interface defined');
  assert(typesSrc.includes('totalCount: number'), 'totalCount must be number');
  assert(typesSrc.includes('tookMs: number'), 'tookMs must be number');
});

// 14. History can be cleared
runTest('14. Search history manager allows clearing and individual removal', () => {
  const histSrc = fs.readFileSync('lib/history.ts', 'utf8');
  assert(histSrc.includes('clear()'), 'clear method must exist');
  assert(histSrc.includes('remove(query: string)'), 'remove method must exist');
  assert(histSrc.includes('removeItem(HISTORY_KEY)'), 'Must clear localStorage key');
});

// 15. Direct navigation to a results URL works
runTest('15. Direct navigation to search results handles query parsing safely', () => {
  const searchPage = fs.readFileSync('app/search/page.tsx', 'utf8');
  assert(searchPage.includes('<Suspense'), 'Search page must wrap dynamic params in Suspense');
  assert(searchPage.includes('fetchResults'), 'Must execute query on mount');
});

console.log('\n----------------------------------------------------');
console.log(`Results: ${passedTests} / ${totalTests} test suites passed.`);
console.log('----------------------------------------------------');

if (passedTests === totalTests) {
  process.exit(0);
} else {
  process.exit(1);
}
