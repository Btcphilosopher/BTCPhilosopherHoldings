'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname, useSearchParams } from 'next/navigation';
import { Search, Image as ImageIcon, Newspaper, Video, MapPin } from 'lucide-react';
import { useLanguage } from '@/lib/i18n';

interface SearchTabsProps {
  currentCategory?: string;
  query?: string;
}

export function SearchTabs({ currentCategory = 'all', query = '' }: SearchTabsProps) {
  const { t } = useLanguage();
  const searchParams = useSearchParams();
  const currentQuery = query || searchParams.get('q') || '';

  const createUrl = (path: string) => {
    return currentQuery ? `${path}?q=${encodeURIComponent(currentQuery)}` : path;
  };

  const tabs = [
    { id: 'all', label: t.all, href: createUrl('/search'), icon: Search },
    { id: 'images', label: t.images, href: createUrl('/images'), icon: ImageIcon },
    { id: 'news', label: t.news, href: createUrl('/news'), icon: Newspaper },
    { id: 'videos', label: t.videos, href: createUrl('/search?category=videos'), icon: Video },
    { id: 'maps', label: t.maps, href: createUrl('/maps'), icon: MapPin },
  ];

  return (
    <div className="w-full border-b border-[#E5E2DA] bg-[#F7F5F1]">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 flex items-center gap-6 sm:gap-8 overflow-x-auto no-scrollbar">
        {tabs.map((tab) => {
          const isActive = currentCategory === tab.id;
          const Icon = tab.icon;
          return (
            <Link
              key={tab.id}
              href={tab.href}
              className={`flex items-center gap-2 py-3 text-sm whitespace-nowrap transition-colors relative font-medium ${
                isActive ? 'text-[#171717]' : 'text-[#85827D] hover:text-[#171717]'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-[#D94132]' : 'text-[#85827D]'}`} />
              <span>{tab.label}</span>
              {isActive && (
                <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#D94132]" />
              )}
            </Link>
          );
        })}
      </div>
    </div>
  );
}
