'use client';

import React from 'react';
import Image from 'next/image';
import { ExternalLink } from 'lucide-react';
import { KnowledgeCard } from '@/lib/search/types';

interface KnowledgePanelProps {
  data: KnowledgeCard;
}

export function KnowledgePanel({ data }: KnowledgePanelProps) {
  return (
    <aside className="w-full lg:w-80 shrink-0 bg-white rounded-xl border border-[#E5E2DA] p-5 shadow-xs mb-6 lg:mb-0">
      {data.imageUrl && (
        <div className="relative w-full h-44 rounded-lg overflow-hidden mb-4 bg-[#F0EEE8]">
          <Image
            src={data.imageUrl}
            alt={data.title}
            fill
            sizes="(max-width: 768px) 100vw, 320px"
            referrerPolicy="no-referrer"
            className="object-cover"
          />
        </div>
      )}

      <div className="space-y-1 mb-3">
        <h2 className="text-xl font-serif font-medium text-[#171717]">{data.title}</h2>
        <p className="text-xs text-[#85827D] font-medium tracking-wide">{data.subtitle}</p>
      </div>

      <p className="text-xs text-[#504E4A] leading-relaxed mb-4">
        {data.description}
      </p>

      {/* Facts Table with Tabular Numerals */}
      <div className="border-t border-[#F0EEE8] pt-3 mb-4">
        <dl className="divide-y divide-[#F0EEE8]">
          {data.facts.map((fact, idx) => (
            <div key={idx} className="py-2 flex justify-between items-baseline gap-2 text-xs">
              <dt className="text-[#85827D] shrink-0">{fact.label}</dt>
              <dd className="text-[#171717] font-medium text-right tabular-nums truncate">
                {fact.value}
              </dd>
            </div>
          ))}
        </dl>
      </div>

      {/* Source Citation */}
      <div className="border-t border-[#F0EEE8] pt-3 flex items-center justify-between text-[11px] text-[#85827D]">
        <span className="truncate">{data.sourceName}</span>
        <a
          href={data.sourceUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1 text-[#D94132] hover:underline shrink-0"
        >
          <span>詳細</span>
          <ExternalLink className="w-3 h-3" />
        </a>
      </div>
    </aside>
  );
}
