'use client';

import React, { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { ChevronDown, Menu, X, MapPin, Sparkles, Settings, FileCode, Info } from 'lucide-react';
import { MiyabiLogo } from './MiyabiLogo';
import { useLanguage } from '@/lib/i18n';

interface HeaderProps {
  compact?: boolean;
}

export function Header({ compact = false }: HeaderProps) {
  const { t } = useLanguage();
  const pathname = usePathname();
  const [moreOpen, setMoreOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setMoreOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Determine active tab
  const isSearchActive = pathname === '/' || pathname.startsWith('/search');
  const isImagesActive = pathname.startsWith('/images');
  const isNewsActive = pathname.startsWith('/news');
  const isMapsActive = pathname.startsWith('/maps');
  const isAssistantActive = pathname.startsWith('/assistant');

  return (
    <header className="relative w-full z-40 bg-transparent">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-5 flex items-center justify-between">
        {/* Left: Brand Identity */}
        <MiyabiLogo compact={compact} />

        {/* Right: Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-7 lg:gap-9 text-sm text-[#171717]" aria-label="Main Navigation">
          {/* Search */}
          <Link
            href="/"
            className={`relative py-1.5 transition-colors hover:text-[#D94132] ${
              isSearchActive ? 'font-medium text-[#171717]' : 'text-[#504E4A]'
            }`}
          >
            {t.searchAction}
            {isSearchActive && (
              <span className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-[#D94132]" />
            )}
          </Link>

          {/* Images */}
          <Link
            href="/images"
            className={`relative py-1.5 transition-colors hover:text-[#D94132] ${
              isImagesActive ? 'font-medium text-[#171717]' : 'text-[#504E4A]'
            }`}
          >
            {t.images}
            {isImagesActive && (
              <span className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-[#D94132]" />
            )}
          </Link>

          {/* News */}
          <Link
            href="/news"
            className={`relative py-1.5 transition-colors hover:text-[#D94132] ${
              isNewsActive ? 'font-medium text-[#171717]' : 'text-[#504E4A]'
            }`}
          >
            {t.news}
            {isNewsActive && (
              <span className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-[#D94132]" />
            )}
          </Link>

          {/* More Dropdown */}
          <div className="relative" ref={dropdownRef}>
            <button
              onClick={() => setMoreOpen(!moreOpen)}
              className={`flex items-center gap-1 py-1.5 transition-colors hover:text-[#D94132] focus:outline-none ${
                isMapsActive || isAssistantActive || moreOpen ? 'text-[#171717] font-medium' : 'text-[#504E4A]'
              }`}
              aria-expanded={moreOpen}
              aria-haspopup="true"
            >
              <span>{t.more}</span>
              <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${moreOpen ? 'rotate-180 text-[#D94132]' : 'text-[#85827D]'}`} />
            </button>

            {/* Dropdown Menu */}
            {moreOpen && (
              <div className="absolute right-0 mt-2 w-56 py-2 bg-white rounded-lg shadow-lg border border-[#E5E2DA] divide-y divide-[#F0EEE8] animate-in fade-in-50 zoom-in-95 duration-150 z-50">
                <div className="py-1">
                  <Link
                    href="/maps"
                    onClick={() => setMoreOpen(false)}
                    className="flex items-center gap-3 px-4 py-2 text-sm text-[#171717] hover:bg-[#F7F5F1] transition-colors"
                  >
                    <MapPin className="w-4 h-4 text-[#85827D]" />
                    <span>{t.maps}</span>
                  </Link>
                  <Link
                    href="/assistant"
                    onClick={() => setMoreOpen(false)}
                    className="flex items-center gap-3 px-4 py-2 text-sm text-[#171717] hover:bg-[#F7F5F1] transition-colors"
                  >
                    <Sparkles className="w-4 h-4 text-[#D94132]" />
                    <span>{t.assistant}</span>
                  </Link>
                </div>

                <div className="py-1">
                  <Link
                    href="/settings"
                    onClick={() => setMoreOpen(false)}
                    className="flex items-center gap-3 px-4 py-2 text-sm text-[#171717] hover:bg-[#F7F5F1] transition-colors"
                  >
                    <Settings className="w-4 h-4 text-[#85827D]" />
                    <span>{t.settings}</span>
                  </Link>
                  <Link
                    href="/settings#architecture"
                    onClick={() => setMoreOpen(false)}
                    className="flex items-center gap-3 px-4 py-2 text-sm text-[#171717] hover:bg-[#F7F5F1] transition-colors"
                  >
                    <FileCode className="w-4 h-4 text-[#85827D]" />
                    <span>{t.architecture}</span>
                  </Link>
                  <Link
                    href="/settings#about"
                    onClick={() => setMoreOpen(false)}
                    className="flex items-center gap-3 px-4 py-2 text-sm text-[#171717] hover:bg-[#F7F5F1] transition-colors"
                  >
                    <Info className="w-4 h-4 text-[#85827D]" />
                    <span>{t.about}</span>
                  </Link>
                </div>
              </div>
            )}
          </div>

          {/* Quick Menu Toggle Icon */}
          <button
            onClick={() => setMobileMenuOpen(true)}
            className="p-1 text-[#171717] hover:text-[#D94132] transition-colors focus:outline-none"
            aria-label="すべてのメニューを開く"
          >
            <Menu className="w-5 h-5 stroke-[1.75]" />
          </button>
        </nav>

        {/* Mobile Hamburger Button */}
        <div className="flex md:hidden items-center gap-3">
          <button
            onClick={() => setMobileMenuOpen(true)}
            className="p-2 text-[#171717] hover:text-[#D94132] transition-colors"
            aria-label="メニュー"
          >
            <Menu className="w-6 h-6 stroke-[1.75]" />
          </button>
        </div>
      </div>

      {/* Mobile Slide-out Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/30 backdrop-blur-xs animate-in fade-in">
          <div className="w-4/5 max-w-sm h-full bg-[#F7F5F1] shadow-2xl p-6 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-6 border-b border-[#E5E2DA]">
                <MiyabiLogo compact />
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-2 text-[#85827D] hover:text-[#171717]"
                  aria-label="メニューを閉じる"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <nav className="mt-6 flex flex-col gap-3">
                <Link
                  href="/"
                  onClick={() => setMobileMenuOpen(false)}
                  className="px-3 py-2.5 rounded-lg text-base font-medium text-[#171717] hover:bg-[#E5E2DA]/40"
                >
                  {t.searchAction}
                </Link>
                <Link
                  href="/images"
                  onClick={() => setMobileMenuOpen(false)}
                  className="px-3 py-2.5 rounded-lg text-base font-medium text-[#171717] hover:bg-[#E5E2DA]/40"
                >
                  {t.images}
                </Link>
                <Link
                  href="/news"
                  onClick={() => setMobileMenuOpen(false)}
                  className="px-3 py-2.5 rounded-lg text-base font-medium text-[#171717] hover:bg-[#E5E2DA]/40"
                >
                  {t.news}
                </Link>
                <Link
                  href="/maps"
                  onClick={() => setMobileMenuOpen(false)}
                  className="px-3 py-2.5 rounded-lg text-base font-medium text-[#171717] hover:bg-[#E5E2DA]/40"
                >
                  {t.maps}
                </Link>
                <Link
                  href="/assistant"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center gap-2 px-3 py-2.5 rounded-lg text-base font-medium text-[#D94132] hover:bg-[#D94132]/10"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{t.assistant}</span>
                </Link>
                <Link
                  href="/settings"
                  onClick={() => setMobileMenuOpen(false)}
                  className="px-3 py-2.5 rounded-lg text-base text-[#504E4A] hover:bg-[#E5E2DA]/40"
                >
                  {t.settings}
                </Link>
              </nav>
            </div>

            <div className="pt-6 border-t border-[#E5E2DA] text-xs text-[#85827D] leading-relaxed">
              <p>{t.footerMotto.replace('\n', ' ')}</p>
              <p className="mt-1">MIYABI Search Engine 2028</p>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
