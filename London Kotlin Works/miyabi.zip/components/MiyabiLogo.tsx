'use client';

import React from 'react';
import Link from 'next/link';

interface MiyabiLogoProps {
  compact?: boolean;
  className?: string;
}

export function MiyabiLogo({ compact = false, className = '' }: MiyabiLogoProps) {
  return (
    <Link
      href="/"
      className={`inline-flex items-center gap-3 group focus:outline-none focus-visible:ring-2 focus-visible:ring-[#D94132] rounded-md transition-opacity hover:opacity-90 ${className}`}
      aria-label="MIYABI ホーム"
    >
      {/* Circular Vermilion Symbol with Stylized Fuji Crest */}
      <div className={`relative flex items-center justify-center shrink-0 rounded-full bg-[#D94132] shadow-sm transition-transform duration-300 group-hover:scale-[1.03] ${compact ? 'w-7 h-7' : 'w-9 h-9'}`}>
        <svg
          viewBox="0 0 36 36"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full p-[6px]"
          aria-hidden="true"
        >
          {/* Stylized snow-capped mountain silhouette inspired by Mount Fuji */}
          <path
            d="M18 7L9 25H27L18 7Z"
            fill="white"
            fillOpacity="0.95"
          />
          {/* Subtle snow cap cut */}
          <path
            d="M18 7L14.5 14C15.8 13.2 16.9 14.2 18 13.5C19.1 14.2 20.2 13.2 21.5 14L18 7Z"
            fill="#D94132"
          />
          {/* Base mist curve */}
          <path
            d="M7 27C11 26 15 27.5 18 26.5C21 27.5 25 26 29 27"
            stroke="white"
            strokeWidth="1.2"
            strokeLinecap="round"
          />
        </svg>
      </div>

      {/* Brand Typography */}
      <div className="flex items-baseline gap-3">
        <span
          className={`font-semibold tracking-[0.28em] text-[#171717] uppercase select-none ${
            compact ? 'text-base' : 'text-lg md:text-xl'
          }`}
          style={{ letterSpacing: '0.28em' }}
        >
          MIYABI
        </span>
        <span
          className={`font-normal text-[#85827D] tracking-wider select-none ${
            compact ? 'text-xs' : 'text-sm'
          }`}
        >
          みやび
        </span>
      </div>
    </Link>
  );
}
