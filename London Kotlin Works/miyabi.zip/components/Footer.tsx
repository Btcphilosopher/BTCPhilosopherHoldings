'use client';

import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown, Check } from 'lucide-react';
import { useLanguage, Locale } from '@/lib/i18n';

export function Footer() {
  const { t, locale, setLocale } = useLanguage();
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const langRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (langRef.current && !langRef.current.contains(event.target as Node)) {
        setLangMenuOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectLanguage = (newLocale: Locale) => {
    setLocale(newLocale);
    setLangMenuOpen(false);
  };

  return (
    <footer className="relative w-full z-30 select-none pb-6 pt-4">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 flex items-end justify-between">
        {/* Bottom-left Japanese Statement */}
        <div className="flex items-start gap-3">
          <div className="w-[1.5px] h-9 bg-[#171717]/40 shrink-0 mt-0.5" />
          <div className="text-xs text-[#504E4A] font-light leading-snug tracking-wider">
            {locale === 'ja' ? (
              <>
                <div>より良い</div>
                <div>未来のために</div>
              </>
            ) : (
              <>
                <div>For a better</div>
                <div>tomorrow</div>
              </>
            )}
          </div>
        </div>

        {/* Bottom-right Language Selector */}
        <div className="relative" ref={langRef}>
          <button
            onClick={() => setLangMenuOpen(!langMenuOpen)}
            className="flex items-center gap-1.5 py-1 px-2 text-xs text-[#504E4A] hover:text-[#171717] transition-colors focus:outline-none focus-visible:ring-1 focus-visible:ring-[#D94132] rounded"
            aria-expanded={langMenuOpen}
            aria-haspopup="listbox"
          >
            <span>{locale === 'ja' ? '日本語' : 'English'}</span>
            <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${langMenuOpen ? 'rotate-180 text-[#D94132]' : 'text-[#85827D]'}`} />
          </button>

          {/* Language Menu */}
          {langMenuOpen && (
            <div
              className="absolute right-0 bottom-full mb-2 w-36 bg-white rounded-lg shadow-lg border border-[#E5E2DA] py-1 z-50 text-xs animate-in fade-in-50 zoom-in-95 duration-100"
              role="listbox"
            >
              <button
                type="button"
                onClick={() => handleSelectLanguage('ja')}
                className={`w-full flex items-center justify-between px-3 py-2 text-left hover:bg-[#F7F5F1] transition-colors ${
                  locale === 'ja' ? 'font-medium text-[#D94132]' : 'text-[#171717]'
                }`}
                role="option"
                aria-selected={locale === 'ja'}
              >
                <span>日本語 (Japanese)</span>
                {locale === 'ja' && <Check className="w-3.5 h-3.5 text-[#D94132]" />}
              </button>
              <button
                type="button"
                onClick={() => handleSelectLanguage('en')}
                className={`w-full flex items-center justify-between px-3 py-2 text-left hover:bg-[#F7F5F1] transition-colors ${
                  locale === 'en' ? 'font-medium text-[#D94132]' : 'text-[#171717]'
                }`}
                role="option"
                aria-selected={locale === 'en'}
              >
                <span>English</span>
                {locale === 'en' && <Check className="w-3.5 h-3.5 text-[#D94132]" />}
              </button>
            </div>
          )}
        </div>
      </div>
    </footer>
  );
}
