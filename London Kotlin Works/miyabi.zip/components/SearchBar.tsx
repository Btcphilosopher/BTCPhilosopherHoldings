'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { Search, ArrowRight, X, Clock, Trash2 } from 'lucide-react';
import { searchHistory } from '@/lib/history';
import { useLanguage } from '@/lib/i18n';

interface SearchBarProps {
  initialQuery?: string;
  variant?: 'hero' | 'compact';
  autoFocus?: boolean;
  onSearchSubmit?: (query: string) => void;
  className?: string;
}

export function SearchBar({
  initialQuery = '',
  variant = 'hero',
  autoFocus = false,
  onSearchSubmit,
  className = '',
}: SearchBarProps) {
  const router = useRouter();
  const { t, locale } = useLanguage();
  const [query, setQuery] = useState(initialQuery);
  const [prevInitial, setPrevInitial] = useState(initialQuery);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [historyItems, setHistoryItems] = useState<string[]>(() => searchHistory.get());
  const [isOpen, setIsOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState<number>(-1);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Sync initial query when prop changes without cascading renders
  if (initialQuery !== prevInitial) {
    setPrevInitial(initialQuery);
    setQuery(initialQuery);
  }

  // Fetch suggestions when query changes
  useEffect(() => {
    const trimmed = query.trim();
    if (!trimmed) return;

    const timer = setTimeout(async () => {
      try {
        const res = await fetch(`/api/suggest?q=${encodeURIComponent(trimmed)}&locale=${locale}`);
        if (res.ok) {
          const data = await res.json();
          setSuggestions(data.suggestions || []);
        }
      } catch {
        // Fallback
      }
    }, 150);

    return () => clearTimeout(timer);
  }, [query, locale]);

  // Click outside listener
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const executeSearch = (targetQuery: string) => {
    const q = targetQuery.trim();
    if (!q) return;

    searchHistory.add(q);
    setHistoryItems(searchHistory.get());
    setIsOpen(false);

    if (onSearchSubmit) {
      onSearchSubmit(q);
    } else {
      router.push(`/search?q=${encodeURIComponent(q)}`);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedIndex >= 0) {
      const allItems = query.trim() ? suggestions : historyItems;
      if (allItems[selectedIndex]) {
        executeSearch(allItems[selectedIndex]);
        return;
      }
    }
    executeSearch(query);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    const activeList = query.trim() ? suggestions : historyItems;
    if (!isOpen || activeList.length === 0) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev < activeList.length - 1 ? prev + 1 : 0));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev > 0 ? prev - 1 : activeList.length - 1));
    } else if (e.key === 'Escape') {
      setIsOpen(false);
      setSelectedIndex(-1);
    }
  };

  const handleClear = () => {
    setQuery('');
    setSuggestions([]);
    inputRef.current?.focus();
  };

  const handleRemoveHistory = (e: React.MouseEvent, item: string) => {
    e.stopPropagation();
    searchHistory.remove(item);
    setHistoryItems(searchHistory.get());
  };

  const handleClearAllHistory = (e: React.MouseEvent) => {
    e.stopPropagation();
    searchHistory.clear();
    setHistoryItems([]);
  };

  const isHero = variant === 'hero';

  return (
    <div
      ref={containerRef}
      className={`relative w-full ${isHero ? 'max-w-2xl' : 'max-w-xl'} ${className}`}
    >
      <form
        onSubmit={handleSubmit}
        role="search"
        className={`relative flex items-center w-full transition-all duration-200 bg-white rounded-full ${
          isHero
            ? 'h-14 sm:h-16 px-5 sm:px-6 shadow-[0_2px_18px_rgba(0,0,0,0.06)] border border-[#E5E2DA] focus-within:border-[#D94132]/60 focus-within:shadow-[0_4px_24px_rgba(217,65,50,0.08)]'
            : 'h-11 sm:h-12 px-4 shadow-xs border border-[#E5E2DA] focus-within:border-[#D94132]/60'
        }`}
      >
        {/* Search Icon */}
        <Search
          className={`shrink-0 text-[#85827D] ${
            isHero ? 'w-5 h-5 sm:w-5 sm:h-5' : 'w-4 h-4'
          } stroke-[1.8]`}
          aria-hidden="true"
        />

        {/* Input */}
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => {
            const val = e.target.value;
            setQuery(val);
            setSelectedIndex(-1);
            if (!val.trim()) {
              setSuggestions([]);
            }
            if (!isOpen) setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          onKeyDown={handleKeyDown}
          autoFocus={autoFocus}
          placeholder={t.searchPlaceholder}
          aria-label={t.searchPlaceholder}
          aria-autocomplete="list"
          className={`w-full bg-transparent border-none outline-none font-sans text-[#171717] placeholder:text-[#9C9993] ${
            isHero ? 'px-3 sm:px-4 text-base sm:text-lg' : 'px-2.5 text-sm sm:text-base'
          }`}
        />

        {/* Clear Button */}
        {query && (
          <button
            type="button"
            onClick={handleClear}
            className="p-1 mr-1 text-[#9C9993] hover:text-[#171717] transition-colors rounded-full focus:outline-none"
            aria-label="検索語句を消去"
          >
            <X className="w-4 h-4" />
          </button>
        )}

        {/* Submit Arrow Button */}
        <button
          type="submit"
          className={`shrink-0 flex items-center justify-center rounded-full text-[#171717] hover:text-[#D94132] hover:bg-[#F7F5F1] transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-[#D94132] ${
            isHero ? 'w-10 h-10 -mr-2 sm:-mr-2' : 'w-8 h-8 -mr-1'
          }`}
          aria-label={t.searchAction}
        >
          <ArrowRight className={`${isHero ? 'w-5 h-5' : 'w-4 h-4'} stroke-[2]`} />
        </button>
      </form>

      {/* Autocomplete / History Dropdown */}
      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-xl border border-[#E5E2DA] overflow-hidden z-50 animate-in fade-in-50 zoom-in-98 duration-100 divide-y divide-[#F0EEE8]">
          {/* Active Suggestions */}
          {query.trim() && suggestions.length > 0 && (
            <ul className="py-2" role="listbox">
              {suggestions.map((item, idx) => (
                <li
                  key={`sug-${idx}`}
                  role="option"
                  aria-selected={selectedIndex === idx}
                  onClick={() => executeSearch(item)}
                  className={`flex items-center gap-3 px-5 py-2.5 cursor-pointer text-sm transition-colors ${
                    selectedIndex === idx ? 'bg-[#F7F5F1] text-[#D94132]' : 'text-[#171717] hover:bg-[#F7F5F1]'
                  }`}
                >
                  <Search className="w-4 h-4 text-[#85827D] shrink-0" />
                  <span className="truncate">{item}</span>
                </li>
              ))}
            </ul>
          )}

          {/* Search History when query is empty */}
          {!query.trim() && historyItems.length > 0 && (
            <div className="py-2">
              <div className="flex items-center justify-between px-5 py-1.5 text-xs text-[#85827D] font-medium">
                <span>{t.recentSearches}</span>
                <button
                  type="button"
                  onClick={handleClearAllHistory}
                  className="hover:text-[#D94132] flex items-center gap-1 transition-colors"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>{t.clearHistory}</span>
                </button>
              </div>
              <ul role="listbox">
                {historyItems.map((item, idx) => (
                  <li
                    key={`hist-${idx}`}
                    role="option"
                    aria-selected={selectedIndex === idx}
                    onClick={() => executeSearch(item)}
                    className={`flex items-center justify-between px-5 py-2.5 cursor-pointer text-sm transition-colors ${
                      selectedIndex === idx ? 'bg-[#F7F5F1] text-[#D94132]' : 'text-[#171717] hover:bg-[#F7F5F1]'
                    }`}
                  >
                    <div className="flex items-center gap-3 truncate">
                      <Clock className="w-4 h-4 text-[#85827D] shrink-0" />
                      <span className="truncate">{item}</span>
                    </div>
                    <button
                      type="button"
                      onClick={(e) => handleRemoveHistory(e, item)}
                      className="p-1 text-[#85827D] hover:text-[#D94132] transition-colors"
                      aria-label={`${item}を履歴から削除`}
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Quick Trending Suggestions when empty and no history */}
          {!query.trim() && historyItems.length === 0 && (
            <div className="py-3 px-5 text-sm text-[#85827D]">
              <p className="text-xs font-medium uppercase tracking-wider text-[#9C9993] mb-2">
                {t.trendingTopics}
              </p>
              <div className="flex flex-wrap gap-2">
                {['富士山', '京都 庭園', '茶道 侘び寂び', '東京 建築', 'AI アシスタント'].map((topic) => (
                  <button
                    key={topic}
                    type="button"
                    onClick={() => executeSearch(topic)}
                    className="px-3 py-1 bg-[#F7F5F1] hover:bg-[#E5E2DA] text-[#171717] text-xs rounded-full transition-colors"
                  >
                    {topic}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
