'use client';

import React from 'react';
import Link from 'next/link';
import { Image as ImageIcon, Newspaper, MapPin, Sparkles } from 'lucide-react';
import { useLanguage } from '@/lib/i18n';

export function QuickShortcuts() {
  const { t } = useLanguage();

  const shortcuts = [
    {
      title: t.shortcuts.images,
      href: '/images',
      icon: ImageIcon,
    },
    {
      title: t.shortcuts.news,
      href: '/news',
      icon: Newspaper,
    },
    {
      title: t.shortcuts.maps,
      href: '/maps',
      icon: MapPin,
    },
    {
      title: t.shortcuts.assistant,
      href: '/assistant',
      icon: Sparkles,
      highlight: true,
    },
  ];

  return (
    <nav
      className="flex items-center justify-center gap-7 sm:gap-11 mt-7 select-none"
      aria-label="クイックアクセス"
    >
      {shortcuts.map((item) => {
        const IconComponent = item.icon;
        return (
          <Link
            key={item.href}
            href={item.href}
            className="group flex flex-col items-center gap-2 text-center focus:outline-none focus-visible:ring-2 focus-visible:ring-[#D94132] rounded-lg p-1.5 transition-transform duration-200 hover:-translate-y-0.5"
          >
            <div className="w-10 h-10 flex items-center justify-center rounded-lg text-[#171717] transition-colors group-hover:text-[#D94132]">
              <IconComponent className="w-5 h-5 stroke-[1.5]" />
            </div>
            <span className="text-xs text-[#504E4A] font-medium tracking-wide transition-colors group-hover:text-[#D94132] whitespace-nowrap">
              {item.title}
            </span>
          </Link>
        );
      })}
    </nav>
  );
}
