'use client';

import React from 'react';
import Image from 'next/image';
import { Header } from '@/components/Header';
import { SearchBar } from '@/components/SearchBar';
import { QuickShortcuts } from '@/components/QuickShortcuts';
import { Footer } from '@/components/Footer';
import { useLanguage } from '@/lib/i18n';

export default function HomePage() {
  const { t, locale } = useLanguage();

  return (
    <main className="relative min-h-screen flex flex-col justify-between overflow-x-hidden bg-[#F7F5F1]">
      {/* Top Navigation */}
      <Header />

      {/* Main Hero Section */}
      <div className="relative z-20 flex-1 flex flex-col items-center justify-center px-4 pt-4 sm:pt-8 pb-32 sm:pb-40 text-center">
        {/* Soft Circular Japanese Moon Backing (subtle motif as in mockup) */}
        <div
          className="absolute -top-12 left-1/2 -translate-x-[60%] w-[380px] h-[380px] sm:w-[560px] sm:h-[560px] md:w-[680px] md:h-[680px] rounded-full bg-white/40 pointer-events-none blur-2xl -z-10"
          aria-hidden="true"
        />

        {/* Central Japanese Headline */}
        <div className="max-w-3xl mx-auto space-y-4 mb-7 sm:mb-9">
          <h1 className="font-serif text-3xl sm:text-5xl md:text-6xl font-light tracking-[0.16em] text-[#171717] leading-[1.35] select-none text-balance">
            {locale === 'ja' ? (
              <>
                美しさを、<br />
                見つける。
              </>
            ) : (
              <>
                Find beauty in<br />
                what you discover.
              </>
            )}
          </h1>

          <p className="text-[11px] sm:text-xs tracking-[0.24em] sm:tracking-[0.28em] text-[#85827D] uppercase font-medium select-none pt-1">
            {t.brandSubline}
          </p>
        </div>

        {/* Pill Search Field */}
        <div className="w-full flex justify-center px-2">
          <SearchBar variant="hero" autoFocus />
        </div>

        {/* 4 Minimalist Shortcuts */}
        <QuickShortcuts />
      </div>

      {/* Panoramic Japanese Landscape (Mount Fuji, Lake Kawaguchi & Sakura Blossoms) */}
      <div className="absolute inset-x-0 bottom-0 h-[48vh] sm:h-[54vh] md:h-[58vh] lg:h-[62vh] pointer-events-none z-10 overflow-hidden">
        {/* Subtle top fade to blend smoothly into the warm porcelain canvas */}
        <div className="absolute inset-0 z-10 bg-gradient-to-t from-transparent via-[#F7F5F1]/15 to-[#F7F5F1]" />
        
        {/* Left soft radial mask for seamless sakura branch integration */}
        <div className="absolute top-0 left-0 bottom-0 w-1/3 z-10 bg-gradient-to-r from-[#F7F5F1]/40 to-transparent" />

        <div className="relative w-full h-full">
          <Image
            src="/images/miyabi_fuji_landscape.jpg"
            alt="雪を戴く富士山と河口湖、春の満開の桜"
            fill
            priority
            sizes="100vw"
            referrerPolicy="no-referrer"
            className="object-cover object-[center_68%] opacity-95"
          />
        </div>
      </div>

      {/* Understated Editorial Footer */}
      <Footer />
    </main>
  );
}
