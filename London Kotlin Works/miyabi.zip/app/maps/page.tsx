'use client';

import React, { Suspense, useState, useEffect } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import Image from 'next/image';
import { MiyabiLogo } from '@/components/MiyabiLogo';
import { SearchBar } from '@/components/SearchBar';
import { SearchTabs } from '@/components/SearchTabs';
import { Footer } from '@/components/Footer';
import { PlaceResult } from '@/lib/search/types';
import { MapPin, Star, Navigation, Compass, Plus, Minus, Layers, ExternalLink } from 'lucide-react';

function MapsContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const query = searchParams.get('q') || '';

  const [places, setPlaces] = useState<PlaceResult[]>([]);
  const [selectedPlace, setSelectedPlace] = useState<PlaceResult | null>(null);
  const [zoom, setZoom] = useState(8);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    async function loadPlaces() {
      setLoading(true);
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(query)}&category=maps`);
        if (res.ok) {
          const data = await res.json();
          const items: PlaceResult[] = data.places || [];
          if (!cancelled) {
            setPlaces(items);
            if (items.length > 0) setSelectedPlace(items[0]);
          }
        }
      } catch (err) {
        console.error('Failed to load places:', err);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    loadPlaces();
    return () => {
      cancelled = true;
    };
  }, [query]);

  return (
    <div className="min-h-screen flex flex-col justify-between bg-[#F7F5F1]">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-[#F7F5F1]/95 backdrop-blur-md border-b border-[#E5E2DA]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12 py-3.5 flex items-center gap-4 sm:gap-8">
          <MiyabiLogo compact />
          <div className="flex-1 max-w-2xl">
            <SearchBar
              initialQuery={query}
              variant="compact"
              onSearchSubmit={(newQ) => {
                router.push(`/maps?q=${encodeURIComponent(newQ)}`);
              }}
            />
          </div>
        </div>
        <SearchTabs currentCategory="maps" query={query} />
      </header>

      {/* Split Map View Container */}
      <main className="flex-1 flex flex-col lg:flex-row h-[calc(100vh-140px)] min-h-[600px] border-b border-[#E5E2DA] overflow-hidden">
        {/* Left: Place List Panel */}
        <div className="w-full lg:w-96 lg:h-full bg-white border-r border-[#E5E2DA] flex flex-col overflow-y-auto shrink-0 shadow-xs">
          <div className="p-4 border-b border-[#F0EEE8] bg-[#F7F5F1]/50 flex items-center justify-between text-xs text-[#85827D]">
            <span>{places.length} 件の登録地点</span>
            <span>MIYABI カルトグラフィ 2028</span>
          </div>

          <div className="divide-y divide-[#F0EEE8] flex-1">
            {places.map((place) => {
              const isSelected = selectedPlace?.id === place.id;
              return (
                <div
                  key={place.id}
                  onClick={() => setSelectedPlace(place)}
                  className={`p-4 cursor-pointer transition-colors ${
                    isSelected ? 'bg-[#F7F5F1] border-l-2 border-[#D94132]' : 'hover:bg-[#FAF9F6]'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="text-sm font-medium text-[#171717]">{place.name}</h3>
                      <p className="text-xs text-[#85827D]">{place.japaneseName}</p>
                    </div>
                    <span className="flex items-center gap-1 text-xs font-semibold text-[#171717] tabular-nums shrink-0">
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                      {place.rating.toFixed(1)}
                    </span>
                  </div>

                  <p className="text-xs text-[#504E4A] line-clamp-2 mt-2 leading-relaxed">
                    {place.summary}
                  </p>

                  <div className="mt-3 flex items-center justify-between text-[11px] text-[#85827D]">
                    <span className="truncate max-w-[200px]">{place.address}</span>
                    {place.openStatus && (
                      <span className="text-[#D94132] font-medium shrink-0">{place.openStatus}</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Interactive Topographic Vector Map Canvas */}
        <div className="flex-1 relative bg-[#EBE8DF] flex items-center justify-center overflow-hidden">
          {/* Topographic Contour Lines Pattern (SVG) */}
          <svg className="absolute inset-0 w-full h-full opacity-35 pointer-events-none" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="contours" width="120" height="120" patternUnits="userSpaceOnUse">
                <path d="M0 40 Q30 10 60 40 T120 40" fill="none" stroke="#85827D" strokeWidth="0.5" />
                <path d="M0 80 Q30 50 60 80 T120 80" fill="none" stroke="#85827D" strokeWidth="0.5" />
                <path d="M0 120 Q30 90 60 120 T120 120" fill="none" stroke="#85827D" strokeWidth="0.5" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#contours)" />
          </svg>

          {/* Interactive Stylized Geographical Grid */}
          <div className="relative w-full max-w-3xl h-[460px] flex items-center justify-center">
            {/* Visual Japan Archipelago Map representation */}
            <div className="relative w-full h-full flex items-center justify-center">
              {places.map((place, idx) => {
                const isSelected = selectedPlace?.id === place.id;
                // Distributed coordinates on canvas
                const offsets = [
                  { top: '35%', left: '55%' }, // Fuji
                  { top: '42%', left: '50%' }, // Kawaguchiko
                  { top: '50%', left: '38%' }, // Kyoto Ryoanji
                  { top: '32%', left: '65%' }, // Ginza
                ];
                const pos = offsets[idx % offsets.length];

                return (
                  <button
                    key={place.id}
                    onClick={() => setSelectedPlace(place)}
                    style={{ top: pos.top, left: pos.left }}
                    className="absolute -translate-x-1/2 -translate-y-1/2 group focus:outline-none z-20 flex flex-col items-center cursor-pointer"
                  >
                    <div
                      className={`p-2 rounded-full shadow-lg transition-transform duration-200 ${
                        isSelected
                          ? 'bg-[#D94132] text-white scale-125 ring-4 ring-[#D94132]/20'
                          : 'bg-white text-[#171717] hover:scale-110 hover:text-[#D94132]'
                      }`}
                    >
                      <MapPin className="w-4 h-4 fill-current" />
                    </div>
                    <span className="mt-1 px-2 py-0.5 bg-white/90 backdrop-blur-xs border border-[#E5E2DA] rounded text-[11px] font-medium text-[#171717] shadow-xs whitespace-nowrap">
                      {place.japaneseName}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Selected Place Detail Overlay Card */}
            {selectedPlace && (
              <div className="absolute bottom-6 left-6 right-6 sm:right-auto sm:w-96 bg-white/95 backdrop-blur-md rounded-2xl shadow-xl border border-[#E5E2DA] p-5 z-30 animate-in fade-in-50 slide-in-from-bottom-2">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-[10px] tracking-widest text-[#85827D] uppercase font-semibold">
                      {selectedPlace.category}
                    </span>
                    <h2 className="text-base font-serif font-medium text-[#171717]">
                      {selectedPlace.japaneseName}
                    </h2>
                    <p className="text-xs text-[#85827D]">{selectedPlace.name}</p>
                  </div>
                  {selectedPlace.image && (
                    <div className="relative w-16 h-16 rounded-lg overflow-hidden shrink-0 border border-[#E5E2DA]">
                      <Image
                        src={selectedPlace.image}
                        alt={selectedPlace.name}
                        fill
                        sizes="64px"
                        referrerPolicy="no-referrer"
                        className="object-cover"
                      />
                    </div>
                  )}
                </div>

                <p className="text-xs text-[#504E4A] mt-2.5 leading-relaxed line-clamp-3">
                  {selectedPlace.summary}
                </p>

                <div className="mt-4 pt-3 border-t border-[#F0EEE8] flex items-center justify-between text-xs">
                  <div className="text-[11px] text-[#85827D] font-mono tabular-nums">
                    {selectedPlace.coordinates.lat.toFixed(4)}° N, {selectedPlace.coordinates.lng.toFixed(4)}° E
                  </div>
                  <a
                    href={`https://www.google.com/maps/search/?api=1&query=${selectedPlace.coordinates.lat},${selectedPlace.coordinates.lng}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#171717] text-white rounded-lg text-xs font-medium hover:bg-[#D94132] transition-colors"
                  >
                    <Navigation className="w-3 h-3" />
                    <span>ルート案内</span>
                    <ExternalLink className="w-3 h-3 ml-0.5" />
                  </a>
                </div>
              </div>
            )}
          </div>

          {/* Map Controls */}
          <div className="absolute top-6 right-6 flex flex-col gap-2 z-30">
            <div className="bg-white rounded-xl shadow-md border border-[#E5E2DA] overflow-hidden flex flex-col divide-y divide-[#F0EEE8]">
              <button
                onClick={() => setZoom((z) => Math.min(z + 1, 15))}
                className="p-2.5 text-[#504E4A] hover:text-[#171717] hover:bg-[#F7F5F1] transition-colors"
                aria-label="拡大"
              >
                <Plus className="w-4 h-4" />
              </button>
              <button
                onClick={() => setZoom((z) => Math.max(z - 1, 4))}
                className="p-2.5 text-[#504E4A] hover:text-[#171717] hover:bg-[#F7F5F1] transition-colors"
                aria-label="縮小"
              >
                <Minus className="w-4 h-4" />
              </button>
            </div>

            <button
              onClick={() => alert('MIYABI Cartography: 地理院タイル & ベクター標高データを統合しています')}
              className="p-2.5 bg-white rounded-xl shadow-md border border-[#E5E2DA] text-[#504E4A] hover:text-[#171717] hover:bg-[#F7F5F1] transition-colors"
              aria-label="レイヤー表示"
            >
              <Layers className="w-4 h-4" />
            </button>
          </div>

          {/* Compass Rose */}
          <div className="absolute bottom-6 right-6 p-2 bg-white/90 backdrop-blur-xs rounded-full shadow-sm border border-[#E5E2DA] text-[#85827D]">
            <Compass className="w-5 h-5 text-[#D94132]" />
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}

export default function MapsPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-[#F7F5F1] p-12 text-center text-xs text-[#85827D]">地図データを準備中...</div>}>
      <MapsContent />
    </Suspense>
  );
}
