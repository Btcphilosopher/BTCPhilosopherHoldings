'use client';

import React, { Suspense, useState, useEffect } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import Image from 'next/image';
import { MiyabiLogo } from '@/components/MiyabiLogo';
import { SearchBar } from '@/components/SearchBar';
import { SearchTabs } from '@/components/SearchTabs';
import { Footer } from '@/components/Footer';
import { useLanguage } from '@/lib/i18n';
import { NewsResult } from '@/lib/search/types';
import { Clock, ExternalLink, Newspaper } from 'lucide-react';

function NewsSearchContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const { locale } = useLanguage();

  const query = searchParams.get('q') || '';
  const [filter, setFilter] = useState<'all' | 'jp' | 'intl'>('all');
  const [news, setNews] = useState<NewsResult[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    async function loadNews() {
      setLoading(true);
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(query)}&category=news&region=${filter === 'jp' ? 'jp' : 'all'}`);
        if (res.ok) {
          const data = await res.json();
          let items: NewsResult[] = data.news || [];
          if (filter === 'intl') items = items.filter((n) => !n.isJapanese);
          if (filter === 'jp') items = items.filter((n) => n.isJapanese);
          if (!cancelled) setNews(items);
        }
      } catch (err) {
        console.error('Failed to load news:', err);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    loadNews();
    return () => {
      cancelled = true;
    };
  }, [query, filter]);

  return (
    <div className="min-h-screen flex flex-col justify-between bg-[#F7F5F1]">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-[#F7F5F1]/95 backdrop-blur-md border-b border-[#E5E2DA]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12 py-3.5 flex items-center gap-4 sm:gap-8">
          <MiyabiLogo compact />
          <div className="flex-1 max-w-2xl">
            <SearchBar
              initialQuery={query}
              variant="compact"
              onSearchSubmit={(newQ) => {
                router.push(`/news?q=${encodeURIComponent(newQ)}`);
              }}
            />
          </div>
        </div>
        <SearchTabs currentCategory="news" query={query} />
      </header>

      {/* Main News Content */}
      <main className="max-w-5xl mx-auto w-full px-4 sm:px-6 lg:px-12 py-8 flex-1">
        {/* News Filters */}
        <div className="flex flex-wrap items-center justify-between gap-4 pb-6 mb-8 border-b border-[#E5E2DA]">
          <div className="flex items-center gap-2">
            <Newspaper className="w-4 h-4 text-[#D94132]" />
            <h1 className="text-base font-serif font-medium text-[#171717]">
              {query ? `「${query}」のニュース` : '主要ニュース・論考'}
            </h1>
          </div>

          <div className="flex items-center gap-1.5 p-1 bg-white rounded-lg border border-[#E5E2DA] text-xs">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                filter === 'all' ? 'bg-[#171717] text-white font-medium' : 'text-[#504E4A] hover:text-[#171717]'
              }`}
            >
              すべて
            </button>
            <button
              onClick={() => setFilter('jp')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                filter === 'jp' ? 'bg-[#171717] text-white font-medium' : 'text-[#504E4A] hover:text-[#171717]'
              }`}
            >
              国内報道
            </button>
            <button
              onClick={() => setFilter('intl')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                filter === 'intl' ? 'bg-[#171717] text-white font-medium' : 'text-[#504E4A] hover:text-[#171717]'
              }`}
            >
              海外メディア
            </button>
          </div>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="space-y-6 animate-pulse">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-32 bg-[#E5E2DA] rounded-xl" />
            ))}
          </div>
        )}

        {/* News Feed List */}
        {!loading && (
          <div className="divide-y divide-[#E5E2DA]">
            {news.map((item) => (
              <article key={item.id} className="py-7 first:pt-0 last:pb-0 flex flex-col sm:flex-row gap-6 group">
                <div className="flex-1 space-y-2">
                  <div className="flex items-center gap-2 text-xs text-[#85827D]">
                    <span className="font-medium text-[#171717]">{item.publisher}</span>
                    <span aria-hidden="true">·</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{item.publishedAt}</span>
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{item.category}</span>
                  </div>

                  <h2 className="text-lg sm:text-xl font-medium leading-snug">
                    <a
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#171717] group-hover:text-[#D94132] transition-colors inline-flex items-center gap-1.5"
                    >
                      <span>{item.headline}</span>
                      <ExternalLink className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity text-[#D94132]" />
                    </a>
                  </h2>

                  <p className="text-sm text-[#4D5156] leading-relaxed">
                    {item.summary}
                  </p>
                </div>

                {item.thumbnailUrl && (
                  <div className="relative w-full sm:w-48 h-32 shrink-0 rounded-xl overflow-hidden bg-[#F0EEE8] border border-[#E5E2DA]">
                    <Image
                      src={item.thumbnailUrl}
                      alt={item.headline}
                      fill
                      sizes="(max-width: 640px) 100vw, 192px"
                      referrerPolicy="no-referrer"
                      className="object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                )}
              </article>
            ))}
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}

export default function NewsPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-[#F7F5F1] p-12 text-center text-xs text-[#85827D]">ニュースフィードを読み込み中...</div>}>
      <NewsSearchContent />
    </Suspense>
  );
}
