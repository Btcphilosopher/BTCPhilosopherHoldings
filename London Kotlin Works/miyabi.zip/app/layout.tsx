import type { Metadata } from 'next';
import { Noto_Sans_JP, Noto_Serif_JP } from 'next/font/google';
import './globals.css';
import { LanguageProvider } from '@/lib/i18n';

const notoSansJP = Noto_Sans_JP({
  weight: ['300', '400', '500', '600', '700'],
  subsets: ['latin'],
  variable: '--font-sans-jp',
  display: 'swap',
});

const notoSerifJP = Noto_Serif_JP({
  weight: ['400', '600', '700'],
  subsets: ['latin'],
  variable: '--font-serif-jp',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'MIYABI — Next-Generation Japanese Search Engine',
  description: 'A refined, next-generation Japanese search engine combining Tokyo minimalism, Japanese craftsmanship, and fast AI-assisted exploration.',
  openGraph: {
    title: 'MIYABI — 美しさを、見つける。',
    description: 'A clearer tomorrow through better search. Next-generation Japanese search platform.',
    type: 'website',
    locale: 'ja_JP',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'MIYABI — Next-Generation Japanese Search Engine',
    description: 'A clearer tomorrow through better search.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ja" className={`${notoSansJP.variable} ${notoSerifJP.variable}`}>
      <body className="min-h-screen bg-[#F7F5F1] text-[#171717] font-sans antialiased selection:bg-[#D94132] selection:text-white" suppressHydrationWarning>
        <LanguageProvider>
          {children}
        </LanguageProvider>
      </body>
    </html>
  );
}
