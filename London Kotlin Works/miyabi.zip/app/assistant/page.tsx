'use client';

import React, { Suspense, useState, useRef, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import ReactMarkdown from 'react-markdown';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { useLanguage } from '@/lib/i18n';
import { Sparkles, Send, Copy, Check, RotateCcw, ArrowRight } from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  isLiveModel?: boolean;
}

function AssistantContent() {
  const searchParams = useSearchParams();
  const initialQ = searchParams.get('q') || '';
  const { t, locale } = useLanguage();

  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const initializedRef = useRef(false);

  // Auto scroll to latest message
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const sendMessage = React.useCallback(async (textToSend: string) => {
    const trimmed = textToSend.trim();
    if (!trimmed || loading) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}-user`,
      role: 'user',
      content: trimmed,
      timestamp: new Date().toLocaleTimeString(locale === 'ja' ? 'ja-JP' : 'en-US', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      setMessages((currentMessages) => {
        const historyPayload = currentMessages.slice(-6).map((m) => ({
          role: m.role,
          content: m.content,
        }));

        fetch('/api/assistant', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: trimmed,
            history: historyPayload,
            locale,
          }),
        })
          .then((res) => {
            if (!res.ok) throw new Error('API request failed');
            return res.json();
          })
          .then((data) => {
            const assistantMsg: ChatMessage = {
              id: `msg-${Date.now()}-assistant`,
              role: 'assistant',
              content: data.reply || '回答が得られませんでした。',
              timestamp: new Date().toLocaleTimeString(locale === 'ja' ? 'ja-JP' : 'en-US', { hour: '2-digit', minute: '2-digit' }),
              isLiveModel: data.isLiveModel,
            };
            setMessages((prev) => [...prev, assistantMsg]);
            setLoading(false);
          })
          .catch(() => {
            const errorMsg: ChatMessage = {
              id: `msg-${Date.now()}-error`,
              role: 'assistant',
              content: locale === 'ja'
                ? '一時的な通信エラーが発生しました。しばらく待ってから再度お試しください。'
                : 'A network communication error occurred. Please try again in a moment.',
              timestamp: new Date().toLocaleTimeString(),
            };
            setMessages((prev) => [...prev, errorMsg]);
            setLoading(false);
          });

        return currentMessages;
      });
    } catch {
      setLoading(false);
    }
  }, [loading, locale]);

  // Initial prompt if passed via URL ?q=
  useEffect(() => {
    if (initialQ && !initializedRef.current) {
      initializedRef.current = true;
      sendMessage(initialQ);
    }
  }, [initialQ, sendMessage]);

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleNewConversation = () => {
    setMessages([]);
  };

  const presetQuestions = locale === 'ja'
    ? [
        '日本の「間（Ma）」と枯山水庭園の空間哲学について教えて',
        '富士山のユネスコ世界文化遺産としての価値と歴史的背景は？',
        '千利休の「侘び茶」における一期一会の精神とは？',
        'MIYABI検索エンジンのアーキテクチャとプライバシー方針',
      ]
    : [
        'Explain the Japanese spatial philosophy of Ma in zen rock gardens',
        'What makes Mount Fuji a UNESCO World Cultural Heritage site?',
        'What is the core essence of Sen no Rikyu’s wabi-cha tea philosophy?',
        'Describe MIYABI search engine architecture and privacy model',
      ];

  return (
    <div className="min-h-screen flex flex-col justify-between bg-[#F7F5F1]">
      <Header />

      <main className="max-w-4xl mx-auto w-full px-4 sm:px-6 py-6 flex-1 flex flex-col">
        {/* Assistant Header Banner */}
        <div className="flex items-center justify-between pb-5 border-b border-[#E5E2DA] mb-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-[#D94132]/10 flex items-center justify-center text-[#D94132]">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h1 className="text-base font-serif font-medium text-[#171717]">
                MIYABI AI アシスタント
              </h1>
              <p className="text-xs text-[#85827D]">
                Powered by Gemini 3.8 Flash · Tokyo Research Core
              </p>
            </div>
          </div>

          {messages.length > 0 && (
            <button
              onClick={handleNewConversation}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#E5E2DA] bg-white text-xs text-[#504E4A] hover:text-[#171717] hover:border-[#171717] transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>新しい対話</span>
            </button>
          )}
        </div>

        {/* Message Stream */}
        <div className="flex-1 space-y-6 min-h-[420px]">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center py-12 text-center max-w-lg mx-auto">
              <div className="w-12 h-12 rounded-full bg-[#D94132]/10 flex items-center justify-center text-[#D94132] mb-4">
                <Sparkles className="w-6 h-6" />
              </div>
              <h2 className="text-xl font-serif text-[#171717] font-medium mb-2">
                美しさと論理が調和する知的探索
              </h2>
              <p className="text-xs text-[#85827D] leading-relaxed mb-8">
                文化、哲学、最先端科学、地域情報など、知りたい事柄について自然言語でお尋ねください。
              </p>

              {/* Preset Prompts */}
              <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-left">
                {presetQuestions.map((q, idx) => (
                  <button
                    key={idx}
                    onClick={() => sendMessage(q)}
                    className="p-3 bg-white rounded-xl border border-[#E5E2DA] hover:border-[#D94132] text-xs text-[#171717] transition-all group flex items-center justify-between text-left"
                  >
                    <span className="line-clamp-2 pr-2">{q}</span>
                    <ArrowRight className="w-3.5 h-3.5 text-[#85827D] group-hover:text-[#D94132] shrink-0" />
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${
                  msg.role === 'user' ? 'items-end' : 'items-start'
                }`}
              >
                <div
                  className={`max-w-2xl rounded-2xl p-5 ${
                    msg.role === 'user'
                      ? 'bg-[#171717] text-white'
                      : 'bg-white border border-[#E5E2DA] text-[#171717] shadow-xs'
                  }`}
                >
                  {msg.role === 'user' ? (
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                  ) : (
                    <div className="space-y-3 text-sm leading-relaxed">
                      <div className="markdown-body prose prose-sm max-w-none text-[#171717]">
                        <ReactMarkdown>{msg.content}</ReactMarkdown>
                      </div>

                      {/* Message Actions */}
                      <div className="pt-3 border-t border-[#F0EEE8] flex items-center justify-between text-[11px] text-[#85827D]">
                        <span className="tabular-nums font-mono">{msg.timestamp}</span>
                        <button
                          onClick={() => handleCopy(msg.id, msg.content)}
                          className="flex items-center gap-1 hover:text-[#171717] transition-colors p-1"
                          aria-label="回答をコピー"
                        >
                          {copiedId === msg.id ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                              <span className="text-emerald-600">コピーしました</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span>コピー</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))
          )}

          {/* Loading Indicator */}
          {loading && (
            <div className="flex items-center gap-3 p-4 bg-white rounded-xl border border-[#E5E2DA] max-w-xs text-xs text-[#85827D] animate-pulse">
              <Sparkles className="w-4 h-4 text-[#D94132] animate-spin" />
              <span>{t.aiSynthesizing}</span>
            </div>
          )}

          <div ref={chatEndRef} />
        </div>

        {/* Input Bar */}
        <div className="sticky bottom-4 z-20 pt-4 bg-[#F7F5F1]">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              sendMessage(input);
            }}
            className="flex items-center gap-2 p-1.5 pl-5 bg-white rounded-full border border-[#E5E2DA] shadow-md focus-within:border-[#D94132] focus-within:ring-2 focus-within:ring-[#D94132]/10"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              disabled={loading}
              placeholder={locale === 'ja' ? '質問や知りたいトピックを入力...' : 'Ask a question or enter a topic...'}
              className="flex-1 text-sm bg-transparent border-none outline-none text-[#171717] placeholder:text-[#9C9993]"
            />
            <button
              type="submit"
              disabled={!input.trim() || loading}
              className="p-3 bg-[#171717] text-white rounded-full hover:bg-[#D94132] disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              aria-label="送信"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
          <p className="text-[10px] text-center text-[#85827D] mt-2">
            MIYABI AIは検証可能な一次情報と引用を重視して回答を構成します。
          </p>
        </div>
      </main>

      <Footer />
    </div>
  );
}

export default function AssistantPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-[#F7F5F1] p-12 text-center text-xs text-[#85827D]">AIアシスタントを起動中...</div>}>
      <AssistantContent />
    </Suspense>
  );
}
