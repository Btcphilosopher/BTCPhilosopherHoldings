'use client';

import React, { useState, useEffect } from 'react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { useLanguage, Locale } from '@/lib/i18n';
import { searchHistory } from '@/lib/history';
import {
  Settings as SettingsIcon,
  Globe,
  Clock,
  Trash2,
  ShieldCheck,
  Cpu,
  Layers,
  Database,
  Search,
  CheckCircle2,
} from 'lucide-react';

export default function SettingsPage() {
  const { locale, setLocale, t } = useLanguage();
  const [historyList, setHistoryList] = useState<string[]>(() => {
    return searchHistory.get();
  });
  const [historyClearedNotice, setHistoryClearedNotice] = useState(false);

  const handleClearHistory = () => {
    searchHistory.clear();
    setHistoryList([]);
    setHistoryClearedNotice(true);
    setTimeout(() => setHistoryClearedNotice(false), 2500);
  };

  const handleRemoveItem = (query: string) => {
    searchHistory.remove(query);
    setHistoryList(searchHistory.get());
  };

  return (
    <div className="min-h-screen flex flex-col justify-between bg-[#F7F5F1]">
      <Header />

      <main className="max-w-4xl mx-auto w-full px-4 sm:px-6 py-10 flex-1 space-y-12">
        {/* Page Title */}
        <div className="border-b border-[#E5E2DA] pb-6">
          <div className="flex items-center gap-2.5 text-xs font-semibold uppercase tracking-wider text-[#D94132] mb-1">
            <SettingsIcon className="w-4 h-4" />
            <span>環境設定</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-serif font-medium text-[#171717]">
            設定とシステム仕様
          </h1>
          <p className="text-xs text-[#85827D] mt-1">
            表示言語、検索プライバシー、履歴管理、および次世代アーキテクチャ設計仕様書。
          </p>
        </div>

        {/* Section 1: Language & Interface */}
        <section className="bg-white rounded-2xl border border-[#E5E2DA] p-6 shadow-xs space-y-6">
          <div className="flex items-center gap-2.5">
            <Globe className="w-5 h-5 text-[#85827D]" />
            <h2 className="text-base font-medium text-[#171717]">表示言語と地域</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <button
              onClick={() => setLocale('ja')}
              className={`p-4 rounded-xl border text-left transition-all ${
                locale === 'ja'
                  ? 'border-[#D94132] bg-[#D94132]/5 ring-1 ring-[#D94132]'
                  : 'border-[#E5E2DA] hover:bg-[#F7F5F1]'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-medium text-sm text-[#171717]">日本語 (Japanese)</span>
                {locale === 'ja' && <CheckCircle2 className="w-4 h-4 text-[#D94132]" />}
              </div>
              <p className="text-xs text-[#85827D] mt-1">
                日本の美意識に基づいた標準インターフェース
              </p>
            </button>

            <button
              onClick={() => setLocale('en')}
              className={`p-4 rounded-xl border text-left transition-all ${
                locale === 'en'
                  ? 'border-[#D94132] bg-[#D94132]/5 ring-1 ring-[#D94132]'
                  : 'border-[#E5E2DA] hover:bg-[#F7F5F1]'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-medium text-sm text-[#171717]">English</span>
                {locale === 'en' && <CheckCircle2 className="w-4 h-4 text-[#D94132]" />}
              </div>
              <p className="text-xs text-[#85827D] mt-1">
                International English interface with Japanese refinement
              </p>
            </button>
          </div>
        </section>

        {/* Section 2: Privacy & Search History */}
        <section className="bg-white rounded-2xl border border-[#E5E2DA] p-6 shadow-xs space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <ShieldCheck className="w-5 h-5 text-[#D94132]" />
              <div>
                <h2 className="text-base font-medium text-[#171717]">プライバシーと検索履歴</h2>
                <p className="text-xs text-[#85827D]">
                  検索履歴はお使いのブラウザ内部（localStorage）にのみ暗号化保持されます。
                </p>
              </div>
            </div>

            {historyList.length > 0 && (
              <button
                onClick={handleClearHistory}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#E5E2DA] text-xs text-[#D94132] hover:bg-red-50 hover:border-red-200 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{t.clearHistory}</span>
              </button>
            )}
          </div>

          {historyClearedNotice && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800">
              検索履歴を完全に消去しました。
            </div>
          )}

          {historyList.length === 0 ? (
            <p className="text-xs text-[#85827D] py-4 text-center">
              保存されている検索履歴はありません。
            </p>
          ) : (
            <div className="divide-y divide-[#F0EEE8]">
              {historyList.map((item, idx) => (
                <div key={idx} className="py-2.5 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2.5 text-[#171717]">
                    <Clock className="w-3.5 h-3.5 text-[#85827D]" />
                    <span>{item}</span>
                  </div>
                  <button
                    onClick={() => handleRemoveItem(item)}
                    className="text-[#85827D] hover:text-[#D94132] transition-colors"
                  >
                    削除
                  </button>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Section 3: Architecture Specifications & Future Roadmap */}
        <section id="architecture" className="bg-white rounded-2xl border border-[#E5E2DA] p-6 sm:p-8 shadow-xs space-y-8">
          <div>
            <div className="flex items-center gap-2.5 text-xs font-semibold uppercase tracking-wider text-[#85827D] mb-1">
              <Cpu className="w-4 h-4 text-[#D94132]" />
              <span>インフラストラクチャ設計書</span>
            </div>
            <h2 className="text-xl font-serif font-medium text-[#171717]">
              MIYABI 検索エンジン アーキテクチャ仕様書
            </h2>
            <p className="text-xs text-[#85827D] mt-1 leading-relaxed">
              本プロジェクトの設計理念および今後の分散検索インフラ統合ロードマップの技術仕様。
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-[#504E4A] leading-relaxed">
            <div className="p-4 bg-[#F7F5F1] rounded-xl border border-[#E5E2DA] space-y-2">
              <div className="flex items-center gap-2 font-medium text-[#171717]">
                <Search className="w-4 h-4 text-[#D94132]" />
                <h3>01. 日本語形態素解析・正規化パイプライン</h3>
              </div>
              <p>
                日本語テキストは空白区切りが存在しないため、Kuromoji / MeCab / UniDic 辞書を用いた形態素解析を実装予定。NFKC Unicode正規化により全角・半角英数字やカタカナ表記揺れを整流化し、助詞・助動詞の重み付けを最適化します。
              </p>
            </div>

            <div className="p-4 bg-[#F7F5F1] rounded-xl border border-[#E5E2DA] space-y-2">
              <div className="flex items-center gap-2 font-medium text-[#171717]">
                <Database className="w-4 h-4 text-[#D94132]" />
                <h3>02. 分散インデックスとハイブリッド検索</h3>
              </div>
              <p>
                BM25（スパース転置インデックス）と Dense Vector Embeddings（ニューラル埋め込み）を融合したハイブリッド検索基盤。キーワードの一致性と意図の文脈的類似度を相反させずに高速スコアリングします。
              </p>
            </div>

            <div className="p-4 bg-[#F7F5F1] rounded-xl border border-[#E5E2DA] space-y-2">
              <div className="flex items-center gap-2 font-medium text-[#171717]">
                <Layers className="w-4 h-4 text-[#D94132]" />
                <h3>03. クローラーと分散URLスケジューラ</h3>
              </div>
              <p>
                Robots.txt プロトコルおよびサイト負荷配慮（Politeness）を徹底する非同期分散クローラー。ETag と Last-Modified に基づく差分クロールにより、ネットワーク帯域とサーバ負荷を最小化します。
              </p>
            </div>

            <div className="p-4 bg-[#F7F5F1] rounded-xl border border-[#E5E2DA] space-y-2">
              <div className="flex items-center gap-2 font-medium text-[#171717]">
                <ShieldCheck className="w-4 h-4 text-[#D94132]" />
                <h3>04. スパム排除・クリックベイト抑止</h3>
              </div>
              <p>
                低品質なアフィリエイト量産コンテンツやAI生成スロップを検知・減点する品質評価シグナル。公的機関、学術論文、一次情報提供者の信頼スコア（Authority Signal）を最上位に配置します。
              </p>
            </div>
          </div>

          <div id="about" className="pt-6 border-t border-[#F0EEE8] text-xs text-[#85827D] space-y-2">
            <h4 className="font-medium text-[#171717]">MIYABI ブランドマニフェスト</h4>
            <p>
              「美しさを、見つける。」— MIYABIは、情報の過剰と商業ノイズに満ちた現代のウェブにおいて、知性の静謐な避難所となるべく設計されました。東京から世界へ、澄んだ検索体験を届けます。
            </p>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
