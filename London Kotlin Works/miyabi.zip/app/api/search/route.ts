import { NextRequest, NextResponse } from 'next/server';
import { searchService } from '@/lib/search/provider';
import { SearchCategory } from '@/lib/search/types';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const query = searchParams.get('q') || '';
    const category = (searchParams.get('category') || 'all') as SearchCategory;
    const page = parseInt(searchParams.get('page') || '1', 10);
    const pageSize = parseInt(searchParams.get('pageSize') || '10', 10);
    const locale = (searchParams.get('locale') || 'ja') as 'ja' | 'en';
    const timeFilter = (searchParams.get('time') || 'all') as 'all' | '24h' | 'week' | 'month';
    const regionFilter = (searchParams.get('region') || 'all') as 'all' | 'jp';

    // Query validation & sanitization
    const sanitizedQuery = query.trim().slice(0, 200);

    const result = await searchService.search({
      query: sanitizedQuery,
      category,
      page,
      pageSize,
      locale,
      timeFilter,
      regionFilter,
    });

    return NextResponse.json(result, {
      status: 200,
      headers: {
        'Cache-Control': 'public, s-maxage=30, stale-while-revalidate=60',
      },
    });
  } catch (error) {
    console.error('Search API error:', error);
    return NextResponse.json(
      {
        error: 'Failed to process search request',
        message: error instanceof Error ? error.message : 'Unknown server error',
      },
      { status: 500 }
    );
  }
}
