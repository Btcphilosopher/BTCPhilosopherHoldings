import { NextRequest, NextResponse } from 'next/server';
import { searchService } from '@/lib/search/provider';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const query = searchParams.get('q') || '';
    const locale = searchParams.get('locale') || 'ja';

    const suggestions = await searchService.suggest(query, locale);

    return NextResponse.json({ suggestions }, {
      status: 200,
      headers: {
        'Cache-Control': 'public, s-maxage=60, stale-while-revalidate=120',
      },
    });
  } catch (error) {
    console.error('Suggest API error:', error);
    return NextResponse.json({ suggestions: [] }, { status: 200 });
  }
}
