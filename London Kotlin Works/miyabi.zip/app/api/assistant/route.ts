import { NextRequest, NextResponse } from 'next/server';
import { GoogleGenAI } from '@google/genai';

let geminiClient: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  try {
    geminiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  } catch (err) {
    console.error('Failed to initialize Gemini client for assistant:', err);
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { message, history = [], locale = 'ja' } = body;

    if (!message || typeof message !== 'string') {
      return NextResponse.json({ error: 'Message is required' }, { status: 400 });
    }

    // If Gemini API is available, generate real AI response
    if (geminiClient) {
      try {
        const systemPrompt = `You are MIYABI AI Assistant (雅), the intellectual core of MIYABI — a next-generation Japanese search platform crafted in Tokyo.
Philosophy: "美しさを、見つける。" (Find beauty in what you discover).
Tone: Refined, serene, authoritative, articulate, and deeply respectful. Avoid fluff, unnecessary disclaimers, or excessive enthusiasm.
Format: Provide clear answers with structured paragraphs. Where factual assertions are made, provide bracketed citation references like [1], [2].
Language: ${locale === 'en' ? 'Respond in elegant English' : 'Respond in natural, sophisticated Japanese (自然で美しい日本語)'}.
At the end of your response, if applicable, list 2-3 credible reference sources under a "Sources / 参照元" section.`;

        // Format history for Gemini
        const contents = [];
        for (const item of history.slice(-6)) {
          contents.push({
            role: item.role === 'user' ? 'user' : 'model',
            parts: [{ text: item.content }],
          });
        }
        contents.push({
          role: 'user',
          parts: [{ text: message }],
        });

        const response = await geminiClient.models.generateContent({
          model: 'gemini-3.8-flash',
          contents,
          config: {
            systemInstruction: systemPrompt,
            temperature: 0.7,
          },
        });

        const replyText = response.text || (locale === 'en' ? 'No response generated.' : '回答を生成できませんでした。');

        return NextResponse.json({
          reply: replyText,
          isLiveModel: true,
          model: 'gemini-3.8-flash',
          timestamp: new Date().toISOString(),
        });
      } catch (geminiError) {
        console.error('Gemini API call failed in assistant route:', geminiError);
        // Fall back to intelligent demonstration mode with clear explanation
      }
    }

    // Demonstration response when GEMINI_API_KEY is not configured or calls fail
    const isEnglish = locale === 'en';
    let demoReply = '';

    const lower = message.toLowerCase();
    if (lower.includes('富士') || lower.includes('fuji')) {
      demoReply = isEnglish
        ? `### Mount Fuji (霊峰 富士)

Mount Fuji stands at 3,776 meters as Japan’s highest peak and the enduring cultural emblem of the archipelago. In 2013, it was designated a UNESCO World Cultural Heritage site under the title *"Fujisan, sacred place and source of artistic inspiration"* [1].

**Key Aspects:**
- **Climbing Seasons:** Typically open from early July through early September via four classical routes: Yoshida, Fujinomiya, Subashiri, and Gotemba [2].
- **Aesthetic Legacy:** Immortalized in Katsushika Hokusai’s *Thirty-Six Views of Mount Fuji* and ancient *waka* poetry in the *Man'yōshū*.
- **Observation Points:** Lake Kawaguchi and Lake Yamanaka provide iconic views of "Upside-down Fuji" (*Sakasa-Fuji*) framed by seasonal cherry blossoms or autumn foliage.

---
**Sources / 参照元:**
[1] UNESCO World Heritage Centre — Fujisan Dossier  
[2] Yamanashi & Shizuoka Prefectural Mount Fuji Safety Council`
        : `### 霊峰 富士（標高 3,776m）

富士山は日本最高峰であり、古来より信仰の対象、そして芸術の源泉として日本人の精神性に深く根ざしてきました。2013年にはユネスコ世界文化遺産に登録されています [1]。

**主要な要点:**
- **登山シーズン:** 例年7月上旬から9月上旬まで開山。吉田ルート・富士宮ルート・須走ルート・御殿場ルートの4登山道が整備されています [2]。
- **芸術と美学:** 葛飾北斎の『富嶽三十六景』や歌川広重の版画、万葉集の和歌に詠まれ、「雅」の象徴とされてきました。
- **展望の妙:** 河口湖北岸からは、湖面に映る「逆さ富士」と春の桜が織りなす絶景を静かに観賞できます。

---
**参照元:**
[1] ユネスコ世界遺産センター 公式文書（富士山）  
[2] 富士山世界文化遺産協議会・環境省学術調査報告`;
    } else if (lower.includes('京都') || lower.includes('kyoto') || lower.includes('枯山水')) {
      demoReply = isEnglish
        ? `### Kyoto & The Philosophy of Ma (間)

Kyoto, the imperial capital for over a millennium (794–1868), represents the height of traditional Japanese aesthetic refinement. Its dry rock gardens (*karesansui*), such as that of Ryōan-ji, demonstrate the profound concept of **Ma**—purposeful negative space [1].

**Philosophical Pillars:**
- **Karesansui (枯山水):** Depicting mountains and oceans through raked white gravel and mossy boulders without a single drop of water.
- **Wabi-Sabi (侘び寂び):** Appreciating the austere, weathered, and impermanent aspects of natural materials.
- **Urban Geometry:** Designed on a classical grid modeled after Chang'an during the Heian period.

---
**Sources / 参照元:**
[1] Kyoto Institute of Cultural Heritage & Zen Aesthetics`
        : `### 京都と「間（Ma）」の空間哲学

平安京遷都（794年）以来千年の都であった京都は、日本の伝統美意識の結晶地です。龍安寺をはじめとする枯山水庭園は、「引き算の美学」と「間（Ma）」の空間構成によって宇宙観を現出させています [1]。

**美意識の要諦:**
- **枯山水:** 水を一切用いず、白砂の箒目と巨石の配置のみで大海や雲海のうねりを表現する極限のミニマリズム。
- **侘び寂び:** 質素で不完全なもの、歳月を重ねた古色のなかに真実の美を見出す禅の心。
- **文化的継承:** 茶道、華道、西陣織、京料理など、生活文化そのものが精緻な工芸として受け継がれています。

---
**参照元:**
[1] 京都文化学術研究所 禅宗庭園論考`;
    } else {
      demoReply = isEnglish
        ? `### MIYABI Information Synthesis: "${message}"

MIYABI synthesizes knowledge through the lens of clarity, relevance, and structural precision [1].

- **Verified Context:** Your inquiry touches upon key themes in contemporary Japanese innovation and international search methodology.
- **Clarity Over Clutter:** Rather than returning promotional noise, MIYABI prioritizes authoritative primary sources and verified data.
- **Real-Time Integration:** When an active \`GEMINI_API_KEY\` is connected in environment settings, live multi-turn neural synthesis is activated dynamically [2].

---
**Sources / 参照元:**
[1] MIYABI Search Platform Architecture Specification  
[2] Google GenAI SDK (gemini-3.8-flash integration)`
        : `### MIYABI 情報要約: 「${message}」

MIYABI（みやび）は、ノイズのない静謐な情報空間から本質的な知識を抽出します [1]。

- **精緻な文脈理解:** ご提示いただいたキーワードについて、日本語の文脈的深みと国際的な学術的正確性を重視して分析しました。
- **余白と明瞭さ:** 広告やクリックベイト誘導を徹底的に排除し、一次情報と信頼できる学術・公的データに根ざした要点を提示します。
- **AI基盤の接続:** 環境変数 \`GEMINI_API_KEY\` が設定されている場合、次世代モデル「gemini-3.8-flash」によるリアルタイム対話がシームレスに機能します [2]。

---
**参照元:**
[1] MIYABI 検索基盤アーキテクチャ仕様書  
[2] Google GenAI SDK (gemini-3.8-flash 接続仕様)`;
    }

    return NextResponse.json({
      reply: demoReply,
      isLiveModel: false,
      model: 'miyabi-demonstration-agent',
      notice: isEnglish
        ? 'Demonstration mode active. To activate live Gemini 3.8 neural synthesis, configure GEMINI_API_KEY in your server environment.'
        : 'デモンストレーションモードで動作中。GEMINI_API_KEY を設定するとリアルタイムのGemini 3.8応答が有効になります。',
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Assistant API error:', error);
    return NextResponse.json(
      { error: 'Internal server error while processing assistant query' },
      { status: 500 }
    );
  }
}
