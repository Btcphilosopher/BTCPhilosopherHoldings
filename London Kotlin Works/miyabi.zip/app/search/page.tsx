'use client';

import React, { Suspense, useState, useEffect } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { MiyabiLogo } from '@/components/MiyabiLogo';
import { SearchBar } from '@/components/SearchBar';
import { SearchTabs } from '@/components/SearchTabs';
import { KnowledgePanel } from '@/components/KnowledgePanel';
import { Footer } from '@/components/Footer';
import { useLanguage } from '@/lib/i18n';
import { SearchResponse, SearchResult } from '@/lib/search/types';
import { Sparkles, SlidersHorizontal, ChevronLeft, ChevronRight, Globe, ShieldCheck } from 'lucide-react';

function SearchResultsContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const { t, locale } = useLanguage();

  const query = searchParams.get('q') || '';
  const category = searchParams.get('category') || 'all';
  const page = parseInt(searchParams.get('page') || '1', 10);
  const timeFilter = searchParams.get('time') || 'all';
  const regionFilter = searchParams.get('region') || 'all';

  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<SearchResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [filterOpen, setFilterOpen] = useState(false);

  useEffect(() => {
    let isCancelled = false;

    async function fetchResults() {
      setLoading(true);
      setError(null);
      try {
        const params = new URLSearchParams({
          q: query,
          category,
          page: page.toString(),
          time: timeFilter,
          region: regionFilter,
          locale,
        });

        const res = await fetch(`/api/search?${params.toString()}`);
        if (!res.ok) throw new Error('Search request failed');
        const json: SearchResponse = await res.json();
        if (!isCancelled) {
          setData(json);
        }
      } catch (err) {
        if (!isCancelled) {
          setError(err instanceof Error ? err.message : 'Unknown error');
        }
      } finally {
        if (!isCancelled) setLoading(false);
      }
    }

    fetchResults();

    return () => {
      isCancelled = true;
    };
  }, [query, category, page, timeFilter, regionFilter, locale]);

  const updateFilters = (newTime?: string, newRegion?: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (newTime !== undefined) {
      if (newTime === 'all') params.delete('time');
      else params.set('time', newTime);
    }
    if (newRegion !== undefined) {
      if (newRegion === 'all') params.delete('region');
      else params.set('region', newRegion);
    }
    params.set('page', '1');
    router.push(`/search?${params.toString()}`);
  };

  const handlePageChange = (newPage: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set('page', newPage.toString());
    router.push(`/search?${params.toString()}`);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col justify-between bg-[#F7F5F1]">
      {/* Search Header */}
      <header className="sticky top-0 z-30 bg-[#F7F5F1]/95 backdrop-blur-md border-b border-[#E5E2DA]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12 py-3.5 flex items-center gap-4 sm:gap-8">
          <MiyabiLogo compact />
          <div className="flex-1 max-w-2xl">
            <SearchBar
              initialQuery={query}
              variant="compact"
              onSearchSubmit={(newQ) => {
                router.push(`/search?q=${encodeURIComponent(newQ)}`);
              }}
            />
          </div>
        </div>

        {/* Categories Tab Bar */}
        <SearchTabs currentCategory={category} query={query} />
      </header>

      {/* Main Results Container */}
      <main className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-12 py-6 flex-1">
        {/* Filters and Metadata Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-[#85827D] pb-5 mb-4 border-b border-[#E5E2DA]">
          <div className="flex items-center gap-2">
            {data && !loading && (
              <span className="tabular-nums">
                {t.resultsCount(data.totalCount, (data.tookMs / 1000).toFixed(2))}
              </span>
            )}
            {data?.providerName && (
              <>
                <span aria-hidden="true">·</span>
                <span className="hidden sm:inline text-[#9C9993]">{data.providerName}</span>
              </>
            )}
          </div>

          {/* Filter Toggles */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setFilterOpen(!filterOpen)}
              className="flex items-center gap-1.5 py-1 px-2.5 rounded-md text-[#504E4A] hover:bg-white hover:text-[#171717] border border-transparent hover:border-[#E5E2DA] transition-colors"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>フィルター</span>
            </button>
          </div>
        </div>

        {/* Filter Dropdown Bar */}
        {filterOpen && (
          <div className="p-4 mb-6 bg-white rounded-xl border border-[#E5E2DA] flex flex-wrap gap-6 text-xs animate-in fade-in-50">
            <div>
              <span className="font-medium text-[#171717] block mb-2">{t.filterTime}</span>
              <div className="flex gap-2">
                {[
                  { id: 'all', label: t.filterAllTime },
                  { id: '24h', label: t.filterPast24h },
                  { id: 'week', label: t.filterPastWeek },
                  { id: 'month', label: t.filterPastMonth },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => updateFilters(item.id, undefined)}
                    className={`px-3 py-1.5 rounded-md transition-colors ${
                      timeFilter === item.id
                        ? 'bg-[#171717] text-white font-medium'
                        : 'bg-[#F7F5F1] text-[#504E4A] hover:bg-[#E5E2DA]'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <span className="font-medium text-[#171717] block mb-2">{t.filterRegion}</span>
              <div className="flex gap-2">
                {[
                  { id: 'all', label: t.filterAllRegions },
                  { id: 'jp', label: t.filterJapanOnly },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => updateFilters(undefined, item.id)}
                    className={`px-3 py-1.5 rounded-md transition-colors ${
                      regionFilter === item.id
                        ? 'bg-[#171717] text-white font-medium'
                        : 'bg-[#F7F5F1] text-[#504E4A] hover:bg-[#E5E2DA]'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Loading Skeleton */}
        {loading && (
          <div className="max-w-3xl space-y-7 animate-pulse">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="space-y-2">
                <div className="h-3 w-48 bg-[#E5E2DA] rounded" />
                <div className="h-5 w-3/4 bg-[#E5E2DA] rounded" />
                <div className="h-3.5 w-full bg-[#E5E2DA] rounded" />
                <div className="h-3.5 w-4/5 bg-[#E5E2DA] rounded" />
              </div>
            ))}
          </div>
        )}

        {/* Error State */}
        {error && !loading && (
          <div className="p-6 bg-white rounded-xl border border-red-200 text-sm text-[#171717]">
            <p className="font-medium text-[#D94132] mb-1">検索リクエストで問題が発生しました</p>
            <p className="text-xs text-[#85827D]">{error}</p>
          </div>
        )}

        {/* Results Layout: Split between primary stream and knowledge panel */}
        {!loading && !error && data && (
          <div className="flex flex-col-reverse lg:flex-row gap-8 lg:gap-12 items-start">
            {/* Left: Primary Search Results Column */}
            <div className="flex-1 max-w-3xl space-y-8">
              {/* AI Overview / Neural Summary Card if present */}
              {data.aiSummary && (
                <div className="p-5 bg-white rounded-xl border border-[#E5E2DA] shadow-xs space-y-3">
                  <div className="flex items-center gap-2 text-xs font-semibold tracking-wider text-[#D94132] uppercase">
                    <Sparkles className="w-4 h-4 text-[#D94132]" />
                    <span>{t.aiOverview}</span>
                  </div>
                  <p className="text-sm text-[#171717] leading-relaxed">
                    {data.aiSummary}
                  </p>
                  <div className="pt-2 border-t border-[#F0EEE8] flex items-center justify-between text-[11px] text-[#85827D]">
                    <span>Gemini 3.8 Flash Neural Synthesis</span>
                    <Link href={`/assistant?q=${encodeURIComponent(query)}`} className="text-[#D94132] hover:underline">
                      AIアシスタントでさらに質問する →
                    </Link>
                  </div>
                </div>
              )}

              {/* Zero Results Handling */}
              {data.results.length === 0 && (
                <div className="py-12 text-center max-w-md mx-auto space-y-3">
                  <h3 className="text-lg font-medium text-[#171717]">{t.noResultsTitle}</h3>
                  <p className="text-sm text-[#85827D] leading-relaxed">{t.noResultsDesc}</p>
                  <div className="pt-4 flex justify-center gap-2">
                    {['富士山', '京都', '茶道', 'MIYABI'].map((rec) => (
                      <Link
                        key={rec}
                        href={`/search?q=${encodeURIComponent(rec)}`}
                        className="px-3 py-1.5 bg-white border border-[#E5E2DA] text-xs text-[#171717] rounded-full hover:border-[#D94132] transition-colors"
                      >
                        {rec}
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              {/* Search Result Items */}
              {data.results.map((result: SearchResult) => (
                <article key={result.id} className="space-y-1.5 group">
                  {/* Breadcrumb / Display URL */}
                  <div className="flex items-center gap-2 text-xs text-[#85827D]">
                    <Globe className="w-3.5 h-3.5 text-[#9C9993] shrink-0" />
                    <span className="truncate">{result.displayUrl}</span>
                  </div>

                  {/* Title Link */}
                  <h2 className="text-lg sm:text-xl font-medium leading-snug">
                    <a
                      href={result.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#1A0DAB] hover:underline visited:text-[#609] group-hover:text-[#D94132] transition-colors"
                    >
                      {result.title}
                    </a>
                  </h2>

                  {/* Snippet */}
                  <p className="text-sm text-[#4D5156] leading-relaxed">
                    {result.snippet}
                  </p>

                  {/* Clean unboxed metadata */}
                  <div className="flex items-center gap-2 text-xs text-[#85827D] pt-0.5">
                    {result.publishedAt && (
                      <>
                        <span className="tabular-nums">{result.publishedAt}</span>
                        <span aria-hidden="true">·</span>
                      </>
                    )}
                    <span>{result.category}</span>
                    <span aria-hidden="true">·</span>
                    <span>{result.sourceName}</span>
                  </div>
                </article>
              ))}

              {/* Related Searches Section */}
              {data.relatedSearches && data.relatedSearches.length > 0 && (
                <div className="pt-8 border-t border-[#E5E2DA] space-y-3">
                  <h3 className="text-sm font-medium text-[#171717]">{t.trendingTopics}</h3>
                  <div className="flex flex-wrap gap-2">
                    {data.relatedSearches.map((rel, idx) => (
                      <Link
                        key={idx}
                        href={`/search?q=${encodeURIComponent(rel)}`}
                        className="px-4 py-2 bg-white rounded-full border border-[#E5E2DA] text-xs text-[#171717] hover:border-[#D94132] transition-colors"
                      >
                        {rel}
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              {/* Pagination */}
              <div className="pt-6 pb-12 flex items-center justify-between border-t border-[#E5E2DA] text-sm">
                <button
                  disabled={page <= 1}
                  onClick={() => handlePageChange(page - 1)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-[#E5E2DA] bg-white text-[#171717] disabled:opacity-30 disabled:cursor-not-allowed hover:bg-[#F7F5F1]"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>前へ</span>
                </button>

                <div className="flex items-center gap-1.5 tabular-nums">
                  {[1, 2, 3].map((pNum) => (
                    <button
                      key={pNum}
                      onClick={() => handlePageChange(pNum)}
                      className={`w-8 h-8 rounded-md flex items-center justify-center font-medium transition-colors ${
                        page === pNum
                          ? 'bg-[#171717] text-white'
                          : 'bg-white border border-[#E5E2DA] text-[#171717] hover:bg-[#F7F5F1]'
                      }`}
                    >
                      {pNum}
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => handlePageChange(page + 1)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-[#E5E2DA] bg-white text-[#171717] hover:bg-[#F7F5F1]"
                >
                  <span>次へ</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {/* Privacy Transparency Notice */}
              <div className="p-4 bg-white/60 rounded-xl border border-[#E5E2DA] flex items-start gap-3 text-xs text-[#85827D]">
                <ShieldCheck className="w-4 h-4 text-[#D94132] shrink-0 mt-0.5" />
                <p className="leading-relaxed">{t.privacyNotice}</p>
              </div>
            </div>

            {/* Right: Knowledge Panel */}
            {data.knowledgeCard && (
              <KnowledgePanel data={data.knowledgeCard} />
            )}
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}

export default function SearchPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-[#F7F5F1] p-12 text-center text-xs text-[#85827D]">読み込み中...</div>}>
      <SearchResultsContent />
    </Suspense>
  );
}
