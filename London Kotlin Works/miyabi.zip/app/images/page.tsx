'use client';

import React, { Suspense, useState, useEffect } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import Image from 'next/image';
import { MiyabiLogo } from '@/components/MiyabiLogo';
import { SearchBar } from '@/components/SearchBar';
import { SearchTabs } from '@/components/SearchTabs';
import { Footer } from '@/components/Footer';
import { useLanguage } from '@/lib/i18n';
import { ImageResult } from '@/lib/search/types';
import { ExternalLink, X, Download, Maximize2 } from 'lucide-react';

function ImageSearchContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const { t } = useLanguage();

  const query = searchParams.get('q') || '';
  const [images, setImages] = useState<ImageResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState<ImageResult | null>(null);

  useEffect(() => {
    let cancelled = false;
    async function loadImages() {
      setLoading(true);
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(query)}&category=images`);
        if (res.ok) {
          const data = await res.json();
          if (!cancelled) setImages(data.images || []);
        }
      } catch (err) {
        console.error('Failed to load images:', err);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    loadImages();
    return () => {
      cancelled = true;
    };
  }, [query]);

  return (
    <div className="min-h-screen flex flex-col justify-between bg-[#F7F5F1]">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-[#F7F5F1]/95 backdrop-blur-md border-b border-[#E5E2DA]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12 py-3.5 flex items-center gap-4 sm:gap-8">
          <MiyabiLogo compact />
          <div className="flex-1 max-w-2xl">
            <SearchBar
              initialQuery={query}
              variant="compact"
              onSearchSubmit={(newQ) => {
                router.push(`/images?q=${encodeURIComponent(newQ)}`);
              }}
            />
          </div>
        </div>
        <SearchTabs currentCategory="images" query={query} />
      </header>

      {/* Main Image Grid */}
      <main className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-12 py-8 flex-1">
        <div className="flex items-center justify-between pb-6 mb-6 border-b border-[#E5E2DA] text-xs text-[#85827D]">
          <span>{query ? `「${query}」の画像結果` : 'おすすめの風景・文化画像'}</span>
          <span>高精細アーカイブ</span>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((n) => (
              <div key={n} className="aspect-4/3 bg-[#E5E2DA] rounded-xl animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {images.map((img) => (
              <div
                key={img.id}
                onClick={() => setSelectedImage(img)}
                className="group relative rounded-xl overflow-hidden bg-white border border-[#E5E2DA] shadow-xs hover:shadow-md cursor-pointer transition-all duration-200"
              >
                <div className="relative aspect-4/3 w-full bg-[#F0EEE8] overflow-hidden">
                  <Image
                    src={img.url}
                    alt={img.altText}
                    fill
                    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
                    referrerPolicy="no-referrer"
                    className="object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
                    <span className="p-2 bg-white/90 rounded-full text-[#171717] shadow-sm">
                      <Maximize2 className="w-4 h-4" />
                    </span>
                  </div>
                </div>

                <div className="p-3.5 space-y-1">
                  <h3 className="text-xs font-medium text-[#171717] truncate">{img.title}</h3>
                  <div className="flex items-center justify-between text-[11px] text-[#85827D]">
                    <span className="truncate">{img.sourceDomain}</span>
                    <span className="tabular-nums font-mono">{img.dimensions.width}×{img.dimensions.height}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Image Detail Modal */}
      {selectedImage && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 sm:p-8 animate-in fade-in"
          onClick={() => setSelectedImage(null)}
        >
          <div
            className="relative max-w-4xl w-full bg-white rounded-2xl overflow-hidden shadow-2xl border border-[#E5E2DA] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-6 py-4 border-b border-[#F0EEE8]">
              <div className="truncate pr-4">
                <h3 className="text-sm font-medium text-[#171717] truncate">{selectedImage.title}</h3>
                <p className="text-xs text-[#85827D]">{selectedImage.sourceDomain}</p>
              </div>
              <button
                onClick={() => setSelectedImage(null)}
                className="p-1.5 text-[#85827D] hover:text-[#171717] rounded-full hover:bg-[#F7F5F1]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="relative w-full h-[60vh] bg-[#171717]">
              <Image
                src={selectedImage.url}
                alt={selectedImage.altText}
                fill
                sizes="100vw"
                referrerPolicy="no-referrer"
                className="object-contain"
              />
            </div>

            <div className="px-6 py-4 bg-[#F7F5F1] flex flex-wrap items-center justify-between gap-4 text-xs">
              <div className="flex items-center gap-4 text-[#85827D]">
                <span>解像度: <strong className="text-[#171717] tabular-nums font-mono">{selectedImage.dimensions.width} × {selectedImage.dimensions.height}</strong></span>
                <span aria-hidden="true">·</span>
                <span>提供元: <strong className="text-[#171717]">{selectedImage.sourceDomain}</strong></span>
              </div>

              <div className="flex items-center gap-3">
                <a
                  href={selectedImage.url}
                  download
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-white border border-[#E5E2DA] text-[#171717] hover:bg-[#F0EEE8] transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>画像を保存</span>
                </a>
                <a
                  href={selectedImage.sourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#D94132] text-white hover:bg-[#C2382A] transition-colors"
                >
                  <span>ウェブサイトを表示</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}

export default function ImagesPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-[#F7F5F1] p-12 text-center text-xs text-[#85827D]">画像ギャラリーを読み込み中...</div>}>
      <ImageSearchContent />
    </Suspense>
  );
}
