# MIYABI (みやび) — A Next-Generation Japanese Search Engine

> **"美しさを、見つける。"**  
> *A clearer tomorrow through better search.*

MIYABI is a conceptual Japanese search platform envisioned for Tokyo in the late 2020s. Its identity combines Japanese minimalism (*Ma* — purposeful negative space, *Wabi-sabi* — restrained warmth and quiet craftsmanship) with the speed, responsiveness, and algorithmic precision of a modern world-class search platform.

---

## 1. Project Architecture

MIYABI is built on Next.js 15+ (App Router) with TypeScript and Tailwind CSS:

```
├── app/
│   ├── layout.tsx            # Global typography (Noto Sans JP, Noto Serif JP), metadata & LanguageProvider
│   ├── page.tsx              # Homepage with visual identity, hero headline, pill search, shortcuts & Fuji backdrop
│   ├── globals.css           # Japanese aesthetic color tokens (#F7F5F1 porcelain, #D94132 vermilion, #171717 charcoal)
│   ├── search/page.tsx       # Search results interface with query parsing, AI overview & KnowledgePanel
│   ├── images/page.tsx       # High-fidelity image search gallery with modal preview & dimensions
│   ├── news/page.tsx         # Refined news search interface with source attribution & time filters
│   ├── maps/page.tsx         # Interactive cartography with topographic vector viewer & place cards
│   ├── assistant/page.tsx    # Conversational AI search assistant powered by server-side Gemini 3.8 Flash
│   ├── settings/page.tsx     # Language preference, local search history manager, & architecture roadmap
│   └── api/
│       ├── search/route.ts   # Core search query API with validation, scoring, and filters
│       ├── suggest/route.ts  # Autocomplete prefix suggestions API
│       └── assistant/route.ts# Server-side Gemini API AI assistant route with verified citations
├── components/
│   ├── MiyabiLogo.tsx        # Vermilion circular seal with stylized Fuji silhouette & MIYABI wordmark
│   ├── Header.tsx            # 3-zone navigation bar with active vermilion underlines and mobile drawer
│   ├── SearchBar.tsx         # Pill-shaped input with clear button, suggestions, and keyboard controls
│   ├── QuickShortcuts.tsx    # 4 minimalist shortcuts (Images, News, Maps, AI Assistant)
│   ├── SearchTabs.tsx        # Category switcher (All, Images, News, Videos, Maps)
│   ├── KnowledgePanel.tsx    # Editorial knowledge card for canonical entities (Fuji, Kyoto, Tea, MIYABI)
│   └── Footer.tsx            # Understated editorial footer with bilingual language selector
├── lib/
│   ├── i18n.tsx              # Bilingual localisation context (Japanese default, English)
│   ├── history.ts            # Client-side local search history manager (zero telemetry / local-only)
│   └── search/
│       ├── types.ts          # Strongly typed search queries, results, news, places, and knowledge cards
│       ├── demo-provider.ts  # Rich Japanese and international search corpus with token matching
│       └── provider.ts       # Interchangeable SearchService orchestrator with Gemini AI Overview
├── public/
│   └── images/               # High-resolution panoramic Fuji landscape and cultural assets
└── scripts/
    └── test-runner.mjs       # Automated QA test runner validating 15 core system behaviors
```

---

## 2. Key Features

- **Exact Visual Reproduction**: Matches the authentic Japanese visual reference with Mount Fuji, Lake Kawaguchi, and pale morning cherry blossoms.
- **Bilingual Interface**: Full support for Japanese (日本語) and English with client-side persistence in `localStorage`.
- **Search Auto-Suggestions & History**: Interactive combobox with keyboard arrow navigation (Up/Down/Enter/Escape), quick history deletion, and zero-tracking privacy policy.
- **Search Results (`/search?q=...`)**: Unboxed typographic hierarchy, page latency indicators, pagination, and side Knowledge Panels for key cultural entities.
- **Image Search (`/images?q=...`)**: Editorial image grid with full-screen inspection modal, dimensions, and download actions.
- **News Search (`/news?q=...`)**: Publisher-attributed journalistic feed with time filters (Domestic vs. International).
- **Maps Experience (`/maps?q=...`)**: Interactive topographic vector cartography with place markers for Mount Fuji, Lake Kawaguchi, Ryōan-ji (Kyoto), and Ginza (Tokyo).
- **AI Search Assistant (`/assistant`)**: Conversational search engine powered by `gemini-3.8-flash` via `@google/genai` on server-side routes with citation brackets and markdown rendering.
- **Architecture Specification (`/settings#architecture`)**: Full technical blueprint covering Japanese morphological analysis (MeCab/Kuromoji), NFKC Unicode normalisation, hybrid sparse-dense vector indexing, and anti-spam scoring.

---

## 3. Installation & Local Development

### Prerequisites
- Node.js 20+
- npm

### Commands
```bash
# Install dependencies
npm install

# Start development server (Port 3000)
npm run dev

# Run automated QA test suite (Tests 1-15)
npm test

# Production build
npm run build

# Start production server
npm start
```

---

## 4. Environment Variables

Create a `.env.local` file based on `.env.example`:

| Variable | Description | Default / Requirement |
| :--- | :--- | :--- |
| `GEMINI_API_KEY` | Server-side Gemini API key for live AI Assistant and AI Overview synthesis | Optional (Graceful fallback to demo mode) |
| `APP_URL` | Hosted application base URL | Injected automatically by Cloud Run / AI Studio |
| `SEARCH_API_KEY` | Optional external search engine adapter key | Unset (uses Demonstration Provider) |
| `SEARCH_API_ENDPOINT`| Optional endpoint URL for custom inverted index | Unset |

---

## 5. Security & Privacy Philosophy

1. **Zero Tracking**: MIYABI collects no telemetry, cookies, or user identifiers.
2. **Local History Only**: Search history is strictly retained inside the user's browser `localStorage` and never transmitted across the network. A 1-click "履歴を消去" (Clear History) control is provided.
3. **Server-Side API Keys**: The Gemini API key is never bundled in frontend JavaScript. All requests go through `/api/assistant` and `/api/search`.

---

## 6. Known Limitations & Roadmap

- External web search operates on the curated Demonstration Provider when external search crawler credentials are not supplied.
- Live AI Assistant requires `GEMINI_API_KEY` in environment variables; in local development without a key, an intelligent demonstration agent provides contextual answers.
