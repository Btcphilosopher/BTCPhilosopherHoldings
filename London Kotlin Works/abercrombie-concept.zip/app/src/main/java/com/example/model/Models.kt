package com.example.model

data class ProductVariant(
  val colorName: String,
  val colorHex: String,
  val size: String,
  val length: String = "Regular",
  val stockCount: Int
)

data class Product(
  val id: String,
  val title: String,
  val category: String, // Denim, Dresses, Shirts, Knitwear, Outerwear, Trousers, Accessories
  val price: Double,
  val originalPrice: Double? = null,
  val description: String,
  val imageUrls: List<String>,
  val colors: List<ColorOption>,
  val sizes: List<String>,
  val lengths: List<String> = listOf("Short", "Regular", "Long"),
  val fitType: String, // e.g. "High Rise Straight", "Relaxed Fit", "Tailored"
  val material: String,
  val careInstructions: String,
  val isNewArrival: Boolean = false,
  val isFeatured: Boolean = false,
  val rating: Double = 4.8,
  val reviewCount: Int = 124,
  val variants: List<ProductVariant>
) {
  fun isVariantInStock(color: String, size: String, length: String): Boolean {
    val v = variants.find { it.colorName == color && it.size == size && it.length == length }
    return v != null && v.stockCount > 0
  }
}

data class ColorOption(
  val name: String,
  val hex: String,
  val previewUrl: String
)

data class Outfit(
  val id: String,
  val title: String,
  val subtitle: String,
  val imageUrl: String,
  val productIds: List<String>,
  val bundleDiscountPercent: Int = 15
)

data class CartItem(
  val cartItemId: String,
  val product: Product,
  val selectedColor: String,
  val selectedSize: String,
  val selectedLength: String,
  val quantity: Int = 1
) {
  val unitPrice: Double get() = product.price
  val totalPrice: Double get() = unitPrice * quantity
}

data class Order(
  val orderId: String,
  val date: String,
  val items: List<CartItem>,
  val subtotal: Double,
  val tax: Double,
  val shipping: Double,
  val total: Double,
  val status: String, // "Order Accepted", "Picking", "Ready for Collection", "Partially Shipped", "Shipped", "Delivered", "Returned"
  val trackingNumber: String,
  val deliveryType: String, // "Click & Collect" or "Standard Shipping"
  val storeName: String? = null,
  val collectionRef: String? = null,
  val returnStatus: String? = null // "None", "Requested", "Inspection", "Refunded"
)

data class Store(
  val id: String,
  val name: String,
  val city: String,
  val address: String,
  val hours: String,
  val distance: String,
  val facilities: List<String>,
  val phone: String
)

data class UserMeasurements(
  val heightCm: Int = 175,
  val weightKg: Int = 68,
  val preferredFit: String = "True to size",
  val waistInches: Int = 28,
  val chestInches: Int = 36
)

data class LoyaltyAccount(
  val tierName: String = "Abercrombie VIP",
  val points: Int = 850,
  val lifetimeSpent: Double = 1240.00,
  val availableRewards: List<String> = listOf("$25 Off Next Purchase", "Free Express Delivery", "Early Access to The Weekend Edit")
)
