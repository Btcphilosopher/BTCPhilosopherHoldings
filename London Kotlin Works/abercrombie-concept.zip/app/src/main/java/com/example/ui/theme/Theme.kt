package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LightColorScheme =
  lightColorScheme(
    primary = EspressoPrimary,
    onPrimary = SurfaceColor,
    secondary = CharcoalSecondary,
    onSecondary = SurfaceColor,
    tertiary = TanAccent,
    background = IvoryBackground,
    onBackground = EspressoPrimary,
    surface = SurfaceColor,
    onSurface = EspressoPrimary,
    surfaceVariant = SoftGray,
    onSurfaceVariant = CharcoalSecondary,
    outline = BorderColor,
    error = ErrorColor
  )

private val DarkColorScheme =
  darkColorScheme(
    primary = SurfaceColor,
    onPrimary = EspressoPrimary,
    secondary = TanAccent,
    onSecondary = EspressoPrimary,
    tertiary = NavyAccent,
    background = Color(0xFF121110),
    onBackground = IvoryBackground,
    surface = Color(0xFF1A1816),
    onSurface = IvoryBackground,
    surfaceVariant = Color(0xFF262320),
    onSurfaceVariant = Color(0xFFDCD6CE),
    outline = Color(0xFF3C3834),
    error = ErrorColor
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }
      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
