package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.LocalShipping
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LoyaltyAccount
import com.example.model.Order
import com.example.ui.theme.*

@Composable
fun AccountScreen(
  loyalty: LoyaltyAccount,
  orders: List<Order>,
  onOrderClick: (Order) -> Unit,
  onOpenAdmin: () -> Unit
) {
  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = "Alexander Vance", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = EspressoPrimary)
          Spacer(modifier = Modifier.height(2.dp))
          Text(text = "alexander@example.com", fontSize = 13.sp, color = CharcoalSecondary)
        }
        OutlinedButton(
          onClick = onOpenAdmin,
          shape = RoundedCornerShape(4.dp),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = EspressoPrimary),
          modifier = Modifier.testTag("open_admin_btn")
        ) {
          Icon(Icons.Outlined.AdminPanelSettings, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Admin", fontSize = 12.sp)
        }
      }
    }

    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = EspressoPrimary),
        shape = RoundedCornerShape(8.dp)
      ) {
        Column(modifier = Modifier.padding(20.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.Star, contentDescription = null, tint = TanAccent, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = loyalty.tierName.uppercase(), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TanAccent, letterSpacing = 1.5.sp)
          }
          Spacer(modifier = Modifier.height(12.dp))
          Text(text = "${loyalty.points} Points Available", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = SurfaceColor)
          Spacer(modifier = Modifier.height(4.dp))
          Text(text = "Lifetime spend: $${loyalty.lifetimeSpent.toInt()}", fontSize = 13.sp, color = Color.LightGray)
          Spacer(modifier = Modifier.height(16.dp))
          Text(text = "Active Rewards:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = SurfaceColor)
          Spacer(modifier = Modifier.height(6.dp))
          loyalty.availableRewards.forEach { reward ->
            Text(text = "• $reward", fontSize = 12.sp, color = Color.LightGray)
          }
        }
      }
    }

    item {
      Text(text = "Recent Orders", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = EspressoPrimary)
      Spacer(modifier = Modifier.height(4.dp))
    }

    items(orders) { order ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onOrderClick(order) }
          .testTag("order_item_${order.orderId}"),
        colors = CardDefaults.cardColors(containerColor = SurfaceColor),
        shape = RoundedCornerShape(6.dp)
      ) {
        Row(
          modifier = Modifier.padding(16.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(Icons.Outlined.LocalShipping, contentDescription = null, tint = EspressoPrimary)
            Column {
              Text(text = "Order #${order.orderId}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = EspressoPrimary)
              Spacer(modifier = Modifier.height(2.dp))
              Text(text = "${order.date} · ${order.status}", fontSize = 12.sp, color = CharcoalSecondary)
            }
          }
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = "$${order.total.toInt()}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = EspressoPrimary)
            Spacer(modifier = Modifier.width(8.dp))
            Icon(Icons.Outlined.ChevronRight, contentDescription = null, tint = CharcoalSecondary)
          }
        }
      }
    }
  }
}
