package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Store
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Order
import com.example.model.Store
import com.example.ui.theme.*

@Composable
fun StoresScreen(
  stores: List<Store>,
  orders: List<Order>,
  onAdvanceStatus: (String) -> Unit
) {
  var searchQuery by remember { mutableStateOf("") }
  val filteredStores = stores.filter { it.name.contains(searchQuery, true) || it.city.contains(searchQuery, true) }
  val clickAndCollectOrders = orders.filter { it.deliveryType == "Click & Collect" }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Text(text = "Store Services & Collection", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = EspressoPrimary)
      Spacer(modifier = Modifier.height(12.dp))
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text("Search by city or store name...") },
        modifier = Modifier.fillMaxWidth().testTag("store_search_input"),
        shape = RoundedCornerShape(4.dp),
        singleLine = true
      )
    }

    if (clickAndCollectOrders.isNotEmpty()) {
      item {
        Text(text = "Active Click & Collect Orders", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = EspressoPrimary)
        Spacer(modifier = Modifier.height(8.dp))
      }
      items(clickAndCollectOrders) { order ->
        Card(
          modifier = Modifier.fillMaxWidth().testTag("collect_order_${order.orderId}"),
          colors = CardDefaults.cardColors(containerColor = SurfaceColor),
          shape = RoundedCornerShape(8.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(text = "Order #${order.orderId}", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = EspressoPrimary)
              Text(text = order.status, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = if (order.status == "Collected") SuccessColor else TanAccent)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = "Store: ${order.storeName}", fontSize = 13.sp, color = CharcoalSecondary)
            if (order.collectionRef != null) {
              Spacer(modifier = Modifier.height(2.dp))
              Text(text = "Collection Reference: ${order.collectionRef}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = EspressoPrimary)
            }
            Spacer(modifier = Modifier.height(12.dp))
            if (order.status != "Collected") {
              Button(
                onClick = { onAdvanceStatus(order.orderId) },
                shape = RoundedCornerShape(4.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EspressoPrimary),
                modifier = Modifier.fillMaxWidth().testTag("advance_status_btn_${order.orderId}")
              ) {
                Text("Simulate Staff Handover / Next Status")
              }
            } else {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.CheckCircle, contentDescription = null, tint = SuccessColor, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Successfully Collected", color = SuccessColor, fontWeight = FontWeight.Bold, fontSize = 13.sp)
              }
            }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(8.dp))
      Text(text = "Flagship & Local Stores", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = EspressoPrimary)
    }

    items(filteredStores) { store ->
      Card(
        modifier = Modifier.fillMaxWidth().testTag("store_card_${store.id}"),
        colors = CardDefaults.cardColors(containerColor = SurfaceColor),
        shape = RoundedCornerShape(8.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.Store, contentDescription = null, tint = EspressoPrimary, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = store.name, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = EspressoPrimary)
          }
          Spacer(modifier = Modifier.height(6.dp))
          Text(text = store.address, fontSize = 13.sp, color = CharcoalSecondary)
          Spacer(modifier = Modifier.height(4.dp))
          Text(text = store.hours, fontSize = 13.sp, color = CharcoalSecondary)
          Spacer(modifier = Modifier.height(8.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            store.facilities.forEach { fac ->
              Surface(
                color = SoftGray,
                shape = RoundedCornerShape(2.dp)
              ) {
                Text(
                  text = fac,
                  fontSize = 11.sp,
                  color = EspressoPrimary,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }
          }
        }
      }
    }
  }
}
