package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.LocalShipping
import androidx.compose.material.icons.outlined.Store
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.CartItem
import com.example.model.Store
import com.example.ui.theme.*

@Composable
fun CartCheckoutScreen(
  cartItems: List<CartItem>,
  stores: List<Store>,
  appliedPromoCode: String?,
  discountAmount: Double,
  onUpdateQuantity: (String, Int) -> Unit,
  onRemoveItem: (String) -> Unit,
  onApplyPromo: (String) -> Unit,
  onCompleteCheckout: (deliveryType: String, storeName: String?) -> Unit,
  onBack: () -> Unit
) {
  var checkoutStep by remember { mutableStateOf(0) }
  var deliveryType by remember { mutableStateOf("Click & Collect") }
  var selectedStore by remember { mutableStateOf(stores.first().name) }
  var promoInput by remember { mutableStateOf("") }
  var cardNumber by remember { mutableStateOf("4242 •••• •••• 4242") }

  val subtotal = cartItems.sumOf { it.totalPrice }
  val tax = subtotal * 0.08
  val shipping = if (deliveryType == "Click & Collect") 0.0 else 9.0
  val total = subtotal + tax + shipping - discountAmount

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
  ) {
    if (checkoutStep == 0) {
      Text(text = "Your Shopping Bag (${cartItems.size})", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = EspressoPrimary)
      Spacer(modifier = Modifier.height(16.dp))

      if (cartItems.isEmpty()) {
        Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
          Text("Your bag is empty.", color = CharcoalSecondary, fontSize = 15.sp)
        }
      } else {
        LazyColumn(
          modifier = Modifier.weight(1f),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          items(cartItems) { item ->
            Card(
              modifier = Modifier.fillMaxWidth().testTag("cart_item_${item.cartItemId}"),
              colors = CardDefaults.cardColors(containerColor = SurfaceColor),
              shape = RoundedCornerShape(6.dp)
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                AsyncImage(
                  model = item.product.imageUrls.first(),
                  contentDescription = item.product.title,
                  modifier = Modifier.size(70.dp).clip(RoundedCornerShape(4.dp)),
                  contentScale = ContentScale.Crop
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(text = item.product.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = EspressoPrimary, maxLines = 1)
                  Spacer(modifier = Modifier.height(2.dp))
                  Text(text = "${item.selectedColor} · Size ${item.selectedSize} · ${item.selectedLength}", fontSize = 12.sp, color = CharcoalSecondary)
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(text = "$${item.unitPrice.toInt()}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = EspressoPrimary)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  OutlinedButton(
                    onClick = { onUpdateQuantity(item.cartItemId, item.quantity - 1) },
                    shape = RoundedCornerShape(4.dp),
                    contentPadding = PaddingValues(4.dp),
                    modifier = Modifier.size(28.dp).testTag("decrease_qty_${item.cartItemId}")
                  ) {
                    Text("-", fontSize = 12.sp)
                  }
                  Text(text = item.quantity.toString(), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                  OutlinedButton(
                    onClick = { onUpdateQuantity(item.cartItemId, item.quantity + 1) },
                    shape = RoundedCornerShape(4.dp),
                    contentPadding = PaddingValues(4.dp),
                    modifier = Modifier.size(28.dp).testTag("increase_qty_${item.cartItemId}")
                  ) {
                    Text("+", fontSize = 12.sp)
                  }
                  IconButton(onClick = { onRemoveItem(item.cartItemId) }, modifier = Modifier.testTag("remove_cart_${item.cartItemId}")) {
                    Icon(Icons.Outlined.Delete, contentDescription = null, tint = CharcoalSecondary, modifier = Modifier.size(18.dp))
                  }
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          OutlinedTextField(
            value = promoInput,
            onValueChange = { promoInput = it },
            placeholder = { Text("Promo code (e.g. CONSIDERED20)") },
            modifier = Modifier.weight(1f).testTag("promo_input"),
            shape = RoundedCornerShape(4.dp),
            singleLine = true
          )
          Button(
            onClick = { onApplyPromo(promoInput) },
            shape = RoundedCornerShape(4.dp),
            colors = ButtonDefaults.buttonColors(containerColor = EspressoPrimary),
            modifier = Modifier.testTag("apply_promo_btn")
          ) {
            Text("Apply")
          }
        }
        if (appliedPromoCode != null) {
          Spacer(modifier = Modifier.height(4.dp))
          Text("Promo code '$appliedPromoCode' applied successfully!", color = SuccessColor, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
          colors = CardDefaults.cardColors(containerColor = SurfaceColor),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("Subtotal", fontSize = 13.sp, color = CharcoalSecondary)
              Text("$${subtotal.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
            if (discountAmount > 0.0) {
              Spacer(modifier = Modifier.height(4.dp))
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Discount ($appliedPromoCode)", fontSize = 13.sp, color = SuccessColor)
                Text("-$${discountAmount.toInt()}", fontSize = 13.sp, color = SuccessColor, fontWeight = FontWeight.Medium)
              }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("Estimated Tax", fontSize = 13.sp, color = CharcoalSecondary)
              Text("$${String.format("%.2f", tax)}", fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("Shipping", fontSize = 13.sp, color = CharcoalSecondary)
              Text(if (shipping == 0.0) "FREE" else "$${shipping.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = BorderColor)
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("Total", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = EspressoPrimary)
              Text("$${String.format("%.2f", total)}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = EspressoPrimary)
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
          onClick = { checkoutStep = 1 },
          modifier = Modifier.fillMaxWidth().height(50.dp).testTag("proceed_checkout_btn"),
          shape = RoundedCornerShape(4.dp),
          colors = ButtonDefaults.buttonColors(containerColor = EspressoPrimary)
        ) {
          Text("Proceed to checkout", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
      }
    } else if (checkoutStep == 1) {
      Text(text = "Choose Fulfilment", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = EspressoPrimary)
      Spacer(modifier = Modifier.height(16.dp))

      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(
          onClick = { deliveryType = "Click & Collect" },
          colors = ButtonDefaults.buttonColors(
            containerColor = if (deliveryType == "Click & Collect") EspressoPrimary else SurfaceColor,
            contentColor = if (deliveryType == "Click & Collect") SurfaceColor else EspressoPrimary
          ),
          shape = RoundedCornerShape(4.dp),
          modifier = Modifier.weight(1f).testTag("click_collect_tab")
        ) {
          Icon(Icons.Outlined.Store, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Click & Collect", fontSize = 13.sp)
        }
        Button(
          onClick = { deliveryType = "Standard Shipping" },
          colors = ButtonDefaults.buttonColors(
            containerColor = if (deliveryType == "Standard Shipping") EspressoPrimary else SurfaceColor,
            contentColor = if (deliveryType == "Standard Shipping") SurfaceColor else EspressoPrimary
          ),
          shape = RoundedCornerShape(4.dp),
          modifier = Modifier.weight(1f).testTag("shipping_tab")
        ) {
          Icon(Icons.Outlined.LocalShipping, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Home Delivery", fontSize = 13.sp)
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      if (deliveryType == "Click & Collect") {
        Text(text = "Select Collection Store:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(8.dp))
        stores.forEach { store ->
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 4.dp)
              .testTag("store_option_${store.id}"),
            colors = CardDefaults.cardColors(
              containerColor = if (selectedStore == store.name) TanAccent.copy(alpha = 0.2f) else SurfaceColor
            ),
            shape = RoundedCornerShape(6.dp)
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .clickable { selectedStore = store.name }
                .padding(16.dp)
            ) {
              Text(text = store.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = EspressoPrimary)
              Spacer(modifier = Modifier.height(2.dp))
              Text(text = store.address, fontSize = 12.sp, color = CharcoalSecondary)
            }
          }
        }
      } else {
        OutlinedTextField(
          value = "742 Evergreen Terrace, New York, NY 10001",
          onValueChange = {},
          label = { Text("Delivery Address") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(4.dp)
        )
      }

      Spacer(modifier = Modifier.weight(1f))

      Button(
        onClick = { checkoutStep = 2 },
        modifier = Modifier.fillMaxWidth().height(50.dp).testTag("proceed_payment_btn"),
        shape = RoundedCornerShape(4.dp),
        colors = ButtonDefaults.buttonColors(containerColor = EspressoPrimary)
      ) {
        Text("Continue to payment", fontWeight = FontWeight.Bold, fontSize = 15.sp)
      }
    } else if (checkoutStep == 2) {
      Text(text = "Secure Payment", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = EspressoPrimary)
      Spacer(modifier = Modifier.height(16.dp))

      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SurfaceColor),
        shape = RoundedCornerShape(8.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(text = "Credit Card (Simulated)", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = EspressoPrimary)
          Spacer(modifier = Modifier.height(12.dp))
          OutlinedTextField(
            value = cardNumber,
            onValueChange = { cardNumber = it },
            label = { Text("Card Number") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(4.dp)
          )
        }
      }

      Spacer(modifier = Modifier.weight(1f))

      Button(
        onClick = {
          onCompleteCheckout(deliveryType, if (deliveryType == "Click & Collect") selectedStore else null)
          checkoutStep = 3
        },
        modifier = Modifier.fillMaxWidth().height(50.dp).testTag("complete_order_btn"),
        shape = RoundedCornerShape(4.dp),
        colors = ButtonDefaults.buttonColors(containerColor = EspressoPrimary)
      ) {
        Text("Pay & Place Order", fontWeight = FontWeight.Bold, fontSize = 15.sp)
      }
    } else {
      Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(Icons.Outlined.CheckCircle, contentDescription = null, tint = SuccessColor, modifier = Modifier.size(64.dp))
          Spacer(modifier = Modifier.height(16.dp))
          Text(text = "Order Placed Successfully!", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = EspressoPrimary)
          Spacer(modifier = Modifier.height(8.dp))
          Text(text = if (deliveryType == "Click & Collect") "Ready for pickup at $selectedStore" else "Shipped to your address", fontSize = 14.sp, color = CharcoalSecondary)
          Spacer(modifier = Modifier.height(24.dp))
          Button(
            onClick = onBack,
            shape = RoundedCornerShape(4.dp),
            colors = ButtonDefaults.buttonColors(containerColor = EspressoPrimary),
            modifier = Modifier.testTag("return_home_btn")
          ) {
            Text("Back to Discover")
          }
        }
      }
    }
  }
}
