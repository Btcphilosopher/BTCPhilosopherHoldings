package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Inventory
import androidx.compose.material.icons.outlined.LocalShipping
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Order
import com.example.model.Product
import com.example.ui.theme.*

@Composable
fun AdminConsoleScreen(
  products: List<Product>,
  orders: List<Order>,
  onBack: () -> Unit,
  onRequestReturn: (String) -> Unit
) {
  var selectedTab by remember { mutableStateOf("Orders") }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        IconButton(onClick = onBack, modifier = Modifier.testTag("admin_back_btn")) {
          Icon(Icons.Outlined.ArrowBack, contentDescription = null, tint = EspressoPrimary)
        }
        Text(text = "Staff Admin Console", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = EspressoPrimary)
      }
      Surface(
        color = TanAccent.copy(alpha = 0.2f),
        shape = RoundedCornerShape(4.dp)
      ) {
        Text("SECURE ACCESS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = EspressoPrimary, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
      Button(
        onClick = { selectedTab = "Orders" },
        colors = ButtonDefaults.buttonColors(
          containerColor = if (selectedTab == "Orders") EspressoPrimary else SurfaceColor,
          contentColor = if (selectedTab == "Orders") SurfaceColor else EspressoPrimary
        ),
        shape = RoundedCornerShape(4.dp)
      ) {
        Icon(Icons.Outlined.LocalShipping, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("Fulfillment & Orders")
      }
      Button(
        onClick = { selectedTab = "Inventory" },
        colors = ButtonDefaults.buttonColors(
          containerColor = if (selectedTab == "Inventory") EspressoPrimary else SurfaceColor,
          contentColor = if (selectedTab == "Inventory") SurfaceColor else EspressoPrimary
        ),
        shape = RoundedCornerShape(4.dp)
      ) {
        Icon(Icons.Outlined.Inventory, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("Catalogue Inventory")
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    if (selectedTab == "Orders") {
      LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(orders) { order ->
          Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = SurfaceColor),
            shape = RoundedCornerShape(6.dp)
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(text = "Order #${order.orderId}", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = EspressoPrimary)
                Text(text = order.status, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TanAccent)
              }
              Spacer(modifier = Modifier.height(6.dp))
              Text(text = "Type: ${order.deliveryType} · Total: $${order.total.toInt()}", fontSize = 13.sp, color = CharcoalSecondary)
              Spacer(modifier = Modifier.height(8.dp))
              if (order.returnStatus == "None") {
                OutlinedButton(
                  onClick = { onRequestReturn(order.orderId) },
                  shape = RoundedCornerShape(4.dp),
                  modifier = Modifier.testTag("admin_request_return_${order.orderId}")
                ) {
                  Text("Process Return / Refund", fontSize = 12.sp)
                }
              } else {
                Text(text = "Return Status: ${order.returnStatus}", fontSize = 12.sp, color = ErrorColor, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    } else {
      LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(products) { product ->
          Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = SurfaceColor),
            shape = RoundedCornerShape(6.dp)
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text(text = product.title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = EspressoPrimary)
              Spacer(modifier = Modifier.height(4.dp))
              Text(text = "Category: ${product.category} · Price: $${product.price.toInt()}", fontSize = 13.sp, color = CharcoalSecondary)
              Spacer(modifier = Modifier.height(6.dp))
              Text(text = "Total SKUs / Variants: ${product.variants.size} variants configured", fontSize = 12.sp, color = EspressoPrimary)
            }
          }
        }
      }
    }
  }
}
