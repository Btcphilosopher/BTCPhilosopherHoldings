package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.Outfit
import com.example.model.Product
import com.example.ui.theme.*

@Composable
fun SavedScreen(
  products: List<Product>,
  savedProductIds: Set<String>,
  outfits: List<Outfit>,
  onProductClick: (String) -> Unit,
  onToggleSave: (String) -> Unit,
  onAddOutfitToCart: (Outfit) -> Unit
) {
  var selectedTab by remember { mutableStateOf("Items") }
  val savedProducts = products.filter { savedProductIds.contains(it.id) }

  Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
    Text(text = "Saved & Outfits", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = EspressoPrimary)
    Spacer(modifier = Modifier.height(16.dp))

    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
      Button(
        onClick = { selectedTab = "Items" },
        colors = ButtonDefaults.buttonColors(
          containerColor = if (selectedTab == "Items") EspressoPrimary else SurfaceColor,
          contentColor = if (selectedTab == "Items") SurfaceColor else EspressoPrimary
        ),
        shape = RoundedCornerShape(4.dp),
        modifier = Modifier.testTag("saved_items_tab")
      ) {
        Text("Saved Items (${savedProducts.size})")
      }
      Button(
        onClick = { selectedTab = "Outfits" },
        colors = ButtonDefaults.buttonColors(
          containerColor = if (selectedTab == "Outfits") EspressoPrimary else SurfaceColor,
          contentColor = if (selectedTab == "Outfits") SurfaceColor else EspressoPrimary
        ),
        shape = RoundedCornerShape(4.dp),
        modifier = Modifier.testTag("outfits_tab")
      ) {
        Text("Outfits & Edits (${outfits.size})")
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    if (selectedTab == "Items") {
      if (savedProducts.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          Text("No saved items yet.", color = CharcoalSecondary, fontSize = 14.sp)
        }
      } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          items(savedProducts) { product ->
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .clickable { onProductClick(product.id) }
                .testTag("saved_item_${product.id}"),
              colors = CardDefaults.cardColors(containerColor = SurfaceColor),
              shape = RoundedCornerShape(6.dp)
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                AsyncImage(
                  model = product.imageUrls.first(),
                  contentDescription = product.title,
                  modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(4.dp)),
                  contentScale = ContentScale.Crop
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(text = product.title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = EspressoPrimary)
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(text = "$${product.price.toInt()}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = EspressoPrimary)
                }
                IconButton(onClick = { onToggleSave(product.id) }, modifier = Modifier.testTag("remove_saved_${product.id}")) {
                  Icon(Icons.Outlined.Delete, contentDescription = "Remove", tint = CharcoalSecondary)
                }
              }
            }
          }
        }
      }
    } else {
      LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        items(outfits) { outfit ->
          val outfitProducts = products.filter { outfit.productIds.contains(it.id) }
          val totalPrice = outfitProducts.sumOf { it.price }
          val discountedPrice = totalPrice * (1.0 - outfit.bundleDiscountPercent / 100.0)

          Card(
            modifier = Modifier.fillMaxWidth().testTag("outfit_card_${outfit.id}"),
            colors = CardDefaults.cardColors(containerColor = SurfaceColor),
            shape = RoundedCornerShape(8.dp)
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              AsyncImage(
                model = outfit.imageUrl,
                contentDescription = outfit.title,
                modifier = Modifier
                  .fillMaxWidth()
                  .height(200.dp)
                  .clip(RoundedCornerShape(6.dp)),
                contentScale = ContentScale.Crop
              )
              Spacer(modifier = Modifier.height(12.dp))
              Text(text = outfit.title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = EspressoPrimary)
              Spacer(modifier = Modifier.height(2.dp))
              Text(text = outfit.subtitle, fontSize = 13.sp, color = CharcoalSecondary)
              Spacer(modifier = Modifier.height(12.dp))

              outfitProducts.forEach { op ->
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(text = "• ${op.title}", fontSize = 13.sp, color = EspressoPrimary)
                  Text(text = "$${op.price.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
              }

              Spacer(modifier = Modifier.height(12.dp))
              Divider(color = BorderColor)
              Spacer(modifier = Modifier.height(12.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(text = "Total (${outfit.bundleDiscountPercent}% bundle save):", fontSize = 12.sp, color = CharcoalSecondary)
                  Text(text = "$${discountedPrice.toInt()}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = EspressoPrimary)
                }
                Button(
                  onClick = { onAddOutfitToCart(outfit) },
                  shape = RoundedCornerShape(4.dp),
                  colors = ButtonDefaults.buttonColors(containerColor = EspressoPrimary),
                  modifier = Modifier.testTag("add_outfit_btn_${outfit.id}")
                ) {
                  Icon(Icons.Outlined.ShoppingBag, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("Add outfit to bag", fontSize = 13.sp)
                }
              }
            }
          }
        }
      }
    }
  }
}
