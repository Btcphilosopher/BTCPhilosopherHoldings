package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.Outfit
import com.example.model.Product
import com.example.ui.theme.CharcoalSecondary
import com.example.ui.theme.EspressoPrimary
import com.example.ui.theme.SurfaceColor

@Composable
fun DiscoverScreen(
  products: List<Product>,
  outfits: List<Outfit>,
  onProductClick: (String) -> Unit,
  onShopCategory: (String) -> Unit
) {
  val scrollState = rememberScrollState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(scrollState)
      .padding(bottom = 32.dp)
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(480.dp)
        .clickable { onShopCategory("All") }
    ) {
      AsyncImage(
        model = "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=1200&q=80",
        contentDescription = "Everyday considered editorial",
        modifier = Modifier.fillMaxSize(),
        contentScale = ContentScale.Crop
      )
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(EspressoPrimary.copy(alpha = 0.25f))
      )
      Column(
        modifier = Modifier
          .align(Alignment.BottomStart)
          .padding(24.dp)
      ) {
        Text(
          text = "Everyday,\nconsidered.",
          color = SurfaceColor,
          fontSize = 36.sp,
          fontWeight = FontWeight.Bold,
          lineHeight = 42.sp
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(
          onClick = { onShopCategory("All") },
          colors = ButtonDefaults.buttonColors(containerColor = SurfaceColor, contentColor = EspressoPrimary),
          shape = RoundedCornerShape(4.dp),
          modifier = Modifier.testTag("shop_new_arrivals_btn")
        ) {
          Text("Shop new arrivals", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    Text(
      text = "Explore Categories",
      fontSize = 18.sp,
      fontWeight = FontWeight.Bold,
      color = EspressoPrimary,
      modifier = Modifier.padding(horizontal = 16.dp)
    )
    Spacer(modifier = Modifier.height(12.dp))

    val categories = listOf(
      Triple("Denim", "https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&w=400&q=80", "Denim"),
      Triple("Dresses", "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?auto=format&fit=crop&w=400&q=80", "Dresses"),
      Triple("Shirts", "https://images.unsplash.com/photo-1598033129183-c4f50c736f10?auto=format&fit=crop&w=400&q=80", "Shirts"),
      Triple("Knitwear", "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=400&q=80", "Knitwear"),
      Triple("Outerwear", "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=400&q=80", "Outerwear")
    )

    LazyRow(
      contentPadding = PaddingValues(horizontal = 16.dp),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      items(categories) { (catName, imageUrl, filterKey) ->
        Card(
          modifier = Modifier
            .width(130.dp)
            .height(170.dp)
            .clickable { onShopCategory(filterKey) },
          shape = RoundedCornerShape(6.dp)
        ) {
          Box(modifier = Modifier.fillMaxSize()) {
            AsyncImage(
              model = imageUrl,
              contentDescription = catName,
              modifier = Modifier.fillMaxSize(),
              contentScale = ContentScale.Crop
            )
            Box(
              modifier = Modifier
                .fillMaxSize()
                .background(EspressoPrimary.copy(alpha = 0.3f))
            )
            Text(
              text = catName,
              color = SurfaceColor,
              fontWeight = FontWeight.Bold,
              fontSize = 15.sp,
              modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(12.dp)
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(32.dp))

    outfits.forEach { outfit ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceColor)
      ) {
        Column {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .height(320.dp)
          ) {
            AsyncImage(
              model = outfit.imageUrl,
              contentDescription = outfit.title,
              modifier = Modifier.fillMaxSize(),
              contentScale = ContentScale.Crop
            )
          }
          Column(modifier = Modifier.padding(16.dp)) {
            Text(text = outfit.title.uppercase(), fontSize = 12.sp, color = CharcoalSecondary, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = outfit.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = EspressoPrimary)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = outfit.subtitle, fontSize = 14.sp, color = CharcoalSecondary)
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedButton(
              onClick = { onShopCategory("All") },
              shape = RoundedCornerShape(4.dp),
              modifier = Modifier.testTag("explore_outfit_btn_${outfit.id}")
            ) {
              Text("Explore outfit pieces", color = EspressoPrimary)
              Spacer(modifier = Modifier.width(8.dp))
              Icon(Icons.Outlined.ArrowForward, contentDescription = null, tint = EspressoPrimary, modifier = Modifier.size(16.dp))
            }
          }
        }
      }
      Spacer(modifier = Modifier.height(24.dp))
    }

    Text(
      text = "Featured Essentials",
      fontSize = 18.sp,
      fontWeight = FontWeight.Bold,
      color = EspressoPrimary,
      modifier = Modifier.padding(horizontal = 16.dp)
    )
    Spacer(modifier = Modifier.height(12.dp))

    LazyRow(
      contentPadding = PaddingValues(horizontal = 16.dp),
      horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      items(products.filter { it.isFeatured }) { product ->
        ProductCard(product = product, onClick = { onProductClick(product.id) })
      }
    }
  }
}

@Composable
fun ProductCard(
  product: Product,
  onClick: () -> Unit
) {
  Card(
    modifier = Modifier
      .width(180.dp)
      .clickable(onClick = onClick)
      .testTag("product_card_${product.id}"),
    shape = RoundedCornerShape(6.dp),
    colors = CardDefaults.cardColors(containerColor = SurfaceColor)
  ) {
    Column {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(220.dp)
      ) {
        AsyncImage(
          model = product.imageUrls.first(),
          contentDescription = product.title,
          modifier = Modifier.fillMaxSize(),
          contentScale = ContentScale.Crop
        )
      }
      Column(modifier = Modifier.padding(12.dp)) {
        Text(
          text = product.title,
          fontSize = 14.sp,
          fontWeight = FontWeight.Medium,
          color = EspressoPrimary,
          maxLines = 1
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "$${product.price.toInt()}",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = EspressoPrimary
          )
          if (product.originalPrice != null) {
            Text(
              text = "$${product.originalPrice.toInt()}",
              fontSize = 12.sp,
              color = CharcoalSecondary,
              style = androidx.compose.ui.text.TextStyle(textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough)
            )
          }
        }
      }
    }
  }
}
