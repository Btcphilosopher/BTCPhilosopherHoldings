package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AbercrombieBottomNav
import com.example.ui.components.AbercrombieTopBar
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.ShopViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        AbercrombieApp()
      }
    }
  }
}

@Composable
fun AbercrombieApp() {
  val viewModel: ShopViewModel = viewModel()
  var currentScreen by remember { mutableStateOf("Main") } // "Main", "ProductDetail", "Cart", "Admin"
  var selectedProductId by remember { mutableStateOf<String?>(null) }

  val products by viewModel.products.collectAsState()
  val cartItems = viewModel.cartItems.value
  val savedIds = viewModel.savedProductIds.value
  val outfits = viewModel.outfits
  val stores = viewModel.stores
  val orders = viewModel.orders.value
  val loyalty = viewModel.loyaltyAccount.value

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    topBar = {
      if (currentScreen == "Main") {
        AbercrombieTopBar(
          cartItemCount = cartItems.sumOf { it.quantity },
          onCartClick = { currentScreen = "Cart" },
          onSearchClick = { viewModel.currentTab = "Shop" }
        )
      }
    },
    bottomBar = {
      if (currentScreen == "Main") {
        AbercrombieBottomNav(
          currentTab = viewModel.currentTab,
          onTabSelected = { viewModel.currentTab = it }
        )
      }
    }
  ) { innerPadding ->
    Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
      when (currentScreen) {
        "Main" -> {
          when (viewModel.currentTab) {
            "Discover" -> DiscoverScreen(
              products = products,
              outfits = outfits,
              onProductClick = { id ->
                selectedProductId = id
                currentScreen = "ProductDetail"
              },
              onShopCategory = { cat ->
                viewModel.selectedCategory = cat
                viewModel.currentTab = "Shop"
              }
            )
            "Shop" -> ShopCatalogScreen(
              products = products,
              selectedCategory = viewModel.selectedCategory,
              onCategoryChanged = { viewModel.selectedCategory = it },
              onProductClick = { id ->
                selectedProductId = id
                currentScreen = "ProductDetail"
              }
            )
            "Saved" -> SavedScreen(
              products = products,
              savedProductIds = savedIds,
              outfits = outfits,
              onProductClick = { id ->
                selectedProductId = id
                currentScreen = "ProductDetail"
              },
              onToggleSave = { id -> viewModel.toggleSaveProduct(id) },
              onAddOutfitToCart = { outfit ->
                outfit.productIds.forEach { pid ->
                  viewModel.getProduct(pid)?.let { p ->
                    viewModel.addToCart(p, p.colors.first().name, p.sizes.first(), p.lengths.first(), 1)
                  }
                }
                currentScreen = "Cart"
              }
            )
            "Stores" -> StoresScreen(
              stores = stores,
              orders = orders,
              onAdvanceStatus = { orderId -> viewModel.advanceCollectionStatus(orderId) }
            )
            "Account" -> AccountScreen(
              loyalty = loyalty,
              orders = orders,
              onOrderClick = { },
              onOpenAdmin = { currentScreen = "Admin" }
            )
          }
        }
        "ProductDetail" -> {
          val product = viewModel.getProduct(selectedProductId)
          if (product != null) {
            ProductDetailScreen(
              product = product,
              isSaved = savedIds.contains(product.id),
              onBack = { currentScreen = "Main" },
              onToggleSave = { viewModel.toggleSaveProduct(product.id) },
              onAddToCart = { color, size, length ->
                viewModel.addToCart(product, color, size, length, 1)
              }
            )
          }
        }
        "Cart" -> {
          CartCheckoutScreen(
            cartItems = cartItems,
            stores = stores,
            appliedPromoCode = viewModel.appliedPromoCode,
            discountAmount = viewModel.discountAmount,
            onUpdateQuantity = { id, qty -> viewModel.updateQuantity(id, qty) },
            onRemoveItem = { id -> viewModel.removeFromCart(id) },
            onApplyPromo = { code -> viewModel.applyPromo(code) },
            onCompleteCheckout = { type, storeName -> viewModel.completeCheckout(type, storeName) },
            onBack = { currentScreen = "Main" }
          )
        }
        "Admin" -> {
          AdminConsoleScreen(
            products = products,
            orders = orders,
            onBack = { currentScreen = "Main" },
            onRequestReturn = { orderId -> viewModel.requestReturn(orderId) }
          )
        }
      }
    }
  }
}
