package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val IvoryBackground = Color(0xFFFBF9F5)
val SurfaceColor = Color(0xFFFFFFFF)
val EspressoPrimary = Color(0xFF1E1B18)
val CharcoalSecondary = Color(0xFF4A4540)
val NavyAccent = Color(0xFF1D2A3A)
val TanAccent = Color(0xFFC5A880)
val SoftGray = Color(0xFFF2EFE9)
val MutedText = Color(0xFF7A7570)
val BorderColor = Color(0xFFE5E0D8)
val ErrorColor = Color(0xFFB33939)
val SuccessColor = Color(0xFF2E7D32)
