package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FilterList
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.Product
import com.example.ui.theme.CharcoalSecondary
import com.example.ui.theme.EspressoPrimary
import com.example.ui.theme.SurfaceColor

@Composable
fun ShopCatalogScreen(
  products: List<Product>,
  selectedCategory: String,
  onCategoryChanged: (String) -> Unit,
  onProductClick: (String) -> Unit
) {
  var showFilters by remember { mutableStateOf(false) }
  var filterSize by remember { mutableStateOf<String?>(null) }
  var filterFit by remember { mutableStateOf<String?>(null) }

  val categories = listOf("All", "Denim", "Dresses", "Shirts", "Knitwear", "Outerwear", "Trousers", "Accessories")

  val filteredProducts = products.filter { p ->
    val matchesCategory = selectedCategory == "All" || p.category.equals(selectedCategory, ignoreCase = true)
    val matchesSize = filterSize == null || p.sizes.contains(filterSize)
    val matchesFit = filterFit == null || p.fitType.contains(filterFit!!, ignoreCase = true)
    matchesCategory && matchesSize && matchesFit
  }

  Column(modifier = Modifier.fillMaxSize()) {
    LazyRow(
      contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(categories) { cat ->
        val selected = selectedCategory == cat
        FilterChip(
          selected = selected,
          onClick = { onCategoryChanged(cat) },
          label = { Text(cat, fontSize = 13.sp) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = EspressoPrimary,
            selectedLabelColor = SurfaceColor,
            containerColor = SurfaceColor,
            labelColor = EspressoPrimary
          ),
          modifier = Modifier.testTag("cat_chip_$cat")
        )
      }
    }

    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 4.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "${filteredProducts.size} items",
        fontSize = 13.sp,
        color = CharcoalSecondary
      )
      OutlinedButton(
        onClick = { showFilters = !showFilters },
        shape = RoundedCornerShape(4.dp),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
        modifier = Modifier.testTag("filter_toggle_btn")
      ) {
        Icon(Icons.Outlined.FilterList, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("Filter", fontSize = 12.sp)
      }
    }

    if (showFilters) {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceColor)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Text("Filter by Size:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          Spacer(modifier = Modifier.height(4.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("All", "XS", "S", "M", "L", "28", "29", "30").forEach { sz ->
              val sel = (sz == "All" && filterSize == null) || filterSize == sz
              OutlinedButton(
                onClick = { filterSize = if (sz == "All") null else sz },
                shape = RoundedCornerShape(4.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                  containerColor = if (sel) EspressoPrimary else SurfaceColor,
                  contentColor = if (sel) SurfaceColor else EspressoPrimary
                ),
                contentPadding = PaddingValues(8.dp)
              ) {
                Text(sz, fontSize = 11.sp)
              }
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    LazyVerticalGrid(
      columns = GridCells.Fixed(2),
      contentPadding = PaddingValues(16.dp),
      horizontalArrangement = Arrangement.spacedBy(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
      modifier = Modifier.fillMaxSize()
    ) {
      items(filteredProducts) { product ->
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .clickable { onProductClick(product.id) }
            .testTag("catalog_item_${product.id}"),
          shape = RoundedCornerShape(6.dp),
          colors = CardDefaults.cardColors(containerColor = SurfaceColor)
        ) {
          Column {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
            ) {
              AsyncImage(
                model = product.imageUrls.first(),
                contentDescription = product.title,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
              )
              if (product.isNewArrival) {
                Box(
                  modifier = Modifier
                    .padding(8.dp)
                    .background(EspressoPrimary, RoundedCornerShape(2.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                  Text("NEW", color = SurfaceColor, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
            Column(modifier = Modifier.padding(12.dp)) {
              Text(
                text = product.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = EspressoPrimary,
                maxLines = 1
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = product.fitType,
                fontSize = 12.sp,
                color = CharcoalSecondary,
                maxLines = 1
              )
              Spacer(modifier = Modifier.height(6.dp))
              Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "$${product.price.toInt()}",
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Bold,
                  color = EspressoPrimary
                )
                if (product.originalPrice != null) {
                  Text(
                    text = "$${product.originalPrice.toInt()}",
                    fontSize = 12.sp,
                    color = CharcoalSecondary,
                    style = androidx.compose.ui.text.TextStyle(textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough)
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}
