package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Straighten
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.Product
import com.example.ui.theme.*

@Composable
fun ProductDetailScreen(
  product: Product,
  isSaved: Boolean,
  onBack: () -> Unit,
  onToggleSave: () -> Unit,
  onAddToCart: (color: String, size: String, length: String) -> Unit
) {
  var selectedColor by remember { mutableStateOf(product.colors.firstOrNull()?.name ?: "") }
  var selectedSize by remember { mutableStateOf(product.sizes.firstOrNull() ?: "") }
  var selectedLength by remember { mutableStateOf(product.lengths.firstOrNull() ?: "Regular") }
  var showSizeGuide by remember { mutableStateOf(false) }
  var addedToast by remember { mutableStateOf(false) }

  val inStock = product.isVariantInStock(selectedColor, selectedSize, selectedLength)
  val scrollState = rememberScrollState()

  Box(modifier = Modifier.fillMaxSize()) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(scrollState)
        .padding(bottom = 90.dp)
    ) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(420.dp)
      ) {
        AsyncImage(
          model = product.imageUrls.first(),
          contentDescription = product.title,
          modifier = Modifier.fillMaxSize(),
          contentScale = ContentScale.Crop
        )
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          IconButton(
            onClick = onBack,
            modifier = Modifier
              .background(SurfaceColor.copy(alpha = 0.8f), CircleShape)
              .testTag("back_btn")
          ) {
            Icon(Icons.Outlined.ArrowBack, contentDescription = "Back", tint = EspressoPrimary)
          }
          IconButton(
            onClick = onToggleSave,
            modifier = Modifier
              .background(SurfaceColor.copy(alpha = 0.8f), CircleShape)
              .testTag("save_product_btn")
          ) {
            Icon(
              if (isSaved) Icons.Outlined.Favorite else Icons.Outlined.FavoriteBorder,
              contentDescription = "Save",
              tint = if (isSaved) ErrorColor else EspressoPrimary
            )
          }
        }
      }

      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = product.category.uppercase(),
          fontSize = 11.sp,
          color = CharcoalSecondary,
          fontWeight = FontWeight.Bold,
          letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = product.title,
          fontSize = 24.sp,
          fontWeight = FontWeight.Bold,
          color = EspressoPrimary
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          Text(
            text = "$${product.price.toInt()}",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = EspressoPrimary
          )
          if (product.originalPrice != null) {
            Text(
              text = "$${product.originalPrice.toInt()}",
              fontSize = 16.sp,
              color = CharcoalSecondary,
              style = androidx.compose.ui.text.TextStyle(textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough)
            )
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
          text = "Colour: $selectedColor",
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold,
          color = EspressoPrimary
        )
        Spacer(modifier = Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          items(product.colors) { colorOpt ->
            val isSelected = selectedColor == colorOpt.name
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier = Modifier
                .clickable { selectedColor = colorOpt.name }
                .testTag("color_option_${colorOpt.name}")
            ) {
              Box(
                modifier = Modifier
                  .size(44.dp)
                  .clip(CircleShape)
                  .border(
                    width = if (isSelected) 2.dp else 1.dp,
                    color = if (isSelected) EspressoPrimary else BorderColor,
                    shape = CircleShape
                  )
                  .background(SurfaceColor),
                contentAlignment = Alignment.Center
              ) {
                AsyncImage(
                  model = colorOpt.previewUrl,
                  contentDescription = colorOpt.name,
                  modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape),
                  contentScale = ContentScale.Crop
                )
              }
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = colorOpt.name,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) EspressoPrimary else CharcoalSecondary
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Size: $selectedSize",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = EspressoPrimary
          )
          TextButton(
            onClick = { showSizeGuide = true },
            modifier = Modifier.testTag("size_guide_btn")
          ) {
            Icon(Icons.Outlined.Straighten, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Size guide", fontSize = 12.sp, color = EspressoPrimary)
          }
        }
        Spacer(modifier = Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(product.sizes) { sz ->
            val isSelected = selectedSize == sz
            val available = product.isVariantInStock(selectedColor, sz, selectedLength)
            OutlinedButton(
              onClick = { selectedSize = sz },
              shape = RoundedCornerShape(4.dp),
              colors = ButtonDefaults.outlinedButtonColors(
                containerColor = if (isSelected) EspressoPrimary else SurfaceColor,
                contentColor = if (isSelected) SurfaceColor else if (available) EspressoPrimary else Color.Gray
              ),
              modifier = Modifier.testTag("size_option_$sz")
            ) {
              Text(sz, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
          }
        }

        if (product.lengths.size > 1) {
          Spacer(modifier = Modifier.height(16.dp))
          Text(
            text = "Length: $selectedLength",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = EspressoPrimary
          )
          Spacer(modifier = Modifier.height(8.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            product.lengths.forEach { len ->
              val isSelected = selectedLength == len
              OutlinedButton(
                onClick = { selectedLength = len },
                shape = RoundedCornerShape(4.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                  containerColor = if (isSelected) EspressoPrimary else SurfaceColor,
                  contentColor = if (isSelected) SurfaceColor else EspressoPrimary
                ),
                modifier = Modifier.testTag("length_option_$len")
              ) {
                Text(len, fontSize = 13.sp)
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(24.dp))

        if (!inStock) {
          Card(
            colors = CardDefaults.cardColors(containerColor = ErrorColor.copy(alpha = 0.1f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = "Selected size ($selectedSize / $selectedLength) in $selectedColor is currently sold out online.",
              color = ErrorColor,
              fontSize = 12.sp,
              modifier = Modifier.padding(12.dp)
            )
          }
          Spacer(modifier = Modifier.height(16.dp))
        }

        Text(text = "Details & Care", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = EspressoPrimary)
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = product.description, fontSize = 13.sp, color = CharcoalSecondary, lineHeight = 20.sp)
        Spacer(modifier = Modifier.height(12.dp))
        Text(text = "Material: ${product.material}", fontSize = 13.sp, color = EspressoPrimary, fontWeight = FontWeight.Medium)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = "Care: ${product.careInstructions}", fontSize = 13.sp, color = CharcoalSecondary)
      }
    }

    Surface(
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .fillMaxWidth(),
      color = SurfaceColor,
      tonalElevation = 16.dp
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Button(
          onClick = {
            if (inStock) {
              onAddToCart(selectedColor, selectedSize, selectedLength)
              addedToast = true
            }
          },
          enabled = inStock,
          modifier = Modifier
            .weight(1f)
            .height(50.dp)
            .testTag("add_to_bag_btn"),
          shape = RoundedCornerShape(4.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = EspressoPrimary,
            disabledContainerColor = Color.LightGray
          )
        ) {
          Text(
            text = if (inStock) "Add to bag - $${product.price.toInt()}" else "Sold Out",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = SurfaceColor
          )
        }
      }
    }

    if (addedToast) {
      Box(
        modifier = Modifier
          .align(Alignment.TopCenter)
          .padding(top = 24.dp)
          .background(EspressoPrimary, RoundedCornerShape(4.dp))
          .padding(horizontal = 16.dp, vertical = 8.dp)
      ) {
        Text("Added to bag successfully", color = SurfaceColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
      }
      LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(2000)
        addedToast = false
      }
    }

    if (showSizeGuide) {
      AlertDialog(
        onDismissRequest = { showSizeGuide = false },
        title = { Text("Size Guide & Fit Guidance", fontWeight = FontWeight.Bold) },
        text = {
          Column {
            Text("Product-specific measurements (inches):", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            Text("• Size 26: Waist 26\", Hip 36\", Inseam 32\"", fontSize = 12.sp)
            Text("• Size 28: Waist 28\", Hip 38\", Inseam 32\"", fontSize = 12.sp)
            Text("• Size 30: Waist 30\", Hip 40\", Inseam 32\"", fontSize = 12.sp)
            Spacer(modifier = Modifier.height(12.dp))
            Text("Fit Note: This style runs true to size with a relaxed drape.", fontSize = 12.sp, color = CharcoalSecondary)
          }
        },
        confirmButton = {
          TextButton(onClick = { showSizeGuide = false }) {
            Text("Close", color = EspressoPrimary)
          }
        }
      )
    }
  }
}
