package com.example.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.data.ShopRepository
import com.example.model.*

class ShopViewModel : ViewModel() {

  // Navigation tab
  var currentTab by mutableStateOf("Discover")

  // Catalog state
  var selectedCategory by mutableStateOf("All")
  var searchQuery by mutableStateOf("")
  var selectedFilterSize by mutableStateOf<String?>(null)
  var selectedFilterColor by mutableStateOf<String?>(null)
  var selectedFilterFit by mutableStateOf<String?>(null)
  var selectedFilterMaxPrice by mutableStateOf(250.0)

  // Product Detail
  var detailProductId by mutableStateOf<String?>(null)
  var selectedDetailColor by mutableStateOf<String?>(null)
  var selectedDetailSize by mutableStateOf<String?>(null)
  var selectedDetailLength by mutableStateOf("Regular")

  // Saved / Outfits
  var savedProductIds = mutableStateOf(setOf("prod_1", "prod_2", "prod_3"))
  var customLists = mutableStateOf(listOf("Spring Capsule", "Weekend Getaway"))

  // Cart
  var cartItems = mutableStateOf(
    listOf(
      CartItem("cart_1", ShopRepository.getProductById("prod_1")!!, "Medium Blue", "28", "Regular", 1),
      CartItem("cart_2", ShopRepository.getProductById("prod_2")!!, "Blue Stripe", "M", "Regular", 1)
    )
  )

  // Orders
  var orders = mutableStateOf(
    listOf(
      Order(
        orderId = "AF-849201",
        date = "Today, 10:45 AM",
        items = listOf(
          CartItem("c_ord_1", ShopRepository.getProductById("prod_1")!!, "Medium Blue", "28", "Regular", 1)
        ),
        subtotal = 90.0,
        tax = 7.20,
        shipping = 0.0,
        total = 97.20,
        status = "Ready for Collection",
        trackingNumber = "TRK-98342109",
        deliveryType = "Click & Collect",
        storeName = "Fifth Avenue Flagship",
        collectionRef = "AF-COLLECT-882",
        returnStatus = "None"
      ),
      Order(
        orderId = "AF-738219",
        date = "3 days ago",
        items = listOf(
          CartItem("c_ord_2", ShopRepository.getProductById("prod_4")!!, "Classic Khaki", "S", "Regular", 1)
        ),
        subtotal = 180.0,
        tax = 14.40,
        shipping = 0.0,
        total = 194.40,
        status = "Partially Shipped",
        trackingNumber = "TRK-77291034",
        deliveryType = "Standard Shipping",
        returnStatus = "Requested"
      )
    )
  )

  // User & Fit Measurements
  var userMeasurements = mutableStateOf(UserMeasurements(175, 68, "True to size", 28, 36))
  var loyaltyAccount = mutableStateOf(LoyaltyAccount())

  // Store selection
  var selectedStoreId = mutableStateOf("store_1")

  // Checkout state
  var checkoutStep by mutableStateOf(0) // 0: Cart, 1: Shipping/Store, 2: Payment, 3: Confirmation
  var guestEmail by mutableStateOf("alexander@example.com")
  var shippingAddress by mutableStateOf("742 Evergreen Terrace, New York, NY 10001")
  var appliedPromoCode by mutableStateOf<String?>(null)
  var discountAmount by mutableStateOf(0.0)

  // Admin state
  var adminInventoryOverride = mutableStateOf(mapOf<String, Int>())

  val products = ShopRepository.products
  val outfits = ShopRepository.outfits
  val stores = ShopRepository.stores

  fun getProduct(id: String?): Product? = if (id != null) ShopRepository.getProductById(id) else null

  fun toggleSaveProduct(productId: String) {
    val current = savedProductIds.value.toMutableSet()
    if (current.contains(productId)) current.remove(productId) else current.add(productId)
    savedProductIds.value = current
  }

  fun addToCart(product: Product, color: String, size: String, length: String, quantity: Int = 1) {
    val existingId = "cart_${product.id}_${color}_${size}_${length}"
    val currentList = cartItems.value.toMutableList()
    val existingIndex = currentList.indexOfFirst { it.cartItemId == existingId }
    if (existingIndex >= 0) {
      val item = currentList[existingIndex]
      currentList[existingIndex] = item.copy(quantity = item.quantity + quantity)
    } else {
      currentList.add(CartItem(existingId, product, color, size, length, quantity))
    }
    cartItems.value = currentList
  }

  fun removeFromCart(cartItemId: String) {
    cartItems.value = cartItems.value.filter { it.cartItemId != cartItemId }
  }

  fun updateQuantity(cartItemId: String, newQty: Int) {
    if (newQty <= 0) {
      removeFromCart(cartItemId)
      return
    }
    cartItems.value = cartItems.value.map {
      if (it.cartItemId == cartItemId) it.copy(quantity = newQty) else it
    }
  }

  fun applyPromo(code: String) {
    if (code.uppercase() == "CONSIDERED20") {
      appliedPromoCode = "CONSIDERED20"
      discountAmount = cartItems.value.sumOf { it.totalPrice } * 0.20
    } else if (code.uppercase() == "WEEKEND15") {
      appliedPromoCode = "WEEKEND15"
      discountAmount = cartItems.value.sumOf { it.totalPrice } * 0.15
    } else {
      appliedPromoCode = null
      discountAmount = 0.0
    }
  }

  fun completeCheckout(deliveryType: String, storeName: String?) {
    val sub = cartItems.value.sumOf { it.totalPrice }
    val tax = sub * 0.08
    val shipping = if (deliveryType == "Click & Collect") 0.0 else 9.0
    val total = sub + tax + shipping - discountAmount

    val newOrder = Order(
      orderId = "AF-${(100000..999999).random()}",
      date = "Just now",
      items = cartItems.value,
      subtotal = sub,
      tax = tax,
      shipping = shipping,
      total = total,
      status = if (deliveryType == "Click & Collect") "Order Accepted" else "Preparing Order",
      trackingNumber = "TRK-${(10000000..99999999).random()}",
      deliveryType = deliveryType,
      storeName = storeName,
      collectionRef = if (deliveryType == "Click & Collect") "AF-COLLECT-${(100..999).random()}" else null,
      returnStatus = "None"
    )

    orders.value = listOf(newOrder) + orders.value
    cartItems.value = emptyList()
    appliedPromoCode = null
    discountAmount = 0.0
  }

  fun requestReturn(orderId: String) {
    orders.value = orders.value.map {
      if (it.orderId == orderId) it.copy(returnStatus = "Requested (RA-${(1000..9999).random()})") else it
    }
  }

  fun advanceCollectionStatus(orderId: String) {
    orders.value = orders.value.map { ord ->
      if (ord.orderId == orderId) {
        val nextStatus = when (ord.status) {
          "Order Accepted" -> "Picking"
          "Picking" -> "Ready for Collection"
          "Ready for Collection" -> "Collected"
          else -> ord.status
        }
        ord.copy(status = nextStatus)
      } else ord
    }
  }
}
