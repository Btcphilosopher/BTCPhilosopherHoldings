package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EspressoPrimary
import com.example.ui.theme.IvoryBackground
import com.example.ui.theme.SurfaceColor
import com.example.ui.theme.TanAccent

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AbercrombieTopBar(
  title: String = "Abercrombie & Fitch",
  cartItemCount: Int,
  onCartClick: () -> Unit,
  onSearchClick: () -> Unit = {}
) {
  TopAppBar(
    title = {
      Text(
        text = title,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.5.sp,
        fontSize = 20.sp,
        color = EspressoPrimary
      )
    },
    actions = {
      IconButton(onClick = onSearchClick, modifier = Modifier.testTag("search_icon_btn")) {
        Icon(Icons.Outlined.Search, contentDescription = "Search", tint = EspressoPrimary)
      }
      Box(modifier = Modifier.padding(end = 8.dp)) {
        IconButton(onClick = onCartClick, modifier = Modifier.testTag("cart_icon_btn")) {
          Icon(Icons.Outlined.ShoppingBag, contentDescription = "Basket", tint = EspressoPrimary)
        }
        if (cartItemCount > 0) {
          Box(
            modifier = Modifier
              .align(Alignment.TopEnd)
              .offset(x = (-4).dp, y = 4.dp)
              .size(18.dp)
              .background(EspressoPrimary, CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = cartItemCount.toString(),
              color = SurfaceColor,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }
    },
    colors = TopAppBarDefaults.topAppBarColors(containerColor = IvoryBackground)
  )
}

@Composable
fun AbercrombieBottomNav(
  currentTab: String,
  onTabSelected: (String) -> Unit
) {
  val tabs = listOf(
    Triple("Discover", Icons.Outlined.Home, "Discover"),
    Triple("Shop", Icons.Outlined.Checkroom, "Shop"),
    Triple("Saved", Icons.Outlined.FavoriteBorder, "Saved"),
    Triple("Stores", Icons.Outlined.Store, "Stores"),
    Triple("Account", Icons.Outlined.Person, "Account")
  )

  NavigationBar(
    containerColor = SurfaceColor,
    tonalElevation = 8.dp
  ) {
    tabs.forEach { (tabKey, icon, label) ->
      val selected = currentTab == tabKey
      NavigationBarItem(
        icon = { Icon(icon, contentDescription = label) },
        label = { Text(label, fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) },
        selected = selected,
        onClick = { onTabSelected(tabKey) },
        colors = NavigationBarItemDefaults.colors(
          selectedIconColor = EspressoPrimary,
          selectedTextColor = EspressoPrimary,
          unselectedIconColor = Color.Gray,
          unselectedTextColor = Color.Gray,
          indicatorColor = TanAccent.copy(alpha = 0.2f)
        ),
        modifier = Modifier.testTag("nav_item_$tabKey")
      )
    }
  }
}
