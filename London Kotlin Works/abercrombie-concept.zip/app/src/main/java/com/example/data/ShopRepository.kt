package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object ShopRepository {

  private val _products = MutableStateFlow(
    listOf(
      Product(
        id = "prod_1",
        title = "High Rise Straight Jean",
        category = "Denim",
        price = 90.0,
        originalPrice = 110.0,
        description = "Crafted in premium non-stretch organic cotton denim with a flattering high rise and relaxed straight leg. Designed for effortless everyday wear with authentic vintage character.",
        imageUrls = listOf(
          "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=1000&q=80",
          "https://images.unsplash.com/photo-1584370848010-d7fe6bc767ec?auto=format&fit=crop&w=1000&q=80",
          "https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&w=1000&q=80"
        ),
        colors = listOf(
          ColorOption("Medium Blue", "#3A5A78", "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=300&q=80"),
          ColorOption("Light Wash", "#8CA8C2", "https://images.unsplash.com/photo-1584370848010-d7fe6bc767ec?auto=format&fit=crop&w=300&q=80"),
          ColorOption("Vintage Ecru", "#EFECE6", "https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&w=300&q=80"),
          ColorOption("Clean Black", "#1E1B18", "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?auto=format&fit=crop&w=300&q=80")
        ),
        sizes = listOf("24", "25", "26", "27", "28", "29", "30", "31", "32"),
        lengths = listOf("Short", "Regular", "Long"),
        fitType = "High Rise Straight",
        material = "100% Organic Cotton (13.5 oz)",
        careInstructions = "Machine wash cold inside out with like colors. Do not bleach. Tumble dry low.",
        isNewArrival = true,
        isFeatured = true,
        rating = 4.9,
        reviewCount = 312,
        variants = listOf(
          ProductVariant("Medium Blue", "#3A5A78", "28", "Regular", 5),
          ProductVariant("Medium Blue", "#3A5A78", "28", "Long", 0), // Sold out test case
          ProductVariant("Medium Blue", "#3A5A78", "27", "Regular", 2),
          ProductVariant("Light Wash", "#8CA8C2", "28", "Regular", 8),
          ProductVariant("Vintage Ecru", "#EFECE6", "26", "Regular", 4),
          ProductVariant("Clean Black", "#1E1B18", "28", "Regular", 10)
        )
      ),
      Product(
        id = "prod_2",
        title = "Linen Button-Up Shirt",
        category = "Shirts",
        price = 70.0,
        description = "An airy, relaxed-fit linen shirt woven from premium European flax. Features a classic collar, button-through front, and dropped shoulders for effortless resort styling.",
        imageUrls = listOf(
          "https://images.unsplash.com/photo-1598033129183-c4f50c736f10?auto=format&fit=crop&w=1000&q=80",
          "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=1000&q=80"
        ),
        colors = listOf(
          ColorOption("Ivory", "#F5F2EB", "https://images.unsplash.com/photo-1598033129183-c4f50c736f10?auto=format&fit=crop&w=300&q=80"),
          ColorOption("Blue Stripe", "#4A709C", "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=300&q=80"),
          ColorOption("Olive", "#555D50", "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=300&q=80")
        ),
        sizes = listOf("XS", "S", "M", "L", "XL"),
        lengths = listOf("Regular"),
        fitType = "Relaxed Fit",
        material = "100% European Flax Linen",
        careInstructions = "Machine wash gentle in cold water. Line dry in shade. Warm iron if needed.",
        isNewArrival = true,
        isFeatured = true,
        rating = 4.8,
        reviewCount = 184,
        variants = listOf(
          ProductVariant("Ivory", "#F5F2EB", "M", "Regular", 12),
          ProductVariant("Blue Stripe", "#4A709C", "M", "Regular", 6),
          ProductVariant("Blue Stripe", "#4A709C", "S", "Regular", 3),
          ProductVariant("Olive", "#555D50", "L", "Regular", 5)
        )
      ),
      Product(
        id = "prod_3",
        title = "Leather Slide Sandal",
        category = "Accessories",
        price = 70.0,
        description = "Supple handcrafted Italian leather slide sandals featuring crossover straps and a cushioned footbed for all-day comfort and timeless warm-weather elegance.",
        imageUrls = listOf(
          "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=1000&q=80",
          "https://images.unsplash.com/photo-1603808033192-082d6939d3e1?auto=format&fit=crop&w=1000&q=80"
        ),
        colors = listOf(
          ColorOption("Tan Leather", "#C49A6C", "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=300&q=80"),
          ColorOption("Espresso", "#362B28", "https://images.unsplash.com/photo-1603808033192-082d6939d3e1?auto=format&fit=crop&w=300&q=80")
        ),
        sizes = listOf("6", "7", "8", "9", "10", "11"),
        lengths = listOf("Standard"),
        fitType = "True to Size",
        material = "100% Genuine Bovine Leather Upper & Sole",
        careInstructions = "Wipe clean with a soft dry cloth. Treat periodically with leather conditioner.",
        isNewArrival = false,
        isFeatured = true,
        rating = 4.7,
        reviewCount = 95,
        variants = listOf(
          ProductVariant("Tan Leather", "#C49A6C", "8", "Standard", 7),
          ProductVariant("Tan Leather", "#C49A6C", "9", "Standard", 4),
          ProductVariant("Espresso", "#362B28", "8", "Standard", 2)
        )
      ),
      Product(
        id = "prod_4",
        title = "Tailored Trench Coat",
        category = "Outerwear",
        price = 180.0,
        originalPrice = 220.0,
        description = "A sophisticated double-breasted trench coat tailored from water-resistant twill. Features epaulettes, a belted waist, storm flaps, and a refined midi silhouette.",
        imageUrls = listOf(
          "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=1000&q=80",
          "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1000&q=80"
        ),
        colors = listOf(
          ColorOption("Classic Khaki", "#D8C5A2", "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=300&q=80"),
          ColorOption("Midnight Navy", "#1D2A3A", "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=300&q=80")
        ),
        sizes = listOf("XS", "S", "M", "L"),
        lengths = listOf("Regular", "Long"),
        fitType = "Tailored Fit",
        material = "65% Cotton, 35% Polyester Twill",
        careInstructions = "Dry clean only.",
        isNewArrival = true,
        isFeatured = true,
        rating = 4.9,
        reviewCount = 78,
        variants = listOf(
          ProductVariant("Classic Khaki", "#D8C5A2", "S", "Regular", 4),
          ProductVariant("Classic Khaki", "#D8C5A2", "M", "Regular", 6),
          ProductVariant("Midnight Navy", "#1D2A3A", "M", "Regular", 3)
        )
      ),
      Product(
        id = "prod_5",
        title = "Cashmere Crewneck Sweater",
        category = "Knitwear",
        price = 120.0,
        description = "Luxuriously soft Grade-A Mongolian cashmere knit with rib-knit trims and a relaxed silhouette. The ultimate layering essential for crisp mornings and cool evenings.",
        imageUrls = listOf(
          "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=1000&q=80",
          "https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=1000&q=80"
        ),
        colors = listOf(
          ColorOption("Oatmeal Heather", "#E6DFC5", "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=300&q=80"),
          ColorOption("Charcoal", "#3A3836", "https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=300&q=80")
        ),
        sizes = listOf("XS", "S", "M", "L", "XL"),
        lengths = listOf("Regular"),
        fitType = "Relaxed Fit",
        material = "100% Mongolian Cashmere",
        careInstructions = "Hand wash cold with wool detergent or professional dry clean. Dry flat.",
        isNewArrival = false,
        isFeatured = true,
        rating = 5.0,
        reviewCount = 210,
        variants = listOf(
          ProductVariant("Oatmeal Heather", "#E6DFC5", "M", "Regular", 9),
          ProductVariant("Oatmeal Heather", "#E6DFC5", "S", "Regular", 5),
          ProductVariant("Charcoal", "#3A3836", "M", "Regular", 8)
        )
      ),
      Product(
        id = "prod_6",
        title = "Pleated Wide-Leg Trousers",
        category = "Trousers",
        price = 95.0,
        description = "Polished high-waisted trousers featuring crisp front pleats and a fluid wide-leg drape. Designed in a premium wool-blend fabric for effortless boardroom-to-dinner transitions.",
        imageUrls = listOf(
          "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?auto=format&fit=crop&w=1000&q=80",
          "https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1000&q=80"
        ),
        colors = listOf(
          ColorOption("Camel", "#C19A6B", "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?auto=format&fit=crop&w=300&q=80"),
          ColorOption("Black", "#111111", "https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=300&q=80")
        ),
        sizes = listOf("24", "25", "26", "27", "28", "29", "30"),
        lengths = listOf("Short", "Regular", "Long"),
        fitType = "High-Rise Wide Leg",
        material = "52% Wool, 44% Polyester, 4% Elastane",
        careInstructions = "Dry clean recommended. Cool iron if needed.",
        isNewArrival = true,
        isFeatured = false,
        rating = 4.6,
        reviewCount = 64,
        variants = listOf(
          ProductVariant("Camel", "#C19A6B", "27", "Regular", 6),
          ProductVariant("Black", "#111111", "28", "Regular", 7)
        )
      ),
      Product(
        id = "prod_7",
        title = "Floral Silk Slip Dress",
        category = "Dresses",
        price = 110.0,
        originalPrice = 140.0,
        description = "Cut on the bias from lustrous washable silk, this midi slip dress features a delicate floral motif, adjustable spaghetti straps, and a romantic cowl neckline.",
        imageUrls = listOf(
          "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?auto=format&fit=crop&w=1000&q=80",
          "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?auto=format&fit=crop&w=1000&q=80"
        ),
        colors = listOf(
          ColorOption("Cream Floral", "#F0EDE6", "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?auto=format&fit=crop&w=300&q=80"),
          ColorOption("Navy Blossom", "#1D2A3A", "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?auto=format&fit=crop&w=300&q=80")
        ),
        sizes = listOf("XS", "S", "M", "L"),
        lengths = listOf("Regular"),
        fitType = "Bias Cut Slip",
        material = "100% Washable Mulberry Silk",
        careInstructions = "Hand wash cold in mild detergent or gentle machine wash in mesh bag. Line dry.",
        isNewArrival = true,
        isFeatured = true,
        rating = 4.9,
        reviewCount = 142,
        variants = listOf(
          ProductVariant("Cream Floral", "#F0EDE6", "S", "Regular", 5),
          ProductVariant("Cream Floral", "#F0EDE6", "M", "Regular", 8),
          ProductVariant("Navy Blossom", "#1D2A3A", "S", "Regular", 3)
        )
      )
    )
  )
  val products: StateFlow<List<Product>> = _products.asStateFlow()

  val outfits = listOf(
    Outfit(
      id = "outfit_1",
      title = "The Weekend Edit",
      subtitle = "3 pieces. One easy outfit.",
      imageUrl = "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1000&q=80",
      productIds = listOf("prod_2", "prod_1", "prod_3"),
      bundleDiscountPercent = 15
    ),
    Outfit(
      id = "outfit_2",
      title = "Everyday, Considered.",
      subtitle = "Effortless tailoring & cashmere layers.",
      imageUrl = "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=1000&q=80",
      productIds = listOf("prod_4", "prod_5", "prod_6"),
      bundleDiscountPercent = 20
    )
  )

  val stores = listOf(
    Store(
      id = "store_1",
      name = "Fifth Avenue Flagship",
      city = "New York, NY",
      address = "666 5th Ave, New York, NY 10103",
      hours = "Mon-Sat: 10AM - 9PM · Sun: 11AM - 7PM",
      distance = "0.8 miles away",
      facilities = listOf("Click & Collect", "Styling Appointments", "Tailoring & Alterations", "VIP Lounge"),
      phone = "(212) 555-0192"
    ),
    Store(
      id = "store_2",
      name = "Regent Street Store",
      city = "London, UK",
      address = "89 Regent St, London W1B 4HZ",
      hours = "Mon-Sat: 9:30AM - 8PM · Sun: 12PM - 6PM",
      distance = "3.2 miles away",
      facilities = listOf("Click & Collect", "Express Handover", "Gift Wrapping"),
      phone = "+44 20 7946 0912"
    ),
    Store(
      id = "store_3",
      name = "Century City Mall",
      city = "Los Angeles, CA",
      address = "10250 Santa Monica Blvd, Los Angeles, CA 90067",
      hours = "Mon-Sun: 10AM - 9PM",
      distance = "5.5 miles away",
      facilities = listOf("Click & Collect", "Curbside Pickup", "Styling Studio"),
      phone = "(310) 555-0481"
    )
  )

  fun getProductById(id: String): Product? = _products.value.find { it.id == id }
}
