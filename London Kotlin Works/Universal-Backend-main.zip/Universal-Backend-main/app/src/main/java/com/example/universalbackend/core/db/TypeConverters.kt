package com.example.universalbackend.core.db

import androidx.room.TypeConverter
import com.example.universalbackend.core.model.AuditActionType
import com.example.universalbackend.core.model.EventType
import com.example.universalbackend.core.model.FlagType
import com.example.universalbackend.core.model.JobStatus
import com.example.universalbackend.core.model.SDUIComponentType
import com.example.universalbackend.core.model.WorkflowStatus
import com.example.universalbackend.core.model.WorkflowTriggerType

class UniversalTypeConverters {

    @TypeConverter
    fun fromSDUIComponentType(value: SDUIComponentType?): String = value?.name ?: SDUIComponentType.TEXT_BLOCK.name

    @TypeConverter
    fun toSDUIComponentType(value: String?): SDUIComponentType =
        try {
            value?.let { SDUIComponentType.valueOf(it) } ?: SDUIComponentType.TEXT_BLOCK
        } catch (e: Exception) {
            SDUIComponentType.TEXT_BLOCK
        }

    @TypeConverter
    fun fromWorkflowTriggerType(value: WorkflowTriggerType?): String = value?.name ?: WorkflowTriggerType.MANUAL_INVOCATION.name

    @TypeConverter
    fun toWorkflowTriggerType(value: String?): WorkflowTriggerType =
        try {
            value?.let { WorkflowTriggerType.valueOf(it) } ?: WorkflowTriggerType.MANUAL_INVOCATION
        } catch (e: Exception) {
            WorkflowTriggerType.MANUAL_INVOCATION
        }

    @TypeConverter
    fun fromWorkflowStatus(value: WorkflowStatus?): String = value?.name ?: WorkflowStatus.ACTIVE.name

    @TypeConverter
    fun toWorkflowStatus(value: String?): WorkflowStatus =
        try {
            value?.let { WorkflowStatus.valueOf(it) } ?: WorkflowStatus.ACTIVE
        } catch (e: Exception) {
            WorkflowStatus.ACTIVE
        }

    @TypeConverter
    fun fromEventType(value: EventType?): String = value?.name ?: EventType.DOMAIN.name

    @TypeConverter
    fun toEventType(value: String?): EventType =
        try {
            value?.let { EventType.valueOf(it) } ?: EventType.DOMAIN
        } catch (e: Exception) {
            EventType.DOMAIN
        }

    @TypeConverter
    fun fromFlagType(value: FlagType?): String = value?.name ?: FlagType.BOOLEAN.name

    @TypeConverter
    fun toFlagType(value: String?): FlagType =
        try {
            value?.let { FlagType.valueOf(it) } ?: FlagType.BOOLEAN
        } catch (e: Exception) {
            FlagType.BOOLEAN
        }

    @TypeConverter
    fun fromJobStatus(value: JobStatus?): String = value?.name ?: JobStatus.COMPLETED.name

    @TypeConverter
    fun toJobStatus(value: String?): JobStatus =
        try {
            value?.let { JobStatus.valueOf(it) } ?: JobStatus.COMPLETED
        } catch (e: Exception) {
            JobStatus.COMPLETED
        }

    @TypeConverter
    fun fromAuditActionType(value: AuditActionType?): String = value?.name ?: AuditActionType.READ.name

    @TypeConverter
    fun toAuditActionType(value: String?): AuditActionType =
        try {
            value?.let { AuditActionType.valueOf(it) } ?: AuditActionType.READ
        } catch (e: Exception) {
            AuditActionType.READ
        }
}
