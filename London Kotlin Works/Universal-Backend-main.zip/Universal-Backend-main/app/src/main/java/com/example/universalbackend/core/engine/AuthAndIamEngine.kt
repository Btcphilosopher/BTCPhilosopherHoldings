package com.example.universalbackend.core.engine

import com.example.universalbackend.core.db.ApiKeyEntity
import com.example.universalbackend.core.db.RoleEntity
import com.example.universalbackend.core.db.TenantEntity
import com.example.universalbackend.core.db.UniversalDao
import com.example.universalbackend.core.db.UserEntity
import com.example.universalbackend.core.model.ApiKey
import com.example.universalbackend.core.model.AuditActionType
import com.example.universalbackend.core.model.Role
import com.example.universalbackend.core.model.Tenant
import com.example.universalbackend.core.model.User
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class AuthAndIamEngine(
    private val dao: UniversalDao,
    private val auditLogger: AuditLogger
) {
    // In-memory token bucket for rate limiting: Key -> (Tokens, LastRefillTimestamp)
    private val rateLimitBuckets = ConcurrentHashMap<String, Pair<Double, Long>>()

    suspend fun authenticateApiKey(token: String): Result<Pair<ApiKey, Role?>> {
        val apiKeyEntity = dao.getApiKeyByToken(token)
            ?: return Result.failure(SecurityException("Invalid or inactive API key"))

        if (apiKeyEntity.expiresAt != null && apiKeyEntity.expiresAt < System.currentTimeMillis()) {
            return Result.failure(SecurityException("API key has expired"))
        }

        // Check Rate Limit
        if (!checkRateLimit(apiKeyEntity.id, apiKeyEntity.rateLimitPerMinute)) {
            return Result.failure(IllegalStateException("Rate limit exceeded for API Key (${apiKeyEntity.rateLimitPerMinute} req/min)"))
        }

        // Update last used timestamp
        dao.insertApiKey(apiKeyEntity.copy(lastUsedAt = System.currentTimeMillis()))

        val roleEntity = dao.getRoleById(apiKeyEntity.roleId)
        val role = roleEntity?.let {
            Role(
                id = it.id,
                tenantId = it.tenantId,
                name = it.name,
                description = it.description,
                permissions = JsonCodec.jsonToStringList(it.permissionsJson),
                isSystem = it.isSystem
            )
        }

        val apiKey = ApiKey(
            id = apiKeyEntity.id,
            tenantId = apiKeyEntity.tenantId,
            name = apiKeyEntity.name,
            keyPrefix = apiKeyEntity.keyPrefix,
            hashedToken = apiKeyEntity.hashedToken,
            roleId = apiKeyEntity.roleId,
            rateLimitPerMinute = apiKeyEntity.rateLimitPerMinute,
            expiresAt = apiKeyEntity.expiresAt,
            lastUsedAt = apiKeyEntity.lastUsedAt,
            isActive = apiKeyEntity.isActive,
            createdAt = apiKeyEntity.createdAt
        )

        return Result.success(Pair(apiKey, role))
    }

    private fun checkRateLimit(keyId: String, limitPerMinute: Int): Boolean {
        val now = System.currentTimeMillis()
        val capacity = limitPerMinute.toDouble()
        val refillRatePerMs = capacity / 60000.0

        val current = rateLimitBuckets.getOrPut(keyId) { Pair(capacity, now) }
        val elapsedTime = now - current.second
        val refilledTokens = (current.first + elapsedTime * refillRatePerMs).coerceAtMost(capacity)

        return if (refilledTokens >= 1.0) {
            rateLimitBuckets[keyId] = Pair(refilledTokens - 1.0, now)
            true
        } else {
            rateLimitBuckets[keyId] = Pair(refilledTokens, now)
            false
        }
    }

    fun hasPermission(userPermissions: List<String>, requiredPermission: String?): Boolean {
        if (requiredPermission == null || requiredPermission.isBlank()) return true
        if (userPermissions.contains("*:*") || userPermissions.contains("*")) return true

        val parts = requiredPermission.split(":")
        val reqResource = parts.getOrNull(0) ?: ""
        val reqAction = parts.getOrNull(1) ?: ""

        for (p in userPermissions) {
            if (p == requiredPermission) return true
            if (p == "$reqResource:*") return true
            if (p == "*:$reqAction") return true
        }
        return false
    }

    suspend fun saveTenant(tenant: Tenant, actor: String): Result<Tenant> {
        return try {
            val entity = TenantEntity(
                id = tenant.id,
                name = tenant.name,
                slug = tenant.slug,
                plan = tenant.plan,
                settingsJson = JsonCodec.stringMapToJson(tenant.settings),
                createdAt = tenant.createdAt
            )
            dao.insertTenant(entity)
            auditLogger.log(
                tenantId = tenant.id,
                actor = actor,
                action = AuditActionType.CREATE,
                targetType = "Tenant",
                targetId = tenant.id,
                details = "Provisioned tenant '${tenant.name}' [${tenant.plan}]"
            )
            Result.success(tenant)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveUser(user: User, actor: String): Result<User> {
        return try {
            val entity = UserEntity(
                id = user.id,
                tenantId = user.tenantId,
                email = user.email,
                fullName = user.fullName,
                roleIdsJson = JsonCodec.stringListToJson(user.roleIds),
                isActive = user.isActive,
                lastLoginAt = user.lastLoginAt,
                createdAt = user.createdAt
            )
            dao.insertUser(entity)
            auditLogger.log(
                tenantId = user.tenantId,
                actor = actor,
                action = AuditActionType.UPDATE,
                targetType = "User",
                targetId = user.id,
                details = "Saved user '${user.email}'"
            )
            Result.success(user)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun generateApiKey(
        tenantId: String,
        name: String,
        roleId: String,
        rateLimit: Int,
        actor: String
    ): Result<Pair<ApiKey, String>> {
        return try {
            val rawToken = "ub_live_" + UUID.randomUUID().toString().replace("-", "")
            val prefix = rawToken.take(11) + "..."
            val keyId = UUID.randomUUID().toString()

            val entity = ApiKeyEntity(
                id = keyId,
                tenantId = tenantId,
                name = name,
                keyPrefix = prefix,
                hashedToken = rawToken,
                roleId = roleId,
                rateLimitPerMinute = rateLimit,
                expiresAt = null,
                lastUsedAt = null,
                isActive = true,
                createdAt = System.currentTimeMillis()
            )
            dao.insertApiKey(entity)

            auditLogger.log(
                tenantId = tenantId,
                actor = actor,
                action = AuditActionType.CREATE,
                targetType = "ApiKey",
                targetId = keyId,
                details = "Generated API Key '$name' ($prefix)"
            )

            val apiKey = ApiKey(
                id = entity.id,
                tenantId = entity.tenantId,
                name = entity.name,
                keyPrefix = entity.keyPrefix,
                hashedToken = entity.hashedToken,
                roleId = entity.roleId,
                rateLimitPerMinute = entity.rateLimitPerMinute,
                expiresAt = entity.expiresAt,
                lastUsedAt = entity.lastUsedAt,
                isActive = entity.isActive,
                createdAt = entity.createdAt
            )
            Result.success(Pair(apiKey, rawToken))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
