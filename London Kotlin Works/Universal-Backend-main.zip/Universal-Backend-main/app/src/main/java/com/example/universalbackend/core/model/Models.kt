package com.example.universalbackend.core.model

import java.util.UUID

// ==========================================
// 1. DATA TYPES & SCHEMA MODELS
// ==========================================

enum class FieldType {
    STRING,
    TEXT,
    INTEGER,
    DECIMAL,
    BOOLEAN,
    DATE,
    DATETIME,
    TIME,
    UUID_TYPE,
    JSON_TYPE,
    ARRAY_TYPE,
    ENUM_TYPE,
    FILE_URL,
    IMAGE_URL,
    EMAIL,
    PHONE,
    GEOLOCATION,
    CURRENCY,
    PERCENTAGE,
    RELATIONSHIP,
    COMPUTED_FORMULA
}

enum class RelationshipType {
    ONE_TO_ONE,
    ONE_TO_MANY,
    MANY_TO_ONE,
    MANY_TO_MANY,
    HIERARCHICAL,
    POLYMORPHIC
}

enum class ValidationType {
    REQUIRED,
    MIN_LENGTH,
    MAX_LENGTH,
    MIN_VALUE,
    MAX_VALUE,
    REGEX_PATTERN,
    EMAIL_FORMAT,
    URL_FORMAT,
    UNIQUE,
    CUSTOM_EXPRESSION
}

data class ValidationRule(
    val type: ValidationType,
    val value: String = "",
    val errorMessage: String = "Validation failed"
)

data class FieldDefinition(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val displayName: String,
    val type: FieldType,
    val defaultValue: String? = null,
    val isRequired: Boolean = false,
    val isUnique: Boolean = false,
    val isSearchable: Boolean = true,
    val isFilterable: Boolean = true,
    val isSortable: Boolean = true,
    val isReadOnly: Boolean = false,
    val formula: String? = null, // e.g. "price * quantity" or "CONCAT(firstName, ' ', lastName)"
    val enumValues: List<String> = emptyList(),
    val targetEntityId: String? = null, // for RELATIONSHIP
    val relationshipType: RelationshipType? = null,
    val validationRules: List<ValidationRule> = emptyList(),
    val metadata: Map<String, String> = emptyMap()
)

data class EntitySchema(
    val id: String = UUID.randomUUID().toString(),
    val tenantId: String = "tenant-default",
    val name: String, // e.g. "orders"
    val displayName: String, // e.g. "Orders"
    val description: String = "",
    val icon: String = "layers",
    val version: Int = 1,
    val isSystem: Boolean = false,
    val isAudited: Boolean = true,
    val isSoftDeleteEnabled: Boolean = true,
    val fields: List<FieldDefinition> = emptyList(),
    val primaryField: String = "id",
    val titleField: String = "name",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class DynamicRecord(
    val id: String = UUID.randomUUID().toString(),
    val tenantId: String = "tenant-default",
    val schemaId: String,
    val version: Int = 1,
    val values: Map<String, Any?> = emptyMap(),
    val isDeleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val createdBy: String = "system",
    val updatedBy: String = "system"
)

// ==========================================
// 2. SERVER-DRIVEN UI (SDUI) COMPOSITION MODELS
// ==========================================

enum class SDUIComponentType {
    APP_HEADER,
    HERO_BANNER,
    METRIC_CARD,
    CHART_WIDGET,
    DATA_TABLE,
    RECORD_GRID,
    FORM_CONTAINER,
    ACTION_BAR,
    BUTTON,
    TEXT_BLOCK,
    INPUT_FIELD,
    DROPDOWN_SELECT,
    MODAL_DIALOG,
    TAB_PANEL,
    SEARCH_BAR,
    FILTER_CHIP_GROUP,
    STATUS_BADGE,
    LIST_ITEM_CARD,
    DIVIDER
}

enum class SDUIActionType {
    NAVIGATE,
    OPEN_MODAL,
    CLOSE_MODAL,
    SUBMIT_FORM,
    TRIGGER_WORKFLOW,
    EXECUTE_API,
    DISPATCH_EVENT,
    DOWNLOAD_EXPORT,
    REFRESH_DATA,
    SHOW_TOAST
}

data class SDUIAction(
    val id: String = UUID.randomUUID().toString(),
    val type: SDUIActionType,
    val target: String, // screen id, workflow id, or api endpoint
    val parameters: Map<String, String> = emptyMap(),
    val confirmationPrompt: String? = null
)

data class SDUIComponent(
    val id: String = UUID.randomUUID().toString(),
    val screenId: String,
    val sectionId: String? = null,
    val parentComponentId: String? = null,
    val type: SDUIComponentType,
    val name: String,
    val title: String? = null,
    val position: Int = 0,
    val isVisible: Boolean = true,
    val requiredPermission: String? = null,
    val config: Map<String, String> = emptyMap(),
    val dataBinding: String? = null, // e.g. "records:products" or "metric:revenue"
    val actions: List<SDUIAction> = emptyList(),
    val childrenIds: List<String> = emptyList(),
    val version: Int = 1
)

data class SDUISection(
    val id: String = UUID.randomUUID().toString(),
    val screenId: String,
    val title: String,
    val subtitle: String? = null,
    val position: Int = 0,
    val layoutType: String = "COLUMN", // COLUMN, ROW, GRID_2, GRID_3
    val isCollapsible: Boolean = false,
    val isVisible: Boolean = true,
    val componentIds: List<String> = emptyList()
)

data class SDUIScreen(
    val id: String = UUID.randomUUID().toString(),
    val tenantId: String = "tenant-default",
    val appId: String = "app-primary",
    val slug: String, // e.g. "/dashboard", "/catalog"
    val title: String,
    val description: String? = null,
    val icon: String = "grid_view",
    val position: Int = 0,
    val isHomeScreen: Boolean = false,
    val isVisibleInNav: Boolean = true,
    val requiredRoles: List<String> = emptyList(),
    val version: Int = 1,
    val sections: List<SDUISection> = emptyList(),
    val metadata: Map<String, String> = emptyMap(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class SDUINavItem(
    val id: String = UUID.randomUUID().toString(),
    val label: String,
    val icon: String,
    val screenSlug: String,
    val badgeCount: Int = 0,
    val position: Int = 0,
    val requiredRole: String? = null
)

data class SDUIApp(
    val id: String = "app-primary",
    val tenantId: String = "tenant-default",
    val name: String = "Universal App",
    val version: String = "1.0.0",
    val theme: Map<String, String> = mapOf(
        "primaryColor" to "#4F46E5",
        "secondaryColor" to "#06B6D4",
        "mode" to "DARK"
    ),
    val navigation: List<SDUINavItem> = emptyList(),
    val screens: List<SDUIScreen> = emptyList(),
    val publishedAt: Long = System.currentTimeMillis()
)

// ==========================================
// 3. WORKFLOW AUTOMATION MODELS
// ==========================================

enum class WorkflowTriggerType {
    RECORD_CREATED,
    RECORD_UPDATED,
    RECORD_DELETED,
    EVENT_RECEIVED,
    CRON_SCHEDULED,
    WEBHOOK_INCOMING,
    MANUAL_INVOCATION
}

enum class WorkflowActionType {
    MUTATE_RECORD,
    CREATE_RECORD,
    EMIT_EVENT,
    SEND_NOTIFICATION,
    HTTP_WEBHOOK,
    CALL_AI_MODEL,
    UPDATE_CONFIG,
    RUN_SCRIPT_EXPRESSION,
    BRANCH_CONDITION
}

enum class WorkflowStatus {
    DRAFT,
    ACTIVE,
    PAUSED,
    ARCHIVED
}

data class WorkflowCondition(
    val fieldPath: String, // e.g. "record.totalAmount"
    val operator: String, // "EQUALS", "GREATER_THAN", "LESS_THAN", "CONTAINS", "REGEX"
    val expectedValue: String
)

data class WorkflowStep(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val actionType: WorkflowActionType,
    val parameters: Map<String, String> = emptyMap(),
    val conditions: List<WorkflowCondition> = emptyList(),
    val nextStepIdOnSuccess: String? = null,
    val nextStepIdOnFailure: String? = null
)

data class WorkflowDefinition(
    val id: String = UUID.randomUUID().toString(),
    val tenantId: String = "tenant-default",
    val name: String,
    val description: String = "",
    val triggerType: WorkflowTriggerType,
    val triggerEntityId: String? = null,
    val triggerFilterExpression: String? = null,
    val status: WorkflowStatus = WorkflowStatus.ACTIVE,
    val steps: List<WorkflowStep> = emptyList(),
    val executionCount: Long = 0L,
    val lastExecutedAt: Long? = null,
    val version: Int = 1,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class WorkflowStepLog(
    val stepId: String,
    val stepName: String,
    val status: String, // SUCCESS, FAILED, SKIPPED
    val durationMs: Long,
    val output: String? = null,
    val error: String? = null
)

data class WorkflowExecution(
    val id: String = UUID.randomUUID().toString(),
    val workflowId: String,
    val workflowName: String,
    val tenantId: String,
    val triggerSource: String,
    val status: String, // RUNNING, COMPLETED, FAILED
    val logs: List<WorkflowStepLog> = emptyList(),
    val executionDurationMs: Long = 0L,
    val startedAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
)

// ==========================================
// 4. IDENTITY, RBAC & TENANCY
// ==========================================

data class Tenant(
    val id: String = "tenant-default",
    val name: String = "Default Enterprise",
    val slug: String = "default-corp",
    val plan: String = "ENTERPRISE",
    val settings: Map<String, String> = emptyMap(),
    val createdAt: Long = System.currentTimeMillis()
)

data class Permission(
    val id: String,
    val resource: String, // e.g. "entity", "sdui", "workflow", "iam", "metrics"
    val action: String, // "create", "read", "update", "delete", "execute", "admin"
    val description: String
) {
    val key: String get() = "$resource:$action"
}

data class Role(
    val id: String = UUID.randomUUID().toString(),
    val tenantId: String = "tenant-default",
    val name: String, // e.g. "SUPER_ADMIN", "DEVELOPER", "CONTENT_EDITOR", "API_CONSUMER"
    val description: String = "",
    val permissions: List<String> = emptyList(), // permission keys
    val isSystem: Boolean = false
)

data class User(
    val id: String = UUID.randomUUID().toString(),
    val tenantId: String = "tenant-default",
    val email: String,
    val fullName: String,
    val roleIds: List<String> = emptyList(),
    val isActive: Boolean = true,
    val lastLoginAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

data class ApiKey(
    val id: String = UUID.randomUUID().toString(),
    val tenantId: String = "tenant-default",
    val name: String,
    val keyPrefix: String, // e.g. "ub_live_..."
    val hashedToken: String,
    val roleId: String,
    val rateLimitPerMinute: Int = 1000,
    val expiresAt: Long? = null,
    val lastUsedAt: Long? = null,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

// ==========================================
// 5. EVENT SYSTEM & BACKGROUND JOBS
// ==========================================

enum class EventType {
    DOMAIN,
    AUDIT,
    SYSTEM,
    USER_ACTION,
    WEBHOOK,
    INTEGRATION
}

data class EventMessage(
    val id: String = UUID.randomUUID().toString(),
    val tenantId: String = "tenant-default",
    val topic: String, // e.g. "order.created", "user.login", "schema.updated"
    val type: EventType = EventType.DOMAIN,
    val payloadJson: String,
    val producer: String = "core.engine",
    val timestamp: Long = System.currentTimeMillis(),
    val isProcessed: Boolean = true,
    val retryCount: Int = 0
)

enum class JobStatus {
    PENDING,
    RUNNING,
    COMPLETED,
    FAILED,
    CANCELLED
}

data class JobDefinition(
    val id: String = UUID.randomUUID().toString(),
    val tenantId: String = "tenant-default",
    val name: String,
    val taskType: String, // "RETENTION_PURGE", "REINDEX_SEARCH", "CACHE_WARMER", "WORKFLOW_SWEEP"
    val cronSchedule: String? = null, // e.g. "0 */6 * * *"
    val priority: Int = 5, // 1 (low) - 10 (high)
    val status: JobStatus = JobStatus.COMPLETED,
    val lastRunDurationMs: Long = 0L,
    val lastRunAt: Long? = null,
    val nextRunAt: Long? = null,
    val parameters: Map<String, String> = emptyMap()
)

// ==========================================
// 6. FEATURE FLAGS & CONFIGURATION
// ==========================================

enum class FlagType {
    BOOLEAN,
    PERCENTAGE_ROLLOUT,
    USER_TARGETED,
    TENANT_TARGETED
}

data class FeatureFlag(
    val id: String = UUID.randomUUID().toString(),
    val tenantId: String = "tenant-default",
    val key: String, // e.g. "enable_new_checkout", "ai_copilot_v2"
    val name: String,
    val description: String = "",
    val type: FlagType = FlagType.BOOLEAN,
    val isEnabled: Boolean = false,
    val rolloutPercentage: Int = 0, // 0 to 100
    val targetedUserEmails: List<String> = emptyList(),
    val targetedTenantIds: List<String> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class ConfigNode(
    val id: String = UUID.randomUUID().toString(),
    val tenantId: String? = null, // null = GLOBAL
    val scope: String = "GLOBAL", // GLOBAL, TENANT, APP, USER
    val key: String,
    val value: String,
    val valueType: String = "STRING", // STRING, NUMBER, BOOLEAN, JSON
    val isEncrypted: Boolean = false,
    val description: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

// ==========================================
// 7. AUDIT TRAIL, OBSERVABILITY & METRICS
// ==========================================

enum class AuditActionType {
    CREATE,
    READ,
    UPDATE,
    DELETE,
    EXECUTE,
    PUBLISH,
    ROLLBACK,
    LOGIN,
    PERMISSION_CHANGE
}

data class AuditLog(
    val id: String = UUID.randomUUID().toString(),
    val tenantId: String = "tenant-default",
    val actor: String, // user email or api key name
    val action: AuditActionType,
    val targetType: String, // "EntitySchema", "DynamicRecord", "SDUIScreen", "Workflow", "Role"
    val targetId: String,
    val details: String,
    val ipAddress: String = "127.0.0.1",
    val timestamp: Long = System.currentTimeMillis()
)

data class SystemMetrics(
    val totalRequests: Long = 0L,
    val totalErrors: Long = 0L,
    val averageLatencyMs: Double = 0.0,
    val activeTenantsCount: Int = 1,
    val totalEntitiesCount: Int = 0,
    val totalRecordsCount: Int = 0,
    val totalWorkflowsCount: Int = 0,
    val eventsProcessedCount: Long = 0L,
    val memoryUsageMb: Double = 0.0,
    val uptimeSeconds: Long = 0L
)

data class HealthStatus(
    val status: String = "HEALTHY", // HEALTHY, DEGRADED, UNHEALTHY
    val version: String = "3.7.0-universal-engine",
    val databaseStatus: String = "UP",
    val workflowEngineStatus: String = "RUNNING",
    val eventBusStatus: String = "ACTIVE",
    val activeWorkersCount: Int = 4,
    val timestamp: Long = System.currentTimeMillis()
)

// ==========================================
// 8. API ROUTER & DISPATCH CONTRACTS
// ==========================================

data class ApiRequest(
    val method: String, // GET, POST, PATCH, PUT, DELETE
    val path: String,
    val headers: Map<String, String> = emptyMap(),
    val queryParams: Map<String, String> = emptyMap(),
    val bodyJson: String? = null,
    val authenticatedUser: User? = null
)

data class ApiResponse<T>(
    val status: Int,
    val success: Boolean,
    val data: T? = null,
    val error: String? = null,
    val metadata: Map<String, Any> = emptyMap(),
    val timestamp: Long = System.currentTimeMillis()
)

data class ApiEndpointDoc(
    val method: String,
    val path: String,
    val summary: String,
    val tag: String,
    val requiredPermission: String?,
    val sampleRequestBody: String? = null,
    val sampleResponseBody: String? = null
)
