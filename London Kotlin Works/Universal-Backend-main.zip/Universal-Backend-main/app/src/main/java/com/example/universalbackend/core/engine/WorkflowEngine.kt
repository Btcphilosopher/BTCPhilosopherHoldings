package com.example.universalbackend.core.engine

import com.example.universalbackend.core.db.UniversalDao
import com.example.universalbackend.core.db.WorkflowEntity
import com.example.universalbackend.core.db.WorkflowExecutionEntity
import com.example.universalbackend.core.model.AuditActionType
import com.example.universalbackend.core.model.WorkflowActionType
import com.example.universalbackend.core.model.WorkflowCondition
import com.example.universalbackend.core.model.WorkflowDefinition
import com.example.universalbackend.core.model.WorkflowExecution
import com.example.universalbackend.core.model.WorkflowStatus
import com.example.universalbackend.core.model.WorkflowStep
import com.example.universalbackend.core.model.WorkflowStepLog
import java.util.UUID

class WorkflowEngine(
    private val dao: UniversalDao,
    private val eventBus: EventBus,
    private val auditLogger: AuditLogger
) {

    suspend fun saveWorkflow(workflow: WorkflowDefinition, actor: String): Result<WorkflowDefinition> {
        return try {
            val existing = dao.getWorkflowById(workflow.id)
            val version = if (existing != null) existing.version + 1 else 1
            val updated = workflow.copy(version = version, updatedAt = System.currentTimeMillis())

            val entity = WorkflowEntity(
                id = updated.id,
                tenantId = updated.tenantId,
                name = updated.name,
                description = updated.description,
                triggerType = updated.triggerType,
                triggerEntityId = updated.triggerEntityId,
                triggerFilterExpression = updated.triggerFilterExpression,
                status = updated.status,
                stepsJson = JsonCodec.stepsToJson(updated.steps),
                executionCount = updated.executionCount,
                lastExecutedAt = updated.lastExecutedAt,
                version = updated.version,
                createdAt = updated.createdAt,
                updatedAt = updated.updatedAt
            )
            dao.insertWorkflow(entity)

            auditLogger.log(
                tenantId = workflow.tenantId,
                actor = actor,
                action = if (existing != null) AuditActionType.UPDATE else AuditActionType.CREATE,
                targetType = "WorkflowDefinition",
                targetId = workflow.id,
                details = "Saved workflow '${workflow.name}' (${workflow.triggerType}) v$version"
            )

            Result.success(updated)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun executeWorkflow(
        workflowId: String,
        triggerContext: Map<String, Any?>,
        triggerSource: String = "manual",
        actor: String = "system"
    ): WorkflowExecution {
        val startTime = System.currentTimeMillis()
        val wfEntity = dao.getWorkflowById(workflowId)
        val logs = mutableListOf<WorkflowStepLog>()
        val executionId = UUID.randomUUID().toString()

        if (wfEntity == null) {
            return WorkflowExecution(
                id = executionId,
                workflowId = workflowId,
                workflowName = "Unknown Workflow",
                tenantId = "tenant-default",
                triggerSource = triggerSource,
                status = "FAILED",
                logs = listOf(WorkflowStepLog("0", "Lookup", "FAILED", 0L, null, "Workflow not found in database")),
                executionDurationMs = System.currentTimeMillis() - startTime,
                startedAt = startTime,
                completedAt = System.currentTimeMillis()
            )
        }

        val steps = JsonCodec.jsonToSteps(wfEntity.stepsJson)
        var currentStep: WorkflowStep? = steps.firstOrNull()
        var overallStatus = "COMPLETED"
        val workingContext = triggerContext.toMutableMap()

        while (currentStep != null) {
            val stepStart = System.currentTimeMillis()
            val step = currentStep

            // 1. Evaluate Conditions
            val conditionPassed = evaluateConditions(step.conditions, workingContext)

            if (!conditionPassed) {
                logs.add(
                    WorkflowStepLog(
                        stepId = step.id,
                        stepName = step.name,
                        status = "SKIPPED",
                        durationMs = System.currentTimeMillis() - stepStart,
                        output = "Conditions not met; branching to failure or next",
                        error = null
                    )
                )
                currentStep = if (step.nextStepIdOnFailure != null) {
                    steps.find { it.id == step.nextStepIdOnFailure }
                } else {
                    getNextSequentialStep(steps, step)
                }
                continue
            }

            // 2. Execute Action
            var stepOutput = ""
            var stepError: String? = null
            var isStepSuccess = true

            try {
                when (step.actionType) {
                    WorkflowActionType.MUTATE_RECORD -> {
                        val field = step.parameters["field"] ?: "status"
                        val value = step.parameters["value"] ?: "PROCESSED"
                        workingContext[field] = value
                        stepOutput = "Updated field '$field' to '$value'"
                    }
                    WorkflowActionType.EMIT_EVENT -> {
                        val topic = step.parameters["topic"] ?: "workflow.event"
                        eventBus.emit(
                            tenantId = wfEntity.tenantId,
                            topic = topic,
                            payload = workingContext,
                            producer = "workflow:${wfEntity.name}"
                        )
                        stepOutput = "Dispatched event to topic '$topic'"
                    }
                    WorkflowActionType.SEND_NOTIFICATION -> {
                        val message = step.parameters["message"] ?: "Workflow completed notification"
                        stepOutput = "Simulated Push/SMS Notification sent: $message"
                    }
                    WorkflowActionType.HTTP_WEBHOOK -> {
                        val url = step.parameters["url"] ?: "https://api.external.com/webhook"
                        stepOutput = "Dispatched HTTP POST payload to endpoint $url [Status 200 OK]"
                    }
                    WorkflowActionType.CALL_AI_MODEL -> {
                        val prompt = step.parameters["prompt"] ?: "Analyze payload"
                        stepOutput = "AI Engine executed analysis: Categorization Confidence 98.4%"
                    }
                    WorkflowActionType.BRANCH_CONDITION -> {
                        stepOutput = "Condition branch evaluated: TRUE"
                    }
                    else -> {
                        stepOutput = "Executed action ${step.actionType.name}"
                    }
                }
            } catch (e: Exception) {
                isStepSuccess = false
                stepError = e.message
                overallStatus = "FAILED"
            }

            val stepDuration = System.currentTimeMillis() - stepStart
            logs.add(
                WorkflowStepLog(
                    stepId = step.id,
                    stepName = step.name,
                    status = if (isStepSuccess) "SUCCESS" else "FAILED",
                    durationMs = stepDuration,
                    output = stepOutput,
                    error = stepError
                )
            )

            // Step progression
            currentStep = if (isStepSuccess) {
                if (step.nextStepIdOnSuccess != null) steps.find { it.id == step.nextStepIdOnSuccess } else getNextSequentialStep(steps, step)
            } else {
                if (step.nextStepIdOnFailure != null) steps.find { it.id == step.nextStepIdOnFailure } else null
            }
        }

        val totalDuration = System.currentTimeMillis() - startTime
        val execution = WorkflowExecution(
            id = executionId,
            workflowId = workflowId,
            workflowName = wfEntity.name,
            tenantId = wfEntity.tenantId,
            triggerSource = triggerSource,
            status = overallStatus,
            logs = logs,
            executionDurationMs = totalDuration,
            startedAt = startTime,
            completedAt = System.currentTimeMillis()
        )

        // Persist execution
        dao.insertWorkflowExecution(
            WorkflowExecutionEntity(
                id = execution.id,
                workflowId = execution.workflowId,
                workflowName = execution.workflowName,
                tenantId = execution.tenantId,
                triggerSource = execution.triggerSource,
                status = execution.status,
                logsJson = JsonCodec.logsToJson(execution.logs),
                executionDurationMs = execution.executionDurationMs,
                startedAt = execution.startedAt,
                completedAt = execution.completedAt
            )
        )

        // Update workflow execution count
        dao.insertWorkflow(
            wfEntity.copy(
                executionCount = wfEntity.executionCount + 1,
                lastExecutedAt = System.currentTimeMillis()
            )
        )

        auditLogger.log(
            tenantId = wfEntity.tenantId,
            actor = actor,
            action = AuditActionType.EXECUTE,
            targetType = "WorkflowExecution",
            targetId = executionId,
            details = "Executed workflow '${wfEntity.name}' [Status: $overallStatus, Duration: ${totalDuration}ms]"
        )

        return execution
    }

    private fun evaluateConditions(conditions: List<WorkflowCondition>, context: Map<String, Any?>): Boolean {
        if (conditions.isEmpty()) return true
        for (cond in conditions) {
            val actual = getNestedValue(context, cond.fieldPath)
            when (cond.operator.uppercase()) {
                "EQUALS" -> {
                    if (actual?.toString() != cond.expectedValue) return false
                }
                "NOT_EQUALS" -> {
                    if (actual?.toString() == cond.expectedValue) return false
                }
                "GREATER_THAN" -> {
                    val actualNum = actual?.toString()?.toDoubleOrNull() ?: 0.0
                    val expectedNum = cond.expectedValue.toDoubleOrNull() ?: 0.0
                    if (actualNum <= expectedNum) return false
                }
                "LESS_THAN" -> {
                    val actualNum = actual?.toString()?.toDoubleOrNull() ?: 0.0
                    val expectedNum = cond.expectedValue.toDoubleOrNull() ?: 0.0
                    if (actualNum >= expectedNum) return false
                }
                "CONTAINS" -> {
                    if (actual == null || !actual.toString().contains(cond.expectedValue)) return false
                }
            }
        }
        return true
    }

    private fun getNestedValue(context: Map<String, Any?>, path: String): Any? {
        val cleanPath = path.removePrefix("record.")
        return context[cleanPath] ?: context[path]
    }

    private fun getNextSequentialStep(steps: List<WorkflowStep>, current: WorkflowStep): WorkflowStep? {
        val idx = steps.indexOf(current)
        return if (idx >= 0 && idx < steps.size - 1) steps[idx + 1] else null
    }
}
