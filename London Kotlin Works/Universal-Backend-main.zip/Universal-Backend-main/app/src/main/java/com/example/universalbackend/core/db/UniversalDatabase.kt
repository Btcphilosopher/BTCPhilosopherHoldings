package com.example.universalbackend.core.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.universalbackend.core.engine.JsonCodec
import com.example.universalbackend.core.model.AuditActionType
import com.example.universalbackend.core.model.EventType
import com.example.universalbackend.core.model.FieldDefinition
import com.example.universalbackend.core.model.FieldType
import com.example.universalbackend.core.model.FlagType
import com.example.universalbackend.core.model.JobStatus
import com.example.universalbackend.core.model.SDUIAction
import com.example.universalbackend.core.model.SDUIActionType
import com.example.universalbackend.core.model.SDUIComponentType
import com.example.universalbackend.core.model.SDUINavItem
import com.example.universalbackend.core.model.SDUISection
import com.example.universalbackend.core.model.ValidationRule
import com.example.universalbackend.core.model.ValidationType
import com.example.universalbackend.core.model.WorkflowActionType
import com.example.universalbackend.core.model.WorkflowCondition
import com.example.universalbackend.core.model.WorkflowStatus
import com.example.universalbackend.core.model.WorkflowStep
import com.example.universalbackend.core.model.WorkflowTriggerType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.UUID

@Database(
    entities = [
        TenantEntity::class,
        SchemaEntity::class,
        RecordEntity::class,
        ScreenEntity::class,
        ComponentEntity::class,
        WorkflowEntity::class,
        WorkflowExecutionEntity::class,
        EventEntity::class,
        FeatureFlagEntity::class,
        ConfigEntity::class,
        JobEntity::class,
        UserEntity::class,
        RoleEntity::class,
        ApiKeyEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(UniversalTypeConverters::class)
abstract class UniversalDatabase : RoomDatabase() {

    abstract fun dao(): UniversalDao

    companion object {
        @Volatile
        private var INSTANCE: UniversalDatabase? = null

        fun getInstance(context: Context): UniversalDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    UniversalDatabase::class.java,
                    "universal_backend_os.db"
                )
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            CoroutineScope(Dispatchers.IO).launch {
                                INSTANCE?.let { seedInitialData(it.dao()) }
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }

        suspend fun seedInitialData(dao: UniversalDao) {
            val now = System.currentTimeMillis()
            val tenantId = "tenant-default"

            // 1. Default Tenant
            dao.insertTenant(
                TenantEntity(
                    id = tenantId,
                    name = "Acme Global Platform",
                    slug = "acme-global",
                    plan = "ENTERPRISE",
                    settingsJson = JsonCodec.stringMapToJson(
                        mapOf(
                            "region" to "us-east",
                            "environment" to "production",
                            "rateLimitTier" to "unlimited",
                            "encryptionLevel" to "AES-256"
                        )
                    ),
                    createdAt = now
                )
            )

            // 2. Standard Roles
            dao.insertRole(
                RoleEntity(
                    id = "role-super-admin",
                    tenantId = tenantId,
                    name = "SUPER_ADMIN",
                    description = "Full administrative access to all schemas, data, workflows, and system configs",
                    permissionsJson = JsonCodec.stringListToJson(
                        listOf(
                            "*:*",
                            "entity:*",
                            "record:*",
                            "sdui:*",
                            "workflow:*",
                            "iam:*",
                            "flag:*",
                            "config:*",
                            "metrics:*"
                        )
                    ),
                    isSystem = true
                )
            )
            dao.insertRole(
                RoleEntity(
                    id = "role-developer",
                    tenantId = tenantId,
                    name = "DEVELOPER",
                    description = "Can design schemas, build SDUI layouts, execute APIs, and create workflows",
                    permissionsJson = JsonCodec.stringListToJson(
                        listOf(
                            "entity:read", "entity:write",
                            "record:*",
                            "sdui:*",
                            "workflow:*",
                            "flag:read", "flag:write",
                            "api:execute"
                        )
                    ),
                    isSystem = true
                )
            )
            dao.insertRole(
                RoleEntity(
                    id = "role-operator",
                    tenantId = tenantId,
                    name = "OPERATIONS_MEMBER",
                    description = "Standard operator with CRUD access to business records",
                    permissionsJson = JsonCodec.stringListToJson(
                        listOf("record:read", "record:write", "sdui:read")
                    ),
                    isSystem = true
                )
            )

            // 3. Root User & API Key
            dao.insertUser(
                UserEntity(
                    id = "user-admin-root",
                    tenantId = tenantId,
                    email = "admin@platform.os",
                    fullName = "Platform Superuser",
                    roleIdsJson = JsonCodec.stringListToJson(listOf("role-super-admin")),
                    isActive = true,
                    lastLoginAt = now,
                    createdAt = now
                )
            )
            dao.insertApiKey(
                ApiKeyEntity(
                    id = "key-primary-dev",
                    tenantId = tenantId,
                    name = "Production API Key (Server-to-Server)",
                    keyPrefix = "ub_live_7x9",
                    hashedToken = "ub_live_secret_token_8899aabbccddeeff00112233",
                    roleId = "role-super-admin",
                    rateLimitPerMinute = 5000,
                    expiresAt = null,
                    lastUsedAt = now,
                    isActive = true,
                    createdAt = now
                )
            )

            // 4. Default Business Entity Schemas (Products, Orders, Customers, Support Tickets)
            val productFields = listOf(
                FieldDefinition(name = "name", displayName = "Product Name", type = FieldType.STRING, isRequired = true, validationRules = listOf(ValidationRule(ValidationType.MIN_LENGTH, "2"))),
                FieldDefinition(name = "sku", displayName = "SKU Code", type = FieldType.STRING, isRequired = true, isUnique = true),
                FieldDefinition(name = "category", displayName = "Category", type = FieldType.ENUM_TYPE, enumValues = listOf("Electronics", "Apparel", "Home & Office", "Industrial", "Digital Goods")),
                FieldDefinition(name = "price", displayName = "Base Price", type = FieldType.CURRENCY, isRequired = true, defaultValue = "0.00"),
                FieldDefinition(name = "stockQuantity", displayName = "Inventory Count", type = FieldType.INTEGER, defaultValue = "100"),
                FieldDefinition(name = "isPublished", displayName = "Live in Catalog", type = FieldType.BOOLEAN, defaultValue = "true"),
                FieldDefinition(name = "rating", displayName = "Average Rating", type = FieldType.DECIMAL, defaultValue = "4.8"),
                FieldDefinition(name = "tags", displayName = "Search Tags", type = FieldType.ARRAY_TYPE)
            )
            dao.insertSchema(
                SchemaEntity(
                    id = "schema-products",
                    tenantId = tenantId,
                    name = "products",
                    displayName = "Products & Catalog",
                    description = "Dynamic inventory and product catalog entity",
                    icon = "inventory_2",
                    version = 1,
                    isSystem = false,
                    isAudited = true,
                    isSoftDeleteEnabled = true,
                    fieldsJson = JsonCodec.fieldsToJson(productFields),
                    primaryField = "id",
                    titleField = "name",
                    createdAt = now,
                    updatedAt = now
                )
            )

            val orderFields = listOf(
                FieldDefinition(name = "orderNumber", displayName = "Order Number", type = FieldType.STRING, isRequired = true),
                FieldDefinition(name = "customerEmail", displayName = "Customer Email", type = FieldType.EMAIL, isRequired = true),
                FieldDefinition(name = "totalAmount", displayName = "Total Amount", type = FieldType.CURRENCY, isRequired = true),
                FieldDefinition(name = "currency", displayName = "Currency", type = FieldType.STRING, defaultValue = "USD"),
                FieldDefinition(name = "status", displayName = "Order Status", type = FieldType.ENUM_TYPE, enumValues = listOf("PENDING", "PROCESSING", "PAID", "SHIPPED", "DELIVERED", "REFUNDED")),
                FieldDefinition(name = "itemCount", displayName = "Total Items", type = FieldType.INTEGER, defaultValue = "1"),
                FieldDefinition(name = "paymentMethod", displayName = "Payment Gateway", type = FieldType.STRING, defaultValue = "Stripe Card"),
                FieldDefinition(name = "isPriority", displayName = "Expedited Shipping", type = FieldType.BOOLEAN, defaultValue = "false")
            )
            dao.insertSchema(
                SchemaEntity(
                    id = "schema-orders",
                    tenantId = tenantId,
                    name = "orders",
                    displayName = "Orders & Transactions",
                    description = "Customer checkout transactions and fulfillment records",
                    icon = "shopping_cart",
                    version = 1,
                    isSystem = false,
                    isAudited = true,
                    isSoftDeleteEnabled = true,
                    fieldsJson = JsonCodec.fieldsToJson(orderFields),
                    primaryField = "id",
                    titleField = "orderNumber",
                    createdAt = now,
                    updatedAt = now
                )
            )

            val ticketFields = listOf(
                FieldDefinition(name = "ticketNumber", displayName = "Ticket Reference", type = FieldType.STRING, isRequired = true),
                FieldDefinition(name = "subject", displayName = "Issue Subject", type = FieldType.STRING, isRequired = true),
                FieldDefinition(name = "priority", displayName = "Priority", type = FieldType.ENUM_TYPE, enumValues = listOf("LOW", "MEDIUM", "HIGH", "CRITICAL")),
                FieldDefinition(name = "status", displayName = "Status", type = FieldType.ENUM_TYPE, enumValues = listOf("OPEN", "IN_PROGRESS", "WAITING_ON_USER", "RESOLVED")),
                FieldDefinition(name = "requesterEmail", displayName = "Requester Email", type = FieldType.EMAIL, isRequired = true),
                FieldDefinition(name = "assignedAgent", displayName = "Assigned Agent", type = FieldType.STRING, defaultValue = "Tier 2 Support")
            )
            dao.insertSchema(
                SchemaEntity(
                    id = "schema-tickets",
                    tenantId = tenantId,
                    name = "support_tickets",
                    displayName = "Support Tickets",
                    description = "Helpdesk issue tracking and SLA workflow tickets",
                    icon = "support_agent",
                    version = 1,
                    isSystem = false,
                    isAudited = true,
                    isSoftDeleteEnabled = true,
                    fieldsJson = JsonCodec.fieldsToJson(ticketFields),
                    primaryField = "id",
                    titleField = "subject",
                    createdAt = now,
                    updatedAt = now
                )
            )

            // 5. Seed Dynamic Sample Records
            dao.insertRecord(
                RecordEntity(
                    id = "rec-prod-001",
                    tenantId = tenantId,
                    schemaId = "schema-products",
                    version = 1,
                    valuesJson = JsonCodec.valuesToJson(
                        mapOf(
                            "name" to "Quantum Core Processor X9",
                            "sku" to "PRD-Q9-001",
                            "category" to "Electronics",
                            "price" to 899.99,
                            "stockQuantity" to 42,
                            "isPublished" to true,
                            "rating" to 4.9,
                            "tags" to listOf("hardware", "cpu", "flagship")
                        )
                    ),
                    isDeleted = false,
                    createdAt = now - 86400000L * 3,
                    updatedAt = now,
                    createdBy = "system",
                    updatedBy = "system"
                )
            )
            dao.insertRecord(
                RecordEntity(
                    id = "rec-prod-002",
                    tenantId = tenantId,
                    schemaId = "schema-products",
                    version = 1,
                    valuesJson = JsonCodec.valuesToJson(
                        mapOf(
                            "name" to "CyberEdge Smart Router Pro",
                            "sku" to "PRD-RT-088",
                            "category" to "Electronics",
                            "price" to 249.50,
                            "stockQuantity" to 120,
                            "isPublished" to true,
                            "rating" to 4.7,
                            "tags" to listOf("networking", "wifi7")
                        )
                    ),
                    isDeleted = false,
                    createdAt = now - 86400000L * 2,
                    updatedAt = now,
                    createdBy = "system",
                    updatedBy = "system"
                )
            )
            dao.insertRecord(
                RecordEntity(
                    id = "rec-prod-003",
                    tenantId = tenantId,
                    schemaId = "schema-products",
                    version = 1,
                    valuesJson = JsonCodec.valuesToJson(
                        mapOf(
                            "name" to "Ergonomic Carbon Fiber Desk",
                            "sku" to "PRD-DK-500",
                            "category" to "Home & Office",
                            "price" to 650.00,
                            "stockQuantity" to 15,
                            "isPublished" to true,
                            "rating" to 4.8,
                            "tags" to listOf("furniture", "ergonomic")
                        )
                    ),
                    isDeleted = false,
                    createdAt = now - 86400000L,
                    updatedAt = now,
                    createdBy = "system",
                    updatedBy = "system"
                )
            )

            dao.insertRecord(
                RecordEntity(
                    id = "rec-ord-1001",
                    tenantId = tenantId,
                    schemaId = "schema-orders",
                    version = 1,
                    valuesJson = JsonCodec.valuesToJson(
                        mapOf(
                            "orderNumber" to "ORD-2026-8801",
                            "customerEmail" to "elena.rostova@techcorp.io",
                            "totalAmount" to 1149.49,
                            "currency" to "USD",
                            "status" to "PROCESSING",
                            "itemCount" to 2,
                            "paymentMethod" to "Stripe Enterprise",
                            "isPriority" to true
                        )
                    ),
                    isDeleted = false,
                    createdAt = now - 3600000L * 5,
                    updatedAt = now,
                    createdBy = "api_gateway",
                    updatedBy = "workflow_engine"
                )
            )
            dao.insertRecord(
                RecordEntity(
                    id = "rec-ord-1002",
                    tenantId = tenantId,
                    schemaId = "schema-orders",
                    version = 1,
                    valuesJson = JsonCodec.valuesToJson(
                        mapOf(
                            "orderNumber" to "ORD-2026-8802",
                            "customerEmail" to "marcus.vance@solaris.net",
                            "totalAmount" to 249.50,
                            "currency" to "USD",
                            "status" to "DELIVERED",
                            "itemCount" to 1,
                            "paymentMethod" to "Apple Pay",
                            "isPriority" to false
                        )
                    ),
                    isDeleted = false,
                    createdAt = now - 3600000L * 12,
                    updatedAt = now,
                    createdBy = "api_gateway",
                    updatedBy = "system"
                )
            )

            // 6. Server-Driven UI (SDUI) Screens & Structure
            val dashboardSections = listOf(
                SDUISection(id = "sec-dash-hero", screenId = "screen-dashboard", title = "Platform Overview", subtitle = "Real-time operating telemetry", position = 0, layoutType = "GRID_3", componentIds = listOf("comp-m1", "comp-m2", "comp-m3")),
                SDUISection(id = "sec-dash-recent", screenId = "screen-dashboard", title = "Recent High-Value Orders", subtitle = "Transactions synced from API engine", position = 1, layoutType = "COLUMN", componentIds = listOf("comp-orders-table"))
            )
            dao.insertScreen(
                ScreenEntity(
                    id = "screen-dashboard",
                    tenantId = tenantId,
                    appId = "app-primary",
                    slug = "/dashboard",
                    title = "Executive Dashboard",
                    description = "Aggregated KPI telemetry and real-time operations feed",
                    icon = "dashboard",
                    position = 0,
                    isHomeScreen = true,
                    isVisibleInNav = true,
                    requiredRolesJson = JsonCodec.stringListToJson(listOf("SUPER_ADMIN", "DEVELOPER", "OPERATIONS_MEMBER")),
                    version = 1,
                    sectionsJson = JsonCodec.sectionsToJson(dashboardSections),
                    metadataJson = JsonCodec.stringMapToJson(mapOf("refreshRateSec" to "30", "cachePolicy" to "STALE_WHILE_REVALIDATE")),
                    updatedAt = now
                )
            )

            // Dashboard Components
            dao.insertComponent(
                ComponentEntity(
                    id = "comp-m1",
                    screenId = "screen-dashboard",
                    sectionId = "sec-dash-hero",
                    parentComponentId = null,
                    type = SDUIComponentType.METRIC_CARD,
                    name = "Monthly Revenue KPI",
                    title = "$184,290.00",
                    position = 0,
                    isVisible = true,
                    requiredPermission = null,
                    configJson = JsonCodec.stringMapToJson(mapOf("subtitle" to "Gross Merchant Volume", "trend" to "+18.4% vs last month", "badgeColor" to "#10B981")),
                    dataBinding = "metric:gmv",
                    actionsJson = "[]",
                    childrenIdsJson = "[]",
                    version = 1
                )
            )
            dao.insertComponent(
                ComponentEntity(
                    id = "comp-m2",
                    screenId = "screen-dashboard",
                    sectionId = "sec-dash-hero",
                    parentComponentId = null,
                    type = SDUIComponentType.METRIC_CARD,
                    name = "Active Subscriptions KPI",
                    title = "1,428",
                    position = 1,
                    isVisible = true,
                    requiredPermission = null,
                    configJson = JsonCodec.stringMapToJson(mapOf("subtitle" to "Enterprise Tenants", "trend" to "+99.98% SLA", "badgeColor" to "#06B6D4")),
                    dataBinding = "metric:active_tenants",
                    actionsJson = "[]",
                    childrenIdsJson = "[]",
                    version = 1
                )
            )
            dao.insertComponent(
                ComponentEntity(
                    id = "comp-m3",
                    screenId = "screen-dashboard",
                    sectionId = "sec-dash-hero",
                    parentComponentId = null,
                    type = SDUIComponentType.METRIC_CARD,
                    name = "API Throughput KPI",
                    title = "4.2M req/day",
                    position = 2,
                    isVisible = true,
                    requiredPermission = null,
                    configJson = JsonCodec.stringMapToJson(mapOf("subtitle" to "Avg Latency 14ms", "trend" to "0.001% error rate", "badgeColor" to "#8B5CF6")),
                    dataBinding = "metric:api_throughput",
                    actionsJson = "[]",
                    childrenIdsJson = "[]",
                    version = 1
                )
            )

            // 7. Workflows
            val orderWorkflowSteps = listOf(
                WorkflowStep(
                    id = "step-1",
                    name = "Evaluate High-Value Order Rule",
                    actionType = WorkflowActionType.BRANCH_CONDITION,
                    conditions = listOf(WorkflowCondition("record.totalAmount", "GREATER_THAN", "500")),
                    parameters = mapOf("description" to "Flag orders exceeding $500 for priority routing"),
                    nextStepIdOnSuccess = "step-2",
                    nextStepIdOnFailure = "step-3"
                ),
                WorkflowStep(
                    id = "step-2",
                    name = "Tag Order as Priority & VIP",
                    actionType = WorkflowActionType.MUTATE_RECORD,
                    parameters = mapOf("field" to "isPriority", "value" to "true"),
                    nextStepIdOnSuccess = "step-3"
                ),
                WorkflowStep(
                    id = "step-3",
                    name = "Emit 'order.processed' Domain Event",
                    actionType = WorkflowActionType.EMIT_EVENT,
                    parameters = mapOf("topic" to "order.processed", "type" to "DOMAIN")
                )
            )
            dao.insertWorkflow(
                WorkflowEntity(
                    id = "wf-order-fulfillment",
                    tenantId = tenantId,
                    name = "Auto-Fulfillment & VIP Router",
                    description = "Automatically applies priority tags and notifies fulfillment workers upon order creation",
                    triggerType = WorkflowTriggerType.RECORD_CREATED,
                    triggerEntityId = "schema-orders",
                    triggerFilterExpression = "status == 'PENDING' || status == 'PROCESSING'",
                    status = WorkflowStatus.ACTIVE,
                    stepsJson = JsonCodec.stepsToJson(orderWorkflowSteps),
                    executionCount = 142L,
                    lastExecutedAt = now - 1800000L,
                    version = 2,
                    createdAt = now - 86400000L * 5,
                    updatedAt = now
                )
            )

            // 8. Feature Flags & Configs
            dao.insertFeatureFlag(
                FeatureFlagEntity(
                    id = "flag-smart-checkout",
                    tenantId = tenantId,
                    key = "enable_smart_checkout",
                    name = "AI-Powered Instant Checkout Flow",
                    description = "Enables biometric one-tap checkout and predictive cart recommendations",
                    type = FlagType.PERCENTAGE_ROLLOUT,
                    isEnabled = true,
                    rolloutPercentage = 75,
                    targetedUsersJson = "[]",
                    targetedTenantsJson = "[]",
                    updatedAt = now
                )
            )
            dao.insertFeatureFlag(
                FeatureFlagEntity(
                    id = "flag-vector-search",
                    tenantId = tenantId,
                    key = "vector_semantic_search",
                    name = "Neural Vector Search Engine",
                    description = "Switches product search from keyword tokenization to cosine embedding similarity",
                    type = FlagType.BOOLEAN,
                    isEnabled = true,
                    rolloutPercentage = 100,
                    targetedUsersJson = "[]",
                    targetedTenantsJson = "[]",
                    updatedAt = now
                )
            )
            dao.insertConfig(
                ConfigEntity(
                    id = "cfg-rate-limit",
                    tenantId = null,
                    scope = "GLOBAL",
                    key = "rate_limit_per_second",
                    value = "1000",
                    valueType = "NUMBER",
                    isEncrypted = false,
                    description = "Maximum permissible global HTTP requests per second",
                    updatedAt = now
                )
            )

            // 9. Initial Audit Log & System Event
            dao.insertAuditLog(
                AuditLogEntity(
                    id = UUID.randomUUID().toString(),
                    tenantId = tenantId,
                    actor = "admin@platform.os",
                    action = AuditActionType.CREATE,
                    targetType = "SystemBootstrap",
                    targetId = "core.os",
                    details = "Universal Application Backend operating system initialized successfully",
                    ipAddress = "127.0.0.1",
                    timestamp = now
                )
            )
            dao.insertEvent(
                EventEntity(
                    id = UUID.randomUUID().toString(),
                    tenantId = tenantId,
                    topic = "system.bootstrapped",
                    type = EventType.SYSTEM,
                    payloadJson = """{"status":"ONLINE","version":"3.7.0","schemasLoaded":3,"activeWorkers":4}""",
                    producer = "core.engine.bootstrap",
                    timestamp = now,
                    isProcessed = true,
                    retryCount = 0
                )
            )

            // 10. Background Jobs
            dao.insertJob(
                JobEntity(
                    id = "job-retention-purge",
                    tenantId = tenantId,
                    name = "Audit Log & Event Retention Purge",
                    taskType = "RETENTION_PURGE",
                    cronSchedule = "0 0 * * *",
                    priority = 3,
                    status = JobStatus.COMPLETED,
                    lastRunDurationMs = 184L,
                    lastRunAt = now - 3600000L * 4,
                    nextRunAt = now + 3600000L * 20,
                    parametersJson = """{"retentionDays":90}"""
                )
            )
            dao.insertJob(
                JobEntity(
                    id = "job-index-rebuilder",
                    tenantId = tenantId,
                    name = "Dynamic Schema Full-Text Reindex",
                    taskType = "REINDEX_SEARCH",
                    cronSchedule = "0 */6 * * *",
                    priority = 7,
                    status = JobStatus.COMPLETED,
                    lastRunDurationMs = 320L,
                    lastRunAt = now - 3600000L * 2,
                    nextRunAt = now + 3600000L * 4,
                    parametersJson = """{"entities":["products","orders"]}"""
                )
            )
        }
    }
}
