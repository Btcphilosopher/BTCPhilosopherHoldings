package com.example.universalbackend.core.engine

import com.example.universalbackend.core.db.ComponentEntity
import com.example.universalbackend.core.db.ScreenEntity
import com.example.universalbackend.core.db.UniversalDao
import com.example.universalbackend.core.model.AuditActionType
import com.example.universalbackend.core.model.EntitySchema
import com.example.universalbackend.core.model.FieldType
import com.example.universalbackend.core.model.SDUIAction
import com.example.universalbackend.core.model.SDUIActionType
import com.example.universalbackend.core.model.SDUIApp
import com.example.universalbackend.core.model.SDUIComponent
import com.example.universalbackend.core.model.SDUIComponentType
import com.example.universalbackend.core.model.SDUINavItem
import com.example.universalbackend.core.model.SDUIScreen
import com.example.universalbackend.core.model.SDUISection
import java.util.UUID

class SDUIEngine(
    private val dao: UniversalDao,
    private val auditLogger: AuditLogger
) {

    suspend fun getFullAppContract(tenantId: String, appId: String = "app-primary"): SDUIApp {
        val screenEntities = dao.getScreensSync(tenantId, appId)
        val screens = mutableListOf<SDUIScreen>()

        for (se in screenEntities) {
            val sections = JsonCodec.jsonToSections(se.sectionsJson)
            val roles = JsonCodec.jsonToStringList(se.requiredRolesJson)
            val metadata = JsonCodec.jsonToStringMap(se.metadataJson)
            screens.add(
                SDUIScreen(
                    id = se.id,
                    tenantId = se.tenantId,
                    appId = se.appId,
                    slug = se.slug,
                    title = se.title,
                    description = se.description,
                    icon = se.icon,
                    position = se.position,
                    isHomeScreen = se.isHomeScreen,
                    isVisibleInNav = se.isVisibleInNav,
                    requiredRoles = roles,
                    version = se.version,
                    sections = sections,
                    metadata = metadata,
                    updatedAt = se.updatedAt
                )
            )
        }

        val navItems = screens.filter { it.isVisibleInNav }.mapIndexed { idx, s ->
            SDUINavItem(
                id = "nav-${s.id}",
                label = s.title,
                icon = s.icon,
                screenSlug = s.slug,
                badgeCount = 0,
                position = idx
            )
        }

        return SDUIApp(
            id = appId,
            tenantId = tenantId,
            name = "Universal Enterprise App",
            version = "3.7.0",
            navigation = navItems,
            screens = screens,
            publishedAt = System.currentTimeMillis()
        )
    }

    suspend fun getScreenWithComponents(screenId: String): Pair<SDUIScreen?, List<SDUIComponent>> {
        val entity = dao.getScreenById(screenId) ?: return Pair(null, emptyList())
        val sections = JsonCodec.jsonToSections(entity.sectionsJson)
        val roles = JsonCodec.jsonToStringList(entity.requiredRolesJson)
        val metadata = JsonCodec.jsonToStringMap(entity.metadataJson)

        val screen = SDUIScreen(
            id = entity.id,
            tenantId = entity.tenantId,
            appId = entity.appId,
            slug = entity.slug,
            title = entity.title,
            description = entity.description,
            icon = entity.icon,
            position = entity.position,
            isHomeScreen = entity.isHomeScreen,
            isVisibleInNav = entity.isVisibleInNav,
            requiredRoles = roles,
            version = entity.version,
            sections = sections,
            metadata = metadata,
            updatedAt = entity.updatedAt
        )

        val compEntities = dao.getComponentsByScreenSync(screenId)
        val components = compEntities.map { c ->
            SDUIComponent(
                id = c.id,
                screenId = c.screenId,
                sectionId = c.sectionId,
                parentComponentId = c.parentComponentId,
                type = c.type,
                name = c.name,
                title = c.title,
                position = c.position,
                isVisible = c.isVisible,
                requiredPermission = c.requiredPermission,
                config = JsonCodec.jsonToStringMap(c.configJson),
                dataBinding = c.dataBinding,
                actions = JsonCodec.jsonToActions(c.actionsJson),
                childrenIds = JsonCodec.jsonToStringList(c.childrenIdsJson),
                version = c.version
            )
        }

        return Pair(screen, components)
    }

    suspend fun saveScreen(screen: SDUIScreen, actor: String): Result<SDUIScreen> {
        return try {
            val existing = dao.getScreenById(screen.id)
            val newVersion = if (existing != null) existing.version + 1 else 1
            val updated = screen.copy(version = newVersion, updatedAt = System.currentTimeMillis())

            val entity = ScreenEntity(
                id = updated.id,
                tenantId = updated.tenantId,
                appId = updated.appId,
                slug = updated.slug,
                title = updated.title,
                description = updated.description,
                icon = updated.icon,
                position = updated.position,
                isHomeScreen = updated.isHomeScreen,
                isVisibleInNav = updated.isVisibleInNav,
                requiredRolesJson = JsonCodec.stringListToJson(updated.requiredRoles),
                version = updated.version,
                sectionsJson = JsonCodec.sectionsToJson(updated.sections),
                metadataJson = JsonCodec.stringMapToJson(updated.metadata),
                updatedAt = updated.updatedAt
            )
            dao.insertScreen(entity)

            auditLogger.log(
                tenantId = screen.tenantId,
                actor = actor,
                action = if (existing != null) AuditActionType.UPDATE else AuditActionType.CREATE,
                targetType = "SDUIScreen",
                targetId = screen.id,
                details = "Saved screen '${screen.title}' (${screen.slug}) v$newVersion"
            )

            Result.success(updated)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun duplicateScreen(screenId: String, newSlug: String, newTitle: String, actor: String): Result<SDUIScreen> {
        return try {
            val (origScreen, origComps) = getScreenWithComponents(screenId)
            if (origScreen == null) return Result.failure(NoSuchElementException("Screen not found"))

            val newScreenId = UUID.randomUUID().toString()
            val duplicatedSections = origScreen.sections.map { s ->
                s.copy(id = UUID.randomUUID().toString(), screenId = newScreenId)
            }

            val duplicatedScreen = origScreen.copy(
                id = newScreenId,
                slug = newSlug,
                title = newTitle,
                isHomeScreen = false,
                version = 1,
                sections = duplicatedSections,
                updatedAt = System.currentTimeMillis()
            )
            saveScreen(duplicatedScreen, actor)

            // Duplicate child components
            for (c in origComps) {
                val newCompId = UUID.randomUUID().toString()
                val compEntity = ComponentEntity(
                    id = newCompId,
                    screenId = newScreenId,
                    sectionId = duplicatedSections.firstOrNull()?.id,
                    parentComponentId = null,
                    type = c.type,
                    name = "${c.name} (Copy)",
                    title = c.title,
                    position = c.position,
                    isVisible = c.isVisible,
                    requiredPermission = c.requiredPermission,
                    configJson = JsonCodec.stringMapToJson(c.config),
                    dataBinding = c.dataBinding,
                    actionsJson = JsonCodec.actionsToJson(c.actions),
                    childrenIdsJson = "[]",
                    version = 1
                )
                dao.insertComponent(compEntity)
            }

            Result.success(duplicatedScreen)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun moveComponent(
        componentId: String,
        targetScreenId: String,
        targetSectionId: String?,
        newPosition: Int,
        actor: String
    ): Result<Boolean> {
        return try {
            val c = dao.getComponentById(componentId) ?: return Result.failure(NoSuchElementException("Component not found"))
            val updated = c.copy(
                screenId = targetScreenId,
                sectionId = targetSectionId,
                position = newPosition,
                version = c.version + 1
            )
            dao.insertComponent(updated)

            auditLogger.log(
                tenantId = "tenant-default",
                actor = actor,
                action = AuditActionType.UPDATE,
                targetType = "SDUIComponent",
                targetId = componentId,
                details = "Moved component '${c.name}' to screen $targetScreenId pos $newPosition"
            )

            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveComponent(component: SDUIComponent, actor: String): Result<SDUIComponent> {
        return try {
            val entity = ComponentEntity(
                id = component.id,
                screenId = component.screenId,
                sectionId = component.sectionId,
                parentComponentId = component.parentComponentId,
                type = component.type,
                name = component.name,
                title = component.title,
                position = component.position,
                isVisible = component.isVisible,
                requiredPermission = component.requiredPermission,
                configJson = JsonCodec.stringMapToJson(component.config),
                dataBinding = component.dataBinding,
                actionsJson = JsonCodec.actionsToJson(component.actions),
                childrenIdsJson = JsonCodec.stringListToJson(component.childrenIds),
                version = component.version + 1
            )
            dao.insertComponent(entity)

            auditLogger.log(
                tenantId = "tenant-default",
                actor = actor,
                action = AuditActionType.UPDATE,
                targetType = "SDUIComponent",
                targetId = component.id,
                details = "Saved component '${component.name}' (${component.type})"
            )

            Result.success(component.copy(version = entity.version))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Dynamic Form Generation from Entity Schema
    fun generateDynamicFormLayout(schema: EntitySchema, targetScreenId: String): List<SDUIComponent> {
        val components = mutableListOf<SDUIComponent>()
        schema.fields.forEachIndexed { index, field ->
            val compType = when (field.type) {
                FieldType.ENUM_TYPE -> SDUIComponentType.DROPDOWN_SELECT
                FieldType.BOOLEAN -> SDUIComponentType.INPUT_FIELD
                FieldType.TEXT -> SDUIComponentType.INPUT_FIELD
                else -> SDUIComponentType.INPUT_FIELD
            }
            components.add(
                SDUIComponent(
                    id = UUID.randomUUID().toString(),
                    screenId = targetScreenId,
                    type = compType,
                    name = "Input: ${field.displayName}",
                    title = field.displayName,
                    position = index,
                    isVisible = true,
                    config = mapOf(
                        "fieldName" to field.name,
                        "fieldType" to field.type.name,
                        "placeholder" to "Enter ${field.displayName}",
                        "isRequired" to field.isRequired.toString()
                    ),
                    dataBinding = "form:${schema.name}.${field.name}"
                )
            )
        }
        return components
    }
}
