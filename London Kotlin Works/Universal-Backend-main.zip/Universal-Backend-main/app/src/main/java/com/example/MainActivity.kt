package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Http
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.ViewQuilt
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BrandCyan
import com.example.ui.theme.BrandEmerald
import com.example.ui.theme.BrandIndigo
import com.example.ui.theme.UniversalBackendTheme
import com.example.universalbackend.ui.ConsoleTab
import com.example.universalbackend.ui.UniversalPlatformViewModel
import com.example.universalbackend.ui.console.AiStudioCopilotScreen
import com.example.universalbackend.ui.console.ApiExplorerScreen
import com.example.universalbackend.ui.console.ConsoleDashboardScreen
import com.example.universalbackend.ui.console.EntityStudioScreen
import com.example.universalbackend.ui.console.EventsAndJobsScreen
import com.example.universalbackend.ui.console.FeatureFlagsConfigScreen
import com.example.universalbackend.ui.console.IamSecurityScreen
import com.example.universalbackend.ui.console.SDUIStudioScreen
import com.example.universalbackend.ui.console.SnapshotsScreen
import com.example.universalbackend.ui.console.WorkflowStudioScreen

class MainActivity : ComponentActivity() {

    private val viewModel: UniversalPlatformViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val isDarkTheme by viewModel.isDarkTheme.collectAsState()

            UniversalBackendTheme(darkTheme = isDarkTheme) {
                val activeTab by viewModel.activeTab.collectAsState()
                val metrics by viewModel.systemMetrics.collectAsState()
                val tenantId by viewModel.activeTenantId.collectAsState()

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        TopAppBar(
                            title = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(26.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(BrandIndigo),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Layers,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(15.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                text = "UNIVERSAL BACKEND OS",
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold,
                                                letterSpacing = 0.5.sp,
                                                fontSize = 13.sp,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(5.dp)
                                                        .clip(CircleShape)
                                                        .background(BrandEmerald)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = "$tenantId • 10 Services Live",
                                                    fontSize = 10.sp,
                                                    fontFamily = FontFamily.Monospace,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(4.dp))
                                                .padding(horizontal = 6.dp, vertical = 3.dp)
                                        ) {
                                            Text(
                                                text = "${metrics.totalRequests} reqs",
                                                fontSize = 10.sp,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold,
                                                color = BrandEmerald
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(4.dp))
                                        IconButton(
                                            onClick = { viewModel.toggleDarkTheme() },
                                            modifier = Modifier.size(32.dp).testTag("theme_toggle_button")
                                        ) {
                                            Icon(
                                                imageVector = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                                                contentDescription = "Toggle theme",
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            ),
                            modifier = Modifier.border(0.dp, Color.Transparent).background(MaterialTheme.colorScheme.surface)
                        )
                    },
                    bottomBar = {
                        PlatformNavigationRail(
                            selectedTab = activeTab,
                            onTabSelected = { viewModel.selectTab(it) }
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(MaterialTheme.colorScheme.background)
                    ) {
                        when (activeTab) {
                            ConsoleTab.DASHBOARD -> ConsoleDashboardScreen(viewModel)
                            ConsoleTab.ENTITIES_DATA -> EntityStudioScreen(viewModel)
                            ConsoleTab.SDUI_COMPOSER -> SDUIStudioScreen(viewModel)
                            ConsoleTab.WORKFLOWS -> WorkflowStudioScreen(viewModel)
                            ConsoleTab.IAM_SECURITY -> IamSecurityScreen(viewModel)
                            ConsoleTab.FEATURE_FLAGS -> FeatureFlagsConfigScreen(viewModel)
                            ConsoleTab.API_EXPLORER -> ApiExplorerScreen(viewModel)
                            ConsoleTab.EVENTS_JOBS -> EventsAndJobsScreen(viewModel)
                            ConsoleTab.AI_COPILOT -> AiStudioCopilotScreen(viewModel)
                            ConsoleTab.SNAPSHOTS -> SnapshotsScreen(viewModel)
                        }
                    }
                }
            }
        }
    }
}

data class ConsoleNavDestination(
    val tab: ConsoleTab,
    val label: String,
    val icon: ImageVector
)

@Composable
fun PlatformNavigationRail(
    selectedTab: ConsoleTab,
    onTabSelected: (ConsoleTab) -> Unit
) {
    val destinations = listOf(
        ConsoleNavDestination(ConsoleTab.DASHBOARD, "Dashboard", Icons.Default.Dashboard),
        ConsoleNavDestination(ConsoleTab.ENTITIES_DATA, "Entities", Icons.Default.Storage),
        ConsoleNavDestination(ConsoleTab.SDUI_COMPOSER, "SDUI", Icons.Default.ViewQuilt),
        ConsoleNavDestination(ConsoleTab.WORKFLOWS, "Workflows", Icons.Default.AccountTree),
        ConsoleNavDestination(ConsoleTab.IAM_SECURITY, "IAM", Icons.Default.Security),
        ConsoleNavDestination(ConsoleTab.FEATURE_FLAGS, "Flags", Icons.Default.Tune),
        ConsoleNavDestination(ConsoleTab.API_EXPLORER, "API", Icons.Default.Http),
        ConsoleNavDestination(ConsoleTab.EVENTS_JOBS, "Events", Icons.Default.Sensors),
        ConsoleNavDestination(ConsoleTab.AI_COPILOT, "AI Copilot", Icons.Default.AutoAwesome),
        ConsoleNavDestination(ConsoleTab.SNAPSHOTS, "Templates", Icons.Default.Download)
    )

    Surface(
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        ScrollableTabRow(
            selectedTabIndex = destinations.indexOfFirst { it.tab == selectedTab }.coerceAtLeast(0),
            edgePadding = 4.dp,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.primary,
            divider = {}
        ) {
            destinations.forEach { dest ->
                val isSelected = dest.tab == selectedTab
                Tab(
                    selected = isSelected,
                    onClick = { onTabSelected(dest.tab) },
                    modifier = Modifier.testTag("nav_tab_${dest.tab.name.lowercase()}"),
                    text = {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.padding(vertical = 4.dp, horizontal = 2.dp)
                        ) {
                            Icon(
                                imageVector = dest.icon,
                                contentDescription = dest.label,
                                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = dest.label,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Default,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                )
            }
        }
    }
}

