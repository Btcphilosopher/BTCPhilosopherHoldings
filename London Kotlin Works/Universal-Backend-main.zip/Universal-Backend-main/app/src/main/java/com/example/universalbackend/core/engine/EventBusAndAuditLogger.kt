package com.example.universalbackend.core.engine

import com.example.universalbackend.core.db.AuditLogEntity
import com.example.universalbackend.core.db.EventEntity
import com.example.universalbackend.core.db.UniversalDao
import com.example.universalbackend.core.model.AuditActionType
import com.example.universalbackend.core.model.AuditLog
import com.example.universalbackend.core.model.EventMessage
import com.example.universalbackend.core.model.EventType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.UUID

class EventBus(
    private val dao: UniversalDao,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {
    private val _eventStream = MutableSharedFlow<EventMessage>(extraBufferCapacity = 64)
    val eventStream: SharedFlow<EventMessage> = _eventStream.asSharedFlow()

    private val subscribers = mutableMapOf<String, MutableList<suspend (EventMessage) -> Unit>>()

    fun subscribe(topic: String, handler: suspend (EventMessage) -> Unit) {
        subscribers.getOrPut(topic) { mutableListOf() }.add(handler)
    }

    suspend fun emit(
        tenantId: String,
        topic: String,
        payload: Map<String, Any?>,
        type: EventType = EventType.DOMAIN,
        producer: String = "core.engine"
    ): EventMessage {
        val event = EventMessage(
            id = UUID.randomUUID().toString(),
            tenantId = tenantId,
            topic = topic,
            type = type,
            payloadJson = JSONObject(payload).toString(),
            producer = producer,
            timestamp = System.currentTimeMillis(),
            isProcessed = true,
            retryCount = 0
        )

        // Persist to Room
        val entity = EventEntity(
            id = event.id,
            tenantId = event.tenantId,
            topic = event.topic,
            type = event.type,
            payloadJson = event.payloadJson,
            producer = event.producer,
            timestamp = event.timestamp,
            isProcessed = event.isProcessed,
            retryCount = event.retryCount
        )
        dao.insertEvent(entity)

        // Emit to stream
        _eventStream.tryEmit(event)

        // Notify subscribers
        scope.launch {
            subscribers[topic]?.forEach { handler ->
                try {
                    handler(event)
                } catch (e: Exception) {
                    // handler error recorded
                }
            }
            // Wildcard listeners
            subscribers["*"]?.forEach { handler ->
                try {
                    handler(event)
                } catch (e: Exception) {
                    // wildcard error
                }
            }
        }

        return event
    }
}

class AuditLogger(
    private val dao: UniversalDao
) {
    suspend fun log(
        tenantId: String,
        actor: String,
        action: AuditActionType,
        targetType: String,
        targetId: String,
        details: String,
        ipAddress: String = "127.0.0.1"
    ): AuditLog {
        val log = AuditLog(
            id = UUID.randomUUID().toString(),
            tenantId = tenantId,
            actor = actor,
            action = action,
            targetType = targetType,
            targetId = targetId,
            details = details,
            ipAddress = ipAddress,
            timestamp = System.currentTimeMillis()
        )

        val entity = AuditLogEntity(
            id = log.id,
            tenantId = log.tenantId,
            actor = log.actor,
            action = log.action,
            targetType = log.targetType,
            targetId = log.targetId,
            details = log.details,
            ipAddress = log.ipAddress,
            timestamp = log.timestamp
        )
        dao.insertAuditLog(entity)
        return log
    }
}
