package com.example.universalbackend.core.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.universalbackend.core.model.AuditActionType
import com.example.universalbackend.core.model.EventType
import com.example.universalbackend.core.model.FlagType
import com.example.universalbackend.core.model.JobStatus
import com.example.universalbackend.core.model.SDUIComponentType
import com.example.universalbackend.core.model.WorkflowStatus
import com.example.universalbackend.core.model.WorkflowTriggerType

@Entity(
    tableName = "tenants",
    indices = [Index(value = ["slug"], unique = true)]
)
data class TenantEntity(
    @PrimaryKey val id: String,
    val name: String,
    val slug: String,
    val plan: String,
    val settingsJson: String,
    val createdAt: Long
)

@Entity(
    tableName = "entity_schemas",
    indices = [Index(value = ["tenantId", "name"], unique = true)]
)
data class SchemaEntity(
    @PrimaryKey val id: String,
    val tenantId: String,
    val name: String,
    val displayName: String,
    val description: String,
    val icon: String,
    val version: Int,
    val isSystem: Boolean,
    val isAudited: Boolean,
    val isSoftDeleteEnabled: Boolean,
    val fieldsJson: String, // List<FieldDefinition> serialized to JSON
    val primaryField: String,
    val titleField: String,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "dynamic_records",
    indices = [
        Index(value = ["tenantId", "schemaId"]),
        Index(value = ["schemaId", "isDeleted"])
    ]
)
data class RecordEntity(
    @PrimaryKey val id: String,
    val tenantId: String,
    val schemaId: String,
    val version: Int,
    val valuesJson: String, // Map<String, Any?> serialized to JSON
    val isDeleted: Boolean,
    val createdAt: Long,
    val updatedAt: Long,
    val createdBy: String,
    val updatedBy: String
)

@Entity(
    tableName = "sdui_screens",
    indices = [Index(value = ["tenantId", "appId", "slug"], unique = true)]
)
data class ScreenEntity(
    @PrimaryKey val id: String,
    val tenantId: String,
    val appId: String,
    val slug: String,
    val title: String,
    val description: String?,
    val icon: String,
    val position: Int,
    val isHomeScreen: Boolean,
    val isVisibleInNav: Boolean,
    val requiredRolesJson: String, // List<String>
    val version: Int,
    val sectionsJson: String, // List<SDUISection>
    val metadataJson: String,
    val updatedAt: Long
)

@Entity(
    tableName = "sdui_components",
    indices = [Index(value = ["screenId", "position"])]
)
data class ComponentEntity(
    @PrimaryKey val id: String,
    val screenId: String,
    val sectionId: String?,
    val parentComponentId: String?,
    val type: SDUIComponentType,
    val name: String,
    val title: String?,
    val position: Int,
    val isVisible: Boolean,
    val requiredPermission: String?,
    val configJson: String,
    val dataBinding: String?,
    val actionsJson: String,
    val childrenIdsJson: String,
    val version: Int
)

@Entity(
    tableName = "workflows",
    indices = [Index(value = ["tenantId", "status"])]
)
data class WorkflowEntity(
    @PrimaryKey val id: String,
    val tenantId: String,
    val name: String,
    val description: String,
    val triggerType: WorkflowTriggerType,
    val triggerEntityId: String?,
    val triggerFilterExpression: String?,
    val status: WorkflowStatus,
    val stepsJson: String, // List<WorkflowStep>
    val executionCount: Long,
    val lastExecutedAt: Long?,
    val version: Int,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "workflow_executions",
    indices = [Index(value = ["workflowId", "startedAt"])]
)
data class WorkflowExecutionEntity(
    @PrimaryKey val id: String,
    val workflowId: String,
    val workflowName: String,
    val tenantId: String,
    val triggerSource: String,
    val status: String,
    val logsJson: String,
    val executionDurationMs: Long,
    val startedAt: Long,
    val completedAt: Long?
)

@Entity(
    tableName = "events",
    indices = [Index(value = ["tenantId", "topic"]), Index(value = ["timestamp"])]
)
data class EventEntity(
    @PrimaryKey val id: String,
    val tenantId: String,
    val topic: String,
    val type: EventType,
    val payloadJson: String,
    val producer: String,
    val timestamp: Long,
    val isProcessed: Boolean,
    val retryCount: Int
)

@Entity(
    tableName = "feature_flags",
    indices = [Index(value = ["tenantId", "key"], unique = true)]
)
data class FeatureFlagEntity(
    @PrimaryKey val id: String,
    val tenantId: String,
    val key: String,
    val name: String,
    val description: String,
    val type: FlagType,
    val isEnabled: Boolean,
    val rolloutPercentage: Int,
    val targetedUsersJson: String,
    val targetedTenantsJson: String,
    val updatedAt: Long
)

@Entity(
    tableName = "configs",
    indices = [Index(value = ["tenantId", "scope", "key"], unique = true)]
)
data class ConfigEntity(
    @PrimaryKey val id: String,
    val tenantId: String?,
    val scope: String,
    val key: String,
    val value: String,
    val valueType: String,
    val isEncrypted: Boolean,
    val description: String,
    val updatedAt: Long
)

@Entity(tableName = "background_jobs")
data class JobEntity(
    @PrimaryKey val id: String,
    val tenantId: String,
    val name: String,
    val taskType: String,
    val cronSchedule: String?,
    val priority: Int,
    val status: JobStatus,
    val lastRunDurationMs: Long,
    val lastRunAt: Long?,
    val nextRunAt: Long?,
    val parametersJson: String
)

@Entity(
    tableName = "users",
    indices = [Index(value = ["tenantId", "email"], unique = true)]
)
data class UserEntity(
    @PrimaryKey val id: String,
    val tenantId: String,
    val email: String,
    val fullName: String,
    val roleIdsJson: String,
    val isActive: Boolean,
    val lastLoginAt: Long?,
    val createdAt: Long
)

@Entity(
    tableName = "roles",
    indices = [Index(value = ["tenantId", "name"], unique = true)]
)
data class RoleEntity(
    @PrimaryKey val id: String,
    val tenantId: String,
    val name: String,
    val description: String,
    val permissionsJson: String,
    val isSystem: Boolean
)

@Entity(
    tableName = "api_keys",
    indices = [Index(value = ["hashedToken"], unique = true)]
)
data class ApiKeyEntity(
    @PrimaryKey val id: String,
    val tenantId: String,
    val name: String,
    val keyPrefix: String,
    val hashedToken: String,
    val roleId: String,
    val rateLimitPerMinute: Int,
    val expiresAt: Long?,
    val lastUsedAt: Long?,
    val isActive: Boolean,
    val createdAt: Long
)

@Entity(
    tableName = "audit_logs",
    indices = [Index(value = ["tenantId", "timestamp"]), Index(value = ["targetType", "targetId"])]
)
data class AuditLogEntity(
    @PrimaryKey val id: String,
    val tenantId: String,
    val actor: String,
    val action: AuditActionType,
    val targetType: String,
    val targetId: String,
    val details: String,
    val ipAddress: String,
    val timestamp: Long
)
