package com.example.universalbackend.core.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface UniversalDao {

    // --- Tenants ---
    @Query("SELECT * FROM tenants ORDER BY name ASC")
    fun getAllTenants(): Flow<List<TenantEntity>>

    @Query("SELECT * FROM tenants WHERE id = :id LIMIT 1")
    suspend fun getTenantById(id: String): TenantEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTenant(tenant: TenantEntity)

    // --- Schemas ---
    @Query("SELECT * FROM entity_schemas WHERE tenantId = :tenantId ORDER BY displayName ASC")
    fun getSchemasByTenant(tenantId: String): Flow<List<SchemaEntity>>

    @Query("SELECT * FROM entity_schemas WHERE id = :id LIMIT 1")
    suspend fun getSchemaById(id: String): SchemaEntity?

    @Query("SELECT * FROM entity_schemas WHERE tenantId = :tenantId AND name = :name LIMIT 1")
    suspend fun getSchemaByName(tenantId: String, name: String): SchemaEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchema(schema: SchemaEntity)

    @Query("DELETE FROM entity_schemas WHERE id = :id")
    suspend fun deleteSchemaById(id: String)

    // --- Records ---
    @Query("SELECT * FROM dynamic_records WHERE schemaId = :schemaId AND isDeleted = 0 ORDER BY createdAt DESC")
    fun getRecordsBySchema(schemaId: String): Flow<List<RecordEntity>>

    @Query("SELECT * FROM dynamic_records WHERE schemaId = :schemaId AND isDeleted = 0 ORDER BY createdAt DESC")
    suspend fun getRecordsBySchemaSync(schemaId: String): List<RecordEntity>

    @Query("SELECT * FROM dynamic_records WHERE id = :id LIMIT 1")
    suspend fun getRecordById(id: String): RecordEntity?

    @Query("SELECT COUNT(*) FROM dynamic_records WHERE isDeleted = 0")
    suspend fun getTotalRecordCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: RecordEntity)

    @Update
    suspend fun updateRecord(record: RecordEntity)

    @Query("UPDATE dynamic_records SET isDeleted = 1, updatedAt = :timestamp WHERE id = :id")
    suspend fun softDeleteRecord(id: String, timestamp: Long)

    @Query("DELETE FROM dynamic_records WHERE id = :id")
    suspend fun hardDeleteRecord(id: String)

    // --- SDUI Screens ---
    @Query("SELECT * FROM sdui_screens WHERE tenantId = :tenantId AND appId = :appId ORDER BY position ASC")
    fun getScreens(tenantId: String, appId: String): Flow<List<ScreenEntity>>

    @Query("SELECT * FROM sdui_screens WHERE tenantId = :tenantId AND appId = :appId ORDER BY position ASC")
    suspend fun getScreensSync(tenantId: String, appId: String): List<ScreenEntity>

    @Query("SELECT * FROM sdui_screens WHERE id = :id LIMIT 1")
    suspend fun getScreenById(id: String): ScreenEntity?

    @Query("SELECT * FROM sdui_screens WHERE slug = :slug AND tenantId = :tenantId LIMIT 1")
    suspend fun getScreenBySlug(slug: String, tenantId: String): ScreenEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScreen(screen: ScreenEntity)

    @Query("DELETE FROM sdui_screens WHERE id = :id")
    suspend fun deleteScreenById(id: String)

    // --- SDUI Components ---
    @Query("SELECT * FROM sdui_components WHERE screenId = :screenId ORDER BY position ASC")
    fun getComponentsByScreen(screenId: String): Flow<List<ComponentEntity>>

    @Query("SELECT * FROM sdui_components WHERE screenId = :screenId ORDER BY position ASC")
    suspend fun getComponentsByScreenSync(screenId: String): List<ComponentEntity>

    @Query("SELECT * FROM sdui_components WHERE id = :id LIMIT 1")
    suspend fun getComponentById(id: String): ComponentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComponent(component: ComponentEntity)

    @Query("DELETE FROM sdui_components WHERE id = :id")
    suspend fun deleteComponentById(id: String)

    // --- Workflows ---
    @Query("SELECT * FROM workflows WHERE tenantId = :tenantId ORDER BY updatedAt DESC")
    fun getWorkflows(tenantId: String): Flow<List<WorkflowEntity>>

    @Query("SELECT * FROM workflows WHERE id = :id LIMIT 1")
    suspend fun getWorkflowById(id: String): WorkflowEntity?

    @Query("SELECT * FROM workflows WHERE tenantId = :tenantId AND status = 'ACTIVE'")
    suspend fun getActiveWorkflows(tenantId: String): List<WorkflowEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkflow(workflow: WorkflowEntity)

    @Query("DELETE FROM workflows WHERE id = :id")
    suspend fun deleteWorkflowById(id: String)

    // --- Workflow Executions ---
    @Query("SELECT * FROM workflow_executions WHERE tenantId = :tenantId ORDER BY startedAt DESC LIMIT 50")
    fun getWorkflowExecutions(tenantId: String): Flow<List<WorkflowExecutionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkflowExecution(execution: WorkflowExecutionEntity)

    // --- Events ---
    @Query("SELECT * FROM events WHERE tenantId = :tenantId ORDER BY timestamp DESC LIMIT 100")
    fun getRecentEvents(tenantId: String): Flow<List<EventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: EventEntity)

    @Query("SELECT COUNT(*) FROM events")
    suspend fun getTotalEventCount(): Long

    // --- Feature Flags ---
    @Query("SELECT * FROM feature_flags WHERE tenantId = :tenantId ORDER BY key ASC")
    fun getFeatureFlags(tenantId: String): Flow<List<FeatureFlagEntity>>

    @Query("SELECT * FROM feature_flags WHERE tenantId = :tenantId AND key = :key LIMIT 1")
    suspend fun getFeatureFlagByKey(tenantId: String, key: String): FeatureFlagEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFeatureFlag(flag: FeatureFlagEntity)

    @Query("DELETE FROM feature_flags WHERE id = :id")
    suspend fun deleteFeatureFlag(id: String)

    // --- Configs ---
    @Query("SELECT * FROM configs WHERE tenantId = :tenantId OR tenantId IS NULL ORDER BY scope ASC, key ASC")
    fun getConfigs(tenantId: String): Flow<List<ConfigEntity>>

    @Query("SELECT * FROM configs WHERE (tenantId = :tenantId OR tenantId IS NULL) AND key = :key LIMIT 1")
    suspend fun getConfigByKey(tenantId: String, key: String): ConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConfig(config: ConfigEntity)

    // --- Jobs ---
    @Query("SELECT * FROM background_jobs WHERE tenantId = :tenantId ORDER BY priority DESC")
    fun getJobs(tenantId: String): Flow<List<JobEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJob(job: JobEntity)

    @Query("UPDATE background_jobs SET status = :status, lastRunAt = :lastRunAt, lastRunDurationMs = :duration WHERE id = :id")
    suspend fun updateJobExecution(id: String, status: com.example.universalbackend.core.model.JobStatus, lastRunAt: Long, duration: Long)

    // --- Users & Roles ---
    @Query("SELECT * FROM users WHERE tenantId = :tenantId ORDER BY fullName ASC")
    fun getUsersByTenant(tenantId: String): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserById(id: String): UserEntity?

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Query("SELECT * FROM roles WHERE tenantId = :tenantId ORDER BY name ASC")
    fun getRolesByTenant(tenantId: String): Flow<List<RoleEntity>>

    @Query("SELECT * FROM roles WHERE id = :id LIMIT 1")
    suspend fun getRoleById(id: String): RoleEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRole(role: RoleEntity)

    // --- API Keys ---
    @Query("SELECT * FROM api_keys WHERE tenantId = :tenantId ORDER BY createdAt DESC")
    fun getApiKeys(tenantId: String): Flow<List<ApiKeyEntity>>

    @Query("SELECT * FROM api_keys WHERE hashedToken = :token AND isActive = 1 LIMIT 1")
    suspend fun getApiKeyByToken(token: String): ApiKeyEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApiKey(apiKey: ApiKeyEntity)

    @Query("DELETE FROM api_keys WHERE id = :id")
    suspend fun deleteApiKey(id: String)

    // --- Audit Logs ---
    @Query("SELECT * FROM audit_logs WHERE tenantId = :tenantId ORDER BY timestamp DESC LIMIT 100")
    fun getAuditLogs(tenantId: String): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity)
}
