package com.example.universalbackend.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.universalbackend.core.api.UniversalApiRouter
import com.example.universalbackend.core.db.ComponentEntity
import com.example.universalbackend.core.db.SchemaEntity
import com.example.universalbackend.core.db.ScreenEntity
import com.example.universalbackend.core.db.UniversalDatabase
import com.example.universalbackend.core.engine.AIAssistantEngine
import com.example.universalbackend.core.engine.AISchemaProposal
import com.example.universalbackend.core.engine.AIWorkflowProposal
import com.example.universalbackend.core.engine.AuditLogger
import com.example.universalbackend.core.engine.AuthAndIamEngine
import com.example.universalbackend.core.engine.EventBus
import com.example.universalbackend.core.engine.ExportImportEngine
import com.example.universalbackend.core.engine.FeatureFlagAndConfigEngine
import com.example.universalbackend.core.engine.JobAutomationEngine
import com.example.universalbackend.core.engine.JsonCodec
import com.example.universalbackend.core.engine.PlatformDiagnosticsEngine
import com.example.universalbackend.core.engine.SDUIEngine
import com.example.universalbackend.core.engine.SchemaAndRecordEngine
import com.example.universalbackend.core.engine.WorkflowEngine
import com.example.universalbackend.core.model.ApiEndpointDoc
import com.example.universalbackend.core.model.ApiRequest
import com.example.universalbackend.core.model.ApiResponse
import com.example.universalbackend.core.model.DynamicRecord
import com.example.universalbackend.core.model.EntitySchema
import com.example.universalbackend.core.model.FeatureFlag
import com.example.universalbackend.core.model.HealthStatus
import com.example.universalbackend.core.model.SDUIComponent
import com.example.universalbackend.core.model.SDUIScreen
import com.example.universalbackend.core.model.SystemMetrics
import com.example.universalbackend.core.model.Tenant
import com.example.universalbackend.core.model.WorkflowDefinition
import com.example.universalbackend.core.model.WorkflowExecution
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

enum class ConsoleTab {
    DASHBOARD,
    ENTITIES_DATA,
    SDUI_COMPOSER,
    WORKFLOWS,
    IAM_SECURITY,
    FEATURE_FLAGS,
    API_EXPLORER,
    EVENTS_JOBS,
    AI_COPILOT,
    SNAPSHOTS
}

class UniversalPlatformViewModel(application: Application) : AndroidViewModel(application) {

    private val db = UniversalDatabase.getInstance(application)
    val dao = db.dao()

    val auditLogger = AuditLogger(dao)
    val eventBus = EventBus(dao, viewModelScope)
    val schemaAndRecordEngine = SchemaAndRecordEngine(dao, eventBus, auditLogger)
    val sduiEngine = SDUIEngine(dao, auditLogger)
    val workflowEngine = WorkflowEngine(dao, eventBus, auditLogger)
    val authEngine = AuthAndIamEngine(dao, auditLogger)
    val featureFlagEngine = FeatureFlagAndConfigEngine(dao, auditLogger)
    val jobEngine = JobAutomationEngine(dao, auditLogger, eventBus)
    val exportImportEngine = ExportImportEngine(dao, schemaAndRecordEngine, sduiEngine, workflowEngine, auditLogger)
    val aiEngine = AIAssistantEngine()
    val diagnosticsEngine = PlatformDiagnosticsEngine(dao)
    val apiRouter = UniversalApiRouter(
        dao, schemaAndRecordEngine, sduiEngine, workflowEngine,
        authEngine, featureFlagEngine, diagnosticsEngine, eventBus
    )

    // Current State
    private val _activeTab = MutableStateFlow(ConsoleTab.DASHBOARD)
    val activeTab: StateFlow<ConsoleTab> = _activeTab.asStateFlow()

    private val _activeTenantId = MutableStateFlow("tenant-default")
    val activeTenantId: StateFlow<String> = _activeTenantId.asStateFlow()

    private val _activeActor = MutableStateFlow("admin@platform.os")
    val activeActor: StateFlow<String> = _activeActor.asStateFlow()

    // Reactive DB Data
    val tenants = dao.getAllTenants().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val schemas = dao.getSchemasByTenant("tenant-default").stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val screens = dao.getScreens("tenant-default", "app-primary").stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val workflows = dao.getWorkflows("tenant-default").stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val workflowExecutions = dao.getWorkflowExecutions("tenant-default").stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val events = dao.getRecentEvents("tenant-default").stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val featureFlags = dao.getFeatureFlags("tenant-default").stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val configs = dao.getConfigs("tenant-default").stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val jobs = dao.getJobs("tenant-default").stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val users = dao.getUsersByTenant("tenant-default").stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val roles = dao.getRolesByTenant("tenant-default").stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val apiKeys = dao.getApiKeys("tenant-default").stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val auditLogs = dao.getAuditLogs("tenant-default").stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Theme & UI Mode
    private val _isDarkTheme = MutableStateFlow(false)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    fun toggleDarkTheme() {
        _isDarkTheme.value = !_isDarkTheme.value
    }

    // Selection States
    private val _selectedSchemaId = MutableStateFlow<String?>("schema-products")
    val selectedSchemaId: StateFlow<String?> = _selectedSchemaId.asStateFlow()

    private val _selectedScreenId = MutableStateFlow<String?>("screen-dashboard")
    val selectedScreenId: StateFlow<String?> = _selectedScreenId.asStateFlow()

    private val _selectedScreenComponents = MutableStateFlow<List<ComponentEntity>>(emptyList())
    val selectedScreenComponents: StateFlow<List<ComponentEntity>> = _selectedScreenComponents.asStateFlow()

    // Telemetry & Metrics
    private val _systemMetrics = MutableStateFlow(SystemMetrics())
    val systemMetrics: StateFlow<SystemMetrics> = _systemMetrics.asStateFlow()

    private val _healthStatus = MutableStateFlow(diagnosticsEngine.getHealthStatus())
    val healthStatus: StateFlow<HealthStatus> = _healthStatus.asStateFlow()

    // Console logs & Notifications
    private val _consoleLogs = MutableStateFlow<List<String>>(listOf("Universal Application Backend OS initialized", "Connected to local SQLite/Room storage in WAL mode", "SDUI Contract Generator ready on /api/v1/sdui/app"))
    val consoleLogs: StateFlow<List<String>> = _consoleLogs.asStateFlow()

    // API Runner state
    private val _lastApiResponse = MutableStateFlow<ApiResponse<Any>?>(null)
    val lastApiResponse: StateFlow<ApiResponse<Any>?> = _lastApiResponse.asStateFlow()

    // AI Proposal state
    private val _aiSchemaProposal = MutableStateFlow<AISchemaProposal?>(null)
    val aiSchemaProposal: StateFlow<AISchemaProposal?> = _aiSchemaProposal.asStateFlow()

    private val _aiWorkflowProposal = MutableStateFlow<AIWorkflowProposal?>(null)
    val aiWorkflowProposal: StateFlow<AIWorkflowProposal?> = _aiWorkflowProposal.asStateFlow()

    init {
        refreshMetrics()
        loadComponentsForSelectedScreen("screen-dashboard")
    }

    fun selectTab(tab: ConsoleTab) {
        _activeTab.value = tab
    }

    fun selectSchema(schemaId: String?) {
        _selectedSchemaId.value = schemaId
    }

    fun selectScreen(screenId: String?) {
        _selectedScreenId.value = screenId
        screenId?.let { loadComponentsForSelectedScreen(it) }
    }

    fun logConsole(message: String) {
        _consoleLogs.value = listOf("[${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())}] $message") + _consoleLogs.value.take(40)
    }

    fun refreshMetrics() {
        viewModelScope.launch {
            _systemMetrics.value = diagnosticsEngine.getSystemMetrics()
            _healthStatus.value = diagnosticsEngine.getHealthStatus()
        }
    }

    fun loadComponentsForSelectedScreen(screenId: String) {
        viewModelScope.launch {
            val comps = dao.getComponentsByScreenSync(screenId)
            _selectedScreenComponents.value = comps
        }
    }

    // --- Entity & Record Actions ---
    fun saveSchema(schema: EntitySchema) {
        viewModelScope.launch {
            val res = schemaAndRecordEngine.saveSchema(schema, _activeActor.value)
            if (res.isSuccess) {
                logConsole("SUCCESS: Schema '${schema.displayName}' saved (v${res.getOrNull()?.version})")
                _selectedSchemaId.value = schema.id
            } else {
                logConsole("ERROR: Failed to save schema: ${res.exceptionOrNull()?.message}")
            }
            refreshMetrics()
        }
    }

    fun deleteSchema(schemaId: String) {
        viewModelScope.launch {
            val res = schemaAndRecordEngine.deleteSchema(schemaId, _activeTenantId.value, _activeActor.value)
            if (res.isSuccess) {
                logConsole("SUCCESS: Schema $schemaId deleted")
                _selectedSchemaId.value = null
            } else {
                logConsole("ERROR: Failed to delete schema: ${res.exceptionOrNull()?.message}")
            }
            refreshMetrics()
        }
    }

    fun saveRecord(schemaId: String, recordId: String?, values: Map<String, Any?>) {
        viewModelScope.launch {
            val res = schemaAndRecordEngine.saveRecord(schemaId, recordId, values, _activeTenantId.value, _activeActor.value)
            if (res.isSuccess) {
                logConsole("SUCCESS: Record saved in schema $schemaId [ID: ${res.getOrNull()?.id}]")
            } else {
                logConsole("ERROR: Record validation/save failed: ${res.exceptionOrNull()?.message}")
            }
            refreshMetrics()
        }
    }

    fun deleteRecord(recordId: String, schemaId: String) {
        viewModelScope.launch {
            val res = schemaAndRecordEngine.deleteRecord(recordId, schemaId, _activeTenantId.value, _activeActor.value)
            if (res.isSuccess) {
                logConsole("SUCCESS: Record $recordId soft-deleted")
            } else {
                logConsole("ERROR: Failed to delete record: ${res.exceptionOrNull()?.message}")
            }
            refreshMetrics()
        }
    }

    // --- SDUI Actions ---
    fun saveScreen(screen: SDUIScreen) {
        viewModelScope.launch {
            val res = sduiEngine.saveScreen(screen, _activeActor.value)
            if (res.isSuccess) {
                logConsole("SUCCESS: SDUI Screen '${screen.title}' (${screen.slug}) saved v${res.getOrNull()?.version}")
            } else {
                logConsole("ERROR: Failed to save SDUI screen: ${res.exceptionOrNull()?.message}")
            }
            refreshMetrics()
        }
    }

    fun duplicateScreen(screenId: String, newSlug: String, newTitle: String) {
        viewModelScope.launch {
            val res = sduiEngine.duplicateScreen(screenId, newSlug, newTitle, _activeActor.value)
            if (res.isSuccess) {
                logConsole("SUCCESS: Duplicated screen to '$newTitle' ($newSlug)")
                _selectedScreenId.value = res.getOrNull()?.id
            } else {
                logConsole("ERROR: Failed to duplicate screen: ${res.exceptionOrNull()?.message}")
            }
            refreshMetrics()
        }
    }

    fun moveComponent(componentId: String, targetScreenId: String, targetSectionId: String?, newPosition: Int) {
        viewModelScope.launch {
            val res = sduiEngine.moveComponent(componentId, targetScreenId, targetSectionId, newPosition, _activeActor.value)
            if (res.isSuccess) {
                logConsole("SUCCESS: Component $componentId moved to position $newPosition")
                loadComponentsForSelectedScreen(_selectedScreenId.value ?: targetScreenId)
            } else {
                logConsole("ERROR: Failed to move component: ${res.exceptionOrNull()?.message}")
            }
        }
    }

    fun saveComponent(component: SDUIComponent) {
        viewModelScope.launch {
            val res = sduiEngine.saveComponent(component, _activeActor.value)
            if (res.isSuccess) {
                logConsole("SUCCESS: Component '${component.name}' saved")
                loadComponentsForSelectedScreen(component.screenId)
            } else {
                logConsole("ERROR: Failed to save component: ${res.exceptionOrNull()?.message}")
            }
        }
    }

    // --- Workflow Actions ---
    fun executeWorkflow(workflowId: String, parameters: Map<String, Any?>) {
        viewModelScope.launch {
            logConsole("Triggering workflow $workflowId...")
            val exec = workflowEngine.executeWorkflow(workflowId, parameters, triggerSource = "admin_console", actor = _activeActor.value)
            logConsole("Workflow execution finished: Status ${exec.status} [Duration ${exec.executionDurationMs}ms]")
            refreshMetrics()
        }
    }

    fun saveWorkflow(workflow: WorkflowDefinition) {
        viewModelScope.launch {
            val res = workflowEngine.saveWorkflow(workflow, _activeActor.value)
            if (res.isSuccess) {
                logConsole("SUCCESS: Workflow '${workflow.name}' saved")
            } else {
                logConsole("ERROR: Failed to save workflow: ${res.exceptionOrNull()?.message}")
            }
            refreshMetrics()
        }
    }

    // --- Feature Flags & Config ---
    fun saveFeatureFlag(flag: FeatureFlag) {
        viewModelScope.launch {
            val res = featureFlagEngine.saveFeatureFlag(flag, _activeActor.value)
            if (res.isSuccess) {
                logConsole("SUCCESS: Feature Flag '${flag.key}' updated [Enabled: ${flag.isEnabled}, Rollout: ${flag.rolloutPercentage}%]")
            } else {
                logConsole("ERROR: Failed to save feature flag: ${res.exceptionOrNull()?.message}")
            }
        }
    }

    // --- Background Jobs ---
    fun runJob(jobId: String) {
        viewModelScope.launch {
            logConsole("Running background worker job $jobId...")
            val res = jobEngine.runJob(jobId, _activeActor.value)
            if (res.isSuccess) {
                logConsole("Job $jobId completed: ${res.getOrNull()}")
            } else {
                logConsole("ERROR: Job execution failed: ${res.exceptionOrNull()?.message}")
            }
            refreshMetrics()
        }
    }

    // --- API Explorer Dispatcher ---
    fun executeApiRequest(method: String, path: String, headers: Map<String, String>, body: String?) {
        viewModelScope.launch {
            logConsole("API Dispatch: $method $path")
            val req = ApiRequest(
                method = method,
                path = path,
                headers = headers,
                bodyJson = body
            )
            val res = apiRouter.handleRequest(req)
            _lastApiResponse.value = res
            logConsole("API Response: ${res.status} [Success: ${res.success}]")
            refreshMetrics()
        }
    }

    // --- AI Copilot ---
    fun generateAiSchema(prompt: String) {
        val proposal = aiEngine.generateSchemaFromPrompt(prompt, _activeTenantId.value)
        _aiSchemaProposal.value = proposal
        logConsole("AI Copilot synthesized schema proposal for '${proposal.displayName}' (${proposal.suggestedFields.size} fields)")
    }

    fun applyAiSchemaProposal() {
        val p = _aiSchemaProposal.value ?: return
        val schema = EntitySchema(
            tenantId = _activeTenantId.value,
            name = p.entityName,
            displayName = p.displayName,
            description = p.description,
            icon = p.icon,
            fields = p.suggestedFields
        )
        saveSchema(schema)
        _aiSchemaProposal.value = null
    }

    fun generateAiWorkflow(prompt: String) {
        val proposal = aiEngine.generateWorkflowFromPrompt(prompt, _activeTenantId.value)
        _aiWorkflowProposal.value = proposal
        logConsole("AI Copilot synthesized workflow '${proposal.workflowName}' (${proposal.steps.size} steps)")
    }

    fun applyAiWorkflowProposal() {
        val p = _aiWorkflowProposal.value ?: return
        val wf = WorkflowDefinition(
            tenantId = _activeTenantId.value,
            name = p.workflowName,
            description = p.description,
            triggerType = p.triggerType,
            triggerEntityId = p.triggerEntityName,
            steps = p.steps
        )
        saveWorkflow(wf)
        _aiWorkflowProposal.value = null
    }

    // --- IAM & API Key Actions ---
    fun generateApiKey(name: String, rateLimit: Int) {
        viewModelScope.launch {
            val res = authEngine.generateApiKey(_activeTenantId.value, name, "role-super-admin", rateLimit, _activeActor.value)
            if (res.isSuccess) {
                logConsole("SUCCESS: Generated API Key '$name'")
            } else {
                logConsole("ERROR: Failed to generate API key: ${res.exceptionOrNull()?.message}")
            }
        }
    }

    // --- Snapshots & Domain Templates ---
    fun loadDomainTemplate(templateName: String) {
        viewModelScope.launch {
            logConsole("Loading domain template '$templateName'...")
            val res = exportImportEngine.loadDomainTemplate(templateName, _activeTenantId.value, _activeActor.value)
            if (res.isSuccess) {
                logConsole("SUCCESS: ${res.getOrNull()}")
            } else {
                logConsole("ERROR: Failed to load domain template: ${res.exceptionOrNull()?.message}")
            }
            refreshMetrics()
        }
    }
}
