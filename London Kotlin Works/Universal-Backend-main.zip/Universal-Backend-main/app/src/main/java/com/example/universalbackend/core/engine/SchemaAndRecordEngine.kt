package com.example.universalbackend.core.engine

import com.example.universalbackend.core.db.RecordEntity
import com.example.universalbackend.core.db.SchemaEntity
import com.example.universalbackend.core.db.UniversalDao
import com.example.universalbackend.core.model.AuditActionType
import com.example.universalbackend.core.model.DynamicRecord
import com.example.universalbackend.core.model.EntitySchema
import com.example.universalbackend.core.model.FieldDefinition
import com.example.universalbackend.core.model.FieldType
import com.example.universalbackend.core.model.ValidationType
import java.util.UUID

class SchemaAndRecordEngine(
    private val dao: UniversalDao,
    private val eventBus: EventBus,
    private val auditLogger: AuditLogger
) {

    // --- Schema Operations ---
    suspend fun saveSchema(schema: EntitySchema, actor: String): Result<EntitySchema> {
        return try {
            // Validate schema definition
            if (schema.name.isBlank()) {
                return Result.failure(IllegalArgumentException("Schema name cannot be blank"))
            }
            val existing = dao.getSchemaByName(schema.tenantId, schema.name)
            val isNew = existing == null || existing.id != schema.id
            val version = if (isNew) 1 else (existing?.version ?: 0) + 1

            val updatedSchema = schema.copy(
                version = version,
                updatedAt = System.currentTimeMillis()
            )

            val entity = SchemaEntity(
                id = updatedSchema.id,
                tenantId = updatedSchema.tenantId,
                name = updatedSchema.name.trim().lowercase(),
                displayName = updatedSchema.displayName.ifBlank { updatedSchema.name },
                description = updatedSchema.description,
                icon = updatedSchema.icon,
                version = updatedSchema.version,
                isSystem = updatedSchema.isSystem,
                isAudited = updatedSchema.isAudited,
                isSoftDeleteEnabled = updatedSchema.isSoftDeleteEnabled,
                fieldsJson = JsonCodec.fieldsToJson(updatedSchema.fields),
                primaryField = updatedSchema.primaryField,
                titleField = updatedSchema.titleField,
                createdAt = updatedSchema.createdAt,
                updatedAt = updatedSchema.updatedAt
            )
            dao.insertSchema(entity)

            auditLogger.log(
                tenantId = schema.tenantId,
                actor = actor,
                action = if (isNew) AuditActionType.CREATE else AuditActionType.UPDATE,
                targetType = "EntitySchema",
                targetId = schema.id,
                details = "Saved schema '${schema.name}' with ${schema.fields.size} fields (v${version})"
            )

            eventBus.emit(
                tenantId = schema.tenantId,
                topic = "schema.saved",
                payload = mapOf("schemaId" to schema.id, "name" to schema.name, "version" to version)
            )

            Result.success(updatedSchema)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteSchema(schemaId: String, tenantId: String, actor: String): Result<Boolean> {
        return try {
            val schema = dao.getSchemaById(schemaId) ?: return Result.failure(NoSuchElementException("Schema not found"))
            if (schema.isSystem) {
                return Result.failure(IllegalStateException("System schemas cannot be deleted"))
            }
            dao.deleteSchemaById(schemaId)
            auditLogger.log(
                tenantId = tenantId,
                actor = actor,
                action = AuditActionType.DELETE,
                targetType = "EntitySchema",
                targetId = schemaId,
                details = "Deleted schema '${schema.name}'"
            )
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- Record Operations ---

    fun validateRecord(schema: EntitySchema, values: Map<String, Any?>): List<String> {
        val errors = mutableListOf<String>()
        for (field in schema.fields) {
            val value = values[field.name]

            // 1. Required check
            if (field.isRequired && (value == null || (value is String && value.isBlank()))) {
                errors.add("Field '${field.displayName}' is required")
                continue
            }

            if (value == null) continue

            // 2. Type & Format checks
            when (field.type) {
                FieldType.EMAIL -> {
                    val str = value.toString().trim()
                    if (!str.matches(Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$"))) {
                        errors.add("Field '${field.displayName}' must be a valid email address")
                    }
                }
                FieldType.INTEGER -> {
                    if (value !is Number && value.toString().toIntOrNull() == null) {
                        errors.add("Field '${field.displayName}' must be a valid integer")
                    }
                }
                FieldType.DECIMAL, FieldType.CURRENCY, FieldType.PERCENTAGE -> {
                    if (value !is Number && value.toString().toDoubleOrNull() == null) {
                        errors.add("Field '${field.displayName}' must be a valid number")
                    }
                }
                FieldType.ENUM_TYPE -> {
                    if (field.enumValues.isNotEmpty() && !field.enumValues.contains(value.toString())) {
                        errors.add("Field '${field.displayName}' value '$value' must be one of: ${field.enumValues.joinToString(", ")}")
                    }
                }
                else -> {}
            }

            // 3. Custom Validation Rules
            for (rule in field.validationRules) {
                when (rule.type) {
                    ValidationType.MIN_LENGTH -> {
                        val min = rule.value.toIntOrNull() ?: 0
                        if (value.toString().length < min) {
                            errors.add(rule.errorMessage.ifBlank { "'${field.displayName}' must be at least $min chars" })
                        }
                    }
                    ValidationType.MAX_LENGTH -> {
                        val max = rule.value.toIntOrNull() ?: Int.MAX_VALUE
                        if (value.toString().length > max) {
                            errors.add(rule.errorMessage.ifBlank { "'${field.displayName}' cannot exceed $max chars" })
                        }
                    }
                    ValidationType.MIN_VALUE -> {
                        val min = rule.value.toDoubleOrNull() ?: Double.MIN_VALUE
                        val num = value.toString().toDoubleOrNull() ?: 0.0
                        if (num < min) {
                            errors.add(rule.errorMessage.ifBlank { "'${field.displayName}' must be >= $min" })
                        }
                    }
                    ValidationType.MAX_VALUE -> {
                        val max = rule.value.toDoubleOrNull() ?: Double.MAX_VALUE
                        val num = value.toString().toDoubleOrNull() ?: 0.0
                        if (num > max) {
                            errors.add(rule.errorMessage.ifBlank { "'${field.displayName}' must be <= $max" })
                        }
                    }
                    ValidationType.REGEX_PATTERN -> {
                        if (!value.toString().matches(Regex(rule.value))) {
                            errors.add(rule.errorMessage.ifBlank { "'${field.displayName}' does not match pattern" })
                        }
                    }
                    else -> {}
                }
            }
        }
        return errors
    }

    fun computeFormulas(schema: EntitySchema, values: Map<String, Any?>): Map<String, Any?> {
        val result = values.toMutableMap()
        for (field in schema.fields) {
            if (field.type == FieldType.COMPUTED_FORMULA && !field.formula.isNullOrBlank()) {
                val computed = evaluateFormula(field.formula, result)
                result[field.name] = computed
            }
        }
        return result
    }

    private fun evaluateFormula(formula: String, values: Map<String, Any?>): Any {
        try {
            // Formula evaluator: basic multiplication, addition, concatenation
            // e.g. "price * quantity" or "CONCAT(firstName, ' ', lastName)"
            if (formula.startsWith("CONCAT(") && formula.endsWith(")")) {
                val inner = formula.substring(7, formula.length - 1)
                val parts = inner.split(",")
                val sb = StringBuilder()
                for (p in parts) {
                    val trimmed = p.trim()
                    if (trimmed.startsWith("'") && trimmed.endsWith("'")) {
                        sb.append(trimmed.substring(1, trimmed.length - 1))
                    } else {
                        sb.append(values[trimmed]?.toString() ?: "")
                    }
                }
                return sb.toString()
            } else if (formula.contains("*")) {
                val parts = formula.split("*")
                var prod = 1.0
                for (p in parts) {
                    val trimmed = p.trim()
                    val v = (values[trimmed]?.toString()?.toDoubleOrNull()) ?: (trimmed.toDoubleOrNull() ?: 1.0)
                    prod *= v
                }
                return String.format("%.2f", prod).toDoubleOrNull() ?: prod
            } else if (formula.contains("+")) {
                val parts = formula.split("+")
                var sum = 0.0
                for (p in parts) {
                    val trimmed = p.trim()
                    val v = (values[trimmed]?.toString()?.toDoubleOrNull()) ?: (trimmed.toDoubleOrNull() ?: 0.0)
                    sum += v
                }
                return String.format("%.2f", sum).toDoubleOrNull() ?: sum
            }
        } catch (e: Exception) {
            // fallback
        }
        return "N/A"
    }

    suspend fun saveRecord(
        schemaId: String,
        recordId: String?,
        values: Map<String, Any?>,
        tenantId: String,
        actor: String
    ): Result<DynamicRecord> {
        return try {
            val schemaEntity = dao.getSchemaById(schemaId) ?: return Result.failure(NoSuchElementException("Schema not found"))
            val schema = EntitySchema(
                id = schemaEntity.id,
                tenantId = schemaEntity.tenantId,
                name = schemaEntity.name,
                displayName = schemaEntity.displayName,
                description = schemaEntity.description,
                icon = schemaEntity.icon,
                version = schemaEntity.version,
                isSystem = schemaEntity.isSystem,
                isAudited = schemaEntity.isAudited,
                isSoftDeleteEnabled = schemaEntity.isSoftDeleteEnabled,
                fields = JsonCodec.jsonToFields(schemaEntity.fieldsJson),
                primaryField = schemaEntity.primaryField,
                titleField = schemaEntity.titleField,
                createdAt = schemaEntity.createdAt,
                updatedAt = schemaEntity.updatedAt
            )

            // Validate
            val errors = validateRecord(schema, values)
            if (errors.isNotEmpty()) {
                return Result.failure(IllegalArgumentException("Validation errors: ${errors.joinToString("; ")}"))
            }

            // Compute formulas
            val processedValues = computeFormulas(schema, values)
            val now = System.currentTimeMillis()

            val isNew = recordId == null || recordId.isBlank()
            val finalId = if (isNew) UUID.randomUUID().toString() else recordId!!
            val existing = if (!isNew) dao.getRecordById(finalId) else null
            val version = if (existing != null) existing.version + 1 else 1

            val recordEntity = RecordEntity(
                id = finalId,
                tenantId = tenantId,
                schemaId = schemaId,
                version = version,
                valuesJson = JsonCodec.valuesToJson(processedValues),
                isDeleted = false,
                createdAt = existing?.createdAt ?: now,
                updatedAt = now,
                createdBy = existing?.createdBy ?: actor,
                updatedBy = actor
            )
            dao.insertRecord(recordEntity)

            if (schema.isAudited) {
                auditLogger.log(
                    tenantId = tenantId,
                    actor = actor,
                    action = if (isNew) AuditActionType.CREATE else AuditActionType.UPDATE,
                    targetType = "DynamicRecord:${schema.name}",
                    targetId = finalId,
                    details = "${if (isNew) "Created" else "Updated"} record in '${schema.name}' (v$version)"
                )
            }

            eventBus.emit(
                tenantId = tenantId,
                topic = if (isNew) "record.created" else "record.updated",
                payload = mapOf(
                    "schemaId" to schemaId,
                    "schemaName" to schema.name,
                    "recordId" to finalId,
                    "actor" to actor,
                    "values" to processedValues
                )
            )

            val record = DynamicRecord(
                id = finalId,
                tenantId = tenantId,
                schemaId = schemaId,
                version = version,
                values = processedValues,
                isDeleted = false,
                createdAt = recordEntity.createdAt,
                updatedAt = recordEntity.updatedAt,
                createdBy = recordEntity.createdBy,
                updatedBy = recordEntity.updatedBy
            )
            Result.success(record)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteRecord(recordId: String, schemaId: String, tenantId: String, actor: String, hardDelete: Boolean = false): Result<Boolean> {
        return try {
            val record = dao.getRecordById(recordId) ?: return Result.failure(NoSuchElementException("Record not found"))
            val schema = dao.getSchemaById(schemaId)
            val now = System.currentTimeMillis()

            if (hardDelete || (schema?.isSoftDeleteEnabled == false)) {
                dao.hardDeleteRecord(recordId)
            } else {
                dao.softDeleteRecord(recordId, now)
            }

            auditLogger.log(
                tenantId = tenantId,
                actor = actor,
                action = AuditActionType.DELETE,
                targetType = "DynamicRecord:${schema?.name ?: "unknown"}",
                targetId = recordId,
                details = "Deleted record $recordId"
            )

            eventBus.emit(
                tenantId = tenantId,
                topic = "record.deleted",
                payload = mapOf("recordId" to recordId, "schemaId" to schemaId)
            )

            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- Aggregation & Analytics Engine ---
    suspend fun calculateAggregations(schemaId: String, fieldName: String): Map<String, Double> {
        val records = dao.getRecordsBySchemaSync(schemaId)
        var count = 0
        var sum = 0.0
        var min = Double.MAX_VALUE
        var max = Double.MIN_VALUE

        for (r in records) {
            val values = JsonCodec.jsonToValues(r.valuesJson)
            val v = values[fieldName]?.toString()?.toDoubleOrNull()
            if (v != null) {
                count++
                sum += v
                if (v < min) min = v
                if (v > max) max = v
            }
        }

        val avg = if (count > 0) sum / count else 0.0
        return mapOf(
            "count" to count.toDouble(),
            "sum" to sum,
            "avg" to avg,
            "min" to if (count > 0) min else 0.0,
            "max" to if (count > 0) max else 0.0
        )
    }
}
