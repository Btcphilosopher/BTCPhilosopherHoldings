package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// High Density Theme Palette (Developer Console & Data Platform)
val BrandIndigo = Color(0xFF4F46E5)
val BrandIndigoDark = Color(0xFF3730A3)
val BrandIndigoLight = Color(0xFFEEF2FF)
val BrandBlue = Color(0xFF2563EB)
val BrandCyan = Color(0xFF0284C7)
val BrandEmerald = Color(0xFF059669)
val BrandAmber = Color(0xFFD97706)
val BrandRose = Color(0xFFE11D48)
val BrandPurple = Color(0xFF7C3AED)

// High Density Light Palette
val BackgroundLight = Color(0xFFF6F8FA)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF0F3F6)
val SurfaceCardLight = Color(0xFFFFFFFF)
val BorderLight = Color(0xFFD0D7DE)
val BorderLightSubtle = Color(0xFFE1E4E8)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
val TextMutedLight = Color(0xFF64748B)

// High Density Dark Palette
val BackgroundDark = Color(0xFF0D1117)
val SurfaceDark = Color(0xFF161B22)
val SurfaceVariantDark = Color(0xFF21262D)
val SurfaceCardDark = Color(0xFF161B22)
val BorderDark = Color(0xFF30363D)
val BorderDarkSubtle = Color(0xFF21262D)
val TextPrimaryDark = Color(0xFFF0F6FC)
val TextSecondaryDark = Color(0xFF8B949E)
val TextMutedDark = Color(0xFF6E7681)

// Common Card alias
val SurfaceCard = SurfaceCardLight

