package com.example.universalbackend.ui.console

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BrandAmber
import com.example.ui.theme.BrandCyan
import com.example.ui.theme.BrandEmerald
import com.example.ui.theme.BrandIndigo
import com.example.ui.theme.BrandPurple
import com.example.ui.theme.BrandRose
import com.example.universalbackend.core.engine.JsonCodec
import com.example.universalbackend.core.model.EntitySchema
import com.example.universalbackend.core.model.FieldDefinition
import com.example.universalbackend.core.model.FieldType
import com.example.universalbackend.core.model.ValidationRule
import com.example.universalbackend.core.model.ValidationType
import com.example.universalbackend.ui.UniversalPlatformViewModel
import java.util.UUID

@Composable
fun EntityStudioScreen(
    viewModel: UniversalPlatformViewModel,
    modifier: Modifier = Modifier
) {
    val schemas by viewModel.schemas.collectAsState()
    val selectedSchemaId by viewModel.selectedSchemaId.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var showCreateSchemaDialog by remember { mutableStateOf(false) }
    var showAddFieldDialog by remember { mutableStateOf(false) }
    var showAddRecordDialog by remember { mutableStateOf(false) }

    val currentSchemaEntity = schemas.find { it.id == selectedSchemaId } ?: schemas.firstOrNull()
    val fields = remember(currentSchemaEntity) {
        currentSchemaEntity?.let { JsonCodec.jsonToFields(it.fieldsJson) } ?: emptyList()
    }

    // Records flow for selected schema
    val recordsFlow = remember(currentSchemaEntity?.id) {
        currentSchemaEntity?.id?.let { viewModel.dao.getRecordsBySchema(it) }
    }
    val records by (recordsFlow?.collectAsState(initial = emptyList()) ?: remember { mutableStateOf(emptyList()) })

    val filteredRecords = records.filter { record ->
        if (searchQuery.isBlank()) true
        else record.valuesJson.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        // 1. Header & Schema Selector
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Entity & Document Studio",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Dynamic schema mutations & polymorphous data layer",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Button(
                onClick = { showCreateSchemaDialog = true },
                shape = RoundedCornerShape(6.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrandIndigo),
                modifier = Modifier.testTag("create_schema_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("New Entity", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 2. Schema Tabs
        if (schemas.isNotEmpty()) {
            ScrollableTabRow(
                selectedTabIndex = schemas.indexOfFirst { it.id == currentSchemaEntity?.id }.coerceAtLeast(0),
                edgePadding = 0.dp,
                containerColor = Color.Transparent,
                divider = {}
            ) {
                schemas.forEach { schema ->
                    val isSelected = schema.id == currentSchemaEntity?.id
                    Tab(
                        selected = isSelected,
                        onClick = { viewModel.selectSchema(schema.id) },
                        text = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Icon(
                                    Icons.Default.Storage,
                                    contentDescription = null,
                                    modifier = Modifier.size(13.dp),
                                    tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = schema.displayName,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 3. Schema Metadata & Field Inspector Bar
        currentSchemaEntity?.let { schemaEntity ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(6.dp)),
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${schemaEntity.name} (v${schemaEntity.version})",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "• ${fields.size} fields",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Row {
                            OutlinedButton(
                                onClick = { showAddFieldDialog = true },
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.testTag("add_field_button")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("Add Field", fontSize = 10.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Field Pills
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(fields) { f ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = f.displayName,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = "[${f.type.name}]",
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    if (f.isRequired) {
                                        Spacer(modifier = Modifier.width(2.dp))
                                        Text("*", color = BrandRose, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 4. Record Controls (Search, Add Record)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Filter records...", fontSize = 11.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(14.dp)) },
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 6.dp),
                shape = RoundedCornerShape(6.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                )
            )

            Button(
                onClick = { showAddRecordDialog = true },
                shape = RoundedCornerShape(6.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrandEmerald),
                modifier = Modifier.testTag("add_record_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Insert Record", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 5. Records Data Grid
        if (filteredRecords.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Layers, contentDescription = null, modifier = Modifier.size(32.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("No records found in this entity", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(filteredRecords) { record ->
                    val values = remember(record.valuesJson) { JsonCodec.jsonToValues(record.valuesJson) }
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(6.dp)),
                        shape = RoundedCornerShape(6.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "ID: ${record.id.take(8)}...",
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "v${record.version}",
                                        fontSize = 9.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                IconButton(
                                    onClick = { currentSchemaEntity?.let { viewModel.deleteRecord(record.id, it.id) } },
                                    modifier = Modifier.size(20.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = BrandRose, modifier = Modifier.size(14.dp))
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            // Key Values row
                            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                fields.take(4).forEach { field ->
                                    val v = values[field.name]?.toString() ?: "—"
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = field.displayName,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = if (field.type == FieldType.CURRENCY) "$$v" else v,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // --- Create Schema Dialog ---
    if (showCreateSchemaDialog) {
        CreateSchemaModal(
            onDismiss = { showCreateSchemaDialog = false },
            onConfirm = { name, displayName, desc ->
                val newSchema = EntitySchema(
                    tenantId = viewModel.activeTenantId.value,
                    name = name,
                    displayName = displayName,
                    description = desc,
                    fields = listOf(
                        FieldDefinition(name = "name", displayName = "Name", type = FieldType.STRING, isRequired = true),
                        FieldDefinition(name = "status", displayName = "Status", type = FieldType.ENUM_TYPE, enumValues = listOf("DRAFT", "ACTIVE", "ARCHIVED")),
                        FieldDefinition(name = "isPublished", displayName = "Published", type = FieldType.BOOLEAN, defaultValue = "true")
                    )
                )
                viewModel.saveSchema(newSchema)
                showCreateSchemaDialog = false
            }
        )
    }

    // --- Add Field Dialog ---
    if (showAddFieldDialog && currentSchemaEntity != null) {
        AddFieldModal(
            onDismiss = { showAddFieldDialog = false },
            onConfirm = { newField ->
                val updatedFields = fields + newField
                val updatedSchema = EntitySchema(
                    id = currentSchemaEntity.id,
                    tenantId = currentSchemaEntity.tenantId,
                    name = currentSchemaEntity.name,
                    displayName = currentSchemaEntity.displayName,
                    description = currentSchemaEntity.description,
                    icon = currentSchemaEntity.icon,
                    fields = updatedFields
                )
                viewModel.saveSchema(updatedSchema)
                showAddFieldDialog = false
            }
        )
    }

    // --- Add Record Dialog ---
    if (showAddRecordDialog && currentSchemaEntity != null) {
        AddRecordModal(
            schemaFields = fields,
            onDismiss = { showAddRecordDialog = false },
            onConfirm = { values ->
                viewModel.saveRecord(currentSchemaEntity.id, null, values)
                showAddRecordDialog = false
            }
        )
    }
}

@Composable
fun CreateSchemaModal(
    onDismiss: () -> Unit,
    onConfirm: (name: String, displayName: String, desc: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Entity Schema", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("System Name (e.g. invoices)", fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = displayName,
                    onValueChange = { displayName = it },
                    label = { Text("Display Name (e.g. Billing Invoices)", fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("Description", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { if (name.isNotBlank()) onConfirm(name, displayName.ifBlank { name }, desc) },
                shape = RoundedCornerShape(6.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrandIndigo)
            ) {
                Text("Create Schema", fontSize = 11.sp)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", fontSize = 11.sp) }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddFieldModal(
    onDismiss: () -> Unit,
    onConfirm: (FieldDefinition) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(FieldType.STRING) }
    var isRequired by remember { mutableStateOf(false) }
    var expandedType by remember { mutableStateOf(false) }

    val fieldTypes = listOf(
        FieldType.STRING, FieldType.INTEGER, FieldType.DECIMAL,
        FieldType.CURRENCY, FieldType.BOOLEAN, FieldType.ENUM_TYPE,
        FieldType.DATE, FieldType.EMAIL, FieldType.PHONE, FieldType.COMPUTED_FORMULA
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Schema Field", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Field Key (e.g. discountCode)", fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = displayName,
                    onValueChange = { displayName = it },
                    label = { Text("Display Label", fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                ExposedDropdownMenuBox(
                    expanded = expandedType,
                    onExpandedChange = { expandedType = !expandedType }
                ) {
                    OutlinedTextField(
                        value = selectedType.name,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Data Type", fontSize = 11.sp) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedType) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = expandedType,
                        onDismissRequest = { expandedType = false }
                    ) {
                        fieldTypes.forEach { t ->
                            DropdownMenuItem(
                                text = { Text(t.name, fontSize = 11.sp) },
                                onClick = {
                                    selectedType = t
                                    expandedType = false
                                }
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isRequired, onCheckedChange = { isRequired = it })
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Is Required Field", fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onConfirm(
                            FieldDefinition(
                                name = name.trim(),
                                displayName = displayName.ifBlank { name },
                                type = selectedType,
                                isRequired = isRequired
                            )
                        )
                    }
                },
                shape = RoundedCornerShape(6.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrandIndigo)
            ) {
                Text("Add Field", fontSize = 11.sp)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", fontSize = 11.sp) }
        }
    )
}

@Composable
fun AddRecordModal(
    schemaFields: List<FieldDefinition>,
    onDismiss: () -> Unit,
    onConfirm: (Map<String, Any?>) -> Unit
) {
    val formValues = remember { mutableStateMapOf<String, String>() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Insert Record", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(
                modifier = Modifier.height(300.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(schemaFields) { field ->
                    OutlinedTextField(
                        value = formValues[field.name] ?: field.defaultValue ?: "",
                        onValueChange = { formValues[field.name] = it },
                        label = { Text("${field.displayName} ${if (field.isRequired) "*" else ""}", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = field.type != FieldType.TEXT
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val map = formValues.toMap().mapValues { (k, v) ->
                        val field = schemaFields.find { it.name == k }
                        when (field?.type) {
                            FieldType.INTEGER -> v.toIntOrNull() ?: v
                            FieldType.DECIMAL, FieldType.CURRENCY -> v.toDoubleOrNull() ?: v
                            FieldType.BOOLEAN -> v.toBooleanStrictOrNull() ?: true
                            else -> v
                        }
                    }
                    onConfirm(map)
                },
                shape = RoundedCornerShape(6.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrandEmerald)
            ) {
                Text("Save Record", fontSize = 11.sp)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", fontSize = 11.sp) }
        }
    )
}

