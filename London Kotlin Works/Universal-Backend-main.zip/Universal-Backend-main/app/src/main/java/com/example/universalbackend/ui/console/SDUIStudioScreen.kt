package com.example.universalbackend.ui.console

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.ViewQuilt
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BrandAmber
import com.example.ui.theme.BrandCyan
import com.example.ui.theme.BrandEmerald
import com.example.ui.theme.BrandIndigo
import com.example.ui.theme.BrandPurple
import com.example.ui.theme.BrandRose
import com.example.universalbackend.core.engine.JsonCodec
import com.example.universalbackend.core.model.SDUIComponent
import com.example.universalbackend.core.model.SDUIComponentType
import com.example.universalbackend.core.model.SDUIScreen
import com.example.universalbackend.core.model.SDUISection
import com.example.universalbackend.ui.UniversalPlatformViewModel
import java.util.UUID

@Composable
fun SDUIStudioScreen(
    viewModel: UniversalPlatformViewModel,
    modifier: Modifier = Modifier
) {
    val screens by viewModel.screens.collectAsState()
    val selectedScreenId by viewModel.selectedScreenId.collectAsState()
    val components by viewModel.selectedScreenComponents.collectAsState()

    var viewModeTab by remember { mutableIntStateOf(0) } // 0: Tree/Editor, 1: Live SDUI Preview, 2: JSON Contract
    var showDuplicateModal by remember { mutableStateOf(false) }
    var showAddComponentModal by remember { mutableStateOf(false) }

    val currentScreen = screens.find { it.id == selectedScreenId } ?: screens.firstOrNull()
    val sections = remember(currentScreen) {
        currentScreen?.let { JsonCodec.jsonToSections(it.sectionsJson) } ?: emptyList()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        // 1. Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Server-Driven UI Studio (SDUI)",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Backend layout, navigation & component composition engine",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(
                    onClick = { showDuplicateModal = true },
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.testTag("duplicate_screen_button")
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("Duplicate", fontSize = 11.sp)
                }

                Button(
                    onClick = { showAddComponentModal = true },
                    shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandIndigo),
                    modifier = Modifier.testTag("add_component_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("Add Comp", fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 2. Screen Selector Tabs
        if (screens.isNotEmpty()) {
            ScrollableTabRow(
                selectedTabIndex = screens.indexOfFirst { it.id == currentScreen?.id }.coerceAtLeast(0),
                edgePadding = 0.dp,
                containerColor = Color.Transparent,
                divider = {}
            ) {
                screens.forEach { screen ->
                    val isSelected = screen.id == currentScreen?.id
                    Tab(
                        selected = isSelected,
                        onClick = { viewModel.selectScreen(screen.id) },
                        text = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Icon(
                                    Icons.Default.Devices,
                                    contentDescription = null,
                                    modifier = Modifier.size(13.dp),
                                    tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = screen.title,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 3. View Mode Switcher: Editor | Live Preview | JSON Contract
        TabRow(
            selectedTabIndex = viewModeTab,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = MaterialTheme.colorScheme.primary,
            modifier = Modifier.clip(RoundedCornerShape(6.dp)),
            divider = {}
        ) {
            Tab(
                selected = viewModeTab == 0,
                onClick = { viewModeTab = 0 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ViewQuilt, contentDescription = null, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Hierarchy", fontSize = 11.sp, fontWeight = if (viewModeTab == 0) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            )
            Tab(
                selected = viewModeTab == 1,
                onClick = { viewModeTab = 1 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Live Preview", fontSize = 11.sp, fontWeight = if (viewModeTab == 1) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            )
            Tab(
                selected = viewModeTab == 2,
                onClick = { viewModeTab = 2 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("JSON Contract", fontSize = 11.sp, fontWeight = if (viewModeTab == 2) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 4. Main Body Content
        when (viewModeTab) {
            0 -> {
                // Component Tree & Position Reorder Editor
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(6.dp)),
                            shape = RoundedCornerShape(6.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "Route Slug: ${currentScreen?.slug ?: "/"}",
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "${sections.size} sections • ${components.size} components",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("v${currentScreen?.version ?: 1}", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    if (components.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("No components placed in this screen yet. Click 'Add Comp' above.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    } else {
                        items(components.sortedBy { it.position }) { comp ->
                            val config = remember(comp.configJson) { JsonCodec.jsonToStringMap(comp.configJson) }
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(6.dp)),
                                shape = RoundedCornerShape(6.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(24.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(MaterialTheme.colorScheme.surfaceVariant),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text("${comp.position}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                text = comp.name,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = comp.type.name,
                                                    fontSize = 9.sp,
                                                    fontFamily = FontFamily.Monospace,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                                if (comp.dataBinding != null) {
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text(
                                                        text = "-> ${comp.dataBinding}",
                                                        fontSize = 9.sp,
                                                        fontFamily = FontFamily.Monospace,
                                                        color = BrandAmber
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    // Position Controls
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(
                                            onClick = {
                                                currentScreen?.let { s ->
                                                    viewModel.moveComponent(comp.id, s.id, comp.sectionId, (comp.position - 1).coerceAtLeast(0))
                                                }
                                            },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Default.ArrowUpward, contentDescription = "Move Up", modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        IconButton(
                                            onClick = {
                                                currentScreen?.let { s ->
                                                    viewModel.moveComponent(comp.id, s.id, comp.sectionId, comp.position + 1)
                                                }
                                            },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Default.ArrowDownward, contentDescription = "Move Down", modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                // Live SDUI Simulated Rendering
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Text(
                            text = "SIMULATED VIEW: ${currentScreen?.title ?: "Screen"}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrandEmerald,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    items(components.sortedBy { it.position }) { comp ->
                        val config = remember(comp.configJson) { JsonCodec.jsonToStringMap(comp.configJson) }
                        when (comp.type) {
                            SDUIComponentType.METRIC_CARD -> {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(6.dp)),
                                    shape = RoundedCornerShape(6.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(text = comp.name, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(text = comp.title ?: comp.name, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                                        config["trend"]?.let {
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(text = it, fontSize = 10.sp, color = BrandEmerald)
                                        }
                                    }
                                }
                            }
                            SDUIComponentType.BUTTON -> {
                                Button(
                                    onClick = {},
                                    shape = RoundedCornerShape(6.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = BrandIndigo),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(comp.title ?: comp.name, fontSize = 12.sp)
                                }
                            }
                            SDUIComponentType.INPUT_FIELD -> {
                                OutlinedTextField(
                                    value = "",
                                    onValueChange = {},
                                    placeholder = { Text(config["placeholder"] ?: (comp.title ?: comp.name), fontSize = 11.sp) },
                                    label = { Text(comp.title ?: comp.name, fontSize = 11.sp) },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(6.dp),
                                    enabled = false
                                )
                            }
                            else -> {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(6.dp)),
                                    shape = RoundedCornerShape(6.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(comp.name, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                                        Text("[${comp.type.name}]", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, fontFamily = FontFamily.Monospace)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            2 -> {
                // Raw JSON Contract Display (GET /api/v1/sdui/app)
                val contractJson = remember(currentScreen, components) {
                    """{
  "screenId": "${currentScreen?.id ?: ""}",
  "slug": "${currentScreen?.slug ?: "/"}",
  "title": "${currentScreen?.title ?: ""}",
  "version": ${currentScreen?.version ?: 1},
  "componentsCount": ${components.size},
  "sections": ${currentScreen?.sectionsJson ?: "[]"},
  "endpoint": "GET /api/v1/sdui/screens/${currentScreen?.id ?: ""}"
}"""
                }

                Card(
                    modifier = Modifier
                        .weight(1f)
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(6.dp)),
                    shape = RoundedCornerShape(6.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    LazyColumn(modifier = Modifier.padding(10.dp)) {
                        item {
                            Text(
                                text = contractJson,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }

    // Duplicate Screen Dialog
    if (showDuplicateModal && currentScreen != null) {
        DuplicateScreenModal(
            originalTitle = currentScreen.title,
            originalSlug = currentScreen.slug,
            onDismiss = { showDuplicateModal = false },
            onConfirm = { slug, title ->
                viewModel.duplicateScreen(currentScreen.id, slug, title)
                showDuplicateModal = false
            }
        )
    }

    // Add Component Dialog
    if (showAddComponentModal && currentScreen != null) {
        AddComponentModal(
            screenId = currentScreen.id,
            onDismiss = { showAddComponentModal = false },
            onConfirm = { comp ->
                viewModel.saveComponent(comp)
                showAddComponentModal = false
            }
        )
    }
}

@Composable
fun DuplicateScreenModal(
    originalTitle: String,
    originalSlug: String,
    onDismiss: () -> Unit,
    onConfirm: (slug: String, title: String) -> Unit
) {
    var title by remember { mutableStateOf("$originalTitle (Copy)") }
    var slug by remember { mutableStateOf("$originalSlug-copy") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Duplicate SDUI Screen", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("New Screen Title", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = slug,
                    onValueChange = { slug = it },
                    label = { Text("New Slug Route (e.g. /analytics)", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { if (slug.isNotBlank()) onConfirm(slug, title) },
                shape = RoundedCornerShape(6.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrandIndigo)
            ) {
                Text("Duplicate", fontSize = 11.sp)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", fontSize = 11.sp) }
        }
    )
}

@Composable
fun AddComponentModal(
    screenId: String,
    onDismiss: () -> Unit,
    onConfirm: (SDUIComponent) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(SDUIComponentType.METRIC_CARD) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add SDUI Component", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Component Identifier", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Display Value / Text", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onConfirm(
                            SDUIComponent(
                                id = UUID.randomUUID().toString(),
                                screenId = screenId,
                                type = selectedType,
                                name = name,
                                title = title,
                                position = 99,
                                isVisible = true
                            )
                        )
                    }
                },
                shape = RoundedCornerShape(6.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrandIndigo)
            ) {
                Text("Add", fontSize = 11.sp)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", fontSize = 11.sp) }
        }
    )
}

