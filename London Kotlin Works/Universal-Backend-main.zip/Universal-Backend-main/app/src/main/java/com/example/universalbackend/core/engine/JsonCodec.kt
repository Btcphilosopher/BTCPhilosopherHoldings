package com.example.universalbackend.core.engine

import com.example.universalbackend.core.model.FieldDefinition
import com.example.universalbackend.core.model.FieldType
import com.example.universalbackend.core.model.RelationshipType
import com.example.universalbackend.core.model.SDUIAction
import com.example.universalbackend.core.model.SDUIActionType
import com.example.universalbackend.core.model.SDUIComponentType
import com.example.universalbackend.core.model.SDUINavItem
import com.example.universalbackend.core.model.SDUISection
import com.example.universalbackend.core.model.ValidationRule
import com.example.universalbackend.core.model.ValidationType
import com.example.universalbackend.core.model.WorkflowActionType
import com.example.universalbackend.core.model.WorkflowCondition
import com.example.universalbackend.core.model.WorkflowStep
import com.example.universalbackend.core.model.WorkflowStepLog
import org.json.JSONArray
import org.json.JSONObject

object JsonCodec {

    // --- Dynamic Values Map ---
    fun valuesToJson(values: Map<String, Any?>): String {
        val json = JSONObject()
        for ((key, value) in values) {
            when (value) {
                null -> json.put(key, JSONObject.NULL)
                is Number, is Boolean, is String -> json.put(key, value)
                is List<*> -> json.put(key, JSONArray(value))
                is Map<*, *> -> json.put(key, JSONObject(value))
                else -> json.put(key, value.toString())
            }
        }
        return json.toString()
    }

    fun jsonToValues(jsonStr: String): Map<String, Any?> {
        if (jsonStr.isBlank() || jsonStr == "{}") return emptyMap()
        val result = mutableMapOf<String, Any?>()
        try {
            val json = JSONObject(jsonStr)
            val keys = json.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val value = json.get(key)
                if (value == JSONObject.NULL) {
                    result[key] = null
                } else if (value is JSONArray) {
                    val list = mutableListOf<Any>()
                    for (i in 0 until value.length()) {
                        list.add(value.get(i))
                    }
                    result[key] = list
                } else {
                    result[key] = value
                }
            }
        } catch (e: Exception) {
            // fallback
        }
        return result
    }

    // --- Field Definitions ---
    fun fieldsToJson(fields: List<FieldDefinition>): String {
        val array = JSONArray()
        for (f in fields) {
            val obj = JSONObject()
            obj.put("id", f.id)
            obj.put("name", f.name)
            obj.put("displayName", f.displayName)
            obj.put("type", f.type.name)
            obj.put("defaultValue", f.defaultValue ?: JSONObject.NULL)
            obj.put("isRequired", f.isRequired)
            obj.put("isUnique", f.isUnique)
            obj.put("isSearchable", f.isSearchable)
            obj.put("isFilterable", f.isFilterable)
            obj.put("isSortable", f.isSortable)
            obj.put("isReadOnly", f.isReadOnly)
            obj.put("formula", f.formula ?: JSONObject.NULL)
            obj.put("enumValues", JSONArray(f.enumValues))
            obj.put("targetEntityId", f.targetEntityId ?: JSONObject.NULL)
            obj.put("relationshipType", f.relationshipType?.name ?: JSONObject.NULL)

            val rulesArr = JSONArray()
            for (r in f.validationRules) {
                val rObj = JSONObject()
                rObj.put("type", r.type.name)
                rObj.put("value", r.value)
                rObj.put("errorMessage", r.errorMessage)
                rulesArr.put(rObj)
            }
            obj.put("validationRules", rulesArr)
            obj.put("metadata", JSONObject(f.metadata))
            array.put(obj)
        }
        return array.toString()
    }

    fun jsonToFields(jsonStr: String): List<FieldDefinition> {
        if (jsonStr.isBlank()) return emptyList()
        val list = mutableListOf<FieldDefinition>()
        try {
            val array = JSONArray(jsonStr)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val typeStr = obj.optString("type", FieldType.STRING.name)
                val type = try { FieldType.valueOf(typeStr) } catch (e: Exception) { FieldType.STRING }

                val relTypeStr = obj.optString("relationshipType", "")
                val relType = if (relTypeStr.isNotBlank()) {
                    try { RelationshipType.valueOf(relTypeStr) } catch (e: Exception) { null }
                } else null

                val enumList = mutableListOf<String>()
                val enumArr = obj.optJSONArray("enumValues")
                if (enumArr != null) {
                    for (j in 0 until enumArr.length()) {
                        enumList.add(enumArr.getString(j))
                    }
                }

                val rules = mutableListOf<ValidationRule>()
                val rulesArr = obj.optJSONArray("validationRules")
                if (rulesArr != null) {
                    for (k in 0 until rulesArr.length()) {
                        val rObj = rulesArr.getJSONObject(k)
                        val vType = try {
                            ValidationType.valueOf(rObj.optString("type", "REQUIRED"))
                        } catch (e: Exception) {
                            ValidationType.REQUIRED
                        }
                        rules.add(
                            ValidationRule(
                                type = vType,
                                value = rObj.optString("value", ""),
                                errorMessage = rObj.optString("errorMessage", "Validation failed")
                            )
                        )
                    }
                }

                list.add(
                    FieldDefinition(
                        id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                        name = obj.optString("name", "field_$i"),
                        displayName = obj.optString("displayName", "Field $i"),
                        type = type,
                        defaultValue = if (obj.has("defaultValue") && !obj.isNull("defaultValue")) obj.getString("defaultValue") else null,
                        isRequired = obj.optBoolean("isRequired", false),
                        isUnique = obj.optBoolean("isUnique", false),
                        isSearchable = obj.optBoolean("isSearchable", true),
                        isFilterable = obj.optBoolean("isFilterable", true),
                        isSortable = obj.optBoolean("isSortable", true),
                        isReadOnly = obj.optBoolean("isReadOnly", false),
                        formula = if (obj.has("formula") && !obj.isNull("formula")) obj.getString("formula") else null,
                        enumValues = enumList,
                        targetEntityId = if (obj.has("targetEntityId") && !obj.isNull("targetEntityId")) obj.getString("targetEntityId") else null,
                        relationshipType = relType,
                        validationRules = rules
                    )
                )
            }
        } catch (e: Exception) {
            // fallback
        }
        return list
    }

    // --- SDUI Sections ---
    fun sectionsToJson(sections: List<SDUISection>): String {
        val arr = JSONArray()
        for (s in sections) {
            val obj = JSONObject()
            obj.put("id", s.id)
            obj.put("screenId", s.screenId)
            obj.put("title", s.title)
            obj.put("subtitle", s.subtitle ?: JSONObject.NULL)
            obj.put("position", s.position)
            obj.put("layoutType", s.layoutType)
            obj.put("isCollapsible", s.isCollapsible)
            obj.put("isVisible", s.isVisible)
            obj.put("componentIds", JSONArray(s.componentIds))
            arr.put(obj)
        }
        return arr.toString()
    }

    fun jsonToSections(jsonStr: String): List<SDUISection> {
        if (jsonStr.isBlank()) return emptyList()
        val list = mutableListOf<SDUISection>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val cList = mutableListOf<String>()
                val cArr = obj.optJSONArray("componentIds")
                if (cArr != null) {
                    for (j in 0 until cArr.length()) cList.add(cArr.getString(j))
                }
                list.add(
                    SDUISection(
                        id = obj.optString("id"),
                        screenId = obj.optString("screenId"),
                        title = obj.optString("title", "Section"),
                        subtitle = if (obj.has("subtitle") && !obj.isNull("subtitle")) obj.getString("subtitle") else null,
                        position = obj.optInt("position", i),
                        layoutType = obj.optString("layoutType", "COLUMN"),
                        isCollapsible = obj.optBoolean("isCollapsible", false),
                        isVisible = obj.optBoolean("isVisible", true),
                        componentIds = cList
                    )
                )
            }
        } catch (e: Exception) {
            // fallback
        }
        return list
    }

    // --- SDUI Actions ---
    fun actionsToJson(actions: List<SDUIAction>): String {
        val arr = JSONArray()
        for (a in actions) {
            val obj = JSONObject()
            obj.put("id", a.id)
            obj.put("type", a.type.name)
            obj.put("target", a.target)
            obj.put("parameters", JSONObject(a.parameters))
            obj.put("confirmationPrompt", a.confirmationPrompt ?: JSONObject.NULL)
            arr.put(obj)
        }
        return arr.toString()
    }

    fun jsonToActions(jsonStr: String): List<SDUIAction> {
        if (jsonStr.isBlank()) return emptyList()
        val list = mutableListOf<SDUIAction>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val type = try {
                    SDUIActionType.valueOf(obj.optString("type", "NAVIGATE"))
                } catch (e: Exception) {
                    SDUIActionType.NAVIGATE
                }
                val params = mutableMapOf<String, String>()
                val pObj = obj.optJSONObject("parameters")
                if (pObj != null) {
                    val k = pObj.keys()
                    while (k.hasNext()) {
                        val key = k.next()
                        params[key] = pObj.optString(key)
                    }
                }
                list.add(
                    SDUIAction(
                        id = obj.optString("id"),
                        type = type,
                        target = obj.optString("target"),
                        parameters = params,
                        confirmationPrompt = if (obj.has("confirmationPrompt") && !obj.isNull("confirmationPrompt")) obj.getString("confirmationPrompt") else null
                    )
                )
            }
        } catch (e: Exception) {
            // fallback
        }
        return list
    }

    // --- Workflow Steps ---
    fun stepsToJson(steps: List<WorkflowStep>): String {
        val arr = JSONArray()
        for (s in steps) {
            val obj = JSONObject()
            obj.put("id", s.id)
            obj.put("name", s.name)
            obj.put("actionType", s.actionType.name)
            obj.put("parameters", JSONObject(s.parameters))

            val condArr = JSONArray()
            for (c in s.conditions) {
                val cObj = JSONObject()
                cObj.put("fieldPath", c.fieldPath)
                cObj.put("operator", c.operator)
                cObj.put("expectedValue", c.expectedValue)
                condArr.put(cObj)
            }
            obj.put("conditions", condArr)
            obj.put("nextStepIdOnSuccess", s.nextStepIdOnSuccess ?: JSONObject.NULL)
            obj.put("nextStepIdOnFailure", s.nextStepIdOnFailure ?: JSONObject.NULL)
            arr.put(obj)
        }
        return arr.toString()
    }

    fun jsonToSteps(jsonStr: String): List<WorkflowStep> {
        if (jsonStr.isBlank()) return emptyList()
        val list = mutableListOf<WorkflowStep>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val aType = try {
                    WorkflowActionType.valueOf(obj.optString("actionType", "MUTATE_RECORD"))
                } catch (e: Exception) {
                    WorkflowActionType.MUTATE_RECORD
                }
                val params = mutableMapOf<String, String>()
                val pObj = obj.optJSONObject("parameters")
                if (pObj != null) {
                    val k = pObj.keys()
                    while (k.hasNext()) {
                        val key = k.next()
                        params[key] = pObj.optString(key)
                    }
                }
                val condList = mutableListOf<WorkflowCondition>()
                val cArr = obj.optJSONArray("conditions")
                if (cArr != null) {
                    for (j in 0 until cArr.length()) {
                        val cObj = cArr.getJSONObject(j)
                        condList.add(
                            WorkflowCondition(
                                fieldPath = cObj.optString("fieldPath"),
                                operator = cObj.optString("operator", "EQUALS"),
                                expectedValue = cObj.optString("expectedValue")
                            )
                        )
                    }
                }
                list.add(
                    WorkflowStep(
                        id = obj.optString("id"),
                        name = obj.optString("name", "Step $i"),
                        actionType = aType,
                        parameters = params,
                        conditions = condList,
                        nextStepIdOnSuccess = if (obj.has("nextStepIdOnSuccess") && !obj.isNull("nextStepIdOnSuccess")) obj.getString("nextStepIdOnSuccess") else null,
                        nextStepIdOnFailure = if (obj.has("nextStepIdOnFailure") && !obj.isNull("nextStepIdOnFailure")) obj.getString("nextStepIdOnFailure") else null
                    )
                )
            }
        } catch (e: Exception) {
            // fallback
        }
        return list
    }

    // --- Workflow Step Logs ---
    fun logsToJson(logs: List<WorkflowStepLog>): String {
        val arr = JSONArray()
        for (l in logs) {
            val obj = JSONObject()
            obj.put("stepId", l.stepId)
            obj.put("stepName", l.stepName)
            obj.put("status", l.status)
            obj.put("durationMs", l.durationMs)
            obj.put("output", l.output ?: JSONObject.NULL)
            obj.put("error", l.error ?: JSONObject.NULL)
            arr.put(obj)
        }
        return arr.toString()
    }

    fun jsonToLogs(jsonStr: String): List<WorkflowStepLog> {
        if (jsonStr.isBlank()) return emptyList()
        val list = mutableListOf<WorkflowStepLog>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    WorkflowStepLog(
                        stepId = obj.optString("stepId"),
                        stepName = obj.optString("stepName"),
                        status = obj.optString("status", "SUCCESS"),
                        durationMs = obj.optLong("durationMs", 0L),
                        output = if (obj.has("output") && !obj.isNull("output")) obj.getString("output") else null,
                        error = if (obj.has("error") && !obj.isNull("error")) obj.getString("error") else null
                    )
                )
            }
        } catch (e: Exception) {
            // fallback
        }
        return list
    }

    // --- Navigation Items ---
    fun navItemsToJson(items: List<SDUINavItem>): String {
        val arr = JSONArray()
        for (n in items) {
            val obj = JSONObject()
            obj.put("id", n.id)
            obj.put("label", n.label)
            obj.put("icon", n.icon)
            obj.put("screenSlug", n.screenSlug)
            obj.put("badgeCount", n.badgeCount)
            obj.put("position", n.position)
            obj.put("requiredRole", n.requiredRole ?: JSONObject.NULL)
            arr.put(obj)
        }
        return arr.toString()
    }

    fun jsonToNavItems(jsonStr: String): List<SDUINavItem> {
        if (jsonStr.isBlank()) return emptyList()
        val list = mutableListOf<SDUINavItem>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    SDUINavItem(
                        id = obj.optString("id"),
                        label = obj.optString("label"),
                        icon = obj.optString("icon", "grid_view"),
                        screenSlug = obj.optString("screenSlug", "/"),
                        badgeCount = obj.optInt("badgeCount", 0),
                        position = obj.optInt("position", i),
                        requiredRole = if (obj.has("requiredRole") && !obj.isNull("requiredRole")) obj.getString("requiredRole") else null
                    )
                )
            }
        } catch (e: Exception) {
            // fallback
        }
        return list
    }

    // --- Generic String List & Map Helper ---
    fun stringListToJson(list: List<String>): String = JSONArray(list).toString()

    fun jsonToStringList(jsonStr: String): List<String> {
        if (jsonStr.isBlank()) return emptyList()
        val list = mutableListOf<String>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) list.add(arr.getString(i))
        } catch (e: Exception) {
            // fallback
        }
        return list
    }

    fun stringMapToJson(map: Map<String, String>): String = JSONObject(map).toString()

    fun jsonToStringMap(jsonStr: String): Map<String, String> {
        if (jsonStr.isBlank()) return emptyMap()
        val map = mutableMapOf<String, String>()
        try {
            val obj = JSONObject(jsonStr)
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                map[k] = obj.optString(k)
            }
        } catch (e: Exception) {
            // fallback
        }
        return map
    }
}
