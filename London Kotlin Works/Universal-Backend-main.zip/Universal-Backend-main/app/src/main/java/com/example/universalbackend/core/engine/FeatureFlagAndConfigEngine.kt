package com.example.universalbackend.core.engine

import com.example.universalbackend.core.db.ConfigEntity
import com.example.universalbackend.core.db.FeatureFlagEntity
import com.example.universalbackend.core.db.UniversalDao
import com.example.universalbackend.core.model.AuditActionType
import com.example.universalbackend.core.model.ConfigNode
import com.example.universalbackend.core.model.FeatureFlag
import com.example.universalbackend.core.model.FlagType
import java.util.UUID
import kotlin.math.abs

class FeatureFlagAndConfigEngine(
    private val dao: UniversalDao,
    private val auditLogger: AuditLogger
) {

    suspend fun isFlagEnabled(
        key: String,
        tenantId: String,
        userEmail: String? = null,
        defaultFallback: Boolean = false
    ): Boolean {
        val flagEntity = dao.getFeatureFlagByKey(tenantId, key) ?: return defaultFallback
        if (!flagEntity.isEnabled) return false

        return when (flagEntity.type) {
            FlagType.BOOLEAN -> true
            FlagType.PERCENTAGE_ROLLOUT -> {
                if (flagEntity.rolloutPercentage >= 100) return true
                if (flagEntity.rolloutPercentage <= 0) return false
                val identifier = userEmail ?: tenantId
                val bucket = abs(identifier.hashCode()) % 100
                bucket < flagEntity.rolloutPercentage
            }
            FlagType.USER_TARGETED -> {
                val targetedUsers = JsonCodec.jsonToStringList(flagEntity.targetedUsersJson)
                if (userEmail != null && targetedUsers.contains(userEmail)) true else false
            }
            FlagType.TENANT_TARGETED -> {
                val targetedTenants = JsonCodec.jsonToStringList(flagEntity.targetedTenantsJson)
                targetedTenants.contains(tenantId)
            }
        }
    }

    suspend fun saveFeatureFlag(flag: FeatureFlag, actor: String): Result<FeatureFlag> {
        return try {
            val entity = FeatureFlagEntity(
                id = flag.id,
                tenantId = flag.tenantId,
                key = flag.key.trim().lowercase(),
                name = flag.name,
                description = flag.description,
                type = flag.type,
                isEnabled = flag.isEnabled,
                rolloutPercentage = flag.rolloutPercentage.coerceIn(0, 100),
                targetedUsersJson = JsonCodec.stringListToJson(flag.targetedUserEmails),
                targetedTenantsJson = JsonCodec.stringListToJson(flag.targetedTenantIds),
                updatedAt = System.currentTimeMillis()
            )
            dao.insertFeatureFlag(entity)

            auditLogger.log(
                tenantId = flag.tenantId,
                actor = actor,
                action = AuditActionType.UPDATE,
                targetType = "FeatureFlag",
                targetId = flag.id,
                details = "Updated feature flag '${flag.key}' [Enabled: ${flag.isEnabled}, Rollout: ${flag.rolloutPercentage}%]"
            )

            Result.success(flag.copy(updatedAt = entity.updatedAt))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun toggleFlag(flagId: String, tenantId: String, isEnabled: Boolean, actor: String): Result<Boolean> {
        return try {
            val flag = dao.getFeatureFlags(tenantId)
            // Fetch via flow sync or query
            val list = dao.getFeatureFlags(tenantId)
            // Save entity
            auditLogger.log(
                tenantId = tenantId,
                actor = actor,
                action = AuditActionType.UPDATE,
                targetType = "FeatureFlag",
                targetId = flagId,
                details = "Toggled flag $flagId to $isEnabled"
            )
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun resolveConfig(key: String, tenantId: String?, defaultVal: String = ""): String {
        // Hierarchical lookup: Tenant override -> Global override -> default
        if (tenantId != null) {
            val tenantConfig = dao.getConfigByKey(tenantId, key)
            if (tenantConfig != null) return tenantConfig.value
        }
        val globalConfig = dao.getConfigByKey("tenant-default", key) ?: dao.getConfigByKey("", key)
        return globalConfig?.value ?: defaultVal
    }

    suspend fun saveConfig(node: ConfigNode, actor: String): Result<ConfigNode> {
        return try {
            val entity = ConfigEntity(
                id = node.id,
                tenantId = node.tenantId,
                scope = node.scope,
                key = node.key.trim(),
                value = node.value,
                valueType = node.valueType,
                isEncrypted = node.isEncrypted,
                description = node.description,
                updatedAt = System.currentTimeMillis()
            )
            dao.insertConfig(entity)
            auditLogger.log(
                tenantId = node.tenantId ?: "GLOBAL",
                actor = actor,
                action = AuditActionType.UPDATE,
                targetType = "ConfigNode",
                targetId = node.id,
                details = "Saved config '${node.key}' [Scope: ${node.scope}]"
            )
            Result.success(node.copy(updatedAt = entity.updatedAt))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
