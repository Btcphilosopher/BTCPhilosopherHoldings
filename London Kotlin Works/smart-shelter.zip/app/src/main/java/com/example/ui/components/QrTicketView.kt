package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.IssuedTicket
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

@Composable
fun QrTicketView(
    ticket: IssuedTicket,
    onPrintReceipt: () -> Unit,
    modifier: Modifier = Modifier
) {
    val expiryDateStr = SimpleDateFormat("HH:mm - d MMM yyyy", Locale.UK).format(Date(ticket.expiryTimestamp))
    val purchaseDateStr = SimpleDateFormat("HH:mm:ss", Locale.UK).format(Date(ticket.purchaseTimestamp))

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(2.dp, LiveArrivalGreen, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF0A1B2E)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top validation banner
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(LiveArrivalGreen.copy(alpha = 0.15f))
                    .border(1.dp, LiveArrivalGreen.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Verified Travel Credential",
                        tint = LiveArrivalGreen,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "VALID TRAVEL TICKET",
                        color = LiveArrivalGreen,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                }

                Text(
                    text = "Ref: ${ticket.ticketRef}",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Ticket Details & Dynamic Canvas QR Code
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Procedural QR matrix canvas
                Box(
                    modifier = Modifier
                        .size(130.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.White)
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val gridSize = 17
                        val cellW = size.width / gridSize
                        val cellH = size.height / gridSize
                        val hash = abs(ticket.qrPayload.hashCode())

                        for (r in 0 until gridSize) {
                            for (c in 0 until gridSize) {
                                // Corner position detection squares
                                val isCorner = (r < 4 && c < 4) || (r < 4 && c >= gridSize - 4) || (r >= gridSize - 4 && c < 4)
                                val isFilled = if (isCorner) {
                                    (r == 0 || r == 3 || c == 0 || c == 3 || (r in 1..2 && c in 1..2))
                                } else {
                                    ((hash shr ((r * 7 + c) % 31)) and 1) == 1
                                }

                                if (isFilled) {
                                    drawRect(
                                        color = Color.Black,
                                        topLeft = Offset(c * cellW, r * cellH),
                                        size = Size(cellW, cellH)
                                    )
                                }
                            }
                        }
                    }
                }

                // Info block
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = ticket.ticketType.title,
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "Fare Paid: £%.2f (%s)".format(ticket.farePaid, ticket.paymentMethod.label),
                        color = LiveArrivalGreen,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Valid Until:",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                    Text(
                        text = expiryDateStr,
                        color = Color(0xFFFDE047),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Text(
                        text = "Auth: ${ticket.authorizationCode} • ${ticket.cardMaskedPan}",
                        color = TextSecondary,
                        fontSize = 10.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action buttons: Print thermal ticket receipt
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onPrintReceipt,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("print_ticket_receipt_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A5F)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Print,
                        contentDescription = "Print Ticket",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Print Paper Ticket / Receipt", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
