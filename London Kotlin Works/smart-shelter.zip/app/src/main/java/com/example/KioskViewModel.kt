package com.example

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.PaymentTerminalService
import com.example.data.TransportRepository
import com.example.model.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

enum class KioskDialog {
    NONE,
    BUY_TICKETS,
    PLAN_JOURNEY,
    LOCAL_AREA,
    ACCESSIBILITY,
    ALL_DEPARTURES,
    ADMIN_DIAGNOSTICS,
    TICKET_WALLET,
    SOS_EMERGENCY
}

data class KioskTelemetry(
    val shelterId: String = "UK-TFL-SHT-WES-0042",
    val nfcReaderStatus: String = "ONLINE (PN7160 EMV-L2)",
    val displayBrightness: Int = 95, // Percent
    val displayTemperatureCelsius: Double = 23.4,
    val cellularSignalDbm: Int = -64, // 5G Strong
    val cellularNetwork: String = "EE Private Transport APN",
    val paperRollRemainingPercent: Int = 84,
    val softwareVersion: String = "v3.14.2-bods-prod",
    val lastSyncTimestamp: String = "Just now",
    val powerSource: String = "Mains 230V + Solar Roof Battery (98%)"
)

class KioskViewModel(
    val repository: TransportRepository = TransportRepository(),
    val paymentService: PaymentTerminalService = PaymentTerminalService()
) : ViewModel() {

    private val _arrivals = MutableStateFlow<List<BusArrival>>(emptyList())
    val arrivals: StateFlow<List<BusArrival>> = _arrivals.asStateFlow()

    private val _routes = MutableStateFlow(repository.getBusRoutes())
    val routes: StateFlow<List<BusRoute>> = _routes.asStateFlow()

    private val _selectedRoute = MutableStateFlow(routes.value.first())
    val selectedRoute: StateFlow<BusRoute> = _selectedRoute.asStateFlow()

    private val _currentTime = MutableStateFlow("16:42")
    val currentTime: StateFlow<String> = _currentTime.asStateFlow()

    private val _currentDate = MutableStateFlow("Fri 24 Oct 2025")
    val currentDate: StateFlow<String> = _currentDate.asStateFlow()

    val weatherTemp = "12°C"
    val weatherDesc = "Light Drizzle"
    val airQuality = "DAQI 2 (Low)"

    private val _activeDialog = MutableStateFlow(KioskDialog.NONE)
    val activeDialog: StateFlow<KioskDialog> = _activeDialog.asStateFlow()

    // Accessibility state
    val isHighContrast = MutableStateFlow(false)
    val isLargeText = MutableStateFlow(false)
    val selectedLanguage = MutableStateFlow(AppLanguage.EN)
    val speechAnnouncements = MutableStateFlow(false)

    // Journey Planner
    val searchQuery = MutableStateFlow("")
    val stepFreeOnly = MutableStateFlow(false)
    private val _journeyResults = MutableStateFlow(repository.searchJourneys("", false))
    val journeyResults: StateFlow<List<JourneyOption>> = _journeyResults.asStateFlow()
    val selectedJourney = MutableStateFlow<JourneyOption?>(null)

    // Ticketing & Payment
    val selectedTicketForPurchase = MutableStateFlow<TicketType?>(null)
    val terminalState = paymentService.terminalState
    private val _purchasedTickets = MutableStateFlow<List<IssuedTicket>>(emptyList())
    val purchasedTickets: StateFlow<List<IssuedTicket>> = _purchasedTickets.asStateFlow()
    val activeIssuedTicket = MutableStateFlow<IssuedTicket?>(null)

    // Local area & Alerts
    val amenities = repository.getLocalAmenities()
    val disruptions = repository.getServiceDisruptions()

    // Kiosk Telemetry
    val telemetry = MutableStateFlow(KioskTelemetry())

    // Inactivity timeout
    private var inactivityTimerJob: Job? = null
    val inactivityRemainingSeconds = MutableStateFlow(45)

    init {
        // Collect live arrivals from repository flow
        viewModelScope.launch {
            repository.getLiveArrivalsFlow().collect { list ->
                _arrivals.value = list
            }
        }

        // Live clock updater
        viewModelScope.launch {
            val timeFormat = SimpleDateFormat("HH:mm", Locale.UK)
            val dateFormat = SimpleDateFormat("EEE d MMM yyyy", Locale.UK)
            while (true) {
                val now = Date()
                _currentTime.value = timeFormat.format(now)
                _currentDate.value = dateFormat.format(now)
                delay(1000)
            }
        }

        startInactivityTimer()
    }

    fun userInteracted() {
        inactivityRemainingSeconds.value = 45
    }

    private fun startInactivityTimer() {
        inactivityTimerJob?.cancel()
        inactivityTimerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                if (_activeDialog.value != KioskDialog.NONE) {
                    val remaining = inactivityRemainingSeconds.value - 1
                    if (remaining <= 0) {
                        dismissDialog()
                        inactivityRemainingSeconds.value = 45
                    } else {
                        inactivityRemainingSeconds.value = remaining
                    }
                } else {
                    inactivityRemainingSeconds.value = 45
                }
            }
        }
    }

    fun openDialog(dialog: KioskDialog) {
        userInteracted()
        _activeDialog.value = dialog
        if (dialog == KioskDialog.BUY_TICKETS && selectedTicketForPurchase.value == null) {
            selectedTicketForPurchase.value = TicketType.SINGLE_BUS_HOPPER
            paymentService.initiatePayment(TicketType.SINGLE_BUS_HOPPER)
        }
    }

    fun dismissDialog() {
        _activeDialog.value = KioskDialog.NONE
        paymentService.resetToIdle()
        selectedTicketForPurchase.value = null
        activeIssuedTicket.value = null
        selectedJourney.value = null
    }

    fun selectRoute(route: BusRoute) {
        userInteracted()
        _selectedRoute.value = route
    }

    fun selectTicketType(type: TicketType) {
        userInteracted()
        selectedTicketForPurchase.value = type
        paymentService.initiatePayment(type)
    }

    fun simulateTapPayment(method: PaymentMethod, onComplete: ((IssuedTicket) -> Unit)? = null) {
        userInteracted()
        viewModelScope.launch {
            val result = paymentService.processContactlessTap(method)
            result.onSuccess { ticket ->
                _purchasedTickets.value = listOf(ticket) + _purchasedTickets.value
                activeIssuedTicket.value = ticket
                onComplete?.invoke(ticket)
            }
        }
    }

    fun onSearchQueryChanged(newQuery: String) {
        userInteracted()
        searchQuery.value = newQuery
        _journeyResults.value = repository.searchJourneys(newQuery, stepFreeOnly.value)
    }

    fun toggleStepFreeOnly() {
        userInteracted()
        val newVal = !stepFreeOnly.value
        stepFreeOnly.value = newVal
        _journeyResults.value = repository.searchJourneys(searchQuery.value, newVal)
    }

    fun selectJourney(journey: JourneyOption) {
        userInteracted()
        selectedJourney.value = journey
    }

    fun toggleHighContrast() {
        userInteracted()
        isHighContrast.value = !isHighContrast.value
    }

    fun toggleLargeText() {
        userInteracted()
        isLargeText.value = !isLargeText.value
    }

    fun toggleSpeechAnnouncements() {
        userInteracted()
        speechAnnouncements.value = !speechAnnouncements.value
    }

    fun setLanguage(lang: AppLanguage) {
        userInteracted()
        selectedLanguage.value = lang
    }
}
