package com.example.model

enum class CrowdingLevel {
    LOW,
    MEDIUM,
    HIGH
}

enum class Operator(val displayName: String, val badgeColorHex: Long) {
    TFL_LONDON_GENERAL("London General", 0xFFDC241F),
    TFL_ABELLIO("Abellio London", 0xFF005DAA),
    TFL_GO_AHEAD("Go-Ahead London", 0xFFE31B23),
    TFL_METROLINE("Metroline", 0xFF003882),
    TFL_STAGECOACH("Stagecoach London", 0xFFF28500)
}

data class BusArrival(
    val id: String,
    val routeNumber: String,
    val destination: String,
    val operator: Operator,
    val minutesAway: Int,
    val scheduledTime: String,
    val predictedTime: String,
    val isLivePrediction: Boolean = true,
    val isWheelchairAccessible: Boolean = true,
    val isLowFloor: Boolean = true,
    val isElectricZeroEmission: Boolean = true,
    val crowding: CrowdingLevel = CrowdingLevel.LOW,
    val delayMinutes: Int = 0,
    val vehicleId: String = "LTZ" + (1000..9999).random(),
    val intermediateVia: String? = null
)

data class RouteStop(
    val stopId: String,
    val name: String,
    val xRatio: Float,
    val yRatio: Float,
    val isShelterLocation: Boolean = false,
    val transferLines: List<String> = emptyList()
)

data class BusRoute(
    val routeNumber: String,
    val destination: String,
    val origin: String,
    val colorHex: Long,
    val frequencyMinutes: Int,
    val stops: List<RouteStop>,
    val operator: Operator
)

enum class TicketType(
    val title: String,
    val description: String,
    val pricePounds: Double,
    val validityDescription: String,
    val isHopperEligible: Boolean = false
) {
    SINGLE_BUS_HOPPER(
        "Single Bus & Tram",
        "Unlimited bus journeys within 60 minutes",
        1.75,
        "Valid for 1 hour from first tap",
        isHopperEligible = true
    ),
    DAY_BUS_PASS(
        "Bus & Tram Day Pass",
        "Unlimited travel until 04:30 tomorrow",
        6.00,
        "Daily price cap equivalent"
    ),
    ZONE_1_2_TRAVELCARD(
        "1-Day Travelcard (Zones 1-2)",
        "Valid on Bus, Tube, DLR, Elizabeth line & Overground",
        9.60,
        "Valid off-peak anytime after 09:30"
    ),
    SEVEN_DAY_BUS_PASS(
        "7-Day Bus & Tram Pass",
        "7 consecutive days unlimited bus travel across Greater London",
        24.70,
        "Valid for 7 days"
    ),
    CONCESSION_ZIP_CHILD(
        "Under 16 / Zip Fare",
        "Eligible children and young persons",
        0.85,
        "Proof of concession required upon inspection",
        isHopperEligible = true
    )
}

enum class PaymentTerminalState {
    IDLE,
    PROMPTING_TAP,
    READING_CARD,
    AUTHORISING_TRANSACTION,
    APPROVED,
    DECLINED,
    TIMED_OUT
}

enum class PaymentMethod(val label: String) {
    CONTACTLESS_EMV("Contactless EMV Card"),
    APPLE_PAY("Apple Pay"),
    GOOGLE_PAY("Google Pay"),
    OYSTER_CARD("TfL Oyster / ITSO Smartcard")
}

data class IssuedTicket(
    val ticketId: String,
    val ticketRef: String,
    val ticketType: TicketType,
    val farePaid: Double,
    val purchaseTimestamp: Long,
    val expiryTimestamp: Long,
    val paymentTransactionId: String,
    val paymentMethod: PaymentMethod,
    val cardMaskedPan: String,
    val authorizationCode: String,
    val qrPayload: String,
    val isValid: Boolean = true
)

data class JourneyLeg(
    val mode: String, // "WALK", "BUS", "TUBE"
    val instruction: String,
    val durationMinutes: Int,
    val routeNumber: String? = null,
    val destination: String? = null,
    val stopsCount: Int = 0
)

data class JourneyOption(
    val id: String,
    val destinationName: String,
    val totalDurationMinutes: Int,
    val departureTime: String,
    val arrivalTime: String,
    val walkingMinutes: Int,
    val changesCount: Int,
    val farePounds: Double,
    val isStepFree: Boolean,
    val primaryRoute: String,
    val legs: List<JourneyLeg>
)

data class AmenityItem(
    val id: String,
    val name: String,
    val category: String, // "Station", "Hospital / First Aid", "Landmark", "Defibrillator", "Restroom"
    val walkingMinutes: Int,
    val distanceMeters: Int,
    val isStepFree: Boolean = true,
    val description: String
)

data class ServiceDisruption(
    val id: String,
    val affectedRoutes: List<String>,
    val severity: String, // "Good Service", "Minor Delays", "Part Closure", "Diversion"
    val title: String,
    val message: String,
    val isUrgent: Boolean = false
)

enum class AppLanguage(val code: String, val label: String, val nativeName: String) {
    EN("en", "English", "English"),
    CY("cy", "Welsh", "Cymraeg"),
    FR("fr", "French", "Français"),
    ES("es", "Spanish", "Español"),
    DE("de", "German", "Deutsch")
}
