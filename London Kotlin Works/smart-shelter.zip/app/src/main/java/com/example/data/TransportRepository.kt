package com.example.data

import com.example.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.text.SimpleDateFormat
import java.util.*

class TransportRepository {

    val shelterId = "UK-TFL-SHT-WES-0042"
    val stopName = "Westminster Bridge Road"
    val stopIndicator = "Stop B"
    val stopCode = "490000253E"
    val naptanCode = "490000253E"
    val borough = "London Borough of Lambeth / City of Westminster"
    val coordinates = "51.5014° N, 0.1171° W"

    private val initialArrivals = listOf(
        BusArrival(
            id = "arr_12_1",
            routeNumber = "12",
            destination = "Oxford Circus",
            operator = Operator.TFL_GO_AHEAD,
            minutesAway = 2,
            scheduledTime = "16:44",
            predictedTime = "16:44",
            crowding = CrowdingLevel.LOW,
            intermediateVia = "via Parliament Sq, Piccadilly Circus",
            isWheelchairAccessible = true,
            isElectricZeroEmission = true
        ),
        BusArrival(
            id = "arr_148_1",
            routeNumber = "148",
            destination = "Camden Town",
            operator = Operator.TFL_LONDON_GENERAL,
            minutesAway = 4,
            scheduledTime = "16:47",
            predictedTime = "16:46",
            crowding = CrowdingLevel.MEDIUM,
            intermediateVia = "via Victoria, Hyde Park Corner, Marble Arch",
            isWheelchairAccessible = true,
            isElectricZeroEmission = true
        ),
        BusArrival(
            id = "arr_211_1",
            routeNumber = "211",
            destination = "Waterloo",
            operator = Operator.TFL_ABELLIO,
            minutesAway = 7,
            scheduledTime = "16:49",
            predictedTime = "16:49",
            crowding = CrowdingLevel.LOW,
            intermediateVia = "via York Road & Waterloo Station",
            isWheelchairAccessible = true,
            isElectricZeroEmission = false
        ),
        BusArrival(
            id = "arr_453_1",
            routeNumber = "453",
            destination = "Battersea Bridge",
            operator = Operator.TFL_STAGECOACH,
            minutesAway = 11,
            scheduledTime = "16:54",
            predictedTime = "16:53",
            crowding = CrowdingLevel.HIGH,
            intermediateVia = "via Lambeth North, Kennington",
            isWheelchairAccessible = true,
            isElectricZeroEmission = true
        ),
        BusArrival(
            id = "arr_159_1",
            routeNumber = "159",
            destination = "Marble Arch",
            operator = Operator.TFL_METROLINE,
            minutesAway = 15,
            scheduledTime = "16:58",
            predictedTime = "16:57",
            crowding = CrowdingLevel.LOW,
            intermediateVia = "via Westminster, Trafalgar Sq, Regent St",
            isWheelchairAccessible = true,
            isElectricZeroEmission = true
        ),
        BusArrival(
            id = "arr_53_1",
            routeNumber = "53",
            destination = "Whitehall / Horse Guards",
            operator = Operator.TFL_STAGECOACH,
            minutesAway = 21,
            scheduledTime = "17:03",
            predictedTime = "17:03",
            crowding = CrowdingLevel.LOW,
            intermediateVia = "via Parliament Street",
            isWheelchairAccessible = true,
            isElectricZeroEmission = false
        )
    )

    fun getBusRoutes(): List<BusRoute> {
        return listOf(
            BusRoute(
                routeNumber = "12",
                destination = "Oxford Circus",
                origin = "Dulwich Library",
                colorHex = 0xFFDC241F,
                frequencyMinutes = 5,
                operator = Operator.TFL_GO_AHEAD,
                stops = listOf(
                    RouteStop("S1", "Elephant & Castle", 0.15f, 0.85f),
                    RouteStop("S2", "Imperial War Museum", 0.30f, 0.70f),
                    RouteStop("S3", "Westminster Bridge Road (Stop B)", 0.45f, 0.50f, isShelterLocation = true, transferLines = listOf("12", "148", "211", "453")),
                    RouteStop("S4", "Westminster Station / Parliament Sq", 0.60f, 0.42f, transferLines = listOf("Jubilee", "District", "Circle")),
                    RouteStop("S5", "Trafalgar Square / Charing Cross", 0.75f, 0.30f, transferLines = listOf("Bakerloo", "Northern")),
                    RouteStop("S6", "Piccadilly Circus", 0.85f, 0.22f, transferLines = listOf("Piccadilly", "Bakerloo")),
                    RouteStop("S7", "Oxford Circus", 0.95f, 0.15f, transferLines = listOf("Central", "Victoria", "Bakerloo"))
                )
            ),
            BusRoute(
                routeNumber = "148",
                destination = "Camden Town",
                origin = "Camberwell Green",
                colorHex = 0xFF005DAA,
                frequencyMinutes = 6,
                operator = Operator.TFL_LONDON_GENERAL,
                stops = listOf(
                    RouteStop("S10", "Elephant & Castle", 0.15f, 0.85f),
                    RouteStop("S3", "Westminster Bridge Road (Stop B)", 0.45f, 0.50f, isShelterLocation = true),
                    RouteStop("S11", "Victoria Station", 0.48f, 0.35f, transferLines = listOf("Victoria", "District", "National Rail")),
                    RouteStop("S12", "Hyde Park Corner", 0.62f, 0.28f),
                    RouteStop("S13", "Marble Arch", 0.75f, 0.20f),
                    RouteStop("S14", "Camden Town", 0.90f, 0.10f, transferLines = listOf("Northern"))
                )
            ),
            BusRoute(
                routeNumber = "211",
                destination = "Waterloo",
                origin = "Hammersmith",
                colorHex = 0xFF00782A,
                frequencyMinutes = 8,
                operator = Operator.TFL_ABELLIO,
                stops = listOf(
                    RouteStop("S20", "St Thomas' Hospital", 0.40f, 0.55f),
                    RouteStop("S3", "Westminster Bridge Road (Stop B)", 0.45f, 0.50f, isShelterLocation = true),
                    RouteStop("S21", "County Hall", 0.52f, 0.52f),
                    RouteStop("S22", "Waterloo Station", 0.65f, 0.60f, transferLines = listOf("Bakerloo", "Jubilee", "Northern", "SWR"))
                )
            ),
            BusRoute(
                routeNumber = "453",
                destination = "Battersea Bridge",
                origin = "Deptford Bridge",
                colorHex = 0xFFF28500,
                frequencyMinutes = 5,
                operator = Operator.TFL_STAGECOACH,
                stops = listOf(
                    RouteStop("S30", "Great Dover Street", 0.20f, 0.75f),
                    RouteStop("S3", "Westminster Bridge Road (Stop B)", 0.45f, 0.50f, isShelterLocation = true),
                    RouteStop("S31", "Lambeth North", 0.42f, 0.65f),
                    RouteStop("S32", "Kennington Road", 0.55f, 0.75f),
                    RouteStop("S33", "Battersea Bridge", 0.80f, 0.88f)
                )
            )
        )
    }

    fun getLocalAmenities(): List<AmenityItem> {
        return listOf(
            AmenityItem(
                id = "am_1",
                name = "Westminster Station",
                category = "Transport Interchange",
                walkingMinutes = 3,
                distanceMeters = 240,
                isStepFree = true,
                description = "Jubilee, District & Circle Underground lines. Fully accessible step-free lifts."
            ),
            AmenityItem(
                id = "am_2",
                name = "London Waterloo Station",
                category = "Transport Interchange",
                walkingMinutes = 7,
                distanceMeters = 550,
                isStepFree = true,
                description = "National Rail (South Western Railway), Bakerloo, Jubilee, Northern & Waterloo & City lines."
            ),
            AmenityItem(
                id = "am_3",
                name = "St Thomas' Hospital Emergency (A&E)",
                category = "Hospital & Emergency",
                walkingMinutes = 2,
                distanceMeters = 160,
                isStepFree = true,
                description = "24/7 NHS Major Trauma & Emergency Department. Automated External Defibrillator (AED) on site."
            ),
            AmenityItem(
                id = "am_4",
                name = "Big Ben & Palace of Westminster",
                category = "Civic Landmark",
                walkingMinutes = 4,
                distanceMeters = 320,
                isStepFree = true,
                description = "Historic British Parliament clock tower and UNESCO world heritage quarter."
            ),
            AmenityItem(
                id = "am_5",
                name = "The London Eye & Southbank",
                category = "Attraction",
                walkingMinutes = 5,
                distanceMeters = 400,
                isStepFree = true,
                description = "Riverside cultural promenade, street performances, food stalls and iconic wheel."
            ),
            AmenityItem(
                id = "am_6",
                name = "Public Restrooms & Defibrillator (AED)",
                category = "Public Facility",
                walkingMinutes = 1,
                distanceMeters = 60,
                isStepFree = true,
                description = "Fully accessible radar-key restroom and public life-saving AED unit next to shelter pillar."
            )
        )
    }

    fun getServiceDisruptions(): List<ServiceDisruption> {
        return listOf(
            ServiceDisruption(
                id = "dis_1",
                affectedRoutes = listOf("12", "148", "453"),
                severity = "Good Service",
                title = "Central London Bus Network Operating Normally",
                message = "All bus services through Westminster Bridge are operating with regular frequency and minimal delay.",
                isUrgent = false
            ),
            ServiceDisruption(
                id = "dis_2",
                affectedRoutes = listOf("211"),
                severity = "Minor Delays",
                title = "York Road Traffic Management",
                message = "Temporary roadworks on York Road may add 3-5 minutes to Waterloo arrivals during peak hours.",
                isUrgent = false
            ),
            ServiceDisruption(
                id = "dis_3",
                affectedRoutes = emptyList(),
                severity = "Planned Works",
                title = "Weekend Tube Maintenance - District Line",
                message = "District Line closed between Tower Hill and Earl's Court on Saturday. Bus substitution in place.",
                isUrgent = false
            )
        )
    }

    fun searchJourneys(query: String, stepFreeOnly: Boolean): List<JourneyOption> {
        val cleanQuery = query.trim().lowercase()
        val allOptions = listOf(
            JourneyOption(
                id = "j_oxford",
                destinationName = "Oxford Circus",
                totalDurationMinutes = 14,
                departureTime = "16:44",
                arrivalTime = "16:58",
                walkingMinutes = 2,
                changesCount = 0,
                farePounds = 1.75,
                isStepFree = true,
                primaryRoute = "Bus 12 (Direct)",
                legs = listOf(
                    JourneyLeg("BUS", "Board Bus 12 towards Oxford Circus at Westminster Bridge Road (Stop B)", 12, "12", "Oxford Circus", 8),
                    JourneyLeg("WALK", "Alight at Oxford Circus Station / John Lewis and walk 100m", 2)
                )
            ),
            JourneyOption(
                id = "j_waterloo",
                destinationName = "Waterloo Station",
                totalDurationMinutes = 7,
                departureTime = "16:49",
                arrivalTime = "16:56",
                walkingMinutes = 1,
                changesCount = 0,
                farePounds = 1.75,
                isStepFree = true,
                primaryRoute = "Bus 211 (Direct)",
                legs = listOf(
                    JourneyLeg("BUS", "Board Bus 211 towards Waterloo at Stop B", 6, "211", "Waterloo", 3),
                    JourneyLeg("WALK", "Arrive at Waterloo Main Concourse", 1)
                )
            ),
            JourneyOption(
                id = "j_camden",
                destinationName = "Camden Town",
                totalDurationMinutes = 24,
                departureTime = "16:46",
                arrivalTime = "17:10",
                walkingMinutes = 3,
                changesCount = 0,
                farePounds = 1.75,
                isStepFree = true,
                primaryRoute = "Bus 148 (Direct)",
                legs = listOf(
                    JourneyLeg("BUS", "Board Bus 148 towards Camden Town at Stop B", 21, "148", "Camden Town", 14),
                    JourneyLeg("WALK", "Alight at Camden Town Tube / Camden High St", 3)
                )
            ),
            JourneyOption(
                id = "j_covent",
                destinationName = "Covent Garden",
                totalDurationMinutes = 16,
                departureTime = "16:44",
                arrivalTime = "17:00",
                walkingMinutes = 4,
                changesCount = 0,
                farePounds = 1.75,
                isStepFree = true,
                primaryRoute = "Bus 12 + Short Walk",
                legs = listOf(
                    JourneyLeg("BUS", "Board Bus 12 to Trafalgar Square / Charing Cross", 11, "12", "Oxford Circus", 6),
                    JourneyLeg("WALK", "Stroll through scenic Bedford St to Covent Garden Piazza", 5)
                )
            ),
            JourneyOption(
                id = "j_victoria",
                destinationName = "Victoria Coach Station",
                totalDurationMinutes = 18,
                departureTime = "16:46",
                arrivalTime = "17:04",
                walkingMinutes = 3,
                changesCount = 0,
                farePounds = 1.75,
                isStepFree = true,
                primaryRoute = "Bus 148",
                legs = listOf(
                    JourneyLeg("BUS", "Board Bus 148 towards Camden Town via Victoria", 14, "148", "Camden Town", 9),
                    JourneyLeg("WALK", "Alight at Victoria Station and walk 250m to Coach Station", 4)
                )
            ),
            JourneyOption(
                id = "j_london_bridge",
                destinationName = "London Bridge & Borough Market",
                totalDurationMinutes = 19,
                departureTime = "16:45",
                arrivalTime = "17:04",
                walkingMinutes = 5,
                changesCount = 1,
                farePounds = 1.75,
                isStepFree = true,
                primaryRoute = "Bus 453 + Bus 344 (Hopper Fare)",
                legs = listOf(
                    JourneyLeg("BUS", "Board Bus 453 to Elephant & Castle (Stop E)", 8, "453", "Battersea Bridge", 5),
                    JourneyLeg("BUS", "Change free of charge to Bus 344 towards London Bridge", 7, "344", "Liverpool Street", 4),
                    JourneyLeg("WALK", "Walk 150m to Borough Market", 4)
                )
            ),
            JourneyOption(
                id = "j_heathrow",
                destinationName = "Heathrow Airport (Terminals 2, 3, 5)",
                totalDurationMinutes = 48,
                departureTime = "16:47",
                arrivalTime = "17:35",
                walkingMinutes = 4,
                changesCount = 1,
                farePounds = 5.60,
                isStepFree = true,
                primaryRoute = "Tube Jubilee -> Elizabeth line",
                legs = listOf(
                    JourneyLeg("WALK", "Walk 3 mins to Westminster Underground Station", 3),
                    JourneyLeg("TUBE", "Jubilee line to Bond Street, transfer to Elizabeth line to Heathrow", 40, "Elizabeth", "Heathrow Airport", 7),
                    JourneyLeg("WALK", "Arrive Heathrow Terminal Central", 5)
                )
            )
        )

        return allOptions.filter {
            (cleanQuery.isEmpty() || it.destinationName.lowercase().contains(cleanQuery) || it.primaryRoute.lowercase().contains(cleanQuery)) &&
                    (!stepFreeOnly || it.isStepFree)
        }
    }

    /**
     * Emulates live countdown stream ticking arrivals down realistically.
     */
    fun getLiveArrivalsFlow(): Flow<List<BusArrival>> = flow {
        var currentList = initialArrivals
        var secondsElapsed = 0

        while (true) {
            emit(currentList)
            delay(1000)
            secondsElapsed++

            // Every 60 seconds or so, decrement minutes away
            if (secondsElapsed % 30 == 0) {
                currentList = currentList.map { arr ->
                    val newMinutes = if (arr.minutesAway > 0) arr.minutesAway - 1 else 0
                    if (newMinutes == 0 && secondsElapsed % 60 == 0) {
                        // Bus arrives and new bus joins the queue
                        arr.copy(minutesAway = (18..25).random(), predictedTime = calculateNextTime(arr.minutesAway))
                    } else {
                        arr.copy(minutesAway = newMinutes)
                    }
                }.sortedBy { it.minutesAway }
            }
        }
    }

    private fun calculateNextTime(plusMins: Int): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.MINUTE, plusMins)
        return SimpleDateFormat("HH:mm", Locale.UK).format(cal.time)
    }
}
