package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun QuickActionTiles(
    onBuyTickets: () -> Unit,
    onPlanJourney: () -> Unit,
    onLocalArea: () -> Unit,
    onAccessibility: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ActionTile(
                title = "Buy tickets",
                subtitle = "Contactless • Oyster • QR",
                icon = Icons.Outlined.CreditCard,
                onClick = onBuyTickets,
                modifier = Modifier.weight(1f),
                testTag = "tile_buy_tickets",
                accentColor = Color(0xFF38BDF8)
            )

            ActionTile(
                title = "Plan a journey",
                subtitle = "Live times • Routes • Favourites",
                icon = Icons.Outlined.AltRoute,
                onClick = onPlanJourney,
                modifier = Modifier.weight(1f),
                testTag = "tile_plan_journey",
                accentColor = Color(0xFF60A5FA)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ActionTile(
                title = "Local area",
                subtitle = "Shops • Food • Attractions",
                icon = Icons.Outlined.Map,
                onClick = onLocalArea,
                modifier = Modifier.weight(1f),
                testTag = "tile_local_area",
                accentColor = Color(0xFF34D399)
            )

            ActionTile(
                title = "Accessibility",
                subtitle = "Step free • Assistance",
                icon = Icons.Filled.AccessibleForward,
                onClick = onAccessibility,
                modifier = Modifier.weight(1f),
                testTag = "tile_accessibility",
                accentColor = Color(0xFFA78BFA)
            )
        }
    }
}

@Composable
private fun ActionTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String,
    accentColor: Color
) {
    Box(
        modifier = modifier
            .height(84.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(TransportGlassSurface)
            .border(1.dp, TransportGlassBorder, RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(accentColor.copy(alpha = 0.15f))
                    .border(1.dp, accentColor.copy(alpha = 0.35f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(24.dp)
                )
            }

            Column(
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = (-0.2).sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Normal
                )
            }
        }
    }
}
