package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TransportNavyDark = Color(0xFF060D17)
val TransportNavySurface = Color(0xFF0C192C)
val TransportNavyContainer = Color(0xFF142642)
val TransportGlassSurface = Color(0xCC0E1F35)
val TransportGlassBorder = Color(0x334B709C)

val TfLRed = Color(0xFFDC241F)
val TfLBlue = Color(0xFF0019A8)
val LiveArrivalGreen = Color(0xFF00E676)
val WarningAmber = Color(0xFFF59E0B)
val DisruptionRed = Color(0xFFEF4444)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

// High contrast accessibility tokens
val HighContrastBg = Color(0xFF000000)
val HighContrastYellow = Color(0xFFFFDD00)
val HighContrastWhite = Color(0xFFFFFFFF)
