package com.example.ui.screens

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.KioskDialog
import com.example.KioskViewModel
import com.example.R
import com.example.model.IssuedTicket
import com.example.model.PaymentMethod
import com.example.model.TicketType
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun MainKioskScreen(
    viewModel: KioskViewModel,
    onSpeakArrivals: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val arrivals by viewModel.arrivals.collectAsStateWithLifecycle()
    val routes by viewModel.routes.collectAsStateWithLifecycle()
    val selectedRoute by viewModel.selectedRoute.collectAsStateWithLifecycle()
    val currentTime by viewModel.currentTime.collectAsStateWithLifecycle()
    val currentDate by viewModel.currentDate.collectAsStateWithLifecycle()
    val activeDialog by viewModel.activeDialog.collectAsStateWithLifecycle()

    val isHighContrast by viewModel.isHighContrast.collectAsStateWithLifecycle()
    val isLargeText by viewModel.isLargeText.collectAsStateWithLifecycle()
    val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()
    val speechAnnouncements by viewModel.speechAnnouncements.collectAsStateWithLifecycle()

    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val stepFreeOnly by viewModel.stepFreeOnly.collectAsStateWithLifecycle()
    val journeyResults by viewModel.journeyResults.collectAsStateWithLifecycle()
    val selectedJourney by viewModel.selectedJourney.collectAsStateWithLifecycle()

    val selectedTicketForPurchase by viewModel.selectedTicketForPurchase.collectAsStateWithLifecycle()
    val terminalState by viewModel.terminalState.collectAsStateWithLifecycle()
    val purchasedTickets by viewModel.purchasedTickets.collectAsStateWithLifecycle()
    val activeIssuedTicket by viewModel.activeIssuedTicket.collectAsStateWithLifecycle()

    val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
    val inactivitySeconds by viewModel.inactivityRemainingSeconds.collectAsStateWithLifecycle()

    // Haptic feedback helper
    fun triggerHapticFeedback() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(50)
                }
            }
        } catch (_: Exception) {}
    }

    Box(modifier = modifier.fillMaxSize()) {
        // Ambient background image of London Westminster bus shelter
        Image(
            painter = painterResource(id = R.drawable.london_shelter_bg),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .alpha(if (isHighContrast) 0.05f else 0.25f)
        )

        // Glassmorphism deep tint overlay
        val overlayModifier = if (isHighContrast) {
            Modifier.background(Color.Black)
        } else {
            Modifier.background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xF0060D17),
                        Color(0xEC091526),
                        Color(0xF5060D17)
                    )
                )
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .then(overlayModifier)
        )

        // Main Shelter Terminal UI Layout
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isWideLayout = maxWidth >= 760.dp

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .padding(8.dp)
            ) {
                // Top Kiosk Header
                TopKioskBar(
                    stopName = viewModel.repository.stopName,
                    stopIndicator = viewModel.repository.stopIndicator,
                    stopCode = viewModel.repository.stopCode,
                    currentTime = currentTime,
                    currentDate = currentDate,
                    weatherTemp = viewModel.weatherTemp,
                    weatherDesc = viewModel.weatherDesc,
                    airQuality = viewModel.airQuality,
                    isAudioAnnouncementsOn = speechAnnouncements,
                    onAudioAnnouncementClick = {
                        triggerHapticFeedback()
                        viewModel.toggleSpeechAnnouncements()
                        val topArrivals = arrivals.take(3).joinToString(". ") {
                            "Route ${it.routeNumber} to ${it.destination} in ${it.minutesAway} minutes"
                        }
                        onSpeakArrivals("Next departures from stop Westminster Bridge Road: $topArrivals")
                    },
                    onAdminClick = {
                        triggerHapticFeedback()
                        viewModel.openDialog(KioskDialog.ADMIN_DIAGNOSTICS)
                    },
                    onSosClick = {
                        triggerHapticFeedback()
                        Toast.makeText(context, "Emergency Help Point activated. Transmitting shelter location.", Toast.LENGTH_LONG).show()
                    },
                    onTicketWalletClick = {
                        triggerHapticFeedback()
                        viewModel.openDialog(KioskDialog.TICKET_WALLET)
                    },
                    ticketCount = purchasedTickets.size
                )

                Spacer(modifier = Modifier.height(4.dp))

                if (isWideLayout) {
                    // Landscape 16:9 / 16:10 Bus Shelter Terminal Layout
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Left Half: Next buses departure board
                        LiveArrivalBoard(
                            arrivals = arrivals,
                            onSeeAllDepartures = {
                                triggerHapticFeedback()
                                viewModel.openDialog(KioskDialog.ALL_DEPARTURES)
                            },
                            onArrivalClick = { arr ->
                                triggerHapticFeedback()
                                val matchedRoute = routes.find { it.routeNumber == arr.routeNumber }
                                if (matchedRoute != null) {
                                    viewModel.selectRoute(matchedRoute)
                                }
                            },
                            modifier = Modifier.weight(1.05f)
                        )

                        // Right Half: Top = Interactive Map, Bottom = Quick Actions
                        Column(
                            modifier = Modifier
                                .weight(0.95f)
                                .fillMaxHeight(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            RouteMapCanvas(
                                selectedRoute = selectedRoute,
                                allRoutes = routes,
                                onSelectRoute = { route ->
                                    triggerHapticFeedback()
                                    viewModel.selectRoute(route)
                                },
                                modifier = Modifier.weight(1f)
                            )

                            QuickActionTiles(
                                onBuyTickets = {
                                    triggerHapticFeedback()
                                    viewModel.openDialog(KioskDialog.BUY_TICKETS)
                                },
                                onPlanJourney = {
                                    triggerHapticFeedback()
                                    viewModel.openDialog(KioskDialog.PLAN_JOURNEY)
                                },
                                onLocalArea = {
                                    triggerHapticFeedback()
                                    viewModel.openDialog(KioskDialog.LOCAL_AREA)
                                },
                                onAccessibility = {
                                    triggerHapticFeedback()
                                    viewModel.openDialog(KioskDialog.ACCESSIBILITY)
                                }
                            )
                        }
                    }
                } else {
                    // Portrait / Handheld Responsive Fallback Layout
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        LiveArrivalBoard(
                            arrivals = arrivals,
                            onSeeAllDepartures = {
                                triggerHapticFeedback()
                                viewModel.openDialog(KioskDialog.ALL_DEPARTURES)
                            },
                            onArrivalClick = { arr ->
                                triggerHapticFeedback()
                                routes.find { it.routeNumber == arr.routeNumber }?.let { viewModel.selectRoute(it) }
                            },
                            modifier = Modifier.height(290.dp)
                        )

                        RouteMapCanvas(
                            selectedRoute = selectedRoute,
                            allRoutes = routes,
                            onSelectRoute = { route ->
                                triggerHapticFeedback()
                                viewModel.selectRoute(route)
                            },
                            modifier = Modifier.height(220.dp)
                        )

                        QuickActionTiles(
                            onBuyTickets = {
                                triggerHapticFeedback()
                                viewModel.openDialog(KioskDialog.BUY_TICKETS)
                            },
                            onPlanJourney = {
                                triggerHapticFeedback()
                                viewModel.openDialog(KioskDialog.PLAN_JOURNEY)
                            },
                            onLocalArea = {
                                triggerHapticFeedback()
                                viewModel.openDialog(KioskDialog.LOCAL_AREA)
                            },
                            onAccessibility = {
                                triggerHapticFeedback()
                                viewModel.openDialog(KioskDialog.ACCESSIBILITY)
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Bottom Civic ticker: "A cleaner, greener London"
                CivicBanner(modifier = Modifier.padding(horizontal = 8.dp))
            }
        }

        // Active Dialog Overlays
        when (activeDialog) {
            KioskDialog.BUY_TICKETS -> {
                TicketPurchaseDialog(
                    selectedTicket = selectedTicketForPurchase,
                    terminalState = terminalState,
                    issuedTicket = activeIssuedTicket,
                    inactivitySeconds = inactivitySeconds,
                    onSelectTicket = { type ->
                        triggerHapticFeedback()
                        viewModel.selectTicketType(type)
                    },
                    onTapMethod = { method ->
                        triggerHapticFeedback()
                        viewModel.simulateTapPayment(method) { ticket ->
                            triggerHapticFeedback()
                            Toast.makeText(context, "Payment Authorised • Ticket Ref: ${ticket.ticketRef}", Toast.LENGTH_SHORT).show()
                        }
                    },
                    onPrintReceipt = {
                        triggerHapticFeedback()
                        Toast.makeText(context, "Printing physical ticket on shelter thermal printer...", Toast.LENGTH_LONG).show()
                    },
                    onDismiss = {
                        triggerHapticFeedback()
                        viewModel.dismissDialog()
                    }
                )
            }

            KioskDialog.PLAN_JOURNEY -> {
                JourneyPlannerDialog(
                    searchQuery = searchQuery,
                    isStepFreeOnly = stepFreeOnly,
                    results = journeyResults,
                    selectedJourney = selectedJourney,
                    inactivitySeconds = inactivitySeconds,
                    onQueryChange = { q -> viewModel.onSearchQueryChanged(q) },
                    onToggleStepFree = {
                        triggerHapticFeedback()
                        viewModel.toggleStepFreeOnly()
                    },
                    onSelectJourney = { j ->
                        triggerHapticFeedback()
                        viewModel.selectJourney(j)
                    },
                    onBuyTicketForJourney = { j ->
                        triggerHapticFeedback()
                        viewModel.openDialog(KioskDialog.BUY_TICKETS)
                    },
                    onDismiss = {
                        triggerHapticFeedback()
                        viewModel.dismissDialog()
                    }
                )
            }

            KioskDialog.LOCAL_AREA -> {
                LocalAreaDialog(
                    amenities = viewModel.amenities,
                    disruptions = viewModel.disruptions,
                    inactivitySeconds = inactivitySeconds,
                    onDismiss = {
                        triggerHapticFeedback()
                        viewModel.dismissDialog()
                    }
                )
            }

            KioskDialog.ACCESSIBILITY -> {
                AccessibilityDialog(
                    isHighContrast = isHighContrast,
                    isLargeText = isLargeText,
                    isAudioAnnouncementsOn = speechAnnouncements,
                    selectedLanguage = selectedLanguage,
                    inactivitySeconds = inactivitySeconds,
                    onToggleHighContrast = {
                        triggerHapticFeedback()
                        viewModel.toggleHighContrast()
                    },
                    onToggleLargeText = {
                        triggerHapticFeedback()
                        viewModel.toggleLargeText()
                    },
                    onToggleAudioAnnouncements = {
                        triggerHapticFeedback()
                        viewModel.toggleSpeechAnnouncements()
                    },
                    onSelectLanguage = { lang ->
                        triggerHapticFeedback()
                        viewModel.setLanguage(lang)
                        Toast.makeText(context, "Language set to ${lang.label}", Toast.LENGTH_SHORT).show()
                    },
                    onDismiss = {
                        triggerHapticFeedback()
                        viewModel.dismissDialog()
                    }
                )
            }

            KioskDialog.ALL_DEPARTURES -> {
                AllDeparturesDialog(
                    arrivals = arrivals,
                    inactivitySeconds = inactivitySeconds,
                    onDismiss = {
                        triggerHapticFeedback()
                        viewModel.dismissDialog()
                    }
                )
            }

            KioskDialog.ADMIN_DIAGNOSTICS -> {
                AdminDiagnosticsDialog(
                    telemetry = telemetry,
                    onDismiss = {
                        triggerHapticFeedback()
                        viewModel.dismissDialog()
                    }
                )
            }

            KioskDialog.TICKET_WALLET -> {
                TicketWalletDialog(
                    tickets = purchasedTickets,
                    inactivitySeconds = inactivitySeconds,
                    onPrintReceipt = { ticket ->
                        triggerHapticFeedback()
                        Toast.makeText(context, "Printing receipt for ${ticket.ticketRef}...", Toast.LENGTH_SHORT).show()
                    },
                    onDismiss = {
                        triggerHapticFeedback()
                        viewModel.dismissDialog()
                    }
                )
            }

            KioskDialog.NONE, KioskDialog.SOS_EMERGENCY -> {}
        }
    }
}
