package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BusRoute
import com.example.ui.theme.*

@Composable
fun RouteMapCanvas(
    selectedRoute: BusRoute,
    allRoutes: List<BusRoute>,
    onSelectRoute: (BusRoute) -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "bus_pulse")
    val pulseProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse"
    )

    Card(
        modifier = modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, TransportGlassBorder, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF091422)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            // Header: Route selector tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Interactive Route Map",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Route pills
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    allRoutes.forEach { route ->
                        val isSelected = route.routeNumber == selectedRoute.routeNumber
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) Color(route.colorHex) else Color.White.copy(alpha = 0.08f))
                                .clickable { onSelectRoute(route) }
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                                .testTag("route_tab_${route.routeNumber}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = route.routeNumber,
                                color = if (isSelected) Color.White else TextSecondary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Canvas drawing the schematic map
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF060D17))
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    // 1. Draw River Thames curve (Blue fluid path)
                    val thamesPath = Path().apply {
                        moveTo(0f, h * 0.45f)
                        cubicTo(
                            w * 0.25f, h * 0.40f,
                            w * 0.45f, h * 0.58f,
                            w * 0.70f, h * 0.52f
                        )
                        cubicTo(
                            w * 0.85f, h * 0.48f,
                            w * 0.95f, h * 0.35f,
                            w, h * 0.30f
                        )
                    }
                    drawPath(
                        path = thamesPath,
                        color = Color(0xFF0D253F),
                        style = Stroke(width = 38f, cap = StrokeCap.Round)
                    )

                    // 2. Draw Bridges (Westminster Bridge, Waterloo Bridge)
                    val westminsterBridgeX = w * 0.48f
                    drawLine(
                        color = Color(0xFF334A65),
                        start = Offset(westminsterBridgeX - 10f, h * 0.42f),
                        end = Offset(westminsterBridgeX + 15f, h * 0.62f),
                        strokeWidth = 6f
                    )

                    // 3. Draw Selected Route line
                    val routePath = Path()
                    val stops = selectedRoute.stops
                    if (stops.isNotEmpty()) {
                        val first = stops.first()
                        routePath.moveTo(first.xRatio * w, first.yRatio * h)
                        for (i in 1 until stops.size) {
                            val stop = stops[i]
                            routePath.lineTo(stop.xRatio * w, stop.yRatio * h)
                        }
                    }

                    // Shadow / glow for route
                    drawPath(
                        path = routePath,
                        color = Color(selectedRoute.colorHex).copy(alpha = 0.3f),
                        style = Stroke(width = 12f, cap = StrokeCap.Round)
                    )
                    // Core route stroke
                    drawPath(
                        path = routePath,
                        color = Color(selectedRoute.colorHex),
                        style = Stroke(width = 5f, cap = StrokeCap.Round)
                    )

                    // 4. Draw Stops
                    stops.forEach { stop ->
                        val sx = stop.xRatio * w
                        val sy = stop.yRatio * h

                        if (stop.isShelterLocation) {
                            // Pulsing radar ring around current shelter
                            drawCircle(
                                color = LiveArrivalGreen.copy(alpha = 1f - pulseProgress),
                                radius = 10f + (pulseProgress * 22f),
                                center = Offset(sx, sy),
                                style = Stroke(width = 2.5f)
                            )
                            // Solid center for shelter
                            drawCircle(
                                color = LiveArrivalGreen,
                                radius = 9f,
                                center = Offset(sx, sy)
                            )
                            drawCircle(
                                color = TransportNavyDark,
                                radius = 4f,
                                center = Offset(sx, sy)
                            )
                        } else {
                            // Regular stop node
                            drawCircle(
                                color = Color.White,
                                radius = 6f,
                                center = Offset(sx, sy)
                            )
                            drawCircle(
                                color = Color(selectedRoute.colorHex),
                                radius = 3.5f,
                                center = Offset(sx, sy)
                            )
                        }
                    }

                    // 5. Draw animated Bus Vehicle advancing along route
                    if (stops.size >= 2) {
                        val totalSegments = stops.size - 1
                        val globalProgress = (pulseProgress * totalSegments)
                        val segIndex = globalProgress.toInt().coerceIn(0, totalSegments - 1)
                        val segProgress = globalProgress - segIndex

                        val p1 = stops[segIndex]
                        val p2 = stops[segIndex + 1]
                        val busX = (p1.xRatio + (p2.xRatio - p1.xRatio) * segProgress) * w
                        val busY = (p1.yRatio + (p2.yRatio - p1.yRatio) * segProgress) * h

                        drawCircle(
                            color = Color(0xFFDC241F),
                            radius = 8f,
                            center = Offset(busX, busY)
                        )
                        drawCircle(
                            color = Color.White,
                            radius = 4f,
                            center = Offset(busX, busY)
                        )
                    }
                }

                // Overlay badge for shelter location
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color.Black.copy(alpha = 0.7f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(LiveArrivalGreen)
                        )
                        Text(
                            text = "You are here (Westminster Bridge Rd)",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Route summary footer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${selectedRoute.origin} ➔ ${selectedRoute.destination}",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Every ${selectedRoute.frequencyMinutes} mins",
                    color = LiveArrivalGreen,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
