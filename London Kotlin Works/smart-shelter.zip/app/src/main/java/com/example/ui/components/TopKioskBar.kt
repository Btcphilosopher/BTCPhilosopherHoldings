package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun TopKioskBar(
    stopName: String,
    stopIndicator: String,
    stopCode: String,
    currentTime: String,
    currentDate: String,
    weatherTemp: String,
    weatherDesc: String,
    airQuality: String,
    isAudioAnnouncementsOn: Boolean,
    onAudioAnnouncementClick: () -> Unit,
    onAdminClick: () -> Unit,
    onSosClick: () -> Unit,
    onTicketWalletClick: () -> Unit,
    ticketCount: Int,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left side: TfL Crest / Roundel + Stop Name + Indicator
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // TfL British Transport Roundel
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF0019A8))
                    .border(3.dp, Color(0xFFDC241F), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .height(10.dp)
                        .background(Color(0xFFDC241F))
                )
                Text(
                    text = "TfL",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 11.sp
                )
            }

            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Transport for London",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )

                    // Red Stop Indicator Pill
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(TfLRed)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = stopIndicator,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }

                Text(
                    text = stopName,
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = (-0.5).sp
                )

                Text(
                    text = "Stop ID: $stopCode • 5G Live Connected",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }

        // Right side: Audio, SOS, Wallet, Weather, Time
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Audio Announcements Button
            IconButton(
                onClick = onAudioAnnouncementClick,
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(if (isAudioAnnouncementsOn) LiveArrivalGreen.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.08f))
                    .border(1.dp, if (isAudioAnnouncementsOn) LiveArrivalGreen else Color.White.copy(alpha = 0.15f), CircleShape)
                    .testTag("audio_announcement_button")
            ) {
                Icon(
                    imageVector = if (isAudioAnnouncementsOn) Icons.Filled.VolumeUp else Icons.Outlined.VolumeUp,
                    contentDescription = "Read Next Bus Arrivals Aloud",
                    tint = if (isAudioAnnouncementsOn) LiveArrivalGreen else Color.White
                )
            }

            // Ticket Wallet Button (shows badge if user purchased tickets)
            BadgedBox(
                badge = {
                    if (ticketCount > 0) {
                        Badge(
                            containerColor = LiveArrivalGreen,
                            contentColor = TransportNavyDark
                        ) {
                            Text(ticketCount.toString(), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            ) {
                IconButton(
                    onClick = onTicketWalletClick,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.08f))
                        .border(1.dp, Color.White.copy(alpha = 0.15f), CircleShape)
                        .testTag("ticket_wallet_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.ConfirmationNumber,
                        contentDescription = "Active Travel Tickets",
                        tint = Color.White
                    )
                }
            }

            // Weather & AQI Box
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White.copy(alpha = 0.06f))
                    .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.CloudQueue,
                    contentDescription = "Weather",
                    tint = Color(0xFF60A5FA),
                    modifier = Modifier.size(20.dp)
                )
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "$weatherTemp $weatherDesc",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "AQI: $airQuality",
                        color = LiveArrivalGreen,
                        fontSize = 10.sp
                    )
                }
            }

            // Clock & Date Box
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = currentTime,
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = (-0.5).sp
                )
                Text(
                    text = currentDate,
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }

            // Admin Diagnostics Gear Icon
            IconButton(
                onClick = onAdminClick,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.05f))
                    .testTag("admin_kiosk_button")
            ) {
                Icon(
                    imageVector = Icons.Outlined.Settings,
                    contentDescription = "Shelter Terminal Diagnostics",
                    tint = TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
