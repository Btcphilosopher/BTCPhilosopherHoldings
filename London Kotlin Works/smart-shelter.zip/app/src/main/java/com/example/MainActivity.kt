package com.example

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ui.screens.MainKioskScreen
import com.example.ui.theme.SmartShelterTheme
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private val kioskViewModel: KioskViewModel by viewModels()
    private var textToSpeech: TextToSpeech? = null
    private var isTtsInitialized = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        try {
            textToSpeech = TextToSpeech(this, this)
        } catch (_: Exception) {
            isTtsInitialized = false
        }

        setContent {
            val isHighContrast by kioskViewModel.isHighContrast.collectAsState()

            SmartShelterTheme(isHighContrast = isHighContrast) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MainKioskScreen(
                        viewModel = kioskViewModel,
                        onSpeakArrivals = { text ->
                            speakText(text)
                        }
                    )
                }
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            textToSpeech?.language = Locale.UK
            isTtsInitialized = true
        }
    }

    private fun speakText(text: String) {
        if (isTtsInitialized && textToSpeech != null) {
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "KIOSK_TTS_UTTERANCE")
        }
    }

    override fun onDestroy() {
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        super.onDestroy()
    }
}
