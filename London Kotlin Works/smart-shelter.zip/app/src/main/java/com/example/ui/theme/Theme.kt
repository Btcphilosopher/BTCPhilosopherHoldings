package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NormalColorScheme = darkColorScheme(
    primary = LiveArrivalGreen,
    onPrimary = TransportNavyDark,
    primaryContainer = TransportNavyContainer,
    onPrimaryContainer = TextPrimary,
    secondary = TfLRed,
    onSecondary = Color.White,
    secondaryContainer = Color(0x33DC241F),
    onSecondaryContainer = Color(0xFFFFCDD2),
    tertiary = TfLBlue,
    onTertiary = Color.White,
    background = TransportNavyDark,
    onBackground = TextPrimary,
    surface = TransportNavySurface,
    onSurface = TextPrimary,
    surfaceVariant = TransportGlassSurface,
    onSurfaceVariant = TextSecondary,
    outline = TransportGlassBorder
)

private val HighContrastColorScheme = darkColorScheme(
    primary = HighContrastYellow,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF222200),
    onPrimaryContainer = HighContrastYellow,
    secondary = HighContrastWhite,
    onSecondary = Color.Black,
    secondaryContainer = Color.DarkGray,
    onSecondaryContainer = HighContrastWhite,
    tertiary = HighContrastYellow,
    background = HighContrastBg,
    onBackground = HighContrastWhite,
    surface = Color.Black,
    onSurface = HighContrastWhite,
    surfaceVariant = Color(0xFF1A1A1A),
    onSurfaceVariant = HighContrastYellow,
    outline = HighContrastYellow
)

@Composable
fun SmartShelterTheme(
    isHighContrast: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (isHighContrast) HighContrastColorScheme else NormalColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
