package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BusArrival
import com.example.model.CrowdingLevel
import com.example.ui.theme.*

@Composable
fun LiveArrivalBoard(
    arrivals: List<BusArrival>,
    onSeeAllDepartures: () -> Unit,
    onArrivalClick: (BusArrival) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, TransportGlassBorder, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(
            containerColor = TransportGlassSurface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(LiveArrivalGreen)
                    )
                    Text(
                        text = "Next buses",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-0.3).sp
                    )
                }

                // Live indicator badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(LiveArrivalGreen.copy(alpha = 0.15f))
                        .border(1.dp, LiveArrivalGreen.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Sensors,
                        contentDescription = "Real-time BODS live telemetry",
                        tint = LiveArrivalGreen,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "LIVE",
                        color = LiveArrivalGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Arrivals List
            val displayList = arrivals.take(5)
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(displayList, key = { it.id }) { arrival ->
                    ArrivalItemRow(
                        arrival = arrival,
                        onClick = { onArrivalClick(arrival) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Footer: "See all departures ->"
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onSeeAllDepartures() }
                    .padding(vertical = 8.dp, horizontal = 4.dp)
                    .testTag("see_all_departures_button"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "See all departures & timetables",
                    color = Color(0xFF60A5FA),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = null,
                    tint = Color(0xFF60A5FA),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun ArrivalItemRow(
    arrival: BusArrival,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White.copy(alpha = 0.04f))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Route number and Destination
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.weight(1f)
        ) {
            // Route number badge
            Text(
                text = arrival.routeNumber,
                color = Color.White,
                fontSize = 26.sp,
                fontWeight = FontWeight.Black,
                modifier = Modifier.widthIn(min = 52.dp)
            )

            Column {
                Text(
                    text = arrival.destination,
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (arrival.intermediateVia != null) {
                        Text(
                            text = arrival.intermediateVia,
                            color = TextSecondary,
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                    }

                    // Feature badges
                    if (arrival.isElectricZeroEmission) {
                        Icon(
                            imageVector = Icons.Filled.ElectricBolt,
                            contentDescription = "Zero Emission Electric",
                            tint = LiveArrivalGreen,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                    if (arrival.isWheelchairAccessible) {
                        Icon(
                            imageVector = Icons.Filled.Accessible,
                            contentDescription = "Wheelchair Accessible",
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }
            }
        }

        // Live Minutes Countdown Pill
        Column(
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.Center
        ) {
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                if (arrival.minutesAway <= 0) {
                    Text(
                        text = "Due",
                        color = WarningAmber,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black
                    )
                } else {
                    Text(
                        text = "${arrival.minutesAway}",
                        color = LiveArrivalGreen,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "min",
                        color = LiveArrivalGreen,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                }
            }

            // Crowding indication
            val (crowdText, crowdColor) = when (arrival.crowding) {
                CrowdingLevel.LOW -> "Seats available" to TextSecondary
                CrowdingLevel.MEDIUM -> "Standing only" to WarningAmber
                CrowdingLevel.HIGH -> "Busy" to DisruptionRed
            }
            Text(
                text = crowdText,
                color = crowdColor,
                fontSize = 10.sp
            )
        }
    }
}
