package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.CreditCard
import androidx.compose.material.icons.outlined.PhoneIphone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PaymentMethod
import com.example.model.PaymentTerminalState
import com.example.ui.theme.*

@Composable
fun NfcReaderPad(
    terminalState: PaymentTerminalState,
    onTapMethod: (PaymentMethod) -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "nfc_rings")
    val waveProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, Color(0xFF1E3A5F), RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF071322)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // EMV 4-LED standard row
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val (led1, led2, led3, led4) = when (terminalState) {
                    PaymentTerminalState.IDLE -> listOf(Color.DarkGray, Color.DarkGray, Color.DarkGray, Color.DarkGray)
                    PaymentTerminalState.PROMPTING_TAP -> listOf(Color(0xFF38BDF8), Color.DarkGray, Color.DarkGray, Color.DarkGray)
                    PaymentTerminalState.READING_CARD -> listOf(Color(0xFF38BDF8), Color(0xFF38BDF8), Color.DarkGray, Color.DarkGray)
                    PaymentTerminalState.AUTHORISING_TRANSACTION -> listOf(Color(0xFF38BDF8), Color(0xFF38BDF8), Color(0xFFFBBF24), Color.DarkGray)
                    PaymentTerminalState.APPROVED -> listOf(LiveArrivalGreen, LiveArrivalGreen, LiveArrivalGreen, LiveArrivalGreen)
                    PaymentTerminalState.DECLINED -> listOf(DisruptionRed, DisruptionRed, DisruptionRed, DisruptionRed)
                    PaymentTerminalState.TIMED_OUT -> listOf(WarningAmber, WarningAmber, Color.DarkGray, Color.DarkGray)
                }

                Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(led1))
                Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(led2))
                Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(led3))
                Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(led4))
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Animated NFC Contactless Target Canvas
            Box(
                modifier = Modifier
                    .size(110.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF0F2642))
                    .border(2.dp, Color(0xFF38BDF8).copy(alpha = 0.5f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (terminalState == PaymentTerminalState.PROMPTING_TAP || terminalState == PaymentTerminalState.READING_CARD) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val center = Offset(size.width / 2f, size.height / 2f)
                        drawCircle(
                            color = Color(0xFF38BDF8).copy(alpha = 1f - waveProgress),
                            radius = 24f + (waveProgress * 30f),
                            center = center,
                            style = Stroke(width = 3f)
                        )
                    }
                }

                Icon(
                    imageVector = Icons.Default.Nfc,
                    contentDescription = "Contactless NFC Target",
                    tint = if (terminalState == PaymentTerminalState.APPROVED) LiveArrivalGreen else Color(0xFF38BDF8),
                    modifier = Modifier.size(54.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Terminal Status Text
            val (statusText, statusColor) = when (terminalState) {
                PaymentTerminalState.IDLE -> "Terminal Ready" to TextSecondary
                PaymentTerminalState.PROMPTING_TAP -> "Tap Card, Phone or Oyster Card Here" to Color.White
                PaymentTerminalState.READING_CARD -> "Reading Contactless EMV Device..." to Color(0xFF38BDF8)
                PaymentTerminalState.AUTHORISING_TRANSACTION -> "Authorising with TfL Payment Gateway..." to Color(0xFFFBBF24)
                PaymentTerminalState.APPROVED -> "Payment Approved • Issuing Travel Credential" to LiveArrivalGreen
                PaymentTerminalState.DECLINED -> "Card Declined • Please try another card" to DisruptionRed
                PaymentTerminalState.TIMED_OUT -> "Transaction Timed Out" to WarningAmber
            }

            Text(
                text = statusText,
                color = statusColor,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            Text(
                text = "Certified EMV Level 2 • PCI-DSS End-to-End Encrypted",
                color = TextSecondary,
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Tap Simulator Buttons (for real interactive testing on the terminal)
            if (terminalState == PaymentTerminalState.PROMPTING_TAP) {
                Text(
                    text = "SELECT TAP INTERACTION TO SIMULATE:",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onTapMethod(PaymentMethod.CONTACTLESS_EMV) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tap_contactless_card"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A5F)),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp)
                    ) {
                        Icon(Icons.Outlined.CreditCard, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Card Tap", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { onTapMethod(PaymentMethod.APPLE_PAY) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tap_apple_pay"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A5F)),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp)
                    ) {
                        Icon(Icons.Outlined.PhoneIphone, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Apple Pay", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { onTapMethod(PaymentMethod.GOOGLE_PAY) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tap_google_pay"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A5F)),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp)
                    ) {
                        Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Google Pay", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { onTapMethod(PaymentMethod.OYSTER_CARD) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tap_oyster_card"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0019A8)),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp)
                    ) {
                        Text("Oyster", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}
