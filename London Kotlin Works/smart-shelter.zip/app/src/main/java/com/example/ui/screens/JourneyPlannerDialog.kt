package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.JourneyOption
import com.example.ui.theme.*

@Composable
fun JourneyPlannerDialog(
    searchQuery: String,
    isStepFreeOnly: Boolean,
    results: List<JourneyOption>,
    selectedJourney: JourneyOption?,
    inactivitySeconds: Int,
    onQueryChange: (String) -> Unit,
    onToggleStepFree: () -> Unit,
    onSelectJourney: (JourneyOption) -> Unit,
    onBuyTicketForJourney: (JourneyOption) -> Unit,
    onDismiss: () -> Unit
) {
    val quickDestinations = listOf("Oxford Circus", "Waterloo", "Camden Town", "Covent Garden", "London Bridge", "Victoria")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.85f))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .fillMaxHeight(0.90f)
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, TransportGlassBorder, RoundedCornerShape(20.dp)),
                colors = CardDefaults.cardColors(containerColor = TransportNavyDark)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "London Journey Planner",
                                color = Color.White,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Departing from Westminster Bridge Road (Stop B) • Closes in ${inactivitySeconds}s",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.1f))
                                .testTag("close_journey_dialog_button")
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Search input & Step-Free filter
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = onQueryChange,
                            placeholder = { Text("Search street, station, landmark...", color = TextSecondary, fontSize = 14.sp) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color.White) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { onQueryChange("") }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondary)
                                    }
                                }
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF0C192C),
                                unfocusedContainerColor = Color(0xFF0C192C),
                                focusedBorderColor = Color(0xFF60A5FA),
                                unfocusedBorderColor = TransportGlassBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("journey_search_input")
                        )

                        // Step-free filter chip
                        FilterChip(
                            selected = isStepFreeOnly,
                            onClick = onToggleStepFree,
                            label = { Text("Step-Free Only", fontSize = 13.sp) },
                            leadingIcon = {
                                Icon(Icons.Filled.Accessible, contentDescription = null, modifier = Modifier.size(16.dp))
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = LiveArrivalGreen,
                                selectedLabelColor = TransportNavyDark,
                                containerColor = Color(0xFF0C192C),
                                labelColor = Color.White
                            ),
                            modifier = Modifier.testTag("filter_step_free_button")
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Quick suggestion pills
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(quickDestinations) { dest ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.White.copy(alpha = 0.08f))
                                    .clickable { onQueryChange(dest) }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                                    .testTag("quick_dest_$dest")
                            ) {
                                Text(dest, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Results List & Detail View
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Left: Journey Results
                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(results, key = { it.id }) { journey ->
                                val isSelected = selectedJourney?.id == journey.id
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .border(
                                            width = if (isSelected) 2.dp else 1.dp,
                                            color = if (isSelected) Color(0xFF60A5FA) else TransportGlassBorder,
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .clickable { onSelectJourney(journey) }
                                        .testTag("journey_card_${journey.id}"),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isSelected) Color(0xFF142742) else Color(0xFF0C192C)
                                    )
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = journey.destinationName,
                                                color = Color.White,
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "${journey.totalDurationMinutes} mins",
                                                color = LiveArrivalGreen,
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(4.dp))

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "${journey.departureTime} ➔ ${journey.arrivalTime} • ${journey.primaryRoute}",
                                                color = TextSecondary,
                                                fontSize = 12.sp
                                            )
                                            Text(
                                                text = "£%.2f".format(journey.farePounds),
                                                color = Color(0xFFFDE047),
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Right: Detailed itinerary legs
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0C192C)),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            if (selectedJourney != null) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(16.dp),
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            text = "ITINERARY BREAKDOWN:",
                                            color = TextSecondary,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 1.sp
                                        )

                                        Spacer(modifier = Modifier.height(10.dp))

                                        selectedJourney.legs.forEachIndexed { index, leg ->
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 6.dp),
                                                verticalAlignment = Alignment.Top,
                                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(28.dp)
                                                        .clip(CircleShape)
                                                        .background(if (leg.mode == "BUS") TfLRed else Color(0xFF2563EB)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = if (leg.mode == "BUS") Icons.Default.DirectionsBus else Icons.Default.DirectionsWalk,
                                                        contentDescription = null,
                                                        tint = Color.White,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }

                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = leg.instruction,
                                                        color = Color.White,
                                                        fontSize = 13.sp,
                                                        fontWeight = FontWeight.Medium
                                                    )
                                                    Text(
                                                        text = "${leg.durationMinutes} mins${if (leg.stopsCount > 0) " (${leg.stopsCount} stops)" else ""}",
                                                        color = TextSecondary,
                                                        fontSize = 11.sp
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    Button(
                                        onClick = { onBuyTicketForJourney(selectedJourney) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("buy_ticket_for_journey_button"),
                                        colors = ButtonDefaults.buttonColors(containerColor = LiveArrivalGreen),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text(
                                            text = "Buy Hopper Ticket (£1.75)",
                                            color = TransportNavyDark,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                    }
                                }
                            } else {
                                Box(
                                    modifier = Modifier.fillMaxSize(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "Select a journey to view step-by-step route and interchange details",
                                        color = TextSecondary,
                                        fontSize = 13.sp,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                        modifier = Modifier.padding(24.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
