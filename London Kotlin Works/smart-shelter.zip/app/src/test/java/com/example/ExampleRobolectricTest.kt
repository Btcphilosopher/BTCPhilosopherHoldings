package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.PaymentTerminalService
import com.example.data.TransportRepository
import com.example.model.PaymentMethod
import com.example.model.PaymentTerminalState
import com.example.model.TicketType
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context verifies Smart Shelter app name`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Smart Shelter", appName)
    }

    @Test
    fun `transport repository contains Westminster Bridge Road routes`() {
        val repo = TransportRepository()
        assertEquals("Westminster Bridge Road", repo.stopName)
        assertEquals("490000253E", repo.stopCode)

        val routes = repo.getBusRoutes()
        assertTrue(routes.any { it.routeNumber == "12" })
        assertTrue(routes.any { it.routeNumber == "148" })
        assertTrue(routes.any { it.routeNumber == "211" })
        assertTrue(routes.any { it.routeNumber == "453" })
    }

    @Test
    fun `payment terminal completes EMV contactless flow and issues verified ticket`() = runTest {
        val terminal = PaymentTerminalService()
        assertEquals(PaymentTerminalState.IDLE, terminal.terminalState.value)

        // Initiate payment for Single Bus Hopper (£1.75)
        terminal.initiatePayment(TicketType.SINGLE_BUS_HOPPER)
        assertEquals(PaymentTerminalState.PROMPTING_TAP, terminal.terminalState.value)

        // Tap Contactless Card
        val result = terminal.processContactlessTap(PaymentMethod.CONTACTLESS_EMV)
        assertTrue(result.isSuccess)

        val ticket = result.getOrNull()
        assertNotNull(ticket)
        assertEquals(TicketType.SINGLE_BUS_HOPPER, ticket!!.ticketType)
        assertEquals(1.75, ticket.farePaid, 0.001)
        assertTrue(ticket.ticketRef.startsWith("TFL-BUS-"))
        assertTrue(ticket.paymentTransactionId.startsWith("TXN-"))
        assertEquals(PaymentTerminalState.APPROVED, terminal.terminalState.value)
    }

    @Test
    fun `journey search returns step free routes to Oxford Circus`() {
        val repo = TransportRepository()
        val results = repo.searchJourneys("Oxford Circus", stepFreeOnly = true)
        assertFalse(results.isEmpty())
        val topResult = results.first()
        assertEquals("Oxford Circus", topResult.destinationName)
        assertTrue(topResult.isStepFree)
        assertEquals(1.75, topResult.farePounds, 0.001)
    }
}
