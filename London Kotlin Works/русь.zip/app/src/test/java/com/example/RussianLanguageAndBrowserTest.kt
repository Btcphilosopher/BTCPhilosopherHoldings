package com.example

import com.example.ai.RusAiCore
import com.example.engine.BundledPortals
import com.example.language.LanguageRegistry
import com.example.language.RussianMorphologyEngine
import com.example.language.RussianSpellcheck
import com.example.language.RussianTypographyEngine
import com.example.language.TranslationEngine
import com.example.language.TransliterationEngine
import com.example.model.CitationStyle
import com.example.model.ResearchItem
import com.example.search.SearchCore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RussianLanguageAndBrowserTest {

    @Test
    fun testRussianTypography() {
        // Проверка замены прямых кавычек на русские «ёлочки»
        val quotesTest = RussianTypographyEngine.typograph("\"Русский текст\"")
        assertEquals("«Русский текст»", quotesTest)

        // Проверка длинного тире между городами: Москва - Санкт-Петербург -> Москва — Санкт-Петербург
        val dashTest = RussianTypographyEngine.typograph("Москва - Санкт-Петербург")
        assertTrue(dashTest.contains("—"))

        // Проверка неразрывных пробелов в больших числах и ₽
        val numberTest = RussianTypographyEngine.typograph("100 000 000 человек")
        assertTrue(numberTest.contains("\u00A0"))

        val currencyTest = RussianTypographyEngine.typograph("Цена: 1 250 000 ₽")
        assertTrue(currencyTest.contains("\u00A0₽") || currencyTest.contains("₽"))

        // Проверка диапазона дат (среднее тире)
        val rangeTest = RussianTypographyEngine.typograph("1941-1945 гг.")
        assertTrue(rangeTest.contains("1941–1945"))
    }

    @Test
    fun testTransliteration() {
        // Латиница -> Кириллица: privet mir -> привет мир
        val cyrillic = TransliterationEngine.latinToCyrillic("privet mir")
        assertEquals("привет мир", cyrillic)

        // Кириллица -> Латиница: Москва -> Moskva
        val latin = TransliterationEngine.cyrillicToLatin("Москва")
        assertEquals("Moskva", latin)

        // Восстановление раскладки: ghbdtn vbh -> привет мир
        val fixedLayout = TransliterationEngine.fixKeyboardLayout("ghbdtn vbh")
        assertEquals("привет мир", fixedLayout)
    }

    @Test
    fun testRussianMorphologyAndSearch() {
        // Лемматизация: самолёты -> самолёт
        val lemma = RussianMorphologyEngine.lemmatize("самолёты")
        assertEquals("самолёт", lemma)

        // Морфологическое расширение запроса: "самолёты" содержит формы и синонимы
        val terms = RussianMorphologyEngine.expandSearchTerms("самолёты")
        assertTrue(terms.contains("самолёт") || terms.contains("авиация"))

        // Умная строка обрабатывает математику: 125 * 17
        val suggestions = SearchCore.processInput("125 * 17")
        val mathItem = suggestions.find { it.badge == "Калькулятор" }
        assertNotNull(mathItem)
        assertTrue(mathItem!!.title.contains("2125"))
    }

    @Test
    fun testSpellcheck() {
        val fix1 = RussianSpellcheck.checkAndSuggest("превет мир")
        assertEquals("привет мир", fix1)

        val fix2 = RussianSpellcheck.checkAndSuggest("броузер")
        assertEquals("браузер", fix2)
    }

    @Test
    fun testAcademicCitationGOST() {
        val item = ResearchItem(
            url = "rus://demo/russian-language",
            title = "История кириллицы и русской типографики",
            author = "Институт языкознания РАН",
            publicationDate = "2026",
            sourceText = "Кириллическая строка отличается монументальностью."
        )

        val gostCitation = item.formatCitation(CitationStyle.GOST)
        assertTrue(gostCitation.contains("Институт языкознания РАН"))
        assertTrue(gostCitation.contains("ГОСТ") || gostCitation.contains("URL:"))
    }

    @Test
    fun testAiSummaryStrictSeparation() {
        val page = BundledPortals.PAGES[0]
        val analysis = RusAiCore.summarizePage(page)

        // Проверка: Источник и интерпретация строго разделены
        assertNotNull(analysis.sourceTitle)
        assertNotNull(analysis.aiInterpretation)
        assertTrue(analysis.sourceExcerpts.isNotEmpty())
        assertTrue(analysis.keyTakeaways.isNotEmpty())
    }
}
