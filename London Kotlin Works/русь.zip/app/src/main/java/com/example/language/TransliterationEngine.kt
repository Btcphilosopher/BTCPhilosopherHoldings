package com.example.language

object TransliterationEngine {

    enum class TranslitScheme {
        GOST_779_B, // ГОСТ 7.79-2000 (система Б)
        ISO_9,      // Международный стандарт ISO 9
        SEARCH_POPULAR // Поисковая интуитивная транслитерация
    }

    private val cyrToLatMulti = mapOf(
        "щ" to "shch", "Щ" to "Shch",
        "ш" to "sh", "Ш" to "Sh",
        "ч" to "ch", "Ч" to "Ch",
        "ж" to "zh", "Ж" to "Zh",
        "ю" to "yu", "Ю" to "Yu",
        "я" to "ya", "Я" to "Ya",
        "э" to "e", "Э" to "E",
        "ё" to "yo", "Ё" to "Yo",
        "ц" to "ts", "Ц" to "Ts",
        "х" to "kh", "Х" to "Kh"
    )

    private val cyrToLatSingle = mapOf(
        'а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d",
        'е' to "e", 'з' to "z", 'и' to "i", 'й' to "y", 'к' to "k",
        'л' to "l", 'м' to "m", 'н' to "n", 'о' to "o", 'п' to "p",
        'р' to "r", 'с' to "s", 'т' to "t", 'у' to "u", 'ф' to "f",
        'ъ' to "", 'ы' to "y", 'ь' to "",
        'А' to "A", 'Б' to "B", 'В' to "V", 'Г' to "G", 'Д' to "D",
        'Е' to "E", 'З' to "Z", 'И' to "I", 'Й' to "Y", 'К' to "K",
        'Л' to "L", 'М' to "M", 'Н' to "N", 'О' to "O", 'П' to "P",
        'Р' to "R", 'С' to "S", 'Т' to "T", 'У' to "U", 'Ф' to "F",
        'Ъ' to "", 'Ы' to "Y", 'Ь' to ""
    )

    private val latToCyrMulti = listOf(
        "shch" to "щ", "Shch" to "Щ", "SHCH" to "Щ",
        "sh" to "ш", "Sh" to "Ш", "SH" to "Ш",
        "ch" to "ч", "Ch" to "Ч", "CH" to "Ч",
        "zh" to "ж", "Zh" to "Ж", "ZH" to "Ж",
        "yu" to "ю", "Yu" to "Ю", "YU" to "Ю",
        "ya" to "я", "Ya" to "Я", "YA" to "Я",
        "yo" to "ё", "Yo" to "Ё", "YO" to "Ё",
        "ts" to "ц", "Ts" to "Ц", "TS" to "Ц",
        "kh" to "х", "Kh" to "Х", "KH" to "Х",
        "yy" to "ый", "Yy" to "Ый", "YY" to "ЫЙ",
        "x" to "кс", "X" to "Кс"
    )

    private val latToCyrSingle = mapOf(
        'a' to 'а', 'b' to 'б', 'v' to 'в', 'w' to 'в', 'g' to 'г', 'd' to 'д',
        'e' to 'е', 'z' to 'з', 'i' to 'и', 'j' to 'й', 'y' to 'ы', 'k' to 'к',
        'l' to 'л', 'm' to 'м', 'n' to 'н', 'o' to 'о', 'p' to 'п',
        'r' to 'р', 's' to 'с', 't' to 'т', 'u' to 'у', 'f' to 'ф', 'h' to 'х',
        'c' to 'ц',
        'A' to 'А', 'B' to 'Б', 'V' to 'В', 'W' to 'В', 'G' to 'Г', 'D' to 'Д',
        'E' to 'Е', 'Z' to 'З', 'I' to 'И', 'J' to 'Й', 'Y' to 'Ы', 'K' to 'К',
        'L' to 'Л', 'M' to 'М', 'N' to 'Н', 'O' to 'О', 'P' to 'П',
        'R' to 'Р', 'S' to 'С', 'T' to 'Т', 'U' to 'У', 'F' to 'Ф', 'H' to 'Х',
        'C' to 'Ц'
    )

    // Клавиатурная раскладка QWERTY -> ЙЦУКЕН
    private val qwertyToJcuken = mapOf(
        'q' to 'й', 'w' to 'ц', 'e' to 'у', 'r' to 'к', 't' to 'е', 'y' to 'н', 'u' to 'г', 'i' to 'ш', 'o' to 'щ', 'p' to 'з', '[' to 'х', ']' to 'ъ',
        'a' to 'ф', 's' to 'ы', 'd' to 'в', 'f' to 'а', 'g' to 'п', 'h' to 'р', 'j' to 'о', 'k' to 'л', 'l' to 'д', ';' to 'ж', '\'' to 'э',
        'z' to 'я', 'x' to 'ч', 'c' to 'с', 'v' to 'м', 'b' to 'и', 'n' to 'т', 'm' to 'ь', ',' to 'б', '.' to 'ю',
        'Q' to 'Й', 'W' to 'Ц', 'E' to 'У', 'R' to 'К', 'T' to 'Е', 'Y' to 'Н', 'U' to 'Г', 'I' to 'Ш', 'O' to 'Щ', 'P' to 'З', '{' to 'Х', '}' to 'Ъ',
        'A' to 'Ф', 'S' to 'Ы', 'D' to 'В', 'F' to 'А', 'G' to 'П', 'H' to 'Р', 'J' to 'О', 'K' to 'Л', 'L' to 'Д', ':' to 'Ж', '"' to 'Э',
        'Z' to 'Я', 'X' to 'Ч', 'C' to 'С', 'V' to 'М', 'B' to 'И', 'N' to 'Т', 'M' to 'Ь', '<' to 'Б', '>' to 'Ю'
    )

    fun cyrillicToLatin(input: String, scheme: TranslitScheme = TranslitScheme.SEARCH_POPULAR): String {
        var text = input
        for ((cyr, lat) in cyrToLatMulti) {
            text = text.replace(cyr, lat)
        }
        val sb = StringBuilder()
        for (char in text) {
            sb.append(cyrToLatSingle[char] ?: char)
        }
        return sb.toString()
    }

    fun latinToCyrillic(input: String): String {
        var text = input
        for ((lat, cyr) in latToCyrMulti) {
            text = text.replace(lat, cyr)
        }
        val sb = StringBuilder()
        for (char in text) {
            sb.append(latToCyrSingle[char] ?: char)
        }
        return sb.toString()
    }

    /**
     * Преобразует опечаточный ввод клавиатурной раскладки: "ghbdtn" -> "привет"
     */
    fun fixKeyboardLayout(input: String): String {
        val sb = StringBuilder()
        for (char in input) {
            sb.append(qwertyToJcuken[char] ?: char)
        }
        return sb.toString()
    }
}
