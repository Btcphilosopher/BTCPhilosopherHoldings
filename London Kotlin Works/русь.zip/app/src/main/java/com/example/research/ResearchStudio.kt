package com.example.research

import com.example.model.CitationStyle
import com.example.model.ResearchItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object ResearchStudio {

    private val initialItems = listOf(
        ResearchItem(
            id = "res-1",
            url = "rus://demo/russian-language",
            title = "История кириллицы и русской типографики: от устава до цифровой эпохи",
            author = "Институт языкознания РАН",
            publicationDate = "2026",
            language = "ru",
            sourceText = "Кириллическая наборная строка отличается плотностью и архитектурным спокойствием прямоугольных форм знаков «ш», «щ», «ц», «ж», «п». В отличие от латиницы с выраженными выносными элементами, русский текст требует деликатного оптического баланса.",
            notes = "Критически важно для разработки шрифтового ядра и корректного распределения белого пространства в верстке.",
            tags = listOf("Лингвистика", "Типографика", "ГОСТ")
        ),
        ResearchItem(
            id = "res-2",
            url = "rus://demo/tech-journal",
            title = "Квантовые процессоры и отечественные компиляторы",
            author = "Лаборатория квантовых вычислений МГУ",
            publicationDate = "2026",
            language = "ru",
            sourceText = "Время когерентности 64-кубитного процессора МГУ доведено до 180 мкс при 12-15 мК с точностью однокубитных операций 99.94%.",
            notes = "Показатели превышают плановые ориентиры программы развития микроэлектроники.",
            tags = listOf("Квантовые вычисления", "Физика", "МГУ")
        ),
        ResearchItem(
            id = "res-3",
            url = "rus://demo/railways",
            title = "Высокоскоростная магистраль Москва — Санкт-Петербург",
            author = "Инженерный корпус РЖД",
            publicationDate = "2026",
            language = "ru",
            sourceText = "Скоростной поезд «Белый кречет» рассчитан на эксплуатационную скорость 400 км/ч, сокращая время в пути между Москвой и Санкт-Петербургом до 2 часов 15 минут.",
            notes = "Технические характеристики безбалластного пути и системы автоматического регулирования по радиоканалу LTE-R.",
            tags = listOf("Транспорт", "Инфраструктура", "РЖД")
        )
    )

    private val _items = MutableStateFlow<List<ResearchItem>>(initialItems)
    val items: StateFlow<List<ResearchItem>> = _items.asStateFlow()

    fun addItem(item: ResearchItem) {
        val current = _items.value.toMutableList()
        current.add(0, item)
        _items.value = current
    }

    fun removeItem(id: String) {
        _items.value = _items.value.filter { it.id != id }
    }

    fun generateFullBibliography(style: CitationStyle = CitationStyle.GOST): String {
        val sb = StringBuilder()
        sb.append("СПИСОК ЛИТЕРАТУРЫ И ИСТОЧНИКОВ (${style.name})\n")
        sb.append("Сформировано в браузере РУСЬ: ").append(java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", java.util.Locale("ru")).format(java.util.Date())).append("\n\n")

        _items.value.forEachIndexed { index, item ->
            sb.append("${index + 1}. ").append(item.formatCitation(style)).append("\n\n")
        }
        return sb.toString()
    }
}
