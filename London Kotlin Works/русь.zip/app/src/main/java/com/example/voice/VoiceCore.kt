package com.example.voice

sealed class VoiceAction {
    data class Search(val query: String) : VoiceAction()
    data class Translate(val targetLang: String) : VoiceAction()
    object Summarize : VoiceAction()
    object Speak : VoiceAction()
    data class Navigate(val destination: String) : VoiceAction()
    data class Unknown(val rawTranscript: String) : VoiceAction()
}

object VoiceCore {

    fun parseCommand(transcript: String): VoiceAction {
        val lower = transcript.trim().lowercase()

        return when {
            lower.startsWith("найди информацию о") || lower.startsWith("найди") || lower.startsWith("поиск") -> {
                val query = lower.removePrefix("найди информацию о")
                    .removePrefix("найди")
                    .removePrefix("поиск")
                    .trim()
                VoiceAction.Search(if (query.isNotBlank()) query else transcript)
            }
            lower.contains("переведи") -> {
                val targetLang = if (lower.contains("английск")) "en" else "ru"
                VoiceAction.Translate(targetLang)
            }
            lower.contains("пересказ") || lower.contains("кратко") || lower.contains("резюме") -> {
                VoiceAction.Summarize
            }
            lower.contains("озвучь") || lower.contains("прочитай вслух") || lower.contains("слушать") -> {
                VoiceAction.Speak
            }
            lower.contains("история") || lower.contains("историю") -> {
                VoiceAction.Navigate("history")
            }
            lower.contains("закладки") -> {
                VoiceAction.Navigate("bookmarks")
            }
            lower.contains("исследование") || lower.contains("исследования") -> {
                VoiceAction.Navigate("research")
            }
            lower.contains("загрузки") -> {
                VoiceAction.Navigate("downloads")
            }
            else -> VoiceAction.Search(transcript)
        }
    }
}
