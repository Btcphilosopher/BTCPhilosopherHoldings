package com.example.reader

import android.content.Context
import android.speech.tts.TextToSpeech
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import com.example.engine.WebPage
import com.example.language.RussianTypographyEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class ReaderTheme {
    LIGHT, DARK, SEPIA
}

enum class ReaderFont(val label: String, val family: FontFamily) {
    SERIF("С засечками (Академический)", FontFamily.Serif),
    SANS("Без засечек (Инженерный)", FontFamily.SansSerif),
    MONOSPACE("Моноширинный (Терминал)", FontFamily.Monospace)
}

data class ReaderSettings(
    val fontSize: Float = 18f,
    val lineHeightMultiplier: Float = 1.6f,
    val maxContentWidthDp: Int = 680,
    val font: ReaderFont = ReaderFont.SERIF,
    val theme: ReaderTheme = ReaderTheme.SEPIA
)

object ReaderModeManager {

    private val _settings = MutableStateFlow(ReaderSettings())
    val settings: StateFlow<ReaderSettings> = _settings.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _currentSpokenSentence = MutableStateFlow<String?>(null)
    val currentSpokenSentence: StateFlow<String?> = _currentSpokenSentence.asStateFlow()

    private var tts: TextToSpeech? = null
    private var isTtsInitialized = false

    fun initTts(context: Context) {
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    val result = tts?.setLanguage(Locale("ru", "RU"))
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        tts?.setLanguage(Locale.getDefault())
                    }
                    isTtsInitialized = true
                }
            }
        }
    }

    fun updateSettings(transform: (ReaderSettings) -> ReaderSettings) {
        _settings.value = transform(_settings.value)
    }

    fun speakText(text: String) {
        if (!isTtsInitialized || tts == null) return
        _isSpeaking.value = true
        _currentSpokenSentence.value = text.take(80)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "RUS_READER_TTS")
    }

    fun stopSpeaking() {
        tts?.stop()
        _isSpeaking.value = false
        _currentSpokenSentence.value = null
    }

    /**
     * Преобразует веб-страницу в очищенный типографированный документ
     */
    fun prepareArticle(page: WebPage): WebPage {
        val cleanParagraphs = page.paragraphs.map { p ->
            RussianTypographyEngine.typograph(p)
        }
        val cleanLead = RussianTypographyEngine.typograph(page.lead)
        return page.copy(
            lead = cleanLead,
            paragraphs = cleanParagraphs
        )
    }
}
