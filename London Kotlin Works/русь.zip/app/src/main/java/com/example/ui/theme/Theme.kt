package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = RusDarkPrimary,
    onPrimary = RusDarkOnPrimary,
    secondary = RusDarkSecondary,
    onSecondary = Color(0xFF0F172A),
    tertiary = RusDarkTertiary,
    background = RusDarkBackground,
    surface = RusDarkSurface,
    surfaceVariant = RusDarkSurfaceVariant,
    outline = RusDarkOutline,
    onBackground = RusDarkTextPrimary,
    onSurface = RusDarkTextPrimary,
    onSurfaceVariant = RusDarkTextSecondary
)

private val LightColorScheme = lightColorScheme(
    primary = RusLightPrimary,
    onPrimary = RusLightOnPrimary,
    secondary = RusLightSecondary,
    onSecondary = Color.White,
    tertiary = RusLightTertiary,
    background = RusLightBackground,
    surface = RusLightSurface,
    surfaceVariant = RusLightSurfaceVariant,
    outline = RusLightOutline,
    onBackground = RusLightTextPrimary,
    onSurface = RusLightTextPrimary,
    onSurfaceVariant = RusLightTextSecondary
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep intentional Rus engineering branding
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
