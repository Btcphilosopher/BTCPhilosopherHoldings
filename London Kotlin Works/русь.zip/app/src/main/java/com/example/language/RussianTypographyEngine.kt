package com.example.language

object RussianTypographyEngine {

    private val PREPOSITIONS = listOf(
        "в", "во", "на", "с", "со", "по", "к", "ко", "о", "об", "обо",
        "из", "изо", "за", "от", "ото", "до", "для", "не", "ни", "и",
        "а", "но", "или", "да", "под", "подо", "над", "надо", "при",
        "без", "безо", "через", "сквозь", "про"
    )

    private val PARTICLES = listOf("же", "ж", "ли", "ль", "бы", "б")

    /**
     * Форматирует текст согласно каноническим правилам русской типографики:
     * 1. Замена прямых кавычек на русские парные «кавычки-ёлочки»
     * 2. Длинное тире (—) между словами вместо дефиса
     * 3. Среднее тире (–) в диапазонах чисел
     * 4. Неразрывные пробелы (\u00A0) после коротких предлогов и союзов
     * 5. Неразрывные пробелы перед частицами (бы, ли, же)
     * 6. Неразрывные пробелы в сокращениях (г., гг., т. д., т. п., в т. ч.)
     * 7. Неразрывные пробелы в разрядах чисел и перед знаками ₽, №, §
     */
    fun typograph(input: String): String {
        if (input.isBlank()) return input

        var result = input

        // 1. Нормализация дефисов в диапазонах (1941-1945 -> 1941–1945)
        result = result.replace(Regex("""(\d+)\s*[-–—]\s*(\d+)"""), "$1–$2")

        // 2. Длинное тире между словами (слово - слово -> слово — слово)
        result = result.replace(Regex("""\s+[-–—]\s+"""), "\u00A0— ")
        result = result.replace(Regex("""^[-–—]\s+"""), "— ")

        // 3. Замена парных кавычек на русские «ёлочки»
        result = convertQuotesToRussianGuillemets(result)

        // 4. Неразрывный пробел в сокращениях: г., гг., т. д., т. п., в т. ч.
        result = result.replace(Regex("""\b(\d+)\s+(г\.|гг\.)"""), "$1\u00A0$2")
        result = result.replace("т. д.", "т.\u00A0д.")
        result = result.replace("т. п.", "т.\u00A0п.")
        result = result.replace("в т. ч.", "в\u00A0т.\u00A0ч.")
        result = result.replace("и т. д.", "и\u00A0т.\u00A0д.")
        result = result.replace("и т. п.", "и\u00A0т.\u00A0п.")

        // 5. Символы № и §
        result = result.replace(Regex("""№\s*(\d+)"""), "№\u00A0$1")
        result = result.replace(Regex("""§\s*(\d+)"""), "§\u00A0$1")

        // 6. Неразрывный пробел перед знаком рубля и словом руб./рублей
        result = result.replace(Regex("""(\d+)\s*([₽]|руб\.|рублей|рубля)"""), "$1\u00A0$2")

        // 7. Разделители разрядов в больших числах (100 000 000)
        result = result.replace(Regex("""(\d{1,3})\s+(\d{3})"""), "$1\u00A0$2")

        // 8. Неразрывные пробелы после предлогов
        for (prep in PREPOSITIONS) {
            // В начале предложения или строки
            val capitalized = prep.replaceFirstChar { it.uppercase() }
            result = result.replace(Regex("""(?<=^|[«"(—\s])$capitalized\s+"""), "$capitalized\u00A0")
            result = result.replace(Regex("""(?<=^|[«"(—\s])$prep\s+"""), "$prep\u00A0")
        }

        // 9. Неразрывные пробелы перед частицами
        for (part in PARTICLES) {
            result = result.replace(Regex("""\s+$part(?=[.,!?;:]|\s|$)"""), "\u00A0$part")
        }

        return result
    }

    /**
     * Конвертирует "..." или “...” в «...»
     */
    private fun convertQuotesToRussianGuillemets(text: String): String {
        val sb = StringBuilder()
        var open = false
        for (i in text.indices) {
            val c = text[i]
            if (c == '"' || c == '“' || c == '”') {
                if (!open) {
                    sb.append('«')
                    open = true
                } else {
                    sb.append('»')
                    open = false
                }
            } else {
                sb.append(c)
            }
        }
        return sb.toString()
    }
}
