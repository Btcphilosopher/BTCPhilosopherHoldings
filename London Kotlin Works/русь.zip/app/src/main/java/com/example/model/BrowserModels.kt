package com.example.model

import java.util.UUID

data class BrowserTab(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "Новая вкладка",
    val url: String = "rus://home",
    val favicon: String = "Р",
    val isPinned: Boolean = false,
    val groupId: String? = null,
    val isSuspended: Boolean = false,
    val isIncognito: Boolean = false,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val isLoading: Boolean = false,
    val progress: Int = 0,
    val lastAccessed: Long = System.currentTimeMillis()
)

data class TabGroup(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val colorHex: Long = 0xFF2563EB
)

data class Bookmark(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val url: String,
    val folder: String = "Избранное",
    val tags: List<String> = emptyList(),
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

data class HistoryEntry(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val url: String,
    val timestamp: Long = System.currentTimeMillis(),
    val language: String = "ru",
    val snippet: String = ""
)

enum class DownloadStatus {
    DOWNLOADING, PAUSED, COMPLETED, FAILED
}

enum class SecurityScanStatus {
    CHECKING, SAFE, CAUTION
}

data class DownloadItem(
    val id: String = UUID.randomUUID().toString(),
    val filename: String,
    val url: String,
    val fileSizeFormatted: String,
    val progressPercent: Int = 100,
    val status: DownloadStatus = DownloadStatus.COMPLETED,
    val securityStatus: SecurityScanStatus = SecurityScanStatus.SAFE,
    val destinationPath: String = "/storage/emulated/0/Download",
    val timestamp: Long = System.currentTimeMillis()
)

enum class CitationStyle {
    GOST, APA, MLA, CHICAGO
}

data class ResearchItem(
    val id: String = UUID.randomUUID().toString(),
    val url: String,
    val title: String,
    val author: String = "Не указан",
    val publicationDate: String = "2026",
    val language: String = "ru",
    val sourceText: String,
    val translation: String? = null,
    val notes: String = "",
    val tags: List<String> = listOf("Исследование"),
    val timestamp: Long = System.currentTimeMillis()
) {
    fun formatCitation(style: CitationStyle = CitationStyle.GOST): String {
        return when (style) {
            CitationStyle.GOST -> {
                // ГОСТ Р 7.0.5-2008
                val authorPrefix = if (author.isNotBlank() && author != "Не указан") "$author. " else ""
                "$authorPrefix$title [Электронный ресурс] // РУСЬ: библиотека исследований. — URL: $url (дата обращения: 18.10.2026)."
            }
            CitationStyle.APA -> {
                val authorPrefix = if (author.isNotBlank() && author != "Не указан") "$author. " else ""
                "$authorPrefix($publicationDate). $title. Retrieved from $url"
            }
            CitationStyle.MLA -> {
                val authorPrefix = if (author.isNotBlank() && author != "Не указан") "$author. " else ""
                "$authorPrefix\"$title.\" Rus Research Archive, 2026, $url."
            }
            CitationStyle.CHICAGO -> {
                val authorPrefix = if (author.isNotBlank() && author != "Не указан") "$author. " else ""
                "$authorPrefix\"$title.\" Accessed October 18, 2026. $url."
            }
        }
    }
}

data class PrivacyStats(
    val trackersBlockedToday: Int = 184,
    val cookiesActive: Int = 42,
    val httpsUpgrades: Int = 127,
    val fingerprintsBlocked: Int = 38,
    val localAiInferences: Int = 14
)

data class SecurityReport(
    val isHttps: Boolean = true,
    val certificateIssuer: String = "Государственный удостоверяющий центр (Минцифры / GlobalSign)",
    val tlsProtocol: String = "TLS 1.3 (ChaCha20-Poly1305)",
    val isSiteIsolated: Boolean = true,
    val isSandboxEnabled: Boolean = true,
    val cookiesCount: Int = 3,
    val permissionsGranted: List<String> = emptyList()
)

data class AIAnalysisResult(
    val sourceTitle: String,
    val sourceUrl: String,
    val sourceDate: String,
    val sourceLanguage: String,
    val sourceExcerpts: List<String>,
    val aiInterpretation: String,
    val keyTakeaways: List<String>,
    val tableExtraction: List<Pair<String, String>> = emptyList(),
    val confidenceStatus: String = "Высокая достоверность (источник верифицирован)"
)

enum class SuggestionType {
    URL, SEARCH, COMMAND, CALCULATION, TRANSLITERATION, HISTORY, BOOKMARK
}

data class OmniSuggestion(
    val type: SuggestionType,
    val title: String,
    val subtitle: String,
    val target: String,
    val badge: String = ""
)
