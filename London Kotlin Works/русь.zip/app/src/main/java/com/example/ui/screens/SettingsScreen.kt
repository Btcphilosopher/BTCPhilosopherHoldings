package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.AIProviderMode
import com.example.ai.RusAiCore
import com.example.language.LanguageRegistry
import com.example.ui.theme.RusLightTertiary

@Composable
fun SettingsScreen(
    onShowMessage: (String) -> Unit
) {
    var aiMode by remember { mutableStateOf(RusAiCore.currentProviderMode) }
    var autoTypograph by remember { mutableStateOf(true) }
    var morphologySearch by remember { mutableStateOf(true) }
    var blockAllTrackers by remember { mutableStateOf(true) }
    var strictHttps by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text(
            text = "НАСТРОЙКИ",
            style = MaterialTheme.typography.displayMedium.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            ),
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = "Конфигурация языкового ядра, приватности и вычислительной платформы",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Раздел: Язык и типографика
            item {
                SettingsCategoryTitle("ЯЗЫК И РУССКАЯ ТИПОГРАФИКА")

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Основной системный язык",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Русский язык как первичная вычислительная среда",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = MaterialTheme.colorScheme.primary
                            ) {
                                Text(
                                    text = "RU (Кириллица)",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(12.dp))

                        SettingToggleRow(
                            title = "Автоматическая русская типографика",
                            subtitle = "Замена кавычек на «ёлочки», длинное тире (—) и неразрывные пробелы после предлогов",
                            checked = autoTypograph,
                            onCheckedChange = {
                                autoTypograph = it
                                onShowMessage("Параметры типографики обновлены")
                            }
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(12.dp))

                        SettingToggleRow(
                            title = "Глубокий морфологический поиск",
                            subtitle = "Учёт падежей, словоформ, лемм и синонимов без скрытой подмены запроса",
                            checked = morphologySearch,
                            onCheckedChange = {
                                morphologySearch = it
                                onShowMessage("Морфологический индекс обновлён")
                            }
                        )
                    }
                }
            }

            // Раздел: РУСЬ AI и вычисления
            item {
                SettingsCategoryTitle("РУСЬ AI И ЛОКАЛЬНЫЕ ВЫЧИСЛЕНИЯ")

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Режим работы AI-провайдера",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Выберите уровень приватности для анализа документов",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            AiModeChip(
                                title = "Только локально",
                                isSelected = aiMode == AIProviderMode.LOCAL_ONLY,
                                onClick = {
                                    aiMode = AIProviderMode.LOCAL_ONLY
                                    RusAiCore.currentProviderMode = AIProviderMode.LOCAL_ONLY
                                    onShowMessage("Установлен автономный локальный режим AI")
                                }
                            )
                            AiModeChip(
                                title = "Гибридный",
                                isSelected = aiMode == AIProviderMode.HYBRID,
                                onClick = {
                                    aiMode = AIProviderMode.HYBRID
                                    RusAiCore.currentProviderMode = AIProviderMode.HYBRID
                                    onShowMessage("Установлен гибридный режим")
                                }
                            )
                            AiModeChip(
                                title = "Облачный (Gemini)",
                                isSelected = aiMode == AIProviderMode.CLOUD_REMOTE,
                                onClick = {
                                    aiMode = AIProviderMode.CLOUD_REMOTE
                                    RusAiCore.currentProviderMode = AIProviderMode.CLOUD_REMOTE
                                    onShowMessage("Установлен режим облачных моделей")
                                }
                            )
                        }
                    }
                }
            }

            // Раздел: Приватность и защита
            item {
                SettingsCategoryTitle("БЕЗОПАСНОСТЬ И КОНФИДЕНЦИАЛЬНОСТЬ")

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        SettingToggleRow(
                            title = "Строгая блокировка сетевых трекеров",
                            subtitle = "Запрет передачи телеметрии и аналитических счётчиков",
                            checked = blockAllTrackers,
                            onCheckedChange = { blockAllTrackers = it }
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(12.dp))

                        SettingToggleRow(
                            title = "Строгий HTTPS Everywhere",
                            subtitle = "Автоматическое повышение до TLS 1.3 и блокировка смешанного контента",
                            checked = strictHttps,
                            onCheckedChange = { strictHttps = it }
                        )
                    }
                }
            }

            // Раздел: О браузере
            item {
                SettingsCategoryTitle("О ПЛАТФОРМЕ")

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "РУСЬ БРАУЗЕР (RUS BROWSER)",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Версия 2026.4.1 (Сборка 104) • Архитектура Jetpack Compose + Native Engine Core",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Интернет должен одинаково хорошо работать с русским языком, а не заставлять русский язык подстраиваться под Интернет.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                lineHeight = 18.sp
                            ),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}

@Composable
private fun SettingsCategoryTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelSmall.copy(
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        ),
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}

@Composable
private fun AiModeChip(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick),
        color = if (isSelected) RusLightTertiary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(8.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            ),
            color = if (isSelected) RusLightTertiary else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }
}
