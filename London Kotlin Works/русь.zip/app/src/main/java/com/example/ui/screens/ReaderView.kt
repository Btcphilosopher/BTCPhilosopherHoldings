package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.WebPage
import com.example.reader.ReaderFont
import com.example.reader.ReaderModeManager
import com.example.reader.ReaderTheme
import com.example.ui.theme.RusLightTertiary
import com.example.ui.theme.RusSepiaBackground
import com.example.ui.theme.RusSepiaSurface
import com.example.ui.theme.RusSepiaText

@Composable
fun ReaderView(
    page: WebPage,
    onClose: () -> Unit
) {
    val settings by ReaderModeManager.settings.collectAsState()
    val isSpeaking by ReaderModeManager.isSpeaking.collectAsState()
    val currentSpokenSentence by ReaderModeManager.currentSpokenSentence.collectAsState()
    var isSettingsPanelOpen by remember { mutableStateOf(false) }

    // Цвета текущей темы режима чтения
    val (bgColor, surfaceColor, textColor) = when (settings.theme) {
        ReaderTheme.SEPIA -> Triple(RusSepiaBackground, RusSepiaSurface, RusSepiaText)
        ReaderTheme.DARK -> Triple(Color(0xFF12141A), Color(0xFF1E222D), Color(0xFFE2E8F0))
        ReaderTheme.LIGHT -> Triple(Color(0xFFFAFAFA), Color(0xFFFFFFFF), Color(0xFF1A1A1A))
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgColor)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Верхняя планка управления режима чтения
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = surfaceColor,
                tonalElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "РЕЖИМ ЧТЕНИЯ РУСЬ",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        ),
                        color = textColor.copy(alpha = 0.7f)
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Озвучивание текста
                        IconButton(
                            onClick = {
                                if (isSpeaking) {
                                    ReaderModeManager.stopSpeaking()
                                } else {
                                    val fullText = page.lead + ". " + page.paragraphs.joinToString(". ")
                                    ReaderModeManager.speakText(fullText)
                                }
                            },
                            modifier = Modifier.testTag("reader_tts_button")
                        ) {
                            Icon(
                                imageVector = if (isSpeaking) Icons.Default.Stop else Icons.Default.VolumeUp,
                                contentDescription = "Озвучить страницу",
                                tint = if (isSpeaking) RusLightTertiary else textColor
                            )
                        }

                        // Настройки типографики (шрифт, размер, тема)
                        IconButton(
                            onClick = { isSettingsPanelOpen = !isSettingsPanelOpen },
                            modifier = Modifier.testTag("reader_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.FormatSize,
                                contentDescription = "Параметры текста",
                                tint = textColor
                            )
                        }

                        // Закрыть режим чтения
                        IconButton(
                            onClick = {
                                ReaderModeManager.stopSpeaking()
                                onClose()
                            },
                            modifier = Modifier.testTag("reader_close_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Выйти из режима чтения",
                                tint = textColor
                            )
                        }
                    }
                }
            }

            // Выпадающая панель настроек чтения
            if (isSettingsPanelOpen) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = surfaceColor),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "ПАРАМЕТРЫ ТИПОГРАФИКИ И ЧТЕНИЯ",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = textColor.copy(alpha = 0.6f)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Темы: Сепия, Светлая, Тёмная
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ReaderThemeChip("Сепия", ReaderTheme.SEPIA, settings.theme == ReaderTheme.SEPIA) {
                                ReaderModeManager.updateSettings { it.copy(theme = ReaderTheme.SEPIA) }
                            }
                            ReaderThemeChip("Светлая", ReaderTheme.LIGHT, settings.theme == ReaderTheme.LIGHT) {
                                ReaderModeManager.updateSettings { it.copy(theme = ReaderTheme.LIGHT) }
                            }
                            ReaderThemeChip("Тёмная", ReaderTheme.DARK, settings.theme == ReaderTheme.DARK) {
                                ReaderModeManager.updateSettings { it.copy(theme = ReaderTheme.DARK) }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Выбор гарнитуры шрифта
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ReaderFont.values().forEach { font ->
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable {
                                            ReaderModeManager.updateSettings { it.copy(font = font) }
                                        },
                                    color = if (settings.font == font) RusLightTertiary.copy(alpha = 0.15f) else bgColor,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = font.label.substringBefore(" "),
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontFamily = font.family,
                                            fontWeight = if (settings.font == font) FontWeight.Bold else FontWeight.Normal
                                        ),
                                        color = if (settings.font == font) RusLightTertiary else textColor,
                                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Размер кегля
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Кегль: ${settings.fontSize.toInt()} sp",
                                style = MaterialTheme.typography.bodySmall,
                                color = textColor
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Slider(
                                value = settings.fontSize,
                                onValueChange = { size ->
                                    ReaderModeManager.updateSettings { it.copy(fontSize = size) }
                                },
                                valueRange = 14f..28f,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Индикатор воспроизведения речи
            if (isSpeaking && currentSpokenSentence != null) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = RusLightTertiary.copy(alpha = 0.1f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Озвучивание",
                            tint = RusLightTertiary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Озвучивание: ${currentSpokenSentence}...",
                            style = MaterialTheme.typography.bodySmall,
                            color = RusLightTertiary,
                            maxLines = 1
                        )
                    }
                }
            }

            // Полнотекстовый контент для чтения
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                item {
                    Spacer(modifier = Modifier.height(28.dp))

                    Text(
                        text = page.title,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontFamily = settings.font.family,
                            fontWeight = FontWeight.Bold,
                            fontSize = (settings.fontSize + 8f).sp,
                            lineHeight = (settings.fontSize * 1.4f + 8f).sp
                        ),
                        color = textColor,
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = settings.maxContentWidthDp.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "${page.author} • ${page.date}",
                        style = MaterialTheme.typography.bodySmall,
                        color = textColor.copy(alpha = 0.65f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = settings.maxContentWidthDp.dp)
                    )

                    Spacer(modifier = Modifier.height(20.dp))
                    HorizontalDivider(
                        color = textColor.copy(alpha = 0.15f),
                        modifier = Modifier.widthIn(max = settings.maxContentWidthDp.dp)
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                }

                if (page.lead.isNotBlank()) {
                    item {
                        Text(
                            text = page.lead,
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontFamily = settings.font.family,
                                fontWeight = FontWeight.Medium,
                                fontSize = (settings.fontSize + 1f).sp,
                                lineHeight = (settings.fontSize * settings.lineHeightMultiplier).sp
                            ),
                            color = textColor,
                            modifier = Modifier
                                .fillMaxWidth()
                                .widthIn(max = settings.maxContentWidthDp.dp)
                                .padding(bottom = 18.dp)
                        )
                    }
                }

                items(page.paragraphs) { p ->
                    Text(
                        text = p,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontFamily = settings.font.family,
                            fontSize = settings.fontSize.sp,
                            lineHeight = (settings.fontSize * settings.lineHeightMultiplier).sp
                        ),
                        color = textColor,
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = settings.maxContentWidthDp.dp)
                            .padding(bottom = 16.dp)
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(60.dp))
                }
            }
        }
    }
}

@Composable
private fun ReaderThemeChip(
    title: String,
    theme: ReaderTheme,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick),
        color = if (isSelected) RusLightTertiary.copy(alpha = 0.15f) else Color.Transparent,
        shape = RoundedCornerShape(8.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            ),
            color = if (isSelected) RusLightTertiary else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}
