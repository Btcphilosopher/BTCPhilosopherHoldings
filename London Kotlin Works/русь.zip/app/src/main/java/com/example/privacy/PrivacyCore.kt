package com.example.privacy

import com.example.model.PrivacyStats
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class BlockedTrackerRecord(
    val domain: String,
    val category: String,
    val timestamp: Long = System.currentTimeMillis()
)

object PrivacyCore {

    private val TRACKER_DOMAINS = listOf(
        "mc.yandex.ru", "google-analytics.com", "doubleclick.net",
        "facebook.net", "analytics.tiktok.com", "top-fwz1.mail.ru",
        "hotjar.com", "criteo.com", "adroll.com", "scorecardresearch.com"
    )

    private val _stats = MutableStateFlow(
        PrivacyStats(
            trackersBlockedToday = 184,
            cookiesActive = 42,
            httpsUpgrades = 127,
            fingerprintsBlocked = 38,
            localAiInferences = 14
        )
    )
    val stats: StateFlow<PrivacyStats> = _stats.asStateFlow()

    private val _blockedTrackers = MutableStateFlow<List<BlockedTrackerRecord>>(
        listOf(
            BlockedTrackerRecord("mc.yandex.ru/watch/...", "Аналитический трекер"),
            BlockedTrackerRecord("google-analytics.com/collect", "Сбор телеметрии поведения"),
            BlockedTrackerRecord("doubleclick.net/pagead", "Рекламный пиксель профилирования"),
            BlockedTrackerRecord("top-fwz1.mail.ru/counter", "Счётчик посещаемости"),
            BlockedTrackerRecord("canvas-fingerprint-probe.io", "Попытка цифрового отпечатка холста")
        )
    )
    val blockedTrackers: StateFlow<List<BlockedTrackerRecord>> = _blockedTrackers.asStateFlow()

    fun isTracker(url: String): Boolean {
        val lower = url.lowercase()
        return TRACKER_DOMAINS.any { lower.contains(it) }
    }

    fun recordBlockedTracker(domain: String, category: String = "Телеметрия") {
        val current = _stats.value
        _stats.value = current.copy(trackersBlockedToday = current.trackersBlockedToday + 1)
        val list = _blockedTrackers.value.toMutableList()
        list.add(0, BlockedTrackerRecord(domain, category))
        _blockedTrackers.value = list.take(50)
    }

    fun recordHttpsUpgrade() {
        val current = _stats.value
        _stats.value = current.copy(httpsUpgrades = current.httpsUpgrades + 1)
    }

    fun recordLocalAiInference() {
        val current = _stats.value
        _stats.value = current.copy(localAiInferences = current.localAiInferences + 1)
    }
}
