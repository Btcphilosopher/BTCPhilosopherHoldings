package com.example.language

data class TranslationResult(
    val sourceLanguage: String,
    val targetLanguage: String,
    val originalText: String,
    val translatedText: String,
    val isBilingualAvailable: Boolean = true
)

object TranslationEngine {

    // Встроенный высокоточный словарь технических и научных терминов
    private val GLOSSARY_EN_TO_RU = mapOf(
        "browser" to "веб-браузер",
        "web platform" to "веб-платформа",
        "nuclear reactor" to "ядерный реактор",
        "quantum computing" to "квантовые вычисления",
        "artificial intelligence" to "искусственный интеллект",
        "machine learning" to "машинное обучение",
        "railway" to "железная дорога",
        "aerospace" to "аэрокосмическая отрасль",
        "research article" to "исследовательская статья",
        "cybersecurity" to "кибербезопасность",
        "open source" to "открытый исходный код",
        "compiler" to "компилятор",
        "memory safety" to "безопасность работы с памятью",
        "privacy" to "конфиденциальность",
        "encryption" to "шифрование",
        "typography" to "типографика"
    )

    private val GLOSSARY_RU_TO_EN = mapOf(
        "браузер" to "browser",
        "веб-платформа" to "web platform",
        "ядерный реактор" to "nuclear reactor",
        "квантовые вычисления" to "quantum computing",
        "искусственный интеллект" to "artificial intelligence",
        "исследование" to "research",
        "типографика" to "typography"
    )

    fun translate(
        text: String,
        targetLang: String = "ru",
        sourceLang: String = "auto"
    ): TranslationResult {
        val detectedScript = LanguageRegistry.detectScript(text)
        val actualSource = if (sourceLang == "auto") {
            if (detectedScript == "Кириллица") "ru" else "en"
        } else sourceLang

        val actualTarget = if (targetLang == actualSource) {
            if (actualSource == "ru") "en" else "ru"
        } else targetLang

        val translated = when {
            actualSource == "en" && actualTarget == "ru" -> translateEnToRu(text)
            actualSource == "ru" && actualTarget == "en" -> translateRuToEn(text)
            else -> "[$actualTarget] " + text
        }

        return TranslationResult(
            sourceLanguage = actualSource,
            targetLanguage = actualTarget,
            originalText = text,
            translatedText = translated,
            isBilingualAvailable = true
        )
    }

    private fun translateEnToRu(input: String): String {
        var result = input
        for ((en, ru) in GLOSSARY_EN_TO_RU) {
            result = result.replace(Regex("(?i)\\b$en\\b"), ru)
        }
        // Шаблонные грамматические структуры для демо-перевода
        result = result
            .replace(Regex("(?i)\\bThe\\b"), "")
            .replace(Regex("(?i)\\bis a\\b"), "— это")
            .replace(Regex("(?i)\\bare\\b"), "являются")
            .replace(Regex("(?i)\\bwith\\b"), "с")
            .replace(Regex("(?i)\\bfor\\b"), "для")
            .replace(Regex("(?i)\\band\\b"), "и")
            .replace(Regex("(?i)\\bin\\b"), "в")
            .replace(Regex("(?i)\\bon\\b"), "на")
            .replace(Regex("(?i)\\bnew generation\\b"), "нового поколения")
            .replace(Regex("(?i)\\bhigh performance\\b"), "высокая производительность")

        return RussianTypographyEngine.typograph(result.trim())
    }

    private fun translateRuToEn(input: String): String {
        var result = input
        for ((ru, en) in GLOSSARY_RU_TO_EN) {
            result = result.replace(Regex("(?i)\\b$ru\\b"), en)
        }
        return result
    }
}
