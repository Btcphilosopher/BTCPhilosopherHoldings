package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.RusLightTertiary
import com.example.viewmodel.BrowserScreen

data class NavEntry(
    val screen: BrowserScreen,
    val title: String,
    val icon: ImageVector,
    val tag: String
)

val NAV_ITEMS = listOf(
    NavEntry(BrowserScreen.HOME, "Главная", Icons.Default.Home, "nav_item_home"),
    NavEntry(BrowserScreen.TABS, "Вкладки", Icons.Default.Layers, "nav_item_tabs"),
    NavEntry(BrowserScreen.BOOKMARKS, "Закладки", Icons.Default.Bookmark, "nav_item_bookmarks"),
    NavEntry(BrowserScreen.HISTORY, "История", Icons.Default.History, "nav_item_history"),
    NavEntry(BrowserScreen.RESEARCH, "Исследования", Icons.Default.MenuBook, "nav_item_research"),
    NavEntry(BrowserScreen.DOWNLOADS, "Загрузки", Icons.Default.Download, "nav_item_downloads"),
    NavEntry(BrowserScreen.PRIVACY, "Защита", Icons.Default.Security, "nav_item_privacy"),
    NavEntry(BrowserScreen.SETTINGS, "Настройки", Icons.Default.Settings, "nav_item_settings")
)

@Composable
fun RusBottomNav(
    currentScreen: BrowserScreen,
    onNavigate: (BrowserScreen) -> Unit
) {
    val mobileItems = listOf(
        NAV_ITEMS[0], // Главная
        NAV_ITEMS[1], // Вкладки
        NAV_ITEMS[2], // Закладки
        NAV_ITEMS[4], // Исследования
        NAV_ITEMS[6], // Защита
        NAV_ITEMS[7]  // Настройки
    )

    NavigationBar(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .testTag("browser_bottom_navigation"),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 4.dp
    ) {
        mobileItems.forEach { entry ->
            val isSelected = currentScreen == entry.screen
            NavigationBarItem(
                selected = isSelected,
                onClick = { onNavigate(entry.screen) },
                icon = {
                    Icon(
                        imageVector = entry.icon,
                        contentDescription = entry.title,
                        modifier = Modifier.size(20.dp)
                    )
                },
                label = {
                    Text(
                        text = entry.title,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = RusLightTertiary,
                    selectedTextColor = RusLightTertiary,
                    indicatorColor = RusLightTertiary.copy(alpha = 0.12f),
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                modifier = Modifier.testTag(entry.tag)
            )
        }
    }
}

@Composable
fun RusSideNavRail(
    currentScreen: BrowserScreen,
    onNavigate: (BrowserScreen) -> Unit
) {
    NavigationRail(
        modifier = Modifier
            .fillMaxHeight()
            .width(88.dp)
            .testTag("browser_side_navigation"),
        containerColor = MaterialTheme.colorScheme.surface,
        header = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(vertical = 12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Р",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "РУСЬ",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    ) {
        NAV_ITEMS.forEach { entry ->
            val isSelected = currentScreen == entry.screen
            NavigationRailItem(
                selected = isSelected,
                onClick = { onNavigate(entry.screen) },
                icon = {
                    Icon(
                        imageVector = entry.icon,
                        contentDescription = entry.title,
                        modifier = Modifier.size(20.dp)
                    )
                },
                label = {
                    Text(
                        text = entry.title,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    )
                },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = RusLightTertiary,
                    selectedTextColor = RusLightTertiary,
                    indicatorColor = RusLightTertiary.copy(alpha = 0.12f),
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                modifier = Modifier.testTag(entry.tag)
            )
        }
    }
}
