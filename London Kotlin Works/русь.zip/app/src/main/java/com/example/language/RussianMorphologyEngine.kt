package com.example.language

object RussianMorphologyEngine {

    // Карта известных лемм и синонимов для семантического поиска
    private val SYNONYMS = mapOf(
        "самолёт" to listOf("самолёты", "самолёта", "самолётов", "авиация", "авиалайнер", "воздушное судно"),
        "самолет" to listOf("самолёт", "самолёты", "самолёта", "самолётов", "авиация"),
        "авиация" to listOf("самолёт", "самолёты", "авиаперевозки", "авиастроение"),
        "железная" to listOf("железные", "железная дорога", "железнодорожный", "ржд", "поезд", "магистраль"),
        "поезд" to listOf("поезда", "железная дорога", "состав", "локомотив"),
        "исследование" to listOf("исследования", "исследовательский", "научная работа", "анализ", "эксперимент"),
        "экономика" to listOf("экономический", "финансы", "рынок", "промышленность", "бюджет"),
        "наука" to listOf("научный", "исследования", "университет", "академия"),
        "университет" to listOf("вуз", "институт", "академия", "мгу", "мфти", "студенты"),
        "город" to listOf("города", "мегаполис", "москва", "петербург")
    )

    // Типичные окончания существительных и прилагательных в русском языке
    private val NOUN_ENDINGS = listOf(
        "ами", "ями", "ов", "ев", "ей", "ом", "ем", "ам", "ям", "ах", "ях",
        "а", "я", "о", "е", "ы", "и", "у", "ю", "ой", "ей", "ью"
    )

    private val ADJ_ENDINGS = listOf(
        "ому", "ему", "ыми", "ими", "ого", "его", "ой", "ей", "ую", "юю",
        "ый", "ий", "ой", "ая", "яя", "ое", "ее", "ые", "ие", "ых", "их", "ым", "им"
    )

    private val VERB_ENDINGS = listOf(
        "вшись", "вшись", "ться", "тся", "лись", "лась", "лось", "лись",
        "л", "ла", "ло", "ли", "ть", "ти", "ешь", "ете", "им", "ит", "ят", "ат", "ут", "ют"
    )

    /**
     * Извлекает основу (стемминг/лемму) русского слова
     */
    fun lemmatize(rawWord: String): String {
        val word = rawWord.trim().lowercase().replace('ё', 'е')
        if (word.length <= 3) return word

        // Проверяем прямое совпадение в словаре
        for ((lemma, forms) in SYNONYMS) {
            val normLemma = lemma.replace('ё', 'е')
            if (normLemma == word || forms.any { it.replace('ё', 'е') == word }) {
                return lemma
            }
        }

        // Правила снятия окончаний для поиска основы
        for (ending in ADJ_ENDINGS) {
            if (word.endsWith(ending) && word.length - ending.length >= 3) {
                return word.substring(0, word.length - ending.length)
            }
        }

        for (ending in VERB_ENDINGS) {
            if (word.endsWith(ending) && word.length - ending.length >= 3) {
                return word.substring(0, word.length - ending.length)
            }
        }

        for (ending in NOUN_ENDINGS) {
            if (word.endsWith(ending) && word.length - ending.length >= 3) {
                return word.substring(0, word.length - ending.length)
            }
        }

        return word
    }

    /**
     * Возвращает семантическое расширение поискового запроса:
     * словоформы, леммы и синонимы без скрытой подмены запроса.
     */
    fun expandSearchTerms(query: String): List<String> {
        val tokens = query.split(Regex("""[\s,.:;!?"«»—]+""")).filter { it.length > 1 }
        val expansions = mutableSetOf<String>()

        for (token in tokens) {
            val lemma = lemmatize(token)
            expansions.add(lemma)

            for ((dictLemma, related) in SYNONYMS) {
                if (dictLemma.startsWith(lemma) || lemma.startsWith(dictLemma)) {
                    expansions.add(dictLemma)
                    expansions.addAll(related.take(3))
                }
            }
        }

        return expansions.toList()
    }
}
