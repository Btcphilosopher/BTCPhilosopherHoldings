package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.model.BrowserTab
import com.example.reader.ReaderModeManager
import com.example.ui.components.OmniSuggestionsOverlay
import com.example.ui.components.RusBottomNav
import com.example.ui.components.RusSideNavRail
import com.example.ui.components.RusTopBar
import com.example.ui.components.VoiceSearchDialog
import com.example.ui.screens.AiResearchSheet
import com.example.ui.screens.BookmarksAndHistoryScreen
import com.example.ui.screens.DownloadsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PrivacySecurityScreen
import com.example.ui.screens.ReaderView
import com.example.ui.screens.ResearchStudioScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TabsScreen
import com.example.ui.screens.WebScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.BrowserScreen
import com.example.viewmodel.BrowserViewModel
import com.example.voice.VoiceAction
import com.example.voice.VoiceCore

class MainActivity : ComponentActivity() {

    private val viewModel: BrowserViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        ReaderModeManager.initTts(this)

        setContent {
            MyApplicationTheme {
                BrowserApp(viewModel)
            }
        }
    }
}

@Composable
fun BrowserApp(viewModel: BrowserViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.statusMessage) {
        uiState.statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearMessage()
        }
    }

    // Обработка кнопки Назад
    BackHandler {
        when {
            uiState.isReaderModeActive -> viewModel.toggleReaderMode()
            uiState.isAiPanelActive -> viewModel.toggleAiPanel()
            uiState.isOmniActive -> viewModel.dismissOmni()
            uiState.currentScreen != BrowserScreen.HOME -> viewModel.navigateTo(BrowserScreen.HOME)
        }
    }

    val activeTab = uiState.tabs.find { it.id == uiState.activeTabId } ?: uiState.tabs.firstOrNull()
    val isCurrentBookmarked = uiState.bookmarks.any { it.url == activeTab?.url }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 600.dp

        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                if (!isWideScreen && !uiState.isReaderModeActive) {
                    RusBottomNav(
                        currentScreen = uiState.currentScreen,
                        onNavigate = { viewModel.navigateTo(it) }
                    )
                }
            }
        ) { paddingValues ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // Боковое меню на планшетах / широких экранах
                if (isWideScreen && !uiState.isReaderModeActive) {
                    RusSideNavRail(
                        currentScreen = uiState.currentScreen,
                        onNavigate = { viewModel.navigateTo(it) }
                    )
                }

                // Основная область браузера
                Box(modifier = Modifier.fillMaxSize()) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Верхняя умная строка браузера
                        if (!uiState.isReaderModeActive) {
                            RusTopBar(
                                currentUrl = activeTab?.url ?: "",
                                omniText = uiState.omniText,
                                isOmniActive = uiState.isOmniActive,
                                isLoading = activeTab?.isLoading == true,
                                progress = activeTab?.progress ?: 0,
                                tabsCount = uiState.tabs.size,
                                canGoBack = activeTab?.canGoBack == true,
                                canGoForward = activeTab?.canGoForward == true,
                                isBookmarked = isCurrentBookmarked,
                                onOmniTextChanged = { viewModel.onOmniTextChanged(it) },
                                onOmniSubmit = { viewModel.openUrlOrQuery(it) },
                                onBackClick = { viewModel.navigateTo(BrowserScreen.HOME) },
                                onForwardClick = {},
                                onRefreshClick = {
                                    activeTab?.url?.let { viewModel.loadPage(it) }
                                },
                                onHomeClick = { viewModel.navigateTo(BrowserScreen.HOME) },
                                onTabsClick = { viewModel.navigateTo(BrowserScreen.TABS) },
                                onBookmarkToggle = {
                                    activeTab?.let { tab ->
                                        if (isCurrentBookmarked) {
                                            val b = uiState.bookmarks.find { it.url == tab.url }
                                            if (b != null) viewModel.removeBookmark(b.id)
                                        } else {
                                            viewModel.addBookmark(tab.title, tab.url)
                                        }
                                    }
                                },
                                onVoiceClick = {
                                    viewModel.showMessage("Активирован голосовой ввод на русском языке")
                                },
                                onSecurityClick = { viewModel.navigateTo(BrowserScreen.SECURITY) },
                                onMenuClick = { viewModel.navigateTo(BrowserScreen.SETTINGS) }
                            )
                        }

                        // Экраны браузера
                        Box(modifier = Modifier.weight(1f)) {
                            when (uiState.currentScreen) {
                                BrowserScreen.HOME -> {
                                    HomeScreen(
                                        onOpenUrl = { viewModel.openUrlOrQuery(it) },
                                        onNavigateBookmarks = { viewModel.navigateTo(BrowserScreen.BOOKMARKS) },
                                        onNavigateHistory = { viewModel.navigateTo(BrowserScreen.HISTORY) },
                                        onNavigateResearch = { viewModel.navigateTo(BrowserScreen.RESEARCH) },
                                        onNavigateDownloads = { viewModel.navigateTo(BrowserScreen.DOWNLOADS) },
                                        onNavigatePrivacy = { viewModel.navigateTo(BrowserScreen.PRIVACY) }
                                    )
                                }

                                BrowserScreen.WEB -> {
                                    val page = uiState.currentPage
                                    if (page != null) {
                                        WebScreen(
                                            page = page,
                                            isBilingualActive = uiState.isBilingualActive,
                                            translationResult = uiState.translationResult,
                                            onToggleReader = { viewModel.toggleReaderMode() },
                                            onToggleTranslation = { viewModel.toggleTranslation() },
                                            onToggleAi = { viewModel.toggleAiPanel() },
                                            onSaveToResearch = { viewModel.saveToResearch(page) }
                                        )
                                    } else {
                                        HomeScreen(
                                            onOpenUrl = { viewModel.openUrlOrQuery(it) },
                                            onNavigateBookmarks = { viewModel.navigateTo(BrowserScreen.BOOKMARKS) },
                                            onNavigateHistory = { viewModel.navigateTo(BrowserScreen.HISTORY) },
                                            onNavigateResearch = { viewModel.navigateTo(BrowserScreen.RESEARCH) },
                                            onNavigateDownloads = { viewModel.navigateTo(BrowserScreen.DOWNLOADS) },
                                            onNavigatePrivacy = { viewModel.navigateTo(BrowserScreen.PRIVACY) }
                                        )
                                    }
                                }

                                BrowserScreen.TABS -> {
                                    TabsScreen(
                                        tabs = uiState.tabs,
                                        activeTabId = uiState.activeTabId,
                                        tabGroups = uiState.tabGroups,
                                        onSelectTab = { viewModel.selectTab(it) },
                                        onCloseTab = { viewModel.closeTab(it) },
                                        onDuplicateTab = { viewModel.duplicateTab(it) },
                                        onTogglePin = { viewModel.toggleTabPin(it) },
                                        onCreateNewTab = { viewModel.createNewTab() },
                                        onClose = {
                                            viewModel.navigateTo(
                                                if (activeTab?.url == "rus://home") BrowserScreen.HOME
                                                else BrowserScreen.WEB
                                            )
                                        }
                                    )
                                }

                                BrowserScreen.BOOKMARKS -> {
                                    BookmarksAndHistoryScreen(
                                        initialTab = "bookmarks",
                                        bookmarks = uiState.bookmarks,
                                        history = uiState.history,
                                        onOpenUrl = { viewModel.openUrlOrQuery(it) },
                                        onRemoveBookmark = { viewModel.removeBookmark(it) },
                                        onShowMessage = { viewModel.showMessage(it) }
                                    )
                                }

                                BrowserScreen.HISTORY -> {
                                    BookmarksAndHistoryScreen(
                                        initialTab = "history",
                                        bookmarks = uiState.bookmarks,
                                        history = uiState.history,
                                        onOpenUrl = { viewModel.openUrlOrQuery(it) },
                                        onRemoveBookmark = { viewModel.removeBookmark(it) },
                                        onShowMessage = { viewModel.showMessage(it) }
                                    )
                                }

                                BrowserScreen.RESEARCH -> {
                                    ResearchStudioScreen(
                                        selectedStyle = uiState.selectedCitationStyle,
                                        onSelectStyle = { viewModel.setCitationStyle(it) },
                                        onOpenUrl = { viewModel.openUrlOrQuery(it) },
                                        onShowMessage = { viewModel.showMessage(it) }
                                    )
                                }

                                BrowserScreen.DOWNLOADS -> {
                                    DownloadsScreen(
                                        downloads = uiState.downloads,
                                        onShowMessage = { viewModel.showMessage(it) }
                                    )
                                }

                                BrowserScreen.PRIVACY, BrowserScreen.SECURITY -> {
                                    PrivacySecurityScreen(
                                        onClearData = {
                                            viewModel.showMessage("История посещений, кэш и cookies успешно очищены")
                                        }
                                    )
                                }

                                BrowserScreen.DIAGNOSTICS -> {
                                    viewModel.loadPage("about:diagnostics")
                                }

                                BrowserScreen.SETTINGS -> {
                                    SettingsScreen(
                                        onShowMessage = { viewModel.showMessage(it) }
                                    )
                                }
                            }
                        }
                    }

                    // Выпадающее окно подсказок умной строки
                    if (uiState.isOmniActive && uiState.suggestions.isNotEmpty()) {
                        OmniSuggestionsOverlay(
                            suggestions = uiState.suggestions,
                            onSelectSuggestion = { viewModel.openUrlOrQuery(it) },
                            onDismiss = { viewModel.dismissOmni() }
                        )
                    }

                    // Полноэкранный режим чтения
                    if (uiState.isReaderModeActive && uiState.currentPage != null) {
                        ReaderView(
                            page = uiState.currentPage!!,
                            onClose = { viewModel.toggleReaderMode() }
                        )
                    }

                    // Модальный лист РУСЬ AI
                    if (uiState.isAiPanelActive && uiState.currentPage != null) {
                        AiResearchSheet(
                            page = uiState.currentPage!!,
                            analysis = uiState.aiAnalysisResult,
                            onClose = { viewModel.toggleAiPanel() },
                            onSaveToResearch = {
                                viewModel.saveToResearch(uiState.currentPage!!)
                            }
                        )
                    }
                }
            }
        }
    }
}
