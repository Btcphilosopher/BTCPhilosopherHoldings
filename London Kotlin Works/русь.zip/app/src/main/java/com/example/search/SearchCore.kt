package com.example.search

import com.example.language.RussianMorphologyEngine
import com.example.language.RussianSpellcheck
import com.example.language.TransliterationEngine
import com.example.model.OmniSuggestion
import com.example.model.SuggestionType

object SearchCore {

    val SYSTEM_COMMANDS = listOf(
        Pair("/главная", "Открыть стартовую страницу браузера"),
        Pair("/поиск", "Выполнить глубокий поиск по ключевым словам"),
        Pair("/история", "Открыть журнал посещений и сессий"),
        Pair("/закладки", "Открыть библиотеку закладок и папок"),
        Pair("/исследование", "Открыть исследовательскую лабораторию и цитаты"),
        Pair("/загрузки", "Открыть менеджер загруженных файлов"),
        Pair("/приватность", "Панель защиты, блокировки трекеров и cookie"),
        Pair("/безопасность", "Центр безопасности, сертификаты и TLS"),
        Pair("/перевод", "Перевести текущую страницу на русский"),
        Pair("/пересказ", "Сгенерировать краткое резюме с источниками"),
        Pair("/диагностика", "about:diagnostics — параметры системы и движка"),
        Pair("/производительность", "about:performance — мониторинг RAM и CPU"),
        Pair("/вычислить", "Калькулятор математических выражений")
    )

    /**
     * Анализирует ввод пользователя в умной строке и формирует предложения
     */
    fun processInput(
        rawInput: String,
        historyUrls: List<Pair<String, String>> = emptyList(),
        bookmarks: List<Pair<String, String>> = emptyList()
    ): List<OmniSuggestion> {
        val input = rawInput.trim()
        if (input.isEmpty()) {
            return getDefaultQuickSuggestions()
        }

        val suggestions = mutableListOf<OmniSuggestion>()

        // 1. Команды (/...)
        if (input.startsWith("/")) {
            val matching = SYSTEM_COMMANDS.filter { it.first.startsWith(input.lowercase()) }
            for ((cmd, desc) in matching) {
                suggestions.add(
                    OmniSuggestion(
                        type = SuggestionType.COMMAND,
                        title = cmd,
                        subtitle = desc,
                        target = cmd,
                        badge = "Команда"
                    )
                )
            }
            return suggestions
        }

        // 2. Вычисления (125 * 17, 2 + 2, etc.)
        val mathResult = tryEvaluateMath(input)
        if (mathResult != null) {
            suggestions.add(
                OmniSuggestion(
                    type = SuggestionType.CALCULATION,
                    title = "$input = $mathResult",
                    subtitle = "Результат вычисления",
                    target = "calc:$mathResult",
                    badge = "Калькулятор"
                )
            )
        }

        // 3. Быстрые ответы (Погода, Курсы валют)
        val lower = input.lowercase()
        if (lower.contains("погода")) {
            suggestions.add(
                OmniSuggestion(
                    type = SuggestionType.SEARCH,
                    title = "Погода в Москве: +14°C, облачно с прояснениями",
                    subtitle = "Давление 748 мм рт. ст., ветер С-З 3 м/с",
                    target = "search:погода в Москве",
                    badge = "Метео"
                )
            )
        }
        if (lower.contains("курс") || lower.contains("доллар") || lower.contains("валют")) {
            suggestions.add(
                OmniSuggestion(
                    type = SuggestionType.SEARCH,
                    title = "Курс ЦБ РФ: USD = 92.40 ₽, EUR = 99.80 ₽, CNY = 12.75 ₽",
                    subtitle = "Официальные курсы валют на сегодня",
                    target = "search:курс валют",
                    badge = "Финансы"
                )
            )
        }

        // 4. Проверка на URL
        val isUrlCandidate = isLikelyUrl(input)
        if (isUrlCandidate) {
            val formattedUrl = formatAsUrl(input)
            suggestions.add(
                OmniSuggestion(
                    type = SuggestionType.URL,
                    title = formattedUrl,
                    subtitle = "Перейти по сетевому адресу",
                    target = formattedUrl,
                    badge = "URL"
                )
            )
        }

        // 5. Опечатки и клавиатурная раскладка
        val typoSuggestion = RussianSpellcheck.checkAndSuggest(input)
        if (typoSuggestion != null && typoSuggestion != input) {
            suggestions.add(
                OmniSuggestion(
                    type = SuggestionType.SEARCH,
                    title = typoSuggestion,
                    subtitle = "Возможно, вы имели в виду: $typoSuggestion",
                    target = "search:$typoSuggestion",
                    badge = "Исправление"
                )
            )
        }

        // 6. Транслитерация (privet mir -> привет мир)
        val isLatinInput = input.all { it in 'a'..'z' || it in 'A'..'Z' || it.isWhitespace() || it in "0123456789-_" }
        if (isLatinInput && !isUrlCandidate) {
            val cyrillicTranslit = TransliterationEngine.latinToCyrillic(input)
            if (cyrillicTranslit != input) {
                suggestions.add(
                    OmniSuggestion(
                        type = SuggestionType.TRANSLITERATION,
                        title = cyrillicTranslit,
                        subtitle = "Транслитерация: $input → $cyrillicTranslit",
                        target = "search:$cyrillicTranslit",
                        badge = "Транслит"
                    )
                )
            }
        }

        // 7. Основной морфологический поиск
        suggestions.add(
            OmniSuggestion(
                type = SuggestionType.SEARCH,
                title = input,
                subtitle = "Найти в интернете через РУСЬ Поиск",
                target = "search:$input",
                badge = "Поиск"
            )
        )

        // 8. Семантическое морфологическое расширение ("самолёты" -> "самолёт авиация")
        val expandedTerms = RussianMorphologyEngine.expandSearchTerms(input)
        if (expandedTerms.isNotEmpty() && expandedTerms.joinToString(" ") != input) {
            val expandedQuery = expandedTerms.take(4).joinToString(" ")
            suggestions.add(
                OmniSuggestion(
                    type = SuggestionType.SEARCH,
                    title = expandedQuery,
                    subtitle = "Расширенный семантический поиск (словоформы и леммы)",
                    target = "search:$expandedQuery",
                    badge = "Морфология"
                )
            )
        }

        // 9. Совпадения по истории и закладкам
        for ((title, url) in bookmarks) {
            if (title.contains(input, ignoreCase = true) || url.contains(input, ignoreCase = true)) {
                suggestions.add(
                    OmniSuggestion(
                        type = SuggestionType.BOOKMARK,
                        title = title,
                        subtitle = url,
                        target = url,
                        badge = "Закладка"
                    )
                )
            }
        }

        for ((title, url) in historyUrls.take(3)) {
            if (title.contains(input, ignoreCase = true) || url.contains(input, ignoreCase = true)) {
                suggestions.add(
                    OmniSuggestion(
                        type = SuggestionType.HISTORY,
                        title = title,
                        subtitle = url,
                        target = url,
                        badge = "История"
                    )
                )
            }
        }

        return suggestions
    }

    private fun getDefaultQuickSuggestions(): List<OmniSuggestion> {
        return listOf(
            OmniSuggestion(
                type = SuggestionType.COMMAND,
                title = "/исследование",
                subtitle = "Открыть лабораторию исследований и заметок",
                target = "/исследование",
                badge = "Наука"
            ),
            OmniSuggestion(
                type = SuggestionType.SEARCH,
                title = "История русского языка и кириллицы",
                subtitle = "Исследовательская статья с библиографией",
                target = "rus://demo/russian-language",
                badge = "Статья"
            ),
            OmniSuggestion(
                type = SuggestionType.SEARCH,
                title = "Квантовые вычисления и микроэлектроника",
                subtitle = "Научный портал МГУ и РАН",
                target = "rus://demo/tech-journal",
                badge = "Журнал"
            ),
            OmniSuggestion(
                type = SuggestionType.COMMAND,
                title = "/приватность",
                subtitle = "Панель блокировки сетевых трекеров",
                target = "/приватность",
                badge = "Защита"
            )
        )
    }

    fun isLikelyUrl(input: String): Boolean {
        if (input.startsWith("http://") || input.startsWith("https://") || input.startsWith("about:") || input.startsWith("rus://")) {
            return true
        }
        if (input.contains(" ")) return false
        val commonTlds = listOf(".ru", ".рф", ".su", ".com", ".org", ".net", ".edu", ".gov", ".io", ".dev", ".ai")
        return commonTlds.any { input.contains(it, ignoreCase = true) }
    }

    fun formatAsUrl(input: String): String {
        if (input.startsWith("http://") || input.startsWith("https://") || input.startsWith("about:") || input.startsWith("rus://")) {
            return input
        }
        return "https://$input"
    }

    /**
     * Вычисляет базовые арифметические выражения (например 125 * 17 или 2^8)
     */
    private fun tryEvaluateMath(input: String): String? {
        val clean = input.replace(" ", "").replace(",", ".")
        if (!clean.matches(Regex("""^[\d.+*/\-^()]+$"""))) return null
        if (!clean.any { it in "+*/-^" }) return null

        return try {
            when {
                clean.contains("*") -> {
                    val parts = clean.split("*")
                    if (parts.size == 2) {
                        val a = parts[0].toDouble()
                        val b = parts[1].toDouble()
                        formatNum(a * b)
                    } else null
                }
                clean.contains("/") -> {
                    val parts = clean.split("/")
                    if (parts.size == 2) {
                        val a = parts[0].toDouble()
                        val b = parts[1].toDouble()
                        if (b != 0.0) formatNum(a / b) else "Деление на 0"
                    } else null
                }
                clean.contains("+") -> {
                    val parts = clean.split("+")
                    if (parts.size == 2) {
                        val a = parts[0].toDouble()
                        val b = parts[1].toDouble()
                        formatNum(a + b)
                    } else null
                }
                clean.contains("-") && !clean.startsWith("-") -> {
                    val parts = clean.split("-")
                    if (parts.size == 2) {
                        val a = parts[0].toDouble()
                        val b = parts[1].toDouble()
                        formatNum(a - b)
                    } else null
                }
                clean.contains("^") -> {
                    val parts = clean.split("^")
                    if (parts.size == 2) {
                        val a = parts[0].toDouble()
                        val b = parts[1].toDouble()
                        formatNum(Math.pow(a, b))
                    } else null
                }
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun formatNum(n: Double): String {
        return if (n % 1.0 == 0.0) {
            n.toLong().toString()
        } else {
            String.format(java.util.Locale.US, "%.4f", n).trimEnd('0').trimEnd('.')
        }
    }
}
