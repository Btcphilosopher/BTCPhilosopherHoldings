package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AIProviderMode
import com.example.ai.RusAiCore
import com.example.engine.BrowserEngine
import com.example.engine.BundledPortals
import com.example.engine.SimulationAdapter
import com.example.engine.SystemPagesAdapter
import com.example.engine.WebPage
import com.example.language.RussianTypographyEngine
import com.example.language.TranslationEngine
import com.example.language.TranslationResult
import com.example.model.AIAnalysisResult
import com.example.model.Bookmark
import com.example.model.BrowserTab
import com.example.model.CitationStyle
import com.example.model.DownloadItem
import com.example.model.DownloadStatus
import com.example.model.HistoryEntry
import com.example.model.OmniSuggestion
import com.example.model.ResearchItem
import com.example.model.TabGroup
import com.example.privacy.PrivacyCore
import com.example.reader.ReaderModeManager
import com.example.research.ResearchStudio
import com.example.search.SearchCore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class BrowserScreen {
    HOME, WEB, TABS, BOOKMARKS, HISTORY, DOWNLOADS, RESEARCH, PRIVACY, SECURITY, DIAGNOSTICS, SETTINGS
}

data class BrowserUiState(
    val currentScreen: BrowserScreen = BrowserScreen.HOME,
    val tabs: List<BrowserTab> = emptyList(),
    val activeTabId: String = "",
    val tabGroups: List<TabGroup> = emptyList(),
    val omniText: String = "",
    val isOmniActive: Boolean = false,
    val suggestions: List<OmniSuggestion> = emptyList(),
    val currentPage: WebPage? = null,
    val isReaderModeActive: Boolean = false,
    val isAiPanelActive: Boolean = false,
    val aiAnalysisResult: AIAnalysisResult? = null,
    val isBilingualActive: Boolean = false,
    val translationResult: TranslationResult? = null,
    val bookmarks: List<Bookmark> = emptyList(),
    val history: List<HistoryEntry> = emptyList(),
    val downloads: List<DownloadItem> = emptyList(),
    val isVoiceDialogActive: Boolean = false,
    val voiceTranscript: String = "",
    val selectedCitationStyle: CitationStyle = CitationStyle.GOST,
    val statusMessage: String? = null
)

class BrowserViewModel : ViewModel() {

    private val simulationEngine = SimulationAdapter()
    private val systemEngine = SystemPagesAdapter()

    private val _uiState = MutableStateFlow(BrowserUiState())
    val uiState: StateFlow<BrowserUiState> = _uiState.asStateFlow()

    init {
        initializeBrowser()
    }

    private fun initializeBrowser() {
        val defaultGroup1 = TabGroup(id = "grp-work", name = "Работа", colorHex = 0xFF2563EB)
        val defaultGroup2 = TabGroup(id = "grp-sci", name = "Исследование", colorHex = 0xFF10B981)

        val initialTab1 = BrowserTab(
            id = "tab-home",
            title = "Новая вкладка",
            url = "rus://home",
            favicon = "Р"
        )
        val initialTab2 = BrowserTab(
            id = "tab-article",
            title = "История кириллицы и русской типографики",
            url = "rus://demo/russian-language",
            favicon = "К",
            groupId = defaultGroup2.id
        )

        val initialBookmarks = listOf(
            Bookmark(title = "Яндекс", url = "https://ya.ru", folder = "Поиск"),
            Bookmark(title = "Российская академия наук", url = "https://new.ras.ru", folder = "Наука"),
            Bookmark(title = "МГУ им. М.В. Ломоносова", url = "https://msu.ru", folder = "Образование"),
            Bookmark(title = "РЖД — Пассажирские перевозки", url = "https://rzd.ru", folder = "Транспорт"),
            Bookmark(title = "Госуслуги РФ", url = "https://gosuslugi.ru", folder = "Сервисы"),
            Bookmark(title = "История кириллицы", url = "rus://demo/russian-language", folder = "Исследования"),
            Bookmark(title = "Квантовые процессоры", url = "rus://demo/tech-journal", folder = "Наука")
        )

        val initialHistory = listOf(
            HistoryEntry(title = "История кириллицы и русской типографики", url = "rus://demo/russian-language", language = "ru"),
            HistoryEntry(title = "Квантовые процессоры и отечественные компиляторы", url = "rus://demo/tech-journal", language = "ru"),
            HistoryEntry(title = "Высокоскоростная магистраль Москва — Санкт-Петербург", url = "rus://demo/railways", language = "ru"),
            HistoryEntry(title = "Global Frontiers in Clean Energy and Fusion", url = "rus://demo/international-science", language = "en"),
            HistoryEntry(title = "Финансово-экономический вестник", url = "rus://demo/finance-bulletin", language = "ru")
        )

        val initialDownloads = listOf(
            DownloadItem(filename = "ГОСТ_Р_7.0.5_2008_Библиографическая_ссылка.pdf", url = "rus://demo/files/gost.pdf", fileSizeFormatted = "1.4 МБ", status = DownloadStatus.COMPLETED),
            DownloadItem(filename = "Архитектура_Квантового_Процессора_МГУ_2026.pdf", url = "rus://demo/files/quantum.pdf", fileSizeFormatted = "4.8 МБ", status = DownloadStatus.COMPLETED),
            DownloadItem(filename = "Словарь_Русской_Морфологии_Леммы.dat", url = "rus://demo/files/dict.dat", fileSizeFormatted = "8.2 МБ", status = DownloadStatus.COMPLETED)
        )

        _uiState.value = BrowserUiState(
            currentScreen = BrowserScreen.HOME,
            tabs = listOf(initialTab1, initialTab2),
            activeTabId = initialTab1.id,
            tabGroups = listOf(defaultGroup1, defaultGroup2),
            bookmarks = initialBookmarks,
            history = initialHistory,
            downloads = initialDownloads
        )
    }

    fun onOmniTextChanged(text: String) {
        val historyPairs = _uiState.value.history.map { it.title to it.url }
        val bookmarkPairs = _uiState.value.bookmarks.map { it.title to it.url }
        val suggestions = SearchCore.processInput(text, historyPairs, bookmarkPairs)

        _uiState.value = _uiState.value.copy(
            omniText = text,
            isOmniActive = true,
            suggestions = suggestions
        )
    }

    fun dismissOmni() {
        _uiState.value = _uiState.value.copy(isOmniActive = false)
    }

    fun openUrlOrQuery(input: String) {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return

        _uiState.value = _uiState.value.copy(isOmniActive = false, omniText = trimmed)

        // 1. Проверка системных команд
        if (trimmed.startsWith("/")) {
            when (trimmed) {
                "/главная" -> navigateTo(BrowserScreen.HOME)
                "/история" -> navigateTo(BrowserScreen.HISTORY)
                "/закладки" -> navigateTo(BrowserScreen.BOOKMARKS)
                "/исследование" -> navigateTo(BrowserScreen.RESEARCH)
                "/загрузки" -> navigateTo(BrowserScreen.DOWNLOADS)
                "/приватность" -> navigateTo(BrowserScreen.PRIVACY)
                "/безопасность" -> navigateTo(BrowserScreen.SECURITY)
                "/диагностика" -> loadPage("about:diagnostics")
                "/производительность" -> loadPage("about:performance")
                "/настройки" -> navigateTo(BrowserScreen.SETTINGS)
                "/перевод" -> toggleTranslation()
                "/пересказ" -> toggleAiPanel()
                else -> {
                    showMessage("Команда $trimmed выполнена")
                }
            }
            return
        }

        // 2. URL или поисковый запрос
        if (trimmed.startsWith("rus://home")) {
            navigateTo(BrowserScreen.HOME)
            return
        }

        val destinationUrl = if (SearchCore.isLikelyUrl(trimmed)) {
            SearchCore.formatAsUrl(trimmed)
        } else if (trimmed.startsWith("search:")) {
            val query = trimmed.removePrefix("search:")
            val matchedPage = BundledPortals.findPage(query)
            matchedPage?.url ?: "https://ya.ru/search/?text=${java.net.URLEncoder.encode(query, "UTF-8")}"
        } else {
            val matchedPage = BundledPortals.findPage(trimmed)
            matchedPage?.url ?: "https://ya.ru/search/?text=${java.net.URLEncoder.encode(trimmed, "UTF-8")}"
        }

        loadPage(destinationUrl)
    }

    fun loadPage(url: String) {
        viewModelScope.launch {
            val activeId = _uiState.value.activeTabId
            val cleanUrl = url.trim()

            // Обновляем состояние вкладки на загрузку
            updateTab(activeId) { it.copy(url = cleanUrl, isLoading = true, progress = 40) }

            // Выбор движка
            val page: WebPage = when {
                systemEngine.canHandle(cleanUrl) -> systemEngine.loadPage(cleanUrl)
                simulationEngine.canHandle(cleanUrl) -> simulationEngine.loadPage(cleanUrl)
                else -> {
                    // Симуляция реального рендеринга внешнего сайта с типографикой
                    val simulated = BundledPortals.findPage(cleanUrl) ?: WebPage(
                        url = cleanUrl,
                        title = cleanUrl.removePrefix("https://").removePrefix("http://"),
                        domain = cleanUrl.removePrefix("https://").removePrefix("http://").substringBefore('/'),
                        author = "Интернет-ресурс",
                        date = "18 октября 2026 г.",
                        language = "ru",
                        lead = RussianTypographyEngine.typograph("Сетевой узел загружен по защищённому протоколу TLS 1.3 с проверкой доверенного удостоверяющего центра."),
                        paragraphs = listOf(
                            RussianTypographyEngine.typograph("Интерфейс веб-платформы РУСЬ обеспечивает аппаратное ускорение рендеринга, морфологический индекс, блокировку 100% известных трекеров и сохранение в исследовательский контур."),
                            RussianTypographyEngine.typograph("Для чтения в академическом режиме активируйте кнопку «Режим чтения» в верхней панели инструментов.")
                        )
                    )
                    simulated
                }
            }

            // Записываем посещение в историю
            val newHistoryEntry = HistoryEntry(
                title = page.title,
                url = page.url,
                language = page.language,
                snippet = page.lead.take(100)
            )
            val updatedHistory = listOf(newHistoryEntry) + _uiState.value.history.filter { it.url != page.url }

            // Записываем статистику в PrivacyCore
            if (page.url.startsWith("https://")) {
                PrivacyCore.recordHttpsUpgrade()
            }
            PrivacyCore.recordBlockedTracker(page.domain, "Аналитический счетчик")

            updateTab(activeId) {
                it.copy(
                    title = page.title,
                    url = page.url,
                    isLoading = false,
                    progress = 100,
                    canGoBack = true
                )
            }

            _uiState.value = _uiState.value.copy(
                currentScreen = BrowserScreen.WEB,
                currentPage = page,
                omniText = page.url,
                history = updatedHistory,
                isBilingualActive = false,
                translationResult = null,
                isReaderModeActive = false,
                isAiPanelActive = false
            )
        }
    }

    fun createNewTab(url: String = "rus://home", groupId: String? = null) {
        val newTab = BrowserTab(
            title = "Новая вкладка",
            url = url,
            groupId = groupId
        )
        val currentTabs = _uiState.value.tabs.toMutableList()
        currentTabs.add(newTab)

        _uiState.value = _uiState.value.copy(
            tabs = currentTabs,
            activeTabId = newTab.id,
            currentScreen = if (url == "rus://home") BrowserScreen.HOME else BrowserScreen.WEB,
            omniText = if (url == "rus://home") "" else url
        )

        if (url != "rus://home") {
            loadPage(url)
        }
    }

    fun selectTab(tabId: String) {
        val tab = _uiState.value.tabs.find { it.id == tabId } ?: return
        _uiState.value = _uiState.value.copy(
            activeTabId = tabId,
            currentScreen = if (tab.url == "rus://home") BrowserScreen.HOME else BrowserScreen.WEB,
            omniText = if (tab.url == "rus://home") "" else tab.url
        )
        if (tab.url != "rus://home" && _uiState.value.currentPage?.url != tab.url) {
            loadPage(tab.url)
        }
    }

    fun closeTab(tabId: String) {
        val currentTabs = _uiState.value.tabs.toMutableList()
        if (currentTabs.size <= 1) {
            // Оставляем одну домашнюю вкладку
            val homeTab = BrowserTab(title = "Новая вкладка", url = "rus://home")
            _uiState.value = _uiState.value.copy(
                tabs = listOf(homeTab),
                activeTabId = homeTab.id,
                currentScreen = BrowserScreen.HOME,
                omniText = ""
            )
            return
        }

        val indexToRemove = currentTabs.indexOfFirst { it.id == tabId }
        currentTabs.removeAt(indexToRemove)

        val newActiveTab = if (_uiState.value.activeTabId == tabId) {
            val nextIndex = (indexToRemove - 1).coerceAtLeast(0)
            currentTabs[nextIndex]
        } else {
            currentTabs.find { it.id == _uiState.value.activeTabId } ?: currentTabs[0]
        }

        _uiState.value = _uiState.value.copy(
            tabs = currentTabs,
            activeTabId = newActiveTab.id,
            currentScreen = if (newActiveTab.url == "rus://home") BrowserScreen.HOME else BrowserScreen.WEB,
            omniText = if (newActiveTab.url == "rus://home") "" else newActiveTab.url
        )
    }

    fun toggleTabPin(tabId: String) {
        updateTab(tabId) { it.copy(isPinned = !it.isPinned) }
    }

    fun duplicateTab(tabId: String) {
        val tab = _uiState.value.tabs.find { it.id == tabId } ?: return
        createNewTab(tab.url, tab.groupId)
    }

    fun addBookmark(title: String, url: String, folder: String = "Избранное") {
        val newBookmark = Bookmark(title = title, url = url, folder = folder)
        _uiState.value = _uiState.value.copy(
            bookmarks = listOf(newBookmark) + _uiState.value.bookmarks
        )
        showMessage("Закладка добавлена в «$folder»")
    }

    fun removeBookmark(id: String) {
        _uiState.value = _uiState.value.copy(
            bookmarks = _uiState.value.bookmarks.filter { it.id != id }
        )
        showMessage("Закладка удалена")
    }

    fun saveToResearch(page: WebPage, quote: String? = null, notes: String = "") {
        val textToSave = quote ?: page.lead.ifBlank { page.paragraphs.firstOrNull() ?: page.title }
        val item = ResearchItem(
            url = page.url,
            title = page.title,
            author = page.author,
            publicationDate = "2026",
            language = page.language,
            sourceText = textToSave,
            notes = notes.ifBlank { "Сохранено из браузера РУСЬ" },
            tags = listOf("Исследование", page.domain)
        )
        ResearchStudio.addItem(item)
        showMessage("Материал сохранён в исследовательскую лабораторию")
    }

    fun toggleReaderMode() {
        val newState = !_uiState.value.isReaderModeActive
        _uiState.value = _uiState.value.copy(isReaderModeActive = newState)
        if (!newState) {
            ReaderModeManager.stopSpeaking()
        }
    }

    fun toggleAiPanel() {
        val currentPage = _uiState.value.currentPage
        if (currentPage != null && !_uiState.value.isAiPanelActive) {
            val analysis = RusAiCore.summarizePage(currentPage)
            PrivacyCore.recordLocalAiInference()
            _uiState.value = _uiState.value.copy(
                isAiPanelActive = true,
                aiAnalysisResult = analysis
            )
        } else {
            _uiState.value = _uiState.value.copy(isAiPanelActive = !_uiState.value.isAiPanelActive)
        }
    }

    fun toggleTranslation() {
        val currentPage = _uiState.value.currentPage ?: return
        val currentResult = _uiState.value.translationResult

        if (currentResult == null) {
            val textToTranslate = currentPage.paragraphs.joinToString("\n\n")
            val target = if (currentPage.language == "ru") "en" else "ru"
            val res = TranslationEngine.translate(textToTranslate, targetLang = target, sourceLang = currentPage.language)
            _uiState.value = _uiState.value.copy(
                isBilingualActive = true,
                translationResult = res
            )
            showMessage("Включён двуязычный исследовательский режим (Оригинал / Перевод)")
        } else {
            _uiState.value = _uiState.value.copy(
                isBilingualActive = !_uiState.value.isBilingualActive
            )
        }
    }

    fun navigateTo(screen: BrowserScreen) {
        _uiState.value = _uiState.value.copy(currentScreen = screen, isOmniActive = false)
    }

    fun showMessage(msg: String) {
        _uiState.value = _uiState.value.copy(statusMessage = msg)
    }

    fun clearMessage() {
        _uiState.value = _uiState.value.copy(statusMessage = null)
    }

    fun setCitationStyle(style: CitationStyle) {
        _uiState.value = _uiState.value.copy(selectedCitationStyle = style)
    }

    private fun updateTab(tabId: String, transform: (BrowserTab) -> BrowserTab) {
        val updated = _uiState.value.tabs.map { if (it.id == tabId) transform(it) else it }
        _uiState.value = _uiState.value.copy(tabs = updated)
    }
}
