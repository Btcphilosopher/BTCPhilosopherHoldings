package com.example.language

data class LanguageInfo(
    val code: String,
    val nativeName: String,
    val russianName: String,
    val script: String,
    val isPrimary: Boolean = false
)

object LanguageRegistry {
    val PRIMARY_LANGUAGE = LanguageInfo("ru", "Русский", "Русский", "Кириллица", isPrimary = true)

    val SUPPORTED_LANGUAGES = listOf(
        PRIMARY_LANGUAGE,
        LanguageInfo("en", "English", "Английский", "Latin"),
        LanguageInfo("be", "Беларуская", "Белорусский", "Кириллица"),
        LanguageInfo("kk", "Қазақша", "Казахский", "Кириллица / Latin"),
        LanguageInfo("uk", "Українська", "Украинский", "Кириллица"),
        LanguageInfo("hy", "Հայերեն", "Армянский", "Армянский"),
        LanguageInfo("ka", "ქართული", "Грузинский", "Грузинский"),
        LanguageInfo("zh", "中文 (简体)", "Китайский", "Хань"),
        LanguageInfo("de", "Deutsch", "Немецкий", "Latin"),
        LanguageInfo("fr", "Français", "Французский", "Latin"),
        LanguageInfo("es", "Español", "Испанский", "Latin"),
        LanguageInfo("ja", "日本語", "Японский", "Кандзи / Кана"),
        LanguageInfo("ko", "한국어", "Корейский", "Хангыль")
    )

    fun detectScript(text: String): String {
        var cyrillic = 0
        var latin = 0
        var han = 0
        for (char in text) {
            when (char) {
                in '\u0400'..'\u04FF' -> cyrillic++
                in 'a'..'z', in 'A'..'Z' -> latin++
                in '\u4E00'..'\u9FFF' -> han++
            }
        }
        return when {
            cyrillic >= latin && cyrillic > 0 -> "Кириллица"
            latin > cyrillic -> "Латиница"
            han > 0 -> "Иероглифика"
            else -> "Смешанный"
        }
    }

    fun isPureCyrillic(text: String): Boolean {
        val letters = text.filter { it.isLetter() }
        if (letters.isEmpty()) return true
        return letters.all { it in '\u0400'..'\u04FF' || it in "Ёё" }
    }
}
