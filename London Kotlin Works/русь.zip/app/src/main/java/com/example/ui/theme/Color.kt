package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Scheme: Milky White, Crisp Slate, Steel, Deep Graphite, Functional Crimson Accent
val RusLightBackground = Color(0xFFF8FAFC)
val RusLightSurface = Color(0xFFFFFFFF)
val RusLightSurfaceVariant = Color(0xFFF1F5F9)
val RusLightPrimary = Color(0xFF0F172A)
val RusLightOnPrimary = Color(0xFFFFFFFF)
val RusLightSecondary = Color(0xFF334155)
val RusLightTertiary = Color(0xFFD32F2F) // Functional Rus Red accent
val RusLightOutline = Color(0xFFCBD5E1)
val RusLightTextPrimary = Color(0xFF0F172A)
val RusLightTextSecondary = Color(0xFF64748B)

// Dark Scheme: Deep Graphite, Midnight Navy, Steel Gray, Slate
val RusDarkBackground = Color(0xFF090D16)
val RusDarkSurface = Color(0xFF0F172A)
val RusDarkSurfaceVariant = Color(0xFF1E293B)
val RusDarkPrimary = Color(0xFFF8FAFC)
val RusDarkOnPrimary = Color(0xFF0F172A)
val RusDarkSecondary = Color(0xFF94A3B8)
val RusDarkTertiary = Color(0xFFEF4444) // Crisp Accent
val RusDarkOutline = Color(0xFF334155)
val RusDarkTextPrimary = Color(0xFFF8FAFC)
val RusDarkTextSecondary = Color(0xFF94A3B8)

// Reader Sepia Scheme
val RusSepiaBackground = Color(0xFFF7F1E5)
val RusSepiaSurface = Color(0xFFEDE4D3)
val RusSepiaText = Color(0xFF2C241D)

// Status / Privacy Colors
val RusShieldGreen = Color(0xFF10B981)
val RusWarningAmber = Color(0xFFF59E0B)
val RusAccentBlue = Color(0xFF2563EB)
