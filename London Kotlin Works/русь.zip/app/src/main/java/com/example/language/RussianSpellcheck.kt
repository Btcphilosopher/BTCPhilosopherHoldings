package com.example.language

object RussianSpellcheck {

    private val COMMON_TYPOS = mapOf(
        "превет" to "привет",
        "броузер" to "браузер",
        "росийский" to "российский",
        "руский" to "русский",
        "екран" to "экран",
        "интернет" to "интернет",
        "интиллигенция" to "интеллигенция",
        "програмирование" to "программирование",
        "самолет" to "самолёт",
        "ежик" to "ёжик",
        "москва" to "Москва",
        "петербург" to "Санкт-Петербург",
        "ядерный" to "ядерный",
        "реактор" to "реактор"
    )

    fun checkAndSuggest(text: String): String? {
        val trimmed = text.trim()
        val lower = trimmed.lowercase()

        // 1. Прямая проверка частых опечаток
        for ((typo, fix) in COMMON_TYPOS) {
            if (lower.contains(typo)) {
                return trimmed.replace(Regex("(?i)$typo"), fix)
            }
        }

        // 2. Проверка раскладки клавиатуры
        if (trimmed.all { it in 'a'..'z' || it in 'A'..'Z' || it.isWhitespace() }) {
            val converted = TransliterationEngine.fixKeyboardLayout(trimmed)
            if (converted.any { it in '\u0400'..'\u04FF' } && converted != trimmed) {
                return converted
            }
        }

        return null
    }
}
