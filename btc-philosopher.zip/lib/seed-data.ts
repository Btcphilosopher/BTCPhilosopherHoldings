import {
  UserProfile,
  Category,
  Thread,
  KnowledgePage,
  MarketMetrics,
  BookmarkCollection,
  Notification,
  DirectMessage,
  Report,
  AuditEvent,
  ReputationEvent,
} from './types';

export const MOCK_USERS: Record<string, UserProfile> = {
  'u-1': {
    id: 'u-1',
    username: 'SatoshiReader',
    displayName: 'SatoshiReader',
    avatarUrl: 'https://picsum.photos/seed/satoshi_reader/150/150',
    bio: 'Decentralized monetary systems researcher & cypherpunk historian.',
    role: 'Senior Moderator',
    joinDate: 'Jan 2021',
    location: 'Zurich, Switzerland',
    identity: {
      nostr: 'npub180cvv07tjdrx9w3qch0sl5x66tk9xcvbhaccc2tm3g88unsns4ssp292',
      pgp: '4F92 B71A 902E E801 33C1',
      lightningAddress: 'satoshireader@getalby.com',
      btcAddress: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh',
      github: 'satoshireader',
    },
    reputation: 9450,
    expertise: [
      { category: 'Bitcoin Protocol', score: 5, derivedReason: '142 peer-reviewed technical post contributions' },
      { category: 'Monetary Economics', score: 5, derivedReason: 'Top cited long-form essays on monetary premium' },
      { category: 'Cryptography', score: 4, derivedReason: 'Verified protocol review contributor' },
    ],
    badges: ['Genesis Member', 'Top Contributor 2024', 'Verified Researcher', 'Senior Mod'],
    followersCount: 1420,
    followingCount: 89,
    postsCount: 512,
    threadsCount: 38,
    essaysCount: 12,
  },
  'u-2': {
    id: 'u-2',
    username: 'Hayekian',
    displayName: 'Hayekian Mind',
    avatarUrl: 'https://picsum.photos/seed/hayekian/150/150',
    bio: 'Austrian Economics practitioner. Analyzing spontaneous order, calculation problems, and market signals.',
    role: 'Trusted User',
    joinDate: 'Mar 2021',
    location: 'Vienna, Austria',
    identity: {
      lightningAddress: 'hayekian@stacker.news',
      btcAddress: 'bc1q9v8k3f4g5h6j7k8l9m0n1p2q3r4s5t6u7v8w9x',
      website: 'https://hayekian.org',
    },
    reputation: 7820,
    expertise: [
      { category: 'Austrian Economics', score: 5, derivedReason: 'Author of landmark series on Subjective Value' },
      { category: 'Central Banking', score: 4, derivedReason: '34 comparative analysis threads' },
      { category: 'Philosophy of Economics', score: 5, derivedReason: 'High citation density on Misesian methodology' },
    ],
    badges: ['Austrian Scholar', 'Top Essayist', 'Peer Reviewer'],
    followersCount: 980,
    followingCount: 42,
    postsCount: 380,
    threadsCount: 24,
    essaysCount: 9,
  },
  'u-3': {
    id: 'u-3',
    username: 'BlockArchitect',
    displayName: 'Block Architect',
    avatarUrl: 'https://picsum.photos/seed/blockarch/150/150',
    bio: 'Distributed systems engineer. Focused on consensus mechanisms, Schnorr signatures, and zero-knowledge proofs.',
    role: 'Moderator',
    joinDate: 'Nov 2021',
    location: 'Austin, TX',
    identity: {
      github: 'blockarchitect-dev',
      pgp: '8A9B 7C6D 5E4F 3A2B',
      lightningAddress: 'blockarchitect@ln.tips',
    },
    reputation: 6340,
    expertise: [
      { category: 'Bitcoin Protocol', score: 5, derivedReason: 'Core protocol benchmark disclosures' },
      { category: 'Distributed Systems', score: 5, derivedReason: '12 consensus trade-off papers cited' },
      { category: 'Cybersecurity', score: 4, derivedReason: 'Threat model contributor' },
    ],
    badges: ['Protocol Dev', 'Security Researcher'],
    followersCount: 750,
    followingCount: 65,
    postsCount: 290,
    threadsCount: 19,
    essaysCount: 5,
  },
  'u-4': {
    id: 'u-4',
    username: 'MonetaryRealist',
    displayName: 'Monetary Realist',
    avatarUrl: 'https://picsum.photos/seed/monetary/150/150',
    bio: 'Macroeconomist studying international monetary regimes, debt cycles, and gold/BTC reserve mechanics.',
    role: 'User',
    joinDate: 'Feb 2022',
    location: 'London, UK',
    identity: {
      website: 'https://monetaryrealism.com',
    },
    reputation: 4910,
    expertise: [
      { category: 'Macroeconomics', score: 5, derivedReason: 'Extensive sovereign debt breakdown analyses' },
      { category: 'Inflation', score: 4, derivedReason: 'Historical inflation vector models' },
    ],
    badges: ['Macro Analyst'],
    followersCount: 510,
    followingCount: 30,
    postsCount: 195,
    threadsCount: 14,
    essaysCount: 4,
  },
  'u-5': {
    id: 'u-5',
    username: 'CypherScholar',
    displayName: 'CypherScholar',
    avatarUrl: 'https://picsum.photos/seed/cypherscholar/150/150',
    bio: 'Philosopher of technology & cryptographic privacy advocate.',
    role: 'Trusted User',
    joinDate: 'May 2022',
    identity: {
      nostr: 'npub19999cypherpunkqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq',
    },
    reputation: 5210,
    expertise: [
      { category: 'Philosophy of Technology', score: 5, derivedReason: 'Ethical implications of sovereign identity' },
      { category: 'Privacy', score: 4, derivedReason: 'CoinJoin & Blind Signature essays' },
    ],
    badges: ['Privacy Pioneer'],
    followersCount: 620,
    followingCount: 50,
    postsCount: 210,
    threadsCount: 16,
    essaysCount: 6,
  },
};

export const MOCK_CATEGORIES: Category[] = [
  { id: 'cat-btc-disc', group: 'BITCOIN', name: 'Bitcoin Discussion', slug: 'bitcoin-discussion', description: 'General strategic and high-level discussion on Bitcoin as a paradigm shift.', threadsCount: 1420, postsCount: 18450, icon: 'Coins' },
  { id: 'cat-btc-proto', group: 'BITCOIN', name: 'Bitcoin Protocol', slug: 'bitcoin-protocol', description: 'Deep technical consensus, softfork proposals, Taproot, Scripting, and node engineering.', threadsCount: 890, postsCount: 12400, icon: 'Cpu' },
  { id: 'cat-btc-lightning', group: 'BITCOIN', name: 'Lightning Network', slug: 'lightning', description: 'Layer-2 scaling, payment routing, liquidity management, and channel graph dynamics.', threadsCount: 640, postsCount: 8900, icon: 'Zap' },
  { id: 'cat-btc-econ', group: 'BITCOIN', name: 'Bitcoin Economics', slug: 'bitcoin-economics', description: 'Monetary properties, stock-to-flow debates, fee markets, and monetary premium.', threadsCount: 1120, postsCount: 15600, icon: 'TrendingUp' },
  { id: 'cat-btc-phil', group: 'BITCOIN', name: 'Bitcoin Philosophy', slug: 'bitcoin-philosophy', description: 'Sovereignty, time preference, immutability, social contracts, and digital realism.', threadsCount: 780, postsCount: 9800, icon: 'BookOpen' },
  { id: 'cat-econ-austrian', group: 'ECONOMICS', name: 'Austrian Economics', slug: 'austrian-economics', description: 'Praxeology, Mengerian origin of money, Hayekian knowledge problems, and capital theory.', threadsCount: 950, postsCount: 14100, icon: 'Scale' },
  { id: 'cat-econ-macro', group: 'ECONOMICS', name: 'Macroeconomics', slug: 'macroeconomics', description: 'Global liquidity, sovereign debt cycles, yield curves, and fiat currency debasement.', threadsCount: 810, postsCount: 11200, icon: 'Globe' },
  { id: 'cat-econ-banking', group: 'ECONOMICS', name: 'Central Banking & Inflation', slug: 'central-banking', description: 'Monetary policy analysis, Federal Reserve operations, interest rates, and cantillon effects.', threadsCount: 690, postsCount: 9300, icon: 'Landmark' },
  { id: 'cat-tech-ai', group: 'TECHNOLOGY', name: 'Artificial Intelligence', slug: 'artificial-intelligence', description: 'AI agent economies, proof of work for machine verification, and autonomous compute.', threadsCount: 540, postsCount: 7200, icon: 'Bot' },
  { id: 'cat-tech-crypto', group: 'TECHNOLOGY', name: 'Cryptography & Privacy', slug: 'cryptography', description: 'Elliptic curves, zero-knowledge proofs, multiparty computation, and metadata hygiene.', threadsCount: 620, postsCount: 8100, icon: 'KeyRound' },
  { id: 'cat-phil-epistem', group: 'PHILOSOPHY', name: 'Epistemology & Ethics', slug: 'epistemology', description: 'Truth models, proof systems, property rights ethics, and game theoretic morality.', threadsCount: 490, postsCount: 6400, icon: 'Brain' },
  { id: 'cat-soc-institutions', group: 'SOCIETY', name: 'Institutions & Civilisation', slug: 'institutions', description: 'Network states, governance, legal frameworks, and long-term societal decay/renewal.', threadsCount: 510, postsCount: 6700, icon: 'Building2' },
];

export const MOCK_THREADS: Thread[] = [
  {
    id: 'th-1',
    slug: 'is-bitcoin-a-monetary-asset-or-a-monetary-network',
    title: 'Is Bitcoin a Monetary Asset or a Monetary Network? Re-evaluating the Liquidity Dichotomy',
    subtitle: 'An inquiry into whether Bitcoin’s terminal value derives from its unconfiscatable bearer asset nature or its settlement network dynamics.',
    categoryId: 'cat-btc-econ',
    categoryName: 'Bitcoin Economics',
    authorId: 'u-1',
    author: MOCK_USERS['u-1'],
    type: 'THREAD',
    state: 'PINNED',
    decayStatus: 'CURRENT',
    createdAt: '2026-08-15T10:30:00Z',
    lastActivityAt: '2026-09-12T14:22:00Z',
    viewsCount: 14280,
    repliesCount: 42,
    citationsCount: 18,
    reputationScore: 485,
    tags: ['monetary-theory', 'liquidity', 'settlement', 'austrian-economics', 'bearer-asset'],
    aiSummary: {
      summary: 'The thread debates whether Bitcoin’s primary value driver is its physical status as a non-sovereign bearer asset (digital gold) or its network layer capabilities as a final settlement engine. Participants draw parallels to historical gold standards vs modern clearing systems.',
      questions: [
        'Can a network maintain monetary premium if transaction fees price out retail on-chain users?',
        'Is finality of settlement superior to transaction throughput in establishing global reserve status?'
      ],
      arguments: [
        'SatoshiReader claims absolute bearer sovereignty (unconfiscability) is the foundational requirement upon which network utility relies.',
        'Hayekian argues that liquidity network effects determine monetary selection prior to store-of-value consolidation.'
      ],
      counterarguments: [
        'MonetaryRealist notes that pure bearer assets without efficient L2 scaling risk being re-hypothecated by custodial intermediaries.'
      ],
      sources: [
        'Carl Menger — On the Origins of Money (1892)',
        'Ludwig von Mises — The Theory of Money and Credit (1912)',
        'Nick Szabo — Shelling Out: The Origins of Money (2002)'
      ],
      disagreements: [
        'Disagreement on whether Lightning Network constitutes true peer-to-peer bitcoin or synthetic credit claims.'
      ],
      unresolved: [
        'Long-term security budget dynamic when subsidy drops below 1 BTC per block.'
      ],
      model: 'gemini-3.8-flash',
      generatedAt: '2026-09-12T15:00:00Z'
    },
    posts: [
      {
        id: 'post-101',
        threadId: 'th-1',
        postNumber: 1,
        authorId: 'u-1',
        author: MOCK_USERS['u-1'],
        createdAt: '2026-08-15T10:30:00Z',
        content: `### 1. Introduction & Problem Statement

In contemporary monetary literature, Bitcoin is frequently classified either as "digital gold" (emphasizing its absolute scarcity and unconfiscatable bearer nature) or as a "disruptive payment rails system" (emphasizing low friction peer-to-peer settlement).

However, treating these two properties as interchangeable ignores a fundamental paradox in monetary history:

> **Can a monetary good retain its status as a primary reserve asset if the physical costs of settlement force the vast majority of economic agents into secondary derivative rails?**

### 2. The Theoretical Framework

To answer this, we must examine the concept of **Salability across Space and Time** as articulated by Carl Menger in *On the Origins of Money*. 

A good becomes money not by social decree, but through a gradual process of market selection based on its degree of liquidity.

\`\`\`latex
S_t = \\lim_{\\Delta t \\to 0} \\frac{V_{instant}}{V_{par}}
\`\`\`

When evaluating Bitcoin, we observe two distinct layers of utility:

1. **The Bearer Asset Layer (UTF-8 / Consensus)**: Absolute mathematical scarcity ($21,000,000$ cap), cryptographic auditability, non-custodial ownership.
2. **The Settlement Network Layer (UTXO / Mempool)**: The throughput constraint of $\\sim 7$ transactions per second on base layer.

### 3. Argument Structure

Below, I formalize the central thesis:`,
        arguments: [
          { id: 'arg-1', type: 'CLAIM', text: 'Bitcoin’s primary value is derived strictly from its property as an unconfiscatable bearer asset, not its base-layer transaction capacity.' },
          { id: 'arg-2', type: 'EVIDENCE', text: 'Historical gold reserve banking showed that settlement finality between central banks preserves monetary premium even when retail transactions move to credit paper.' },
          { id: 'arg-3', type: 'CONCLUSION', text: 'Layer 2 scaling solutions do not dilute Bitcoin’s monetary premium as long as base-layer settlement remains decentralized and cryptographically verifiable.' }
        ],
        citations: [
          {
            id: 'cit-1',
            sourceType: 'book',
            title: 'On the Origins of Money',
            author: 'Carl Menger',
            date: '1892',
            publisher: 'Economic Journal',
            quote: 'Money has not been generated by law. In its origin it is a social institution...'
          },
          {
            id: 'cit-2',
            sourceType: 'paper',
            title: 'Shelling Out: The Origins of Money',
            author: 'Nick Szabo',
            date: '2002',
            url: 'https://nakamotoinstitute.org/shelling-out/',
            quote: 'Unforgeable costliness is the essential characteristic of collectibles and early money.'
          }
        ],
        reactions: { '🧠': 42, '⚡': 28, '📜': 19 },
        userReactions: ['🧠']
      },
      {
        id: 'post-102',
        threadId: 'th-1',
        postNumber: 2,
        authorId: 'u-2',
        author: MOCK_USERS['u-2'],
        createdAt: '2026-08-15T12:15:00Z',
        quotePostId: 'post-101',
        quoteSnippet: {
          postNumber: 1,
          authorName: 'SatoshiReader',
          text: 'Can a monetary good retain its status as a primary reserve asset if physical settlement costs force retail onto secondary rails?'
        },
        content: `@SatoshiReader brings up a vital point, but I must raise a **Hayekian counter-argument** regarding market price signals.

In *The Use of Knowledge in Society* (1945), Friedrich Hayek demonstrated that price signals act as decentralized data aggregation mechanisms. If retail users are completely priced out of on-chain UTXO management due to high fee environments (e.g., $100+ per L1 transaction), they lose the direct ability to audit their own reserves.

### The Risk of Re-hypothecation

When users interact strictly through custodial Layer-2 wrappers or centralized exchange IOUs, the *information integrity* of the $21$ million hard cap begins to degrade. Fractional reserve banking did not arise because gold was flawed; it arose because gold was heavy and expensive to clear.

\`\`\`
Base Layer (Physical Gold / L1 UTXO) 
  └─► Secondary Banks (Paper Receipts / Custodial L2) 
        └─► Fractional Credit Expansion (Paper Supply > Real Supply)
\`\`\`

Therefore, **network access is not secondary to asset sovereignty — it is the shield that prevents asset financialization.**`,
        arguments: [
          { id: 'arg-4', type: 'COUNTERARGUMENT', text: 'If L1 fee barriers force 99% of population onto custodial L2s, fractional reserve credit expansion will re-emerge, undermining the 21M hard cap.' },
          { id: 'arg-5', type: 'EVIDENCE', text: '1930s gold reserve nationalization succeeded precisely because retail holders held paper certificates rather than physical gold coins.' }
        ],
        citations: [
          {
            id: 'cit-3',
            sourceType: 'article',
            title: 'The Use of Knowledge in Society',
            author: 'Friedrich A. Hayek',
            date: '1945',
            publisher: 'American Economic Review',
            quote: 'The price system is just one of those formations which man has learned to use after he had stumbled upon it without understanding it.'
          }
        ],
        reactions: { '🧠': 31, '⚖️': 15 },
        userReactions: []
      },
      {
        id: 'post-103',
        threadId: 'th-1',
        postNumber: 3,
        authorId: 'u-3',
        author: MOCK_USERS['u-3'],
        createdAt: '2026-08-15T15:45:00Z',
        content: `From a **distributed protocol engineering perspective**, we must distinguish between *custodial L2s* and *trust-minimized L2s* (such as Lightning, Ark, and Zero-Knowledge Rollups).

In Lightning:
- You retain cryptographic ownership via HTLCs/PTLCs.
- You can unilateral exit to L1 at any point by broadcasting pre-signed commitment transactions.

The bottleneck isn't protocol security; it's **inbound liquidity management** and **state chain bandwidth**.

Let's look at the math for channel closure under high L1 congestion:

$$\\text{Max Channels Exit} = \\frac{\\text{Block Size Bytes} - \\text{Header Bytes}}{\\text{Average Commitment Tx Bytes}} \\times 144 \\text{ blocks/day}$$

With 4MB block weight, that caps global unilateral closures at roughly 350,000 channels per day. This is why non-interactive channel factories and client-side validation (RGB / Taproot Assets) are essential for retaining bearer asset properties without requiring every coffee transaction to hit the mempool.`,
        arguments: [
          { id: 'arg-6', type: 'ARGUMENT', text: 'Trust-minimized Layer 2 protocols preserve mathematical bearer security through unilateral exit guarantees, preventing fractional reserve expansion.' }
        ],
        reactions: { '⚡': 39, '🛠️': 22 },
        userReactions: []
      }
    ]
  },
  {
    id: 'th-2',
    slug: 'the-knowledge-problem-and-decentralised-markets',
    title: 'The Knowledge Problem and Decentralised Markets: Hayekian Calculations in Peer-to-Peer Consensus',
    subtitle: 'Why central planning of block limits fails to account for local node operator opportunity costs.',
    categoryId: 'cat-econ-austrian',
    categoryName: 'Austrian Economics',
    authorId: 'u-2',
    author: MOCK_USERS['u-2'],
    type: 'ESSAY',
    state: 'PUBLISHED',
    decayStatus: 'CURRENT',
    createdAt: '2026-08-20T09:00:00Z',
    lastActivityAt: '2026-09-11T18:10:00Z',
    viewsCount: 9850,
    repliesCount: 28,
    citationsCount: 14,
    reputationScore: 390,
    tags: ['austrian-economics', 'hayek', 'knowledge-problem', 'consensus', 'blocksize'],
    coverImage: 'https://picsum.photos/seed/hayek_essay/1200/400',
    posts: [
      {
        id: 'post-201',
        threadId: 'th-2',
        postNumber: 1,
        authorId: 'u-2',
        author: MOCK_USERS['u-2'],
        createdAt: '2026-08-20T09:00:00Z',
        content: `# Abstract

The calculation debate (*Socialist Calculation Debate*) initiated by Ludwig von Mises and expanded by F.A. Hayek established that no central planning body can aggregate tacit, localized, and context-dependent knowledge. 

In this essay, we apply Hayek’s *Economic Calculation Problem* to decentralized protocol governance, specifically analyzing how dynamic fee markets act as decentralized price discovery mechanisms for scarce block space.

---

## I. Tacit Knowledge in Node Validation

Every node operator in a peer-to-peer network possesses unique constraints:
- Local ISP bandwidth & latency limits
- Hardware disk I/O performance
- Jurisdiction-specific electrical and regulatory costs

When a protocol hardcodes parameters (such as block size caps or minimum relay fees), it imposes an arbitrary central plan upon heterogeneous node operators.

\`\`\`
Central Planner (Hardcoded Limits) ────► Ignores Local Resource Constraints
Market Dynamic (Fee Auctions + Mempool) ─► Discovers True Marginal Cost of Verification
\`\`\`

## II. Proof of Work as an Information Aggregator

Proof of Work is not merely a security mechanism; it is a **real-time converter of physical energy into economic truth**. The hash rate is the unforgeable sum of millions of private economic decisions made across the globe under competing cost structures.

---

> "The peculiar character of the problem of a rational economic order is determined precisely by the fact that the knowledge of the circumstances of which we must make use never exists in concentrated or integrated form." — F.A. Hayek`,
        arguments: [
          { id: 'arg-7', type: 'CLAIM', text: 'Proof of Work is an economic information aggregator that solves the decentralized calculation problem for network state consensus.' }
        ],
        citations: [
          {
            id: 'cit-4',
            sourceType: 'book',
            title: 'Individualism and Economic Order',
            author: 'F.A. Hayek',
            date: '1948',
            publisher: 'University of Chicago Press',
            quote: 'Knowledge of the particular circumstances of time and place.'
          }
        ],
        reactions: { '📜': 48, '🧠': 37 },
        userReactions: ['📜']
      }
    ]
  },
  {
    id: 'th-3',
    slug: 'does-scarcity-create-monetary-value-critique-s2f',
    title: 'Does Scarcity Create Monetary Value? A Critique of Pure Stock-to-Flow Models',
    subtitle: 'Deconstructing the distinction between absolute mathematical scarcity and subjective monetary demand.',
    categoryId: 'cat-btc-econ',
    categoryName: 'Bitcoin Economics',
    authorId: 'u-4',
    author: MOCK_USERS['u-4'],
    type: 'QUESTION',
    state: 'PUBLISHED',
    decayStatus: 'CURRENT',
    createdAt: '2026-08-28T14:10:00Z',
    lastActivityAt: '2026-09-10T11:05:00Z',
    viewsCount: 7410,
    repliesCount: 19,
    citationsCount: 9,
    reputationScore: 265,
    tags: ['stock-to-flow', 'subjective-value', 'scarcity', 'monetary-economics', 'critique'],
    poll: {
      id: 'poll-1',
      question: 'What is the primary driver of Bitcoin’s long-term purchasing power?',
      type: 'single',
      options: [
        { id: 'opt-1', text: 'Strict algorithmic supply schedule (21M cap & halvings)', votes: 142 },
        { id: 'opt-2', text: 'Subjective liquidity preference and unconfiscatable reserve utility', votes: 210 },
        { id: 'opt-3', text: 'Network effect of developer, node, & institutional adoption', votes: 88 },
        { id: 'opt-4', text: 'Energy expenditure anchoring cost of production', votes: 54 }
      ],
      isAnonymous: false,
      totalVotes: 494,
      userVotedOptionIds: ['opt-2']
    },
    posts: [
      {
        id: 'post-301',
        threadId: 'th-3',
        postNumber: 1,
        authorId: 'u-4',
        author: MOCK_USERS['u-4'],
        createdAt: '2026-08-28T14:10:00Z',
        content: `Many Bitcoin analysts have historically relied on econometric models like Stock-to-Flow (S2F) to assert that high ratios of existing stock to annual production automatically dictate high purchasing power.

However, from an Austrian perspective of **Subjective Value Theory** (Carl Menger, Eugen von Böhm-Bawerk):

1. **Scarcity is a necessary, but not sufficient condition for value.**
2. A unique painting created by an unknown artist is strictly scarce ($1/1$), yet possesses near-zero market value.
3. Monetary goods require *ongoing subjective demand* for liquidity and store-of-value function.

I pose this question to the forum:

**How do we formalize the relationship between Bitcoin’s fixed supply curve and the fluctuating velocity of money ($V$) under liquidity preference shifts?**`,
        arguments: [
          { id: 'arg-8', type: 'QUESTION', text: 'Is supply scarcity capable of driving price without accounting for marginal utility shifts in liquidity preference?' }
        ],
        citations: [],
        reactions: { '❓': 24, '🧠': 18 },
        userReactions: []
      }
    ]
  },
  {
    id: 'th-4',
    slug: 'proof-of-work-as-an-economic-signal',
    title: 'Proof of Work as a Physical Economic Signal: Entropy Reduction vs Capital Commitment',
    subtitle: 'Why energy expenditure cannot be faked or social engineered.',
    categoryId: 'cat-btc-proto',
    categoryName: 'Protocol Engineering',
    authorId: 'u-3',
    author: MOCK_USERS['u-3'],
    type: 'THREAD',
    state: 'PUBLISHED',
    decayStatus: 'CURRENT',
    createdAt: '2026-09-02T11:00:00Z',
    lastActivityAt: '2026-09-13T07:40:00Z',
    viewsCount: 6120,
    repliesCount: 15,
    citationsCount: 11,
    reputationScore: 310,
    tags: ['proof-of-work', 'thermodynamics', 'game-theory', 'consensus', 'security-budget'],
    posts: [
      {
        id: 'post-401',
        threadId: 'th-4',
        postNumber: 1,
        authorId: 'u-3',
        author: MOCK_USERS['u-3'],
        createdAt: '2026-09-02T11:00:00Z',
        content: `Proof of Stake protocols attempt to replace physical energy expenditure with internal capital locking. However, this creates an un-anchored circular security model:

> **In Proof of Stake, the state dictates who holds the capital, and the capital dictates the state.**

Proof of Work breaks this circularity by tying ledger state changes to the laws of thermodynamics:

$$\\Delta S_{universe} > 0 \\quad \\text{and} \\quad W = \\int F \\cdot ds$$

Energy spent in hashing is irreversibly expended into entropy. It cannot be reverted by legal decree, political collusion, or administrative hard forks without expending equal or greater physical energy.`,
        arguments: [
          { id: 'arg-9', type: 'CLAIM', text: 'Proof of Work grounds digital consensus in irreversible thermodynamic physics, preventing political history rewrite.' }
        ],
        reactions: { '⚡': 52, '🔬': 34 },
        userReactions: ['⚡']
      }
    ]
  }
];

export const MOCK_KNOWLEDGE_PAGES: KnowledgePage[] = [
  {
    id: 'kp-1',
    slug: 'bitcoin-monetary-theory',
    title: 'Bitcoin Monetary Theory',
    category: 'Bitcoin Economics',
    summary: 'The study of Bitcoin’s monetary properties, supply dynamics, purchasing power stabilization, and role as an unconfiscatable global reserve asset.',
    keyQuestions: [
      'How does an inelastic supply curve respond to massive demand shocks?',
      'Can Bitcoin achieve unit of account status without price volatility stabilizing?',
      'What is the interaction between L1 settlement fees and monetary velocity?'
    ],
    importantThreadIds: ['th-1', 'th-3'],
    importantUserIds: ['u-1', 'u-2', 'u-4'],
    sources: [
      {
        id: 's-1',
        sourceType: 'book',
        title: 'The Bitcoin Standard',
        author: 'Saifedean Ammous',
        date: '2018',
        publisher: 'Wiley',
        quote: 'Bitcoin is the hardest money ever created...'
      },
      {
        id: 's-2',
        sourceType: 'paper',
        title: 'Bitcoin: A Peer-to-Peer Electronic Cash System',
        author: 'Satoshi Nakamoto',
        date: '2008',
        quote: 'A purely peer-to-peer version of electronic cash would allow online payments to be sent directly from one party to another...'
      }
    ],
    debates: [
      { title: 'Stock-to-Flow vs Subjective Value', summary: 'Debate on whether scarcity alone dictates purchasing power or if subjective marginal utility remains primary.' },
      { title: 'Store of Value vs Medium of Exchange First', summary: 'Discussion on whether medium-of-exchange adoption precedes store-of-value status.' }
    ],
    relatedConcepts: ['Austrian Economics', 'Salability', 'Stock-to-Flow', 'Lightning Network', 'Unit of Account'],
    timeline: [
      { year: '2008', event: 'Satoshi Nakamoto publishes whitepaper detailing cryptographic proof of work.' },
      { year: '2009', event: 'Genesis block mined with embedded Times headline on bank bailouts.' },
      { year: '2012', event: 'First Bitcoin block halving reduces subsidy from 50 to 25 BTC.' },
      { year: '2024', event: 'Fourth block halving reduces subsidy to 3.125 BTC.' }
    ]
  },
  {
    id: 'kp-2',
    slug: 'austrian-economics',
    title: 'Austrian Economics & Sound Money',
    category: 'Economics',
    summary: 'A school of economic thought based on praxeology (the study of human action), subjective value theory, spontaneous order, and private property rights.',
    keyQuestions: [
      'How does artificial interest rate suppression distort capital structure (ABCT)?',
      'Why is subjective marginal utility the foundation of economic calculation?'
    ],
    importantThreadIds: ['th-2', 'th-3'],
    importantUserIds: ['u-2', 'u-1'],
    sources: [
      {
        id: 's-3',
        sourceType: 'book',
        title: 'Human Action',
        author: 'Ludwig von Mises',
        date: '1949',
        publisher: 'Yale University Press',
        quote: 'Economics is not about things and tangible material objects; it is about men, their meanings and actions.'
      }
    ],
    debates: [
      { title: 'The Calculation Problem', summary: 'Why central planning fails to allocate capital efficiently without market prices.' }
    ],
    relatedConcepts: ['Praxeology', 'Hayek Knowledge Problem', 'Time Preference', 'Cantillon Effect'],
    timeline: [
      { year: '1871', event: 'Carl Menger publishes Principles of Economics, founding the Austrian School.' },
      { year: '1912', event: 'Ludwig von Mises publishes The Theory of Money and Credit.' },
      { year: '1945', event: 'F.A. Hayek publishes The Use of Knowledge in Society.' }
    ]
  },
  {
    id: 'kp-3',
    slug: 'lightning-network',
    title: 'Lightning Network & Layer 2 Scaling',
    category: 'Bitcoin Protocol',
    summary: 'A payment channel protocol built on Bitcoin Taproot & Script, enabling instant, micro-fee, bi-directional transactions through off-chain state updates.',
    keyQuestions: [
      'What are the optimal routing algorithms for multi-path payments under privacy constraints?',
      'How do non-interactive channel factories improve onboarding capacity?'
    ],
    importantThreadIds: ['th-1'],
    importantUserIds: ['u-3', 'u-1'],
    sources: [
      {
        id: 's-4',
        sourceType: 'paper',
        title: 'The Bitcoin Lightning Network: Scalable Off-Chain Instant Payments',
        author: 'Joseph Poon & Thaddeus Dryja',
        date: '2016',
        quote: 'Payment channels allow recurring transactions between nodes without publishing to the blockchain.'
      }
    ],
    debates: [
      { title: 'Inbound Liquidity & Channel Capital Costs', summary: 'Balancing routing node profitability against user UX.' }
    ],
    relatedConcepts: ['HTLC', 'PTLC', 'Payment Channels', 'Submarine Swaps', 'Liquidity Ads'],
    timeline: [
      { year: '2016', event: 'Lightning Network whitepaper released by Poon & Dryja.' },
      { year: '2018', event: 'First mainnet Lightning payments executed.' }
    ]
  }
];

export const MOCK_MARKET_METRICS: MarketMetrics = {
  btcPriceUsd: 94850,
  btcPriceChange24h: 3.42,
  marketCapUsd: 1872000000000,
  blockHeight: 894210,
  recommendedFeeSatByte: 18,
  hashrateEh: 685,
  difficultyT: 89.4,
  lastUpdated: '2026-09-13T08:00:00Z',
};

export const MOCK_NOTIFICATIONS: Notification[] = [
  {
    id: 'n-1',
    userId: 'u-1',
    type: 'reply',
    title: 'New Reply from Hayekian Mind',
    message: 'Hayekian Mind replied to your thread "Is Bitcoin a Monetary Asset or a Monetary Network?"',
    linkUrl: '/thread/is-bitcoin-a-monetary-asset-or-a-monetary-network#post-102',
    isRead: false,
    createdAt: '2 hours ago',
  },
  {
    id: 'n-2',
    userId: 'u-1',
    type: 'citation',
    title: 'Citation Added',
    message: 'Block Architect cited your post on Layer-2 consensus exit proofs.',
    linkUrl: '/thread/is-bitcoin-a-monetary-asset-or-a-monetary-network#post-103',
    isRead: false,
    createdAt: '5 hours ago',
  },
  {
    id: 'n-3',
    userId: 'u-1',
    type: 'reputation',
    title: 'Reputation Increased (+25)',
    message: 'Your argument was endorsed as a Top Quality Citation by 3 trusted users.',
    linkUrl: '/profile/SatoshiReader',
    isRead: true,
    createdAt: '1 day ago',
  },
];

export const MOCK_REPUTATION_EVENTS: ReputationEvent[] = [
  {
    id: 'rep-1',
    actorId: 'u-2',
    actorName: 'Hayekian Mind',
    recipientId: 'u-1',
    reason: 'Endorsed argument on monetary salability in Thread #1',
    sourcePostId: 'post-101',
    timestamp: '2026-09-12T14:00:00Z',
    weight: 15,
  },
  {
    id: 'rep-2',
    actorId: 'u-3',
    actorName: 'Block Architect',
    recipientId: 'u-1',
    reason: 'Verified technical citation on consensus immutability',
    sourcePostId: 'post-101',
    timestamp: '2026-09-11T10:30:00Z',
    weight: 10,
  },
];

export const MOCK_REPORTS: Report[] = [
  {
    id: 'rep-101',
    reporterId: 'u-5',
    reporterName: 'CypherScholar',
    targetType: 'post',
    targetId: 'post-999',
    targetTitle: 'Low-effort spam post on speculative meme token',
    reason: 'Off-topic promotional spam violating forum seriousness policy',
    priority: 'medium',
    status: 'OPEN',
    createdAt: '2026-09-13T06:15:00Z',
  },
];

export const MOCK_AUDIT_EVENTS: AuditEvent[] = [
  {
    id: 'aud-1',
    actorId: 'u-1',
    actorName: 'SatoshiReader',
    action: 'PIN_THREAD',
    target: 'Thread #th-1: Is Bitcoin a Monetary Asset...',
    timestamp: '2026-08-15T11:00:00Z',
    details: 'Pinned thread for high citation density and foundational discussion quality.',
  },
];
