'use client';

import { useState, useEffect } from 'react';
import {
  UserProfile,
  Thread,
  Category,
  KnowledgePage,
  MarketMetrics,
  Notification,
  DirectMessage,
  Report,
  AuditEvent,
  ReputationEvent,
  Post,
  Citation,
  ArgumentBlock,
  BookmarkCollection,
} from './types';
import {
  MOCK_USERS,
  MOCK_CATEGORIES,
  MOCK_THREADS,
  MOCK_KNOWLEDGE_PAGES,
  MOCK_MARKET_METRICS,
  MOCK_NOTIFICATIONS,
  MOCK_REPUTATION_EVENTS,
  MOCK_REPORTS,
  MOCK_AUDIT_EVENTS,
} from './seed-data';

// Persistent Local Store Keys
const STORE_KEY_THREADS = 'btc_philosopher_threads';
const STORE_KEY_BOOKMARKS = 'btc_philosopher_bookmarks';
const STORE_KEY_NOTIFS = 'btc_philosopher_notifs';
const STORE_KEY_USER = 'btc_philosopher_current_user_id';
const STORE_KEY_PHILOSOPHER_MODE = 'btc_philosopher_mode_active';
const STORE_KEY_THEME = 'btc_philosopher_theme';

interface AppStoreState {
  currentUserId: string;
  currentUser: UserProfile;
  threads: Thread[];
  categories: Category[];
  knowledgePages: KnowledgePage[];
  marketMetrics: MarketMetrics;
  notifications: Notification[];
  reputationEvents: ReputationEvent[];
  reports: Report[];
  auditEvents: AuditEvent[];
  bookmarkCollections: BookmarkCollection[];
  directMessages: DirectMessage[];
  isPhilosopherMode: boolean;
  isFocusMode: boolean;
  theme: 'dark' | 'light' | 'system';
  activeTipModalUser: UserProfile | null;
  activeCompareThreads: [string, string] | null;
  activeMessageRecipient: UserProfile | null;
  activeReportItem: { type: 'thread' | 'post'; id: string; title: string } | null;
  searchQuery: string;
}

// Initial state builder
function getInitialState(): AppStoreState {
  return {
    currentUserId: 'u-1',
    currentUser: MOCK_USERS['u-1'],
    threads: MOCK_THREADS,
    categories: MOCK_CATEGORIES,
    knowledgePages: MOCK_KNOWLEDGE_PAGES,
    marketMetrics: MOCK_MARKET_METRICS,
    notifications: MOCK_NOTIFICATIONS,
    reputationEvents: MOCK_REPUTATION_EVENTS,
    reports: MOCK_REPORTS,
    auditEvents: MOCK_AUDIT_EVENTS,
    bookmarkCollections: [
      { id: 'bm-1', name: 'Bitcoin Economics', isPrivate: false, threadIds: ['th-1'], postIds: ['post-101'], knowledgePageIds: ['kp-1'] },
      { id: 'bm-2', name: 'Reading List', isPrivate: true, threadIds: ['th-2', 'th-3'], postIds: [], knowledgePageIds: [] },
    ],
    directMessages: [
      {
        id: 'dm-1',
        senderId: 'u-2',
        recipientId: 'u-1',
        sender: MOCK_USERS['u-2'],
        recipient: MOCK_USERS['u-1'],
        content: 'Greetings SatoshiReader. Excellent points on the spatial salability of L1 UTXOs. Have you considered Menger’s second volume?',
        timestamp: 'Yesterday at 18:30',
        isRead: true,
      },
    ],
    isPhilosopherMode: true,
    isFocusMode: false,
    theme: 'dark',
    activeTipModalUser: null,
    activeCompareThreads: null,
    activeMessageRecipient: null,
    activeReportItem: null,
    searchQuery: '',
  };
}

type Listener = () => void;
const listeners = new Set<Listener>();

let state: AppStoreState = getInitialState();

function notifyListeners() {
  listeners.forEach((l) => l());
}

export const store = {
  getState: () => state,

  subscribe: (listener: Listener) => {
    listeners.add(listener);
    return () => listeners.delete(listener);
  },

  // Actions
  setCurrentUser: (userId: string) => {
    if (MOCK_USERS[userId]) {
      state = {
        ...state,
        currentUserId: userId,
        currentUser: MOCK_USERS[userId],
      };
      notifyListeners();
    }
  },

  setPhilosopherMode: (enabled: boolean) => {
    state = { ...state, isPhilosopherMode: enabled };
    notifyListeners();
  },

  setFocusMode: (enabled: boolean) => {
    state = { ...state, isFocusMode: enabled };
    notifyListeners();
  },

  setTheme: (theme: 'dark' | 'light' | 'system') => {
    state = { ...state, theme };
    if (typeof document !== 'undefined') {
      if (theme === 'light') {
        document.documentElement.classList.remove('dark');
        document.documentElement.classList.add('light');
      } else {
        document.documentElement.classList.remove('light');
        document.documentElement.classList.add('dark');
      }
    }
    notifyListeners();
  },

  setSearchQuery: (query: string) => {
    state = { ...state, searchQuery: query };
    notifyListeners();
  },

  openTipModal: (user: UserProfile) => {
    state = { ...state, activeTipModalUser: user };
    notifyListeners();
  },
  closeTipModal: () => {
    state = { ...state, activeTipModalUser: null };
    notifyListeners();
  },

  openCompareModal: (threadId1: string, threadId2: string) => {
    state = { ...state, activeCompareThreads: [threadId1, threadId2] };
    notifyListeners();
  },
  closeCompareModal: () => {
    state = { ...state, activeCompareThreads: null };
    notifyListeners();
  },

  openMessageModal: (recipient: UserProfile) => {
    state = { ...state, activeMessageRecipient: recipient };
    notifyListeners();
  },
  closeMessageModal: () => {
    state = { ...state, activeMessageRecipient: null };
    notifyListeners();
  },

  openReportModal: (item: { type: 'thread' | 'post'; id: string; title: string }) => {
    state = { ...state, activeReportItem: item };
    notifyListeners();
  },
  closeReportModal: () => {
    state = { ...state, activeReportItem: null };
    notifyListeners();
  },

  // Thread actions
  createThread: (newThreadData: {
    title: string;
    subtitle?: string;
    categoryId: string;
    type: 'THREAD' | 'ESSAY' | 'QUESTION' | 'POLL';
    tags: string[];
    content: string;
    arguments?: ArgumentBlock[];
    citations?: Citation[];
    pollQuestion?: string;
    pollOptions?: string[];
  }) => {
    const category = state.categories.find((c) => c.id === newThreadData.categoryId) || state.categories[0];
    const threadId = `th-${Date.now()}`;
    const slug = newThreadData.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');

    const initialPost: Post = {
      id: `post-${Date.now()}`,
      threadId,
      postNumber: 1,
      authorId: state.currentUser.id,
      author: state.currentUser,
      createdAt: new Date().toISOString(),
      content: newThreadData.content,
      arguments: newThreadData.arguments || [],
      citations: newThreadData.citations || [],
      reactions: {},
    };

    const newThread: Thread = {
      id: threadId,
      slug,
      title: newThreadData.title,
      subtitle: newThreadData.subtitle,
      categoryId: category.id,
      categoryName: category.name,
      authorId: state.currentUser.id,
      author: state.currentUser,
      type: newThreadData.type,
      state: 'PUBLISHED',
      decayStatus: 'CURRENT',
      createdAt: new Date().toISOString(),
      lastActivityAt: new Date().toISOString(),
      viewsCount: 1,
      repliesCount: 0,
      citationsCount: (newThreadData.citations || []).length,
      reputationScore: 10,
      tags: newThreadData.tags.length > 0 ? newThreadData.tags : ['bitcoin', 'discussion'],
      posts: [initialPost],
    };

    if (newThreadData.type === 'POLL' && newThreadData.pollQuestion && newThreadData.pollOptions) {
      newThread.poll = {
        id: `poll-${Date.now()}`,
        question: newThreadData.pollQuestion,
        type: 'single',
        options: newThreadData.pollOptions.map((opt, i) => ({ id: `opt-${i}`, text: opt, votes: 0 })),
        isAnonymous: false,
        totalVotes: 0,
      };
    }

    // Add reputation event
    const repEvent: ReputationEvent = {
      id: `rep-${Date.now()}`,
      actorId: state.currentUser.id,
      actorName: state.currentUser.displayName,
      recipientId: state.currentUser.id,
      reason: `Published new thread "${newThread.title}"`,
      timestamp: new Date().toISOString(),
      weight: 10,
    };

    const updatedUser = {
      ...state.currentUser,
      reputation: state.currentUser.reputation + 10,
      threadsCount: state.currentUser.threadsCount + 1,
    };

    state = {
      ...state,
      threads: [newThread, ...state.threads],
      currentUser: updatedUser,
      reputationEvents: [repEvent, ...state.reputationEvents],
    };

    notifyListeners();
    return newThread;
  },

  createReply: (threadId: string, content: string, argumentBlocks?: ArgumentBlock[], citations?: Citation[], quotePostId?: string) => {
    const threadIndex = state.threads.findIndex((t) => t.id === threadId);
    if (threadIndex === -1) return;

    const thread = state.threads[threadIndex];
    const postNumber = thread.posts.length + 1;
    let quoteSnippet;

    if (quotePostId) {
      const targetPost = thread.posts.find((p) => p.id === quotePostId);
      if (targetPost) {
        quoteSnippet = {
          postNumber: targetPost.postNumber,
          authorName: targetPost.author.displayName,
          text: targetPost.content.substring(0, 150) + '...',
        };
      }
    }

    const newPost: Post = {
      id: `post-${Date.now()}`,
      threadId,
      postNumber,
      authorId: state.currentUser.id,
      author: state.currentUser,
      createdAt: new Date().toISOString(),
      content,
      arguments: argumentBlocks || [],
      citations: citations || [],
      reactions: {},
      quotePostId,
      quoteSnippet,
    };

    const updatedThread: Thread = {
      ...thread,
      lastActivityAt: new Date().toISOString(),
      repliesCount: thread.repliesCount + 1,
      citationsCount: thread.citationsCount + (citations ? citations.length : 0),
      posts: [...thread.posts, newPost],
    };

    const updatedThreads = [...state.threads];
    updatedThreads[threadIndex] = updatedThread;

    // Reputation reward for high quality reply
    const repEvent: ReputationEvent = {
      id: `rep-${Date.now()}`,
      actorId: state.currentUser.id,
      actorName: state.currentUser.displayName,
      recipientId: state.currentUser.id,
      reason: `Contributed chronological reply #${postNumber} on "${thread.title}"`,
      timestamp: new Date().toISOString(),
      weight: 5,
    };

    const updatedUser = {
      ...state.currentUser,
      reputation: state.currentUser.reputation + 5,
      postsCount: state.currentUser.postsCount + 1,
    };

    state = {
      ...state,
      threads: updatedThreads,
      currentUser: updatedUser,
      reputationEvents: [repEvent, ...state.reputationEvents],
    };

    notifyListeners();
    return newPost;
  },

  reactToPost: (threadId: string, postId: string, emoji: string) => {
    const threadIndex = state.threads.findIndex((t) => t.id === threadId);
    if (threadIndex === -1) return;

    const thread = state.threads[threadIndex];
    const postIndex = thread.posts.findIndex((p) => p.id === postId);
    if (postIndex === -1) return;

    const post = thread.posts[postIndex];
    const currentReactions = { ...post.reactions };
    const userReactions = post.userReactions ? [...post.userReactions] : [];

    if (userReactions.includes(emoji)) {
      // Remove reaction
      currentReactions[emoji] = Math.max(0, (currentReactions[emoji] || 1) - 1);
      const userIndex = userReactions.indexOf(emoji);
      userReactions.splice(userIndex, 1);
    } else {
      // Add reaction
      currentReactions[emoji] = (currentReactions[emoji] || 0) + 1;
      userReactions.push(emoji);
    }

    const updatedPost = {
      ...post,
      reactions: currentReactions,
      userReactions,
    };

    const updatedPosts = [...thread.posts];
    updatedPosts[postIndex] = updatedPost;

    const updatedThread = {
      ...thread,
      posts: updatedPosts,
    };

    const updatedThreads = [...state.threads];
    updatedThreads[threadIndex] = updatedThread;

    state = { ...state, threads: updatedThreads };
    notifyListeners();
  },

  votePoll: (threadId: string, optionId: string) => {
    const threadIndex = state.threads.findIndex((t) => t.id === threadId);
    if (threadIndex === -1) return;

    const thread = state.threads[threadIndex];
    if (!thread.poll) return;

    const poll = thread.poll;
    if (poll.userVotedOptionIds && poll.userVotedOptionIds.length > 0) return; // already voted

    const updatedOptions = poll.options.map((opt) =>
      opt.id === optionId ? { ...opt, votes: opt.votes + 1 } : opt
    );

    const updatedPoll = {
      ...poll,
      options: updatedOptions,
      totalVotes: poll.totalVotes + 1,
      userVotedOptionIds: [optionId],
    };

    const updatedThread = { ...thread, poll: updatedPoll };
    const updatedThreads = [...state.threads];
    updatedThreads[threadIndex] = updatedThread;

    state = { ...state, threads: updatedThreads };
    notifyListeners();
  },

  toggleBookmarkThread: (threadId: string) => {
    const collection = state.bookmarkCollections[0];
    const isBookmarked = collection.threadIds.includes(threadId);

    const updatedThreadIds = isBookmarked
      ? collection.threadIds.filter((id) => id !== threadId)
      : [...collection.threadIds, threadId];

    const updatedCollections = state.bookmarkCollections.map((c, i) =>
      i === 0 ? { ...c, threadIds: updatedThreadIds } : c
    );

    state = { ...state, bookmarkCollections: updatedCollections };
    notifyListeners();
  },

  submitReport: (reason: string) => {
    if (!state.activeReportItem) return;

    const newReport: Report = {
      id: `rep-${Date.now()}`,
      reporterId: state.currentUser.id,
      reporterName: state.currentUser.displayName,
      targetType: state.activeReportItem.type,
      targetId: state.activeReportItem.id,
      targetTitle: state.activeReportItem.title,
      reason,
      priority: 'medium',
      status: 'OPEN',
      createdAt: new Date().toISOString(),
    };

    state = {
      ...state,
      reports: [newReport, ...state.reports],
      activeReportItem: null,
    };

    notifyListeners();
  },

  sendDirectMessage: (content: string) => {
    if (!state.activeMessageRecipient) return;

    const newMsg: DirectMessage = {
      id: `dm-${Date.now()}`,
      senderId: state.currentUser.id,
      recipientId: state.activeMessageRecipient.id,
      sender: state.currentUser,
      recipient: state.activeMessageRecipient,
      content,
      timestamp: 'Just now',
      isRead: false,
    };

    state = {
      ...state,
      directMessages: [...state.directMessages, newMsg],
      activeMessageRecipient: null,
    };

    notifyListeners();
  },

  markNotificationRead: (notifId: string) => {
    const updatedNotifs = state.notifications.map((n) =>
      n.id === notifId ? { ...n, isRead: true } : n
    );
    state = { ...state, notifications: updatedNotifs };
    notifyListeners();
  },
};

export function useAppStore() {
  const [storeState, setStoreState] = useState<AppStoreState>(store.getState());

  useEffect(() => {
    const unsubscribe = store.subscribe(() => {
      setStoreState(store.getState());
    });
    return () => {
      unsubscribe();
    };
  }, []);

  return storeState;
}
