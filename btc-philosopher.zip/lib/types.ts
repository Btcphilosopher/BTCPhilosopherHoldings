export type UserRole = 'User' | 'Trusted User' | 'Moderator' | 'Senior Moderator' | 'Administrator' | 'Owner';

export type ThreadState = 'DRAFT' | 'PUBLISHED' | 'LOCKED' | 'ARCHIVED' | 'PINNED' | 'DELETED' | 'UNDER_REVIEW';

export type ThreadType = 'THREAD' | 'ESSAY' | 'QUESTION' | 'POLL';

export type KnowledgeDecayStatus = 'CURRENT' | 'AGING' | 'HISTORICAL' | 'SUPERSEDED' | 'DISPUTED';

export type ArgumentType = 'CLAIM' | 'EVIDENCE' | 'ARGUMENT' | 'COUNTERARGUMENT' | 'QUESTION' | 'CONCLUSION' | 'SOURCE';

export type CitationType = 'book' | 'paper' | 'article' | 'government' | 'dataset' | 'website' | 'post' | 'thread';

export interface UserIdentity {
  nostr?: string;
  pgp?: string;
  lightningAddress?: string;
  btcAddress?: string;
  github?: string;
  website?: string;
}

export interface UserExpertise {
  category: string;
  score: number; // 1 to 5 stars
  derivedReason: string;
}

export interface UserProfile {
  id: string;
  username: string;
  displayName: string;
  avatarUrl: string;
  bio: string;
  role: UserRole;
  joinDate: string;
  location?: string;
  identity: UserIdentity;
  reputation: number;
  expertise: UserExpertise[];
  badges: string[];
  followersCount: number;
  followingCount: number;
  postsCount: number;
  threadsCount: number;
  essaysCount: number;
}

export interface Citation {
  id: string;
  sourceType: CitationType;
  title: string;
  author: string;
  publisher?: string;
  date?: string;
  url?: string;
  doi?: string;
  isbn?: string;
  page?: string;
  quote: string;
  context?: string;
}

export interface ArgumentBlock {
  id: string;
  type: ArgumentType;
  text: string;
  citationId?: string;
}

export interface PostRevision {
  id: string;
  postId: string;
  editorId: string;
  content: string;
  timestamp: string;
  reason: string;
}

export interface Reaction {
  emoji: string;
  count: number;
  userGuids: string[];
}

export interface Post {
  id: string;
  threadId: string;
  postNumber: number;
  authorId: string;
  author: UserProfile;
  content: string;
  createdAt: string;
  updatedAt?: string;
  isEdited?: boolean;
  arguments?: ArgumentBlock[];
  citations?: Citation[];
  reactions: Record<string, number>;
  userReactions?: string[];
  quotePostId?: string;
  quoteSnippet?: {
    postNumber: number;
    authorName: string;
    text: string;
  };
  attachments?: { name: string; url: string; type: string }[];
}

export interface PollOption {
  id: string;
  text: string;
  votes: number;
}

export interface Poll {
  id: string;
  question: string;
  type: 'single' | 'multiple' | 'ranked';
  options: PollOption[];
  isAnonymous: boolean;
  expiresAt?: string;
  totalVotes: number;
  userVotedOptionIds?: string[];
}

export interface Thread {
  id: string;
  slug: string;
  title: string;
  subtitle?: string;
  categoryId: string;
  categoryName: string;
  communityId?: string;
  communityName?: string;
  authorId: string;
  author: UserProfile;
  type: ThreadType;
  state: ThreadState;
  decayStatus: KnowledgeDecayStatus;
  createdAt: string;
  lastActivityAt: string;
  viewsCount: number;
  repliesCount: number;
  citationsCount: number;
  reputationScore: number;
  tags: string[];
  coverImage?: string;
  isAcceptedAnswer?: boolean;
  acceptedPostId?: string;
  poll?: Poll;
  aiSummary?: AISummary;
  posts: Post[];
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  group: 'BITCOIN' | 'ECONOMICS' | 'TECHNOLOGY' | 'PHILOSOPHY' | 'SOCIETY' | 'MARKETS' | 'PROJECTS' | 'GENERAL';
  description: string;
  threadsCount: number;
  postsCount: number;
  icon: string;
}

export interface Community {
  id: string;
  name: string;
  slug: string;
  description: string;
  rules: string[];
  membersCount: number;
  threadsCount: number;
}

export interface KnowledgePage {
  id: string;
  slug: string;
  title: string;
  category: string;
  summary: string;
  keyQuestions: string[];
  importantThreadIds: string[];
  importantUserIds: string[];
  sources: Citation[];
  debates: { title: string; summary: string }[];
  relatedConcepts: string[];
  timeline: { year: string; event: string }[];
}

export interface ReputationEvent {
  id: string;
  actorId: string;
  actorName: string;
  recipientId: string;
  reason: string;
  sourcePostId?: string;
  timestamp: string;
  weight: number;
}

export interface BookmarkCollection {
  id: string;
  name: string;
  isPrivate: boolean;
  threadIds: string[];
  postIds: string[];
  knowledgePageIds: string[];
}

export interface Notification {
  id: string;
  userId: string;
  type: 'reply' | 'mention' | 'quote' | 'followed_thread' | 'followed_user' | 'citation' | 'reputation' | 'moderation' | 'message';
  title: string;
  message: string;
  linkUrl: string;
  isRead: boolean;
  createdAt: string;
}

export interface DirectMessage {
  id: string;
  senderId: string;
  recipientId: string;
  sender: UserProfile;
  recipient: UserProfile;
  content: string;
  timestamp: string;
  isRead: boolean;
}

export interface Report {
  id: string;
  reporterId: string;
  reporterName: string;
  targetType: 'thread' | 'post' | 'user';
  targetId: string;
  targetTitle: string;
  reason: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  status: 'OPEN' | 'UNDER_REVIEW' | 'RESOLVED' | 'DISMISSED' | 'APPEALED';
  assignedModerator?: string;
  createdAt: string;
  resolution?: string;
}

export interface AuditEvent {
  id: string;
  actorId: string;
  actorName: string;
  action: string;
  target: string;
  timestamp: string;
  details: string;
}

export interface AISummary {
  summary: string;
  questions: string[];
  arguments: string[];
  counterarguments: string[];
  sources: string[];
  consensus?: string;
  disagreements: string[];
  unresolved: string[];
  model: string;
  generatedAt: string;
}

export interface KnowledgeGraphNode {
  id: string;
  label: string;
  type: 'CLAIM' | 'AUTHOR' | 'SOURCE' | 'TOPIC' | 'POST' | 'THREAD';
  subText?: string;
  x?: number;
  y?: number;
}

export interface KnowledgeGraphEdge {
  id: string;
  source: string;
  target: string;
  label: 'supports' | 'contradicts' | 'references' | 'responds_to' | 'expands' | 'questions';
}

export interface MarketMetrics {
  btcPriceUsd: number;
  btcPriceChange24h: number;
  marketCapUsd: number;
  blockHeight: number;
  recommendedFeeSatByte: number;
  hashrateEh: number;
  difficultyT: number;
  lastUpdated: string;
}
