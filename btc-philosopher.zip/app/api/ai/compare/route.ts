import { GoogleGenAI, Type } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

export async function POST(req: NextRequest) {
  try {
    const { thread1, thread2 } = await req.json();

    const promptText = `Compare these two intellectual discussion threads:

THREAD A:
Title: ${thread1.title}
Category: ${thread1.categoryName}
Author: ${thread1.author?.displayName}
Content: ${thread1.posts?.[0]?.content}

THREAD B:
Title: ${thread2.title}
Category: ${thread2.categoryName}
Author: ${thread2.author?.displayName}
Content: ${thread2.posts?.[0]?.content}

Identify:
1. Shared foundational claims.
2. Core points of disagreement or departure.
3. Contradictory premises.
4. Synthesized conclusion comparing their intellectual utility.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: promptText,
      config: {
        systemInstruction:
          'You are Philosopher AI, a dialectical comparison tool for forum threads. Compare premises rigorously and objectively.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            sharedClaims: { type: Type.ARRAY, items: { type: Type.STRING } },
            pointsOfDeparture: { type: Type.ARRAY, items: { type: Type.STRING } },
            contradictions: { type: Type.ARRAY, items: { type: Type.STRING } },
            synthesizedConclusion: { type: Type.STRING },
          },
          required: ['sharedClaims', 'pointsOfDeparture', 'contradictions', 'synthesizedConclusion'],
        },
      },
    });

    const jsonText = response.text?.trim() || '{}';
    const parsedData = JSON.parse(jsonText);

    return NextResponse.json(parsedData);
  } catch (err: any) {
    console.error('AI Thread Compare Error:', err);
    return NextResponse.json(
      { error: err.message || 'Failed to compare threads' },
      { status: 500 }
    );
  }
}
