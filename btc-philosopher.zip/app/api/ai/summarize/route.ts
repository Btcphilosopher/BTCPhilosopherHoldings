import { GoogleGenAI, Type } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

export async function POST(req: NextRequest) {
  try {
    const { threadTitle, threadContent, posts } = await req.json();

    const promptText = `Analyze the following forum thread and produce a structured intellectual summary.
Thread Title: ${threadTitle}
Main Content: ${threadContent}
Replies:
${posts?.map((p: any, i: number) => `[Post #${i + 1} by ${p.authorName}]: ${p.content}`).join('\n\n')}

Formulate a concise summary with key questions, arguments, counterarguments, cited sources, consensus (if any), disagreements, and unresolved questions.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: promptText,
      config: {
        systemInstruction:
          'You are Philosopher AI, a serious monetary economics and cryptographic protocol summary agent. Produce precise, high-intellect bullet points. Never fabricate consensus or quotations.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            questions: { type: Type.ARRAY, items: { type: Type.STRING } },
            arguments: { type: Type.ARRAY, items: { type: Type.STRING } },
            counterarguments: { type: Type.ARRAY, items: { type: Type.STRING } },
            sources: { type: Type.ARRAY, items: { type: Type.STRING } },
            consensus: { type: Type.STRING },
            disagreements: { type: Type.ARRAY, items: { type: Type.STRING } },
            unresolved: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          required: ['summary', 'questions', 'arguments', 'counterarguments', 'sources', 'disagreements', 'unresolved'],
        },
      },
    });

    const jsonText = response.text?.trim() || '{}';
    const parsedData = JSON.parse(jsonText);

    return NextResponse.json({
      ...parsedData,
      model: 'gemini-3.8-flash',
      generatedAt: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error('AI Summarize Error:', err);
    return NextResponse.json(
      { error: err.message || 'Failed to generate AI summary' },
      { status: 500 }
    );
  }
}
