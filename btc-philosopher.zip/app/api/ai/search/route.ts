import { GoogleGenAI, Type } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

export async function POST(req: NextRequest) {
  try {
    const { query, availableThreads, availableKnowledge } = await req.json();

    const promptText = `User Query: "${query}"

Available Forum Archives:
${availableThreads?.map((t: any) => `Thread ID: ${t.id} | Title: "${t.title}" | Category: ${t.categoryName} | Tags: ${t.tags?.join(', ')} | Excerpt: ${t.posts?.[0]?.content?.substring(0, 300)}`).join('\n')}

Available Knowledge Hub Pages:
${availableKnowledge?.map((k: any) => `Knowledge Page: "${k.title}" | Category: ${k.category} | Summary: ${k.summary}`).join('\n')}

Perform a semantic analysis of the query. Return:
1. An AI answer synthesizing context and citing relevant thread IDs or knowledge topics.
2. Filtered relevant thread IDs ranked by semantic relevance.
3. Suggested follow-up intellectual questions.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: promptText,
      config: {
        systemInstruction:
          'You are Philosopher AI, an archival search navigator for BTC Philosopher forum. You strictly cite actual threads provided. Never fabricate posts or users.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            answer: { type: Type.STRING },
            matchedThreadIds: { type: Type.ARRAY, items: { type: Type.STRING } },
            matchedKnowledgeIds: { type: Type.ARRAY, items: { type: Type.STRING } },
            suggestedQuestions: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          required: ['answer', 'matchedThreadIds', 'suggestedQuestions'],
        },
      },
    });

    const jsonText = response.text?.trim() || '{}';
    const parsedData = JSON.parse(jsonText);

    return NextResponse.json({
      ...parsedData,
      model: 'gemini-3.8-flash',
      timestamp: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error('AI Search Error:', err);
    return NextResponse.json(
      { error: err.message || 'Failed to perform semantic search' },
      { status: 500 }
    );
  }
}
