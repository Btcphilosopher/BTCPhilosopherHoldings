import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'BTC Philosopher — The Modern Intellectual Forum',
  description: 'A modern intellectual forum for durable discussions, technical debate, long-form essays, knowledge graphs, and AI-assisted discovery.',
  openGraph: {
    title: 'BTC Philosopher — The Modern Intellectual Forum',
    description: 'A modern intellectual forum for durable discussions, technical debate, long-form essays, knowledge graphs, and AI-assisted discovery.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'BTC Philosopher — The Modern Intellectual Forum',
    description: 'A modern intellectual forum for durable discussions, technical debate, long-form essays, knowledge graphs, and AI-assisted discovery.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;800&family=Instrument+Serif:ital@0;1&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet" />
      </head>
      <body className="bg-[#0b0c0e] text-[#e4e4e7] antialiased selection:bg-[#f7931a]/30 selection:text-[#f7931a] min-h-screen font-sans" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
