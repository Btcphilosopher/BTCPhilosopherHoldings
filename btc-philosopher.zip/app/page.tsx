'use client';

import React, { useState } from 'react';
import { useAppStore } from '@/lib/store';
import { Navbar } from '@/components/Navbar';
import { LeftSidebar } from '@/components/LeftSidebar';
import { RightIntelligencePanel } from '@/components/RightIntelligencePanel';
import { ThreadCard } from '@/components/ThreadCard';
import { ThreadView } from '@/components/ThreadView';
import { ThreadComposer } from '@/components/ThreadComposer';
import { DiscoverView } from '@/components/DiscoverView';
import { EssaysView } from '@/components/EssaysView';
import { KnowledgeHubView } from '@/components/KnowledgeHubView';
import { KnowledgeGraphView } from '@/components/KnowledgeGraphView';
import { UserProfileView } from '@/components/UserProfileView';
import { MarketsView } from '@/components/MarketsView';
import { BookmarksView } from '@/components/BookmarksView';
import { SearchView } from '@/components/SearchView';
import { AdminAuditView } from '@/components/AdminAuditView';

import { TippingModal } from '@/components/TippingModal';
import { ThreadCompareModal } from '@/components/ThreadCompareModal';
import { DirectMessageModal } from '@/components/DirectMessageModal';
import { ReportModal } from '@/components/ReportModal';
import { Pin, Filter } from 'lucide-react';

export default function HomePage() {
  const { threads, categories, isFocusMode } = useAppStore();

  const [activeView, setActiveView] = useState<string>('home');
  const [activeId, setActiveId] = useState<string | undefined>(undefined);
  const [selectedCategoryId, setSelectedCategoryId] = useState<string | undefined>(undefined);

  const handleNavigate = (view: string, id?: string) => {
    setActiveView(view);
    setActiveId(id);
    if (view !== 'category') {
      setSelectedCategoryId(undefined);
    } else if (id) {
      setSelectedCategoryId(id);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Filter threads for main Home view
  const filteredThreads = threads.filter((t) => {
    if (selectedCategoryId) {
      return t.categoryId === selectedCategoryId;
    }
    return true;
  });

  const pinnedThreads = filteredThreads.filter((t) => t.state === 'PINNED');
  const standardThreads = filteredThreads.filter((t) => t.state !== 'PINNED');

  const activeCategoryName = selectedCategoryId
    ? categories.find((c) => c.id === selectedCategoryId)?.name
    : 'All Categories';

  return (
    <div className="min-h-screen bg-[#0b0c0e] text-zinc-100 font-sans selection:bg-[#f7931a] selection:text-black">
      {/* Navbar */}
      <Navbar onNavigate={handleNavigate} activeView={activeView} />

      {/* Main Container Layout */}
      <div className="max-w-[1600px] mx-auto px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Left Navigation Sidebar (Hidden in Focus Mode) */}
          {!isFocusMode && (
            <LeftSidebar
              onNavigate={handleNavigate}
              activeView={activeView}
              selectedCategoryId={selectedCategoryId}
              onSelectCategory={(catId) => {
                setSelectedCategoryId(catId);
                if (catId) setActiveView('category');
              }}
            />
          )}

          {/* Central Main Workspace Content */}
          <main className="flex-1 min-w-0">
            {/* View Switching Logic */}
            {activeView === 'home' || activeView === 'category' ? (
              <div className="space-y-6">
                {/* Category Title Header */}
                <div className="flex flex-wrap items-center justify-between border-b border-[#272a30] pb-3 text-xs">
                  <div>
                    <h1 className="text-xl font-extrabold text-zinc-100 flex items-center space-x-2">
                      <span className="text-[#f7931a]">BTC PHILOSOPHER</span>
                      <span className="text-zinc-600">/</span>
                      <span>{activeCategoryName}</span>
                    </h1>
                    <p className="text-xs text-zinc-400 mt-0.5">
                      Durable discussions, chronological replies, and structured argument analysis.
                    </p>
                  </div>

                  <div className="flex items-center space-x-2 text-zinc-400 font-mono text-xs">
                    <span>{filteredThreads.length} Threads</span>
                  </div>
                </div>

                {/* Pinned Threads Section */}
                {pinnedThreads.length > 0 && (
                  <div className="space-y-3">
                    <div className="text-[10px] font-mono tracking-widest text-[#f7931a] uppercase font-bold flex items-center space-x-1.5">
                      <Pin className="w-3 h-3" />
                      <span>PINNED CANONICAL DISCUSSIONS</span>
                    </div>
                    {pinnedThreads.map((thread) => (
                      <ThreadCard key={thread.id} thread={thread} onNavigate={handleNavigate} />
                    ))}
                  </div>
                )}

                {/* Standard Discussions Stream */}
                <div className="space-y-4">
                  <div className="text-[10px] font-mono tracking-widest text-zinc-500 uppercase font-semibold">
                    CHRONOLOGICAL THREADS STREAM
                  </div>
                  {standardThreads.map((thread) => (
                    <ThreadCard key={thread.id} thread={thread} onNavigate={handleNavigate} />
                  ))}
                </div>
              </div>
            ) : null}

            {activeView === 'thread' && (
              <ThreadView threadId={activeId || 'th-1'} onNavigate={handleNavigate} />
            )}

            {activeView === 'create' && <ThreadComposer onNavigate={handleNavigate} />}

            {activeView === 'discover' && <DiscoverView onNavigate={handleNavigate} />}

            {activeView === 'essays' && <EssaysView onNavigate={handleNavigate} />}

            {activeView === 'knowledge' && <KnowledgeHubView onNavigate={handleNavigate} />}

            {activeView === 'knowledge-page' && (
              <KnowledgeHubView onNavigate={handleNavigate} selectedPageId={activeId} />
            )}

            {activeView === 'graph' && <KnowledgeGraphView onNavigate={handleNavigate} />}

            {activeView === 'markets' && <MarketsView />}

            {activeView === 'profile' && (
              <UserProfileView userId={activeId || 'u-1'} onNavigate={handleNavigate} />
            )}

            {activeView === 'bookmarks' && <BookmarksView onNavigate={handleNavigate} />}

            {activeView === 'search' && <SearchView onNavigate={handleNavigate} />}

            {activeView === 'dashboard' && <MarketsView />}

            {activeView === 'admin' && <AdminAuditView />}

            {activeView === 'archive' && (
              <div className="space-y-4">
                <div className="border-b border-[#272a30] pb-3">
                  <h1 className="text-xl font-bold text-zinc-100">ARCHIVED THREADS</h1>
                  <p className="text-xs text-zinc-400">Historical & superseded discussion logs.</p>
                </div>
                {threads.map((t) => (
                  <ThreadCard key={t.id} thread={t} onNavigate={handleNavigate} />
                ))}
              </div>
            )}
          </main>

          {/* Right Intelligence Panel (Hidden in Focus Mode) */}
          {!isFocusMode && <RightIntelligencePanel onNavigate={handleNavigate} />}
        </div>
      </div>

      {/* Global Modals */}
      <TippingModal />
      <ThreadCompareModal />
      <DirectMessageModal />
      <ReportModal />
    </div>
  );
}
