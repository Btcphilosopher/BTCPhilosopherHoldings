'use client';

import React, { useState } from 'react';
import { useAppStore, store } from '@/lib/store';
import { Send, Lock } from 'lucide-react';

export const DirectMessageModal: React.FC = () => {
  const { activeMessageRecipient } = useAppStore();
  const [message, setMessage] = useState('');

  if (!activeMessageRecipient) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    store.sendDirectMessage(message.trim());
    setMessage('');
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#121418] border border-[#272a30] rounded-2xl p-6 max-w-lg w-full shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b border-[#1e2127] pb-3">
          <div className="flex items-center space-x-2 text-zinc-100 font-bold text-sm">
            <Lock className="w-4 h-4 text-[#f7931a]" />
            <span>DIRECT MESSAGE TO @{activeMessageRecipient.username}</span>
          </div>
          <button onClick={() => store.closeMessageModal()} className="text-zinc-500 hover:text-zinc-200 font-bold">
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <textarea
            rows={4}
            placeholder={`Send private message to ${activeMessageRecipient.displayName}...`}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            required
            className="w-full bg-[#0b0c0e] border border-[#272a30] rounded-xl p-3 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-[#f7931a]"
          />

          <div className="flex justify-end">
            <button
              type="submit"
              className="px-4 py-2 bg-[#f7931a] text-black font-bold text-xs rounded-lg hover:bg-[#e08213] flex items-center space-x-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send Message</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
