'use client';

import React from 'react';
import { useAppStore } from '@/lib/store';
import { BookOpen, Sparkles, ArrowRight, UserCheck, Layers, ExternalLink } from 'lucide-react';

interface KnowledgeHubViewProps {
  onNavigate: (view: string, id?: string) => void;
  selectedPageId?: string;
}

export const KnowledgeHubView: React.FC<KnowledgeHubViewProps> = ({ onNavigate, selectedPageId }) => {
  const { knowledgePages, threads } = useAppStore();

  const activePage = selectedPageId
    ? knowledgePages.find((p) => p.id === selectedPageId) || knowledgePages[0]
    : knowledgePages[0];

  return (
    <div className="max-w-6xl mx-auto py-4 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#272a30] pb-4">
        <div>
          <h1 className="text-xl font-extrabold text-zinc-100 flex items-center space-x-2">
            <BookOpen className="w-5 h-5 text-emerald-400" />
            <span>LIVING KNOWLEDGE HUBS</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Living syntheses of durable forum consensus, core literature, key debates, and canonical threads.
          </p>
        </div>
      </div>

      {/* Main Grid: Left Hub List, Right Active Synthesis */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Hub Selector List */}
        <div className="space-y-3">
          <div className="text-[10px] font-mono tracking-widest text-zinc-500 uppercase font-semibold px-1">
            CANONICAL KNOWLEDGE TOPICS
          </div>

          {knowledgePages.map((page) => {
            const isSelected = page.id === activePage.id;
            return (
              <div
                key={page.id}
                onClick={() => onNavigate('knowledge-page', page.id)}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-emerald-500/10 border-emerald-500 text-emerald-400'
                    : 'bg-[#121418] border-[#272a30] text-zinc-300 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center justify-between font-bold text-sm">
                  <span>{page.title}</span>
                  <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-[#181b20] text-zinc-400 border border-zinc-700">
                    {page.category}
                  </span>
                </div>
                <p className="text-xs text-zinc-400 mt-2 line-clamp-2 leading-relaxed">{page.summary}</p>
              </div>
            );
          })}
        </div>

        {/* Active Knowledge Hub Detailed View */}
        <div className="lg:col-span-2 bg-[#121418] border border-[#272a30] rounded-xl p-6 shadow-sm space-y-6">
          <div className="border-b border-[#1e2127] pb-4">
            <span className="text-[10px] font-mono text-emerald-400 font-bold uppercase tracking-wider">
              CANONICAL SYNTHESIS PAGE #{activePage.id}
            </span>
            <h2 className="text-2xl font-bold text-zinc-100 mt-1">{activePage.title}</h2>
            <p className="text-xs text-zinc-300 mt-2 leading-relaxed">{activePage.summary}</p>
          </div>

          {/* Core Debates */}
          <div className="space-y-2">
            <h3 className="text-xs font-mono font-bold text-amber-400 uppercase">CORE INTELLECTUAL DEBATES</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {activePage.debates.map((deb, i) => (
                <div key={i} className="p-3 bg-[#0b0c0e] rounded-lg border border-zinc-800 text-xs text-zinc-300">
                  <strong className="text-zinc-100 block mb-1">{deb.title}</strong>
                  <span>{deb.summary}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Primary Literature Sources */}
          <div className="space-y-2">
            <h3 className="text-xs font-mono font-bold text-[#f7931a] uppercase">PRIMARY LITERATURE SOURCES</h3>
            <div className="space-y-1.5 text-xs text-zinc-300">
              {activePage.sources.map((src, i) => (
                <div key={i} className="p-2.5 bg-[#0b0c0e] rounded-lg border border-zinc-800 flex items-center justify-between">
                  <span>📜 &quot;{src.title}&quot; by {src.author} ({src.date || 'N/A'})</span>
                  <span className="text-[10px] text-zinc-500 font-mono">Peer-Verified</span>
                </div>
              ))}
            </div>
          </div>

          {/* Associated Canonical Forum Threads */}
          <div className="space-y-2">
            <h3 className="text-xs font-mono font-bold text-zinc-300 uppercase">ASSOCIATED CANONICAL THREADS</h3>
            <div className="space-y-2">
              {threads
                .filter((t) => activePage.importantThreadIds.includes(t.id))
                .map((thread) => (
                  <div
                    key={thread.id}
                    onClick={() => onNavigate('thread', thread.id)}
                    className="p-3 bg-[#14171d] rounded-lg border border-[#272a30] hover:border-[#f7931a]/50 cursor-pointer transition-colors flex items-center justify-between"
                  >
                    <div>
                      <div className="font-semibold text-zinc-100 text-xs hover:text-[#f7931a]">{thread.title}</div>
                      <div className="text-[10px] text-zinc-500 font-mono mt-0.5">
                        By {thread.author.displayName} • {thread.citationsCount} citations
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-zinc-500" />
                  </div>
                ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
