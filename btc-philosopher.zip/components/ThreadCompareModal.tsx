'use client';

import React, { useState, useEffect } from 'react';
import { useAppStore, store } from '@/lib/store';
import { Layers, Sparkles, ArrowRight } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

export const ThreadCompareModal: React.FC = () => {
  const { activeCompareThreads, threads } = useAppStore();
  const [loading, setLoading] = useState(false);
  const [comparisonResult, setComparisonResult] = useState<any>(null);

  const t1 = activeCompareThreads ? threads.find((t) => t.id === activeCompareThreads[0]) || threads[0] : null;
  const t2 = activeCompareThreads ? threads.find((t) => t.id === activeCompareThreads[1]) || threads[1] || threads[0] : null;

  useEffect(() => {
    if (!activeCompareThreads || !t1 || !t2) return;
    let isMounted = true;
    const runComparison = async () => {
      setLoading(true);
      try {
        const res = await fetch('/api/ai/compare', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ thread1: t1, thread2: t2 }),
        });
        const data = await res.json();
        if (isMounted && !data.error) {
          setComparisonResult(data);
        }
      } catch (err) {
        console.error(err);
      } finally {
        if (isMounted) setLoading(false);
      }
    };
    runComparison();
    return () => {
      isMounted = false;
    };
  }, [activeCompareThreads, t1, t2]);

  if (!activeCompareThreads || !t1 || !t2) return null;

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-[#121418] border border-purple-500/50 rounded-2xl p-6 max-w-5xl w-full max-h-[90vh] overflow-y-auto shadow-2xl space-y-6">
        <div className="flex items-center justify-between border-b border-[#1e2127] pb-3">
          <div className="flex items-center space-x-2 text-purple-400 font-bold text-sm">
            <Layers className="w-5 h-5" />
            <span>DIALECTICAL THREAD COMPARISON MODE</span>
          </div>
          <button onClick={() => store.closeCompareModal()} className="text-zinc-500 hover:text-zinc-200 text-sm font-bold">
            ✕
          </button>
        </div>

        {/* Side-by-side threads header */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-[#14171d] rounded-xl border border-[#272a30]">
            <span className="text-[10px] font-mono text-purple-400 font-bold uppercase">THREAD A</span>
            <h3 className="font-bold text-zinc-100 text-sm mt-1">{t1.title}</h3>
            <p className="text-xs text-zinc-400 mt-1 line-clamp-3">{t1.posts[0]?.content}</p>
          </div>

          <div className="p-4 bg-[#14171d] rounded-xl border border-[#272a30]">
            <span className="text-[10px] font-mono text-purple-400 font-bold uppercase">THREAD B</span>
            <h3 className="font-bold text-zinc-100 text-sm mt-1">{t2.title}</h3>
            <p className="text-xs text-zinc-400 mt-1 line-clamp-3">{t2.posts[0]?.content}</p>
          </div>
        </div>

        {/* AI Comparison Synthesis */}
        <div className="bg-[#0b0c0e] border border-purple-500/30 rounded-xl p-5 space-y-4">
          <div className="flex items-center space-x-2 text-purple-400 font-bold text-xs font-mono uppercase">
            <Sparkles className="w-4 h-4" />
            <span>PHILOSOPHER AI DIALECTIC SYNTHESIS</span>
          </div>

          {loading ? (
            <div className="py-6 text-center text-xs text-zinc-400 flex items-center justify-center space-x-2">
              <span className="w-4 h-4 rounded-full border-2 border-purple-400 border-t-transparent animate-spin"></span>
              <span>Comparing arguments and core premises...</span>
            </div>
          ) : comparisonResult ? (
            <div className="space-y-4 text-xs text-zinc-300">
              <div className="p-3 bg-[#14171d] rounded-lg border border-zinc-800">
                <span className="font-bold text-emerald-400 block mb-1 uppercase font-mono text-[10px]">Shared Claims & Foundations</span>
                <ul className="list-disc list-inside space-y-1 text-zinc-300">
                  {comparisonResult.sharedClaims?.map((c: string, i: number) => (
                    <li key={i}>{c}</li>
                  ))}
                </ul>
              </div>

              <div className="p-3 bg-[#14171d] rounded-lg border border-zinc-800">
                <span className="font-bold text-rose-400 block mb-1 uppercase font-mono text-[10px]">Points of Departure & Contradictions</span>
                <ul className="list-disc list-inside space-y-1 text-zinc-300">
                  {comparisonResult.pointsOfDeparture?.map((p: string, i: number) => (
                    <li key={i}>{p}</li>
                  ))}
                </ul>
              </div>

              <div className="p-3 bg-[#14171d] rounded-lg border border-zinc-800">
                <span className="font-bold text-purple-400 block mb-1 uppercase font-mono text-[10px]">Synthesized Conclusion</span>
                <p className="leading-relaxed text-zinc-200">{comparisonResult.synthesizedConclusion}</p>
              </div>
            </div>
          ) : (
            <div className="text-xs text-zinc-500">Failed to render comparison.</div>
          )}
        </div>
      </div>
    </div>
  );
};
