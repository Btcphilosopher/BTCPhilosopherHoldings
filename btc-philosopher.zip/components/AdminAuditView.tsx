'use client';

import React, { useState } from 'react';
import { useAppStore } from '@/lib/store';
import { ShieldAlert, FileText, CheckCircle, XCircle, AlertTriangle, Eye, Shield } from 'lucide-react';

export const AdminAuditView: React.FC = () => {
  const { reports, auditEvents } = useAppStore();
  const [activeTab, setActiveTab] = useState<'REPORTS' | 'AUDIT'>('REPORTS');

  return (
    <div className="max-w-5xl mx-auto py-4 space-y-6">
      <div className="border-b border-[#272a30] pb-4">
        <h1 className="text-xl font-extrabold text-zinc-100 flex items-center space-x-2">
          <ShieldAlert className="w-5 h-5 text-rose-400" />
          <span>MODERATION & AUDIT INTELLIGENCE</span>
        </h1>
        <p className="text-xs text-zinc-400 mt-0.5">
          Transparent moderation queue and immutable administrative audit log.
        </p>
      </div>

      <div className="flex items-center space-x-2 border-b border-[#272a30] pb-2 text-xs font-medium">
        <button
          onClick={() => setActiveTab('REPORTS')}
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            activeTab === 'REPORTS'
              ? 'bg-rose-500/15 text-rose-400 font-bold border border-rose-500/30'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          OPEN REPORTS ({reports.length})
        </button>
        <button
          onClick={() => setActiveTab('AUDIT')}
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            activeTab === 'AUDIT'
              ? 'bg-[#f7931a]/15 text-[#f7931a] font-bold border border-[#f7931a]/30'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          IMMUTABLE AUDIT LOG ({auditEvents.length})
        </button>
      </div>

      {activeTab === 'REPORTS' && (
        <div className="space-y-3">
          {reports.map((report) => (
            <div key={report.id} className="p-4 bg-[#121418] border border-[#272a30] rounded-xl space-y-2 text-xs">
              <div className="flex items-center justify-between font-mono">
                <span className="font-bold text-rose-400 uppercase">[{report.priority} PRIORITY] {report.targetType}</span>
                <span className="text-zinc-500">{new Date(report.createdAt).toLocaleString()}</span>
              </div>
              <div className="font-bold text-zinc-100 text-sm">{report.targetTitle}</div>
              <div className="text-zinc-300 bg-[#0b0c0e] p-2 rounded border border-zinc-800">
                <span className="text-zinc-500 mr-2">Reason:</span>
                <span>{report.reason}</span>
              </div>
              <div className="flex justify-between items-center text-[10px] text-zinc-500 pt-1">
                <span>Reported by: {report.reporterName}</span>
                <div className="flex space-x-2">
                  <button className="px-2.5 py-1 bg-emerald-500/20 text-emerald-400 font-bold rounded">Dismiss</button>
                  <button className="px-2.5 py-1 bg-rose-500/20 text-rose-400 font-bold rounded">Moderate Target</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'AUDIT' && (
        <div className="bg-[#121418] border border-[#272a30] rounded-xl p-5 space-y-3">
          {auditEvents.map((evt) => (
            <div key={evt.id} className="p-3 bg-[#0b0c0e] rounded-lg border border-zinc-800 text-xs flex justify-between items-center font-mono">
              <div>
                <div className="font-bold text-[#f7931a]">{evt.action}</div>
                <div className="text-zinc-300 text-[11px] mt-0.5">{evt.details}</div>
                <div className="text-[10px] text-zinc-500 mt-1">Actor: {evt.actorName}</div>
              </div>
              <span className="text-[10px] text-zinc-500">{new Date(evt.timestamp).toLocaleTimeString()}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
