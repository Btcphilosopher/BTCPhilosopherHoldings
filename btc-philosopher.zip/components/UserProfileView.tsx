'use client';

import React, { useState } from 'react';
import { MOCK_USERS } from '@/lib/seed-data';
import { useAppStore, store } from '@/lib/store';
import {
  User,
  Zap,
  Shield,
  Award,
  BookOpen,
  MessageSquare,
  Key,
  Star,
  Clock,
  Send,
  ExternalLink,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';
import { ThreadCard } from './ThreadCard';

interface UserProfileViewProps {
  userId: string;
  onNavigate: (view: string, id?: string) => void;
}

export const UserProfileView: React.FC<UserProfileViewProps> = ({ userId, onNavigate }) => {
  const { threads, reputationEvents } = useAppStore();
  const user = MOCK_USERS[userId] || MOCK_USERS['u-1'];

  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'THREADS' | 'ESSAYS' | 'LEDGER'>('OVERVIEW');

  const userThreads = threads.filter((t) => t.authorId === user.id);
  const userEssays = userThreads.filter((t) => t.type === 'ESSAY');
  const userEvents = reputationEvents.filter((e) => e.recipientId === user.id || e.actorId === user.id);

  return (
    <div className="max-w-5xl mx-auto py-4 space-y-6">
      {/* Profile Header Card */}
      <div className="bg-[#121418] border border-[#272a30] rounded-xl p-6 shadow-sm space-y-6">
        <div className="flex flex-wrap items-start justify-between gap-4 border-b border-[#1e2127] pb-6">
          <div className="flex items-center space-x-4">
            <img
              src={user.avatarUrl}
              alt={user.displayName}
              className="w-16 h-16 rounded-xl object-cover border-2 border-[#f7931a] shadow-md"
            />
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-2xl font-extrabold text-zinc-100">{user.displayName}</h1>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#f7931a]/15 text-[#f7931a] border border-[#f7931a]/40">
                  {user.role}
                </span>
              </div>
              <div className="text-xs text-zinc-400 font-mono mt-0.5">
                @{user.username} • Joined {user.joinDate}
              </div>
              <p className="text-xs text-zinc-300 mt-2 max-w-xl leading-relaxed">{user.bio}</p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => store.openMessageModal(user)}
              className="px-3.5 py-2 rounded-lg bg-[#14171d] border border-[#272a30] text-zinc-200 hover:text-zinc-100 text-xs font-semibold flex items-center space-x-1.5"
            >
              <Send className="w-3.5 h-3.5 text-zinc-400" />
              <span>Direct Message</span>
            </button>

            <button
              onClick={() => store.openTipModal(user)}
              className="px-3.5 py-2 rounded-lg bg-[#f7931a] text-black font-bold text-xs hover:bg-[#e08213] transition-colors flex items-center space-x-1.5 shadow-md"
            >
              <Zap className="w-3.5 h-3.5 fill-current" />
              <span>Tip sats</span>
            </button>
          </div>
        </div>

        {/* Derived Expertise Ratings & Cryptographic Identity */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
          {/* Expertise */}
          <div className="bg-[#0b0c0e] p-3 rounded-lg border border-zinc-800 space-y-2">
            <div className="text-[10px] text-amber-400 font-bold uppercase flex items-center space-x-1">
              <Star className="w-3.5 h-3.5 fill-current" />
              <span>DERIVED EXPERTISE RATINGS</span>
            </div>
            {user.expertise.map((exp) => (
              <div key={exp.category} className="flex items-center justify-between text-zinc-300">
                <span className="capitalize">{exp.category.replace('-', ' ')}</span>
                <div className="flex items-center space-x-1 text-[#f7931a]">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <span key={i} className={i < exp.score ? 'text-[#f7931a]' : 'text-zinc-700'}>★</span>
                  ))}
                  <span className="text-zinc-400 text-[10px] ml-1">({exp.score}/5)</span>
                </div>
              </div>
            ))}
          </div>

          {/* Cryptographic Proofs & Addresses */}
          <div className="bg-[#0b0c0e] p-3 rounded-lg border border-zinc-800 space-y-2">
            <div className="text-[10px] text-[#f7931a] font-bold uppercase flex items-center space-x-1">
              <Key className="w-3.5 h-3.5" />
              <span>CRYPTOGRAPHIC IDENTIFIERS</span>
            </div>
            {user.identity?.pgp && (
              <div className="truncate text-zinc-400">
                <span className="text-zinc-500 mr-2">PGP:</span>
                <span className="text-zinc-300">{user.identity.pgp}</span>
              </div>
            )}
            {user.identity?.lightningAddress && (
              <div className="truncate text-zinc-400">
                <span className="text-zinc-500 mr-2">LN:</span>
                <span className="text-zinc-300">{user.identity.lightningAddress}</span>
              </div>
            )}
            {user.identity?.nostr && (
              <div className="truncate text-zinc-400">
                <span className="text-zinc-500 mr-2">NOSTR:</span>
                <span className="text-zinc-300">{user.identity.nostr}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center space-x-1 border-b border-[#272a30] pb-2 text-xs font-medium">
        {[
          { id: 'OVERVIEW', label: 'OVERVIEW' },
          { id: 'THREADS', label: `THREADS (${userThreads.length})` },
          { id: 'ESSAYS', label: `ESSAYS (${userEssays.length})` },
          { id: 'LEDGER', label: 'REPUTATION LEDGER' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-3 py-1.5 rounded-md transition-colors ${
              activeTab === tab.id
                ? 'bg-[#f7931a]/15 text-[#f7931a] font-bold border border-[#f7931a]/30'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#121418]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === 'OVERVIEW' && (
        <div className="space-y-4">
          <h3 className="text-xs font-mono text-zinc-400 font-bold uppercase">RECENT INTELLECTUAL THREADS</h3>
          {userThreads.length === 0 ? (
            <div className="text-xs text-zinc-500 py-6 text-center">No threads published yet.</div>
          ) : (
            userThreads.map((thread) => (
              <ThreadCard key={thread.id} thread={thread} onNavigate={onNavigate} />
            ))
          )}
        </div>
      )}

      {activeTab === 'THREADS' && (
        <div className="space-y-4">
          {userThreads.map((thread) => (
            <ThreadCard key={thread.id} thread={thread} onNavigate={onNavigate} />
          ))}
        </div>
      )}

      {activeTab === 'ESSAYS' && (
        <div className="space-y-4">
          {userEssays.map((thread) => (
            <ThreadCard key={thread.id} thread={thread} onNavigate={onNavigate} />
          ))}
        </div>
      )}

      {activeTab === 'LEDGER' && (
        <div className="bg-[#121418] border border-[#272a30] rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-[#1e2127] pb-3">
            <span className="text-xs font-mono text-[#f7931a] font-bold uppercase flex items-center space-x-1.5">
              <TrendingUp className="w-4 h-4" />
              <span>REPUTATION AUDIT LEDGER</span>
            </span>
            <span className="text-xs font-mono text-zinc-300 font-bold">TOTAL SCORE: {user.reputation} REP</span>
          </div>

          <div className="space-y-2">
            {userEvents.map((evt) => (
              <div key={evt.id} className="p-3 bg-[#0b0c0e] rounded-lg border border-zinc-800 text-xs flex justify-between items-center">
                <div>
                  <div className="font-semibold text-zinc-200">{evt.reason}</div>
                  <div className="text-[10px] text-zinc-500 font-mono mt-0.5">
                    {new Date(evt.timestamp).toLocaleString()} • Actor: {evt.actorName}
                  </div>
                </div>
                <span className="font-mono text-emerald-400 font-bold text-sm">+{evt.weight} REP</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
