'use client';

import React, { useState } from 'react';
import { useAppStore } from '@/lib/store';
import {
  TrendingUp,
  Award,
  BookOpen,
  Sparkles,
  Search,
  Zap,
  Cpu,
  Shield,
  ExternalLink,
  ArrowUpRight,
} from 'lucide-react';

interface RightIntelligencePanelProps {
  onNavigate: (view: string, id?: string) => void;
}

export const RightIntelligencePanel: React.FC<RightIntelligencePanelProps> = ({ onNavigate }) => {
  const { marketMetrics, threads, knowledgePages } = useAppStore();
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResponse, setAiResponse] = useState<string | null>(null);

  // Trending discussions sorted by citation density & replies
  const trendingThreads = [...threads]
    .sort((a, b) => b.citationsCount * 3 + b.repliesCount - (a.citationsCount * 3 + a.repliesCount))
    .slice(0, 4);

  const handleAskAI = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiPrompt.trim()) return;

    setAiLoading(true);
    setAiResponse(null);

    try {
      const res = await fetch('/api/ai/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: aiPrompt,
          availableThreads: threads,
          availableKnowledge: knowledgePages,
        }),
      });

      const data = await res.json();
      if (data.answer) {
        setAiResponse(data.answer);
      } else {
        setAiResponse('Philosopher AI evaluated the archives but found no direct consensus matching your query.');
      }
    } catch (err) {
      setAiResponse('Error querying Philosopher AI backend.');
    } finally {
      setAiLoading(false);
    }
  };

  return (
    <aside className="w-full lg:w-80 shrink-0 space-y-6 text-xs">
      {/* 1. Bitcoin Network Telemetry & Market Metrics */}
      <div className="bg-[#121418] border border-[#272a30] rounded-xl p-3.5 shadow-sm">
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#1e2127]">
          <div className="flex items-center space-x-1.5 text-[10px] font-mono tracking-widest text-[#f7931a] uppercase font-bold">
            <span className="w-2 h-2 rounded-full bg-[#f7931a]"></span>
            <span>BITCOIN TELEMETRY</span>
          </div>
          <span className="text-[10px] text-zinc-500 font-mono">LIVE</span>
        </div>

        <div className="grid grid-cols-2 gap-2 font-mono">
          <div className="bg-[#14171d] p-2 rounded-lg border border-[#272a30]">
            <div className="text-[9px] text-zinc-500 uppercase">BTC PRICE</div>
            <div className="text-sm font-bold text-zinc-100">${marketMetrics.btcPriceUsd.toLocaleString()}</div>
            <div className="text-[10px] text-emerald-400 font-semibold">+{marketMetrics.btcPriceChange24h}% 24h</div>
          </div>

          <div className="bg-[#14171d] p-2 rounded-lg border border-[#272a30]">
            <div className="text-[9px] text-zinc-500 uppercase">BLOCK HEIGHT</div>
            <div className="text-sm font-bold text-zinc-100">#{marketMetrics.blockHeight}</div>
            <div className="text-[10px] text-zinc-400">Halving Epoch 5</div>
          </div>

          <div className="bg-[#14171d] p-2 rounded-lg border border-[#272a30]">
            <div className="text-[9px] text-zinc-500 uppercase">FEE RATE</div>
            <div className="text-sm font-bold text-[#f7931a]">{marketMetrics.recommendedFeeSatByte} sat/vB</div>
            <div className="text-[10px] text-zinc-400">Medium Priority</div>
          </div>

          <div className="bg-[#14171d] p-2 rounded-lg border border-[#272a30]">
            <div className="text-[9px] text-zinc-500 uppercase">HASHRATE</div>
            <div className="text-sm font-bold text-zinc-100">{marketMetrics.hashrateEh} EH/s</div>
            <div className="text-[10px] text-zinc-400">Diff {marketMetrics.difficultyT}T</div>
          </div>
        </div>
      </div>

      {/* 2. Philosopher AI Search & Citation Navigation */}
      <div className="bg-gradient-to-br from-[#14171d] to-[#121418] border border-[#f7931a]/30 rounded-xl p-3.5 shadow-md">
        <div className="flex items-center space-x-2 text-[#f7931a] font-semibold mb-2">
          <Sparkles className="w-4 h-4" />
          <span className="text-xs tracking-wider">PHILOSOPHER AI NAVIGATOR</span>
        </div>
        <p className="text-[11px] text-zinc-400 mb-2.5 leading-relaxed">
          Ask questions across canonical threads, Austrian economics papers, and protocol archives.
        </p>

        <form onSubmit={handleAskAI} className="space-y-2">
          <div className="relative">
            <input
              type="text"
              placeholder="e.g., Explain Hayekian calculation..."
              value={aiPrompt}
              onChange={(e) => setAiPrompt(e.target.value)}
              className="w-full bg-[#0b0c0e] border border-[#272a30] rounded-lg pl-3 pr-8 py-1.5 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-[#f7931a]"
            />
            <button
              type="submit"
              disabled={aiLoading}
              className="absolute right-1.5 top-1.5 p-1 rounded bg-[#f7931a] text-black hover:bg-[#e08213] transition-colors"
            >
              <Search className="w-3 h-3" />
            </button>
          </div>
        </form>

        {aiLoading && (
          <div className="mt-3 p-2.5 rounded-lg bg-[#0b0c0e] border border-zinc-800 text-zinc-400 text-[11px] flex items-center space-x-2">
            <span className="w-3 h-3 rounded-full border-2 border-[#f7931a] border-t-transparent animate-spin"></span>
            <span>Querying forum archives...</span>
          </div>
        )}

        {aiResponse && !aiLoading && (
          <div className="mt-3 p-2.5 rounded-lg bg-[#0b0c0e] border border-[#f7931a]/30 text-zinc-300 text-[11px] leading-relaxed max-h-48 overflow-y-auto space-y-1">
            <div className="font-bold text-[#f7931a] text-[10px] uppercase font-mono">Synthesized Archive Response</div>
            <p>{aiResponse}</p>
          </div>
        )}
      </div>

      {/* 3. Trending Discussions */}
      <div className="bg-[#121418] border border-[#272a30] rounded-xl p-3.5">
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#1e2127]">
          <span className="text-[10px] font-mono tracking-widest text-zinc-500 uppercase font-semibold flex items-center gap-1">
            <TrendingUp className="w-3 h-3 text-[#f7931a]" />
            MOST DISCUSSED & CITED
          </span>
        </div>

        <div className="space-y-3">
          {trendingThreads.map((thread) => (
            <div
              key={thread.id}
              onClick={() => onNavigate('thread', thread.id)}
              className="group cursor-pointer p-2 rounded-lg bg-[#14171d]/60 border border-transparent hover:border-[#272a30] hover:bg-[#14171d] transition-all"
            >
              <div className="text-zinc-200 font-medium text-xs group-hover:text-[#f7931a] transition-colors line-clamp-2 leading-snug">
                {thread.title}
              </div>
              <div className="flex items-center justify-between mt-1.5 text-[10px] text-zinc-500">
                <span>By {thread.author.displayName}</span>
                <span className="font-mono text-[#f7931a]">{thread.citationsCount} citations • {thread.repliesCount} replies</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 4. Living Knowledge Hubs */}
      <div className="bg-[#121418] border border-[#272a30] rounded-xl p-3.5">
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#1e2127]">
          <span className="text-[10px] font-mono tracking-widest text-zinc-500 uppercase font-semibold flex items-center gap-1">
            <BookOpen className="w-3 h-3 text-emerald-400" />
            LIVING KNOWLEDGE HUBS
          </span>
        </div>

        <div className="space-y-2">
          {knowledgePages.map((page) => (
            <div
              key={page.id}
              onClick={() => onNavigate('knowledge-page', page.id)}
              className="cursor-pointer p-2 rounded-lg bg-[#14171d] border border-[#272a30] hover:border-emerald-500/50 transition-colors"
            >
              <div className="flex items-center justify-between text-zinc-200 font-semibold text-xs">
                <span>{page.title}</span>
                <ArrowUpRight className="w-3 h-3 text-zinc-500" />
              </div>
              <p className="text-[10px] text-zinc-400 mt-1 line-clamp-2">{page.summary}</p>
            </div>
          ))}
        </div>
      </div>
    </aside>
  );
};
