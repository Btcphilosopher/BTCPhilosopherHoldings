'use client';

import React, { useState } from 'react';
import { useAppStore } from '@/lib/store';
import { Layers, Search, Sparkles, ExternalLink, Filter, BookOpen } from 'lucide-react';

interface KnowledgeGraphViewProps {
  onNavigate: (view: string, id?: string) => void;
}

export const KnowledgeGraphView: React.FC<KnowledgeGraphViewProps> = ({ onNavigate }) => {
  const { threads, knowledgePages } = useAppStore();
  const [selectedNodeType, setSelectedNodeType] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeNodeId, setActiveNodeId] = useState<string>('n-1');

  // Build graph nodes & edges dynamically from seed data
  const nodes = [
    { id: 'n-1', label: 'Bitcoin (L1 Base Layer)', type: 'TOPIC', color: '#f7931a', threadId: 'th-1' },
    { id: 'n-2', label: 'Misesian Regression Theorem', type: 'CLAIM', color: '#a855f7', threadId: 'th-1' },
    { id: 'n-3', label: 'Carl Menger (1892)', type: 'SOURCE', color: '#3b82f6', threadId: 'th-1' },
    { id: 'n-4', label: 'Layer 2 Payment Channels', type: 'TOPIC', color: '#10b981', threadId: 'th-[mock]' },
    { id: 'n-5', label: 'Satoshi Nakamoto', type: 'AUTHOR', color: '#ec4899', threadId: 'th-2' },
    { id: 'n-6', label: 'Stock-to-Flow Model', type: 'COUNTERARGUMENT', color: '#f43f5e', threadId: 'th-3' },
    { id: 'n-7', label: 'Gresham-Hayek Law', type: 'CLAIM', color: '#eab308', threadId: 'th-1' },
  ];

  const edges = [
    { from: 'n-1', to: 'n-2', label: 'validates' },
    { from: 'n-2', to: 'n-3', label: 'cites literature' },
    { from: 'n-1', to: 'n-5', label: 'authored by' },
    { from: 'n-1', to: 'n-4', label: 'scales via' },
    { from: 'n-2', to: 'n-6', label: 'disputes' },
    { from: 'n-3', to: 'n-7', label: 'derives' },
  ];

  const filteredNodes = nodes.filter((n) => {
    const matchesType = selectedNodeType === 'ALL' || n.type === selectedNodeType;
    const matchesSearch = n.label.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesSearch;
  });

  const activeNode = nodes.find((n) => n.id === activeNodeId) || nodes[0];

  return (
    <div className="max-w-6xl mx-auto py-4 space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#272a30] pb-4">
        <div>
          <h1 className="text-xl font-extrabold text-zinc-100 flex items-center space-x-2">
            <Layers className="w-5 h-5 text-[#f7931a]" />
            <span>FORUM KNOWLEDGE GRAPH & ARGUMENT MAP</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Explore dialectical node linkages connecting claims, literature sources, topics, and authors.
          </p>
        </div>

        {/* Filter Toolbar */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2 text-zinc-500" />
            <input
              type="text"
              placeholder="Search graph nodes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-[#121418] border border-[#272a30] rounded-lg pl-9 pr-3 py-1 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-[#f7931a]"
            />
          </div>

          <select
            value={selectedNodeType}
            onChange={(e) => setSelectedNodeType(e.target.value)}
            className="bg-[#121418] border border-[#272a30] rounded-lg px-3 py-1 text-xs text-zinc-200 focus:outline-none"
          >
            <option value="ALL">All Node Types</option>
            <option value="TOPIC">Topic</option>
            <option value="CLAIM">Claim</option>
            <option value="SOURCE">Source</option>
            <option value="AUTHOR">Author</option>
            <option value="COUNTERARGUMENT">Counterargument</option>
          </select>
        </div>
      </div>

      {/* Main Graph Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Canvas / SVG Visual Representation */}
        <div className="lg:col-span-2 bg-[#121418] border border-[#272a30] rounded-xl p-6 min-h-[480px] relative flex flex-col justify-between overflow-hidden shadow-inner">
          <div className="flex items-center justify-between text-[10px] font-mono text-zinc-500 uppercase pb-2 border-b border-[#1e2127]">
            <span>DIALECTICAL LINKAGE NETWORK</span>
            <span>{filteredNodes.length} Active Nodes</span>
          </div>

          {/* Graphical Node Canvas Visual Mock */}
          <div className="relative my-auto py-12 flex flex-wrap items-center justify-center gap-6">
            {filteredNodes.map((node) => {
              const isActive = node.id === activeNodeId;
              return (
                <div
                  key={node.id}
                  onClick={() => setActiveNodeId(node.id)}
                  style={{ borderColor: node.color }}
                  className={`p-3 rounded-xl border-2 cursor-pointer transition-all duration-300 shadow-lg flex flex-col items-center justify-center text-center max-w-[170px] ${
                    isActive
                      ? 'bg-[#181b20] scale-105 ring-2 ring-offset-2 ring-offset-[#0b0c0e] ring-[#f7931a]'
                      : 'bg-[#14171d] hover:bg-[#181b20]'
                  }`}
                >
                  <span
                    className="text-[9px] font-mono font-bold uppercase px-1.5 py-0.5 rounded text-black mb-1.5"
                    style={{ backgroundColor: node.color }}
                  >
                    {node.type}
                  </span>
                  <span className="text-xs font-bold text-zinc-100 line-clamp-2 leading-tight">
                    {node.label}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Legend */}
          <div className="pt-3 border-t border-[#1e2127] flex flex-wrap items-center justify-center gap-4 text-[10px] font-mono text-zinc-400">
            <span className="flex items-center space-x-1">
              <span className="w-2.5 h-2.5 rounded-full bg-[#f7931a]"></span>
              <span>TOPIC</span>
            </span>
            <span className="flex items-center space-x-1">
              <span className="w-2.5 h-2.5 rounded-full bg-[#a855f7]"></span>
              <span>CLAIM</span>
            </span>
            <span className="flex items-center space-x-1">
              <span className="w-2.5 h-2.5 rounded-full bg-[#3b82f6]"></span>
              <span>SOURCE</span>
            </span>
            <span className="flex items-center space-x-1">
              <span className="w-2.5 h-2.5 rounded-full bg-[#f43f5e]"></span>
              <span>COUNTERARGUMENT</span>
            </span>
          </div>
        </div>

        {/* Selected Node Details Card */}
        <div className="bg-[#121418] border border-[#272a30] rounded-xl p-5 space-y-4">
          <div className="text-xs font-mono text-[#f7931a] uppercase font-bold flex items-center justify-between border-b border-[#1e2127] pb-2">
            <span>SELECTED NODE DETAILS</span>
            <span className="text-[10px] text-zinc-500">{activeNode.id}</span>
          </div>

          <div>
            <span
              className="text-[9px] font-mono font-bold uppercase px-2 py-0.5 rounded text-black"
              style={{ backgroundColor: activeNode.color }}
            >
              {activeNode.type}
            </span>
            <h3 className="text-lg font-bold text-zinc-100 mt-2">{activeNode.label}</h3>
          </div>

          {/* Connected Edges */}
          <div className="space-y-2">
            <div className="text-[10px] font-mono text-zinc-500 uppercase font-semibold">
              CONNECTED ARCS ({edges.filter((e) => e.from === activeNode.id || e.to === activeNode.id).length})
            </div>
            <div className="space-y-1.5 text-xs text-zinc-300">
              {edges
                .filter((e) => e.from === activeNode.id || e.to === activeNode.id)
                .map((edge, idx) => {
                  const targetId = edge.from === activeNode.id ? edge.to : edge.from;
                  const targetNode = nodes.find((n) => n.id === targetId);
                  return (
                    <div key={idx} className="p-2 bg-[#0b0c0e] rounded border border-zinc-800 flex items-center justify-between">
                      <span className="text-[10px] font-mono text-[#f7931a]">{edge.label}</span>
                      <span className="font-semibold text-zinc-200">{targetNode?.label}</span>
                    </div>
                  );
                })}
            </div>
          </div>

          <button
            onClick={() => onNavigate('thread', activeNode.threadId || 'th-1')}
            className="w-full py-2 bg-[#f7931a] text-black font-bold text-xs rounded-lg hover:bg-[#e08213] transition-colors flex items-center justify-center space-x-2"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Open Associated Discussion Thread</span>
          </button>
        </div>
      </div>
    </div>
  );
};
