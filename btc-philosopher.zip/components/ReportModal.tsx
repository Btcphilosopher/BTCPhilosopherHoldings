'use client';

import React, { useState } from 'react';
import { useAppStore, store } from '@/lib/store';
import { Flag, AlertTriangle } from 'lucide-react';

export const ReportModal: React.FC = () => {
  const { activeReportItem } = useAppStore();
  const [reason, setReason] = useState('');

  if (!activeReportItem) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) return;
    store.submitReport(reason.trim());
    setReason('');
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#121418] border border-rose-500/50 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b border-[#1e2127] pb-3">
          <div className="flex items-center space-x-2 text-rose-400 font-bold text-sm">
            <Flag className="w-4 h-4" />
            <span>SUBMIT MODERATION REPORT</span>
          </div>
          <button onClick={() => store.closeReportModal()} className="text-zinc-500 hover:text-zinc-200 font-bold">
            ✕
          </button>
        </div>

        <div className="text-xs text-zinc-300">
          Target: <strong className="text-zinc-100">{activeReportItem.title}</strong>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <textarea
            rows={3}
            placeholder="State grounds for report (e.g. ad hominem attack, spam, inaccurate primary source citation)..."
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            required
            className="w-full bg-[#0b0c0e] border border-[#272a30] rounded-xl p-3 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-rose-500"
          />

          <div className="flex justify-end">
            <button
              type="submit"
              className="px-4 py-2 bg-rose-600 text-white font-bold text-xs rounded-lg hover:bg-rose-500"
            >
              Submit Flag to Moderation Queue
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
