'use client';

import React, { useState } from 'react';
import { useAppStore, store } from '@/lib/store';
import { Zap, Copy, Check, QrCode } from 'lucide-react';

export const TippingModal: React.FC = () => {
  const { activeTipModalUser } = useAppStore();
  const [satsAmount, setSatsAmount] = useState(1000);
  const [copied, setCopied] = useState(false);
  const [invoiceGenerated, setInvoiceGenerated] = useState(false);

  if (!activeTipModalUser) return null;

  const address = `${activeTipModalUser.username}@btcphilosopher.org`;
  const invoice = `lnbc${satsAmount}0n1p3...philosopher_tip_${activeTipModalUser.username}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#121418] border border-[#f7931a]/50 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-5 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between border-b border-[#1e2127] pb-3">
          <div className="flex items-center space-x-2 text-[#f7931a] font-bold text-sm">
            <Zap className="w-5 h-5 fill-current" />
            <span>TIP SATS TO {activeTipModalUser.displayName.toUpperCase()}</span>
          </div>
          <button
            onClick={() => store.closeTipModal()}
            className="text-zinc-500 hover:text-zinc-200 text-sm font-bold"
          >
            ✕
          </button>
        </div>

        {/* User preview */}
        <div className="flex items-center space-x-3 bg-[#14171d] p-3 rounded-xl border border-[#272a30]">
          <img
            src={activeTipModalUser.avatarUrl}
            alt={activeTipModalUser.displayName}
            className="w-10 h-10 rounded-full object-cover border border-[#f7931a]"
          />
          <div>
            <div className="font-bold text-zinc-100 text-xs">{activeTipModalUser.displayName}</div>
            <div className="text-[10px] text-[#f7931a] font-mono">{address}</div>
          </div>
        </div>

        {/* Amount Presets */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-zinc-300">SELECT SATOSHIS AMOUNT</label>
          <div className="grid grid-cols-4 gap-2 text-xs font-mono font-bold">
            {[210, 1000, 5000, 21000].map((amt) => (
              <button
                key={amt}
                onClick={() => {
                  setSatsAmount(amt);
                  setInvoiceGenerated(false);
                }}
                className={`py-2 rounded-lg border transition-colors ${
                  satsAmount === amt
                    ? 'bg-[#f7931a] text-black border-[#f7931a]'
                    : 'bg-[#14171d] border-[#272a30] text-zinc-300 hover:border-zinc-700'
                }`}
              >
                {amt.toLocaleString()} sats
              </button>
            ))}
          </div>
        </div>

        {/* Lightning Invoice / QR Code View */}
        <div className="bg-[#0b0c0e] p-4 rounded-xl border border-zinc-800 text-center space-y-3 font-mono">
          <div className="w-32 h-32 mx-auto bg-zinc-900 border-2 border-[#f7931a] rounded-xl flex items-center justify-center text-xs text-[#f7931a] p-2">
            {/* Visual QR Geometry */}
            <div className="space-y-1 text-center">
              <QrCode className="w-12 h-12 mx-auto text-[#f7931a]" />
              <span className="text-[9px] text-zinc-400">LN-URL PAY</span>
            </div>
          </div>

          <div className="text-xs text-zinc-300 break-all p-2 bg-[#14171d] rounded border border-zinc-800 text-[10px]">
            {address}
          </div>

          <button
            onClick={handleCopy}
            className="w-full py-2 bg-[#181b20] border border-zinc-700 hover:border-[#f7931a] text-zinc-200 text-xs font-bold rounded-lg transition-colors flex items-center justify-center space-x-1.5"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-[#f7931a]" />}
            <span>{copied ? 'Copied Lightning Address!' : 'Copy Lightning Address'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
