'use client';

import React from 'react';
import { useAppStore } from '@/lib/store';
import { BookOpen, PenTool, Sparkles, ArrowRight, Quote } from 'lucide-react';
import { ThreadCard } from './ThreadCard';

interface EssaysViewProps {
  onNavigate: (view: string, id?: string) => void;
}

export const EssaysView: React.FC<EssaysViewProps> = ({ onNavigate }) => {
  const { threads } = useAppStore();
  const essays = threads.filter((t) => t.type === 'ESSAY' || t.posts[0]?.content.length > 600);

  return (
    <div className="max-w-5xl mx-auto py-4 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#272a30] pb-4">
        <div>
          <h1 className="text-xl font-extrabold text-zinc-100 flex items-center space-x-2">
            <BookOpen className="w-5 h-5 text-purple-400" />
            <span>EDITORIAL ESSAYS & LONG-FORM MONOGRAPHS</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Durable, long-form scholarship on monetary economics, protocol architecture, and digital philosophy.
          </p>
        </div>

        <button
          onClick={() => onNavigate('create')}
          className="px-4 py-2 rounded-lg bg-purple-600 text-white font-bold text-xs hover:bg-purple-500 transition-colors flex items-center space-x-1.5 shadow-md"
        >
          <PenTool className="w-3.5 h-3.5" />
          <span>Publish Essay</span>
        </button>
      </div>

      <div className="space-y-4">
        {essays.map((essay) => (
          <ThreadCard key={essay.id} thread={essay} onNavigate={onNavigate} />
        ))}
      </div>
    </div>
  );
};
