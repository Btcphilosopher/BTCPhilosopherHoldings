'use client';

import React from 'react';
import { useAppStore } from '@/lib/store';
import {
  Home,
  Compass,
  Users,
  Bookmark,
  BookOpen,
  FolderTree,
  Archive,
  BarChart2,
  ShieldAlert,
  HelpCircle,
  Coins,
  Cpu,
  Zap,
  TrendingUp,
  Scale,
  Globe,
  Bot,
  KeyRound,
  Brain,
  Building2,
  Layers,
} from 'lucide-react';

interface LeftSidebarProps {
  onNavigate: (view: string, id?: string) => void;
  activeView: string;
  selectedCategoryId?: string;
  onSelectCategory?: (catId: string | undefined) => void;
}

export const LeftSidebar: React.FC<LeftSidebarProps> = ({
  onNavigate,
  activeView,
  selectedCategoryId,
  onSelectCategory,
}) => {
  const { categories, bookmarkCollections, currentUser } = useAppStore();

  const totalBookmarks = bookmarkCollections.reduce(
    (acc, col) => acc + col.threadIds.length,
    0
  );

  const mainNav = [
    { id: 'home', label: 'HOME', icon: Home },
    { id: 'discover', label: 'DISCOVER', icon: Compass },
    { id: 'essays', label: 'ESSAYS', icon: BookOpen },
    { id: 'knowledge', label: 'KNOWLEDGE', icon: FolderTree },
    { id: 'bookmarks', label: 'BOOKMARKS', icon: Bookmark, badge: totalBookmarks },
    { id: 'graph', label: 'KNOWLEDGE GRAPH', icon: Layers },
    { id: 'archive', label: 'ARCHIVE', icon: Archive },
    { id: 'dashboard', label: 'INTELLIGENCE', icon: BarChart2 },
    { id: 'admin', label: 'MODERATION', icon: ShieldAlert },
  ];

  const getCategoryIcon = (slug: string) => {
    switch (slug) {
      case 'bitcoin-discussion': return Coins;
      case 'bitcoin-protocol': return Cpu;
      case 'lightning': return Zap;
      case 'bitcoin-economics': return TrendingUp;
      case 'austrian-economics': return Scale;
      case 'macroeconomics': return Globe;
      case 'artificial-intelligence': return Bot;
      case 'cryptography': return KeyRound;
      case 'epistemology': return Brain;
      case 'institutions': return Building2;
      default: return Coins;
    }
  };

  return (
    <aside className="w-full lg:w-64 shrink-0 space-y-6 text-xs">
      {/* Primary Left Navigation */}
      <div className="bg-[#121418] border border-[#272a30] rounded-xl p-3 shadow-sm">
        <div className="text-[10px] font-mono tracking-widest text-zinc-500 uppercase px-3 pb-2 border-b border-[#1e2127] mb-2 font-semibold">
          NAVIGATION
        </div>
        <nav className="space-y-1">
          {mainNav.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.id && !selectedCategoryId;
            return (
              <button
                key={item.id}
                onClick={() => {
                  if (onSelectCategory) onSelectCategory(undefined);
                  onNavigate(item.id);
                }}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg transition-all ${
                  isActive
                    ? 'bg-[#f7931a]/15 text-[#f7931a] font-semibold border border-[#f7931a]/30'
                    : 'text-zinc-300 hover:text-zinc-100 hover:bg-[#181b20]'
                }`}
              >
                <div className="flex items-center space-x-2.5">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-[#f7931a]' : 'text-zinc-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="bg-[#1e2127] text-zinc-300 font-mono text-[10px] px-2 py-0.5 rounded-full border border-zinc-700">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Forum Categories */}
      <div className="bg-[#121418] border border-[#272a30] rounded-xl p-3 shadow-sm">
        <div className="flex items-center justify-between px-3 pb-2 border-b border-[#1e2127] mb-2">
          <span className="text-[10px] font-mono tracking-widest text-zinc-500 uppercase font-semibold">
            CATEGORIES
          </span>
          <span className="text-[10px] text-zinc-500 font-mono">{categories.length}</span>
        </div>
        <div className="space-y-0.5 max-h-80 overflow-y-auto pr-1">
          <button
            onClick={() => {
              if (onSelectCategory) onSelectCategory(undefined);
              onNavigate('home');
            }}
            className={`w-full text-left px-3 py-1.5 rounded-md text-xs transition-colors flex items-center justify-between ${
              !selectedCategoryId && activeView === 'home'
                ? 'text-[#f7931a] font-medium bg-[#181b20]'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#181b20]'
            }`}
          >
            <span>All Categories</span>
          </button>
          {categories.map((cat) => {
            const Icon = getCategoryIcon(cat.slug);
            const isSelected = selectedCategoryId === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => {
                  if (onSelectCategory) onSelectCategory(cat.id);
                  onNavigate('category', cat.id);
                }}
                className={`w-full text-left px-3 py-1.5 rounded-md text-xs transition-colors flex items-center justify-between group ${
                  isSelected
                    ? 'text-[#f7931a] font-semibold bg-[#f7931a]/10 border border-[#f7931a]/30'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#181b20]'
                }`}
              >
                <div className="flex items-center space-x-2 truncate">
                  <Icon className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-[#f7931a]' : 'text-zinc-500 group-hover:text-zinc-300'}`} />
                  <span className="truncate">{cat.name}</span>
                </div>
                <span className="text-[10px] text-zinc-600 font-mono shrink-0 ml-1">
                  {cat.threadsCount}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* User Reputation Quick Info Box */}
      <div className="bg-[#121418] border border-[#272a30] rounded-xl p-3">
        <div className="flex items-center space-x-3">
          <img
            src={currentUser.avatarUrl}
            alt={currentUser.displayName}
            className="w-9 h-9 rounded-lg object-cover border border-[#f7931a]/50"
          />
          <div>
            <div className="font-semibold text-zinc-200">{currentUser.displayName}</div>
            <div className="text-[10px] text-zinc-400 flex items-center space-x-2">
              <span className="text-[#f7931a] font-mono font-bold">{currentUser.reputation} REP</span>
              <span>•</span>
              <span className="text-zinc-500">{currentUser.role}</span>
            </div>
          </div>
        </div>
        <div className="mt-3 pt-2 border-t border-[#1e2127] flex justify-between text-[11px] text-zinc-400">
          <span>Threads: <strong className="text-zinc-200">{currentUser.threadsCount}</strong></span>
          <span>Posts: <strong className="text-zinc-200">{currentUser.postsCount}</strong></span>
        </div>
      </div>
    </aside>
  );
};
