'use client';

import React from 'react';
import { Thread } from '@/lib/types';
import { store, useAppStore } from '@/lib/store';
import {
  MessageSquare,
  Eye,
  Bookmark,
  Sparkles,
  Pin,
  Clock,
  Quote,
  TrendingUp,
  FileText,
  HelpCircle,
  Vote,
  ShieldCheck,
} from 'lucide-react';

interface ThreadCardProps {
  thread: Thread;
  onNavigate: (view: string, id?: string) => void;
}

export const ThreadCard: React.FC<ThreadCardProps> = ({ thread, onNavigate }) => {
  const { bookmarkCollections, isPhilosopherMode } = useAppStore();
  const isBookmarked = bookmarkCollections[0].threadIds.includes(thread.id);

  const getDecayBadgeColor = (status: string) => {
    switch (status) {
      case 'CURRENT': return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
      case 'AGING': return 'bg-amber-500/10 text-amber-400 border-amber-500/30';
      case 'HISTORICAL': return 'bg-blue-500/10 text-blue-400 border-blue-500/30';
      case 'SUPERSEDED': return 'bg-rose-500/10 text-rose-400 border-rose-500/30';
      default: return 'bg-zinc-800 text-zinc-400 border-zinc-700';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'ESSAY': return <FileText className="w-3.5 h-3.5 text-purple-400" />;
      case 'QUESTION': return <HelpCircle className="w-3.5 h-3.5 text-amber-400" />;
      case 'POLL': return <Vote className="w-3.5 h-3.5 text-cyan-400" />;
      default: return <MessageSquare className="w-3.5 h-3.5 text-[#f7931a]" />;
    }
  };

  return (
    <article className="group bg-[#14171d] border border-[#272a30] hover:border-[#f7931a]/50 rounded-xl p-4 transition-all duration-200 shadow-sm hover:shadow-md relative">
      {/* Top Meta Line: Category, Status & Decay Badge */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-2 text-[11px]">
        <div className="flex items-center space-x-2">
          {thread.state === 'PINNED' && (
            <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full bg-[#f7931a]/15 text-[#f7931a] font-semibold border border-[#f7931a]/30">
              <Pin className="w-3 h-3" />
              <span>PINNED</span>
            </span>
          )}

          <button
            onClick={(e) => {
              e.stopPropagation();
              onNavigate('category', thread.categoryId);
            }}
            className="font-semibold text-[#f7931a] hover:underline"
          >
            {thread.categoryName}
          </button>

          <span className="text-zinc-600">•</span>

          <div className="flex items-center space-x-1 font-mono text-zinc-400">
            {getTypeIcon(thread.type)}
            <span className="uppercase text-[10px]">{thread.type}</span>
          </div>
        </div>

        {/* Decay Badge & Bookmarks */}
        <div className="flex items-center space-x-2">
          <span className={`px-2 py-0.5 rounded-full font-mono text-[9px] uppercase border ${getDecayBadgeColor(thread.decayStatus)}`}>
            {thread.decayStatus}
          </span>

          <button
            onClick={(e) => {
              e.stopPropagation();
              store.toggleBookmarkThread(thread.id);
            }}
            className={`p-1 rounded hover:bg-zinc-800 transition-colors ${
              isBookmarked ? 'text-[#f7931a]' : 'text-zinc-500 hover:text-zinc-300'
            }`}
            title="Bookmark Thread"
          >
            <Bookmark className="w-3.5 h-3.5 fill-current" />
          </button>
        </div>
      </div>

      {/* Title & Subtitle */}
      <div
        onClick={() => onNavigate('thread', thread.id)}
        className="cursor-pointer group-hover:text-[#f7931a] transition-colors"
      >
        <h3 className="text-base font-bold text-zinc-100 leading-snug tracking-tight">
          {thread.title}
        </h3>
        {thread.subtitle && (
          <p className="text-xs text-zinc-400 mt-1 line-clamp-2 leading-relaxed">
            {thread.subtitle}
          </p>
        )}
      </div>

      {/* Philosopher Mode Argument Blocks Preview (if enabled) */}
      {isPhilosopherMode && thread.posts[0]?.arguments && thread.posts[0].arguments.length > 0 && (
        <div className="mt-3 p-2.5 rounded-lg bg-[#0b0c0e] border border-zinc-800/80 space-y-1 text-xs">
          <div className="text-[10px] font-mono text-amber-400 font-semibold flex items-center space-x-1">
            <Sparkles className="w-3 h-3" />
            <span>ARGUMENT PREVIEW:</span>
          </div>
          {thread.posts[0].arguments.slice(0, 2).map((arg) => (
            <div key={arg.id} className={`p-1.5 rounded text-[11px] text-zinc-300 arg-marker-${arg.type.toLowerCase()}`}>
              <strong className="text-zinc-400 uppercase text-[9px] font-mono mr-1.5">{arg.type}:</strong>
              <span>{arg.text}</span>
            </div>
          ))}
        </div>
      )}

      {/* Footer Info: Author, Activity & Metrics */}
      <div className="mt-4 pt-3 border-t border-[#1e2127] flex flex-wrap items-center justify-between gap-3 text-xs">
        {/* Author Bio */}
        <div
          onClick={(e) => {
            e.stopPropagation();
            onNavigate('profile', thread.author.id);
          }}
          className="flex items-center space-x-2.5 cursor-pointer hover:opacity-80 transition-opacity"
        >
          <img
            src={thread.author.avatarUrl}
            alt={thread.author.displayName}
            className="w-7 h-7 rounded-full object-cover border border-zinc-700"
          />
          <div>
            <div className="font-semibold text-zinc-200 text-xs flex items-center space-x-1">
              <span>{thread.author.displayName}</span>
              <span className="text-[10px] text-[#f7931a] font-mono">({thread.author.reputation} rep)</span>
            </div>
            <div className="text-[10px] text-zinc-500 font-mono">
              Joined {thread.author.joinDate}
            </div>
          </div>
        </div>

        {/* Thread Metrics & Activity */}
        <div className="flex items-center space-x-4 text-[11px] text-zinc-400 font-mono">
          <span className="flex items-center space-x-1 text-[#f7931a]" title="Citations density">
            <Quote className="w-3 h-3" />
            <span>{thread.citationsCount}</span>
          </span>

          <span className="flex items-center space-x-1" title="Total replies">
            <MessageSquare className="w-3 h-3 text-zinc-500" />
            <span>{thread.repliesCount}</span>
          </span>

          <span className="flex items-center space-x-1" title="Views">
            <Eye className="w-3 h-3 text-zinc-500" />
            <span>{thread.viewsCount}</span>
          </span>

          <span className="hidden sm:flex items-center space-x-1 text-zinc-500" title="Last Activity">
            <Clock className="w-3 h-3" />
            <span>{new Date(thread.lastActivityAt).toLocaleDateString()}</span>
          </span>
        </div>
      </div>
    </article>
  );
};
