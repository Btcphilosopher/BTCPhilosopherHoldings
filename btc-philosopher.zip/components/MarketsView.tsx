'use client';

import React from 'react';
import { useAppStore } from '@/lib/store';
import { TrendingUp, Cpu, Zap, Shield, Globe, Activity, HardDrive, BarChart3 } from 'lucide-react';

export const MarketsView: React.FC = () => {
  const { marketMetrics } = useAppStore();

  return (
    <div className="max-w-5xl mx-auto py-4 space-y-6">
      <div className="border-b border-[#272a30] pb-4">
        <h1 className="text-xl font-extrabold text-zinc-100 flex items-center space-x-2">
          <TrendingUp className="w-5 h-5 text-[#f7931a]" />
          <span>BITCOIN TELEMETRY & NETWORK METRICS</span>
        </h1>
        <p className="text-xs text-zinc-400 mt-0.5">
          Real-time network telemetry, monetary policy parameters, and mempool conditions.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono">
        <div className="bg-[#121418] border border-[#272a30] rounded-xl p-4 space-y-1">
          <div className="text-[10px] text-zinc-500 uppercase flex items-center justify-between">
            <span>BITCOIN PRICE (USD)</span>
            <span className="text-emerald-400">+{marketMetrics.btcPriceChange24h}%</span>
          </div>
          <div className="text-2xl font-bold text-zinc-100">${marketMetrics.btcPriceUsd.toLocaleString()}</div>
          <div className="text-[10px] text-zinc-400">Market Cap: ${(marketMetrics.marketCapUsd / 1e9).toFixed(1)}B</div>
        </div>

        <div className="bg-[#121418] border border-[#272a30] rounded-xl p-4 space-y-1">
          <div className="text-[10px] text-zinc-500 uppercase flex items-center justify-between">
            <span>BLOCK HEIGHT</span>
            <HardDrive className="w-3.5 h-3.5 text-[#f7931a]" />
          </div>
          <div className="text-2xl font-bold text-zinc-100">#{marketMetrics.blockHeight}</div>
          <div className="text-[10px] text-zinc-400">Halving Epoch 5 (Subsidy: 3.125 BTC)</div>
        </div>

        <div className="bg-[#121418] border border-[#272a30] rounded-xl p-4 space-y-1">
          <div className="text-[10px] text-zinc-500 uppercase flex items-center justify-between">
            <span>RECOMMENDED FEE</span>
            <Zap className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-[#f7931a]">{marketMetrics.recommendedFeeSatByte} sat/vB</div>
          <div className="text-[10px] text-zinc-400">Next block priority target</div>
        </div>

        <div className="bg-[#121418] border border-[#272a30] rounded-xl p-4 space-y-1">
          <div className="text-[10px] text-zinc-500 uppercase flex items-center justify-between">
            <span>HASHRATE & DIFF</span>
            <Cpu className="w-3.5 h-3.5 text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-zinc-100">{marketMetrics.hashrateEh} EH/s</div>
          <div className="text-[10px] text-zinc-400">Difficulty: {marketMetrics.difficultyT}T</div>
        </div>
      </div>

      {/* Monetary Policy Schedule Summary */}
      <div className="bg-[#121418] border border-[#272a30] rounded-xl p-6 space-y-4">
        <h3 className="text-sm font-bold text-zinc-100 font-mono uppercase text-[#f7931a]">
          HARD-CODED MONETARY ISSUANCE SCHEDULE
        </h3>
        <p className="text-xs text-zinc-300 leading-relaxed">
          Bitcoin&apos;s issuance curve is bounded by $20,999,999.9769$ BTC. The current subsidy rate of 3.125 BTC per block ensures an annualized inflation rate below 0.85%, lower than gold.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-mono">
          <div className="p-3 bg-[#0b0c0e] rounded-lg border border-zinc-800">
            <span className="text-[10px] text-zinc-500 block">CURRENT ISSUANCE</span>
            <span className="text-base font-bold text-zinc-200">~450 BTC / day</span>
          </div>
          <div className="p-3 bg-[#0b0c0e] rounded-lg border border-zinc-800">
            <span className="text-[10px] text-zinc-500 block">NEXT HALVING ESTIMATE</span>
            <span className="text-base font-bold text-zinc-200">April 2028 (Block 1,050,000)</span>
          </div>
          <div className="p-3 bg-[#0b0c0e] rounded-lg border border-zinc-800">
            <span className="text-[10px] text-zinc-500 block">TERMINAL SUBSIDY</span>
            <span className="text-base font-bold text-zinc-200">Year 2140 (0 BTC)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
