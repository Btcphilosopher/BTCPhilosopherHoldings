'use client';

import React, { useState, useEffect } from 'react';
import { useAppStore } from '@/lib/store';
import { Search, Sparkles, Filter, BookOpen } from 'lucide-react';
import { ThreadCard } from './ThreadCard';

interface SearchViewProps {
  onNavigate: (view: string, id?: string) => void;
}

export const SearchView: React.FC<SearchViewProps> = ({ onNavigate }) => {
  const { searchQuery, threads, knowledgePages } = useAppStore();
  const [query, setQuery] = useState(searchQuery || '');
  const [aiAnswer, setAiAnswer] = useState<string | null>(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [suggestedQuestions, setSuggestedQuestions] = useState<string[]>([]);

  const filteredThreads = threads.filter((t) => {
    if (!query.trim()) return true;
    const q = query.toLowerCase();
    return (
      t.title.toLowerCase().includes(q) ||
      t.subtitle?.toLowerCase().includes(q) ||
      t.tags.some((tag) => tag.toLowerCase().includes(q)) ||
      t.posts.some((p) => p.content.toLowerCase().includes(q))
    );
  });

  const handleRunAiSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!query.trim()) return;

    setAiLoading(true);
    setAiAnswer(null);

    try {
      const res = await fetch('/api/ai/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query,
          availableThreads: threads,
          availableKnowledge: knowledgePages,
        }),
      });

      const data = await res.json();
      if (data.answer) {
        setAiAnswer(data.answer);
        setSuggestedQuestions(data.suggestedQuestions || []);
      }
    } catch (err) {
      setAiAnswer('Error running Philosopher AI semantic search.');
    } finally {
      setAiLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto py-4 space-y-6">
      {/* Search Header Form */}
      <div className="bg-[#121418] border border-[#272a30] rounded-xl p-6 shadow-sm space-y-4">
        <h1 className="text-xl font-bold text-zinc-100 flex items-center space-x-2">
          <Search className="w-5 h-5 text-[#f7931a]" />
          <span>SEMANTIC ARCHIVE SEARCH</span>
        </h1>

        <form onSubmit={handleRunAiSearch} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-3 text-zinc-500" />
            <input
              type="text"
              placeholder="Search claims, literature sources, topics, or ask a question..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full bg-[#0b0c0e] border border-[#272a30] rounded-lg pl-10 pr-4 py-2.5 text-sm text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-[#f7931a]"
            />
          </div>
          <button
            type="submit"
            disabled={aiLoading}
            className="px-5 py-2.5 bg-[#f7931a] text-black font-bold text-xs rounded-lg hover:bg-[#e08213] transition-colors flex items-center space-x-2 shadow-md"
          >
            <Sparkles className="w-4 h-4" />
            <span>AI Synthesize</span>
          </button>
        </form>
      </div>

      {/* AI Synthesized Answer Card */}
      {aiLoading && (
        <div className="p-4 bg-[#121418] border border-zinc-800 rounded-xl text-xs text-zinc-400 flex items-center space-x-2">
          <span className="w-4 h-4 rounded-full border-2 border-[#f7931a] border-t-transparent animate-spin"></span>
          <span>Philosopher AI analyzing corpus across threads and primary literature...</span>
        </div>
      )}

      {aiAnswer && !aiLoading && (
        <div className="bg-gradient-to-br from-[#14171d] to-[#121418] border border-[#f7931a]/40 rounded-xl p-5 space-y-3 shadow-lg">
          <div className="flex items-center space-x-2 text-[#f7931a] font-bold text-xs uppercase font-mono">
            <Sparkles className="w-4 h-4" />
            <span>PHILOSOPHER AI SYNTHESIS</span>
          </div>
          <p className="text-sm text-zinc-200 leading-relaxed font-sans">{aiAnswer}</p>

          {suggestedQuestions.length > 0 && (
            <div className="pt-2 border-t border-[#1e2127]">
              <span className="text-[10px] font-mono text-zinc-500 uppercase font-semibold">Suggested Intellectual Inquiries:</span>
              <div className="flex flex-wrap gap-2 mt-1.5">
                {suggestedQuestions.map((q, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setQuery(q);
                      handleRunAiSearch();
                    }}
                    className="px-2.5 py-1 bg-[#0b0c0e] border border-zinc-800 rounded text-xs text-zinc-300 hover:text-[#f7931a] hover:border-[#f7931a]/40 transition-colors"
                  >
                    💡 {q}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Results Stream */}
      <div className="space-y-4">
        <div className="flex items-center justify-between text-xs font-mono text-zinc-400 border-b border-[#272a30] pb-2">
          <span>MATCHING ARCHIVE THREADS ({filteredThreads.length})</span>
        </div>

        {filteredThreads.map((thread) => (
          <ThreadCard key={thread.id} thread={thread} onNavigate={onNavigate} />
        ))}
      </div>
    </div>
  );
};
