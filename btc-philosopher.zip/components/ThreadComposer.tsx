'use client';

import React, { useState } from 'react';
import { useAppStore, store } from '@/lib/store';
import ReactMarkdown from 'react-markdown';
import {
  PenTool,
  Sparkles,
  Quote,
  Send,
  HelpCircle,
  Vote,
  FileText,
  MessageSquare,
} from 'lucide-react';
import { ArgumentBlock, Citation } from '@/lib/types';

interface ThreadComposerProps {
  onNavigate: (view: string, id?: string) => void;
}

export const ThreadComposer: React.FC<ThreadComposerProps> = ({ onNavigate }) => {
  const { categories } = useAppStore();

  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [categoryId, setCategoryId] = useState(categories[0]?.id || 'cat-btc-econ');
  const [type, setType] = useState<'THREAD' | 'ESSAY' | 'QUESTION' | 'POLL'>('THREAD');
  const [tagsInput, setTagsInput] = useState('bitcoin, economics, philosophy');
  const [content, setContent] = useState('');
  const [editorMode, setEditorMode] = useState<'WRITE' | 'PREVIEW' | 'SPLIT'>('WRITE');

  // Argument & Citation state
  const [tempArgumentType, setTempArgumentType] = useState<ArgumentBlock['type']>('CLAIM');
  const [tempArgumentText, setTempArgumentText] = useState('');
  const [argumentsList, setArgumentsList] = useState<ArgumentBlock[]>([]);

  const [tempCitationTitle, setTempCitationTitle] = useState('');
  const [tempCitationAuthor, setTempCitationAuthor] = useState('');
  const [tempCitationQuote, setTempCitationQuote] = useState('');
  const [citationsList, setCitationsList] = useState<Citation[]>([]);

  // Poll state
  const [pollQuestion, setPollQuestion] = useState('');
  const [pollOptions, setPollOptions] = useState<string[]>(['Option 1', 'Option 2']);

  const handleAddArgument = () => {
    if (!tempArgumentText.trim()) return;
    setArgumentsList([
      ...argumentsList,
      { id: `arg-${Date.now()}`, type: tempArgumentType, text: tempArgumentText.trim() },
    ]);
    setTempArgumentText('');
  };

  const handleAddCitation = () => {
    if (!tempCitationTitle.trim() || !tempCitationQuote.trim()) return;
    setCitationsList([
      ...citationsList,
      {
        id: `cit-${Date.now()}`,
        sourceType: 'book',
        title: tempCitationTitle.trim(),
        author: tempCitationAuthor.trim() || 'Unknown',
        quote: tempCitationQuote.trim(),
      },
    ]);
    setTempCitationTitle('');
    setTempCitationAuthor('');
    setTempCitationQuote('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    const tags = tagsInput
      .split(',')
      .map((t) => t.trim().toLowerCase())
      .filter(Boolean);

    const newThread = store.createThread({
      title: title.trim(),
      subtitle: subtitle.trim() || undefined,
      categoryId,
      type,
      tags,
      content: content.trim(),
      arguments: argumentsList,
      citations: citationsList,
      pollQuestion: type === 'POLL' ? pollQuestion : undefined,
      pollOptions: type === 'POLL' ? pollOptions.filter(Boolean) : undefined,
    });

    onNavigate('thread', newThread.id);
  };

  return (
    <div className="max-w-4xl mx-auto py-4 space-y-6">
      <div className="flex items-center justify-between border-b border-[#272a30] pb-3">
        <div>
          <h1 className="text-xl font-bold text-zinc-100 flex items-center space-x-2">
            <PenTool className="w-5 h-5 text-[#f7931a]" />
            <span>PUBLISH TO BTC PHILOSOPHER</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Durable discussion threads become part of the permanent knowledge archive.
          </p>
        </div>

        {/* Editor Mode Selector */}
        <div className="flex items-center space-x-1 bg-[#121418] p-1 rounded-lg border border-[#272a30] text-xs">
          {(['WRITE', 'PREVIEW', 'SPLIT'] as const).map((mode) => (
            <button
              key={mode}
              onClick={() => setEditorMode(mode)}
              className={`px-3 py-1 rounded-md font-medium transition-colors ${
                editorMode === mode ? 'bg-[#f7931a] text-black font-bold' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              {mode}
            </button>
          ))}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Thread Type Selection */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          {[
            { id: 'THREAD', label: 'Discussion Thread', icon: MessageSquare, desc: 'Chronological argument' },
            { id: 'ESSAY', label: 'Long-Form Essay', icon: FileText, desc: 'Editorial publication' },
            { id: 'QUESTION', label: 'Knowledge Question', icon: HelpCircle, desc: 'Solicits expert answers' },
            { id: 'POLL', label: 'Consensus Poll', icon: Vote, desc: 'Immutable voting' },
          ].map((item) => {
            const Icon = item.icon;
            const isSelected = type === item.id;
            return (
              <div
                key={item.id}
                onClick={() => setType(item.id as any)}
                className={`p-3 rounded-xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-[#f7931a]/15 border-[#f7931a] text-[#f7931a]'
                    : 'bg-[#121418] border-[#272a30] text-zinc-400 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center space-x-2 font-bold text-xs">
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </div>
                <div className="text-[10px] text-zinc-500 mt-1">{item.desc}</div>
              </div>
            );
          })}
        </div>

        {/* Title, Subtitle, Category & Tags */}
        <div className="bg-[#121418] border border-[#272a30] rounded-xl p-4 space-y-3">
          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1">THREAD TITLE</label>
            <input
              type="text"
              placeholder="e.g. Is Bitcoin a Monetary Asset or a Monetary Network?"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              className="w-full bg-[#0b0c0e] border border-[#272a30] rounded-lg p-2.5 text-sm text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-[#f7931a] font-semibold"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1">SUBTITLE / PREMISE ABSTRACT</label>
            <input
              type="text"
              placeholder="Brief summary of the inquiry or thesis..."
              value={subtitle}
              onChange={(e) => setSubtitle(e.target.value)}
              className="w-full bg-[#0b0c0e] border border-[#272a30] rounded-lg p-2 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-[#f7931a]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">FORUM CATEGORY</label>
              <select
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value)}
                className="w-full bg-[#0b0c0e] border border-[#272a30] rounded-lg p-2 text-xs text-zinc-200 focus:outline-none focus:border-[#f7931a]"
              >
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.group}: {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">TAGS (comma separated)</label>
              <input
                type="text"
                placeholder="monetary-economics, austrian-economics"
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
                className="w-full bg-[#0b0c0e] border border-[#272a30] rounded-lg p-2 text-xs text-zinc-200 focus:outline-none focus:border-[#f7931a] font-mono"
              />
            </div>
          </div>
        </div>

        {/* Poll Options (If Poll selected) */}
        {type === 'POLL' && (
          <div className="bg-[#121418] border border-cyan-500/40 rounded-xl p-4 space-y-3">
            <div className="text-xs font-bold text-cyan-400 font-mono flex items-center space-x-1.5">
              <Vote className="w-4 h-4" />
              <span>CONFIGURE POLL QUESTION & OPTIONS</span>
            </div>

            <input
              type="text"
              placeholder="Poll Question?"
              value={pollQuestion}
              onChange={(e) => setPollQuestion(e.target.value)}
              className="w-full bg-[#0b0c0e] border border-zinc-700 rounded-lg p-2 text-xs text-zinc-200"
            />

            <div className="space-y-2">
              {pollOptions.map((opt, i) => (
                <div key={i} className="flex items-center space-x-2">
                  <input
                    type="text"
                    placeholder={`Option ${i + 1}`}
                    value={opt}
                    onChange={(e) => {
                      const copy = [...pollOptions];
                      copy[i] = e.target.value;
                      setPollOptions(copy);
                    }}
                    className="flex-1 bg-[#0b0c0e] border border-zinc-700 rounded p-1.5 text-xs text-zinc-200"
                  />
                  {pollOptions.length > 2 && (
                    <button
                      type="button"
                      onClick={() => setPollOptions(pollOptions.filter((_, idx) => idx !== i))}
                      className="text-rose-400 text-xs hover:underline"
                    >
                      Remove
                    </button>
                  )}
                </div>
              ))}
              <button
                type="button"
                onClick={() => setPollOptions([...pollOptions, `Option ${pollOptions.length + 1}`])}
                className="text-xs text-cyan-400 hover:underline font-semibold"
              >
                + Add Poll Option
              </button>
            </div>
          </div>
        )}

        {/* Content Body Editor */}
        <div className={`grid gap-4 ${editorMode === 'SPLIT' ? 'grid-cols-2' : 'grid-cols-1'}`}>
          {(editorMode === 'WRITE' || editorMode === 'SPLIT') && (
            <textarea
              rows={12}
              placeholder="Write your long-form argument using Markdown formatting, LaTeX math ($S_t$), code blocks, and footnotes..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              required
              className="w-full bg-[#121418] border border-[#272a30] rounded-xl p-4 text-xs text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-[#f7931a] font-mono leading-relaxed shadow-inner"
            />
          )}

          {(editorMode === 'PREVIEW' || editorMode === 'SPLIT') && (
            <div className="w-full bg-[#121418] border border-[#272a30] rounded-xl p-4 text-xs text-zinc-200 min-h-[280px] prose prose-invert max-w-none">
              <ReactMarkdown>{content || '*Live preview will render markdown and math syntax here...*'}</ReactMarkdown>
            </div>
          )}
        </div>

        {/* Structured Arguments Attachment */}
        <div className="bg-[#121418] border border-[#272a30] rounded-xl p-4 space-y-3">
          <div className="text-xs font-bold text-amber-400 font-mono flex items-center space-x-1.5">
            <Sparkles className="w-4 h-4" />
            <span>ARGUMENT STRUCTURE TAGGING (PHILOSOPHER MODE)</span>
          </div>

          <div className="flex flex-wrap gap-2">
            <select
              value={tempArgumentType}
              onChange={(e) => setTempArgumentType(e.target.value as any)}
              className="bg-[#0b0c0e] border border-zinc-700 rounded text-xs text-zinc-200 px-2 py-1.5"
            >
              <option value="CLAIM">CLAIM</option>
              <option value="EVIDENCE">EVIDENCE</option>
              <option value="ARGUMENT">ARGUMENT</option>
              <option value="COUNTERARGUMENT">COUNTERARGUMENT</option>
              <option value="QUESTION">QUESTION</option>
              <option value="CONCLUSION">CONCLUSION</option>
            </select>

            <input
              type="text"
              placeholder="Formal argument statement..."
              value={tempArgumentText}
              onChange={(e) => setTempArgumentText(e.target.value)}
              className="flex-1 min-w-[240px] bg-[#0b0c0e] border border-zinc-700 rounded px-2.5 py-1.5 text-xs text-zinc-200 placeholder-zinc-500"
            />

            <button
              type="button"
              onClick={handleAddArgument}
              className="px-3 py-1.5 bg-zinc-800 text-zinc-200 hover:bg-zinc-700 rounded text-xs font-semibold"
            >
              + Tag Argument
            </button>
          </div>

          {argumentsList.length > 0 && (
            <div className="space-y-1.5 pt-2">
              {argumentsList.map((arg, idx) => (
                <div key={idx} className="text-xs text-zinc-300 font-mono flex items-center justify-between bg-[#0b0c0e] p-2 rounded border border-zinc-800">
                  <span>[{arg.type}] {arg.text}</span>
                  <button
                    type="button"
                    onClick={() => setArgumentsList(argumentsList.filter((_, i) => i !== idx))}
                    className="text-rose-400 hover:underline text-[10px]"
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Citations Attachment */}
        <div className="bg-[#121418] border border-[#272a30] rounded-xl p-4 space-y-3">
          <div className="text-xs font-bold text-[#f7931a] font-mono flex items-center space-x-1.5">
            <Quote className="w-4 h-4" />
            <span>PRIMARY SOURCES & CITATIONS</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <input
              type="text"
              placeholder="Title (e.g. On the Origins of Money)"
              value={tempCitationTitle}
              onChange={(e) => setTempCitationTitle(e.target.value)}
              className="bg-[#0b0c0e] border border-zinc-700 rounded px-2.5 py-1.5 text-xs text-zinc-200"
            />
            <input
              type="text"
              placeholder="Author (e.g. Carl Menger)"
              value={tempCitationAuthor}
              onChange={(e) => setTempCitationAuthor(e.target.value)}
              className="bg-[#0b0c0e] border border-zinc-700 rounded px-2.5 py-1.5 text-xs text-zinc-200"
            />
            <input
              type="text"
              placeholder="Quote snippet..."
              value={tempCitationQuote}
              onChange={(e) => setTempCitationQuote(e.target.value)}
              className="bg-[#0b0c0e] border border-zinc-700 rounded px-2.5 py-1.5 text-xs text-zinc-200"
            />
          </div>

          <button
            type="button"
            onClick={handleAddCitation}
            className="px-3 py-1.5 bg-zinc-800 text-zinc-200 hover:bg-zinc-700 rounded text-xs font-semibold"
          >
            + Attach Citation
          </button>

          {citationsList.length > 0 && (
            <div className="space-y-1.5 pt-1">
              {citationsList.map((cit, idx) => (
                <div key={idx} className="text-xs text-zinc-300 flex items-center justify-between bg-[#0b0c0e] p-2 rounded border border-zinc-800">
                  <span>📜 &quot;{cit.title}&quot; by {cit.author}</span>
                  <button
                    type="button"
                    onClick={() => setCitationsList(citationsList.filter((_, i) => i !== idx))}
                    className="text-rose-400 hover:underline text-[10px]"
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Submit */}
        <div className="flex justify-end pt-2">
          <button
            type="submit"
            className="px-6 py-2.5 rounded-xl bg-[#f7931a] text-black font-bold text-xs hover:bg-[#e08213] transition-colors flex items-center space-x-2 shadow-lg"
          >
            <Send className="w-4 h-4" />
            <span>Publish Thread to Archive</span>
          </button>
        </div>
      </form>
    </div>
  );
};
