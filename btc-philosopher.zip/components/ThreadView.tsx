'use client';

import React, { useState } from 'react';
import { Thread, Post, ArgumentBlock, Citation } from '@/lib/types';
import { store, useAppStore } from '@/lib/store';
import ReactMarkdown from 'react-markdown';
import {
  Sparkles,
  Bookmark,
  Share2,
  Clock,
  Pin,
  Quote,
  MessageSquare,
  Zap,
  ThumbsUp,
  Maximize2,
  Minimize2,
  Layers,
  Flag,
  CheckCircle2,
  Plus,
  Send,
  Eye,
  BookOpen,
  Split,
  Edit3,
  HelpCircle,
  Vote,
  ExternalLink,
} from 'lucide-react';

interface ThreadViewProps {
  threadId: string;
  onNavigate: (view: string, id?: string) => void;
}

export const ThreadView: React.FC<ThreadViewProps> = ({ threadId, onNavigate }) => {
  const { threads, isPhilosopherMode, isFocusMode, currentUser, bookmarkCollections } = useAppStore();

  const thread = threads.find((t) => t.id === threadId) || threads[0];
  const isBookmarked = bookmarkCollections[0].threadIds.includes(thread.id);

  // AI Summary State
  const [aiSummary, setAiSummary] = useState(thread.aiSummary || null);
  const [aiSummaryLoading, setAiSummaryLoading] = useState(false);

  // Reply Composer State
  const [replyContent, setReplyContent] = useState('');
  const [editorMode, setEditorMode] = useState<'WRITE' | 'PREVIEW' | 'SPLIT'>('WRITE');
  const [quotingPostId, setQuotingPostId] = useState<string | null>(null);

  // Argument & Citation Composer Helpers
  const [tempArgumentType, setTempArgumentType] = useState<ArgumentBlock['type']>('CLAIM');
  const [tempArgumentText, setTempArgumentText] = useState('');
  const [addedArguments, setAddedArguments] = useState<ArgumentBlock[]>([]);

  const [tempCitationTitle, setTempCitationTitle] = useState('');
  const [tempCitationAuthor, setTempCitationAuthor] = useState('');
  const [tempCitationQuote, setTempCitationQuote] = useState('');
  const [addedCitations, setAddedCitations] = useState<Citation[]>([]);

  const handleGenerateAISummary = async () => {
    setAiSummaryLoading(true);
    try {
      const res = await fetch('/api/ai/summarize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          threadTitle: thread.title,
          threadContent: thread.posts[0]?.content || '',
          posts: thread.posts.map((p) => ({ authorName: p.author.displayName, content: p.content })),
        }),
      });
      const data = await res.json();
      if (!data.error) {
        setAiSummary(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setAiSummaryLoading(false);
    }
  };

  const handleAddArgument = () => {
    if (!tempArgumentText.trim()) return;
    setAddedArguments([
      ...addedArguments,
      { id: `arg-${Date.now()}`, type: tempArgumentType, text: tempArgumentText.trim() },
    ]);
    setTempArgumentText('');
  };

  const handleAddCitation = () => {
    if (!tempCitationTitle.trim() || !tempCitationQuote.trim()) return;
    setAddedCitations([
      ...addedCitations,
      {
        id: `cit-${Date.now()}`,
        sourceType: 'book',
        title: tempCitationTitle.trim(),
        author: tempCitationAuthor.trim() || 'Unknown',
        quote: tempCitationQuote.trim(),
      },
    ]);
    setTempCitationTitle('');
    setTempCitationAuthor('');
    setTempCitationQuote('');
  };

  const handlePostReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyContent.trim()) return;

    store.createReply(thread.id, replyContent, addedArguments, addedCitations, quotingPostId || undefined);

    setReplyContent('');
    setAddedArguments([]);
    setAddedCitations([]);
    setQuotingPostId(null);
  };

  return (
    <div className={`max-w-5xl mx-auto space-y-6 ${isFocusMode ? 'py-4' : 'py-2'}`}>
      {/* Controls Bar: Focus Mode, Compare Thread, Bookmark */}
      <div className="flex items-center justify-between text-xs text-zinc-400 border-b border-[#272a30] pb-3">
        <button
          onClick={() => onNavigate('category', thread.categoryId)}
          className="text-[#f7931a] hover:underline font-semibold flex items-center space-x-1"
        >
          <span>← {thread.categoryName}</span>
        </button>

        <div className="flex items-center space-x-3">
          {/* Focus Mode Toggle */}
          <button
            onClick={() => store.setFocusMode(!isFocusMode)}
            className="flex items-center space-x-1 px-2.5 py-1 rounded bg-[#14171d] border border-[#272a30] hover:text-zinc-100"
            title="Focus Reading Mode"
          >
            {isFocusMode ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            <span>{isFocusMode ? 'Exit Focus' : 'Focus Mode'}</span>
          </button>

          {/* Compare Threads Button */}
          <button
            onClick={() => store.openCompareModal(thread.id, threads[1]?.id || thread.id)}
            className="flex items-center space-x-1 px-2.5 py-1 rounded bg-[#14171d] border border-[#272a30] text-purple-400 hover:border-purple-500/50"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Compare Thread</span>
          </button>

          {/* Bookmark */}
          <button
            onClick={() => store.toggleBookmarkThread(thread.id)}
            className={`flex items-center space-x-1 px-2.5 py-1 rounded bg-[#14171d] border border-[#272a30] ${
              isBookmarked ? 'text-[#f7931a]' : 'hover:text-zinc-100'
            }`}
          >
            <Bookmark className="w-3.5 h-3.5 fill-current" />
            <span>{isBookmarked ? 'Bookmarked' : 'Bookmark'}</span>
          </button>
        </div>
      </div>

      {/* Thread Header Block */}
      <header className="bg-[#121418] border border-[#272a30] rounded-xl p-6 shadow-sm">
        <div className="flex items-center space-x-2 text-xs font-mono text-zinc-400 mb-2">
          <span className="px-2 py-0.5 rounded bg-[#181b20] border border-zinc-700 text-[#f7931a]">
            {thread.type}
          </span>
          <span>•</span>
          <span>Created {new Date(thread.createdAt).toLocaleDateString()}</span>
          <span>•</span>
          <span className="text-emerald-400">{thread.decayStatus}</span>
        </div>

        <h1 className="text-2xl sm:text-3xl font-extrabold text-zinc-100 leading-tight tracking-tight">
          {thread.title}
        </h1>

        {thread.subtitle && (
          <p className="text-sm text-zinc-300 mt-2 leading-relaxed font-sans">
            {thread.subtitle}
          </p>
        )}

        {/* Tags */}
        <div className="flex flex-wrap gap-1.5 mt-4">
          {thread.tags.map((tag) => (
            <span
              key={tag}
              className="px-2.5 py-0.5 rounded-full text-[11px] font-mono bg-[#181b20] text-zinc-300 border border-[#272a30]"
            >
              #{tag}
            </span>
          ))}
        </div>

        {/* Author Details Header */}
        <div className="mt-5 pt-4 border-t border-[#1e2127] flex flex-wrap items-center justify-between gap-4 text-xs">
          <div
            onClick={() => onNavigate('profile', thread.author.id)}
            className="flex items-center space-x-3 cursor-pointer group"
          >
            <img
              src={thread.author.avatarUrl}
              alt={thread.author.displayName}
              className="w-10 h-10 rounded-full object-cover border-2 border-[#f7931a]"
            />
            <div>
              <div className="font-bold text-zinc-100 group-hover:text-[#f7931a] transition-colors flex items-center space-x-1.5">
                <span>{thread.author.displayName}</span>
                <span className="text-[#f7931a] font-mono text-xs">({thread.author.reputation} REP)</span>
              </div>
              <div className="text-[11px] text-zinc-400">
                {thread.author.bio}
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => store.openTipModal(thread.author)}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-[#f7931a]/15 text-[#f7931a] font-semibold border border-[#f7931a]/40 hover:bg-[#f7931a]/25 transition-colors text-xs"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Tip Author</span>
            </button>
          </div>
        </div>
      </header>

      {/* AI Thread Summary Panel */}
      <div className="bg-gradient-to-r from-[#14171d] via-[#161a22] to-[#121418] border border-[#f7931a]/40 rounded-xl p-4 shadow-md">
        <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#272a30]">
          <div className="flex items-center space-x-2 text-[#f7931a] font-bold text-xs uppercase tracking-wider">
            <Sparkles className="w-4 h-4" />
            <span>PHILOSOPHER AI THREAD SUMMARY</span>
            <span className="text-[9px] font-mono text-zinc-500 uppercase bg-zinc-800 px-1.5 py-0.5 rounded">Machine Generated</span>
          </div>

          {!aiSummary && (
            <button
              onClick={handleGenerateAISummary}
              disabled={aiSummaryLoading}
              className="px-3 py-1 rounded bg-[#f7931a] text-black font-semibold text-xs hover:bg-[#e08213] transition-colors"
            >
              {aiSummaryLoading ? 'Analyzing...' : 'Generate AI Summary'}
            </button>
          )}
        </div>

        {aiSummary ? (
          <div className="space-y-3 text-xs text-zinc-300 leading-relaxed">
            <p className="font-medium text-zinc-200">{aiSummary.summary}</p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
              <div className="bg-[#0b0c0e] p-2.5 rounded-lg border border-zinc-800">
                <div className="font-bold text-amber-400 text-[10px] uppercase font-mono mb-1">Key Arguments</div>
                <ul className="list-disc list-inside space-y-1 text-zinc-400">
                  {aiSummary.arguments.map((arg, idx) => (
                    <li key={idx}>{arg}</li>
                  ))}
                </ul>
              </div>

              <div className="bg-[#0b0c0e] p-2.5 rounded-lg border border-zinc-800">
                <div className="font-bold text-rose-400 text-[10px] uppercase font-mono mb-1">Counterarguments</div>
                <ul className="list-disc list-inside space-y-1 text-zinc-400">
                  {aiSummary.counterarguments.map((carg, idx) => (
                    <li key={idx}>{carg}</li>
                  ))}
                </ul>
              </div>
            </div>

            {aiSummary.sources.length > 0 && (
              <div className="pt-2">
                <span className="text-[10px] font-mono text-zinc-500 uppercase font-semibold">Cited Sources:</span>
                <div className="flex flex-wrap gap-2 mt-1">
                  {aiSummary.sources.map((src, i) => (
                    <span key={i} className="px-2 py-0.5 bg-[#0b0c0e] border border-zinc-800 rounded text-[11px] text-zinc-300">
                      📜 {src}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          <p className="text-xs text-zinc-400">
            Click &quot;Generate AI Summary&quot; to synthesize key claims, counterarguments, cited literature, and unresolved questions across this discussion.
          </p>
        )}
      </div>

      {/* Poll Section (if any) */}
      {thread.poll && (
        <div className="bg-[#14171d] border border-cyan-500/30 rounded-xl p-5 space-y-3">
          <div className="flex items-center space-x-2 text-cyan-400 font-bold text-xs uppercase font-mono">
            <Vote className="w-4 h-4" />
            <span>COMMUNITY POLL</span>
          </div>

          <h3 className="text-base font-bold text-zinc-100">{thread.poll.question}</h3>

          <div className="space-y-2 max-w-xl">
            {thread.poll.options.map((opt) => {
              const pct = thread.poll!.totalVotes > 0 ? Math.round((opt.votes / thread.poll!.totalVotes) * 100) : 0;
              const hasVoted = thread.poll!.userVotedOptionIds?.includes(opt.id);

              return (
                <div
                  key={opt.id}
                  onClick={() => store.votePoll(thread.id, opt.id)}
                  className={`p-3 rounded-lg border cursor-pointer transition-all relative overflow-hidden ${
                    hasVoted
                      ? 'bg-cyan-500/10 border-cyan-500 text-cyan-200'
                      : 'bg-[#0b0c0e] border-[#272a30] hover:border-cyan-500/50 text-zinc-300'
                  }`}
                >
                  <div
                    className="absolute left-0 top-0 bottom-0 bg-cyan-500/15 transition-all"
                    style={{ width: `${pct}%` }}
                  ></div>
                  <div className="relative flex justify-between items-center text-xs font-medium">
                    <span>{opt.text}</span>
                    <span className="font-mono text-cyan-400">{pct}% ({opt.votes} votes)</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Chronological Posts Stream */}
      <div className="space-y-6">
        <div className="flex items-center justify-between border-b border-[#272a30] pb-2 text-xs text-zinc-400 font-mono">
          <span>CHRONOLOGICAL REPLIES ({thread.posts.length})</span>
          <span>Permanent Stable Anchors Active</span>
        </div>

        {thread.posts.map((post) => (
          <article
            key={post.id}
            id={`post-${post.postNumber}`}
            className="bg-[#121418] border border-[#272a30] rounded-xl p-5 shadow-sm space-y-4 relative"
          >
            {/* Post Header: User Avatar, Post #, Anchor */}
            <div className="flex items-center justify-between pb-3 border-b border-[#1e2127]">
              <div className="flex items-center space-x-3">
                <img
                  src={post.author.avatarUrl}
                  alt={post.author.displayName}
                  className="w-8 h-8 rounded-full object-cover border border-[#f7931a]"
                />
                <div>
                  <div className="font-bold text-zinc-100 text-xs flex items-center space-x-2">
                    <span
                      onClick={() => onNavigate('profile', post.author.id)}
                      className="hover:underline cursor-pointer"
                    >
                      {post.author.displayName}
                    </span>
                    <span className="text-[#f7931a] font-mono text-[10px]">({post.author.reputation} REP)</span>
                  </div>
                  <div className="text-[10px] text-zinc-500 font-mono">
                    Posted {new Date(post.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • Joined {post.author.joinDate}
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-2 font-mono text-xs">
                <a
                  href={`#post-${post.postNumber}`}
                  className="px-2 py-0.5 rounded bg-[#181b20] border border-zinc-700 text-zinc-400 hover:text-[#f7931a] transition-colors"
                >
                  #{post.postNumber}
                </a>
              </div>
            </div>

            {/* Quoted Snippet (if any) */}
            {post.quoteSnippet && (
              <div className="p-3 rounded-lg bg-[#0b0c0e] border-l-2 border-[#f7931a] text-xs text-zinc-400 italic">
                <div className="font-semibold text-zinc-300 not-italic text-[11px] mb-1">
                  Quoting Post #{post.quoteSnippet.postNumber} by {post.quoteSnippet.authorName}:
                </div>
                &quot;{post.quoteSnippet.text}&quot;
              </div>
            )}

            {/* Markdown Body Content */}
            <div className="text-sm text-zinc-200 leading-relaxed space-y-3 font-sans prose prose-invert max-w-none">
              <ReactMarkdown>{post.content}</ReactMarkdown>
            </div>

            {/* Argument Markers (Philosopher Mode) */}
            {isPhilosopherMode && post.arguments && post.arguments.length > 0 && (
              <div className="mt-4 pt-3 border-t border-[#1e2127] space-y-2">
                <div className="text-[10px] font-mono text-amber-400 uppercase font-semibold flex items-center space-x-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>STRUCTURED ARGUMENT MARKERS:</span>
                </div>
                {post.arguments.map((arg) => (
                  <div key={arg.id} className={`p-2.5 rounded-lg text-xs text-zinc-200 arg-marker-${arg.type.toLowerCase()}`}>
                    <span className="font-mono text-[10px] font-bold uppercase mr-2 text-zinc-400">
                      [{arg.type}]
                    </span>
                    <span>{arg.text}</span>
                  </div>
                ))}
              </div>
            )}

            {/* Citations Box */}
            {post.citations && post.citations.length > 0 && (
              <div className="mt-4 p-3 rounded-lg bg-[#0b0c0e] border border-zinc-800 space-y-2">
                <div className="text-[10px] font-mono text-[#f7931a] uppercase font-semibold flex items-center space-x-1">
                  <Quote className="w-3.5 h-3.5" />
                  <span>CITATIONS & PRIMARY SOURCES ({post.citations.length}):</span>
                </div>
                {post.citations.map((cit) => (
                  <div key={cit.id} className="text-xs text-zinc-300 space-y-1">
                    <div className="font-semibold text-zinc-100 flex items-center space-x-2">
                      <span>&quot;{cit.title}&quot;</span>
                      <span className="text-[10px] text-zinc-500 font-mono">by {cit.author} ({cit.date || 'N/A'})</span>
                    </div>
                    <p className="italic text-zinc-400 text-[11px] border-l border-zinc-700 pl-2">
                      &quot;{cit.quote}&quot;
                    </p>
                  </div>
                ))}
              </div>
            )}

            {/* Reactions & Post Footer Actions */}
            <div className="mt-4 pt-3 border-t border-[#1e2127] flex flex-wrap items-center justify-between gap-3 text-xs">
              {/* Emoji Reactions */}
              <div className="flex items-center space-x-1.5">
                {['🧠', '⚡', '📜', '⚖️'].map((emoji) => {
                  const count = post.reactions[emoji] || 0;
                  const isUserReacted = post.userReactions?.includes(emoji);
                  return (
                    <button
                      key={emoji}
                      onClick={() => store.reactToPost(thread.id, post.id, emoji)}
                      className={`px-2 py-1 rounded-md text-xs font-mono border transition-colors flex items-center space-x-1 ${
                        isUserReacted
                          ? 'bg-[#f7931a]/15 border-[#f7931a] text-[#f7931a]'
                          : 'bg-[#181b20] border-zinc-800 text-zinc-400 hover:border-zinc-700'
                      }`}
                    >
                      <span>{emoji}</span>
                      <span>{count}</span>
                    </button>
                  );
                })}
              </div>

              {/* Actions: Quote, Reply, Tip, Report */}
              <div className="flex items-center space-x-3 text-zinc-400 text-[11px]">
                <button
                  onClick={() => {
                    setQuotingPostId(post.id);
                    const el = document.getElementById('reply-composer');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="hover:text-zinc-100 flex items-center space-x-1"
                >
                  <Quote className="w-3 h-3 text-[#f7931a]" />
                  <span>Quote</span>
                </button>

                <button
                  onClick={() => store.openTipModal(post.author)}
                  className="hover:text-[#f7931a] flex items-center space-x-1"
                >
                  <Zap className="w-3 h-3 text-[#f7931a]" />
                  <span>Tip</span>
                </button>

                <button
                  onClick={() => store.openReportModal({ type: 'post', id: post.id, title: `Post #${post.postNumber}` })}
                  className="hover:text-rose-400 flex items-center space-x-1"
                >
                  <Flag className="w-3 h-3" />
                  <span>Report</span>
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>

      {/* Professional Publishing Editor / Reply Composer */}
      <div id="reply-composer" className="bg-[#121418] border border-[#272a30] rounded-xl p-5 shadow-lg space-y-4">
        <div className="flex items-center justify-between border-b border-[#1e2127] pb-3">
          <div className="font-bold text-zinc-100 text-sm flex items-center space-x-2">
            <Edit3 className="w-4 h-4 text-[#f7931a]" />
            <span>CONTRIBUTE INTELLECTUAL REPLY</span>
          </div>

          {/* Mode switch */}
          <div className="flex items-center space-x-1 bg-[#0b0c0e] p-1 rounded-lg border border-zinc-800 text-xs">
            {(['WRITE', 'PREVIEW', 'SPLIT'] as const).map((mode) => (
              <button
                key={mode}
                onClick={() => setEditorMode(mode)}
                className={`px-2.5 py-1 rounded-md transition-colors ${
                  editorMode === mode ? 'bg-[#f7931a] text-black font-bold' : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {mode}
              </button>
            ))}
          </div>
        </div>

        {quotingPostId && (
          <div className="p-2.5 bg-[#181b20] border border-[#f7931a]/40 rounded-lg text-xs text-zinc-300 flex justify-between items-center">
            <span>Quoting post #{quotingPostId}</span>
            <button onClick={() => setQuotingPostId(null)} className="text-zinc-500 hover:text-zinc-200">✕</button>
          </div>
        )}

        <form onSubmit={handlePostReply} className="space-y-4">
          {/* Editor Body */}
          <div className={`grid gap-4 ${editorMode === 'SPLIT' ? 'grid-cols-2' : 'grid-cols-1'}`}>
            {(editorMode === 'WRITE' || editorMode === 'SPLIT') && (
              <textarea
                rows={6}
                placeholder="Write your argument using Markdown, LaTeX math ($S_t$), or citations..."
                value={replyContent}
                onChange={(e) => setReplyContent(e.target.value)}
                className="w-full bg-[#0b0c0e] border border-[#272a30] rounded-lg p-3 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-[#f7931a] font-mono leading-relaxed"
              />
            )}

            {(editorMode === 'PREVIEW' || editorMode === 'SPLIT') && (
              <div className="w-full bg-[#0b0c0e] border border-[#272a30] rounded-lg p-3 text-xs text-zinc-200 min-h-[140px] prose prose-invert max-w-none">
                <ReactMarkdown>{replyContent || '*Preview will appear here...*'}</ReactMarkdown>
              </div>
            )}
          </div>

          {/* Argument Tagging Section (Philosopher Mode) */}
          <div className="bg-[#0b0c0e] p-3 rounded-lg border border-zinc-800 space-y-2">
            <div className="text-[11px] font-mono text-amber-400 font-semibold flex items-center justify-between">
              <span className="flex items-center space-x-1">
                <Sparkles className="w-3.5 h-3.5" />
                <span>ATTACH STRUCTURED ARGUMENT PARAGRAPH</span>
              </span>
              <span className="text-zinc-500 text-[10px]">Optional</span>
            </div>

            <div className="flex flex-wrap gap-2">
              <select
                value={tempArgumentType}
                onChange={(e) => setTempArgumentType(e.target.value as any)}
                className="bg-[#14171d] border border-zinc-700 rounded text-xs text-zinc-200 px-2 py-1 focus:outline-none"
              >
                <option value="CLAIM">CLAIM</option>
                <option value="EVIDENCE">EVIDENCE</option>
                <option value="ARGUMENT">ARGUMENT</option>
                <option value="COUNTERARGUMENT">COUNTERARGUMENT</option>
                <option value="QUESTION">QUESTION</option>
                <option value="CONCLUSION">CONCLUSION</option>
              </select>

              <input
                type="text"
                placeholder="Argument sentence..."
                value={tempArgumentText}
                onChange={(e) => setTempArgumentText(e.target.value)}
                className="flex-1 min-w-[200px] bg-[#14171d] border border-zinc-700 rounded px-2 py-1 text-xs text-zinc-200 placeholder-zinc-500"
              />

              <button
                type="button"
                onClick={handleAddArgument}
                className="px-3 py-1 bg-zinc-800 text-zinc-200 hover:bg-zinc-700 rounded text-xs font-semibold"
              >
                + Add Argument
              </button>
            </div>

            {addedArguments.length > 0 && (
              <div className="space-y-1 pt-2">
                {addedArguments.map((arg, idx) => (
                  <div key={idx} className="text-xs text-zinc-300 font-mono flex items-center justify-between bg-[#14171d] p-1.5 rounded">
                    <span>[{arg.type}] {arg.text}</span>
                    <button
                      type="button"
                      onClick={() => setAddedArguments(addedArguments.filter((_, i) => i !== idx))}
                      className="text-rose-400 hover:underline text-[10px]"
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Citation Tagger */}
          <div className="bg-[#0b0c0e] p-3 rounded-lg border border-zinc-800 space-y-2">
            <div className="text-[11px] font-mono text-[#f7931a] font-semibold flex items-center justify-between">
              <span className="flex items-center space-x-1">
                <Quote className="w-3.5 h-3.5" />
                <span>CITE LITERATURE OR SOURCE</span>
              </span>
              <span className="text-zinc-500 text-[10px]">Optional</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <input
                type="text"
                placeholder="Source Title (e.g. Human Action)"
                value={tempCitationTitle}
                onChange={(e) => setTempCitationTitle(e.target.value)}
                className="bg-[#14171d] border border-zinc-700 rounded px-2 py-1 text-xs text-zinc-200"
              />
              <input
                type="text"
                placeholder="Author (e.g. Ludwig von Mises)"
                value={tempCitationAuthor}
                onChange={(e) => setTempCitationAuthor(e.target.value)}
                className="bg-[#14171d] border border-zinc-700 rounded px-2 py-1 text-xs text-zinc-200"
              />
              <input
                type="text"
                placeholder="Direct Quote excerpt..."
                value={tempCitationQuote}
                onChange={(e) => setTempCitationQuote(e.target.value)}
                className="bg-[#14171d] border border-zinc-700 rounded px-2 py-1 text-xs text-zinc-200"
              />
            </div>

            <button
              type="button"
              onClick={handleAddCitation}
              className="px-3 py-1 bg-zinc-800 text-zinc-200 hover:bg-zinc-700 rounded text-xs font-semibold"
            >
              + Attach Citation
            </button>

            {addedCitations.length > 0 && (
              <div className="space-y-1 pt-1">
                {addedCitations.map((cit, idx) => (
                  <div key={idx} className="text-xs text-zinc-300 flex items-center justify-between bg-[#14171d] p-1.5 rounded">
                    <span>📜 &quot;{cit.title}&quot; by {cit.author}</span>
                    <button
                      type="button"
                      onClick={() => setAddedCitations(addedCitations.filter((_, i) => i !== idx))}
                      className="text-rose-400 hover:underline text-[10px]"
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              className="px-5 py-2 rounded-lg bg-[#f7931a] text-black font-bold text-xs hover:bg-[#e08213] transition-colors flex items-center space-x-2 shadow-md"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Publish Reply & Update Archive</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
