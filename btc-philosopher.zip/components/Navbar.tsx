'use client';

import React, { useState } from 'react';
import { useAppStore, store } from '@/lib/store';
import { MOCK_USERS } from '@/lib/seed-data';
import {
  Search,
  Bell,
  Sun,
  Moon,
  Sparkles,
  BookOpen,
  Zap,
  Cpu,
  Globe,
  Plus,
  User as UserIcon,
  Shield,
  Layers,
  LogOut,
  ChevronDown,
} from 'lucide-react';
import Link from 'next/link';

interface NavbarProps {
  onNavigate: (view: string, id?: string) => void;
  activeView: string;
}

export const Navbar: React.FC<NavbarProps> = ({ onNavigate, activeView }) => {
  const { currentUser, isPhilosopherMode, theme, notifications, searchQuery } = useAppStore();
  const [showNotifs, setShowNotifs] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const unreadNotifs = notifications.filter((n) => !n.isRead).length;

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    store.setSearchQuery(e.target.value);
    if (activeView !== 'search' && e.target.value.trim().length > 0) {
      onNavigate('search');
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#0b0c0e]/95 backdrop-blur-md border-b border-[#272a30]">
      {/* Top Banner Ticker / Secondary Quick Navigation */}
      <div className="max-w-[1600px] mx-auto px-4 py-1.5 flex items-center justify-between text-xs text-zinc-400 border-b border-[#1e2127]">
        <div className="flex items-center space-x-4 overflow-x-auto no-scrollbar">
          <span className="font-mono text-[#f7931a] font-semibold flex items-center space-x-1">
            <span className="inline-block w-2 h-2 rounded-full bg-[#f7931a] animate-pulse"></span>
            <span>₿-PHILOSOPHER ARCHIVE</span>
          </span>
          <span className="hidden sm:inline text-zinc-600">•</span>
          <span className="hidden sm:inline text-zinc-300">
            Durable Intellectual Forum for the 2020s
          </span>
        </div>

        <div className="flex items-center space-x-4">
          {/* Philosopher Mode Toggle */}
          <button
            onClick={() => store.setPhilosopherMode(!isPhilosopherMode)}
            className={`flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full text-xs transition-colors border ${
              isPhilosopherMode
                ? 'bg-[#f7931a]/10 border-[#f7931a]/40 text-[#f7931a]'
                : 'bg-zinc-800/60 border-zinc-700 text-zinc-400 hover:text-zinc-200'
            }`}
            title="Toggle Argument Mode, Citations, and Knowledge Graph overlays"
          >
            <Sparkles className="w-3 h-3" />
            <span className="font-medium">
              Philosopher Mode: {isPhilosopherMode ? 'ON' : 'OFF'}
            </span>
          </button>

          {/* Theme Switcher */}
          <button
            onClick={() => store.setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="p-1 rounded text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800"
            title="Toggle Theme"
          >
            {theme === 'dark' ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Main Navigation Row */}
      <div className="max-w-[1600px] mx-auto px-4 py-2.5 flex items-center justify-between gap-4">
        {/* Brand Identity */}
        <div className="flex items-center space-x-6">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center space-x-3 group text-left"
          >
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#181b20] to-[#0b0c0e] border border-[#f7931a]/40 flex items-center justify-center text-[#f7931a] shadow-md group-hover:border-[#f7931a] transition-all">
              {/* Custom ₿-inspired Geometry */}
              <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                <path d="M16 11.5C16.8 10.7 17.3 9.6 17.3 8.3C17.3 5.9 15.3 4 12.9 4H7V20H13.6C16 20 18 18 18 15.6C18 13.8 17.2 12.3 16 11.5ZM9.5 6.5H12.5C13.5 6.5 14.3 7.3 14.3 8.3C14.3 9.3 13.5 10.1 12.5 10.1H9.5V6.5ZM13.2 17.5H9.5V12.6H13.2C14.3 12.6 15.1 13.4 15.1 14.5C15.1 15.6 14.3 17.5 13.2 17.5Z" />
              </svg>
            </div>
            <div>
              <div className="font-brand font-bold text-lg tracking-wider text-zinc-100 group-hover:text-[#f7931a] transition-colors flex items-center gap-1.5">
                <span>BTC PHILOSOPHER</span>
              </div>
              <div className="text-[10px] text-zinc-500 font-mono tracking-widest uppercase">
                Intellectual Forum
              </div>
            </div>
          </button>

          {/* Nav items */}
          <nav className="hidden lg:flex items-center space-x-1 text-xs font-medium">
            {[
              { id: 'home', label: 'DISCUSS' },
              { id: 'discover', label: 'EXPLORE' },
              { id: 'knowledge', label: 'KNOWLEDGE' },
              { id: 'essays', label: 'ESSAYS' },
              { id: 'markets', label: 'MARKETS' },
              { id: 'graph', label: 'GRAPH' },
              { id: 'dashboard', label: 'INTELLIGENCE' },
            ].map((nav) => (
              <button
                key={nav.id}
                onClick={() => onNavigate(nav.id)}
                className={`px-3 py-1.5 rounded-md transition-all ${
                  activeView === nav.id
                    ? 'bg-[#f7931a]/15 text-[#f7931a] font-semibold border border-[#f7931a]/30'
                    : 'text-zinc-300 hover:text-zinc-100 hover:bg-zinc-800/70'
                }`}
              >
                {nav.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Search Bar & Actions */}
        <div className="flex items-center space-x-3">
          {/* Quick Compact Search */}
          <div className="relative w-48 sm:w-64">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-zinc-500" />
            <input
              type="text"
              placeholder="Search claims, threads, sources..."
              value={searchQuery}
              onChange={handleSearchChange}
              className="w-full bg-[#14171d] border border-[#272a30] rounded-lg pl-9 pr-3 py-1.5 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-[#f7931a] transition-colors font-sans"
            />
          </div>

          {/* New Thread CTA */}
          <button
            onClick={() => onNavigate('create')}
            className="flex items-center space-x-1.5 bg-[#f7931a] hover:bg-[#e08213] text-black font-semibold text-xs px-3 py-1.5 rounded-lg transition-colors shadow-sm"
          >
            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
            <span className="hidden sm:inline">New Thread</span>
          </button>

          {/* Notifications Bell */}
          <div className="relative">
            <button
              onClick={() => setShowNotifs(!showNotifs)}
              className="p-2 rounded-lg bg-[#14171d] border border-[#272a30] text-zinc-300 hover:text-zinc-100 hover:border-zinc-700 relative"
            >
              <Bell className="w-4 h-4" />
              {unreadNotifs > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#f7931a] text-black text-[10px] font-bold flex items-center justify-center">
                  {unreadNotifs}
                </span>
              )}
            </button>

            {/* Notification Dropdown */}
            {showNotifs && (
              <div className="absolute right-0 mt-2 w-80 bg-[#121418] border border-[#272a30] rounded-xl shadow-2xl p-3 z-50 animate-in fade-in slide-in-from-top-2">
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#272a30]">
                  <h4 className="text-xs font-semibold text-zinc-200">Notifications</h4>
                  <span className="text-[10px] text-zinc-500">{notifications.length} total</span>
                </div>
                <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                  {notifications.length === 0 ? (
                    <div className="text-xs text-zinc-500 text-center py-4">No notifications</div>
                  ) : (
                    notifications.map((n) => (
                      <div
                        key={n.id}
                        onClick={() => {
                          store.markNotificationRead(n.id);
                          setShowNotifs(false);
                          onNavigate('home');
                        }}
                        className={`p-2 rounded-lg text-xs cursor-pointer border transition-colors ${
                          n.isRead
                            ? 'bg-[#14171d]/50 border-transparent text-zinc-400'
                            : 'bg-[#181b20] border-[#f7931a]/30 text-zinc-200'
                        }`}
                      >
                        <div className="font-semibold text-[#f7931a] text-[11px] mb-0.5">{n.title}</div>
                        <p className="text-zinc-300 text-[11px] leading-snug">{n.message}</p>
                        <span className="text-[9px] text-zinc-500 mt-1 block">{n.createdAt}</span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* User Profile Menu */}
          <div className="relative">
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center space-x-2 p-1 pr-2 rounded-lg bg-[#14171d] border border-[#272a30] hover:border-zinc-700 transition-colors"
            >
              <img
                src={currentUser.avatarUrl}
                alt={currentUser.displayName}
                className="w-7 h-7 rounded-md object-cover border border-[#f7931a]/50"
              />
              <div className="hidden sm:block text-left">
                <div className="text-xs font-semibold text-zinc-200 leading-none">
                  {currentUser.displayName}
                </div>
                <div className="text-[10px] text-[#f7931a] font-mono leading-tight mt-0.5">
                  {currentUser.reputation} rep
                </div>
              </div>
              <ChevronDown className="w-3 h-3 text-zinc-500" />
            </button>

            {/* Profile Dropdown */}
            {showUserMenu && (
              <div className="absolute right-0 mt-2 w-56 bg-[#121418] border border-[#272a30] rounded-xl shadow-2xl p-2 z-50">
                <div className="p-2 border-b border-[#272a30] mb-1">
                  <div className="text-xs font-bold text-zinc-100">{currentUser.displayName}</div>
                  <div className="text-[10px] text-zinc-400 font-mono">@{currentUser.username} • {currentUser.role}</div>
                </div>
                <button
                  onClick={() => {
                    setShowUserMenu(false);
                    onNavigate('profile', currentUser.id);
                  }}
                  className="w-full text-left px-3 py-1.5 text-xs text-zinc-300 hover:text-zinc-100 hover:bg-zinc-800 rounded-lg flex items-center space-x-2"
                >
                  <UserIcon className="w-3.5 h-3.5 text-zinc-400" />
                  <span>My Profile & Ledger</span>
                </button>
                <button
                  onClick={() => {
                    setShowUserMenu(false);
                    onNavigate('admin');
                  }}
                  className="w-full text-left px-3 py-1.5 text-xs text-zinc-300 hover:text-zinc-100 hover:bg-zinc-800 rounded-lg flex items-center space-x-2"
                >
                  <Shield className="w-3.5 h-3.5 text-zinc-400" />
                  <span>Moderation & Audit</span>
                </button>
                <div className="border-t border-[#272a30] my-1 pt-1">
                  <div className="px-3 py-1 text-[10px] text-zinc-500 font-semibold uppercase">Switch User Persona</div>
                  {Object.values(MOCK_USERS).map((usr) => (
                    <button
                      key={usr.id}
                      onClick={() => {
                        store.setCurrentUser(usr.id);
                        setShowUserMenu(false);
                      }}
                      className={`w-full text-left px-3 py-1 text-xs rounded-md flex items-center justify-between ${
                        usr.id === currentUser.id ? 'text-[#f7931a] font-medium' : 'text-zinc-400 hover:bg-zinc-800'
                      }`}
                    >
                      <span>{usr.displayName}</span>
                      <span className="text-[9px] font-mono text-zinc-500">{usr.role}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
