'use client';

import React from 'react';
import { useAppStore } from '@/lib/store';
import { Bookmark, Folder, Lock, Globe } from 'lucide-react';
import { ThreadCard } from './ThreadCard';

interface BookmarksViewProps {
  onNavigate: (view: string, id?: string) => void;
}

export const BookmarksView: React.FC<BookmarksViewProps> = ({ onNavigate }) => {
  const { bookmarkCollections, threads } = useAppStore();

  const bookmarkedThreads = threads.filter((t) =>
    bookmarkCollections.some((c) => c.threadIds.includes(t.id))
  );

  return (
    <div className="max-w-5xl mx-auto py-4 space-y-6">
      <div className="border-b border-[#272a30] pb-4">
        <h1 className="text-xl font-extrabold text-zinc-100 flex items-center space-x-2">
          <Bookmark className="w-5 h-5 text-[#f7931a] fill-current" />
          <span>BOOKMARKS & RESEARCH COLLECTIONS</span>
        </h1>
        <p className="text-xs text-zinc-400 mt-0.5">
          Curated lists of saved threads, posts, and primary sources for long-term inquiry.
        </p>
      </div>

      {/* Collections header */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {bookmarkCollections.map((col) => (
          <div key={col.id} className="p-4 bg-[#121418] border border-[#272a30] rounded-xl space-y-2">
            <div className="flex items-center justify-between font-bold text-sm text-zinc-200">
              <span className="flex items-center space-x-2">
                <Folder className="w-4 h-4 text-[#f7931a]" />
                <span>{col.name}</span>
              </span>
              <span className="text-xs text-zinc-500 font-mono flex items-center space-x-1">
                {col.isPrivate ? <Lock className="w-3 h-3" /> : <Globe className="w-3 h-3" />}
                <span>{col.isPrivate ? 'Private' : 'Public'}</span>
              </span>
            </div>
            <div className="text-xs text-zinc-400 font-mono">
              {col.threadIds.length} Threads Saved
            </div>
          </div>
        ))}
      </div>

      {/* Stream of saved items */}
      <div className="space-y-4">
        <h3 className="text-xs font-mono font-bold text-zinc-400 uppercase">SAVED THREADS ({bookmarkedThreads.length})</h3>
        {bookmarkedThreads.length === 0 ? (
          <div className="py-8 text-center text-xs text-zinc-500">No bookmarked threads yet.</div>
        ) : (
          bookmarkedThreads.map((thread) => (
            <ThreadCard key={thread.id} thread={thread} onNavigate={onNavigate} />
          ))
        )}
      </div>
    </div>
  );
};
