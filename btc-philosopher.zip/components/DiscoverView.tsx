'use client';

import React, { useState } from 'react';
import { useAppStore } from '@/lib/store';
import { Compass, Sparkles, Flame, BookOpen, Clock, HelpCircle, UserCheck, Info } from 'lucide-react';
import { ThreadCard } from './ThreadCard';

interface DiscoverViewProps {
  onNavigate: (view: string, id?: string) => void;
}

export const DiscoverView: React.FC<DiscoverViewProps> = ({ onNavigate }) => {
  const { threads } = useAppStore();
  const [activeFeed, setActiveFeed] = useState<'LATEST' | 'DISCOVER' | 'DEEP' | 'EXPERT' | 'RISING' | 'UNANSWERED'>('DISCOVER');

  const getFilteredThreads = () => {
    switch (activeFeed) {
      case 'LATEST':
        return [...threads].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      case 'DEEP':
        return threads.filter((t) => t.type === 'ESSAY' || t.posts[0]?.content.length > 500);
      case 'EXPERT':
        return threads.filter((t) => t.author.reputation > 500);
      case 'RISING':
        return [...threads].sort((a, b) => b.repliesCount + b.citationsCount * 2 - (a.repliesCount + a.citationsCount * 2));
      case 'UNANSWERED':
        return threads.filter((t) => t.repliesCount === 0 || t.type === 'QUESTION');
      default:
        // DISCOVER (Relevance balanced)
        return threads;
    }
  };

  const getFeedExplanation = () => {
    switch (activeFeed) {
      case 'LATEST':
        return 'Strict chronological feed ordered purely by timestamp. No recommendation algorithms applied.';
      case 'DISCOVER':
        return 'Personalized intellectual feed scoring citations density, Austrian monetary economics tags, and peer reputation weights.';
      case 'DEEP':
        return 'Filtered long-form technical essays, mathematical proofs, and comprehensive whitepaper analyses.';
      case 'EXPERT':
        return 'Threads authored exclusively by users holding 500+ derived reputation and category expertise.';
      case 'RISING':
        return 'High-velocity threads gaining rapid citations and peer reactions over the past 48 hours.';
      case 'UNANSWERED':
        return 'Open inquiries and technical questions requiring primary literature citations or consensus responses.';
    }
  };

  const filteredThreads = getFilteredThreads();

  return (
    <div className="max-w-5xl mx-auto py-4 space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#272a30] pb-4">
        <div>
          <h1 className="text-xl font-extrabold text-zinc-100 flex items-center space-x-2">
            <Compass className="w-5 h-5 text-[#f7931a]" />
            <span>EXPLORE & DISCOVER FEEDS</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Transparent feeds with explicit algorithmic explanations and decay controls.
          </p>
        </div>

        {/* Feed Selector Buttons */}
        <div className="flex flex-wrap gap-1 bg-[#121418] p-1 rounded-xl border border-[#272a30] text-xs">
          {[
            { id: 'DISCOVER', label: 'DISCOVER', icon: Sparkles },
            { id: 'LATEST', label: 'LATEST', icon: Clock },
            { id: 'DEEP', label: 'DEEP ESSAYS', icon: BookOpen },
            { id: 'EXPERT', label: 'EXPERT ONLY', icon: UserCheck },
            { id: 'RISING', label: 'RISING', icon: Flame },
            { id: 'UNANSWERED', label: 'UNANSWERED', icon: HelpCircle },
          ].map((feed) => {
            const Icon = feed.icon;
            const isSelected = activeFeed === feed.id;
            return (
              <button
                key={feed.id}
                onClick={() => setActiveFeed(feed.id as any)}
                className={`px-3 py-1.5 rounded-lg font-medium transition-all flex items-center space-x-1.5 ${
                  isSelected
                    ? 'bg-[#f7931a] text-black font-bold shadow-md'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#181b20]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{feed.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Transparent Algorithmic Explanation Box */}
      <div className="p-3 bg-[#121418] border border-[#272a30] rounded-xl text-xs text-zinc-300 flex items-start space-x-2.5">
        <Info className="w-4 h-4 text-[#f7931a] shrink-0 mt-0.5" />
        <div>
          <span className="font-bold text-zinc-100 font-mono mr-2">FEED ALGORITHM EXPLANATION:</span>
          <span className="text-zinc-400">{getFeedExplanation()}</span>
        </div>
      </div>

      {/* Stream */}
      <div className="space-y-4">
        {filteredThreads.map((thread) => (
          <ThreadCard key={thread.id} thread={thread} onNavigate={onNavigate} />
        ))}
      </div>
    </div>
  );
};
