# BTC PHILOSOPHER PRIVATE - THREAT MODEL

## PHASE 2: SECURITY EVALUATION MATRIX (GEMINI 3.6 SPECIFICATION #73)

BTC Philosopher Private is designed under a **Zero-Trust Server Architecture**. The central server is treated strictly as an untrusted, high-availability router of encrypted envelopes. This threat model identifies the critical system threat vectors, maps their corresponding attack paths, defines the cryptographic mitigations, assesses the residual risk, and provides deterministic verification tests implemented within our on-device test suites.

---

### THREAT 1: Central Server Compromise / Malicious Administrator
*   **Attack Path:** An adversary gains root access to the central routing server or is an internal malicious administrator. They tap the active message routing database and socket queues.
*   **Operational Impact:** Exposure of metadata (sender IDs, recipient device IDs, delivery timestamps).
*   **Cryptographic Mitigation:** **PQXDH + Double Ratchet**. All message payloads are encrypted end-to-end on-device before being transmitted as a blind ciphertext envelope. The server possesses no identity key material, prekeys, or session ratchet keys.
*   **Residual Risk:** Metadata traffic analysis remains a theoretical risk. This is mitigated by ephemeral routing identifiers that do not tie to Bitcoin addresses or permanent on-device keys.
*   **Verification Test:** **SECURITY PANEL - ATTACKER MESSAGE QUEUE ACCESS (FAIL)**. Assert that raw WebSocket stream captures reveal only opaque base64 ciphertext and ephemeral ratchet headers.

---

### THREAT 2: Physical Device Theft / Raw Database Dump
*   **Attack Path:** An attacker physically steals the user’s Android device and executes a physical memory dump, pulling the raw SQLite database bytes (`btc_philosopher_private_secure.db`) from the application folder.
*   **Operational Impact:** Potential exposure of local message history and identity key files.
*   **Cryptographic Mitigation:** **Encrypted SQLite Room State**. Data stored on-device is protected via the Android Keystore system. Raw database contents are unreadable without the runtime hardware-backed encryption key.
*   **Residual Risk:** Rooted devices with modified bootloaders could theoretically attempt RAM extraction, which is blocked by standard Android OS isolation barriers.
*   **Verification Test:** **SECURITY PANEL - ATTACKER DATABASE DUMP (FAIL)**. Assert that querying raw SQLite message bodies outputs only AES-GCM encrypted blocks and reveals ZERO plaintext bytes.

---

### THREAT 3: Active Message Queue Spoofing / Replay Attack
*   **Attack Path:** An active Man-In-The-Middle (MITM) captures valid encrypted envelopes in transit and re-injects them into the WebSocket queue to induce replay or force state desynchronization.
*   **Operational Impact:** Attempted message replay or session ratchet desynchronization.
*   **Cryptographic Mitigation:** **Authenticated Associated Data (AAD)**. The GCM authenticated tag covers immutable metadata fields: `auth_version=3.6;sender=$senderId;conv=$conversationId;epoch=$epoch`. Envelopes with mismatched headers or duplicate ratchet sequences are rejected by the client state machine immediately.
*   **Residual Risk:** Minimal. The sequence numbers inside the double ratchet chains prevent replay attacks deterministically.
*   **Verification Test:** Handled by the Room message validation layer which enforces monotonic epoch sequences and rejects stale ratchet headers.

---

### THREAT 4: Post-Departure Group Exposure (Removed Circle Member)
*   **Attack Path:** A participant is removed from an intellectual Circle (Salon) or a secure media call session, but retains their historic session keys and attempts to decrypt future correspondence or voice feeds.
*   **Operational Impact:** Unauthorized disclosure of future communications.
*   **Cryptographic Mitigation:** **Immediate Ephemeral Key Rotation & Epoch Advance**. Upon participant departure, active hosts rotate the session keys and increment the WebRTC media call epoch. The new key is negotiated exclusively among remaining verified devices.
*   **Residual Risk:** Historic conversations up to the departure point remain readable by design (perfect forward secrecy applies forward, not retroactively).
*   **Verification Test:** **SECURITY PANEL - REMOVED GROUP MEMBER DECRYPTION (FAIL)**. Assert that Daniel's post-removal decryption attempts of Call Epoch 2 fail with signature integrity rejection.

---

### THREAT 5: Rogue / Compromised Secondary Device
*   **Attack Path:** An older verified secondary device (e.g., an iPhone 15 Pro) is compromised or lost. The adversary attempts to negotiate new ratchet sessions using the stale credentials.
*   **Operational Impact:** Potential man-in-the-middle impersonation or unauthorized session sniffing.
*   **Cryptographic Mitigation:** **Remote Secure Device Revocation**. The user executes an immediate device status change to `REVOKED` in their local database. This triggers an immediate local key rotation for all direct and salon sessions, invalidating active prekey bundles for that device.
*   **Residual Risk:** Minimal, assuming the user triggers the revocation promptly.
*   **Verification Test:** **SECURITY PANEL - REVOKED DEVICE SESSION ATTEMPT (FAIL)**. Assert that incoming session handshakes from the revoked device ID are instantly blocked by the client's local identity registry.

---

### THREAT 6: Identity Key Tampering (Man-In-The-Middle)
*   **Attack Path:** A compromised routing server replaces Maya's identity key bundle on the public registry with an attacker-controlled key bundle to intercept future communications.
*   **Operational Impact:** Total session exposure if communication is silently completed with the forged key.
*   **Cryptographic Mitigation:** **Asymmetric Verification Warning**. Stored fingerprints are pinned in the local SQLite. If an incoming prekey bundle features a different identity key, communication is halted instantly and a prominent warning blocks further message processing.
*   **Residual Risk:** Ignored warnings by the user. Mitigated by restricting communication until the user explicitly accepts or verifies the new fingerprint out-of-band.
*   **Verification Test:** **SECURITY PANEL - KEY CHANGE WARNING (WARNING)**. Assert that signature mismatch halts transmission and prompts warning.

---

### THREAT 7: Cloud Binary Storage Compromise (Attachment Leak)
*   **Attack Path:** An attacker compromises the cloud-hosted blob storage (e.g., AWS S3 or Google Cloud Storage) containing the encrypted research papers (e.g., `hayek_coordination.pdf`).
*   **Operational Impact:** Unauthorized file access.
*   **Cryptographic Mitigation:** **Out-of-band Symmetric File Key Sharing**. Files are encrypted with an ephemeral AES-256 key *before* upload. The key and the SHA-256 integrity hash are shared exclusively over the E2EE chat channel. The cloud host receives only raw ciphertext.
*   **Residual Risk:** None for file confidentiality.
*   **Verification Test:** **SECURITY PANEL - ATTACKER ATTACHMENT STORAGE ACCESS (FAIL)**. Assert that binary chunks pulled from the server are un-decryptable without the local ephemeral key, and that file integrity hashes match perfectly upon decryption.
