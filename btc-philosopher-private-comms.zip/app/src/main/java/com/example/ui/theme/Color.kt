package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// BTC Philosopher Private Cryptographic Editorial Palette
val NearBlack = Color(0xFF0E1013)      // Main background
val DeepGraphite = Color(0xFF16181C)   // Secondary background / Surface
val LightGraphite = Color(0xFF23272D)  // Muted panels / Card borders
val WarmWhite = Color(0xFFFAF8F5)      // Elegant primary text / Light background
val MutedGrey = Color(0xFF8E929A)      // Small metadata / Secondary labels
val BitcoinOrange = Color(0xFFF7931A)  // Accents / High importance actions
val DeepAmber = Color(0xFFD97706)      // Security alerts / Critical warnings
val RestrainedBlue = Color(0xFF3B82F6) // Connections / Signal indicators
val SubtleGreen = Color(0xFF10B981)    // Verified badges / Active calls
val SubtleRed = Color(0xFFEF4444)      // Revoked / Blocked devices
