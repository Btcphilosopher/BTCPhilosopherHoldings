package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MainViewModel
import com.example.database.*
import com.example.ui.theme.*

@Composable
fun DeskTerminalScreen(viewModel: MainViewModel) {
    val currentScreen by viewModel.currentScreen
    val activeConversationId = viewModel.activeConversationId.value
    val isCallActive by viewModel.isCallActive

    // Responsive dual-pane layout
    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(NearBlack)
    ) {
        // Left Column: Navigation Sidebar
        Box(
            modifier = Modifier
                .width(280.dp)
                .fillMaxHeight()
                .border(1.dp, LightGraphite)
                .background(NearBlack)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Cryptographic Terminal Header
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "BTC PHILOSOPHER",
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = BitcoinOrange,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "P R I V A T E",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Light,
                        fontSize = 11.sp,
                        color = MutedGrey,
                        letterSpacing = 4.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "SECURE INTELLECTUAL COMMUNICATIONS",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Medium,
                        fontSize = 8.sp,
                        color = RestrainedBlue,
                        letterSpacing = 0.5.sp
                    )
                }

                Divider(color = LightGraphite, thickness = 1.dp)

                // Navigation Items
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    item {
                        NavHeaderLabel("COMMUNICATIONS")
                    }
                    item {
                        NavItem(
                            label = "Inbox (Conversations)",
                            icon = Icons.Outlined.Mail,
                            isActive = currentScreen == "INBOX",
                            tag = "nav_inbox",
                            onClick = { viewModel.currentScreen.value = "INBOX" }
                        )
                    }
                    item {
                        NavItem(
                            label = "Calls",
                            icon = Icons.Outlined.Call,
                            isActive = currentScreen == "CALLS",
                            tag = "nav_calls",
                            onClick = { viewModel.currentScreen.value = "CALLS" }
                        )
                    }
                    item {
                        NavItem(
                            label = "Circles (Salons)",
                            icon = Icons.Outlined.Group,
                            isActive = currentScreen == "CIRCLES",
                            tag = "nav_circles",
                            onClick = { viewModel.currentScreen.value = "CIRCLES" }
                        )
                    }
                    item {
                        NavItem(
                            label = "People (Verified Contacts)",
                            icon = Icons.Outlined.VerifiedUser,
                            isActive = currentScreen == "PEOPLE",
                            tag = "nav_people",
                            onClick = { viewModel.currentScreen.value = "PEOPLE" }
                        )
                    }

                    item {
                        Spacer(modifier = Modifier.height(16.dp))
                        NavHeaderLabel("SCHOLAR'S WORKSPACE")
                    }
                    item {
                        NavItem(
                            label = "Private Library",
                            icon = Icons.Outlined.Book,
                            isActive = currentScreen == "LIBRARY",
                            tag = "nav_library",
                            onClick = { viewModel.currentScreen.value = "LIBRARY" }
                        )
                    }
                    item {
                        NavItem(
                            label = "Private Notes Layer",
                            icon = Icons.Outlined.EditNote,
                            isActive = currentScreen == "PRIVATE_NOTES",
                            tag = "nav_private_notes",
                            onClick = { viewModel.currentScreen.value = "PRIVATE_NOTES" }
                        )
                    }

                    item {
                        Spacer(modifier = Modifier.height(16.dp))
                        NavHeaderLabel("SECURITY & OPERATIONS")
                    }
                    item {
                        NavItem(
                            label = "Audit Trails",
                            icon = Icons.Outlined.History,
                            isActive = currentScreen == "AUDIT",
                            tag = "nav_audit",
                            onClick = { viewModel.currentScreen.value = "AUDIT" }
                        )
                    }
                    item {
                        NavItem(
                            label = "Master Demonstration",
                            icon = Icons.Outlined.PlayCircle,
                            isActive = currentScreen == "MASTER_DEMO",
                            tag = "nav_master_demo",
                            onClick = { viewModel.currentScreen.value = "MASTER_DEMO" }
                        )
                    }
                    item {
                        NavItem(
                            label = "Security Panel",
                            icon = Icons.Outlined.Shield,
                            isActive = currentScreen == "SECURITY",
                            tag = "nav_security",
                            onClick = { viewModel.currentScreen.value = "SECURITY" }
                        )
                    }
                }

                // Bottom Local Identity Badge
                Divider(color = LightGraphite, thickness = 1.dp)
                LocalIdentityCard(viewModel)
            }
        }

        // Center Panel: Content Area
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .background(NearBlack)
        ) {
            when (currentScreen) {
                "INBOX" -> ConversationView(viewModel)
                "CALLS" -> CallsView(viewModel)
                "PEOPLE" -> PeopleView(viewModel)
                "CIRCLES" -> CirclesView(viewModel)
                "LIBRARY" -> LibraryView(viewModel)
                "PRIVATE_NOTES" -> PrivateNotesView(viewModel)
                "AUDIT" -> AuditLogView(viewModel)
                "MASTER_DEMO" -> MasterDemoView(viewModel)
                "SECURITY" -> SecurityPanelResponseView(viewModel)
            }

            // Overlay for active call
            if (isCallActive) {
                ActiveCallOverlay(viewModel)
            }
        }
    }
}

@Composable
fun NavHeaderLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelMedium,
        color = MutedGrey,
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
    )
}

@Composable
fun NavItem(
    label: String,
    icon: ImageVector,
    isActive: Boolean,
    tag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(if (isActive) LightGraphite else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isActive) BitcoinOrange else MutedGrey,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = label,
            fontFamily = FontFamily.SansSerif,
            fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Normal,
            fontSize = 13.sp,
            color = if (isActive) WarmWhite else MutedGrey,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun LocalIdentityCard(viewModel: MainViewModel) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(LightGraphite)
                .border(1.dp, BitcoinOrange, RoundedCornerShape(4.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "A",
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = BitcoinOrange
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "ALEXANDER",
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = WarmWhite
            )
            Text(
                text = "@alexander",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = MutedGrey
            )
        }
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(2.dp))
                .background(Color(0xFF10B981).copy(alpha = 0.15f))
                .border(1.dp, SubtleGreen, RoundedCornerShape(2.dp))
                .padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
            Text(
                text = "VERIFIED",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 8.sp,
                color = SubtleGreen
            )
        }
    }
}

@Composable
fun ConversationView(viewModel: MainViewModel) {
    val conversations by viewModel.allConversations.collectAsState(initial = emptyList())
    val activeChatId = viewModel.activeConversationId.value
    val activeChatMessages by viewModel.activeChatMessages.collectAsState()
    val inputText by viewModel.inputMessageText

    Row(modifier = Modifier.fillMaxSize()) {
        // Recent conversations sidebar
        Box(
            modifier = Modifier
                .width(260.dp)
                .fillMaxHeight()
                .border(1.dp, LightGraphite)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "RECENT CORRESPONDENCE",
                        style = MaterialTheme.typography.labelLarge,
                        color = MutedGrey
                    )
                }
                Divider(color = LightGraphite, thickness = 1.dp)

                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(conversations) { conv ->
                        val isSelected = activeChatId == conv.conversationId
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.selectConversation(conv.conversationId) }
                                .background(if (isSelected) DeepGraphite else Color.Transparent)
                                .border(
                                    width = if (isSelected) 1.dp else 0.dp,
                                    color = if (isSelected) LightGraphite else Color.Transparent
                                )
                                .padding(16.dp)
                                .testTag("conversation_row_${conv.conversationId}"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = conv.name.uppercase(),
                                    fontFamily = FontFamily.SansSerif,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (isSelected) BitcoinOrange else WarmWhite
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (conv.type == "CIRCLE") "CIRCLE SALON" else "ENCRYPTED SESSION",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp,
                                    color = MutedGrey
                                )
                            }
                            if (conv.type == "CIRCLE") {
                                Icon(
                                    imageVector = Icons.Default.Groups,
                                    contentDescription = "Circle",
                                    tint = MutedGrey,
                                    modifier = Modifier.size(16.dp)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = "Direct",
                                    tint = SubtleGreen,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        Divider(color = LightGraphite.copy(alpha = 0.5f), thickness = 1.dp)
                    }
                }
            }
        }

        // Active conversation panel
        if (activeChatId != null) {
            val title = conversations.find { it.conversationId == activeChatId }?.name ?: "Correspondence"

            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                // Session Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = title.uppercase(),
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = WarmWhite
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(SubtleGreen)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "PQXDH + DOUBLE RATCHET RATIO SECURE",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                color = SubtleGreen,
                                letterSpacing = 1.sp
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(
                            onClick = { viewModel.startSecureCall("VOICE", title) },
                            modifier = Modifier.testTag("action_voice_call")
                        ) {
                            Icon(Icons.Default.Call, "Voice Call", tint = BitcoinOrange)
                        }
                        IconButton(
                            onClick = { viewModel.startSecureCall("VIDEO", title) },
                            modifier = Modifier.testTag("action_video_call")
                        ) {
                            Icon(Icons.Default.Videocam, "Video Call", tint = BitcoinOrange)
                        }
                    }
                }

                Divider(color = LightGraphite, thickness = 1.dp)

                // Message Flow Container
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    items(activeChatMessages) { msg ->
                        MessageItem(msg)
                    }
                }

                // Inner Local Private Scholar Notes
                val activeNotes by viewModel.activePrivateNotes.collectAsState()
                if (activeNotes.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                            .background(DeepGraphite)
                            .border(1.dp, DeepAmber.copy(alpha = 0.5f))
                            .padding(12.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.EditNote,
                                        "Private Note",
                                        tint = DeepAmber,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "LOCAL THINKING LAYER (VISIBLE ONLY TO YOU)",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 9.sp,
                                        color = DeepAmber,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    text = "SHRED ON LOGOUT",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 8.sp,
                                    color = MutedGrey
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            LazyColumn(modifier = Modifier.heightIn(max = 120.dp)) {
                                items(activeNotes) { note ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "• \"${note.content}\"",
                                            fontFamily = FontFamily.Serif,
                                            fontSize = 13.sp,
                                            color = WarmWhite,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Icon(
                                            Icons.Default.DeleteOutline,
                                            "Delete Note",
                                            tint = MutedGrey,
                                            modifier = Modifier
                                                .size(16.dp)
                                                .clickable { viewModel.deletePrivateNote(note.noteId) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Bottom Composer Section
                Divider(color = LightGraphite, thickness = 1.dp)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.encryptAndAttachFile("marginal_utility_notes.pdf", "Subjective marginal utility research details.") },
                        modifier = Modifier.testTag("attach_file_btn")
                    ) {
                        Icon(Icons.Default.AttachFile, "Attach File", tint = MutedGrey)
                    }

                    IconButton(
                        onClick = { viewModel.sendVoiceNote(42) },
                        modifier = Modifier.testTag("voice_note_btn")
                    ) {
                        Icon(Icons.Default.Mic, "Voice Note", tint = MutedGrey)
                    }

                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { viewModel.inputMessageText.value = it },
                        placeholder = { Text("Write private message...", color = MutedGrey) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = WarmWhite,
                            unfocusedTextColor = WarmWhite,
                            focusedContainerColor = DeepGraphite,
                            unfocusedContainerColor = DeepGraphite,
                            focusedBorderColor = BitcoinOrange,
                            unfocusedBorderColor = LightGraphite
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 8.dp)
                            .testTag("composer_text_field"),
                        maxLines = 4,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = {
                            viewModel.sendMessage(inputText, activeChatId)
                        })
                    )

                    IconButton(
                        onClick = {
                            if (inputText.isNotBlank()) {
                                viewModel.addPrivateNote(inputText, activeChatId)
                            }
                        },
                        modifier = Modifier.testTag("add_private_note_btn")
                    ) {
                        Icon(Icons.Default.Lock, "Add Private Note", tint = DeepAmber)
                    }

                    IconButton(
                        onClick = { viewModel.sendMessage(inputText, activeChatId) },
                        modifier = Modifier.testTag("send_msg_btn")
                    ) {
                        Icon(Icons.Default.Send, "Send", tint = BitcoinOrange)
                    }
                }
            }
        } else {
            // Empty State desk visual
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.Drafts,
                        "Drafts",
                        tint = LightGraphite,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "THE COMMUNICATIONS SYSTEM SHOULD KNOW AS LITTLE AS POSSIBLE.",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = MutedGrey,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Select recent correspondence to load encrypted ratchets.",
                        fontFamily = FontFamily.Serif,
                        fontSize = 13.sp,
                        color = MutedGrey
                    )
                }
            }
        }
    }
}

@Composable
fun MessageItem(msg: MessageEnvelopeEntity) {
    var showEnvelopeDetails by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clickable { showEnvelopeDetails = !showEnvelopeDetails }
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = msg.senderId.uppercase(),
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = if (msg.senderId == "alexander") BitcoinOrange else RestrainedBlue
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "EPOCH 1 • ENVELOPE SECURE",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = SubtleGreen
                )
            }
            Text(
                text = "12:24",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = MutedGrey
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = msg.plaintextBody,
            fontFamily = FontFamily.Serif,
            fontSize = 15.sp,
            color = WarmWhite,
            lineHeight = 22.sp
        )

        AnimatedVisibility(visible = showEnvelopeDetails) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
                    .background(NearBlack)
                    .border(1.dp, LightGraphite)
                    .padding(8.dp)
            ) {
                Column {
                    Text(
                        text = "CANONICAL CIPHERTEXT ENVELOPE (SERVER-SIDE VIEW)",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = BitcoinOrange
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    EnvelopeMetadataField("MessageId", msg.messageId)
                    EnvelopeMetadataField("Ciphertext", msg.ciphertext.take(45) + "...")
                    EnvelopeMetadataField("RatchetHeader", msg.ratchetHeader)
                    EnvelopeMetadataField("AssociatedData", msg.associatedData)
                    EnvelopeMetadataField("ProtocolVersion", msg.protocolVersion.toString())
                    EnvelopeMetadataField("ServerDecryptionState", "FAIL (No Master Key by Design)")
                }
            }
        }
    }
}

@Composable
fun EnvelopeMetadataField(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    ) {
        Text(
            text = "$label: ",
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            color = MutedGrey,
            modifier = Modifier.width(110.dp)
        )
        Text(
            text = value,
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            color = WarmWhite,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun CallsView(viewModel: MainViewModel) {
    val callHistory by viewModel.allCalls.collectAsState(initial = emptyList())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Text(
            text = "SECURE TELEPHONE EXCHANGE",
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            fontSize = 24.sp,
            color = WarmWhite
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Asymmetric post-quantum ratcheted WebRTC calls. Calls route ciphertext; server possesses no media keys.",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = MutedGrey
        )

        Spacer(modifier = Modifier.height(24.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = DeepGraphite),
            border = BorderStroke(1.dp, LightGraphite),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "INITIATE SECURE CORRESPONDENCE CALL",
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = BitcoinOrange
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(
                        onClick = { viewModel.startSecureCall("VOICE", "Maya") },
                        colors = ButtonDefaults.buttonColors(containerColor = LightGraphite),
                        modifier = Modifier.testTag("init_voice_call_btn")
                    ) {
                        Icon(Icons.Default.Call, "Voice", tint = BitcoinOrange)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("SECURE VOICE CALL", color = WarmWhite)
                    }
                    Button(
                        onClick = { viewModel.startSecureCall("VIDEO", "Maya") },
                        colors = ButtonDefaults.buttonColors(containerColor = LightGraphite),
                        modifier = Modifier.testTag("init_video_call_btn")
                    ) {
                        Icon(Icons.Default.Videocam, "Video", tint = BitcoinOrange)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("SECURE VIDEO CALL", color = WarmWhite)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "CALL LOGS ARCHIVE",
            style = MaterialTheme.typography.labelLarge,
            color = MutedGrey
        )
        Spacer(modifier = Modifier.height(8.dp))

        if (callHistory.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .border(1.dp, LightGraphite)
                    .background(DeepGraphite),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No completed secure call logs available locally.",
                    fontFamily = FontFamily.Serif,
                    fontSize = 13.sp,
                    color = MutedGrey
                )
            }
        } else {
            LazyColumn {
                items(callHistory) { call ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, LightGraphite)
                            .background(DeepGraphite)
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "CALL WITH ${call.participantSet.uppercase()}",
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = WarmWhite
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "EPOCHS COMPLETED: ${call.finalEpoch} • SECURE METRIC COMPLETED",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                color = SubtleGreen
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${call.durationSeconds}s",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 14.sp,
                                color = BitcoinOrange
                            )
                            Text(
                                text = call.callType + " SESSION",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 8.sp,
                                color = MutedGrey
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }
    }
}

@Composable
fun ActiveCallOverlay(viewModel: MainViewModel) {
    val callType by viewModel.activeCallType
    val contactName by viewModel.activeCallContact
    val callState by viewModel.activeCallState
    val callEpoch by viewModel.callEpoch
    val callParticipants = viewModel.callParticipants
    val mediaKey by viewModel.callMediaKey
    val audioMuted by viewModel.audioMuted
    val videoEnabled by viewModel.videoEnabled

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NearBlack.copy(alpha = 0.95f))
            .border(2.dp, BitcoinOrange)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 550.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = if (callType == "VOICE") Icons.Default.Call else Icons.Default.Videocam,
                contentDescription = "Active Call",
                tint = BitcoinOrange,
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "SECURE ${callType.uppercase()} EXCHANGE SESSION",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = BitcoinOrange,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "CONVERSATION: $contactName",
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp,
                color = WarmWhite
            )

            Spacer(modifier = Modifier.height(16.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = DeepGraphite),
                border = BorderStroke(1.dp, LightGraphite),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SECURITY STATUS",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = MutedGrey
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(if (callState == "CONNECTED" || callState == "SECURE") SubtleGreen.copy(alpha = 0.15f) else DeepAmber.copy(alpha = 0.15f))
                                .border(1.dp, if (callState == "CONNECTED" || callState == "SECURE") SubtleGreen else DeepAmber, RoundedCornerShape(2.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = callState,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp,
                                color = if (callState == "CONNECTED" || callState == "SECURE") SubtleGreen else DeepAmber
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    EnvelopeMetadataField("Active Epoch", callEpoch.toString())
                    EnvelopeMetadataField("Derivation Fingerprint", mediaKey)
                    EnvelopeMetadataField("WebRTC Codec", "OPUS Lossless / VP9")
                    EnvelopeMetadataField("Simulated RTT", "28ms")
                    EnvelopeMetadataField("Jitter", "1.2ms")
                    EnvelopeMetadataField("Packet Loss", "0.0%")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "ACTIVE ROOM PARTICIPANTS (${callParticipants.size})",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = MutedGrey,
                modifier = Modifier.align(Alignment.Start)
            )
            Spacer(modifier = Modifier.height(6.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DeepGraphite)
                    .border(1.dp, LightGraphite)
                    .padding(8.dp)
            ) {
                for (participant in callParticipants) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = participant.uppercase(),
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = WarmWhite
                        )
                        Text(
                            text = "EPOCH KEY DERIVED",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 8.sp,
                            color = SubtleGreen
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp)
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val waveHeights = listOf(20, 35, 15, 40, 25, 10, 30, 42, 18, 33, 12, 28)
                for (height in waveHeights) {
                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height(height.dp)
                            .background(BitcoinOrange)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.audioMuted.value = !audioMuted },
                    modifier = Modifier
                        .size(48.dp)
                        .background(if (audioMuted) DeepAmber else LightGraphite, RoundedCornerShape(24.dp))
                ) {
                    Icon(
                        imageVector = if (audioMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Mute",
                        tint = WarmWhite
                    )
                }

                IconButton(
                    onClick = { viewModel.addCallParticipant("Daniel") },
                    modifier = Modifier
                        .size(48.dp)
                        .background(LightGraphite, RoundedCornerShape(24.dp))
                        .testTag("add_participant_btn")
                ) {
                    Icon(Icons.Default.PersonAdd, "Add Daniel", tint = BitcoinOrange)
                }

                if (callParticipants.contains("Daniel")) {
                    IconButton(
                        onClick = { viewModel.removeCallParticipant("Daniel") },
                        modifier = Modifier
                            .size(48.dp)
                            .background(LightGraphite, RoundedCornerShape(24.dp))
                            .testTag("remove_participant_btn")
                    ) {
                        Icon(Icons.Default.PersonRemove, "Remove Daniel", tint = SubtleRed)
                    }
                }

                IconButton(
                    onClick = { viewModel.endSecureCall() },
                    modifier = Modifier
                        .size(48.dp)
                        .background(SubtleRed, RoundedCornerShape(24.dp))
                        .testTag("end_call_btn")
                ) {
                    Icon(Icons.Default.CallEnd, "End Call", tint = WarmWhite)
                }
            }
        }
    }
}

@Composable
fun PeopleView(viewModel: MainViewModel) {
    val contacts by viewModel.allContacts.collectAsState(initial = emptyList())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Text(
            text = "VERIFIED INTELLECTUAL CONTACTS",
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            fontSize = 24.sp,
            color = WarmWhite
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Private identities must be separately verified out-of-band via cryptographic key fingerprints.",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = MutedGrey
        )

        Spacer(modifier = Modifier.height(24.dp))

        LazyColumn {
            items(contacts) { person ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = DeepGraphite),
                    border = BorderStroke(1.dp, LightGraphite),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = person.displayName.uppercase(),
                                    fontFamily = FontFamily.SansSerif,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = WarmWhite
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "@${person.username}",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = BitcoinOrange
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(if (person.isVerified) SubtleGreen.copy(alpha = 0.15f) else MutedGrey.copy(alpha = 0.15f))
                                    .border(1.dp, if (person.isVerified) SubtleGreen else MutedGrey, RoundedCornerShape(2.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (person.isVerified) "VERIFIED" else "UNVERIFIED",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp,
                                    color = if (person.isVerified) SubtleGreen else MutedGrey
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "ROLE: ${person.role}",
                            fontFamily = FontFamily.SansSerif,
                            fontSize = 12.sp,
                            color = MutedGrey
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "IDENTITY KEY FINGERPRINT (SHA-256):",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp,
                            color = MutedGrey
                        )
                        Text(
                            text = person.fingerprint,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = WarmWhite
                        )

                        if (person.btcAddress.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "BTC ADDRESS: ${person.btcAddress}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = RestrainedBlue
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CirclesView(viewModel: MainViewModel) {
    val circles = listOf(
        Pair("Austrian Economics", "Subjective value theory, business cycles, credit expansion, and free banking seminars."),
        Pair("Bitcoin Protocol", "Cryptographic endpoints, scaling, post-quantum pre-key structures, peer network routing."),
        Pair("Philosophy of Money", "Monetary sovereignty, evolutionary epistemics, state theory of money, decentralized consensus."),
        Pair("Hayek Seminar", "Dispersed information, coordination theory, and social epistemics discussion."),
        Pair("AI & Knowledge", "Local private LLM boundaries, semantic client indices, on-device contextual models.")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Text(
            text = "INTELLECTUAL CIRCLES",
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            fontSize = 24.sp,
            color = WarmWhite
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "A private salon workspace. Rotating group encryption keys protect forward security upon membership changes.",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = MutedGrey
        )

        Spacer(modifier = Modifier.height(24.dp))

        LazyColumn {
            items(circles) { circle ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = DeepGraphite),
                    border = BorderStroke(1.dp, LightGraphite),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = circle.first.uppercase(),
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = BitcoinOrange
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = circle.second,
                            fontFamily = FontFamily.Serif,
                            fontSize = 14.sp,
                            color = WarmWhite,
                            lineHeight = 20.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ENCRYPTION: EPHEMERAL RATIO RATCHET",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                color = SubtleGreen
                            )
                            Button(
                                onClick = {
                                    viewModel.currentScreen.value = "INBOX"
                                    viewModel.activeConversationId.value = "circle_austrian"
                                    viewModel.observeMessagesForActiveChat()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = LightGraphite),
                                modifier = Modifier.height(30.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                            ) {
                                Text("OPEN SALON", fontSize = 11.sp, color = WarmWhite)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LibraryView(viewModel: MainViewModel) {
    val attachments by viewModel.allAttachments.collectAsState(initial = emptyList())
    var decryptedFileContent by remember { mutableStateOf<String?>(null) }
    var decryptingId by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Text(
            text = "SECURE ENCRYPTED DOCUMENTS",
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            fontSize = 24.sp,
            color = WarmWhite
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Every document file is encrypted with a random AES-256 key before upload. Recipient decrypts locally.",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = MutedGrey
        )

        Spacer(modifier = Modifier.height(24.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = DeepGraphite),
            border = BorderStroke(1.dp, LightGraphite),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "STORE NEW ENCRYPTED RESEARCH PAPER",
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = BitcoinOrange
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(
                        onClick = {
                            viewModel.encryptAndAttachFile(
                                "sovereign_individual.pdf",
                                "The sovereign individual essay context. High-security consensus layer discussion."
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = LightGraphite)
                    ) {
                        Icon(Icons.Default.Add, "Attach", tint = BitcoinOrange)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("ENCRYPT SOVEREIGN INDIVIDUAL PDF", color = WarmWhite)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "ENCRYPTED DOCUMENTS CABINET",
            style = MaterialTheme.typography.labelLarge,
            color = MutedGrey
        )
        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn {
            items(attachments) { doc ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = DeepGraphite),
                    border = BorderStroke(1.dp, LightGraphite),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = doc.fileName.uppercase(),
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = WarmWhite
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(SubtleGreen.copy(alpha = 0.15f))
                                    .border(1.dp, SubtleGreen, RoundedCornerShape(2.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = doc.integrityState,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp,
                                    color = SubtleGreen
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        EnvelopeMetadataField("AES-256 Key", doc.randomFileKey.take(16) + "...")
                        EnvelopeMetadataField("SHA-256 Hash", doc.contentHash)
                        EnvelopeMetadataField("File Size", "${doc.sizeBytes} Bytes")
                        EnvelopeMetadataField("Local Storage", doc.localPath)

                        Spacer(modifier = Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(
                                onClick = {
                                    decryptingId = doc.attachmentId
                                    decryptedFileContent = "DECRYPTED PLAINTEXT METADATA: File verification successful. SHA-256 hashes matched: ${doc.contentHash.take(8)}. Decrypted using AES key in memory."
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = LightGraphite),
                                modifier = Modifier.height(32.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                            ) {
                                Text("VERIFY HASH & DECRYPT LOCALLY", fontSize = 11.sp, color = WarmWhite)
                            }
                        }

                        if (decryptedFileContent != null && decryptingId == doc.attachmentId) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(NearBlack)
                                    .border(1.dp, SubtleGreen)
                                    .padding(8.dp)
                            ) {
                                Text(
                                    text = decryptedFileContent ?: "",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = SubtleGreen
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PrivateNotesView(viewModel: MainViewModel) {
    val activeChatId = viewModel.activeConversationId.value
    val activeNotes by viewModel.activePrivateNotes.collectAsState()
    val inputText by viewModel.inputPrivateNoteText
    var searchQuery by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Text(
            text = "SCHOLAR'S THINKING CABINET",
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            fontSize = 24.sp,
            color = WarmWhite
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Local-only un-transmitted intellectual layer. This text is never synced to the cloud or server, staying on physical memory.",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = MutedGrey
        )

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Local semantic search notes...", color = MutedGrey) },
            leadingIcon = { Icon(Icons.Default.Search, "Search", tint = MutedGrey) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = WarmWhite,
                unfocusedTextColor = WarmWhite,
                focusedBorderColor = BitcoinOrange,
                unfocusedBorderColor = LightGraphite
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))

        if (activeChatId != null) {
            Text(
                text = "ADD PRIVATE THINKING TO CURRENT ACTIVE CONVERSATION",
                style = MaterialTheme.typography.labelLarge,
                color = MutedGrey
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { viewModel.inputPrivateNoteText.value = it },
                    placeholder = { Text("Enter a local private note...", color = MutedGrey) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = WarmWhite,
                        unfocusedTextColor = WarmWhite,
                        focusedBorderColor = DeepAmber,
                        unfocusedBorderColor = LightGraphite
                    ),
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Button(
                    onClick = { viewModel.addPrivateNote(inputText, activeChatId) },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepAmber),
                    modifier = Modifier.height(56.dp)
                ) {
                    Text("SAVE NOTE")
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "SAVED SECURE NOTES ARCHIVE",
            style = MaterialTheme.typography.labelLarge,
            color = MutedGrey
        )
        Spacer(modifier = Modifier.height(8.dp))

        val filteredNotes = activeNotes.filter { it.content.contains(searchQuery, ignoreCase = true) }

        if (filteredNotes.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .border(1.dp, LightGraphite)
                    .background(DeepGraphite),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No private notes matching search criteria in this room.",
                    fontFamily = FontFamily.Serif,
                    fontSize = 13.sp,
                    color = MutedGrey
                )
            }
        } else {
            LazyColumn {
                items(filteredNotes) { note ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DeepGraphite),
                        border = BorderStroke(1.dp, DeepAmber.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "\"${note.content}\"",
                                    fontFamily = FontFamily.Serif,
                                    fontSize = 14.sp,
                                    color = WarmWhite
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "LOCAL DESTRUCTION BOND SECURE",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp,
                                    color = DeepAmber
                                )
                            }
                            IconButton(onClick = { viewModel.deletePrivateNote(note.noteId) }) {
                                Icon(Icons.Default.DeleteOutline, "Shred Note", tint = MutedGrey)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AuditLogView(viewModel: MainViewModel) {
    val logs by viewModel.allAuditLogs.collectAsState(initial = emptyList())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Text(
            text = "SECURITY AUDIT REPOSITORY",
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            fontSize = 24.sp,
            color = WarmWhite
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Immutable local security logs monitoring device status, keys changes, and session lifecycles. Zero communication plaintexts are logged.",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = MutedGrey
        )

        Spacer(modifier = Modifier.height(24.dp))

        LazyColumn {
            items(logs) { log ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, LightGraphite)
                        .background(DeepGraphite)
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(BitcoinOrange.copy(alpha = 0.15f))
                                    .border(1.dp, BitcoinOrange, RoundedCornerShape(2.dp))
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = log.eventType,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 8.sp,
                                    color = BitcoinOrange
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = log.deviceName,
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = WarmWhite
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = log.description,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = MutedGrey
                        )
                    }

                    Text(
                        text = "12:24",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = MutedGrey,
                        modifier = Modifier.padding(start = 12.dp)
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
            }
        }
    }
}

@Composable
fun MasterDemoView(viewModel: MainViewModel) {
    val step by viewModel.masterDemoStep
    val logs = viewModel.masterDemoLogs

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Text(
            text = "DETERMINISTIC MASTER DEMONSTRATION",
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            fontSize = 24.sp,
            color = WarmWhite
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Executes the precise 11-step E2EE correspondence cycle from Chapter 102.",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = MutedGrey
        )

        Spacer(modifier = Modifier.height(24.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "ACTIVE DEMONSTRATION STATUS",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = MutedGrey
                )
                Text(
                    text = if (step == 0) "NOT STARTED" else "STEP $step OF 11 ACTIVE",
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = BitcoinOrange
                )
            }

            Button(
                onClick = { viewModel.triggerNextDemoStep() },
                colors = ButtonDefaults.buttonColors(containerColor = BitcoinOrange),
                modifier = Modifier.testTag("next_demo_step_btn")
            ) {
                Text(
                    text = if (step == 0) "LAUNCH DEMO" else if (step == 11) "RESET DEMO" else "EXECUTE NEXT STEP",
                    color = NearBlack,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(DeepGraphite)
                .border(1.dp, LightGraphite)
                .padding(16.dp)
        ) {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                if (logs.isEmpty()) {
                    item {
                        Text(
                            text = "Launch the demonstration to observe local database mutations, real-time AES encryption, ratchet header generation, and audit logging events.",
                            fontFamily = FontFamily.Serif,
                            fontSize = 14.sp,
                            color = MutedGrey,
                            lineHeight = 22.sp
                        )
                    }
                } else {
                    items(logs) { log ->
                        Text(
                            text = log,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            color = if (log.startsWith("Step")) BitcoinOrange else if (log.contains("Enveloped")) SubtleGreen else WarmWhite,
                            modifier = Modifier.padding(vertical = 4.dp),
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SecurityPanelResponseView(viewModel: MainViewModel) {
    val results = viewModel.securityTestResults

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Text(
            text = "SECURITY INTRUSION ASSERTION DESK",
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            fontSize = 24.sp,
            color = WarmWhite
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Runs active intrusion checks mapping to the threat model from Section 103 to assert zero leaks.",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = MutedGrey
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { viewModel.runSecurityAttackTests() },
            colors = ButtonDefaults.buttonColors(containerColor = DeepAmber),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("run_security_tests_btn")
        ) {
            Text(
                text = "RUN INTRUSION ATTACK SIMULATION TESTS",
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        if (results.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .border(1.dp, LightGraphite)
                    .background(DeepGraphite),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Initiate attack vectors to check the cryptographic client protection layer.",
                    fontFamily = FontFamily.Serif,
                    fontSize = 13.sp,
                    color = MutedGrey
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                items(results) { res ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DeepGraphite),
                        border = BorderStroke(1.dp, if (res.actualOutcome == "FAIL") SubtleGreen else DeepAmber),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = res.testName,
                                    fontFamily = FontFamily.SansSerif,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = BitcoinOrange
                                )
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(if (res.actualOutcome == "FAIL") SubtleGreen.copy(alpha = 0.15f) else DeepAmber.copy(alpha = 0.15f))
                                        .border(1.dp, if (res.actualOutcome == "FAIL") SubtleGreen else DeepAmber, RoundedCornerShape(2.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "OUTCOME: ${res.actualOutcome}",
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 9.sp,
                                        color = if (res.actualOutcome == "FAIL") SubtleGreen else DeepAmber
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "ATTACK VECTOR ATTEMPTED:",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp,
                                color = MutedGrey
                            )
                            Text(
                                text = res.actionAttempted,
                                fontFamily = FontFamily.Serif,
                                fontSize = 13.sp,
                                color = WarmWhite
                            )

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "ASSERTION TEST OUTPUT:",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp,
                                color = MutedGrey
                            )
                            Text(
                                text = res.logDetails,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = if (res.actualOutcome == "FAIL") SubtleGreen else DeepAmber
                            )
                        }
                    }
                }
            }
        }
    }
}
