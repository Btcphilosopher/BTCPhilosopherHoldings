package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = BitcoinOrange,
    onPrimary = NearBlack,
    primaryContainer = LightGraphite,
    onPrimaryContainer = BitcoinOrange,
    secondary = RestrainedBlue,
    onSecondary = Color.White,
    background = NearBlack,
    onBackground = WarmWhite,
    surface = DeepGraphite,
    onSurface = WarmWhite,
    surfaceVariant = LightGraphite,
    onSurfaceVariant = MutedGrey,
    error = DeepAmber,
    onError = Color.White,
    outline = MutedGrey
)

private val LightColorScheme = lightColorScheme(
    primary = BitcoinOrange,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFBFBF9),
    onPrimaryContainer = NearBlack,
    secondary = RestrainedBlue,
    onSecondary = Color.White,
    background = WarmWhite,
    onBackground = NearBlack,
    surface = Color(0xFFF5F3ED),
    onSurface = NearBlack,
    surfaceVariant = Color(0xFFEBE8E0),
    onSurfaceVariant = LightGraphite,
    error = DeepAmber,
    onError = Color.White,
    outline = MutedGrey
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Disabled to enforce the signature cryptographic terminal aesthetic
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else DarkColorScheme // Enforce secure dark terminal aesthetic as default

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
