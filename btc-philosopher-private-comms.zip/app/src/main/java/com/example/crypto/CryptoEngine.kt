package com.example.crypto

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

// Interfaces as described in Chapter 12: Cryptographic Abstraction
interface IdentityKeyStore {
    fun getLocalFingerprint(): String
    fun getDeviceIdentityKey(): String
}

interface PreKeyStore {
    fun generatePreKeys(count: Int): List<String>
    fun getSignedPreKey(): String
}

interface AttachmentEncryptor {
    fun encryptAttachment(plaintext: ByteArray): EncryptedAttachment
    fun decryptAttachment(ciphertext: ByteArray, keyBase64: String): ByteArray
}

data class EncryptedAttachment(
    val ciphertext: ByteArray,
    val randomKeyBase64: String,
    val sha256Hash: String,
    val sizeBytes: Long
)

class CryptoEngine : IdentityKeyStore, PreKeyStore, AttachmentEncryptor {

    private val secureRandom = SecureRandom()
    private val keyPairSeed: ByteArray = ByteArray(32).apply { secureRandom.nextBytes(this) }

    override fun getLocalFingerprint(): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hash = digest.digest(keyPairSeed)
        return hash.joinToString(":") { "%02X".format(it) }
    }

    override fun getDeviceIdentityKey(): String {
        return Base64.encodeToString(keyPairSeed, Base64.NO_WRAP)
    }

    override fun generatePreKeys(count: Int): List<String> {
        return (1..count).map {
            val key = ByteArray(32).apply { secureRandom.nextBytes(this) }
            "pre_key_pq_${it}_" + Base64.encodeToString(key, Base64.NO_WRAP).take(16)
        }
    }

    override fun getSignedPreKey(): String {
        val sig = ByteArray(64).apply { secureRandom.nextBytes(this) }
        return "signed_pre_" + Base64.encodeToString(sig, Base64.NO_WRAP).take(20)
    }

    // Real AES-GCM Encryptor for Attachment Security (Chapter 19 & 20)
    override fun encryptAttachment(plaintext: ByteArray): EncryptedAttachment {
        val keyGen = KeyGenerator.getInstance("AES")
        keyGen.init(256, secureRandom)
        val secretKey = keyGen.generateKey()
        val keyBytes = secretKey.encoded
        val keyBase64 = Base64.encodeToString(keyBytes, Base64.NO_WRAP)

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val iv = ByteArray(12).apply { secureRandom.nextBytes(this) }
        val spec = GCMParameterSpec(128, iv)
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, spec)
        
        val encryptedBytes = cipher.doFinal(plaintext)
        // Combine IV and Ciphertext to simplify storage
        val combined = ByteArray(iv.size + encryptedBytes.size)
        System.arraycopy(iv, 0, combined, 0, iv.size)
        System.arraycopy(encryptedBytes, 0, combined, iv.size, encryptedBytes.size)

        // Generate actual SHA-256 of plaintext for integrity verification (Chapter 20)
        val digest = MessageDigest.getInstance("SHA-256")
        val sha256 = digest.digest(plaintext).joinToString("") { "%02x".format(it) }

        return EncryptedAttachment(
            ciphertext = combined,
            randomKeyBase64 = keyBase64,
            sha256Hash = sha256,
            sizeBytes = plaintext.size.toLong()
        )
    }

    override fun decryptAttachment(ciphertext: ByteArray, keyBase64: String): ByteArray {
        val keyBytes = Base64.decode(keyBase64, Base64.NO_WRAP)
        val secretKey = SecretKeySpec(keyBytes, "AES")

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val iv = ByteArray(12)
        System.arraycopy(ciphertext, 0, iv, 0, 12)
        
        val encryptedPayload = ByteArray(ciphertext.size - 12)
        System.arraycopy(ciphertext, 12, encryptedPayload, 0, encryptedPayload.size)

        val spec = GCMParameterSpec(128, iv)
        cipher.init(Cipher.DECRYPT_MODE, secretKey, spec)
        return cipher.doFinal(encryptedPayload)
    }

    // Real AES-GCM string encryption helper for local storage / text messages
    fun encryptString(plaintext: String, keyBase64: String): String {
        try {
            val keyBytes = Base64.decode(keyBase64, Base64.NO_WRAP)
            val secretKey = SecretKeySpec(keyBytes, "AES")
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            val iv = ByteArray(12).apply { secureRandom.nextBytes(this) }
            val spec = GCMParameterSpec(128, iv)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, spec)
            val encryptedBytes = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
            val combined = ByteArray(iv.size + encryptedBytes.size)
            System.arraycopy(iv, 0, combined, 0, iv.size)
            System.arraycopy(encryptedBytes, 0, combined, iv.size, encryptedBytes.size)
            return Base64.encodeToString(combined, Base64.NO_WRAP)
        } catch (e: Exception) {
            return "encryption_error:${e.message}"
        }
    }

    fun decryptString(ciphertextBase64: String, keyBase64: String): String {
        try {
            val combined = Base64.decode(ciphertextBase64, Base64.NO_WRAP)
            val keyBytes = Base64.decode(keyBase64, Base64.NO_WRAP)
            val secretKey = SecretKeySpec(keyBytes, "AES")
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            val iv = ByteArray(12)
            System.arraycopy(combined, 0, iv, 0, 12)
            val encryptedPayload = ByteArray(combined.size - 12)
            System.arraycopy(combined, 12, encryptedPayload, 0, encryptedPayload.size)
            val spec = GCMParameterSpec(128, iv)
            cipher.init(Cipher.DECRYPT_MODE, secretKey, spec)
            return String(cipher.doFinal(encryptedPayload), Charsets.UTF_8)
        } catch (e: Exception) {
            return "decryption_error: integrity verification failed"
        }
    }

    // Double Ratchet Session Packing Simulator (Chapter 11, 14, 33)
    fun packEnvelope(
        messageId: String,
        conversationId: String,
        senderId: String,
        plaintext: String,
        sessionKeyBase64: String,
        epoch: Int
    ): PackedEnvelope {
        val ciphertext = encryptString(plaintext, sessionKeyBase64)
        val ratchetHeader = "DR_KEM_EPOCH_${epoch}_KEY_" + sessionKeyBase64.take(12)
        val associatedData = "auth_version=3.6;sender=$senderId;conv=$conversationId;epoch=$epoch"
        
        return PackedEnvelope(
            messageId = messageId,
            conversationId = conversationId,
            ciphertext = ciphertext,
            ratchetHeader = ratchetHeader,
            associatedData = associatedData
        )
    }
}

data class PackedEnvelope(
    val messageId: String,
    val conversationId: String,
    val ciphertext: String,
    val ratchetHeader: String,
    val associatedData: String
)
