package com.example.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        UserEntity::class,
        DeviceEntity::class,
        ContactEntity::class,
        ConversationEntity::class,
        MessageEnvelopeEntity::class,
        PrivateNoteEntity::class,
        AttachmentEntity::class,
        CallSessionEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class BtcPrivateDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun deviceDao(): DeviceDao
    abstract fun contactDao(): ContactDao
    abstract fun conversationDao(): ConversationDao
    abstract fun messageDao(): MessageDao
    abstract fun privateNoteDao(): PrivateNoteDao
    abstract fun attachmentDao(): AttachmentDao
    abstract fun callDao(): CallDao
    abstract fun auditLogDao(): AuditLogDao

    companion object {
        @Volatile
        private var INSTANCE: BtcPrivateDatabase? = null

        fun getDatabase(context: Context): BtcPrivateDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BtcPrivateDatabase::class.java,
                    "btc_philosopher_private_secure.db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
