package com.example.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE userId = :userId")
    suspend fun getUserById(userId: String): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)
}

@Dao
interface DeviceDao {
    @Query("SELECT * FROM devices WHERE userId = :userId")
    fun getDevicesByUserIdFlow(userId: String): Flow<List<DeviceEntity>>

    @Query("SELECT * FROM devices")
    fun getAllDevicesFlow(): Flow<List<DeviceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDevice(device: DeviceEntity)

    @Query("UPDATE devices SET verificationState = :state WHERE deviceId = :deviceId")
    suspend fun updateDeviceState(deviceId: String, state: String)

    @Query("DELETE FROM devices WHERE deviceId = :deviceId")
    suspend fun deleteDevice(deviceId: String)
}

@Dao
interface ContactDao {
    @Query("SELECT * FROM contacts")
    fun getAllContactsFlow(): Flow<List<ContactEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContact(contact: ContactEntity)

    @Query("UPDATE contacts SET isVerified = :isVerified WHERE username = :username")
    suspend fun updateContactVerification(username: String, isVerified: Boolean)
}

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations ORDER BY lastActivity DESC")
    fun getAllConversationsFlow(): Flow<List<ConversationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConversation(conversation: ConversationEntity)
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM message_envelopes WHERE conversationId = :conversationId ORDER BY timestampMetadata ASC")
    fun getMessagesByConversationFlow(conversationId: String): Flow<List<MessageEnvelopeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEnvelopeEntity)

    @Query("UPDATE message_envelopes SET isRead = 1 WHERE messageId = :messageId")
    suspend fun markAsRead(messageId: String)
}

@Dao
interface PrivateNoteDao {
    @Query("SELECT * FROM private_notes WHERE conversationId = :conversationId ORDER BY timestamp DESC")
    fun getPrivateNotesFlow(conversationId: String): Flow<List<PrivateNoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrivateNote(note: PrivateNoteEntity)

    @Query("DELETE FROM private_notes WHERE noteId = :noteId")
    suspend fun deletePrivateNote(noteId: Int)
}

@Dao
interface AttachmentDao {
    @Query("SELECT * FROM attachments")
    fun getAllAttachmentsFlow(): Flow<List<AttachmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttachment(attachment: AttachmentEntity)

    @Query("UPDATE attachments SET integrityState = :state WHERE attachmentId = :attachmentId")
    suspend fun updateIntegrityState(attachmentId: String, state: String)
}

@Dao
interface CallDao {
    @Query("SELECT * FROM calls ORDER BY startTime DESC")
    fun getAllCallsFlow(): Flow<List<CallSessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCall(call: CallSessionEntity)
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC")
    fun getAllAuditLogsFlow(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AuditLogEntity)
}
