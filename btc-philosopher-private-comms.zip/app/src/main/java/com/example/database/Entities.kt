package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val userId: String,
    val username: String,
    val displayName: String,
    val profileImage: String,
    val publicProfileReference: String,
    val identityPublicKey: String,
    val verificationState: String, // UNVERIFIED, VERIFIED, KEY_CHANGED, REVOKED, BLOCKED
    val bio: String = "",
    val researchInterests: String = ""
)

@Entity(tableName = "devices")
data class DeviceEntity(
    @PrimaryKey val deviceId: String,
    val userId: String,
    val deviceName: String,
    val platform: String,
    val identityKey: String,
    val registrationId: Int,
    val verificationState: String, // UNVERIFIED, VERIFIED, KEY_CHANGED, REVOKED, BLOCKED
    val createdAt: Long = System.currentTimeMillis(),
    val lastSeenAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "contacts")
data class ContactEntity(
    @PrimaryKey val username: String,
    val displayName: String,
    val role: String, // e.g. "Economics", "Bitcoin Research", "Systems Engineering"
    val isVerified: Boolean,
    val fingerprint: String,
    val btcAddress: String = "",
    val pgpKey: String = "",
    val website: String = ""
)

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey val conversationId: String,
    val name: String,
    val type: String, // DIRECT, CIRCLE, PROJECT, PRIVATE_SALON, RESEARCH_GROUP
    val lastActivity: Long = System.currentTimeMillis(),
    val retentionPolicy: String = "KEEP_FOREVER", // KEEP_FOREVER, 30_DAYS, 7_DAYS, 24_HOURS
    val encryptionState: String = "ENCRYPTED"
)

@Entity(tableName = "message_envelopes")
data class MessageEnvelopeEntity(
    @PrimaryKey val messageId: String,
    val conversationId: String,
    val senderId: String,
    val recipientDeviceId: String,
    val protocolVersion: Int = 1,
    val ciphertext: String, // Simulated hex block representing PQXDH ciphertext
    val associatedData: String,
    val ratchetHeader: String, // Ephemeral keys
    val timestampMetadata: Long = System.currentTimeMillis(),
    val isDelivered: Boolean = true,
    val isRead: Boolean = false,
    val messageType: String = "TEXT", // TEXT, REPLY, DOCUMENT, REACTION, CALL_EVENT
    val plaintextBody: String = "" // In a real system, the server only receives the envelope. The local DB decrypted cache is stored here.
)

@Entity(tableName = "private_notes")
data class PrivateNoteEntity(
    @PrimaryKey(autoGenerate = true) val noteId: Int = 0,
    val conversationId: String,
    val content: String, // Local scholar's thinking layer, visible only to author, never transmitted.
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "attachments")
data class AttachmentEntity(
    @PrimaryKey val attachmentId: String,
    val fileName: String,
    val contentHash: String, // SHA-256 for integrity verification
    val sizeBytes: Long,
    val mimeType: String,
    val localPath: String,
    val randomFileKey: String, // AES-256 ephemeral file key
    val uploadState: String, // QUEUED, UPLOADING, COMPLETED, FAILED
    val integrityState: String // UNVERIFIED, VERIFIED, CORRUPTED
)

@Entity(tableName = "calls")
data class CallSessionEntity(
    @PrimaryKey val callId: String,
    val callType: String, // VOICE, VIDEO
    val durationSeconds: Int,
    val startTime: Long = System.currentTimeMillis(),
    val participantSet: String, // Comma-separated list of names
    val finalEpoch: Int = 1,
    val finalState: String // SECURE, ENCRYPTED, DEGRADED, COMPLETED
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val auditId: Int = 0,
    val eventType: String, // ACCOUNT_CREATED, DEVICE_REGISTERED, DEVICE_VERIFIED, DEVICE_REVOKED, KEY_CHANGED
    val description: String,
    val timestamp: Long = System.currentTimeMillis(),
    val ipAddress: String = "127.0.0.1",
    val deviceName: String = ""
)
