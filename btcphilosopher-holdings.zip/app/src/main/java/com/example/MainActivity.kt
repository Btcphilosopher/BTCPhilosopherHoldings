package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.Currency
import com.example.ui.TerminalViewModel
import com.example.ui.TerminalWorkspace
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.BTCPhilosopherTheme
import com.example.ui.theme.BackgroundObsidian

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BTCPhilosopherTheme {
                HoldingCompanyApp()
            }
        }
    }
}

@Composable
fun HoldingCompanyApp(
    viewModel: TerminalViewModel = viewModel()
) {
    val currentWorkspace by viewModel.currentWorkspace.collectAsStateWithLifecycle()
    val selectedEntityId by viewModel.selectedEntityId.collectAsStateWithLifecycle()
    val commandInput by viewModel.commandInput.collectAsStateWithLifecycle()
    val activeProposal by viewModel.activeCommandProposal.collectAsStateWithLifecycle()
    val toastMsg by viewModel.toastMessage.collectAsStateWithLifecycle()
    val generatedReport by viewModel.generatedReport.collectAsStateWithLifecycle()

    val entities by viewModel.repository.entities.collectAsStateWithLifecycle()
    val directives by viewModel.repository.directives.collectAsStateWithLifecycle()
    val fundingRequests by viewModel.repository.fundingRequests.collectAsStateWithLifecycle()
    val commitments by viewModel.repository.commitments.collectAsStateWithLifecycle()
    val payments by viewModel.repository.paymentInstructions.collectAsStateWithLifecycle()
    val accounts by viewModel.repository.treasuryAccounts.collectAsStateWithLifecycle()
    val journals by viewModel.repository.intercompanyJournals.collectAsStateWithLifecycle()
    val research by viewModel.repository.researchProgrammes.collectAsStateWithLifecycle()
    val ipAssets by viewModel.repository.ipAssets.collectAsStateWithLifecycle()
    val risks by viewModel.repository.risks.collectAsStateWithLifecycle()
    val auditEvents by viewModel.repository.auditEvents.collectAsStateWithLifecycle()
    val isSimulationMode by viewModel.repository.isSimulationMode.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(toastMsg) {
        toastMsg?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearToast()
        }
    }

    // Android BackHandler: if on any sub-screen, pressing Back navigates to COMMAND
    BackHandler(enabled = currentWorkspace != TerminalWorkspace.COMMAND) {
        viewModel.navigateTo(TerminalWorkspace.COMMAND)
    }

    val totalGbpTreasury = accounts.filter { it.currency == Currency.GBP }.sumOf { it.balance }
    val totalBtcReserve = accounts.filter { it.currency == Currency.BTC }.sumOf { it.balance }
    val pendingDirectivesCount = directives.count { it.status.name.contains("PROGRESS") || it.status.name.contains("ISSUED") || it.status.name.contains("REVIEW") }
    val criticalRisksCount = risks.count { it.isCritical }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundObsidian)
            .testTag("main_scaffold"),
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            HeaderBar(
                entityCount = entities.size,
                treasuryGbp = totalGbpTreasury,
                btcReserve = totalBtcReserve,
                pendingDirectivesCount = pendingDirectivesCount,
                criticalRisksCount = criticalRisksCount,
                isSimulationMode = isSimulationMode,
                onToggleSimulation = {
                    viewModel.executeProposal(
                        com.example.data.CommandActionProposal.ProposeSimulationToggle(!isSimulationMode)
                    )
                },
                onGenerateReport = {
                    viewModel.generateExecutiveConsolidatedReport()
                }
            )
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                CommandPromptBar(
                    commandInput = commandInput,
                    onInputChange = { viewModel.setCommandInput(it) },
                    onSubmit = { viewModel.submitCommand() }
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BackgroundObsidian)
        ) {
            // Workspace selector tabs
            WorkspaceNavigationBar(
                currentWorkspace = currentWorkspace,
                onSelectWorkspace = { viewModel.navigateTo(it) }
            )

            // Dynamic workspace screen
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                when (currentWorkspace) {
                    TerminalWorkspace.COMMAND -> {
                        CommandOverviewScreen(
                            entities = entities,
                            directives = directives,
                            fundingRequests = fundingRequests,
                            commitments = commitments,
                            accounts = accounts,
                            risks = risks,
                            research = research,
                            onNavigateWorkspace = { viewModel.navigateTo(it) },
                            onSelectEntity = {
                                viewModel.selectEntity(it)
                                viewModel.navigateTo(TerminalWorkspace.HIERARCHY)
                            },
                            onApproveFunding = { viewModel.approveFunding(it) },
                            onRejectFunding = { viewModel.rejectFunding(it) }
                        )
                    }

                    TerminalWorkspace.HIERARCHY -> {
                        HierarchyScreen(
                            entities = entities,
                            directives = directives,
                            ipAssets = ipAssets,
                            selectedEntityId = selectedEntityId,
                            onSelectEntity = { viewModel.selectEntity(it) },
                            onUpdateEntity = { viewModel.repository.updateEntity(it) }
                        )
                    }

                    TerminalWorkspace.DIRECTIVES -> {
                        DirectivesScreen(
                            directives = directives,
                            entities = entities,
                            onAdvanceStatus = { id, next, note -> viewModel.advanceDirectiveStatus(id, next, note) },
                            onCreateDirective = { viewModel.repository.createDirective(it) }
                        )
                    }

                    TerminalWorkspace.CAPITAL -> {
                        CapitalAllocationScreen(
                            fundingRequests = fundingRequests,
                            commitments = commitments,
                            paymentInstructions = payments,
                            treasuryAccounts = accounts,
                            entities = entities,
                            isSimulationMode = isSimulationMode,
                            onApproveRequest = { viewModel.approveFunding(it) },
                            onRejectRequest = { viewModel.rejectFunding(it) },
                            onExecutePayment = { comId, srcAcc, target, amt, curr, purp ->
                                viewModel.executePayment(comId, srcAcc, target, amt, curr, purp)
                            }
                        )
                    }

                    TerminalWorkspace.TREASURY -> {
                        TreasuryLedgerScreen(
                            accounts = accounts,
                            journals = journals,
                            entities = entities
                        )
                    }

                    TerminalWorkspace.RESEARCH -> {
                        ResearchSciencesScreen(
                            programmes = research,
                            onUpdateStatus = { id, st -> viewModel.repository.updateResearchStatus(id, st) },
                            onAugmentBudget = { id, amt -> viewModel.repository.allocateResearchBudget(id, amt) }
                        )
                    }

                    TerminalWorkspace.IP_REGISTRY -> {
                        IntellectualPropertyScreen(
                            ipAssets = ipAssets,
                            entities = entities
                        )
                    }

                    TerminalWorkspace.RISK_GOVERNANCE -> {
                        RiskComplianceScreen(
                            risks = risks,
                            entities = entities
                        )
                    }

                    TerminalWorkspace.AUDIT_LOG -> {
                        AuditTrailScreen(
                            auditEvents = auditEvents,
                            onGenerateReport = { viewModel.generateExecutiveConsolidatedReport() }
                        )
                    }
                }
            }
        }
    }

    // Modal proposal review dialog
    if (activeProposal != null) {
        ProposalDialog(
            proposal = activeProposal!!,
            onConfirm = { viewModel.executeProposal(it) },
            onDismiss = { viewModel.dismissCommandProposal() }
        )
    }

    // Modal executive consolidated report pack
    if (generatedReport != null) {
        ExecutiveReportDialog(
            report = generatedReport!!,
            onDismiss = { viewModel.dismissReport() }
        )
    }
}
