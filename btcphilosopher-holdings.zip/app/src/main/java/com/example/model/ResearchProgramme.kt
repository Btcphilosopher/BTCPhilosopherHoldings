package com.example.model

enum class ResearchCategory(val label: String) {
    QUANTUM_COMPUTING("Quantum Computing & Algorithms"),
    QUANTUM_CRYPTOGRAPHY("Quantum & Cryptographic Security"),
    INDUSTRY_4_0("Industry 4.0 & Industrial Automation"),
    ADVANCED_COMPUTING("Advanced Computing & P vs NP"),
    SEMICONDUCTORS("Semiconductors & Big-Chips"),
    AEROSPACE_PROPULSION("Aerospace & Propulsion Engineering"),
    CLEAN_ENERGY_HYDROGEN("Clean Hydrogen & Energy Systems")
}

enum class ResearchMaturity(val label: String) {
    THEORETICAL_PROPOSAL("Theoretical Proposal"),
    SIMULATED_NUMERICAL("Numerical / Mathematical Simulation"),
    LABORATORY_PROTOTYPE("Laboratory Proof-of-Concept"),
    PILOT_DEPLOYMENT("Pilot Trial / Industrial Testbed"),
    PRODUCTION_READY("Production / Space-Flight Ready")
}

enum class ResearchStatus(val label: String) {
    ACTIVE_PROGRAMME("Active Research"),
    AWAITING_DECISION("Awaiting Board Decision"),
    PHASE_COMPLETED("Phase Completed"),
    FUNDING_PAUSED("Funding Paused"),
    COMMERCIALISED("Commercialised / Spun Out")
}

data class ResearchMilestone(
    val title: String,
    val targetQuarter: String,
    val isCompleted: Boolean = false
)

data class ResearchProgramme(
    val id: String,
    val title: String,
    val entityId: String = "duke-theoretical-sciences",
    val category: ResearchCategory,
    val maturity: ResearchMaturity,
    val status: ResearchStatus = ResearchStatus.ACTIVE_PROGRAMME,
    val researchLead: String,
    val budgetGbp: Double,
    val actualExpenditureGbp: Double,
    val researchQuestion: String,
    val validationCriteria: String,
    val githubPath: String? = null,
    val keyMilestones: List<ResearchMilestone> = emptyList(),
    val publicationOrIpStatus: String = "Internal Proprietary",
    val resultsSummary: String
)
