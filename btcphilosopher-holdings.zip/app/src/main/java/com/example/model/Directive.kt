package com.example.model

enum class DirectiveStatus(val label: String) {
    DRAFT("Draft"),
    SUBMITTED("Submitted"),
    UNDER_REVIEW("Under Review"),
    APPROVED("Approved"),
    ISSUED("Issued"),
    ACKNOWLEDGED("Acknowledged"),
    IN_PROGRESS("In Progress"),
    COMPLETED("Completed"),
    REVIEWED("Reviewed"),
    BLOCKED("Blocked"),
    REJECTED("Rejected"),
    SUSPENDED("Suspended")
}

enum class DirectivePriority(val label: String) {
    ROUTINE("Routine"),
    STRATEGIC("Strategic"),
    URGENT("Urgent"),
    CRITICAL("Critical")
}

data class DirectiveRevision(
    val timestamp: Long,
    val author: String,
    val note: String,
    val previousStatus: DirectiveStatus,
    val newStatus: DirectiveStatus
)

data class Directive(
    val id: String,
    val title: String,
    val originatingEntityId: String = "btc-holdings",
    val targetEntityId: String,
    val instruction: String,
    val businessRationale: String,
    val priority: DirectivePriority = DirectivePriority.STRATEGIC,
    val status: DirectiveStatus = DirectiveStatus.ISSUED,
    val effectiveDate: String,
    val deadlineDate: String,
    val budgetAuthorityGbp: Double = 0.0,
    val responsibleRole: String = "Lead Director",
    val requiredDeliverables: List<String> = emptyList(),
    val successCriteria: String = "",
    val riskAssessment: String = "Standard operational governance",
    val evidenceOfCompletion: String? = null,
    val revisions: List<DirectiveRevision> = emptyList()
)
