package com.example.model

enum class FundingType(val label: String) {
    EQUITY_CONTRIBUTION("Equity Contribution"),
    INTERCOMPANY_LOAN("Intercompany Loan"),
    PROJECT_FUNDING("Project Funding"),
    OPERATING_BUDGET("Operating Budget"),
    CAPITAL_EXPENDITURE("Capital Expenditure (CapEx)"),
    RESEARCH_GRANT("Research & Development Grant"),
    CONVERTIBLE_NOTE("Convertible Note"),
    CUSTOM_INSTRUMENT("Other Defined Instrument")
}

enum class FundingRequestStatus(val label: String) {
    PENDING_REVIEW("Pending Parent Review"),
    APPROVED_COMMITTED("Approved & Committed"),
    DISBURSED("Disbursed / Paid"),
    REJECTED("Rejected"),
    CANCELLED("Cancelled")
}

enum class Currency(val code: String, val symbol: String, val rateToGbp: Double) {
    GBP("GBP", "£", 1.0),
    EUR("EUR", "€", 0.85),
    USD("USD", "$", 0.78),
    BTC("BTC", "₿", 52000.0) // reference rate for conversion tracking
}

data class FundingRequest(
    val id: String,
    val requestingEntityId: String,
    val recipientEntityId: String,
    val projectOrProgramme: String,
    val requestedAmount: Double,
    val currency: Currency = Currency.GBP,
    val fundingType: FundingType,
    val purpose: String,
    val businessCase: String,
    val expectedMilestones: List<String> = emptyList(),
    val riskClassification: String = "Medium",
    val status: FundingRequestStatus = FundingRequestStatus.PENDING_REVIEW,
    val submissionDate: String,
    val requiredByDate: String,
    val approvalNotes: String? = null
)

data class CapitalCommitment(
    val id: String,
    val fundingRequestId: String,
    val entityId: String,
    val committedAmount: Double,
    val currency: Currency,
    val remainingUndisbursed: Double,
    val commitmentDate: String,
    val authorizedBy: String = "BTCPhilosopher Investment Committee"
)

enum class PaymentStatus(val label: String) {
    PENDING_REVIEW("Pending Execution Review"),
    AUTHORIZED_RELEASE("Authorized for Release"),
    SETTLED("Settled & Cleared"),
    RECONCILED("Reconciled"),
    FAILED("Execution Failed"),
    SIMULATED_TEST("Simulated Test Run")
}

data class PaymentInstruction(
    val id: String,
    val commitmentId: String?,
    val sourceAccountId: String,
    val targetEntityId: String,
    val targetAccountDetails: String,
    val amount: Double,
    val currency: Currency,
    val purpose: String,
    val isSimulationMode: Boolean = true,
    val providerReference: String? = null,
    val status: PaymentStatus = PaymentStatus.PENDING_REVIEW,
    val creationTimestamp: Long = System.currentTimeMillis()
)
