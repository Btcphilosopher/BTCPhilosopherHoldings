package com.example.model

enum class IpAssetType(val label: String) {
    SOFTWARE_REPOSITORY("Software Repository"),
    ALGORITHMIC_MODEL("Algorithmic Model"),
    PATENT_SPECIFICATION("Patent / Provisional Filing"),
    TRADEMARK_BRAND("Trademark & Commercial Brand"),
    RESEARCH_DATASET("Proprietary Dataset"),
    SYSTEM_ARCHITECTURE("Technical Architecture & Specs")
}

enum class LicensingModel(val label: String) {
    PROPRIETARY_HOLDING("Proprietary Holding Asset"),
    GROUP_INTERNAL_LICENCE("Internal Intercompany Licence"),
    COMMERCIAL_EXCLUSIVE("Commercial Exclusive Licence"),
    COMMERCIAL_RECURRING_SAAS("Recurring SaaS / Commercial"),
    OPEN_SOURCE_APACHE2("Open Source (Apache 2.0 / MIT)"),
    PENDING_VERIFICATION("Pending Legal Review")
}

data class IpAsset(
    val id: String,
    val name: String,
    val type: IpAssetType,
    val custodianEntityId: String,
    val claimedOwner: String = "BTCPhilosopherHoldings",
    val legalOwnerVerified: String? = null,
    val licensingModel: LicensingModel,
    val repositoryPath: String? = null,
    val commercialStatus: String = "Internal Core Asset",
    val estimatedAssetValueGbp: Double? = null,
    val description: String,
    val dependencies: List<String> = emptyList(),
    val registeredJurisdiction: String = "United Kingdom & International"
)
