package com.example.model

enum class AccountType(val label: String) {
    BANK_ACCOUNT("Tier-1 Bank Account"),
    IMPORT_STATEMENT("Imported Statement Feed"),
    MANUAL_ENTRY("Manual Book Entry"),
    INTERNAL_LEDGER("Internal Ledger"),
    BITCOIN_WALLET("Bitcoin Cold/Multi-Sig Treasury"),
    EXCHANGE_CUSTODY("Exchange / Custody Account"),
    SIMULATED_ACCOUNT("Simulated Sandbox Account")
}

enum class BalanceVerificationStatus(val label: String) {
    VERIFIED_ONLINE("Live Bank Verified"),
    STATEMENT_IMPORTED("Statement Reconciled"),
    MANUAL_UNVERIFIED("Manual Declared"),
    BITCOIN_ONCHAIN("On-Chain Confirmed"),
    SIMULATED_TEST("Simulated Test"),
    UNRECONCILED("Unreconciled Discrepancy")
}

data class TreasuryAccount(
    val id: String,
    val name: String,
    val entityId: String,
    val institution: String,
    val accountType: AccountType,
    val currency: Currency,
    val balance: Double,
    val verificationStatus: BalanceVerificationStatus,
    val lastUpdated: String,
    val accountNumberMasked: String = "•••• 4892",
    val notes: String = ""
)

enum class IntercompanyTransactionType(val label: String) {
    EQUITY_CONTRIBUTION("Equity Contribution"),
    INTERCOMPANY_LOAN("Intercompany Loan Facility"),
    LOAN_REPAYMENT("Principal / Interest Repayment"),
    SHARED_SERVICE_CHARGE("Shared Services Cost Allocation"),
    SOFTWARE_LICENCE_FEE("Software & IP Licence Charge"),
    IP_TRANSFER("IP / Asset Transfer"),
    MANAGEMENT_CHARGE("Holding Management Charge")
}

data class IntercompanyJournalEntry(
    val id: String,
    val transactionRef: String,
    val originatingEntityId: String,
    val counterpartyEntityId: String,
    val amount: Double,
    val currency: Currency,
    val transactionType: IntercompanyTransactionType,
    val debitAccount: String,
    val creditAccount: String,
    val isBalanced: Boolean = true,
    val isEliminatedInConsolidation: Boolean = true,
    val date: String,
    val status: String = "POSTED_BALANCED",
    val description: String
)
