package com.example.model

enum class RiskCategory(val label: String) {
    FINANCIAL_CAPITAL("Financial & Capital Allocation"),
    LIQUIDITY_TREASURY("Liquidity & Cash Flow"),
    CYBERSECURITY("Cybersecurity & Infrastructure"),
    IP_OWNERSHIP("Intellectual Property & Licensing"),
    REGULATORY_COMPLIANCE("Regulatory & Governance"),
    ENGINEERING_SAFETY("Engineering & Safety Integrity"),
    COUNTERPARTY("Counterparty & Vendor"),
    RESEARCH_INTEGRITY("Research & Academic Validity")
}

enum class RiskStatus(val label: String) {
    ACTIVE_MONITORED("Active Monitored"),
    MITIGATED("Mitigation Implemented"),
    CRITICAL_ATTENTION("Critical Attention Required"),
    RESOLVED("Resolved")
}

data class RiskItem(
    val id: String,
    val entityId: String,
    val category: RiskCategory,
    val title: String,
    val description: String,
    val likelihood: Int, // 1 to 5
    val impact: Int,     // 1 to 5
    val mitigationPlan: String,
    val status: RiskStatus = RiskStatus.ACTIVE_MONITORED,
    val ownerRole: String = "Group Executive Risk Lead"
) {
    val inherentScore: Int get() = likelihood * impact
    val isCritical: Boolean get() = inherentScore >= 16 || status == RiskStatus.CRITICAL_ATTENTION
}

data class AuditEvent(
    val id: String,
    val timestamp: Long = System.currentTimeMillis(),
    val actor: String = "Group Executive",
    val actionType: String,
    val targetRecordId: String,
    val targetRecordType: String,
    val previousStateSummary: String? = null,
    val newStateSummary: String,
    val rationale: String,
    val correlationId: String
)
