package com.example.model

enum class EntityType(val label: String) {
    HOLDING_COMPANY("Holding Company"),
    SUBSIDIARY("Subsidiary PLC/Ltd"),
    DIVISION("Business Division"),
    RESEARCH_DIVISION("Research & Sciences"),
    VENTURE("Commercial Venture"),
    PRODUCT_LINE("Software Product"),
    BRAND_TRADING_NAME("Brand / Trading Name")
}

enum class VerificationStatus(val label: String) {
    VERIFIED("Verified"),
    USER_DECLARED("User-declared"),
    PROPOSED("Proposed"),
    PENDING_VERIFICATION("Pending Verification"),
    ARCHIVED("Archived")
}

data class CorporateEntity(
    val id: String,
    val name: String,
    val legalName: String? = null,
    val type: EntityType,
    val parentId: String? = null,
    val targetOwnershipPercent: Double = 100.0,
    val actualRecordedPercent: Double = 100.0,
    val votingRightsPercent: Double = 100.0,
    val verificationStatus: VerificationStatus = VerificationStatus.USER_DECLARED,
    val jurisdiction: String = "United Kingdom",
    val executiveLead: String = "Executive Committee",
    val description: String = "",
    val repositoryPath: String? = null,
    val authorizedBudgetGbp: Double = 0.0,
    val allocatedCapitalGbp: Double = 0.0,
    val spentCapitalGbp: Double = 0.0,
    val tags: List<String> = emptyList(),
    val notes: String = ""
)
