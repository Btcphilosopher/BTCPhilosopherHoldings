package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun HeaderBar(
    entityCount: Int,
    treasuryGbp: Double,
    btcReserve: Double,
    pendingDirectivesCount: Int,
    criticalRisksCount: Int,
    isSimulationMode: Boolean,
    onToggleSimulation: () -> Unit,
    onGenerateReport: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("terminal_header"),
        color = SurfaceSlate,
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Title and Heraldic Tag
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(BorderSubtle, RoundedCornerShape(8.dp))
                            .border(1.dp, SovereignGold, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "BPH",
                            color = SovereignGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "BTCPhilosopherHoldings",
                                color = TextIvory,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (isSimulationMode) SimulationPurple.copy(alpha = 0.2f) else VerifiedEmeraldMuted,
                                        RoundedCornerShape(4.dp)
                                    )
                                    .border(
                                        1.dp,
                                        if (isSimulationMode) SimulationPurple else VerifiedEmerald,
                                        RoundedCornerShape(4.dp)
                                    )
                                    .clickable { onToggleSimulation() }
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                    .testTag("simulation_mode_chip")
                            ) {
                                Text(
                                    text = if (isSimulationMode) "SIMULATION MODE" else "LIVE TERMINAL",
                                    color = if (isSimulationMode) SimulationPurple else VerifiedEmerald,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                        Text(
                            text = "Group Executive Command Terminal • Institutional Holding OS",
                            color = TextSteel,
                            fontSize = 11.sp
                        )
                    }
                }

                // Report button
                OutlinedButton(
                    onClick = onGenerateReport,
                    modifier = Modifier.testTag("generate_report_button"),
                    shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = BorderSubtle.copy(alpha = 0.5f),
                        contentColor = TextIvory
                    ),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Summarize,
                        contentDescription = "Export Report",
                        tint = SovereignGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Executive Pack", fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Quick Telemetry Ribbon
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TelemetryChip(
                    label = "ENTITIES",
                    value = "$entityCount",
                    valueColor = CommandCyan,
                    modifier = Modifier.weight(1f)
                )
                TelemetryChip(
                    label = "CASH (GBP)",
                    value = "£${String.format(java.util.Locale.UK, "%,.1fM", treasuryGbp / 1000000.0)}",
                    valueColor = VerifiedEmerald,
                    modifier = Modifier.weight(1.2f)
                )
                TelemetryChip(
                    label = "BTC RESERVE",
                    value = "₿${String.format(java.util.Locale.UK, "%.2f", btcReserve)}",
                    valueColor = BitcoinOrange,
                    modifier = Modifier.weight(1.2f)
                )
                TelemetryChip(
                    label = "DIRECTIVES",
                    value = "$pendingDirectivesCount Active",
                    valueColor = SovereignGold,
                    modifier = Modifier.weight(1.2f)
                )
                TelemetryChip(
                    label = "CRITICAL RISKS",
                    value = "$criticalRisksCount Monitored",
                    valueColor = if (criticalRisksCount > 0) RiskCrimson else TextSteel,
                    modifier = Modifier.weight(1.2f)
                )
            }
        }
    }
}

@Composable
fun TelemetryChip(
    label: String,
    value: String,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(SurfaceCard, RoundedCornerShape(6.dp))
            .border(0.5.dp, BorderSubtle, RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Column {
            Text(
                text = label,
                color = TextMuted,
                fontSize = 9.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 0.5.sp
            )
            Text(
                text = value,
                color = valueColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                maxLines = 1
            )
        }
    }
}
