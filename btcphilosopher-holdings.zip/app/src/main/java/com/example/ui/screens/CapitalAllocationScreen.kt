package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.TelemetryChip
import com.example.ui.theme.*

@Composable
fun CapitalAllocationScreen(
    fundingRequests: List<FundingRequest>,
    commitments: List<CapitalCommitment>,
    paymentInstructions: List<PaymentInstruction>,
    treasuryAccounts: List<TreasuryAccount>,
    entities: List<CorporateEntity>,
    isSimulationMode: Boolean,
    onApproveRequest: (String) -> Unit,
    onRejectRequest: (String) -> Unit,
    onExecutePayment: (String?, String, String, Double, Currency, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showPaymentModal by remember { mutableStateOf(false) }
    var selectedCommitmentForPayment by remember { mutableStateOf<CapitalCommitment?>(null) }

    val totalCommittedGbp = commitments.sumOf { it.committedAmount * it.currency.rateToGbp }
    val totalUndisbursedGbp = commitments.sumOf { it.remainingUndisbursed * it.currency.rateToGbp }
    val totalParentGbp = treasuryAccounts.filter { it.entityId == "btc-holdings" && it.currency == Currency.GBP }.sumOf { it.balance }
    val availableUncommittedGbp = (totalParentGbp - totalUndisbursedGbp).coerceAtLeast(0.0)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("capital_allocation_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Capital Allocation Header & Headroom Stats
        item {
            CapitalHeadroomCard(
                parentCashGbp = totalParentGbp,
                committedUndisbursedGbp = totalUndisbursedGbp,
                availableUncommittedGbp = availableUncommittedGbp,
                isSimulationMode = isSimulationMode
            )
        }

        // Section: Active Funding Requests Pipeline
        item {
            SectionHeader(
                title = "SUBSIDIARY FUNDING REQUESTS PIPELINE",
                badge = "${fundingRequests.size} Total Requests",
                badgeColor = CommandCyan
            )
        }

        items(fundingRequests) { req ->
            val entityName = entities.find { it.id == req.requestingEntityId }?.name ?: req.requestingEntityId
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                color = SurfaceCard,
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (req.status == FundingRequestStatus.PENDING_REVIEW) SovereignGold.copy(alpha = 0.5f) else BorderSubtle
                )
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = req.projectOrProgramme,
                                color = TextIvory,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "$entityName • ${req.fundingType.label} • Req: ${req.submissionDate}",
                                color = CommandCyan,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Text(
                            text = "${req.currency.symbol}${String.format(java.util.Locale.UK, "%,.0f", req.requestedAmount)}",
                            color = SovereignGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = req.purpose,
                        color = TextSteel,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Business Case: ${req.businessCase}",
                        color = TextSteel.copy(alpha = 0.8f),
                        fontSize = 10.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .background(
                                    when (req.status) {
                                        FundingRequestStatus.APPROVED_COMMITTED -> VerifiedEmeraldMuted
                                        FundingRequestStatus.DISBURSED -> CommandCyan.copy(alpha = 0.15f)
                                        FundingRequestStatus.PENDING_REVIEW -> SovereignGoldMuted
                                        else -> RiskCrimsonMuted
                                    },
                                    RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = req.status.label,
                                color = when (req.status) {
                                    FundingRequestStatus.APPROVED_COMMITTED -> VerifiedEmerald
                                    FundingRequestStatus.DISBURSED -> CommandCyan
                                    FundingRequestStatus.PENDING_REVIEW -> SovereignGold
                                    else -> RiskCrimson
                                },
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (req.status == FundingRequestStatus.PENDING_REVIEW) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = { onRejectRequest(req.id) },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = RiskCrimson),
                                    shape = RoundedCornerShape(4.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text("Reject", fontSize = 11.sp)
                                }
                                Button(
                                    onClick = { onApproveRequest(req.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = SovereignGold, contentColor = BackgroundObsidian),
                                    shape = RoundedCornerShape(4.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                ) {
                                    Text("Approve & Commit", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section: Capital Commitments Ledger
        item {
            SectionHeader(
                title = "APPROVED CAPITAL COMMITMENTS & DISBURSEMENTS",
                badge = "${commitments.size} Commitments Active",
                badgeColor = VerifiedEmerald
            )
        }

        items(commitments) { com ->
            val entityName = entities.find { it.id == com.entityId }?.name ?: com.entityId
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                color = SurfaceCard,
                border = androidx.compose.foundation.BorderStroke(0.5.dp, BorderSubtle)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${com.id} • $entityName",
                                color = TextIvory,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "Authorized by ${com.authorizedBy} • Date: ${com.commitmentDate}",
                                color = TextSteel,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Committed: ${com.currency.symbol}${String.format(java.util.Locale.UK, "%,.0f", com.committedAmount)}",
                                color = VerifiedEmerald,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Remaining: ${com.currency.symbol}${String.format(java.util.Locale.UK, "%,.0f", com.remainingUndisbursed)}",
                                color = SovereignGold,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    if (com.remainingUndisbursed > 0) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Button(
                                onClick = {
                                    selectedCommitmentForPayment = com
                                    showPaymentModal = true
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = CommandCyan, contentColor = BackgroundObsidian),
                                shape = RoundedCornerShape(4.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.testTag("disburse_tranche_${com.id}")
                            ) {
                                Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Execute Tranche Disbursement", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Section: Payment Instructions Audit
        if (paymentInstructions.isNotEmpty()) {
            item {
                SectionHeader(
                    title = "EXECUTED PAYMENT INSTRUCTIONS",
                    badge = "${paymentInstructions.size} Instructions",
                    badgeColor = CommandCyan
                )
            }

            items(paymentInstructions) { pmt ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(6.dp),
                    color = SurfaceCard,
                    border = androidx.compose.foundation.BorderStroke(0.5.dp, BorderSubtle)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "${pmt.id} • ${pmt.purpose}",
                                color = TextIvory,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Ref: ${pmt.providerReference} • Recipient: ${pmt.targetEntityId}",
                                color = TextSteel,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${pmt.currency.symbol}${String.format(java.util.Locale.UK, "%,.2f", pmt.amount)}",
                                color = if (pmt.isSimulationMode) SimulationPurple else VerifiedEmerald,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = pmt.status.label,
                                color = TextSteel,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }

    if (showPaymentModal && selectedCommitmentForPayment != null) {
        PaymentExecutionDialog(
            commitment = selectedCommitmentForPayment!!,
            accounts = treasuryAccounts.filter { it.entityId == "btc-holdings" },
            isSimulationMode = isSimulationMode,
            onDismiss = {
                showPaymentModal = false
                selectedCommitmentForPayment = null
            },
            onConfirm = { sourceAccId, amount, purpose ->
                onExecutePayment(
                    selectedCommitmentForPayment!!.id,
                    sourceAccId,
                    selectedCommitmentForPayment!!.entityId,
                    amount,
                    selectedCommitmentForPayment!!.currency,
                    purpose
                )
                showPaymentModal = false
                selectedCommitmentForPayment = null
            }
        )
    }
}

@Composable
fun CapitalHeadroomCard(
    parentCashGbp: Double,
    committedUndisbursedGbp: Double,
    availableUncommittedGbp: Double,
    isSimulationMode: Boolean
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        color = SurfaceSlate,
        border = androidx.compose.foundation.BorderStroke(1.dp, SovereignGoldMuted)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "PARENT CAPITAL ALLOCATION ENGINE",
                    color = SovereignGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Box(
                    modifier = Modifier
                        .background(if (isSimulationMode) SimulationPurple.copy(alpha = 0.2f) else VerifiedEmeraldMuted, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (isSimulationMode) "SIMULATION ACTIVE" else "LIVE TREASURY",
                        color = if (isSimulationMode) SimulationPurple else VerifiedEmerald,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TelemetryChip(
                    label = "HOLDING CASH",
                    value = "£${String.format(java.util.Locale.UK, "%,.0f", parentCashGbp)}",
                    valueColor = VerifiedEmerald,
                    modifier = Modifier.weight(1f)
                )
                TelemetryChip(
                    label = "COMMITTED UNDISBURSED",
                    value = "£${String.format(java.util.Locale.UK, "%,.0f", committedUndisbursedGbp)}",
                    valueColor = SovereignGold,
                    modifier = Modifier.weight(1.2f)
                )
                TelemetryChip(
                    label = "NET AVAILABLE",
                    value = "£${String.format(java.util.Locale.UK, "%,.0f", availableUncommittedGbp)}",
                    valueColor = CommandCyan,
                    modifier = Modifier.weight(1.2f)
                )
            }
        }
    }
}

@Composable
fun PaymentExecutionDialog(
    commitment: CapitalCommitment,
    accounts: List<TreasuryAccount>,
    isSimulationMode: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (sourceAccountId: String, amount: Double, purpose: String) -> Unit
) {
    var selectedAccountId by remember { mutableStateOf(accounts.firstOrNull()?.id ?: "") }
    var amountText by remember { mutableStateOf(commitment.remainingUndisbursed.toString()) }
    var purposeText by remember { mutableStateOf("Tranche disbursement for commitment ${commitment.id}") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Review & Authorize Payment", color = TextIvory, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (isSimulationMode) {
                    Text(
                        text = "[SIMULATION MODE] No real banking funds will be transferred. A simulated settlement ref will be recorded.",
                        color = SimulationPurple,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text("Commitment ID: ${commitment.id}", color = SovereignGold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                Text("Target Entity: ${commitment.entityId}", color = CommandCyan, fontSize = 12.sp)

                Spacer(modifier = Modifier.height(4.dp))
                Text("Source Treasury Account:", color = TextSteel, fontSize = 11.sp)
                accounts.forEach { acc ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        RadioButton(
                            selected = selectedAccountId == acc.id,
                            onClick = { selectedAccountId = acc.id }
                        )
                        Column {
                            Text(acc.name, color = TextIvory, fontSize = 11.sp)
                            Text("Balance: £${String.format(java.util.Locale.UK, "%,.2f", acc.balance)}", color = TextSteel, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Transfer Amount (${commitment.currency.code})") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = purposeText,
                    onValueChange = { purposeText = it },
                    label = { Text("Payment Memo / Ledger Purpose") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountText.toDoubleOrNull() ?: 0.0
                    if (amount > 0 && selectedAccountId.isNotBlank()) {
                        onConfirm(selectedAccountId, amount, purposeText)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isSimulationMode) SimulationPurple else VerifiedEmerald,
                    contentColor = BackgroundObsidian
                )
            ) {
                Text(if (isSimulationMode) "Execute Simulated Transfer" else "Release Live Payment", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
        containerColor = SurfaceSlate
    )
}
