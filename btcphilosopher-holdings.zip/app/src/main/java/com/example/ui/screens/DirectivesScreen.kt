package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun DirectivesScreen(
    directives: List<Directive>,
    entities: List<CorporateEntity>,
    onAdvanceStatus: (String, DirectiveStatus, String) -> Unit,
    onCreateDirective: (Directive) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedDirectiveId by remember { mutableStateOf(directives.firstOrNull()?.id) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var selectedPriorityFilter by remember { mutableStateOf<DirectivePriority?>(null) }

    val filteredDirectives = directives.filter {
        selectedPriorityFilter == null || it.priority == selectedPriorityFilter
    }

    val selectedDirective = directives.find { it.id == selectedDirectiveId } ?: directives.firstOrNull()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("directives_screen")
    ) {
        // Top Action Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "DECISIONS & EXECUTIVE DIRECTIVES",
                    color = TextIvory,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Holding Company Mandates • Formal Governance Lifecycle",
                    color = TextSteel,
                    fontSize = 11.sp
                )
            }

            Button(
                onClick = { showCreateDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = SovereignGold, contentColor = BackgroundObsidian),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.testTag("new_directive_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Draft Directive", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Priority filter row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FilterChip(
                selected = selectedPriorityFilter == null,
                onClick = { selectedPriorityFilter = null },
                label = { Text("All Priorities (${directives.size})", fontSize = 10.sp) }
            )
            DirectivePriority.entries.forEach { p ->
                FilterChip(
                    selected = selectedPriorityFilter == p,
                    onClick = { selectedPriorityFilter = p },
                    label = { Text("${p.label} (${directives.count { it.priority == p }})", fontSize = 10.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Two-pane master detail
        Row(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Directives List
            LazyColumn(
                modifier = Modifier
                    .weight(1.1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredDirectives) { dir ->
                    DirectiveItemCard(
                        directive = dir,
                        targetName = entities.find { it.id == dir.targetEntityId }?.name ?: dir.targetEntityId,
                        isSelected = selectedDirective?.id == dir.id,
                        onClick = { selectedDirectiveId = dir.id }
                    )
                }
            }

            // Directive Detail View
            if (selectedDirective != null) {
                Box(
                    modifier = Modifier
                        .weight(1.3f)
                        .fillMaxHeight()
                ) {
                    DirectiveDetailCard(
                        directive = selectedDirective,
                        originatingName = entities.find { it.id == selectedDirective.originatingEntityId }?.name ?: "BTCPhilosopherHoldings",
                        targetName = entities.find { it.id == selectedDirective.targetEntityId }?.name ?: selectedDirective.targetEntityId,
                        onAdvance = { nextStatus, note ->
                            onAdvanceStatus(selectedDirective.id, nextStatus, note)
                        }
                    )
                }
            }
        }
    }

    if (showCreateDialog) {
        CreateDirectiveDialog(
            entities = entities.filter { it.id != "btc-holdings" },
            onDismiss = { showCreateDialog = false },
            onCreate = { newDir ->
                onCreateDirective(newDir)
                showCreateDialog = false
                selectedDirectiveId = newDir.id
            }
        )
    }
}

@Composable
fun DirectiveItemCard(
    directive: Directive,
    targetName: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("directive_card_${directive.id}"),
        shape = RoundedCornerShape(6.dp),
        color = if (isSelected) SurfaceElevated else SurfaceCard,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) SovereignGold else BorderSubtle
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = directive.id,
                    color = SovereignGold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                Box(
                    modifier = Modifier
                        .background(
                            when (directive.status) {
                                DirectiveStatus.COMPLETED, DirectiveStatus.REVIEWED -> VerifiedEmeraldMuted
                                DirectiveStatus.IN_PROGRESS, DirectiveStatus.ACKNOWLEDGED -> CommandCyan.copy(alpha = 0.2f)
                                DirectiveStatus.ISSUED, DirectiveStatus.APPROVED -> SovereignGoldMuted
                                else -> BorderSubtle
                            },
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = directive.status.label,
                        color = when (directive.status) {
                            DirectiveStatus.COMPLETED, DirectiveStatus.REVIEWED -> VerifiedEmerald
                            DirectiveStatus.IN_PROGRESS, DirectiveStatus.ACKNOWLEDGED -> CommandCyan
                            DirectiveStatus.ISSUED, DirectiveStatus.APPROVED -> SovereignGold
                            else -> TextSteel
                        },
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = directive.title,
                color = TextIvory,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Target: $targetName • Deadline: ${directive.deadlineDate}",
                color = TextSteel,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun DirectiveDetailCard(
    directive: Directive,
    originatingName: String,
    targetName: String,
    onAdvance: (DirectiveStatus, String) -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxSize()
            .testTag("directive_detail_pane"),
        shape = RoundedCornerShape(8.dp),
        color = SurfaceSlate,
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = directive.title,
                            color = TextIvory,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "${directive.id} • Priority: ${directive.priority.label}",
                            color = SovereignGold,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(CommandCyan.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            .border(1.dp, CommandCyan, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = directive.status.label,
                            color = CommandCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            item {
                HorizontalDivider(color = BorderSubtle, thickness = 0.5.dp)
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    DetailRow("Originating Authority", originatingName)
                    DetailRow("Target Subsidiary", targetName)
                    DetailRow("Responsible Role", directive.responsibleRole)
                    DetailRow("Effective Date", directive.effectiveDate)
                    DetailRow("Deadline Date", directive.deadlineDate)
                    DetailRow("Budget Authority", "£${String.format(java.util.Locale.UK, "%,.2f", directive.budgetAuthorityGbp)}")
                }
            }

            item {
                Text(
                    text = "FORMAL INSTRUCTION",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = directive.instruction, color = TextIvory, fontSize = 12.sp, lineHeight = 17.sp)
            }

            item {
                Text(
                    text = "BUSINESS RATIONALE",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = directive.businessRationale, color = TextSteel, fontSize = 11.sp, lineHeight = 16.sp)
            }

            if (directive.requiredDeliverables.isNotEmpty()) {
                item {
                    Text(
                        text = "REQUIRED DELIVERABLES",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    directive.requiredDeliverables.forEach { item ->
                        Text(text = "• $item", color = TextIvory, fontSize = 11.sp)
                    }
                }
            }

            if (directive.evidenceOfCompletion != null) {
                item {
                    Text(
                        text = "EVIDENCE OF COMPLETION",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = directive.evidenceOfCompletion, color = VerifiedEmerald, fontSize = 11.sp)
                }
            }

            // Lifecycle Progression Controls
            item {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "LIFECYCLE TRANSITION ACTIONS",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    when (directive.status) {
                        DirectiveStatus.DRAFT, DirectiveStatus.SUBMITTED -> {
                            Button(
                                onClick = { onAdvance(DirectiveStatus.APPROVED, "Executive Board approved directive.") },
                                colors = ButtonDefaults.buttonColors(containerColor = SovereignGold, contentColor = BackgroundObsidian),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text("Approve Directive", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        DirectiveStatus.APPROVED -> {
                            Button(
                                onClick = { onAdvance(DirectiveStatus.ISSUED, "Formally issued to subsidiary lead.") },
                                colors = ButtonDefaults.buttonColors(containerColor = CommandCyan, contentColor = BackgroundObsidian),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text("Issue to Subsidiary", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        DirectiveStatus.ISSUED -> {
                            Button(
                                onClick = { onAdvance(DirectiveStatus.ACKNOWLEDGED, "Subsidiary director acknowledged receipt.") },
                                colors = ButtonDefaults.buttonColors(containerColor = CommandCyan, contentColor = BackgroundObsidian),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text("Record Acknowledgement", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        DirectiveStatus.ACKNOWLEDGED -> {
                            Button(
                                onClick = { onAdvance(DirectiveStatus.IN_PROGRESS, "Execution commenced by project team.") },
                                colors = ButtonDefaults.buttonColors(containerColor = CommandCyan, contentColor = BackgroundObsidian),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text("Mark In Progress", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        DirectiveStatus.IN_PROGRESS -> {
                            Button(
                                onClick = { onAdvance(DirectiveStatus.COMPLETED, "All deliverables submitted and verified.") },
                                colors = ButtonDefaults.buttonColors(containerColor = VerifiedEmerald, contentColor = BackgroundObsidian),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text("Mark Completed", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        DirectiveStatus.COMPLETED -> {
                            Button(
                                onClick = { onAdvance(DirectiveStatus.REVIEWED, "Holding board reviewed and closed directive.") },
                                colors = ButtonDefaults.buttonColors(containerColor = VerifiedEmerald, contentColor = BackgroundObsidian),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text("Final Board Review", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        else -> {
                            Text("Directive is in terminal status: ${directive.status.label}", color = TextSteel, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CreateDirectiveDialog(
    entities: List<CorporateEntity>,
    onDismiss: () -> Unit,
    onCreate: (Directive) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var targetEntityId by remember { mutableStateOf(entities.firstOrNull()?.id ?: "") }
    var instruction by remember { mutableStateOf("") }
    var rationale by remember { mutableStateOf("") }
    var budgetText by remember { mutableStateOf("25000") }
    var priority by remember { mutableStateOf(DirectivePriority.STRATEGIC) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Draft Executive Directive", color = TextIvory, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Directive Title") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Text("Target Subsidiary:", color = TextSteel, fontSize = 11.sp)
                entities.take(4).forEach { ent ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { targetEntityId = ent.id }
                    ) {
                        RadioButton(
                            selected = targetEntityId == ent.id,
                            onClick = { targetEntityId = ent.id }
                        )
                        Text(ent.name, color = TextIvory, fontSize = 11.sp)
                    }
                }

                OutlinedTextField(
                    value = instruction,
                    onValueChange = { instruction = it },
                    label = { Text("Formal Instruction") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )

                OutlinedTextField(
                    value = rationale,
                    onValueChange = { rationale = it },
                    label = { Text("Business Rationale") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )

                OutlinedTextField(
                    value = budgetText,
                    onValueChange = { budgetText = it },
                    label = { Text("Authorized Budget (GBP)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && instruction.isNotBlank()) {
                        val dir = Directive(
                            id = "DIR-2026-${(100..999).random()}",
                            title = title,
                            targetEntityId = targetEntityId,
                            instruction = instruction,
                            businessRationale = rationale,
                            priority = priority,
                            status = DirectiveStatus.APPROVED,
                            effectiveDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.UK).format(java.util.Date()),
                            deadlineDate = "2026-12-31",
                            budgetAuthorityGbp = budgetText.toDoubleOrNull() ?: 0.0,
                            requiredDeliverables = listOf("Core Spec", "Implementation Source", "Review Sign-off")
                        )
                        onCreate(dir)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = SovereignGold, contentColor = BackgroundObsidian)
            ) {
                Text("Issue Directive", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
        containerColor = SurfaceSlate
    )
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = TextSteel, fontSize = 11.sp)
        Text(text = value, color = TextIvory, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Medium)
    }
}
