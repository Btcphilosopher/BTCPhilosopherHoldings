package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Anglo-Futurist Institutional Terminal Palette
val BackgroundObsidian = Color(0xFF090D16)
val SurfaceSlate = Color(0xFF0F172A)
val SurfaceCard = Color(0xFF131D31)
val SurfaceElevated = Color(0xFF1E293B)
val BorderSubtle = Color(0xFF24334C)
val BorderHairline = Color(0xFF334155)

// Typography & Content
val TextIvory = Color(0xFFF8FAFC)
val TextSteel = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Accents & Semantics
val CommandCyan = Color(0xFF38BDF8)
val CommandBlueDark = Color(0xFF0369A1)
val SovereignGold = Color(0xFFF59E0B)
val SovereignGoldMuted = Color(0x33F59E0B)
val VerifiedEmerald = Color(0xFF10B981)
val VerifiedEmeraldMuted = Color(0x2210B981)
val RiskCrimson = Color(0xFFEF4444)
val RiskCrimsonMuted = Color(0x28EF4444)
val BitcoinOrange = Color(0xFFF7931A)
val SimulationPurple = Color(0xFF8B5CF6)
