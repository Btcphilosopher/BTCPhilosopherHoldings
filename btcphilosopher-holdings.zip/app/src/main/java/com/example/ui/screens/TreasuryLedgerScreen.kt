package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.TelemetryChip
import com.example.ui.theme.*

@Composable
fun TreasuryLedgerScreen(
    accounts: List<TreasuryAccount>,
    journals: List<IntercompanyJournalEntry>,
    entities: List<CorporateEntity>,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Treasury Accounts, 1: Intercompany Ledger

    val totalGbpAccounts = accounts.filter { it.currency == Currency.GBP }.sumOf { it.balance }
    val totalBtcReserve = accounts.filter { it.currency == Currency.BTC }.sumOf { it.balance }
    val totalSimulatedUsd = accounts.filter { it.accountType == AccountType.SIMULATED_ACCOUNT }.sumOf { it.balance }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("treasury_ledger_screen")
    ) {
        // Treasury Summary Banner
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            color = SurfaceSlate,
            border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "GROUP TREASURY & INTERCOMPANY LEDGER",
                    color = TextIvory,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Consolidated Accounts • Verified Balances • Double-Entry Reconciliation",
                    color = TextSteel,
                    fontSize = 11.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TelemetryChip(
                        label = "TIER-1 FIAT (GBP)",
                        value = "£${String.format(java.util.Locale.UK, "%,.2f", totalGbpAccounts)}",
                        valueColor = VerifiedEmerald,
                        modifier = Modifier.weight(1.2f)
                    )
                    TelemetryChip(
                        label = "BITCOIN TREASURY",
                        value = "₿${String.format(java.util.Locale.UK, "%.4f", totalBtcReserve)}",
                        valueColor = BitcoinOrange,
                        modifier = Modifier.weight(1.2f)
                    )
                    TelemetryChip(
                        label = "SIMULATED / SYNTHETIC",
                        value = "$${String.format(java.util.Locale.UK, "%,.0f", totalSimulatedUsd)}",
                        valueColor = SimulationPurple,
                        modifier = Modifier.weight(1.2f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Tab selection
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = SurfaceSlate,
            contentColor = CommandCyan,
            divider = {}
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Treasury Accounts (${accounts.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Intercompany Journals (${journals.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (selectedTab == 0) {
            // Treasury Accounts List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(accounts) { acc ->
                    val ownerName = entities.find { it.id == acc.entityId }?.name ?: acc.entityId
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(6.dp),
                        color = SurfaceCard,
                        border = androidx.compose.foundation.BorderStroke(0.5.dp, BorderSubtle)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = when (acc.accountType) {
                                        AccountType.BITCOIN_WALLET -> Icons.Default.CurrencyBitcoin
                                        AccountType.BANK_ACCOUNT -> Icons.Default.AccountBalance
                                        AccountType.SIMULATED_ACCOUNT -> Icons.Default.VpnKey
                                        else -> Icons.Default.ReceiptLong
                                    },
                                    contentDescription = null,
                                    tint = when (acc.accountType) {
                                        AccountType.BITCOIN_WALLET -> BitcoinOrange
                                        AccountType.BANK_ACCOUNT -> VerifiedEmerald
                                        AccountType.SIMULATED_ACCOUNT -> SimulationPurple
                                        else -> CommandCyan
                                    },
                                    modifier = Modifier.size(22.dp)
                                )

                                Spacer(modifier = Modifier.width(10.dp))

                                Column {
                                    Text(
                                        text = acc.name,
                                        color = TextIvory,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = "$ownerName • ${acc.institution} • ${acc.accountNumberMasked}",
                                        color = TextSteel,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = "Updated: ${acc.lastUpdated}",
                                        color = TextMuted,
                                        fontSize = 9.sp
                                    )
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = if (acc.currency == Currency.BTC) "₿${acc.balance}" else "${acc.currency.symbol}${String.format(java.util.Locale.UK, "%,.2f", acc.balance)}",
                                    color = if (acc.accountType == AccountType.SIMULATED_ACCOUNT) SimulationPurple else TextIvory,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    fontFamily = FontFamily.Monospace
                                )

                                Box(
                                    modifier = Modifier
                                        .background(
                                            when (acc.verificationStatus) {
                                                BalanceVerificationStatus.VERIFIED_ONLINE, BalanceVerificationStatus.BITCOIN_ONCHAIN -> VerifiedEmeraldMuted
                                                BalanceVerificationStatus.STATEMENT_IMPORTED -> CommandCyan.copy(alpha = 0.15f)
                                                BalanceVerificationStatus.SIMULATED_TEST -> SimulationPurple.copy(alpha = 0.2f)
                                                else -> SovereignGoldMuted
                                            },
                                            RoundedCornerShape(4.dp)
                                        )
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = acc.verificationStatus.label,
                                        color = when (acc.verificationStatus) {
                                            BalanceVerificationStatus.VERIFIED_ONLINE, BalanceVerificationStatus.BITCOIN_ONCHAIN -> VerifiedEmerald
                                            BalanceVerificationStatus.STATEMENT_IMPORTED -> CommandCyan
                                            BalanceVerificationStatus.SIMULATED_TEST -> SimulationPurple
                                            else -> SovereignGold
                                        },
                                        fontSize = 8.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Intercompany Double-Entry Journals List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(journals) { jnl ->
                    val originatingName = entities.find { it.id == jnl.originatingEntityId }?.name ?: jnl.originatingEntityId
                    val counterpartyName = entities.find { it.id == jnl.counterpartyEntityId }?.name ?: jnl.counterpartyEntityId

                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(6.dp),
                        color = SurfaceCard,
                        border = androidx.compose.foundation.BorderStroke(0.5.dp, BorderSubtle)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${jnl.id} • ${jnl.transactionType.label}",
                                    color = SovereignGold,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )

                                Text(
                                    text = "${jnl.currency.symbol}${String.format(java.util.Locale.UK, "%,.2f", jnl.amount)}",
                                    color = TextIvory,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = jnl.description,
                                color = TextIvory,
                                fontSize = 11.sp
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Origin: $originatingName → Target: $counterpartyName",
                                    color = CommandCyan,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "Balanced Double-Entry: YES [Eliminated]",
                                    color = VerifiedEmerald,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(
                                text = "Debit: ${jnl.debitAccount} | Credit: ${jnl.creditAccount}",
                                color = TextMuted,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}
