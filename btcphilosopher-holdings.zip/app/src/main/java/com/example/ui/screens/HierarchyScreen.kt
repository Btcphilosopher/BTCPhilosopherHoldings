package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun HierarchyScreen(
    entities: List<CorporateEntity>,
    directives: List<Directive>,
    ipAssets: List<IpAsset>,
    selectedEntityId: String?,
    onSelectEntity: (String) -> Unit,
    onUpdateEntity: (CorporateEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    val filteredEntities = entities.filter {
        it.name.contains(searchQuery, ignoreCase = true) ||
        it.description.contains(searchQuery, ignoreCase = true) ||
        it.tags.any { tag -> tag.contains(searchQuery, ignoreCase = true) }
    }

    val selectedEntity = entities.find { it.id == selectedEntityId } ?: entities.firstOrNull()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("hierarchy_screen")
    ) {
        // Search bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("entity_search_field"),
            placeholder = { Text("Filter subsidiaries, brands, divisions...", fontSize = 12.sp, color = TextMuted) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSteel) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = CommandCyan,
                unfocusedBorderColor = BorderSubtle,
                focusedTextColor = TextIvory,
                unfocusedTextColor = TextIvory,
                focusedContainerColor = SurfaceCard,
                unfocusedContainerColor = SurfaceCard
            ),
            shape = RoundedCornerShape(6.dp),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Left pane: Corporate Tree List
            LazyColumn(
                modifier = Modifier
                    .weight(1.1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Group Parent Node
                val parentNode = entities.find { it.parentId == null }
                if (parentNode != null && (searchQuery.isEmpty() || filteredEntities.contains(parentNode))) {
                    item {
                        Text(
                            text = "HOLDING COMPANY EXECUTIVE LEVEL",
                            color = TextMuted,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        EntityTreeNodeCard(
                            entity = parentNode,
                            isSelected = selectedEntity?.id == parentNode.id,
                            depth = 0,
                            onClick = { onSelectEntity(parentNode.id) }
                        )
                    }
                }

                // First tier subsidiaries
                val firstTier = filteredEntities.filter { it.parentId == "btc-holdings" }
                if (firstTier.isNotEmpty()) {
                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "PRINCIPAL SUBSIDIARIES & PLC NODES",
                            color = TextMuted,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    items(firstTier) { sub ->
                        EntityTreeNodeCard(
                            entity = sub,
                            isSelected = selectedEntity?.id == sub.id,
                            depth = 1,
                            onClick = { onSelectEntity(sub.id) }
                        )

                        // If it has children (e.g. Duke Satoshi), render sub-nodes indented
                        val children = filteredEntities.filter { it.parentId == sub.id }
                        children.forEach { child ->
                            EntityTreeNodeCard(
                                entity = child,
                                isSelected = selectedEntity?.id == child.id,
                                depth = 2,
                                onClick = { onSelectEntity(child.id) }
                            )
                        }
                    }
                }
            }

            // Right pane: Entity Institutional Inspector
            if (selectedEntity != null) {
                Box(
                    modifier = Modifier
                        .weight(1.3f)
                        .fillMaxHeight()
                ) {
                    EntityInspectorPane(
                        entity = selectedEntity,
                        directives = directives.filter { it.targetEntityId == selectedEntity.id },
                        ipAssets = ipAssets.filter { it.custodianEntityId == selectedEntity.id },
                        parentName = entities.find { it.id == selectedEntity.parentId }?.name,
                        onUpdateVerification = { newStatus ->
                            onUpdateEntity(selectedEntity.copy(verificationStatus = newStatus))
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun EntityTreeNodeCard(
    entity: CorporateEntity,
    isSelected: Boolean,
    depth: Int,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = (depth * 14).dp)
            .clickable { onClick() }
            .testTag("entity_node_${entity.id}"),
        shape = RoundedCornerShape(6.dp),
        color = if (isSelected) SurfaceElevated else SurfaceCard,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) CommandCyan else BorderSubtle
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = when (entity.type) {
                    EntityType.HOLDING_COMPANY -> Icons.Default.Shield
                    EntityType.SUBSIDIARY -> Icons.Default.Business
                    EntityType.RESEARCH_DIVISION -> Icons.Default.Science
                    EntityType.DIVISION -> Icons.Default.Folder
                    EntityType.VENTURE -> Icons.Default.TrendingUp
                    EntityType.PRODUCT_LINE -> Icons.Default.Code
                    EntityType.BRAND_TRADING_NAME -> Icons.Default.Bookmark
                },
                contentDescription = null,
                tint = if (isSelected) CommandCyan else SovereignGold,
                modifier = Modifier.size(16.dp)
            )

            Spacer(modifier = Modifier.width(8.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = entity.name,
                    color = if (isSelected) TextIvory else TextIvory.copy(alpha = 0.9f),
                    fontSize = 12.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    maxLines = 1
                )
                Text(
                    text = "${entity.targetOwnershipPercent.toInt()}% • ${entity.type.label}",
                    color = TextSteel,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Box(
                modifier = Modifier
                    .background(
                        when (entity.verificationStatus) {
                            VerificationStatus.VERIFIED -> VerifiedEmeraldMuted
                            VerificationStatus.USER_DECLARED -> CommandCyan.copy(alpha = 0.15f)
                            VerificationStatus.PENDING_VERIFICATION -> SovereignGoldMuted
                            else -> BorderSubtle
                        },
                        RoundedCornerShape(4.dp)
                    )
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                Text(
                    text = when (entity.verificationStatus) {
                        VerificationStatus.VERIFIED -> "VERIFIED"
                        VerificationStatus.USER_DECLARED -> "DECLARED"
                        VerificationStatus.PENDING_VERIFICATION -> "PENDING"
                        else -> "OTHER"
                    },
                    color = when (entity.verificationStatus) {
                        VerificationStatus.VERIFIED -> VerifiedEmerald
                        VerificationStatus.USER_DECLARED -> CommandCyan
                        VerificationStatus.PENDING_VERIFICATION -> SovereignGold
                        else -> TextSteel
                    },
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun EntityInspectorPane(
    entity: CorporateEntity,
    directives: List<Directive>,
    ipAssets: List<IpAsset>,
    parentName: String?,
    onUpdateVerification: (VerificationStatus) -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxSize()
            .testTag("entity_inspector_pane"),
        shape = RoundedCornerShape(8.dp),
        color = SurfaceSlate,
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = entity.name,
                            color = TextIvory,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = entity.legalName ?: entity.name,
                            color = TextSteel,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(VerifiedEmeraldMuted, RoundedCornerShape(4.dp))
                            .border(1.dp, VerifiedEmerald, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${entity.targetOwnershipPercent}% OWNERSHIP",
                            color = VerifiedEmerald,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            item {
                HorizontalDivider(color = BorderSubtle, thickness = 0.5.dp)
            }

            // Core Profile Grid
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    InspectorRow("Classification", entity.type.label)
                    InspectorRow("Parent Authority", parentName ?: "Self (Supreme Parent Layer)")
                    InspectorRow("Jurisdiction", entity.jurisdiction)
                    InspectorRow("Executive Lead", entity.executiveLead)
                    InspectorRow("Verification Status", entity.verificationStatus.label)
                    InspectorRow("Voting Rights", "${entity.votingRightsPercent}%")
                }
            }

            // Description
            item {
                Text(
                    text = "BUSINESS MANDATE & SCOPE",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = entity.description,
                    color = TextIvory,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }

            // Capital & Budget Position
            item {
                Text(
                    text = "CAPITAL ALLOCATION POSITION",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    BudgetStatBox(
                        label = "AUTH BUDGET",
                        value = "£${String.format(java.util.Locale.UK, "%,.0f", entity.authorizedBudgetGbp)}",
                        valueColor = TextIvory,
                        modifier = Modifier.weight(1f)
                    )
                    BudgetStatBox(
                        label = "ALLOCATED",
                        value = "£${String.format(java.util.Locale.UK, "%,.0f", entity.allocatedCapitalGbp)}",
                        valueColor = SovereignGold,
                        modifier = Modifier.weight(1f)
                    )
                    BudgetStatBox(
                        label = "EXPENDITURE",
                        value = "£${String.format(java.util.Locale.UK, "%,.0f", entity.spentCapitalGbp)}",
                        valueColor = CommandCyan,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Repository Provenance Link
            if (entity.repositoryPath != null) {
                item {
                    Text(
                        text = "REPOSITORY PROVENANCE",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SurfaceCard, RoundedCornerShape(4.dp))
                            .border(0.5.dp, BorderHairline, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = entity.repositoryPath,
                            color = CommandCyan,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            // Active Directives for this entity
            item {
                Text(
                    text = "ACTIVE DIRECTIVES (${directives.size})",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(4.dp))
                if (directives.isEmpty()) {
                    Text("No active mandates pending.", color = TextSteel, fontSize = 11.sp)
                } else {
                    directives.forEach { dir ->
                        Text(
                            text = "• [${dir.id}] ${dir.title} (${dir.status.label})",
                            color = TextIvory,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            // IP Assets
            item {
                Text(
                    text = "INTELLECTUAL PROPERTY (${ipAssets.size})",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(4.dp))
                if (ipAssets.isEmpty()) {
                    Text("No registered IP assets assigned.", color = TextSteel, fontSize = 11.sp)
                } else {
                    ipAssets.forEach { ip ->
                        Text(
                            text = "• ${ip.name} [${ip.type.label}]",
                            color = SovereignGold,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            // Verification Status Selector
            item {
                Text(
                    text = "UPDATE VERIFICATION GOVERNANCE",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(VerificationStatus.VERIFIED, VerificationStatus.USER_DECLARED, VerificationStatus.PENDING_VERIFICATION).forEach { st ->
                        FilterChip(
                            selected = entity.verificationStatus == st,
                            onClick = { onUpdateVerification(st) },
                            label = { Text(st.label, fontSize = 9.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CommandCyan,
                                selectedLabelColor = BackgroundObsidian
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun InspectorRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = TextSteel, fontSize = 11.sp)
        Text(text = value, color = TextIvory, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun BudgetStatBox(
    label: String,
    value: String,
    valueColor: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(SurfaceCard, RoundedCornerShape(4.dp))
            .border(0.5.dp, BorderSubtle, RoundedCornerShape(4.dp))
            .padding(6.dp)
    ) {
        Column {
            Text(text = label, color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            Text(text = value, color = valueColor, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
    }
}
