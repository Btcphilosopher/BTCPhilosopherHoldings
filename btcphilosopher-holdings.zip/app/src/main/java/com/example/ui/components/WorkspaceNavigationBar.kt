package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.TerminalWorkspace
import com.example.ui.theme.*

@Composable
fun WorkspaceNavigationBar(
    currentWorkspace: TerminalWorkspace,
    onSelectWorkspace: (TerminalWorkspace) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("workspace_navigation_bar"),
        color = SurfaceSlate,
        tonalElevation = 3.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TerminalWorkspace.entries.forEach { ws ->
                val isSelected = currentWorkspace == ws
                val icon = getWorkspaceIcon(ws)

                Button(
                    onClick = { onSelectWorkspace(ws) },
                    modifier = Modifier
                        .height(38.dp)
                        .testTag("nav_item_${ws.name.lowercase()}"),
                    shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) CommandCyan else SurfaceCard,
                        contentColor = if (isSelected) BackgroundObsidian else TextSteel
                    ),
                    border = if (isSelected) null else androidx.compose.foundation.BorderStroke(0.5.dp, BorderHairline),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = ws.title,
                        modifier = Modifier.size(15.dp),
                        tint = if (isSelected) BackgroundObsidian else TextSteel
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = ws.shortLabel,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }
    }
}

private fun getWorkspaceIcon(workspace: TerminalWorkspace): ImageVector {
    return when (workspace) {
        TerminalWorkspace.COMMAND -> Icons.Default.Dashboard
        TerminalWorkspace.HIERARCHY -> Icons.Default.AccountTree
        TerminalWorkspace.DIRECTIVES -> Icons.Default.Gavel
        TerminalWorkspace.CAPITAL -> Icons.Default.AccountBalance
        TerminalWorkspace.TREASURY -> Icons.Default.AccountBalanceWallet
        TerminalWorkspace.RESEARCH -> Icons.Default.Science
        TerminalWorkspace.IP_REGISTRY -> Icons.Default.Memory
        TerminalWorkspace.RISK_GOVERNANCE -> Icons.Default.Shield
        TerminalWorkspace.AUDIT_LOG -> Icons.Default.History
    }
}
