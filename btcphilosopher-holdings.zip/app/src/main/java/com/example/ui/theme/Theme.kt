package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = CommandCyan,
    onPrimary = BackgroundObsidian,
    primaryContainer = CommandBlueDark,
    onPrimaryContainer = TextIvory,
    secondary = SovereignGold,
    onSecondary = BackgroundObsidian,
    secondaryContainer = SovereignGoldMuted,
    onSecondaryContainer = SovereignGold,
    tertiary = VerifiedEmerald,
    background = BackgroundObsidian,
    onBackground = TextIvory,
    surface = SurfaceSlate,
    onSurface = TextIvory,
    surfaceVariant = SurfaceCard,
    onSurfaceVariant = TextSteel,
    outline = BorderSubtle,
    outlineVariant = BorderHairline,
    error = RiskCrimson,
    onError = TextIvory
)

@Composable
fun BTCPhilosopherTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
