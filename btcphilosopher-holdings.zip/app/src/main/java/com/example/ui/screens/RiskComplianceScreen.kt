package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun RiskComplianceScreen(
    risks: List<RiskItem>,
    entities: List<CorporateEntity>,
    modifier: Modifier = Modifier
) {
    var selectedCategoryFilter by remember { mutableStateOf<RiskCategory?>(null) }

    val filtered = risks.filter {
        selectedCategoryFilter == null || it.category == selectedCategoryFilter
    }

    val criticalCount = risks.count { it.isCritical }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("risk_compliance_screen")
    ) {
        // Risk Header
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            color = SurfaceSlate,
            border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = RiskCrimson,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "CORPORATE RISK & GOVERNANCE REGISTER",
                            color = TextIvory,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(if (criticalCount > 0) RiskCrimsonMuted else VerifiedEmeraldMuted, RoundedCornerShape(4.dp))
                            .border(1.dp, if (criticalCount > 0) RiskCrimson else VerifiedEmerald, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "$criticalCount CRITICAL RISKS",
                            color = if (criticalCount > 0) RiskCrimson else VerifiedEmerald,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Matrix of corporate, liquidity, regulatory, and engineering risks across holding subsidiaries and R&D divisions.",
                    color = TextSteel,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Category Filter Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FilterChip(
                selected = selectedCategoryFilter == null,
                onClick = { selectedCategoryFilter = null },
                label = { Text("All Categories (${risks.size})", fontSize = 10.sp) }
            )
            listOf(RiskCategory.ENGINEERING_SAFETY, RiskCategory.REGULATORY_COMPLIANCE, RiskCategory.IP_OWNERSHIP, RiskCategory.LIQUIDITY_TREASURY).forEach { cat ->
                FilterChip(
                    selected = selectedCategoryFilter == cat,
                    onClick = { selectedCategoryFilter = cat },
                    label = { Text(cat.label, fontSize = 10.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Risk Items List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filtered) { risk ->
                val entityName = entities.find { it.id == risk.entityId }?.name ?: risk.entityId
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(6.dp),
                    color = SurfaceCard,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (risk.isCritical) RiskCrimson.copy(alpha = 0.5f) else BorderSubtle
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (risk.isCritical) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = RiskCrimson,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                }
                                Text(
                                    text = risk.title,
                                    color = TextIvory,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .background(
                                        if (risk.isCritical) RiskCrimsonMuted else SovereignGoldMuted,
                                        RoundedCornerShape(4.dp)
                                    )
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "SCORE: ${risk.inherentScore} (L${risk.likelihood} × I${risk.impact})",
                                    color = if (risk.isCritical) RiskCrimson else SovereignGold,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "$entityName • ${risk.category.label} • Owner: ${risk.ownerRole}",
                            color = CommandCyan,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = risk.description,
                            color = TextSteel,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SurfaceSlate, RoundedCornerShape(4.dp))
                                .border(0.5.dp, BorderHairline, RoundedCornerShape(4.dp))
                                .padding(8.dp)
                        ) {
                            Column {
                                Text(
                                    text = "ACTIVE MITIGATION PLAN",
                                    color = VerifiedEmerald,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = risk.mitigationPlan,
                                    color = TextIvory,
                                    fontSize = 11.sp,
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
