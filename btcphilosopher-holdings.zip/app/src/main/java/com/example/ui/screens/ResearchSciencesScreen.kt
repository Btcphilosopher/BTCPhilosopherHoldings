package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun ResearchSciencesScreen(
    programmes: List<ResearchProgramme>,
    onUpdateStatus: (String, ResearchStatus) -> Unit,
    onAugmentBudget: (String, Double) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategoryFilter by remember { mutableStateOf<ResearchCategory?>(null) }
    var selectedProgrammeId by remember { mutableStateOf(programmes.firstOrNull()?.id) }

    val filtered = programmes.filter {
        selectedCategoryFilter == null || it.category == selectedCategoryFilter
    }

    val selectedProgramme = programmes.find { it.id == selectedProgrammeId } ?: programmes.firstOrNull()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("research_sciences_screen")
    ) {
        // Division Header
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            color = SurfaceSlate,
            border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Science,
                            contentDescription = null,
                            tint = SovereignGold,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "THEORETICAL & APPLIED SCIENCES DIVISION",
                            color = TextIvory,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(CommandCyan.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "DUKE SATOSHI PLC R&D LAYER",
                            color = CommandCyan,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Executive oversight of Quantum Research, Advanced Complexity, Semiconductor Big-Chips, and Industry 4.0 Cyber-Physical Systems.",
                    color = TextSteel,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Category Filter Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FilterChip(
                selected = selectedCategoryFilter == null,
                onClick = { selectedCategoryFilter = null },
                label = { Text("All Disciplines (${programmes.size})", fontSize = 10.sp) }
            )
            listOf(ResearchCategory.QUANTUM_CRYPTOGRAPHY, ResearchCategory.ADVANCED_COMPUTING, ResearchCategory.INDUSTRY_4_0, ResearchCategory.SEMICONDUCTORS).forEach { cat ->
                FilterChip(
                    selected = selectedCategoryFilter == cat,
                    onClick = { selectedCategoryFilter = cat },
                    label = { Text(cat.label, fontSize = 10.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Two-pane master detail
        Row(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Programmes List
            LazyColumn(
                modifier = Modifier
                    .weight(1.1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filtered) { prog ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedProgrammeId = prog.id },
                        shape = RoundedCornerShape(6.dp),
                        color = if (selectedProgramme?.id == prog.id) SurfaceElevated else SurfaceCard,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (selectedProgramme?.id == prog.id) SovereignGold else BorderSubtle
                        )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = prog.id,
                                    color = SovereignGold,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = prog.status.label,
                                    color = when (prog.status) {
                                        ResearchStatus.ACTIVE_PROGRAMME -> VerifiedEmerald
                                        ResearchStatus.AWAITING_DECISION -> SovereignGold
                                        else -> TextSteel
                                    },
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = prog.title,
                                color = TextIvory,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = "${prog.category.label} • ${prog.maturity.label}",
                                color = CommandCyan,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            // Programme Detail
            if (selectedProgramme != null) {
                Box(
                    modifier = Modifier
                        .weight(1.3f)
                        .fillMaxHeight()
                ) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        shape = RoundedCornerShape(8.dp),
                        color = SurfaceSlate,
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle)
                    ) {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            item {
                                Text(
                                    text = selectedProgramme.title,
                                    color = TextIvory,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "${selectedProgramme.id} • Lead: ${selectedProgramme.researchLead}",
                                    color = TextSteel,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            item {
                                HorizontalDivider(color = BorderSubtle, thickness = 0.5.dp)
                            }

                            item {
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    DetailRow("Category", selectedProgramme.category.label)
                                    DetailRow("Scientific Maturity", selectedProgramme.maturity.label)
                                    DetailRow("Authorized Budget", "£${String.format(java.util.Locale.UK, "%,.0f", selectedProgramme.budgetGbp)}")
                                    DetailRow("Actual Expenditure", "£${String.format(java.util.Locale.UK, "%,.0f", selectedProgramme.actualExpenditureGbp)}")
                                    DetailRow("IP / Publication Status", selectedProgramme.publicationOrIpStatus)
                                }
                            }

                            item {
                                Text(
                                    text = "CENTRAL RESEARCH QUESTION",
                                    color = TextMuted,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = selectedProgramme.researchQuestion, color = TextIvory, fontSize = 12.sp, lineHeight = 17.sp)
                            }

                            item {
                                Text(
                                    text = "VALIDATION CRITERIA & METHODOLOGY",
                                    color = TextMuted,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = selectedProgramme.validationCriteria, color = CommandCyan, fontSize = 11.sp, lineHeight = 16.sp)
                            }

                            if (selectedProgramme.githubPath != null) {
                                item {
                                    Text(
                                        text = "REPOSITORY PROVENANCE PATH",
                                        color = TextMuted,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(SurfaceCard, RoundedCornerShape(4.dp))
                                            .padding(8.dp)
                                    ) {
                                        Text(text = selectedProgramme.githubPath, color = TextSteel, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                    }
                                }
                            }

                            item {
                                Text(
                                    text = "LATEST SCIENTIFIC RESULTS",
                                    color = TextMuted,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = selectedProgramme.resultsSummary, color = VerifiedEmerald, fontSize = 11.sp, lineHeight = 16.sp)
                            }

                            // Holding Governance Actions
                            item {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "HOLDING GOVERNANCE ACTIONS",
                                    color = TextMuted,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Button(
                                        onClick = { onAugmentBudget(selectedProgramme.id, 25000.0) },
                                        colors = ButtonDefaults.buttonColors(containerColor = SovereignGold, contentColor = BackgroundObsidian),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text("+£25k Tranche", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }

                                    if (selectedProgramme.status != ResearchStatus.FUNDING_PAUSED) {
                                        OutlinedButton(
                                            onClick = { onUpdateStatus(selectedProgramme.id, ResearchStatus.FUNDING_PAUSED) },
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = SovereignGold),
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text("Pause Funding", fontSize = 10.sp)
                                        }
                                    } else {
                                        Button(
                                            onClick = { onUpdateStatus(selectedProgramme.id, ResearchStatus.ACTIVE_PROGRAMME) },
                                            colors = ButtonDefaults.buttonColors(containerColor = VerifiedEmerald, contentColor = BackgroundObsidian),
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text("Resume Funding", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    Button(
                                        onClick = { onUpdateStatus(selectedProgramme.id, ResearchStatus.COMMERCIALISED) },
                                        colors = ButtonDefaults.buttonColors(containerColor = CommandCyan, contentColor = BackgroundObsidian),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text("Authorize Spin-out", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
