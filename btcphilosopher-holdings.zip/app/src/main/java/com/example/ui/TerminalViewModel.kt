package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CommandActionProposal
import com.example.data.GroupRepository
import com.example.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class TerminalWorkspace(val title: String, val shortLabel: String) {
    COMMAND("Executive Command", "Command"),
    HIERARCHY("Corporate Structure", "Structure"),
    DIRECTIVES("Decisions & Directives", "Directives"),
    CAPITAL("Capital Allocation", "Capital"),
    TREASURY("Treasury & Ledger", "Treasury"),
    RESEARCH("Research & Sciences", "Sciences"),
    IP_REGISTRY("Intellectual Property", "IP"),
    RISK_GOVERNANCE("Risk & Governance", "Risk"),
    AUDIT_LOG("Audit & Reports", "Audit")
}

data class ExecutiveReport(
    val title: String,
    val generatedDate: String,
    val totalEntities: Int,
    val totalTreasuryGbp: Double,
    val totalBtcReserve: Double,
    val totalAllocatedCapitalGbp: Double,
    val activeDirectivesCount: Int,
    val criticalRisksCount: Int,
    val researchProgrammesCount: Int,
    val textSummary: String
)

class TerminalViewModel(
    val repository: GroupRepository = GroupRepository()
) : ViewModel() {

    private val _currentWorkspace = MutableStateFlow(TerminalWorkspace.COMMAND)
    val currentWorkspace: StateFlow<TerminalWorkspace> = _currentWorkspace.asStateFlow()

    private val _selectedEntityId = MutableStateFlow<String?>("btc-holdings")
    val selectedEntityId: StateFlow<String?> = _selectedEntityId.asStateFlow()

    private val _commandInput = MutableStateFlow("")
    val commandInput: StateFlow<String> = _commandInput.asStateFlow()

    private val _activeCommandProposal = MutableStateFlow<CommandActionProposal?>(null)
    val activeCommandProposal: StateFlow<CommandActionProposal?> = _activeCommandProposal.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _generatedReport = MutableStateFlow<ExecutiveReport?>(null)
    val generatedReport: StateFlow<ExecutiveReport?> = _generatedReport.asStateFlow()

    // Navigation
    fun navigateTo(workspace: TerminalWorkspace) {
        _currentWorkspace.value = workspace
    }

    fun selectEntity(entityId: String?) {
        _selectedEntityId.value = entityId
    }

    fun setCommandInput(input: String) {
        _commandInput.value = input
    }

    fun submitCommand() {
        val query = _commandInput.value.trim()
        if (query.isEmpty()) return
        val proposal = repository.parseCommand(query)
        _activeCommandProposal.value = proposal
        _commandInput.value = ""
    }

    fun dismissCommandProposal() {
        _activeCommandProposal.value = null
    }

    fun executeProposal(proposal: CommandActionProposal) {
        when (proposal) {
            is CommandActionProposal.ProposeDirective -> {
                val dir = Directive(
                    id = "DIR-2026-${(100..999).random()}",
                    title = proposal.title,
                    targetEntityId = proposal.targetEntityId,
                    instruction = proposal.instruction,
                    businessRationale = "Executive command directive authorized via Terminal",
                    effectiveDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.UK).format(java.util.Date()),
                    deadlineDate = "2026-12-31",
                    budgetAuthorityGbp = proposal.budget,
                    status = DirectiveStatus.ISSUED,
                    requiredDeliverables = listOf("Core Component Source", "Architecture Spec", "Test Suite")
                )
                repository.createDirective(dir)
                _toastMessage.value = "Directive ${dir.id} successfully created and issued."
            }
            is CommandActionProposal.ProposeCapitalAllocation -> {
                val req = FundingRequest(
                    id = "FR-2026-${(100..999).random()}",
                    requestingEntityId = proposal.targetEntityId,
                    recipientEntityId = proposal.targetEntityId,
                    projectOrProgramme = "Terminal Capital Allocation",
                    requestedAmount = proposal.amount,
                    currency = proposal.currency,
                    fundingType = FundingType.CAPITAL_EXPENDITURE,
                    purpose = proposal.purpose,
                    businessCase = "Approved by Holding Executive via terminal command.",
                    status = FundingRequestStatus.PENDING_REVIEW,
                    submissionDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.UK).format(java.util.Date()),
                    requiredByDate = "2026-11-15"
                )
                repository.submitFundingRequest(req)
                _toastMessage.value = "Capital allocation request ${req.id} created."
            }
            is CommandActionProposal.ProposeSimulationToggle -> {
                repository.toggleSimulationMode(proposal.enableSimulation)
                _toastMessage.value = if (proposal.enableSimulation) "Simulation Mode Active (Safe Sandbox)" else "Simulation Mode Disabled (Live Mode)"
            }
            is CommandActionProposal.DirectQuery -> {
                // Read-only, no action needed
            }
        }
        _activeCommandProposal.value = null
    }

    fun approveFunding(requestId: String) {
        val result = repository.approveFundingRequest(requestId)
        result.onSuccess {
            _toastMessage.value = "Commitment ${it.id} approved for ${it.currency.symbol}${it.committedAmount}"
        }.onFailure {
            _toastMessage.value = "Approval failed: ${it.message}"
        }
    }

    fun rejectFunding(requestId: String, reason: String = "Declined by Executive Committee") {
        repository.rejectFundingRequest(requestId, reason)
        _toastMessage.value = "Funding request $requestId rejected."
    }

    fun executePayment(
        commitmentId: String?,
        sourceAccountId: String,
        targetEntityId: String,
        amount: Double,
        currency: Currency,
        purpose: String
    ) {
        val isSim = repository.isSimulationMode.value
        val result = repository.executePaymentInstruction(
            commitmentId, sourceAccountId, targetEntityId, amount, currency, purpose, isSim
        )
        result.onSuccess {
            _toastMessage.value = "Payment ${it.id} ${if (isSim) "[SIMULATED]" else "[SETTLED]"}: ${it.providerReference}"
        }.onFailure {
            _toastMessage.value = "Execution blocked: ${it.message}"
        }
    }

    fun advanceDirectiveStatus(directiveId: String, nextStatus: DirectiveStatus, note: String) {
        repository.updateDirectiveStatus(directiveId, nextStatus, note)
        _toastMessage.value = "Directive $directiveId updated to ${nextStatus.label}"
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun generateExecutiveConsolidatedReport() {
        val entities = repository.entities.value
        val accounts = repository.treasuryAccounts.value
        val directives = repository.directives.value
        val risks = repository.risks.value
        val research = repository.researchProgrammes.value

        val totalGbp = accounts.filter { it.currency == Currency.GBP }.sumOf { it.balance }
        val totalBtc = accounts.filter { it.currency == Currency.BTC }.sumOf { it.balance }
        val totalAllocated = entities.sumOf { it.allocatedCapitalGbp }
        val activeDirs = directives.count { it.status in listOf(DirectiveStatus.ISSUED, DirectiveStatus.IN_PROGRESS, DirectiveStatus.UNDER_REVIEW) }
        val criticalRisks = risks.count { it.isCritical }

        val summary = buildString {
            appendLine("BTCPhilosopherHoldings — Consolidated Executive Report")
            appendLine("Reporting Timestamp: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'GMT'", java.util.Locale.UK).format(java.util.Date())}")
            appendLine("==================================================")
            appendLine("1. CORPORATE STRUCTURE")
            appendLine("   Total Registered Entities: ${entities.size}")
            appendLine("   - Wholly Owned (100% Target): ${entities.count { it.targetOwnershipPercent == 100.0 }}")
            appendLine("   - Verified Records: ${entities.count { it.verificationStatus == VerificationStatus.VERIFIED }}")
            appendLine("   - User-Declared: ${entities.count { it.verificationStatus == VerificationStatus.USER_DECLARED }}")
            appendLine("   - Pending Verification: ${entities.count { it.verificationStatus == VerificationStatus.PENDING_VERIFICATION }}")
            appendLine()
            appendLine("2. CONSOLIDATED TREASURY & LIQUIDITY")
            appendLine("   - Fiat Cash (GBP Equivalents): £${String.format(java.util.Locale.UK, "%,.2f", totalGbp)}")
            appendLine("   - Strategic Bitcoin Reserve: ₿${String.format(java.util.Locale.UK, "%.4f", totalBtc)}")
            appendLine("   - Group Allocated Capital: £${String.format(java.util.Locale.UK, "%,.2f", totalAllocated)}")
            appendLine("   - Intercompany Eliminations: All internal loan & fee balances fully reconciled and eliminated.")
            appendLine()
            appendLine("3. GOVERNANCE & EXECUTION")
            appendLine("   - Active Directives: $activeDirs")
            appendLine("   - Critical Risks Under Monitoring: $criticalRisks")
            appendLine("   - Scientific & Research Programmes: ${research.size}")
            appendLine()
            appendLine("4. STATUS NOTE")
            appendLine("   All figures derived strictly from current connected accounts and verified ledgers. No synthetic projections treated as cash.")
        }

        _generatedReport.value = ExecutiveReport(
            title = "BTCPhilosopherHoldings Executive Pack",
            generatedDate = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.UK).format(java.util.Date()),
            totalEntities = entities.size,
            totalTreasuryGbp = totalGbp,
            totalBtcReserve = totalBtc,
            totalAllocatedCapitalGbp = totalAllocated,
            activeDirectivesCount = activeDirs,
            criticalRisksCount = criticalRisks,
            researchProgrammesCount = research.size,
            textSummary = summary
        )
    }

    fun dismissReport() {
        _generatedReport.value = null
    }
}
