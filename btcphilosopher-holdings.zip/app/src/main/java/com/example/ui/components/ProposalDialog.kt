package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.CommandActionProposal
import com.example.ui.theme.*

@Composable
fun ProposalDialog(
    proposal: CommandActionProposal,
    onConfirm: (CommandActionProposal) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("proposal_dialog"),
            shape = RoundedCornerShape(12.dp),
            color = SurfaceSlate,
            border = androidx.compose.foundation.BorderStroke(1.dp, BorderHairline)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                when (proposal) {
                    is CommandActionProposal.DirectQuery -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = CommandCyan,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = proposal.title,
                                color = TextIvory,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 340.dp)
                                .background(SurfaceCard, RoundedCornerShape(6.dp))
                                .border(0.5.dp, BorderSubtle, RoundedCornerShape(6.dp))
                                .padding(12.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                text = proposal.message,
                                color = TextIvory,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 18.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = onDismiss,
                            modifier = Modifier
                                .align(Alignment.End)
                                .testTag("dismiss_query_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = CommandCyan, contentColor = BackgroundObsidian),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("Acknowledge", fontWeight = FontWeight.Bold)
                        }
                    }

                    is CommandActionProposal.ProposeDirective -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = SovereignGold,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Review Proposed Directive",
                                color = TextIvory,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Executive mandate awaiting authorization:",
                            color = TextSteel,
                            fontSize = 12.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SurfaceCard, RoundedCornerShape(6.dp))
                                .border(0.5.dp, SovereignGoldMuted, RoundedCornerShape(6.dp))
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = proposal.title,
                                    color = SovereignGold,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "Target: ${proposal.targetEntityId}",
                                    color = CommandCyan,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "Budget Authority: £${String.format(java.util.Locale.UK, "%,.2f", proposal.budget)}",
                                    color = VerifiedEmerald,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = proposal.instruction,
                                    color = TextIvory,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            OutlinedButton(
                                onClick = onDismiss,
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSteel),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text("Cancel")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = { onConfirm(proposal) },
                                colors = ButtonDefaults.buttonColors(containerColor = SovereignGold, contentColor = BackgroundObsidian),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.testTag("confirm_directive_button")
                            ) {
                                Text("Authorize Directive", fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    is CommandActionProposal.ProposeCapitalAllocation -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = VerifiedEmerald,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Review Capital Allocation Proposal",
                                color = TextIvory,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SurfaceCard, RoundedCornerShape(6.dp))
                                .border(0.5.dp, BorderSubtle, RoundedCornerShape(6.dp))
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "Recipient Entity: ${proposal.targetEntityId}",
                                    color = CommandCyan,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "Proposed Amount: ${proposal.currency.symbol}${String.format(java.util.Locale.UK, "%,.2f", proposal.amount)} (${proposal.currency.code})",
                                    color = VerifiedEmerald,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "Purpose: ${proposal.purpose}",
                                    color = TextIvory,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = "Requires Investment Committee review and available authorized cash check before commitment is recorded.",
                                    color = TextSteel,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            OutlinedButton(
                                onClick = onDismiss,
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSteel),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text("Cancel")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = { onConfirm(proposal) },
                                colors = ButtonDefaults.buttonColors(containerColor = VerifiedEmerald, contentColor = BackgroundObsidian),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.testTag("confirm_capital_button")
                            ) {
                                Text("Submit Funding Request", fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    is CommandActionProposal.ProposeSimulationToggle -> {
                        Text(
                            text = if (proposal.enableSimulation) "Enable Simulation Mode" else "Disable Simulation Mode",
                            color = TextIvory,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (proposal.enableSimulation)
                                "Simulation mode prevents any actual funds or live settlements from occurring. All payment instructions and ledger postings will be tagged [SIMULATED]."
                            else
                                "CAUTION: Disabling simulation mode switches the terminal to live financial execution mode. External API transactions will attempt live network settlement.",
                            color = if (proposal.enableSimulation) TextSteel else SovereignGold,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            OutlinedButton(onClick = onDismiss, shape = RoundedCornerShape(6.dp)) {
                                Text("Cancel")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = { onConfirm(proposal) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (proposal.enableSimulation) SimulationPurple else SovereignGold,
                                    contentColor = BackgroundObsidian
                                ),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(if (proposal.enableSimulation) "Switch to Simulation" else "Confirm Live Mode", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
