package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun CommandPromptBar(
    commandInput: String,
    onInputChange: (String) -> Unit,
    onSubmit: () -> Unit,
    modifier: Modifier = Modifier
) {
    val suggestedCommands = listOf(
        "Show all companies and their ownership",
        "List every funding request awaiting my approval",
        "Prepare a capital allocation proposal of £25,000 for Newton Rockets",
        "Compare the budgets for Rhino Bank and Aureom.AI",
        "Show research projects awaiting review",
        "Draft a directive for London Kotlin Works",
        "Show uncommitted capital by subsidiary",
        "Toggle simulation mode"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(SurfaceSlate)
            .border(0.5.dp, BorderSubtle, RoundedCornerShape(8.dp))
            .padding(12.dp)
            .testTag("command_prompt_bar")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Terminal,
                contentDescription = "Command Prompt",
                tint = CommandCyan,
                modifier = Modifier.size(20.dp)
            )

            Spacer(modifier = Modifier.width(8.dp))

            OutlinedTextField(
                value = commandInput,
                onValueChange = onInputChange,
                modifier = Modifier
                    .weight(1f)
                    .testTag("command_input_field"),
                placeholder = {
                    Text(
                        "Issue directive, allocate capital, or query group ledger...",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CommandCyan,
                    unfocusedBorderColor = BorderSubtle,
                    focusedTextColor = TextIvory,
                    unfocusedTextColor = TextIvory,
                    focusedContainerColor = SurfaceCard,
                    unfocusedContainerColor = SurfaceCard
                ),
                shape = RoundedCornerShape(6.dp)
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = onSubmit,
                modifier = Modifier
                    .background(CommandCyan, RoundedCornerShape(6.dp))
                    .size(44.dp)
                    .testTag("submit_command_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Submit Command",
                    tint = BackgroundObsidian,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Suggested Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            suggestedCommands.forEach { suggestion ->
                SuggestionChip(
                    onClick = {
                        onInputChange(suggestion)
                    },
                    label = {
                        Text(
                            suggestion,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextSteel
                        )
                    },
                    colors = SuggestionChipDefaults.suggestionChipColors(
                        containerColor = SurfaceCard
                    ),
                    border = SuggestionChipDefaults.suggestionChipBorder(
                        enabled = true,
                        borderColor = BorderHairline
                    ),
                    shape = RoundedCornerShape(4.dp)
                )
            }
        }
    }
}
