package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.TerminalWorkspace
import com.example.ui.theme.*

@Composable
fun CommandOverviewScreen(
    entities: List<CorporateEntity>,
    directives: List<Directive>,
    fundingRequests: List<FundingRequest>,
    commitments: List<CapitalCommitment>,
    accounts: List<TreasuryAccount>,
    risks: List<RiskItem>,
    research: List<ResearchProgramme>,
    onNavigateWorkspace: (TerminalWorkspace) -> Unit,
    onSelectEntity: (String) -> Unit,
    onApproveFunding: (String) -> Unit,
    onRejectFunding: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val pendingFunding = fundingRequests.filter { it.status == FundingRequestStatus.PENDING_REVIEW }
    val activeDirectives = directives.filter { it.status in listOf(DirectiveStatus.ISSUED, DirectiveStatus.ACKNOWLEDGED, DirectiveStatus.IN_PROGRESS, DirectiveStatus.UNDER_REVIEW) }
    val criticalRisks = risks.filter { it.isCritical }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("command_overview_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Holding Authority Banner
        item {
            ExecutiveAuthorityCard(
                parentEntity = entities.find { it.id == "btc-holdings" },
                totalSubsidiaries = entities.count { it.parentId != null },
                onInspectHierarchy = { onNavigateWorkspace(TerminalWorkspace.HIERARCHY) }
            )
        }

        // Pending Decisions & Funding Requests
        item {
            SectionHeader(
                title = "GOVERNANCE DECISIONS & FUNDING REQUESTS",
                badge = "${pendingFunding.size} Awaiting Approval",
                badgeColor = if (pendingFunding.isNotEmpty()) SovereignGold else TextMuted
            )
        }

        if (pendingFunding.isEmpty()) {
            item {
                EmptyStateCard("No pending funding requests. All subsidiary capital applications are processed.")
            }
        } else {
            items(pendingFunding) { req ->
                FundingRequestApprovalCard(
                    request = req,
                    requestingEntityName = entities.find { it.id == req.requestingEntityId }?.name ?: req.requestingEntityId,
                    onApprove = { onApproveFunding(req.id) },
                    onReject = { onRejectFunding(req.id) }
                )
            }
        }

        // Active Directives & Mandates
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionHeader(
                    title = "ACTIVE EXECUTIVE DIRECTIVES",
                    badge = "${activeDirectives.size} Under Execution",
                    badgeColor = CommandCyan
                )
                TextButton(onClick = { onNavigateWorkspace(TerminalWorkspace.DIRECTIVES) }) {
                    Text("View All Directives", fontSize = 11.sp, color = CommandCyan)
                }
            }
        }

        items(activeDirectives.take(3)) { dir ->
            ActiveDirectiveSummaryCard(
                directive = dir,
                targetEntityName = entities.find { it.id == dir.targetEntityId }?.name ?: dir.targetEntityId,
                onClick = { onNavigateWorkspace(TerminalWorkspace.DIRECTIVES) }
            )
        }

        // Research & Sciences Highlights
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionHeader(
                    title = "THEORETICAL & APPLIED SCIENCES PIPELINE",
                    badge = "${research.size} Programmes",
                    badgeColor = SovereignGold
                )
                TextButton(onClick = { onNavigateWorkspace(TerminalWorkspace.RESEARCH) }) {
                    Text("Enter Science Division", fontSize = 11.sp, color = SovereignGold)
                }
            }
        }

        items(research.take(2)) { res ->
            ScienceOverviewCard(
                programme = res,
                onClick = { onNavigateWorkspace(TerminalWorkspace.RESEARCH) }
            )
        }

        // Material Risks
        if (criticalRisks.isNotEmpty()) {
            item {
                SectionHeader(
                    title = "CRITICAL CORPORATE RISK REGISTER",
                    badge = "${criticalRisks.size} Monitored",
                    badgeColor = RiskCrimson
                )
            }
            items(criticalRisks) { rsk ->
                CriticalRiskSummaryCard(
                    risk = rsk,
                    entityName = entities.find { it.id == rsk.entityId }?.name ?: rsk.entityId,
                    onClick = { onNavigateWorkspace(TerminalWorkspace.RISK_GOVERNANCE) }
                )
            }
        }
    }
}

@Composable
fun ExecutiveAuthorityCard(
    parentEntity: CorporateEntity?,
    totalSubsidiaries: Int,
    onInspectHierarchy: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("executive_authority_card"),
        shape = RoundedCornerShape(10.dp),
        color = SurfaceSlate,
        border = androidx.compose.foundation.BorderStroke(1.dp, SovereignGoldMuted)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = SovereignGold,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = parentEntity?.name ?: "BTCPhilosopherHoldings",
                        color = TextIvory,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
                Box(
                    modifier = Modifier
                        .background(VerifiedEmeraldMuted, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "EXECUTIVE AUTHORITY",
                        color = VerifiedEmerald,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Governing Layer: One Holding Company → Governed Corporate Hierarchy → Subsidiaries → Research & Projects → Authorized Capital & Directives.",
                color = TextSteel,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$totalSubsidiaries Controlled Subsidiaries & Operating Divisions",
                    color = CommandCyan,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )

                TextButton(
                    onClick = onInspectHierarchy,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text("Inspect Hierarchy", fontSize = 11.sp, color = SovereignGold)
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = SovereignGold,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    badge: String,
    badgeColor: androidx.compose.ui.graphics.Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            color = TextSteel,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 0.5.sp
        )
        Box(
            modifier = Modifier
                .background(badgeColor.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                .border(0.5.dp, badgeColor, RoundedCornerShape(4.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Text(
                text = badge,
                color = badgeColor,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun FundingRequestApprovalCard(
    request: FundingRequest,
    requestingEntityName: String,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("funding_card_${request.id}"),
        shape = RoundedCornerShape(8.dp),
        color = SurfaceCard,
        border = androidx.compose.foundation.BorderStroke(1.dp, SovereignGold.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = request.projectOrProgramme,
                        color = TextIvory,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "$requestingEntityName • ${request.fundingType.label}",
                        color = CommandCyan,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Text(
                    text = "${request.currency.symbol}${String.format(java.util.Locale.UK, "%,.0f", request.requestedAmount)}",
                    color = SovereignGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = request.purpose,
                color = TextSteel,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onReject,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = RiskCrimson),
                    shape = RoundedCornerShape(4.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("reject_${request.id}")
                ) {
                    Text("Reject", fontSize = 11.sp)
                }

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = onApprove,
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignGold, contentColor = BackgroundObsidian),
                    shape = RoundedCornerShape(4.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("approve_${request.id}")
                ) {
                    Text("Approve & Commit", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ActiveDirectiveSummaryCard(
    directive: Directive,
    targetEntityName: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(8.dp),
        color = SurfaceCard,
        border = androidx.compose.foundation.BorderStroke(0.5.dp, BorderSubtle)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(
                        when (directive.priority) {
                            DirectivePriority.CRITICAL -> RiskCrimson
                            DirectivePriority.URGENT -> SovereignGold
                            else -> CommandCyan
                        },
                        RoundedCornerShape(4.dp)
                    )
            )

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = directive.title,
                    color = TextIvory,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Target: $targetEntityName • Deadline: ${directive.deadlineDate}",
                    color = TextSteel,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Box(
                modifier = Modifier
                    .background(BorderSubtle, RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = directive.status.label,
                    color = TextIvory,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun ScienceOverviewCard(
    programme: ResearchProgramme,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(8.dp),
        color = SurfaceCard,
        border = androidx.compose.foundation.BorderStroke(0.5.dp, BorderSubtle)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = programme.title,
                    color = TextIvory,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "£${String.format(java.util.Locale.UK, "%,.0f", programme.budgetGbp)}",
                    color = SovereignGold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Text(
                text = "${programme.category.label} • ${programme.maturity.label}",
                color = CommandCyan,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = programme.resultsSummary,
                color = TextSteel,
                fontSize = 11.sp,
                maxLines = 2
            )
        }
    }
}

@Composable
fun CriticalRiskSummaryCard(
    risk: RiskItem,
    entityName: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(8.dp),
        color = SurfaceCard,
        border = androidx.compose.foundation.BorderStroke(1.dp, RiskCrimson.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = null,
                tint = RiskCrimson,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = risk.title,
                    color = TextIvory,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "$entityName • Inherent Score: ${risk.inherentScore} (Likelihood ${risk.likelihood} × Impact ${risk.impact})",
                    color = RiskCrimson,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun EmptyStateCard(message: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(SurfaceCard, RoundedCornerShape(8.dp))
            .border(0.5.dp, BorderHairline, RoundedCornerShape(8.dp))
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = message,
            color = TextSteel,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}
