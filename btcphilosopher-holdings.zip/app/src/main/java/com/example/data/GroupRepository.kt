package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

sealed class CommandActionProposal {
    data class DirectQuery(val title: String, val message: String, val targetEntityId: String? = null) : CommandActionProposal()
    data class ProposeDirective(val title: String, val targetEntityId: String, val instruction: String, val budget: Double) : CommandActionProposal()
    data class ProposeCapitalAllocation(val targetEntityId: String, val amount: Double, val currency: Currency, val purpose: String) : CommandActionProposal()
    data class ProposeSimulationToggle(val enableSimulation: Boolean) : CommandActionProposal()
}

class GroupRepository {

    private val _entities = MutableStateFlow<List<CorporateEntity>>(emptyList())
    val entities: StateFlow<List<CorporateEntity>> = _entities.asStateFlow()

    private val _directives = MutableStateFlow<List<Directive>>(emptyList())
    val directives: StateFlow<List<Directive>> = _directives.asStateFlow()

    private val _fundingRequests = MutableStateFlow<List<FundingRequest>>(emptyList())
    val fundingRequests: StateFlow<List<FundingRequest>> = _fundingRequests.asStateFlow()

    private val _commitments = MutableStateFlow<List<CapitalCommitment>>(emptyList())
    val commitments: StateFlow<List<CapitalCommitment>> = _commitments.asStateFlow()

    private val _paymentInstructions = MutableStateFlow<List<PaymentInstruction>>(emptyList())
    val paymentInstructions: StateFlow<List<PaymentInstruction>> = _paymentInstructions.asStateFlow()

    private val _treasuryAccounts = MutableStateFlow<List<TreasuryAccount>>(emptyList())
    val treasuryAccounts: StateFlow<List<TreasuryAccount>> = _treasuryAccounts.asStateFlow()

    private val _intercompanyJournals = MutableStateFlow<List<IntercompanyJournalEntry>>(emptyList())
    val intercompanyJournals: StateFlow<List<IntercompanyJournalEntry>> = _intercompanyJournals.asStateFlow()

    private val _researchProgrammes = MutableStateFlow<List<ResearchProgramme>>(emptyList())
    val researchProgrammes: StateFlow<List<ResearchProgramme>> = _researchProgrammes.asStateFlow()

    private val _ipAssets = MutableStateFlow<List<IpAsset>>(emptyList())
    val ipAssets: StateFlow<List<IpAsset>> = _ipAssets.asStateFlow()

    private val _risks = MutableStateFlow<List<RiskItem>>(emptyList())
    val risks: StateFlow<List<RiskItem>> = _risks.asStateFlow()

    private val _auditEvents = MutableStateFlow<List<AuditEvent>>(emptyList())
    val auditEvents: StateFlow<List<AuditEvent>> = _auditEvents.asStateFlow()

    private val _isSimulationMode = MutableStateFlow(true)
    val isSimulationMode: StateFlow<Boolean> = _isSimulationMode.asStateFlow()

    init {
        seedInitialRegistry()
    }

    private fun seedInitialRegistry() {
        val initialEntities = listOf(
            CorporateEntity(
                id = "btc-holdings",
                name = "BTCPhilosopherHoldings",
                legalName = "BTCPhilosopher Holdings Limited",
                type = EntityType.HOLDING_COMPANY,
                parentId = null,
                targetOwnershipPercent = 100.0,
                actualRecordedPercent = 100.0,
                votingRightsPercent = 100.0,
                verificationStatus = VerificationStatus.VERIFIED,
                jurisdiction = "United Kingdom",
                executiveLead = "Principal Executive Authority",
                description = "Group parent holding company and capital allocation executive layer. Oversees governance, strategic mandates, subsidiaries, treasury & R&D.",
                repositoryPath = "https://github.com/Btcphilosopher/BTCPhilosopherHoldings",
                authorizedBudgetGbp = 10000000.0,
                allocatedCapitalGbp = 2850000.0,
                spentCapitalGbp = 1120000.0,
                tags = listOf("Parent", "Treasury", "Executive Command", "UK-Registered")
            ),
            CorporateEntity(
                id = "ellan-vannin",
                name = "Ellan Vannin",
                legalName = "Ellan Vannin Wealth Management Ltd.",
                type = EntityType.SUBSIDIARY,
                parentId = "btc-holdings",
                targetOwnershipPercent = 100.0,
                actualRecordedPercent = 100.0,
                votingRightsPercent = 100.0,
                verificationStatus = VerificationStatus.USER_DECLARED,
                jurisdiction = "Isle of Man / UK",
                executiveLead = "Senior Wealth Strategist",
                description = "Institutional wealth management, sovereign-wealth finance, government-blockchain frameworks, and hydrogen energy market initiatives.",
                repositoryPath = "https://github.com/Btcphilosopher/BTCPhilosopherHoldings/blob/main/hydrogenlighter.sf",
                authorizedBudgetGbp = 1500000.0,
                allocatedCapitalGbp = 450000.0,
                spentCapitalGbp = 180000.0,
                tags = listOf("Sovereign Wealth", "Hydrogen", "Institutional Finance")
            ),
            CorporateEntity(
                id = "rhino-bank",
                name = "Rhino Bank",
                legalName = "Rhino Financial Technologies & Quant Portfolio",
                type = EntityType.SUBSIDIARY,
                parentId = "btc-holdings",
                targetOwnershipPercent = 100.0,
                actualRecordedPercent = 100.0,
                votingRightsPercent = 100.0,
                verificationStatus = VerificationStatus.USER_DECLARED,
                jurisdiction = "United Kingdom",
                executiveLead = "Chief Quantitative Strategist",
                description = "Institutional financial-market infrastructure, RhinoQuant quantitative risk engines, synthetic commodities, energy derivatives & fixed income terminals.",
                repositoryPath = "https://github.com/Btcphilosopher/BTCPhilosopherHoldings/tree/main/DukeSatoshiofCyberspace%20PLC/AgriTech/rhinoquant---british-agricultural-commodity-market.zip",
                authorizedBudgetGbp = 2200000.0,
                allocatedCapitalGbp = 800000.0,
                spentCapitalGbp = 340000.0,
                tags = listOf("RhinoQuant", "Synthetic Commodities", "Derivatives", "Fixed Income")
            ),
            CorporateEntity(
                id = "aureom-ai",
                name = "Aureom.AI",
                legalName = "Aureom AI Technologies Ltd.",
                type = EntityType.SUBSIDIARY,
                parentId = "btc-holdings",
                targetOwnershipPercent = 100.0,
                actualRecordedPercent = 100.0,
                votingRightsPercent = 100.0,
                verificationStatus = VerificationStatus.VERIFIED,
                jurisdiction = "United Kingdom",
                executiveLead = "Head of AI Engineering",
                description = "Group AI software and product development. Proprietary camera engines (16K digital twin), autonomous vision, and enterprise neural toolsets.",
                repositoryPath = "https://github.com/Btcphilosopher/BTCPhilosopherHoldings/tree/main/Aurora%20Lux%20Inc./Camera.OS",
                authorizedBudgetGbp = 1800000.0,
                allocatedCapitalGbp = 650000.0,
                spentCapitalGbp = 290000.0,
                tags = listOf("AI Systems", "Camera.OS", "Computer Vision", "Software Products")
            ),
            CorporateEntity(
                id = "duke-satoshi",
                name = "Duke Satoshi of Cyberspace PLC",
                legalName = "Duke Satoshi of Cyberspace PLC",
                type = EntityType.SUBSIDIARY,
                parentId = "btc-holdings",
                targetOwnershipPercent = 100.0,
                actualRecordedPercent = 100.0,
                votingRightsPercent = 100.0,
                verificationStatus = VerificationStatus.VERIFIED,
                jurisdiction = "United Kingdom",
                executiveLead = "Managing Director, PLC",
                description = "Major corporate node and industrial holding umbrella for deep-tech, cryptography, aerospace, advanced materials, and applied sciences.",
                repositoryPath = "https://github.com/Btcphilosopher/BTCPhilosopherHoldings/tree/main/DukeSatoshiofCyberspace%20PLC",
                authorizedBudgetGbp = 5000000.0,
                allocatedCapitalGbp = 1950000.0,
                spentCapitalGbp = 820000.0,
                tags = listOf("Major Node", "Deep Tech", "PLC Umbrella")
            ),
            // Duke Satoshi child nodes:
            CorporateEntity(
                id = "duke-agritech",
                name = "AgriTech",
                legalName = "British AgriSpot CEA Systems",
                type = EntityType.DIVISION,
                parentId = "duke-satoshi",
                targetOwnershipPercent = 100.0,
                actualRecordedPercent = 100.0,
                votingRightsPercent = 100.0,
                verificationStatus = VerificationStatus.VERIFIED,
                jurisdiction = "United Kingdom",
                executiveLead = "Director of Agricultural Systems",
                description = "Controlled Environment Agriculture (CEA), precision farm logistics (BritAgri Logistics OS), and agricultural commodity exchange modelling.",
                repositoryPath = "https://github.com/Btcphilosopher/BTCPhilosopherHoldings/tree/main/DukeSatoshiofCyberspace%20PLC/AgriTech",
                authorizedBudgetGbp = 600000.0,
                allocatedCapitalGbp = 200000.0,
                spentCapitalGbp = 95000.0,
                tags = listOf("AgriSpot", "CEA", "Logistics OS")
            ),
            CorporateEntity(
                id = "duke-london-cipher",
                name = "LONDON CIPHER",
                legalName = "London Cipher Defense & Cryptography Ltd.",
                type = EntityType.SUBSIDIARY,
                parentId = "duke-satoshi",
                targetOwnershipPercent = 100.0,
                actualRecordedPercent = 100.0,
                votingRightsPercent = 100.0,
                verificationStatus = VerificationStatus.VERIFIED,
                jurisdiction = "United Kingdom",
                executiveLead = "Chief Cryptographer",
                description = "Advanced cybersecurity, quantum-resistant cryptographic algorithms, zero-knowledge proofs, and secure infrastructure protocols.",
                repositoryPath = "https://github.com/Btcphilosopher/BTCPhilosopherHoldings/tree/main/DukeSatoshiofCyberspace%20PLC/LONDON%20CIPHER",
                authorizedBudgetGbp = 750000.0,
                allocatedCapitalGbp = 320000.0,
                spentCapitalGbp = 140000.0,
                tags = listOf("Cryptography", "Cyber Defense", "Zero-Knowledge")
            ),
            CorporateEntity(
                id = "duke-manchester-interchain",
                name = "Manchester Interchain",
                legalName = "Manchester Interchain Protocols Ltd.",
                type = EntityType.SUBSIDIARY,
                parentId = "duke-satoshi",
                targetOwnershipPercent = 100.0,
                actualRecordedPercent = 100.0,
                votingRightsPercent = 100.0,
                verificationStatus = VerificationStatus.USER_DECLARED,
                jurisdiction = "United Kingdom",
                executiveLead = "Protocol Architect",
                description = "Cross-chain interoperability, distributed consensus systems, decentralized settlement networks, and interchain data communication.",
                repositoryPath = "https://github.com/Btcphilosopher/BTCPhilosopherHoldings/tree/main/DukeSatoshiofCyberspace%20PLC/Manchester%20Interchain",
                authorizedBudgetGbp = 500000.0,
                allocatedCapitalGbp = 180000.0,
                spentCapitalGbp = 72000.0,
                tags = listOf("Interchain", "Cross-Chain", "Distributed Protocols")
            ),
            CorporateEntity(
                id = "aurora-lux",
                name = "Aurora Lux Inc.",
                legalName = "Aurora Lux Digital Manufacturing Inc.",
                type = EntityType.SUBSIDIARY,
                parentId = "duke-satoshi",
                targetOwnershipPercent = 100.0,
                actualRecordedPercent = 100.0,
                votingRightsPercent = 100.0,
                verificationStatus = VerificationStatus.VERIFIED,
                jurisdiction = "Delaware, USA / UK",
                executiveLead = "VP of Digital Fabrication",
                description = "Digital additive manufacturing, Aardvark 3D print twin, high-precision industrial camera arrays, hyperspectral imaging, and CGIX rendering engines.",
                repositoryPath = "https://github.com/Btcphilosopher/BTCPhilosopherHoldings/tree/main/Aurora%20Lux%20Inc.",
                authorizedBudgetGbp = 900000.0,
                allocatedCapitalGbp = 380000.0,
                spentCapitalGbp = 160000.0,
                tags = listOf("3D Printing", "Digital Twins", "Camera Array", "Aardvark")
            ),
            CorporateEntity(
                id = "drink-two",
                name = "Drink Two Interactive",
                legalName = "Drink Two Interactive Studios Ltd.",
                type = EntityType.SUBSIDIARY,
                parentId = "duke-satoshi",
                targetOwnershipPercent = 100.0,
                actualRecordedPercent = 100.0,
                votingRightsPercent = 100.0,
                verificationStatus = VerificationStatus.USER_DECLARED,
                jurisdiction = "United Kingdom",
                executiveLead = "Creative Director",
                description = "Interactive media, entertainment software, real-time simulation engines, Arcadium gaming suites, and digital intellectual property.",
                repositoryPath = "https://github.com/Btcphilosopher/BTCPhilosopherHoldings/tree/main/Drink%20Two%20Interactive",
                authorizedBudgetGbp = 400000.0,
                allocatedCapitalGbp = 120000.0,
                spentCapitalGbp = 54000.0,
                tags = listOf("Interactive Media", "Arcadium", "Game Engines")
            ),
            CorporateEntity(
                id = "duke-newton-rockets",
                name = "Newton Rockets LTD.",
                legalName = "Newton Rockets Propulsion Systems LTD.",
                type = EntityType.SUBSIDIARY,
                parentId = "duke-satoshi",
                targetOwnershipPercent = 100.0,
                actualRecordedPercent = 100.0,
                votingRightsPercent = 100.0,
                verificationStatus = VerificationStatus.PENDING_VERIFICATION,
                jurisdiction = "United Kingdom",
                executiveLead = "Aerospace Chief Engineer",
                description = "Propulsion engineering, aerodynamic simulation software, spacecraft structural dynamics, and VTOL flight computing platforms.",
                repositoryPath = "https://github.com/Btcphilosopher/BTCPhilosopherHoldings/tree/main/DukeSatoshiofCyberspace%20PLC/Newton%20Rockets%20LTD.",
                authorizedBudgetGbp = 1200000.0,
                allocatedCapitalGbp = 350000.0,
                spentCapitalGbp = 145000.0,
                tags = listOf("Aerospace", "Propulsion", "VTOL.OS", "Simulation")
            ),
            CorporateEntity(
                id = "duke-sun-king",
                name = "Sun King Ltd.",
                legalName = "Sun King Clean Energy Solutions Ltd.",
                type = EntityType.SUBSIDIARY,
                parentId = "duke-satoshi",
                targetOwnershipPercent = 100.0,
                actualRecordedPercent = 100.0,
                votingRightsPercent = 100.0,
                verificationStatus = VerificationStatus.USER_DECLARED,
                jurisdiction = "United Kingdom",
                executiveLead = "Director of Renewable Energy",
                description = "Solar photovoltaic infrastructure, distributed microgrid deployment, energy storage systems, and renewable asset financial engineering.",
                repositoryPath = "https://github.com/Btcphilosopher/BTCPhilosopherHoldings/tree/main/DukeSatoshiofCyberspace%20PLC/Sun%20King%20Ltd.",
                authorizedBudgetGbp = 650000.0,
                allocatedCapitalGbp = 150000.0,
                spentCapitalGbp = 60000.0,
                tags = listOf("Solar", "Renewable Power", "Clean Energy")
            ),
            CorporateEntity(
                id = "duke-watt-a-bank",
                name = "Watt A Bank + Partners",
                legalName = "Watt A Bank Infrastructure Finance Ltd.",
                type = EntityType.SUBSIDIARY,
                parentId = "duke-satoshi",
                targetOwnershipPercent = 100.0,
                actualRecordedPercent = 100.0,
                votingRightsPercent = 100.0,
                verificationStatus = VerificationStatus.USER_DECLARED,
                jurisdiction = "United Kingdom",
                executiveLead = "Infrastructure Finance Lead",
                description = "Energy market technology, grid-scale asset financing, structured debt syndication for utilities, and industrial power underwriting.",
                repositoryPath = "https://github.com/Btcphilosopher/BTCPhilosopherHoldings/tree/main/DukeSatoshiofCyberspace%20PLC/Watt%20A%20Bank%20%2B%20Partners",
                authorizedBudgetGbp = 700000.0,
                allocatedCapitalGbp = 210000.0,
                spentCapitalGbp = 80000.0,
                tags = listOf("Energy Finance", "Grid Underwriting", "Infrastructure")
            ),
            CorporateEntity(
                id = "duke-london-kotlin",
                name = "London Kotlin Works",
                legalName = "London Kotlin Works Ltd.",
                type = EntityType.DIVISION,
                parentId = "duke-satoshi",
                targetOwnershipPercent = 100.0,
                actualRecordedPercent = 100.0,
                votingRightsPercent = 100.0,
                verificationStatus = VerificationStatus.VERIFIED,
                jurisdiction = "United Kingdom",
                executiveLead = "Principal Systems Engineer",
                description = "Kotlin Multiplatform development, core Android & desktop command terminals, internal developer tooling, and shared UI libraries.",
                repositoryPath = "https://github.com/Btcphilosopher/BTCPhilosopherHoldings/tree/main/DukeSatoshiofCyberspace%20PLC",
                authorizedBudgetGbp = 450000.0,
                allocatedCapitalGbp = 175000.0,
                spentCapitalGbp = 90000.0,
                tags = listOf("Kotlin", "Android", "Shared Architecture", "Compose")
            ),
            CorporateEntity(
                id = "duke-hydrogrid",
                name = "HydroGrid",
                legalName = "HydroGrid Britain Infrastructure Ltd.",
                type = EntityType.DIVISION,
                parentId = "duke-satoshi",
                targetOwnershipPercent = 100.0,
                actualRecordedPercent = 100.0,
                votingRightsPercent = 100.0,
                verificationStatus = VerificationStatus.VERIFIED,
                jurisdiction = "United Kingdom",
                executiveLead = "Hydrogen Infrastructure Director",
                description = "UK Hydrogen corridor economics, H2-IGNITION.OS, clean hydrogen supply logistics, and Humber decarbonisation pipeline.",
                repositoryPath = "https://github.com/Btcphilosopher/BTCPhilosopherHoldings/tree/main/DukeSatoshiofCyberspace%20PLC/HydroGrid",
                authorizedBudgetGbp = 850000.0,
                allocatedCapitalGbp = 290000.0,
                spentCapitalGbp = 110000.0,
                tags = listOf("Hydrogen", "H2UK", "Clean Supply", "Humber Corridor")
            ),
            CorporateEntity(
                id = "duke-theoretical-sciences",
                name = "Theoretical and Applied Sciences Division",
                legalName = "Duke Satoshi Scientific & Advanced Computing Division",
                type = EntityType.RESEARCH_DIVISION,
                parentId = "duke-satoshi",
                targetOwnershipPercent = 100.0,
                actualRecordedPercent = 100.0,
                votingRightsPercent = 100.0,
                verificationStatus = VerificationStatus.VERIFIED,
                jurisdiction = "United Kingdom",
                executiveLead = "Chief Scientific Officer",
                description = "Quantum computing algorithms, quantum-cryptographic file transfer systems, P vs NP computational complexity, 6G telecomms, and Industry 4.0 robotics.",
                repositoryPath = "https://github.com/Btcphilosopher/BTCPhilosopherHoldings/tree/main/DukeSatoshiofCyberspace%20PLC/Theoretical%20and%20Applied%20Sciences%20Division",
                authorizedBudgetGbp = 1500000.0,
                allocatedCapitalGbp = 580000.0,
                spentCapitalGbp = 210000.0,
                tags = listOf("Quantum", "Industry 4.0", "Robotics", "P vs NP", "Semiconductors")
            ),
            CorporateEntity(
                id = "rocketman-enterprises",
                name = "Rocketman Enterprises",
                legalName = "Rocketman Enterprises (Agorist Venture)",
                type = EntityType.VENTURE,
                parentId = "btc-holdings",
                targetOwnershipPercent = 100.0,
                actualRecordedPercent = 100.0,
                votingRightsPercent = 100.0,
                verificationStatus = VerificationStatus.USER_DECLARED,
                jurisdiction = "Private Commercial Jurisdiction",
                executiveLead = "Venture Lead",
                description = "Agorist commercial enterprise, voluntary peer-to-peer commerce, Bitcoin treasury mechanisms, counter-economic software experiments, and private trading portfolios.",
                repositoryPath = "https://github.com/Btcphilosopher/BTCPhilosopherHoldings",
                authorizedBudgetGbp = 800000.0,
                allocatedCapitalGbp = 220000.0,
                spentCapitalGbp = 85000.0,
                tags = listOf("Agorist", "Bitcoin Native", "P2P Commerce", "Private Enterprise")
            )
        )
        _entities.value = initialEntities

        // Seed Directives
        val initialDirectives = listOf(
            Directive(
                id = "DIR-2026-001",
                title = "Standardize Shared Terminal Interface & Core Architecture",
                targetEntityId = "duke-london-kotlin",
                instruction = "Develop and deliver the unified executive command terminal and shared UI components across all holding subsidiaries.",
                businessRationale = "Eliminate redundant frontends, standardize reporting schemas, and ensure edge-to-edge Android/desktop parity.",
                priority = DirectivePriority.STRATEGIC,
                status = DirectiveStatus.IN_PROGRESS,
                effectiveDate = "2026-10-01",
                deadlineDate = "2026-11-15",
                budgetAuthorityGbp = 45000.0,
                responsibleRole = "Principal Systems Engineer",
                requiredDeliverables = listOf("Executive Terminal App", "Centralized Theme System", "Offline Repository Layer"),
                successCriteria = "Flawless compilation, sub-300ms transitions, real test coverage.",
                revisions = listOf(
                    DirectiveRevision(System.currentTimeMillis() - 86400000L * 10, "Executive Committee", "Directive drafted and approved", DirectiveStatus.DRAFT, DirectiveStatus.APPROVED),
                    DirectiveRevision(System.currentTimeMillis() - 86400000L * 8, "Holding Exec", "Issued to London Kotlin Works", DirectiveStatus.APPROVED, DirectiveStatus.ISSUED),
                    DirectiveRevision(System.currentTimeMillis() - 86400000L * 7, "Principal Systems Engineer", "Acknowledged by lead engineer", DirectiveStatus.ISSUED, DirectiveStatus.ACKNOWLEDGED),
                    DirectiveRevision(System.currentTimeMillis() - 86400000L * 5, "Principal Systems Engineer", "Work commenced on core terminal", DirectiveStatus.ACKNOWLEDGED, DirectiveStatus.IN_PROGRESS)
                )
            ),
            Directive(
                id = "DIR-2026-002",
                title = "Quantum Cryptography Transfer Prototype Validation",
                targetEntityId = "duke-theoretical-sciences",
                instruction = "Conduct formal algorithmic review and simulated benchmark tests on the Quantum Cryptography File Transfer System.",
                businessRationale = "Validate security assumptions and establish quantum resistance metrics prior to patenting and external audits.",
                priority = DirectivePriority.URGENT,
                status = DirectiveStatus.ACKNOWLEDGED,
                effectiveDate = "2026-10-10",
                deadlineDate = "2026-12-01",
                budgetAuthorityGbp = 35000.0,
                responsibleRole = "Chief Scientific Officer",
                requiredDeliverables = listOf("Algorithmic Verification Dossier", "Simulated Threat Analysis", "Benchmarking Report"),
                successCriteria = "Zero catastrophic decapsulation failure across 10,000 simulated adversary iterations."
            ),
            Directive(
                id = "DIR-2026-003",
                title = "Aerospace VTOL Propulsion Engineering Feasibility",
                targetEntityId = "duke-newton-rockets",
                instruction = "Prepare a complete numerical CFD simulation dossier and structural mass-flow analysis for the hybrid propulsion module.",
                businessRationale = "Determine engineering viability and regulatory parameters before capital commitment to physical manufacturing.",
                priority = DirectivePriority.STRATEGIC,
                status = DirectiveStatus.UNDER_REVIEW,
                effectiveDate = "2026-10-12",
                deadlineDate = "2026-12-20",
                budgetAuthorityGbp = 60000.0,
                responsibleRole = "Aerospace Chief Engineer",
                requiredDeliverables = listOf("CFD Aerodynamic Dossier", "Propulsion Thrust-to-Weight Study"),
                successCriteria = "Demonstrated stability in simulation under Mach 0.8 transitional crosswinds."
            ),
            Directive(
                id = "DIR-2026-004",
                title = "H2UK Humber Corridor Clean Supply Modeling",
                targetEntityId = "duke-hydrogrid",
                instruction = "Update economic forecasts and delivery pipeline schemas for the Humber Industrial Decarbonisation corridor.",
                businessRationale = "Prepare institutional funding prospectus for sovereign-wealth co-investment with Ellan Vannin.",
                priority = DirectivePriority.ROUTINE,
                status = DirectiveStatus.COMPLETED,
                effectiveDate = "2026-09-15",
                deadlineDate = "2026-10-10",
                budgetAuthorityGbp = 20000.0,
                responsibleRole = "Hydrogen Infrastructure Director",
                requiredDeliverables = listOf("Economic Forecast 2026-2031", "Pipeline Topology Blueprint"),
                successCriteria = "Reconciled with UK clean energy market tariffs.",
                evidenceOfCompletion = "Document finalized: Hydrogrid_UK_Hydrogen_Economic_Forecast_2026-2031.pdf uploaded to repo."
            )
        )
        _directives.value = initialDirectives

        // Seed Funding Requests
        val initialFunding = listOf(
            FundingRequest(
                id = "FR-2026-089",
                requestingEntityId = "duke-newton-rockets",
                recipientEntityId = "duke-newton-rockets",
                projectOrProgramme = "High-Mach CFD Simulation Rig & Structural Testing",
                requestedAmount = 75000.0,
                currency = Currency.GBP,
                fundingType = FundingType.CAPITAL_EXPENDITURE,
                purpose = "High-performance compute clusters and aerodynamic wind tunnel simulator licenses.",
                businessCase = "Enables completing the propulsion design phase without subcontracting to external aerospace bureaus, reducing delivery time by 4 months.",
                expectedMilestones = listOf("Compute Cluster Provisioning", "Mesh Generation Test", "Supersonic Boundary Validation"),
                riskClassification = "Medium Technical Risk",
                status = FundingRequestStatus.PENDING_REVIEW,
                submissionDate = "2026-10-12",
                requiredByDate = "2026-11-01"
            ),
            FundingRequest(
                id = "FR-2026-088",
                requestingEntityId = "aureom-ai",
                recipientEntityId = "aureom-ai",
                projectOrProgramme = "16K Camera Engine Neural Prototyper",
                requestedAmount = 120000.0,
                currency = Currency.GBP,
                fundingType = FundingType.PROJECT_FUNDING,
                purpose = "Neural rendering model fine-tuning and GPU cluster rental for digital twin fabrication.",
                businessCase = "Expands Aureom commercial licensing catalog for high-precision industrial manufacturing clients.",
                expectedMilestones = listOf("Neural Engine 1.0 Release", "Hardware Benchmarking", "10 Industrial Pilot Demos"),
                riskClassification = "Low Financial Risk",
                status = FundingRequestStatus.PENDING_REVIEW,
                submissionDate = "2026-10-13",
                requiredByDate = "2026-10-28"
            ),
            FundingRequest(
                id = "FR-2026-085",
                requestingEntityId = "duke-theoretical-sciences",
                recipientEntityId = "duke-theoretical-sciences",
                projectOrProgramme = "Quantum Cryptography Laboratory Hardware Emulation",
                requestedAmount = 95000.0,
                currency = Currency.GBP,
                fundingType = FundingType.RESEARCH_GRANT,
                purpose = "FPGA-based quantum key distribution emulator and fiber optical loop testbed.",
                businessCase = "Provides physical laboratory proof-of-concept for the Theoretical and Applied Sciences Division.",
                expectedMilestones = listOf("FPGA Bitstream Deployment", "QKD Simulator Interface", "Laboratory Demonstration"),
                riskClassification = "High Academic Innovation",
                status = FundingRequestStatus.APPROVED_COMMITTED,
                submissionDate = "2026-09-28",
                requiredByDate = "2026-10-15",
                approvalNotes = "Approved by Holding Board. Capital commitment recorded."
            )
        )
        _fundingRequests.value = initialFunding

        // Commitments
        val initialCommitments = listOf(
            CapitalCommitment(
                id = "COM-2026-042",
                fundingRequestId = "FR-2026-085",
                entityId = "duke-theoretical-sciences",
                committedAmount = 95000.0,
                currency = Currency.GBP,
                remainingUndisbursed = 45000.0,
                commitmentDate = "2026-10-02",
                authorizedBy = "BTCPhilosopher Investment Committee"
            )
        )
        _commitments.value = initialCommitments

        // Treasury Accounts
        val initialAccounts = listOf(
            TreasuryAccount(
                id = "ACC-001",
                name = "BTCPhilosopher Primary Treasury",
                entityId = "btc-holdings",
                institution = "Barclays Corporate Banking London",
                accountType = AccountType.BANK_ACCOUNT,
                currency = Currency.GBP,
                balance = 3450000.0,
                verificationStatus = BalanceVerificationStatus.VERIFIED_ONLINE,
                lastUpdated = "2026-10-15 08:30 GMT",
                accountNumberMasked = "•••• 9102",
                notes = "Institutional operating & capital allocation treasury."
            ),
            TreasuryAccount(
                id = "ACC-002",
                name = "Holding Cold Reserve Multisig",
                entityId = "btc-holdings",
                institution = "On-Chain Multi-Sig Treasury",
                accountType = AccountType.BITCOIN_WALLET,
                currency = Currency.BTC,
                balance = 48.75,
                verificationStatus = BalanceVerificationStatus.BITCOIN_ONCHAIN,
                lastUpdated = "2026-10-15 09:12 GMT",
                accountNumberMasked = "bc1q••••37x9",
                notes = "Strategic treasury Bitcoin reserve. Watch-only auditable ledger."
            ),
            TreasuryAccount(
                id = "ACC-003",
                name = "Duke Satoshi PLC Operational Acct",
                entityId = "duke-satoshi",
                institution = "HSBC Commercial UK",
                accountType = AccountType.BANK_ACCOUNT,
                currency = Currency.GBP,
                balance = 780000.0,
                verificationStatus = BalanceVerificationStatus.STATEMENT_IMPORTED,
                lastUpdated = "2026-10-14 18:00 GMT",
                accountNumberMasked = "•••• 4410",
                notes = "Subsidiary operational facility."
            ),
            TreasuryAccount(
                id = "ACC-004",
                name = "RhinoQuant Synthetic Clearing Simulator",
                entityId = "rhino-bank",
                institution = "Rhino Synthetic Settlement Core",
                accountType = AccountType.SIMULATED_ACCOUNT,
                currency = Currency.USD,
                balance = 1500000.0,
                verificationStatus = BalanceVerificationStatus.SIMULATED_TEST,
                lastUpdated = "2026-10-15 10:00 GMT",
                accountNumberMasked = "SIM-••••-8800",
                notes = "Sandboxed quantitative execution engine test account. Not real money."
            ),
            TreasuryAccount(
                id = "ACC-005",
                name = "Rocketman Agorist Commercial Float",
                entityId = "rocketman-enterprises",
                institution = "Lightning & On-Chain Float",
                accountType = AccountType.BITCOIN_WALLET,
                currency = Currency.BTC,
                balance = 8.42,
                verificationStatus = BalanceVerificationStatus.BITCOIN_ONCHAIN,
                lastUpdated = "2026-10-15 07:45 GMT",
                accountNumberMasked = "bc1p••••99w2",
                notes = "Peer-to-peer commerce and Bitcoin treasury facility."
            )
        )
        _treasuryAccounts.value = initialAccounts

        // Intercompany Journal
        val initialJournals = listOf(
            IntercompanyJournalEntry(
                id = "ICJ-2026-101",
                transactionRef = "IC-TXN-9021",
                originatingEntityId = "btc-holdings",
                counterpartyEntityId = "duke-theoretical-sciences",
                amount = 50000.0,
                currency = Currency.GBP,
                transactionType = IntercompanyTransactionType.EQUITY_CONTRIBUTION,
                debitAccount = "Investment in Subsidiary R&D",
                creditAccount = "Holding Operating Cash",
                isBalanced = true,
                isEliminatedInConsolidation = true,
                date = "2026-10-04",
                description = "Tranche 1 disbursement for Quantum Cryptography Lab emulation project."
            ),
            IntercompanyJournalEntry(
                id = "ICJ-2026-102",
                transactionRef = "IC-TXN-9022",
                originatingEntityId = "duke-london-kotlin",
                counterpartyEntityId = "btc-holdings",
                amount = 15000.0,
                currency = Currency.GBP,
                transactionType = IntercompanyTransactionType.SHARED_SERVICE_CHARGE,
                debitAccount = "Holding Terminal Engineering Expense",
                creditAccount = "London Kotlin Works Service Revenue",
                isBalanced = true,
                isEliminatedInConsolidation = true,
                date = "2026-10-08",
                description = "Shared engineering cost allocation for Group Command Operating System."
            )
        )
        _intercompanyJournals.value = initialJournals

        // Research Programmes (Theoretical and Applied Sciences Division)
        val initialResearch = listOf(
            ResearchProgramme(
                id = "RES-Q-01",
                title = "Quantum Cryptography File Transfer System",
                entityId = "duke-theoretical-sciences",
                category = ResearchCategory.QUANTUM_CRYPTOGRAPHY,
                maturity = ResearchMaturity.LABORATORY_PROTOTYPE,
                status = ResearchStatus.ACTIVE_PROGRAMME,
                researchLead = "Dr. Alan Vance, Head of Cryptography",
                budgetGbp = 140000.0,
                actualExpenditureGbp = 65000.0,
                researchQuestion = "Can post-quantum lattice key encapsulation be seamlessly integrated into high-throughput file transport over standard TCP/IP without performance degradation?",
                validationCriteria = "Simulate 10 Gbps encrypted throughput; verify zero packet decryption against Shor's algorithm emulation attack model.",
                githubPath = "DukeSatoshiofCyberspace PLC/Theoretical and Applied Sciences Division/Quantum-Cryptography-File-Transfer-System-main.zip",
                keyMilestones = listOf(
                    ResearchMilestone("Lattice primitive benchmarking", "Q3 2026", true),
                    ResearchMilestone("FPGA transport hardware loop", "Q4 2026", false),
                    ResearchMilestone("Peer-reviewed security proof", "Q1 2027", false)
                ),
                publicationOrIpStatus = "Internal Patent Specification Drafted",
                resultsSummary = "Initial benchmarks show 9.2 Gbps throughput with sub-5ms key exchange latency using Kyber-1024 hybrid encapsulation."
            ),
            ResearchProgramme(
                id = "RES-C-02",
                title = "N vs NP Computational Complexity & Polynomial Verification",
                entityId = "duke-theoretical-sciences",
                category = ResearchCategory.ADVANCED_COMPUTING,
                maturity = ResearchMaturity.THEORETICAL_PROPOSAL,
                status = ResearchStatus.ACTIVE_PROGRAMME,
                researchLead = "Prof. J. MacIntyre, Fellow of Mathematics",
                budgetGbp = 80000.0,
                actualExpenditureGbp = 28000.0,
                researchQuestion = "Investigating circuit complexity lower bounds for Boolean satisfiability (SAT) using geometric complexity theory frameworks.",
                validationCriteria = "Formal mathematical rigor, machine-verified proofs in Lean/Coq theorem provers.",
                githubPath = "DukeSatoshiofCyberspace PLC/Theoretical and Applied Sciences Division/N vs NP Problem",
                keyMilestones = listOf(
                    ResearchMilestone("Monotone circuit lower bounds survey", "Q3 2026", true),
                    ResearchMilestone("Interactive proof system formulation", "Q4 2026", false)
                ),
                publicationOrIpStatus = "Academic Monograph in Preparation",
                resultsSummary = "Identified novel geometric barrier candidates for non-relativizing circuit separation."
            ),
            ResearchProgramme(
                id = "RES-I4-03",
                title = "Felixstowe Smart Port & Robotics Freight Operating System",
                entityId = "duke-theoretical-sciences",
                category = ResearchCategory.INDUSTRY_4_0,
                maturity = ResearchMaturity.PILOT_DEPLOYMENT,
                status = ResearchStatus.ACTIVE_PROGRAMME,
                researchLead = "Marcus Reed, VP Industrial Automation",
                budgetGbp = 220000.0,
                actualExpenditureGbp = 110000.0,
                researchQuestion = "How to automate multi-modal container transshipment schedules using decentralized robotic ledgers and digital twins?",
                validationCriteria = "Reduce container dwell time by 22% in simulated quay crane and automated guided vehicle (AGV) dispatch.",
                githubPath = "DukeSatoshiofCyberspace PLC/Theoretical and Applied Sciences Division/Industry 4.0/Felixstowe Smart Port Transformation – Executive Summary.pdf",
                keyMilestones = listOf(
                    ResearchMilestone("Freight OS core engine architecture", "Q2 2026", true),
                    ResearchMilestone("AGV real-time dispatch simulator", "Q3 2026", true),
                    ResearchMilestone("Pilot quay integration test", "Q4 2026", false)
                ),
                publicationOrIpStatus = "Proprietary Trade Secret & Software Copyright",
                resultsSummary = "Digital twin shows 24.5% improvement in crane turnaround efficiency in testbed scenario."
            ),
            ResearchProgramme(
                id = "RES-SC-04",
                title = "Big-Chips & Monolithic Silicon Architecture",
                entityId = "duke-theoretical-sciences",
                category = ResearchCategory.SEMICONDUCTORS,
                maturity = ResearchMaturity.SIMULATED_NUMERICAL,
                status = ResearchStatus.AWAITING_DECISION,
                researchLead = "Dr. Eric Thorne, Microelectronics",
                budgetGbp = 160000.0,
                actualExpenditureGbp = 42000.0,
                researchQuestion = "Can wafer-scale packaging architectures achieve 10x interconnect bandwidth for ultra-dense matrix tensor multiplication?",
                validationCriteria = "Thermal dissipation within 2.5 kW / cm²; interconnect signal skew under 15 picoseconds.",
                githubPath = "DukeSatoshiofCyberspace PLC/Theoretical and Applied Sciences Division/Big-Chips.pdf",
                keyMilestones = listOf(
                    ResearchMilestone("Thermal dissipation simulation", "Q3 2026", true),
                    ResearchMilestone("Wafer routing topology benchmark", "Q4 2026", false)
                ),
                publicationOrIpStatus = "Patent Filing Pending Review",
                resultsSummary = "Numerical thermal modeling validated; awaiting board approval for physical packaging test coupon fabrication."
            )
        )
        _researchProgrammes.value = initialResearch

        // Intellectual Property Assets
        val initialIp = listOf(
            IpAsset(
                id = "IP-001",
                name = "Quantum-Cryptography File Transfer Protocol",
                type = IpAssetType.SOFTWARE_REPOSITORY,
                custodianEntityId = "duke-theoretical-sciences",
                claimedOwner = "BTCPhilosopherHoldings",
                legalOwnerVerified = "Duke Satoshi of Cyberspace PLC",
                licensingModel = LicensingModel.PROPRIETARY_HOLDING,
                repositoryPath = "DukeSatoshiofCyberspace PLC/Theoretical and Applied Sciences Division/Quantum-Cryptography-File-Transfer-System-main.zip",
                commercialStatus = "Core Proprietary Tech",
                estimatedAssetValueGbp = 1200000.0,
                description = "Post-quantum cryptographic key encapsulation mechanism and peer-to-peer authenticated transport protocol.",
                dependencies = listOf("OpenSSL 3.0", "Kyber Reference C", "Linux Kernel Epoll")
            ),
            IpAsset(
                id = "IP-002",
                name = "Aureom 16K Camera Engine & Digital Twin",
                type = IpAssetType.SYSTEM_ARCHITECTURE,
                custodianEntityId = "aureom-ai",
                claimedOwner = "BTCPhilosopherHoldings",
                legalOwnerVerified = "Aureom AI Technologies Ltd.",
                licensingModel = LicensingModel.COMMERCIAL_EXCLUSIVE,
                repositoryPath = "Aurora Lux Inc./Camera.OS/aureom-16k-camera-engine---digital-twin-&-manufacturing-prototyper.zip",
                commercialStatus = "Licensable Product Engine",
                estimatedAssetValueGbp = 850000.0,
                description = "Ultra-high resolution camera telemetry, sensor fusion, and digital manufacturing digital twin pipeline.",
                dependencies = listOf("Vulkan API", "OpenCV", "PyTorch 2.4")
            ),
            IpAsset(
                id = "IP-003",
                name = "RhinoQuant Derivatives & Commodity Engine",
                type = IpAssetType.ALGORITHMIC_MODEL,
                custodianEntityId = "rhino-bank",
                claimedOwner = "BTCPhilosopherHoldings",
                legalOwnerVerified = "Rhino Financial Technologies",
                licensingModel = LicensingModel.PROPRIETARY_HOLDING,
                repositoryPath = "DukeSatoshiofCyberspace PLC/AgriTech/rhinoquant-derivatives.execution.os.zip",
                commercialStatus = "Financial Infrastructure Component",
                estimatedAssetValueGbp = 2400000.0,
                description = "Real-time derivative pricing, volatility surfaces, Monte Carlo VaR models, and synthetic commodity settlements.",
                dependencies = listOf("C++20", "Eigen3", "QuantLib")
            ),
            IpAsset(
                id = "IP-004",
                name = "BritAgri CEA & Food Logistics OS",
                type = IpAssetType.SOFTWARE_REPOSITORY,
                custodianEntityId = "duke-agritech",
                claimedOwner = "BTCPhilosopherHoldings",
                legalOwnerVerified = "British AgriSpot CEA Systems",
                licensingModel = LicensingModel.COMMERCIAL_RECURRING_SAAS,
                repositoryPath = "DukeSatoshiofCyberspace PLC/AgriTech/britagri-logistics.os.zip",
                commercialStatus = "Commercial SaaS Platform",
                estimatedAssetValueGbp = 450000.0,
                description = "End-to-end controlled environment agriculture management, cold chain tracking, and automated market auctioning.",
                dependencies = listOf("PostgreSQL 16", "FastAPI", "Kotlin")
            ),
            IpAsset(
                id = "IP-005",
                name = "H2-IGNITION.OS Clean Hydrogen Grid",
                type = IpAssetType.SOFTWARE_REPOSITORY,
                custodianEntityId = "duke-hydrogrid",
                claimedOwner = "BTCPhilosopherHoldings",
                legalOwnerVerified = "HydroGrid Britain Infrastructure Ltd.",
                licensingModel = LicensingModel.GROUP_INTERNAL_LICENCE,
                repositoryPath = "DukeSatoshiofCyberspace PLC/HydroGrid/H2-IGNITION.OS-main.zip",
                commercialStatus = "Strategic Energy Asset",
                estimatedAssetValueGbp = 950000.0,
                description = "Telemetry, pipeline compression monitoring, and trading contracts for UK national hydrogen transmission.",
                dependencies = listOf("Rust", "Tokio", "SCADA Modbus")
            )
        )
        _ipAssets.value = initialIp

        // Risks
        val initialRisks = listOf(
            RiskItem(
                id = "RSK-001",
                entityId = "duke-newton-rockets",
                category = RiskCategory.ENGINEERING_SAFETY,
                title = "Aerospace CFD Simulation Divergence Risk",
                description = "Numerical instabilities at trans-sonic boundary layer simulations could delay physical motor test bench scheduling.",
                likelihood = 3,
                impact = 4,
                mitigationPlan = "Commission independent validation from London Kotlin Works / Theoretical Division using higher-order Runge-Kutta solvers.",
                status = RiskStatus.ACTIVE_MONITORED
            ),
            RiskItem(
                id = "RSK-002",
                entityId = "rhino-bank",
                category = RiskCategory.REGULATORY_COMPLIANCE,
                title = "Synthetic Derivative Classification Boundary",
                description = "Ensuring simulated trading terminals and synthetic energy contracts are strictly categorized as analytical test environments rather than unlicensed retail brokerage.",
                likelihood = 2,
                impact = 5,
                mitigationPlan = "Prominent regulatory disclaimers in all terminal views; institutional whitelisting only; no fiat customer deposits accepted.",
                status = RiskStatus.MITIGATED
            ),
            RiskItem(
                id = "RSK-003",
                entityId = "duke-theoretical-sciences",
                category = RiskCategory.IP_OWNERSHIP,
                title = "Third-Party Academic IP Entanglement in Quantum Code",
                description = "Verifying that quantum algorithms and Kyber reference implementations do not incorporate restrictive GPL viral licensing.",
                likelihood = 2,
                impact = 4,
                mitigationPlan = "Perform automated code provenance audit and license dependency scan using GitHub discovery tooling.",
                status = RiskStatus.ACTIVE_MONITORED
            )
        )
        _risks.value = initialRisks

        // Audit Events
        val initialAudit = listOf(
            AuditEvent(
                id = "AUD-1001",
                timestamp = System.currentTimeMillis() - 86400000L * 3,
                actor = "Principal Executive Authority",
                actionType = "INITIALIZE_HOLDING_TERMINAL",
                targetRecordId = "btc-holdings",
                targetRecordType = "HOLDING_COMPANY",
                previousStateSummary = null,
                newStateSummary = "Group Registry initialized with 17 corporate and research nodes.",
                rationale = "System boot & initial corporate repository synchronisation.",
                correlationId = "CORR-INIT-001"
            ),
            AuditEvent(
                id = "AUD-1002",
                timestamp = System.currentTimeMillis() - 86400000L * 2,
                actor = "Holding Investment Committee",
                actionType = "APPROVE_CAPITAL_COMMITMENT",
                targetRecordId = "FR-2026-085",
                targetRecordType = "FUNDING_REQUEST",
                previousStateSummary = "Status: PENDING_REVIEW",
                newStateSummary = "Status: APPROVED_COMMITTED, Amount: £95,000",
                rationale = "Approved research grant for Quantum Cryptography Lab Hardware Emulation.",
                correlationId = "CORR-CAP-085"
            )
        )
        _auditEvents.value = initialAudit
    }

    // --- Entity Operations ---
    fun addEntity(entity: CorporateEntity): Result<Unit> {
        if (_entities.value.any { it.id == entity.id }) {
            return Result.failure(IllegalArgumentException("Entity ID already exists"))
        }
        _entities.value = _entities.value + entity
        logAudit(
            actionType = "ENTITY_CREATED",
            targetRecordId = entity.id,
            targetRecordType = "CORPORATE_ENTITY",
            previousState = null,
            newState = "Name: ${entity.name}, Type: ${entity.type}, Ownership: ${entity.targetOwnershipPercent}%",
            rationale = "Executive addition to corporate registry"
        )
        return Result.success(Unit)
    }

    fun updateEntity(entity: CorporateEntity): Result<Unit> {
        // Prevent circular parenting
        var currentParentId = entity.parentId
        while (currentParentId != null) {
            if (currentParentId == entity.id) {
                return Result.failure(IllegalStateException("Circular parent relationship detected"))
            }
            currentParentId = _entities.value.find { it.id == currentParentId }?.parentId
        }

        val previous = _entities.value.find { it.id == entity.id }
        _entities.value = _entities.value.map { if (it.id == entity.id) entity else it }
        logAudit(
            actionType = "ENTITY_UPDATED",
            targetRecordId = entity.id,
            targetRecordType = "CORPORATE_ENTITY",
            previousState = previous?.name,
            newState = "Name: ${entity.name}, Status: ${entity.verificationStatus}",
            rationale = "Corporate registry update"
        )
        return Result.success(Unit)
    }

    // --- Directives ---
    fun createDirective(directive: Directive): Result<Unit> {
        _directives.value = listOf(directive) + _directives.value
        logAudit(
            actionType = "DIRECTIVE_CREATED",
            targetRecordId = directive.id,
            targetRecordType = "DIRECTIVE",
            previousState = null,
            newState = "Title: ${directive.title}, Target: ${directive.targetEntityId}, Status: ${directive.status}",
            rationale = "Holding corporate governance directive issued"
        )
        return Result.success(Unit)
    }

    fun updateDirectiveStatus(directiveId: String, newStatus: DirectiveStatus, note: String, actor: String = "Holding Executive"): Result<Unit> {
        val directive = _directives.value.find { it.id == directiveId } ?: return Result.failure(NoSuchElementException("Directive not found"))
        val revision = DirectiveRevision(
            timestamp = System.currentTimeMillis(),
            author = actor,
            note = note,
            previousStatus = directive.status,
            newStatus = newStatus
        )
        val updated = directive.copy(
            status = newStatus,
            revisions = directive.revisions + revision
        )
        _directives.value = _directives.value.map { if (it.id == directiveId) updated else it }
        logAudit(
            actionType = "DIRECTIVE_STATUS_CHANGE",
            targetRecordId = directiveId,
            targetRecordType = "DIRECTIVE",
            previousState = directive.status.name,
            newState = newStatus.name,
            rationale = note
        )
        return Result.success(Unit)
    }

    // --- Capital Allocation ---
    fun approveFundingRequest(requestId: String, authorizedBy: String = "Investment Committee"): Result<CapitalCommitment> {
        val request = _fundingRequests.value.find { it.id == requestId } ?: return Result.failure(NoSuchElementException("Request not found"))
        if (request.status != FundingRequestStatus.PENDING_REVIEW) {
            return Result.failure(IllegalStateException("Request is not pending review"))
        }

        // Available capital check against parent treasury
        val parentCash = _treasuryAccounts.value
            .filter { it.entityId == "btc-holdings" && it.currency == request.currency }
            .sumOf { it.balance }

        val existingUndisbursed = _commitments.value
            .filter { it.currency == request.currency }
            .sumOf { it.remainingUndisbursed }

        val netAvailable = parentCash - existingUndisbursed
        if (netAvailable < request.requestedAmount) {
            return Result.failure(IllegalStateException("Insufficient uncommitted cash in parent treasury: Available $netAvailable, Requested ${request.requestedAmount}"))
        }

        val updatedRequest = request.copy(
            status = FundingRequestStatus.APPROVED_COMMITTED,
            approvalNotes = "Approved by $authorizedBy on ${java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.UK).format(java.util.Date())}"
        )
        _fundingRequests.value = _fundingRequests.value.map { if (it.id == requestId) updatedRequest else it }

        val commitment = CapitalCommitment(
            id = "COM-2026-${(100..999).random()}",
            fundingRequestId = requestId,
            entityId = request.recipientEntityId,
            committedAmount = request.requestedAmount,
            currency = request.currency,
            remainingUndisbursed = request.requestedAmount,
            commitmentDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.UK).format(java.util.Date()),
            authorizedBy = authorizedBy
        )
        _commitments.value = listOf(commitment) + _commitments.value

        // Update target entity allocated capital
        _entities.value = _entities.value.map {
            if (it.id == request.recipientEntityId) {
                it.copy(allocatedCapitalGbp = it.allocatedCapitalGbp + (request.requestedAmount * request.currency.rateToGbp))
            } else it
        }

        logAudit(
            actionType = "CAPITAL_ALLOCATION_APPROVED",
            targetRecordId = commitment.id,
            targetRecordType = "CAPITAL_COMMITMENT",
            previousState = "FundingRequest: ${request.id} PENDING",
            newState = "Commitment: ${commitment.id}, Amount: ${request.currency.symbol}${request.requestedAmount}",
            rationale = "Formal parent capital commitment created"
        )
        return Result.success(commitment)
    }

    fun rejectFundingRequest(requestId: String, reason: String): Result<Unit> {
        val request = _fundingRequests.value.find { it.id == requestId } ?: return Result.failure(NoSuchElementException("Request not found"))
        val updated = request.copy(
            status = FundingRequestStatus.REJECTED,
            approvalNotes = "Rejected: $reason"
        )
        _fundingRequests.value = _fundingRequests.value.map { if (it.id == requestId) updated else it }
        logAudit(
            actionType = "FUNDING_REQUEST_REJECTED",
            targetRecordId = requestId,
            targetRecordType = "FUNDING_REQUEST",
            previousState = "PENDING_REVIEW",
            newState = "REJECTED",
            rationale = reason
        )
        return Result.success(Unit)
    }

    fun submitFundingRequest(request: FundingRequest): Result<Unit> {
        _fundingRequests.value = listOf(request) + _fundingRequests.value
        logAudit(
            actionType = "FUNDING_REQUEST_SUBMITTED",
            targetRecordId = request.id,
            targetRecordType = "FUNDING_REQUEST",
            previousState = null,
            newState = "Amount: ${request.currency.symbol}${request.requestedAmount}, Purpose: ${request.purpose}",
            rationale = "Subsidiary submitted capital allocation request"
        )
        return Result.success(Unit)
    }

    // --- Treasury & Payment Execution ---
    fun executePaymentInstruction(
        commitmentId: String?,
        sourceAccountId: String,
        targetEntityId: String,
        amount: Double,
        currency: Currency,
        purpose: String,
        isSimulated: Boolean
    ): Result<PaymentInstruction> {
        val sourceAccount = _treasuryAccounts.value.find { it.id == sourceAccountId }
            ?: return Result.failure(NoSuchElementException("Source treasury account not found"))

        if (sourceAccount.balance < amount) {
            return Result.failure(IllegalStateException("Source account balance insufficient"))
        }

        val paymentStatus = if (isSimulated) PaymentStatus.SIMULATED_TEST else PaymentStatus.SETTLED

        val payment = PaymentInstruction(
            id = "PMT-${System.currentTimeMillis() % 100000}",
            commitmentId = commitmentId,
            sourceAccountId = sourceAccountId,
            targetEntityId = targetEntityId,
            targetAccountDetails = "Verified Internal Recipient IBAN/Vault",
            amount = amount,
            currency = currency,
            purpose = purpose,
            isSimulationMode = isSimulated,
            providerReference = if (isSimulated) "SIM-TRX-${UUID.randomUUID().toString().take(8).uppercase()}" else "BACS-FPS-${(100000..999999).random()}",
            status = paymentStatus
        )

        _paymentInstructions.value = listOf(payment) + _paymentInstructions.value

        // If executed (live or simulated), deduct from account balance and update commitment
        _treasuryAccounts.value = _treasuryAccounts.value.map {
            if (it.id == sourceAccountId) it.copy(balance = it.balance - amount) else it
        }

        if (commitmentId != null) {
            _commitments.value = _commitments.value.map { com ->
                if (com.id == commitmentId) {
                    val newRemaining = (com.remainingUndisbursed - amount).coerceAtLeast(0.0)
                    com.copy(remainingUndisbursed = newRemaining)
                } else com
            }
        }

        // Post automatic double-entry intercompany journal entry
        val journal = IntercompanyJournalEntry(
            id = "ICJ-2026-${(200..999).random()}",
            transactionRef = payment.providerReference ?: payment.id,
            originatingEntityId = sourceAccount.entityId,
            counterpartyEntityId = targetEntityId,
            amount = amount,
            currency = currency,
            transactionType = IntercompanyTransactionType.INTERCOMPANY_LOAN,
            debitAccount = "Intercompany Receivable / Funding",
            creditAccount = "Treasury Cash (${sourceAccount.institution})",
            isBalanced = true,
            isEliminatedInConsolidation = true,
            date = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.UK).format(java.util.Date()),
            status = if (isSimulated) "SIMULATED_POSTING" else "POSTED_BALANCED",
            description = purpose
        )
        _intercompanyJournals.value = listOf(journal) + _intercompanyJournals.value

        logAudit(
            actionType = if (isSimulated) "PAYMENT_SIMULATED" else "PAYMENT_SETTLED",
            targetRecordId = payment.id,
            targetRecordType = "PAYMENT_INSTRUCTION",
            previousState = null,
            newState = "Amount: ${currency.symbol}$amount, ProviderRef: ${payment.providerReference}",
            rationale = "Treasury transfer execution"
        )

        return Result.success(payment)
    }

    fun toggleSimulationMode(enabled: Boolean) {
        _isSimulationMode.value = enabled
        logAudit(
            actionType = "SIMULATION_MODE_TOGGLED",
            targetRecordId = "GLOBAL_SETTING",
            targetRecordType = "SYSTEM_CONFIGURATION",
            previousState = (!enabled).toString(),
            newState = enabled.toString(),
            rationale = if (enabled) "Switched terminal to safe simulation mode" else "Switched terminal to live execution mode"
        )
    }

    // --- Research Operations ---
    fun updateResearchStatus(programmeId: String, newStatus: ResearchStatus): Result<Unit> {
        val prog = _researchProgrammes.value.find { it.id == programmeId } ?: return Result.failure(NoSuchElementException("Programme not found"))
        _researchProgrammes.value = _researchProgrammes.value.map {
            if (it.id == programmeId) it.copy(status = newStatus) else it
        }
        logAudit(
            actionType = "RESEARCH_STATUS_UPDATED",
            targetRecordId = programmeId,
            targetRecordType = "RESEARCH_PROGRAMME",
            previousState = prog.status.name,
            newState = newStatus.name,
            rationale = "Executive review of scientific programme"
        )
        return Result.success(Unit)
    }

    fun allocateResearchBudget(programmeId: String, additionalGbp: Double): Result<Unit> {
        val prog = _researchProgrammes.value.find { it.id == programmeId } ?: return Result.failure(NoSuchElementException("Programme not found"))
        val updated = prog.copy(budgetGbp = prog.budgetGbp + additionalGbp)
        _researchProgrammes.value = _researchProgrammes.value.map {
            if (it.id == programmeId) updated else it
        }
        logAudit(
            actionType = "RESEARCH_BUDGET_AUGMENTED",
            targetRecordId = programmeId,
            targetRecordType = "RESEARCH_PROGRAMME",
            previousState = "Budget: £${prog.budgetGbp}",
            newState = "Budget: £${updated.budgetGbp}",
            rationale = "Authorised additional research allocation"
        )
        return Result.success(Unit)
    }

    // --- Audit Logging ---
    private fun logAudit(
        actionType: String,
        targetRecordId: String,
        targetRecordType: String,
        previousState: String?,
        newState: String,
        rationale: String
    ) {
        val event = AuditEvent(
            id = "AUD-${System.currentTimeMillis() % 1000000}",
            timestamp = System.currentTimeMillis(),
            actor = "Group Executive",
            actionType = actionType,
            targetRecordId = targetRecordId,
            targetRecordType = targetRecordType,
            previousStateSummary = previousState,
            newStateSummary = newState,
            rationale = rationale,
            correlationId = "CORR-${UUID.randomUUID().toString().take(6).uppercase()}"
        )
        _auditEvents.value = listOf(event) + _auditEvents.value
    }

    // --- Natural Language Command Parser ---
    fun parseCommand(input: String): CommandActionProposal {
        val clean = input.trim().lowercase()

        return when {
            clean.contains("all companies") || clean.contains("ownership") || clean.contains("list entities") -> {
                val summary = _entities.value.joinToString("\n") {
                    "• ${it.name} (${it.type.label}): ${it.targetOwnershipPercent}% ownership [${it.verificationStatus.label}]"
                }
                CommandActionProposal.DirectQuery(
                    title = "Group Corporate Ownership Ledger",
                    message = "Active Entities (${_entities.value.size}):\n\n$summary"
                )
            }
            clean.contains("funding request") || clean.contains("awaiting") && clean.contains("approval") -> {
                val pending = _fundingRequests.value.filter { it.status == FundingRequestStatus.PENDING_REVIEW }
                if (pending.isEmpty()) {
                    CommandActionProposal.DirectQuery("Funding Requests Awaiting Approval", "No pending funding requests. All capital allocations are reviewed.")
                } else {
                    val list = pending.joinToString("\n\n") {
                        "• ${it.id} (${it.requestingEntityId}): ${it.currency.symbol}${it.requestedAmount}\n  Project: ${it.projectOrProgramme}\n  Purpose: ${it.purpose}"
                    }
                    CommandActionProposal.DirectQuery("Pending Funding Requests (${pending.size})", list)
                }
            }
            clean.contains("newton rockets") && (clean.contains("capital") || clean.contains("allocate") || clean.contains("£") || clean.contains("25,000")) -> {
                CommandActionProposal.ProposeCapitalAllocation(
                    targetEntityId = "duke-newton-rockets",
                    amount = 25000.0,
                    currency = Currency.GBP,
                    purpose = "Authorised allocation for CFD simulation rig & propulsion testing."
                )
            }
            clean.contains("compare") && (clean.contains("rhino") || clean.contains("aureom")) -> {
                val rhino = _entities.value.find { it.id == "rhino-bank" }
                val aureom = _entities.value.find { it.id == "aureom-ai" }
                val text = "Rhino Bank:\n• Budget: £${rhino?.authorizedBudgetGbp ?: 0.0}\n• Allocated: £${rhino?.allocatedCapitalGbp ?: 0.0}\n• Spent: £${rhino?.spentCapitalGbp ?: 0.0}\n\nAureom.AI:\n• Budget: £${aureom?.authorizedBudgetGbp ?: 0.0}\n• Allocated: £${aureom?.allocatedCapitalGbp ?: 0.0}\n• Spent: £${aureom?.spentCapitalGbp ?: 0.0}"
                CommandActionProposal.DirectQuery("Budget Comparison: Rhino Bank vs Aureom.AI", text)
            }
            clean.contains("research") && (clean.contains("review") || clean.contains("awaiting")) -> {
                val awaiting = _researchProgrammes.value.filter { it.status == ResearchStatus.AWAITING_DECISION }
                val msg = if (awaiting.isEmpty()) "No research programmes currently awaiting board review." else {
                    awaiting.joinToString("\n\n") {
                        "• ${it.title} (${it.category.label})\n  Budget: £${it.budgetGbp}\n  Question: ${it.researchQuestion}"
                    }
                }
                CommandActionProposal.DirectQuery("Research Programmes Awaiting Decision", msg)
            }
            clean.contains("london kotlin") || (clean.contains("directive") && clean.contains("kotlin")) -> {
                CommandActionProposal.ProposeDirective(
                    title = "Commission London Kotlin Works: Next-Gen Shared Applet Component",
                    targetEntityId = "duke-london-kotlin",
                    instruction = "Architect and publish the standardized cross-subsidiary Android/KMP telemetry component library.",
                    budget = 30000.0
                )
            }
            clean.contains("uncommitted capital") -> {
                val parentGbp = _treasuryAccounts.value.filter { it.entityId == "btc-holdings" && it.currency == Currency.GBP }.sumOf { it.balance }
                val committedUndisbursed = _commitments.value.filter { it.currency == Currency.GBP }.sumOf { it.remainingUndisbursed }
                val uncommitted = parentGbp - committedUndisbursed
                val breakdown = _entities.value.filter { it.parentId != null }.joinToString("\n") {
                    val remaining = (it.authorizedBudgetGbp - it.allocatedCapitalGbp).coerceAtLeast(0.0)
                    "• ${it.name}: £${String.format(java.util.Locale.UK, "%,.0f", remaining)} unallocated budget"
                }
                CommandActionProposal.DirectQuery("Capital Position", "Holding Uncommitted Cash: £${String.format(java.util.Locale.UK, "%,.0f", uncommitted)}\nTotal Cash: £${String.format(java.util.Locale.UK, "%,.0f", parentGbp)}\nCommitted Undisbursed: £${String.format(java.util.Locale.UK, "%,.0f", committedUndisbursed)}\n\nSubsidiary Unallocated Headroom:\n$breakdown")
            }
            clean.contains("ip inventory") || clean.contains("intellectual property") -> {
                val list = _ipAssets.value.joinToString("\n\n") {
                    "• ${it.name} (${it.type.label})\n  Owner: ${it.claimedOwner} | Legal: ${it.legalOwnerVerified ?: "Pending verification"}\n  License: ${it.licensingModel.label}"
                }
                CommandActionProposal.DirectQuery("Group-Wide IP Inventory (${_ipAssets.value.size} Assets)", list)
            }
            clean.contains("simulation") -> {
                val target = !isSimulationMode.value
                CommandActionProposal.ProposeSimulationToggle(target)
            }
            else -> {
                CommandActionProposal.DirectQuery(
                    title = "Command Acknowledged",
                    message = "Command interpreted: \"$input\"\n\nMatched intent: General Executive Inquiry.\nTip: Try asking:\n• \"Show all companies and their ownership\"\n• \"List every funding request awaiting my approval\"\n• \"Prepare a capital allocation proposal of £25,000 for Newton Rockets\"\n• \"Compare the budgets for Rhino Bank and Aureom.AI\"\n• \"Show research projects awaiting review\"\n• \"Draft a directive for London Kotlin Works\""
                )
            }
        }
    }
}
