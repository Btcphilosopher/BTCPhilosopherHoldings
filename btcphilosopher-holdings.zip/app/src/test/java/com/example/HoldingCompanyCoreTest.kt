package com.example

import com.example.data.CommandActionProposal
import com.example.data.GroupRepository
import com.example.model.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class HoldingCompanyCoreTest {

    private lateinit var repository: GroupRepository

    @Before
    fun setUp() {
        repository = GroupRepository()
    }

    @Test
    fun testInitialCorporateHierarchy() {
        val entities = repository.entities.value
        assertTrue("Holding registry should contain seeded entities", entities.isNotEmpty())

        val parent = entities.find { it.id == "btc-holdings" }
        assertNotNull("BTCPhilosopherHoldings parent must exist", parent)
        assertEquals(EntityType.HOLDING_COMPANY, parent?.type)
        assertEquals(100.0, parent?.targetOwnershipPercent)

        val dukeSatoshi = entities.find { it.id == "duke-satoshi" }
        assertNotNull("Duke Satoshi PLC must exist", dukeSatoshi)
        assertEquals("btc-holdings", dukeSatoshi?.parentId)

        // Check child division
        val theoreticalSciences = entities.find { it.id == "duke-theoretical-sciences" }
        assertNotNull("Theoretical and Applied Sciences Division must exist", theoreticalSciences)
        assertEquals("duke-satoshi", theoreticalSciences?.parentId)
    }

    @Test
    fun testCircularParentPrevention() {
        val parent = repository.entities.value.find { it.id == "btc-holdings" }!!
        // Attempting to set parent's parent to one of its children
        val circularUpdate = parent.copy(parentId = "duke-satoshi")
        val result = repository.updateEntity(circularUpdate)
        assertTrue("Circular parent update must fail", result.isFailure)
    }

    @Test
    fun testDirectiveLifecycleProgression() {
        val newDirective = Directive(
            id = "DIR-TEST-001",
            title = "Autonomous Logistics Test Directive",
            targetEntityId = "duke-agritech",
            instruction = "Implement test harness",
            businessRationale = "Validation",
            effectiveDate = "2026-10-15",
            deadlineDate = "2026-11-01",
            status = DirectiveStatus.DRAFT
        )
        val createResult = repository.createDirective(newDirective)
        assertTrue(createResult.isSuccess)

        // Advance to SUBMITTED -> APPROVED -> ISSUED -> ACKNOWLEDGED
        repository.updateDirectiveStatus("DIR-TEST-001", DirectiveStatus.APPROVED, "Board review complete")
        val updated1 = repository.directives.value.find { it.id == "DIR-TEST-001" }
        assertEquals(DirectiveStatus.APPROVED, updated1?.status)

        repository.updateDirectiveStatus("DIR-TEST-001", DirectiveStatus.ISSUED, "Formally issued to AgriTech")
        val updated2 = repository.directives.value.find { it.id == "DIR-TEST-001" }
        assertEquals(DirectiveStatus.ISSUED, updated2?.status)
    }

    @Test
    fun testCapitalAllocationAndCommitment() {
        val req = FundingRequest(
            id = "FR-TEST-100",
            requestingEntityId = "duke-newton-rockets",
            recipientEntityId = "duke-newton-rockets",
            projectOrProgramme = "Propulsion R&D",
            requestedAmount = 15000.0,
            currency = Currency.GBP,
            fundingType = FundingType.CAPITAL_EXPENDITURE,
            purpose = "Test compute nodes",
            businessCase = "Aerodynamic test",
            status = FundingRequestStatus.PENDING_REVIEW,
            submissionDate = "2026-10-15",
            requiredByDate = "2026-10-30"
        )
        repository.submitFundingRequest(req)

        val approveResult = repository.approveFundingRequest("FR-TEST-100")
        assertTrue("Funding request within budget should be approved", approveResult.isSuccess)

        val commitment = approveResult.getOrNull()
        assertNotNull(commitment)
        assertEquals(15000.0, commitment?.committedAmount)
        assertEquals(15000.0, commitment?.remainingUndisbursed)

        // Verify request marked approved
        val storedReq = repository.fundingRequests.value.find { it.id == "FR-TEST-100" }
        assertEquals(FundingRequestStatus.APPROVED_COMMITTED, storedReq?.status)
    }

    @Test
    fun testSimulationPaymentWorkflow() {
        val sourceAccount = repository.treasuryAccounts.value.find { it.entityId == "btc-holdings" && it.currency == Currency.GBP }!!
        val initialBalance = sourceAccount.balance

        val paymentResult = repository.executePaymentInstruction(
            commitmentId = null,
            sourceAccountId = sourceAccount.id,
            targetEntityId = "aureom-ai",
            amount = 5000.0,
            currency = Currency.GBP,
            purpose = "Simulated neural model license test",
            isSimulated = true
        )

        assertTrue(paymentResult.isSuccess)
        val pmt = paymentResult.getOrNull()!!
        assertTrue(pmt.isSimulationMode)
        assertEquals(PaymentStatus.SIMULATED_TEST, pmt.status)
        assertTrue(pmt.providerReference!!.startsWith("SIM-TRX-"))

        // Check account balance deducted
        val updatedAccount = repository.treasuryAccounts.value.find { it.id == sourceAccount.id }!!
        assertEquals(initialBalance - 5000.0, updatedAccount.balance, 0.01)

        // Check double-entry journal entry was automatically created
        val journal = repository.intercompanyJournals.value.find { it.transactionRef == pmt.providerReference }
        assertNotNull("Intercompany journal must be generated", journal)
        assertTrue(journal!!.isBalanced)
        assertEquals(IntercompanyTransactionType.INTERCOMPANY_LOAN, journal.transactionType)
    }

    @Test
    fun testNaturalLanguageCommandParser() {
        val proposal1 = repository.parseCommand("Show all companies and their ownership")
        assertTrue(proposal1 is CommandActionProposal.DirectQuery)
        assertTrue((proposal1 as CommandActionProposal.DirectQuery).message.contains("BTCPhilosopherHoldings"))

        val proposal2 = repository.parseCommand("Prepare a capital allocation proposal of £25,000 for Newton Rockets")
        assertTrue(proposal2 is CommandActionProposal.ProposeCapitalAllocation)
        val capProp = proposal2 as CommandActionProposal.ProposeCapitalAllocation
        assertEquals("duke-newton-rockets", capProp.targetEntityId)
        assertEquals(25000.0, capProp.amount, 0.01)

        val proposal3 = repository.parseCommand("Draft a directive for London Kotlin Works to build shared terminal")
        assertTrue(proposal3 is CommandActionProposal.ProposeDirective)
        val dirProp = proposal3 as CommandActionProposal.ProposeDirective
        assertEquals("duke-london-kotlin", dirProp.targetEntityId)
    }
}
