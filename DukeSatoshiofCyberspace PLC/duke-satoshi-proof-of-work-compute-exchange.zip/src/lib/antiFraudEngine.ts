/**
 * Anti-Fraud & Invariant Verification Engine
 * Duke Satoshi Proof-of-Work Compute Exchange
 *
 * Implements strict state machine invariants and fraud tripwires:
 *   NO HARDWARE -> NO WORK
 *   NO WORK -> NO PROOF
 *   NO MEASUREMENT -> NO PROOF
 *   NO VALID OUTPUT -> NO VERIFIED PROOF
 *   NO VERIFIED PROOF -> NO CREDIT
 */

import {
  ComputationalJob,
  ProofRecord,
  ComputationalAttestation,
  DataCentreMint,
  AntiFraudAlert,
} from '../types';

export interface ValidationResult {
  passed: boolean;
  errors: string[];
  warnings: string[];
  alert?: AntiFraudAlert;
}

export class AntiFraudEngine {
  /**
   * Cross-checks hardware existence and capacity limits
   */
  static validateHardwareAllocation(
    job: ComputationalJob,
    dataCentres: DataCentreMint[]
  ): ValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    const centre = dataCentres.find(d => d.id === job.providerId);
    if (!centre) {
      return {
        passed: false,
        errors: [`Data centre ${job.providerId} is not an authorized DSCX Mint facility`],
        warnings,
        alert: {
          alertId: `AFT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          timestamp: new Date().toISOString(),
          type: 'CAPACITY_OVERSTATEMENT',
          severity: 'CRITICAL',
          entityId: job.jobId,
          details: `Unauthorized provider ${job.providerId} attempted job submission without registered hardware`,
          evidence: { providerId: job.providerId, jobId: job.jobId },
          status: 'DETECTED',
        },
      };
    }

    if (job.hardwareIds.length === 0) {
      errors.push('No hardware allocated: INVARIANT VIOLATION (NO HARDWARE -> NO WORK)');
    }

    if (job.resourceConsumption.gpuHoursConsumed > centre.totalGpuCapacity * 24) {
      errors.push(
        `Claimed GPU hours (${job.resourceConsumption.gpuHoursConsumed}) exceeds daily physical capacity (${centre.totalGpuCapacity * 24})`
      );
    }

    return {
      passed: errors.length === 0,
      errors,
      warnings,
    };
  }

  /**
   * Validates continuous telemetry physics:
   * Power vs utilization consistency, memory constraints, clock frequencies
   */
  static validateTelemetryPhysics(
    job: ComputationalJob,
    attestations: ComputationalAttestation[]
  ): ValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];
    let alert: AntiFraudAlert | undefined;

    if (!attestations || attestations.length === 0) {
      return {
        passed: false,
        errors: ['Zero telemetry attestations received: INVARIANT VIOLATION (NO MEASUREMENT -> NO PROOF)'],
        warnings,
        alert: {
          alertId: `AFT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          timestamp: new Date().toISOString(),
          type: 'FAKE_TELEMETRY',
          severity: 'HIGH',
          entityId: job.jobId,
          details: 'Proof generation attempted on unmetered computation stream',
          evidence: { jobId: job.jobId, attestationCount: 0 },
          status: 'DETECTED',
        },
      };
    }

    // Check physics anomalies in telemetry
    for (const sample of attestations) {
      // Anomaly 1: High utilization (>80%) with impossible idle power (<80W for H100/H200 SXM)
      if (sample.gpuUtilisationPercent > 80 && sample.gpuPowerWatts < 100) {
        errors.push(
          `Impossible power physics: GPU ${sample.gpuId} reporting ${sample.gpuUtilisationPercent}% load at only ${sample.gpuPowerWatts}W (Baseline idle is ~120W)`
        );
        alert = {
          alertId: `AFT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          timestamp: new Date().toISOString(),
          type: 'IMPOSSIBLE_POWER',
          severity: 'CRITICAL',
          entityId: sample.gpuId,
          details: `Physics violation: impossible low power consumption during high tensor utilization`,
          evidence: {
            gpuId: sample.gpuId,
            utilPercent: sample.gpuUtilisationPercent,
            powerWatts: sample.gpuPowerWatts,
          },
          status: 'DETECTED',
        };
        break;
      }

      // Anomaly 2: Zero utilization with maximum TDP power (>650W)
      if (sample.gpuUtilisationPercent === 0 && sample.gpuPowerWatts > 600) {
        warnings.push(`Suspicious power draw: 0% utilization with high thermal load (${sample.gpuPowerWatts}W)`);
      }

      // Anomaly 3: Temperature over thermal limit (>95C) without throttle
      if (sample.gpuTemperatureCelsius > 92 && sample.gpuClockMhz > 1900) {
        warnings.push(`Thermal threshold reached (${sample.gpuTemperatureCelsius}°C) without clock throttling`);
      }
    }

    // Check energy balance: MWh consumed must approximately match sum of power * dt
    const avgPowerKw = job.resourceConsumption.avgPowerWatts / 1000;
    const durationHours = job.durationSeconds / 3600;
    const theoreticalKwh = avgPowerKw * durationHours * job.hardwareIds.length;
    const reportedKwh = job.resourceConsumption.totalKwh;

    if (Math.abs(theoreticalKwh - reportedKwh) > theoreticalKwh * 0.35 + 5) {
      warnings.push(
        `Energy discrepancy: Integrated telemetry indicates ~${theoreticalKwh.toFixed(1)} kWh but job reported ${reportedKwh.toFixed(1)} kWh`
      );
    }

    return {
      passed: errors.length === 0,
      errors,
      warnings,
      alert,
    };
  }

  /**
   * Validates Output Commitment against Replay and Duplication
   */
  static validateOutputCommitment(
    job: ComputationalJob,
    existingProofs: ProofRecord[]
  ): ValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    if (!job.outputCommitment || job.outputCommitment.length < 10) {
      return {
        passed: false,
        errors: ['Missing or empty output commitment: INVARIANT VIOLATION (NO VALID OUTPUT -> NO PROOF)'],
        warnings,
      };
    }

    // Check for replay attacks across previous proofs
    const duplicate = existingProofs.find(
      p => p.outputCommitment.toLowerCase() === job.outputCommitment.toLowerCase() && p.jobId !== job.jobId
    );

    if (duplicate) {
      return {
        passed: false,
        errors: [`REPLAY ATTACK DETECTED: Output commitment already registered in prior Proof #${duplicate.proofId}`],
        warnings,
        alert: {
          alertId: `AFT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          timestamp: new Date().toISOString(),
          type: 'REPLAYED_PROOF',
          severity: 'CRITICAL',
          entityId: job.jobId,
          details: `Attestation rejected: Output hash ${job.outputCommitment.slice(0, 14)}... duplicates historic Proof #${duplicate.proofId}`,
          evidence: {
            currentJobId: job.jobId,
            priorProofId: duplicate.proofId,
            replayedHash: job.outputCommitment,
          },
          status: 'QUARANTINED',
        },
      };
    }

    return {
      passed: errors.length === 0,
      errors,
      warnings,
    };
  }

  /**
   * Enforces that credit issuance can only occur on VERIFIED proofs and prevents double-issuance
   */
  static validateCreditIssuanceRule(
    proof: ProofRecord,
    existingCreditsIssued: string[]
  ): ValidationResult {
    const errors: string[] = [];

    if (proof.status !== 'VERIFIED') {
      errors.push(
        `Cannot issue credit: Proof #${proof.proofId} has status '${proof.status}'. (NO VERIFIED PROOF -> NO CREDIT)`
      );
    }

    if (proof.issuedCreditId || existingCreditsIssued.includes(proof.proofId)) {
      return {
        passed: false,
        errors: [`DOUBLE-ISSUANCE VIOLATION: Credits for Proof #${proof.proofId} have already been minted!`],
        warnings: [],
        alert: {
          alertId: `AFT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          timestamp: new Date().toISOString(),
          type: 'DOUBLE_ISSUANCE_ATTEMPT',
          severity: 'CRITICAL',
          entityId: proof.proofId,
          details: `Attempted duplicate credit generation against settled Proof #${proof.proofId}`,
          evidence: { proofId: proof.proofId, alreadyIssuedCreditId: proof.issuedCreditId },
          status: 'DETECTED',
        },
      };
    }

    if (proof.computeConsumedGpuHours <= 0) {
      errors.push('Cannot issue credit: Proof indicates zero GPU hours consumed');
    }

    return {
      passed: errors.length === 0,
      errors,
      warnings: [],
    };
  }
}
