/**
 * Duke Satoshi Proof-of-Work Compute Exchange (DS-PoW)
 * Core Operational State & Execution Context
 * Organisation: Duke Satoshi of Cyberspace PLC
 */

import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import {
  WorkOrder,
  ComputationalJob,
  ProofRecord,
  Credit,
  CreditClass,
  DataCentreMint,
  VerifierEntity,
  DoubleEntryLedgerTransaction,
  SwapContract,
  MarketOrder,
  TradeExecution,
  ProductionCertificate,
  AntiFraudAlert,
  WorkType,
  VerificationAssuranceLevel,
  ComputationalAttestation,
} from '../types';
import {
  WORK_REGISTRY,
  INITIAL_DATA_CENTRES,
  INITIAL_VERIFIERS,
  INITIAL_CREDIT_CLASSES,
  INITIAL_WORK_ORDERS,
  INITIAL_COMPUTATIONAL_JOBS,
  INITIAL_PROOF_CHAIN,
  INITIAL_CREDITS,
  INITIAL_LEDGER_TRANSACTIONS,
  INITIAL_SWAP_CONTRACTS,
  INITIAL_MARKET_ORDERS,
  INITIAL_TRADES,
  INITIAL_PRODUCTION_CERTIFICATES,
} from '../data/initialData';
import { computeProofHash, generateProofSignature, auditEntireProofChain, sha256Sync } from '../lib/crypto';
import { AntiFraudEngine } from '../lib/antiFraudEngine';

interface ComputeExchangeContextType {
  dataCentres: DataCentreMint[];
  workOrders: WorkOrder[];
  jobs: ComputationalJob[];
  proofChain: ProofRecord[];
  verifiers: VerifierEntity[];
  credits: Credit[];
  creditClasses: CreditClass[];
  ledger: DoubleEntryLedgerTransaction[];
  swaps: SwapContract[];
  orders: MarketOrder[];
  trades: TradeExecution[];
  certificates: ProductionCertificate[];
  alerts: AntiFraudAlert[];
  liveGpuTelemetry: ComputationalAttestation;
  isSimulating: boolean;
  selectedProofForInspection: ProofRecord | null;
  setSelectedProofForInspection: (proof: ProofRecord | null) => void;

  // Actions
  createWorkOrder: (order: Partial<WorkOrder>) => WorkOrder;
  dispatchJob: (workOrderId: string, providerId: string) => ComputationalJob;
  runJobSimulation: (jobId: string, durationSec?: number) => Promise<ProofRecord | null>;
  generateProof: (jobId: string) => ProofRecord | null;
  verifyProofWithConsensus: (proofId: string) => Promise<boolean>;
  issueCreditsForProof: (proofId: string) => Credit | null;
  placeOrder: (order: Omit<MarketOrder, 'orderId' | 'filled' | 'status' | 'timestamp'>) => MarketOrder;
  executeSwap: (swapId: string) => boolean;
  createSwapProposal: (proposal: Partial<SwapContract>) => SwapContract;
  redeemCreditCapacity: (creditId: string, targetCentreId: string, quantity: number) => boolean;
  triggerFraudSimulation: (type: 'IMPOSSIBLE_POWER' | 'REPLAY_OUTPUT' | 'NO_WORK_CREDIT') => void;
  verifyChainIntegrity: () => { isChainValid: boolean; brokenIndex?: number; error?: string };
  executeVerticalSlice1: () => Promise<void>;
  executeVerticalSlice2: () => Promise<void>;
  executeVerticalSlice3: () => Promise<void>;
  executeVerticalSlice4: () => Promise<void>;
  dismissAlert: (alertId: string) => void;
}

const ComputeExchangeContext = createContext<ComputeExchangeContextType | undefined>(undefined);

export const ComputeExchangeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [dataCentres, setDataCentres] = useState<DataCentreMint[]>(INITIAL_DATA_CENTRES);
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>(INITIAL_WORK_ORDERS);
  const [jobs, setJobs] = useState<ComputationalJob[]>(INITIAL_COMPUTATIONAL_JOBS);
  const [proofChain, setProofChain] = useState<ProofRecord[]>(INITIAL_PROOF_CHAIN);
  const [verifiers, setVerifiers] = useState<VerifierEntity[]>(INITIAL_VERIFIERS);
  const [credits, setCredits] = useState<Credit[]>(INITIAL_CREDITS);
  const [creditClasses] = useState<CreditClass[]>(INITIAL_CREDIT_CLASSES);
  const [ledger, setLedger] = useState<DoubleEntryLedgerTransaction[]>(INITIAL_LEDGER_TRANSACTIONS);
  const [swaps, setSwaps] = useState<SwapContract[]>(INITIAL_SWAP_CONTRACTS);
  const [orders, setOrders] = useState<MarketOrder[]>(INITIAL_MARKET_ORDERS);
  const [trades, setTrades] = useState<TradeExecution[]>(INITIAL_TRADES);
  const [certificates, setCertificates] = useState<ProductionCertificate[]>(INITIAL_PRODUCTION_CERTIFICATES);
  const [alerts, setAlerts] = useState<AntiFraudAlert[]>([]);
  const [isSimulating, setIsSimulating] = useState(false);
  const [selectedProofForInspection, setSelectedProofForInspection] = useState<ProofRecord | null>(null);

  // High-fidelity live telemetry sample for GPU #382 (Duke Satoshi London Crown Mint)
  const [liveGpuTelemetry, setLiveGpuTelemetry] = useState<ComputationalAttestation>({
    timestamp: new Date().toISOString(),
    gpuId: 'H200-SXM5-R04-G382',
    gpuModel: 'NVIDIA H200 SXM5 141GB HBM3e',
    gpuUtilisationPercent: 98.4,
    gpuMemoryUsedGb: 139.4,
    gpuMemoryTotalGb: 141.0,
    gpuPowerWatts: 708,
    gpuTemperatureCelsius: 64,
    gpuClockMhz: 1980,
    cpuUtilisationPercent: 41.2,
    ramUtilisationPercent: 84.1,
    networkThroughputGbps: 396.4,
    storageIops: 215000,
    schedulerState: 'RUNNING',
    processId: 'PID_88392_TORCH',
    containerId: 'CTR_DSCX_DEEPSEEK_04',
    workloadIdentity: 'DSCX-LLM-70B-DEEPSEEK-V3',
    attestationSignature: 'SIG_LON01_HWATTEST_R4_G382_VALID',
  });

  // Background heartbeat updating live telemetry jitter
  useEffect(() => {
    const timer = setInterval(() => {
      setLiveGpuTelemetry(prev => {
        const utilJitter = (Math.random() - 0.5) * 1.5;
        const newUtil = Math.min(99.9, Math.max(95.0, prev.gpuUtilisationPercent + utilJitter));
        const powerJitter = (Math.random() - 0.5) * 8;
        const newPower = Math.round(Math.min(715, Math.max(695, prev.gpuPowerWatts + powerJitter)));
        const tempJitter = (Math.random() - 0.5) * 0.4;
        const newTemp = Math.round(Math.min(67, Math.max(62, prev.gpuTemperatureCelsius + tempJitter)));

        return {
          ...prev,
          timestamp: new Date().toISOString(),
          gpuUtilisationPercent: parseFloat(newUtil.toFixed(1)),
          gpuPowerWatts: newPower,
          gpuTemperatureCelsius: newTemp,
          networkThroughputGbps: parseFloat((390 + Math.random() * 12).toFixed(1)),
          storageIops: Math.round(210000 + Math.random() * 12000),
          attestationSignature: `SIG_LON01_HWATTEST_R4_G382_${Date.now().toString(16).slice(-6)}`,
        };
      });
    }, 2500);

    return () => clearInterval(timer);
  }, []);

  const dismissAlert = useCallback((alertId: string) => {
    setAlerts(prev => prev.filter(a => a.alertId !== alertId));
  }, []);

  /**
   * 1. CREATE WORK ORDER
   */
  const createWorkOrder = useCallback((params: Partial<WorkOrder>): WorkOrder => {
    const provider = dataCentres.find(d => d.id === params.providerId) || dataCentres[0];
    const newOrder: WorkOrder = {
      orderId: `WO-2027-${params.providerId?.slice(5, 8) || 'LON'}-${(workOrders.length + 101).toString().padStart(4, '0')}`,
      providerId: provider.id,
      providerName: provider.name,
      customerId: params.customerId || 'CLI-DEFAULT-ENTERPRISE',
      customerName: params.customerName || 'Institutional Compute Partner',
      workType: params.workType || 'AI_TRAINING',
      title: params.title || 'Verified Enterprise Compute Pipeline',
      requiredComputeGpuHours: params.requiredComputeGpuHours || 1000,
      accelerator: params.accelerator || 'H200',
      expectedOutput: params.expectedOutput || 'Deterministic Checkpoint Set + Validation Output Hash',
      assuranceLevel: params.assuranceLevel || 'INSTITUTIONAL',
      deadline: params.deadline || new Date(Date.now() + 14 * 86400000).toISOString(),
      createdAt: new Date().toISOString(),
      status: 'SUBMITTED',
      associatedJobIds: [],
    };

    setWorkOrders(prev => [newOrder, ...prev]);
    return newOrder;
  }, [dataCentres, workOrders.length]);

  /**
   * 2. DISPATCH COMPUTATIONAL JOB
   */
  const dispatchJob = useCallback((workOrderId: string, providerId: string): ComputationalJob => {
    const wo = workOrders.find(w => w.orderId === workOrderId);
    const spec = WORK_REGISTRY[wo?.workType || 'AI_TRAINING'];
    const jobId = `JOB-${providerId.slice(5, 8).toUpperCase()}-${Math.floor(88400 + Math.random() * 900)}`;

    const newJob: ComputationalJob = {
      jobId,
      workOrderId,
      providerId,
      clusterId: `${providerId.slice(5, 8).toUpperCase()}-CLUSTER-ALPHA`,
      hardwareIds: ['H200-SXM5-R05-G401', 'H200-SXM5-R05-G402', 'H200-SXM5-R05-G403', 'H200-SXM5-R05-G404'],
      workType: wo?.workType || 'AI_TRAINING',
      softwareEnvironment: {
        cudaVersion: '12.6.2',
        driverVersion: '560.35.03',
        osKernel: 'Linux 6.8.0-45-generic',
        containerHash: `sha256:${sha256Sync(jobId + '_CONTAINER').slice(0, 64)}`,
        framework: 'Megatron-LM v0.7 + FlashAttention-3 (BF16)',
      },
      datasetCommitment: spec.datasetCommitment || '0x' + sha256Sync(jobId + '_DATASET'),
      modelCommitment: '0x' + sha256Sync(jobId + '_MODEL'),
      startTime: new Date().toISOString(),
      durationSeconds: 3600,
      resourceConsumption: {
        gpuHoursConsumed: wo?.requiredComputeGpuHours || 1000,
        totalKwh: (wo?.requiredComputeGpuHours || 1000) * 0.72,
        avgPowerWatts: 705,
        avgGpuUtilPercent: 98.2,
        peakMemoryGb: 139.2,
      },
      outputCommitment: '0x' + sha256Sync(jobId + '_OUTPUT_COMMITMENT_' + Date.now()),
      checkpointHashes: [
        '0x' + sha256Sync(jobId + '_CHK_1'),
        '0x' + sha256Sync(jobId + '_CHK_2'),
      ],
      verificationStatus: 'RUNNING',
      telemetryStream: [
        {
          timestamp: new Date().toISOString(),
          gpuId: 'H200-SXM5-R05-G401',
          gpuModel: 'NVIDIA H200 SXM5 141GB',
          gpuUtilisationPercent: 98.5,
          gpuMemoryUsedGb: 139.1,
          gpuMemoryTotalGb: 141.0,
          gpuPowerWatts: 708,
          gpuTemperatureCelsius: 63,
          gpuClockMhz: 1980,
          cpuUtilisationPercent: 39.0,
          ramUtilisationPercent: 81.0,
          networkThroughputGbps: 392.0,
          storageIops: 204000,
          schedulerState: 'RUNNING',
          processId: `PID_${jobId}`,
          containerId: `CTR_${jobId}`,
          workloadIdentity: spec.modelIdentifier || 'DSCX-WORKLOAD-STANDARD',
          attestationSignature: `SIG_${providerId}_ATTEST_${jobId}`,
        },
      ],
      aiWorkMetrics: wo?.workType === 'AI_TRAINING' ? {
        lossTrajectory: [3.50, 3.05, 2.62, 2.19, 1.84, 1.58, 1.39, 1.25],
        tokensProcessedMillion: 12500,
        throughputTokensPerSec: 1120000,
        validationPerplexity: 4.08,
      } : undefined,
    };

    setJobs(prev => [newJob, ...prev]);
    setWorkOrders(prev =>
      prev.map(w =>
        w.orderId === workOrderId
          ? { ...w, status: 'IN_EXECUTION', associatedJobIds: [...w.associatedJobIds, jobId] }
          : w
      )
    );

    return newJob;
  }, [dataCentres, workOrders]);

  /**
   * 3. GENERATE PROOF RECORD (Pluggable Proof Engine)
   */
  const generateProof = useCallback((jobId: string): ProofRecord | null => {
    const job = jobs.find(j => j.jobId === jobId);
    if (!job) return null;

    // Check invariants with AntiFraudEngine
    const hwCheck = AntiFraudEngine.validateHardwareAllocation(job, dataCentres);
    if (!hwCheck.passed) {
      if (hwCheck.alert) setAlerts(prev => [hwCheck.alert!, ...prev]);
      return null;
    }

    const telemCheck = AntiFraudEngine.validateTelemetryPhysics(job, job.telemetryStream);
    if (!telemCheck.passed) {
      if (telemCheck.alert) setAlerts(prev => [telemCheck.alert!, ...prev]);
      return null;
    }

    const outputCheck = AntiFraudEngine.validateOutputCommitment(job, proofChain);
    if (!outputCheck.passed) {
      if (outputCheck.alert) setAlerts(prev => [outputCheck.alert!, ...prev]);
      return null;
    }

    const lastProof = proofChain[proofChain.length - 1];
    const sequenceNumber = lastProof ? lastProof.sequenceNumber + 1 : 0;
    const previousProofHash = lastProof
      ? lastProof.proofHash
      : '0x0000000000000000000000000000000000000000000000000000000000000000';

    const executionEnd = new Date().toISOString();
    const measurementRootHash = '0x' + sha256Sync(job.jobId + '_TELEMETRY_MERKLE_' + Date.now());

    const proofHash = computeProofHash({
      providerId: job.providerId,
      hardwareSummary: `${job.hardwareIds.length}x ${job.softwareEnvironment.framework}`,
      jobId: job.jobId,
      workType: job.workType,
      inputCommitment: job.datasetCommitment,
      outputCommitment: job.outputCommitment,
      measurementRootHash,
      executionStart: job.startTime,
      executionEnd,
      computeConsumedGpuHours: job.resourceConsumption.gpuHoursConsumed,
      energyConsumedMwh: job.resourceConsumption.totalKwh / 1000,
      previousProofHash,
    });

    const newProof: ProofRecord = {
      proofId: (88290 + sequenceNumber).toString().padStart(8, '0'),
      sequenceNumber,
      previousProofHash,
      proofHash,
      jobId: job.jobId,
      workOrderId: job.workOrderId,
      providerId: job.providerId,
      clusterId: job.clusterId,
      hardwareSummary: `${job.hardwareIds.length}x NVIDIA H200 SXM5 141GB Array`,
      workType: job.workType,
      algorithm: job.softwareEnvironment.framework,
      inputCommitment: job.datasetCommitment,
      outputCommitment: job.outputCommitment,
      executionStart: job.startTime,
      executionEnd,
      computeConsumedGpuHours: job.resourceConsumption.gpuHoursConsumed,
      energyConsumedMwh: parseFloat((job.resourceConsumption.totalKwh / 1000).toFixed(4)),
      pue: 1.12,
      softwareHash: job.softwareEnvironment.containerHash,
      containerHash: job.softwareEnvironment.containerHash,
      checkpointHash: job.checkpointHashes[0] || '0x0',
      measurementRootHash,
      assuranceLevel: 'INSTITUTIONAL',
      verifiers: [],
      status: 'PENDING',
      qualityScore: 99.6,
      efficiencyScore: 26.2,
      creditsIssued: 0,
      signature: generateProofSignature(proofHash, job.providerId),
      timestamp: executionEnd,
    };

    setProofChain(prev => [...prev, newProof]);
    setJobs(prev =>
      prev.map(j => (j.jobId === jobId ? { ...j, verificationStatus: 'ATTESTED', endTime: executionEnd } : j))
    );
    setSelectedProofForInspection(newProof);

    return newProof;
  }, [dataCentres, jobs, proofChain]);

  /**
   * 4. INDEPENDENT VERIFIER CONSENSUS
   */
  const verifyProofWithConsensus = useCallback(async (proofId: string): Promise<boolean> => {
    const proof = proofChain.find(p => p.proofId === proofId);
    if (!proof) return false;

    // Simulate multi-party cryptographic attestation by independent verifier nodes
    const attestations = verifiers.map(v => ({
      verifierId: v.id,
      verifierName: v.name,
      status: 'APPROVED' as const,
      confidenceScore: parseFloat((0.995 + Math.random() * 0.004).toFixed(4)),
      method: `Independent Cryptographic Audit & Telemetry Validation (${v.organization.slice(0, 24)})`,
      signature: `SIG_${v.id}_CONSENSUS_${proof.proofHash.slice(2, 12)}`,
      timestamp: new Date().toISOString(),
      auditNotes: `Certified productive execution for ${proof.workType} (${proof.computeConsumedGpuHours} GPU-hrs) across dual-metered PUE telemetry.`,
    }));

    setProofChain(prev =>
      prev.map(p =>
        p.proofId === proofId
          ? {
              ...p,
              status: 'VERIFIED',
              verifiers: attestations,
            }
          : p
      )
    );

    // Update work order status
    if (proof.workOrderId) {
      setWorkOrders(prev =>
        prev.map(w => (w.orderId === proof.workOrderId ? { ...w, status: 'COMPLETED' } : w))
      );
    }

    return true;
  }, [proofChain, verifiers]);

  /**
   * 5. ISSUE CREDITS FOR VERIFIED PROOF
   */
  const issueCreditsForProof = useCallback((proofId: string): Credit | null => {
    const proof = proofChain.find(p => p.proofId === proofId);
    if (!proof) return null;

    const issuedProofIds = credits.flatMap(c => c.associatedProofIds);
    const ruleCheck = AntiFraudEngine.validateCreditIssuanceRule(proof, issuedProofIds);
    if (!ruleCheck.passed) {
      if (ruleCheck.alert) setAlerts(prev => [ruleCheck.alert!, ...prev]);
      return null;
    }

    const creditId = `CR-${proof.providerId.slice(5, 8).toUpperCase()}-H200-${proof.proofId}`;
    const quantity = proof.computeConsumedGpuHours;

    const newCredit: Credit = {
      creditId,
      classId: 'DS-H200',
      quantityGpuHours: quantity,
      issuerCentreId: proof.providerId,
      issueDate: new Date().toISOString(),
      proofRange: `#${proof.proofId}`,
      associatedProofIds: [proof.proofId],
      ownerId: 'OWNER-DSCX-TREASURY',
      ownerName: 'Duke Satoshi Liquidity Reserve',
      status: 'CIRCULATING',
      provenance: {
        dataCentre: proof.providerId,
        cluster: proof.clusterId,
        hardware: proof.hardwareSummary,
        workType: proof.workType,
        jobId: proof.jobId,
        workOrderId: proof.workOrderId,
        proofId: proof.proofId,
        assuranceLevel: proof.assuranceLevel,
        energyMwh: proof.energyConsumedMwh,
        carbonOffsetKg: Math.round(proof.energyConsumedMwh * 420),
      },
    };

    // Double-entry ledger entry
    const newTx: DoubleEntryLedgerTransaction = {
      txId: `TX-DSCX-LEDGER-${(ledger.length + 1).toString().padStart(4, '0')}`,
      sequence: ledger.length + 1,
      type: 'ISSUE',
      creditId,
      creditClass: 'DS-H200',
      quantity,
      debitAccount: 'ACT-UNISSUED-PROVEN-COMPUTE',
      creditAccount: 'ACT-TREASURY-CIRCULATING',
      proofRef: `PROOF-#${proof.proofId}`,
      description: `Proof-of-Production Issuance: ${quantity} verified GPU-hours from ${proof.providerId}`,
      timestamp: new Date().toISOString(),
      signature: `SIG_DSCX_MINT_TX_${ledger.length + 1}`,
    };

    setCredits(prev => [newCredit, ...prev]);
    setLedger(prev => [...prev, newTx]);
    setProofChain(prev =>
      prev.map(p =>
        p.proofId === proofId ? { ...p, creditsIssued: quantity, issuedCreditId: creditId } : p
      )
    );

    // Update Mint total verified hours & issued credits
    setDataCentres(prev =>
      prev.map(d =>
        d.id === proof.providerId
          ? {
              ...d,
              verifiedGpuHours: d.verifiedGpuHours + quantity,
              creditsIssued: d.creditsIssued + quantity,
            }
          : d
      )
    );

    return newCredit;
  }, [credits, ledger.length, proofChain]);

  /**
   * 6. REDEEM CREDITS & PERMANENT RETIREMENT
   */
  const redeemCreditCapacity = useCallback(
    (creditId: string, targetCentreId: string, quantity: number): boolean => {
      const credit = credits.find(c => c.creditId === creditId && c.status === 'CIRCULATING');
      if (!credit || credit.quantityGpuHours < quantity) return false;

      // Update credit status to RETIRED
      setCredits(prev =>
        prev.map(c =>
          c.creditId === creditId
            ? { ...c, status: 'RETIRED' }
            : c
        )
      );

      // Add double entry retirement transaction
      const retirementTx: DoubleEntryLedgerTransaction = {
        txId: `TX-DSCX-LEDGER-${(ledger.length + 1).toString().padStart(4, '0')}`,
        sequence: ledger.length + 1,
        type: 'RETIRE',
        creditId,
        creditClass: credit.classId,
        quantity,
        debitAccount: `ACT-OWNER-${credit.ownerId}`,
        creditAccount: 'ACT-RETIRED-SINK-PERMANENT',
        proofRef: credit.proofRange,
        description: `Physical Capacity Redemption at ${targetCentreId}. Credits permanently retired from circulation.`,
        timestamp: new Date().toISOString(),
        signature: `SIG_DSCX_RETIRE_TX_${Date.now().toString(16)}`,
      };

      setLedger(prev => [...prev, retirementTx]);

      // Update Mint statistics
      setDataCentres(prev =>
        prev.map(d =>
          d.id === targetCentreId
            ? { ...d, creditsRedeemed: d.creditsRedeemed + quantity }
            : d
        )
      );

      return true;
    },
    [credits, ledger.length]
  );

  /**
   * 7. MARKET TRADING & ORDER BOOK
   */
  const placeOrder = useCallback(
    (orderParams: Omit<MarketOrder, 'orderId' | 'filled' | 'status' | 'timestamp'>): MarketOrder => {
      const orderId = `ORD-${Date.now().toString(16).slice(-6).toUpperCase()}`;
      const newOrder: MarketOrder = {
        ...orderParams,
        orderId,
        filled: 0,
        status: 'OPEN',
        timestamp: new Date().toISOString(),
      };

      // Check if immediate match against opposite side
      const oppositeSide = orderParams.side === 'BID' ? 'ASK' : 'BID';
      const matchCandidate = orders.find(
        o =>
          o.pair === orderParams.pair &&
          o.side === oppositeSide &&
          o.status !== 'FILLED' &&
          (orderParams.side === 'BID' ? o.price <= orderParams.price : o.price >= orderParams.price)
      );

      if (matchCandidate) {
        const fillAmount = Math.min(newOrder.quantity, matchCandidate.quantity - matchCandidate.filled);
        const execPrice = matchCandidate.price;

        const trade: TradeExecution = {
          tradeId: `TRD-${Date.now().toString(16).slice(-6).toUpperCase()}`,
          pair: orderParams.pair,
          side: orderParams.side === 'BID' ? 'BUY' : 'SELL',
          price: execPrice,
          quantity: fillAmount,
          buyer: orderParams.side === 'BID' ? orderParams.traderName : matchCandidate.traderName,
          seller: orderParams.side === 'ASK' ? orderParams.traderName : matchCandidate.traderName,
          timestamp: new Date().toISOString(),
          settlementTxId: `TX-SETTLE-${Date.now().toString(16)}`,
        };

        setTrades(prev => [trade, ...prev]);

        newOrder.filled = fillAmount;
        newOrder.status = fillAmount === newOrder.quantity ? 'FILLED' : 'PARTIAL';

        setOrders(prev =>
          prev.map(o =>
            o.orderId === matchCandidate.orderId
              ? {
                  ...o,
                  filled: o.filled + fillAmount,
                  status: o.filled + fillAmount >= o.quantity ? 'FILLED' : 'PARTIAL',
                }
              : o
          )
        );
      }

      setOrders(prev => [newOrder, ...prev]);
      return newOrder;
    },
    [orders]
  );

  /**
   * 8. COMPUTE SWAP PROPOSAL & SETTLEMENT
   */
  const createSwapProposal = useCallback((proposal: Partial<SwapContract>): SwapContract => {
    const swapId = `SWAP-2027-${Math.floor(100 + Math.random() * 900)}`;
    const newSwap: SwapContract = {
      swapId,
      partyA: proposal.partyA || {
        id: 'CLI-AERO-ROLLSROYCE',
        name: 'Rolls-Royce Aerodynamics PLC',
        offeringClass: 'DS-H100',
        quantity: 50000,
      },
      partyB: proposal.partyB || {
        id: 'CLI-DEEP-AI-ENT',
        name: 'Cognitive Dynamics Enterprise AI',
        offeringClass: 'DS-H200',
        quantity: 40000,
      },
      conversionRatio: proposal.conversionRatio || 1.25,
      deliveryWindow: proposal.deliveryWindow || 'Q1 2027 (Jan 20 – Mar 31)',
      locationSla: proposal.locationSla || 'Slough Tier IV to MediaCityUK Interlink (<2ms latency)',
      cashAdjustmentUsd: proposal.cashAdjustmentUsd || 0,
      status: 'PROPOSED',
      settlementLegs: {
        legAtoB: `TX-LEG-A-${swapId}`,
        legBtoA: `TX-LEG-B-${swapId}`,
      },
      createdAt: new Date().toISOString(),
    };

    setSwaps(prev => [newSwap, ...prev]);
    return newSwap;
  }, []);

  const executeSwap = useCallback((swapId: string): boolean => {
    const target = swaps.find(s => s.swapId === swapId);
    if (!target) return false;

    setSwaps(prev =>
      prev.map(s =>
        s.swapId === swapId
          ? { ...s, status: 'SETTLED', settledAt: new Date().toISOString() }
          : s
      )
    );

    // Add swap settlement to double-entry ledger
    const swapTx: DoubleEntryLedgerTransaction = {
      txId: `TX-DSCX-LEDGER-${(ledger.length + 1).toString().padStart(4, '0')}`,
      sequence: ledger.length + 1,
      type: 'SWAP',
      creditId: `SWAP-SETTLEMENT-${swapId}`,
      creditClass: `${target.partyA.offeringClass} <-> ${target.partyB.offeringClass}`,
      quantity: target.partyA.quantity,
      debitAccount: `ACT-${target.partyA.id}`,
      creditAccount: `ACT-${target.partyB.id}`,
      proofRef: `SWAP-CONTRACT-${swapId}`,
      description: `Bilateral compute swap settlement: ${target.partyA.quantity} ${target.partyA.offeringClass} for ${target.partyB.quantity} ${target.partyB.offeringClass}`,
      timestamp: new Date().toISOString(),
      signature: `SIG_DSCX_SWAP_${swapId}`,
    };

    setLedger(prev => [...prev, swapTx]);
    return true;
  }, [ledger.length, swaps]);

  /**
   * 9. SIMULATED JOB RUNNER WITH PROGRESS
   */
  const runJobSimulation = useCallback(
    async (jobId: string, durationSec = 3): Promise<ProofRecord | null> => {
      setIsSimulating(true);
      await new Promise(res => setTimeout(res, durationSec * 1000));
      const proof = generateProof(jobId);
      if (proof) {
        await verifyProofWithConsensus(proof.proofId);
        issueCreditsForProof(proof.proofId);
      }
      setIsSimulating(false);
      return proof;
    },
    [generateProof, issueCreditsForProof, verifyProofWithConsensus]
  );

  /**
   * 10. ANTI-FRAUD SIMULATION TRIPWIRES
   */
  const triggerFraudSimulation = useCallback(
    (type: 'IMPOSSIBLE_POWER' | 'REPLAY_OUTPUT' | 'NO_WORK_CREDIT') => {
      if (type === 'IMPOSSIBLE_POWER') {
        const alert: AntiFraudAlert = {
          alertId: `AFT-ERR-${Date.now()}`,
          timestamp: new Date().toISOString(),
          type: 'IMPOSSIBLE_POWER',
          severity: 'CRITICAL',
          entityId: 'GPU-H200-SXM5-R02-G104',
          details:
            'Physics Invariant Breached: GPU reporting 100% Tensor Core load at only 38 Watts power draw (Theoretical minimum idle: 120W). Telemetry attestation rejected.',
          evidence: {
            gpuId: 'GPU-H200-SXM5-R02-G104',
            reportedUtil: '100.0%',
            reportedPower: '38 W',
            baselineIdle: '120 W',
            tdpLimit: '700 W',
          },
          status: 'DETECTED',
        };
        setAlerts(prev => [alert, ...prev]);
      } else if (type === 'REPLAY_OUTPUT') {
        const lastProof = proofChain[proofChain.length - 1];
        const alert: AntiFraudAlert = {
          alertId: `AFT-ERR-${Date.now()}`,
          timestamp: new Date().toISOString(),
          type: 'REPLAYED_PROOF',
          severity: 'CRITICAL',
          entityId: 'JOB-ROGUE-99999',
          details: `Replay Attack Blocked: Submitted output commitment hash duplicates settled Proof #${lastProof?.proofId || '00088291'}. Re-issuance denied.`,
          evidence: {
            replayedOutputHash: lastProof?.outputCommitment || '0x88392fa9019283748291048571928374',
            originalProofId: lastProof?.proofId,
          },
          status: 'QUARANTINED',
        };
        setAlerts(prev => [alert, ...prev]);
      } else if (type === 'NO_WORK_CREDIT') {
        const alert: AntiFraudAlert = {
          alertId: `AFT-ERR-${Date.now()}`,
          timestamp: new Date().toISOString(),
          type: 'FABRICATED_JOB',
          severity: 'HIGH',
          entityId: 'MINT-DISPATCH-000',
          details:
            'Software Invariant Enforced: (NO WORK -> NO PROOF -> NO CREDIT). Credit issuance button click denied without prior verified computational execution.',
          evidence: { reason: 'Missing hardware telemetry attestation stream and verifier signatures' },
          status: 'DETECTED',
        };
        setAlerts(prev => [alert, ...prev]);
      }
    },
    [proofChain]
  );

  /**
   * 11. AUDIT ENTIRE PROOF CHAIN
   */
  const verifyChainIntegrity = useCallback(() => {
    return auditEntireProofChain(proofChain);
  }, [proofChain]);

  /**
   * VERTICAL SLICE 1:
   * Register Data Centre/GPU -> Work Order -> Synthetic Verified Workload -> Telemetry -> Proof -> Consensus -> Credit -> Ledger -> Provenance
   */
  const executeVerticalSlice1 = useCallback(async () => {
    setIsSimulating(true);
    // 1. Create order
    const order = createWorkOrder({
      providerId: 'DSCX-London-01',
      customerId: 'CLI-UK-MET-OFFICE',
      customerName: 'UK Met Office Climate Computing',
      workType: 'PHYSICS_SIMULATION',
      title: 'North Atlantic Hurricane Storm Surge Hydrodynamic Model',
      requiredComputeGpuHours: 2500,
      accelerator: 'H200',
    });

    // 2. Dispatch Job
    const job = dispatchJob(order.orderId, 'DSCX-London-01');

    // 3. Simulate execution & telemetry
    await new Promise(r => setTimeout(r, 1500));

    // 4. Generate Proof
    const proof = generateProof(job.jobId);
    if (proof) {
      await new Promise(r => setTimeout(r, 1000));
      // 5. Independent consensus
      await verifyProofWithConsensus(proof.proofId);
      await new Promise(r => setTimeout(r, 800));
      // 6. Issue Credit
      issueCreditsForProof(proof.proofId);
    }
    setIsSimulating(false);
  }, [createWorkOrder, dispatchJob, generateProof, issueCreditsForProof, verifyProofWithConsensus]);

  /**
   * VERTICAL SLICE 2:
   * Genuine AI Workload (DeepSeek-v3 fine-tuning with loss trajectory, checkpoints, and token throughput)
   */
  const executeVerticalSlice2 = useCallback(async () => {
    setIsSimulating(true);
    const order = createWorkOrder({
      providerId: 'DSCX-London-01',
      customerId: 'CLI-BIO-GENOME',
      customerName: 'Oxford Nanopore BioComputing',
      workType: 'AI_TRAINING',
      title: 'Frontier Bio-Molecular Foundation Model (Step 80,000)',
      requiredComputeGpuHours: 5000,
      accelerator: 'H200',
      expectedOutput: 'BF16 Model Weight Checkpoints + Validation Perplexity < 3.8',
    });

    const job = dispatchJob(order.orderId, 'DSCX-London-01');
    await new Promise(r => setTimeout(r, 1600));

    const proof = generateProof(job.jobId);
    if (proof) {
      await new Promise(r => setTimeout(r, 1000));
      await verifyProofWithConsensus(proof.proofId);
      issueCreditsForProof(proof.proofId);
    }
    setIsSimulating(false);
  }, [createWorkOrder, dispatchJob, generateProof, issueCreditsForProof, verifyProofWithConsensus]);

  /**
   * VERTICAL SLICE 3:
   * Dual Data Centre Arbitrage (London-01 H200 <-> Manchester-01 H100 swap)
   */
  const executeVerticalSlice3 = useCallback(async () => {
    setIsSimulating(true);
    const swap = createSwapProposal({
      partyA: {
        id: 'DSCX-London-01-TREASURY',
        name: 'London Crown Mint (H200)',
        offeringClass: 'DS-H200',
        quantity: 20000,
      },
      partyB: {
        id: 'DSCX-Manchester-01-TREASURY',
        name: 'Manchester Powerhouse Mint (H100)',
        offeringClass: 'DS-H100',
        quantity: 25000,
      },
      conversionRatio: 1.25,
      deliveryWindow: 'Prompt Spot Bilateral Swap',
    });

    await new Promise(r => setTimeout(r, 1200));
    executeSwap(swap.swapId);
    setIsSimulating(false);
  }, [createSwapProposal, executeSwap]);

  /**
   * VERTICAL SLICE 4:
   * Full Market: Produce -> Buy -> Swap -> Redeem to RETIRED
   */
  const executeVerticalSlice4 = useCallback(async () => {
    setIsSimulating(true);
    // 1. Place order
    placeOrder({
      pair: 'DS-H200/USD',
      side: 'BID',
      type: 'LIMIT',
      price: 4.86,
      quantity: 2000,
      traderId: 'TRADER-ENTERPRISE-SIM',
      traderName: 'Astra BioMolecular Labs',
    });

    await new Promise(r => setTimeout(r, 1000));

    // 2. Find circulating credit to redeem
    const credit = credits.find(c => c.status === 'CIRCULATING' && c.classId === 'DS-H200');
    if (credit) {
      redeemCreditCapacity(credit.creditId, 'DSCX-London-01', Math.min(1000, credit.quantityGpuHours));
    }
    setIsSimulating(false);
  }, [credits, placeOrder, redeemCreditCapacity]);

  return (
    <ComputeExchangeContext.Provider
      value={{
        dataCentres,
        workOrders,
        jobs,
        proofChain,
        verifiers,
        credits,
        creditClasses,
        ledger,
        swaps,
        orders,
        trades,
        certificates,
        alerts,
        liveGpuTelemetry,
        isSimulating,
        selectedProofForInspection,
        setSelectedProofForInspection,
        createWorkOrder,
        dispatchJob,
        runJobSimulation,
        generateProof,
        verifyProofWithConsensus,
        issueCreditsForProof,
        placeOrder,
        executeSwap,
        createSwapProposal,
        redeemCreditCapacity,
        triggerFraudSimulation,
        verifyChainIntegrity,
        executeVerticalSlice1,
        executeVerticalSlice2,
        executeVerticalSlice3,
        executeVerticalSlice4,
        dismissAlert,
      }}
    >
      {children}
    </ComputeExchangeContext.Provider>
  );
};

export const useComputeExchange = () => {
  const context = useContext(ComputeExchangeContext);
  if (!context) {
    throw new Error('useComputeExchange must be used within a ComputeExchangeProvider');
  }
  return context;
};
