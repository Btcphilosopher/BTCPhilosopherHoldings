/**
 * Duke Satoshi Proof-of-Work Compute Exchange (DS-PoW)
 * Main Application Orchestrator
 * Organisation: Duke Satoshi of Cyberspace PLC
 */

import React, { useState } from 'react';
import { ComputeExchangeProvider, useComputeExchange } from './context/ComputeExchangeContext';
import { Header } from './components/Header';
import { AntiFraudBanner } from './components/AntiFraudBanner';
import { ProofModal } from './components/ProofModal';
import { ProvenanceDrawer } from './components/ProvenanceDrawer';
import { CreateOrderModal } from './components/CreateOrderModal';

// Views
import { OverviewView } from './components/views/OverviewView';
import { DataCentresView } from './components/views/DataCentresView';
import { ProofChainView } from './components/views/ProofChainView';
import { VerificationView } from './components/views/VerificationView';
import { CreditsLedgerView } from './components/views/CreditsLedgerView';
import { MarketView } from './components/views/MarketView';
import { SwapsView } from './components/views/SwapsView';
import { RedemptionView } from './components/views/RedemptionView';
import { DigitalTwinView } from './components/views/DigitalTwinView';
import { CertificatesView } from './components/views/CertificatesView';
import { ApiExplorerView } from './components/views/ApiExplorerView';
import { ProofRecord, Credit } from './types';

const MainContent: React.FC = () => {
  const { proofChain } = useComputeExchange();
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [inspectedProof, setInspectedProof] = useState<ProofRecord | null>(null);
  const [inspectedCredit, setInspectedCredit] = useState<Credit | null>(null);
  const [isNewOrderModalOpen, setIsNewOrderModalOpen] = useState(false);

  const handleInspectProofById = (proofId: string) => {
    const p = proofChain.find(item => item.proofId === proofId);
    if (p) {
      setInspectedProof(p);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-200">
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenNewOrder={() => setIsNewOrderModalOpen(true)}
      />

      <AntiFraudBanner />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {activeTab === 'overview' && (
          <OverviewView
            onInspectProof={handleInspectProofById}
            setActiveTab={setActiveTab}
          />
        )}
        {activeTab === 'datacentres' && (
          <DataCentresView onInspectProof={handleInspectProofById} />
        )}
        {activeTab === 'proofchain' && (
          <ProofChainView onInspectProof={handleInspectProofById} />
        )}
        {activeTab === 'verification' && <VerificationView />}
        {activeTab === 'credits' && (
          <CreditsLedgerView
            onSelectCreditForProvenance={setInspectedCredit}
            onInspectProof={handleInspectProofById}
          />
        )}
        {activeTab === 'market' && <MarketView />}
        {activeTab === 'swaps' && <SwapsView />}
        {activeTab === 'redemption' && <RedemptionView />}
        {activeTab === 'digitaltwin' && <DigitalTwinView />}
        {activeTab === 'certificates' && <CertificatesView />}
        {activeTab === 'api' && <ApiExplorerView />}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 py-6 px-4 sm:px-6 text-xs text-slate-500 font-mono">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-400">DUKE SATOSHI OF CYBERSPACE PLC</span>
            <span>•</span>
            <span>Proof-of-Work Compute Exchange (DS-PoW)</span>
          </div>
          <div>
            <span>&ldquo;No work, no proof. No proof, no credit. No credit without provenance.&rdquo;</span>
          </div>
        </div>
      </footer>

      {/* Modals & Drawers */}
      <ProofModal proof={inspectedProof} onClose={() => setInspectedProof(null)} />
      <ProvenanceDrawer
        credit={inspectedCredit}
        onClose={() => setInspectedCredit(null)}
        onInspectProof={handleInspectProofById}
      />
      <CreateOrderModal
        isOpen={isNewOrderModalOpen}
        onClose={() => setIsNewOrderModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <ComputeExchangeProvider>
      <MainContent />
    </ComputeExchangeProvider>
  );
}
