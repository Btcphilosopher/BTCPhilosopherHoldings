/**
 * Anti-Fraud Tripwire Alert Banner
 * Duke Satoshi Proof-of-Work Compute Exchange
 */

import React from 'react';
import { AlertOctagon, X, ShieldAlert, FileText } from 'lucide-react';
import { useComputeExchange } from '../context/ComputeExchangeContext';

export const AntiFraudBanner: React.FC = () => {
  const { alerts, dismissAlert } = useComputeExchange();

  if (alerts.length === 0) return null;

  return (
    <div className="bg-red-950/90 border-b border-red-500/50 text-red-200 px-4 sm:px-6 py-3 relative z-30">
      <div className="max-w-7xl mx-auto flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-mono font-bold tracking-wider text-red-400 uppercase">
            <AlertOctagon className="h-4 w-4 text-red-400 animate-pulse" />
            <span>ANTI-FRAUD TRACE ENGINE: {alerts.length} ACTIVE ATTESTATION ALERT(S)</span>
          </div>
        </div>

        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {alerts.map(alert => (
            <div
              key={alert.alertId}
              className="bg-slate-900/90 border border-red-800/80 rounded-lg p-3 text-xs flex flex-col justify-between gap-2 shadow-lg"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-1">
                  <span className="font-mono font-bold text-red-300">{alert.type}</span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-red-900/60 text-red-200 border border-red-700/50">
                    {alert.severity}
                  </span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed mb-2">{alert.details}</p>
                {alert.evidence && (
                  <div className="bg-slate-950 p-2 rounded border border-slate-800 font-mono text-[10px] text-slate-400 overflow-x-auto">
                    <span className="text-slate-500 block mb-0.5 font-sans font-semibold">Evidence Metadata:</span>
                    <pre>{JSON.stringify(alert.evidence, null, 2)}</pre>
                  </div>
                )}
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-[10px] text-slate-400 font-mono">
                <span>{new Date(alert.timestamp).toLocaleTimeString()}</span>
                <button
                  onClick={() => dismissAlert(alert.alertId)}
                  className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center gap-1 transition-colors"
                >
                  <X className="h-3 w-3" />
                  <span>Dismiss</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
