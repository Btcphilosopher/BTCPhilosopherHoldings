/**
 * Header & System Status Command Bar
 * Duke Satoshi Proof-of-Work Compute Exchange (DS-PoW)
 * Organisation: Duke Satoshi of Cyberspace PLC
 */

import React, { useState } from 'react';
import {
  Cpu,
  ShieldCheck,
  Zap,
  Activity,
  AlertTriangle,
  Play,
  RotateCcw,
  CheckCircle2,
  Lock,
  ChevronDown,
  Layers,
  Database,
  Award,
  Terminal,
} from 'lucide-react';
import { useComputeExchange } from '../context/ComputeExchangeContext';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenNewOrder: () => void;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab, onOpenNewOrder }) => {
  const {
    proofChain,
    credits,
    dataCentres,
    isSimulating,
    executeVerticalSlice1,
    executeVerticalSlice2,
    executeVerticalSlice3,
    executeVerticalSlice4,
    verifyChainIntegrity,
    triggerFraudSimulation,
    alerts,
  } = useComputeExchange();

  const [slicesOpen, setSlicesOpen] = useState(false);
  const [fraudOpen, setFraudOpen] = useState(false);
  const [integrityStatus, setIntegrityStatus] = useState<string | null>(null);

  // Compute aggregate stats
  const totalVerifiedGpuHours = dataCentres.reduce((acc, d) => acc + d.verifiedGpuHours, 0);
  const circulatingCredits = credits
    .filter(c => c.status === 'CIRCULATING')
    .reduce((acc, c) => acc + c.quantityGpuHours, 0);
  const retiredCredits = credits
    .filter(c => c.status === 'RETIRED')
    .reduce((acc, c) => acc + c.quantityGpuHours, 0);

  const handleAuditChain = () => {
    const res = verifyChainIntegrity();
    if (res.isChainValid) {
      setIntegrityStatus(`Verified ${proofChain.length} Proofs: 100% Cryptographically Intact`);
    } else {
      setIntegrityStatus(`CRITICAL: Chain broken at Proof index ${res.brokenIndex}`);
    }
    setTimeout(() => setIntegrityStatus(null), 6000);
  };

  return (
    <header className="border-b border-slate-800 bg-slate-950/90 backdrop-blur-md sticky top-0 z-40">
      {/* Top corporate branding & live infrastructure telemetry bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 border-b border-slate-800/60 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="h-6 w-6 rounded bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-mono font-bold text-xs">
              DS
            </div>
            <div>
              <span className="font-semibold tracking-wider text-slate-100">DUKE SATOSHI OF CYBERSPACE PLC</span>
              <span className="text-slate-500 ml-2 hidden sm:inline font-mono">REG: #09284712 (UK LSE LISTED)</span>
            </div>
          </div>
          <span className="h-3 w-px bg-slate-800 hidden sm:inline" />
          <div className="hidden lg:flex items-center gap-1.5 text-emerald-400">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-mono">PROOF CHAIN #{proofChain[proofChain.length - 1]?.proofId || '000000'}</span>
          </div>
        </div>

        {/* Live headline ticker */}
        <div className="flex items-center gap-4 text-slate-300 font-mono">
          <div className="flex items-center gap-1.5">
            <Cpu className="h-3.5 w-3.5 text-cyan-400" />
            <span className="text-slate-400">VERIFIED WORK:</span>
            <span className="font-semibold text-slate-100">{totalVerifiedGpuHours.toLocaleString()} GPU-HRS</span>
          </div>
          <div className="hidden md:flex items-center gap-1.5">
            <Zap className="h-3.5 w-3.5 text-amber-400" />
            <span className="text-slate-400">CIRCULATING:</span>
            <span className="text-amber-300 font-semibold">{circulatingCredits.toLocaleString()} DS-PoW</span>
          </div>
          <div className="hidden md:flex items-center gap-1.5">
            <Lock className="h-3.5 w-3.5 text-purple-400" />
            <span className="text-slate-400">RETIRED:</span>
            <span className="text-slate-300 font-semibold">{retiredCredits.toLocaleString()}</span>
          </div>
          <button
            onClick={handleAuditChain}
            className="flex items-center gap-1 px-2 py-1 rounded bg-slate-900 border border-slate-700 hover:border-cyan-500/50 hover:bg-slate-800 text-slate-200 transition-colors"
            title="Perform full SHA-256 cryptographic audit from Genesis block to chain tip"
          >
            <ShieldCheck className="h-3.5 w-3.5 text-cyan-400" />
            <span>Audit Chain</span>
          </button>
        </div>
      </div>

      {/* Integrity banner if triggered */}
      {integrityStatus && (
        <div className="bg-cyan-950/80 border-b border-cyan-500/30 px-4 py-1.5 text-center text-xs font-mono text-cyan-300 flex items-center justify-center gap-2">
          <CheckCircle2 className="h-4 w-4 text-cyan-400" />
          <span>{integrityStatus}</span>
        </div>
      )}

      {/* Main Bar: Title, Navigation & Vertical Slice Executions */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="cursor-pointer" onClick={() => setActiveTab('overview')}>
            <h1 className="text-lg sm:text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <span className="text-amber-400 font-mono">DS-PoW</span>
              <span className="text-slate-400 font-light">|</span>
              <span className="font-semibold text-slate-100">Compute Exchange</span>
            </h1>
            <p className="text-[11px] text-slate-400 tracking-wide">
              Proof-of-Production Credit Infrastructure • No Work, No Credit
            </p>
          </div>
        </div>

        {/* Action buttons: Vertical Slices & Anti-Fraud Simulator */}
        <div className="flex items-center gap-2.5">
          {/* Vertical Slices Dropdown */}
          <div className="relative">
            <button
              onClick={() => setSlicesOpen(!slicesOpen)}
              disabled={isSimulating}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-950/80 border border-indigo-700/50 text-indigo-200 hover:bg-indigo-900 text-xs font-medium transition-colors shadow-sm disabled:opacity-50"
            >
              <Play className="h-3.5 w-3.5 text-indigo-400" />
              <span>{isSimulating ? 'Executing Pipeline...' : 'Run Vertical Slices'}</span>
              <ChevronDown className="h-3.5 w-3.5 opacity-70" />
            </button>

            {slicesOpen && (
              <div className="absolute right-0 mt-2 w-80 rounded-lg bg-slate-900 border border-slate-700 shadow-xl py-2 z-50 text-xs">
                <div className="px-3 py-1 text-[11px] font-mono text-slate-400 uppercase tracking-wider border-b border-slate-800">
                  Automated End-to-End Pipelines
                </div>
                <button
                  onClick={() => {
                    setSlicesOpen(false);
                    executeVerticalSlice1();
                  }}
                  className="w-full text-left px-3 py-2 hover:bg-slate-800 text-slate-200 flex flex-col gap-0.5 border-b border-slate-800/60"
                >
                  <span className="font-semibold text-cyan-300">Vertical Slice 1: End-to-End Pipeline</span>
                  <span className="text-[11px] text-slate-400">
                    Order → Dispatch → Telemetry → SHA-256 Proof → Multi-Sig Consensus → Credit Issuance → Ledger
                  </span>
                </button>
                <button
                  onClick={() => {
                    setSlicesOpen(false);
                    executeVerticalSlice2();
                  }}
                  className="w-full text-left px-3 py-2 hover:bg-slate-800 text-slate-200 flex flex-col gap-0.5 border-b border-slate-800/60"
                >
                  <span className="font-semibold text-emerald-300">Vertical Slice 2: Genuine AI Workload</span>
                  <span className="text-[11px] text-slate-400">
                    DeepSeek-v3 / Megatron-LM loss trajectory descent, checkpoint hashes, token throughput
                  </span>
                </button>
                <button
                  onClick={() => {
                    setSlicesOpen(false);
                    executeVerticalSlice3();
                  }}
                  className="w-full text-left px-3 py-2 hover:bg-slate-800 text-slate-200 flex flex-col gap-0.5 border-b border-slate-800/60"
                >
                  <span className="font-semibold text-amber-300">Vertical Slice 3: Dual Data Centre Swap</span>
                  <span className="text-[11px] text-slate-400">
                    London-01 (H200) ↔ Manchester-01 (H100) bilateral swap with published conversion ratio
                  </span>
                </button>
                <button
                  onClick={() => {
                    setSlicesOpen(false);
                    executeVerticalSlice4();
                  }}
                  className="w-full text-left px-3 py-2 hover:bg-slate-800 text-slate-200 flex flex-col gap-0.5"
                >
                  <span className="font-semibold text-purple-300">Vertical Slice 4: Full Market Settlement</span>
                  <span className="text-[11px] text-slate-400">
                    Produce → Order Book Trade Match → Bilateral Swap → Capacity Redemption &amp; Burn to RETIRED
                  </span>
                </button>
              </div>
            )}
          </div>

          {/* Anti-Fraud Tripwire Simulator Dropdown */}
          <div className="relative">
            <button
              onClick={() => setFraudOpen(!fraudOpen)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-950/50 border border-red-800/50 text-red-200 hover:bg-red-900/60 text-xs font-medium transition-colors"
            >
              <AlertTriangle className="h-3.5 w-3.5 text-red-400" />
              <span>Test Anti-Fraud</span>
              <ChevronDown className="h-3.5 w-3.5 opacity-70" />
            </button>

            {fraudOpen && (
              <div className="absolute right-0 mt-2 w-72 rounded-lg bg-slate-900 border border-slate-700 shadow-xl py-2 z-50 text-xs">
                <div className="px-3 py-1 text-[11px] font-mono text-red-400 uppercase tracking-wider border-b border-slate-800">
                  Simulate Fraud Tripwires
                </div>
                <button
                  onClick={() => {
                    setFraudOpen(false);
                    triggerFraudSimulation('IMPOSSIBLE_POWER');
                  }}
                  className="w-full text-left px-3 py-2 hover:bg-slate-800 text-slate-200 flex flex-col gap-0.5 border-b border-slate-800/60"
                >
                  <span className="font-medium text-amber-300">1. Impossible Power Physics</span>
                  <span className="text-[11px] text-slate-400">Attempt 100% load at 38W (below idle threshold)</span>
                </button>
                <button
                  onClick={() => {
                    setFraudOpen(false);
                    triggerFraudSimulation('REPLAY_OUTPUT');
                  }}
                  className="w-full text-left px-3 py-2 hover:bg-slate-800 text-slate-200 flex flex-col gap-0.5 border-b border-slate-800/60"
                >
                  <span className="font-medium text-red-300">2. Replay Historic Output</span>
                  <span className="text-[11px] text-slate-400">Attempt to re-register output commitment</span>
                </button>
                <button
                  onClick={() => {
                    setFraudOpen(false);
                    triggerFraudSimulation('NO_WORK_CREDIT');
                  }}
                  className="w-full text-left px-3 py-2 hover:bg-slate-800 text-slate-200 flex flex-col gap-0.5"
                >
                  <span className="font-medium text-purple-300">3. No-Work Fractional Issuance</span>
                  <span className="text-[11px] text-slate-400">Attempt to mint credit without verified proof</span>
                </button>
              </div>
            )}
          </div>

          <button
            onClick={onOpenNewOrder}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold text-xs transition-colors shadow-sm"
          >
            <span>+ Create Work Order</span>
          </button>
        </div>
      </div>

      {/* Primary Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex overflow-x-auto no-scrollbar gap-1 border-t border-slate-800/80 text-xs">
        {[
          { id: 'overview', label: 'OVERVIEW', icon: Activity },
          { id: 'datacentres', label: 'DATA CENTRES & MINTS', icon: Database },
          { id: 'proofchain', label: 'PROOF ENGINE & CHAIN', icon: ShieldCheck },
          { id: 'verification', label: 'VERIFIER CONSENSUS', icon: Award },
          { id: 'credits', label: 'CREDITS & LEDGER', icon: Layers },
          { id: 'market', label: 'EXCHANGE & ORDER BOOK', icon: Zap },
          { id: 'swaps', label: 'COMPUTE SWAPS', icon: RotateCcw },
          { id: 'redemption', label: 'REDEMPTION & SINK', icon: Lock },
          { id: 'digitaltwin', label: 'DIGITAL TWIN', icon: Cpu },
          { id: 'certificates', label: 'AUDIT & CERTIFICATES', icon: CheckCircle2 },
          { id: 'api', label: 'ENTERPRISE API', icon: Terminal },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 py-2.5 px-3 whitespace-nowrap font-medium border-b-2 transition-colors ${
                isActive
                  ? 'border-amber-400 text-amber-300 bg-amber-500/5'
                  : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
              }`}
            >
              <Icon className={`h-3.5 w-3.5 ${isActive ? 'text-amber-400' : 'text-slate-500'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
