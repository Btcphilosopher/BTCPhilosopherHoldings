/**
 * Create Work Order Modal
 * Duke Satoshi Proof-of-Work Compute Exchange
 */

import React, { useState } from 'react';
import { X, FileText, Cpu, CheckCircle2, Shield } from 'lucide-react';
import { useComputeExchange } from '../context/ComputeExchangeContext';
import { WorkType, VerificationAssuranceLevel } from '../types';
import { WORK_REGISTRY } from '../data/initialData';

interface CreateOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CreateOrderModal: React.FC<CreateOrderModalProps> = ({ isOpen, onClose }) => {
  const { dataCentres, createWorkOrder, dispatchJob } = useComputeExchange();

  const [providerId, setProviderId] = useState(dataCentres[0]?.id || 'DSCX-London-01');
  const [customerName, setCustomerName] = useState('DeepMind Compute Partners');
  const [workType, setWorkType] = useState<WorkType>('AI_TRAINING');
  const [title, setTitle] = useState('Frontier Multimodal Latent Space Pre-training');
  const [gpuHours, setGpuHours] = useState(25000);
  const [accelerator, setAccelerator] = useState('H200');
  const [assuranceLevel, setAssuranceLevel] = useState<VerificationAssuranceLevel>('INSTITUTIONAL');
  const [expectedOutput, setExpectedOutput] = useState('Full Model Weights Checkpoint + Bitwise Deterministic Validation');
  const [autoDispatch, setAutoDispatch] = useState(true);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const order = createWorkOrder({
      providerId,
      customerName,
      workType,
      title,
      requiredComputeGpuHours: gpuHours,
      accelerator,
      assuranceLevel,
      expectedOutput,
    });

    if (autoDispatch) {
      dispatchJob(order.orderId, providerId);
    }

    onClose();
  };

  const currentSpec = WORK_REGISTRY[workType];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl max-w-2xl w-full overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <FileText className="h-4 w-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Create Enterprise Work Order</h2>
              <p className="text-xs text-slate-400">Root provenance contract for verifiable computational production</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="h-8 w-8 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-400 font-mono mb-1 text-[11px] uppercase">
                Authorized Mint / Data Centre
              </label>
              <select
                value={providerId}
                onChange={e => setProviderId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-amber-500"
              >
                {dataCentres.map(dc => (
                  <option key={dc.id} value={dc.id}>
                    {dc.name} ({dc.location})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 font-mono mb-1 text-[11px] uppercase">Customer / Organization</label>
              <input
                type="text"
                value={customerName}
                onChange={e => setCustomerName(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-400 font-mono mb-1 text-[11px] uppercase">Workload Title</label>
            <input
              type="text"
              value={title}
              onChange={e => setTitle(e.target.value)}
              required
              className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-slate-400 font-mono mb-1 text-[11px] uppercase">Formal Work Class</label>
              <select
                value={workType}
                onChange={e => setWorkType(e.target.value as WorkType)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-amber-500 font-mono"
              >
                {Object.keys(WORK_REGISTRY).map(type => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 font-mono mb-1 text-[11px] uppercase">Required Compute</label>
              <div className="relative">
                <input
                  type="number"
                  min="10"
                  step="100"
                  value={gpuHours}
                  onChange={e => setGpuHours(parseInt(e.target.value) || 100)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-amber-500 font-mono"
                />
                <span className="absolute right-3 top-2.5 text-slate-500 font-mono text-[10px]">GPU-HRS</span>
              </div>
            </div>

            <div>
              <label className="block text-slate-400 font-mono mb-1 text-[11px] uppercase">Assurance Tier</label>
              <select
                value={assuranceLevel}
                onChange={e => setAssuranceLevel(e.target.value as VerificationAssuranceLevel)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-amber-500 font-mono"
              >
                <option value="STANDARD">STANDARD</option>
                <option value="ENHANCED">ENHANCED</option>
                <option value="INSTITUTIONAL">INSTITUTIONAL</option>
                <option value="CRITICAL">CRITICAL</option>
              </select>
            </div>
          </div>

          {/* Machine-readable spec preview */}
          {currentSpec && (
            <div className="bg-slate-950 rounded-lg p-3 border border-slate-800 text-[11px] space-y-1 font-mono">
              <span className="text-amber-400 font-semibold block">DSCX Specification Standard:</span>
              <div className="text-slate-400">
                • Target Accelerator: <span className="text-slate-200">{currentSpec.accelerator}</span> | Precision:{' '}
                <span className="text-slate-200">{currentSpec.precision || 'BF16'}</span>
              </div>
              <div className="text-slate-400">
                • Verification Protocol: <span className="text-cyan-300">{currentSpec.verificationMethod}</span>
              </div>
            </div>
          )}

          <div>
            <label className="block text-slate-400 font-mono mb-1 text-[11px] uppercase">Expected Output Commitment</label>
            <input
              type="text"
              value={expectedOutput}
              onChange={e => setExpectedOutput(e.target.value)}
              required
              className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="flex items-center gap-2 pt-2">
            <input
              type="checkbox"
              id="autoDispatch"
              checked={autoDispatch}
              onChange={e => setAutoDispatch(e.target.checked)}
              className="rounded bg-slate-950 border-slate-700 text-amber-500 focus:ring-0"
            />
            <label htmlFor="autoDispatch" className="text-slate-300 cursor-pointer">
              Immediately schedule &amp; dispatch to GPU cluster upon creation
            </label>
          </div>

          {/* Actions */}
          <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold transition-colors"
            >
              Sign &amp; Submit Order
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
