/**
 * Proof Record Cryptographic Inspector Modal
 * Duke Satoshi Proof-of-Work Compute Exchange
 */

import React, { useState } from 'react';
import {
  X,
  ShieldCheck,
  Cpu,
  Zap,
  CheckCircle2,
  AlertCircle,
  Copy,
  Terminal,
  Clock,
  Layers,
  Award,
} from 'lucide-react';
import { ProofRecord } from '../types';
import { computeProofHash } from '../lib/crypto';

interface ProofModalProps {
  proof: ProofRecord | null;
  onClose: () => void;
}

export const ProofModal: React.FC<ProofModalProps> = ({ proof, onClose }) => {
  const [verificationOutput, setVerificationOutput] = useState<{
    computed: string;
    matches: boolean;
  } | null>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [viewRawJson, setViewRawJson] = useState(false);

  if (!proof) return null;

  const handleRecalculateHash = () => {
    const computed = computeProofHash({
      providerId: proof.providerId,
      hardwareSummary: proof.hardwareSummary,
      jobId: proof.jobId,
      workType: proof.workType,
      inputCommitment: proof.inputCommitment,
      outputCommitment: proof.outputCommitment,
      measurementRootHash: proof.measurementRootHash,
      executionStart: proof.executionStart,
      executionEnd: proof.executionEnd,
      computeConsumedGpuHours: proof.computeConsumedGpuHours,
      energyConsumedMwh: proof.energyConsumedMwh,
      previousProofHash: proof.previousProofHash,
    });

    const matches = computed.toLowerCase() === proof.proofHash.toLowerCase();
    setVerificationOutput({ computed, matches });
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(label);
    setTimeout(() => setCopiedField(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/50">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white font-mono">PROOF #{proof.proofId}</h2>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-mono font-semibold border ${
                    proof.status === 'VERIFIED'
                      ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                      : 'bg-amber-950/60 text-amber-300 border-amber-500/40'
                  }`}
                >
                  {proof.status}
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-purple-950/60 text-purple-300 border border-purple-500/40">
                  {proof.assuranceLevel}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Sequence #{proof.sequenceNumber} • Issued by {proof.providerId}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setViewRawJson(!viewRawJson)}
              className="px-2.5 py-1 text-xs rounded border border-slate-700 bg-slate-800 text-slate-300 hover:bg-slate-700 flex items-center gap-1 font-mono transition-colors"
            >
              <Terminal className="h-3.5 w-3.5" />
              <span>{viewRawJson ? 'Standard View' : 'Raw JSON'}</span>
            </button>
            <button
              onClick={onClose}
              className="h-8 w-8 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs text-slate-300">
          {viewRawJson ? (
            <div className="bg-slate-950 rounded-lg p-4 font-mono text-[11px] overflow-x-auto border border-slate-800 text-slate-300">
              <pre>{JSON.stringify(proof, null, 2)}</pre>
            </div>
          ) : (
            <>
              {/* Cryptographic Linkage Block */}
              <div className="bg-slate-950 rounded-xl p-4 border border-slate-800 space-y-3 font-mono">
                <div className="flex items-center justify-between text-[11px] text-slate-400 border-b border-slate-800/80 pb-2">
                  <span className="font-sans font-semibold text-slate-200 flex items-center gap-1.5">
                    <Layers className="h-3.5 w-3.5 text-cyan-400" />
                    Cryptographic Proof-Chain Linkage
                  </span>
                  <button
                    onClick={handleRecalculateHash}
                    className="px-2.5 py-1 rounded bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-500/40 text-cyan-300 transition-colors flex items-center gap-1"
                  >
                    <ShieldCheck className="h-3.5 w-3.5" />
                    <span>Recalculate &amp; Verify SHA-256</span>
                  </button>
                </div>

                <div className="space-y-2 text-[11px]">
                  <div>
                    <span className="text-slate-500 block text-[10px] uppercase">Proof Hash (Canonical):</span>
                    <div className="flex items-center justify-between bg-slate-900 p-2 rounded border border-slate-800 text-cyan-300 break-all">
                      <span>{proof.proofHash}</span>
                      <button
                        onClick={() => copyToClipboard(proof.proofHash, 'hash')}
                        className="ml-2 text-slate-400 hover:text-white"
                        title="Copy Hash"
                      >
                        <Copy className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>

                  <div>
                    <span className="text-slate-500 block text-[10px] uppercase">Previous Proof Hash (Predecessor):</span>
                    <div className="flex items-center justify-between bg-slate-900 p-2 rounded border border-slate-800 text-slate-400 break-all">
                      <span>{proof.previousProofHash}</span>
                      <button
                        onClick={() => copyToClipboard(proof.previousProofHash, 'prevHash')}
                        className="ml-2 text-slate-500 hover:text-white"
                        title="Copy Previous Hash"
                      >
                        <Copy className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>

                  {verificationOutput && (
                    <div
                      className={`p-3 rounded-lg border text-xs flex items-center justify-between ${
                        verificationOutput.matches
                          ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                          : 'bg-red-950/40 border-red-500/40 text-red-300'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        {verificationOutput.matches ? (
                          <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                        ) : (
                          <AlertCircle className="h-4 w-4 text-red-400" />
                        )}
                        <span>
                          {verificationOutput.matches
                            ? 'SHA-256 Match Verified: Exact cryptographic equality over canonical execution parameters.'
                            : 'Tamper Detected! Recomputed hash does not match proof signature.'}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400">{verificationOutput.computed.slice(0, 16)}...</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Workload & Computational Metrics */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <span className="text-slate-500 text-[10px] uppercase font-mono block mb-1">Productive Work</span>
                  <div className="text-base font-bold text-white font-mono">
                    {proof.computeConsumedGpuHours.toLocaleString()} GPU-Hours
                  </div>
                  <span className="text-[11px] text-cyan-400 font-mono">{proof.workType}</span>
                </div>

                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <span className="text-slate-500 text-[10px] uppercase font-mono block mb-1">Energy Consumed</span>
                  <div className="text-base font-bold text-amber-300 font-mono">
                    {proof.energyConsumedMwh.toFixed(2)} MWh
                  </div>
                  <span className="text-[11px] text-slate-400 font-mono">PUE: {proof.pue.toFixed(2)}</span>
                </div>

                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <span className="text-slate-500 text-[10px] uppercase font-mono block mb-1">Quality &amp; Efficiency</span>
                  <div className="text-base font-bold text-emerald-400 font-mono">
                    {proof.qualityScore.toFixed(1)} / 100
                  </div>
                  <span className="text-[11px] text-slate-400 font-mono">
                    {proof.efficiencyScore.toFixed(1)} Work / kWh
                  </span>
                </div>
              </div>

              {/* Commitments & Attestation Roots */}
              <div className="space-y-2">
                <h3 className="font-semibold text-slate-200 text-xs tracking-wider uppercase font-mono">
                  Cryptographic Commitments
                </h3>
                <div className="bg-slate-950 rounded-lg p-3 border border-slate-800 space-y-2 text-[11px] font-mono">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 border-b border-slate-800/60 pb-1.5">
                    <span className="text-slate-500">Input/Dataset Commitment:</span>
                    <span className="text-slate-300 break-all">{proof.inputCommitment}</span>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 border-b border-slate-800/60 pb-1.5">
                    <span className="text-slate-500">Output Checkpoint Commitment:</span>
                    <span className="text-emerald-400 break-all">{proof.outputCommitment}</span>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 border-b border-slate-800/60 pb-1.5">
                    <span className="text-slate-500">Telemetry Merkle Root:</span>
                    <span className="text-purple-400 break-all">{proof.measurementRootHash}</span>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                    <span className="text-slate-500">Software Container Digest:</span>
                    <span className="text-slate-400 break-all">{proof.containerHash}</span>
                  </div>
                </div>
              </div>

              {/* Independent Verifiers Consensus */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-slate-200 text-xs tracking-wider uppercase font-mono flex items-center gap-1.5">
                    <Award className="h-3.5 w-3.5 text-amber-400" />
                    Independent Verifier Multi-Sig Consensus ({proof.verifiers.length} Signers)
                  </h3>
                  <span className="text-[10px] text-emerald-400 font-mono">Consensus Threshold: 100% Met</span>
                </div>

                <div className="grid gap-2">
                  {proof.verifiers.map((v, idx) => (
                    <div
                      key={idx}
                      className="bg-slate-950 rounded-lg p-3 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-slate-200 text-xs">{v.verifierName}</span>
                          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-1.5 py-0.2 rounded border border-emerald-800/60">
                            CONFIDENCE: {(v.confidenceScore * 100).toFixed(1)}%
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400">{v.auditNotes}</p>
                      </div>
                      <div className="text-[10px] font-mono text-slate-500 text-right">
                        <span>{new Date(v.timestamp).toLocaleTimeString()}</span>
                        <div className="text-slate-400 truncate max-w-[140px]">{v.signature}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950 flex items-center justify-between text-xs text-slate-400 font-mono">
          <span>Root Work Order: {proof.workOrderId}</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-medium font-sans transition-colors"
          >
            Close Inspector
          </button>
        </div>
      </div>
    </div>
  );
};
