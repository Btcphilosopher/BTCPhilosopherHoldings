/**
 * Credit Deep Provenance Tree Drawer
 * Duke Satoshi Proof-of-Work Compute Exchange
 */

import React from 'react';
import { X, ArrowDown, Database, Cpu, ShieldCheck, FileText, Zap, Award } from 'lucide-react';
import { Credit } from '../types';

interface ProvenanceDrawerProps {
  credit: Credit | null;
  onClose: () => void;
  onInspectProof: (proofId: string) => void;
}

export const ProvenanceDrawer: React.FC<ProvenanceDrawerProps> = ({
  credit,
  onClose,
  onInspectProof,
}) => {
  if (!credit) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-slate-900 border-l border-slate-700 w-full max-w-xl h-full flex flex-col shadow-2xl overflow-hidden">
        {/* Drawer Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-sm font-bold text-amber-400">{credit.creditId}</span>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-mono font-semibold ${
                  credit.status === 'CIRCULATING'
                    ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-500/40'
                    : 'bg-purple-950/60 text-purple-300 border border-purple-500/40'
                }`}
              >
                {credit.status}
              </span>
            </div>
            <h3 className="text-base font-bold text-white mt-0.5">Proof-of-Production Provenance Chain</h3>
          </div>
          <button
            onClick={onClose}
            className="h-8 w-8 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Provenance Tree Body */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs">
          <p className="text-slate-400 text-xs leading-relaxed">
            In accordance with the Duke Satoshi doctrine, every credit is an auditable accounting representation of
            proven computational work. The complete execution hierarchy is cryptographically sealed below:
          </p>

          {/* Level 1: The Credit */}
          <div className="bg-slate-950 border border-amber-500/30 rounded-xl p-4 space-y-2 relative">
            <div className="flex items-center justify-between text-amber-300 font-mono font-semibold">
              <span className="flex items-center gap-2">
                <Zap className="h-4 w-4 text-amber-400" />
                1. COMPUTE CREDIT ({credit.classId})
              </span>
              <span>{credit.quantityGpuHours.toLocaleString()} GPU-Hours</span>
            </div>
            <div className="text-slate-400 text-[11px] font-mono space-y-1">
              <div>Owner: <span className="text-slate-200">{credit.ownerName}</span></div>
              <div>Issue Date: <span className="text-slate-200">{new Date(credit.issueDate).toLocaleString()}</span></div>
              <div>Proof Range: <span className="text-cyan-300">{credit.proofRange}</span></div>
            </div>
          </div>

          <div className="flex justify-center text-slate-600">
            <ArrowDown className="h-5 w-5" />
          </div>

          {/* Level 2: Issuance Event & Double-Entry Reference */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between text-slate-200 font-mono font-semibold">
              <span className="flex items-center gap-2">
                <FileText className="h-4 w-4 text-indigo-400" />
                2. ISSUANCE EVENT &amp; LEDGER ENTRY
              </span>
              <span className="text-emerald-400 text-[11px]">100% Mint Reserve Backed</span>
            </div>
            <div className="text-slate-400 text-[11px] font-mono space-y-1">
              <div>Mint Facility: <span className="text-slate-200">{credit.provenance.dataCentre}</span></div>
              <div>Conversion Formula: <span className="text-slate-200">1.00 Verified GPU-Hr = 1.00 DS-PoW Credit</span></div>
              <div>Zero Fractional Creation: <span className="text-emerald-300">Audited (Issued &lt;= Verified Work)</span></div>
            </div>
          </div>

          <div className="flex justify-center text-slate-600">
            <ArrowDown className="h-5 w-5" />
          </div>

          {/* Level 3: Cryptographic Proof */}
          <div className="bg-slate-950 border border-cyan-500/30 rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between text-cyan-300 font-mono font-semibold">
              <span className="flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-cyan-400" />
                3. CRYPTOGRAPHIC PROOF RECORD
              </span>
              <button
                onClick={() => onInspectProof(credit.provenance.proofId)}
                className="px-2 py-0.5 rounded bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-500/40 text-[10px] transition-colors"
              >
                Inspect Proof #{credit.provenance.proofId}
              </button>
            </div>
            <div className="text-slate-400 text-[11px] font-mono space-y-1">
              <div>Assurance Grade: <span className="text-purple-300">{credit.provenance.assuranceLevel}</span></div>
              <div>Energy Consumed: <span className="text-amber-300">{credit.provenance.energyMwh} MWh</span></div>
              <div>Renewable Offset: <span className="text-emerald-400">{credit.provenance.carbonOffsetKg} kg CO2e</span></div>
            </div>
          </div>

          <div className="flex justify-center text-slate-600">
            <ArrowDown className="h-5 w-5" />
          </div>

          {/* Level 4: Computational Job */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between text-slate-200 font-mono font-semibold">
              <span className="flex items-center gap-2">
                <Cpu className="h-4 w-4 text-emerald-400" />
                4. COMPUTATIONAL JOB EXECUTION
              </span>
              <span className="text-cyan-400 text-[11px]">{credit.provenance.workType}</span>
            </div>
            <div className="text-slate-400 text-[11px] font-mono space-y-1">
              <div>Job ID: <span className="text-slate-200">{credit.provenance.jobId}</span></div>
              <div>Hardware Array: <span className="text-slate-200">{credit.provenance.hardware}</span></div>
              <div>Attestation: <span className="text-emerald-300">Continuous Sub-Second Telemetry Verified</span></div>
            </div>
          </div>

          <div className="flex justify-center text-slate-600">
            <ArrowDown className="h-5 w-5" />
          </div>

          {/* Level 5: Physical Data Centre & Hardware Cluster */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between text-slate-200 font-mono font-semibold">
              <span className="flex items-center gap-2">
                <Database className="h-4 w-4 text-amber-400" />
                5. PHYSICAL DATA CENTRE ROOT
              </span>
              <span className="text-slate-400 text-[10px]">Tier IV Hyperscale</span>
            </div>
            <div className="text-slate-400 text-[11px] font-mono space-y-1">
              <div>Facility: <span className="text-slate-200">{credit.provenance.dataCentre}</span></div>
              <div>Cluster Node: <span className="text-slate-200">{credit.provenance.cluster}</span></div>
              <div>Work Order Root: <span className="text-indigo-300">{credit.provenance.workOrderId}</span></div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-medium transition-colors"
          >
            Close Provenance
          </button>
        </div>
      </div>
    </div>
  );
};
