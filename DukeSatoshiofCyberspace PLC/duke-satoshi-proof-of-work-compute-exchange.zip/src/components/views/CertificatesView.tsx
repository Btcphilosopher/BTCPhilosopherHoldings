/**
 * Production Certificates & Anti-Fraud Audit Testbench View
 * Duke Satoshi Proof-of-Work Compute Exchange
 */

import React, { useState } from 'react';
import {
  Award,
  ShieldCheck,
  Printer,
  CheckCircle2,
  AlertTriangle,
  Building,
  Sparkles,
} from 'lucide-react';
import { useComputeExchange } from '../../context/ComputeExchangeContext';
import { ProductionCertificate } from '../../types';

export const CertificatesView: React.FC = () => {
  const { certificates, triggerFraudSimulation } = useComputeExchange();

  const [selectedCert, setSelectedCert] = useState<ProductionCertificate | null>(certificates[0] || null);

  return (
    <div className="space-y-6">
      {/* Doctrine Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-amber-400 uppercase tracking-wider">
            <Award className="h-4 w-4" />
            <span>Section 37: Cryptographic Production Certificates &amp; Enterprise Audit</span>
          </div>
          <h2 className="text-lg font-bold text-white mt-1">Proof-of-Work Compute Certificates</h2>
          <p className="text-xs text-slate-400">
            Formal legal and technical certificates issued to enterprise, scientific, and sovereign clients verifying
            proven execution, energy provenance, and independent consensus.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => window.print()}
            className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono flex items-center gap-1.5 transition-colors border border-slate-700"
          >
            <Printer className="h-4 w-4 text-cyan-400" />
            <span>Print Official Certificate</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Certificate List Selector */}
        <div className="space-y-3">
          <h3 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">
            Issued Production Certificates
          </h3>
          <div className="space-y-2">
            {certificates.map(cert => (
              <div
                key={cert.certificateId}
                onClick={() => setSelectedCert(cert)}
                className={`p-3.5 rounded-xl border cursor-pointer transition-all text-xs font-mono ${
                  selectedCert?.certificateId === cert.certificateId
                    ? 'bg-slate-900 border-amber-500/60 ring-1 ring-amber-500/40'
                    : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-amber-300">{cert.certificateId}</span>
                  <span className="text-[10px] text-emerald-400 font-semibold">VALIDATED</span>
                </div>
                <div className="text-white font-bold mt-1">{cert.centreName}</div>
                <div className="text-[11px] text-slate-400 mt-1">
                  {(cert.verifiedGpuHours || 0).toLocaleString()} GPU-Hrs • {cert.hardwareClass}
                </div>
              </div>
            ))}
          </div>

          {/* Anti-Fraud Sandbox Trigger Panel */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-3 font-mono text-xs mt-6">
            <h4 className="text-xs font-bold text-red-400 uppercase flex items-center gap-1.5">
              <AlertTriangle className="h-4 w-4" />
              Anti-Fraud Invariant Audit Testbench
            </h4>
            <p className="text-slate-400 text-[11px]">
              Execute deliberate malicious invalid state transitions to observe real-time tripwires:
            </p>
            <div className="space-y-1.5 pt-1">
              <button
                onClick={() => triggerFraudSimulation('IMPOSSIBLE_POWER')}
                className="w-full text-left p-2 rounded bg-slate-950 hover:bg-slate-850 border border-slate-800 text-slate-300 hover:text-amber-300 transition-colors"
              >
                1. Impossible Power Physics Invariant
              </button>
              <button
                onClick={() => triggerFraudSimulation('REPLAY_OUTPUT')}
                className="w-full text-left p-2 rounded bg-slate-950 hover:bg-slate-850 border border-slate-800 text-slate-300 hover:text-red-300 transition-colors"
              >
                2. Duplicate Output Commitment Replay
              </button>
              <button
                onClick={() => triggerFraudSimulation('NO_WORK_CREDIT')}
                className="w-full text-left p-2 rounded bg-slate-950 hover:bg-slate-850 border border-slate-800 text-slate-300 hover:text-purple-300 transition-colors"
              >
                3. No-Work Fractional Issuance Attempt
              </button>
            </div>
          </div>
        </div>

        {/* Official Certificate Visual Presentation */}
        {selectedCert && (
          <div className="lg:col-span-2 bg-slate-950 border-2 border-amber-500/40 rounded-2xl p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden">
            {/* Ambient Watermark Background */}
            <div className="absolute right-4 top-4 text-slate-850 opacity-20 pointer-events-none select-none font-serif text-8xl font-black">
              DS
            </div>

            {/* Certificate Header */}
            <div className="text-center space-y-2 border-b border-amber-500/30 pb-6">
              <div className="flex justify-center mb-1">
                <div className="h-12 w-12 rounded-full bg-amber-500/10 border border-amber-500/50 flex items-center justify-center text-amber-400 font-mono font-bold text-lg">
                  DS
                </div>
              </div>
              <span className="text-[11px] font-mono tracking-widest text-amber-400 uppercase block font-bold">
                DUKE SATOSHI OF CYBERSPACE PLC
              </span>
              <h1 className="text-xl sm:text-2xl font-serif font-bold text-white tracking-wide">
                CERTIFICATE OF VERIFIED COMPUTATIONAL WORK
              </h1>
              <p className="text-xs text-slate-400 font-mono">
                Certificate ID: <span className="text-slate-200 font-bold">{selectedCert.certificateId}</span> • Registered
                under DS-PoW Provenance Protocol
              </p>
            </div>

            {/* Certificate Core Statement */}
            <div className="space-y-4 text-xs font-mono text-slate-300">
              <p className="text-slate-300 text-center italic text-sm font-serif">
                This is to certify that computational work has been physically performed by authorized data centre
                hardware, cryptographically verified by independent consensus nodes, and sealed into the immutable
                Duke Satoshi Proof Chain.
              </p>

              <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 space-y-2 text-xs">
                <div className="grid grid-cols-2 gap-2 border-b border-slate-800/80 pb-2">
                  <span className="text-slate-400">Issuing Facility / Mint:</span>
                  <span className="text-amber-400 font-semibold text-right">{selectedCert.centreName}</span>
                </div>
                <div className="grid grid-cols-2 gap-2 border-b border-slate-800/80 pb-2">
                  <span className="text-slate-400">Hardware Class:</span>
                  <span className="text-slate-200 text-right">{selectedCert.hardwareClass}</span>
                </div>
                <div className="grid grid-cols-2 gap-2 border-b border-slate-800/80 pb-2">
                  <span className="text-slate-400">Verification Grade:</span>
                  <span className="text-cyan-300 font-semibold text-right">{selectedCert.verificationGrade}</span>
                </div>
                <div className="grid grid-cols-2 gap-2 border-b border-slate-800/80 pb-2">
                  <span className="text-slate-400">Total Verified Output:</span>
                  <span className="text-emerald-400 font-bold text-right">
                    {(selectedCert.verifiedGpuHours || 0).toLocaleString()} GPU-Hours
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 border-b border-slate-800/80 pb-2">
                  <span className="text-slate-400">Energy Consumed &amp; PUE:</span>
                  <span className="text-amber-300 text-right">
                    {selectedCert.energyMwh} MWh (PUE: {selectedCert.pue?.toFixed(2) || '1.12'})
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 border-b border-slate-800/80 pb-2">
                  <span className="text-slate-400">Issued Credits:</span>
                  <span className="text-purple-300 font-bold text-right">
                    {(selectedCert.creditsIssued || 0).toLocaleString()} DS-PoW
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="text-slate-400">Proof Block Range:</span>
                  <span className="text-emerald-400 text-right">{selectedCert.proofRange}</span>
                </div>
              </div>

              {/* Workload Distribution */}
              {selectedCert.workloadDistribution && selectedCert.workloadDistribution.length > 0 && (
                <div className="space-y-2">
                  <span className="text-slate-400 text-[10px] uppercase font-bold">Verified Workload Breakdown</span>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    {selectedCert.workloadDistribution.map((item, idx) => (
                      <div key={idx} className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                        <div className="text-slate-400 text-[10px] truncate">{item.workType}</div>
                        <div className="text-cyan-300 font-bold">{item.percentage}%</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Certificate Hash */}
              <div className="space-y-1">
                <span className="text-slate-500 text-[10px] uppercase block">Cryptographic Certificate Hash</span>
                <div className="p-2 rounded bg-slate-900 border border-slate-800 text-[11px] text-cyan-300 break-all font-mono">
                  {selectedCert.certificateHash}
                </div>
              </div>

              {/* Multi-Sig Signatures Block */}
              <div className="pt-4 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-2 gap-4 text-[10px]">
                <div className="space-y-1">
                  <span className="text-slate-500 uppercase block">Independent Verifier Multi-Sig</span>
                  <div className="text-slate-300 font-bold">
                    {selectedCert.independentVerifiers?.join(' • ') || 'Audited by Turing Lab & CERN'}
                  </div>
                  <div className="text-slate-500 truncate">{selectedCert.cryptographicSignature}</div>
                </div>

                <div className="space-y-1 text-right">
                  <span className="text-slate-500 uppercase block">Issuing Authority</span>
                  <div className="text-amber-400 font-bold">Duke Satoshi of Cyberspace PLC</div>
                  <div className="text-slate-500">{new Date(selectedCert.issueDate).toLocaleDateString()}</div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
