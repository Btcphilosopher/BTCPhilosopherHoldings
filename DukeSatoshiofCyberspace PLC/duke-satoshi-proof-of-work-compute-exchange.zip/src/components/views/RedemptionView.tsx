/**
 * Redemption, Physical Delivery & Permanent Retirement Sink
 * Duke Satoshi Proof-of-Work Compute Exchange
 */

import React, { useState } from 'react';
import { Lock, Flame, CheckCircle2, AlertOctagon, Cpu, Database, ArrowDown, Zap } from 'lucide-react';
import { useComputeExchange } from '../../context/ComputeExchangeContext';

export const RedemptionView: React.FC = () => {
  const { credits, dataCentres, redeemCreditCapacity } = useComputeExchange();

  const circulatingCredits = credits.filter(c => c.status === 'CIRCULATING');
  const retiredCredits = credits.filter(c => c.status === 'RETIRED');

  const [selectedCreditId, setSelectedCreditId] = useState(circulatingCredits[0]?.creditId || '');
  const [targetCentreId, setTargetCentreId] = useState(dataCentres[0]?.id || 'DSCX-London-01');
  const [redeemQuantity, setRedeemQuantity] = useState(1000);
  const [recentRetirementTx, setRecentRetirementTx] = useState<string | null>(null);

  const selectedCredit = credits.find(c => c.creditId === selectedCreditId);

  const handleExecuteRedemption = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCredit) return;

    const success = redeemCreditCapacity(selectedCredit.creditId, targetCentreId, redeemQuantity);
    if (success) {
      setRecentRetirementTx(`RETIRE-DSCX-${Date.now().toString(16).toUpperCase()}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Doctrine Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-purple-400 uppercase tracking-wider">
            <Lock className="h-4 w-4" />
            <span>Section 22 &amp; 23: Redemption Pipeline &amp; Capacity Settlement Sink</span>
          </div>
          <h2 className="text-lg font-bold text-white mt-1">Physical Compute Redemption &amp; Retirement</h2>
          <p className="text-xs text-slate-400">
            A credit represents a call option on real computational capacity. When redeemed, hardware is provisioned,
            work is executed, and the credit is permanently transferred to the non-circulating retirement sink.
          </p>
        </div>
        <div className="bg-slate-950 px-3 py-2 rounded-lg border border-slate-800 font-mono text-xs text-purple-300">
          Permanent Sink: ACT-RETIRED-SINK-PERMANENT
        </div>
      </div>

      {/* Main Form & Sink Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Col 1 & 2: Interactive Redemption Terminal */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-5">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              Execute Capacity Delivery &amp; Burn Credit
            </h3>
            <p className="text-xs text-slate-400">
              Allocates physical GPU slots at the target facility and burns the token to prevent double-spending
            </p>
          </div>

          {recentRetirementTx && (
            <div className="bg-emerald-950/60 border border-emerald-500/50 rounded-lg p-3 text-xs font-mono text-emerald-300 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                <span>
                  Redemption confirmed! Capacity locked at {targetCentreId}. Credit permanently retired via TX{' '}
                  <strong>{recentRetirementTx}</strong>.
                </span>
              </div>
            </div>
          )}

          <form onSubmit={handleExecuteRedemption} className="space-y-4 text-xs font-mono">
            <div>
              <label className="block text-slate-400 text-[10px] uppercase mb-1">
                Select Owned Circulating Credit
              </label>
              <select
                value={selectedCreditId}
                onChange={e => setSelectedCreditId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-slate-200"
              >
                {circulatingCredits.map(c => (
                  <option key={c.creditId} value={c.creditId}>
                    {c.creditId} ({c.quantityGpuHours.toLocaleString()} GPU-Hrs | {c.classId} | {c.ownerName})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-400 text-[10px] uppercase mb-1">Target Delivery Facility</label>
                <select
                  value={targetCentreId}
                  onChange={e => setTargetCentreId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-slate-200"
                >
                  {dataCentres.map(dc => (
                    <option key={dc.id} value={dc.id}>
                      {dc.name} ({dc.location})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 text-[10px] uppercase mb-1">Hours to Redeem</label>
                <input
                  type="number"
                  min="100"
                  step="100"
                  max={selectedCredit?.quantityGpuHours || 100000}
                  value={redeemQuantity}
                  onChange={e => setRedeemQuantity(parseInt(e.target.value) || 100)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-slate-200 font-bold"
                />
              </div>
            </div>

            {/* 5-Step Pipeline Progress Indicator */}
            <div className="bg-slate-950 rounded-xl p-4 border border-slate-800 space-y-2">
              <span className="text-slate-400 block text-[10px] uppercase font-bold">
                Automated 5-Step Delivery Lifecycle:
              </span>
              <div className="grid grid-cols-5 gap-1 text-[10px] text-center">
                <div className="bg-slate-900 p-2 rounded text-cyan-300">1. Holder Request</div>
                <div className="bg-slate-900 p-2 rounded text-indigo-300">2. Proof Audit</div>
                <div className="bg-slate-900 p-2 rounded text-amber-300">3. Hardware Lock</div>
                <div className="bg-slate-900 p-2 rounded text-emerald-300">4. Run Workload</div>
                <div className="bg-purple-950 p-2 rounded text-purple-200 font-bold">5. Burn to Sink</div>
              </div>
            </div>

            <button
              type="submit"
              disabled={!selectedCredit}
              className="w-full py-3 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Flame className="h-4 w-4" />
              <span>Redeem Physical Capacity &amp; Permanently Retire Credit</span>
            </button>
          </form>
        </div>

        {/* Col 3: Retired Sink Ledger */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center gap-1.5">
              <Lock className="h-4 w-4 text-purple-400" />
              Permanent Retirement Sink
            </h3>
            <p className="text-xs text-slate-400">Dead address sink accounting</p>
          </div>

          <div className="space-y-2 font-mono text-xs">
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <span className="text-slate-500 text-[10px] uppercase block">Total Burned Volume</span>
              <div className="text-lg font-bold text-purple-400">
                {retiredCredits.reduce((acc, c) => acc + c.quantityGpuHours, 0).toLocaleString()} GPU-Hrs
              </div>
              <span className="text-[10px] text-slate-400">Permanently Taken Out of Circulation</span>
            </div>

            <div className="space-y-1.5 pt-2">
              <span className="text-slate-400 text-[10px] uppercase block">Recent Retirement Records</span>
              {retiredCredits.map(c => (
                <div key={c.creditId} className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-[11px]">
                  <div className="flex justify-between text-slate-200 font-semibold">
                    <span>{c.creditId}</span>
                    <span className="text-purple-400">{c.quantityGpuHours.toLocaleString()} Hrs</span>
                  </div>
                  <div className="text-slate-500 text-[10px]">
                    Status: <span className="text-purple-300 font-bold">BURNED</span> • Proof:{' '}
                    <span className="text-slate-400">{c.proofRange}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
