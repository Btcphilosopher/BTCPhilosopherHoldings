/**
 * Market, Order Book & Matching Engine View
 * Duke Satoshi Proof-of-Work Compute Exchange
 */

import React, { useState } from 'react';
import { Zap, TrendingUp, TrendingDown, Clock, ShieldCheck, ArrowRight, Activity, DollarSign } from 'lucide-react';
import { useComputeExchange } from '../../context/ComputeExchangeContext';

export const MarketView: React.FC = () => {
  const { orders, trades, placeOrder } = useComputeExchange();

  const [selectedPair, setSelectedPair] = useState('DS-H200/USD');
  const [orderSide, setOrderSide] = useState<'BID' | 'ASK'>('BID');
  const [orderType, setOrderType] = useState<'LIMIT' | 'MARKET'>('LIMIT');
  const [price, setPrice] = useState('4.85');
  const [quantity, setQuantity] = useState('1000');
  const [traderName, setTraderName] = useState('Institutional Quantitative Fund');

  const pairOrders = orders.filter(o => o.pair === selectedPair);
  const bids = pairOrders.filter(o => o.side === 'BID' && o.status !== 'FILLED').sort((a, b) => b.price - a.price);
  const asks = pairOrders.filter(o => o.side === 'ASK' && o.status !== 'FILLED').sort((a, b) => a.price - b.price);
  const pairTrades = trades.filter(t => t.pair === selectedPair);

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    placeOrder({
      pair: selectedPair,
      side: orderSide,
      type: orderType,
      price: parseFloat(price) || 4.85,
      quantity: parseInt(quantity) || 1000,
      traderId: `CLI-${Date.now().toString(16).slice(-4).toUpperCase()}`,
      traderName,
    });
  };

  return (
    <div className="space-y-6">
      {/* Doctrine Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-amber-400 uppercase tracking-wider">
            <Zap className="h-4 w-4" />
            <span>Section 16: Exchange &amp; Compute Credit Market Infrastructure</span>
          </div>
          <h2 className="text-lg font-bold text-white mt-1">Proof-of-Production Secondary Market</h2>
          <p className="text-xs text-slate-400">
            Proven computational work is liquid and transferable. Spot markets establish continuous fair valuation for
            verified GPU capacity.
          </p>
        </div>

        {/* Pair Switcher */}
        <div className="flex flex-wrap gap-2">
          {['DS-H200/USD', 'DS-H100/USD', 'DS-B200/USD', 'DS-AI-INFERENCE/USD'].map(pair => (
            <button
              key={pair}
              onClick={() => setSelectedPair(pair)}
              className={`px-3 py-1.5 rounded-lg font-mono text-xs font-semibold transition-colors ${
                selectedPair === pair
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {pair}
            </button>
          ))}
        </div>
      </div>

      {/* Main Trading Floor Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Col 1 & 2: Order Book & Trades */}
        <div className="lg:col-span-2 space-y-6">
          {/* Order Book Depth */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                  Order Book: {selectedPair}
                </h3>
                <p className="text-xs text-slate-400">Continuous double-auction depth with sub-cent tick size</p>
              </div>
              <div className="text-xs font-mono text-slate-400 flex items-center gap-3">
                <span>Spread: <strong className="text-white">$0.02</strong></span>
                <span>VWAP: <strong className="text-amber-400">$4.85</strong></span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
              {/* Asks (Sells) */}
              <div className="space-y-2">
                <span className="text-red-400 font-bold block text-[11px] uppercase">
                  Sell Orders (Asks)
                </span>
                <div className="bg-slate-950 rounded-lg p-2 border border-slate-800 space-y-1 divide-y divide-slate-850">
                  <div className="flex justify-between text-[10px] text-slate-500 pb-1">
                    <span>PRICE ($)</span>
                    <span>SIZE (GPU-HRS)</span>
                    <span>TRADER</span>
                  </div>
                  {asks.map(a => (
                    <div key={a.orderId} className="flex justify-between py-1 text-slate-300">
                      <span className="text-red-400 font-bold">${a.price.toFixed(2)}</span>
                      <span>{(a.quantity - a.filled).toLocaleString()}</span>
                      <span className="text-slate-500 text-[10px] truncate max-w-[100px]">{a.traderName}</span>
                    </div>
                  ))}
                  {asks.length === 0 && (
                    <div className="text-slate-600 text-center py-2">No open asks</div>
                  )}
                </div>
              </div>

              {/* Bids (Buys) */}
              <div className="space-y-2">
                <span className="text-emerald-400 font-bold block text-[11px] uppercase">
                  Buy Orders (Bids)
                </span>
                <div className="bg-slate-950 rounded-lg p-2 border border-slate-800 space-y-1 divide-y divide-slate-850">
                  <div className="flex justify-between text-[10px] text-slate-500 pb-1">
                    <span>PRICE ($)</span>
                    <span>SIZE (GPU-HRS)</span>
                    <span>TRADER</span>
                  </div>
                  {bids.map(b => (
                    <div key={b.orderId} className="flex justify-between py-1 text-slate-300">
                      <span className="text-emerald-400 font-bold">${b.price.toFixed(2)}</span>
                      <span>{(b.quantity - b.filled).toLocaleString()}</span>
                      <span className="text-slate-500 text-[10px] truncate max-w-[100px]">{b.traderName}</span>
                    </div>
                  ))}
                  {bids.length === 0 && (
                    <div className="text-slate-600 text-center py-2">No open bids</div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Trade Execution Tape */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              Market Trade Execution Stream
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-500 text-[10px] uppercase">
                    <th className="py-2 px-3">Trade ID</th>
                    <th className="py-2 px-3">Price</th>
                    <th className="py-2 px-3">Quantity</th>
                    <th className="py-2 px-3">Buyer</th>
                    <th className="py-2 px-3">Seller</th>
                    <th className="py-2 px-3">Settlement TX</th>
                    <th className="py-2 px-3">Time</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300 text-[11px]">
                  {pairTrades.map(t => (
                    <tr key={t.tradeId} className="hover:bg-slate-800/40">
                      <td className="py-2.5 px-3 font-bold text-slate-200">{t.tradeId}</td>
                      <td className="py-2.5 px-3 text-emerald-400 font-bold">${t.price.toFixed(2)}</td>
                      <td className="py-2.5 px-3 text-white font-semibold">{t.quantity.toLocaleString()}</td>
                      <td className="py-2.5 px-3 text-slate-400 truncate max-w-[120px]">{t.buyer}</td>
                      <td className="py-2.5 px-3 text-slate-400 truncate max-w-[120px]">{t.seller}</td>
                      <td className="py-2.5 px-3 text-cyan-300 text-[10px]">{t.settlementTxId}</td>
                      <td className="py-2.5 px-3 text-slate-500 text-[10px]">
                        {new Date(t.timestamp).toLocaleTimeString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Col 3: Order Entry Form */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">Place Exchange Order</h3>
            <p className="text-xs text-slate-400">Institutional credit execution router</p>
          </div>

          <form onSubmit={handlePlaceOrder} className="space-y-4 text-xs font-mono">
            {/* Bid / Ask Selector */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setOrderSide('BID')}
                className={`py-2 rounded-lg font-bold transition-colors ${
                  orderSide === 'BID'
                    ? 'bg-emerald-500 text-slate-950'
                    : 'bg-slate-950 text-slate-400 border border-slate-800'
                }`}
              >
                BUY (BID)
              </button>
              <button
                type="button"
                onClick={() => setOrderSide('ASK')}
                className={`py-2 rounded-lg font-bold transition-colors ${
                  orderSide === 'ASK'
                    ? 'bg-red-500 text-slate-950'
                    : 'bg-slate-950 text-slate-400 border border-slate-800'
                }`}
              >
                SELL (ASK)
              </button>
            </div>

            <div>
              <label className="block text-slate-400 text-[10px] uppercase mb-1">Trading Entity</label>
              <input
                type="text"
                value={traderName}
                onChange={e => setTraderName(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 text-[10px] uppercase mb-1">Order Type</label>
                <select
                  value={orderType}
                  onChange={e => setOrderType(e.target.value as 'LIMIT' | 'MARKET')}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-slate-200"
                >
                  <option value="LIMIT">LIMIT</option>
                  <option value="MARKET">MARKET</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 text-[10px] uppercase mb-1">Limit Price ($)</label>
                <input
                  type="number"
                  step="0.01"
                  value={price}
                  onChange={e => setPrice(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-amber-500 font-bold"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-400 text-[10px] uppercase mb-1">Quantity (GPU-Hours)</label>
              <input
                type="number"
                step="100"
                value={quantity}
                onChange={e => setQuantity(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-amber-500 font-bold"
              />
            </div>

            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1 text-slate-400 text-[11px]">
              <div className="flex justify-between">
                <span>Notional Total:</span>
                <span className="font-bold text-white">
                  ${((parseFloat(price) || 0) * (parseInt(quantity) || 0)).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Settlement Asset:</span>
                <span className="text-cyan-400 font-bold">Physical Provenance Backed</span>
              </div>
            </div>

            <button
              type="submit"
              className={`w-full py-2.5 rounded-lg font-bold text-xs transition-colors ${
                orderSide === 'BID'
                  ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                  : 'bg-red-500 hover:bg-red-400 text-slate-950'
              }`}
            >
              Submit {orderSide} Order
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
