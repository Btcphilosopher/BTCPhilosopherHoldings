/**
 * Data Centres as Mints View
 * Duke Satoshi Proof-of-Work Compute Exchange
 * Organisation: Duke Satoshi of Cyberspace PLC
 */

import React, { useState } from 'react';
import {
  Database,
  Cpu,
  Zap,
  ShieldCheck,
  Play,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Wind,
  Layers,
  Activity,
  ArrowRight,
} from 'lucide-react';
import { useComputeExchange } from '../../context/ComputeExchangeContext';
import { WorkType } from '../../types';
import { WORK_REGISTRY } from '../../data/initialData';

interface DataCentresViewProps {
  onInspectProof: (proofId: string) => void;
}

export const DataCentresView: React.FC<DataCentresViewProps> = ({ onInspectProof }) => {
  const { dataCentres, dispatchJob, runJobSimulation, createWorkOrder, isSimulating } = useComputeExchange();

  const [selectedCentre, setSelectedCentre] = useState(dataCentres[0]?.id || 'DSCX-London-01');
  const [selectedWorkType, setSelectedWorkType] = useState<WorkType>('AI_TRAINING');
  const [hoursToDispatch, setHoursToDispatch] = useState(2000);
  const [lastDispatchedProofId, setLastDispatchedProofId] = useState<string | null>(null);

  const activeCentre = dataCentres.find(d => d.id === selectedCentre) || dataCentres[0];

  const handleLaunchProductionRun = async () => {
    // 1. Create order
    const order = createWorkOrder({
      providerId: activeCentre.id,
      customerName: 'Institutional Mint Production Batch',
      workType: selectedWorkType,
      title: `${selectedWorkType} Production Batch (${hoursToDispatch} GPU-Hrs)`,
      requiredComputeGpuHours: hoursToDispatch,
    });

    // 2. Dispatch
    const job = dispatchJob(order.orderId, activeCentre.id);

    // 3. Run simulation
    const proof = await runJobSimulation(job.jobId, 2);
    if (proof) {
      setLastDispatchedProofId(proof.proofId);
    }
  };

  return (
    <div className="space-y-6">
      {/* Doctrine Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 sm:p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">
            <Database className="h-4 w-4" />
            <span>Section 27 &amp; 28: Data Centre as Mint Architecture</span>
          </div>
          <p className="text-sm font-medium text-slate-200 mt-1">
            A data centre is not a cryptocurrency miner burning hashes. It is a{' '}
            <strong className="text-amber-400">Proof-of-Production Centre</strong>.
          </p>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            MINTING INVARIANTS: NO HARDWARE → NO WORK → NO PROOF → NO VERIFIED PRODUCTION → NO CREDIT
          </p>
        </div>
        <div className="bg-slate-950 px-3 py-2 rounded-lg border border-slate-800 font-mono text-xs text-emerald-400 flex items-center gap-2">
          <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>3 Authorized Facilities Online</span>
        </div>
      </div>

      {/* Facilities Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {dataCentres.map(centre => {
          const isSelected = centre.id === activeCentre.id;
          return (
            <div
              key={centre.id}
              onClick={() => setSelectedCentre(centre.id)}
              className={`rounded-xl p-5 border cursor-pointer transition-all flex flex-col justify-between gap-4 ${
                isSelected
                  ? 'bg-slate-900 border-amber-500/60 ring-1 ring-amber-500/40 shadow-lg'
                  : 'bg-slate-900/70 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="font-mono text-xs text-amber-400 font-bold block">{centre.id}</span>
                    <h3 className="text-base font-bold text-white mt-0.5">{centre.name}</h3>
                    <p className="text-xs text-slate-400">{centre.location}</p>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-950 text-cyan-300 border border-slate-800">
                    {centre.tier}
                  </span>
                </div>

                <div className="space-y-1.5 font-mono text-xs text-slate-300 pt-2 border-t border-slate-800/80">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Total GPU Fleet:</span>
                    <span className="font-bold text-white">{(centre.totalGpuCapacity || 0).toLocaleString()} GPUs</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Power Baseline:</span>
                    <span className="text-amber-300">{(centre.pue || 1.12).toFixed(2)} PUE ({centre.renewablePercentage || 100}% Green)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Useful Work/kWh:</span>
                    <span className="text-emerald-400 font-bold">{centre.usefulWorkPerKwh || 1.0} Work/kWh</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Verified Output:</span>
                    <span className="text-cyan-300 font-bold">{(centre.verifiedGpuHours || 0).toLocaleString()} GPU-hrs</span>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                <span className="text-[11px] font-mono text-slate-400">
                  {centre.clusters?.length || 0} Production Clusters
                </span>
                <span className="text-amber-400 font-medium flex items-center gap-1">
                  {isSelected ? 'Active Mint Selected' : 'Select Mint'}
                  <ArrowRight className="h-3 w-3" />
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Mint Deep Inspection & Real-Time Production Runner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs font-bold text-amber-400">{activeCentre.id}</span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-950/60 text-emerald-300 border border-emerald-500/40">
                {activeCentre.verificationGrade}
              </span>
            </div>
            <h2 className="text-lg font-bold text-white mt-1">{activeCentre.name}</h2>
            <p className="text-xs text-slate-400">
              Power Grid: <strong className="text-slate-200">{activeCentre.powerSource}</strong> • Allocated:{' '}
              <strong className="text-slate-200">{(activeCentre.gridMwhAllocated || 0).toLocaleString()} MWh</strong>
            </p>
          </div>

          {/* Interactive Workload Production Runner */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-wrap items-center gap-3">
            <div>
              <span className="text-[10px] font-mono text-slate-500 uppercase block mb-1">Workload Class</span>
              <select
                value={selectedWorkType}
                onChange={e => setSelectedWorkType(e.target.value as WorkType)}
                className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-mono"
              >
                <option value="AI_TRAINING">AI_TRAINING (BF16 H200)</option>
                <option value="AI_INFERENCE">AI_INFERENCE (FP8 H100)</option>
                <option value="ENGINEERING_SIMULATION">ENGINEERING_SIMULATION (FP64)</option>
                <option value="MONTE_CARLO">MONTE_CARLO (FP32 H100)</option>
                <option value="PHYSICS_SIMULATION">PHYSICS_SIMULATION (B200)</option>
              </select>
            </div>

            <div>
              <span className="text-[10px] font-mono text-slate-500 uppercase block mb-1">Workload Volume</span>
              <select
                value={hoursToDispatch}
                onChange={e => setHoursToDispatch(parseInt(e.target.value))}
                className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-mono"
              >
                <option value={500}>500 GPU-Hours</option>
                <option value={2000}>2,000 GPU-Hours</option>
                <option value={5000}>5,000 GPU-Hours</option>
                <option value={10000}>10,000 GPU-Hours</option>
              </select>
            </div>

            <div className="self-end">
              <button
                onClick={handleLaunchProductionRun}
                disabled={isSimulating}
                className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold text-xs flex items-center gap-1.5 transition-colors disabled:opacity-50"
              >
                <Play className="h-3.5 w-3.5 fill-current" />
                <span>{isSimulating ? 'Executing Workload...' : 'Launch Verified Production Run'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Feedback if run produced proof */}
        {lastDispatchedProofId && (
          <div className="bg-emerald-950/60 border border-emerald-500/50 rounded-lg p-3 text-xs flex items-center justify-between font-mono text-emerald-300">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-400" />
              <span>
                Production batch verified &amp; sealed: <strong>Proof #{lastDispatchedProofId}</strong> issued to
                credit ledger.
              </span>
            </div>
            <button
              onClick={() => onInspectProof(lastDispatchedProofId)}
              className="px-2.5 py-1 rounded bg-emerald-900 text-emerald-100 hover:bg-emerald-800 text-[11px]"
            >
              Inspect Proof
            </button>
          </div>
        )}

        {/* Clusters & Interconnect Array */}
        <div className="space-y-3">
          <h3 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">
            Active Production Clusters &amp; Interconnect Fabrics
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {activeCentre.clusters.map(c => (
              <div key={c.clusterId} className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-slate-200">{c.name}</span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-emerald-950/60 text-emerald-400 border border-emerald-800">
                    {c.status}
                  </span>
                </div>
                <div className="text-xs font-mono text-slate-400 space-y-1">
                  <div>Cluster ID: <span className="text-slate-300">{c.clusterId}</span></div>
                  <div>Racks: <span className="text-slate-300">{c.racksCount} liquid-cooled racks</span></div>
                  <div>Density: <span className="text-slate-300">{c.gpusPerRack} GPUs per rack</span></div>
                  <div>Fabric: <span className="text-cyan-400">{c.interconnect}</span></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Energy Provenance Metric */}
        <div className="bg-slate-950 rounded-xl p-4 border border-slate-800 space-y-2 font-mono text-xs">
          <div className="flex items-center justify-between text-slate-300 font-semibold border-b border-slate-800/80 pb-2">
            <span className="flex items-center gap-1.5 text-amber-400">
              <Zap className="h-4 w-4" />
              Section 25: Energy Provenance Integration
            </span>
            <span className="text-emerald-400">{activeCentre.renewablePercentage}% Renewable PPA</span>
          </div>
          <p className="text-slate-400 text-[11px] leading-relaxed">
            Data centre telemetry correlates MWh consumed with productive GPU-hours, validating power meters
            against job scheduler state. Every issued credit accounts for its embedded carbon and energy displacement.
          </p>
          <div className="grid grid-cols-3 gap-2 pt-2 text-center">
            <div className="bg-slate-900 p-2 rounded border border-slate-800">
              <span className="text-slate-500 text-[10px] block">Energy Consumed</span>
              <span className="text-slate-200 font-bold">{(activeCentre.verifiedGpuHours * 0.7 / 1000).toFixed(1)} MWh</span>
            </div>
            <div className="bg-slate-900 p-2 rounded border border-slate-800">
              <span className="text-slate-500 text-[10px] block">Facility PUE</span>
              <span className="text-amber-400 font-bold">{activeCentre.pue.toFixed(2)}</span>
            </div>
            <div className="bg-slate-900 p-2 rounded border border-slate-800">
              <span className="text-slate-500 text-[10px] block">Useful Output / £</span>
              <span className="text-emerald-400 font-bold">5.82 GPU-Hrs / £</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
