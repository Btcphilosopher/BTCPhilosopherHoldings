/**
 * Overview & Enterprise Dashboard View
 * Duke Satoshi Proof-of-Work Compute Exchange (DS-PoW)
 */

import React from 'react';
import {
  Cpu,
  Zap,
  ShieldCheck,
  TrendingUp,
  Database,
  ArrowUpRight,
  Activity,
  Layers,
  Award,
  Play,
  Clock,
  Sparkles,
  Lock,
} from 'lucide-react';
import { useComputeExchange } from '../../context/ComputeExchangeContext';

interface OverviewViewProps {
  onInspectProof: (proofId: string) => void;
  setActiveTab: (tab: string) => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({ onInspectProof, setActiveTab }) => {
  const {
    dataCentres,
    proofChain,
    credits,
    creditClasses,
    executeVerticalSlice1,
    executeVerticalSlice2,
    executeVerticalSlice3,
    executeVerticalSlice4,
    isSimulating,
  } = useComputeExchange();

  // Aggregate computations
  const totalPhysicalGpuCapacity = dataCentres.reduce((acc, d) => acc + d.totalGpuCapacity, 0);
  const activeGpuCapacity = dataCentres.reduce((acc, d) => acc + d.activeGpuCapacity, 0);
  const totalCompletedGpuHours = dataCentres.reduce((acc, d) => acc + d.completedGpuHours, 0);
  const totalVerifiedGpuHours = dataCentres.reduce((acc, d) => acc + d.verifiedGpuHours, 0);
  const totalCreditsIssued = dataCentres.reduce((acc, d) => acc + d.creditsIssued, 0);
  const totalCreditsRedeemed = dataCentres.reduce((acc, d) => acc + d.creditsRedeemed, 0);
  const circulatingCredits = totalCreditsIssued - totalCreditsRedeemed;
  const totalMwhConsumed = (totalVerifiedGpuHours * 0.7) / 1000;

  // Supply visualization percentages (referenced to physical capacity baseline)
  const maxBaseline = 5000000;
  const pPhysical = 100;
  const pCompleted = Math.min(100, (totalCompletedGpuHours / maxBaseline) * 100);
  const pVerified = Math.min(100, (totalVerifiedGpuHours / maxBaseline) * 100);
  const pIssued = Math.min(100, (totalCreditsIssued / maxBaseline) * 100);
  const pCirculating = Math.min(100, (circulatingCredits / maxBaseline) * 100);
  const pRedeemed = Math.min(100, (totalCreditsRedeemed / maxBaseline) * 100);

  return (
    <div className="space-y-6">
      {/* Central Economic Principle Callout */}
      <div className="rounded-xl bg-gradient-to-r from-amber-500/10 via-slate-900 to-cyan-500/10 border border-amber-500/20 p-4 sm:p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-amber-400 uppercase tracking-wider">
            <Sparkles className="h-4 w-4" />
            <span>Foundational Economic Doctrine</span>
          </div>
          <p className="text-sm font-medium text-slate-200">
            &ldquo;Work produces the credit. The credit represents proven productive computation. The exchange makes
            that proven work transferable.&rdquo;
          </p>
          <p className="text-xs text-slate-400 font-mono">
            PHYSICAL CAPACITY → COMPUTATIONAL WORK → VERIFIABLE OUTPUT → PROOF → CREDIT ISSUANCE → EXCHANGE → SETTLEMENT
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setActiveTab('datacentres')}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors border border-slate-700"
          >
            View Mints
          </button>
          <button
            onClick={() => setActiveTab('market')}
            className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-semibold transition-colors"
          >
            Enter Exchange
          </button>
        </div>
      </div>

      {/* Section 35: Headline Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 space-y-1">
          <span className="text-slate-400 text-[11px] uppercase tracking-wider font-mono flex items-center justify-between">
            <span>Verified Work</span>
            <ShieldCheck className="h-3.5 w-3.5 text-cyan-400" />
          </span>
          <div className="text-lg sm:text-xl font-bold font-mono text-white">
            {totalVerifiedGpuHours.toLocaleString()}
          </div>
          <span className="text-[10px] text-emerald-400 font-mono">GPU-HOURS TOTAL</span>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 space-y-1">
          <span className="text-slate-400 text-[11px] uppercase tracking-wider font-mono flex items-center justify-between">
            <span>Today&apos;s Production</span>
            <Activity className="h-3.5 w-3.5 text-emerald-400" />
          </span>
          <div className="text-lg sm:text-xl font-bold font-mono text-emerald-400">
            +184,200
          </div>
          <span className="text-[10px] text-slate-400 font-mono">24H AUDITED RUNS</span>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 space-y-1">
          <span className="text-slate-400 text-[11px] uppercase tracking-wider font-mono flex items-center justify-between">
            <span>Circulating Credits</span>
            <Zap className="h-3.5 w-3.5 text-amber-400" />
          </span>
          <div className="text-lg sm:text-xl font-bold font-mono text-amber-300">
            {circulatingCredits.toLocaleString()}
          </div>
          <span className="text-[10px] text-slate-400 font-mono">UNREDEEMED UNITS</span>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 space-y-1">
          <span className="text-slate-400 text-[11px] uppercase tracking-wider font-mono flex items-center justify-between">
            <span>Credits Retired</span>
            <Lock className="h-3.5 w-3.5 text-purple-400" />
          </span>
          <div className="text-lg sm:text-xl font-bold font-mono text-purple-300">
            {totalCreditsRedeemed.toLocaleString()}
          </div>
          <span className="text-[10px] text-slate-400 font-mono">PERMANENTLY BURNED</span>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 space-y-1 col-span-2 sm:col-span-1">
          <span className="text-slate-400 text-[11px] uppercase tracking-wider font-mono flex items-center justify-between">
            <span>Active GPU Fleet</span>
            <Cpu className="h-3.5 w-3.5 text-indigo-400" />
          </span>
          <div className="text-lg sm:text-xl font-bold font-mono text-white">
            {activeGpuCapacity.toLocaleString()} / {totalPhysicalGpuCapacity.toLocaleString()}
          </div>
          <span className="text-[10px] text-cyan-400 font-mono">3 AUTHORIZED MINTS</span>
        </div>
      </div>

      {/* Section 41: Strict 5-Tier Supply Accounting Visualisation */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
              <Layers className="h-4 w-4 text-cyan-400" />
              Proof-of-Production Supply Accounting
            </h3>
            <p className="text-xs text-slate-400">
              No fractional creation: Credits issued are strictly bounded by verified computational work.
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
            <span>Ratio Issued/Verified:</span>
            <span className="text-emerald-400 font-bold">100.0% (No Dilution)</span>
          </div>
        </div>

        {/* The 5 Stacked Waterfall Bars */}
        <div className="space-y-3 font-mono text-xs">
          {/* 1. Physical Capacity */}
          <div className="space-y-1">
            <div className="flex justify-between text-slate-300">
              <span className="font-semibold text-slate-400">1. PHYSICAL COMPUTE CAPACITY</span>
              <span>5,000,000 GPU-Hours (Quarterly Max)</span>
            </div>
            <div className="h-4 w-full bg-slate-950 rounded overflow-hidden border border-slate-800">
              <div
                className="h-full bg-slate-600 rounded transition-all duration-500"
                style={{ width: `${pPhysical}%` }}
              />
            </div>
          </div>

          {/* 2. Completed Work */}
          <div className="space-y-1">
            <div className="flex justify-between text-slate-300">
              <span className="font-semibold text-cyan-400">2. COMPLETED WORKLOADS</span>
              <span>{totalCompletedGpuHours.toLocaleString()} GPU-Hours</span>
            </div>
            <div className="h-4 w-full bg-slate-950 rounded overflow-hidden border border-slate-800">
              <div
                className="h-full bg-cyan-600 rounded transition-all duration-500"
                style={{ width: `${pCompleted}%` }}
              />
            </div>
          </div>

          {/* 3. Verified Work */}
          <div className="space-y-1">
            <div className="flex justify-between text-slate-300">
              <span className="font-semibold text-emerald-400">3. CRYPTOGRAPHICALLY VERIFIED WORK</span>
              <span>{totalVerifiedGpuHours.toLocaleString()} GPU-Hours (Passes Multi-Sig)</span>
            </div>
            <div className="h-4 w-full bg-slate-950 rounded overflow-hidden border border-slate-800">
              <div
                className="h-full bg-emerald-500 rounded transition-all duration-500"
                style={{ width: `${pVerified}%` }}
              />
            </div>
          </div>

          {/* 4. Credits Issued */}
          <div className="space-y-1">
            <div className="flex justify-between text-slate-300">
              <span className="font-semibold text-amber-400">4. CREDITS ISSUED</span>
              <span>{totalCreditsIssued.toLocaleString()} DS-PoW Credits</span>
            </div>
            <div className="h-4 w-full bg-slate-950 rounded overflow-hidden border border-slate-800">
              <div
                className="h-full bg-amber-500 rounded transition-all duration-500"
                style={{ width: `${pIssued}%` }}
              />
            </div>
          </div>

          {/* 5. Credits Circulating vs Retired */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div className="space-y-1 bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div className="flex justify-between text-amber-300">
                <span>CIRCULATING SUPPLY:</span>
                <span className="font-bold">{circulatingCredits.toLocaleString()}</span>
              </div>
              <div className="h-2.5 w-full bg-slate-900 rounded overflow-hidden">
                <div className="h-full bg-amber-400" style={{ width: `${pCirculating}%` }} />
              </div>
              <p className="text-[10px] text-slate-400">Available for trading, OTC swaps, or forward claims</p>
            </div>

            <div className="space-y-1 bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div className="flex justify-between text-purple-300">
                <span>PERMANENTLY RETIRED:</span>
                <span className="font-bold">{totalCreditsRedeemed.toLocaleString()}</span>
              </div>
              <div className="h-2.5 w-full bg-slate-900 rounded overflow-hidden">
                <div className="h-full bg-purple-500" style={{ width: `${pRedeemed}%` }} />
              </div>
              <p className="text-[10px] text-slate-400">Redeemed for real compute and burned from circulation</p>
            </div>
          </div>
        </div>
      </div>

      {/* Section 21 & Section 31: Production Curve & Economic Valuation Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Section 21: Computational Production Curve (Forecast) */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-emerald-400" />
                Computational Production Curve (Forward Horizon)
              </h3>
              <p className="text-xs text-slate-400">
                Forecasted productive capacity across Duke Satoshi authorized data centres
              </p>
            </div>
            <span className="text-xs font-mono text-slate-400">TFLOP/s Calibrated</span>
          </div>

          <div className="grid grid-cols-4 gap-2 text-center text-xs font-mono">
            {[
              { month: 'January', actual: 4877000, expected: 4800000, reserved: 3200000, unallocated: 1677000 },
              { month: 'February', actual: 5240000, expected: 5100000, reserved: 3900000, unallocated: 1340000 },
              { month: 'March', actual: 5800000, expected: 5600000, reserved: 4500000, unallocated: 1300000 },
              { month: 'April (Est)', actual: 6450000, expected: 6400000, reserved: 5100000, unallocated: 1350000 },
            ].map(col => (
              <div key={col.month} className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1.5">
                <div className="text-slate-400 font-semibold">{col.month}</div>
                <div className="text-sm font-bold text-emerald-400">
                  {(col.actual / 1000000).toFixed(2)}M
                </div>
                <div className="text-[10px] text-slate-500 space-y-0.5 pt-1 border-t border-slate-800/80">
                  <div>Rsv: {(col.reserved / 1000000).toFixed(1)}M</div>
                  <div className="text-cyan-400">Unalloc: {(col.unallocated / 1000000).toFixed(1)}M</div>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800/80 flex flex-wrap items-center justify-between text-xs text-slate-300 font-mono">
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-emerald-400" />
              <span>Current Production: ~184k GPU-hrs/day</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-amber-400" />
              <span>PUE Efficiency Baseline: 1.12</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-cyan-400" />
              <span>Average Work/kWh: 26.4</span>
            </div>
          </div>
        </div>

        {/* Section 31: Four Economic Valuations */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              Section 31: Valuation Matrix
            </h3>
            <p className="text-xs text-slate-400">Distinct economic quantities per DS-H200 Credit</p>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase">Market Price</span>
                <span className="font-bold text-amber-300 text-sm">$4.85 / GPU-Hr</span>
              </div>
              <span className="text-[10px] text-slate-500 text-right">Order Book VWAP</span>
            </div>

            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase">Redemption Value</span>
                <span className="font-bold text-emerald-400 text-sm">$4.60 / GPU-Hr</span>
              </div>
              <span className="text-[10px] text-slate-500 text-right">Contract SLA</span>
            </div>

            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase">Production Value</span>
                <span className="font-bold text-cyan-300 text-sm">$3.82 / GPU-Hr</span>
              </div>
              <span className="text-[10px] text-slate-500 text-right">Power + CapEx</span>
            </div>

            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase">Replacement Cost</span>
                <span className="font-bold text-purple-300 text-sm">$5.40 / GPU-Hr</span>
              </div>
              <span className="text-[10px] text-slate-500 text-right">Spot On-Demand</span>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Cryptographic Proofs Stream */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-cyan-400" />
              Recent Verified Proof Records (Immutable Proof Chain)
            </h3>
            <p className="text-xs text-slate-400">
              Each proof seals hardware telemetry, output checkpoint commitments, and multi-verifier signatures
            </p>
          </div>
          <button
            onClick={() => setActiveTab('proofchain')}
            className="text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
          >
            <span>View All ({proofChain.length})</span>
            <ArrowUpRight className="h-3.5 w-3.5" />
          </button>
        </div>

        <div className="divide-y divide-slate-800/80">
          {proofChain.slice(-4).reverse().map(proof => (
            <div
              key={proof.proofId}
              onClick={() => onInspectProof(proof.proofId)}
              className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-800/40 px-2 rounded-lg cursor-pointer transition-colors text-xs"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-cyan-300">PROOF #{proof.proofId}</span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-emerald-950/60 text-emerald-300 border border-emerald-500/40">
                    {proof.status}
                  </span>
                  <span className="text-slate-400 font-mono text-[11px]">{proof.workType}</span>
                </div>
                <div className="text-slate-400 text-[11px] font-mono">
                  Issuer: <span className="text-slate-200">{proof.providerId}</span> • Hash:{' '}
                  <span className="text-slate-300">{proof.proofHash.slice(0, 18)}...</span>
                </div>
              </div>

              <div className="flex items-center gap-4 text-right font-mono">
                <div>
                  <div className="text-white font-bold">{proof.computeConsumedGpuHours.toLocaleString()} GPU-Hrs</div>
                  <div className="text-[10px] text-amber-400">{proof.energyConsumedMwh} MWh</div>
                </div>
                <button
                  onClick={e => {
                    e.stopPropagation();
                    onInspectProof(proof.proofId);
                  }}
                  className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition-colors"
                >
                  Inspect
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
