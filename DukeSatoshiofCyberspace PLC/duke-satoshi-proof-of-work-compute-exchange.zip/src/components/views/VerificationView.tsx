/**
 * Verifier Consensus & Assurance Matrix View
 * Duke Satoshi Proof-of-Work Compute Exchange
 */

import React, { useState } from 'react';
import {
  Award,
  ShieldCheck,
  CheckCircle2,
  GitCompare,
  AlertTriangle,
  Scale,
  Users,
  Activity,
  Layers,
} from 'lucide-react';
import { useComputeExchange } from '../../context/ComputeExchangeContext';

export const VerificationView: React.FC = () => {
  const { verifiers } = useComputeExchange();

  const [simulatingRedundancy, setSimulatingRedundancy] = useState(false);
  const [redundancyResult, setRedundancyResult] = useState<{
    providerAOutput: string;
    providerBOutput: string;
    bitErrorRate: number;
    divergenceEpsilon: number;
    passed: boolean;
  } | null>(null);

  const handleTestRedundancy = () => {
    setSimulatingRedundancy(true);
    setTimeout(() => {
      setRedundancyResult({
        providerAOutput: '0x3f8a91c890192847581920384759102938475910293847591029384759102938',
        providerBOutput: '0x3f8a91c890192847581920384759102938475910293847591029384759102938',
        bitErrorRate: 0.0,
        divergenceEpsilon: 3.4e-9,
        passed: true,
      });
      setSimulatingRedundancy(false);
    }, 1200);
  };

  return (
    <div className="space-y-6">
      {/* Doctrine Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-amber-400 uppercase tracking-wider">
            <Award className="h-4 w-4" />
            <span>Section 9 &amp; 19: Multi-Party Independent Verifier Consensus</span>
          </div>
          <h2 className="text-lg font-bold text-white mt-1">Decentralized Verification Protocol</h2>
          <p className="text-xs text-slate-400">
            Proofs are never self-certified by data centres. Independent authorized verifier nodes audit hardware telemetry,
            recalculate deterministic steps, and stake capital against cryptographic attestations.
          </p>
        </div>
        <div className="bg-slate-950 px-3 py-2 rounded-lg border border-slate-800 font-mono text-xs text-cyan-400">
          Consensus Model: BFT Multi-Sig (Threshold &gt;= 3/4)
        </div>
      </div>

      {/* Active Independent Verifier Entities */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {verifiers.map(v => (
          <div key={v.id} className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <span className="font-mono text-xs font-bold text-cyan-400">{v.id}</span>
                <h3 className="text-sm font-bold text-white mt-0.5">{v.name}</h3>
                <p className="text-[11px] text-slate-400">{v.organization}</p>
              </div>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-emerald-950/60 text-emerald-400 border border-emerald-800">
                {v.status}
              </span>
            </div>

            <div className="space-y-1 text-xs font-mono text-slate-300 pt-2 border-t border-slate-800/80">
              <div className="flex justify-between">
                <span className="text-slate-400">Stake:</span>
                <span className="text-amber-300 font-semibold">{v.stakeAmountDsPow.toLocaleString()} DS-PoW</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Accuracy:</span>
                <span className="text-emerald-400 font-semibold">{(v.accuracyScore * 100).toFixed(2)}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Audited Proofs:</span>
                <span className="text-white">{v.verifiedProofsCount.toLocaleString()}</span>
              </div>
            </div>

            <p className="text-[10px] text-slate-400 font-mono pt-2 border-t border-slate-800">
              Audit Focus: {v.specialty}
            </p>
          </div>
        ))}
      </div>

      {/* Section 18: AI Work Verification Hierarchy */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="border-b border-slate-800 pb-3">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
            <Layers className="h-4 w-4 text-cyan-400" />
            Section 18: Four-Tier AI Work Verification Hierarchy
          </h3>
          <p className="text-xs text-slate-400">
            How non-deterministic or deep floating-point AI workloads are verified without full re-computation
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs font-mono">
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2">
            <span className="text-slate-500 block text-[10px]">TIER 1 (BASELINE)</span>
            <div className="font-bold text-slate-200">Continuous Telemetry Physics</div>
            <p className="text-[11px] text-slate-400 font-sans">
              High-frequency power, GPU utilization, and clock attestations proving physical execution occurred.
            </p>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2">
            <span className="text-slate-500 block text-[10px]">TIER 2 (CHECKPOINT)</span>
            <div className="font-bold text-cyan-300">Model Weight Checkpoint Hashes</div>
            <p className="text-[11px] text-slate-400 font-sans">
              Cryptographic commitment to intermediate and final model weights stored on decentralized storage.
            </p>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2">
            <span className="text-slate-500 block text-[10px]">TIER 3 (SPOT AUDIT)</span>
            <div className="font-bold text-amber-300">Deterministic Sub-Step Re-execution</div>
            <p className="text-[11px] text-slate-400 font-sans">
              Verifier samples random batch steps (e.g. step 41,200) and executes forward pass with bitwise tolerance.
            </p>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2">
            <span className="text-slate-500 block text-[10px]">TIER 4 (TRAJECTORY)</span>
            <div className="font-bold text-emerald-400">Loss Trajectory Convergence Audit</div>
            <p className="text-[11px] text-slate-400 font-sans">
              Statistical verification that loss trajectory followed realistic thermodynamic descent without fabrication.
            </p>
          </div>
        </div>
      </div>

      {/* Section 17: Redundant Computation & Discrepancy Engine */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
              <GitCompare className="h-4 w-4 text-purple-400" />
              Section 17: Redundant Computation &amp; Tolerance Comparison Engine
            </h3>
            <p className="text-xs text-slate-400">
              Dual-provider execution comparison for Institutional and Critical assurance workloads
            </p>
          </div>
          <button
            onClick={handleTestRedundancy}
            disabled={simulatingRedundancy}
            className="px-3 py-1.5 rounded-lg bg-purple-950 hover:bg-purple-900 border border-purple-500/40 text-purple-200 text-xs font-mono font-medium transition-colors"
          >
            {simulatingRedundancy ? 'Evaluating Diff...' : 'Run Dual-Provider Differential Test'}
          </button>
        </div>

        {redundancyResult ? (
          <div className="bg-slate-950 rounded-xl p-4 border border-slate-800 font-mono text-xs space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
              <span className="text-emerald-400 font-bold flex items-center gap-1.5">
                <CheckCircle2 className="h-4 w-4" />
                Differential Verification Succeeded (Passes ε &lt; 10⁻⁷ Standard)
              </span>
              <span className="text-slate-400 text-[11px]">Divergence: ε = {redundancyResult.divergenceEpsilon}</span>
            </div>

            <div className="space-y-2 text-[11px]">
              <div>
                <span className="text-slate-500 block">Provider A (London-01 H200) Checkpoint Hash:</span>
                <span className="text-cyan-300 break-all">{redundancyResult.providerAOutput}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Provider B (Manchester-01 H100) Checkpoint Hash:</span>
                <span className="text-purple-300 break-all">{redundancyResult.providerBOutput}</span>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
              <span>Bit Error Rate: 0.000%</span>
              <span className="text-emerald-400 font-bold">Both Providers Certified &amp; Rewarded</span>
            </div>
          </div>
        ) : (
          <div className="bg-slate-950 rounded-xl p-6 border border-slate-800 text-center font-mono text-xs text-slate-400">
            Click &quot;Run Dual-Provider Differential Test&quot; to simulate independent parallel execution across two
            data centres and measure numerical convergence.
          </div>
        )}
      </div>
    </div>
  );
};
