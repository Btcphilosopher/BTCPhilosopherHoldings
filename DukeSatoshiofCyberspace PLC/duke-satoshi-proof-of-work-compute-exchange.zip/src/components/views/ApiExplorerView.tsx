/**
 * Enterprise API & Machine Interfaces Explorer
 * Duke Satoshi Proof-of-Work Compute Exchange
 */

import React, { useState } from 'react';
import { Terminal, Play, CheckCircle2, Copy, Code, Layers } from 'lucide-react';
import { useComputeExchange } from '../../context/ComputeExchangeContext';

export const ApiExplorerView: React.FC = () => {
  const { proofChain, credits, dataCentres, orders, ledger, verifyChainIntegrity } = useComputeExchange();

  const [selectedEndpoint, setSelectedEndpoint] = useState('GET /api/v1/proofs/{id}');
  const [responseOutput, setResponseOutput] = useState<string>(
    JSON.stringify(proofChain[proofChain.length - 1], null, 2)
  );

  const endpoints = [
    {
      method: 'GET',
      path: '/api/v1/chain/audit',
      desc: 'Verify proof-of-work chain integrity from Genesis to tip',
      action: () => {
        const audit = verifyChainIntegrity();
        setResponseOutput(JSON.stringify(audit, null, 2));
      },
    },
    {
      method: 'GET',
      path: '/api/v1/proofs/{id}',
      desc: 'Retrieve full canonical proof record and verifier multi-sig',
      action: () => {
        setResponseOutput(JSON.stringify(proofChain[proofChain.length - 1], null, 2));
      },
    },
    {
      method: 'GET',
      path: '/api/v1/credits/{id}/provenance',
      desc: 'Extract full 5-tier cryptographic provenance chain for credit',
      action: () => {
        const target = credits[0];
        setResponseOutput(
          JSON.stringify(
            {
              creditId: target.creditId,
              provenance: target.provenance,
              status: target.status,
              proofRange: target.proofRange,
            },
            null,
            2
          )
        );
      },
    },
    {
      method: 'GET',
      path: '/api/v1/market/orderbook',
      desc: 'Fetch Level 2 order book snapshot with cumulative depth',
      action: () => {
        setResponseOutput(
          JSON.stringify(
            {
              pair: 'DS-H200/USD',
              timestamp: new Date().toISOString(),
              bids: orders.filter(o => o.side === 'BID'),
              asks: orders.filter(o => o.side === 'ASK'),
            },
            null,
            2
          )
        );
      },
    },
    {
      method: 'GET',
      path: '/api/v1/datacentres/{id}/status',
      desc: 'Query live facility telemetry, PUE, and grid allocation',
      action: () => {
        setResponseOutput(JSON.stringify(dataCentres[0], null, 2));
      },
    },
    {
      method: 'GET',
      path: '/api/v1/ledger/journal',
      desc: 'Inspect double-entry journal transactions with debit/credit balance',
      action: () => {
        setResponseOutput(JSON.stringify(ledger.slice(-3), null, 2));
      },
    },
  ];

  return (
    <div className="space-y-6">
      {/* Doctrine Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">
            <Terminal className="h-4 w-4" />
            <span>Section 36: Enterprise API &amp; Machine Interfaces</span>
          </div>
          <h2 className="text-lg font-bold text-white mt-1">DSCX Machine-to-Machine Integration Suite</h2>
          <p className="text-xs text-slate-400">
            Open OpenAPI 3.1 compatible REST &amp; gRPC endpoints for programmatic job dispatch, proof retrieval,
            verifier attestation, and liquidity market making.
          </p>
        </div>
        <div className="bg-slate-950 px-3 py-2 rounded-lg border border-slate-800 font-mono text-xs text-emerald-400">
          TLS 1.3 • mTLS Enterprise Auth Active
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Endpoints Selector */}
        <div className="space-y-2 font-mono text-xs">
          <span className="text-slate-400 block text-[10px] uppercase font-bold">Standard Machine Endpoints</span>
          {endpoints.map(ep => {
            const key = `${ep.method} ${ep.path}`;
            const isSelected = selectedEndpoint === key;
            return (
              <div
                key={key}
                onClick={() => {
                  setSelectedEndpoint(key);
                  ep.action();
                }}
                className={`p-3 rounded-xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-slate-900 border-cyan-500/60 ring-1 ring-cyan-500/30'
                    : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                      ep.method === 'GET'
                        ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                        : 'bg-amber-950 text-amber-300 border border-amber-800'
                    }`}
                  >
                    {ep.method}
                  </span>
                  <span className="font-bold text-slate-200 truncate">{ep.path}</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1 font-sans">{ep.desc}</p>
              </div>
            );
          })}
        </div>

        {/* Live Interactive API Response Terminal */}
        <div className="lg:col-span-2 bg-slate-950 border border-slate-800 rounded-xl p-5 space-y-3 font-mono text-xs shadow-2xl flex flex-col justify-between">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <span className="h-3 w-3 rounded-full bg-red-500/80" />
              <span className="h-3 w-3 rounded-full bg-amber-500/80" />
              <span className="h-3 w-3 rounded-full bg-emerald-500/80" />
              <span className="text-slate-400 text-xs ml-2">{selectedEndpoint}</span>
            </div>
            <span className="text-[11px] text-emerald-400 font-bold">HTTP 200 OK</span>
          </div>

          <div className="overflow-x-auto max-h-[500px] text-cyan-300 text-[11px] py-2">
            <pre>{responseOutput}</pre>
          </div>

          <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
            <span>Latency: 14ms • Content-Type: application/json</span>
            <button
              onClick={() => navigator.clipboard.writeText(responseOutput)}
              className="px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 transition-colors flex items-center gap-1"
            >
              <Copy className="h-3 w-3" />
              <span>Copy Response</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
