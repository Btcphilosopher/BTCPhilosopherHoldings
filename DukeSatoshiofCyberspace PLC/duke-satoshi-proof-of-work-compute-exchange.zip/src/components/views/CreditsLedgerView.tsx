/**
 * Credits, Taxonomy & Double-Entry Ledger View
 * Duke Satoshi Proof-of-Work Compute Exchange
 */

import React, { useState } from 'react';
import {
  Layers,
  FileText,
  ShieldCheck,
  Zap,
  ArrowUpRight,
  Lock,
  RotateCcw,
  CheckCircle2,
  TrendingUp,
  Cpu,
} from 'lucide-react';
import { useComputeExchange } from '../../context/ComputeExchangeContext';
import { Credit } from '../../types';

interface CreditsLedgerViewProps {
  onSelectCreditForProvenance: (credit: Credit) => void;
  onInspectProof: (proofId: string) => void;
}

export const CreditsLedgerView: React.FC<CreditsLedgerViewProps> = ({
  onSelectCreditForProvenance,
  onInspectProof,
}) => {
  const { credits, creditClasses, ledger } = useComputeExchange();

  const [activeSubTab, setActiveSubTab] = useState<'CREDITS' | 'TAXONOMY' | 'LEDGER'>('CREDITS');

  // Double-entry ledger audit calculation
  const totalDebits = ledger.reduce((acc, tx) => acc + tx.quantity, 0);
  const totalCredits = ledger.reduce((acc, tx) => acc + tx.quantity, 0);
  const isLedgerBalanced = totalDebits === totalCredits;

  return (
    <div className="space-y-6">
      {/* Doctrine Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-amber-400 uppercase tracking-wider">
            <Layers className="h-4 w-4" />
            <span>Section 13, 14 &amp; 15: Credit Taxonomy &amp; Double-Entry Ledger</span>
          </div>
          <h2 className="text-lg font-bold text-white mt-1">Proof-of-Production Accounting Framework</h2>
          <p className="text-xs text-slate-400">
            A credit is an auditable accounting representation of proven computational work. Every unit is strictly
            backed by a cryptographic proof, and all movements are tracked in an immutable double-entry journal.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-lg border border-slate-800 text-xs font-mono">
          <button
            onClick={() => setActiveSubTab('CREDITS')}
            className={`px-3 py-1.5 rounded-md transition-colors ${
              activeSubTab === 'CREDITS' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Credit Inventory ({credits.length})
          </button>
          <button
            onClick={() => setActiveSubTab('TAXONOMY')}
            className={`px-3 py-1.5 rounded-md transition-colors ${
              activeSubTab === 'TAXONOMY' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Taxonomy Classes
          </button>
          <button
            onClick={() => setActiveSubTab('LEDGER')}
            className={`px-3 py-1.5 rounded-md transition-colors ${
              activeSubTab === 'LEDGER' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Ledger Journal ({ledger.length})
          </button>
        </div>
      </div>

      {/* SUB-TAB 1: CREDITS INVENTORY */}
      {activeSubTab === 'CREDITS' && (
        <div className="space-y-4">
          <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                  Issued Proof-of-Work Compute Credits
                </h3>
                <p className="text-xs text-slate-400">
                  Click any credit to inspect its complete 5-tier cryptographic provenance tree
                </p>
              </div>
              <div className="text-xs font-mono text-slate-400">
                Total Tracked: <span className="text-amber-400 font-bold">{credits.length} Batches</span>
              </div>
            </div>

            <div className="divide-y divide-slate-800/80">
              {credits.map(credit => (
                <div
                  key={credit.creditId}
                  onClick={() => onSelectCreditForProvenance(credit)}
                  className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-800/40 px-3 rounded-lg cursor-pointer transition-colors text-xs"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-amber-300 text-sm">{credit.creditId}</span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-mono font-semibold ${
                          credit.status === 'CIRCULATING'
                            ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-500/40'
                            : 'bg-purple-950/60 text-purple-300 border border-purple-500/40'
                        }`}
                      >
                        {credit.status}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-950 text-cyan-300 border border-slate-800">
                        {credit.classId}
                      </span>
                    </div>
                    <div className="text-slate-400 font-mono text-[11px]">
                      Owner: <span className="text-slate-200">{credit.ownerName}</span> • Issued by{' '}
                      <span className="text-slate-300">{credit.issuerCentreId}</span> • Proof Range:{' '}
                      <span className="text-cyan-400">{credit.proofRange}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 text-right font-mono">
                    <div>
                      <div className="text-white font-bold text-sm">
                        {credit.quantityGpuHours.toLocaleString()} GPU-Hrs
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {new Date(credit.issueDate).toLocaleDateString()}
                      </div>
                    </div>
                    <button
                      onClick={e => {
                        e.stopPropagation();
                        onSelectCreditForProvenance(credit);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors"
                    >
                      Inspect Provenance
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 2: TAXONOMY CLASSES */}
      {activeSubTab === 'TAXONOMY' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {creditClasses.map(cls => (
            <div key={cls.classId} className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <span className="font-mono text-xs font-bold text-amber-400">{cls.classId}</span>
                  <h3 className="text-base font-bold text-white mt-0.5">{cls.name}</h3>
                  <p className="text-xs text-slate-400 font-mono mt-1">{cls.accelerator}</p>
                </div>
                <div className="text-right font-mono">
                  <span className="text-xs text-slate-400 block">Baseline Weight</span>
                  <span className="text-sm font-bold text-emerald-400">{cls.baselinePerformanceWeight}x H100</span>
                </div>
              </div>

              <div className="space-y-1.5 text-xs font-mono text-slate-300 bg-slate-950 p-3 rounded-lg border border-slate-800">
                <div className="flex justify-between">
                  <span className="text-slate-500">Memory Bandwidth:</span>
                  <span className="text-slate-200">{cls.memoryBandwidthGbps.toLocaleString()} GB/s</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Interconnect Fabric:</span>
                  <span className="text-cyan-400">{cls.interconnectType}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Spot Market Ref:</span>
                  <span className="text-amber-300 font-bold">${cls.spotPriceUsd.toFixed(2)} / hr</span>
                </div>
              </div>

              <p className="text-[11px] text-slate-400 leading-relaxed">{cls.description}</p>
            </div>
          ))}
        </div>
      )}

      {/* SUB-TAB 3: DOUBLE-ENTRY IMMUTABLE LEDGER */}
      {activeSubTab === 'LEDGER' && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                  Double-Entry Production Accounting Journal
                </h3>
                {isLedgerBalanced && (
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-950/60 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                    <CheckCircle2 className="h-3 w-3 text-emerald-400" />
                    DEBITS = CREDITS BALANCED
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400">
                Every credit issuance, transfer, OTC swap, and capacity retirement is recorded with matched debits and
                credits.
              </p>
            </div>
            <div className="text-xs font-mono text-slate-400">
              Total Volume: <span className="text-amber-400 font-bold">{totalDebits.toLocaleString()} GPU-Hrs</span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-500 text-[10px] uppercase">
                  <th className="py-2.5 px-3">TX ID &amp; Seq</th>
                  <th className="py-2.5 px-3">Type</th>
                  <th className="py-2.5 px-3">Quantity</th>
                  <th className="py-2.5 px-3">Debit Account</th>
                  <th className="py-2.5 px-3">Credit Account</th>
                  <th className="py-2.5 px-3">Proof / Contract Ref</th>
                  <th className="py-2.5 px-3">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300 text-[11px]">
                {ledger.map(tx => (
                  <tr key={tx.txId} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-3">
                      <div className="font-bold text-slate-200">{tx.txId}</div>
                      <div className="text-[10px] text-slate-500">#{tx.sequence}</div>
                    </td>
                    <td className="py-3 px-3">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${
                          tx.type === 'ISSUE'
                            ? 'bg-amber-950 text-amber-300 border border-amber-800'
                            : tx.type === 'TRANSFER'
                            ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                            : tx.type === 'SWAP'
                            ? 'bg-indigo-950 text-indigo-300 border border-indigo-800'
                            : 'bg-purple-950 text-purple-300 border border-purple-800'
                        }`}
                      >
                        {tx.type}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-bold text-white">
                      {tx.quantity.toLocaleString()} <span className="text-[10px] text-slate-400">{tx.creditClass}</span>
                    </td>
                    <td className="py-3 px-3 text-red-300 font-mono text-[10px]">{tx.debitAccount}</td>
                    <td className="py-3 px-3 text-emerald-300 font-mono text-[10px]">{tx.creditAccount}</td>
                    <td className="py-3 px-3 text-cyan-300 text-[10px] truncate max-w-[140px]">{tx.proofRef}</td>
                    <td className="py-3 px-3 text-slate-400 text-[10px]">
                      {new Date(tx.timestamp).toLocaleTimeString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
