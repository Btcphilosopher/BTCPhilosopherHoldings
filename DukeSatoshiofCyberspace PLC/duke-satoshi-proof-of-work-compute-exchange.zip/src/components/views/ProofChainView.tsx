/**
 * Proof Engine & Immutable Proof Chain Explorer
 * Duke Satoshi Proof-of-Work Compute Exchange
 */

import React, { useState } from 'react';
import {
  ShieldCheck,
  Search,
  Filter,
  CheckCircle2,
  AlertOctagon,
  ArrowRight,
  Layers,
  Cpu,
  Clock,
  Zap,
  Lock,
} from 'lucide-react';
import { useComputeExchange } from '../../context/ComputeExchangeContext';
import { WorkType } from '../../types';

interface ProofChainViewProps {
  onInspectProof: (proofId: string) => void;
}

export const ProofChainView: React.FC<ProofChainViewProps> = ({ onInspectProof }) => {
  const { proofChain, verifyChainIntegrity } = useComputeExchange();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('ALL');
  const [auditResult, setAuditResult] = useState<{
    isChainValid: boolean;
    brokenIndex?: number;
    error?: string;
  } | null>(null);

  const handleAudit = () => {
    const res = verifyChainIntegrity();
    setAuditResult(res);
    setTimeout(() => setAuditResult(null), 8000);
  };

  const filteredProofs = proofChain.filter(p => {
    const matchesSearch =
      p.proofId.includes(searchTerm) ||
      p.proofHash.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.providerId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.jobId.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'ALL' || p.workType === filterType;
    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-6">
      {/* Header & Chain Stats */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">
            <ShieldCheck className="h-4 w-4" />
            <span>Section 8 &amp; 33: Pluggable Proof Engine &amp; Chain Explorer</span>
          </div>
          <h2 className="text-lg font-bold text-white mt-1">Immutable Proof-of-Production Chain</h2>
          <p className="text-xs text-slate-400">
            Append-only, cryptographically linked execution ledger. Each proof seals telemetry, input commitments, and
            verifier signatures.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-slate-950 px-3 py-2 rounded-lg border border-slate-800 font-mono text-xs text-slate-300">
            Chain Height: <span className="text-cyan-400 font-bold">#{proofChain.length - 1}</span>
          </div>
          <button
            onClick={handleAudit}
            className="px-3.5 py-2 rounded-lg bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-500/40 text-cyan-300 text-xs font-mono font-semibold transition-colors flex items-center gap-1.5"
          >
            <ShieldCheck className="h-4 w-4" />
            <span>Audit All Chain Hashes</span>
          </button>
        </div>
      </div>

      {/* Audit Banner Feedback */}
      {auditResult && (
        <div
          className={`p-4 rounded-xl border text-xs font-mono flex items-center justify-between ${
            auditResult.isChainValid
              ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300'
              : 'bg-red-950/60 border-red-500/50 text-red-300'
          }`}
        >
          <div className="flex items-center gap-2">
            {auditResult.isChainValid ? (
              <CheckCircle2 className="h-5 w-5 text-emerald-400" />
            ) : (
              <AlertOctagon className="h-5 w-5 text-red-400" />
            )}
            <div>
              <div className="font-bold">
                {auditResult.isChainValid
                  ? 'Cryptographic Audit Passed: 100% Chain Integrity'
                  : 'Chain Tamper Detected!'}
              </div>
              <p className="text-[11px] text-slate-400">
                {auditResult.isChainValid
                  ? `Every proof from Genesis block #000000 to Tip #${proofChain[proofChain.length - 1]?.proofId} strictly adheres to previousProofHash linkage and canonical SHA-256 formulas.`
                  : auditResult.error}
              </p>
            </div>
          </div>
          <span className="text-[10px] text-slate-400">Zero Inconsistencies</span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="h-4 w-4 absolute left-3 top-3 text-slate-500" />
          <input
            type="text"
            placeholder="Search by Proof ID, Hash, Job ID, or Provider..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-9 pr-4 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 font-mono"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-slate-500" />
          <select
            value={filterType}
            onChange={e => setFilterType(e.target.value)}
            className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 font-mono"
          >
            <option value="ALL">All Workload Classes</option>
            <option value="AI_TRAINING">AI_TRAINING</option>
            <option value="AI_INFERENCE">AI_INFERENCE</option>
            <option value="ENGINEERING_SIMULATION">ENGINEERING_SIMULATION</option>
            <option value="MONTE_CARLO">MONTE_CARLO</option>
            <option value="PHYSICS_SIMULATION">PHYSICS_SIMULATION</option>
          </select>
        </div>
      </div>

      {/* Proof Chain Chronological Explorer List */}
      <div className="space-y-3">
        {filteredProofs.slice().reverse().map((proof, idx) => {
          const isTip = idx === 0;
          return (
            <div
              key={proof.proofId}
              onClick={() => onInspectProof(proof.proofId)}
              className="bg-slate-900/90 border border-slate-800 hover:border-cyan-500/50 rounded-xl p-4 sm:p-5 transition-all cursor-pointer space-y-3 text-xs"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-sm font-bold text-white">PROOF #{proof.proofId}</span>
                  {isTip && (
                    <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-cyan-950/60 text-cyan-300 border border-cyan-500/40">
                      CHAIN TIP
                    </span>
                  )}
                  <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-emerald-950/60 text-emerald-300 border border-emerald-500/40">
                    {proof.status}
                  </span>
                  <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-purple-950/60 text-purple-300 border border-purple-500/40">
                    {proof.assuranceLevel}
                  </span>
                </div>
                <div className="flex items-center gap-3 font-mono text-[11px] text-slate-400">
                  <span>Seq #{proof.sequenceNumber}</span>
                  <span>{new Date(proof.executionEnd).toLocaleTimeString()}</span>
                </div>
              </div>

              {/* Hash Linkage Display */}
              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 font-mono text-[11px] space-y-1">
                <div className="flex items-center justify-between gap-2 text-slate-400">
                  <span className="text-slate-500 text-[10px] uppercase">Proof Hash:</span>
                  <span className="text-cyan-300 truncate max-w-xl">{proof.proofHash}</span>
                </div>
                <div className="flex items-center justify-between gap-2 text-slate-500 text-[10px]">
                  <span>Previous Hash:</span>
                  <span className="truncate max-w-xl text-slate-400">{proof.previousProofHash}</span>
                </div>
              </div>

              {/* Details & Output Metrics */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-[11px]">
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase">Work Type</span>
                  <span className="text-slate-200 font-semibold">{proof.workType}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase">Verified Compute</span>
                  <span className="text-white font-bold">{proof.computeConsumedGpuHours.toLocaleString()} GPU-Hrs</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase">Facility / Mint</span>
                  <span className="text-amber-400">{proof.providerId}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase">Consensus Multi-Sig</span>
                  <span className="text-emerald-400 font-semibold">{proof.verifiers.length} Independent Nodes</span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-800/60 text-[11px]">
                <span className="text-slate-500 font-mono">Job: {proof.jobId}</span>
                <span className="text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1">
                  <span>Inspect Full Cryptographic Payload</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
