/**
 * Digital Twin & Live Hardware Telemetry View
 * Duke Satoshi Proof-of-Work Compute Exchange
 */

import React, { useState } from 'react';
import { Cpu, Zap, Thermometer, Activity, Database, ShieldCheck, Server, RefreshCw } from 'lucide-react';
import { useComputeExchange } from '../../context/ComputeExchangeContext';

export const DigitalTwinView: React.FC = () => {
  const { liveGpuTelemetry } = useComputeExchange();

  const [selectedNode, setSelectedNode] = useState('NODE-R04-SRV02');

  const powerPercent = Math.min(100, (liveGpuTelemetry.gpuPowerWatts / 700) * 100);
  const memoryPercent = Math.min(100, (liveGpuTelemetry.gpuMemoryUsedGb / liveGpuTelemetry.gpuMemoryTotalGb) * 100);

  return (
    <div className="space-y-6">
      {/* Doctrine Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">
            <Cpu className="h-4 w-4" />
            <span>Section 34: Digital Twin &amp; Hardware Telemetry Attestation</span>
          </div>
          <h2 className="text-lg font-bold text-white mt-1">
            Physical-to-Digital Provenance: GPU #{liveGpuTelemetry.gpuId}
          </h2>
          <p className="text-xs text-slate-400">
            Real-time physical telemetry stream from London Crown Mint (Rack #04, Node #02, SXM5 Baseboard).
            Every computation is attested by hardware roots of trust before proof generation.
          </p>
        </div>

        <div className="bg-slate-950 px-3 py-2 rounded-lg border border-slate-800 font-mono text-xs text-emerald-400 flex items-center gap-2">
          <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>NVML Sub-Second Attestation Active</span>
        </div>
      </div>

      {/* 5-Stage Physical Hierarchy Flow */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-3">
        <h3 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">
          Physical Infrastructure Hierarchy
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 text-xs font-mono text-center">
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
            <span className="text-[10px] text-slate-500 uppercase block">1. Grid Substation</span>
            <div className="font-bold text-amber-300">National Grid 132kV</div>
            <span className="text-[10px] text-emerald-400">100% Offshore Wind</span>
          </div>
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
            <span className="text-[10px] text-slate-500 uppercase block">2. Facility PDU</span>
            <div className="font-bold text-white">Duke Satoshi London-01</div>
            <span className="text-[10px] text-cyan-300">PUE 1.12 Liquid Loop</span>
          </div>
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
            <span className="text-[10px] text-slate-500 uppercase block">3. Cluster Alpha</span>
            <div className="font-bold text-indigo-300">Cluster Lon-Alpha</div>
            <span className="text-[10px] text-slate-400">3.2 Tbps Quantum-2</span>
          </div>
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
            <span className="text-[10px] text-slate-500 uppercase block">4. Server Rack</span>
            <div className="font-bold text-purple-300">Rack #04 (64 GPUs)</div>
            <span className="text-[10px] text-slate-400">CoolIT Direct Liquid</span>
          </div>
          <div className="bg-slate-950 p-3 rounded-lg border border-cyan-500/50 space-y-1 ring-1 ring-cyan-500/30">
            <span className="text-[10px] text-cyan-400 uppercase block font-bold">5. Target Accelerator</span>
            <div className="font-bold text-cyan-300">{liveGpuTelemetry.gpuId}</div>
            <span className="text-[10px] text-emerald-400">Attestation Bound</span>
          </div>
        </div>
      </div>

      {/* Live Physical Gauges & Sensor Telemetry */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono">
        {/* GPU Utilization */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="uppercase font-bold">Tensor Core Load</span>
            <Activity className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-400">
            {liveGpuTelemetry.gpuUtilisationPercent.toFixed(1)}%
          </div>
          <div className="h-2 w-full bg-slate-950 rounded overflow-hidden">
            <div
              className="h-full bg-emerald-500 transition-all duration-300"
              style={{ width: `${liveGpuTelemetry.gpuUtilisationPercent}%` }}
            />
          </div>
          <span className="text-[10px] text-slate-500 block">Process: {liveGpuTelemetry.processId}</span>
        </div>

        {/* Power Draw */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="uppercase font-bold">Power Draw</span>
            <Zap className="h-4 w-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-amber-300">
            {liveGpuTelemetry.gpuPowerWatts} W
          </div>
          <div className="h-2 w-full bg-slate-950 rounded overflow-hidden">
            <div
              className="h-full bg-amber-500 transition-all duration-300"
              style={{ width: `${powerPercent}%` }}
            />
          </div>
          <span className="text-[10px] text-slate-500 block">SXM5 TDP Baseline: 700 W</span>
        </div>

        {/* Temperature */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="uppercase font-bold">Die Temperature</span>
            <Thermometer className="h-4 w-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold text-cyan-300">
            {liveGpuTelemetry.gpuTemperatureCelsius} °C
          </div>
          <div className="h-2 w-full bg-slate-950 rounded overflow-hidden">
            <div
              className="h-full bg-cyan-500 transition-all duration-300"
              style={{ width: `${(liveGpuTelemetry.gpuTemperatureCelsius / 90) * 100}%` }}
            />
          </div>
          <span className="text-[10px] text-slate-500 block">Cooling Delta: 18 °C In / 32 °C Out</span>
        </div>

        {/* Memory Allocation */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="uppercase font-bold">HBM3e Allocation</span>
            <Database className="h-4 w-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold text-purple-300">
            {liveGpuTelemetry.gpuMemoryUsedGb.toFixed(1)} / {liveGpuTelemetry.gpuMemoryTotalGb.toFixed(0)} GB
          </div>
          <div className="h-2 w-full bg-slate-950 rounded overflow-hidden">
            <div
              className="h-full bg-purple-500 transition-all duration-300"
              style={{ width: `${memoryPercent}%` }}
            />
          </div>
          <span className="text-[10px] text-slate-500 block">Bandwidth: 4.8 TB/s HBM3e</span>
        </div>
      </div>

      {/* Host Node & Cryptographic TPM Attestation Signature */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <ShieldCheck className="h-4 w-4 text-cyan-400" />
            Hardware Root-of-Trust Attestation Block
          </h3>
          <span className="text-[10px] text-emerald-400">Hardware Attested</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1.5 text-slate-300">
            <div>Hardware Model: <span className="text-white font-bold">{liveGpuTelemetry.gpuModel}</span></div>
            <div>Core Clock: <span className="text-cyan-300 font-bold">{liveGpuTelemetry.gpuClockMhz} MHz</span></div>
            <div>InfiniBand Fabric: <span className="text-emerald-400 font-bold">{liveGpuTelemetry.networkThroughputGbps} Gbps</span></div>
            <div>NVMe IOPS: <span className="text-slate-200 font-bold">{liveGpuTelemetry.storageIops.toLocaleString()} IOPS</span></div>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1.5 text-slate-300">
            <div>Active Workload Identity: <span className="text-amber-300 font-bold">{liveGpuTelemetry.workloadIdentity}</span></div>
            <div>Container ID: <span className="text-slate-400">{liveGpuTelemetry.containerId}</span></div>
            <div>Scheduler State: <span className="text-emerald-400 font-bold">{liveGpuTelemetry.schedulerState}</span></div>
            <div>
              Attestation Signature: <span className="text-cyan-300 break-all text-[11px]">{liveGpuTelemetry.attestationSignature}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
