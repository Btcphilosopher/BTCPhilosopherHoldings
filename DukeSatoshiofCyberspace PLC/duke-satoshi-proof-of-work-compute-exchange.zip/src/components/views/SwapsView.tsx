/**
 * Compute Swaps & Bilateral Conversion Engine View
 * Duke Satoshi Proof-of-Work Compute Exchange
 */

import React, { useState } from 'react';
import { RotateCcw, ArrowRight, ShieldCheck, CheckCircle2, Clock, Zap, Plus } from 'lucide-react';
import { useComputeExchange } from '../../context/ComputeExchangeContext';

export const SwapsView: React.FC = () => {
  const { swaps, executeSwap, createSwapProposal } = useComputeExchange();

  const [showNewSwapModal, setShowNewSwapModal] = useState(false);
  const [partyAName, setPartyAName] = useState('BAE Systems Digital Foundry');
  const [partyAClass, setPartyAClass] = useState('DS-H100');
  const [partyAQuantity, setPartyAQuantity] = useState(30000);
  const [partyBName, setPartyBName] = useState('Oxford Nanopore BioComputing');
  const [partyBClass, setPartyBClass] = useState('DS-H200');
  const [partyBQuantity, setPartyBQuantity] = useState(24000);
  const [ratio, setRatio] = useState(1.25);

  const handleCreateSwap = (e: React.FormEvent) => {
    e.preventDefault();
    createSwapProposal({
      partyA: {
        id: `CLI-${partyAName.slice(0, 4).toUpperCase()}`,
        name: partyAName,
        offeringClass: partyAClass,
        quantity: partyAQuantity,
      },
      partyB: {
        id: `CLI-${partyBName.slice(0, 4).toUpperCase()}`,
        name: partyBName,
        offeringClass: partyBClass,
        quantity: partyBQuantity,
      },
      conversionRatio: ratio,
      deliveryWindow: 'Prompt Bilateral Settlement Window',
      locationSla: 'Equinix LD4 Slough to MediaCityUK Interlink (<2.5ms latency)',
    });
    setShowNewSwapModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Doctrine Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-indigo-400 uppercase tracking-wider">
            <RotateCcw className="h-4 w-4" />
            <span>Section 20: Compute Swaps &amp; Cross-Cluster Conversion Mechanics</span>
          </div>
          <h2 className="text-lg font-bold text-white mt-1">Bilateral Compute Swap Engine</h2>
          <p className="text-xs text-slate-400">
            Enables enterprise parties to swap heterogeneous compute classes (e.g. H100 vs H200) across disparate data
            centres with published exchange ratios and synchronized delivery windows.
          </p>
        </div>

        <button
          onClick={() => setShowNewSwapModal(true)}
          className="px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-semibold flex items-center gap-1.5 transition-colors"
        >
          <Plus className="h-4 w-4" />
          <span>Propose Compute Swap</span>
        </button>
      </div>

      {/* Active Swap Contracts List */}
      <div className="space-y-4">
        {swaps.map(swap => (
          <div
            key={swap.swapId}
            className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4 text-xs font-mono"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <span className="font-bold text-amber-400 text-sm">{swap.swapId}</span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                    swap.status === 'SETTLED'
                      ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-500/40'
                      : 'bg-indigo-950/60 text-indigo-300 border border-indigo-500/40'
                  }`}
                >
                  {swap.status}
                </span>
                <span className="text-slate-400 text-[11px]">Ratio: {swap.conversionRatio.toFixed(2)}x</span>
              </div>
              <div className="text-slate-400 text-[11px]">
                {swap.status === 'SETTLED' ? (
                  <span className="text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    Settled at {new Date(swap.settledAt || '').toLocaleTimeString()}
                  </span>
                ) : (
                  <span>Created: {new Date(swap.createdAt).toLocaleTimeString()}</span>
                )}
              </div>
            </div>

            {/* Bilateral Parties Diagram */}
            <div className="grid grid-cols-1 md:grid-cols-5 gap-3 items-center">
              {/* Party A */}
              <div className="md:col-span-2 bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-500 uppercase block">Party A (Offering)</span>
                <div className="font-bold text-white text-sm">{swap.partyA.name}</div>
                <div className="text-amber-400 font-bold text-sm">
                  {swap.partyA.quantity.toLocaleString()} {swap.partyA.offeringClass} GPU-Hrs
                </div>
              </div>

              {/* Swap Flow Icon */}
              <div className="flex justify-center text-slate-500">
                <div className="h-10 w-10 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-cyan-400">
                  <RotateCcw className="h-5 w-5" />
                </div>
              </div>

              {/* Party B */}
              <div className="md:col-span-2 bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-500 uppercase block">Party B (Offering)</span>
                <div className="font-bold text-white text-sm">{swap.partyB.name}</div>
                <div className="text-cyan-300 font-bold text-sm">
                  {swap.partyB.quantity.toLocaleString()} {swap.partyB.offeringClass} GPU-Hrs
                </div>
              </div>
            </div>

            {/* SLA & Settlement Legs */}
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800/80 space-y-1 text-[11px] text-slate-400">
              <div>Delivery Window: <span className="text-slate-200">{swap.deliveryWindow}</span></div>
              <div>Location &amp; Latency SLA: <span className="text-slate-200">{swap.locationSla}</span></div>
              <div className="pt-1 border-t border-slate-850 flex flex-wrap justify-between gap-2 text-[10px]">
                <span>Leg 1: <strong className="text-indigo-300">{swap.settlementLegs.legAtoB}</strong></span>
                <span>Leg 2: <strong className="text-cyan-300">{swap.settlementLegs.legBtoA}</strong></span>
              </div>
            </div>

            {/* Action Bar */}
            {swap.status !== 'SETTLED' && (
              <div className="flex justify-end pt-2">
                <button
                  onClick={() => executeSwap(swap.swapId)}
                  className="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-colors flex items-center gap-1.5"
                >
                  <CheckCircle2 className="h-4 w-4" />
                  <span>Execute &amp; Settle Bilateral Swap Legs</span>
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* New Swap Proposal Modal */}
      {showNewSwapModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl max-w-xl w-full p-6 space-y-4 text-xs font-mono">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Create Bilateral Compute Swap Contract
            </h3>

            <form onSubmit={handleCreateSwap} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 text-[10px] uppercase mb-1">Party A Name</label>
                  <input
                    type="text"
                    value={partyAName}
                    onChange={e => setPartyAName(e.target.value)}
                    required
                    className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-200"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 text-[10px] uppercase mb-1">Party A Offering</label>
                  <select
                    value={partyAClass}
                    onChange={e => setPartyAClass(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-200"
                  >
                    <option value="DS-H100">DS-H100</option>
                    <option value="DS-H200">DS-H200</option>
                    <option value="DS-B200">DS-B200</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 text-[10px] uppercase mb-1">Party B Name</label>
                  <input
                    type="text"
                    value={partyBName}
                    onChange={e => setPartyBName(e.target.value)}
                    required
                    className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-200"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 text-[10px] uppercase mb-1">Party B Offering</label>
                  <select
                    value={partyBClass}
                    onChange={e => setPartyBClass(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-200"
                  >
                    <option value="DS-H200">DS-H200</option>
                    <option value="DS-H100">DS-H100</option>
                    <option value="DS-B200">DS-B200</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-400 text-[10px] uppercase mb-1">Party A Qty</label>
                  <input
                    type="number"
                    value={partyAQuantity}
                    onChange={e => setPartyAQuantity(parseInt(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-200"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 text-[10px] uppercase mb-1">Party B Qty</label>
                  <input
                    type="number"
                    value={partyBQuantity}
                    onChange={e => setPartyBQuantity(parseInt(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-200"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 text-[10px] uppercase mb-1">Conversion Ratio</label>
                  <input
                    type="number"
                    step="0.05"
                    value={ratio}
                    onChange={e => setRatio(parseFloat(e.target.value) || 1.0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-200"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewSwapModal(false)}
                  className="px-3 py-1.5 rounded bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3 py-1.5 rounded bg-amber-500 text-slate-950 font-bold"
                >
                  Create Proposal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
