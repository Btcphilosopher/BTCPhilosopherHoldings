/**
 * Duke Satoshi Proof-of-Work Compute Exchange (DS-PoW)
 * Enterprise Data Types & Schemas
 * Organisation: Duke Satoshi of Cyberspace PLC
 */

export type WorkType =
  | 'AI_TRAINING'
  | 'AI_INFERENCE'
  | 'SCIENTIFIC_COMPUTATION'
  | 'ENGINEERING_SIMULATION'
  | 'MONTE_CARLO'
  | 'VIDEO_RENDERING'
  | '3D_RENDERING'
  | 'PHYSICS_SIMULATION'
  | 'FINANCIAL_SIMULATION'
  | 'CRYPTOGRAPHIC_COMPUTATION'
  | 'DATA_PROCESSING'
  | 'MODEL_EVALUATION'
  | 'BENCHMARKING'
  | 'OPTIMIZATION'
  | 'MACHINE_LEARNING';

export interface WorkSpecification {
  workType: WorkType;
  modelIdentifier?: string;
  datasetCommitment?: string;
  precision?: 'FP64' | 'FP32' | 'TF32' | 'FP16' | 'BF16' | 'FP8' | 'INT8' | 'INT4';
  accelerator: 'H200' | 'H100' | 'B200' | 'GH200' | 'L40S';
  minimumWorkloadGpuHours: number;
  verificationMethod: string;
  deterministicTolerance: number; // e.g. 0.0001 for non-deterministic AI or 0 for math
  expectedTflops: number;
}

export type VerificationAssuranceLevel =
  | 'STANDARD'
  | 'ENHANCED'
  | 'INSTITUTIONAL'
  | 'CRITICAL';

export type WorkOrderStatus =
  | 'SUBMITTED'
  | 'SCHEDULED'
  | 'IN_EXECUTION'
  | 'MEASURED'
  | 'COMPLETED'
  | 'DISPUTED'
  | 'CANCELLED';

export interface WorkOrder {
  orderId: string;
  providerId: string;
  providerName: string;
  customerId: string;
  customerName: string;
  workType: WorkType;
  title: string;
  requiredComputeGpuHours: number;
  accelerator: string;
  expectedOutput: string;
  assuranceLevel: VerificationAssuranceLevel;
  deadline: string;
  createdAt: string;
  status: WorkOrderStatus;
  associatedJobIds: string[];
}

export interface ComputationalAttestation {
  timestamp: string;
  gpuId: string;
  gpuModel: string;
  gpuUtilisationPercent: number;
  gpuMemoryUsedGb: number;
  gpuMemoryTotalGb: number;
  gpuPowerWatts: number;
  gpuTemperatureCelsius: number;
  gpuClockMhz: number;
  cpuUtilisationPercent: number;
  ramUtilisationPercent: number;
  networkThroughputGbps: number;
  storageIops: number;
  schedulerState: 'RUNNING' | 'CHECKPOINTING' | 'VALIDATING' | 'IDLE';
  processId: string;
  containerId: string;
  workloadIdentity: string;
  attestationSignature: string;
}

export type JobStatus =
  | 'QUEUED'
  | 'RUNNING'
  | 'ATTESTED'
  | 'VERIFIED'
  | 'FAILED'
  | 'DISPUTED';

export interface ComputationalJob {
  jobId: string;
  workOrderId: string;
  providerId: string;
  clusterId: string;
  hardwareIds: string[];
  workType: WorkType;
  softwareEnvironment: {
    cudaVersion: string;
    driverVersion: string;
    osKernel: string;
    containerHash: string;
    framework: string;
  };
  datasetCommitment: string;
  modelCommitment: string;
  startTime: string;
  endTime?: string;
  durationSeconds: number;
  resourceConsumption: {
    gpuHoursConsumed: number;
    totalKwh: number;
    avgPowerWatts: number;
    avgGpuUtilPercent: number;
    peakMemoryGb: number;
  };
  outputCommitment: string;
  checkpointHashes: string[];
  verificationStatus: JobStatus;
  telemetryStream: ComputationalAttestation[];
  aiWorkMetrics?: {
    lossTrajectory: number[];
    tokensProcessedMillion: number;
    throughputTokensPerSec: number;
    validationPerplexity?: number;
  };
}

export type ProofStatus =
  | 'UNVERIFIED'
  | 'PENDING'
  | 'VERIFIED'
  | 'PARTIALLY_VERIFIED'
  | 'REJECTED'
  | 'DISPUTED'
  | 'REVOKED';

export interface VerifierAttestation {
  verifierId: string;
  verifierName: string;
  status: 'APPROVED' | 'REJECTED' | 'DISPUTED';
  confidenceScore: number; // 0.00 - 1.00
  method: string;
  signature: string;
  timestamp: string;
  auditNotes: string;
}

export interface ProofRecord {
  proofId: string;
  sequenceNumber: number;
  previousProofHash: string;
  proofHash: string;
  jobId: string;
  workOrderId: string;
  providerId: string;
  clusterId: string;
  hardwareSummary: string;
  workType: WorkType;
  algorithm: string;
  inputCommitment: string;
  outputCommitment: string;
  executionStart: string;
  executionEnd: string;
  computeConsumedGpuHours: number;
  energyConsumedMwh: number;
  pue: number;
  softwareHash: string;
  containerHash: string;
  checkpointHash: string;
  measurementRootHash: string;
  assuranceLevel: VerificationAssuranceLevel;
  verifiers: VerifierAttestation[];
  status: ProofStatus;
  qualityScore: number; // 0 - 100
  efficiencyScore: number; // useful compute / kWh
  creditsIssued: number;
  issuedCreditId?: string;
  signature: string;
  timestamp: string;
}

export interface VerifierEntity {
  id: string;
  name: string;
  organization: string;
  publicKey: string;
  assuranceTiers: VerificationAssuranceLevel[];
  consensusWeight: number;
  totalAuditedProofs: number;
  reputationScore: number;
  status: 'ACTIVE' | 'MAINTENANCE' | 'OFFLINE';
}

export interface CreditClass {
  id: string;
  code: string;
  name: string;
  accelerator: string;
  workTypeCategory: string;
  baselineGpuHours: number;
  marketPriceUsd: number;
  redemptionPriceUsd: number;
  replacementCostUsd: number;
  description: string;
}

export type CreditStatus =
  | 'CIRCULATING'
  | 'RESERVED'
  | 'RETIRED'
  | 'FROZEN';

export interface Credit {
  creditId: string;
  classId: string;
  quantityGpuHours: number;
  issuerCentreId: string;
  issueDate: string;
  proofRange: string;
  associatedProofIds: string[];
  ownerId: string;
  ownerName: string;
  status: CreditStatus;
  provenance: {
    dataCentre: string;
    cluster: string;
    hardware: string;
    workType: WorkType;
    jobId: string;
    workOrderId: string;
    proofId: string;
    assuranceLevel: VerificationAssuranceLevel;
    energyMwh: number;
    carbonOffsetKg: number;
  };
}

export type LedgerTransactionType =
  | 'ISSUE'
  | 'TRANSFER'
  | 'SWAP'
  | 'REDEEM'
  | 'RETIRE'
  | 'REVOKE'
  | 'ADJUST';

export interface DoubleEntryLedgerTransaction {
  txId: string;
  sequence: number;
  type: LedgerTransactionType;
  creditId: string;
  creditClass: string;
  quantity: number;
  debitAccount: string;
  creditAccount: string;
  proofRef: string;
  description: string;
  timestamp: string;
  signature: string;
}

export interface SwapContract {
  swapId: string;
  partyA: {
    id: string;
    name: string;
    offeringClass: string;
    quantity: number;
  };
  partyB: {
    id: string;
    name: string;
    offeringClass: string;
    quantity: number;
  };
  conversionRatio: number; // e.g., 1.25 DS-H100 per 1.00 DS-H200
  deliveryWindow: string;
  locationSla: string;
  cashAdjustmentUsd: number;
  status: 'PROPOSED' | 'MATCHED' | 'SETTLED' | 'CANCELLED';
  settlementLegs: {
    legAtoB: string; // Tx ID
    legBtoA: string; // Tx ID
  };
  createdAt: string;
  settledAt?: string;
}

export interface MarketOrder {
  orderId: string;
  pair: string;
  side: 'BID' | 'ASK';
  type: 'LIMIT' | 'MARKET';
  price: number;
  quantity: number;
  filled: number;
  traderId: string;
  traderName: string;
  timestamp: string;
  status: 'OPEN' | 'PARTIAL' | 'FILLED' | 'CANCELLED';
}

export interface TradeExecution {
  tradeId: string;
  pair: string;
  side: 'BUY' | 'SELL';
  price: number;
  quantity: number;
  buyer: string;
  seller: string;
  timestamp: string;
  settlementTxId: string;
}

export interface DataCentreMint {
  id: string;
  name: string;
  location: string;
  tier: string;
  totalGpuCapacity: number;
  activeGpuCapacity: number;
  acceleratorTypes: string[];
  powerSource: string;
  gridMwhAllocated: number;
  pue: number;
  renewablePercentage: number;
  usefulWorkPerKwh: number;
  completedGpuHours: number;
  verifiedGpuHours: number;
  creditsIssued: number;
  creditsRedeemed: number;
  verificationGrade: string;
  clusters: {
    clusterId: string;
    name: string;
    racksCount: number;
    gpusPerRack: number;
    interconnect: string;
    status: 'ONLINE' | 'MAINTENANCE';
  }[];
}

export interface ProductionCertificate {
  certificateId: string;
  centreId: string;
  centreName: string;
  periodStart: string;
  periodEnd: string;
  hardwareClass: string;
  verifiedGpuHours: number;
  energyMwh: number;
  pue: number;
  workloadDistribution: {
    workType: WorkType;
    percentage: number;
  }[];
  proofRange: string;
  creditsIssued: number;
  verificationGrade: string;
  independentVerifiers: string[];
  cryptographicSignature: string;
  certificateHash: string;
  issueDate: string;
}

export interface RedemptionRequest {
  redemptionId: string;
  customerId: string;
  customerName: string;
  creditId: string;
  creditClass: string;
  quantityToRedeem: number;
  targetDataCentreId: string;
  requestedStartDate: string;
  requestedWorkType: WorkType;
  workloadSpecification: string;
  status: 'REQUESTED' | 'RESERVED' | 'ALLOCATED' | 'COMPUTING' | 'DELIVERED' | 'RETIRED';
  capacityReservationToken?: string;
  retirementTxId?: string;
  createdAt: string;
}

export interface AntiFraudAlert {
  alertId: string;
  timestamp: string;
  type:
    | 'FABRICATED_JOB'
    | 'DUPLICATE_JOB'
    | 'REPLAYED_PROOF'
    | 'FAKE_TELEMETRY'
    | 'DOUBLE_ISSUANCE_ATTEMPT'
    | 'IMPOSSIBLE_POWER'
    | 'IMPOSSIBLE_UTILISATION'
    | 'CAPACITY_OVERSTATEMENT'
    | 'TIMESTAMP_MANIPULATION';
  severity: 'WARNING' | 'HIGH' | 'CRITICAL';
  entityId: string;
  details: string;
  evidence: Record<string, unknown>;
  status: 'DETECTED' | 'INVESTIGATING' | 'QUARANTINED' | 'RESOLVED';
}
