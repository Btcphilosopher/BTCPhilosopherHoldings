package com.example.vtolos.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.vtolos.core.model.PassengerAircraftState

/**
 * Developer & Dispatch REST / WebSocket Cockpit API Console.
 */
@Composable
fun DeveloperApiDeck(
    state: PassengerAircraftState,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(AeroGraphite)
            .border(1.dp, AeroBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
            .testTag("developer_api_deck")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "VTOL.OS OPENAPI & WEBSOCKET DEVELOPER INTERFACE",
                    color = HudWhite,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "vtol-os://api/v1/aircraft/${state.aircraftId}/stream · WebSocket Port 8080 Active",
                    color = HudCyan,
                    fontSize = 9.5.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Live JSON WebSocket Payload Stream
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(AeroBlack)
                    .border(1.dp, AeroBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "LIVE TELEMETRY JSON STREAM (WS 10Hz):",
                    color = HudMuted,
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = """
{
  "aircraftId": "${state.aircraftId}",
  "type": "${state.aircraftType.name}",
  "flightMode": "${state.flightMode.name}",
  "transitionState": "${state.transitionState.name}",
  "kinematics": {
    "lat": ${String.format("%.5f", state.latitude)},
    "lon": ${String.format("%.5f", state.longitude)},
    "altMslFt": ${String.format("%.1f", state.altitudeMslFt)},
    "altAglFt": ${String.format("%.1f", state.altitudeAglFt)},
    "iasKts": ${String.format("%.1f", state.airspeedIasKts)},
    "nacelleAngleDeg": ${String.format("%.1f", state.nacelleTiltAngleDeg)},
    "wingLiftRatio": ${String.format("%.2f", state.wingLiftRatio)}
  },
  "energy": {
    "socPercent": ${String.format("%.1f", state.battery.socPercent)},
    "powerKw": ${String.format("%.1f", state.totalPowerKw)},
    "enduranceMin": ${String.format("%.1f", state.battery.estimatedEnduranceMinutes)}
  },
  "passengerCabin": {
    "passengersBoarded": ${state.totalPassengersBoarded},
    "comfortG": ${String.format("%.2f", state.cabin.passengerComfortG)},
    "doors": "${state.cabin.doorsState.name}"
  }
}
                    """.trimIndent(),
                    color = HudCyan,
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Generated Code Snippets
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(AeroPanelBg)
                    .border(1.dp, AeroBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "CLIENT INTEGRATION EXAMPLES (KOTLIN / PYTHON / CURL):",
                    color = HudWhite,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = """
// 1. Kotlin Coroutine Stream Client:
val client = VtolOsClient("wss://api.vtolos.aero/v1/stream")
client.subscribeTelemetry("${state.aircraftId}").collect { state ->
    println("Nacelle: " + state.nacelleAngle + " | Wing Lift: " + state.wingLiftRatio)
}

# 2. cURL Command Dispatch:
curl -X POST https://api.vtolos.aero/v1/commands/arm \
  -H "Authorization: Bearer UK-UAM-SECRET-TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"aircraftId":"G-VTOL-01","authority":"GROUND_OPERATOR"}'
                    """.trimIndent(),
                    color = HudEmerald,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
