package com.example.vtolos.core.model

/**
 * British Anglo-Futuristic Vertiport & Skyway Network.
 */
object VertiportNetwork {

    val BATTERSEA = Vertiport(
        id = "VPORT-LON-01",
        icaoCode = "EGLW-V",
        name = "London Battersea Skyport",
        city = "London",
        latitude = 51.4695,
        longitude = -0.1705,
        elevationFt = 18f,
        padCount = 6,
        megawattChargersAvailable = 4,
        weatherMetar = "EGLW 251220Z 09008KT 9999 FEW025 18/11 Q1018 NOSIG"
    )

    val HEATHROW_T5 = Vertiport(
        id = "VPORT-LHR-05",
        icaoCode = "EGLL-V",
        name = "Heathrow T5 Vertipad Hub",
        city = "London / Heathrow",
        latitude = 51.4720,
        longitude = -0.4880,
        elevationFt = 83f,
        padCount = 12,
        megawattChargersAvailable = 10,
        weatherMetar = "EGLL 251220Z 10009KT CAVOK 19/10 Q1018 NOSIG"
    )

    val CANARY_WHARF = Vertiport(
        id = "VPORT-CNW-01",
        icaoCode = "EGCW-V",
        name = "Canary Wharf Skyport Spire",
        city = "London Docklands",
        latitude = 51.5048,
        longitude = -0.0195,
        elevationFt = 145f,
        padCount = 4,
        megawattChargersAvailable = 4,
        weatherMetar = "EGCW 251220Z 08006KT 9999 BKN030 18/12 Q1018 NOSIG"
    )

    val CAMBRIDGE_AERO = Vertiport(
        id = "VPORT-CBG-01",
        icaoCode = "EGSC-V",
        name = "Cambridge Tech Skyway Port",
        city = "Cambridge",
        latitude = 52.2050,
        longitude = 0.1750,
        elevationFt = 48f,
        padCount = 8,
        megawattChargersAvailable = 6,
        weatherMetar = "EGSC 251220Z 07007KT CAVOK 17/09 Q1018 NOSIG"
    )

    val FARNBOROUGH = Vertiport(
        id = "VPORT-FAB-01",
        icaoCode = "EGLF-V",
        name = "Farnborough Aerospace Vertigate",
        city = "Farnborough",
        latitude = 51.2750,
        longitude = -0.7760,
        elevationFt = 238f,
        padCount = 8,
        megawattChargersAvailable = 6,
        weatherMetar = "EGLF 251220Z 09010KT CAVOK 19/09 Q1018 NOSIG"
    )

    val ALL_VERTIPORTS = listOf(BATTERSEA, HEATHROW_T5, CANARY_WHARF, CAMBRIDGE_AERO, FARNBOROUGH)

    fun createStandardFlightPlan(
        origin: Vertiport = BATTERSEA,
        dest: Vertiport = HEATHROW_T5
    ): SkywayFlightPlan {
        val waypoints = listOf(
            RouteWaypoint(
                index = 0,
                name = "BATTERSEA-PAD-3",
                latitude = origin.latitude,
                longitude = origin.longitude,
                targetAltMslFt = 18f,
                targetSpeedKts = 0f,
                action = MissionAction.TAKEOFF
            ),
            RouteWaypoint(
                index = 1,
                name = "THAMES-CLIMB-GATE",
                latitude = 51.4780,
                longitude = -0.2200,
                targetAltMslFt = 800f,
                targetSpeedKts = 60f,
                action = MissionAction.TRANSITION
            ),
            RouteWaypoint(
                index = 2,
                name = "RICHMOND-SKY-GATE",
                latitude = 51.4620,
                longitude = -0.3000,
                targetAltMslFt = 1500f,
                targetSpeedKts = 135f,
                action = MissionAction.NAVIGATE
            ),
            RouteWaypoint(
                index = 3,
                name = "HOUNSLOW-DECEL-WAYPOINT",
                latitude = 51.4700,
                longitude = -0.4000,
                targetAltMslFt = 800f,
                targetSpeedKts = 75f,
                action = MissionAction.TRANSITION
            ),
            RouteWaypoint(
                index = 4,
                name = "HEATHROW-T5-FINAL",
                latitude = dest.latitude,
                longitude = dest.longitude,
                targetAltMslFt = 83f,
                targetSpeedKts = 0f,
                action = MissionAction.LAND
            )
        )

        return SkywayFlightPlan(
            flightPlanId = "UK-UAM-8842",
            flightNumber = "BA-SKY 402",
            passengerAircraftId = "G-VTOL-01",
            origin = origin,
            destination = dest,
            waypoints = waypoints,
            scheduledDeparture = "12:30 UTC",
            scheduledArrival = "12:41 UTC",
            cruisingAltitudeFt = 1500f,
            cruiseSpeedKts = 135f,
            passengerCount = 4,
            alternateVertiport = FARNBOROUGH
        )
    }
}
