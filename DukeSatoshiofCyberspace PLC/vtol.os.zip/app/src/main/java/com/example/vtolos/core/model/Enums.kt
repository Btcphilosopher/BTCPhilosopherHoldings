package com.example.vtolos.core.model

/**
 * Universal VTOL Aircraft Type Classifications.
 * Tailored for advanced urban passenger air mobility (eVTOL) and multi-mission architectures.
 */
enum class AircraftType(val displayName: String, val category: String) {
    TILTROTOR_PASSENGER("AeroSky 6-Pax Tiltrotor", "Urban Air Mobility (eVTOL)"),
    LIFT_PLUS_CRUISE_PAX("MetroGlide 4-Pax Lift+Cruise", "City Vertiport Transit"),
    TILTWING_EXPRESS("VectraWing 6-Pax Regional", "Intercity Skyways"),
    MULTIROTOR_SHUTTLE("CityCopter 2-Pax Aerotaxi", "Inner-City Micro-hop"),
    HYBRID_EXTENDED_RANGE("AngloAero SkyCruiser 8-Pax", "Regional Hybrid-Electric")
}

/**
 * Authoritative Strongly-Typed Flight Mode State Machine.
 */
enum class FlightMode(val label: String, val isAirborne: Boolean, val isEmergency: Boolean = false) {
    DISARMED("DISARMED", false),
    INITIALISING("PRE-CHECK", false),
    BOARDING("BOARDING", false),
    DOORS_LOCKED("CABIN SECURE", false),
    ARMED("SYSTEMS ARMED", false),
    GROUND_TAXI("VERTIPAD TAXI", false),
    TAKEOFF("VERTICAL CLIMB", true),
    HOVER("VERTIPAD HOVER", true),
    TRANSITION_TO_CRUISE("CONVERSION TO CRUISE", true),
    CRUISE("SKYWAY CRUISE", true),
    TRANSITION_TO_HOVER("CONVERSION TO HOVER", true),
    APPROACH("VERTIPAD GLIDEPATH", true),
    LANDING("VERTICAL DESCENT", true),
    TOUCHDOWN("TOUCHDOWN", false),
    DISEMBARKING("DISEMBARKING", false),
    EMERGENCY("EMERGENCY HOLD", true, true),
    RETURN_TO_HOME("RETURN TO BASE", true),
    LOST_LINK("AUTONOMOUS HOLD", true, true),
    FAILSAFE("FAILSAFE DIVERT", true, true),
    RECOVERY("AUTOPILOT RECOVERY", true),
    MAINTENANCE("MAINTENANCE", false),
    SIMULATION("SIMULATION", false)
}

/**
 * VTOL Conversion Corridor Transition State Machine.
 */
enum class TransitionState(val label: String, val nacelleAngleDeg: Float, val wingLiftRatio: Float) {
    HOVER_LIFT("HOVER LIFT (90°)", 90f, 0.0f),
    TRANSITION_ARMED("CORRIDOR ARMED (90°)", 90f, 0.05f),
    TRANSITION_INITIATED("TILT INITIATED (75°)", 75f, 0.20f),
    CONVERSION_CORRIDOR("WING LIFT TRANSFER (45°)", 45f, 0.55f),
    AIRSPEED_CONFIRMED("CRUISE VELOCITY (15°)", 15f, 0.85f),
    WING_BORNE_LOCKED("WING-BORNE CRUISE (0°)", 0f, 1.0f),
    CRUISE_FLIGHT("AERODYNAMIC CRUISE (0°)", 0f, 1.0f),
    REVERSE_INITIATED("DECELERATION TILT (35°)", 35f, 0.65f),
    HOVER_DECEL("APPROACH HOVER (75°)", 75f, 0.25f),
    HOVER_STABILIZED("VERTIPAD FINAL HOVER (90°)", 90f, 0.0f)
}

/**
 * Command Authority hierarchy.
 */
enum class CommandAuthority(val priority: Int, val description: String) {
    SAFETY_SYSTEM(100, "Autonomous Aircraft Safety Override"),
    REMOTE_PILOT(80, "Licensed Pilot-in-Command (PIC)"),
    GROUND_OPERATOR(70, "Skyway Dispatch Flight Operator"),
    AUTONOMOUS_ATC(60, "National Air Traffic Urban Corridor Control"),
    MISSION_MANAGER(50, "Autonomous Route Scheduler"),
    AUTONOMY_SYSTEM(40, "Onboard Flight Guidance & Avoidance"),
    SIMULATOR(10, "Digital Twin Simulation Engine")
}

/**
 * Subsystem Health status.
 */
enum class HealthStatus(val label: String, val severityLevel: Int) {
    NOMINAL("NOMINAL", 0),
    DEGRADED("DEGRADED", 1),
    WARNING("WARNING", 2),
    CRITICAL("CRITICAL", 3),
    FAILED("FAILED", 4),
    UNKNOWN("UNKNOWN", -1)
}

/**
 * Telemetry Source Provenance.
 */
enum class TelemetrySource {
    MEASURED,
    ESTIMATED,
    SIMULATED,
    COMMANDED,
    DERIVED,
    PREDICTED
}

/**
 * Autonomy operational modes.
 */
enum class AutonomyMode(val label: String) {
    MANUAL_FLY_BY_WIRE("Fly-By-Wire"),
    ASSISTED_CORRIDOR("Corridor Assist"),
    URBAN_AUTO_PILOT("UAM Autopilot"),
    SUPERVISED_DISPATCH("Dispatch Supervised"),
    FULL_AUTONOMOUS("Full Autonomous (Level 5)"),
    FAILSAFE_ACTIVE("Failsafe Divert")
}

/**
 * Passenger Seat Allocation & State.
 */
enum class PassengerSeatStatus {
    EMPTY,
    BOARDED_UNBUCKLED,
    SECURELY_BUCKLED,
    ASSISTANCE_REQUESTED
}

/**
 * Cabin Door & Environmental Locks.
 */
enum class DoorState {
    OPEN_BOARDING,
    CLOSING,
    LOCKED_AND_PRESSURIZED,
    EMERGENCY_RELEASE_ARMED
}

/**
 * Mission actions that can be assigned to waypoints.
 */
enum class MissionAction(val label: String) {
    NAVIGATE("Navigate"),
    HOLD("Hold Position"),
    ORBIT("Orbit Point"),
    SURVEY("Sensor Survey Grid"),
    PHOTO("High-Res Optical Capture"),
    VIDEO("IR/Optical Video Track"),
    DELIVER("Precision Cargo Release"),
    INSPECT("Proximity Inspection"),
    LOITER("Loiter on Station"),
    RETURN_HOME("Return to Launch/Base"),
    TAKEOFF("Vertical Takeoff"),
    LAND("Vertical Land"),
    WAIT("Timed Wait"),
    TRANSITION("Force Conversion Corridor")
}
