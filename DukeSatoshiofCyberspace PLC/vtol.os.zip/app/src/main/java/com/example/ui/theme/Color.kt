package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Anglo-Aerospace Cockpit Palette (BAE / UberAir Futuristic Supermodern)
val AeroBlack = Color(0xFF090D12)
val AeroGraphite = Color(0xFF0F151D)
val AeroPanelBg = Color(0xFF141C26)
val AeroCardSurface = Color(0xFF1B2430)
val AeroElevated = Color(0xFF222D3D)
val AeroBorder = Color(0xFF2C394B)
val AeroBorderBright = Color(0xFF3E5067)

// Avionics HUD & Telemetry Tints
val HudEmerald = Color(0xFF3FB950)
val HudEmeraldGlow = Color(0x333FB950)
val HudCyan = Color(0xFF58A6FF)
val HudCyanGlow = Color(0x3358A6FF)
val HudAmber = Color(0xFFD29922)
val HudCrimson = Color(0xFFF85149)
val HudWhite = Color(0xFFF0F6FC)
val HudMuted = Color(0xFF8B949E)
val HudSubtle = Color(0xFF5A6777)

// Horizon colors
val HorizonSky = Color(0xFF1A3352)
val HorizonGround = Color(0xFF2C2218)
val HorizonLine = Color(0xFF58A6FF)
