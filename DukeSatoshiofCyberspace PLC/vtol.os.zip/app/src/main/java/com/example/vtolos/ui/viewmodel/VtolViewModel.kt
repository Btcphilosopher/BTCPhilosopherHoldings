package com.example.vtolos.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.vtolos.core.engine.DigitalTwinEngine
import com.example.vtolos.core.model.*
import com.example.vtolos.data.db.AuditEventEntity
import com.example.vtolos.data.db.FlightRecordEntity
import com.example.vtolos.data.db.VtolDatabase
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

enum class CockpitTab(val title: String) {
    PFD_AND_TRANSITION("FLIGHT DECK"),
    TACTICAL_MAP("SKYWAY MAP"),
    PASSENGER_CABIN("PASSENGER CABIN"),
    ENERGY_SYSTEMS("ENERGY OS"),
    HEALTH_AND_SAFETY("SYSTEM HEALTH"),
    FAULT_INJECTION("FAILURE MATRIX"),
    BLACK_BOX_RECORDER("BLACK BOX"),
    FLEET_COMMAND("FLEET OS"),
    DEVELOPER_API("API CONSOLE")
}

class VtolViewModel(application: Application) : AndroidViewModel(application) {

    private val db = VtolDatabase.getDatabase(application)
    private val flightRecordDao = db.flightRecordDao()
    private val auditEventDao = db.auditEventDao()

    private val engine = DigitalTwinEngine(
        scope = viewModelScope,
        onRecordSnapshot = { state ->
            saveFlightSnapshot(state)
        },
        onAuditEvent = { event ->
            saveAuditEvent(event)
        }
    )

    val aircraftState: StateFlow<PassengerAircraftState> = engine.aircraftState
    val recentAuditEvents: StateFlow<List<AuditEventEntity>> = auditEventDao.getRecentEvents()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedTab = MutableStateFlow(CockpitTab.PFD_AND_TRANSITION)
    val selectedTab: StateFlow<CockpitTab> = _selectedTab.asStateFlow()

    private val _simulationSpeed = MutableStateFlow(1.0f)
    val simulationSpeed: StateFlow<Float> = _simulationSpeed.asStateFlow()

    fun selectTab(tab: CockpitTab) {
        _selectedTab.value = tab
    }

    fun setSimulationSpeed(speed: Float) {
        _simulationSpeed.value = speed
        engine.simulationSpeed = speed
    }

    // Quick Command Actions
    fun startBoarding() {
        engine.dispatchCommand(
            CommandDispatch(
                commandId = UUID.randomUUID().toString(),
                aircraftId = aircraftState.value.aircraftId,
                authority = CommandAuthority.GROUND_OPERATOR,
                actionName = "START_BOARDING"
            )
        )
    }

    fun closeDoorsAndSecure() {
        engine.dispatchCommand(
            CommandDispatch(
                commandId = UUID.randomUUID().toString(),
                aircraftId = aircraftState.value.aircraftId,
                authority = CommandAuthority.REMOTE_PILOT,
                actionName = "CLOSE_CABIN_DOORS"
            )
        )
    }

    fun armAndTakeoff() {
        engine.dispatchCommand(
            CommandDispatch(
                commandId = UUID.randomUUID().toString(),
                aircraftId = aircraftState.value.aircraftId,
                authority = CommandAuthority.AUTONOMOUS_ATC,
                actionName = "ARM_AND_TAKEOFF"
            )
        )
    }

    fun executeTransitionCruise() {
        engine.dispatchCommand(
            CommandDispatch(
                commandId = UUID.randomUUID().toString(),
                aircraftId = aircraftState.value.aircraftId,
                authority = CommandAuthority.AUTONOMY_SYSTEM,
                actionName = "EXECUTE_TRANSITION_CRUISE"
            )
        )
    }

    fun executeTransitionHover() {
        engine.dispatchCommand(
            CommandDispatch(
                commandId = UUID.randomUUID().toString(),
                aircraftId = aircraftState.value.aircraftId,
                authority = CommandAuthority.AUTONOMY_SYSTEM,
                actionName = "HOLD_VERTIPAD_APPROACH"
            )
        )
    }

    fun executeLanding() {
        engine.dispatchCommand(
            CommandDispatch(
                commandId = UUID.randomUUID().toString(),
                aircraftId = aircraftState.value.aircraftId,
                authority = CommandAuthority.SAFETY_SYSTEM,
                actionName = "LAND_VERTIPAD"
            )
        )
    }

    fun emergencyDivert() {
        engine.dispatchCommand(
            CommandDispatch(
                commandId = UUID.randomUUID().toString(),
                aircraftId = aircraftState.value.aircraftId,
                authority = CommandAuthority.SAFETY_SYSTEM,
                actionName = "EMERGENCY_DIVERT_NEAREST_VERTIPAD"
            )
        )
    }

    fun resetSimulation() {
        engine.dispatchCommand(
            CommandDispatch(
                commandId = UUID.randomUUID().toString(),
                aircraftId = aircraftState.value.aircraftId,
                authority = CommandAuthority.GROUND_OPERATOR,
                actionName = "RESET_SIMULATION"
            )
        )
    }

    // Cabin Comfort Commands
    fun setCabinLighting(mode: CabinLightingMode) {
        engine.dispatchCommand(
            CommandDispatch(
                commandId = UUID.randomUUID().toString(),
                aircraftId = aircraftState.value.aircraftId,
                authority = CommandAuthority.REMOTE_PILOT,
                actionName = "SET_CABIN_LIGHTING",
                parameters = mapOf("theme" to mode.name)
            )
        )
    }

    fun setCabinTemperature(tempC: Float) {
        engine.dispatchCommand(
            CommandDispatch(
                commandId = UUID.randomUUID().toString(),
                aircraftId = aircraftState.value.aircraftId,
                authority = CommandAuthority.REMOTE_PILOT,
                actionName = "SET_CABIN_TEMPERATURE",
                parameters = mapOf("temp" to tempC.toString())
            )
        )
    }

    fun toggleDoors() {
        if (aircraftState.value.cabin.doorsState == DoorState.LOCKED_AND_PRESSURIZED) {
            startBoarding()
        } else {
            closeDoorsAndSecure()
        }
    }

    // Fault Injections
    fun toggleMotorFault() {
        engine.faultMotorDegraded = !engine.faultMotorDegraded
    }

    fun toggleGnssFault() {
        engine.faultGnssDegraded = !engine.faultGnssDegraded
    }

    fun toggleMicroburst() {
        engine.faultMicroburstWind = !engine.faultMicroburstWind
    }

    fun toggleCommsFault() {
        engine.faultCommsDrop = !engine.faultCommsDrop
    }

    fun toggleLowBattery() {
        engine.faultLowBattery = !engine.faultLowBattery
        if (engine.faultLowBattery) {
            emergencyDivert()
        }
    }

    fun clearAllFaults() {
        engine.faultMotorDegraded = false
        engine.faultGnssDegraded = false
        engine.faultMicroburstWind = false
        engine.faultCommsDrop = false
        engine.faultLowBattery = false
    }

    // Signature Demonstration Scenarios
    fun runDemo1FullPassengerFlight() {
        clearAllFaults()
        resetSimulation()
        viewModelScope.launch {
            startBoarding()
            kotlinx.coroutines.delay(1200)
            closeDoorsAndSecure()
            kotlinx.coroutines.delay(1200)
            armAndTakeoff()
        }
    }

    fun runDemo2MotorDegradation() {
        clearAllFaults()
        engine.faultMotorDegraded = true
        _selectedTab.value = CockpitTab.PFD_AND_TRANSITION
    }

    fun runDemo3UrbanMicroburst() {
        clearAllFaults()
        engine.faultMicroburstWind = true
        _selectedTab.value = CockpitTab.PASSENGER_CABIN
    }

    fun runDemo4EmergencyDivert() {
        clearAllFaults()
        engine.faultLowBattery = true
        emergencyDivert()
        _selectedTab.value = CockpitTab.TACTICAL_MAP
    }

    private fun saveFlightSnapshot(state: PassengerAircraftState) {
        viewModelScope.launch {
            try {
                val entity = FlightRecordEntity(
                    timestampMs = state.timestampMs,
                    aircraftId = state.aircraftId,
                    flightMode = state.flightMode.name,
                    transitionState = state.transitionState.name,
                    latitude = state.latitude,
                    longitude = state.longitude,
                    altitudeMslFt = state.altitudeMslFt,
                    altitudeAglFt = state.altitudeAglFt,
                    airspeedKts = state.airspeedIasKts,
                    groundSpeedKts = state.groundSpeedKts,
                    verticalSpeedFpm = state.verticalSpeedFpm,
                    pitchDeg = state.pitchDeg,
                    rollDeg = state.rollDeg,
                    headingDeg = state.headingDeg,
                    nacelleTiltDeg = state.nacelleTiltAngleDeg,
                    wingLiftRatio = state.wingLiftRatio,
                    totalPowerKw = state.totalPowerKw,
                    batterySocPercent = state.battery.socPercent,
                    passengerComfortG = state.cabin.passengerComfortG,
                    acousticNoiseDba = state.acousticNoiseDba,
                    totalPassengers = state.totalPassengersBoarded,
                    activeWaypoint = state.nextWaypointName
                )
                flightRecordDao.insertRecord(entity)
            } catch (e: Exception) {
                // Ignore DB transient write errors in preview
            }
        }
    }

    private fun saveAuditEvent(event: AuditEvent) {
        viewModelScope.launch {
            try {
                val entity = AuditEventEntity(
                    timestampMs = event.timestampMs,
                    category = event.eventCategory,
                    authority = event.sourceAuthority.name,
                    title = event.title,
                    detail = event.detail,
                    severity = event.severity.name
                )
                auditEventDao.insertEvent(entity)
            } catch (e: Exception) {
                // Ignore DB transient write errors
            }
        }
    }
}
