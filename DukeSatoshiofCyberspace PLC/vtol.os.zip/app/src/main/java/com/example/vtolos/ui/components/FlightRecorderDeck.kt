package com.example.vtolos.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.vtolos.data.db.AuditEventEntity
import com.example.vtolos.data.db.FlightRecordEntity
import java.text.SimpleDateFormat
import java.util.*

/**
 * Black Box Flight Data Recorder (FDR) & Time-Series Audit Log.
 */
@Composable
fun FlightRecorderDeck(
    events: List<AuditEventEntity>,
    records: List<FlightRecordEntity>,
    modifier: Modifier = Modifier
) {
    val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.UK)

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(AeroGraphite)
            .border(1.dp, AeroBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
            .testTag("flight_recorder_deck")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "FLIGHT DATA RECORDER (BLACK BOX) & AUDIT PROVENANCE",
                    color = HudWhite,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "High-Rate Telemetry Persistence · Event-Sourced Audit Provenance",
                    color = HudMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.SansSerif
                )
            }

            Text(
                text = "${events.size} EVENTS RECORDED",
                color = HudCyan,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Scrollable Event Stream List
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(4.dp))
                .background(AeroBlack)
                .border(1.dp, AeroBorder, RoundedCornerShape(4.dp))
                .padding(4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (events.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Black Box Recording Active · Awaiting flight events...",
                            color = HudMuted,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            } else {
                items(events) { event ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(3.dp))
                            .background(AeroCardSurface)
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = timeFormat.format(Date(event.timestampMs)),
                                    color = HudCyan,
                                    fontSize = 8.5.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "[${event.authority}] ${event.title}",
                                    color = HudWhite,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = event.detail,
                                color = HudMuted,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.SansSerif
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(AeroElevated)
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = event.category,
                                color = HudAmber,
                                fontSize = 7.5.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}
