package com.example.vtolos.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.vtolos.core.model.PassengerAircraftState

/**
 * Energy OS & Battery Telemetry Deck.
 * Monitors 800V distributed battery banks, rapid megawatt charging,
 * power consumption dynamics, and predictive flight range.
 */
@Composable
fun EnergyAndPowerDeck(
    state: PassengerAircraftState,
    modifier: Modifier = Modifier
) {
    val b = state.battery
    val isLowBattery = b.socPercent < 20f

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(AeroGraphite)
            .border(1.dp, AeroBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
            .testTag("energy_and_power_deck")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "ENERGY OS & BATTERY TELEMETRY",
                    color = HudWhite,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "800V High-Density Lithium-Silicon Architecture · 4-Pack Redundant Bank",
                    color = HudMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.SansSerif
                )
            }

            // SoC Readout Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(AeroCardSurface)
                    .border(1.dp, if (isLowBattery) HudCrimson else HudEmerald, RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = "SoC: ${String.format("%.1f%%", b.socPercent)}",
                    color = if (isLowBattery) HudCrimson else HudEmerald,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // SoC Progress Bar
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("STATE OF CHARGE (SoC)", color = HudMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                Text("${String.format("%.1f", b.energyRemainingKwh)} / ${b.totalCapacityKwh} kWh REMAINING", color = HudWhite, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
            Spacer(modifier = Modifier.height(3.dp))
            LinearProgressIndicator(
                progress = { (b.socPercent / 100.0f).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = if (isLowBattery) HudCrimson else HudEmerald,
                trackColor = AeroCardSurface
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 4 Key Energy Telemetry Boxes
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Box 1: Endurance & Range
            EnergyMetricCard(
                title = "EST. ENDURANCE",
                value = "${String.format("%.1f", b.estimatedEnduranceMinutes)} MIN",
                subtitle = "Range: ${String.format("%.0f", b.estimatedRangeKm)} km",
                accentColor = HudEmerald,
                modifier = Modifier.weight(1f)
            )

            // Box 2: Total Power Draw
            EnergyMetricCard(
                title = "POWER DRAW",
                value = "${String.format("%.0f", state.totalPowerKw)} kW",
                subtitle = if (state.wingLiftRatio > 0.8f) "Low-Drag Cruise" else "High-Power Lift",
                accentColor = HudCyan,
                modifier = Modifier.weight(1f)
            )

            // Box 3: Voltage & Current
            EnergyMetricCard(
                title = "PACK VOLTAGE",
                value = "${String.format("%.1f", b.totalVoltageV)} V",
                subtitle = "${String.format("%.0f", b.totalCurrentA)} A Draw",
                accentColor = HudWhite,
                modifier = Modifier.weight(1f)
            )

            // Box 4: Thermal & Health
            EnergyMetricCard(
                title = "PACK THERMAL",
                value = "${String.format("%.1f", b.maxTempC)}°C",
                subtitle = "SoH: ${String.format("%.1f%%", b.sohPercent)}",
                accentColor = if (b.maxTempC > 45f) HudCrimson else HudEmerald,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun EnergyMetricCard(
    title: String,
    value: String,
    subtitle: String,
    accentColor: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(AeroCardSurface)
            .border(1.dp, AeroBorder, RoundedCornerShape(4.dp))
            .padding(6.dp)
    ) {
        Text(text = title, color = HudMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, color = accentColor, fontSize = 11.5.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(1.dp))
        Text(text = subtitle, color = HudSubtle, fontSize = 8.sp, fontFamily = FontFamily.SansSerif)
    }
}
