package com.example.vtolos.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.vtolos.core.model.HealthStatus
import com.example.vtolos.core.model.PassengerAircraftState
import com.example.vtolos.core.model.RotorState
import kotlin.math.*

/**
 * Dedicated VTOL Conversion Corridor, Nacelle Kinematics & Propulsion Deck.
 * Visualizes the physical transition between Vertical Rotor Lift and Wing-Borne Cruise,
 * with Distributed Electric Propulsion (DEP) rotor cluster status and acoustic footprint.
 */
@Composable
fun VtolTransitionPanel(
    state: PassengerAircraftState,
    onExecuteTransitionCruise: () -> Unit,
    onExecuteTransitionHover: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(AeroGraphite)
            .border(1.dp, AeroBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
            .testTag("vtol_transition_panel")
    ) {
        // Section Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "VTOL TRANSITION & PROPULSION DECK",
                    color = HudWhite,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "AeroSky 8-Rotor Distributed Electric Tiltrotor (DEP)",
                    color = HudMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.SansSerif
                )
            }

            // Nacelle Angle Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(AeroCardSurface)
                    .border(1.dp, HudCyan, RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = "NACELLE: ${String.format("%.1f°", state.nacelleTiltAngleDeg)}",
                    color = HudCyan,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Center Graphic: Nacelle Tilt Kinematics & Conversion Envelope
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Left: Vector Nacelle Angle Graphic
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(6.dp))
                    .background(AeroBlack)
                    .border(1.dp, AeroBorder, RoundedCornerShape(6.dp))
                    .padding(4.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize().testTag("canvas_nacelle_tilt")) {
                    drawNacelleKinematics(state.nacelleTiltAngleDeg, state.wingLiftRatio)
                }

                // Overlay Status Text
                Text(
                    text = if (state.nacelleTiltAngleDeg > 80f) "VERTICAL HOVER (90°)"
                    else if (state.nacelleTiltAngleDeg < 10f) "WING-BORNE CRUISE (0°)"
                    else "CONVERSION CORRIDOR (${String.format("%.0f°", state.nacelleTiltAngleDeg)})",
                    color = if (state.nacelleTiltAngleDeg in 10f..80f) HudAmber else HudEmerald,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 4.dp)
                )
            }

            // Right: Lift Distribution & Acoustic Footprint
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(6.dp))
                    .background(AeroPanelBg)
                    .border(1.dp, AeroBorder, RoundedCornerShape(6.dp))
                    .padding(8.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Lift Distribution
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "LIFT SPLIT",
                            color = HudMuted,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Wing ${String.format("%.0f%%", state.wingLiftRatio * 100)} / Rotor ${String.format("%.0f%%", (1f - state.wingLiftRatio) * 100)}",
                            color = HudWhite,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    LinearProgressIndicator(
                        progress = { state.wingLiftRatio },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = HudCyan,
                        trackColor = HudAmber
                    )
                }

                // Acoustic Ground Noise
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "ACOUSTIC dBA",
                            color = HudMuted,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${String.format("%.1f", state.acousticNoiseDba)} / ${String.format("%.0f", state.noiseAbatementMaxDba)} dBA MAX",
                            color = if (state.acousticNoiseDba > state.noiseAbatementMaxDba) HudCrimson else HudEmerald,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    LinearProgressIndicator(
                        progress = { (state.acousticNoiseDba / 80.0f).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = if (state.acousticNoiseDba > state.noiseAbatementMaxDba) HudCrimson else HudEmerald,
                        trackColor = AeroElevated
                    )
                }

                // Total Thrust & Power
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("POWER", color = HudMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        Text("${String.format("%.0f", state.totalPowerKw)} kW", color = HudWhite, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("THRUST", color = HudMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        Text("${String.format("%.1f", state.totalThrustN / 1000f)} kN", color = HudWhite, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // DEP Rotor Cluster Grid (Rotors 1 to 8)
        Text(
            text = "DISTRIBUTED PROPULSION CLUSTER (ROTORS 1 - 8)",
            color = HudMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            state.rotors.take(8).forEach { rotor ->
                RotorItemCard(
                    rotor = rotor,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Transition Control Actions
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onExecuteTransitionCruise,
                modifier = Modifier.weight(1f).height(36.dp).testTag("button_transition_cruise"),
                colors = ButtonDefaults.buttonColors(containerColor = AeroElevated),
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, HudCyan)
            ) {
                Text(
                    text = "COMMAND CRUISE TRANSITION (0°)",
                    fontSize = 10.sp,
                    color = HudCyan,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = onExecuteTransitionHover,
                modifier = Modifier.weight(1f).height(36.dp).testTag("button_transition_hover"),
                colors = ButtonDefaults.buttonColors(containerColor = AeroElevated),
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, HudAmber)
            ) {
                Text(
                    text = "COMMAND HOVER TRANSITION (90°)",
                    fontSize = 10.sp,
                    color = HudAmber,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun RotorItemCard(rotor: RotorState, modifier: Modifier = Modifier) {
    val isWarning = rotor.health == HealthStatus.WARNING || rotor.health == HealthStatus.CRITICAL
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (isWarning) HudCrimson.copy(alpha = 0.2f) else AeroCardSurface)
            .border(1.dp, if (isWarning) HudCrimson else AeroBorder, RoundedCornerShape(4.dp))
            .padding(vertical = 4.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "#${rotor.id}",
            color = if (isWarning) HudCrimson else HudCyan,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "${rotor.rpm.toInt()}",
            color = HudWhite,
            fontSize = 8.sp,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = "${String.format("%.0f", rotor.motorTempC)}°C",
            color = if (rotor.motorTempC > 70f) HudCrimson else HudMuted,
            fontSize = 7.5.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}

private fun DrawScope.drawNacelleKinematics(tiltDeg: Float, wingLiftRatio: Float) {
    val cx = size.width / 2f
    val cy = size.height * 0.55f

    // Fixed Airframe Fuselage Silhouette
    drawLine(
        color = HudSubtle,
        start = Offset(cx - 45.dp.toPx(), cy + 12.dp.toPx()),
        end = Offset(cx + 45.dp.toPx(), cy + 12.dp.toPx()),
        strokeWidth = 4f
    )
    // Wing outline
    drawLine(
        color = HudCyan.copy(alpha = 0.6f),
        start = Offset(cx - 30.dp.toPx(), cy),
        end = Offset(cx + 30.dp.toPx(), cy),
        strokeWidth = 3f
    )

    // Swiveling Engine Nacelle (Rotates around Wingtip Pivot)
    val pivotX = cx - 18.dp.toPx()
    val pivotY = cy

    // Draw Pivot Joint
    drawCircle(
        color = HudWhite,
        radius = 3.dp.toPx(),
        center = Offset(pivotX, pivotY)
    )

    // Nacelle Body & Propeller Disk
    rotate(degrees = -(90f - tiltDeg), pivot = Offset(pivotX, pivotY)) {
        // Nacelle body
        drawLine(
            color = HudCyan,
            start = Offset(pivotX - 6.dp.toPx(), pivotY),
            end = Offset(pivotX + 26.dp.toPx(), pivotY),
            strokeWidth = 5f
        )
        // Propeller Disk Spin Line
        drawLine(
            color = HudEmerald,
            start = Offset(pivotX + 26.dp.toPx(), pivotY - 22.dp.toPx()),
            end = Offset(pivotX + 26.dp.toPx(), pivotY + 22.dp.toPx()),
            strokeWidth = 2.5f
        )
        // Thrust Arrow Vector
        drawLine(
            color = HudEmerald,
            start = Offset(pivotX + 26.dp.toPx(), pivotY),
            end = Offset(pivotX + 44.dp.toPx(), pivotY),
            strokeWidth = 2f
        )
    }

    // Conversion Arc Reference Line (90° vertical to 0° horizontal)
    val arcRadius = 32.dp.toPx()
    drawArc(
        color = HudAmber.copy(alpha = 0.4f),
        startAngle = 180f,
        sweepAngle = 90f,
        useCenter = false,
        topLeft = Offset(pivotX - arcRadius, pivotY - arcRadius),
        size = Size(arcRadius * 2f, arcRadius * 2f),
        style = Stroke(width = 1.5f)
    )
}
