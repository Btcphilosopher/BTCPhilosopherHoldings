package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = HudCyan,
    onPrimary = AeroBlack,
    primaryContainer = AeroElevated,
    onPrimaryContainer = HudCyan,
    secondary = HudEmerald,
    onSecondary = AeroBlack,
    secondaryContainer = AeroCardSurface,
    onSecondaryContainer = HudEmerald,
    tertiary = HudAmber,
    onTertiary = AeroBlack,
    background = AeroBlack,
    onBackground = HudWhite,
    surface = AeroGraphite,
    onSurface = HudWhite,
    surfaceVariant = AeroPanelBg,
    onSurfaceVariant = HudMuted,
    outline = AeroBorder,
    error = HudCrimson,
    onError = HudWhite
)

@Composable
fun VTOLOSTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
