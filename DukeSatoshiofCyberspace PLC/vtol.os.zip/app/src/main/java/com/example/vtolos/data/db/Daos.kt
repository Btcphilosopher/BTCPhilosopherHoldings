package com.example.vtolos.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface FlightRecordDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: FlightRecordEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecords(records: List<FlightRecordEntity>)

    @Query("SELECT * FROM flight_records WHERE aircraftId = :aircraftId ORDER BY timestampMs DESC LIMIT 500")
    fun getRecentRecords(aircraftId: String): Flow<List<FlightRecordEntity>>

    @Query("SELECT * FROM flight_records WHERE aircraftId = :aircraftId ORDER BY timestampMs ASC")
    suspend fun getAllRecordsForReplay(aircraftId: String): List<FlightRecordEntity>

    @Query("DELETE FROM flight_records")
    suspend fun clearAllRecords()
}

@Dao
interface AuditEventDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: AuditEventEntity): Long

    @Query("SELECT * FROM audit_events ORDER BY timestampMs DESC LIMIT 200")
    fun getRecentEvents(): Flow<List<AuditEventEntity>>

    @Query("DELETE FROM audit_events")
    suspend fun clearEvents()
}

@Dao
interface FlightPlanDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlan(plan: FlightPlanEntity)

    @Query("SELECT * FROM flight_plans ORDER BY departureTime ASC")
    fun getAllFlightPlans(): Flow<List<FlightPlanEntity>>
}
