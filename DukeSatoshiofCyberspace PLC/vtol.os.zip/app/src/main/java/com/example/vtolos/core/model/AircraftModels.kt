package com.example.vtolos.core.model

/**
 * Passenger Cabin Environmental State & Comfort Metrics.
 */
data class CabinEnvironment(
    val targetTempC: Float = 21.0f,
    val currentTempC: Float = 21.2f,
    val cabinAltitudeFt: Float = 1200f,
    val cabinPressurePsi: Float = 14.7f,
    val activeNoiseCancellationDbaReduction: Float = 18.5f,
    val internalNoiseDba: Float = 58.2f,
    val airQualityIndex: Int = 12, // Pristine HEPA
    val lightingTheme: CabinLightingMode = CabinLightingMode.DAY_CRUISE,
    val doorsState: DoorState = DoorState.LOCKED_AND_PRESSURIZED,
    val baggageBayLocked: Boolean = true,
    val passengerComfortG: Float = 1.01f, // Smooth ride G-load
    val comfortRating: String = "Ultra-Smooth (Executive Class)"
)

enum class CabinLightingMode(val displayName: String, val colorHex: String) {
    BOARDING_ILLUMINATED("Welcome Illumination", "#E6EDF3"),
    DAY_CRUISE("Skyway Ambient", "#58A6FF"),
    AMBIENT_SUNSET("Anglo Sunset Amber", "#D29922"),
    NIGHT_TRANQUIL("Tranquil Twilight Indigo", "#388BFD"),
    EMERGENCY_EXIT("Emergency Guidance", "#F85149")
}

data class PassengerSeat(
    val seatId: String, // "1A", "1B", "2A", "2B", "3A", "3B"
    val passengerName: String,
    val status: PassengerSeatStatus,
    val baggageWeightKg: Float,
    val destinationVertiport: String
)

data class RotorState(
    val id: Int,
    val name: String,
    val rpm: Float,
    val commandedRpm: Float,
    val torquePercent: Float,
    val motorTempC: Float,
    val currentAmps: Float,
    val health: HealthStatus
)

data class BatteryBankState(
    val packCount: Int = 4,
    val totalVoltageV: Float = 812.4f,
    val totalCurrentA: Float = 184.2f,
    val socPercent: Float = 84.5f,
    val sohPercent: Float = 98.2f,
    val maxTempC: Float = 32.4f,
    val energyRemainingKwh: Float = 192.4f,
    val totalCapacityKwh: Float = 228.0f,
    val estimatedEnduranceMinutes: Float = 48.5f,
    val estimatedRangeKm: Float = 168.0f,
    val reserveMinutes: Float = 15.0f,
    val isFastCharging: Boolean = false,
    val chargeRateKw: Float = 0.0f
)

data class SensorRedundancyReport(
    val imuPrimaryHealthy: Boolean = true,
    val imuSecondaryHealthy: Boolean = true,
    val imuTertiaryHealthy: Boolean = true,
    val imuVotingAgreed: Boolean = true,
    val gnss1Healthy: Boolean = true,
    val gnss2Healthy: Boolean = true,
    val gnssSatellites: Int = 18,
    val gnssHdop: Float = 0.82f,
    val pitotPrimaryAirspeedKts: Float = 124.5f,
    val pitotSecondaryAirspeedKts: Float = 124.2f,
    val laserAltimeterAglFt: Float = 450f,
    val urbanCorridorLidarClear: Boolean = true
)

data class PassengerAircraftState(
    val aircraftId: String = "G-VTOL-01",
    val callsign: String = "AIR-MOBILITY 01",
    val aircraftName: String = "AeroSky Sovereign eVTOL",
    val aircraftType: AircraftType = AircraftType.TILTROTOR_PASSENGER,
    val timestampMs: Long = System.currentTimeMillis(),
    
    // Position & Kinematics
    val latitude: Double = 51.4690, // Near London Battersea Heliport
    val longitude: Double = -0.1700,
    val altitudeMslFt: Float = 1200f,
    val altitudeAglFt: Float = 1180f,
    val pitchDeg: Float = 2.4f,
    val rollDeg: Float = 0.0f,
    val headingDeg: Float = 278.0f,
    val trackDeg: Float = 278.5f,
    val yawDeg: Float = 278.0f,
    val rollRateDps: Float = 0.0f,
    val pitchRateDps: Float = 0.0f,
    val yawRateDps: Float = 0.0f,
    
    // Velocities & Wind
    val airspeedIasKts: Float = 122.0f,
    val airspeedTasKts: Float = 124.5f,
    val groundSpeedKts: Float = 128.0f,
    val verticalSpeedFpm: Float = 0.0f,
    val windSpeedKts: Float = 8.5f,
    val windDirectionDeg: Float = 095.0f,
    val windCrosswindKts: Float = 1.2f,
    
    // VTOL Mechanics & Aerodynamics
    val nacelleTiltAngleDeg: Float = 0.0f, // 0 = Forward Cruise, 90 = Vertical Hover
    val targetNacelleAngleDeg: Float = 0.0f,
    val wingLiftRatio: Float = 1.0f, // 0.0 = 100% Rotor Lift, 1.0 = 100% Wing-Borne
    val totalThrustN: Float = 14200f,
    val acousticNoiseDba: Float = 54.2f, // External ground footprint
    val noiseAbatementMaxDba: Float = 62.0f,
    
    // Propulsion & Energy
    val rotors: List<RotorState> = emptyList(),
    val battery: BatteryBankState = BatteryBankState(),
    val totalPowerKw: Float = 148.5f,
    
    // Subsystem Health & Redundancy
    val overallHealth: HealthStatus = HealthStatus.NOMINAL,
    val propulsionHealth: HealthStatus = HealthStatus.NOMINAL,
    val batteryHealth: HealthStatus = HealthStatus.NOMINAL,
    val navigationHealth: HealthStatus = HealthStatus.NOMINAL,
    val commsHealth: HealthStatus = HealthStatus.NOMINAL,
    val cabinHealth: HealthStatus = HealthStatus.NOMINAL,
    val sensorsReport: SensorRedundancyReport = SensorRedundancyReport(),
    
    // Connectivity & Comms
    val linkRssiDbm: Int = -58,
    val linkLatencyMs: Int = 18,
    val linkPacketLossPct: Float = 0.02f,
    val satelliteLinkActive: Boolean = true,
    val urban5gMeshActive: Boolean = true,
    val atcClearanceStatus: String = "CLEARED: SKYWAY CORRIDOR BRAVO-4",
    
    // Flight & Autonomy States
    val flightMode: FlightMode = FlightMode.CRUISE,
    val transitionState: TransitionState = TransitionState.WING_BORNE_LOCKED,
    val autonomyMode: AutonomyMode = AutonomyMode.URBAN_AUTO_PILOT,
    val commandAuthority: CommandAuthority = CommandAuthority.AUTONOMOUS_ATC,
    
    // Passenger Cabin
    val cabin: CabinEnvironment = CabinEnvironment(),
    val passengerSeats: List<PassengerSeat> = emptyList(),
    val totalPassengersBoarded: Int = 4,
    val totalBaggageWeightKg: Float = 58.0f,
    
    // Route & Navigation
    val departureVertiport: String = "London Battersea Skyport (EGLW)",
    val destinationVertiport: String = "Heathrow T5 Vertipad (EGLL-V)",
    val currentRouteName: String = "Corridor Alpha-10 Westbound",
    val distanceRemainingKm: Float = 14.8f,
    val distanceCoveredKm: Float = 7.4f,
    val flightTimeElapsedSec: Int = 240,
    val estimatedTimeToArrivalMin: Float = 4.2f,
    val nextWaypointName: String = "RICHMOND-SKY-GATE",
    val activeWaypointIndex: Int = 2,
    val totalWaypoints: Int = 5,
    
    // Active Alerts & Fault Injections
    val activeFaults: List<String> = emptyList(),
    val cautionMessages: List<String> = emptyList()
)

data class Vertiport(
    val id: String,
    val icaoCode: String,
    val name: String,
    val city: String,
    val latitude: Double,
    val longitude: Double,
    val elevationFt: Float,
    val padCount: Int,
    val megawattChargersAvailable: Int,
    val weatherMetar: String,
    val status: String = "OPEN - CAT III eVTOL"
)

data class RouteWaypoint(
    val index: Int,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val targetAltMslFt: Float,
    val targetSpeedKts: Float,
    val action: MissionAction,
    val acousticConstraintDba: Float = 60.0f
)

data class SkywayFlightPlan(
    val flightPlanId: String,
    val flightNumber: String,
    val passengerAircraftId: String,
    val origin: Vertiport,
    val destination: Vertiport,
    val waypoints: List<RouteWaypoint>,
    val scheduledDeparture: String,
    val scheduledArrival: String,
    val cruisingAltitudeFt: Float = 1500f,
    val cruiseSpeedKts: Float = 135f,
    val passengerCount: Int = 4,
    val alternateVertiport: Vertiport
)

data class AuditEvent(
    val id: Long = 0,
    val timestampMs: Long = System.currentTimeMillis(),
    val eventCategory: String,
    val sourceAuthority: CommandAuthority,
    val title: String,
    val detail: String,
    val severity: HealthStatus = HealthStatus.NOMINAL
)

data class CommandDispatch(
    val commandId: String,
    val aircraftId: String,
    val authority: CommandAuthority,
    val actionName: String,
    val parameters: Map<String, String> = emptyMap(),
    val timestampMs: Long = System.currentTimeMillis()
)

data class CommandResponse(
    val commandId: String,
    val accepted: Boolean,
    val statusText: String,
    val executionDetail: String,
    val timestampMs: Long = System.currentTimeMillis()
)
