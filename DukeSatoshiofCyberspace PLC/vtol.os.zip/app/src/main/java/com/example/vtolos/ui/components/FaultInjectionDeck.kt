package com.example.vtolos.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

/**
 * Interactive Aerospace Fault & Stress Injection Console.
 * Allows flight test engineers and operators to simulate real-time airborne failures
 * and evaluate VTOL.OS autonomous adaptation.
 */
@Composable
fun FaultInjectionDeck(
    isMotorFaultActive: Boolean,
    isGnssFaultActive: Boolean,
    isMicroburstActive: Boolean,
    isCommsFaultActive: Boolean,
    isLowBatteryActive: Boolean,
    onToggleMotorFault: () -> Unit,
    onToggleGnssFault: () -> Unit,
    onToggleMicroburst: () -> Unit,
    onToggleCommsFault: () -> Unit,
    onToggleLowBattery: () -> Unit,
    onClearAllFaults: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(AeroGraphite)
            .border(1.dp, AeroBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
            .testTag("fault_injection_deck")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "FAILURE INJECTION & CONTINGENCY MATRIX",
                    color = HudWhite,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Hardware-in-the-Loop & Flight-Critical Failure Testing",
                    color = HudMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.SansSerif
                )
            }

            // Reset Button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(AeroCardSurface)
                    .border(1.dp, HudEmerald, RoundedCornerShape(4.dp))
                    .clickable { onClearAllFaults() }
                    .padding(horizontal = 8.dp, vertical = 3.dp)
                    .testTag("button_clear_faults")
            ) {
                Text(
                    text = "RESET ALL TO NOMINAL",
                    color = HudEmerald,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Grid of 5 Fault Injections
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FaultToggleButton(
                    label = "DEP MOTOR #4 FAILURE",
                    desc = "Tests rotor torque compensation",
                    isActive = isMotorFaultActive,
                    onClick = onToggleMotorFault,
                    modifier = Modifier.weight(1f)
                )

                FaultToggleButton(
                    label = "URBAN WIND SHEAR (28KT)",
                    desc = "Tests passenger G-damping",
                    isActive = isMicroburstActive,
                    onClick = onToggleMicroburst,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FaultToggleButton(
                    label = "GNSS MULTIPATH JAMMING",
                    desc = "Tests triple-IMU voting failover",
                    isActive = isGnssFaultActive,
                    onClick = onToggleGnssFault,
                    modifier = Modifier.weight(1f)
                )

                FaultToggleButton(
                    label = "5G SKYWAY LINK LOSS",
                    desc = "Tests autonomous satellite hold",
                    isActive = isCommsFaultActive,
                    onClick = onToggleCommsFault,
                    modifier = Modifier.weight(1f)
                )
            }

            FaultToggleButton(
                label = "BATTERY RESERVE CRITICAL (<18% SOC)",
                desc = "Tests automatic priority divert to nearest vertipad (Farnborough EGLF-V)",
                isActive = isLowBatteryActive,
                onClick = onToggleLowBattery,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun FaultToggleButton(
    label: String,
    desc: String,
    isActive: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (isActive) HudCrimson.copy(alpha = 0.25f) else AeroCardSurface)
            .border(1.dp, if (isActive) HudCrimson else AeroBorder, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label,
                    color = if (isActive) HudCrimson else HudWhite,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = desc,
                    color = if (isActive) HudAmber else HudMuted,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.SansSerif
                )
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (isActive) HudCrimson else AeroElevated)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = if (isActive) "ACTIVE" else "INJECT",
                    color = if (isActive) HudWhite else HudMuted,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
