package com.example.vtolos.core.engine

import com.example.vtolos.core.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.*

/**
 * High-Fidelity Aerospace Digital Twin & Aerodynamic Simulation Engine.
 * Models passenger eVTOL flight physics, conversion corridor aerodynamics,
 * 8-rotor distributed electric propulsion, cabin acoustics, and urban corridor navigation.
 */
class DigitalTwinEngine(
    private val scope: CoroutineScope,
    private val onRecordSnapshot: (PassengerAircraftState) -> Unit = {},
    private val onAuditEvent: (AuditEvent) -> Unit = {}
) {
    private val _aircraftState = MutableStateFlow(createInitialState())
    val aircraftState: StateFlow<PassengerAircraftState> = _aircraftState.asStateFlow()

    private var activeFlightPlan: SkywayFlightPlan = VertiportNetwork.createStandardFlightPlan()
    private var simulationJob: Job? = null
    var simulationSpeed: Float = 1.0f

    // Fault flags
    var faultMotorDegraded: Boolean = false
    var faultGnssDegraded: Boolean = false
    var faultMicroburstWind: Boolean = false
    var faultCommsDrop: Boolean = false
    var faultLowBattery: Boolean = false

    init {
        startEngineLoop()
    }

    private fun createInitialState(): PassengerAircraftState {
        val initialRotors = (1..8).map { id ->
            RotorState(
                id = id,
                name = "DEP-Rotor #$id",
                rpm = 1850f,
                commandedRpm = 1850f,
                torquePercent = 52f,
                motorTempC = 38.5f + (id * 0.4f),
                currentAmps = 24.2f,
                health = HealthStatus.NOMINAL
            )
        }

        val initialSeats = listOf(
            PassengerSeat("1A", "Lord Sterling (Executive)", PassengerSeatStatus.SECURELY_BUCKLED, 14.5f, "Heathrow T5"),
            PassengerSeat("1B", "Dr. E. Harrison (AeroTech)", PassengerSeatStatus.SECURELY_BUCKLED, 12.0f, "Heathrow T5"),
            PassengerSeat("2A", "Sir Arthur Pendelton", PassengerSeatStatus.SECURELY_BUCKLED, 18.0f, "Heathrow T5"),
            PassengerSeat("2B", "Victoria Vance (Dispatch)", PassengerSeatStatus.SECURELY_BUCKLED, 13.5f, "Heathrow T5")
        )

        return PassengerAircraftState(
            aircraftId = "G-VTOL-01",
            callsign = "ANGLO-AERO 01",
            aircraftName = "AeroSky Sovereign eVTOL",
            aircraftType = AircraftType.TILTROTOR_PASSENGER,
            latitude = 51.4695,
            longitude = -0.1705,
            altitudeMslFt = 18f,
            altitudeAglFt = 0f,
            pitchDeg = 0.0f,
            rollDeg = 0.0f,
            headingDeg = 278.0f,
            trackDeg = 278.0f,
            airspeedIasKts = 0.0f,
            airspeedTasKts = 0.0f,
            groundSpeedKts = 0.0f,
            verticalSpeedFpm = 0.0f,
            nacelleTiltAngleDeg = 90.0f, // Pure vertical
            targetNacelleAngleDeg = 90.0f,
            wingLiftRatio = 0.0f,
            totalPowerKw = 28.0f, // Ground systems standby
            flightMode = FlightMode.BOARDING,
            transitionState = TransitionState.HOVER_LIFT,
            autonomyMode = AutonomyMode.SUPERVISED_DISPATCH,
            commandAuthority = CommandAuthority.GROUND_OPERATOR,
            rotors = initialRotors,
            passengerSeats = initialSeats,
            totalPassengersBoarded = 4,
            cabin = CabinEnvironment(
                doorsState = DoorState.OPEN_BOARDING,
                lightingTheme = CabinLightingMode.BOARDING_ILLUMINATED,
                internalNoiseDba = 42.0f
            ),
            departureVertiport = VertiportNetwork.BATTERSEA.name,
            destinationVertiport = VertiportNetwork.HEATHROW_T5.name,
            currentRouteName = "Corridor Alpha-10 Westbound",
            distanceRemainingKm = 24.5f,
            distanceCoveredKm = 0.0f,
            activeWaypointIndex = 0,
            totalWaypoints = 5,
            nextWaypointName = "BATTERSEA-PAD-3"
        )
    }

    private fun startEngineLoop() {
        simulationJob?.cancel()
        simulationJob = scope.launch(Dispatchers.Default) {
            var stepCount = 0
            while (isActive) {
                val dt = 0.1f * simulationSpeed // 100ms base step
                stepPhysics(dt)
                
                stepCount++
                if (stepCount % 10 == 0) {
                    onRecordSnapshot(_aircraftState.value)
                }
                delay(100L)
            }
        }
    }

    private fun stepPhysics(dt: Float) {
        val current = _aircraftState.value

        // 1. Slew nacelle tilt angle towards target
        val currentTilt = current.nacelleTiltAngleDeg
        val targetTilt = current.targetNacelleAngleDeg
        val tiltRate = 7.5f * dt // 7.5 deg/sec transition slew rate
        val newTilt = when {
            abs(targetTilt - currentTilt) <= tiltRate -> targetTilt
            targetTilt > currentTilt -> currentTilt + tiltRate
            else -> currentTilt - tiltRate
        }

        // 2. Wing lift ratio based on nacelle angle and airspeed
        val wingLiftRatio = ((90.0f - newTilt) / 90.0f).coerceIn(0.0f, 1.0f)

        // 3. Flight Mode dynamics & Trajectory navigation
        var newFlightMode = current.flightMode
        var newTransState = current.transitionState
        var newAltMsl = current.altitudeMslFt
        var newAltAgl = current.altitudeAglFt
        var newAirspeed = current.airspeedIasKts
        var newVerticalSpeed = current.verticalSpeedFpm
        var newPitch = current.pitchDeg
        var newRoll = current.rollDeg
        var newLat = current.latitude
        var newLon = current.longitude
        var newDistCovered = current.distanceCoveredKm
        var newDistRem = current.distanceRemainingKm
        var newWpIndex = current.activeWaypointIndex
        var newNextWp = current.nextWaypointName

        val currentWp = activeFlightPlan.waypoints.getOrNull(newWpIndex) ?: activeFlightPlan.waypoints.last()
        val targetLat = currentWp.latitude
        val targetLon = currentWp.longitude
        val targetAlt = currentWp.targetAltMslFt
        val targetSpeed = currentWp.targetSpeedKts

        when (current.flightMode) {
            FlightMode.BOARDING -> {
                newAirspeed = 0f
                newVerticalSpeed = 0f
                newAltMsl = 18f
                newAltAgl = 0f
            }
            FlightMode.DOORS_LOCKED -> {
                newAirspeed = 0f
                newVerticalSpeed = 0f
            }
            FlightMode.ARMED -> {
                newAirspeed = 0f
                newVerticalSpeed = 0f
            }
            FlightMode.TAKEOFF -> {
                newTransState = TransitionState.HOVER_LIFT
                newVerticalSpeed = 650.0f // Climb rate in fpm
                newAltMsl += (newVerticalSpeed / 60.0f) * dt
                newAltAgl = (newAltMsl - 18f).coerceAtLeast(0f)
                newAirspeed = (newAirspeed + 3.0f * dt).coerceAtMost(25.0f)
                newPitch = 1.5f

                if (newAltMsl >= 450.0f) {
                    newFlightMode = FlightMode.TRANSITION_TO_CRUISE
                    logAudit("TRANSITION_CORRIDOR", CommandAuthority.AUTONOMY_SYSTEM, "Nacelle Tilt Initiated", "Auto-transition from Vertical Hover to Wing-Borne Cruise.")
                }
            }
            FlightMode.HOVER -> {
                newTransState = TransitionState.HOVER_LIFT
                newVerticalSpeed = 0f
                newAirspeed = (newAirspeed - 5.0f * dt).coerceAtLeast(0f)
                newPitch = 0.5f
            }
            FlightMode.TRANSITION_TO_CRUISE -> {
                // Slew nacelles to 0 deg forward
                if (newTilt > 0f && current.targetNacelleAngleDeg != 0.0f) {
                    _aircraftState.value = current.copy(targetNacelleAngleDeg = 0.0f)
                }

                newTransState = when {
                    newTilt > 70f -> TransitionState.TRANSITION_INITIATED
                    newTilt > 30f -> TransitionState.CONVERSION_CORRIDOR
                    newTilt > 5f -> TransitionState.AIRSPEED_CONFIRMED
                    else -> TransitionState.WING_BORNE_LOCKED
                }

                newAirspeed = (newAirspeed + 12.0f * dt).coerceAtMost(135.0f)
                newVerticalSpeed = 400.0f
                newAltMsl = (newAltMsl + (newVerticalSpeed / 60.0f) * dt).coerceAtMost(1500.0f)
                newAltAgl = newAltMsl - 25f
                newPitch = (newTilt / 90.0f) * 4.0f

                if (newTilt <= 0.0f && newAirspeed >= 120.0f) {
                    newFlightMode = FlightMode.CRUISE
                    newTransState = TransitionState.CRUISE_FLIGHT
                    logAudit("FLIGHT_MODE", CommandAuthority.AUTONOMY_SYSTEM, "Wing-Borne Cruise Locked", "Aircraft 100% wing-borne. Rotors in low-drag cruise configuration.")
                }
            }
            FlightMode.CRUISE -> {
                newTransState = TransitionState.CRUISE_FLIGHT
                newAirspeed = 135.0f
                newVerticalSpeed = 0.0f
                newAltMsl = 1500.0f
                newAltAgl = 1420.0f
                newPitch = 2.2f
                newRoll = sin(System.currentTimeMillis() / 4000.0).toFloat() * 1.5f

                // Navigate towards destination
                val dLat = targetLat - newLat
                val dLon = targetLon - newLon
                val distToWp = sqrt(dLat * dLat + dLon * dLon) * 111.0f // km
                
                if (distToWp < 0.8f && newWpIndex < activeFlightPlan.waypoints.size - 1) {
                    newWpIndex++
                    newNextWp = activeFlightPlan.waypoints[newWpIndex].name
                    logAudit("WAYPOINT", CommandAuthority.MISSION_MANAGER, "Waypoint Reached", "Arrived at $newNextWp. Proceeding on Skyway Corridor Alpha-10.")
                    
                    if (newWpIndex >= 3) {
                        newFlightMode = FlightMode.TRANSITION_TO_HOVER
                        _aircraftState.value = current.copy(targetNacelleAngleDeg = 90.0f)
                        logAudit("TRANSITION_CORRIDOR", CommandAuthority.AUTONOMY_SYSTEM, "Approach Deceleration", "Decelerating from 135 kts to Vertipad Approach speed.")
                    }
                }

                val speedKmS = (newAirspeed * 1.852f) / 3600.0f
                val stepKm = speedKmS * dt
                val dirAngle = atan2(dLon, dLat)
                newLat += (cos(dirAngle) * stepKm / 111.0)
                newLon += (sin(dirAngle) * stepKm / (111.0 * cos(Math.toRadians(newLat))))
                newDistCovered += stepKm
                newDistRem = (24.5f - newDistCovered).coerceAtLeast(0f)
            }
            FlightMode.TRANSITION_TO_HOVER -> {
                newTransState = when {
                    newTilt < 40f -> TransitionState.REVERSE_INITIATED
                    newTilt < 80f -> TransitionState.HOVER_DECEL
                    else -> TransitionState.HOVER_STABILIZED
                }
                newAirspeed = (newAirspeed - 15.0f * dt).coerceAtLeast(20.0f)
                newVerticalSpeed = -450.0f
                newAltMsl = (newAltMsl + (newVerticalSpeed / 60.0f) * dt).coerceAtLeast(250.0f)
                newAltAgl = newAltMsl - 83f

                if (newTilt >= 90.0f && newAltMsl <= 280.0f) {
                    newFlightMode = FlightMode.APPROACH
                    logAudit("APPROACH", CommandAuthority.AUTONOMOUS_ATC, "Vertipad Cat III Glidepath", "Captured Heathrow T5 Vertipad Precision Laser Glidepath.")
                }
            }
            FlightMode.APPROACH -> {
                newTransState = TransitionState.HOVER_STABILIZED
                newAirspeed = 15.0f
                newVerticalSpeed = -300.0f
                newAltMsl = (newAltMsl + (newVerticalSpeed / 60.0f) * dt).coerceAtLeast(95.0f)
                newAltAgl = (newAltMsl - 83.0f).coerceAtLeast(12.0f)

                if (newAltAgl <= 15.0f) {
                    newFlightMode = FlightMode.LANDING
                }
            }
            FlightMode.LANDING -> {
                newTransState = TransitionState.HOVER_LIFT
                newAirspeed = 0.0f
                newVerticalSpeed = -120.0f
                newAltMsl = (newAltMsl + (newVerticalSpeed / 60.0f) * dt).coerceAtLeast(83.0f)
                newAltAgl = (newAltMsl - 83.0f).coerceAtLeast(0.0f)

                if (newAltAgl <= 0.2f) {
                    newFlightMode = FlightMode.TOUCHDOWN
                    logAudit("TOUCHDOWN", CommandAuthority.SAFETY_SYSTEM, "Touchdown Confirmed", "Landed safely on Heathrow T5 Vertipad Pad #4.")
                }
            }
            FlightMode.TOUCHDOWN -> {
                newAirspeed = 0f
                newVerticalSpeed = 0f
                newAltMsl = 83f
                newAltAgl = 0f
            }
            FlightMode.DISEMBARKING -> {
                newAirspeed = 0f
                newVerticalSpeed = 0f
            }
            FlightMode.EMERGENCY, FlightMode.LOST_LINK, FlightMode.FAILSAFE -> {
                newAirspeed = (newAirspeed - 5.0f * dt).coerceAtLeast(30.0f)
                newVerticalSpeed = -200.0f
                newAltMsl = (newAltMsl + (newVerticalSpeed / 60.0f) * dt).coerceAtLeast(500.0f)
            }
            FlightMode.RETURN_TO_HOME -> {
                newAirspeed = 110.0f
                newAltMsl = 1000.0f
            }
            FlightMode.RECOVERY, FlightMode.INITIALISING, FlightMode.MAINTENANCE, FlightMode.SIMULATION, FlightMode.GROUND_TAXI, FlightMode.DISARMED -> {
                // Standby modes
            }
        }

        // 4. Power & Energy Dynamics
        val baseHoverPowerKw = 275.0f
        val baseCruisePowerKw = 92.0f
        val powerKw = when (newFlightMode) {
            FlightMode.BOARDING, FlightMode.DOORS_LOCKED, FlightMode.ARMED -> 22.0f
            FlightMode.TAKEOFF, FlightMode.HOVER, FlightMode.LANDING -> baseHoverPowerKw
            FlightMode.TRANSITION_TO_CRUISE, FlightMode.TRANSITION_TO_HOVER -> {
                baseHoverPowerKw * (1.0f - wingLiftRatio) + baseCruisePowerKw * wingLiftRatio + 25.0f
            }
            FlightMode.CRUISE -> baseCruisePowerKw
            FlightMode.APPROACH -> 180.0f
            else -> 35.0f
        }

        // Battery drain
        val energyDrainedKwh = (powerKw / 3600.0f) * dt
        var newSoc = (current.battery.socPercent - (energyDrainedKwh / current.battery.totalCapacityKwh * 100.0f)).coerceAtLeast(5.0f)
        if (faultLowBattery) {
            newSoc = 16.5f // Simulate critical battery threshold
        }
        val newEnergyRemKwh = (newSoc / 100.0f) * current.battery.totalCapacityKwh
        val estimatedEnduranceMin = (newEnergyRemKwh / (powerKw.coerceAtLeast(50.0f))) * 60.0f

        // 5. Rotors Telemetry & Fault compensation
        val targetRpm = when (newFlightMode) {
            FlightMode.BOARDING, FlightMode.DOORS_LOCKED, FlightMode.ARMED -> 0.0f
            FlightMode.TAKEOFF, FlightMode.HOVER, FlightMode.LANDING -> 2450.0f
            FlightMode.CRUISE -> 1250.0f // Low RPM in cruise
            else -> 1900.0f
        }

        val updatedRotors = current.rotors.map { rotor ->
            if (faultMotorDegraded && rotor.id == 4) {
                rotor.copy(
                    rpm = 620.0f,
                    motorTempC = 78.5f,
                    torquePercent = 22.0f,
                    health = HealthStatus.WARNING
                )
            } else {
                val compensatedRpm = if (faultMotorDegraded) targetRpm * 1.08f else targetRpm
                rotor.copy(
                    rpm = compensatedRpm,
                    motorTempC = 42.0f + (rotor.id * 0.5f),
                    torquePercent = (powerKw / 8.0f / 35.0f * 100.0f).coerceIn(10.0f, 98.0f),
                    health = HealthStatus.NOMINAL
                )
            }
        }

        // 6. Acoustics & Passenger Comfort G-Forces
        var gForce = 1.0f + (sin(System.currentTimeMillis() / 1500.0).toFloat() * 0.02f)
        var windSpeed = 8.5f
        if (faultMicroburstWind) {
            windSpeed = 28.5f
            gForce = 1.0f + (sin(System.currentTimeMillis() / 300.0).toFloat() * 0.14f)
        }

        val extNoiseDba = when (newFlightMode) {
            FlightMode.BOARDING, FlightMode.DOORS_LOCKED, FlightMode.ARMED -> 38.0f
            FlightMode.TAKEOFF, FlightMode.HOVER, FlightMode.LANDING -> 63.8f
            FlightMode.TRANSITION_TO_CRUISE, FlightMode.TRANSITION_TO_HOVER -> 59.2f
            FlightMode.CRUISE -> 49.5f
            else -> 45.0f
        }

        // 7. Fault and Alert Generation
        val activeFaultList = mutableListOf<String>()
        val cautionList = mutableListOf<String>()

        if (faultMotorDegraded) {
            activeFaultList.add("PROPULSION: DEP Motor #4 Thrust Loss (74% Degradation)")
            cautionList.add("Differential Torque Compensation Active on Rotors 2, 3, 5, 6")
        }
        if (faultMicroburstWind) {
            activeFaultList.add("ENVIRONMENT: Low-Altitude Urban Wind Shear / Microburst (28.5 kts)")
            cautionList.add("Passenger Comfort Active G-Damping Engaged")
        }
        if (faultGnssDegraded) {
            activeFaultList.add("NAVIGATION: Urban High-Rise GNSS Multi-Path Interference")
            cautionList.add("Triple-Redundant IMU Voting & Optical Flow Engaged")
        }
        if (faultCommsDrop) {
            activeFaultList.add("COMMS: Skyway 5G Ground Link Disrupted")
            cautionList.add("Autonomous Fail-Soft Satellite Navigation Active")
        }
        if (faultLowBattery) {
            activeFaultList.add("ENERGY: Battery Bank Reserve Threshold (<18%)")
            cautionList.add("Air Traffic Cleared Priority Glidepath to Vertipad Pad #4")
        }

        val propulsionHealth = if (faultMotorDegraded) HealthStatus.WARNING else HealthStatus.NOMINAL
        val navHealth = if (faultGnssDegraded) HealthStatus.DEGRADED else HealthStatus.NOMINAL
        val commsHealth = if (faultCommsDrop) HealthStatus.WARNING else HealthStatus.NOMINAL
        val batteryHealth = if (faultLowBattery) HealthStatus.CRITICAL else HealthStatus.NOMINAL

        val overallHealth = listOf(propulsionHealth, navHealth, commsHealth, batteryHealth)
            .maxByOrNull { it.severityLevel } ?: HealthStatus.NOMINAL

        _aircraftState.value = current.copy(
            timestampMs = System.currentTimeMillis(),
            latitude = newLat,
            longitude = newLon,
            altitudeMslFt = newAltMsl,
            altitudeAglFt = newAltAgl,
            airspeedIasKts = newAirspeed,
            airspeedTasKts = newAirspeed * 1.02f,
            groundSpeedKts = (newAirspeed + 4.5f).coerceAtLeast(0f),
            verticalSpeedFpm = newVerticalSpeed,
            pitchDeg = newPitch,
            rollDeg = newRoll,
            nacelleTiltAngleDeg = newTilt,
            wingLiftRatio = wingLiftRatio,
            totalPowerKw = powerKw,
            windSpeedKts = windSpeed,
            acousticNoiseDba = extNoiseDba,
            flightMode = newFlightMode,
            transitionState = newTransState,
            distanceCoveredKm = newDistCovered,
            distanceRemainingKm = newDistRem,
            activeWaypointIndex = newWpIndex,
            nextWaypointName = newNextWp,
            estimatedTimeToArrivalMin = (newDistRem / ((newAirspeed.coerceAtLeast(40.0f) * 1.852f) / 60.0f)),
            rotors = updatedRotors,
            battery = current.battery.copy(
                socPercent = newSoc,
                energyRemainingKwh = newEnergyRemKwh,
                estimatedEnduranceMinutes = estimatedEnduranceMin,
                totalVoltageV = 800.0f + (newSoc * 0.2f),
                totalCurrentA = (powerKw * 1000.0f) / 810.0f
            ),
            cabin = current.cabin.copy(
                passengerComfortG = gForce,
                internalNoiseDba = extNoiseDba - current.cabin.activeNoiseCancellationDbaReduction,
                comfortRating = if (faultMicroburstWind) "Moderate Turbulence (Active Damping)" else "Executive Ultra-Smooth (0.02G variance)"
            ),
            sensorsReport = current.sensorsReport.copy(
                gnss1Healthy = !faultGnssDegraded,
                gnssSatellites = if (faultGnssDegraded) 6 else 18,
                gnssHdop = if (faultGnssDegraded) 2.45f else 0.82f
            ),
            linkLatencyMs = if (faultCommsDrop) 280 else 18,
            linkPacketLossPct = if (faultCommsDrop) 14.5f else 0.02f,
            overallHealth = overallHealth,
            propulsionHealth = propulsionHealth,
            navigationHealth = navHealth,
            commsHealth = commsHealth,
            batteryHealth = batteryHealth,
            activeFaults = activeFaultList,
            cautionMessages = cautionList
        )
    }

    fun dispatchCommand(command: CommandDispatch): CommandResponse {
        val current = _aircraftState.value
        logAudit("COMMAND", command.authority, "Command Dispatched: ${command.actionName}", "Parameters: ${command.parameters}")

        when (command.actionName) {
            "START_BOARDING" -> {
                _aircraftState.value = current.copy(
                    flightMode = FlightMode.BOARDING,
                    cabin = current.cabin.copy(
                        doorsState = DoorState.OPEN_BOARDING,
                        lightingTheme = CabinLightingMode.BOARDING_ILLUMINATED
                    )
                )
                return CommandResponse(command.commandId, true, "BOARDING_ACTIVE", "Cabin doors open. Welcome lighting activated.")
            }
            "CLOSE_CABIN_DOORS" -> {
                _aircraftState.value = current.copy(
                    flightMode = FlightMode.DOORS_LOCKED,
                    cabin = current.cabin.copy(
                        doorsState = DoorState.LOCKED_AND_PRESSURIZED,
                        lightingTheme = CabinLightingMode.DAY_CRUISE
                    )
                )
                return CommandResponse(command.commandId, true, "CABIN_SECURE", "All 4 passenger doors locked and pressurized.")
            }
            "ARM_AND_TAKEOFF" -> {
                _aircraftState.value = current.copy(
                    flightMode = FlightMode.TAKEOFF,
                    targetNacelleAngleDeg = 90.0f,
                    autonomyMode = AutonomyMode.URBAN_AUTO_PILOT
                )
                return CommandResponse(command.commandId, true, "TAKEOFF_INITIATED", "Climbing vertically to 450 ft transition window.")
            }
            "EXECUTE_TRANSITION_CRUISE" -> {
                _aircraftState.value = current.copy(
                    flightMode = FlightMode.TRANSITION_TO_CRUISE,
                    targetNacelleAngleDeg = 0.0f
                )
                return CommandResponse(command.commandId, true, "CONVERSION_INITIATED", "Tilting nacelles to 0° forward flight.")
            }
            "HOLD_VERTIPAD_APPROACH" -> {
                _aircraftState.value = current.copy(
                    flightMode = FlightMode.TRANSITION_TO_HOVER,
                    targetNacelleAngleDeg = 90.0f
                )
                return CommandResponse(command.commandId, true, "APPROACH_INITIATED", "Decelerating for Heathrow T5 Vertipad approach.")
            }
            "LAND_VERTIPAD" -> {
                _aircraftState.value = current.copy(
                    flightMode = FlightMode.LANDING,
                    targetNacelleAngleDeg = 90.0f
                )
                return CommandResponse(command.commandId, true, "LANDING_ACTIVE", "Vertical descent to Vertipad touchdown.")
            }
            "EMERGENCY_DIVERT_NEAREST_VERTIPAD" -> {
                _aircraftState.value = current.copy(
                    flightMode = FlightMode.FAILSAFE,
                    destinationVertiport = "Farnborough Aerospace Vertigate (EGLF-V)",
                    activeFaults = listOf("SAFETY: Diverting to Alternate Vertigate EGLF-V")
                )
                return CommandResponse(command.commandId, true, "DIVERT_INITIATED", "Cleared priority routing to Farnborough.")
            }
            "SET_CABIN_LIGHTING" -> {
                val themeName = command.parameters["theme"] ?: "DAY_CRUISE"
                val theme = CabinLightingMode.entries.find { it.name == themeName } ?: CabinLightingMode.DAY_CRUISE
                _aircraftState.value = current.copy(
                    cabin = current.cabin.copy(lightingTheme = theme)
                )
                return CommandResponse(command.commandId, true, "CABIN_LIGHTING_UPDATED", "Theme set to ${theme.displayName}.")
            }
            "SET_CABIN_TEMPERATURE" -> {
                val temp = command.parameters["temp"]?.toFloatOrNull() ?: 21.0f
                _aircraftState.value = current.copy(
                    cabin = current.cabin.copy(targetTempC = temp, currentTempC = temp)
                )
                return CommandResponse(command.commandId, true, "TEMPERATURE_UPDATED", "Target cabin temperature set to $temp°C.")
            }
            "RESET_SIMULATION" -> {
                faultMotorDegraded = false
                faultGnssDegraded = false
                faultMicroburstWind = false
                faultCommsDrop = false
                faultLowBattery = false
                _aircraftState.value = createInitialState()
                return CommandResponse(command.commandId, true, "SIMULATION_RESET", "Aircraft reset to London Battersea Vertipad.")
            }
            else -> {
                return CommandResponse(command.commandId, false, "UNKNOWN_COMMAND", "Command ${command.actionName} not recognized.")
            }
        }
    }

    private fun logAudit(category: String, authority: CommandAuthority, title: String, detail: String) {
        val event = AuditEvent(
            timestampMs = System.currentTimeMillis(),
            eventCategory = category,
            sourceAuthority = authority,
            title = title,
            detail = detail
        )
        onAuditEvent(event)
    }
}
