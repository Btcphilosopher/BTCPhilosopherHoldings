package com.example.vtolos.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "flight_records")
data class FlightRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestampMs: Long,
    val aircraftId: String,
    val flightMode: String,
    val transitionState: String,
    val latitude: Double,
    val longitude: Double,
    val altitudeMslFt: Float,
    val altitudeAglFt: Float,
    val airspeedKts: Float,
    val groundSpeedKts: Float,
    val verticalSpeedFpm: Float,
    val pitchDeg: Float,
    val rollDeg: Float,
    val headingDeg: Float,
    val nacelleTiltDeg: Float,
    val wingLiftRatio: Float,
    val totalPowerKw: Float,
    val batterySocPercent: Float,
    val passengerComfortG: Float,
    val acousticNoiseDba: Float,
    val totalPassengers: Int,
    val activeWaypoint: String
)

@Entity(tableName = "audit_events")
data class AuditEventEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestampMs: Long,
    val category: String,
    val authority: String,
    val title: String,
    val detail: String,
    val severity: String
)

@Entity(tableName = "flight_plans")
data class FlightPlanEntity(
    @PrimaryKey
    val flightPlanId: String,
    val flightNumber: String,
    val originIcao: String,
    val destinationIcao: String,
    val departureTime: String,
    val arrivalTime: String,
    val passengerCount: Int,
    val status: String
)
