package com.example.vtolos.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.vtolos.core.model.FlightMode
import com.example.vtolos.core.model.PassengerAircraftState
import com.example.vtolos.core.model.TransitionState
import kotlin.math.*

/**
 * Supermodern British Aerospace Primary Flight Display (PFD).
 * Features Electronic Flight Instrument System (EFIS):
 * - Pitch ladder & Artificial Horizon (-40° to +40°)
 * - Airspeed tape with transition corridor & stall limits
 * - Altitude tape (MSL) & Radar Altimeter (AGL)
 * - Heading tape with track bug
 * - Flight Path Vector & Flight Mode Annunciator (FMA)
 */
@Composable
fun PrimaryFlightDisplay(
    state: PassengerAircraftState,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(AeroGraphite)
            .border(1.dp, AeroBorder, RoundedCornerShape(8.dp))
            .padding(6.dp)
            .testTag("primary_flight_display")
    ) {
        // Top Flight Mode Annunciator (FMA)
        FlightModeAnnunciatorBar(state)

        Spacer(modifier = Modifier.height(4.dp))

        // Center Glass Cockpit Instruments
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(4.dp))
                .background(AeroBlack)
        ) {
            // 1. Artificial Horizon Canvas
            Canvas(modifier = Modifier.fillMaxSize().testTag("canvas_artificial_horizon")) {
                drawArtificialHorizon(state)
            }

            // 2. Airspeed Tape (Left)
            AirspeedTapeOverlay(
                airspeed = state.airspeedIasKts,
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .width(64.dp)
                    .fillMaxHeight()
            )

            // 3. Altitude & VSI Tape (Right)
            AltitudeTapeOverlay(
                altMsl = state.altitudeMslFt,
                altAgl = state.altitudeAglFt,
                vsi = state.verticalSpeedFpm,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .width(76.dp)
                    .fillMaxHeight()
            )

            // 4. Center Bore & Flight Path Vector (FPV)
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawAircraftBoreAndFpv(state)
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Bottom Heading / Compass Ribbon
        HeadingTapeBar(
            headingDeg = state.headingDeg,
            trackDeg = state.trackDeg,
            modifier = Modifier
                .fillMaxWidth()
                .height(38.dp)
        )
    }
}

@Composable
private fun FlightModeAnnunciatorBar(state: PassengerAircraftState) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(AeroPanelBg)
            .border(1.dp, AeroBorderBright, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Active Flight Mode
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (state.flightMode.isEmergency) HudCrimson else HudEmerald)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = state.flightMode.label,
                color = if (state.flightMode.isEmergency) HudCrimson else HudEmerald,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        // Transition Corridor State
        Text(
            text = "CORRIDOR: ${state.transitionState.label}",
            color = HudCyan,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold
        )

        // Autonomy Mode
        Text(
            text = state.autonomyMode.label,
            color = HudWhite,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}

private fun DrawScope.drawArtificialHorizon(state: PassengerAircraftState) {
    val cx = size.width / 2f
    val cy = size.height / 2f
    val radius = min(size.width, size.height)

    rotate(degrees = -state.rollDeg, pivot = Offset(cx, cy)) {
        val pitchOffset = (state.pitchDeg / 40.0f) * (size.height * 0.45f)
        val horizonY = cy + pitchOffset

        // Sky Rectangle
        drawRect(
            color = HorizonSky,
            topLeft = Offset(cx - radius * 1.5f, horizonY - radius * 2f),
            size = Size(radius * 3f, radius * 2f)
        )

        // Ground Rectangle
        drawRect(
            color = HorizonGround,
            topLeft = Offset(cx - radius * 1.5f, horizonY),
            size = Size(radius * 3f, radius * 2f)
        )

        // Horizon Dividing Line
        drawLine(
            color = HorizonLine,
            start = Offset(cx - radius * 1.2f, horizonY),
            end = Offset(cx + radius * 1.2f, horizonY),
            strokeWidth = 2.5f
        )

        // Pitch Ladder Rungs (-30° to +30° in 5° steps)
        for (pitch in -30..30 step 5) {
            if (pitch == 0) continue
            val py = horizonY - (pitch / 40.0f) * (size.height * 0.45f)
            val rungWidth = if (abs(pitch) % 10 == 0) 46.dp.toPx() else 24.dp.toPx()
            val strokeColor = if (pitch > 0) HudCyan.copy(alpha = 0.8f) else HudAmber.copy(alpha = 0.8f)

            // Left rung
            drawLine(
                color = strokeColor,
                start = Offset(cx - rungWidth, py),
                end = Offset(cx - 10.dp.toPx(), py),
                strokeWidth = 2f
            )
            // Right rung
            drawLine(
                color = strokeColor,
                start = Offset(cx + 10.dp.toPx(), py),
                end = Offset(cx + rungWidth, py),
                strokeWidth = 2f
            )
        }
    }
}

private fun DrawScope.drawAircraftBoreAndFpv(state: PassengerAircraftState) {
    val cx = size.width / 2f
    val cy = size.height / 2f

    // Aircraft Center Bore (Yellow/White Precision Wings)
    val wingSpan = 22.dp.toPx()
    val barHeight = 4.dp.toPx()

    // Left Wing
    drawLine(
        color = HudAmber,
        start = Offset(cx - wingSpan - 12.dp.toPx(), cy),
        end = Offset(cx - 12.dp.toPx(), cy),
        strokeWidth = 3f
    )
    drawLine(
        color = HudAmber,
        start = Offset(cx - 12.dp.toPx(), cy),
        end = Offset(cx - 12.dp.toPx(), cy + barHeight),
        strokeWidth = 3f
    )

    // Center Dot
    drawCircle(
        color = HudAmber,
        radius = 3.5.dp.toPx(),
        center = Offset(cx, cy)
    )

    // Right Wing
    drawLine(
        color = HudAmber,
        start = Offset(cx + 12.dp.toPx(), cy),
        end = Offset(cx + wingSpan + 12.dp.toPx(), cy),
        strokeWidth = 3f
    )
    drawLine(
        color = HudAmber,
        start = Offset(cx + 12.dp.toPx(), cy),
        end = Offset(cx + 12.dp.toPx(), cy + barHeight),
        strokeWidth = 3f
    )

    // Flight Path Vector (Green Bird Circle + Winglets)
    val fpvX = cx + (state.windCrosswindKts * 2.5f)
    val fpvY = cy - (state.verticalSpeedFpm / 1500.0f) * 28.dp.toPx()
    drawCircle(
        color = HudEmerald,
        radius = 5.dp.toPx(),
        center = Offset(fpvX, fpvY),
        style = Stroke(width = 2f)
    )
    drawLine(
        color = HudEmerald,
        start = Offset(fpvX - 10.dp.toPx(), fpvY),
        end = Offset(fpvX - 5.dp.toPx(), fpvY),
        strokeWidth = 2f
    )
    drawLine(
        color = HudEmerald,
        start = Offset(fpvX + 5.dp.toPx(), fpvY),
        end = Offset(fpvX + 10.dp.toPx(), fpvY),
        strokeWidth = 2f
    )
    drawLine(
        color = HudEmerald,
        start = Offset(fpvX, fpvY - 5.dp.toPx()),
        end = Offset(fpvX, fpvY - 9.dp.toPx()),
        strokeWidth = 2f
    )
}

@Composable
private fun AirspeedTapeOverlay(airspeed: Float, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(AeroBlack.copy(alpha = 0.65f))
            .border(1.dp, AeroBorder, RoundedCornerShape(topStart = 4.dp, bottomStart = 4.dp))
            .padding(2.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "IAS KTS",
                color = HudMuted,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )

            // Dynamic Airspeed Readout Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(3.dp))
                    .background(AeroCardSurface)
                    .border(1.5.dp, HudCyan, RoundedCornerShape(3.dp))
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = String.format("%.0f", airspeed),
                    color = HudWhite,
                    fontSize = 16.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            // Transition corridor speed window indicator
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "CORR: 40-135",
                    color = HudCyan,
                    fontSize = 7.5.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "VNE: 160",
                    color = HudAmber,
                    fontSize = 7.5.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
private fun AltitudeTapeOverlay(
    altMsl: Float,
    altAgl: Float,
    vsi: Float,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(AeroBlack.copy(alpha = 0.65f))
            .border(1.dp, AeroBorder, RoundedCornerShape(topEnd = 4.dp, bottomEnd = 4.dp))
            .padding(2.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "ALT MSL",
                color = HudMuted,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )

            // Dynamic Altitude Readout Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(3.dp))
                    .background(AeroCardSurface)
                    .border(1.5.dp, HudEmerald, RoundedCornerShape(3.dp))
                    .padding(vertical = 3.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = String.format("%.0f", altMsl),
                        color = HudWhite,
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "R-AGL ${String.format("%.0f", altAgl)}'",
                        color = HudEmerald,
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Vertical Speed Indicator (VSI)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "VSI ",
                    color = HudMuted,
                    fontSize = 7.5.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = String.format("%+d", vsi.toInt()),
                    color = if (vsi >= 0) HudEmerald else HudAmber,
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun HeadingTapeBar(
    headingDeg: Float,
    trackDeg: Float,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(AeroPanelBg)
            .border(1.dp, AeroBorder, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "HDG: ${String.format("%03.0f°", headingDeg)}",
            color = HudWhite,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )

        // Center Compass Cardinal Box
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(3.dp))
                .background(AeroCardSurface)
                .border(1.dp, HudCyan, RoundedCornerShape(3.dp))
                .padding(horizontal = 12.dp, vertical = 2.dp)
        ) {
            val cardinal = when (headingDeg.toInt()) {
                in 338..360, in 0..22 -> "N"
                in 23..67 -> "NE"
                in 68..112 -> "E"
                in 113..157 -> "SE"
                in 158..202 -> "S"
                in 203..247 -> "SW"
                in 248..292 -> "W"
                else -> "NW"
            }
            Text(
                text = "$cardinal · ${String.format("%03.0f°", headingDeg)}",
                color = HudCyan,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        Text(
            text = "TRK: ${String.format("%03.0f°", trackDeg)}",
            color = HudEmerald,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold
        )
    }
}
