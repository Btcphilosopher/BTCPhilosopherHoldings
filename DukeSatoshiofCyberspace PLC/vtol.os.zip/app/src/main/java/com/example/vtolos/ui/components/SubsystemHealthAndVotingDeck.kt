package com.example.vtolos.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.vtolos.core.model.HealthStatus
import com.example.vtolos.core.model.PassengerAircraftState

/**
 * Subsystem Health & Triple-Redundant Sensor Voting Matrix.
 */
@Composable
fun SubsystemHealthAndVotingDeck(
    state: PassengerAircraftState,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(AeroGraphite)
            .border(1.dp, AeroBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
            .testTag("subsystem_health_deck")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "AIRCRAFT HEALTH & SENSOR VOTING",
                    color = HudWhite,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Triple IMU Voting · Dual GNSS · 5G Mesh & SatCom Redundancy",
                    color = HudMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.SansSerif
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(AeroCardSurface)
                    .border(1.dp, if (state.overallHealth == HealthStatus.NOMINAL) HudEmerald else HudAmber, RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = "STATUS: ${state.overallHealth.label}",
                    color = if (state.overallHealth == HealthStatus.NOMINAL) HudEmerald else HudAmber,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Subsystem Matrix Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            SubsystemChip("PROPULSION", state.propulsionHealth, Modifier.weight(1f))
            SubsystemChip("BATTERY", state.batteryHealth, Modifier.weight(1f))
            SubsystemChip("NAVIGATION", state.navigationHealth, Modifier.weight(1f))
            SubsystemChip("COMMS", state.commsHealth, Modifier.weight(1f))
            SubsystemChip("CABIN", state.cabinHealth, Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Sensor Voting Breakdown Box
        val s = state.sensorsReport
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(4.dp))
                .background(AeroPanelBg)
                .border(1.dp, AeroBorder, RoundedCornerShape(4.dp))
                .padding(6.dp)
        ) {
            Text(
                text = "TRIPLE SENSOR VOTING & INTEGRITY",
                color = HudMuted,
                fontSize = 8.5.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(3.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "IMU 1/2/3: ${if (s.imuVotingAgreed) "ALL 3 IN PARITY (NOMINAL)" else "IMU 2 DISAGREEMENT ISOLATED"}",
                    color = if (s.imuVotingAgreed) HudEmerald else HudAmber,
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "GNSS: ${s.gnssSatellites} SATS (HDOP ${String.format("%.2f", s.gnssHdop)})",
                    color = if (s.gnss1Healthy) HudEmerald else HudAmber,
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Pitot Airspeed 1/2: ${String.format("%.1f", s.pitotPrimaryAirspeedKts)} / ${String.format("%.1f", s.pitotSecondaryAirspeedKts)} kts",
                    color = HudWhite,
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Laser Altimeter: ${String.format("%.0f", s.laserAltimeterAglFt)}' AGL",
                    color = HudCyan,
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Active Alerts & Cautions
        if (state.activeFaults.isNotEmpty() || state.cautionMessages.isNotEmpty()) {
            Spacer(modifier = Modifier.height(6.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(HudCrimson.copy(alpha = 0.15f))
                    .border(1.dp, HudCrimson.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                    .padding(6.dp)
            ) {
                state.activeFaults.forEach { fault ->
                    Text(text = "⚠ $fault", color = HudCrimson, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
                state.cautionMessages.forEach { caution ->
                    Text(text = "↳ $caution", color = HudAmber, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
private fun SubsystemChip(name: String, status: HealthStatus, modifier: Modifier = Modifier) {
    val isNominal = status == HealthStatus.NOMINAL
    val color = when (status) {
        HealthStatus.NOMINAL -> HudEmerald
        HealthStatus.DEGRADED -> HudCyan
        HealthStatus.WARNING -> HudAmber
        HealthStatus.CRITICAL, HealthStatus.FAILED -> HudCrimson
        else -> HudMuted
    }
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(3.dp))
            .background(AeroCardSurface)
            .border(1.dp, color.copy(alpha = 0.6f), RoundedCornerShape(3.dp))
            .padding(vertical = 3.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = name, color = HudMuted, fontSize = 7.5.sp, fontFamily = FontFamily.Monospace)
        Text(text = status.label, color = color, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}
