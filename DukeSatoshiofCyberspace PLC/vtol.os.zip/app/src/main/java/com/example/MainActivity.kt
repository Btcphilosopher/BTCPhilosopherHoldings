package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.VTOLOSTheme
import com.example.vtolos.ui.screens.MainCockpitScreen
import com.example.vtolos.ui.viewmodel.VtolViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VTOLOSTheme {
                val viewModel: VtolViewModel = viewModel()
                MainCockpitScreen(viewModel = viewModel)
            }
        }
    }
}

