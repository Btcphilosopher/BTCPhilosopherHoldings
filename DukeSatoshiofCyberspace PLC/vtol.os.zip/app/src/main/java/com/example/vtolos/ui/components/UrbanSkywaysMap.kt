package com.example.vtolos.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.vtolos.core.model.PassengerAircraftState
import com.example.vtolos.core.model.VertiportNetwork
import kotlin.math.*

/**
 * Supermodern Synthetic Vector Moving Map for Anglo Urban Air Mobility (UAM).
 * Renders Vertiport hubs, Skyway Corridors, Geofence boundaries, and live traffic.
 */
@Composable
fun UrbanSkywaysMap(
    state: PassengerAircraftState,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(AeroGraphite)
            .border(1.dp, AeroBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
            .testTag("urban_skyways_map")
    ) {
        // Map Header & ATC Status
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "URBAN SKYWAY TACTICAL MOVING MAP",
                    color = HudWhite,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${state.currentRouteName} · ${state.atcClearanceStatus}",
                    color = HudEmerald,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // ETA Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(AeroCardSurface)
                    .border(1.dp, HudEmerald, RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = "ETA ${String.format("%.1f", state.estimatedTimeToArrivalMin)} MIN · ${String.format("%.1f", state.distanceRemainingKm)} KM",
                    color = HudEmerald,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Vector Map Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(6.dp))
                .background(AeroBlack)
                .border(1.dp, AeroBorder, RoundedCornerShape(6.dp))
        ) {
            Canvas(modifier = Modifier.fillMaxSize().testTag("canvas_vector_map")) {
                drawUrbanSkywayMap(state)
            }

            // Map Overlay Legend & Quick Stats
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(AeroBlack.copy(alpha = 0.8f))
                    .border(1.dp, AeroBorder, RoundedCornerShape(4.dp))
                    .padding(6.dp)
            ) {
                Text(
                    text = "DEPARTURE: ${state.departureVertiport}",
                    color = HudWhite,
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "DESTINATION: ${state.destinationVertiport}",
                    color = HudCyan,
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "ACTIVE GATE: ${state.nextWaypointName} (WPT ${state.activeWaypointIndex + 1}/${state.totalWaypoints})",
                    color = HudAmber,
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

private fun DrawScope.drawUrbanSkywayMap(state: PassengerAircraftState) {
    val cx = size.width / 2f
    val cy = size.height / 2f

    // 1. Airspace Grid Lines
    val gridSpacing = 40.dp.toPx()
    for (x in 0..(size.width / gridSpacing).toInt()) {
        drawLine(
            color = AeroBorder.copy(alpha = 0.35f),
            start = Offset(x * gridSpacing, 0f),
            end = Offset(x * gridSpacing, size.height),
            strokeWidth = 1f
        )
    }
    for (y in 0..(size.height / gridSpacing).toInt()) {
        drawLine(
            color = AeroBorder.copy(alpha = 0.35f),
            start = Offset(0f, y * gridSpacing),
            end = Offset(size.width, y * gridSpacing),
            strokeWidth = 1f
        )
    }

    // 2. Synthetic London River Thames Vector Curve
    val thamesPath = Path().apply {
        moveTo(20.dp.toPx(), cy + 60.dp.toPx())
        cubicTo(
            size.width * 0.3f, cy + 80.dp.toPx(),
            size.width * 0.6f, cy - 20.dp.toPx(),
            size.width - 20.dp.toPx(), cy - 40.dp.toPx()
        )
    }
    drawPath(
        path = thamesPath,
        color = Color(0xFF1E3A5F).copy(alpha = 0.6f),
        style = Stroke(width = 8.dp.toPx())
    )

    // 3. Skyway Corridor Bravo-4 Bounds (Cyan corridor)
    val startX = 50.dp.toPx()
    val startY = cy + 45.dp.toPx()
    val endX = size.width - 60.dp.toPx()
    val endY = cy - 35.dp.toPx()

    // Corridor centerline
    drawLine(
        color = HudCyan.copy(alpha = 0.75f),
        start = Offset(startX, startY),
        end = Offset(endX, endY),
        strokeWidth = 2f
    )

    // Corridor boundaries (± 25dp width)
    drawLine(
        color = HudCyan.copy(alpha = 0.3f),
        start = Offset(startX, startY - 20.dp.toPx()),
        end = Offset(endX, endY - 20.dp.toPx()),
        strokeWidth = 1f
    )
    drawLine(
        color = HudCyan.copy(alpha = 0.3f),
        start = Offset(startX, startY + 20.dp.toPx()),
        end = Offset(endX, endY + 20.dp.toPx()),
        strokeWidth = 1f
    )

    // 4. Vertiports on Map
    // Origin (Battersea)
    drawCircle(color = HudEmerald, radius = 7.dp.toPx(), center = Offset(startX, startY))
    drawCircle(color = HudEmerald.copy(alpha = 0.3f), radius = 14.dp.toPx(), center = Offset(startX, startY), style = Stroke(width = 1.5f))

    // Destination (Heathrow T5)
    drawCircle(color = HudCyan, radius = 7.dp.toPx(), center = Offset(endX, endY))
    drawCircle(color = HudCyan.copy(alpha = 0.3f), radius = 14.dp.toPx(), center = Offset(endX, endY), style = Stroke(width = 1.5f))

    // Alternate Vertigate (Farnborough - South West)
    val altX = size.width * 0.25f
    val altY = size.height - 40.dp.toPx()
    drawCircle(color = HudAmber, radius = 5.dp.toPx(), center = Offset(altX, altY))

    // 5. Waypoints along corridor
    val wpSteps = 4
    for (i in 1 until wpSteps) {
        val frac = i.toFloat() / wpSteps
        val wx = startX + (endX - startX) * frac
        val wy = startY + (endY - startY) * frac
        drawCircle(color = HudWhite.copy(alpha = 0.8f), radius = 3.5.dp.toPx(), center = Offset(wx, wy))
    }

    // 6. Current Aircraft Position & Heading Vector
    val progressFrac = (state.distanceCoveredKm / 24.5f).coerceIn(0.05f, 0.95f)
    val planeX = startX + (endX - startX) * progressFrac
    val planeY = startY + (endY - startY) * progressFrac

    // Breadcrumb Trail (Past path)
    drawLine(
        color = HudEmerald,
        start = Offset(startX, startY),
        end = Offset(planeX, planeY),
        strokeWidth = 3f
    )

    // Aircraft Symbol (Stylized Arrow / Diamond)
    rotate(degrees = state.headingDeg - 270f, pivot = Offset(planeX, planeY)) {
        val planePath = Path().apply {
            moveTo(planeX, planeY - 12.dp.toPx())
            lineTo(planeX + 8.dp.toPx(), planeY + 8.dp.toPx())
            lineTo(planeX, planeY + 4.dp.toPx())
            lineTo(planeX - 8.dp.toPx(), planeY + 8.dp.toPx())
            close()
        }
        drawPath(path = planePath, color = HudWhite)
        drawPath(path = planePath, color = HudEmerald, style = Stroke(width = 1.5f))

        // Forward Projector Vector Line (5 miles ahead)
        drawLine(
            color = HudEmerald.copy(alpha = 0.6f),
            start = Offset(planeX, planeY - 12.dp.toPx()),
            end = Offset(planeX, planeY - 38.dp.toPx()),
            strokeWidth = 1.5f
        )
    }

    // 7. Other Sector Traffic (Simulated SkyCabs)
    val traffic1X = size.width * 0.7f
    val traffic1Y = cy + 50.dp.toPx()
    drawCircle(color = HudAmber, radius = 4.dp.toPx(), center = Offset(traffic1X, traffic1Y))
    drawLine(
        color = HudAmber.copy(alpha = 0.5f),
        start = Offset(traffic1X, traffic1Y),
        end = Offset(traffic1X - 15.dp.toPx(), traffic1Y - 10.dp.toPx()),
        strokeWidth = 1.5f
    )
}
