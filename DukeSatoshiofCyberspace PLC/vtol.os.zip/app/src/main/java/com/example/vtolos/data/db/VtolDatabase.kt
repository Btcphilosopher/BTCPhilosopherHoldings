package com.example.vtolos.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [FlightRecordEntity::class, AuditEventEntity::class, FlightPlanEntity::class],
    version = 1,
    exportSchema = false
)
abstract class VtolDatabase : RoomDatabase() {
    abstract fun flightRecordDao(): FlightRecordDao
    abstract fun auditEventDao(): AuditEventDao
    abstract fun flightPlanDao(): FlightPlanDao

    companion object {
        @Volatile
        private var INSTANCE: VtolDatabase? = null

        fun getDatabase(context: Context): VtolDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    VtolDatabase::class.java,
                    "vtol_os_flight_blackbox.db"
                ).fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
