package com.example.vtolos.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

data class FleetAircraftItem(
    val reg: String,
    val model: String,
    val route: String,
    val passengers: Int,
    val status: String,
    val altitude: String,
    val soc: Int,
    val eta: String,
    val isAirborne: Boolean
)

/**
 * National Fleet Command & Dispatch Deck.
 * Monitors the entire Anglo-Aero urban passenger fleet across London, Cambridge & Farnborough corridors.
 */
@Composable
fun FleetConsoleDeck(modifier: Modifier = Modifier) {
    val fleetList = listOf(
        FleetAircraftItem("G-VTOL-01", "AeroSky 6-Pax Tiltrotor", "Battersea ➔ Heathrow T5", 4, "EN ROUTE (CRUISE)", "1,500 ft", 84, "4.2 min", true),
        FleetAircraftItem("G-VTOL-02", "MetroGlide 4-Pax", "Canary Wharf ➔ Battersea", 3, "APPROACHING PAD #2", "450 ft", 72, "1.8 min", true),
        FleetAircraftItem("G-VTOL-03", "VectraWing 6-Pax", "Cambridge ➔ Canary Wharf", 6, "EN ROUTE (CRUISE)", "2,200 ft", 68, "12.4 min", true),
        FleetAircraftItem("G-VTOL-04", "AeroSky 6-Pax Tiltrotor", "Farnborough ➔ Heathrow T5", 4, "BOARDING / PRE-CHECK", "0 ft", 98, "Dep in 2m", false),
        FleetAircraftItem("G-VTOL-05", "MetroGlide 4-Pax", "London City Pier ➔ Battersea", 2, "EN ROUTE (CRUISE)", "1,200 ft", 61, "6.0 min", true),
        FleetAircraftItem("G-VTOL-06", "AeroSky 6-Pax Tiltrotor", "Heathrow T5 ➔ Oxford West", 4, "EN ROUTE (CRUISE)", "1,800 ft", 55, "14.5 min", true),
        FleetAircraftItem("G-VTOL-07", "CityCopter 2-Pax", "Battersea ➔ Shoreditch Skygate", 2, "MEGAWATT FAST-CHARGE", "0 ft", 92, "Dep in 5m", false),
        FleetAircraftItem("G-VTOL-08", "VectraWing 6-Pax", "Gatwick North ➔ Canary Wharf", 5, "EN ROUTE (CRUISE)", "2,000 ft", 77, "8.9 min", true)
    )

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(AeroGraphite)
            .border(1.dp, AeroBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
            .testTag("fleet_console_deck")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "NATIONAL UAM FLEET DISPATCH COMMAND",
                    color = HudWhite,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "8 Active Aircraft in Greater London / Thames Valley Sector · Skyway Flow Control Active",
                    color = HudMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.SansSerif
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(AeroCardSurface)
                    .border(1.dp, HudCyan, RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = "6 AIRBORNE · 2 CHARGING",
                    color = HudCyan,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(fleetList) { aircraft ->
                FleetAircraftRow(aircraft)
            }
        }
    }
}

@Composable
private fun FleetAircraftRow(aircraft: FleetAircraftItem) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(AeroCardSurface)
            .border(1.dp, AeroBorder, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1.2f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = aircraft.reg,
                    color = HudCyan,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${aircraft.passengers} Pax",
                    color = HudWhite,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Text(
                text = aircraft.route,
                color = HudWhite,
                fontSize = 9.5.sp,
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Medium
            )
        }

        Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = aircraft.status,
                color = if (aircraft.isAirborne) HudEmerald else HudAmber,
                fontSize = 8.5.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Alt: ${aircraft.altitude} · ETA ${aircraft.eta}",
                color = HudMuted,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(3.dp))
                .background(AeroElevated)
                .padding(horizontal = 6.dp, vertical = 3.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "${aircraft.soc}% SoC",
                color = if (aircraft.soc > 30) HudEmerald else HudCrimson,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
