package com.example.vtolos.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.vtolos.core.model.*
import kotlin.math.abs

/**
 * Passenger Cabin Management & Environmental Comfort Deck.
 * Tailored for UberAir-style urban air mobility luxury executive interiors.
 */
@Composable
fun PassengerCabinDeck(
    state: PassengerAircraftState,
    onSetCabinLighting: (CabinLightingMode) -> Unit,
    onSetCabinTemperature: (Float) -> Unit,
    onToggleDoors: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(AeroGraphite)
            .border(1.dp, AeroBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
            .testTag("passenger_cabin_deck")
    ) {
        // Deck Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "PASSENGER CABIN & COMFORT DECK",
                    color = HudWhite,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "4-Seat Executive Suite · Active Acoustic Cancellation · ${state.cabin.comfortRating}",
                    color = HudEmerald,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.SansSerif
                )
            }

            // Door & Pressurization Status
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(AeroCardSurface)
                    .border(1.dp, if (state.cabin.doorsState == DoorState.LOCKED_AND_PRESSURIZED) HudEmerald else HudAmber, RoundedCornerShape(4.dp))
                    .clickable { onToggleDoors() }
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = if (state.cabin.doorsState == DoorState.LOCKED_AND_PRESSURIZED) "DOORS: LOCKED & SEALED" else "DOORS: OPEN / BOARDING",
                    color = if (state.cabin.doorsState == DoorState.LOCKED_AND_PRESSURIZED) HudEmerald else HudAmber,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Passenger Seats Grid (Seats 1A, 1B, 2A, 2B)
        Text(
            text = "PASSENGER MANIFEST & SEATING SUITE",
            color = HudMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            state.passengerSeats.forEach { seat ->
                PassengerSeatCard(
                    seat = seat,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Cabin Environmental Metrics & Ride Comfort
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Left: Climate & Pressure Box
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(6.dp))
                    .background(AeroPanelBg)
                    .border(1.dp, AeroBorder, RoundedCornerShape(6.dp))
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("CLIMATE CONTROL", color = HudMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Text("${String.format("%.1f", state.cabin.currentTempC)}°C", color = HudCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Temperature Selector Buttons (20°C, 21°C, 22°C, 23°C)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(20.0f, 21.0f, 22.0f, 23.0f).forEach { temp ->
                        val isSelected = abs(state.cabin.targetTempC - temp) < 0.2f
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(3.dp))
                                .background(if (isSelected) HudCyan else AeroCardSurface)
                                .border(1.dp, if (isSelected) HudCyan else AeroBorder, RoundedCornerShape(3.dp))
                                .clickable { onSetCabinTemperature(temp) }
                                .padding(vertical = 3.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${temp.toInt()}°C",
                                color = if (isSelected) AeroBlack else HudWhite,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("HEPA Clean Air Index", color = HudMuted, fontSize = 8.5.sp, fontFamily = FontFamily.SansSerif)
                    Text("AQI ${state.cabin.airQualityIndex} (Pristine)", color = HudEmerald, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                }
            }

            // Right: Acoustic Cancellation & Smooth Flight G-Meter
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(6.dp))
                    .background(AeroPanelBg)
                    .border(1.dp, AeroBorder, RoundedCornerShape(6.dp))
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("ACOUSTICS & G-LOAD", color = HudMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Text("${String.format("%.2f", state.cabin.passengerComfortG)} G", color = HudEmerald, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Active Noise Cancel", color = HudMuted, fontSize = 8.5.sp, fontFamily = FontFamily.SansSerif)
                    Text("-${String.format("%.1f", state.cabin.activeNoiseCancellationDbaReduction)} dBA", color = HudEmerald, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Internal Cabin Sound", color = HudMuted, fontSize = 8.5.sp, fontFamily = FontFamily.SansSerif)
                    Text("${String.format("%.1f", state.cabin.internalNoiseDba)} dBA (Whisper)", color = HudWhite, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Baggage Bay", color = HudMuted, fontSize = 8.5.sp, fontFamily = FontFamily.SansSerif)
                    Text("${state.totalBaggageWeightKg} kg (Locked)", color = HudCyan, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Cabin Ambient Lighting Themes
        Text(
            text = "CABIN AMBIENCE LIGHTING THEMES",
            color = HudMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            CabinLightingMode.entries.take(4).forEach { mode ->
                val isSelected = state.cabin.lightingTheme == mode
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) AeroElevated else AeroCardSurface)
                        .border(1.dp, if (isSelected) HudCyan else AeroBorder, RoundedCornerShape(4.dp))
                        .clickable { onSetCabinLighting(mode) }
                        .padding(vertical = 5.dp, horizontal = 2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = mode.displayName.split(" ").first(),
                        color = if (isSelected) HudCyan else HudWhite,
                        fontSize = 8.5.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
    }
}

@Composable
private fun PassengerSeatCard(seat: PassengerSeat, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(AeroCardSurface)
            .border(1.dp, AeroBorder, RoundedCornerShape(4.dp))
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = seat.seatId,
                color = HudCyan,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(if (seat.status == PassengerSeatStatus.SECURELY_BUCKLED) HudEmerald else HudAmber)
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = seat.passengerName.split(" ").first(),
            color = HudWhite,
            fontSize = 8.5.sp,
            fontFamily = FontFamily.SansSerif,
            maxLines = 1
        )
        Text(
            text = "${seat.baggageWeightKg}kg",
            color = HudMuted,
            fontSize = 7.5.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}
