package com.example.vtolos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.vtolos.core.model.FlightMode
import com.example.vtolos.ui.components.*
import com.example.vtolos.ui.viewmodel.CockpitTab
import com.example.vtolos.ui.viewmodel.VtolViewModel
import kotlin.math.abs

/**
 * Main Cockpit Screen for Anglo-Futuristic Passenger eVTOL (VTOL.OS).
 * Delivers an authoritative flight deck experience with high information density,
 * tactile aerospace typography, and supermodern British industrial computing aesthetics.
 */
@Composable
fun MainCockpitScreen(
    viewModel: VtolViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.aircraftState.collectAsState()
    val selectedTab by viewModel.selectedTab.collectAsState()
    val simSpeed by viewModel.simulationSpeed.collectAsState()
    val auditEvents by viewModel.recentAuditEvents.collectAsState()

    var showScenarioDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AeroBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("main_cockpit_screen")
    ) {
        // 1. Top Aerospace Cockpit Header
        AerospaceCockpitHeader(
            state = state,
            simSpeed = simSpeed,
            onSpeedChange = { viewModel.setSimulationSpeed(it) },
            onOpenScenarios = { showScenarioDialog = true }
        )

        Spacer(modifier = Modifier.height(4.dp))

        // 2. Horizontal Avionics Deck Tab Ribbon
        AvionicsTabRibbon(
            selectedTab = selectedTab,
            onSelectTab = { viewModel.selectTab(it) }
        )

        Spacer(modifier = Modifier.height(4.dp))

        // 3. Central Operational Display Area
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 8.dp)
        ) {
            when (selectedTab) {
                CockpitTab.PFD_AND_TRANSITION -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PrimaryFlightDisplay(
                            state = state,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(270.dp)
                        )
                        VtolTransitionPanel(
                            state = state,
                            onExecuteTransitionCruise = { viewModel.executeTransitionCruise() },
                            onExecuteTransitionHover = { viewModel.executeTransitionHover() },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                CockpitTab.TACTICAL_MAP -> {
                    UrbanSkywaysMap(
                        state = state,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                CockpitTab.PASSENGER_CABIN -> {
                    PassengerCabinDeck(
                        state = state,
                        onSetCabinLighting = { viewModel.setCabinLighting(it) },
                        onSetCabinTemperature = { viewModel.setCabinTemperature(it) },
                        onToggleDoors = { viewModel.toggleDoors() },
                        modifier = Modifier.fillMaxSize()
                    )
                }
                CockpitTab.ENERGY_SYSTEMS -> {
                    EnergyAndPowerDeck(
                        state = state,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                CockpitTab.HEALTH_AND_SAFETY -> {
                    SubsystemHealthAndVotingDeck(
                        state = state,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                CockpitTab.FAULT_INJECTION -> {
                    FaultInjectionDeck(
                        isMotorFaultActive = state.propulsionHealth != com.example.vtolos.core.model.HealthStatus.NOMINAL,
                        isGnssFaultActive = !state.sensorsReport.gnss1Healthy,
                        isMicroburstActive = state.windSpeedKts > 20f,
                        isCommsFaultActive = state.linkLatencyMs > 100,
                        isLowBatteryActive = state.battery.socPercent < 20f,
                        onToggleMotorFault = { viewModel.toggleMotorFault() },
                        onToggleGnssFault = { viewModel.toggleGnssFault() },
                        onToggleMicroburst = { viewModel.toggleMicroburst() },
                        onToggleCommsFault = { viewModel.toggleCommsFault() },
                        onToggleLowBattery = { viewModel.toggleLowBattery() },
                        onClearAllFaults = { viewModel.clearAllFaults() },
                        modifier = Modifier.fillMaxSize()
                    )
                }
                CockpitTab.BLACK_BOX_RECORDER -> {
                    FlightRecorderDeck(
                        events = auditEvents,
                        records = emptyList(),
                        modifier = Modifier.fillMaxSize()
                    )
                }
                CockpitTab.FLEET_COMMAND -> {
                    FleetConsoleDeck(modifier = Modifier.fillMaxSize())
                }
                CockpitTab.DEVELOPER_API -> {
                    DeveloperApiDeck(state = state, modifier = Modifier.fillMaxSize())
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // 4. Master Flight Command Bar (Bottom)
        MasterFlightCommandBar(
            flightMode = state.flightMode,
            onStartBoarding = { viewModel.startBoarding() },
            onCloseDoors = { viewModel.closeDoorsAndSecure() },
            onArmAndTakeoff = { viewModel.armAndTakeoff() },
            onTransitionCruise = { viewModel.executeTransitionCruise() },
            onTransitionHover = { viewModel.executeTransitionHover() },
            onLand = { viewModel.executeLanding() },
            onDivert = { viewModel.emergencyDivert() },
            onReset = { viewModel.resetSimulation() }
        )
    }

    // Scenario Launcher Dialog
    if (showScenarioDialog) {
        SignatureScenarioDialog(
            onDismiss = { showScenarioDialog = false },
            onSelectScenario1 = {
                viewModel.runDemo1FullPassengerFlight()
                showScenarioDialog = false
            },
            onSelectScenario2 = {
                viewModel.runDemo2MotorDegradation()
                showScenarioDialog = false
            },
            onSelectScenario3 = {
                viewModel.runDemo3UrbanMicroburst()
                showScenarioDialog = false
            },
            onSelectScenario4 = {
                viewModel.runDemo4EmergencyDivert()
                showScenarioDialog = false
            }
        )
    }
}

@Composable
private fun AerospaceCockpitHeader(
    state: com.example.vtolos.core.model.PassengerAircraftState,
    simSpeed: Float,
    onSpeedChange: (Float) -> Unit,
    onOpenScenarios: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(AeroGraphite)
            .border(1.dp, AeroBorder)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Aircraft Identity & Callsign
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "VTOL.OS",
                    color = HudCyan,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = state.callsign,
                    color = HudWhite,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = "${state.aircraftName} · ${state.aircraftType.displayName}",
                color = HudMuted,
                fontSize = 9.sp,
                fontFamily = FontFamily.SansSerif
            )
        }

        // Sim Speed & Scenario Selector Buttons
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Speed Chips (1x, 2x, 5x)
            listOf(1.0f, 2.0f, 5.0f).forEach { speed ->
                val isSelected = abs(simSpeed - speed) < 0.1f
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(if (isSelected) HudCyan else AeroCardSurface)
                        .border(1.dp, if (isSelected) HudCyan else AeroBorder, RoundedCornerShape(3.dp))
                        .clickable { onSpeedChange(speed) }
                        .padding(horizontal = 5.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "${speed.toInt()}x",
                        color = if (isSelected) AeroBlack else HudWhite,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Scenario Launcher Button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(AeroElevated)
                    .border(1.dp, HudAmber, RoundedCornerShape(4.dp))
                    .clickable { onOpenScenarios() }
                    .padding(horizontal = 6.dp, vertical = 3.dp)
                    .testTag("button_open_scenarios")
            ) {
                Text(
                    text = "SCENARIOS ⚙",
                    color = HudAmber,
                    fontSize = 9.5.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun AvionicsTabRibbon(
    selectedTab: CockpitTab,
    onSelectTab: (CockpitTab) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        CockpitTab.entries.forEach { tab ->
            val isSelected = selectedTab == tab
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (isSelected) AeroCardSurface else AeroPanelBg)
                    .border(1.dp, if (isSelected) HudCyan else AeroBorder, RoundedCornerShape(4.dp))
                    .clickable { onSelectTab(tab) }
                    .padding(horizontal = 8.dp, vertical = 5.dp)
                    .testTag("tab_${tab.name.lowercase()}")
            ) {
                Text(
                    text = tab.title,
                    color = if (isSelected) HudCyan else HudMuted,
                    fontSize = 9.5.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun MasterFlightCommandBar(
    flightMode: FlightMode,
    onStartBoarding: () -> Unit,
    onCloseDoors: () -> Unit,
    onArmAndTakeoff: () -> Unit,
    onTransitionCruise: () -> Unit,
    onTransitionHover: () -> Unit,
    onLand: () -> Unit,
    onDivert: () -> Unit,
    onReset: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(AeroGraphite)
            .border(1.dp, AeroBorder)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 6.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CommandButton("1. BOARD", onStartBoarding, HudWhite, "cmd_board")
        CommandButton("2. CLOSE DOORS", onCloseDoors, HudCyan, "cmd_doors")
        CommandButton("3. TAKEOFF", onArmAndTakeoff, HudEmerald, "cmd_takeoff")
        CommandButton("4. CRUISE (0°)", onTransitionCruise, HudCyan, "cmd_cruise")
        CommandButton("5. HOVER (90°)", onTransitionHover, HudAmber, "cmd_hover")
        CommandButton("6. LAND", onLand, HudEmerald, "cmd_land")
        CommandButton("DIVERT", onDivert, HudCrimson, "cmd_divert")
        CommandButton("RESET", onReset, HudMuted, "cmd_reset")
    }
}

@Composable
private fun CommandButton(
    label: String,
    onClick: () -> Unit,
    color: androidx.compose.ui.graphics.Color,
    tag: String
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(AeroCardSurface)
            .border(1.dp, color.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 6.dp)
            .testTag(tag)
    ) {
        Text(
            text = label,
            color = color,
            fontSize = 9.5.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun SignatureScenarioDialog(
    onDismiss: () -> Unit,
    onSelectScenario1: () -> Unit,
    onSelectScenario2: () -> Unit,
    onSelectScenario3: () -> Unit,
    onSelectScenario4: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AeroGraphite,
        title = {
            Text(
                text = "VTOL.OS SIGNATURE SCENARIO LAUNCHER",
                color = HudWhite,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ScenarioItem(
                    title = "SCENARIO 1: London Battersea to Heathrow T5 Express",
                    detail = "Complete autonomous passenger flight through Thames Skyway Corridor Alpha-10.",
                    onClick = onSelectScenario1
                )
                ScenarioItem(
                    title = "SCENARIO 2: Single Motor Failure & Differential DEP",
                    detail = "Injects 74% torque loss on Rotor #4; demonstrates automated rotor thrust compensation.",
                    onClick = onSelectScenario2
                )
                ScenarioItem(
                    title = "SCENARIO 3: Urban Wind Shear & Passenger G-Damping",
                    detail = "Injects 28.5 kt urban wind shear with real-time active cabin vibration suppression.",
                    onClick = onSelectScenario3
                )
                ScenarioItem(
                    title = "SCENARIO 4: Low Battery Reserve & Priority Vertipad Divert",
                    detail = "Simulates battery reserve threshold violation and auto-routes to Farnborough Vertigate.",
                    onClick = onSelectScenario4
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("CLOSE", color = HudMuted, fontFamily = FontFamily.Monospace)
            }
        }
    )
}

@Composable
private fun ScenarioItem(
    title: String,
    detail: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(AeroCardSurface)
            .border(1.dp, AeroBorder, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(8.dp)
    ) {
        Column {
            Text(text = title, color = HudCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = detail, color = HudMuted, fontSize = 9.sp, fontFamily = FontFamily.SansSerif)
        }
    }
}
