package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.vtolos.core.model.AircraftType
import com.example.vtolos.core.model.FlightMode
import com.example.vtolos.core.model.TransitionState
import com.example.vtolos.core.model.VertiportNetwork
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("VTOL.OS", appName)
    }

    @Test
    fun `verify standard passenger flight plan creation`() {
        val plan = VertiportNetwork.createStandardFlightPlan()
        assertEquals("EGLW-V", plan.origin.icaoCode)
        assertEquals("EGLL-V", plan.destination.icaoCode)
        assertEquals(5, plan.waypoints.size)
        assertEquals(4, plan.passengerCount)
    }

    @Test
    fun `verify conversion corridor state machine`() {
        assertEquals(90f, TransitionState.HOVER_LIFT.nacelleAngleDeg)
        assertEquals(0.0f, TransitionState.HOVER_LIFT.wingLiftRatio)
        assertEquals(0f, TransitionState.WING_BORNE_LOCKED.nacelleAngleDeg)
        assertEquals(1.0f, TransitionState.WING_BORNE_LOCKED.wingLiftRatio)
    }

    @Test
    fun `verify flight mode emergency identification`() {
        assertTrue(FlightMode.EMERGENCY.isEmergency)
        assertTrue(FlightMode.LOST_LINK.isEmergency)
        assertTrue(FlightMode.FAILSAFE.isEmergency)
    }
}
