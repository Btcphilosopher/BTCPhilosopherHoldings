package com.example.data.model

data class HouseholdProfile(
    val id: String,
    val name: String,
    val avatarColorHex: String,
    val isKidsMode: Boolean = false,
    val preferredQuality: QualityProfile = QualityProfile.AUTO_4K,
    val favoriteClubIds: Set<String> = emptySet(),
    val isCurrent: Boolean = false
)

data class ConnectedDevice(
    val id: String,
    val name: String,
    val type: String, // "Android TV (Living Room)", "Mobile (Pixel 9)", "Tablet", "Web Browser"
    val lastActive: String,
    val isCurrentDevice: Boolean = false,
    val maxConcurrentLimit: Int = 4
)

data class NotificationPreferences(
    val kickOffAlerts: Boolean = true,
    val goalAlerts: Boolean = true,
    val redCards: Boolean = true,
    val varDecisions: Boolean = true,
    val fullTimeScore: Boolean = true,
    val highlightsReady: Boolean = true,
    val quietHoursEnabled: Boolean = false,
    val quietHoursStart: String = "23:00",
    val quietHoursEnd: String = "07:00"
)

data class ContinueWatchingItem(
    val matchId: String,
    val title: String,
    val subtitle: String,
    val progressFraction: Float,
    val durationText: String
)
