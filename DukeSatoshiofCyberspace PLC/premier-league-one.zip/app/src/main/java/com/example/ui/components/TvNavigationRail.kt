package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppDestination

@Composable
fun TvNavigationRail(
    currentDestination: AppDestination,
    onNavigate: (AppDestination) -> Unit,
    onToggleTvMode: () -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationRail(
        modifier = modifier
            .fillMaxHeight()
            .testTag("tv_navigation_rail"),
        containerColor = PlDarkBackground,
        header = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(vertical = 16.dp)
            ) {
                Surface(
                    color = PlPurplePrimary,
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "PL 1",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "TV OS",
                    color = PlPitchGreen,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    ) {
        Column(
            modifier = Modifier.fillMaxHeight(),
            verticalArrangement = Arrangement.Center
        ) {
            mobileNavItems.forEach { item ->
                val isSelected = currentDestination == item.destination
                NavigationRailItem(
                    selected = isSelected,
                    onClick = { onNavigate(item.destination) },
                    icon = {
                        Icon(
                            imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                            contentDescription = item.label,
                            modifier = Modifier.size(24.dp)
                        )
                    },
                    label = {
                        Text(
                            text = item.label,
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationRailItemDefaults.colors(
                        selectedIconColor = PlPurpleNeon,
                        unselectedIconColor = PlTextSecondary,
                        selectedTextColor = PlPurpleNeon,
                        unselectedTextColor = PlTextSecondary,
                        indicatorColor = PlPurplePrimary
                    ),
                    modifier = Modifier
                        .padding(vertical = 4.dp)
                        .testTag("tv_nav_item_${item.destination.name.lowercase()}")
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            // TV Mode / Remote Helper Toggle
            IconButton(
                onClick = onToggleTvMode,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(bottom = 16.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Tv,
                    contentDescription = "Toggle TV Mode",
                    tint = PlPitchGreen
                )
            }
        }
    }
}
