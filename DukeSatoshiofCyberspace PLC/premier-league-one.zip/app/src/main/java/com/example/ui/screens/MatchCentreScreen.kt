package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.StreamPlayerView
import com.example.ui.components.TacticalPitchCanvas
import com.example.ui.theme.*
import com.example.ui.viewmodel.MatchCentreTab
import com.example.ui.viewmodel.TacticalLayer

@Composable
fun MatchCentreScreen(
    match: Match,
    selectedTab: MatchCentreTab,
    onSelectTab: (MatchCentreTab) -> Unit,
    // Player controls
    isPlaying: Boolean,
    onTogglePlayPause: () -> Unit,
    currentSeconds: Long,
    isLiveEdge: Boolean,
    onJumpLiveEdge: () -> Unit,
    onSeekRelative: (Long) -> Unit,
    telemetry: StreamTelemetry,
    showStatsForGeeks: Boolean,
    onToggleStatsForGeeks: () -> Unit,
    selectedQuality: QualityProfile,
    onSelectQuality: (QualityProfile) -> Unit,
    selectedAudio: AudioTrack,
    onSelectAudio: (AudioTrack) -> Unit,
    selectedSubtitle: SubtitleTrack,
    onSelectSubtitle: (SubtitleTrack) -> Unit,
    selectedCamera: CameraAngle,
    onSelectCamera: (CameraAngle) -> Unit,
    tacticalLayer: TacticalLayer,
    onSelectTacticalLayer: (TacticalLayer) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PlDarkBackground)
            .testTag("match_centre_screen")
    ) {
        // Top Match Stream Player
        StreamPlayerView(
            match = match,
            isPlaying = isPlaying,
            onTogglePlayPause = onTogglePlayPause,
            currentSeconds = currentSeconds,
            isLiveEdge = isLiveEdge,
            onJumpLiveEdge = onJumpLiveEdge,
            onSeekRelative = onSeekRelative,
            telemetry = telemetry,
            showStatsForGeeks = showStatsForGeeks,
            onToggleStatsForGeeks = onToggleStatsForGeeks,
            selectedQuality = selectedQuality,
            onSelectQuality = onSelectQuality,
            selectedAudio = selectedAudio,
            onSelectAudio = onSelectAudio,
            selectedSubtitle = selectedSubtitle,
            onSelectSubtitle = onSelectSubtitle,
            selectedCamera = selectedCamera,
            onSelectCamera = onSelectCamera,
            onClosePlayer = onBack
        )

        // Match Info Summary Strip
        Surface(
            color = PlSurfaceDeep,
            border = androidx.compose.foundation.BorderStroke(1.dp, PlBorderSubtle)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack, modifier = Modifier.size(28.dp).testTag("match_centre_back_btn")) {
                        Icon(Icons.Default.ArrowBack, "Back", tint = PlTextPrimary)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = "${match.homeClub.name} vs ${match.awayClub.name}",
                            color = PlTextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${match.broadcasterName} • ${match.stadium}",
                            color = PlTextTertiary,
                            fontSize = 11.sp
                        )
                    }
                }

                Surface(
                    color = PlLiveRed,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "LIVE ${match.minute}'",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
        }

        // Sub-tabs Scrollable Bar: WATCH | COMMENTARY | STATS | LINE-UPS | TACTICS | EVENTS | H2H
        ScrollableTabRow(
            selectedTabIndex = selectedTab.ordinal,
            containerColor = PlDarkBackground,
            contentColor = PlPurpleNeon,
            edgePadding = 12.dp,
            divider = { Divider(color = PlBorderSubtle) }
        ) {
            MatchCentreTab.values().forEach { tab ->
                val isSelected = selectedTab == tab
                Tab(
                    selected = isSelected,
                    onClick = { onSelectTab(tab) },
                    text = {
                        Text(
                            text = tab.label,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) PlPurpleNeon else PlTextSecondary
                        )
                    },
                    modifier = Modifier.testTag("match_tab_${tab.name.lowercase()}")
                )
            }
        }

        // Tab Content
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (selectedTab) {
                MatchCentreTab.WATCH -> {
                    MatchWatchOverview(match = match)
                }
                MatchCentreTab.COMMENTARY -> {
                    MatchCommentaryList(match = match)
                }
                MatchCentreTab.STATS -> {
                    MatchStatsComparison(match = match)
                }
                MatchCentreTab.LINE_UPS -> {
                    MatchLineupsView(match = match)
                }
                MatchCentreTab.TACTICS -> {
                    MatchTacticsView(
                        match = match,
                        layer = tacticalLayer,
                        onSelectLayer = onSelectTacticalLayer
                    )
                }
                MatchCentreTab.EVENTS -> {
                    MatchEventsTimeline(match = match)
                }
                MatchCentreTab.HEAD_TO_HEAD -> {
                    MatchHeadToHead(match = match)
                }
            }
        }
    }
}

@Composable
fun MatchWatchOverview(match: Match) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 60.dp)
    ) {
        // Quick In-Match xG & Possession Bar
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = PlSurfaceDeep),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PlBorderSubtle)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "LIVE MATCH MOMENTUM",
                        color = PlTextTertiary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${match.homeClub.code} ${match.homeStats.possessionPercentage}%",
                            color = PlPitchGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(text = "Possession", color = PlTextSecondary, fontSize = 11.sp)
                        Text(
                            text = "${match.awayStats.possessionPercentage}% ${match.awayClub.code}",
                            color = Pl4kCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { match.homeStats.possessionPercentage / 100f },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                        color = PlPitchGreen,
                        trackColor = Pl4kCyan
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${match.homeStats.expectedGoals} xG",
                            color = PlPitchGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(text = "Expected Goals (xG)", color = PlTextSecondary, fontSize = 11.sp)
                        Text(
                            text = "${match.awayStats.expectedGoals} xG",
                            color = Pl4kCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Recent Key Events in Match
        item {
            Text(
                text = "MATCH HIGHLIGHT MOMENTS",
                color = PlTextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        items(match.events) { ev ->
            Surface(
                color = PlSurfaceDeep,
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PlBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = when (ev.type) {
                            EventType.GOAL -> PlPitchGreen
                            EventType.YELLOW_CARD -> PlScoreAmber
                            EventType.RED_CARD -> PlLiveRed
                            EventType.VAR_REVIEW -> PlPurpleAccent
                            else -> PlTextSecondary
                        },
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "${ev.minute}'",
                            color = Color.Black,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${ev.type.name.replace("_", " ")}: ${ev.playerPrimary}",
                            color = PlTextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = ev.detail,
                            color = PlTextSecondary,
                            fontSize = 11.sp
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.PlayCircle,
                        contentDescription = "Replay Event",
                        tint = PlPurpleNeon,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun MatchCommentaryList(match: Match) {
    val commentaryFeed = listOf(
        Pair(74, "Michael Oliver halts play for a brief injury check. Both managers delivering tactical instructions on the touchline."),
        Pair(71, "CHANCE! Phil Foden strikes from the edge of the area, but Gabriel blocks courageously."),
        Pair(67, "GOAL ARSENAL! Bukayo Saka steps up and coolly places the spot-kick into the top right corner! (2-1)"),
        Pair(65, "VAR OVERTURN: After pitchside monitor review, a penalty is officially awarded for handball."),
        Pair(52, "GOAL MANCHESTER CITY! Kevin De Bruyne swings in an immaculate cross for Erling Haaland to head home from 6 yards! (1-1)"),
        Pair(45, "Three minutes of added time announced for the first half."),
        Pair(38, "YELLOW CARD: Rúben Dias booked for pulling back Havertz on a promising breakaway."),
        Pair(14, "GOAL ARSENAL! Bukayo Saka cuts inside on his left foot and unleashes a thunderbolt into the far corner! (1-0)")
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 60.dp)
    ) {
        items(commentaryFeed) { (minute, text) ->
            Surface(
                color = PlSurfaceDeep,
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PlBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "$minute'",
                        color = PlPitchGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.width(36.dp)
                    )
                    Text(
                        text = text,
                        color = PlTextPrimary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
fun MatchStatsComparison(match: Match) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 60.dp)
    ) {
        item {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(match.homeClub.name, color = PlPitchGreen, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text("MATCH STATISTICS", color = PlTextTertiary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(match.awayClub.name, color = Pl4kCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
        }

        item {
            StatBarRow("Possession", "${match.homeStats.possessionPercentage}%", "${match.awayStats.possessionPercentage}%", match.homeStats.possessionPercentage, 100)
        }
        item {
            StatBarRow("Total Shots", "${match.homeStats.shots}", "${match.awayStats.shots}", match.homeStats.shots, 25)
        }
        item {
            StatBarRow("Shots on Target", "${match.homeStats.shotsOnTarget}", "${match.awayStats.shotsOnTarget}", match.homeStats.shotsOnTarget, 15)
        }
        item {
            StatBarRow("Expected Goals (xG)", "${match.homeStats.expectedGoals}", "${match.awayStats.expectedGoals}", (match.homeStats.expectedGoals * 10).toInt(), 40)
        }
        item {
            StatBarRow("Pass Accuracy", "${match.homeStats.passAccuracyPercentage}%", "${match.awayStats.passAccuracyPercentage}%", match.homeStats.passAccuracyPercentage, 100)
        }
        item {
            StatBarRow("Corners", "${match.homeStats.corners}", "${match.awayStats.corners}", match.homeStats.corners, 12)
        }
        item {
            StatBarRow("Fouls", "${match.homeStats.fouls}", "${match.awayStats.fouls}", match.homeStats.fouls, 20)
        }
        item {
            StatBarRow("Yellow Cards", "${match.homeStats.yellowCards}", "${match.awayStats.yellowCards}", match.homeStats.yellowCards, 6)
        }
        item {
            StatBarRow("Field Tilt %", "${match.homeStats.fieldTiltPercentage}%", "${match.awayStats.fieldTiltPercentage}%", match.homeStats.fieldTiltPercentage, 100)
        }
        item {
            StatBarRow("Pressing PPDA", "${match.homeStats.ppda}", "${match.awayStats.ppda}", 50, 100)
        }
    }
}

@Composable
fun StatBarRow(
    label: String,
    homeValue: String,
    awayValue: String,
    homeProgress: Int,
    maxVal: Int
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(homeValue, color = PlTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(label, color = PlTextSecondary, fontSize = 11.sp)
            Text(awayValue, color = PlTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(4.dp))
        val ratio = (homeProgress.toFloat() / maxVal.coerceAtLeast(1).toFloat()).coerceIn(0.05f, 0.95f)
        LinearProgressIndicator(
            progress = { ratio },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
            color = PlPitchGreen,
            trackColor = Pl4kCyan
        )
    }
}

@Composable
fun MatchLineupsView(match: Match) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 60.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(match.homeClub.name, color = PlPitchGreen, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("Formation: ${match.homeFormation.formationName}", color = PlTextTertiary, fontSize = 11.sp)
                    Text("Manager: ${match.homeClub.manager}", color = PlTextSecondary, fontSize = 11.sp)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(match.awayClub.name, color = Pl4kCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("Formation: ${match.awayFormation.formationName}", color = PlTextTertiary, fontSize = 11.sp)
                    Text("Manager: ${match.awayClub.manager}", color = PlTextSecondary, fontSize = 11.sp)
                }
            }
        }

        item {
            Text("STARTING XI (KEY PLAYERS)", color = PlTextTertiary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        item {
            LineupPlayerRow(number = 7, name = "Bukayo Saka", pos = "RW • 8.4 Rating", isHome = true)
        }
        item {
            LineupPlayerRow(number = 41, name = "Declan Rice", pos = "CM • 7.8 Rating", isHome = true)
        }
        item {
            LineupPlayerRow(number = 2, name = "William Saliba", pos = "CB • 7.8 Rating", isHome = true)
        }
        item {
            LineupPlayerRow(number = 9, name = "Erling Haaland", pos = "ST • 8.1 Rating", isHome = false)
        }
        item {
            LineupPlayerRow(number = 17, name = "Kevin De Bruyne", pos = "AM • 7.9 Rating", isHome = false)
        }
        item {
            LineupPlayerRow(number = 47, name = "Phil Foden", pos = "LW • 7.7 Rating", isHome = false)
        }
    }
}

@Composable
fun LineupPlayerRow(number: Int, name: String, pos: String, isHome: Boolean) {
    Surface(
        color = PlSurfaceDeep,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, PlBorderSubtle),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = if (isHome) PlPitchGreenDark else PlPurplePrimary,
                    shape = CircleShape
                ) {
                    Text(
                        text = "$number",
                        color = if (isHome) PlPitchGreen else PlPurpleNeon,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(name, color = PlTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(pos, color = PlTextSecondary, fontSize = 11.sp)
                }
            }

            Surface(
                color = PlSurfaceHighlight,
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    text = if (isHome) "HOME" else "AWAY",
                    color = PlTextTertiary,
                    fontSize = 10.sp,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }
    }
}

@Composable
fun MatchTacticsView(
    match: Match,
    layer: TacticalLayer,
    onSelectLayer: (TacticalLayer) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Layer Selector Pills
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            TacticalLayer.values().forEach { l ->
                val isSelected = (layer == l)
                Surface(
                    color = if (isSelected) PlPurplePrimary else PlSurfaceDeep,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) PlPurpleNeon else PlBorderSubtle
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .clickable { onSelectLayer(l) }
                        .weight(1f)
                ) {
                    Text(
                        text = when (l) {
                            TacticalLayer.SHOT_MAP -> "Shot Map"
                            TacticalLayer.PASS_NETWORK -> "Passing"
                            TacticalLayer.PRESSING_TILT -> "Tilt & PPDA"
                            TacticalLayer.FORMATIONS -> "Formations"
                        },
                        color = if (isSelected) Color.White else PlTextSecondary,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.padding(vertical = 6.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        }

        // Render Pitch Canvas
        TacticalPitchCanvas(
            match = match,
            layer = layer
        )
    }
}

@Composable
fun MatchEventsTimeline(match: Match) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 60.dp)
    ) {
        items(match.events) { ev ->
            Surface(
                color = PlSurfaceDeep,
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PlBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${ev.minute}'",
                                color = PlPitchGreen,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = ev.type.name.replace("_", " "),
                                color = PlPurpleNeon,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            color = PlSurfaceHighlight,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "VERIFIED EVENT",
                                color = Pl4kCyan,
                                fontSize = 9.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = ev.playerPrimary + (ev.playerSecondary?.let { " (Assist: $it)" } ?: ""),
                        color = PlTextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = ev.detail,
                        color = PlTextSecondary,
                        fontSize = 11.sp
                    )

                    ev.varVerdict?.let { verdict ->
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            color = PlPurplePrimary,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "VAR OFFICIAL VERDICT: $verdict",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MatchHeadToHead(match: Match) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 60.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = PlSurfaceDeep),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PlBorderSubtle)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "HISTORICAL PREMIER LEAGUE RECORD",
                        color = PlTextTertiary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${match.homeClub.shortName} Wins", color = PlTextSecondary, fontSize = 11.sp)
                            Text("24", color = PlPitchGreen, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Draws", color = PlTextSecondary, fontSize = 11.sp)
                            Text("11", color = PlTextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${match.awayClub.shortName} Wins", color = PlTextSecondary, fontSize = 11.sp)
                            Text("19", color = Pl4kCyan, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Text("RECENT PREMIER LEAGUE ENCOUNTERS", color = PlTextTertiary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        item {
            H2hEncounterRow(date = "31 Mar 2024", score = "MCI 0 - 0 ARS", comp = "Premier League")
        }
        item {
            H2hEncounterRow(date = "08 Oct 2023", score = "ARS 1 - 0 MCI", comp = "Premier League (Martinelli 86')")
        }
        item {
            H2hEncounterRow(date = "26 Apr 2023", score = "MCI 4 - 1 ARS", comp = "Premier League")
        }
    }
}

@Composable
fun H2hEncounterRow(date: String, score: String, comp: String) {
    Surface(
        color = PlSurfaceDeep,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, PlBorderSubtle),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(score, color = PlTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(comp, color = PlTextSecondary, fontSize = 11.sp)
            }
            Text(date, color = PlTextTertiary, fontSize = 11.sp)
        }
    }
}
