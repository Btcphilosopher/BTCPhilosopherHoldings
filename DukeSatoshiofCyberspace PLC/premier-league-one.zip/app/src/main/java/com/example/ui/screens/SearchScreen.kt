package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Club
import com.example.data.model.EditorialHighlight
import com.example.data.model.Match
import com.example.data.model.Player
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppDestination
import com.example.ui.viewmodel.MatchCentreTab

@Composable
fun SearchScreen(
    searchQuery: String,
    onQueryChange: (String) -> Unit,
    matches: List<Match>,
    clubs: List<Club>,
    players: List<Player>,
    highlights: List<EditorialHighlight>,
    onSelectMatch: (String, MatchCentreTab) -> Unit,
    onSelectClub: (String) -> Unit,
    onNavigate: (AppDestination) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val q = searchQuery.trim().lowercase()

    val matchedClubs = if (q.isEmpty()) emptyList() else clubs.filter {
        it.name.lowercase().contains(q) || it.shortName.lowercase().contains(q) || it.code.lowercase().contains(q)
    }

    val matchedPlayers = if (q.isEmpty()) emptyList() else players.filter {
        it.name.lowercase().contains(q) || it.position.lowercase().contains(q)
    }

    val matchedMatches = if (q.isEmpty()) emptyList() else matches.filter {
        it.homeClub.name.lowercase().contains(q) || it.awayClub.name.lowercase().contains(q) || it.stadium.lowercase().contains(q)
    }

    val matchedHighlights = if (q.isEmpty()) emptyList() else highlights.filter {
        it.title.lowercase().contains(q) || it.category.lowercase().contains(q)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(PlDarkBackground)
            .testTag("search_screen"),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Search Input Top Bar
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(32.dp).testTag("search_back_btn")) {
                    Icon(Icons.Default.ArrowBack, "Back", tint = PlTextPrimary)
                }
                Spacer(modifier = Modifier.width(8.dp))

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onQueryChange,
                    placeholder = { Text("Search matches, clubs, players, tactics...", color = PlTextTertiary, fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, "Search", tint = PlTextSecondary) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onQueryChange("") }) {
                                Icon(Icons.Default.Close, "Clear", tint = PlTextSecondary)
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PlPurpleAccent,
                        unfocusedBorderColor = PlBorderSubtle,
                        focusedTextColor = PlTextPrimary,
                        unfocusedTextColor = PlTextPrimary,
                        cursorColor = PlPitchGreen
                    ),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_input_field")
                )
            }
        }

        if (q.isEmpty()) {
            item {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("POPULAR SEARCHES", color = PlTextTertiary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    listOf("Arsenal vs Man City", "Erling Haaland xG", "Liverpool Pressing", "Bukayo Saka", "Weekend Review").forEach { suggestion ->
                        Surface(
                            color = PlSurfaceDeep,
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, PlBorderSubtle),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable { onQueryChange(suggestion) }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Search, "Search", tint = PlPurpleNeon, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(suggestion, color = PlTextPrimary, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        } else {
            // Matched Clubs
            if (matchedClubs.isNotEmpty()) {
                item {
                    Text("CLUBS", color = PlTextTertiary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                }
                items(matchedClubs) { club ->
                    Surface(
                        color = PlSurfaceDeep,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .clickable {
                                onSelectClub(club.id)
                                onNavigate(AppDestination.CLUBS)
                            }
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(club.name, color = PlTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Pos #${club.position} • ${club.points} pts", color = PlTextTertiary, fontSize = 11.sp)
                        }
                    }
                }
            }

            // Matched Players
            if (matchedPlayers.isNotEmpty()) {
                item {
                    Text("PLAYERS", color = PlTextTertiary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                }
                items(matchedPlayers) { pl ->
                    Surface(
                        color = PlSurfaceDeep,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .clickable {
                                onNavigate(AppDestination.TACTICAL_STUDIO)
                            }
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(pl.name, color = PlTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("${pl.position} • #${pl.shirtNumber} • ${pl.clubId.uppercase()} • ${pl.goals} Goals", color = PlTextTertiary, fontSize = 11.sp)
                        }
                    }
                }
            }

            // Matched Matches
            if (matchedMatches.isNotEmpty()) {
                item {
                    Text("MATCHES", color = PlTextTertiary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                }
                items(matchedMatches) { m ->
                    Surface(
                        color = PlSurfaceDeep,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .clickable { onSelectMatch(m.id, MatchCentreTab.WATCH) }
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${m.homeClub.name} vs ${m.awayClub.name}", color = PlTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(m.formattedTime, color = PlPitchGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Matched Highlights
            if (matchedHighlights.isNotEmpty()) {
                item {
                    Text("REPLAYS & HIGHLIGHTS", color = PlTextTertiary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                }
                items(matchedHighlights) { hl ->
                    Surface(
                        color = PlSurfaceDeep,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .clickable { onNavigate(AppDestination.HIGHLIGHTS) }
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(hl.title, color = PlTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(hl.category, color = PlPurpleNeon, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}
