package com.example.data.model

import java.time.LocalDateTime

enum class MatchStatus {
    SCHEDULED,
    WARMUP,
    LIVE_FIRST_HALF,
    HALF_TIME,
    LIVE_SECOND_HALF,
    EXTRA_TIME,
    FULL_TIME
}

enum class EventType {
    MATCH_STARTED,
    GOAL,
    OWN_GOAL,
    PENALTY_AWARDED,
    PENALTY_SCORED,
    PENALTY_MISSED,
    YELLOW_CARD,
    RED_CARD,
    SUBSTITUTION,
    VAR_REVIEW,
    HALF_TIME,
    FULL_TIME
}

data class Club(
    val id: String,
    val name: String,
    val shortName: String,
    val code: String,
    val primaryColorHex: String,
    val secondaryColorHex: String,
    val stadium: String,
    val capacity: Int,
    val manager: String,
    val position: Int,
    val played: Int,
    val won: Int,
    val drawn: Int,
    val lost: Int,
    val goalsFor: Int,
    val goalsAgainst: Int,
    val points: Int,
    val form: List<String> = listOf("W", "W", "D", "W", "L"),
    val isFavorite: Boolean = false
) {
    val goalDifference: Int get() = goalsFor - goalsAgainst
}

data class MatchEvent(
    val id: String,
    val minute: Int,
    val addedMinute: Int = 0,
    val type: EventType,
    val clubId: String,
    val playerPrimary: String,
    val playerSecondary: String? = null,
    val detail: String,
    val varVerdict: String? = null,
    val videoClipTimestampSeconds: Long = 0L
)

data class TeamStats(
    val possessionPercentage: Int,
    val shots: Int,
    val shotsOnTarget: Int,
    val expectedGoals: Double,
    val corners: Int,
    val fouls: Int,
    val yellowCards: Int,
    val redCards: Int,
    val offsides: Int,
    val passesCompleted: Int,
    val passAccuracyPercentage: Int,
    val fieldTiltPercentage: Int = 50,
    val ppda: Double = 10.4 // Passes Per Defensive Action (Pressing intensity)
)

data class Player(
    val id: String,
    val name: String,
    val shirtNumber: Int,
    val position: String, // GK, DEF, MID, FWD
    val nationality: String,
    val clubId: String,
    val appearances: Int = 0,
    val minutesPlayed: Int = 0,
    val goals: Int = 0,
    val assists: Int = 0,
    val expectedGoals: Double = 0.0,
    val expectedAssists: Double = 0.0,
    val passAccuracy: Int = 0,
    val tacklesWon: Int = 0,
    val duelsWonPercentage: Int = 0,
    val rating: Double = 7.5,
    val isStarter: Boolean = true
)

data class TacticalFormation(
    val formationName: String, // e.g. "4-3-3", "4-2-3-1"
    val starters: List<PlayerNode>
)

data class PlayerNode(
    val player: Player,
    val normalizedX: Float, // 0.0 (left) to 1.0 (right)
    val normalizedY: Float  // 0.0 (defensive) to 1.0 (attacking)
)

data class ShotData(
    val id: String,
    val x: Float, // Pitch coords: 0.0 to 1.0
    val y: Float,
    val xG: Double,
    val outcome: String, // "Goal", "Saved", "Blocked", "Missed"
    val shooter: String,
    val minute: Int,
    val isHomeTeam: Boolean
)

data class PassLink(
    val fromPlayerId: String,
    val toPlayerId: String,
    val passCount: Int,
    val isHomeTeam: Boolean
)

data class Match(
    val id: String,
    val homeClub: Club,
    val awayClub: Club,
    val homeScore: Int,
    val awayScore: Int,
    val status: MatchStatus,
    val minute: Int,
    val addedTime: Int = 0,
    val matchweek: Int,
    val kickOffTime: String,
    val stadium: String,
    val referee: String,
    val broadcasterName: String, // "Sky Sports Main Event", "TNT Sports 1", "Prime Video", "Peacock 4K"
    val is4kAvailable: Boolean = true,
    val isHdrAvailable: Boolean = true,
    val streamBitrateMbps: Double = 24.5,
    val events: List<MatchEvent> = emptyList(),
    val homeStats: TeamStats,
    val awayStats: TeamStats,
    val homeFormation: TacticalFormation,
    val awayFormation: TacticalFormation,
    val shotMap: List<ShotData> = emptyList(),
    val passLinks: List<PassLink> = emptyList(),
    val isDemoData: Boolean = true
) {
    val isLive: Boolean
        get() = status == MatchStatus.LIVE_FIRST_HALF ||
                status == MatchStatus.HALF_TIME ||
                status == MatchStatus.LIVE_SECOND_HALF ||
                status == MatchStatus.EXTRA_TIME

    val formattedTime: String
        get() = when (status) {
            MatchStatus.SCHEDULED -> kickOffTime
            MatchStatus.WARMUP -> "WARMUP"
            MatchStatus.LIVE_FIRST_HALF -> if (addedTime > 0) "$minute'+$addedTime" else "$minute'"
            MatchStatus.HALF_TIME -> "HALF TIME"
            MatchStatus.LIVE_SECOND_HALF -> if (addedTime > 0) "$minute'+$addedTime" else "$minute'"
            MatchStatus.EXTRA_TIME -> "ET $minute'"
            MatchStatus.FULL_TIME -> "FULL TIME"
        }
}
