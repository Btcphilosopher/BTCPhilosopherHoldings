package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Broadcast Midnight & Stadium Palette
val PlDarkBackground = Color(0xFF060912)
val PlSurfaceDeep = Color(0xFF0D1222)
val PlSurfaceElevated = Color(0xFF151C33)
val PlSurfaceHighlight = Color(0xFF1E2849)
val PlBorderSubtle = Color(0xFF263256)

// Iconic Premier League Branding
val PlPurplePrimary = Color(0xFF4A0E4E)
val PlPurpleAccent = Color(0xFFB14AED)
val PlPurpleNeon = Color(0xFFD67BFF)

// Stadium Green
val PlPitchGreen = Color(0xFF00E676)
val PlPitchGreenDark = Color(0xFF004D27)

// Telemetry & Broadcast Accents
val Pl4kCyan = Color(0xFF00E5FF)
val PlLiveRed = Color(0xFFFF1744)
val PlScoreAmber = Color(0xFFFFC400)

// Text Hierarchy
val PlTextPrimary = Color(0xFFF7F8FC)
val PlTextSecondary = Color(0xFFA6B0C6)
val PlTextTertiary = Color(0xFF68748F)
