package com.example.data.model

data class ConnectedProvider(
    val id: String,
    val name: String,
    val territory: String,
    val isConnected: Boolean,
    val subscriptionTier: String, // e.g. "4K UHD Sports Pass", "Premier Broadcast Elite"
    val renewalDate: String,
    val concurrentStreamsAllowed: Int = 4,
    val activeStreamsCount: Int = 1,
    val iconName: String
)

data class ContentRights(
    val contentId: String,
    val title: String,
    val territory: String, // "GB", "US", "AU", "GLOBAL"
    val isLicensed: Boolean,
    val validFrom: String,
    val validUntil: String,
    val permittedResolution: String, // "2160p 4K HDR", "1080p 60fps"
    val permittedDevices: List<String>,
    val providerName: String,
    val licenseReference: String,
    val isDemoModeActive: Boolean = true
)

data class EditorialHighlight(
    val id: String,
    val title: String,
    val subtitle: String,
    val durationMinutes: Int,
    val matchweek: Int,
    val category: String, // "Extended Highlights", "Tactical Masterclass", "Weekend Review", "Goals of the Round"
    val resolutionBadge: String, // "4K UHD", "1080p HDR"
    val thumbnailGradientHex: Pair<String, String>,
    val homeClubCode: String,
    val awayClubCode: String,
    val chapters: List<VideoChapter>
)

data class VideoChapter(
    val title: String,
    val timestampSeconds: Long,
    val eventType: EventType? = null
)
