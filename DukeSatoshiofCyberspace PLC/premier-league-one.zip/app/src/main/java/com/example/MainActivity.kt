package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.MobileBottomBar
import com.example.ui.components.TvNavigationRail
import com.example.ui.screens.*
import com.example.ui.theme.PlDarkBackground
import com.example.ui.theme.PremierLeagueOneTheme
import com.example.ui.viewmodel.AppDestination
import com.example.ui.viewmodel.PremierLeagueViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: PremierLeagueViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val context = LocalContext.current
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            val clubs by viewModel.clubs.collectAsStateWithLifecycle()
            val matches by viewModel.matches.collectAsStateWithLifecycle()
            val favoriteClubIds by viewModel.favoriteClubIds.collectAsStateWithLifecycle()

            // Handle back presses
            BackHandler(enabled = true) {
                val handled = viewModel.handleBackPress()
                if (!handled) {
                    finish()
                }
            }

            // Notification toast trigger
            LaunchedEffect(uiState.userNotificationToast) {
                uiState.userNotificationToast?.let { msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    viewModel.clearNotificationToast()
                }
            }

            PremierLeagueOneTheme {
                val currentMatch = viewModel.getSelectedMatch()

                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(PlDarkBackground),
                    color = PlDarkBackground
                ) {
                    if (uiState.isTvMode) {
                        // TV / Large-screen Layout: TV Navigation Rail on left
                        Row(modifier = Modifier.fillMaxSize()) {
                            TvNavigationRail(
                                currentDestination = uiState.currentDestination,
                                onNavigate = { viewModel.navigateTo(it) },
                                onToggleTvMode = { viewModel.toggleTvMode() }
                            )

                            Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                                AppContentSwitcher(
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    currentMatch = currentMatch,
                                    matches = matches,
                                    clubs = clubs,
                                    favoriteClubIds = favoriteClubIds
                                )
                            }
                        }
                    } else {
                        // Mobile / Handheld Layout: Bottom Navigation Bar
                        Scaffold(
                            modifier = Modifier
                                .fillMaxSize()
                                .testTag("main_scaffold"),
                            containerColor = PlDarkBackground,
                            contentWindowInsets = WindowInsets.safeDrawing,
                            bottomBar = {
                                MobileBottomBar(
                                    currentDestination = uiState.currentDestination,
                                    onNavigate = { viewModel.navigateTo(it) }
                                )
                            }
                        ) { innerPadding ->
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(innerPadding)
                            ) {
                                AppContentSwitcher(
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    currentMatch = currentMatch,
                                    matches = matches,
                                    clubs = clubs,
                                    favoriteClubIds = favoriteClubIds
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AppContentSwitcher(
    uiState: com.example.ui.viewmodel.UiState,
    viewModel: PremierLeagueViewModel,
    currentMatch: com.example.data.model.Match,
    matches: List<com.example.data.model.Match>,
    clubs: List<com.example.data.model.Club>,
    favoriteClubIds: Set<String>
) {
    when (uiState.currentDestination) {
        AppDestination.HOME -> {
            HomeScreen(
                featuredMatch = matches.firstOrNull() ?: currentMatch,
                liveMatches = matches,
                clubs = clubs,
                favoriteClubIds = favoriteClubIds,
                highlights = viewModel.highlights,
                isTvMode = uiState.isTvMode,
                onToggleTvMode = { viewModel.toggleTvMode() },
                onSelectMatch = { id, tab -> viewModel.selectMatch(id, tab) },
                onNavigate = { viewModel.navigateTo(it) },
                onToggleFavoriteClub = { viewModel.toggleFavoriteClub(it) },
                isDemoBannerVisible = uiState.isDemoBannerVisible,
                onDismissDemoBanner = { viewModel.dismissDemoBanner() }
            )
        }
        AppDestination.MATCH_CENTRE -> {
            MatchCentreScreen(
                match = currentMatch,
                selectedTab = uiState.matchCentreTab,
                onSelectTab = { viewModel.selectMatchCentreTab(it) },
                isPlaying = uiState.isPlaying,
                onTogglePlayPause = { viewModel.togglePlayPause() },
                currentSeconds = uiState.playerCurrentSeconds,
                isLiveEdge = uiState.isLiveEdge,
                onJumpLiveEdge = { viewModel.jumpToLiveEdge() },
                onSeekRelative = { viewModel.seekRelative(it) },
                telemetry = uiState.telemetry,
                showStatsForGeeks = uiState.showStatsForGeeks,
                onToggleStatsForGeeks = { viewModel.toggleStatsForGeeks() },
                selectedQuality = uiState.selectedQuality,
                onSelectQuality = { viewModel.setQuality(it) },
                selectedAudio = uiState.selectedAudio,
                onSelectAudio = { viewModel.setAudioTrack(it) },
                selectedSubtitle = uiState.selectedSubtitle,
                onSelectSubtitle = { viewModel.setSubtitle(it) },
                selectedCamera = uiState.selectedCamera,
                onSelectCamera = { viewModel.setCameraAngle(it) },
                tacticalLayer = uiState.tacticalLayer,
                onSelectTacticalLayer = { viewModel.setTacticalLayer(it) },
                onBack = { viewModel.navigateTo(AppDestination.HOME) }
            )
        }
        AppDestination.MULTI_VIEW -> {
            MultiViewScreen(
                matches = matches,
                layout = uiState.multiViewLayout,
                onSelectLayout = { viewModel.setMultiViewLayout(it) },
                audioFocusMatchId = uiState.multiViewAudioFocusMatchId,
                onSelectAudioFocus = { viewModel.setMultiViewAudioFocus(it) },
                onSelectMatch = { viewModel.selectMatch(it) },
                goalFlashAlert = uiState.goalFlashAlert,
                onSwitchToGoalingMatch = { viewModel.switchToGoalingMatch() },
                onDismissGoalFlash = { viewModel.dismissGoalFlash() },
                onBack = { viewModel.navigateTo(AppDestination.HOME) }
            )
        }
        AppDestination.TACTICAL_STUDIO -> {
            TacticalStudioScreen(
                match = currentMatch,
                tacticalLayer = uiState.tacticalLayer,
                onSelectTacticalLayer = { viewModel.setTacticalLayer(it) },
                allPlayers = viewModel.getAllPlayers(),
                playerAId = uiState.selectedPlayerComparisonA,
                playerBId = uiState.selectedPlayerComparisonB,
                onSelectPlayerA = { viewModel.setPlayerComparison(it, uiState.selectedPlayerComparisonB) },
                onSelectPlayerB = { viewModel.setPlayerComparison(uiState.selectedPlayerComparisonA, it) }
            )
        }
        AppDestination.FIXTURES -> {
            FixturesScreen(
                matches = matches,
                clubs = clubs,
                selectedMatchweek = uiState.selectedMatchweek,
                onSelectMatchweek = { viewModel.setMatchweek(it) },
                selectedClubFilter = uiState.fixtureClubFilter,
                onSelectClubFilter = { viewModel.setFixtureClubFilter(it) },
                onSelectMatch = { id, tab -> viewModel.selectMatch(id, tab) },
                onSetReminderToast = { viewModel.clearNotificationToast() }
            )
        }
        AppDestination.CLUBS -> {
            ClubsScreen(
                clubs = clubs,
                favoriteClubIds = favoriteClubIds,
                onToggleFavoriteClub = { viewModel.toggleFavoriteClub(it) },
                selectedClubDetailId = uiState.selectedClubDetailId,
                onSelectClubDetail = { viewModel.selectClubDetail(it) }
            )
        }
        AppDestination.HIGHLIGHTS -> {
            HighlightsScreen(
                highlights = viewModel.highlights,
                onSelectHighlightToast = { viewModel.clearNotificationToast() }
            )
        }
        AppDestination.RIGHTS -> {
            BroadcasterRightsScreen(
                providers = viewModel.connectedProviders,
                onShowToast = { viewModel.clearNotificationToast() }
            )
        }
        AppDestination.PROFILE -> {
            ProfileSettingsScreen(
                onNavigate = { viewModel.navigateTo(it) },
                onShowToast = { viewModel.clearNotificationToast() }
            )
        }
        AppDestination.SEARCH -> {
            SearchScreen(
                searchQuery = uiState.searchQuery,
                onQueryChange = { viewModel.setSearchQuery(it) },
                matches = matches,
                clubs = clubs,
                players = viewModel.getAllPlayers(),
                highlights = viewModel.highlights,
                onSelectMatch = { id, tab -> viewModel.selectMatch(id, tab) },
                onSelectClub = { viewModel.selectClubDetail(it) },
                onNavigate = { viewModel.navigateTo(it) },
                onBack = { viewModel.navigateTo(AppDestination.HOME) }
            )
        }
    }
}
