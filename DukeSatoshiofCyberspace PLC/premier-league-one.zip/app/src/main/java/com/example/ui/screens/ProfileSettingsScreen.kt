package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppDestination

@Composable
fun ProfileSettingsScreen(
    onNavigate: (AppDestination) -> Unit,
    onShowToast: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var kickOffAlerts by remember { mutableStateOf(true) }
    var goalAlerts by remember { mutableStateOf(true) }
    var varAlerts by remember { mutableStateOf(true) }
    var highContrast by remember { mutableStateOf(false) }
    var activeProfile by remember { mutableStateOf("Tom (Master)") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(PlDarkBackground)
            .testTag("profile_settings_screen"),
        contentPadding = PaddingValues(top = 14.dp, bottom = 90.dp, start = 16.dp, end = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text(
                    text = "ACCOUNT & HOUSEHOLD",
                    color = PlTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Profiles, device authorization, and sports broadcast preferences",
                    color = PlTextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        // Active Profile Card
        item {
            Surface(
                color = PlSurfaceDeep,
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PlBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(PlPurpleAccent, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("T", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(activeProfile, color = PlTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text("4K UHD HDR Tier • tom@ahyx.org", color = PlTextTertiary, fontSize = 11.sp)
                    }
                    Button(
                        onClick = {
                            activeProfile = if (activeProfile.contains("Master")) "Tactical Analyst" else "Tom (Master)"
                            onShowToast("Switched profile to $activeProfile")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PlSurfaceHighlight),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("SWITCH", fontSize = 10.sp, color = Pl4kCyan)
                    }
                }
            }
        }

        // Broadcasters shortcut
        item {
            Surface(
                color = PlSurfaceDeep,
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PlBorderSubtle),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigate(AppDestination.RIGHTS) }
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Tv, "Broadcasters", tint = PlPitchGreen)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Broadcaster Subscriptions & Entitlements", color = PlTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("Sky Sports, TNT Sports, Prime Video", color = PlTextTertiary, fontSize = 11.sp)
                        }
                    }
                    Icon(Icons.Default.ChevronRight, "Open", tint = PlTextSecondary)
                }
            }
        }

        // Notification Preferences
        item {
            Text("NOTIFICATIONS & MATCH ALERTS", color = PlTextTertiary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }

        item {
            Surface(
                color = PlSurfaceDeep,
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PlBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Kick-Off Countdown Alerts", color = PlTextPrimary, fontSize = 13.sp)
                        Switch(
                            checked = kickOffAlerts,
                            onCheckedChange = {
                                kickOffAlerts = it
                                onShowToast(if (it) "Kick-off alerts enabled" else "Kick-off alerts disabled")
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = PlPitchGreen)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Live Goal Notifications", color = PlTextPrimary, fontSize = 13.sp)
                        Switch(
                            checked = goalAlerts,
                            onCheckedChange = {
                                goalAlerts = it
                                onShowToast(if (it) "Goal alerts enabled" else "Goal alerts disabled")
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = PlPitchGreen)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("VAR Official Review Alerts", color = PlTextPrimary, fontSize = 13.sp)
                        Switch(
                            checked = varAlerts,
                            onCheckedChange = {
                                varAlerts = it
                                onShowToast(if (it) "VAR alerts enabled" else "VAR alerts disabled")
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = PlPitchGreen)
                        )
                    }
                }
            }
        }

        // Connected Devices
        item {
            Text("AUTHORIZED DEVICES (CONCURRENT LIMIT: 4)", color = PlTextTertiary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }

        item {
            Surface(
                color = PlSurfaceDeep,
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PlBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    DeviceRow("Google TV (Living Room 4K)", "Active Now • Streaming Sky Sports 4K", true)
                    DeviceRow("Pixel 9 Pro (This Device)", "Active Now • Premier League One Mobile", true)
                    DeviceRow("iPad Pro 12.9 (Tactical)", "Last active 2 hours ago", false)
                }
            }
        }
    }
}

@Composable
fun DeviceRow(deviceName: String, status: String, isCurrent: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(deviceName, color = PlTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(status, color = if (isCurrent) PlPitchGreen else PlTextTertiary, fontSize = 10.sp)
        }
        if (isCurrent) {
            Surface(color = PlPitchGreenDark, shape = RoundedCornerShape(4.dp)) {
                Text("CURRENT", color = PlPitchGreen, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
            }
        }
    }
}
