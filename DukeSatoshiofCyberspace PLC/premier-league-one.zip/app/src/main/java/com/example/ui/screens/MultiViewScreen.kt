package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Match
import com.example.ui.components.MultiViewGrid
import com.example.ui.theme.*
import com.example.ui.viewmodel.GoalFlashAlert
import com.example.ui.viewmodel.MultiViewLayout

@Composable
fun MultiViewScreen(
    matches: List<Match>,
    layout: MultiViewLayout,
    onSelectLayout: (MultiViewLayout) -> Unit,
    audioFocusMatchId: String,
    onSelectAudioFocus: (String) -> Unit,
    onSelectMatch: (String) -> Unit,
    goalFlashAlert: GoalFlashAlert?,
    onSwitchToGoalingMatch: () -> Unit,
    onDismissGoalFlash: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(PlDarkBackground)
            .testTag("multi_view_screen"),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(32.dp).testTag("multiview_back_btn")) {
                    Icon(Icons.Default.ArrowBack, "Back", tint = PlTextPrimary)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "MULTI-VIEW STADIUM",
                        color = PlTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Synchronized low-latency live feeds",
                        color = PlPitchGreen,
                        fontSize = 11.sp
                    )
                }
            }
        }

        item {
            MultiViewGrid(
                matches = matches,
                layout = layout,
                onSelectLayout = onSelectLayout,
                audioFocusMatchId = audioFocusMatchId,
                onSelectAudioFocus = onSelectAudioFocus,
                onSelectMatch = onSelectMatch,
                goalFlashAlert = goalFlashAlert,
                onSwitchToGoalingMatch = onSwitchToGoalingMatch,
                onDismissGoalFlash = onDismissGoalFlash
            )
        }

        item {
            // Multi-View Stadium Guide Card
            Surface(
                color = PlSurfaceDeep,
                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PlBorderSubtle),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "ABOUT MULTI-VIEW BROADCASTING",
                        color = PlTextTertiary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "• Switch between Dual-Split and Quad-Grid using the layout toggles.\n• Tap any match box to route audio commentary into your headphones or TV speakers.\n• Instant Goal Flash notifications will alert you when a goal is scored in another match with a 1-tap jump.",
                        color = PlTextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}
