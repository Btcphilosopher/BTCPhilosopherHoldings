package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EditorialHighlight
import com.example.ui.theme.*

@Composable
fun HighlightsScreen(
    highlights: List<EditorialHighlight>,
    onSelectHighlightToast: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedHighlightForChapters by remember { mutableStateOf<EditorialHighlight?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(PlDarkBackground)
            .testTag("highlights_screen"),
        contentPadding = PaddingValues(top = 14.dp, bottom = 90.dp, start = 16.dp, end = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text(
                    text = "REPLAYS & HIGHLIGHTS VOD",
                    color = PlTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "4K HDR extended match cuts, tactical analysis programmes and chapter jumping",
                    color = PlTextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        items(highlights) { hl ->
            Card(
                colors = CardDefaults.cardColors(containerColor = PlSurfaceDeep),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PlBorderSubtle),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { selectedHighlightForChapters = hl }
                    .testTag("vod_card_${hl.id}")
            ) {
                Column {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(
                                        try {
                                            Color(android.graphics.Color.parseColor(hl.thumbnailGradientHex.first))
                                        } catch (_: Exception) {
                                            PlPurplePrimary
                                        },
                                        PlDarkBackground
                                    )
                                )
                            )
                    ) {
                        Surface(
                            color = Color.Black.copy(alpha = 0.75f),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.padding(10.dp).align(Alignment.TopStart)
                        ) {
                            Text(
                                text = hl.resolutionBadge,
                                color = Pl4kCyan,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        Surface(
                            color = Color.Black.copy(alpha = 0.75f),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.padding(10.dp).align(Alignment.BottomEnd)
                        ) {
                            Text(
                                text = "${hl.durationMinutes} MINS",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        Icon(
                            imageVector = Icons.Default.PlayCircle,
                            contentDescription = "Play Video",
                            tint = Color.White.copy(alpha = 0.9f),
                            modifier = Modifier.size(48.dp).align(Alignment.Center)
                        )
                    }

                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = hl.title,
                            color = PlTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = hl.subtitle,
                            color = PlTextSecondary,
                            fontSize = 12.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Chapters preview chips
                        Text(
                            text = "EVENT CHAPTERS (TAP TO JUMP):",
                            color = PlTextTertiary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            hl.chapters.take(3).forEach { ch ->
                                Surface(
                                    color = PlSurfaceElevated,
                                    shape = RoundedCornerShape(6.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, PlBorderSubtle),
                                    modifier = Modifier.clickable {
                                        onSelectHighlightToast("Jumping to chapter: ${ch.title}")
                                    }
                                ) {
                                    Text(
                                        text = ch.title,
                                        color = PlPurpleNeon,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Chapters Navigation Dialog
    selectedHighlightForChapters?.let { hl ->
        AlertDialog(
            onDismissRequest = { selectedHighlightForChapters = null },
            title = { Text(hl.title, color = PlTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Select a chapter point to begin playback:", color = PlTextSecondary, fontSize = 12.sp)
                    hl.chapters.forEach { chapter ->
                        Surface(
                            color = PlSurfaceElevated,
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, PlBorderSubtle),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelectHighlightToast("Playing ${hl.title} from [${chapter.title}]")
                                    selectedHighlightForChapters = null
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.PlayArrow, "Play", tint = PlPitchGreen, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(chapter.title, color = PlTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Text("${chapter.timestampSeconds / 60}:${String.format("%02d", chapter.timestampSeconds % 60)}", color = PlTextTertiary, fontSize = 11.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedHighlightForChapters = null }) {
                    Text("CLOSE", color = PlPurpleAccent)
                }
            },
            containerColor = PlSurfaceDeep
        )
    }
}
