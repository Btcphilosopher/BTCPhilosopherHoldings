package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Club
import com.example.data.model.Match
import com.example.ui.theme.*

@Composable
fun MatchCard(
    match: Match,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isTvFocused: Boolean = false,
    onWatchClick: (() -> Unit)? = null
) {
    val borderColor = if (isTvFocused) PlPurpleNeon else PlBorderSubtle
    val cardBackground = Brush.verticalGradient(
        colors = listOf(PlSurfaceElevated, PlSurfaceDeep)
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(
                width = if (isTvFocused) 2.dp else 1.dp,
                color = borderColor,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onClick)
            .testTag("match_card_${match.id}"),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(modifier = Modifier.background(cardBackground)) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Top row: Competition, Live/Scheduled Badge, 4K Badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = PlPurplePrimary,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "MW ${match.matchweek}",
                                color = PlPurpleNeon,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = match.broadcasterName,
                            color = PlTextTertiary,
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (match.is4kAvailable) {
                            Surface(
                                color = PlSurfaceHighlight,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "4K UHD",
                                    color = Pl4kCyan,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                        }

                        if (match.isLive) {
                            Surface(
                                color = PlLiveRed.copy(alpha = 0.2f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, PlLiveRed),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .background(PlLiveRed, CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text(
                                        text = match.formattedTime,
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        } else {
                            Text(
                                text = match.formattedTime,
                                color = PlTextSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Teams & Scoreline Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Home Team
                    TeamDisplay(
                        club = match.homeClub,
                        modifier = Modifier.weight(1f),
                        isHome = true
                    )

                    // Scoreboard / VS
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 12.dp)
                            .background(PlDarkBackground, RoundedCornerShape(8.dp))
                            .border(1.dp, PlBorderSubtle, RoundedCornerShape(8.dp))
                            .padding(horizontal = 14.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (match.isLive || match.status == com.example.data.model.MatchStatus.FULL_TIME) {
                            Text(
                                text = "${match.homeScore} - ${match.awayScore}",
                                color = PlTextPrimary,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 2.sp
                            )
                        } else {
                            Text(
                                text = "VS",
                                color = PlTextSecondary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Away Team
                    TeamDisplay(
                        club = match.awayClub,
                        modifier = Modifier.weight(1f),
                        isHome = false
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Bottom bar: Stadium & Quick Action
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = match.stadium,
                        color = PlTextTertiary,
                        fontSize = 11.sp,
                        maxLines = 1,
                        modifier = Modifier.weight(1f)
                    )

                    if (match.isLive) {
                        Button(
                            onClick = { onWatchClick?.invoke() ?: onClick() },
                            colors = ButtonDefaults.buttonColors(containerColor = PlPurpleAccent),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(32.dp).testTag("watch_live_btn_${match.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Watch Live",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "WATCH",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TeamDisplay(
    club: Club,
    isHome: Boolean,
    modifier: Modifier = Modifier
) {
    val teamColor = try {
        Color(android.graphics.Color.parseColor(club.primaryColorHex))
    } catch (_: Exception) {
        PlPurpleAccent
    }

    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = if (isHome) Arrangement.End else Arrangement.Start
    ) {
        if (!isHome) {
            Box(
                modifier = Modifier
                    .size(14.dp)
                    .clip(CircleShape)
                    .background(teamColor)
            )
            Spacer(modifier = Modifier.width(8.dp))
        }

        Column(
            horizontalAlignment = if (isHome) Alignment.End else Alignment.Start
        ) {
            Text(
                text = club.shortName,
                color = PlTextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                textAlign = if (isHome) TextAlign.End else TextAlign.Start
            )
            Text(
                text = "Pos ${club.position}",
                color = PlTextTertiary,
                fontSize = 11.sp
            )
        }

        if (isHome) {
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .size(14.dp)
                    .clip(CircleShape)
                    .background(teamColor)
            )
        }
    }
}
