package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Club
import com.example.data.model.EditorialHighlight
import com.example.data.model.Match
import com.example.ui.components.MatchCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppDestination
import com.example.ui.viewmodel.MatchCentreTab

@Composable
fun HomeScreen(
    featuredMatch: Match,
    liveMatches: List<Match>,
    clubs: List<Club>,
    favoriteClubIds: Set<String>,
    highlights: List<EditorialHighlight>,
    isTvMode: Boolean,
    onToggleTvMode: () -> Unit,
    onSelectMatch: (String, MatchCentreTab) -> Unit,
    onNavigate: (AppDestination) -> Unit,
    onToggleFavoriteClub: (String) -> Unit,
    isDemoBannerVisible: Boolean,
    onDismissDemoBanner: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(PlDarkBackground)
            .testTag("home_screen_lazy_column"),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Top App Bar
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = PlPurplePrimary,
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, PlPurpleNeon)
                    ) {
                        Text(
                            text = "PL 1",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "PREMIER LEAGUE ONE",
                            color = PlTextPrimary,
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "BROADCAST OS • 4K HDR",
                            color = PlPitchGreen,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Mode Toggle (Mobile / TV)
                    IconButton(
                        onClick = onToggleTvMode,
                        modifier = Modifier.testTag("toggle_tv_mode_btn")
                    ) {
                        Icon(
                            imageVector = if (isTvMode) Icons.Default.Tv else Icons.Default.Smartphone,
                            contentDescription = "Switch UI Mode",
                            tint = if (isTvMode) PlPitchGreen else PlTextSecondary
                        )
                    }

                    IconButton(
                        onClick = { onNavigate(AppDestination.SEARCH) },
                        modifier = Modifier.testTag("home_search_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = PlTextPrimary
                        )
                    }

                    IconButton(
                        onClick = { onNavigate(AppDestination.PROFILE) },
                        modifier = Modifier.testTag("home_profile_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = "User Account",
                            tint = PlPurpleNeon
                        )
                    }
                }
            }
        }

        // Clearly Labeled Demonstration Mode Notice
        if (isDemoBannerVisible) {
            item {
                Surface(
                    color = PlSurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(1.dp, PlPurplePrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .testTag("demo_mode_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.VerifiedUser,
                                contentDescription = "Rights Aware",
                                tint = Pl4kCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "DEMO MODE: Synthetic fixtures & test media active. Verified rights layer ready for authorized broadcaster feeds.",
                                color = PlTextSecondary,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                        IconButton(onClick = onDismissDemoBanner, modifier = Modifier.size(20.dp)) {
                            Icon(Icons.Default.Close, "Dismiss", tint = PlTextTertiary, modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }
        }

        // Cinematic Hero Live Match Feature
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, PlBorderSubtle, RoundedCornerShape(20.dp))
                    .clickable { onSelectMatch(featuredMatch.id, MatchCentreTab.WATCH) }
                    .testTag("hero_featured_match")
            ) {
                // Background Image
                Image(
                    painter = painterResource(id = R.drawable.img_hero_match),
                    contentDescription = "Featured Live Match",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(230.dp),
                    contentScale = ContentScale.Crop
                )

                // Dark Gradient for legibility
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    PlDarkBackground.copy(alpha = 0.7f),
                                    PlDarkBackground.copy(alpha = 0.98f)
                                )
                            )
                        )
                )

                // Content Overlay
                Column(
                    modifier = Modifier
                        .matchParentSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Top row in Hero: Live badge & 4K HDR
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = PlLiveRed,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(modifier = Modifier.size(6.dp).background(Color.White, CircleShape))
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = "LIVE • ${featuredMatch.minute}'",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Surface(
                            color = Color.Black.copy(alpha = 0.7f),
                            shape = RoundedCornerShape(6.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, PlBorderSubtle)
                        ) {
                            Text(
                                text = "2160p 4K HDR",
                                color = Pl4kCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    // Bottom info in Hero
                    Column {
                        Text(
                            text = "MATCH OF THE ROUND • MATCHWEEK ${featuredMatch.matchweek}",
                            color = PlPurpleNeon,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${featuredMatch.homeClub.name} ${featuredMatch.homeScore} - ${featuredMatch.awayScore} ${featuredMatch.awayClub.name}",
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${featuredMatch.broadcasterName} • ${featuredMatch.stadium}",
                            color = PlTextSecondary,
                            fontSize = 12.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Actions Row
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { onSelectMatch(featuredMatch.id, MatchCentreTab.WATCH) },
                                colors = ButtonDefaults.buttonColors(containerColor = PlPurpleAccent),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("hero_watch_btn")
                            ) {
                                Icon(Icons.Default.PlayArrow, "Watch", tint = Color.White)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("WATCH LIVE IN 4K", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }

                            OutlinedButton(
                                onClick = { onNavigate(AppDestination.MULTI_VIEW) },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                border = androidx.compose.foundation.BorderStroke(1.dp, PlBorderSubtle),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("hero_multiview_btn")
                            ) {
                                Icon(Icons.Default.GridView, "Multi-View", tint = PlPitchGreen)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("MULTI-VIEW", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // Favourite Clubs Quick Rail
        item {
            Column(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Text(
                    text = "FAVOURITE CLUBS",
                    color = PlTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(clubs.take(8)) { club ->
                        val isFav = favoriteClubIds.contains(club.id)
                        Surface(
                            color = if (isFav) PlSurfaceHighlight else PlSurfaceDeep,
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isFav) PlPurpleAccent else PlBorderSubtle
                            ),
                            modifier = Modifier
                                .clickable { onToggleFavoriteClub(club.id) }
                                .testTag("fav_club_chip_${club.code}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val teamColor = try {
                                    Color(android.graphics.Color.parseColor(club.primaryColorHex))
                                } catch (_: Exception) {
                                    PlPurpleAccent
                                }
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .background(teamColor, CircleShape)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = club.shortName,
                                    color = PlTextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = if (isFav) Icons.Default.Star else Icons.Outlined.StarOutline,
                                    contentDescription = "Favorite",
                                    tint = if (isFav) PlScoreAmber else PlTextTertiary,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Live Matches Rail
        item {
            Column(modifier = Modifier.fillMaxWidth().padding(top = 20.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LIVE MATCHES & FIXTURES",
                        color = PlTextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "VIEW CALENDAR",
                        color = PlPurpleNeon,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { onNavigate(AppDestination.FIXTURES) }
                    )
                }

                Column(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    liveMatches.forEach { match ->
                        MatchCard(
                            match = match,
                            onClick = { onSelectMatch(match.id, MatchCentreTab.WATCH) },
                            onWatchClick = { onSelectMatch(match.id, MatchCentreTab.WATCH) }
                        )
                    }
                }
            }
        }

        // Latest 4K Highlights & Playlists
        item {
            Column(modifier = Modifier.fillMaxWidth().padding(top = 24.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "4K REPLAYS & EDITORIAL",
                        color = PlTextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "ALL REPLAYS",
                        color = PlPurpleNeon,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { onNavigate(AppDestination.HIGHLIGHTS) }
                    )
                }

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(highlights) { hl ->
                        HighlightCard(
                            highlight = hl,
                            onClick = { onNavigate(AppDestination.HIGHLIGHTS) }
                        )
                    }
                }
            }
        }

        // League Table Snapshot
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 24.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(PlSurfaceDeep)
                    .border(1.dp, PlBorderSubtle, RoundedCornerShape(16.dp))
                    .padding(16.dp)
                    .testTag("league_table_snapshot")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PREMIER LEAGUE TABLE SNAPSHOT",
                        color = PlTextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "MW 9",
                        color = PlPurpleNeon,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Table Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("#  CLUB", color = PlTextTertiary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text("PL", color = PlTextTertiary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("GD", color = PlTextTertiary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("PTS", color = PlPitchGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Divider(color = PlBorderSubtle, modifier = Modifier.padding(vertical = 8.dp))

                // Top 5 clubs
                clubs.take(5).forEach { c ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${c.position}",
                                color = if (c.position <= 4) PlPitchGreen else PlTextSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(20.dp)
                            )
                            Text(
                                text = c.shortName,
                                color = PlTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            Text(
                                text = "${c.played}",
                                color = PlTextSecondary,
                                fontSize = 12.sp,
                                modifier = Modifier.width(16.dp)
                            )
                            Text(
                                text = "${if (c.goalDifference > 0) "+" else ""}${c.goalDifference}",
                                color = PlTextSecondary,
                                fontSize = 12.sp,
                                modifier = Modifier.width(22.dp)
                            )
                            Text(
                                text = "${c.points}",
                                color = PlTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(24.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HighlightCard(
    highlight: EditorialHighlight,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(240.dp)
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, PlBorderSubtle, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .testTag("highlight_card_${highlight.id}"),
        colors = CardDefaults.cardColors(containerColor = PlSurfaceDeep)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .background(
                        Brush.linearGradient(
                            listOf(
                                try {
                                    Color(android.graphics.Color.parseColor(highlight.thumbnailGradientHex.first))
                                } catch (_: Exception) {
                                    PlPurplePrimary
                                },
                                PlDarkBackground
                            )
                        )
                    )
            ) {
                // Resolution Badge
                Surface(
                    color = Color.Black.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.padding(8.dp).align(Alignment.TopStart)
                ) {
                    Text(
                        text = highlight.resolutionBadge,
                        color = Pl4kCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                // Duration Badge
                Surface(
                    color = Color.Black.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.padding(8.dp).align(Alignment.BottomEnd)
                ) {
                    Text(
                        text = "${highlight.durationMinutes}m",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Icon(
                    imageVector = Icons.Default.PlayCircle,
                    contentDescription = "Play Highlight",
                    tint = Color.White.copy(alpha = 0.85f),
                    modifier = Modifier.size(36.dp).align(Alignment.Center)
                )
            }

            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = highlight.title,
                    color = PlTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = highlight.category,
                    color = PlPurpleNeon,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
