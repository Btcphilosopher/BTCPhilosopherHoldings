package com.example.data.model

enum class QualityProfile(
    val label: String,
    val resolution: String,
    val bitrateMbps: Double,
    val isHdr: Boolean
) {
    AUTO_4K("Auto (Best Available)", "3840x2160", 25.0, true),
    UHD_4K("2160p 4K UHD", "3840x2160", 25.0, true),
    QHD_1440("1440p QHD", "2560x1440", 14.5, false),
    FHD_1080_60("1080p 60fps", "1920x1080", 8.5, false),
    HD_720("720p HD", "1280x720", 4.0, false)
}

enum class AudioTrack(val title: String, val codec: String, val language: String) {
    MAIN_BROADCAST("Main Broadcast Commentary", "Dolby Atmos 5.1", "English"),
    STADIUM_ATMOSPHERE("Stadium Atmosphere (Crowd Only)", "5.1 Surround", "Clean Audio"),
    TACTICAL_STUDIO("Tactical Studio Analysis", "Stereo 320kbps", "English"),
    CLUB_AUDIO_HOME("Home Team Radio Broadcast", "Stereo 256kbps", "English"),
    INTERNATIONAL_SPANISH("Comentarios en Español", "Stereo 256kbps", "Español")
}

enum class SubtitleTrack(val title: String) {
    OFF("Off"),
    ENGLISH_CC("English (Live Closed Captions)"),
    SPANISH("Español (Subtítulos en vivo)")
}

enum class CameraAngle(val title: String, val description: String) {
    MAIN_BROADCAST("Broadcast Master", "Director's primary television cut"),
    TACTICAL_HIGH("Tactical High-Cam", "All 22 players wide view from roof gantry"),
    PLAYER_CAM("Star Player ISO Cam", "Tracking key playmaker movements"),
    GOAL_MOUNT_4K("Behind-The-Goal 4K", "Ultra-wide goalmouth angle")
}

data class StreamTelemetry(
    val selectedQuality: QualityProfile = QualityProfile.AUTO_4K,
    val currentResolution: String = "3840x2160 @ 59.94fps",
    val actualBitrateMbps: Double = 24.8,
    val bufferHealthSeconds: Double = 4.8,
    val latencyToLiveEdgeSeconds: Double = 1.2,
    val droppedFrames: Int = 0,
    val totalFrames: Int = 18450,
    val audioCodec: String = "Dolby Atmos (E-AC-3 JOC)",
    val videoCodec: String = "HEVC Main10 (HDR10)",
    val cdnEdgeNode: String = "LON-EDGE-04 (Cloudflare/Fastly PL-CDN)",
    val roundTripTimeMs: Int = 18,
    val isDvrActive: Boolean = false,
    val isLiveEdge: Boolean = true
)
