package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val PremierLeagueColorScheme = darkColorScheme(
    primary = PlPurpleAccent,
    onPrimary = Color.White,
    primaryContainer = PlPurplePrimary,
    onPrimaryContainer = PlPurpleNeon,
    secondary = PlPitchGreen,
    onSecondary = Color.Black,
    secondaryContainer = PlPitchGreenDark,
    onSecondaryContainer = PlPitchGreen,
    tertiary = Pl4kCyan,
    onTertiary = Color.Black,
    background = PlDarkBackground,
    onBackground = PlTextPrimary,
    surface = PlSurfaceDeep,
    onSurface = PlTextPrimary,
    surfaceVariant = PlSurfaceElevated,
    onSurfaceVariant = PlTextSecondary,
    outline = PlBorderSubtle,
    error = PlLiveRed,
    onError = Color.White
)

@Composable
fun PremierLeagueOneTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = PremierLeagueColorScheme,
        typography = Typography,
        content = content
    )
}

// Backward compatibility alias for template references
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    PremierLeagueOneTheme(content = content)
}
