package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Match
import com.example.data.model.Player
import com.example.ui.components.TacticalPitchCanvas
import com.example.ui.theme.*
import com.example.ui.viewmodel.TacticalLayer

@Composable
fun TacticalStudioScreen(
    match: Match,
    tacticalLayer: TacticalLayer,
    onSelectTacticalLayer: (TacticalLayer) -> Unit,
    allPlayers: List<Player>,
    playerAId: String,
    playerBId: String,
    onSelectPlayerA: (String) -> Unit,
    onSelectPlayerB: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val playerA = allPlayers.find { it.id == playerAId } ?: allPlayers.first()
    val playerB = allPlayers.find { it.id == playerBId } ?: allPlayers[1]

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(PlDarkBackground)
            .testTag("tactical_studio_screen"),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            // Header
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Text(
                    text = "TACTICAL STUDIO",
                    color = PlTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Advanced match analysis, expected goals (xG), and spatial tracking",
                    color = PlTextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        item {
            // Tactical Pitch Canvas with Layer Chips
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    TacticalLayer.values().forEach { l ->
                        val isSelected = (tacticalLayer == l)
                        Surface(
                            color = if (isSelected) PlPurplePrimary else PlSurfaceDeep,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) PlPurpleNeon else PlBorderSubtle
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .clickable { onSelectTacticalLayer(l) }
                                .weight(1f)
                                .testTag("tactical_layer_chip_${l.name.lowercase()}")
                        ) {
                            Text(
                                text = when (l) {
                                    TacticalLayer.SHOT_MAP -> "Shot Map"
                                    TacticalLayer.PASS_NETWORK -> "Passing"
                                    TacticalLayer.PRESSING_TILT -> "Tilt & PPDA"
                                    TacticalLayer.FORMATIONS -> "Formations"
                                },
                                color = if (isSelected) Color.White else PlTextSecondary,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.padding(vertical = 8.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                TacticalPitchCanvas(
                    match = match,
                    layer = tacticalLayer
                )
            }
        }

        // Positional Player Comparison Tool
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 20.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(PlSurfaceDeep)
                    .border(1.dp, PlBorderSubtle, RoundedCornerShape(16.dp))
                    .padding(16.dp)
                    .testTag("player_comparison_section")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CompareArrows,
                            contentDescription = "Compare Players",
                            tint = PlPurpleNeon,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "HEAD-TO-HEAD PLAYER COMPARISON",
                            color = PlTextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }

                    Surface(
                        color = PlSurfaceHighlight,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "SEASON 2026/27",
                            color = Pl4kCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Select Player A and B
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Player 1", color = PlTextTertiary, fontSize = 11.sp)
                        Text(
                            text = playerA.name,
                            color = PlPitchGreen,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${playerA.position} • #${playerA.shirtNumber} • ${playerA.clubId.uppercase()}",
                            color = PlTextSecondary,
                            fontSize = 11.sp
                        )
                    }

                    Text("VS", color = PlTextTertiary, fontWeight = FontWeight.Black, fontSize = 14.sp)

                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(text = "Player 2", color = PlTextTertiary, fontSize = 11.sp)
                        Text(
                            text = playerB.name,
                            color = Pl4kCyan,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${playerB.position} • #${playerB.shirtNumber} • ${playerB.clubId.uppercase()}",
                            color = PlTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                Divider(color = PlBorderSubtle, modifier = Modifier.padding(vertical = 12.dp))

                // Comparative metric bars
                PlayerMetricBar("Goals", "${playerA.goals}", "${playerB.goals}", playerA.goals, playerB.goals, 15)
                PlayerMetricBar("Expected Goals (xG)", "${playerA.expectedGoals}", "${playerB.expectedGoals}", (playerA.expectedGoals * 10).toInt(), (playerB.expectedGoals * 10).toInt(), 120)
                PlayerMetricBar("Assists", "${playerA.assists}", "${playerB.assists}", playerA.assists, playerB.assists, 10)
                PlayerMetricBar("Expected Assists (xA)", "${playerA.expectedAssists}", "${playerB.expectedAssists}", (playerA.expectedAssists * 10).toInt(), (playerB.expectedAssists * 10).toInt(), 60)
                PlayerMetricBar("Pass Accuracy %", "${playerA.passAccuracy}%", "${playerB.passAccuracy}%", playerA.passAccuracy, playerB.passAccuracy, 100)
                PlayerMetricBar("Duels Won %", "${playerA.duelsWonPercentage}%", "${playerB.duelsWonPercentage}%", playerA.duelsWonPercentage, playerB.duelsWonPercentage, 100)
                PlayerMetricBar("Match Rating", "${playerA.rating}", "${playerB.rating}", (playerA.rating * 10).toInt(), (playerB.rating * 10).toInt(), 100)

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "SELECT PLAYERS TO COMPARE",
                    color = PlTextTertiary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(allPlayers) { pl ->
                        val isA = pl.id == playerAId
                        val isB = pl.id == playerBId
                        Surface(
                            color = if (isA) PlPitchGreenDark else if (isB) PlSurfaceHighlight else PlSurfaceElevated,
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isA) PlPitchGreen else if (isB) Pl4kCyan else PlBorderSubtle
                            ),
                            modifier = Modifier.clickable {
                                if (!isA && !isB) {
                                    onSelectPlayerB(pl.id)
                                } else if (isB) {
                                    onSelectPlayerA(pl.id)
                                }
                            }
                        ) {
                            Text(
                                text = pl.name,
                                color = if (isA) PlPitchGreen else if (isB) Pl4kCyan else PlTextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PlayerMetricBar(
    label: String,
    valA: String,
    valB: String,
    numA: Int,
    numB: Int,
    maxVal: Int
) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(valA, color = PlPitchGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(label, color = PlTextSecondary, fontSize = 11.sp)
            Text(valB, color = Pl4kCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(3.dp))
        val total = (numA + numB).coerceAtLeast(1).toFloat()
        val fracA = (numA / total).coerceIn(0.05f, 0.95f)
        LinearProgressIndicator(
            progress = { fracA },
            modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape),
            color = PlPitchGreen,
            trackColor = Pl4kCyan
        )
    }
}
