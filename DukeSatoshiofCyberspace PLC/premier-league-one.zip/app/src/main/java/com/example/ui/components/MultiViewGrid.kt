package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Match
import com.example.ui.theme.*
import com.example.ui.viewmodel.GoalFlashAlert
import com.example.ui.viewmodel.MultiViewLayout

@Composable
fun MultiViewGrid(
    matches: List<Match>,
    layout: MultiViewLayout,
    onSelectLayout: (MultiViewLayout) -> Unit,
    audioFocusMatchId: String,
    onSelectAudioFocus: (String) -> Unit,
    onSelectMatch: (String) -> Unit,
    goalFlashAlert: GoalFlashAlert?,
    onSwitchToGoalingMatch: () -> Unit,
    onDismissGoalFlash: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("multi_view_container")
    ) {
        // Multi-View Control Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = PlPurplePrimary,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "MULTI-VIEW STADIUM",
                        color = PlPurpleNeon,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Tap any match to focus audio",
                    color = PlTextTertiary,
                    fontSize = 11.sp
                )
            }

            // Layout switchers
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(
                    onClick = { onSelectLayout(MultiViewLayout.DUAL_SPLIT) },
                    modifier = Modifier
                        .size(36.dp)
                        .background(
                            if (layout == MultiViewLayout.DUAL_SPLIT) PlSurfaceHighlight else Color.Transparent,
                            RoundedCornerShape(6.dp)
                        )
                        .testTag("layout_dual_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.ViewAgenda,
                        contentDescription = "Dual Split",
                        tint = if (layout == MultiViewLayout.DUAL_SPLIT) PlPitchGreen else PlTextSecondary
                    )
                }

                IconButton(
                    onClick = { onSelectLayout(MultiViewLayout.QUAD_GRID) },
                    modifier = Modifier
                        .size(36.dp)
                        .background(
                            if (layout == MultiViewLayout.QUAD_GRID) PlSurfaceHighlight else Color.Transparent,
                            RoundedCornerShape(6.dp)
                        )
                        .testTag("layout_quad_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.GridView,
                        contentDescription = "Quad Grid",
                        tint = if (layout == MultiViewLayout.QUAD_GRID) PlPitchGreen else PlTextSecondary
                    )
                }
            }
        }

        // Real-Time Goal Flash Alert Floating Banner
        AnimatedVisibility(
            visible = goalFlashAlert != null && goalFlashAlert.isVisible,
            enter = slideInVertically(),
            exit = slideOutVertically()
        ) {
            goalFlashAlert?.let { alert ->
                Surface(
                    color = PlLiveRed,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .testTag("goal_flash_alert_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "⚽ GOAL! ${alert.matchTitle}",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = alert.scorer,
                                color = Color.White.copy(alpha = 0.9f),
                                fontSize = 12.sp
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Button(
                                onClick = onSwitchToGoalingMatch,
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Text("SWITCH", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(4.dp))
                            IconButton(onClick = onDismissGoalFlash, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Close, "Dismiss", tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }

        // Feeds Container
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            when (layout) {
                MultiViewLayout.DUAL_SPLIT -> {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        matches.take(2).forEach { m ->
                            MultiViewFeedCell(
                                match = m,
                                hasAudioFocus = (m.id == audioFocusMatchId),
                                onSelectAudio = { onSelectAudioFocus(m.id) },
                                onSelectFullMatch = { onSelectMatch(m.id) },
                                heightDp = 180
                            )
                        }
                    }
                }
                MultiViewLayout.QUAD_GRID -> {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            matches.take(2).forEach { m ->
                                Box(modifier = Modifier.weight(1f)) {
                                    MultiViewFeedCell(
                                        match = m,
                                        hasAudioFocus = (m.id == audioFocusMatchId),
                                        onSelectAudio = { onSelectAudioFocus(m.id) },
                                        onSelectFullMatch = { onSelectMatch(m.id) },
                                        heightDp = 130
                                    )
                                }
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            matches.drop(2).take(2).forEach { m ->
                                Box(modifier = Modifier.weight(1f)) {
                                    MultiViewFeedCell(
                                        match = m,
                                        hasAudioFocus = (m.id == audioFocusMatchId),
                                        onSelectAudio = { onSelectAudioFocus(m.id) },
                                        onSelectFullMatch = { onSelectMatch(m.id) },
                                        heightDp = 130
                                    )
                                }
                            }
                        }
                    }
                }
                MultiViewLayout.FEATURED_PIP -> {
                    val featured = matches.firstOrNull() ?: return@Box
                    val others = matches.drop(1).take(2)
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        MultiViewFeedCell(
                            match = featured,
                            hasAudioFocus = (featured.id == audioFocusMatchId),
                            onSelectAudio = { onSelectAudioFocus(featured.id) },
                            onSelectFullMatch = { onSelectMatch(featured.id) },
                            heightDp = 200
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            others.forEach { m ->
                                Box(modifier = Modifier.weight(1f)) {
                                    MultiViewFeedCell(
                                        match = m,
                                        hasAudioFocus = (m.id == audioFocusMatchId),
                                        onSelectAudio = { onSelectAudioFocus(m.id) },
                                        onSelectFullMatch = { onSelectMatch(m.id) },
                                        heightDp = 110
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Hardware decoder telemetry indicator
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "HARDWARE TELEMETRY: 4 CONCURRENT HEVC DECODERS ACTIVE",
                color = Pl4kCyan,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "AUDIO SYNC: ZERO DRIFT (PTS LOCK)",
                color = PlPitchGreen,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun MultiViewFeedCell(
    match: Match,
    hasAudioFocus: Boolean,
    onSelectAudio: () -> Unit,
    onSelectFullMatch: () -> Unit,
    heightDp: Int
) {
    val borderColor = if (hasAudioFocus) PlPitchGreen else PlBorderSubtle

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(heightDp.dp)
            .clip(RoundedCornerShape(12.dp))
            .border(if (hasAudioFocus) 2.dp else 1.dp, borderColor, RoundedCornerShape(12.dp))
            .clickable { onSelectAudio() }
            .testTag("multiview_feed_${match.id}")
    ) {
        // Video thumbnail/stream surface
        Image(
            painter = painterResource(id = R.drawable.img_hero_match),
            contentDescription = "Match Stream Feed",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Gradient overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.5f),
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.75f)
                        )
                    )
                )
        )

        // Top Row: Score Bug & Audio Focus Pill
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = Color.Black.copy(alpha = 0.85f),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(
                    text = "${match.homeClub.code} ${match.homeScore} - ${match.awayScore} ${match.awayClub.code}  ${match.minute}'",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                )
            }

            // Audio Focus indicator
            Surface(
                color = if (hasAudioFocus) PlPitchGreen else Color.Black.copy(alpha = 0.6f),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.clickable { onSelectAudio() }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (hasAudioFocus) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
                        contentDescription = if (hasAudioFocus) "Audio Active" else "Audio Muted",
                        tint = if (hasAudioFocus) Color.Black else PlTextSecondary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = if (hasAudioFocus) "ACTIVE SOUND" else "TAP SOUND",
                        color = if (hasAudioFocus) Color.Black else PlTextSecondary,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Bottom Row: Broadcaster & Expand Fullscreen button
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = match.broadcasterName,
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 10.sp,
                maxLines = 1
            )

            IconButton(
                onClick = onSelectFullMatch,
                modifier = Modifier
                    .size(28.dp)
                    .background(Color.Black.copy(alpha = 0.6f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Fullscreen,
                    contentDescription = "Expand Fullscreen",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
