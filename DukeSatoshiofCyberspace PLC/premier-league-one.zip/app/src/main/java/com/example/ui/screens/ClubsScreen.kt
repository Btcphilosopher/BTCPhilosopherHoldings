package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Club
import com.example.ui.theme.*

@Composable
fun ClubsScreen(
    clubs: List<Club>,
    favoriteClubIds: Set<String>,
    onToggleFavoriteClub: (String) -> Unit,
    selectedClubDetailId: String?,
    onSelectClubDetail: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(PlDarkBackground)
            .testTag("clubs_screen")
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(top = 14.dp, bottom = 90.dp, start = 16.dp, end = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Column {
                    Text(
                        text = "PREMIER LEAGUE CLUBS",
                        color = PlTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "All 20 official clubs • Follow teams to customize recommendations",
                        color = PlTextSecondary,
                        fontSize = 12.sp
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            items(clubs) { club ->
                val isFav = favoriteClubIds.contains(club.id)
                val teamColor = try {
                    Color(android.graphics.Color.parseColor(club.primaryColorHex))
                } catch (_: Exception) {
                    PlPurpleAccent
                }

                Surface(
                    color = PlSurfaceDeep,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isFav) PlPurpleAccent else PlBorderSubtle
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectClubDetail(club.id) }
                        .testTag("club_row_${club.code}")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(16.dp)
                                    .clip(CircleShape)
                                    .background(teamColor)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = club.name,
                                    color = PlTextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${club.stadium} • Mgr: ${club.manager}",
                                    color = PlTextTertiary,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "${club.points} PTS",
                                    color = PlPitchGreen,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Pos ${club.position}",
                                    color = PlTextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            IconButton(
                                onClick = { onToggleFavoriteClub(club.id) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = if (isFav) Icons.Default.Star else Icons.Outlined.StarOutline,
                                    contentDescription = "Toggle Favorite",
                                    tint = if (isFav) PlScoreAmber else PlTextTertiary
                                )
                            }
                        }
                    }
                }
            }
        }

        // Club Detail Sheet/Overlay
        selectedClubDetailId?.let { cId ->
            val club = clubs.find { it.id == cId }
            if (club != null) {
                ClubDetailDialog(
                    club = club,
                    isFavorite = favoriteClubIds.contains(club.id),
                    onToggleFavorite = { onToggleFavoriteClub(club.id) },
                    onDismiss = { onSelectClubDetail(null) }
                )
            }
        }
    }
}

@Composable
fun ClubDetailDialog(
    club: Club,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onDismiss: () -> Unit
) {
    val teamColor = try {
        Color(android.graphics.Color.parseColor(club.primaryColorHex))
    } catch (_: Exception) {
        PlPurpleAccent
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(16.dp).background(teamColor, CircleShape))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(club.name, color = PlTextPrimary, fontWeight = FontWeight.Black, fontSize = 16.sp)
                }
                IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Close, "Close", tint = PlTextSecondary)
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("STADIUM: ${club.stadium} (${club.capacity.toString().replace(Regex("(\\d)(?=(\\d{3})+$)"), "$1,")} capacity)", color = PlTextSecondary, fontSize = 12.sp)
                Text("HEAD COACH: ${club.manager}", color = PlTextSecondary, fontSize = 12.sp)
                Text("LEAGUE POSITION: #${club.position} (${club.played} GP • ${club.won} W • ${club.drawn} D • ${club.lost} L)", color = PlTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("GOAL DIFFERENCE: ${if (club.goalDifference > 0) "+" else ""}${club.goalDifference} (${club.goalsFor} GF / ${club.goalsAgainst} GA)", color = PlTextTertiary, fontSize = 11.sp)

                Spacer(modifier = Modifier.height(4.dp))
                Text("RECENT FORM:", color = PlTextTertiary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    club.form.forEach { f ->
                        Surface(
                            color = when (f) {
                                "W" -> PlPitchGreen
                                "D" -> PlScoreAmber
                                else -> PlLiveRed
                            },
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = f,
                                color = Color.Black,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = onToggleFavorite,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isFavorite) PlSurfaceHighlight else PlPurpleAccent
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Default.Star else Icons.Outlined.StarOutline,
                        contentDescription = "Favorite",
                        tint = if (isFavorite) PlScoreAmber else Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isFavorite) "FOLLOWING (FAVOURITE)" else "FOLLOW CLUB")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("DONE", color = PlPurpleAccent)
            }
        },
        containerColor = PlSurfaceDeep
    )
}
