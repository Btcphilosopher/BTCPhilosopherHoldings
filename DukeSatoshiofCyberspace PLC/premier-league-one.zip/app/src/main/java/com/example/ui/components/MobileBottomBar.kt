package com.example.ui.components

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppDestination

data class NavItem(
    val destination: AppDestination,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val label: String
)

val mobileNavItems = listOf(
    NavItem(AppDestination.HOME, Icons.Filled.Home, Icons.Outlined.Home, "Home"),
    NavItem(AppDestination.MATCH_CENTRE, Icons.Filled.SportsSoccer, Icons.Outlined.SportsSoccer, "Matches"),
    NavItem(AppDestination.MULTI_VIEW, Icons.Filled.GridView, Icons.Outlined.GridView, "Multi-View"),
    NavItem(AppDestination.TACTICAL_STUDIO, Icons.Filled.Analytics, Icons.Outlined.Analytics, "Tactics"),
    NavItem(AppDestination.FIXTURES, Icons.Filled.CalendarMonth, Icons.Outlined.CalendarMonth, "Fixtures"),
    NavItem(AppDestination.CLUBS, Icons.Filled.Shield, Icons.Outlined.Shield, "Clubs")
)

@Composable
fun MobileBottomBar(
    currentDestination: AppDestination,
    onNavigate: (AppDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier
            .windowInsetsPadding(WindowInsets.navigationBars)
            .testTag("mobile_bottom_bar"),
        containerColor = PlDarkBackground,
        tonalElevation = 8.dp
    ) {
        mobileNavItems.forEach { item ->
            val isSelected = currentDestination == item.destination
            NavigationBarItem(
                selected = isSelected,
                onClick = { onNavigate(item.destination) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                        contentDescription = item.label,
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Text(
                        text = item.label,
                        fontSize = 10.sp,
                        color = if (isSelected) PlPurpleNeon else PlTextSecondary
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = PlPurpleNeon,
                    unselectedIconColor = PlTextSecondary,
                    selectedTextColor = PlPurpleNeon,
                    unselectedTextColor = PlTextSecondary,
                    indicatorColor = PlPurplePrimary
                ),
                modifier = Modifier.testTag("nav_item_${item.destination.name.lowercase()}")
            )
        }
    }
}
