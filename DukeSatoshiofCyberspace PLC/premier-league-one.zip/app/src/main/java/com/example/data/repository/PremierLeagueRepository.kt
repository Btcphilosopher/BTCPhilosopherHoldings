package com.example.data.repository

import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class PremierLeagueRepository {

    private val scope = CoroutineScope(Dispatchers.Default)

    // Complete 20 Premier League clubs
    private val allClubs = listOf(
        Club("ars", "Arsenal", "Arsenal", "ARS", "#EF0107", "#063672", "Emirates Stadium", 60704, "Mikel Arteta", 1, 9, 7, 1, 1, 21, 6, 22, listOf("W", "W", "W", "D", "W"), true),
        Club("mci", "Manchester City", "Man City", "MCI", "#6CABDD", "#1C2C5B", "Etihad Stadium", 53400, "Pep Guardiola", 2, 9, 6, 2, 1, 22, 9, 20, listOf("W", "D", "W", "W", "W"), true),
        Club("liv", "Liverpool", "Liverpool", "LIV", "#C8102E", "#00B2A9", "Anfield", 61276, "Arne Slot", 3, 9, 6, 1, 2, 19, 7, 19, listOf("W", "W", "L", "W", "W"), true),
        Club("che", "Chelsea", "Chelsea", "CHE", "#034694", "#EE242C", "Stamford Bridge", 40343, "Enzo Maresca", 4, 9, 5, 2, 2, 18, 11, 17, listOf("W", "W", "D", "W", "D"), false),
        Club("avl", "Aston Villa", "Aston Villa", "AVL", "#95BFE5", "#670E36", "Villa Park", 42682, "Unai Emery", 5, 9, 5, 2, 2, 16, 12, 17, listOf("W", "D", "W", "D", "W"), false),
        Club("tot", "Tottenham Hotspur", "Spurs", "TOT", "#132257", "#FFFFFF", "Tottenham Hotspur Stadium", 62850, "Ange Postecoglou", 6, 9, 5, 1, 3, 19, 11, 16, listOf("L", "W", "W", "L", "W"), false),
        Club("new", "Newcastle United", "Newcastle", "NEW", "#241F20", "#41B6E6", "St James' Park", 52305, "Eddie Howe", 7, 9, 4, 3, 2, 14, 11, 15, listOf("D", "D", "W", "L", "W"), false),
        Club("mun", "Manchester United", "Man Utd", "MUN", "#DA291C", "#FBE122", "Old Trafford", 74310, "Rúben Amorim", 8, 9, 4, 2, 3, 13, 12, 14, listOf("W", "L", "D", "W", "L"), false),
        Club("bha", "Brighton & Hove Albion", "Brighton", "BHA", "#0057B8", "#FFCD00", "Amex Stadium", 31876, "Fabian Hürzeler", 9, 9, 4, 2, 3, 14, 14, 14, listOf("D", "W", "L", "W", "D"), false),
        Club("ful", "Fulham", "Fulham", "FUL", "#CC0000", "#000000", "Craven Cottage", 25700, "Marco Silva", 10, 9, 3, 3, 3, 12, 13, 12, listOf("L", "D", "W", "L", "W"), false),
        Club("bou", "AFC Bournemouth", "Bournemouth", "BOU", "#DA291C", "#000000", "Vitality Stadium", 11307, "Andoni Iraola", 11, 9, 3, 3, 3, 11, 12, 12, listOf("W", "L", "W", "D", "L"), false),
        Club("bre", "Brentford", "Brentford", "BRE", "#E30613", "#FEEB00", "Gtech Community Stadium", 17250, "Thomas Frank", 12, 9, 3, 2, 4, 14, 16, 11, listOf("W", "L", "W", "L", "D"), false),
        Club("nfo", "Nottingham Forest", "Nott'm Forest", "NFO", "#DD0000", "#FFFFFF", "City Ground", 30445, "Nuno Espírito Santo", 13, 9, 3, 2, 4, 9, 12, 11, listOf("D", "W", "L", "D", "L"), false),
        Club("whu", "West Ham United", "West Ham", "WHU", "#7A263A", "#1BB1E7", "London Stadium", 62500, "Julen Lopetegui", 14, 9, 3, 2, 4, 11, 17, 11, listOf("L", "W", "L", "D", "L"), false),
        Club("eve", "Everton", "Everton", "EVE", "#003399", "#FFFFFF", "Goodison Park", 39572, "Sean Dyche", 15, 9, 2, 3, 4, 10, 15, 9, listOf("D", "W", "D", "L", "D"), false),
        Club("lei", "Leicester City", "Leicester", "LEI", "#003090", "#FDBE11", "King Power Stadium", 32261, "Steve Cooper", 16, 9, 2, 3, 4, 12, 18, 9, listOf("W", "L", "L", "W", "D"), false),
        Club("cry", "Crystal Palace", "Crystal Palace", "CRY", "#1B458F", "#A7A5A6", "Selhurst Park", 25486, "Oliver Glasner", 17, 9, 1, 4, 4, 8, 14, 7, listOf("L", "D", "L", "D", "W"), false),
        Club("ips", "Ipswich Town", "Ipswich", "IPS", "#0047AB", "#FFFFFF", "Portman Road", 30014, "Kieran McKenna", 18, 9, 0, 4, 5, 8, 19, 4, listOf("D", "L", "L", "D", "L"), false),
        Club("wol", "Wolverhampton Wanderers", "Wolves", "WOL", "#FDB913", "#231F20", "Molineux Stadium", 31750, "Gary O'Neil", 19, 9, 0, 3, 6, 10, 23, 3, listOf("L", "L", "L", "D", "L"), false),
        Club("sou", "Southampton", "Southampton", "SOU", "#D71920", "#130F30", "St Mary's Stadium", 32384, "Russell Martin", 20, 9, 0, 2, 7, 6, 21, 2, listOf("L", "L", "D", "L", "L"), false)
    )

    private val _clubsState = MutableStateFlow(allClubs)
    val clubs: StateFlow<List<Club>> = _clubsState.asStateFlow()

    private val _favoriteClubIds = MutableStateFlow(setOf("ars", "mci", "liv"))
    val favoriteClubIds: StateFlow<Set<String>> = _favoriteClubIds.asStateFlow()

    // Key players database
    private val allPlayers = listOf(
        Player("p_haaland", "Erling Haaland", 9, "FWD", "Norway", "mci", 9, 810, 11, 1, 9.8, 1.2, 79, 4, 62, 8.4),
        Player("p_saka", "Bukayo Saka", 7, "FWD", "England", "ars", 9, 785, 4, 7, 3.6, 5.8, 86, 18, 59, 8.2),
        Player("p_salah", "Mohamed Salah", 11, "FWD", "Egypt", "liv", 9, 790, 7, 5, 6.2, 4.4, 82, 9, 48, 8.3),
        Player("p_palmer", "Cole Palmer", 20, "MID", "England", "che", 9, 760, 6, 5, 4.9, 4.6, 84, 12, 54, 8.1),
        Player("p_rice", "Declan Rice", 41, "MID", "England", "ars", 8, 710, 1, 2, 0.9, 2.1, 91, 28, 68, 7.8),
        Player("p_debruyne", "Kevin De Bruyne", 17, "MID", "Belgium", "mci", 6, 490, 2, 4, 1.8, 4.2, 88, 8, 46, 7.9),
        Player("p_vvd", "Virgil van Dijk", 4, "DEF", "Netherlands", "liv", 9, 810, 1, 1, 0.8, 0.4, 93, 24, 76, 7.9),
        Player("p_son", "Son Heung-min", 7, "FWD", "South Korea", "tot", 8, 680, 4, 3, 3.2, 2.8, 83, 11, 45, 7.6),
        Player("p_saliba", "William Saliba", 2, "DEF", "France", "ars", 8, 720, 0, 0, 0.4, 0.2, 94, 22, 73, 7.8),
        Player("p_foden", "Phil Foden", 47, "MID", "England", "mci", 7, 550, 3, 2, 2.4, 2.9, 89, 14, 52, 7.7)
    )

    // Initial Matches
    private val _matchesState = MutableStateFlow<List<Match>>(emptyList())
    val matches: StateFlow<List<Match>> = _matchesState.asStateFlow()

    // Highlights Catalogue
    val highlights = listOf(
        EditorialHighlight(
            id = "hl_01",
            title = "Arsenal vs Man City: 6-Goal Title Thriller",
            subtitle = "Matchweek 9 Extended Cut in 4K HDR",
            durationMinutes = 16,
            matchweek = 9,
            category = "Extended Highlights",
            resolutionBadge = "4K UHD HDR",
            thumbnailGradientHex = Pair("#EF0107", "#6CABDD"),
            homeClubCode = "ARS",
            awayClubCode = "MCI",
            chapters = listOf(
                VideoChapter("Kick-Off", 0L, EventType.MATCH_STARTED),
                VideoChapter("Saka Curler 1-0", 145L, EventType.GOAL),
                VideoChapter("Haaland Header 1-1", 410L, EventType.GOAL),
                VideoChapter("Red Card Drama 45'", 620L, EventType.RED_CARD),
                VideoChapter("Late Stunner 90+3'", 890L, EventType.GOAL)
            )
        ),
        EditorialHighlight(
            id = "hl_02",
            title = "Tactical Masterclass: Liverpool's High-Press System",
            subtitle = "How Arne Slot transformed midfield transitions with xG breakdown",
            durationMinutes = 12,
            matchweek = 9,
            category = "Tactical Masterclass",
            resolutionBadge = "4K UHD",
            thumbnailGradientHex = Pair("#C8102E", "#0B0F1D"),
            homeClubCode = "LIV",
            awayClubCode = "CHE",
            chapters = listOf(
                VideoChapter("Introduction", 0L),
                VideoChapter("Pressing Zones", 180L),
                VideoChapter("Transition Speed", 420L),
                VideoChapter("Shot Map Analysis", 650L)
            )
        ),
        EditorialHighlight(
            id = "hl_03",
            title = "The Weekend Review: Matchweek 9 All 28 Goals",
            subtitle = "Every goal, every angle, and official VAR audio releases",
            durationMinutes = 24,
            matchweek = 9,
            category = "Weekend Review",
            resolutionBadge = "4K UHD HDR",
            thumbnailGradientHex = Pair("#38003C", "#00D856"),
            homeClubCode = "PL",
            awayClubCode = "ONE",
            chapters = listOf(
                VideoChapter("Saturday Lunchtime Kickoff", 0L),
                VideoChapter("3PM Blackout Highlights", 480L),
                VideoChapter("Sunday Derby Clashes", 920L)
            )
        )
    )

    // Connected Broadcasters & Entitlements
    val connectedProviders = listOf(
        ConnectedProvider("p_sky", "Sky Sports Main Event UHD", "United Kingdom", true, "Premier 4K Ultimate", "2027-01-01", 4, 1, "ic_tv"),
        ConnectedProvider("p_tnt", "TNT Sports 1 4K HDR", "United Kingdom", true, "Total Sports Pass", "2026-12-15", 4, 0, "ic_tv"),
        ConnectedProvider("p_prime", "Prime Video Premier Broadcast", "United Kingdom", true, "Included in Prime", "2027-05-30", 3, 0, "ic_tv"),
        ConnectedProvider("p_peacock", "Peacock Premier League Pass", "United States", false, "Connect Account", "-", 2, 0, "ic_tv")
    )

    init {
        initializeMatches()
        startLiveEventSimulation()
    }

    private fun initializeMatches() {
        val ars = allClubs.first { it.id == "ars" }
        val mci = allClubs.first { it.id == "mci" }
        val liv = allClubs.first { it.id == "liv" }
        val che = allClubs.first { it.id == "che" }
        val avl = allClubs.first { it.id == "avl" }
        val tot = allClubs.first { it.id == "tot" }
        val new = allClubs.first { it.id == "new" }
        val mun = allClubs.first { it.id == "mun" }

        val match1 = Match(
            id = "m_live_01",
            homeClub = ars,
            awayClub = mci,
            homeScore = 2,
            awayScore = 1,
            status = MatchStatus.LIVE_SECOND_HALF,
            minute = 74,
            addedTime = 4,
            matchweek = 9,
            kickOffTime = "16:30 BST",
            stadium = "Emirates Stadium, London",
            referee = "Michael Oliver",
            broadcasterName = "Sky Sports Main Event 4K UHD",
            is4kAvailable = true,
            isHdrAvailable = true,
            streamBitrateMbps = 24.8,
            events = listOf(
                MatchEvent("ev_01", 14, 0, EventType.GOAL, "ars", "Bukayo Saka", "Martin Ødegaard", "Left-footed curled shot into the top-left corner", null, 140L),
                MatchEvent("ev_02", 38, 0, EventType.YELLOW_CARD, "mci", "Rúben Dias", null, "Tactical foul breaking counter-attack", null, 380L),
                MatchEvent("ev_03", 52, 0, EventType.GOAL, "mci", "Erling Haaland", "Kevin De Bruyne", "Powerful header from 6 yards", null, 520L),
                MatchEvent("ev_04", 65, 0, EventType.VAR_REVIEW, "ars", "Declan Rice", null, "VAR Review: Possible Handball in Penalty Area -> PENALTY CONFIRMED", "OVERTURN TO PENALTY", 650L),
                MatchEvent("ev_05", 67, 0, EventType.GOAL, "ars", "Bukayo Saka", null, "Penalty scored with composure down the middle", null, 670L)
            ),
            homeStats = TeamStats(
                possessionPercentage = 48,
                shots = 13,
                shotsOnTarget = 6,
                expectedGoals = 2.14,
                corners = 5,
                fouls = 8,
                yellowCards = 1,
                redCards = 0,
                offsides = 2,
                passesCompleted = 412,
                passAccuracyPercentage = 87,
                fieldTiltPercentage = 53,
                ppda = 9.8
            ),
            awayStats = TeamStats(
                possessionPercentage = 52,
                shots = 11,
                shotsOnTarget = 4,
                expectedGoals = 1.48,
                corners = 4,
                fouls = 11,
                yellowCards = 2,
                redCards = 0,
                offsides = 1,
                passesCompleted = 478,
                passAccuracyPercentage = 89,
                fieldTiltPercentage = 47,
                ppda = 11.2
            ),
            homeFormation = TacticalFormation(
                formationName = "4-3-3",
                starters = listOf(
                    PlayerNode(allPlayers.first { it.id == "p_saka" }, 0.82f, 0.78f),
                    PlayerNode(allPlayers.first { it.id == "p_rice" }, 0.50f, 0.44f),
                    PlayerNode(allPlayers.first { it.id == "p_saliba" }, 0.65f, 0.22f)
                )
            ),
            awayFormation = TacticalFormation(
                formationName = "4-2-3-1",
                starters = listOf(
                    PlayerNode(allPlayers.first { it.id == "p_haaland" }, 0.50f, 0.84f),
                    PlayerNode(allPlayers.first { it.id == "p_debruyne" }, 0.52f, 0.62f),
                    PlayerNode(allPlayers.first { it.id == "p_foden" }, 0.22f, 0.72f)
                )
            ),
            shotMap = listOf(
                ShotData("s_1", 0.75f, 0.88f, 0.12, "Goal", "B. Saka (14')", 14, true),
                ShotData("s_2", 0.48f, 0.76f, 0.45, "Saved", "K. Havertz (28')", 28, true),
                ShotData("s_3", 0.52f, 0.92f, 0.68, "Goal", "E. Haaland (52')", 52, false),
                ShotData("s_4", 0.50f, 0.88f, 0.79, "Goal", "B. Saka (Pen 67')", 67, true),
                ShotData("s_5", 0.38f, 0.72f, 0.08, "Blocked", "P. Foden (71')", 71, false)
            ),
            passLinks = listOf(
                PassLink("p_saliba", "p_rice", 28, true),
                PassLink("p_rice", "p_saka", 19, true),
                PassLink("p_debruyne", "p_haaland", 14, false)
            )
        )

        val match2 = Match(
            id = "m_live_02",
            homeClub = liv,
            awayClub = che,
            homeScore = 1,
            awayScore = 1,
            status = MatchStatus.LIVE_SECOND_HALF,
            minute = 61,
            addedTime = 2,
            matchweek = 9,
            kickOffTime = "16:30 BST",
            stadium = "Anfield, Liverpool",
            referee = "Anthony Taylor",
            broadcasterName = "TNT Sports 1 4K HDR",
            is4kAvailable = true,
            isHdrAvailable = true,
            streamBitrateMbps = 24.2,
            events = listOf(
                MatchEvent("ev_l1", 29, 0, EventType.GOAL, "liv", "Mohamed Salah", null, "Cut inside on left foot and curled into bottom corner", null, 290L),
                MatchEvent("ev_l2", 48, 0, EventType.GOAL, "che", "Cole Palmer", "Nicolas Jackson", "Smart one-two finish from edge of box", null, 480L)
            ),
            homeStats = TeamStats(55, 14, 5, 1.88, 6, 9, 1, 0, 1, 460, 88),
            awayStats = TeamStats(45, 9, 3, 1.12, 3, 12, 2, 0, 2, 370, 84),
            homeFormation = TacticalFormation("4-3-3", emptyList()),
            awayFormation = TacticalFormation("4-2-3-1", emptyList())
        )

        val match3 = Match(
            id = "m_live_03",
            homeClub = tot,
            awayClub = avl,
            homeScore = 0,
            awayScore = 0,
            status = MatchStatus.LIVE_FIRST_HALF,
            minute = 33,
            addedTime = 1,
            matchweek = 9,
            kickOffTime = "16:30 BST",
            stadium = "Tottenham Hotspur Stadium",
            referee = "Paul Tierney",
            broadcasterName = "Prime Video PL 4K",
            is4kAvailable = true,
            isHdrAvailable = false,
            streamBitrateMbps = 18.5,
            events = listOf(
                MatchEvent("ev_t1", 18, 0, EventType.YELLOW_CARD, "tot", "Cristian Romero", null, "Late challenge", null, 180L)
            ),
            homeStats = TeamStats(62, 7, 2, 0.65, 3, 5, 1, 0, 2, 290, 91),
            awayStats = TeamStats(38, 4, 1, 0.42, 1, 7, 0, 0, 1, 180, 82),
            homeFormation = TacticalFormation("4-3-3", emptyList()),
            awayFormation = TacticalFormation("4-4-2", emptyList())
        )

        val match4Upcoming = Match(
            id = "m_up_01",
            homeClub = new,
            awayClub = mun,
            homeScore = 0,
            awayScore = 0,
            status = MatchStatus.SCHEDULED,
            minute = 0,
            matchweek = 9,
            kickOffTime = "20:00 BST Tonight",
            stadium = "St James' Park, Newcastle",
            referee = "Simon Hooper",
            broadcasterName = "Sky Sports Premier League UHD",
            is4kAvailable = true,
            isHdrAvailable = true,
            streamBitrateMbps = 25.0,
            homeStats = TeamStats(50, 0, 0, 0.0, 0, 0, 0, 0, 0, 0, 0),
            awayStats = TeamStats(50, 0, 0, 0.0, 0, 0, 0, 0, 0, 0, 0),
            homeFormation = TacticalFormation("4-3-3", emptyList()),
            awayFormation = TacticalFormation("3-4-2-1", emptyList())
        )

        _matchesState.value = listOf(match1, match2, match3, match4Upcoming)
    }

    private fun startLiveEventSimulation() {
        scope.launch {
            while (true) {
                delay(6000L) // Real-time pulse every 6 seconds
                val current = _matchesState.value
                val updated = current.map { m ->
                    if (m.isLive && m.minute < 95) {
                        val nextMin = m.minute + 1
                        m.copy(minute = nextMin)
                    } else m
                }
                _matchesState.value = updated
            }
        }
    }

    fun toggleFavoriteClub(clubId: String) {
        val current = _favoriteClubIds.value.toMutableSet()
        if (current.contains(clubId)) {
            current.remove(clubId)
        } else {
            current.add(clubId)
        }
        _favoriteClubIds.value = current
        _clubsState.value = _clubsState.value.map {
            if (it.id == clubId) it.copy(isFavorite = current.contains(clubId)) else it
        }
    }

    fun getAllPlayers(): List<Player> = allPlayers

    fun getPlayerById(id: String): Player? = allPlayers.find { it.id == id }

    fun getClubById(id: String): Club? = allClubs.find { it.id == id }

    fun getMatchById(id: String): Match? = _matchesState.value.find { it.id == id }
}
