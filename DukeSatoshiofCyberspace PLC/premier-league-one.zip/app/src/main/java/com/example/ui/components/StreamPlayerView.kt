package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.*
import com.example.ui.theme.*

@Composable
fun StreamPlayerView(
    match: Match,
    isPlaying: Boolean,
    onTogglePlayPause: () -> Unit,
    currentSeconds: Long,
    isLiveEdge: Boolean,
    onJumpLiveEdge: () -> Unit,
    onSeekRelative: (Long) -> Unit,
    telemetry: StreamTelemetry,
    showStatsForGeeks: Boolean,
    onToggleStatsForGeeks: () -> Unit,
    selectedQuality: QualityProfile,
    onSelectQuality: (QualityProfile) -> Unit,
    selectedAudio: AudioTrack,
    onSelectAudio: (AudioTrack) -> Unit,
    selectedSubtitle: SubtitleTrack,
    onSelectSubtitle: (SubtitleTrack) -> Unit,
    selectedCamera: CameraAngle,
    onSelectCamera: (CameraAngle) -> Unit,
    onClosePlayer: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var controlsVisible by remember { mutableStateOf(true) }
    var showQualityDialog by remember { mutableStateOf(false) }
    var showAudioDialog by remember { mutableStateOf(false) }
    var showCameraDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(280.dp)
            .background(Color.Black)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                controlsVisible = !controlsVisible
            }
            .testTag("stream_player_container")
    ) {
        // Video Surface Background (Realistic 4K broadcast visual)
        Image(
            painter = painterResource(id = R.drawable.img_hero_match),
            contentDescription = "Live 4K Match Broadcast Feed",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Broadcast Scanline & Vignette Overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.65f),
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.85f)
                        )
                    )
                )
        )

        // Permanent Broadcast Top-Left Score Bug & Watermark
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = PlDarkBackground.copy(alpha = 0.9f),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PlBorderSubtle)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${match.homeClub.code} ${match.homeScore} - ${match.awayScore} ${match.awayClub.code}",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        color = if (isLiveEdge) PlLiveRed else PlScoreAmber,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = if (isLiveEdge) "${match.minute}'" else "DVR",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Demo Mode & 4K Tag
            Surface(
                color = PlPurplePrimary.copy(alpha = 0.85f),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(
                    text = "DEMO FEED • 4K HDR",
                    color = Pl4kCyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        // Camera Angle Watermark in Top Right
        Surface(
            color = Color.Black.copy(alpha = 0.6f),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Videocam,
                    contentDescription = "Active Camera",
                    tint = PlPitchGreen,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = selectedCamera.title,
                    color = PlTextPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Player Controls Overlay
        AnimatedVisibility(
            visible = controlsVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.45f))
            ) {
                // Center Play / Seek Buttons
                Row(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(24.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { onSeekRelative(-10L) },
                        modifier = Modifier
                            .size(44.dp)
                            .background(PlSurfaceDeep.copy(alpha = 0.8f), CircleShape)
                            .testTag("player_seek_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Replay10,
                            contentDescription = "Seek back 10 seconds",
                            tint = Color.White
                        )
                    }

                    IconButton(
                        onClick = onTogglePlayPause,
                        modifier = Modifier
                            .size(64.dp)
                            .background(PlPurpleAccent, CircleShape)
                            .testTag("player_play_pause_btn")
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = Color.White,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    IconButton(
                        onClick = { onSeekRelative(10L) },
                        modifier = Modifier
                            .size(44.dp)
                            .background(PlSurfaceDeep.copy(alpha = 0.8f), CircleShape)
                            .testTag("player_seek_forward_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Forward10,
                            contentDescription = "Seek forward 10 seconds",
                            tint = Color.White
                        )
                    }
                }

                // Bottom Controls Bar: Scrub bar, Live Edge button, Quality, Audio, Camera, Stats
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    // Timeline Scrubber Slider
                    val progress = (currentSeconds.toFloat() / 5400f).coerceIn(0f, 1f)
                    Slider(
                        value = progress,
                        onValueChange = { frac ->
                            onSeekRelative((frac * 5400).toLong() - currentSeconds)
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = PlPurpleAccent,
                            activeTrackColor = PlPitchGreen,
                            inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(20.dp)
                            .testTag("player_timeline_slider")
                    )

                    // Control Actions Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Live Edge Jump button
                        Surface(
                            color = if (isLiveEdge) PlLiveRed else PlSurfaceElevated,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .clickable { onJumpLiveEdge() }
                                .testTag("jump_live_edge_btn")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .background(if (isLiveEdge) Color.White else PlTextSecondary, CircleShape)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isLiveEdge) "LIVE EDGE" else "GO TO LIVE",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Right Controls: Camera, Audio, Quality, Stats
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { showCameraDialog = true },
                                modifier = Modifier.testTag("player_camera_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SwitchVideo,
                                    contentDescription = "Switch Camera Angle",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            IconButton(
                                onClick = { showAudioDialog = true },
                                modifier = Modifier.testTag("player_audio_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VolumeUp,
                                    contentDescription = "Select Audio Track",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            IconButton(
                                onClick = { showQualityDialog = true },
                                modifier = Modifier.testTag("player_quality_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.HighQuality,
                                    contentDescription = "Select Quality",
                                    tint = Pl4kCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            IconButton(
                                onClick = onToggleStatsForGeeks,
                                modifier = Modifier.testTag("player_telemetry_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Speed,
                                    contentDescription = "Stream Health Telemetry",
                                    tint = if (showStatsForGeeks) PlPitchGreen else Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Stats for Geeks (Live Broadcast Telemetry Overlay)
        if (showStatsForGeeks) {
            Surface(
                color = PlDarkBackground.copy(alpha = 0.92f),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PlBorderSubtle),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .widthIn(max = 300.dp)
                    .testTag("telemetry_stats_overlay")
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "STREAM TELEMETRY (4K ENGINE)",
                            color = Pl4kCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Telemetry",
                            tint = PlTextSecondary,
                            modifier = Modifier
                                .size(16.dp)
                                .clickable { onToggleStatsForGeeks() }
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    TelemetryRow("Profile", selectedQuality.label)
                    TelemetryRow("Resolution", telemetry.currentResolution)
                    TelemetryRow("Bitrate", "${telemetry.actualBitrateMbps} Mbps (HEVC Main10)")
                    TelemetryRow("Buffer Health", "${telemetry.bufferHealthSeconds}s")
                    TelemetryRow("Live Edge Lag", "${telemetry.latencyToLiveEdgeSeconds}s")
                    TelemetryRow("Audio Codec", telemetry.audioCodec)
                    TelemetryRow("Edge Server", telemetry.cdnEdgeNode)
                    TelemetryRow("Frames Dropped", "${telemetry.droppedFrames} / ${telemetry.totalFrames}")
                }
            }
        }
    }

    // Quality Selection Dialog
    if (showQualityDialog) {
        AlertDialog(
            onDismissRequest = { showQualityDialog = false },
            title = { Text("Select Playback Profile", color = PlTextPrimary) },
            text = {
                Column {
                    QualityProfile.values().forEach { profile ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelectQuality(profile)
                                    showQualityDialog = false
                                }
                                .padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = profile.label,
                                    color = if (profile == selectedQuality) PlPurpleNeon else PlTextPrimary,
                                    fontWeight = if (profile == selectedQuality) FontWeight.Bold else FontWeight.Normal
                                )
                                Text(
                                    text = "${profile.resolution} • ${profile.bitrateMbps} Mbps",
                                    color = PlTextTertiary,
                                    fontSize = 12.sp
                                )
                            }
                            if (profile == selectedQuality) {
                                Icon(Icons.Default.Check, "Selected", tint = PlPurpleAccent)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showQualityDialog = false }) {
                    Text("DONE", color = PlPurpleAccent)
                }
            },
            containerColor = PlSurfaceDeep
        )
    }

    // Audio Selection Dialog
    if (showAudioDialog) {
        AlertDialog(
            onDismissRequest = { showAudioDialog = false },
            title = { Text("Select Audio Commentary Track", color = PlTextPrimary) },
            text = {
                Column {
                    AudioTrack.values().forEach { track ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelectAudio(track)
                                    showAudioDialog = false
                                }
                                .padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = track.title,
                                    color = if (track == selectedAudio) PlPitchGreen else PlTextPrimary,
                                    fontWeight = if (track == selectedAudio) FontWeight.Bold else FontWeight.Normal
                                )
                                Text(
                                    text = "${track.codec} • ${track.language}",
                                    color = PlTextTertiary,
                                    fontSize = 12.sp
                                )
                            }
                            if (track == selectedAudio) {
                                Icon(Icons.Default.Check, "Selected", tint = PlPitchGreen)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAudioDialog = false }) {
                    Text("DONE", color = PlPurpleAccent)
                }
            },
            containerColor = PlSurfaceDeep
        )
    }

    // Camera Angle Selection Dialog
    if (showCameraDialog) {
        AlertDialog(
            onDismissRequest = { showCameraDialog = false },
            title = { Text("Select Broadcast Camera Feed", color = PlTextPrimary) },
            text = {
                Column {
                    CameraAngle.values().forEach { cam ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelectCamera(cam)
                                    showCameraDialog = false
                                }
                                .padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = cam.title,
                                    color = if (cam == selectedCamera) Pl4kCyan else PlTextPrimary,
                                    fontWeight = if (cam == selectedCamera) FontWeight.Bold else FontWeight.Normal
                                )
                                Text(
                                    text = cam.description,
                                    color = PlTextTertiary,
                                    fontSize = 12.sp
                                )
                            }
                            if (cam == selectedCamera) {
                                Icon(Icons.Default.Check, "Selected", tint = Pl4kCyan)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showCameraDialog = false }) {
                    Text("DONE", color = PlPurpleAccent)
                }
            },
            containerColor = PlSurfaceDeep
        )
    }
}

@Composable
fun TelemetryRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = PlTextTertiary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        Text(text = value, color = PlTextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold)
    }
}
