package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ConnectedProvider
import com.example.ui.theme.*

@Composable
fun BroadcasterRightsScreen(
    providers: List<ConnectedProvider>,
    onShowToast: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var providerList by remember { mutableStateOf(providers) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(PlDarkBackground)
            .testTag("broadcaster_rights_screen"),
        contentPadding = PaddingValues(top = 14.dp, bottom = 90.dp, start = 16.dp, end = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text(
                    text = "BROADCASTER RIGHTS & ENTITLEMENTS",
                    color = PlTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Authorised provider integrations and territorial licensing validation",
                    color = PlTextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        // Territory & License Verification Status Card
        item {
            Surface(
                color = PlSurfaceDeep,
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PlBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, "Rights Security", tint = PlPitchGreen, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("TERRITORY ENTITLEMENT ENGINE", color = PlTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("• Detected Territory: United Kingdom (GB)", color = PlTextSecondary, fontSize = 12.sp)
                    Text("• Authorized Playback Resolution: Up to 2160p 4K UHD with HDR10", color = PlTextSecondary, fontSize = 12.sp)
                    Text("• Active Concurrent Stream Allowance: 4 Devices", color = PlTextSecondary, fontSize = 12.sp)
                    Text("• Digital Rights: Widevine L1 Hardware Decryption Active", color = PlPitchGreen, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        item {
            Text("CONNECTED BROADCASTER ACCOUNTS", color = PlTextTertiary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }

        items(providerList) { prov ->
            Surface(
                color = PlSurfaceDeep,
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (prov.isConnected) PlPitchGreenDark else PlBorderSubtle
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = if (prov.isConnected) PlPitchGreenDark else PlSurfaceHighlight,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Tv,
                                contentDescription = prov.name,
                                tint = if (prov.isConnected) PlPitchGreen else PlTextSecondary,
                                modifier = Modifier.padding(8.dp).size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(prov.name, color = PlTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("${prov.territory} • ${prov.subscriptionTier}", color = PlTextTertiary, fontSize = 11.sp)
                        }
                    }

                    Button(
                        onClick = {
                            val next = providerList.map {
                                if (it.id == prov.id) it.copy(isConnected = !it.isConnected) else it
                            }
                            providerList = next
                            onShowToast(if (!prov.isConnected) "Connected ${prov.name}" else "Disconnected ${prov.name}")
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (prov.isConnected) PlSurfaceHighlight else PlPurpleAccent
                        ),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Text(
                            text = if (prov.isConnected) "CONNECTED" else "CONNECT",
                            color = if (prov.isConnected) PlPitchGreen else Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
