package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.PremierLeagueRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AppDestination(val label: String) {
    HOME("Home"),
    MATCH_CENTRE("Match Centre"),
    MULTI_VIEW("Multi-View"),
    TACTICAL_STUDIO("Tactics"),
    FIXTURES("Fixtures"),
    CLUBS("Clubs"),
    HIGHLIGHTS("Replays"),
    SEARCH("Search"),
    RIGHTS("Broadcasters"),
    PROFILE("Account")
}

enum class MatchCentreTab(val label: String) {
    WATCH("WATCH"),
    COMMENTARY("COMMENTARY"),
    STATS("STATS"),
    LINE_UPS("LINE-UPS"),
    TACTICS("TACTICS"),
    EVENTS("EVENTS"),
    HEAD_TO_HEAD("HEAD-TO-HEAD")
}

enum class MultiViewLayout {
    DUAL_SPLIT,
    QUAD_GRID,
    FEATURED_PIP
}

enum class TacticalLayer {
    SHOT_MAP,
    PASS_NETWORK,
    PRESSING_TILT,
    FORMATIONS
}

data class GoalFlashAlert(
    val matchId: String,
    val matchTitle: String,
    val scorer: String,
    val minute: Int,
    val newScore: String,
    val isVisible: Boolean = false
)

data class UiState(
    val currentDestination: AppDestination = AppDestination.HOME,
    val previousDestination: AppDestination? = null,
    val isTvMode: Boolean = false,
    val selectedMatchId: String = "m_live_01",
    val matchCentreTab: MatchCentreTab = MatchCentreTab.WATCH,
    // Player controls & telemetry
    val isPlaying: Boolean = true,
    val playerCurrentSeconds: Long = 4440L, // ~74 mins in
    val isLiveEdge: Boolean = true,
    val showControls: Boolean = true,
    val showStatsForGeeks: Boolean = false,
    val selectedQuality: QualityProfile = QualityProfile.AUTO_4K,
    val selectedAudio: AudioTrack = AudioTrack.MAIN_BROADCAST,
    val selectedSubtitle: SubtitleTrack = SubtitleTrack.OFF,
    val selectedCamera: CameraAngle = CameraAngle.MAIN_BROADCAST,
    val telemetry: StreamTelemetry = StreamTelemetry(),
    // Multi-View
    val multiViewLayout: MultiViewLayout = MultiViewLayout.DUAL_SPLIT,
    val multiViewMatchIds: List<String> = listOf("m_live_01", "m_live_02", "m_live_03", "m_up_01"),
    val multiViewAudioFocusMatchId: String = "m_live_01",
    val goalFlashAlert: GoalFlashAlert? = null,
    // Tactical Studio
    val tacticalLayer: TacticalLayer = TacticalLayer.SHOT_MAP,
    val selectedPlayerComparisonA: String = "p_haaland",
    val selectedPlayerComparisonB: String = "p_salah",
    // Fixtures
    val selectedMatchweek: Int = 9,
    val fixtureClubFilter: String = "ALL",
    // Clubs
    val selectedClubDetailId: String? = null,
    // Universal Search
    val searchQuery: String = "",
    // Household & Demo
    val isDemoBannerVisible: Boolean = true,
    val userNotificationToast: String? = null
)

class PremierLeagueViewModel(
    private val repository: PremierLeagueRepository = PremierLeagueRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    val clubs: StateFlow<List<Club>> = repository.clubs
    val matches: StateFlow<List<Match>> = repository.matches
    val favoriteClubIds: StateFlow<Set<String>> = repository.favoriteClubIds
    val highlights: List<EditorialHighlight> = repository.highlights
    val connectedProviders: List<ConnectedProvider> = repository.connectedProviders

    init {
        startTelemetryLoop()
        startMultiViewSimulatedGoalFlash()
    }

    private fun startTelemetryLoop() {
        viewModelScope.launch {
            while (true) {
                delay(3000L)
                val cur = _uiState.value
                if (cur.isPlaying) {
                    val nextBitrate = 24.2 + (Math.random() * 1.4)
                    val nextBuffer = 4.2 + (Math.random() * 1.2)
                    val latency = if (cur.isLiveEdge) 1.1 + (Math.random() * 0.4) else 14.5
                    _uiState.update {
                        it.copy(
                            telemetry = it.telemetry.copy(
                                actualBitrateMbps = Math.round(nextBitrate * 10.0) / 10.0,
                                bufferHealthSeconds = Math.round(nextBuffer * 10.0) / 10.0,
                                latencyToLiveEdgeSeconds = Math.round(latency * 10.0) / 10.0,
                                totalFrames = it.telemetry.totalFrames + 180
                            )
                        )
                    }
                }
            }
        }
    }

    private fun startMultiViewSimulatedGoalFlash() {
        viewModelScope.launch {
            delay(12000L)
            _uiState.update {
                it.copy(
                    goalFlashAlert = GoalFlashAlert(
                        matchId = "m_live_02",
                        matchTitle = "LIV 2 - 1 CHE",
                        scorer = "Mohamed Salah (Pen 68')",
                        minute = 68,
                        newScore = "2 - 1",
                        isVisible = true
                    )
                )
            }
        }
    }

    fun navigateTo(dest: AppDestination) {
        _uiState.update {
            it.copy(
                previousDestination = it.currentDestination,
                currentDestination = dest
            )
        }
    }

    fun handleBackPress(): Boolean {
        val cur = _uiState.value
        return if (cur.selectedClubDetailId != null) {
            _uiState.update { it.copy(selectedClubDetailId = null) }
            true
        } else if (cur.currentDestination != AppDestination.HOME) {
            _uiState.update {
                it.copy(
                    currentDestination = it.previousDestination ?: AppDestination.HOME,
                    previousDestination = null
                )
            }
            true
        } else {
            false
        }
    }

    fun toggleTvMode() {
        _uiState.update { it.copy(isTvMode = !it.isTvMode) }
    }

    fun selectMatch(matchId: String, openTab: MatchCentreTab = MatchCentreTab.WATCH) {
        _uiState.update {
            it.copy(
                selectedMatchId = matchId,
                matchCentreTab = openTab,
                currentDestination = AppDestination.MATCH_CENTRE
            )
        }
    }

    fun selectMatchCentreTab(tab: MatchCentreTab) {
        _uiState.update { it.copy(matchCentreTab = tab) }
    }

    fun togglePlayPause() {
        _uiState.update { it.copy(isPlaying = !it.isPlaying) }
    }

    fun jumpToLiveEdge() {
        _uiState.update {
            it.copy(
                isLiveEdge = true,
                playerCurrentSeconds = 4440L,
                userNotificationToast = "Jumped to Live Broadcast Edge (1080p/4K HDR)"
            )
        }
    }

    fun seekRelative(seconds: Long) {
        _uiState.update {
            val next = (it.playerCurrentSeconds + seconds).coerceIn(0L, 5400L)
            it.copy(
                playerCurrentSeconds = next,
                isLiveEdge = (next >= 4400L)
            )
        }
    }

    fun toggleStatsForGeeks() {
        _uiState.update { it.copy(showStatsForGeeks = !it.showStatsForGeeks) }
    }

    fun setQuality(quality: QualityProfile) {
        _uiState.update {
            it.copy(
                selectedQuality = quality,
                telemetry = it.telemetry.copy(
                    selectedQuality = quality,
                    currentResolution = "${quality.resolution} @ 59.94fps",
                    actualBitrateMbps = quality.bitrateMbps
                ),
                userNotificationToast = "Stream profile switched to ${quality.label}"
            )
        }
    }

    fun setAudioTrack(audio: AudioTrack) {
        _uiState.update {
            it.copy(
                selectedAudio = audio,
                userNotificationToast = "Audio feed: ${audio.title}"
            )
        }
    }

    fun setSubtitle(subtitle: SubtitleTrack) {
        _uiState.update { it.copy(selectedSubtitle = subtitle) }
    }

    fun setCameraAngle(camera: CameraAngle) {
        _uiState.update {
            it.copy(
                selectedCamera = camera,
                userNotificationToast = "Switched to ${camera.title}"
            )
        }
    }

    fun setMultiViewLayout(layout: MultiViewLayout) {
        _uiState.update { it.copy(multiViewLayout = layout) }
    }

    fun setMultiViewAudioFocus(matchId: String) {
        _uiState.update {
            it.copy(
                multiViewAudioFocusMatchId = matchId,
                userNotificationToast = "Audio focus switched to match feed"
            )
        }
    }

    fun dismissGoalFlash() {
        _uiState.update { it.copy(goalFlashAlert = null) }
    }

    fun switchToGoalingMatch() {
        val alert = _uiState.value.goalFlashAlert ?: return
        selectMatch(alert.matchId, MatchCentreTab.WATCH)
        dismissGoalFlash()
    }

    fun setTacticalLayer(layer: TacticalLayer) {
        _uiState.update { it.copy(tacticalLayer = layer) }
    }

    fun setPlayerComparison(playerAId: String, playerBId: String) {
        _uiState.update {
            it.copy(
                selectedPlayerComparisonA = playerAId,
                selectedPlayerComparisonB = playerBId
            )
        }
    }

    fun setMatchweek(week: Int) {
        _uiState.update { it.copy(selectedMatchweek = week) }
    }

    fun setFixtureClubFilter(code: String) {
        _uiState.update { it.copy(fixtureClubFilter = code) }
    }

    fun toggleFavoriteClub(clubId: String) {
        repository.toggleFavoriteClub(clubId)
        val isFav = repository.favoriteClubIds.value.contains(clubId)
        _uiState.update {
            it.copy(userNotificationToast = if (isFav) "Added to Favourites" else "Removed from Favourites")
        }
    }

    fun selectClubDetail(clubId: String?) {
        _uiState.update { it.copy(selectedClubDetailId = clubId) }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun clearNotificationToast() {
        _uiState.update { it.copy(userNotificationToast = null) }
    }

    fun dismissDemoBanner() {
        _uiState.update { it.copy(isDemoBannerVisible = false) }
    }

    fun getSelectedMatch(): Match {
        val id = _uiState.value.selectedMatchId
        return repository.getMatchById(id) ?: matches.value.first()
    }

    fun getAllPlayers(): List<Player> = repository.getAllPlayers()

    fun getPlayerById(id: String): Player? = repository.getPlayerById(id)
}
