package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.TacticalLayer

@Composable
fun TacticalPitchCanvas(
    match: Match,
    layer: TacticalLayer,
    modifier: Modifier = Modifier
) {
    var selectedShot by remember { mutableStateOf<ShotData?>(null) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(PlSurfaceDeep)
            .border(1.dp, PlBorderSubtle, RoundedCornerShape(16.dp))
            .padding(12.dp)
            .testTag("tactical_pitch_canvas_container")
    ) {
        // Pitch Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = when (layer) {
                        TacticalLayer.SHOT_MAP -> "EXPECTED GOALS (xG) SHOT MAP"
                        TacticalLayer.PASS_NETWORK -> "PASSING NETWORK & NODES"
                        TacticalLayer.PRESSING_TILT -> "TERRITORIAL FIELD TILT & PRESSING"
                        TacticalLayer.FORMATIONS -> "TACTICAL FORMATIONS"
                    },
                    color = PlTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Spatial tracking model • Scaled to 105m x 68m standard pitch",
                    color = PlTextTertiary,
                    fontSize = 11.sp
                )
            }

            Surface(
                color = PlPurplePrimary,
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(
                    text = "${match.homeClub.code} vs ${match.awayClub.code}",
                    color = PlPurpleNeon,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Canvas Pitch
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(260.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF0F3B20))
                .border(1.dp, Color(0xFF1B5E34), RoundedCornerShape(12.dp))
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("interactive_pitch_canvas")
            ) {
                drawPitchMarkings()

                when (layer) {
                    TacticalLayer.SHOT_MAP -> {
                        drawShotMap(match.shotMap)
                    }
                    TacticalLayer.PASS_NETWORK -> {
                        drawPassNetwork(match)
                    }
                    TacticalLayer.PRESSING_TILT -> {
                        drawPressingTiltZones(match)
                    }
                    TacticalLayer.FORMATIONS -> {
                        drawFormations(match)
                    }
                }
            }

            // Legend / Selected Shot popup
            if (layer == TacticalLayer.SHOT_MAP) {
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(8.dp)
                        .background(PlDarkBackground.copy(alpha = 0.85f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LegendItem(color = PlPitchGreen, label = "Goal")
                    LegendItem(color = PlScoreAmber, label = "Saved")
                    LegendItem(color = PlLiveRed, label = "Missed")
                    LegendItem(color = Color.LightGray, label = "Blocked")
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Bottom Metric Summary
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            MetricChip(
                label = "Home xG",
                value = String.format("%.2f", match.homeStats.expectedGoals),
                color = PlPitchGreen
            )
            MetricChip(
                label = "Away xG",
                value = String.format("%.2f", match.awayStats.expectedGoals),
                color = Pl4kCyan
            )
            MetricChip(
                label = "Field Tilt",
                value = "${match.homeStats.fieldTiltPercentage}% - ${match.awayStats.fieldTiltPercentage}%",
                color = PlPurpleNeon
            )
            MetricChip(
                label = "PPDA (Press)",
                value = "${match.homeStats.ppda} vs ${match.awayStats.ppda}",
                color = PlTextPrimary
            )
        }
    }
}

@Composable
fun LegendItem(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .background(color, androidx.compose.foundation.shape.CircleShape)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = label, color = PlTextSecondary, fontSize = 10.sp)
    }
}

@Composable
fun MetricChip(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, color = PlTextTertiary, fontSize = 10.sp)
        Text(text = value, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

private fun DrawScope.drawPitchMarkings() {
    val w = size.width
    val h = size.height
    val lineCol = Color.White.copy(alpha = 0.45f)
    val strokeWidth = 1.5.dp.toPx()

    // Lawn grass alternating mowing stripes
    val stripeCount = 6
    val stripeWidth = w / stripeCount
    for (i in 0 until stripeCount step 2) {
        drawRect(
            color = Color(0xFF134727),
            topLeft = Offset(i * stripeWidth, 0f),
            size = Size(stripeWidth, h)
        )
    }

    // Outer boundary
    drawRect(
        color = lineCol,
        topLeft = Offset(8f, 8f),
        size = Size(w - 16f, h - 16f),
        style = Stroke(strokeWidth)
    )

    // Halfway line
    drawLine(
        color = lineCol,
        start = Offset(w / 2f, 8f),
        end = Offset(w / 2f, h - 8f),
        strokeWidth = strokeWidth
    )

    // Center circle
    drawCircle(
        color = lineCol,
        radius = h * 0.18f,
        center = Offset(w / 2f, h / 2f),
        style = Stroke(strokeWidth)
    )

    // Center spot
    drawCircle(
        color = lineCol,
        radius = 3.dp.toPx(),
        center = Offset(w / 2f, h / 2f)
    )

    // Left Penalty Box (18-yard box)
    val boxWidth = w * 0.16f
    val boxHeight = h * 0.55f
    drawRect(
        color = lineCol,
        topLeft = Offset(8f, (h - boxHeight) / 2f),
        size = Size(boxWidth, boxHeight),
        style = Stroke(strokeWidth)
    )

    // Right Penalty Box
    drawRect(
        color = lineCol,
        topLeft = Offset(w - 8f - boxWidth, (h - boxHeight) / 2f),
        size = Size(boxWidth, boxHeight),
        style = Stroke(strokeWidth)
    )

    // 6-yard boxes
    val sixWidth = w * 0.06f
    val sixHeight = h * 0.30f
    drawRect(
        color = lineCol,
        topLeft = Offset(8f, (h - sixHeight) / 2f),
        size = Size(sixWidth, sixHeight),
        style = Stroke(strokeWidth)
    )
    drawRect(
        color = lineCol,
        topLeft = Offset(w - 8f - sixWidth, (h - sixHeight) / 2f),
        size = Size(sixWidth, sixHeight),
        style = Stroke(strokeWidth)
    )
}

private fun DrawScope.drawShotMap(shots: List<ShotData>) {
    shots.forEach { shot ->
        val x = shot.x * size.width
        val y = shot.y * size.height
        val radius = (shot.xG * 24 + 6).toFloat()

        val shotColor = when (shot.outcome) {
            "Goal" -> PlPitchGreen
            "Saved" -> PlScoreAmber
            "Missed" -> PlLiveRed
            else -> Color.LightGray
        }

        // Glow ring
        drawCircle(
            color = shotColor.copy(alpha = 0.3f),
            radius = radius + 4f,
            center = Offset(x, y)
        )
        // Solid core
        drawCircle(
            color = shotColor,
            radius = radius,
            center = Offset(x, y)
        )
        // Center white dot
        drawCircle(
            color = Color.White,
            radius = 2.dp.toPx(),
            center = Offset(x, y)
        )
    }
}

private fun DrawScope.drawPassNetwork(match: Match) {
    // Draw connecting passing lines between key positions
    val w = size.width
    val h = size.height

    val node1 = Offset(w * 0.25f, h * 0.5f)
    val node2 = Offset(w * 0.42f, h * 0.35f)
    val node3 = Offset(w * 0.45f, h * 0.65f)
    val node4 = Offset(w * 0.68f, h * 0.25f)
    val node5 = Offset(w * 0.72f, h * 0.52f)

    // Pass thickness links
    drawLine(PlPitchGreen.copy(alpha = 0.7f), node1, node2, strokeWidth = 5f, cap = StrokeCap.Round)
    drawLine(PlPitchGreen.copy(alpha = 0.7f), node1, node3, strokeWidth = 4f, cap = StrokeCap.Round)
    drawLine(PlPitchGreen.copy(alpha = 0.7f), node2, node4, strokeWidth = 6f, cap = StrokeCap.Round)
    drawLine(PlPitchGreen.copy(alpha = 0.7f), node3, node5, strokeWidth = 5f, cap = StrokeCap.Round)

    // Nodes
    listOf(node1, node2, node3, node4, node5).forEach { pos ->
        drawCircle(PlDarkBackground, radius = 10.dp.toPx(), center = pos)
        drawCircle(PlPitchGreen, radius = 9.dp.toPx(), center = pos, style = Stroke(2.dp.toPx()))
    }
}

private fun DrawScope.drawPressingTiltZones(match: Match) {
    val w = size.width
    val h = size.height

    // Defensive third
    drawRect(
        color = PlPitchGreen.copy(alpha = 0.15f),
        topLeft = Offset(8f, 8f),
        size = Size(w * 0.33f, h - 16f)
    )
    // Middle third
    drawRect(
        color = PlScoreAmber.copy(alpha = 0.12f),
        topLeft = Offset(w * 0.33f, 8f),
        size = Size(w * 0.33f, h - 16f)
    )
    // Attacking third (Field Tilt)
    drawRect(
        color = PlPurpleAccent.copy(alpha = 0.22f),
        topLeft = Offset(w * 0.66f, 8f),
        size = Size(w * 0.33f - 8f, h - 16f)
    )
}

private fun DrawScope.drawFormations(match: Match) {
    val w = size.width
    val h = size.height

    // Draw Arsenal 4-3-3 nodes on left
    val homeNodes = listOf(
        Offset(w * 0.08f, h * 0.50f), // GK
        Offset(w * 0.22f, h * 0.20f), // LB
        Offset(w * 0.20f, h * 0.40f), // CB
        Offset(w * 0.20f, h * 0.60f), // CB
        Offset(w * 0.22f, h * 0.80f), // RB
        Offset(w * 0.32f, h * 0.35f), // LCM
        Offset(w * 0.30f, h * 0.50f), // CM (Rice)
        Offset(w * 0.32f, h * 0.65f), // RCM
        Offset(w * 0.42f, h * 0.22f), // LW
        Offset(w * 0.44f, h * 0.50f), // ST
        Offset(w * 0.42f, h * 0.78f)  // RW (Saka)
    )

    homeNodes.forEach { pt ->
        drawCircle(Color(0xFFEF0107), radius = 8.dp.toPx(), center = pt)
        drawCircle(Color.White, radius = 8.dp.toPx(), center = pt, style = Stroke(1.5.dp.toPx()))
    }

    // Draw City 4-2-3-1 nodes on right
    val awayNodes = listOf(
        Offset(w * 0.92f, h * 0.50f), // GK
        Offset(w * 0.78f, h * 0.20f), // RB
        Offset(w * 0.80f, h * 0.40f), // CB
        Offset(w * 0.80f, h * 0.60f), // CB
        Offset(w * 0.78f, h * 0.80f), // LB
        Offset(w * 0.68f, h * 0.40f), // DM
        Offset(w * 0.68f, h * 0.60f), // DM
        Offset(w * 0.60f, h * 0.22f), // RW
        Offset(w * 0.58f, h * 0.50f), // AM (De Bruyne)
        Offset(w * 0.60f, h * 0.78f), // LW
        Offset(w * 0.54f, h * 0.50f)  // ST (Haaland)
    )

    awayNodes.forEach { pt ->
        drawCircle(Color(0xFF6CABDD), radius = 8.dp.toPx(), center = pt)
        drawCircle(Color.White, radius = 8.dp.toPx(), center = pt, style = Stroke(1.5.dp.toPx()))
    }
}
