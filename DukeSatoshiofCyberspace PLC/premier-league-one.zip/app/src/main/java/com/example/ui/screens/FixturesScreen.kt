package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Club
import com.example.data.model.Match
import com.example.ui.components.MatchCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.MatchCentreTab

@Composable
fun FixturesScreen(
    matches: List<Match>,
    clubs: List<Club>,
    selectedMatchweek: Int,
    onSelectMatchweek: (Int) -> Unit,
    selectedClubFilter: String,
    onSelectClubFilter: (String) -> Unit,
    onSelectMatch: (String, MatchCentreTab) -> Unit,
    onSetReminderToast: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var remindersSet by remember { mutableStateOf(setOf<String>()) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(PlDarkBackground)
            .testTag("fixtures_screen"),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            // Header
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Text(
                    text = "FIXTURES & CALENDAR",
                    color = PlTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Season 2026/27 • Live TV Schedule & Kickoff times in Local Time",
                    color = PlTextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        // Matchweek Switcher Chips
        item {
            Column(modifier = Modifier.padding(bottom = 12.dp)) {
                Text(
                    text = "MATCHWEEK",
                    color = PlTextTertiary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(listOf(8, 9, 10, 11, 12, 13)) { mw ->
                        val isSelected = mw == selectedMatchweek
                        Surface(
                            color = if (isSelected) PlPurplePrimary else PlSurfaceDeep,
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) PlPurpleNeon else PlBorderSubtle
                            ),
                            modifier = Modifier
                                .clickable { onSelectMatchweek(mw) }
                                .testTag("mw_chip_$mw")
                        ) {
                            Text(
                                text = "MW $mw",
                                color = if (isSelected) Color.White else PlTextSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }
        }

        // Club Filter Chips
        item {
            Column(modifier = Modifier.padding(bottom = 16.dp)) {
                Text(
                    text = "FILTER BY CLUB",
                    color = PlTextTertiary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        val isAll = selectedClubFilter == "ALL"
                        Surface(
                            color = if (isAll) PlPitchGreenDark else PlSurfaceDeep,
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isAll) PlPitchGreen else PlBorderSubtle
                            ),
                            modifier = Modifier.clickable { onSelectClubFilter("ALL") }
                        ) {
                            Text(
                                text = "All Clubs",
                                color = if (isAll) PlPitchGreen else PlTextSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }

                    items(clubs) { club ->
                        val isSelected = selectedClubFilter == club.code
                        Surface(
                            color = if (isSelected) PlPurplePrimary else PlSurfaceDeep,
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) PlPurpleNeon else PlBorderSubtle
                            ),
                            modifier = Modifier.clickable { onSelectClubFilter(club.code) }
                        ) {
                            Text(
                                text = club.shortName,
                                color = if (isSelected) Color.White else PlTextSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // Filtered Fixtures List
        val filteredMatches = matches.filter { m ->
            (selectedClubFilter == "ALL" || m.homeClub.code == selectedClubFilter || m.awayClub.code == selectedClubFilter)
        }

        if (filteredMatches.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No fixtures match the selected filter in Matchweek $selectedMatchweek",
                        color = PlTextTertiary,
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            items(filteredMatches) { m ->
                val hasReminder = remindersSet.contains(m.id)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    MatchCard(
                        match = m,
                        onClick = { onSelectMatch(m.id, MatchCentreTab.WATCH) },
                        onWatchClick = { onSelectMatch(m.id, MatchCentreTab.WATCH) }
                    )

                    // Reminder Button
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp, end = 4.dp),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = {
                                remindersSet = if (hasReminder) remindersSet - m.id else remindersSet + m.id
                                onSetReminderToast(
                                    if (!hasReminder) "Reminder set for ${m.homeClub.shortName} vs ${m.awayClub.shortName}" else "Reminder removed"
                                )
                            },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Icon(
                                imageVector = if (hasReminder) Icons.Default.NotificationsActive else Icons.Default.Alarm,
                                contentDescription = "Reminder",
                                tint = if (hasReminder) PlPitchGreen else PlTextTertiary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (hasReminder) "REMINDER SET" else "ADD TO CALENDAR",
                                color = if (hasReminder) PlPitchGreen else PlTextTertiary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
