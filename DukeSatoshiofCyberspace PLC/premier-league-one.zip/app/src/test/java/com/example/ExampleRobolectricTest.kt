package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AudioTrack
import com.example.data.model.QualityProfile
import com.example.data.repository.PremierLeagueRepository
import com.example.ui.viewmodel.AppDestination
import com.example.ui.viewmodel.MultiViewLayout
import com.example.ui.viewmodel.PremierLeagueViewModel
import com.example.ui.viewmodel.TacticalLayer
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun testAppNameString() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Premier League One", appName)
    }

    @Test
    fun testRepositoryInitializesClubsAndMatches() {
        val repo = PremierLeagueRepository()
        val clubs = repo.clubs.value
        assertEquals(20, clubs.size)
        assertTrue(clubs.any { it.code == "ARS" })
        assertTrue(clubs.any { it.code == "MCI" })

        val matches = repo.matches.value
        assertTrue(matches.isNotEmpty())
        val liveMatch = matches.first { it.isLive }
        assertNotNull(liveMatch)
        assertEquals("Sky Sports Main Event 4K UHD", liveMatch.broadcasterName)
    }

    @Test
    fun testViewModelNavigationAndControls() {
        val repo = PremierLeagueRepository()
        val viewModel = PremierLeagueViewModel(repo)

        // Initial destination
        assertEquals(AppDestination.HOME, viewModel.uiState.value.currentDestination)

        // Navigation
        viewModel.navigateTo(AppDestination.MULTI_VIEW)
        assertEquals(AppDestination.MULTI_VIEW, viewModel.uiState.value.currentDestination)

        // Quality Profile Switch
        viewModel.setQuality(QualityProfile.UHD_4K)
        assertEquals(QualityProfile.UHD_4K, viewModel.uiState.value.selectedQuality)

        // Audio Track Switch
        viewModel.setAudioTrack(AudioTrack.STADIUM_ATMOSPHERE)
        assertEquals(AudioTrack.STADIUM_ATMOSPHERE, viewModel.uiState.value.selectedAudio)

        // MultiView Layout Switch
        viewModel.setMultiViewLayout(MultiViewLayout.QUAD_GRID)
        assertEquals(MultiViewLayout.QUAD_GRID, viewModel.uiState.value.multiViewLayout)

        // Tactical Layer
        viewModel.setTacticalLayer(TacticalLayer.PASS_NETWORK)
        assertEquals(TacticalLayer.PASS_NETWORK, viewModel.uiState.value.tacticalLayer)

        // Favorite Toggle
        val arsFavInitial = viewModel.favoriteClubIds.value.contains("ars")
        viewModel.toggleFavoriteClub("ars")
        assertNotEquals(arsFavInitial, viewModel.favoriteClubIds.value.contains("ars"))
    }
}
