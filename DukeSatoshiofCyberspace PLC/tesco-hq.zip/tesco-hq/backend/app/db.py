from sqlalchemy import Column, DateTime, ForeignKey, Integer, MetaData, Numeric, create_engine, func
from sqlalchemy.orm import declarative_base, sessionmaker

from .config import settings

convention = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}
Base = declarative_base(metadata=MetaData(naming_convention=convention))
engine = create_engine(settings.database_url, pool_pre_ping=True, pool_size=10, max_overflow=30)
SessionLocal = sessionmaker(engine, expire_on_commit=False)

Money = Numeric(14, 2)   # currency amounts, GBP, 2dp
Cost = Numeric(14, 4)    # unit costs carry 4dp to avoid case->unit rounding drift
Qty = Numeric(14, 3)     # quantities in base units (each or kg)


def pk():
    return Column(Integer, primary_key=True)


def fk(target, **kw):
    kw.setdefault("index", True)
    return Column(Integer, ForeignKey(target), **kw)


def ts(**kw):
    return Column(DateTime(timezone=True), server_default=func.now(), nullable=False, **kw)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
