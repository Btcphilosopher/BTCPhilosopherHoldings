"""Object storage for documents (supplier certificates, delivery notes, product images).
S3-compatible (MinIO in Docker Compose); falls back to a local directory when no endpoint is set."""
import os
import uuid
from typing import Protocol

from .config import settings


class DocumentStore(Protocol):
    def put(self, name: str, data: bytes, content_type: str) -> str: ...
    def get(self, key: str) -> bytes: ...


class LocalStore:
    def __init__(self, root):
        self.root = root
        os.makedirs(root, exist_ok=True)

    def put(self, name, data, content_type):
        key = f"{uuid.uuid4().hex}-{os.path.basename(name)}"
        with open(os.path.join(self.root, key), "wb") as f:
            f.write(data)
        return key

    def get(self, key):
        with open(os.path.join(self.root, os.path.basename(key)), "rb") as f:
            return f.read()


class S3Store:
    def __init__(self):
        import boto3
        self.s3 = boto3.client("s3", endpoint_url=settings.s3_endpoint, aws_access_key_id=settings.s3_access_key,
                               aws_secret_access_key=settings.s3_secret_key, region_name="us-east-1")
        self.bucket = settings.s3_bucket
        try:
            self.s3.head_bucket(Bucket=self.bucket)
        except Exception:  # noqa: BLE001
            self.s3.create_bucket(Bucket=self.bucket)

    def put(self, name, data, content_type):
        key = f"{uuid.uuid4().hex}/{os.path.basename(name)}"
        self.s3.put_object(Bucket=self.bucket, Key=key, Body=data, ContentType=content_type)
        return key

    def get(self, key):
        return self.s3.get_object(Bucket=self.bucket, Key=key)["Body"].read()


_store = None


def store() -> DocumentStore:
    global _store
    if _store is None:
        _store = S3Store() if settings.s3_endpoint else LocalStore(settings.local_storage_dir)
    return _store
