"""Background worker: relays the outbox to integration adapters, confirms price publications,
runs queued jobs (forecasts, timesheet imports) and periodic housekeeping.

Run with:  python -m app.worker        (one process; safe to run several - rows are claimed with SKIP LOCKED)"""
import logging
import time
from datetime import date, timedelta

from sqlalchemy import select, text

from . import models_registry  # noqa: F401
from .adapters import mocks
from .cache import wait_for_wake
from .common import flag, now
from .db import SessionLocal
from .domains.loyalty import service as loyalty
from .domains.platform.models import IntegrationDelivery, Job, OutboxEvent
from .domains.pricing import service as pricing
from .domains.procurement import forecasting
from .domains.procurement.models import PurchaseOrder
from .domains.workforce.api import run_timesheet_import

log = logging.getLogger("thq.worker")
ROUTES = {  # topic -> adapter label
    "purchase_order.approved": "supplier_edi", "price.published": "pos_gateway", "sale.completed": "analytics_feed",
    "sale.refunded": "analytics_feed", "online_order.placed": "ecommerce", "goods_receipt.posted": "wms", "route.dispatched": "tms",
}


def relay_outbox(db, limit=100):
    n = 0
    for ev in db.execute(select(OutboxEvent).where(OutboxEvent.published_at.is_(None)).order_by(OutboxEvent.id).limit(limit)
                         .with_for_update(skip_locked=True)).scalars().all():
        adapter = ROUTES.get(ev.topic, "unrouted")
        try:
            if ev.topic == "purchase_order.approved":
                resp = mocks.supplier_edi.send_purchase_order(ev.key, ev.payload)
            elif ev.topic == "price.published":
                resp = pricing.deliver_publications(db, ev.payload["item_type"], ev.payload["item_id"])
            else:
                resp = {"delivered": True, "simulator": True}
            status = "delivered"
        except Exception as e:  # noqa: BLE001
            resp, status = {"error": str(e)}, "failed"
        ev.attempts += 1
        if status == "delivered" or ev.attempts >= 5:
            ev.published_at = now()
        db.add(IntegrationDelivery(adapter=adapter, event_id=ev.id, topic=ev.topic, status=status, response=resp))
        n += 1
    db.commit()
    return n


def run_jobs(db):
    job = db.execute(select(Job).where(Job.status == "queued").order_by(Job.id).limit(1).with_for_update(skip_locked=True)).scalar_one_or_none()
    if not job:
        return 0
    job.status, job.started_at = "running", now()
    db.commit()
    try:
        if job.kind == "forecast":
            forecasting.rollup_demand(db, date.today() - timedelta(days=3), date.today() - timedelta(days=1))
            run = forecasting.run_forecast(db, as_of=date.today(), horizon=job.payload.get("horizon_days", 14),
                                           holdout=job.payload.get("holdout_days", 14), actor_id=job.created_by)
            job.result = {"forecast_run_id": run.id, "chosen_method": run.chosen_method, "evaluation": run.evaluation}
        elif job.kind == "timesheet_import":
            job.result = run_timesheet_import(db, job)
        elif job.kind == "loyalty_expiry":
            job.result = loyalty.expire_inactive(db)
        else:
            raise ValueError(f"unknown job kind {job.kind}")
        job.status = "succeeded"
    except Exception as e:  # noqa: BLE001
        db.rollback()
        job = db.get(Job, job.id)
        job.status, job.result = "failed", {"error": f"{type(e).__name__}: {e}"}
        log.exception("job %s failed", job.id)
    job.finished_at = now()
    db.commit()
    return 1


def housekeeping(db):
    """Periodic checks that raise exceptions for people to act on. Idempotent via dedupe keys."""
    for po in db.execute(select(PurchaseOrder).where(PurchaseOrder.status.in_(["approved", "part_received"]),
                                                     PurchaseOrder.expected_date < date.today())).scalars():
        flag(db, "late_delivery", f"{po.number} was due {po.expected_date} and is not fully received", severity="high",
             entity_type="purchase_order", entity_id=po.id, site_id=po.site_id, dedupe=f"po-late:{po.id}")
    for r in db.execute(text("""SELECT b.site_id, l.id lot_id, l.lot_code, p.name, SUM(b.qty) q, l.expiry_date FROM stock_balances b JOIN lots l ON l.id=b.lot_id
            JOIN products p ON p.id=b.product_id WHERE b.bucket='available' AND b.qty>0 AND l.expiry_date <= current_date + 1 GROUP BY b.site_id, l.id, p.name""")):
        flag(db, "expiry_risk", f"{r.q} x {r.name} (lot {r.lot_code}) expires {r.expiry_date}", severity="medium", entity_type="lot",
             entity_id=r.lot_id, site_id=r.site_id, dedupe=f"exp:{r.site_id}:{r.lot_id}")
    for r in db.execute(text("""SELECT t.id, e.name, e.site_id, t.course, t.expires_on FROM training_records t JOIN employees e ON e.id=t.employee_id
            WHERE t.expires_on BETWEEN current_date - 30 AND current_date + 30""")):
        flag(db, "qualification_expiring", f"{r.name}: '{r.course}' expires {r.expires_on}", severity="low", entity_type="training_record",
             entity_id=r.id, site_id=r.site_id, dedupe=f"train:{r.id}")
    for r in db.execute(text("SELECT q.id, s.name, q.kind, q.valid_to FROM supplier_qualifications q JOIN suppliers s ON s.id=q.supplier_id WHERE q.valid_to <= current_date + 30")):
        flag(db, "supplier_qualification", f"{r.name}: {r.kind} valid to {r.valid_to}", severity="medium", entity_type="supplier_qualification",
             entity_id=r.id, dedupe=f"squal:{r.id}")
    db.commit()


def tick(db):
    return relay_outbox(db) + run_jobs(db)


def drain(db, rounds=20):
    """Process everything pending (used by the seed script and tests)."""
    for _ in range(rounds):
        if tick(db) == 0:
            break
    housekeeping(db)


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    log.info("worker started")
    last_hk = 0.0
    while True:
        with SessionLocal() as db:
            try:
                did = tick(db)
                if time.time() - last_hk > 60:
                    housekeeping(db)
                    last_hk = time.time()
            except Exception:  # noqa: BLE001
                db.rollback()
                log.exception("worker tick failed")
                did = 0
        if not did:
            wait_for_wake(2)


if __name__ == "__main__":
    main()
