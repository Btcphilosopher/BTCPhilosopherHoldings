"""Integration boundaries. Each external system is reached only through one of these interfaces.
The bundled implementations are simulators; real adapters implement the same Protocol.
No endpoint, payload or credential of any real retailer is assumed anywhere in this codebase."""
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Protocol


@dataclass
class PaymentResult:
    status: str            # succeeded | failed | uncertain
    ref: str | None = None
    message: str = ""


class PaymentProviderTimeout(Exception):
    """The provider did not answer. The outcome is UNKNOWN - it may or may not have taken the money."""


class PaymentProvider(Protocol):
    name: str
    def authorise(self, db, key: str, amount: Decimal, token: str) -> PaymentResult: ...
    def capture(self, db, key: str, auth_ref: str, amount: Decimal) -> PaymentResult: ...
    def charge(self, db, key: str, amount: Decimal, token: str) -> PaymentResult: ...
    def refund(self, db, key: str, parent_ref: str, amount: Decimal) -> PaymentResult: ...
    def void(self, db, key: str, auth_ref: str) -> PaymentResult: ...
    def lookup(self, db, key: str) -> PaymentResult | None: ...
    def settlement_report(self, db, business_date) -> dict: ...


class PosGateway(Protocol):
    """Pushes price/promotion files to store terminals and the e-commerce platform."""
    def push(self, terminal_code: str, online: bool, item_type: str, item_id: int) -> tuple[bool, str]: ...


class WarehouseScanner(Protocol):
    def confirm(self, task_id: int, operator_id: int | None) -> str: ...


class VehicleTracking(Protocol):
    def eta(self, fleet_no: str, stop_seq: int, planned: datetime) -> tuple[datetime, str]: ...


class ProofOfDelivery(Protocol):
    def capture(self, stop_id: int, receiver: str) -> str: ...


class HrPayrollGateway(Protocol):
    """Boundary to the HR / payroll system of record. This platform plans rotas; it does not run payroll."""
    def export_timesheets(self, entries: list[dict]) -> dict: ...


class LoyaltyProgrammeGateway(Protocol):
    """Future integration point for an external loyalty platform."""
    def sync_member(self, member_no: str) -> dict: ...


class SupplierGateway(Protocol):
    def send_purchase_order(self, po_number: str, payload: dict) -> dict: ...


class InsightProvider(Protocol):
    """Summarises exceptions. Must return citations and is never given write access."""
    def summarise(self, exceptions: list[dict]) -> dict: ...
