from sqlalchemy import Column, Date, DateTime, Integer, String

from ..db import Base, Money, pk, ts


class MockPspTransaction(Base):
    """State held by the *simulated* payment provider. In production this lives at the provider;
    it is in the database here only so the demo can show reconciliation and uncertain outcomes."""
    __tablename__ = "mock_psp_transactions"
    id = pk()
    idempotency_key = Column(String(120), unique=True, nullable=False)
    kind = Column(String(12), nullable=False)  # authorise|capture|refund|void|charge
    amount = Column(Money, nullable=False)
    status = Column(String(12), nullable=False)
    ref = Column(String(80), unique=True, nullable=False)
    parent_ref = Column(String(80))
    business_date = Column(Date)
    created_at = ts()
    settled_batch = Column(String(60))
