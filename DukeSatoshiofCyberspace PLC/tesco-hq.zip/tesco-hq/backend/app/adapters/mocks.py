"""Simulated external systems for the demonstration. Deterministic, clearly labelled, replaceable."""
import hashlib
from collections import defaultdict
from datetime import timedelta
from decimal import Decimal

from sqlalchemy import func, select

from ..common import ZERO, now, q2
from .base import PaymentProviderTimeout, PaymentResult
from .models import MockPspTransaction


class MockPaymentProvider:
    """Test tokens:  tok_ok -> succeeds;  tok_declined -> fails;
    tok_timeout -> the provider records the authorisation but the response is 'lost' (uncertain outcome)."""
    name = "MockPay (simulator)"
    today = None  # seed scripts set this to back-date simulated history

    def _get(self, db, key):
        return db.execute(select(MockPspTransaction).where(MockPspTransaction.idempotency_key == key)).scalar_one_or_none()

    def _record(self, db, key, kind, amount, status, parent=None):
        existing = self._get(db, key)
        if existing:  # provider-side idempotency: same key, same transaction, no second charge
            return existing, False
        ref = "mp_" + hashlib.sha1(key.encode()).hexdigest()[:16]
        t = MockPspTransaction(idempotency_key=key, kind=kind, amount=amount, status=status, ref=ref, parent_ref=parent,
                               business_date=self.today or now().date())
        db.add(t)
        db.flush()
        return t, True

    def authorise(self, db, key, amount, token):
        if token == "tok_declined":
            t, _ = self._record(db, key, "authorise", amount, "failed")
            return PaymentResult("failed", t.ref, "card declined (simulated)")
        t, created = self._record(db, key, "authorise", amount, "succeeded")
        if token == "tok_timeout" and created:
            raise PaymentProviderTimeout("gateway timeout (simulated): outcome unknown")
        return PaymentResult(t.status, t.ref)

    def charge(self, db, key, amount, token="tok_ok"):
        t, _ = self._record(db, key, "charge", amount, "failed" if token == "tok_declined" else "succeeded")
        return PaymentResult(t.status, t.ref)

    def capture(self, db, key, auth_ref, amount):
        t, _ = self._record(db, key, "capture", amount, "succeeded", auth_ref)
        return PaymentResult(t.status, t.ref)

    def refund(self, db, key, parent_ref, amount):
        t, _ = self._record(db, key, "refund", amount, "succeeded", parent_ref)
        return PaymentResult(t.status, t.ref)

    def void(self, db, key, auth_ref):
        t, _ = self._record(db, key, "void", ZERO, "succeeded", auth_ref)
        return PaymentResult(t.status, t.ref)

    def lookup(self, db, key):
        t = self._get(db, key)
        return PaymentResult(t.status, t.ref) if t else None

    def settlement_report(self, db, business_date):
        """What the provider says it will pay for a business date. Fee rate is the simulator's own."""
        rows = db.execute(select(MockPspTransaction).where(
            MockPspTransaction.business_date == business_date, MockPspTransaction.status == "succeeded",
            MockPspTransaction.kind.in_(["charge", "capture", "refund"]))).scalars().all()
        gross = sum((r.amount for r in rows if r.kind != "refund"), ZERO)
        refunds = sum((r.amount for r in rows if r.kind == "refund"), ZERO)
        fees = q2(gross * Decimal("0.012"))
        return {"provider": self.name, "batch_ref": f"MP-{business_date:%Y%m%d}", "business_date": business_date,
                "gross": gross, "refunds": refunds, "fees": fees, "net": gross - refunds - fees,
                "refs": {r.ref: (r.kind, r.amount) for r in rows}}


class MockPosGateway:
    def push(self, terminal_code, online, item_type, item_id):
        if not online:
            return False, "terminal offline - no acknowledgement (simulated)"
        return True, "acknowledged"


class MockScanner:
    def confirm(self, task_id, operator_id):
        return f"SCAN-{task_id:06d}"


class MockVehicleTracking:
    """Deterministic pseudo-telemetry: delay derived from the fleet number and stop sequence."""
    def eta(self, fleet_no, stop_seq, planned):
        delay = (int(hashlib.sha1(f"{fleet_no}:{stop_seq}".encode()).hexdigest(), 16) % 5) * 9 - 9  # -9..27 min
        return planned + timedelta(minutes=delay), "MockTrack telemetry (simulator)"


class MockProofOfDelivery:
    def capture(self, stop_id, receiver):
        return f"POD-{stop_id:06d}"


class MockHrGateway:
    def export_timesheets(self, entries):
        return {"accepted": len(entries), "system": "HR/payroll simulator", "note": "No payroll is calculated by this platform"}


class MockSupplierGateway:
    def send_purchase_order(self, po_number, payload):
        return {"accepted": True, "channel": "EDI simulator", "po": po_number}


class DemoLoyaltyGateway:
    def sync_member(self, member_no):
        return {"synced": False, "note": "No external loyalty platform is connected in the demonstration"}


class RuleBasedInsights:
    """Deterministic summariser. Groups exceptions, cites every record, suggests what to look at.
    It has no write access: it cannot change prices, approve payments or touch personnel records."""
    SUGGEST = {
        "late_delivery": "Review the supplier's on-time record and whether safety stock covers the lead-time variability.",
        "receipt_discrepancy": "Compare the receipt with the PO and raise a claim or supplier return before invoice matching.",
        "invoice_mismatch": "Hold payment; check invoice quantity and price against the receipt and PO lines cited.",
        "payment_uncertain": "Query the provider with the original idempotency key before retrying - do not charge again.",
        "promotion_conflict": "Confirm the intended precedence with Pricing; the simulator shows which offer wins.",
        "price_not_confirmed": "Check terminal connectivity; the shelf-edge label and till may disagree until acknowledged.",
        "stock_discrepancy": "Schedule a cycle count for the product and check recent receipts and waste postings.",
        "infeasible_route": "Add vehicle capacity or renegotiate the delivery window; the plan did not schedule this stop.",
        "failed_delivery": "Confirm stock returned to the DC and rebook the store delivery.",
        "expiry_risk": "Consider a short-dated markdown (requires pricing approval) or a transfer to a faster-selling store.",
        "qualification_expiring": "Arrange refresher training before the expiry date; the duty cannot be rostered afterwards.",
        "supplier_qualification": "Request the renewed certificate; consider suspending new orders if it lapses.",
        "cash_variance": "Recount the till float and review refunds and voids for the day.",
        "settlement_difference": "Match the unmatched provider references listed against the payments ledger.",
    }

    def summarise(self, exceptions):
        groups = defaultdict(list)
        for e in exceptions:
            groups[e["kind"]].append(e)
        items = []
        for kind, es in sorted(groups.items(), key=lambda kv: (-sum(x["severity"] == "high" for x in kv[1]), -len(kv[1]))):
            items.append({
                "kind": kind, "count": len(es), "high_severity": sum(x["severity"] == "high" for x in es),
                "summary": f"{len(es)} open '{kind.replace('_', ' ')}' exception(s); e.g. {es[0]['title']}",
                "suggested_investigation": self.SUGGEST.get(kind, "Open the cited records and review."),
                "citations": [{"exception_id": x["id"], "entity_type": x["entity_type"], "entity_id": x["entity_id"],
                               "title": x["title"]} for x in es[:8]]})
        return {"provider": "rules (deterministic, no language model)", "generated_at": now(), "items": items,
                "guardrails": "Advisory only. Cannot change prices, approve payments or alter personnel records. "
                              "Every statement cites stored records."}


payments = MockPaymentProvider()
pos = MockPosGateway()
scanner = MockScanner()
tracking = MockVehicleTracking()
pod = MockProofOfDelivery()
hr = MockHrGateway()
supplier_edi = MockSupplierGateway()
loyalty_gateway = DemoLoyaltyGateway()
insights = RuleBasedInsights()
