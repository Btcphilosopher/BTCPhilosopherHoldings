from datetime import date, time

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import select

from ...common import audit, get_or_404, mappings, row, rows
from ...db import get_db
from ...security import require
from .models import BusinessUnit, Department, Location, OpeningHours, Region, Site, SiteContact, StoreFormat

router = APIRouter(prefix="/org", tags=["Stores & hierarchy"])


@router.get("/hierarchy")
def hierarchy(p=Depends(require("org.read")), db=Depends(get_db)):
    sites = rows(db.execute(p.scope(select(Site).order_by(Site.name), Site.id, "org.read")).scalars())
    return {"business_units": rows(db.execute(select(BusinessUnit)).scalars()),
            "regions": rows(db.execute(select(Region)).scalars()),
            "formats": rows(db.execute(select(StoreFormat)).scalars()), "sites": sites}


@router.get("/regions")
def regions(p=Depends(require("org.read")), db=Depends(get_db)):
    return rows(db.execute(select(Region).order_by(Region.name)).scalars())


@router.get("/sites")
def sites(kind: str | None = None, p=Depends(require("org.read")), db=Depends(get_db)):
    """Site list with a 7-day operating summary. Every figure is a count or sum of stored rows."""
    return mappings(db, """
        SELECT s.*, r.name region, f.name format,
          (SELECT COALESCE(SUM(net),0) FROM sales x WHERE x.site_id=s.id AND x.at >= now() - interval '7 days') net_sales_7d,
          (SELECT COUNT(*) FROM store_tasks t WHERE t.site_id=s.id AND t.status='open') open_tasks,
          (SELECT COUNT(*) FROM maintenance_requests m WHERE m.site_id=s.id AND m.status<>'closed') open_maintenance,
          (SELECT COUNT(*) FROM shifts h WHERE h.site_id=s.id AND h.starts_at::date = current_date) shifts_today,
          (SELECT COUNT(*) FROM exceptions e WHERE e.site_id=s.id AND e.status='open') open_exceptions,
          (SELECT ROUND(100.0 * COUNT(*) FILTER (WHERE COALESCE(b.q,0) > 0) / NULLIF(COUNT(*),0), 1)
             FROM replenishment_policies rp LEFT JOIN (SELECT site_id, product_id, SUM(qty) q FROM stock_balances
                  WHERE bucket='available' GROUP BY 1,2) b ON b.site_id=rp.site_id AND b.product_id=rp.product_id
             WHERE rp.site_id=s.id) availability_pct
        FROM sites s JOIN regions r ON r.id=s.region_id LEFT JOIN store_formats f ON f.id=s.format_id
        WHERE (:k IS NULL OR s.kind=:k) AND (:all_sites OR s.id = ANY(CAST(:sites AS int[]))) ORDER BY s.kind, s.name""",
                    k=kind, **p.sql_sites("org.read"))


@router.get("/sites/{site_id}")
def site(site_id: int, p=Depends(require("org.read")), db=Depends(get_db)):
    s = get_or_404(db, Site, site_id)
    p.check_read("org.read", site_id)
    f = lambda m: rows(db.execute(select(m).where(m.site_id == site_id).order_by(m.id)).scalars())
    return row(s, departments=f(Department), locations=f(Location), opening_hours=f(OpeningHours), contacts=f(SiteContact),
               tasks=mappings(db, "SELECT * FROM store_tasks WHERE site_id=:s AND status='open' ORDER BY due_at", s=site_id),
               maintenance=mappings(db, "SELECT * FROM maintenance_requests WHERE site_id=:s AND status<>'closed'", s=site_id))


class SiteIn(BaseModel):
    code: str
    name: str
    kind: str = "store"
    region_id: int
    format_id: int | None = None
    address: str | None = None
    opened_on: date | None = None
    grid_x: float = 0
    grid_y: float = 0


@router.post("/sites")
def create_site(body: SiteIn, p=Depends(require("org.write")), db=Depends(get_db)):
    p.check("org.write")
    s = Site(**body.model_dump(), delivery_window_start=time(6), delivery_window_end=time(11))
    db.add(s)
    db.flush()
    audit(db, p, "site.created", "site", s.id, body.model_dump())
    db.commit()
    return row(s)


class SitePatch(BaseModel):
    name: str | None = None
    status: str | None = None
    format_id: int | None = None
    delivery_window_start: time | None = None
    delivery_window_end: time | None = None


@router.patch("/sites/{site_id}")
def patch_site(site_id: int, body: SitePatch, p=Depends(require("org.write")), db=Depends(get_db)):
    s = get_or_404(db, Site, site_id)
    p.check("org.write", site_id)
    changes = body.model_dump(exclude_none=True)
    for k, v in changes.items():
        setattr(s, k, v)
    audit(db, p, "site.updated", "site", s.id, changes)
    db.commit()
    return row(s)


class FormatPatch(BaseModel):
    assortment_tier: str | None = None
    replenishment_policy: dict | None = None


@router.patch("/formats/{format_id}")
def patch_format(format_id: int, body: FormatPatch, p=Depends(require("org.write")), db=Depends(get_db)):
    p.check("org.write")
    f = get_or_404(db, StoreFormat, format_id)
    changes = body.model_dump(exclude_none=True)
    for k, v in changes.items():
        setattr(f, k, v)
    audit(db, p, "format.updated", "store_format", f.id, changes)
    db.commit()
    return row(f)
