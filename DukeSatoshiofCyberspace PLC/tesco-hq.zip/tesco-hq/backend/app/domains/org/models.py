from sqlalchemy import JSON, Column, Date, Integer, Numeric, String, Time, UniqueConstraint

from ...db import Base, fk, pk


class BusinessUnit(Base):
    __tablename__ = "business_units"
    id = pk()
    code = Column(String(20), unique=True, nullable=False)
    name = Column(String(120), nullable=False)


class Region(Base):
    __tablename__ = "regions"
    id = pk()
    business_unit_id = fk("business_units.id", nullable=False)
    code = Column(String(20), unique=True, nullable=False)
    name = Column(String(120), nullable=False)


class StoreFormat(Base):
    """Format drives assortment, pricing scope and replenishment policy - all configurable."""
    __tablename__ = "store_formats"
    id = pk()
    code = Column(String(20), unique=True, nullable=False)
    name = Column(String(120), nullable=False)
    assortment_tier = Column(String(20), nullable=False, default="full")  # full|core|convenience
    replenishment_policy = Column(JSON, nullable=False, default=dict)   # {cover_days, safety_days}


class Site(Base):
    __tablename__ = "sites"
    id = pk()
    code = Column(String(20), unique=True, nullable=False)
    name = Column(String(160), nullable=False)
    kind = Column(String(10), nullable=False)  # store|dc
    region_id = fk("regions.id", nullable=False)
    format_id = fk("store_formats.id")
    address = Column(String(300))
    grid_x = Column(Numeric(8, 2), nullable=False, default=0)  # fictional planning grid, km
    grid_y = Column(Numeric(8, 2), nullable=False, default=0)
    opened_on = Column(Date)
    status = Column(String(20), nullable=False, default="trading")
    delivery_window_start = Column(Time)
    delivery_window_end = Column(Time)
    online_fulfilment = Column(Integer, nullable=False, default=0)
    sales_area_sqft = Column(Integer)


class Department(Base):
    __tablename__ = "departments"
    id = pk()
    site_id = fk("sites.id", nullable=False)
    code = Column(String(20), nullable=False)
    name = Column(String(120), nullable=False)
    __table_args__ = (UniqueConstraint("site_id", "code"),)


class Location(Base):
    __tablename__ = "locations"
    id = pk()
    site_id = fk("sites.id", nullable=False)
    code = Column(String(30), nullable=False)
    kind = Column(String(20), nullable=False)  # dock|bin|shelf|staging|quarantine
    temp_class = Column(String(10), nullable=False, default="ambient")
    capacity_units = Column(Integer)
    __table_args__ = (UniqueConstraint("site_id", "code"),)


class OpeningHours(Base):
    __tablename__ = "opening_hours"
    id = pk()
    site_id = fk("sites.id", nullable=False)
    weekday = Column(Integer, nullable=False)  # 0=Monday
    opens = Column(Time)
    closes = Column(Time)
    note = Column(String(120))
    __table_args__ = (UniqueConstraint("site_id", "weekday"),)


class SiteContact(Base):
    __tablename__ = "site_contacts"
    id = pk()
    site_id = fk("sites.id", nullable=False)
    role = Column(String(80), nullable=False)
    name = Column(String(120), nullable=False)
    phone = Column(String(40))
    email = Column(String(160))
