from datetime import date

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import select

from ...common import audit, flag, get_or_404, mappings, row, rows
from ...db import get_db
from ...security import require
from .models import QualityIncident, Supplier, SupplierQualification

router = APIRouter(prefix="/suppliers", tags=["Suppliers"])

PERF = """
  SELECT s.id supplier_id,
    COUNT(a.id) FILTER (WHERE a.actual_arrival IS NOT NULL) deliveries,
    COUNT(a.id) FILTER (WHERE a.actual_arrival IS NOT NULL AND a.actual_arrival <= a.slot_end) on_time,
    (SELECT COALESCE(SUM(l.cases_ordered),0) FROM purchase_order_lines l JOIN purchase_orders p ON p.id=l.po_id
       WHERE p.supplier_id=s.id AND p.status IN ('received','part_received','closed')) cases_ordered,
    (SELECT COALESCE(SUM(l.cases_received),0) FROM purchase_order_lines l JOIN purchase_orders p ON p.id=l.po_id
       WHERE p.supplier_id=s.id AND p.status IN ('received','part_received','closed')) cases_accepted
  FROM suppliers s LEFT JOIN purchase_orders po ON po.supplier_id=s.id LEFT JOIN delivery_appointments a ON a.po_id=po.id
  GROUP BY s.id"""


@router.get("")
def suppliers(p=Depends(require("supplier.read")), db=Depends(get_db)):
    return mappings(db, f"""
        SELECT s.*, pf.deliveries, pf.on_time, pf.cases_ordered, pf.cases_accepted,
          ROUND(100.0*pf.on_time/NULLIF(pf.deliveries,0),1) on_time_pct,
          ROUND(100.0*pf.cases_accepted/NULLIF(pf.cases_ordered,0),1) in_full_pct,
          (SELECT COUNT(*) FROM quality_incidents q WHERE q.supplier_id=s.id AND q.status='open') open_incidents,
          (SELECT string_agg(c.name, ', ') FROM supplier_categories sc JOIN categories c ON c.id=sc.category_id WHERE sc.supplier_id=s.id) approved_categories,
          (SELECT MIN(valid_to) FROM supplier_qualifications q WHERE q.supplier_id=s.id) next_qualification_expiry
        FROM suppliers s JOIN ({PERF}) pf ON pf.supplier_id=s.id ORDER BY s.name""")


@router.get("/{supplier_id}")
def supplier(supplier_id: int, p=Depends(require("supplier.read")), db=Depends(get_db)):
    s = get_or_404(db, Supplier, supplier_id)
    return row(s,
               ownership_note="Ownership and upstream dependencies are as declared by the supplier and are unverified. "
                              "Do not treat separate supplier records as independent sources of supply without due diligence.",
               qualifications=rows(db.execute(select(SupplierQualification).where(SupplierQualification.supplier_id == supplier_id)).scalars()),
               incidents=rows(db.execute(select(QualityIncident).where(QualityIncident.supplier_id == supplier_id).order_by(QualityIncident.id.desc())).scalars()),
               products=mappings(db, "SELECT sp.*, p.sku, p.name FROM supplier_products sp JOIN products p ON p.id=sp.product_id WHERE sp.supplier_id=:s ORDER BY p.sku", s=supplier_id),
               deliveries=mappings(db, """SELECT po.number, a.slot_start, a.slot_end, a.actual_arrival, a.status FROM delivery_appointments a
                   JOIN purchase_orders po ON po.id=a.po_id WHERE po.supplier_id=:s ORDER BY a.slot_start DESC LIMIT 50""", s=supplier_id))


class StatusIn(BaseModel):
    status: str
    reason: str


@router.post("/{supplier_id}/status")
def set_status(supplier_id: int, body: StatusIn, p=Depends(require("supplier.write")), db=Depends(get_db)):
    p.check("supplier.write")
    s = get_or_404(db, Supplier, supplier_id)
    audit(db, p, "supplier.status_changed", "supplier", s.id, {"from": s.status, "to": body.status, "reason": body.reason})
    s.status = body.status
    db.commit()
    return row(s)


class QualIn(BaseModel):
    kind: str
    reference: str | None = None
    valid_to: date | None = None


@router.post("/{supplier_id}/qualifications")
def add_qualification(supplier_id: int, body: QualIn, p=Depends(require("supplier.write")), db=Depends(get_db)):
    p.check("supplier.write")
    q = SupplierQualification(supplier_id=supplier_id, **body.model_dump())
    db.add(q)
    audit(db, p, "supplier.qualification_added", "supplier", supplier_id, body.model_dump())
    db.commit()
    return row(q)


class IncidentIn(BaseModel):
    product_id: int | None = None
    lot_code: str | None = None
    severity: str = "minor"
    description: str


@router.post("/{supplier_id}/incidents")
def add_incident(supplier_id: int, body: IncidentIn, p=Depends(require("supplier.write", "inventory.write")), db=Depends(get_db)):
    q = QualityIncident(supplier_id=supplier_id, **body.model_dump())
    db.add(q)
    db.flush()
    if body.severity == "major":
        flag(db, "quality_incident", f"Major quality incident: {body.description[:120]}", severity="high", entity_type="quality_incident", entity_id=q.id)
    audit(db, p, "supplier.incident_raised", "supplier", supplier_id, body.model_dump())
    db.commit()
    return row(q)
