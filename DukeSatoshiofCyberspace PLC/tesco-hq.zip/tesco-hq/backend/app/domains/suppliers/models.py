from sqlalchemy import Boolean, Column, Date, Integer, String, Text, UniqueConstraint

from ...db import Base, Cost, Money, fk, pk, ts


class Supplier(Base):
    __tablename__ = "suppliers"
    id = pk()
    code = Column(String(20), unique=True, nullable=False)
    name = Column(String(200), nullable=False)
    status = Column(String(20), nullable=False, default="approved")  # approved|suspended|onboarding
    lead_time_days = Column(Integer, nullable=False, default=2)
    delivery_weekdays = Column(String(20), nullable=False, default="0,1,2,3,4")
    delivery_terms = Column(String(120))
    payment_terms_days = Column(Integer, nullable=False, default=30)
    min_order_value = Column(Money)
    # Ownership / upstream dependency is NOT assumed. Only what the supplier has declared is stored,
    # and it is labelled unverified. Two supplier records may share owners or sources.
    declared_parent_group = Column(String(200))
    upstream_dependency_note = Column(Text)
    contact_email = Column(String(160))


class SupplierCategory(Base):
    __tablename__ = "supplier_categories"
    id = pk()
    supplier_id = fk("suppliers.id", nullable=False)
    category_id = fk("categories.id", nullable=False)
    __table_args__ = (UniqueConstraint("supplier_id", "category_id"),)


class SupplierProduct(Base):
    __tablename__ = "supplier_products"
    id = pk()
    supplier_id = fk("suppliers.id", nullable=False)
    product_id = fk("products.id", nullable=False)
    case_cost = Column(Cost, nullable=False)
    moq_cases = Column(Integer, nullable=False, default=1)
    available = Column(Boolean, nullable=False, default=True)
    is_primary = Column(Boolean, nullable=False, default=True)
    __table_args__ = (UniqueConstraint("supplier_id", "product_id"),)


class CostHistory(Base):
    __tablename__ = "cost_history"
    id = pk()
    supplier_product_id = fk("supplier_products.id", nullable=False)
    case_cost = Column(Cost, nullable=False)
    effective_from = Column(Date, nullable=False)
    source = Column(String(80))
    recorded_at = ts()


class SupplierQualification(Base):
    __tablename__ = "supplier_qualifications"
    id = pk()
    supplier_id = fk("suppliers.id", nullable=False)
    kind = Column(String(80), nullable=False)
    reference = Column(String(80))
    valid_to = Column(Date)
    status = Column(String(20), nullable=False, default="valid")


class QualityIncident(Base):
    __tablename__ = "quality_incidents"
    id = pk()
    supplier_id = fk("suppliers.id", nullable=False)
    product_id = fk("products.id")
    lot_code = Column(String(60))
    severity = Column(String(10), nullable=False, default="minor")
    description = Column(Text, nullable=False)
    status = Column(String(20), nullable=False, default="open")
    raised_at = ts()
