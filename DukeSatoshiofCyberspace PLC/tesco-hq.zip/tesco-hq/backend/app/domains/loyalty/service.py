"""Loyalty ledger. Demonstration policy only (see settings 'loyalty.policy')."""
from decimal import ROUND_DOWN

from sqlalchemy import text

from ...common import conflict, dec, get_setting, insert_once, now, q2
from .models import LoyaltyLedger


def policy(db):
    return get_setting(db, "loyalty.policy")


def points_for(db, eligible_gross) -> int:
    return int((dec(eligible_gross) * dec(policy(db)["points_per_pound"])).to_integral_value(rounding=ROUND_DOWN))


def point_value(db, points):
    return q2(dec(points) * dec(policy(db)["point_value"]))


def _ledger(db, member_id, kind, points, ref_type, ref_id, note=None) -> bool:
    """Insert once per (member, kind, ref). Returns False if this event was already posted."""
    return insert_once(db, LoyaltyLedger, member_id=member_id, kind=kind, points=points, ref_type=ref_type,
                       ref_id=ref_id, note=note)


def award(db, member_id, points, ref_type, ref_id, note=None) -> int:
    """Award points exactly once for a business event. A replayed event awards nothing."""
    if points <= 0 or not _ledger(db, member_id, "earn", points, ref_type, ref_id, note):
        return 0
    db.execute(text("UPDATE loyalty_members SET points_balance = points_balance + :p, last_activity_at = :t WHERE id = :m"),
               {"p": points, "m": member_id, "t": now()})
    return points


def redeem(db, member_id, points, ref_type, ref_id):
    """Atomic conditional decrement: two concurrent redemptions cannot both spend the same points."""
    mult = int(policy(db)["redeem_multiple"])
    if points <= 0 or points % mult:
        raise conflict(f"Points are redeemed in multiples of {mult}", "invalid_redemption")
    if not _ledger(db, member_id, "redeem", -points, ref_type, ref_id):
        return 0  # already redeemed for this reference
    res = db.execute(text("UPDATE loyalty_members SET points_balance = points_balance - :p, last_activity_at = :t "
                          "WHERE id = :m AND points_balance >= :p AND status = 'active'"),
                     {"p": points, "m": member_id, "t": now()})
    if res.rowcount != 1:
        raise conflict("Insufficient points balance", "insufficient_points")
    return points


def reverse(db, member_id, points, ref_type, ref_id, note=None) -> int:
    """Take back points earned on a returned item. Never drives the balance negative: any shortfall
    is recorded on the ledger note for follow-up rather than hidden."""
    if points <= 0:
        return 0
    bal = db.execute(text("SELECT points_balance FROM loyalty_members WHERE id=:m FOR UPDATE"), {"m": member_id}).scalar()
    take = min(points, bal)
    if take < points:
        note = f"{note or ''} (shortfall {points - take} points: balance already spent)".strip()
    if not _ledger(db, member_id, "reversal", -take, ref_type, ref_id, note):
        return 0
    db.execute(text("UPDATE loyalty_members SET points_balance = points_balance - :p WHERE id = :m"),
               {"p": take, "m": member_id})
    return take


def recredit(db, member_id, points, ref_type, ref_id, note=None) -> int:
    if points <= 0 or not _ledger(db, member_id, "recredit", points, ref_type, ref_id, note):
        return 0
    db.execute(text("UPDATE loyalty_members SET points_balance = points_balance + :p WHERE id = :m"),
               {"p": points, "m": member_id})
    return points


def redeem_coupon(db, code, sale_id):
    """Single-use: the conditional UPDATE is the replay guard."""
    res = db.execute(text("UPDATE coupons SET status='redeemed', redeemed_sale_id=:s, redeemed_at=:t "
                          "WHERE code=:c AND status='active'"), {"s": sale_id, "c": code, "t": now()})
    if res.rowcount != 1:
        raise conflict(f"Coupon {code} has already been used or is void", "coupon_replay")


def expire_inactive(db) -> dict:
    """Demo expiry rule: all points lapse after N months without activity."""
    months = int(policy(db)["expiry_months_inactive"])
    rows = db.execute(text(
        "SELECT id, points_balance FROM loyalty_members WHERE points_balance > 0 AND "
        "COALESCE(last_activity_at, joined_at) < now() - make_interval(months => :m) FOR UPDATE"), {"m": months}).all()
    total = 0
    for mid, bal in rows:
        ref = int(now().strftime("%Y%m"))
        if _ledger(db, mid, "expiry", -bal, "expiry_run", ref, f"Inactive for {months} months"):
            db.execute(text("UPDATE loyalty_members SET points_balance = 0 WHERE id=:m"), {"m": mid})
            total += bal
    return {"members": len(rows), "points_expired": total}
