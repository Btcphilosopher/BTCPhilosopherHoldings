from datetime import datetime
from decimal import Decimal

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import select

from ...adapters import mocks
from ...common import audit, bad, get_or_404, get_setting, mappings, now, row, rows
from ...db import get_db
from ...security import audited_sensitive, require
from ..pricing.models import Coupon
from . import service
from .models import LoyaltyCard, LoyaltyLedger, LoyaltyMember

router = APIRouter(prefix="/loyalty", tags=["Loyalty"])


def _mask(m, full):
    if not full:
        m["display_name"] = m["display_name"][0] + "•••"
        m["email"] = None
    return m


@router.get("/policy")
def policy(p=Depends(require("loyalty.read")), db=Depends(get_db)):
    return {"policy": get_setting(db, "loyalty.policy"), "integration": mocks.loyalty_gateway.sync_member("n/a"),
            "notice": "Fictional demonstration rules. They do not describe any real loyalty programme."}


@router.get("/members")
def members(q: str | None = None, p=Depends(require("loyalty.read")), db=Depends(get_db)):
    """Names and emails are masked unless the caller holds loyalty.member.read."""
    full = p.has("loyalty.member.read")
    data = mappings(db, """SELECT m.*, (SELECT COUNT(*) FROM loyalty_cards c WHERE c.member_id=m.id AND c.status='active') cards,
          (SELECT COUNT(*) FROM coupons c WHERE c.member_id=m.id AND c.status='active') active_coupons
        FROM loyalty_members m WHERE (:q IS NULL OR m.member_no ILIKE :q) ORDER BY m.member_no""", q=f"%{q}%" if q else None)
    return [_mask(m, full) for m in data]


@router.get("/members/{member_id}")
def member(member_id: int, p=Depends(require("loyalty.read")), db=Depends(get_db)):
    m = get_or_404(db, LoyaltyMember, member_id)
    full = p.has("loyalty.member.read")
    if full:
        audited_sensitive(db, p, "loyalty.member_viewed", "loyalty_member", m.id)
        db.commit()
    ledger = rows(db.execute(select(LoyaltyLedger).where(LoyaltyLedger.member_id == m.id).order_by(LoyaltyLedger.id.desc()).limit(200)).scalars())
    return _mask(row(m, ledger=ledger, ledger_sum=sum(l["points"] for l in ledger),
                     cards=rows(db.execute(select(LoyaltyCard).where(LoyaltyCard.member_id == m.id)).scalars()),
                     coupons=rows(db.execute(select(Coupon).where(Coupon.member_id == m.id)).scalars()),
                     eligible_offers=mappings(db, """SELECT code, name, kind, params, ends_at FROM promotions WHERE status='published'
                         AND starts_at <= now() AND ends_at > now() AND kind='loyalty_price'""")), full)


class PrefsIn(BaseModel):
    email: bool = False
    sms: bool = False
    post: bool = False


@router.put("/members/{member_id}/preferences")
def prefs(member_id: int, body: PrefsIn, p=Depends(require("loyalty.write", "service.write")), db=Depends(get_db)):
    m = get_or_404(db, LoyaltyMember, member_id)
    audit(db, p, "loyalty.preferences_changed", "loyalty_member", m.id, {"before": m.comms_prefs, "after": body.model_dump()})
    m.comms_prefs = body.model_dump()
    db.commit()
    return row(m)


class CouponIn(BaseModel):
    code: str
    description: str | None = None
    amount_off: Decimal
    min_spend: Decimal = Decimal(0)
    member_id: int | None = None
    valid_to: datetime | None = None


@router.post("/coupons")
def issue_coupon(body: CouponIn, p=Depends(require("loyalty.write")), db=Depends(get_db)):
    p.check("loyalty.write")
    if body.amount_off <= 0:
        raise bad("amount_off must be positive")
    c = Coupon(**body.model_dump())
    db.add(c)
    db.flush()
    audit(db, p, "coupon.issued", "coupon", c.id, {"code": c.code, "amount_off": c.amount_off})
    db.commit()
    return row(c)


class AdjustIn(BaseModel):
    points: int
    reason: str


@router.post("/members/{member_id}/adjust")
def adjust(member_id: int, body: AdjustIn, p=Depends(require("loyalty.write")), db=Depends(get_db)):
    """Goodwill credit (positive only). Each adjustment is a ledger row tied to its audit record."""
    p.check("loyalty.write")
    if not 0 < body.points <= 5000:
        raise bad("Adjustment must be between 1 and 5000 points")
    m = get_or_404(db, LoyaltyMember, member_id)
    audit(db, p, "loyalty.adjustment", "loyalty_member", m.id, body.model_dump())
    db.flush()
    from sqlalchemy import func
    from ..platform.models import AuditLog
    ref = db.execute(select(func.max(AuditLog.id))).scalar()
    service._ledger(db, m.id, "adjust", body.points, "audit_log", ref, body.reason)
    from sqlalchemy import text
    db.execute(text("UPDATE loyalty_members SET points_balance = points_balance + :p WHERE id=:m"), {"p": body.points, "m": m.id})
    db.commit()
    return {"status": "posted"}


@router.post("/expiry/run")
def expiry(p=Depends(require("loyalty.write")), db=Depends(get_db)):
    p.check("loyalty.write")
    out = service.expire_inactive(db)
    audit(db, p, "loyalty.expiry_run", detail=out)
    db.commit()
    return out


@router.get("/integrity")
def integrity(p=Depends(require("loyalty.read")), db=Depends(get_db)):
    bad_rows = mappings(db, """SELECT m.id, m.member_no, m.points_balance, COALESCE(l.s,0) ledger_sum FROM loyalty_members m
        LEFT JOIN (SELECT member_id, SUM(points) s FROM loyalty_ledger GROUP BY 1) l ON l.member_id=m.id WHERE m.points_balance <> COALESCE(l.s,0)""")
    return {"balanced": not bad_rows, "mismatches": bad_rows}
