from sqlalchemy import JSON, CheckConstraint, Column, DateTime, Integer, String, Text, UniqueConstraint

from ...db import Base, fk, pk, ts


class LoyaltyMember(Base):
    """Membership identity only - no password, no login. Authentication lives elsewhere."""
    __tablename__ = "loyalty_members"
    id = pk()
    member_no = Column(String(20), unique=True, nullable=False)
    display_name = Column(String(160), nullable=False)
    email = Column(String(200))
    status = Column(String(12), nullable=False, default="active")
    points_balance = Column(Integer, nullable=False, default=0)
    comms_prefs = Column(JSON, nullable=False, default=dict)  # {"email":bool,"sms":bool,"post":bool}
    joined_at = ts()
    last_activity_at = Column(DateTime(timezone=True))
    __table_args__ = (CheckConstraint("points_balance >= 0", name="non_negative"),)


class LoyaltyCard(Base):
    __tablename__ = "loyalty_cards"
    id = pk()
    member_id = fk("loyalty_members.id", nullable=False)
    token = Column(String(40), unique=True, nullable=False)  # digital-card identifier (opaque)
    kind = Column(String(12), nullable=False, default="digital")
    status = Column(String(12), nullable=False, default="active")


class LoyaltyLedger(Base):
    """Append-only points ledger. The unique key makes each business event postable exactly once."""
    __tablename__ = "loyalty_ledger"
    id = pk()
    member_id = fk("loyalty_members.id", nullable=False)
    at = ts()
    kind = Column(String(14), nullable=False)  # earn|redeem|reversal|expiry|adjust|recredit
    points = Column(Integer, nullable=False)   # signed
    ref_type = Column(String(30), nullable=False)
    ref_id = Column(Integer, nullable=False)
    note = Column(Text)
    __table_args__ = (UniqueConstraint("member_id", "kind", "ref_type", "ref_id"),)
