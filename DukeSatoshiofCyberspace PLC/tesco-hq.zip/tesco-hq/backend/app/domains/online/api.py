from datetime import datetime
from decimal import Decimal

from fastapi import APIRouter, Depends, Header
from pydantic import BaseModel
from sqlalchemy import select

from ...common import DomainError, audit, bad, get_or_404, idem_begin, idem_finish, mappings, now, row
from ...db import get_db
from ...security import require
from ..sales.api import BasketLine, ReturnLine, resolve_lines
from . import service
from .models import OnlineOrder, ServiceCase

router = APIRouter(prefix="/online", tags=["Online orders & customer service"])
SC = "(:all_sites OR {c} = ANY(CAST(:sites AS int[])))"


class OrderLineIn(BasketLine):
    allow_substitution: bool = True


class OrderIn(BaseModel):
    customer_id: int
    slot_id: int
    lines: list[OrderLineIn]
    payment_token: str = "tok_ok"  # test tokens only: tok_ok | tok_declined | tok_timeout


def order_detail(db, o):
    return row(o,
               lines=mappings(db, "SELECT l.*, p.sku, sp.sku sub_sku FROM online_order_lines l JOIN products p ON p.id=l.product_id LEFT JOIN products sp ON sp.id=l.sub_product_id WHERE order_id=:o ORDER BY l.id", o=o.id),
               payments=mappings(db, "SELECT * FROM payments WHERE order_id=:o ORDER BY id", o=o.id),
               customer=mappings(db, "SELECT ref, name, substitution_pref FROM customers WHERE id=:c", c=o.customer_id)[0],
               sale_lines=mappings(db, "SELECT sl.id, sl.description, sl.qty, sl.gross, sl.returned_qty FROM sale_lines sl WHERE sale_id=:s ORDER BY id", s=o.sale_id or 0),
               slot=mappings(db, "SELECT * FROM delivery_slots WHERE id=:s", s=o.slot_id)[0],
               state_machines=service.MACHINES)


@router.post("/orders")
def place(body: OrderIn, idempotency_key: str = Header(...), p=Depends(require("online.write", "service.write")), db=Depends(get_db)):
    """Order ingestion endpoint for the e-commerce platform. Idempotency-Key is mandatory: a retry after a
    network failure returns the original order and never creates a second order or a second charge."""
    payload = body.model_dump(mode="json")
    if (replay := idem_begin(db, "online.order", idempotency_key, payload)) is not None:
        db.commit()
        return replay
    lines = resolve_lines(db, body.lines)
    for l, src in zip(lines, body.lines):
        l["allow_substitution"] = src.allow_substitution
    o = service.place_order(db, customer_id=body.customer_id, slot_id=body.slot_id, lines=lines, payment_token=body.payment_token,
                            payment_key=f"order:{idempotency_key}")
    out = idem_finish(db, "online.order", idempotency_key, order_detail(db, o))
    db.commit()
    return out


@router.get("/orders")
def orders(status: str | None = None, p=Depends(require("online.read", "service.write")), db=Depends(get_db)):
    perm = "online.read" if p.has("online.read") else "service.write"
    return mappings(db, f"""SELECT o.id, o.number, o.placed_at, s.name site, c.ref customer_ref, c.name customer, o.method, o.order_status,
          o.payment_status, o.fulfilment_status, o.gross_estimated, o.gross_final, sl.starts_at slot_start, sl.ends_at slot_end,
          (SELECT COUNT(*) FROM online_order_lines l WHERE l.order_id=o.id) lines,
          (SELECT COUNT(*) FROM online_order_lines l WHERE l.order_id=o.id AND l.sub_product_id IS NOT NULL) substitutions
        FROM online_orders o JOIN sites s ON s.id=o.site_id JOIN customers c ON c.id=o.customer_id JOIN delivery_slots sl ON sl.id=o.slot_id
        WHERE (:st IS NULL OR o.order_status=:st) AND {SC.format(c='o.site_id')} ORDER BY o.id DESC LIMIT 300""", st=status, **p.sql_sites(perm))


def _order(db, p, oid, perm="online.write"):
    o = get_or_404(db, OnlineOrder, oid)
    if not (p.can(perm, o.site_id) or p.can("service.write", o.site_id)):
        p.check(perm, o.site_id)
    return o


@router.get("/orders/{oid}")
def order(oid: int, p=Depends(require("online.read", "service.write")), db=Depends(get_db)):
    return order_detail(db, get_or_404(db, OnlineOrder, oid))


class PickLine(BaseModel):
    line_id: int
    picked_qty: Decimal
    substitute_sku: str | None = None
    substitute_qty: Decimal | None = None


class PickIn(BaseModel):
    lines: list[PickLine] = []


@router.post("/orders/{oid}/pick")
def pick(oid: int, body: PickIn, p=Depends(require("online.write")), db=Depends(get_db)):
    from ..catalog.models import Product
    o = _order(db, p, oid)
    picks = []
    for l in body.lines:
        d = {"line_id": l.line_id, "picked_qty": l.picked_qty}
        if l.substitute_sku:
            sub = db.execute(select(Product).where(Product.sku == l.substitute_sku)).scalar_one_or_none()
            if not sub:
                raise bad(f"Unknown substitute SKU {l.substitute_sku}")
            d.update(substitute_product_id=sub.id, **({"substitute_qty": l.substitute_qty} if l.substitute_qty else {}))
        picks.append(d)
    service.pick(db, o, picks, actor_id=p.user.id)
    audit(db, p, "online_order.picked", "online_order", o.id)
    db.commit()
    return order_detail(db, o)


@router.post("/orders/{oid}/dispatch")
def dispatch(oid: int, p=Depends(require("online.write")), db=Depends(get_db)):
    o = _order(db, p, oid)
    service.dispatch(db, o)
    db.commit()
    return order_detail(db, o)


class HandoverIn(BaseModel):
    substitution_decisions: dict[str, str] = {}  # {line_id: accepted|rejected}
    failed_reason: str | None = None


@router.post("/orders/{oid}/handover")
def handover(oid: int, body: HandoverIn, idempotency_key: str | None = Header(default=None), p=Depends(require("online.write")), db=Depends(get_db)):
    o = _order(db, p, oid)
    if (replay := idem_begin(db, f"handover:{oid}", idempotency_key, body.model_dump())) is not None:
        db.commit()
        return replay
    service.handover(db, o, substitution_decisions=body.substitution_decisions, failed_reason=body.failed_reason, actor_id=p.user.id)
    audit(db, p, "online_order.handover", "online_order", o.id, body.model_dump())
    out = idem_finish(db, f"handover:{oid}", idempotency_key, order_detail(db, o))
    db.commit()
    return out


class CancelIn(BaseModel):
    reason: str


@router.post("/orders/{oid}/cancel")
def cancel(oid: int, body: CancelIn, p=Depends(require("online.write", "service.write")), db=Depends(get_db)):
    o = _order(db, p, oid)
    service.cancel(db, o, body.reason)
    audit(db, p, "online_order.cancelled", "online_order", o.id, {"reason": body.reason})
    db.commit()
    return order_detail(db, o)


@router.post("/orders/{oid}/resolve-payment")
def resolve_payment(oid: int, p=Depends(require("online.write", "service.write", "finance.write")), db=Depends(get_db)):
    o = get_or_404(db, OnlineOrder, oid)
    service.resolve_payment(db, o)
    audit(db, p, "online_order.payment_resolved", "online_order", o.id, {"payment_status": o.payment_status})
    db.commit()
    return order_detail(db, o)


class RefundIn(BaseModel):
    lines: list[ReturnLine]
    reason: str


@router.post("/orders/{oid}/refunds")
def refund(oid: int, body: RefundIn, idempotency_key: str = Header(...), p=Depends(require("service.write")), db=Depends(get_db)):
    """Customer-service refund. Idempotency-Key is mandatory so a double-click or retry cannot refund twice."""
    o = _order(db, p, oid, "service.write")
    if (replay := idem_begin(db, f"order.refund:{oid}", idempotency_key, body.model_dump(mode="json"))) is not None:
        db.commit()
        return replay
    ret = service.refund(db, o, line_items=[l.model_dump() for l in body.lines], reason=body.reason, actor_id=p.user.id)
    audit(db, p, "online_order.refunded", "online_order", o.id, {"return": ret.number, "gross": ret.gross})
    out = idem_finish(db, f"order.refund:{oid}", idempotency_key, {"return": row(ret), "order": order_detail(db, o)})
    db.commit()
    return out


@router.get("/slots")
def slots(p=Depends(require("online.read", "service.write")), db=Depends(get_db)):
    return mappings(db, """SELECT sl.*, s.name site, (sl.capacity - sl.booked) remaining FROM delivery_slots sl JOIN sites s ON s.id=sl.site_id
        ORDER BY sl.starts_at, s.name""")


@router.get("/customers")
def customers(p=Depends(require("online.read", "service.write")), db=Depends(get_db)):
    """Synthetic demonstration customers."""
    return mappings(db, "SELECT id, ref, name, substitution_pref, member_id, synthetic FROM customers ORDER BY ref")


class CaseIn(BaseModel):
    customer_id: int | None = None
    order_id: int | None = None
    category: str
    subject: str
    note: str | None = None


@router.get("/cases")
def cases(p=Depends(require("online.read", "service.write")), db=Depends(get_db)):
    return mappings(db, """SELECT c.*, cu.name customer, o.number order_number FROM service_cases c LEFT JOIN customers cu ON cu.id=c.customer_id
        LEFT JOIN online_orders o ON o.id=c.order_id ORDER BY c.id DESC""")


@router.post("/cases")
def open_case(body: CaseIn, p=Depends(require("service.write")), db=Depends(get_db)):
    n = db.execute(select(ServiceCase.id).order_by(ServiceCase.id.desc()).limit(1)).scalar() or 0
    c = ServiceCase(number=f"CS-{n + 1:06d}", customer_id=body.customer_id, order_id=body.order_id, category=body.category,
                    subject=body.subject, opened_by=p.user.id,
                    notes=[{"at": now().isoformat(), "by": p.user.name, "text": body.note}] if body.note else [])
    db.add(c)
    db.commit()
    return row(c)


class CaseNote(BaseModel):
    text: str
    close: bool = False


@router.post("/cases/{cid}/notes")
def case_note(cid: int, body: CaseNote, p=Depends(require("service.write")), db=Depends(get_db)):
    c = get_or_404(db, ServiceCase, cid)
    c.notes = list(c.notes or []) + [{"at": now().isoformat(), "by": p.user.name, "text": body.text}]
    if body.close:
        c.status, c.closed_at = "closed", now()
    db.commit()
    return row(c)
