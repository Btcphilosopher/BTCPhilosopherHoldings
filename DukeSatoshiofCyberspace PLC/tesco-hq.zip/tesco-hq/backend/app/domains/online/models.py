from sqlalchemy import JSON, Boolean, Column, DateTime, Integer, String, Text

from ...db import Base, Money, Qty, fk, pk, ts


class Customer(Base):
    """Synthetic online customer account. Loyalty membership is a separate record (optional link)."""
    __tablename__ = "customers"
    id = pk()
    ref = Column(String(30), unique=True, nullable=False)
    name = Column(String(160), nullable=False)
    email = Column(String(200), nullable=False)
    address = Column(String(300))
    substitution_pref = Column(String(12), nullable=False, default="allow")  # allow|ask|none
    member_id = fk("loyalty_members.id")
    synthetic = Column(Boolean, nullable=False, default=True)


class DeliverySlot(Base):
    __tablename__ = "delivery_slots"
    id = pk()
    site_id = fk("sites.id", nullable=False)
    method = Column(String(12), nullable=False, default="delivery")  # delivery|collection
    starts_at = Column(DateTime(timezone=True), nullable=False)
    ends_at = Column(DateTime(timezone=True), nullable=False)
    capacity = Column(Integer, nullable=False)
    booked = Column(Integer, nullable=False, default=0)


class OnlineOrder(Base):
    """Three independent state machines: order, payment, fulfilment (see online/service.py)."""
    __tablename__ = "online_orders"
    id = pk()
    number = Column(String(30), unique=True, nullable=False)
    customer_id = fk("customers.id", nullable=False)
    site_id = fk("sites.id", nullable=False)
    slot_id = fk("delivery_slots.id", nullable=False)
    method = Column(String(12), nullable=False)
    order_status = Column(String(20), nullable=False, default="placed", index=True)
    payment_status = Column(String(20), nullable=False, default="pending", index=True)
    fulfilment_status = Column(String(20), nullable=False, default="unallocated", index=True)
    gross_estimated = Column(Money, nullable=False, default=0)
    gross_final = Column(Money)
    payment_key = Column(String(120))
    auth_ref = Column(String(80))
    sale_id = Column(Integer)
    placed_at = Column(DateTime(timezone=True), nullable=False, index=True)
    completed_at = Column(DateTime(timezone=True))
    history = Column(JSON, nullable=False, default=list)
    version = Column(Integer, nullable=False, default=1)
    __mapper_args__ = {"version_id_col": version}


class OnlineOrderLine(Base):
    __tablename__ = "online_order_lines"
    id = pk()
    order_id = fk("online_orders.id", nullable=False)
    product_id = fk("products.id", nullable=False)
    description = Column(String(200), nullable=False)
    qty = Column(Qty, nullable=False)
    unit_price = Column(Money, nullable=False)       # effective unit price at order time (after promotions)
    line_gross = Column(Money, nullable=False)
    pricing = Column(JSON)
    allow_substitution = Column(Boolean, nullable=False, default=True)
    reserved_qty = Column(Qty, nullable=False, default=0)
    picked_qty = Column(Qty, nullable=False, default=0)
    status = Column(String(14), nullable=False, default="pending")  # pending|picked|short|substituted
    sub_product_id = fk("products.id")
    sub_description = Column(String(200))
    sub_qty = Column(Qty)
    sub_shelf_price = Column(Money)      # substitute's own price
    sub_charged_price = Column(Money)    # what the customer is charged per unit (policy: lower of the two)
    sub_price_difference = Column(Money)  # shelf price difference absorbed (+) per unit
    sub_consent = Column(String(10))     # pending|accepted|rejected
    sub_consent_at = Column(DateTime(timezone=True))


class ServiceCase(Base):
    __tablename__ = "service_cases"
    id = pk()
    number = Column(String(30), unique=True, nullable=False)
    customer_id = fk("customers.id")
    order_id = fk("online_orders.id")
    site_id = fk("sites.id")
    category = Column(String(40), nullable=False)
    subject = Column(String(200), nullable=False)
    status = Column(String(20), nullable=False, default="open")
    notes = Column(JSON, nullable=False, default=list)
    opened_by = Column(Integer)
    opened_at = ts()
    closed_at = Column(DateTime(timezone=True))
