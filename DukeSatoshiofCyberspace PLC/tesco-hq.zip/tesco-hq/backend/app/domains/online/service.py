"""Online orders. Three state machines that move independently:

  order:      placed -> confirmed -> completed | cancelled
  payment:    pending -> authorised -> captured -> part_refunded -> refunded
              pending -> failed ;  pending -> uncertain -> authorised | failed ;  authorised -> voided
  fulfilment: unallocated -> reserved -> picked -> out_for_delivery | ready_for_collection
              -> delivered | collected | failed ;  (any pre-handover) -> released

An order is not a sale. Revenue is recognised when goods are handed over; cash arrives later still,
when the provider settles."""
from decimal import Decimal

from sqlalchemy import select, text

from ...adapters import mocks
from ...adapters.base import PaymentProviderTimeout
from ...common import ZERO, bad, conflict, dec, emit, flag, get_setting, now, q2
from ..catalog.models import Product, TaxCategory
from ..finance.service import tax_split
from ..inventory import service as inv
from ..org.models import Site
from ..pricing.engine import base_prices, price_basket
from ..sales import service as sales
from ..sales.models import Payment, Sale
from .models import Customer, DeliverySlot, OnlineOrder, OnlineOrderLine

MACHINES = {
    "order_status": {"placed": {"confirmed", "cancelled"}, "confirmed": {"completed", "cancelled"}, "completed": set(), "cancelled": set()},
    "payment_status": {"pending": {"authorised", "failed", "uncertain"}, "uncertain": {"authorised", "failed"},
                       "authorised": {"captured", "voided"}, "captured": {"part_refunded", "refunded"},
                       "part_refunded": {"part_refunded", "refunded"}, "failed": set(), "voided": set(), "refunded": set()},
    "fulfilment_status": {"unallocated": {"reserved", "released"}, "reserved": {"picked", "released"},
                          "picked": {"out_for_delivery", "ready_for_collection", "released"},
                          "out_for_delivery": {"delivered", "failed"}, "ready_for_collection": {"collected", "failed"},
                          "delivered": set(), "collected": set(), "failed": set(), "released": set()},
}


def transition(order, machine, new):
    cur = getattr(order, machine)
    if new == cur:
        return
    if new not in MACHINES[machine][cur]:
        raise conflict(f"Illegal {machine} transition: {cur} -> {new}", "illegal_transition")
    setattr(order, machine, new)
    order.history = list(order.history or []) + [{"at": now().isoformat(), "machine": machine, "from": cur, "to": new}]


def place_order(db, *, customer_id, slot_id, lines, payment_token, payment_key, at=None):
    """lines: [{product_id, qty, allow_substitution}]. Caller wraps this in an idempotency key so a
    retried request returns the same order instead of creating a second one or a second charge."""
    at = at or now()
    cust = db.get(Customer, customer_id)
    slot = db.get(DeliverySlot, slot_id)
    if not cust or not slot:
        raise bad("Unknown customer or slot")
    # slot capacity: conditional increment - cannot overbook under concurrency
    if db.execute(text("UPDATE delivery_slots SET booked = booked + 1 WHERE id = :i AND booked < capacity"), {"i": slot_id}).rowcount != 1:
        raise conflict("That slot is full", "slot_full")
    priced = price_basket(db, site_id=slot.site_id, channel="online", lines=lines, at=at, member_id=cust.member_id)
    n = db.execute(text("SELECT COALESCE(MAX(id),0)+1 FROM online_orders")).scalar()
    order = OnlineOrder(number=f"ON-{n:07d}", customer_id=cust.id, site_id=slot.site_id, slot_id=slot.id, method=slot.method,
                        gross_estimated=priced["totals"]["gross"], placed_at=at, payment_key=payment_key, history=[])
    db.add(order)
    db.flush()
    short = False
    for req, pl in zip(lines, priced["lines"]):
        got = inv.reserve(db, site_id=slot.site_id, product_id=pl["product_id"], qty=pl["qty"], ref_type="online_order",
                          ref_id=order.id, allow_partial=True)
        short |= got < pl["qty"]
        db.add(OnlineOrderLine(order_id=order.id, product_id=pl["product_id"], description=pl["description"], qty=pl["qty"],
                               unit_price=q2(pl["gross"] / pl["qty"]), line_gross=pl["gross"], reserved_qty=got,
                               allow_substitution=bool(req.get("allow_substitution", True)) and cust.substitution_pref != "none",
                               pricing={"base_unit_price": str(pl["base_unit_price"]), "discount": str(pl["discount"]),
                                        "applied": sales._plain_applied(pl["applied"])}))
    transition(order, "fulfilment_status", "reserved")
    try:
        res = mocks.payments.authorise(db, payment_key + ":auth", order.gross_estimated, payment_token)
        status, ref = ("authorised" if res.status == "succeeded" else "failed"), res.ref
    except PaymentProviderTimeout:
        status, ref = "uncertain", None
    db.add(Payment(order_id=order.id, site_id=order.site_id, kind="authorise", method="card", amount=order.gross_estimated,
                   status={"authorised": "succeeded", "failed": "failed", "uncertain": "uncertain"}[status], provider_ref=ref,
                   idempotency_key=payment_key + ":auth", at=at))
    transition(order, "payment_status", status)
    order.auth_ref = ref
    if status == "authorised":
        transition(order, "order_status", "confirmed")
    elif status == "failed":
        _release(db, order)
        transition(order, "order_status", "cancelled")
    else:
        flag(db, "payment_uncertain", f"{order.number}: payment authorisation timed out - outcome unknown", severity="high",
             entity_type="online_order", entity_id=order.id, site_id=order.site_id, dedupe=f"pay:{order.id}",
             detail="Do not retry the charge. Resolve by querying the provider with the original idempotency key.")
    emit(db, "online_order.placed", order.number, {"order_id": order.id, "payment_status": order.payment_status})
    db.flush()
    return order


def resolve_payment(db, order):
    """Ask the provider what happened to the original request (same key) - never issue a new charge."""
    if order.payment_status != "uncertain":
        raise conflict("Payment outcome is not uncertain")
    res = mocks.payments.lookup(db, order.payment_key + ":auth")
    pay = db.execute(select(Payment).where(Payment.idempotency_key == order.payment_key + ":auth")).scalar_one()
    if res and res.status == "succeeded":
        pay.status, pay.provider_ref, order.auth_ref = "succeeded", res.ref, res.ref
        transition(order, "payment_status", "authorised")
        transition(order, "order_status", "confirmed")
    else:
        pay.status = "failed"
        transition(order, "payment_status", "failed")
        _release(db, order)
        transition(order, "order_status", "cancelled")
    db.execute(text("UPDATE exceptions SET status='resolved', resolved_at=now(), resolution=:r WHERE dedupe_key=:k AND status='open'"),
               {"k": f"pay:{order.id}", "r": f"Provider lookup: {order.payment_status}"})
    db.flush()
    return order


def _release(db, order):
    inv.release(db, ref_type="online_order", ref_id=order.id)
    db.execute(text("UPDATE delivery_slots SET booked = GREATEST(booked - 1, 0) WHERE id = :i"), {"i": order.slot_id})
    if order.fulfilment_status in ("unallocated", "reserved", "picked"):
        transition(order, "fulfilment_status", "released")


def cancel(db, order, reason=None):
    if order.order_status not in ("placed", "confirmed") or order.fulfilment_status in ("out_for_delivery", "ready_for_collection"):
        raise conflict("Order can no longer be cancelled; use a refund after handover", "not_cancellable")
    if order.payment_status == "uncertain":
        raise conflict("Resolve the uncertain payment before cancelling", "payment_uncertain")
    _release(db, order)
    if order.payment_status == "authorised":
        mocks.payments.void(db, order.payment_key + ":void", order.auth_ref)
        db.add(Payment(order_id=order.id, site_id=order.site_id, kind="void", method="card", amount=ZERO, provider_ref=order.auth_ref,
                       idempotency_key=order.payment_key + ":void", at=now()))
        transition(order, "payment_status", "voided")
    transition(order, "order_status", "cancelled")
    db.flush()
    return order


def pick(db, order, picks, actor_id=None):
    """picks: [{line_id, picked_qty, substitute_product_id?, substitute_qty?}]"""
    if order.order_status != "confirmed" or order.fulfilment_status != "reserved":
        raise conflict(f"Order is not ready to pick (order {order.order_status}, fulfilment {order.fulfilment_status})")
    site = db.get(Site, order.site_id)
    cust = db.get(Customer, order.customer_id)
    by_id = {p["line_id"]: p for p in picks}
    for line in db.execute(select(OnlineOrderLine).where(OnlineOrderLine.order_id == order.id)).scalars():
        pk_ = by_id.get(line.id, {"picked_qty": line.reserved_qty})
        picked = dec(pk_.get("picked_qty", 0))
        if picked < 0 or picked > line.reserved_qty:
            raise bad(f"'{line.description}': picked {picked} but only {line.reserved_qty} reserved")
        if picked < line.reserved_qty:
            inv.release(db, ref_type="online_order", ref_id=order.id, product_id=line.product_id, qty=line.reserved_qty - picked, actor_id=actor_id)
        line.picked_qty = picked
        line.status = "picked" if picked == line.qty else "short"
        sub_id = pk_.get("substitute_product_id")
        if sub_id and picked < line.qty:
            if not line.allow_substitution:
                raise conflict(f"Customer does not allow substitution for '{line.description}'", "substitution_not_allowed")
            sub = db.get(Product, sub_id)
            sub_qty = dec(pk_.get("substitute_qty", line.qty - picked))
            if sub_qty > line.qty - picked:
                raise bad("Substitute quantity exceeds the shortfall")
            inv.reserve(db, site_id=order.site_id, product_id=sub.id, qty=sub_qty, ref_type="online_order", ref_id=order.id, actor_id=actor_id)
            shelf = base_prices(db, [sub.id], site, "online", now())[sub.id][0].price
            charged = min(shelf, line.unit_price)  # demo policy: customer never pays more than they agreed
            line.sub_product_id, line.sub_description, line.sub_qty = sub.id, sub.name, sub_qty
            line.sub_shelf_price, line.sub_charged_price, line.sub_price_difference = shelf, charged, shelf - charged
            line.sub_consent = "pending" if cust.substitution_pref != "allow" else "pending"
            line.status = "substituted"
    transition(order, "fulfilment_status", "picked")
    db.flush()
    return order


def dispatch(db, order):
    transition(order, "fulfilment_status", "out_for_delivery" if order.method == "delivery" else "ready_for_collection")
    db.flush()
    return order


def handover(db, order, *, substitution_decisions=None, failed_reason=None, actor_id=None, at=None):
    """Customer receives the order (or delivery fails). Substitution consent is recorded here; rejected
    substitutes are not charged and go back to stock. Then payment is captured for the final amount and
    the sale is recognised."""
    at = at or now()
    if order.fulfilment_status not in ("out_for_delivery", "ready_for_collection"):
        raise conflict("Order has not been dispatched")
    if failed_reason:
        transition(order, "fulfilment_status", "failed")
        inv.release(db, ref_type="online_order", ref_id=order.id)
        mocks.payments.void(db, order.payment_key + ":void", order.auth_ref)
        transition(order, "payment_status", "voided")
        transition(order, "order_status", "cancelled")
        flag(db, "failed_delivery", f"{order.number} could not be delivered: {failed_reason}", severity="medium",
             entity_type="online_order", entity_id=order.id, site_id=order.site_id)
        db.flush()
        return order
    decisions = substitution_decisions or {}
    rates = {t.id: t.rate for t in db.execute(select(TaxCategory)).scalars()}
    priced_lines = []
    for line in db.execute(select(OnlineOrderLine).where(OnlineOrderLine.order_id == order.id).order_by(OnlineOrderLine.id)).scalars():
        prod = db.get(Product, line.product_id)
        if line.picked_qty > 0:
            g = line.line_gross if line.picked_qty == line.qty else q2(line.line_gross * line.picked_qty / line.qty)
            before = q2(dec(line.pricing["base_unit_price"]) * line.picked_qty)
            net, tax = tax_split(g, rates[prod.tax_category_id])
            priced_lines.append({"product_id": prod.id, "sku": prod.sku, "description": line.description, "product_version": prod.version,
                                 "qty": line.picked_qty, "base_unit_price": dec(line.pricing["base_unit_price"]),
                                 "gross_before_discount": max(before, g), "discount": max(before, g) - g, "gross": g,
                                 "tax_rate": rates[prod.tax_category_id], "net": net, "tax": tax, "applied": line.pricing.get("applied")})
        if line.sub_product_id:
            decision = decisions.get(str(line.id), decisions.get(line.id, "accepted"))
            line.sub_consent, line.sub_consent_at = decision, at
            if decision == "rejected":
                inv.release(db, ref_type="online_order", ref_id=order.id, product_id=line.sub_product_id, qty=line.sub_qty, actor_id=actor_id)
            else:
                sub = db.get(Product, line.sub_product_id)
                g = q2(line.sub_charged_price * line.sub_qty)
                before = q2(line.sub_shelf_price * line.sub_qty)
                net, tax = tax_split(g, rates[sub.tax_category_id])
                priced_lines.append({"product_id": sub.id, "sku": sub.sku, "description": f"{sub.name} (substitute for {line.description})",
                                     "product_version": sub.version, "qty": line.sub_qty, "base_unit_price": line.sub_shelf_price,
                                     "gross_before_discount": before, "discount": before - g, "gross": g, "tax_rate": rates[sub.tax_category_id],
                                     "net": net, "tax": tax,
                                     "applied": [{"kind": "substitution_price_match", "saving": str(before - g), "note": "charged the lower of original and substitute price"}] if before > g else []})
    if not priced_lines:
        return handover(db, order, failed_reason="Nothing could be supplied", actor_id=actor_id, at=at)
    tot = {k: sum((l[k] for l in priced_lines), ZERO) for k in ("gross_before_discount", "discount", "gross", "net", "tax")}
    if tot["gross"] > order.gross_estimated:
        raise conflict("Final amount exceeds the authorised amount; a new customer authorisation would be required", "over_capture")
    res = mocks.payments.capture(db, order.payment_key + ":capture", order.auth_ref, tot["gross"])
    pay = Payment(order_id=order.id, site_id=order.site_id, kind="capture", method="card", amount=tot["gross"], provider_ref=res.ref,
                  idempotency_key=order.payment_key + ":capture", at=at)
    db.add(pay)
    db.flush()
    cust = db.get(Customer, order.customer_id)
    sale = sales.record_sale(db, {"totals": tot, "lines": priced_lines, "rules": ["Prices fixed at order time; substitutions per policy"], "coupons": []},
                             site_id=order.site_id, channel="online", member_id=cust.member_id, actor_id=actor_id, at=at,
                             order_id=order.id, reservation_ref=("online_order", order.id), payment=pay)
    order.sale_id, order.gross_final, order.completed_at = sale.id, tot["gross"], at
    transition(order, "payment_status", "captured")
    transition(order, "fulfilment_status", "delivered" if order.method == "delivery" else "collected")
    transition(order, "order_status", "completed")
    db.flush()
    return order


def refund(db, order, *, line_items, reason, actor_id=None):
    """Post-handover refund via the linked sale. line_items: [{sale_line_id, qty, disposition}]"""
    if not order.sale_id:
        raise conflict("Order has no completed sale to refund")
    ret = sales.process_return(db, sale_id=order.sale_id, lines=line_items, reason=reason, actor_id=actor_id)
    sale = db.get(Sale, order.sale_id)
    transition(order, "payment_status", "refunded" if sale.status == "refunded" else "part_refunded")
    db.flush()
    return ret
