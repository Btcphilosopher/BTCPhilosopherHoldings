import csv
import io
from datetime import date, datetime, timedelta

from fastapi import APIRouter, Depends, File, UploadFile
from pydantic import BaseModel
from sqlalchemy import select, text

from ...adapters import mocks
from ...cache import wake_worker
from ...common import audit, bad, conflict, flag, get_or_404, get_setting, insert_once, mappings, now, row, rows
from ...db import get_db
from ...security import audited_sensitive, require
from ..platform.models import Job
from .models import (Availability, Employee, EmployeePrivate, LeaveRequest, MaintenanceRequest, Shift, StoreTask,
                     TimesheetEntry, TrainingRecord)

router = APIRouter(prefix="/workforce", tags=["Workforce & store tasks"])
SC = "(:all_sites OR {c} = ANY(CAST(:sites AS int[])))"
DUTY_REQUIRES = {"Forklift operator": "Forklift licence", "Pharmacy counter": "Pharmacy assistant certificate",
                 "Alcohol sales supervisor": "Licensing awareness", "Bakery": "Food hygiene level 2", "Counters": "Food hygiene level 2"}


def validate_shift(db, emp, starts_at, ends_at, duty, ignore_id=None):
    """Check a proposed shift against the configurable constraints. Returns (errors, warnings)."""
    pol = get_setting(db, "workforce.policy")
    errors, warnings = [], []
    hours = (ends_at - starts_at).total_seconds() / 3600
    if hours <= 0:
        errors.append("Shift must end after it starts")
    if hours > pol["max_shift_hours"]:
        errors.append(f"Shift is {hours:.1f} h; maximum is {pol['max_shift_hours']} h")
    others = [s for s in db.execute(select(Shift).where(Shift.employee_id == emp.id, Shift.status != "cancelled",
                                                        Shift.starts_at > starts_at - timedelta(days=8), Shift.starts_at < ends_at + timedelta(days=8))).scalars()
              if s.id != ignore_id]
    for s in others:
        if s.starts_at < ends_at and starts_at < s.ends_at:
            errors.append(f"Overlaps an existing shift ({s.starts_at:%a %H:%M}-{s.ends_at:%H:%M})")
        gap = min(abs((starts_at - s.ends_at).total_seconds()), abs((s.starts_at - ends_at).total_seconds())) / 3600
        if not (s.starts_at < ends_at and starts_at < s.ends_at) and gap < pol["min_rest_hours"]:
            errors.append(f"Only {gap:.1f} h rest from the shift on {s.starts_at:%a %d %b}; minimum is {pol['min_rest_hours']} h")
    week_start = (starts_at - timedelta(days=starts_at.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
    week = sum((s.ends_at - s.starts_at).total_seconds() / 3600 for s in others if week_start <= s.starts_at < week_start + timedelta(days=7)) + hours
    if week > pol["max_weekly_hours"]:
        errors.append(f"Week total would be {week:.1f} h; maximum is {pol['max_weekly_hours']} h")
    elif week > float(emp.contract_hours):
        warnings.append(f"Week total {week:.1f} h exceeds contracted {emp.contract_hours} h")
    if db.execute(select(LeaveRequest.id).where(LeaveRequest.employee_id == emp.id, LeaveRequest.status == "approved",
                                                LeaveRequest.from_date <= starts_at.date(), LeaveRequest.to_date >= starts_at.date())).first():
        errors.append("Employee is on approved leave that day")
    av = db.execute(select(Availability).where(Availability.employee_id == emp.id, Availability.weekday == starts_at.weekday())).scalar_one_or_none()
    if av is None:
        warnings.append("No availability recorded for that weekday")
    elif starts_at.time() < av.from_time or ends_at.time() > av.to_time:
        warnings.append(f"Outside stated availability ({av.from_time:%H:%M}-{av.to_time:%H:%M})")
    need = DUTY_REQUIRES.get(duty)
    if need:
        tr = db.execute(select(TrainingRecord).where(TrainingRecord.employee_id == emp.id, TrainingRecord.course == need)
                        .order_by(TrainingRecord.expires_on.desc().nulls_first())).scalars().first()
        if not tr:
            errors.append(f"Duty '{duty}' requires '{need}', which is not on record")
        elif tr.expires_on and tr.expires_on < starts_at.date():
            errors.append(f"'{need}' expired on {tr.expires_on}")
    return errors, warnings


@router.get("/employees")
def employees(site_id: int | None = None, p=Depends(require("workforce.read")), db=Depends(get_db)):
    return mappings(db, f"""SELECT e.*, s.name site,
          (SELECT MIN(expires_on) FROM training_records t WHERE t.employee_id=e.id AND t.expires_on IS NOT NULL) next_expiry,
          (SELECT COALESCE(SUM(EXTRACT(EPOCH FROM (h.ends_at-h.starts_at))/3600),0) FROM shifts h WHERE h.employee_id=e.id
             AND h.starts_at >= date_trunc('week', now()) AND h.starts_at < date_trunc('week', now()) + interval '7 days') hours_this_week
        FROM employees e JOIN sites s ON s.id=e.site_id WHERE (:s IS NULL OR e.site_id=:s) AND {SC.format(c='e.site_id')} ORDER BY s.name, e.name""",
                    s=site_id, **p.sql_sites("workforce.read"))


@router.get("/employees/{emp_id}")
def employee(emp_id: int, p=Depends(require("workforce.read")), db=Depends(get_db)):
    e = get_or_404(db, Employee, emp_id)
    p.check_read("workforce.read", e.site_id)
    f = lambda m: rows(db.execute(select(m).where(m.employee_id == emp_id)).scalars())
    out = row(e, training=f(TrainingRecord), availability=f(Availability), leave=f(LeaveRequest),
              private={"restricted": "Requires workforce.private.read. Access is audited."})
    if p.can("workforce.private.read", e.site_id):
        audited_sensitive(db, p, "workforce.private_viewed", "employee", e.id)
        db.commit()
        out["private"] = row(db.get(EmployeePrivate, emp_id)) or {}
        out["private"]["note"] = "No medical information is held here; health matters are handled in the occupational-health system."
    return out


@router.get("/shifts")
def shifts(site_id: int | None = None, days: int = 7, p=Depends(require("workforce.read")), db=Depends(get_db)):
    return mappings(db, f"""SELECT h.*, e.name employee, e.job_role, s.name site, ROUND(EXTRACT(EPOCH FROM (h.ends_at-h.starts_at))/3600, 2) hours
        FROM shifts h JOIN employees e ON e.id=h.employee_id JOIN sites s ON s.id=h.site_id
        WHERE (:s IS NULL OR h.site_id=:s) AND h.starts_at >= current_date - 1 AND h.starts_at < current_date + CAST(:d AS int) AND {SC.format(c='h.site_id')}
        ORDER BY h.starts_at, s.name""", s=site_id, d=days, **p.sql_sites("workforce.read"))


class ShiftIn(BaseModel):
    employee_id: int
    starts_at: datetime
    ends_at: datetime
    duty: str
    dry_run: bool = False


@router.post("/shifts")
def create_shift(body: ShiftIn, p=Depends(require("workforce.write")), db=Depends(get_db)):
    e = get_or_404(db, Employee, body.employee_id)
    p.check("workforce.write", e.site_id)
    errors, warnings = validate_shift(db, e, body.starts_at, body.ends_at, body.duty)
    if errors:
        raise conflict("Shift violates scheduling constraints: " + "; ".join(errors), "schedule_constraint", {"errors": errors, "warnings": warnings})
    if body.dry_run:
        return {"valid": True, "warnings": warnings}
    s = Shift(employee_id=e.id, site_id=e.site_id, starts_at=body.starts_at, ends_at=body.ends_at, duty=body.duty, warnings=warnings, created_by=p.user.id)
    db.add(s)
    db.commit()
    return row(s)


@router.post("/shifts/{shift_id}/cancel")
def cancel_shift(shift_id: int, p=Depends(require("workforce.write")), db=Depends(get_db)):
    s = get_or_404(db, Shift, shift_id)
    p.check("workforce.write", s.site_id)
    s.status = "cancelled"
    db.commit()
    return row(s)


@router.get("/training")
def training(expiring_days: int | None = None, p=Depends(require("workforce.read")), db=Depends(get_db)):
    return mappings(db, f"""SELECT t.*, e.name employee, s.name site, (t.expires_on - current_date) days_left,
          CASE WHEN t.expires_on IS NULL THEN 'valid' WHEN t.expires_on < current_date THEN 'expired'
               WHEN t.expires_on < current_date + 30 THEN 'expiring' ELSE 'valid' END status
        FROM training_records t JOIN employees e ON e.id=t.employee_id JOIN sites s ON s.id=e.site_id
        WHERE (:d IS NULL OR t.expires_on <= current_date + CAST(:d AS int)) AND {SC.format(c='e.site_id')} ORDER BY t.expires_on NULLS LAST""",
                    d=expiring_days, **p.sql_sites("workforce.read"))


class TrainingIn(BaseModel):
    employee_id: int
    course: str
    completed_on: date
    expires_on: date | None = None


@router.post("/training")
def add_training(body: TrainingIn, p=Depends(require("workforce.write")), db=Depends(get_db)):
    e = get_or_404(db, Employee, body.employee_id)
    p.check("workforce.write", e.site_id)
    t = TrainingRecord(**body.model_dump())
    db.add(t)
    db.commit()
    return row(t)


@router.get("/leave")
def leave(p=Depends(require("workforce.read")), db=Depends(get_db)):
    return mappings(db, f"""SELECT l.*, e.name employee, s.name site, e.site_id FROM leave_requests l JOIN employees e ON e.id=l.employee_id
        JOIN sites s ON s.id=e.site_id WHERE {SC.format(c='e.site_id')} ORDER BY l.id DESC""", **p.sql_sites("workforce.read"))


class LeaveIn(BaseModel):
    employee_id: int
    from_date: date
    to_date: date
    category: str = "annual"


@router.post("/leave")
def request_leave(body: LeaveIn, p=Depends(require("workforce.write")), db=Depends(get_db)):
    e = get_or_404(db, Employee, body.employee_id)
    p.check("workforce.write", e.site_id)
    if body.category not in ("annual", "unpaid", "other") or body.to_date < body.from_date:
        raise bad("Category must be annual, unpaid or other, and dates must be in order. Reasons for absence are not recorded here.")
    l = LeaveRequest(**body.model_dump())
    db.add(l)
    db.commit()
    return row(l)


class LeaveDecision(BaseModel):
    approve: bool


@router.post("/leave/{leave_id}/decision")
def decide_leave(leave_id: int, body: LeaveDecision, p=Depends(require("workforce.write")), db=Depends(get_db)):
    """A person decides leave; the system only reports clashes with planned shifts."""
    l = get_or_404(db, LeaveRequest, leave_id)
    e = db.get(Employee, l.employee_id)
    p.check("workforce.write", e.site_id)
    if l.status != "requested":
        raise conflict(f"Leave already {l.status}")
    l.status, l.decided_by = ("approved" if body.approve else "declined"), p.user.id
    clashes = mappings(db, "SELECT id, starts_at FROM shifts WHERE employee_id=:e AND status='planned' AND starts_at::date BETWEEN :f AND :t",
                       e=e.id, f=l.from_date, t=l.to_date) if body.approve else []
    audit(db, p, f"leave.{l.status}", "leave_request", l.id)
    db.commit()
    return {"leave": row(l), "shift_clashes_to_reassign": clashes}


@router.post("/timesheets/import")
async def import_timesheets(file: UploadFile = File(...), p=Depends(require("workforce.write")), db=Depends(get_db)):
    """Queue a timesheet CSV (employee_no,work_date,hours) for the background worker.
    Re-importing the same file is harmless: rows are unique per employee, date and source."""
    data = (await file.read()).decode("utf-8", "replace")
    job = Job(kind="timesheet_import", payload={"source": file.filename, "csv": data[:500_000]}, created_by=p.user.id)
    db.add(job)
    db.commit()
    wake_worker()
    return row(job)


def run_timesheet_import(db, job):
    ok = skipped = 0
    errors = []
    emps = {e.employee_no: e.id for e in db.execute(select(Employee)).scalars()}
    for i, r in enumerate(csv.DictReader(io.StringIO(job.payload["csv"])), start=2):
        try:
            eid = emps[r["employee_no"].strip()]
            if insert_once(db, TimesheetEntry, employee_id=eid, work_date=date.fromisoformat(r["work_date"].strip()),
                           hours=float(r["hours"]), source=job.payload["source"], job_id=job.id):
                ok += 1
            else:
                skipped += 1
        except Exception as e:  # noqa: BLE001 - report bad rows, keep going
            errors.append(f"line {i}: {type(e).__name__} {e}")
    return {"imported": ok, "duplicates_skipped": skipped, "errors": errors[:50]}


@router.get("/timesheets")
def timesheets(p=Depends(require("workforce.read")), db=Depends(get_db)):
    return mappings(db, f"""SELECT t.*, e.name employee, e.employee_no, s.name site FROM timesheet_entries t JOIN employees e ON e.id=t.employee_id
        JOIN sites s ON s.id=e.site_id WHERE {SC.format(c='e.site_id')} ORDER BY t.work_date DESC, e.name LIMIT 500""", **p.sql_sites("workforce.read"))


@router.post("/timesheets/export-to-hr")
def export_hr(p=Depends(require("workforce.write")), db=Depends(get_db)):
    """Hand approved hours to the HR/payroll system through its adapter. No pay is calculated here."""
    entries = mappings(db, "SELECT employee_id, work_date, hours FROM timesheet_entries WHERE work_date >= current_date - 14")
    out = mocks.hr.export_timesheets(entries)
    audit(db, p, "timesheets.exported_to_hr", detail=out, sensitive=True)
    db.commit()
    return out


class TaskIn(BaseModel):
    site_id: int
    title: str
    category: str = "general"
    priority: str = "normal"
    due_at: datetime | None = None
    assigned_to: int | None = None


@router.get("/tasks")
def tasks(status: str | None = "open", p=Depends(require("workforce.read")), db=Depends(get_db)):
    return mappings(db, f"""SELECT t.*, s.name site, e.name assignee, (t.due_at < now() AND t.status='open') overdue FROM store_tasks t
        JOIN sites s ON s.id=t.site_id LEFT JOIN employees e ON e.id=t.assigned_to
        WHERE (:st IS NULL OR t.status=:st) AND {SC.format(c='t.site_id')} ORDER BY t.due_at NULLS LAST""", st=status, **p.sql_sites("workforce.read"))


@router.post("/tasks")
def add_task(body: TaskIn, p=Depends(require("workforce.write")), db=Depends(get_db)):
    p.check("workforce.write", body.site_id)
    if body.assigned_to and db.get(Employee, body.assigned_to).site_id != body.site_id:
        raise bad("Assignee works at a different site")
    t = StoreTask(**body.model_dump(), created_by=p.user.id)
    db.add(t)
    db.commit()
    return row(t)


class TaskPatch(BaseModel):
    assigned_to: int | None = None
    complete: bool = False


@router.post("/tasks/{task_id}")
def update_task(task_id: int, body: TaskPatch, p=Depends(require("workforce.write")), db=Depends(get_db)):
    t = get_or_404(db, StoreTask, task_id)
    p.check("workforce.write", t.site_id)
    if body.assigned_to:
        t.assigned_to = body.assigned_to
    if body.complete:
        t.status, t.completed_at = "done", now()
    db.commit()
    return row(t)


class MaintIn(BaseModel):
    site_id: int
    equipment: str
    description: str
    priority: str = "normal"


@router.get("/maintenance")
def maintenance(p=Depends(require("workforce.read")), db=Depends(get_db)):
    return mappings(db, f"""SELECT m.*, s.name site FROM maintenance_requests m JOIN sites s ON s.id=m.site_id
        WHERE {SC.format(c='m.site_id')} ORDER BY (m.status='closed'), m.id DESC""", **p.sql_sites("workforce.read"))


@router.post("/maintenance")
def add_maintenance(body: MaintIn, p=Depends(require("workforce.write")), db=Depends(get_db)):
    p.check("workforce.write", body.site_id)
    m = MaintenanceRequest(**body.model_dump(), raised_by=p.user.id)
    db.add(m)
    db.flush()
    if body.priority == "urgent":
        flag(db, "maintenance_urgent", f"Urgent maintenance: {body.equipment}", severity="high", entity_type="maintenance_request",
             entity_id=m.id, site_id=body.site_id)
    db.commit()
    return row(m)


class MaintPatch(BaseModel):
    status: str
    contractor_ref: str | None = None


@router.post("/maintenance/{mid}")
def update_maintenance(mid: int, body: MaintPatch, p=Depends(require("workforce.write")), db=Depends(get_db)):
    m = get_or_404(db, MaintenanceRequest, mid)
    p.check("workforce.write", m.site_id)
    if body.status not in ("open", "assigned", "closed"):
        raise bad("status must be open, assigned or closed")
    m.status, m.contractor_ref = body.status, body.contractor_ref or m.contractor_ref
    if body.status == "closed":
        m.closed_at = now()
    db.commit()
    return row(m)
