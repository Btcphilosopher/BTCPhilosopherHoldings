from sqlalchemy import JSON, Column, Date, DateTime, Integer, Numeric, String, Text, Time, UniqueConstraint

from ...db import Base, fk, pk, ts


class Employee(Base):
    """General workforce record: work facts only. Personal data is in employee_private."""
    __tablename__ = "employees"
    id = pk()
    employee_no = Column(String(20), unique=True, nullable=False)
    name = Column(String(160), nullable=False)
    site_id = fk("sites.id", nullable=False)
    department = Column(String(60))
    job_role = Column(String(80), nullable=False)
    contract_hours = Column(Numeric(5, 2), nullable=False, default=37.5)
    status = Column(String(20), nullable=False, default="active")
    started_on = Column(Date)


class EmployeePrivate(Base):
    """Restricted (workforce.private.read, access audited). Holds no medical detail by design:
    health information belongs in the occupational-health system behind the HR adapter."""
    __tablename__ = "employee_private"
    employee_id = Column(Integer, primary_key=True)
    date_of_birth = Column(Date)
    home_address = Column(String(300))
    personal_phone = Column(String(40))
    emergency_contact = Column(String(200))


class Availability(Base):
    __tablename__ = "availability"
    id = pk()
    employee_id = fk("employees.id", nullable=False)
    weekday = Column(Integer, nullable=False)
    from_time = Column(Time, nullable=False)
    to_time = Column(Time, nullable=False)
    __table_args__ = (UniqueConstraint("employee_id", "weekday"),)


class Shift(Base):
    __tablename__ = "shifts"
    id = pk()
    employee_id = fk("employees.id", nullable=False)
    site_id = fk("sites.id", nullable=False)
    starts_at = Column(DateTime(timezone=True), nullable=False, index=True)
    ends_at = Column(DateTime(timezone=True), nullable=False)
    duty = Column(String(80), nullable=False)
    status = Column(String(20), nullable=False, default="planned")
    warnings = Column(JSON)
    created_by = Column(Integer)


class TrainingRecord(Base):
    __tablename__ = "training_records"
    id = pk()
    employee_id = fk("employees.id", nullable=False)
    course = Column(String(120), nullable=False)
    completed_on = Column(Date, nullable=False)
    expires_on = Column(Date)


class LeaveRequest(Base):
    __tablename__ = "leave_requests"
    id = pk()
    employee_id = fk("employees.id", nullable=False)
    from_date = Column(Date, nullable=False)
    to_date = Column(Date, nullable=False)
    category = Column(String(20), nullable=False, default="annual")  # annual|unpaid|other (no medical detail)
    status = Column(String(20), nullable=False, default="requested")
    decided_by = Column(Integer)
    requested_at = ts()


class TimesheetEntry(Base):
    __tablename__ = "timesheet_entries"
    id = pk()
    employee_id = fk("employees.id", nullable=False)
    work_date = Column(Date, nullable=False)
    hours = Column(Numeric(5, 2), nullable=False)
    source = Column(String(60), nullable=False)
    job_id = Column(Integer)
    __table_args__ = (UniqueConstraint("employee_id", "work_date", "source"),)


class StoreTask(Base):
    __tablename__ = "store_tasks"
    id = pk()
    site_id = fk("sites.id", nullable=False)
    title = Column(String(200), nullable=False)
    category = Column(String(40), nullable=False, default="general")
    priority = Column(String(10), nullable=False, default="normal")
    due_at = Column(DateTime(timezone=True))
    status = Column(String(20), nullable=False, default="open", index=True)
    assigned_to = fk("employees.id")
    created_by = Column(Integer)
    created_at = ts()
    completed_at = Column(DateTime(timezone=True))


class MaintenanceRequest(Base):
    __tablename__ = "maintenance_requests"
    id = pk()
    site_id = fk("sites.id", nullable=False)
    equipment = Column(String(120), nullable=False)
    description = Column(Text, nullable=False)
    priority = Column(String(10), nullable=False, default="normal")
    status = Column(String(20), nullable=False, default="open", index=True)
    raised_by = Column(Integer)
    raised_at = ts()
    contractor_ref = Column(String(80))
    closed_at = Column(DateTime(timezone=True))
