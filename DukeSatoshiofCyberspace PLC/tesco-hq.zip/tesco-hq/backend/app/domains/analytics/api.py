"""Executive overview and decision-support analytics.

Rule for everything in this file: a number is only shown together with its definition, period,
currency/unit, source tables, and (for ratios) the numerator and denominator. Actuals, budgets and
forecasts are separate fields - never blended. Each metric names a drill-down that lists the rows
it was computed from."""
from datetime import date, timedelta
from decimal import Decimal

from fastapi import APIRouter, Depends
from sqlalchemy import text

from ...adapters import mocks
from ...cache import cache_get, cache_set
from ...common import ZERO, get_setting, mappings, now, plain, q2
from ...db import get_db
from ...security import require

router = APIRouter(tags=["Executive overview & analytics"])
S = "(:all_sites OR {c} = ANY(CAST(:sites AS int[])))"


def metric(key, label, value, unit, definition, source, *, basis="actual", numerator=None, denominator=None,
           exclusions=None, drill=None, period=None):
    return {"key": key, "label": label, "value": value, "unit": unit, "basis": basis, "definition": definition, "source": source,
            "numerator": numerator, "denominator": denominator, "exclusions": exclusions, "drill": drill, "period": period}


def pct(n, d):
    return (Decimal(n) * 100 / Decimal(d)).quantize(Decimal("0.1")) if d else None


def _period(days):
    end = date.today()
    start = end - timedelta(days=days - 1)
    return start, end


@router.get("/executive/overview")
def overview(days: int = 14, p=Depends(require("exec.read")), db=Depends(get_db)):
    days = max(1, min(days, 90))
    sc = p.sql_sites("exec.read")
    ck = f"exec:{p.user.id}:{days}"
    if (hit := cache_get(ck)) is not None:
        hit["cache"] = "hit (30 s TTL)"
        return hit
    start, end = _period(days)
    P = {"f": start, "t": end, **sc}
    per = f"{start:%d %b %Y} to {end:%d %b %Y} ({days} days, dates in UTC)"
    one = lambda sql, **kw: db.execute(text(sql), {**P, **kw}).one()
    dq = f"date_from={start}&date_to={end}"

    o = one(f"SELECT COUNT(*), COALESCE(SUM(gross_estimated),0) FROM online_orders o WHERE placed_at::date BETWEEN :f AND :t AND {S.format(c='o.site_id')}")
    s = one(f"""SELECT COUNT(*), COALESCE(SUM(gross),0), COALESCE(SUM(net),0), COALESCE(SUM(cost),0), COALESCE(SUM(tax),0)
                FROM sales s WHERE at::date BETWEEN :f AND :t AND {S.format(c='s.site_id')}""")
    r = one(f"SELECT COUNT(*), COALESCE(SUM(gross),0), COALESCE(SUM(net),0), COALESCE(SUM(cost_restored),0) FROM sale_returns r WHERE at::date BETWEEN :f AND :t AND {S.format(c='r.site_id')}")
    cash = one(f"""SELECT COALESCE(SUM(l.debit),0) FROM journal_lines l JOIN journal_entries e ON e.id=l.entry_id JOIN accounts a ON a.id=l.account_id
                  WHERE a.code='1000' AND e.source_type IN ('settlement','cash_reconciliation') AND e.entry_date BETWEEN :f AND :t
                  AND (:all_sites OR l.site_id IS NULL OR l.site_id = ANY(CAST(:sites AS int[])))""")[0]
    inv_val = one(f"""SELECT COALESCE(SUM(b.qty*l.unit_cost),0) FROM stock_balances b JOIN lots l ON l.id=b.lot_id
                     WHERE b.bucket IN ('available','reserved','in_transit','quarantined') AND {S.format(c='b.site_id')}""")[0]
    gl = one(f"""SELECT COALESCE(SUM(CASE WHEN a.code IN ('4000','4010','4020') THEN l.credit-l.debit END),0) revenue,
                        COALESCE(SUM(CASE WHEN a.code='5000' THEN l.debit-l.credit END),0) cogs,
                        COALESCE(SUM(CASE WHEN a.code='5100' THEN l.debit-l.credit END),0) waste,
                        COALESCE(SUM(CASE WHEN a.code BETWEEN '6000' AND '6899' THEN l.debit-l.credit END),0) opex
                 FROM journal_lines l JOIN journal_entries e ON e.id=l.entry_id JOIN accounts a ON a.id=l.account_id
                 WHERE e.entry_date BETWEEN :f AND :t AND (:all_sites OR l.site_id = ANY(CAST(:sites AS int[])))""")
    gp = gl.revenue - gl.cogs
    flow = [
        metric("orders", "Online orders placed", {"count": o[0], "value": q2(o[1])}, "GBP incl. VAT", "Online orders placed in the period at their estimated value when placed. Not yet sales: an order may be cancelled, substituted or part-picked.", "online_orders", drill="/online/orders", period=per),
        metric("completed_sales", "Completed sales", {"count": s[0], "value": q2(s[1])}, "GBP incl. VAT", "Till transactions plus online orders handed over in the period, at the VAT-inclusive amount charged.", "sales", drill=f"/sales?{dq}", period=per),
        metric("revenue", "Revenue (net)", q2(gl.revenue), "GBP excl. VAT", "Sales net of VAT, less returns and loyalty points issued (ledger accounts 4000, 4010, 4020).", "journal_lines", drill="/finance/journal?account=4000", period=per),
        metric("cash_receipts", "Cash receipts", q2(cash), "GBP", "Money that reached the bank in the period: card settlements received (after provider fees) plus till cash banked. Lags sales by the settlement delay.", "journal_lines (account 1000; sources: settlement, cash_reconciliation)", drill="/finance/journal?account=1000", period=per),
        metric("refunds", "Refunds", {"count": r[0], "value": q2(r[1])}, "GBP incl. VAT", "Customer refunds issued in the period, at the price actually paid.", "sale_returns", drill="/finance/journal?source_type=sale_return", period=per),
        metric("gross_profit", "Gross profit", q2(gp), "GBP", "Revenue (net) less cost of goods sold at specific lot cost (account 5000). Waste is reported separately.", "journal_lines", numerator=f"revenue {q2(gl.revenue)}", denominator=f"COGS {q2(gl.cogs)}", drill="/finance/journal?account=5000", period=per),
        metric("inventory_value", "Inventory value", q2(inv_val), "GBP at cost", "Quantity x lot unit cost for available, reserved, in-transit and quarantined stock, as at now. Damaged and expired stock is excluded (already written off).", "stock_balances, lots", exclusions="damaged and expired buckets", drill="/inventory/stock", period="as at now"),
    ]

    av = one(f"""SELECT COUNT(*) FILTER (WHERE COALESCE(b.q,0) > 0), COUNT(*) FROM replenishment_policies rp JOIN sites st ON st.id=rp.site_id AND st.kind='store'
                JOIN products pr ON pr.id=rp.product_id AND pr.status='active'
                LEFT JOIN (SELECT site_id, product_id, SUM(qty) q FROM stock_balances WHERE bucket='available' GROUP BY 1,2) b ON b.site_id=rp.site_id AND b.product_id=rp.product_id
                WHERE {S.format(c='rp.site_id')}""")
    sup = one("""SELECT COUNT(*) FILTER (WHERE a.actual_arrival <= a.slot_end), COUNT(*) FROM delivery_appointments a
                 WHERE a.actual_arrival IS NOT NULL AND a.actual_arrival::date BETWEEN :f AND :t""")
    fill = one("""SELECT COALESCE(SUM(l.cases_received),0), COALESCE(SUM(l.cases_ordered),0) FROM purchase_order_lines l JOIN purchase_orders p ON p.id=l.po_id
                  WHERE p.status IN ('received','part_received') AND EXISTS (SELECT 1 FROM goods_receipts g WHERE g.po_id=p.id AND g.received_at::date BETWEEN :f AND :t)""")
    onl = one(f"""SELECT COUNT(*) FILTER (WHERE fulfilment_status IN ('delivered','collected')), COUNT(*) FILTER (WHERE order_status <> 'placed'),
                         COUNT(*) FILTER (WHERE fulfilment_status = 'failed')
                  FROM online_orders o WHERE placed_at::date BETWEEN :f AND :t AND {S.format(c='o.site_id')}""")
    promo = one(f"""SELECT COALESCE(SUM((j->>'saving')::numeric),0), COUNT(DISTINCT sl.sale_id) FROM sale_lines sl JOIN sales s ON s.id=sl.sale_id,
                    json_array_elements(sl.promotions) j WHERE s.at::date BETWEEN :f AND :t AND j->>'promotion_id' IS NOT NULL AND {S.format(c='s.site_id')}""")
    exc = mappings(db, f"""SELECT kind, COUNT(*) n, COUNT(*) FILTER (WHERE severity='high') high FROM exceptions e WHERE status='open'
                           AND (:all_sites OR e.site_id IS NULL OR e.site_id = ANY(CAST(:sites AS int[]))) GROUP BY kind ORDER BY 3 DESC, 2 DESC""", **sc)
    kpis = [
        metric("gross_margin_pct", "Gross margin", pct(gp, gl.revenue), "%", "Gross profit / revenue (net).", "journal_lines", numerator=f"gross profit {q2(gp)}", denominator=f"revenue {q2(gl.revenue)}", drill="/finance/journal?account=5000", period=per),
        metric("operating_costs", "Operating costs", q2(gl.opex), "GBP", "Card fees, wages, energy, rent and logistics posted in the period (accounts 6000-6899). Wages, energy, rent and logistics are accruals imported from the HR and facilities feeds.", "journal_lines, operating_costs", drill="/finance/journal?source_type=operating_cost", period=per),
        metric("availability", "On-shelf availability", pct(av[0], av[1]), "%", "Share of ranged store x product lines with available stock above zero, right now. A system-stock measure: it cannot see gaps on the shelf.", "stock_balances, replenishment_policies", numerator=f"{av[0]} lines in stock", denominator=f"{av[1]} ranged lines (active products at trading stores)", exclusions="distribution centre; delisted and withdrawn products", drill="/inventory/stock", period="as at now"),
        metric("waste", "Waste", {"value": q2(gl.waste), "rate_pct": pct(gl.waste, gl.revenue)}, "GBP at cost / % of revenue", "Cost of stock written off (expiry, damage, shrink adjustments; account 5100) and its share of revenue (net).", "journal_lines", numerator=f"waste {q2(gl.waste)}", denominator=f"revenue {q2(gl.revenue)}", drill="/finance/journal?account=5100", period=per),
        metric("supplier_on_time", "Supplier deliveries on time", pct(sup[0], sup[1]), "%", "Deliveries that arrived by the end of their booked slot / deliveries that arrived in the period.", "delivery_appointments", numerator=f"{sup[0]} on time", denominator=f"{sup[1]} arrived", exclusions="deliveries not yet arrived", drill="/procurement/appointments", period=per),
        metric("supplier_in_full", "Supplier fill rate", pct(fill[0], fill[1]), "%", "Cases accepted in good condition / cases ordered, for POs with a receipt in the period.", "purchase_order_lines, goods_receipts", numerator=f"{fill[0]} cases accepted", denominator=f"{fill[1]} cases ordered", exclusions="damaged cases count as not delivered", drill="/procurement/purchase-orders", period=per),
        metric("online_fulfilment", "Online orders fulfilled", pct(onl[0], onl[1]), "%", "Orders delivered or collected / orders placed in the period whose payment was resolved.", "online_orders", numerator=f"{onl[0]} handed over", denominator=f"{onl[1]} confirmed or cancelled ({onl[2]} failed deliveries)", exclusions="orders still awaiting payment outcome", drill="/online/orders", period=per),
        metric("promotion_discount", "Promotional discount given", {"value": q2(promo[0]), "baskets": promo[1]}, "GBP incl. VAT", "Sum of promotion savings recorded on sale lines, and baskets that contained a promoted line. A cost measure only - see Analytics for uplift evaluation; no causal claim is made here.", "sale_lines.promotions", drill="/pricing/promotions", period=per),
    ]

    trend = mappings(db, f"""SELECT d::date AS day,
           (SELECT COALESCE(SUM(net),0) FROM sales s WHERE s.at::date = d::date AND {S.format(c='s.site_id')}) AS actual_net_sales,
           (SELECT ROUND(COALESCE(SUM(b.amount / (b.period_end - b.period_start + 1)),0),2) FROM budgets b WHERE b.metric='net_sales'
              AND d::date BETWEEN b.period_start AND b.period_end AND {S.format(c='b.site_id')}) AS budget_net_sales
        FROM generate_series(CAST(:f AS date), CAST(:t AS date) + 7, interval '1 day') d ORDER BY 1""", **P)
    fc = {x["day"]: x["v"] for x in mappings(db, f"""
        SELECT f.day, ROUND(SUM(f.qty * pe.price / (1 + tx.rate)), 2) v FROM forecasts f
        JOIN products pr ON pr.id=f.product_id JOIN tax_categories tx ON tx.id=pr.tax_category_id
        JOIN LATERAL (SELECT e.price FROM price_entries e JOIN price_books b ON b.id=e.price_book_id AND b.scope_type='national' AND b.channel='all'
             WHERE e.product_id=f.product_id AND e.status='published' AND e.effective_from <= now() ORDER BY e.effective_from DESC, e.id DESC LIMIT 1) pe ON true
        WHERE f.run_id=(SELECT MAX(id) FROM forecast_runs) AND f.day >= current_date AND f.day <= current_date + 7 AND {S.format(c='f.site_id')} GROUP BY f.day""", **sc)}
    today = date.today().isoformat()
    for row_ in trend:
        row_["forecast_net_sales"] = fc.get(row_["day"])
        if row_["day"] > today:
            row_["actual_net_sales"] = None
        elif row_["day"] == today:
            row_["note"] = "today is a part day"

    stores = mappings(db, f"""SELECT st.id, st.name, f.name format,
          COALESCE(SUM(s.net),0) net_sales, COALESCE(SUM(s.net - s.cost),0) gross_profit, COUNT(s.id) transactions,
          ROUND(100*COALESCE(SUM(s.net - s.cost),0)/NULLIF(SUM(s.net),0),1) margin_pct, ROUND(COALESCE(SUM(s.gross),0)/NULLIF(COUNT(s.id),0),2) avg_basket,
          (SELECT ROUND(COALESCE(SUM(b.amount * (CAST(:t AS date) - CAST(:f AS date) + 1) / (b.period_end - b.period_start + 1)),0),2) FROM budgets b WHERE b.site_id=st.id AND b.metric='net_sales') budget_net_sales
        FROM sites st LEFT JOIN store_formats f ON f.id=st.format_id LEFT JOIN sales s ON s.site_id=st.id AND s.at::date BETWEEN :f AND :t
        WHERE st.kind='store' AND {S.format(c='st.id')} GROUP BY st.id, f.name ORDER BY 4 DESC""", **P)

    fin = get_setting(db, "finance.policy")
    lag = int(fin["settlement_lag_days"])
    cf = mappings(db, f"""
      WITH days AS (SELECT d::date AS day FROM generate_series(current_date, current_date + 13, interval '1 day') d)
      SELECT days.day,
        (SELECT COALESCE(SUM(CASE WHEN kind='refund' THEN -amount ELSE amount END),0) FROM payments p WHERE p.method='card' AND p.status='succeeded'
           AND p.kind IN ('sale','capture','refund') AND p.settlement_id IS NULL AND GREATEST(p.at::date + {lag}, current_date) = days.day) AS card_settlements_due,
        (SELECT COALESCE(SUM(f.qty * pe.price),0) FROM forecasts f JOIN LATERAL (SELECT e.price FROM price_entries e JOIN price_books b ON b.id=e.price_book_id
             AND b.scope_type='national' AND b.channel='all' WHERE e.product_id=f.product_id AND e.status='published' AND e.effective_from <= now()
             ORDER BY e.effective_from DESC, e.id DESC LIMIT 1) pe ON true
           WHERE f.run_id=(SELECT MAX(id) FROM forecast_runs) AND f.day + {lag} = days.day) AS forecast_sales_receipts,
        (SELECT COALESCE(SUM(gross),0) FROM supplier_invoices i WHERE i.status IN ('matched','approved_for_payment') AND GREATEST(i.due_date, current_date) = days.day) AS supplier_payments_due,
        (SELECT COALESCE(SUM((l.cases_received - l.cases_invoiced) * l.case_cost),0) FROM purchase_order_lines l JOIN purchase_orders po ON po.id=l.po_id
           JOIN suppliers su ON su.id=po.supplier_id WHERE l.cases_received > l.cases_invoiced AND GREATEST(po.expected_date + su.payment_terms_days, current_date) = days.day) AS uninvoiced_receipts_due
      FROM days ORDER BY 1""")
    bal = db.execute(text("SELECT COALESCE(SUM(l.debit-l.credit),0) FROM journal_lines l JOIN accounts a ON a.id=l.account_id WHERE a.code='1000'")).scalar()
    running = bal
    for c in cf:
        c["inflow"] = str(Decimal(c["card_settlements_due"]) + Decimal(c["forecast_sales_receipts"]))
        c["outflow"] = str(Decimal(c["supplier_payments_due"]) + Decimal(c["uninvoiced_receipts_due"]))
        running += Decimal(c["inflow"]) - Decimal(c["outflow"])
        c["projected_bank_balance"] = str(q2(running))

    out = plain({
        "currency": "GBP", "generated_at": now(), "period": {"from": start, "to": end, "days": days, "label": per},
        "scope": "All sites" if sc["all_sites"] else f"{len(sc['sites'])} site(s) in your permission scope",
        "flow": flow, "kpis": kpis, "trend": trend, "stores": stores, "exceptions": exc,
        "trend_notes": {"actual": "Net sales from the sales table.", "budget": "Period budget spread evenly by day (budgets table).",
                        "forecast": "Latest forecast run: units x current national shelf price, ex-VAT. Promotions are not modelled."},
        "cash_flow_forecast": {"basis": "forecast", "opening_bank_balance": q2(bal), "rows": cf, "scope": "Whole business (not filtered by site scope)",
                               "method": f"Inflows: unsettled card takings on their expected settlement date (sale date + {lag} days) plus forecast sales at shelf price "
                                         f"(+{lag} days). Outflows: matched supplier invoices on their due date, and received-not-invoiced goods at PO date + payment terms. "
                                         "Excludes wages, tax and capital spend. A planning aid, not a treasury forecast."}})
    cache_set(ck, out, ttl=30)
    out["cache"] = "miss"
    return out


@router.get("/analytics/summary")
def analytics(days: int = 14, p=Depends(require("analytics.read")), db=Depends(get_db)):
    sc = p.sql_sites("analytics.read")
    start, end = date.today() - timedelta(days=days), date.today() - timedelta(days=1)
    P = {"f": start, "t": end, **sc}
    per = f"{start:%d %b} to {end:%d %b %Y} ({days} complete days)"
    out = []

    # ---- like-for-like
    min_weeks = int(get_setting(db, "analytics.policy")["lfl_min_weeks_open"])
    lfl = mappings(db, f"""
        SELECT st.id, st.name, st.opened_on, st.status,
          (st.status='trading' AND st.opened_on <= CAST(:f AS date) - CAST(:w AS int) * 7 - 364) eligible,
          (SELECT COALESCE(SUM(net),0) FROM sales s WHERE s.site_id=st.id AND s.at::date BETWEEN :f AND :t) this_period,
          (SELECT COALESCE(SUM(net_sales),0) FROM legacy_sales_daily l WHERE l.site_id=st.id AND l.day BETWEEN CAST(:f AS date) - 364 AND CAST(:t AS date) - 364) prior_period
        FROM sites st WHERE st.kind='store' AND {S.format(c='st.id')} ORDER BY st.name""", w=min_weeks, **P)
    cur = sum(Decimal(r["this_period"]) for r in lfl if r["eligible"])
    prev = sum(Decimal(r["prior_period"]) for r in lfl if r["eligible"])
    for r in lfl:
        r["reason"] = "eligible" if r["eligible"] else (f"opened {r['opened_on']}: fewer than {min_weeks} weeks trading before the comparative period" if r["status"] == "trading" else f"status {r['status']}")
        r["change_pct"] = pct(Decimal(r["this_period"]) - Decimal(r["prior_period"]), r["prior_period"]) if r["eligible"] and Decimal(r["prior_period"]) else None
    out.append({**metric("lfl", "Like-for-like sales growth", pct(cur - prev, prev), "%", f"Net sales growth for eligible stores only, versus the same weekdays 52 weeks earlier. Eligible = trading now and open at least {min_weeks} weeks before the comparative period began.", "sales (current); legacy_sales_daily (prior year, legacy import)", numerator=f"current {q2(cur)} - prior {q2(prev)}", denominator=f"prior {q2(prev)}", exclusions=f"{sum(not r['eligible'] for r in lfl)} store(s) excluded - see table; online and store sales both included", period=per), "rows": lfl})

    # ---- basket
    b = mappings(db, f"""SELECT s.channel, COUNT(*) baskets, ROUND(AVG(s.gross),2) avg_basket_value,
          ROUND(AVG((SELECT COUNT(*) FROM sale_lines sl WHERE sl.sale_id=s.id)),2) avg_lines
        FROM sales s WHERE s.at::date BETWEEN :f AND :t AND {S.format(c='s.site_id')} GROUP BY s.channel ORDER BY 1""", **P)
    tot = db.execute(text(f"SELECT COALESCE(SUM(gross),0), COUNT(*) FROM sales s WHERE s.at::date BETWEEN :f AND :t AND {S.format(c='s.site_id')}"), P).one()
    out.append({**metric("basket", "Average basket value", q2(tot[0] / tot[1]) if tot[1] else None, "GBP incl. VAT", "Total amount charged / number of completed sales.", "sales", numerator=f"{q2(tot[0])} charged", denominator=f"{tot[1]} sales", exclusions="refunds are not netted off", period=per), "rows": b})

    # ---- availability by store
    av = mappings(db, f"""SELECT st.name store, COUNT(*) ranged_lines, COUNT(*) FILTER (WHERE COALESCE(b.q,0) > 0) in_stock,
          ROUND(100.0*COUNT(*) FILTER (WHERE COALESCE(b.q,0) > 0)/NULLIF(COUNT(*),0),1) availability_pct
        FROM replenishment_policies rp JOIN sites st ON st.id=rp.site_id AND st.kind='store' JOIN products pr ON pr.id=rp.product_id AND pr.status='active'
        LEFT JOIN (SELECT site_id, product_id, SUM(qty) q FROM stock_balances WHERE bucket='available' GROUP BY 1,2) b ON b.site_id=rp.site_id AND b.product_id=rp.product_id
        WHERE {S.format(c='rp.site_id')} GROUP BY st.name ORDER BY 4""", **sc)
    n, d = sum(r["in_stock"] for r in av), sum(r["ranged_lines"] for r in av)
    out.append({**metric("availability", "Product availability", pct(n, d), "%", "Ranged store x product lines with available stock > 0.", "stock_balances, replenishment_policies", numerator=f"{n} in stock", denominator=f"{d} ranged lines", exclusions="DC stock; withdrawn or delisted products; system stock only", period="as at now"), "rows": av})

    # ---- inventory turnover
    t = db.execute(text(f"""SELECT (SELECT COALESCE(SUM(cost),0) FROM sales s WHERE s.at::date BETWEEN :f AND :t AND {S.format(c='s.site_id')}),
          (SELECT COALESCE(SUM(b.qty*l.unit_cost),0) FROM stock_balances b JOIN lots l ON l.id=b.lot_id WHERE b.bucket IN ('available','reserved','in_transit','quarantined') AND {S.format(c='b.site_id')})"""), P).one()
    ann = (t[0] / days * 365 / t[1]).quantize(Decimal("0.1")) if t[1] else None
    out.append({**metric("turnover", "Inventory turnover (annualised)", ann, "turns / year", "Cost of goods sold in the period, annualised, / inventory at cost now. Uses closing rather than average inventory - a simplification.", "sales, stock_balances, lots", numerator=f"COGS {q2(t[0])} over {days} days x 365/{days}", denominator=f"inventory {q2(t[1])}", exclusions="damaged and expired stock", period=per), "rows": []})

    # ---- waste
    w = mappings(db, f"""SELECT st.name site, e.source_type reason, ROUND(SUM(l.debit - l.credit),2) waste_cost FROM journal_lines l JOIN journal_entries e ON e.id=l.entry_id
        JOIN accounts a ON a.id=l.account_id AND a.code='5100' JOIN sites st ON st.id=l.site_id
        WHERE e.entry_date BETWEEN :f AND :t AND {S.format(c='l.site_id')} GROUP BY st.name, e.source_type ORDER BY 3 DESC""", **P)
    rev = db.execute(text(f"SELECT COALESCE(SUM(net),0) FROM sales s WHERE s.at::date BETWEEN :f AND :t AND {S.format(c='s.site_id')}"), P).scalar()
    wt = sum((Decimal(r["waste_cost"]) for r in w), ZERO)
    out.append({**metric("waste", "Waste rate", pct(wt, rev), "% of net sales", "Stock written off at cost (account 5100) / net sales.", "journal_lines, sales", numerator=f"waste {q2(wt)}", denominator=f"net sales {q2(rev)}", exclusions="supplier-damaged goods rejected at receipt (never valued)", period=per), "rows": w})

    # ---- supplier reliability
    sr = mappings(db, """SELECT s.name supplier, COUNT(a.id) FILTER (WHERE a.actual_arrival IS NOT NULL) deliveries,
          COUNT(a.id) FILTER (WHERE a.actual_arrival <= a.slot_end) on_time,
          ROUND(100.0*COUNT(a.id) FILTER (WHERE a.actual_arrival <= a.slot_end)/NULLIF(COUNT(a.id) FILTER (WHERE a.actual_arrival IS NOT NULL),0),1) on_time_pct,
          (SELECT ROUND(100.0*SUM(l.cases_received)/NULLIF(SUM(l.cases_ordered),0),1) FROM purchase_order_lines l JOIN purchase_orders p ON p.id=l.po_id WHERE p.supplier_id=s.id AND p.status IN ('received','part_received')) in_full_pct,
          (SELECT COUNT(*) FROM quality_incidents q WHERE q.supplier_id=s.id) incidents
        FROM suppliers s LEFT JOIN purchase_orders po ON po.supplier_id=s.id LEFT JOIN delivery_appointments a ON a.po_id=po.id GROUP BY s.id ORDER BY 4 NULLS LAST""")
    n, d = sum(r["on_time"] for r in sr), sum(r["deliveries"] for r in sr)
    out.append({**metric("supplier", "Supplier reliability (on time)", pct(n, d), "%", "Deliveries arriving by slot end / deliveries arrived. In-full = cases accepted / cases ordered on received POs.", "delivery_appointments, purchase_order_lines", numerator=f"{n} on time", denominator=f"{d} arrived", exclusions="suppliers with no deliveries show blank, not 100%", period="all recorded deliveries"), "rows": sr})

    # ---- forecast error
    run = db.execute(text("SELECT id, as_of, chosen_method, evaluation, censored_days FROM forecast_runs ORDER BY id DESC LIMIT 1")).first()
    if run:
        ev = [{"method": k, **v, "chosen": k == run.chosen_method} for k, v in run.evaluation.items() if not k.startswith("_")]
        out.append({**metric("forecast_error", "Forecast error (WAPE)", run.evaluation[run.chosen_method]["wape_pct"], "%", "Weighted absolute percentage error of the chosen baseline on a time-ordered holdout. " + run.evaluation["_protocol"], "forecast_runs, demand_observations", numerator="sum |forecast - actual|", denominator="sum actual", exclusions=f"{run.censored_days} stock-out days un-censored before scoring", period=f"forecast run #{run.id} as of {run.as_of}"), "rows": ev})

    # ---- online substitutions, picking
    ol = db.execute(text(f"""SELECT COUNT(*) FILTER (WHERE l.status <> 'pending'), COUNT(*) FILTER (WHERE l.sub_product_id IS NOT NULL),
          COUNT(*) FILTER (WHERE l.sub_consent='rejected'), COUNT(*) FILTER (WHERE l.status='picked'), COUNT(*) FILTER (WHERE l.status='short')
        FROM online_order_lines l JOIN online_orders o ON o.id=l.order_id WHERE o.placed_at::date BETWEEN :f AND CAST(:t AS date) + 1 AND {S.format(c='o.site_id')}"""), P).one()
    out.append({**metric("substitutions", "Online substitution rate", pct(ol[1], ol[0]), "%", "Picked order lines where a substitute was offered / all picked order lines. Rejected substitutions are shown separately.", "online_order_lines", numerator=f"{ol[1]} substituted ({ol[2]} rejected by the customer)", denominator=f"{ol[0]} lines picked", exclusions="lines not yet picked", period=per + " + today"), "rows": []})
    wp = db.execute(text("SELECT COUNT(*) FILTER (WHERE qty_done = qty), COUNT(*) FROM warehouse_tasks WHERE kind='pick' AND status='done'")).one()
    out.append({**metric("picking", "Picking accuracy", pct(ol[3] + wp[0], ol[0] + wp[1]), "%", "Lines picked in full as requested / lines picked, across online order lines and warehouse pick tasks. Measures completeness; mis-picks found later are not captured without scanner data.", "online_order_lines, warehouse_tasks", numerator=f"{ol[3]} online + {wp[0]} warehouse lines in full", denominator=f"{ol[0]} online + {wp[1]} warehouse lines", exclusions="open tasks", period="all recorded picks"), "rows": []})

    # ---- delivery punctuality
    dp = db.execute(text("""SELECT COUNT(*) FILTER (WHERE status='delivered' AND actual_arrival <= window_end), COUNT(*) FILTER (WHERE status IN ('delivered','failed')),
          COUNT(*) FILTER (WHERE status='failed') FROM route_stops""")).one()
    out.append({**metric("punctuality", "Store delivery punctuality", pct(dp[0], dp[1]), "%", "Store deliveries confirmed within the delivery window / completed stops. Failed deliveries count against the measure.", "route_stops", numerator=f"{dp[0]} in window", denominator=f"{dp[1]} completed ({dp[2]} failed)", exclusions="stops still en route; transfers never scheduled (see infeasible routes)", period="all recorded stops"), "rows": []})

    # ---- promotions (evaluation method stated)
    out.append(_promotions(db, sc))

    # ---- loyalty
    lo = db.execute(text(f"""SELECT COUNT(*) FILTER (WHERE member_id IS NOT NULL), COUNT(*), COUNT(DISTINCT member_id) FROM sales s
        WHERE s.at::date BETWEEN :f AND :t AND {S.format(c='s.site_id')}"""), P).one()
    members = db.execute(text("SELECT COUNT(*) FROM loyalty_members WHERE status='active'")).scalar()
    pts = mappings(db, "SELECT kind, COUNT(*) entries, SUM(points) points FROM loyalty_ledger GROUP BY kind ORDER BY 1")
    out.append({**metric("loyalty", "Loyalty participation", pct(lo[0], lo[1]), "% of sales", "Completed sales with a member card / all completed sales. Active members shopping in the period shown alongside.", "sales, loyalty_members, loyalty_ledger", numerator=f"{lo[0]} member sales ({lo[2]} distinct members of {members} active)", denominator=f"{lo[1]} sales", exclusions="none", period=per), "rows": pts})
    return plain({"period": per, "currency": "GBP", "metrics": out})


def _promotions(db, sc):
    rows_ = []
    for pr in mappings(db, "SELECT * FROM promotions WHERE status IN ('published','ended') AND starts_at <= now() ORDER BY starts_at DESC LIMIT 10"):
        pids = [r[0] for r in db.execute(text("SELECT product_id FROM promotion_products WHERE promotion_id=:p"), {"p": pr["id"]})]
        all_stores = [r[0] for r in db.execute(text("SELECT id FROM sites WHERE kind='store'"))]
        control = pr["control_site_ids"] or []
        treated = [s for s in (pr["site_ids"] or all_stores) if s not in control]
        u = db.execute(text("""
            WITH w AS (SELECT CAST(:st AS timestamptz) st, LEAST(now(), CAST(:en AS timestamptz)) en)
            SELECT COALESCE(SUM(sl.qty) FILTER (WHERE s.site_id = ANY(:tr) AND s.at >= w.st AND s.at < w.en),0) t_during,
                   COALESCE(SUM(sl.qty) FILTER (WHERE s.site_id = ANY(:tr) AND s.at < w.st AND s.at >= w.st - (w.en - w.st)),0) t_before,
                   COALESCE(SUM(sl.qty) FILTER (WHERE s.site_id = ANY(:co) AND s.at >= w.st AND s.at < w.en),0) c_during,
                   COALESCE(SUM(sl.qty) FILTER (WHERE s.site_id = ANY(:co) AND s.at < w.st AND s.at >= w.st - (w.en - w.st)),0) c_before,
                   EXTRACT(EPOCH FROM (w.en - w.st))/86400 days
            FROM sale_lines sl JOIN sales s ON s.id=sl.sale_id, w WHERE sl.product_id = ANY(:p) GROUP BY w.st, w.en"""),
                       {"st": pr["starts_at"], "en": pr["ends_at"], "tr": treated, "co": control or [-1], "p": pids or [-1]}).first()
        if not u:
            continue
        r = {"promotion": pr["code"], "name": pr["name"], "window_days": round(float(u.days), 1), "treated_stores": len(treated), "control_stores": len(control),
             "treated_units_during": u.t_during, "treated_units_before": u.t_before}
        if control and u.c_before and u.t_before:
            expected = Decimal(u.t_before) * Decimal(u.c_during) / Decimal(u.c_before)
            r.update(control_units_during=u.c_during, control_units_before=u.c_before, method="difference-in-differences vs holdout stores",
                     estimated_uplift_units=(Decimal(u.t_during) - expected).quantize(Decimal("0.1")),
                     estimated_uplift_pct=pct(Decimal(u.t_during) - expected, expected),
                     confidence="Experimental design, but few stores and a short window: no significance test is possible. Treat as indicative.")
        else:
            r.update(method="before/after comparison (observational)", estimated_uplift_units=None, estimated_uplift_pct=None,
                     raw_change_pct=pct(Decimal(u.t_during) - Decimal(u.t_before), u.t_before),
                     confidence="NOT a causal estimate: no control group. Seasonality, weather, stock and other offers are not separated out.")
        rows_.append(r)
    exp = [r for r in rows_ if r["estimated_uplift_pct"] is not None]
    return {**metric("promotions", "Promotion outcomes", {"evaluated": len(rows_), "with_control_group": len(exp)}, "promotions",
                     "Units sold of promoted products during the promotion versus an equal-length window before it. Where holdout (control) stores were configured the "
                     "uplift is a difference-in-differences estimate; otherwise only the raw change is shown and no causal claim is made.",
                     "sale_lines, promotions", numerator="see per-promotion rows", denominator="see per-promotion rows",
                     exclusions="cannibalisation of other products and pull-forward of demand are not measured", period="each promotion's own window"), "rows": rows_}


@router.get("/analytics/insights")
def insights(p=Depends(require("analytics.read", "exec.read")), db=Depends(get_db)):
    """Advisory summary of open exceptions with citations. Read-only by construction."""
    perm = "analytics.read" if p.has("analytics.read") else "exec.read"
    ex = mappings(db, """SELECT id, kind, severity, title, entity_type, entity_id FROM exceptions e WHERE status='open'
        AND (:all_sites OR e.site_id IS NULL OR e.site_id = ANY(CAST(:sites AS int[]))) ORDER BY id DESC LIMIT 500""", **p.sql_sites(perm))
    return plain(mocks.insights.summarise(ex))
