from decimal import Decimal

from fastapi import APIRouter, Depends, Header
from pydantic import BaseModel
from sqlalchemy import select

from ...common import audit, bad, get_or_404, idem_begin, idem_finish, mappings, row
from ...db import get_db
from ...security import require
from ..catalog.models import Product
from ..pricing.models import PosTerminal
from . import service
from .models import Sale

router = APIRouter(tags=["Store sales (POS)"])
SC = "(:all_sites OR {c} = ANY(CAST(:sites AS int[])))"


class BasketLine(BaseModel):
    sku: str | None = None
    product_id: int | None = None
    qty: Decimal
    lot_id: int | None = None


def resolve_lines(db, lines):
    out = []
    for l in lines:
        pid = l.product_id
        if pid is None:
            pid = db.execute(select(Product.id).where(Product.sku == l.sku)).scalar_one_or_none()
            if pid is None:
                raise bad(f"Unknown SKU {l.sku}")
        out.append({"product_id": pid, "qty": l.qty, "lot_id": l.lot_id})
    if not out:
        raise bad("Basket is empty")
    return out


class SaleIn(BaseModel):
    site_id: int
    terminal_id: int | None = None
    lines: list[BasketLine]
    member: str | None = None
    coupon_codes: list[str] = []
    tender: str = "card"
    redeem_points: int = 0


@router.post("/pos/sales")
def create_sale(body: SaleIn, idempotency_key: str | None = Header(default=None), p=Depends(require("pos.write")), db=Depends(get_db)):
    """Simulated till transaction. Integration point for a real POS: post completed baskets here with an
    Idempotency-Key; a retry returns the original sale."""
    p.check("pos.write", body.site_id)
    payload = body.model_dump(mode="json")
    if (replay := idem_begin(db, "pos.sale", idempotency_key, payload)) is not None:
        db.commit()
        return replay
    sale = service.process_sale(db, site_id=body.site_id, terminal_id=body.terminal_id, lines=resolve_lines(db, body.lines),
                                member=body.member, coupon_codes=body.coupon_codes, tender=body.tender,
                                redeem_points=body.redeem_points, actor_id=p.user.id)
    out = idem_finish(db, "pos.sale", idempotency_key, sale_detail(db, sale))
    db.commit()
    return out


def sale_detail(db, sale):
    return row(sale,
               lines=mappings(db, "SELECT sl.*, p.sku FROM sale_lines sl JOIN products p ON p.id=sl.product_id WHERE sale_id=:s ORDER BY sl.id", s=sale.id),
               payments=mappings(db, "SELECT * FROM payments WHERE sale_id=:s ORDER BY id", s=sale.id),
               returns=mappings(db, "SELECT * FROM sale_returns WHERE sale_id=:s ORDER BY id", s=sale.id),
               journal=mappings(db, """SELECT e.number, e.source_type, a.code, a.name account, l.debit, l.credit, l.memo FROM journal_lines l
                   JOIN journal_entries e ON e.id=l.entry_id JOIN accounts a ON a.id=l.account_id
                   WHERE (e.source_type='sale' AND e.source_id=:s) OR (e.source_type='sale_return' AND e.source_id IN (SELECT id FROM sale_returns WHERE sale_id=:s))
                   ORDER BY e.id, l.id""", s=sale.id),
               stock_movements=mappings(db, "SELECT at, bucket, qty, mtype, lot_id FROM stock_movements WHERE ref_type='sale' AND ref_id=:s ORDER BY id", s=sale.id),
               loyalty=mappings(db, """SELECT kind, points, ref_type, ref_id, note FROM loyalty_ledger WHERE (ref_type='sale' AND ref_id=:s)
                   OR (ref_type='sale_return' AND ref_id IN (SELECT id FROM sale_returns WHERE sale_id=:s))""", s=sale.id))


@router.get("/sales")
def sales(site_id: int | None = None, channel: str | None = None, date_from: str | None = None, date_to: str | None = None,
          product_id: int | None = None, limit: int = 300, p=Depends(require("exec.read", "pos.write", "finance.read")), db=Depends(get_db)):
    perm = next(x for x in ("exec.read", "pos.write", "finance.read") if p.has(x))
    return mappings(db, f"""SELECT s.id, s.number, s.at, st.name site, s.channel, s.gross_before_discount, s.discount, s.gross, s.net, s.tax, s.cost,
          (s.net - s.cost) gross_profit, s.refunded_gross, s.points_earned, s.status, s.order_id
        FROM sales s JOIN sites st ON st.id=s.site_id
        WHERE (:s IS NULL OR s.site_id=:s) AND (:c IS NULL OR s.channel=:c) AND (CAST(:f AS date) IS NULL OR s.at::date >= CAST(:f AS date))
          AND (CAST(:t AS date) IS NULL OR s.at::date <= CAST(:t AS date))
          AND (:p IS NULL OR EXISTS (SELECT 1 FROM sale_lines sl WHERE sl.sale_id=s.id AND sl.product_id=:p)) AND {SC.format(c='s.site_id')}
        ORDER BY s.at DESC LIMIT :lim""", s=site_id, c=channel, f=date_from, t=date_to, p=product_id, lim=min(limit, 2000), **p.sql_sites(perm))


@router.get("/sales/{sale_id}")
def sale(sale_id: int, p=Depends(require("exec.read", "pos.write", "finance.read", "service.write")), db=Depends(get_db)):
    s = get_or_404(db, Sale, sale_id)
    return sale_detail(db, s)


class ReturnLine(BaseModel):
    sale_line_id: int
    qty: Decimal
    disposition: str = "restock"


class ReturnIn(BaseModel):
    lines: list[ReturnLine]
    reason: str


@router.post("/sales/{sale_id}/returns")
def create_return(sale_id: int, body: ReturnIn, idempotency_key: str | None = Header(default=None),
                  p=Depends(require("pos.write", "service.write")), db=Depends(get_db)):
    s = get_or_404(db, Sale, sale_id)
    if not (p.can("pos.write", s.site_id) or p.can("service.write", s.site_id)):
        p.check("pos.write", s.site_id)
    payload = body.model_dump(mode="json")
    if (replay := idem_begin(db, f"return:{sale_id}", idempotency_key, payload)) is not None:
        db.commit()
        return replay
    ret = service.process_return(db, sale_id=sale_id, lines=[l.model_dump() for l in body.lines], reason=body.reason, actor_id=p.user.id)
    audit(db, p, "sale.refunded", "sale", sale_id, {"return": ret.number, "gross": ret.gross})
    out = idem_finish(db, f"return:{sale_id}", idempotency_key, {"return": row(ret), "sale": sale_detail(db, s)})
    db.commit()
    return out


@router.get("/pos/terminals")
def terminals(p=Depends(require("pricing.read", "pos.write")), db=Depends(get_db)):
    return mappings(db, "SELECT t.*, s.name site FROM pos_terminals t JOIN sites s ON s.id=t.site_id ORDER BY s.name, t.code")


class TerminalState(BaseModel):
    online: bool


@router.post("/pos/terminals/{terminal_id}/connectivity")
def set_connectivity(terminal_id: int, body: TerminalState, p=Depends(require("pricing.approve", "admin.write")), db=Depends(get_db)):
    """Simulator control: take a terminal offline/online to demonstrate unconfirmed price publications."""
    t = get_or_404(db, PosTerminal, terminal_id)
    t.online = body.online
    audit(db, p, "terminal.connectivity_simulated", "pos_terminal", t.id, {"online": body.online})
    db.commit()
    return row(t)
