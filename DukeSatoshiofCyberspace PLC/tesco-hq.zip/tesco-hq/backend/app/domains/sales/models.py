from sqlalchemy import JSON, Column, DateTime, Integer, Numeric, String, Text

from ...db import Base, Cost, Money, Qty, fk, pk, ts


class Sale(Base):
    """A completed sale (revenue is recognised here). Online orders create one at handover."""
    __tablename__ = "sales"
    id = pk()
    number = Column(String(30), unique=True, nullable=False)
    site_id = fk("sites.id", nullable=False)
    terminal_id = fk("pos_terminals.id")
    channel = Column(String(10), nullable=False, default="store", index=True)
    at = Column(DateTime(timezone=True), nullable=False, index=True)
    member_id = fk("loyalty_members.id")
    order_id = Column(Integer, index=True)
    gross_before_discount = Column(Money, nullable=False)
    discount = Column(Money, nullable=False, default=0)
    gross = Column(Money, nullable=False)   # VAT-inclusive amount charged
    net = Column(Money, nullable=False)     # revenue excluding VAT
    tax = Column(Money, nullable=False)
    cost = Column(Money, nullable=False, default=0)
    refunded_gross = Column(Money, nullable=False, default=0)
    points_earned = Column(Integer, nullable=False, default=0)
    status = Column(String(20), nullable=False, default="completed")  # completed|part_refunded|refunded
    pricing_trace = Column(JSON)
    cashier_id = Column(Integer)


class SaleLine(Base):
    __tablename__ = "sale_lines"
    id = pk()
    sale_id = fk("sales.id", nullable=False)
    product_id = fk("products.id", nullable=False)
    product_version = Column(Integer)
    description = Column(String(200), nullable=False)  # as sold; survives later product renames
    lot_id = fk("lots.id")
    qty = Column(Qty, nullable=False)
    unit_price = Column(Money, nullable=False)
    gross_before_discount = Column(Money, nullable=False)
    discount = Column(Money, nullable=False, default=0)
    gross = Column(Money, nullable=False)
    net = Column(Money, nullable=False)
    tax = Column(Money, nullable=False)
    tax_rate = Column(Numeric(6, 4), nullable=False)
    cost = Column(Cost, nullable=False, default=0)
    qty_unfulfilled = Column(Qty, nullable=False, default=0)  # sold but not found in system stock
    returned_qty = Column(Qty, nullable=False, default=0)
    refunded_gross = Column(Money, nullable=False, default=0)
    promotions = Column(JSON)


class Payment(Base):
    """Money movement against a sale or order. Card details never reach this system: only the
    provider's opaque reference is stored."""
    __tablename__ = "payments"
    id = pk()
    sale_id = fk("sales.id")
    order_id = Column(Integer, index=True)
    return_id = Column(Integer)
    site_id = fk("sites.id", nullable=False)
    kind = Column(String(12), nullable=False)    # sale|authorise|capture|refund|void
    method = Column(String(12), nullable=False)  # card|cash|points
    amount = Column(Money, nullable=False)
    status = Column(String(12), nullable=False, default="succeeded", index=True)  # succeeded|failed|uncertain|pending
    provider_ref = Column(String(80))
    idempotency_key = Column(String(120), unique=True)
    at = Column(DateTime(timezone=True), nullable=False, index=True)
    settlement_id = Column(Integer, index=True)


class SaleReturn(Base):
    __tablename__ = "sale_returns"
    id = pk()
    number = Column(String(30), unique=True, nullable=False)
    sale_id = fk("sales.id", nullable=False)
    site_id = fk("sites.id", nullable=False)
    at = Column(DateTime(timezone=True), nullable=False, index=True)
    reason = Column(Text)
    gross = Column(Money, nullable=False)
    net = Column(Money, nullable=False)
    tax = Column(Money, nullable=False)
    cost_restored = Column(Money, nullable=False, default=0)
    points_reversed = Column(Integer, nullable=False, default=0)
    processed_by = Column(Integer)


class SaleReturnLine(Base):
    __tablename__ = "sale_return_lines"
    id = pk()
    return_id = fk("sale_returns.id", nullable=False)
    sale_line_id = fk("sale_lines.id", nullable=False)
    qty = Column(Qty, nullable=False)
    gross = Column(Money, nullable=False)
    disposition = Column(String(12), nullable=False)  # restock|damaged|none
