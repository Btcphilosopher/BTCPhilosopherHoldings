"""Store sales and returns: price -> stock -> payment -> loyalty -> ledger, all in one transaction."""
from sqlalchemy import func, select

from ...adapters import mocks
from ...common import ZERO, bad, conflict, dec, emit, flag, now, q2
from ..finance.service import post_journal, tax_split
from ..inventory import service as inv
from ..loyalty import service as loyalty
from ..loyalty.models import LoyaltyCard, LoyaltyMember
from ..pricing.engine import price_basket
from .models import Payment, Sale, SaleLine, SaleReturn, SaleReturnLine

TENDER_ACCOUNT = {"card": "1020", "cash": "1010"}


def find_member(db, identifier):
    """Resolve a member number or digital-card token to a member id (identification, not authentication)."""
    if not identifier:
        return None
    m = db.execute(select(LoyaltyMember).where(LoyaltyMember.member_no == identifier)).scalar_one_or_none()
    if not m:
        card = db.execute(select(LoyaltyCard).where(LoyaltyCard.token == identifier, LoyaltyCard.status == "active")).scalar_one_or_none()
        m = db.get(LoyaltyMember, card.member_id) if card else None
    if not m or m.status != "active":
        raise bad("Loyalty member not found or inactive", "unknown_member")
    return m.id


def _next(db, model, prefix):
    return f"{prefix}-{db.execute(select(func.coalesce(func.max(model.id), 0))).scalar() + 1:07d}"


def record_sale(db, priced, *, site_id, channel="store", terminal_id=None, member_id=None, tender="card",
                redeem_points=0, actor_id=None, at=None, order_id=None, reservation_ref=None, payment=None,
                payment_key=None):
    """Persist a priced basket as a completed sale. `priced` is price_basket() output (or the same shape)."""
    at = at or now()
    t = priced["totals"]
    sale = Sale(number=_next(db, Sale, "S"), site_id=site_id, terminal_id=terminal_id, channel=channel, at=at,
                member_id=member_id, order_id=order_id, gross_before_discount=t["gross_before_discount"],
                discount=t["discount"], gross=t["gross"], net=t["net"], tax=t["tax"], cashier_id=actor_id,
                pricing_trace={"rules": priced.get("rules", []), "coupons": [dict(c, saving=str(c["saving"])) for c in priced.get("coupons", [])]})
    db.add(sale)
    db.flush()

    total_cost = ZERO
    for ln in priced["lines"]:
        qty = dec(ln["qty"])
        if reservation_ref:
            done, cost, lots = inv.consume_reserved(db, ref_type=reservation_ref[0], ref_id=reservation_ref[1],
                                                    product_id=ln["product_id"], qty=qty, mtype="sale",
                                                    out_ref_type="sale", out_ref_id=sale.id, actor_id=actor_id)
        else:
            done, cost, lots = inv.deplete(db, site_id=site_id, product_id=ln["product_id"], qty=qty, mtype="sale",
                                           ref_type="sale", ref_id=sale.id, lot_id=ln.get("lot_id"), actor_id=actor_id)
        short = qty - done
        cost = q2(cost)
        total_cost += cost
        sl = SaleLine(sale_id=sale.id, product_id=ln["product_id"], product_version=ln.get("product_version"),
                      description=ln["description"], lot_id=lots[0][0] if lots else None, qty=qty,
                      unit_price=ln["base_unit_price"], gross_before_discount=ln["gross_before_discount"],
                      discount=ln["discount"], gross=ln["gross"], net=ln["net"], tax=ln["tax"], tax_rate=ln["tax_rate"],
                      cost=cost, qty_unfulfilled=short, promotions=_plain_applied(ln.get("applied")))
        db.add(sl)
        if short > 0:
            # The customer has the goods, so the book stock was wrong. Do not go negative: record it.
            flag(db, "stock_discrepancy", f"{ln['sku']} sold {qty} but only {done} in system stock at site {site_id}",
                 severity="medium", entity_type="sale", entity_id=sale.id, site_id=site_id,
                 detail="Sale completed; shortfall left unposted to keep availability non-negative. Cycle count required.")
    sale.cost = total_cost

    for c in priced.get("coupons", []):
        if c["status"] == "applied":
            loyalty.redeem_coupon(db, c["code"], sale.id)

    # tender
    points_value = ZERO
    if redeem_points:
        if not member_id:
            raise bad("Points can only be redeemed with a member card")
        loyalty.redeem(db, member_id, int(redeem_points), "sale", sale.id)
        points_value = loyalty.point_value(db, redeem_points)
        if points_value > sale.gross:
            raise bad("Points value exceeds the basket total")
        db.add(Payment(sale_id=sale.id, site_id=site_id, kind="sale", method="points", amount=points_value, at=at,
                       idempotency_key=f"sale:{sale.id}:points"))
    due = sale.gross - points_value
    if payment is not None:           # online: already captured by the order flow
        payment.sale_id = sale.id
        tender = "card"
    elif due > 0:
        ref, key = None, payment_key or f"sale:{sale.id}:{tender}"
        if tender == "card":
            res = mocks.payments.charge(db, key, due, "tok_ok")
            if res.status != "succeeded":
                raise conflict("Card payment declined", "payment_declined")
            ref = res.ref
        elif tender != "cash":
            raise bad("Tender must be 'card' or 'cash'")
        db.add(Payment(sale_id=sale.id, site_id=site_id, kind="sale", method=tender, amount=due, provider_ref=ref,
                       idempotency_key=key, at=at))

    # loyalty: points are earned on money paid, not on points spent
    earned = 0
    if member_id:
        earned = loyalty.award(db, member_id, loyalty.points_for(db, due), "sale", sale.id, f"Sale {sale.number}")
        sale.points_earned = earned
    earned_value = loyalty.point_value(db, earned)

    post_journal(db, entry_date=at.date(), source_type="sale", source_id=sale.id, posted_by=actor_id,
                 description=f"Sale {sale.number} ({channel})", lines=[
                     (TENDER_ACCOUNT[tender], due, 0, site_id, f"{tender} tender"),
                     ("2200", points_value, 0, site_id, "points redeemed"),
                     ("4000", 0, sale.net, site_id, "revenue net of VAT"),
                     ("2100", 0, sale.tax, site_id, "output VAT"),
                     ("5000", total_cost, 0, site_id, "cost of goods sold"),
                     ("1200", 0, total_cost, site_id, "inventory relieved"),
                     ("4020", earned_value, 0, site_id, "points issued"),
                     ("2200", 0, earned_value, site_id, "points liability"),
                 ])
    emit(db, "sale.completed", sale.number, {"sale_id": sale.id, "site_id": site_id, "gross": sale.gross, "channel": channel})
    db.flush()
    return sale


def _plain_applied(applied):
    return [{k: (str(v) if not isinstance(v, (int, str, type(None))) else v) for k, v in a.items()} for a in (applied or [])]


def process_sale(db, *, site_id, lines, terminal_id=None, member=None, coupon_codes=(), tender="card", redeem_points=0,
                 actor_id=None, at=None, channel="store"):
    member_id = find_member(db, member)
    priced = price_basket(db, site_id=site_id, channel=channel, lines=lines, at=at, member_id=member_id,
                          coupon_codes=coupon_codes, terminal_id=terminal_id)
    return record_sale(db, priced, site_id=site_id, channel=channel, terminal_id=terminal_id, member_id=member_id,
                       tender=tender, redeem_points=redeem_points, actor_id=actor_id, at=at)


def process_return(db, *, sale_id, lines, reason, actor_id=None, at=None):
    """Refund items at the price actually paid and reverse stock, loyalty and ledger entries.
    lines: [{sale_line_id, qty, disposition: restock|damaged|none}]"""
    at = at or now()
    sale = db.execute(select(Sale).where(Sale.id == sale_id).with_for_update()).scalar_one_or_none()
    if not sale:
        raise bad("Sale not found", status=404)
    ret = SaleReturn(number=_next(db, SaleReturn, "R"), sale_id=sale.id, site_id=sale.site_id, at=at, reason=reason,
                     gross=0, net=0, tax=0, processed_by=actor_id)
    db.add(ret)
    db.flush()
    gross = net = tax = restored = written_off = ZERO
    for rl in lines:
        sl = db.get(SaleLine, rl["sale_line_id"])
        qty = dec(rl["qty"])
        disp = rl.get("disposition", "restock")
        if not sl or sl.sale_id != sale.id:
            raise bad("Return line does not belong to this sale")
        if qty <= 0 or qty > sl.qty - sl.returned_qty:
            raise conflict(f"Cannot return {qty}: only {sl.qty - sl.returned_qty} of '{sl.description}' remain returnable",
                           "over_return")
        full = qty == sl.qty - sl.returned_qty
        g = (sl.gross - sl.refunded_gross) if full else q2(sl.gross * qty / sl.qty)
        n, tx = tax_split(g, sl.tax_rate)
        cost = q2(sl.cost * qty / sl.qty)
        sl.returned_qty += qty
        sl.refunded_gross += g
        gross, net, tax = gross + g, net + n, tax + tx
        db.add(SaleReturnLine(return_id=ret.id, sale_line_id=sl.id, qty=qty, gross=g, disposition=disp))
        if disp in ("restock", "damaged") and sl.lot_id:
            inv.post(db, site_id=sale.site_id, product_id=sl.product_id, lot_id=sl.lot_id,
                     bucket="available" if disp == "restock" else "damaged", qty=qty, mtype="customer_return",
                     ref_type="sale_return", ref_id=ret.id, actor_id=actor_id, reason=reason)
            if disp == "restock":
                restored += cost
            else:
                written_off += cost
        elif disp not in ("restock", "damaged", "none"):
            raise bad("disposition must be restock, damaged or none")
    ret.gross, ret.net, ret.tax, ret.cost_restored = gross, net, tax, restored

    # refund to the original tender; anything paid with points goes back as points
    paid = {p.method: p for p in db.execute(select(Payment).where(Payment.sale_id == sale.id, Payment.kind.in_(["sale", "capture"]))).scalars()}
    already = db.execute(select(func.coalesce(func.sum(Payment.amount), 0)).where(
        Payment.sale_id == sale.id, Payment.kind == "refund", Payment.method != "points")).scalar()
    money = next((p for m, p in paid.items() if m != "points"), None)
    money_refund = min(gross, (money.amount - already) if money else ZERO)
    if money_refund > 0:
        ref, key = None, f"return:{ret.id}:{money.method}"
        if money.method == "card":
            ref = mocks.payments.refund(db, key, money.provider_ref, money_refund).ref
        db.add(Payment(sale_id=sale.id, order_id=sale.order_id, return_id=ret.id, site_id=sale.site_id, kind="refund",
                       method=money.method, amount=money_refund, provider_ref=ref, idempotency_key=key, at=at))
    points_refund_value = gross - money_refund
    if points_refund_value > 0 and sale.member_id:
        pts = int(points_refund_value / dec(loyalty.policy(db)["point_value"]))
        loyalty.recredit(db, sale.member_id, pts, "sale_return", ret.id, "Refund of points tender")
        db.add(Payment(sale_id=sale.id, return_id=ret.id, site_id=sale.site_id, kind="refund", method="points",
                       amount=points_refund_value, idempotency_key=f"return:{ret.id}:points", at=at))

    # reverse loyalty points earned on the refunded money
    reversed_pts = 0
    if sale.member_id and sale.points_earned and money_refund > 0 and money:
        target = int(sale.points_earned * money_refund / money.amount)
        reversed_pts = loyalty.reverse(db, sale.member_id, target, "sale_return", ret.id, f"Return {ret.number}")
    ret.points_reversed = reversed_pts
    rv = loyalty.point_value(db, reversed_pts)

    sale.refunded_gross += gross
    sale.status = "refunded" if sale.refunded_gross >= sale.gross else "part_refunded"
    s = sale.site_id
    post_journal(db, entry_date=at.date(), source_type="sale_return", source_id=ret.id, posted_by=actor_id,
                 description=f"Return {ret.number} against sale {sale.number}", lines=[
                     ("4010", net, 0, s, "sales returns"), ("2100", tax, 0, s, "output VAT reversed"),
                     (TENDER_ACCOUNT[money.method] if money else "1020", 0, money_refund, s, "refund to tender"),
                     ("2200", 0, points_refund_value, s, "points tender re-credited"),
                     ("1200", restored, 0, s, "stock returned to inventory"), ("5100", written_off, 0, s, "returned stock written off"),
                     ("5000", 0, restored + written_off, s, "cost of goods sold reversed"),
                     ("2200", rv, 0, s, "points reversed"), ("4020", 0, rv, s, "points reversed"),
                 ])
    emit(db, "sale.refunded", ret.number, {"return_id": ret.id, "sale_id": sale.id, "gross": gross})
    db.flush()
    return ret
