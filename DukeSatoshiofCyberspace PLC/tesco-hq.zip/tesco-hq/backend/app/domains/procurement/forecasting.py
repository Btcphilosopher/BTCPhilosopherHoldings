"""Transparent baseline demand forecasts.

Method (deliberately simple and inspectable):
  1. Build a daily series per store x product from demand_observations.
  2. Un-censor: on stock-out days the units sold understate demand, so they are replaced by the mean of
     the same weekday on in-stock days (or the series mean) before fitting. Counts are reported.
  3. Three baselines: seasonal-naive (same weekday last week), 7-day moving average, weekday profile
     (mean of the last 4 same weekdays).
  4. Evaluate on a time-ordered holdout: train on days before the cut, predict the last N days, never
     shuffling. Report WAPE, MAE and bias per method; choose the lowest WAPE.
  5. Forecast the horizon with the chosen method."""
from collections import defaultdict
from datetime import timedelta
from decimal import Decimal

from sqlalchemy import select

from ...common import ZERO, dec
from .models import DemandObservation, Forecast, ForecastRun

METHODS = ("seasonal_naive", "moving_average_7", "weekday_profile_4")


def _predict(method, hist, day):
    """hist: {date: demand} strictly before `day`'s forecast origin. Returns float."""
    if not hist:
        return 0.0
    last = max(hist)
    if method == "seasonal_naive":
        d = day
        while d > last:
            d -= timedelta(days=7)
        return hist.get(d, 0.0)
    if method == "moving_average_7":
        vals = [hist[d] for d in sorted(hist)[-7:]]
        return sum(vals) / len(vals)
    vals = [hist[d] for d in sorted(hist) if d.weekday() == day.weekday()][-4:]
    return sum(vals) / len(vals) if vals else sum(hist.values()) / len(hist)


def uncensor(series):
    """series: {date: (units, stockout)} -> ({date: demand}, censored_day_count)"""
    by_wd, ok = defaultdict(list), []
    for d, (u, so) in series.items():
        if not so:
            by_wd[d.weekday()].append(u)
            ok.append(u)
    out, n = {}, 0
    for d, (u, so) in series.items():
        if so:
            ref = by_wd.get(d.weekday()) or ok
            est = sum(ref) / len(ref) if ref else u
            out[d] = max(u, est)
            n += 1
        else:
            out[d] = u
    return out, n


def run_forecast(db, *, as_of, horizon=14, holdout=14, actor_id=None, site_ids=None):
    q = select(DemandObservation).where(DemandObservation.day < as_of)
    if site_ids:
        q = q.where(DemandObservation.site_id.in_(site_ids))
    raw = defaultdict(dict)
    for o in db.execute(q).scalars():
        raw[(o.site_id, o.product_id)][o.day] = (float(o.units_sold), o.stockout)
    series, censored = {}, 0
    for k, s in raw.items():
        series[k], n = uncensor(s)
        censored += n

    cut = as_of - timedelta(days=holdout)
    err = {m: {"abs": 0.0, "sum": 0.0, "act": 0.0, "n": 0} for m in METHODS}
    for k, s in series.items():
        train = {d: v for d, v in s.items() if d < cut}
        if len(train) < 14:
            continue
        for i in range(holdout):
            day = cut + timedelta(days=i)
            if day not in s:
                continue
            for m in METHODS:
                p = _predict(m, train, day)   # fixed origin: no information from the holdout leaks in
                err[m]["abs"] += abs(p - s[day]); err[m]["sum"] += p - s[day]; err[m]["act"] += s[day]; err[m]["n"] += 1
    evaluation = {}
    for m, e in err.items():
        evaluation[m] = {
            "wape_pct": round(100 * e["abs"] / e["act"], 2) if e["act"] else None,
            "mae_units": round(e["abs"] / e["n"], 3) if e["n"] else None,
            "bias_units": round(e["sum"] / e["n"], 3) if e["n"] else None,
            "points": e["n"]}
    scored = [m for m in METHODS if evaluation[m]["wape_pct"] is not None]
    chosen = min(scored, key=lambda m: evaluation[m]["wape_pct"]) if scored else "weekday_profile_4"
    evaluation["_protocol"] = (f"Fixed-origin holdout: trained on days before {cut}, scored on {cut}..{as_of - timedelta(days=1)}. "
                               f"WAPE = sum|forecast-actual| / sum(actual). Stock-out days un-censored before fitting ({censored} days).")

    run = ForecastRun(as_of=as_of, horizon_days=horizon, holdout_days=holdout, chosen_method=chosen,
                      evaluation=evaluation, series_count=len(series), censored_days=censored, created_by=actor_id)
    db.add(run)
    db.flush()
    rows = []
    for (site_id, product_id), s in series.items():
        for i in range(horizon):
            day = as_of + timedelta(days=i)
            rows.append({"run_id": run.id, "site_id": site_id, "product_id": product_id, "day": day,
                         "qty": Decimal(str(round(max(0.0, _predict(chosen, s, day)), 3)))})
    if rows:
        db.execute(Forecast.__table__.insert(), rows)
    return run


def latest_run(db):
    return db.execute(select(ForecastRun).order_by(ForecastRun.id.desc()).limit(1)).scalar_one_or_none()


def store_forecast(db, run_id, start, days):
    """-> {(site_id, product_id): Decimal total over [start, start+days)}"""
    out = defaultdict(lambda: ZERO)
    end = start + timedelta(days=days)
    for f in db.execute(select(Forecast).where(Forecast.run_id == run_id, Forecast.day >= start, Forecast.day < end)).scalars():
        out[(f.site_id, f.product_id)] += dec(f.qty)
    return out


def rollup_demand(db, day_from, day_to, stockout_today=True):
    """Roll completed sales up into demand_observations (idempotent upsert). For the most recent day a
    zero available balance is recorded as a stock-out so the forecast can un-censor it."""
    from sqlalchemy import text
    db.execute(text("""
        INSERT INTO demand_observations (site_id, product_id, day, units_sold, stockout, source)
        SELECT rp.site_id, rp.product_id, d::date, COALESCE(x.q, 0), false, 'sales_rollup'
        FROM replenishment_policies rp JOIN sites s ON s.id = rp.site_id AND s.kind = 'store'
        CROSS JOIN generate_series(CAST(:f AS date), CAST(:t AS date), interval '1 day') d
        LEFT JOIN (SELECT sa.site_id, sl.product_id, sa.at::date dd, SUM(sl.qty) q FROM sale_lines sl JOIN sales sa ON sa.id = sl.sale_id
                   WHERE sa.at::date BETWEEN :f AND :t GROUP BY 1, 2, 3) x ON x.site_id = rp.site_id AND x.product_id = rp.product_id AND x.dd = d::date
        ON CONFLICT ON CONSTRAINT uq_demand_observations_site_id DO UPDATE SET units_sold = EXCLUDED.units_sold"""), {"f": day_from, "t": day_to})
    if stockout_today:
        db.execute(text("""UPDATE demand_observations o SET stockout = true WHERE o.day = :t AND NOT EXISTS (
            SELECT 1 FROM stock_balances b WHERE b.site_id = o.site_id AND b.product_id = o.product_id AND b.bucket = 'available' AND b.qty > 0)"""), {"t": day_to})
