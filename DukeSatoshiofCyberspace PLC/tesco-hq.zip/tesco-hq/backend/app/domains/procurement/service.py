"""Procurement: recommendations -> requisition -> purchase order -> receipt -> invoice match."""
import math
from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal

from sqlalchemy import func, select, text

from ...adapters import mocks
from ...common import ZERO, bad, conflict, dec, emit, flag, get_setting, now, q2
from ..catalog.models import Product, TaxCategory
from ..distribution.models import WarehouseTask
from ..finance.service import post_journal
from ..inventory import service as inv
from ..inventory.models import Lot, StockBalance
from ..org.models import Site
from ..platform import approvals
from ..suppliers.models import CostHistory, Supplier, SupplierCategory, SupplierProduct
from . import forecasting
from .models import (DeliveryAppointment, Discrepancy, GoodsReceipt, GoodsReceiptLine, PurchaseOrder,
                     PurchaseOrderLine, Quotation, ReorderRecommendation, ReplenishmentPolicy, Requisition,
                     RequisitionLine, SupplierInvoice, SupplierInvoiceLine, SupplierReturn)

OPEN_PO = ("pending_approval", "approved", "part_received")


def _next(db, model, prefix):
    return f"{prefix}-{db.execute(select(func.coalesce(func.max(model.id), 0))).scalar() + 1:06d}"


def next_delivery_date(supplier, earliest: date) -> date:
    days = {int(x) for x in supplier.delivery_weekdays.split(",") if x != ""}
    d = earliest
    for _ in range(14):
        if d.weekday() in days:
            return d
        d += timedelta(days=1)
    return earliest


def on_order_units(db, site_id):
    rows = db.execute(text("""
        SELECT l.product_id, SUM((l.cases_ordered - l.cases_received - l.cases_damaged) * l.case_size) q,
               SUM((l.cases_ordered - l.cases_received - l.cases_damaged) * l.case_cost) v
        FROM purchase_order_lines l JOIN purchase_orders p ON p.id = l.po_id
        WHERE p.site_id = :s AND p.status IN ('pending_approval','approved','part_received')
        GROUP BY l.product_id"""), {"s": site_id}).all()
    return {r.product_id: max(ZERO, r.q) for r in rows}, sum((max(ZERO, r.v) for r in rows), ZERO)


def recommend(db, *, site_id, as_of: date, actor_id=None):
    """Reorder recommendations for a distribution centre. Each row keeps its working and the ordered
    list of constraints that changed the quantity, so a buyer can see *why* the number is what it is."""
    pol = get_setting(db, "procurement.policy")
    run = forecasting.latest_run(db)
    if not run:
        raise conflict("Run a demand forecast first", "no_forecast")
    review = int(pol["review_period_days"])
    db.execute(text("UPDATE reorder_recommendations SET status='superseded' WHERE site_id=:s AND status='open'"), {"s": site_id})

    stock = {}
    for pid, bucket, qty in db.execute(select(StockBalance.product_id, StockBalance.bucket, func.sum(StockBalance.qty))
                                       .where(StockBalance.site_id == site_id).group_by(StockBalance.product_id, StockBalance.bucket)):
        stock.setdefault(pid, {})[bucket] = qty
    on_order, committed = on_order_units(db, site_id)
    policies = {p.product_id: p for p in db.execute(select(ReplenishmentPolicy).where(ReplenishmentPolicy.site_id == site_id)).scalars()}
    suppliers = {s.id: s for s in db.execute(select(Supplier)).scalars()}
    approved_cats = {(c.supplier_id, c.category_id) for c in db.execute(select(SupplierCategory)).scalars()}
    sps = {}
    for sp in db.execute(select(SupplierProduct).order_by(SupplierProduct.is_primary.desc(), SupplierProduct.case_cost)).scalars():
        sps.setdefault(sp.product_id, []).append(sp)

    drafts = []
    for product in db.execute(select(Product).where(Product.status == "active").order_by(Product.sku)).scalars():
        pol_row = policies.get(product.id)
        if not pol_row:
            continue
        cons = []
        chosen = None
        for sp in sps.get(product.id, []):
            s = suppliers[sp.supplier_id]
            if s.status != "approved":
                cons.append({"constraint": "supplier_availability", "effect": f"{s.code} skipped: supplier status is '{s.status}'"})
            elif not sp.available:
                cons.append({"constraint": "supplier_availability", "effect": f"{s.code} skipped: product flagged unavailable by supplier"})
            elif (s.id, product.category_id) not in approved_cats:
                cons.append({"constraint": "supplier_availability", "effect": f"{s.code} skipped: not approved for this category"})
            else:
                chosen = (sp, s)
                if not sp.is_primary:
                    cons.append({"constraint": "supplier_availability", "effect": f"using secondary supplier {s.code}"})
                break
        lead = chosen[1].lead_time_days if chosen else 2
        horizon = lead + review
        fc = forecasting.store_forecast(db, run.id, as_of, horizon)
        demand = sum((v for (sid, pid), v in fc.items() if pid == product.id), ZERO)
        st = stock.get(product.id, {})
        avail, oo = st.get("available", ZERO), on_order.get(product.id, ZERO)
        position = avail + oo
        safety = dec(pol_row.safety_stock)
        need = demand + safety - position
        inputs = {"forecast_run_id": run.id, "method": run.chosen_method, "lead_time_days": lead, "review_days": review,
                  "demand_over_horizon": demand, "safety_stock": safety, "dc_available": avail,
                  "dc_reserved_for_stores": st.get("reserved", ZERO), "on_order": oo, "position": position,
                  "formula": "need = forecast demand over (lead time + review period) + safety stock - (DC available + on order)"}
        if need <= 0:
            continue
        cs = dec(product.case_size)
        cases = unconstrained = math.ceil(need / cs)
        cons.append({"constraint": "case_pack", "effect": f"{need.quantize(Decimal('0.001'))} units rounded up to {cases} case(s) of {cs}"})
        expected = None
        if not chosen:
            cases = 0
            cons.append({"constraint": "supplier_availability", "effect": "no approved, available supplier - cannot order"})
        else:
            sp, s = chosen
            if cases < sp.moq_cases:
                cons.append({"constraint": "minimum_order_quantity", "effect": f"raised from {cases} to supplier MOQ {sp.moq_cases} cases"})
                cases = sp.moq_cases
            room = dec(pol_row.max_capacity) - (avail + st.get("reserved", ZERO) + oo)
            cap_cases = max(0, math.floor(room / cs))
            if cases > cap_cases:
                cons.append({"constraint": "storage_capacity", "effect": f"capped from {cases} to {cap_cases} cases: {room} units of space left of {pol_row.max_capacity}"})
                cases = cap_cases
            if product.shelf_life_days and horizon:
                daily = demand / horizon
                sellable = max(ZERO, daily * max(1, product.shelf_life_days - 2) - avail)  # 2 days lost in the chain
                life_cases = max(0, math.floor(sellable / cs))
                if cases > life_cases and daily > 0:
                    cons.append({"constraint": "expiry_risk", "effect": f"capped from {cases} to {life_cases} cases: more would outlast the {product.shelf_life_days}-day shelf life at {daily.quantize(Decimal('0.1'))}/day"})
                    cases = life_cases
            expected = next_delivery_date(s, as_of + timedelta(days=lead))
            if expected != as_of + timedelta(days=lead):
                cons.append({"constraint": "delivery_calendar", "effect": f"earliest lead-time date {as_of + timedelta(days=lead)} is not a delivery day; next is {expected}"})
        cover = (position / (demand / horizon)) if demand > 0 else Decimal(99)
        drafts.append((cover, product, chosen, need, unconstrained, cases, expected, inputs, cons))

    # working-capital limit: most urgent (lowest days of cover) first
    limit = dec(pol["working_capital_limit"])
    spend = committed
    out = []
    for cover, product, chosen, need, unconstrained, cases, expected, inputs, cons in sorted(drafts, key=lambda d: d[0]):
        cost = chosen[0].case_cost if chosen else None
        if chosen and cases > 0:
            value = cases * cost
            if spend + value > limit:
                fit = max(0, math.floor((limit - spend) / cost))
                cons.append({"constraint": "working_capital", "effect": f"reduced from {cases} to {fit} cases: open commitments {q2(spend)} + this order would exceed the {limit} limit"})
                cases = fit
            spend += cases * cost
        inputs["days_of_cover"] = cover.quantize(Decimal("0.1"))
        from ...common import plain
        rec = ReorderRecommendation(run_id=inputs["forecast_run_id"], site_id=site_id, product_id=product.id,
                                    supplier_id=chosen[1].id if chosen else None, need_units=need,
                                    unconstrained_cases=unconstrained, recommended_cases=cases, final_cases=cases,
                                    case_cost=cost, expected_delivery=expected, inputs=plain(inputs), constraints=cons)
        db.add(rec)
        out.append(rec)
    db.flush()
    return out


def decide_recommendation(db, rec, p, *, action, cases=None, reason=None):
    if rec.status != "open":
        raise conflict(f"Recommendation is already {rec.status}")
    if action == "reject":
        if not reason:
            raise bad("A reason is required")
        rec.status, rec.override_reason, rec.decided_by = "rejected", reason, p.user.id
        return None
    if action == "override":
        if cases is None or cases < 0 or not reason:
            raise bad("Override needs a quantity and a recorded reason")
        rec.final_cases, rec.override_reason, rec.status = cases, reason, "overridden"
    else:
        rec.status = "accepted"
    rec.decided_by = p.user.id
    if rec.final_cases <= 0 or not rec.supplier_id:
        raise bad("Nothing to order for this recommendation (0 cases or no supplier)")
    req = db.execute(select(Requisition).where(Requisition.site_id == rec.site_id, Requisition.supplier_id == rec.supplier_id,
                                               Requisition.status == "open")).scalar_one_or_none()
    if not req:
        req = Requisition(number=_next(db, Requisition, "REQ"), site_id=rec.site_id, supplier_id=rec.supplier_id,
                          requested_by=p.user.id)
        db.add(req)
        db.flush()
    db.add(RequisitionLine(requisition_id=req.id, product_id=rec.product_id, cases=rec.final_cases, recommendation_id=rec.id))
    rec.requisition_id = req.id
    db.flush()
    return req


def create_po(db, p, *, supplier_id, site_id, lines, expected_date=None, requisition=None):
    """lines: [{product_id, cases}]. Costs come from the supplier agreement, never from the caller."""
    supplier = db.get(Supplier, supplier_id)
    if not supplier or supplier.status != "approved":
        raise bad("Supplier is not approved for ordering")
    po = PurchaseOrder(number=_next(db, PurchaseOrder, "PO"), supplier_id=supplier_id, site_id=site_id,
                       status="pending_approval", created_by=p.user.id,
                       expected_date=expected_date or next_delivery_date(supplier, date.today() + timedelta(days=supplier.lead_time_days)))
    db.add(po)
    db.flush()
    total = ZERO
    for ln in lines:
        sp = db.execute(select(SupplierProduct).where(SupplierProduct.supplier_id == supplier_id,
                                                      SupplierProduct.product_id == ln["product_id"])).scalar_one_or_none()
        if not sp:
            raise bad(f"Supplier does not list product {ln['product_id']}")
        if ln["cases"] < sp.moq_cases:
            raise bad(f"Below supplier minimum order quantity ({sp.moq_cases} cases) for product {ln['product_id']}")
        prod = db.get(Product, ln["product_id"])
        db.add(PurchaseOrderLine(po_id=po.id, product_id=prod.id, description=prod.name, case_size=prod.case_size,
                                 cases_ordered=ln["cases"], case_cost=sp.case_cost))
        total += ln["cases"] * sp.case_cost
    po.net_total = q2(total)
    if requisition:
        requisition.status, requisition.po_id = "converted", po.id
        db.execute(text("UPDATE reorder_recommendations SET status='ordered' WHERE requisition_id=:r"), {"r": requisition.id})
    approvals.request(db, p, "purchase_order", f"{po.number} to {supplier.name}: {po.net_total} net",
                      "procurement.approve", entity_type="purchase_order", entity_id=po.id, site_id=site_id, amount=po.net_total)
    db.flush()
    return po


@approvals.handler("purchase_order")
def _po_decided(db, a, p, approve):
    po = db.get(PurchaseOrder, a.entity_id)
    if not approve:
        po.status = "rejected"
        return
    po.status, po.approved_by, po.approved_at = "approved", p.user.id, now()
    start = datetime.combine(po.expected_date, time(6, 0), tzinfo=timezone.utc)
    db.add(DeliveryAppointment(po_id=po.id, site_id=po.site_id, slot_start=start, slot_end=start + timedelta(hours=2), dock="DOCK-1"))
    emit(db, "purchase_order.approved", po.number, {"po_id": po.id, "supplier_id": po.supplier_id, "net": po.net_total})


def receive(db, p, po, *, delivery_note_ref, lines, arrived_at=None, close_short=False):
    """Book a (possibly partial) delivery. lines: [{po_line_id, cases_received, cases_damaged, lot_code, expiry_date}]"""
    po = db.execute(select(PurchaseOrder).where(PurchaseOrder.id == po.id).with_for_update()).scalar_one()
    if po.status not in ("approved", "part_received"):
        raise conflict(f"PO {po.number} is {po.status}; it cannot be received", "po_not_receivable")
    if db.execute(select(GoodsReceipt.id).where(GoodsReceipt.po_id == po.id, GoodsReceipt.delivery_note_ref == delivery_note_ref)).first():
        raise conflict(f"Delivery note {delivery_note_ref} has already been received against {po.number}", "duplicate_receipt")
    arrived_at = arrived_at or now()
    gr = GoodsReceipt(po_id=po.id, site_id=po.site_id, delivery_note_ref=delivery_note_ref, received_by=p.user.id, received_at=arrived_at)
    db.add(gr)
    db.flush()
    value = ZERO
    for ln in lines:
        pl = db.get(PurchaseOrderLine, ln["po_line_id"])
        if not pl or pl.po_id != po.id:
            raise bad("Receipt line does not belong to this PO")
        good, dmg = int(ln.get("cases_received", 0)), int(ln.get("cases_damaged", 0))
        if good < 0 or dmg < 0 or good + dmg == 0:
            continue
        outstanding = pl.cases_ordered - pl.cases_received - pl.cases_damaged
        if good + dmg > outstanding:
            raise bad(f"Over-delivery on '{pl.description}': {good + dmg} cases presented, {outstanding} outstanding. "
                      f"Refuse the excess or amend the PO.", "over_delivery")
        prod = db.get(Product, pl.product_id)
        code = ln.get("lot_code") or f"{po.number}-{pl.id}"
        expiry = ln.get("expiry_date") or (arrived_at.date() + timedelta(days=prod.shelf_life_days) if prod.shelf_life_days else None)
        lot = db.execute(select(Lot).where(Lot.product_id == prod.id, Lot.lot_code == code)).scalar_one_or_none()
        if not lot:
            lot = Lot(product_id=prod.id, lot_code=code, expiry_date=expiry, supplier_id=po.supplier_id, receipt_id=gr.id,
                      unit_cost=(pl.case_cost / pl.case_size).quantize(Decimal("0.0001")))
            db.add(lot)
            db.flush()
        db.add(GoodsReceiptLine(receipt_id=gr.id, po_line_id=pl.id, lot_id=lot.id, cases_received=good, cases_damaged=dmg))
        kw = dict(site_id=po.site_id, product_id=prod.id, lot_id=lot.id, ref_type="goods_receipt", ref_id=gr.id, actor_id=p.user.id)
        if good:
            inv.post(db, bucket="available", qty=good * pl.case_size, mtype="goods_receipt", **kw)
            value += good * pl.case_size * lot.unit_cost
            db.add(WarehouseTask(site_id=po.site_id, kind="putaway", ref_type="goods_receipt", ref_id=gr.id, product_id=prod.id,
                                 lot_id=lot.id, qty=good * pl.case_size, temp_class=prod.storage_class))
        if dmg:
            inv.post(db, bucket="damaged", qty=dmg * pl.case_size, mtype="goods_receipt_damaged", reason="Damaged on arrival", **kw)
            db.add(Discrepancy(receipt_id=gr.id, po_line_id=pl.id, kind="damaged", cases=dmg, note="Damaged on arrival; not accepted into saleable stock"))
            db.add(SupplierReturn(supplier_id=po.supplier_id, site_id=po.site_id, product_id=prod.id, lot_id=lot.id,
                                  qty=dmg * pl.case_size, reason="Damaged on arrival"))
            flag(db, "receipt_discrepancy", f"{po.number}: {dmg} case(s) of {prod.name} damaged on arrival", severity="medium",
                 entity_type="goods_receipt", entity_id=gr.id, site_id=po.site_id)
        pl.cases_received += good
        pl.cases_damaged += dmg
    db.flush()
    pls = db.execute(select(PurchaseOrderLine).where(PurchaseOrderLine.po_id == po.id)).scalars().all()
    outstanding = sum(l.cases_ordered - l.cases_received - l.cases_damaged for l in pls)
    if outstanding == 0:
        po.status = "received"
    elif close_short:
        po.status = "received"
        for l in pls:
            short = l.cases_ordered - l.cases_received - l.cases_damaged
            if short:
                db.add(Discrepancy(receipt_id=gr.id, po_line_id=l.id, kind="short", cases=short, note="Closed short"))
        flag(db, "receipt_discrepancy", f"{po.number} closed {outstanding} case(s) short", entity_type="goods_receipt",
             entity_id=gr.id, site_id=po.site_id)
    else:
        po.status = "part_received"
        flag(db, "receipt_discrepancy", f"{po.number} part-received: {outstanding} case(s) still outstanding",
             severity="low", entity_type="purchase_order", entity_id=po.id, site_id=po.site_id, dedupe=f"po-part:{po.id}")
    appt = db.execute(select(DeliveryAppointment).where(DeliveryAppointment.po_id == po.id).order_by(DeliveryAppointment.id.desc())).scalars().first()
    if appt and appt.actual_arrival is None:
        appt.actual_arrival = arrived_at
        if arrived_at > appt.slot_end:
            appt.status = "late"
            mins = int((arrived_at - appt.slot_end).total_seconds() // 60)
            flag(db, "late_delivery", f"{po.number} arrived {mins} min after its booked slot", severity="medium" if mins < 240 else "high",
                 entity_type="delivery_appointment", entity_id=appt.id, site_id=po.site_id)
        else:
            appt.status = "completed"
    post_journal(db, entry_date=arrived_at.date(), source_type="goods_receipt", source_id=gr.id, posted_by=p.user.id,
                 description=f"Goods receipt {delivery_note_ref} against {po.number}",
                 lines=[("1200", value, 0, po.site_id, "stock received"), ("2010", 0, value, po.site_id, "GRNI accrual")])
    emit(db, "goods_receipt.posted", gr.id, {"po": po.number, "receipt_id": gr.id})
    db.flush()
    return gr


def register_invoice(db, p, *, supplier_id, po_id, invoice_no, invoice_date, lines, net, tax):
    sup = db.get(Supplier, supplier_id)
    if db.execute(select(SupplierInvoice.id).where(SupplierInvoice.supplier_id == supplier_id, SupplierInvoice.invoice_no == invoice_no)).first():
        raise conflict(f"Invoice {invoice_no} from this supplier is already registered", "duplicate_invoice")
    inv_ = SupplierInvoice(supplier_id=supplier_id, po_id=po_id, invoice_no=invoice_no, invoice_date=invoice_date,
                           due_date=invoice_date + timedelta(days=sup.payment_terms_days), net=q2(net), tax=q2(tax),
                           gross=q2(net) + q2(tax))
    db.add(inv_)
    db.flush()
    rates = {t.id: t.rate for t in db.execute(select(TaxCategory)).scalars()}
    for ln in lines:
        pl = db.get(PurchaseOrderLine, ln["po_line_id"])
        rate = rates[db.get(Product, pl.product_id).tax_category_id] if pl else ZERO
        db.add(SupplierInvoiceLine(invoice_id=inv_.id, po_line_id=ln["po_line_id"], cases=ln["cases"],
                                   case_cost=dec(ln["case_cost"]), tax_rate=rate))
    db.flush()
    return inv_


def match_invoice(db, p, invoice):
    """Three-way match: invoice vs purchase order (price) vs goods receipts (quantity).
    Posts to the ledger only on a clean match; otherwise raises an exception case and posts nothing."""
    if invoice.status not in ("received", "exception"):
        raise conflict(f"Invoice is already {invoice.status}")
    tol = dec(get_setting(db, "procurement.policy")["invoice_price_tolerance_pct"])
    lines = db.execute(select(SupplierInvoiceLine).where(SupplierInvoiceLine.invoice_id == invoice.id)).scalars().all()
    checks, problems = [], []
    accrual = ppv = net = tax = ZERO
    site_id = db.get(PurchaseOrder, invoice.po_id).site_id if invoice.po_id else None
    for il in lines:
        pl = db.get(PurchaseOrderLine, il.po_line_id) if il.po_line_id else None
        c = {"invoice_line_id": il.id, "po_line_id": il.po_line_id, "invoiced_cases": il.cases, "invoice_case_cost": il.case_cost}
        if not pl or pl.po_id != invoice.po_id:
            c["result"] = "no matching PO line"
            problems.append(f"Line {il.id}: no matching PO line")
            checks.append(c)
            continue
        uninvoiced = pl.cases_received - pl.cases_invoiced
        diff_pct = abs(il.case_cost - pl.case_cost) / pl.case_cost * 100
        c.update(description=pl.description, po_cases=pl.cases_ordered, po_case_cost=pl.case_cost, received_cases=pl.cases_received,
                 received_not_invoiced=uninvoiced, price_variance_pct=diff_pct.quantize(Decimal("0.01")),
                 quantity_ok=il.cases <= uninvoiced, price_ok=diff_pct <= tol)
        if il.cases > uninvoiced:
            problems.append(f"{pl.description}: invoiced {il.cases} cases but only {uninvoiced} received and not yet invoiced")
        if diff_pct > tol:
            problems.append(f"{pl.description}: invoice price {il.case_cost} vs PO {pl.case_cost} ({diff_pct.quantize(Decimal('0.01'))}% > {tol}% tolerance)")
        c["result"] = "ok" if c["quantity_ok"] and c["price_ok"] else "mismatch"
        checks.append(c)
        accrual += il.cases * pl.case_cost
        ppv += il.cases * (il.case_cost - pl.case_cost)
        line_net = q2(il.cases * il.case_cost)
        net += line_net
        tax += q2(line_net * il.tax_rate)
    if abs(net - invoice.net) > Decimal("0.01"):
        problems.append(f"Invoice net {invoice.net} does not equal the sum of its lines {net}")
    if abs(tax - invoice.tax) > Decimal("0.02"):
        problems.append(f"Invoice VAT {invoice.tax} does not equal VAT computed from lines {tax}")
    from ...common import plain
    invoice.match_result = plain({"tolerance_pct": tol, "checks": checks, "problems": problems})
    invoice.matched_by = p.user.id
    if problems:
        invoice.status = "exception"
        flag(db, "invoice_mismatch", f"Invoice {invoice.invoice_no} failed three-way match: {problems[0]}", severity="high",
             entity_type="supplier_invoice", entity_id=invoice.id, site_id=site_id, dedupe=f"inv:{invoice.id}",
             detail="\n".join(problems))
        db.flush()
        return invoice
    for il in lines:
        db.get(PurchaseOrderLine, il.po_line_id).cases_invoiced += il.cases
    invoice.status = "matched"
    accrual, ppv = q2(accrual), invoice.net - q2(accrual)
    post_journal(db, entry_date=invoice.invoice_date, source_type="supplier_invoice", source_id=invoice.id, posted_by=p.user.id,
                 description=f"Supplier invoice {invoice.invoice_no} matched", lines=[
                     ("2010", accrual, 0, site_id, "GRNI accrual released"), ("5200", ppv, 0, site_id, "price variance within tolerance"),
                     ("1300", invoice.tax, 0, site_id, "input VAT"), ("2000", 0, invoice.gross, site_id, "trade payable")])
    db.execute(text("UPDATE exceptions SET status='resolved', resolution='Invoice re-matched cleanly', resolved_at=now() "
                    "WHERE dedupe_key=:k AND status='open'"), {"k": f"inv:{invoice.id}"})
    db.flush()
    return invoice


def accept_quotation(db, p, quote):
    if quote.status != "received":
        raise conflict(f"Quotation already {quote.status}")
    sp = db.execute(select(SupplierProduct).where(SupplierProduct.supplier_id == quote.supplier_id,
                                                  SupplierProduct.product_id == quote.product_id)).scalar_one_or_none()
    if not sp:
        sp = SupplierProduct(supplier_id=quote.supplier_id, product_id=quote.product_id, case_cost=quote.case_cost,
                             moq_cases=quote.moq_cases, is_primary=False)
        db.add(sp)
        db.flush()
    sp.case_cost, sp.moq_cases = quote.case_cost, quote.moq_cases
    db.add(CostHistory(supplier_product_id=sp.id, case_cost=quote.case_cost, effective_from=date.today(), source=f"quotation #{quote.id}"))
    quote.status, quote.decided_by = "accepted", p.user.id
    db.flush()
    return sp
