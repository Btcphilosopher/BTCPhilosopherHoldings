from datetime import date, datetime, timedelta
from decimal import Decimal

from fastapi import APIRouter, Depends, Header
from pydantic import BaseModel
from sqlalchemy import select

from ...cache import wake_worker
from ...common import audit, bad, conflict, get_or_404, idem_begin, idem_finish, mappings, row, rows
from ...db import get_db
from ...security import require
from ..platform.models import Job
from . import forecasting, service
from .models import (ForecastRun, PurchaseOrder, PurchaseOrderLine, Quotation, ReorderRecommendation, Requisition,
                     RequisitionLine, SupplierReturn)

router = APIRouter(prefix="/procurement", tags=["Procurement & replenishment"])
SC = "(:all_sites OR {c} = ANY(CAST(:sites AS int[])))"


class RunForecast(BaseModel):
    horizon_days: int = 14
    holdout_days: int = 14
    background: bool = False


@router.post("/forecasts/run")
def run_forecast(body: RunForecast, p=Depends(require("procurement.write")), db=Depends(get_db)):
    if body.background:
        job = Job(kind="forecast", payload=body.model_dump(), created_by=p.user.id)
        db.add(job)
        db.commit()
        wake_worker()
        return {"job": row(job)}
    forecasting.rollup_demand(db, date.today() - timedelta(days=3), date.today() - timedelta(days=1))
    run = forecasting.run_forecast(db, as_of=date.today(), horizon=body.horizon_days, holdout=body.holdout_days, actor_id=p.user.id)
    audit(db, p, "forecast.run", "forecast_run", run.id)
    db.commit()
    return row(run)


@router.get("/forecasts/runs")
def forecast_runs(p=Depends(require("procurement.read")), db=Depends(get_db)):
    return rows(db.execute(select(ForecastRun).order_by(ForecastRun.id.desc()).limit(20)).scalars())


@router.get("/forecasts/series")
def forecast_series(product_id: int, site_id: int | None = None, p=Depends(require("procurement.read")), db=Depends(get_db)):
    """History (sold units, stock-out flags) and the latest forecast for one product (one store or all)."""
    run = forecasting.latest_run(db)
    hist = mappings(db, """SELECT day, SUM(units_sold) units_sold, BOOL_OR(stockout) stockout FROM demand_observations
        WHERE product_id=:p AND (:s IS NULL OR site_id=:s) AND day >= current_date - 42 GROUP BY day ORDER BY day""", p=product_id, s=site_id)
    fc = mappings(db, """SELECT day, SUM(qty) qty FROM forecasts WHERE run_id=:r AND product_id=:p AND (:s IS NULL OR site_id=:s)
        GROUP BY day ORDER BY day""", r=run.id if run else 0, p=product_id, s=site_id)
    return {"run": row(run), "history": hist, "forecast": fc}


class RunRecs(BaseModel):
    site_id: int


@router.post("/recommendations/run")
def run_recs(body: RunRecs, p=Depends(require("procurement.write")), db=Depends(get_db)):
    p.check("procurement.write", body.site_id)
    recs = service.recommend(db, site_id=body.site_id, as_of=date.today(), actor_id=p.user.id)
    db.commit()
    return {"created": len(recs)}


@router.get("/recommendations")
def recs(status: str | None = "open", p=Depends(require("procurement.read")), db=Depends(get_db)):
    return mappings(db, f"""SELECT r.*, pr.sku, pr.name product, pr.case_size, s.name supplier, st.name site,
           ROUND(r.final_cases * COALESCE(r.case_cost,0), 2) order_value
        FROM reorder_recommendations r JOIN products pr ON pr.id=r.product_id LEFT JOIN suppliers s ON s.id=r.supplier_id
        JOIN sites st ON st.id=r.site_id WHERE (:st IS NULL OR r.status=:st) AND {SC.format(c='r.site_id')} ORDER BY r.id DESC LIMIT 400""",
                    st=status, **p.sql_sites("procurement.read"))


class RecDecision(BaseModel):
    action: str  # accept|override|reject
    cases: int | None = None
    reason: str | None = None


@router.post("/recommendations/{rec_id}/decide")
def decide_rec(rec_id: int, body: RecDecision, p=Depends(require("procurement.write")), db=Depends(get_db)):
    rec = get_or_404(db, ReorderRecommendation, rec_id)
    p.check("procurement.write", rec.site_id)
    req = service.decide_recommendation(db, rec, p, action=body.action, cases=body.cases, reason=body.reason)
    audit(db, p, f"recommendation.{body.action}", "reorder_recommendation", rec.id,
          {"recommended": rec.recommended_cases, "final": rec.final_cases, "reason": body.reason})
    db.commit()
    return {"recommendation": row(rec), "requisition": row(req)}


@router.get("/requisitions")
def requisitions(p=Depends(require("procurement.read")), db=Depends(get_db)):
    return mappings(db, f"""SELECT r.*, s.name supplier, st.name site,
        (SELECT COUNT(*) FROM requisition_lines l WHERE l.requisition_id=r.id) lines,
        (SELECT string_agg(p.name || ' x' || l.cases, '; ') FROM requisition_lines l JOIN products p ON p.id=l.product_id WHERE l.requisition_id=r.id) contents
        FROM requisitions r JOIN suppliers s ON s.id=r.supplier_id JOIN sites st ON st.id=r.site_id
        WHERE {SC.format(c='r.site_id')} ORDER BY r.id DESC""", **p.sql_sites("procurement.read"))


class ConvertIn(BaseModel):
    expected_date: date | None = None


@router.post("/requisitions/{req_id}/convert")
def convert(req_id: int, body: ConvertIn | None = None, p=Depends(require("procurement.write")), db=Depends(get_db)):
    req = get_or_404(db, Requisition, req_id)
    p.check("procurement.write", req.site_id)
    if req.status != "open":
        raise conflict(f"Requisition already {req.status}")
    lines = [{"product_id": l.product_id, "cases": l.cases} for l in db.execute(select(RequisitionLine).where(RequisitionLine.requisition_id == req.id)).scalars()]
    po = service.create_po(db, p, supplier_id=req.supplier_id, site_id=req.site_id, lines=lines, requisition=req,
                           expected_date=body.expected_date if body else None)
    audit(db, p, "purchase_order.created", "purchase_order", po.id, {"from_requisition": req.number})
    db.commit()
    return row(po)


class PoLineIn(BaseModel):
    product_id: int
    cases: int


class PoIn(BaseModel):
    supplier_id: int
    site_id: int
    expected_date: date | None = None
    lines: list[PoLineIn]


@router.post("/purchase-orders")
def create_po(body: PoIn, p=Depends(require("procurement.write")), db=Depends(get_db)):
    p.check("procurement.write", body.site_id)
    po = service.create_po(db, p, supplier_id=body.supplier_id, site_id=body.site_id, expected_date=body.expected_date,
                           lines=[l.model_dump() for l in body.lines])
    audit(db, p, "purchase_order.created", "purchase_order", po.id)
    db.commit()
    return row(po)


@router.get("/purchase-orders")
def pos(status: str | None = None, p=Depends(require("procurement.read")), db=Depends(get_db)):
    return mappings(db, f"""SELECT po.*, s.name supplier, st.name site, u.name created_by_name, a.name approved_by_name,
          (SELECT SUM(cases_ordered) FROM purchase_order_lines l WHERE l.po_id=po.id) cases_ordered,
          (SELECT SUM(cases_received) FROM purchase_order_lines l WHERE l.po_id=po.id) cases_received,
          (SELECT SUM(cases_damaged) FROM purchase_order_lines l WHERE l.po_id=po.id) cases_damaged
        FROM purchase_orders po JOIN suppliers s ON s.id=po.supplier_id JOIN sites st ON st.id=po.site_id
        LEFT JOIN users u ON u.id=po.created_by LEFT JOIN users a ON a.id=po.approved_by
        WHERE (:st IS NULL OR po.status=:st) AND {SC.format(c='po.site_id')} ORDER BY po.id DESC""", st=status, **p.sql_sites("procurement.read"))


@router.get("/purchase-orders/{po_id}")
def po_detail(po_id: int, p=Depends(require("procurement.read")), db=Depends(get_db)):
    po = get_or_404(db, PurchaseOrder, po_id)
    p.check_read("procurement.read", po.site_id)
    return row(po,
               lines=mappings(db, "SELECT l.*, p.sku FROM purchase_order_lines l JOIN products p ON p.id=l.product_id WHERE po_id=:i ORDER BY l.id", i=po_id),
               receipts=mappings(db, """SELECT g.*, (SELECT json_agg(json_build_object('po_line_id', rl.po_line_id, 'lot_id', rl.lot_id,
                   'cases_received', rl.cases_received, 'cases_damaged', rl.cases_damaged)) FROM goods_receipt_lines rl WHERE rl.receipt_id=g.id) lines
                   FROM goods_receipts g WHERE po_id=:i ORDER BY g.id""", i=po_id),
               appointments=mappings(db, "SELECT * FROM delivery_appointments WHERE po_id=:i", i=po_id),
               discrepancies=mappings(db, "SELECT d.* FROM receipt_discrepancies d JOIN goods_receipts g ON g.id=d.receipt_id WHERE g.po_id=:i", i=po_id),
               invoices=mappings(db, "SELECT * FROM supplier_invoices WHERE po_id=:i", i=po_id),
               approval=mappings(db, "SELECT * FROM approvals WHERE kind='purchase_order' AND entity_id=:i", i=po_id))


class ReceiptLineIn(BaseModel):
    po_line_id: int
    cases_received: int = 0
    cases_damaged: int = 0
    lot_code: str | None = None
    expiry_date: date | None = None


class ReceiptIn(BaseModel):
    delivery_note_ref: str
    arrived_at: datetime | None = None
    close_short: bool = False
    lines: list[ReceiptLineIn]


@router.post("/purchase-orders/{po_id}/receipts")
def receive(po_id: int, body: ReceiptIn, idempotency_key: str | None = Header(default=None), p=Depends(require("procurement.write")),
            db=Depends(get_db)):
    """Book a delivery. Safe to retry with the same Idempotency-Key; a delivery note can only be received once."""
    po = get_or_404(db, PurchaseOrder, po_id)
    p.check("procurement.write", po.site_id)
    payload = body.model_dump(mode="json")
    if (replay := idem_begin(db, f"receipt:{po_id}", idempotency_key, payload)) is not None:
        db.commit()
        return replay
    gr = service.receive(db, p, po, delivery_note_ref=body.delivery_note_ref, arrived_at=body.arrived_at,
                         close_short=body.close_short, lines=[l.model_dump() for l in body.lines])
    audit(db, p, "goods_receipt.posted", "goods_receipt", gr.id, {"po": po.number, "delivery_note": body.delivery_note_ref})
    out = idem_finish(db, f"receipt:{po_id}", idempotency_key, {"receipt": row(gr), "po_status": po.status})
    db.commit()
    return out


@router.get("/appointments")
def appointments(p=Depends(require("procurement.read")), db=Depends(get_db)):
    return mappings(db, f"""SELECT a.*, po.number po_number, s.name supplier, st.name site FROM delivery_appointments a
        JOIN purchase_orders po ON po.id=a.po_id JOIN suppliers s ON s.id=po.supplier_id JOIN sites st ON st.id=a.site_id
        WHERE {SC.format(c='a.site_id')} ORDER BY a.slot_start DESC LIMIT 200""", **p.sql_sites("procurement.read"))


@router.get("/discrepancies")
def discrepancies(p=Depends(require("procurement.read")), db=Depends(get_db)):
    return mappings(db, f"""SELECT d.*, po.number po_number, l.description, s.name supplier, g.delivery_note_ref FROM receipt_discrepancies d
        JOIN goods_receipts g ON g.id=d.receipt_id JOIN purchase_orders po ON po.id=g.po_id JOIN purchase_order_lines l ON l.id=d.po_line_id
        JOIN suppliers s ON s.id=po.supplier_id WHERE {SC.format(c='g.site_id')} ORDER BY d.id DESC""", **p.sql_sites("procurement.read"))


@router.get("/supplier-returns")
def supplier_returns(p=Depends(require("procurement.read")), db=Depends(get_db)):
    return mappings(db, f"""SELECT r.*, s.name supplier, p.name product, lo.lot_code FROM supplier_returns r JOIN suppliers s ON s.id=r.supplier_id
        JOIN products p ON p.id=r.product_id JOIN lots lo ON lo.id=r.lot_id WHERE {SC.format(c='r.site_id')} ORDER BY r.id DESC""",
                    **p.sql_sites("procurement.read"))


@router.post("/supplier-returns/{ret_id}/collect")
def collect_return(ret_id: int, p=Depends(require("procurement.write")), db=Depends(get_db)):
    """Supplier collects damaged goods: they leave the 'damaged' bucket."""
    from ..inventory import service as inv
    r = get_or_404(db, SupplierReturn, ret_id)
    p.check("procurement.write", r.site_id)
    if r.status != "open":
        raise conflict(f"Return already {r.status}")
    inv.post(db, site_id=r.site_id, product_id=r.product_id, lot_id=r.lot_id, bucket="damaged", qty=-r.qty, mtype="supplier_return",
             ref_type="supplier_return", ref_id=r.id, actor_id=p.user.id, reason=r.reason)
    r.status = "collected"
    audit(db, p, "supplier_return.collected", "supplier_return", r.id)
    db.commit()
    return row(r)


class QuoteIn(BaseModel):
    supplier_id: int
    product_id: int
    case_cost: Decimal
    moq_cases: int = 1
    valid_until: date | None = None


@router.get("/quotations")
def quotations(p=Depends(require("procurement.read")), db=Depends(get_db)):
    return mappings(db, """SELECT q.*, s.name supplier, p.sku, p.name product,
        (SELECT sp.case_cost FROM supplier_products sp WHERE sp.product_id=q.product_id AND sp.is_primary LIMIT 1) current_primary_cost
        FROM quotations q JOIN suppliers s ON s.id=q.supplier_id JOIN products p ON p.id=q.product_id ORDER BY q.id DESC""")


@router.post("/quotations")
def add_quote(body: QuoteIn, p=Depends(require("procurement.write")), db=Depends(get_db)):
    p.check("procurement.write")
    q = Quotation(**body.model_dump())
    db.add(q)
    db.commit()
    return row(q)


@router.post("/quotations/{quote_id}/accept")
def accept_quote(quote_id: int, p=Depends(require("procurement.write")), db=Depends(get_db)):
    p.check("procurement.write")
    q = get_or_404(db, Quotation, quote_id)
    sp = service.accept_quotation(db, p, q)
    audit(db, p, "quotation.accepted", "quotation", q.id, {"case_cost": q.case_cost})
    db.commit()
    return {"quotation": row(q), "supplier_product": row(sp)}
