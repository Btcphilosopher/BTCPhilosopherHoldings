from sqlalchemy import JSON, Boolean, Column, Date, DateTime, Integer, Numeric, String, Text, UniqueConstraint

from ...db import Base, Cost, Money, Qty, fk, pk, ts


class DemandObservation(Base):
    """Daily units sold per store/product, with a stock-out flag so sales are not mistaken for demand."""
    __tablename__ = "demand_observations"
    id = pk()
    site_id = fk("sites.id", nullable=False)
    product_id = fk("products.id", nullable=False)
    day = Column(Date, nullable=False, index=True)
    units_sold = Column(Qty, nullable=False, default=0)
    stockout = Column(Boolean, nullable=False, default=False)
    source = Column(String(30), nullable=False, default="sales_rollup")  # sales_rollup|legacy_import
    __table_args__ = (UniqueConstraint("site_id", "product_id", "day"),)


class ForecastRun(Base):
    __tablename__ = "forecast_runs"
    id = pk()
    created_at = ts()
    created_by = Column(Integer)
    as_of = Column(Date, nullable=False)
    horizon_days = Column(Integer, nullable=False)
    holdout_days = Column(Integer, nullable=False)
    chosen_method = Column(String(40), nullable=False)
    evaluation = Column(JSON, nullable=False)  # per-method WAPE / MAE / bias on the time-ordered holdout
    series_count = Column(Integer, nullable=False, default=0)
    censored_days = Column(Integer, nullable=False, default=0)


class Forecast(Base):
    __tablename__ = "forecasts"
    id = pk()
    run_id = fk("forecast_runs.id", nullable=False)
    site_id = fk("sites.id", nullable=False)
    product_id = fk("products.id", nullable=False)
    day = Column(Date, nullable=False)
    qty = Column(Qty, nullable=False)
    __table_args__ = (UniqueConstraint("run_id", "site_id", "product_id", "day"),)


class ReplenishmentPolicy(Base):
    __tablename__ = "replenishment_policies"
    id = pk()
    site_id = fk("sites.id", nullable=False)
    product_id = fk("products.id", nullable=False)
    safety_stock = Column(Qty, nullable=False, default=0)
    max_capacity = Column(Qty, nullable=False)  # storage capacity for this product at this site, base units
    __table_args__ = (UniqueConstraint("site_id", "product_id"),)


class ReorderRecommendation(Base):
    __tablename__ = "reorder_recommendations"
    id = pk()
    run_id = fk("forecast_runs.id")
    site_id = fk("sites.id", nullable=False)
    product_id = fk("products.id", nullable=False)
    supplier_id = fk("suppliers.id")
    created_at = ts()
    need_units = Column(Qty, nullable=False)
    unconstrained_cases = Column(Integer, nullable=False)
    recommended_cases = Column(Integer, nullable=False)
    final_cases = Column(Integer, nullable=False)
    case_cost = Column(Cost)
    expected_delivery = Column(Date)
    inputs = Column(JSON)       # demand, position, safety stock - the working behind the number
    constraints = Column(JSON)  # every constraint that changed the quantity, in order
    status = Column(String(20), nullable=False, default="open")  # open|accepted|overridden|rejected|ordered
    override_reason = Column(Text)
    decided_by = Column(Integer)
    requisition_id = Column(Integer)


class Requisition(Base):
    __tablename__ = "requisitions"
    id = pk()
    number = Column(String(30), unique=True, nullable=False)
    site_id = fk("sites.id", nullable=False)
    supplier_id = fk("suppliers.id", nullable=False)
    status = Column(String(20), nullable=False, default="open")  # open|converted|cancelled
    requested_by = Column(Integer)
    created_at = ts()
    po_id = Column(Integer)


class RequisitionLine(Base):
    __tablename__ = "requisition_lines"
    id = pk()
    requisition_id = fk("requisitions.id", nullable=False)
    product_id = fk("products.id", nullable=False)
    cases = Column(Integer, nullable=False)
    recommendation_id = Column(Integer)


class Quotation(Base):
    __tablename__ = "quotations"
    id = pk()
    supplier_id = fk("suppliers.id", nullable=False)
    product_id = fk("products.id", nullable=False)
    case_cost = Column(Cost, nullable=False)
    moq_cases = Column(Integer, nullable=False, default=1)
    valid_until = Column(Date)
    status = Column(String(20), nullable=False, default="received")  # received|accepted|declined|expired
    received_at = ts()
    decided_by = Column(Integer)


class PurchaseOrder(Base):
    __tablename__ = "purchase_orders"
    id = pk()
    number = Column(String(30), unique=True, nullable=False)
    supplier_id = fk("suppliers.id", nullable=False)
    site_id = fk("sites.id", nullable=False)
    status = Column(String(20), nullable=False, default="draft", index=True)
    # draft|pending_approval|approved|sent|part_received|received|closed|cancelled|rejected
    expected_date = Column(Date)
    net_total = Column(Money, nullable=False, default=0)
    created_by = Column(Integer)
    approved_by = Column(Integer)
    created_at = ts()
    approved_at = Column(DateTime(timezone=True))
    version = Column(Integer, nullable=False, default=1)
    __mapper_args__ = {"version_id_col": version}


class PurchaseOrderLine(Base):
    __tablename__ = "purchase_order_lines"
    id = pk()
    po_id = fk("purchase_orders.id", nullable=False)
    product_id = fk("products.id", nullable=False)
    description = Column(String(200), nullable=False)
    case_size = Column(Qty, nullable=False)
    cases_ordered = Column(Integer, nullable=False)
    case_cost = Column(Cost, nullable=False)
    cases_received = Column(Integer, nullable=False, default=0)   # accepted in good condition
    cases_damaged = Column(Integer, nullable=False, default=0)
    cases_invoiced = Column(Integer, nullable=False, default=0)


class DeliveryAppointment(Base):
    __tablename__ = "delivery_appointments"
    id = pk()
    po_id = fk("purchase_orders.id", nullable=False)
    site_id = fk("sites.id", nullable=False)
    slot_start = Column(DateTime(timezone=True), nullable=False)
    slot_end = Column(DateTime(timezone=True), nullable=False)
    dock = Column(String(20))
    status = Column(String(20), nullable=False, default="booked")  # booked|arrived|late|missed|completed
    actual_arrival = Column(DateTime(timezone=True))


class GoodsReceipt(Base):
    __tablename__ = "goods_receipts"
    id = pk()
    po_id = fk("purchase_orders.id", nullable=False)
    site_id = fk("sites.id", nullable=False)
    delivery_note_ref = Column(String(60), nullable=False)
    received_at = ts()
    received_by = Column(Integer)
    # A delivery note can be booked in once per PO: the duplicate-receipt guard.
    __table_args__ = (UniqueConstraint("po_id", "delivery_note_ref"),)


class GoodsReceiptLine(Base):
    __tablename__ = "goods_receipt_lines"
    id = pk()
    receipt_id = fk("goods_receipts.id", nullable=False)
    po_line_id = fk("purchase_order_lines.id", nullable=False)
    lot_id = fk("lots.id", nullable=False)
    cases_received = Column(Integer, nullable=False)
    cases_damaged = Column(Integer, nullable=False, default=0)


class Discrepancy(Base):
    __tablename__ = "receipt_discrepancies"
    id = pk()
    receipt_id = fk("goods_receipts.id", nullable=False)
    po_line_id = fk("purchase_order_lines.id", nullable=False)
    kind = Column(String(20), nullable=False)  # short|damaged|over
    cases = Column(Integer, nullable=False)
    status = Column(String(20), nullable=False, default="open")
    note = Column(Text)


class SupplierReturn(Base):
    __tablename__ = "supplier_returns"
    id = pk()
    supplier_id = fk("suppliers.id", nullable=False)
    site_id = fk("sites.id", nullable=False)
    product_id = fk("products.id", nullable=False)
    lot_id = fk("lots.id", nullable=False)
    qty = Column(Qty, nullable=False)
    reason = Column(String(200))
    status = Column(String(20), nullable=False, default="open")  # open|collected|credited
    created_at = ts()


class SupplierInvoice(Base):
    __tablename__ = "supplier_invoices"
    id = pk()
    supplier_id = fk("suppliers.id", nullable=False)
    po_id = fk("purchase_orders.id")
    invoice_no = Column(String(60), nullable=False)
    invoice_date = Column(Date, nullable=False)
    due_date = Column(Date)
    net = Column(Money, nullable=False)
    tax = Column(Money, nullable=False, default=0)
    gross = Column(Money, nullable=False)
    status = Column(String(20), nullable=False, default="received", index=True)
    # received|matched|exception|approved_for_payment|paid
    match_result = Column(JSON)
    matched_by = Column(Integer)
    created_at = ts()
    __table_args__ = (UniqueConstraint("supplier_id", "invoice_no"),)


class SupplierInvoiceLine(Base):
    __tablename__ = "supplier_invoice_lines"
    id = pk()
    invoice_id = fk("supplier_invoices.id", nullable=False)
    po_line_id = fk("purchase_order_lines.id")
    cases = Column(Integer, nullable=False)
    case_cost = Column(Cost, nullable=False)
    tax_rate = Column(Numeric(6, 4), nullable=False, default=0)
