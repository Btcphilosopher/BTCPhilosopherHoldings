"""Distribution: allocation to stores, warehouse work queue, route planning, dispatch and receipt."""
import math
from collections import defaultdict
from datetime import date, datetime, time, timedelta, timezone
from decimal import ROUND_DOWN, Decimal

from sqlalchemy import func, select

from ...adapters import mocks
from ...common import ZERO, bad, conflict, dec, emit, flag, now, plain
from ..catalog.models import Product
from ..inventory import service as inv
from ..inventory.models import Reservation, StockBalance
from ..org.models import Site, StoreFormat
from ..procurement import forecasting
from ..procurement.models import ReplenishmentPolicy
from .models import PickWave, Route, RoutePlan, RouteStop, Transfer, TransferLine, Vehicle, WarehouseTask

CASES_PER_CAGE = 30
SPEED_KMH = 40
SERVICE_MIN = 25


def _next(db):
    return f"TR-{db.execute(select(func.coalesce(func.max(Transfer.id), 0))).scalar() + 1:06d}"


def allocate(db, *, dc_id, as_of: date, actor_id=None, store_ids=None):
    """Allocate DC stock to stores: need = forecast over the format's cover days + store safety stock
    - (store available + in transit). When the DC is short, stores get a proportional fair share
    (whole cases) and the shortfall stays visible on the transfer line."""
    run = forecasting.latest_run(db)
    if not run:
        raise conflict("Run a demand forecast first", "no_forecast")
    stores = db.execute(select(Site).where(Site.kind == "store", Site.status == "trading")).scalars().all()
    if store_ids:
        stores = [s for s in stores if s.id in store_ids]
    formats = {f.id: f for f in db.execute(select(StoreFormat)).scalars()}
    products = {p.id: p for p in db.execute(select(Product).where(Product.status == "active")).scalars()}
    pol = {(p.site_id, p.product_id): p for p in db.execute(select(ReplenishmentPolicy)).scalars()}
    pos = defaultdict(lambda: ZERO)
    for sid, pid, q in db.execute(select(StockBalance.site_id, StockBalance.product_id, func.sum(StockBalance.qty))
                                  .where(StockBalance.bucket.in_(["available", "in_transit"])).group_by(StockBalance.site_id, StockBalance.product_id)):
        pos[(sid, pid)] = q
    open_alloc = defaultdict(lambda: ZERO)  # already planned but not yet dispatched
    for sid, pid, q in db.execute(select(Transfer.to_site_id, TransferLine.product_id, func.sum(TransferLine.qty_allocated))
                                  .join(TransferLine, TransferLine.transfer_id == Transfer.id)
                                  .where(Transfer.status.in_(["planned", "picking", "picked", "packed", "staged"]))
                                  .group_by(Transfer.to_site_id, TransferLine.product_id)):
        open_alloc[(sid, pid)] = q
    needs = defaultdict(dict)
    for s in stores:
        cover = int((formats[s.format_id].replenishment_policy or {}).get("cover_days", 3)) if s.format_id else 3
        fc = forecasting.store_forecast(db, run.id, as_of, cover)
        for pid, prod in products.items():
            policy = pol.get((s.id, pid))
            if not policy:
                continue
            need = fc.get((s.id, pid), ZERO) + dec(policy.safety_stock) - pos[(s.id, pid)] - open_alloc[(s.id, pid)]
            room = dec(policy.max_capacity) - pos[(s.id, pid)] - open_alloc[(s.id, pid)]
            need = min(need, room)
            cases = math.ceil(need / prod.case_size) if need > 0 else 0
            if cases > 0:
                needs[pid][s.id] = cases
    by_store = defaultdict(list)
    for pid, per_store in needs.items():
        prod = products[pid]
        avail_cases = int((inv.available(db, dc_id, pid) / prod.case_size).to_integral_value(rounding=ROUND_DOWN))
        want = sum(per_store.values())
        for sid, cases in sorted(per_store.items()):
            give = cases if want <= avail_cases else math.floor(cases * avail_cases / want)
            by_store[sid].append((prod, cases, give))
    out = []
    for sid, items in by_store.items():
        if not any(g for _, _, g in items):
            continue
        tr = Transfer(number=_next(db), from_site_id=dc_id, to_site_id=sid)
        db.add(tr)
        db.flush()
        cages = defaultdict(int)
        for prod, cases, give in items:
            got = inv.reserve(db, site_id=dc_id, product_id=prod.id, qty=give * prod.case_size, ref_type="transfer",
                              ref_id=tr.id, allow_partial=True, actor_id=actor_id) if give else ZERO
            db.add(TransferLine(transfer_id=tr.id, product_id=prod.id, qty_requested=cases * prod.case_size, qty_allocated=got))
            cages[prod.storage_class] += give
        tr.cages = {k: math.ceil(v / CASES_PER_CAGE) for k, v in cages.items() if v}
        out.append(tr)
    db.flush()
    return out


def release_wave(db, *, dc_id, transfer_ids=None, actor_id=None):
    q = select(Transfer).where(Transfer.from_site_id == dc_id, Transfer.status == "planned")
    if transfer_ids:
        q = q.where(Transfer.id.in_(transfer_ids))
    trs = db.execute(q).scalars().all()
    if not trs:
        raise conflict("No planned transfers to release")
    wave = PickWave(site_id=dc_id, created_by=actor_id)
    db.add(wave)
    db.flush()
    for tr in trs:
        tr.status, tr.wave_id = "picking", wave.id
        for r in db.execute(select(Reservation).where(Reservation.ref_type == "transfer", Reservation.ref_id == tr.id,
                                                      Reservation.status == "active")).scalars():
            prod = db.get(Product, r.product_id)
            db.add(WarehouseTask(site_id=dc_id, kind="pick", ref_type="pick_wave", ref_id=wave.id, transfer_id=tr.id,
                                 product_id=r.product_id, lot_id=r.lot_id, qty=r.qty, temp_class=prod.storage_class))
    db.flush()
    return wave


def complete_task(db, task, *, qty_done=None, actor_id=None):
    if task.status != "open":
        raise conflict("Task already completed")
    task.qty_done = dec(qty_done) if qty_done is not None else task.qty
    if task.qty is not None and (task.qty_done < 0 or task.qty_done > task.qty):
        raise bad("Quantity done must be between 0 and the task quantity")
    task.status, task.completed_at, task.completed_by = "done", now(), actor_id
    task.scan_ref = mocks.scanner.confirm(task.id, actor_id)
    tr = db.get(Transfer, task.transfer_id) if task.transfer_id else None
    if task.kind == "pick":
        line = db.execute(select(TransferLine).where(TransferLine.transfer_id == tr.id, TransferLine.product_id == task.product_id)).scalar_one()
        line.qty_picked += task.qty_done
        short = task.qty - task.qty_done
        if short > 0:  # could not find it: release the reservation so it is not stranded
            inv.release(db, ref_type="transfer", ref_id=tr.id, product_id=task.product_id, qty=short, actor_id=actor_id)
            flag(db, "stock_discrepancy", f"Short pick on {tr.number}: {short} units not found", entity_type="warehouse_task",
                 entity_id=task.id, site_id=task.site_id)
        db.flush()
        if not db.execute(select(WarehouseTask.id).where(WarehouseTask.transfer_id == tr.id, WarehouseTask.kind == "pick",
                                                         WarehouseTask.status == "open")).first():
            tr.status = "picked"
            db.add(WarehouseTask(site_id=task.site_id, kind="pack", transfer_id=tr.id, ref_type="transfer", ref_id=tr.id))
    elif task.kind == "pack":
        tr.status = "packed"
        db.add(WarehouseTask(site_id=task.site_id, kind="stage", transfer_id=tr.id, ref_type="transfer", ref_id=tr.id, location_code="STAGE-1"))
    elif task.kind == "stage":
        tr.status = "staged"
    db.flush()
    return task


def _dist(a, b):
    return math.hypot(float(a.grid_x - b.grid_x), float(a.grid_y - b.grid_y))


def plan_routes(db, *, dc_id, day: date, depart: time = time(5, 0), actor_id=None):
    """Baseline planner: greedy nearest-neighbour per vehicle with hard capacity, temperature and
    delivery-window checks. Anything it cannot schedule is returned as infeasible with the reason;
    it never fabricates a route that breaks a constraint."""
    dc = db.get(Site, dc_id)
    trs = db.execute(select(Transfer).where(Transfer.from_site_id == dc_id, Transfer.status == "staged",
                                            Transfer.route_stop_id.is_(None))).scalars().all()
    if not trs:
        raise conflict("No staged transfers awaiting transport")
    start = datetime.combine(day, depart, tzinfo=timezone.utc)
    plan = RoutePlan(site_id=dc_id, day=day, depart_at=start, created_by=actor_id,
                     method=f"Greedy nearest-neighbour baseline; {SPEED_KMH} km/h on a planning grid; {SERVICE_MIN} min per stop")
    db.add(plan)
    db.flush()
    pending = {t.id: t for t in trs}
    sites = {t.id: db.get(Site, t.to_site_id) for t in trs}
    reasons = defaultdict(dict)   # transfer -> {vehicle: first (best-case) reason}
    for v in db.execute(select(Vehicle).where(Vehicle.site_id == dc_id, Vehicle.status == "available").order_by(Vehicle.capacity_cages.desc())).scalars():
        if not pending:
            break
        route, here, clock, load, dist, seq = None, dc, start, 0, 0.0, 0
        while True:
            best = None
            for t in pending.values():
                cages, st = t.cages or {}, sites[t.id]
                total = sum(cages.values())
                if cages.get("frozen") and not v.frozen:
                    reasons[t.id].setdefault(v.fleet_no, "no frozen compartment")
                    continue
                if cages.get("chilled") and not v.chilled:
                    reasons[t.id].setdefault(v.fleet_no, "no chilled compartment")
                    continue
                if load + total > v.capacity_cages:
                    reasons[t.id].setdefault(v.fleet_no, f"{total} cages needed, {v.capacity_cages - load} free")
                    continue
                km = _dist(here, st)
                arrive = clock + timedelta(minutes=km / SPEED_KMH * 60)
                ws = datetime.combine(day, st.delivery_window_start or time(0, 0), tzinfo=timezone.utc)
                we = datetime.combine(day, st.delivery_window_end or time(23, 59), tzinfo=timezone.utc)
                arrive = max(arrive, ws)  # wait for the window to open
                if arrive > we:
                    reasons[t.id].setdefault(v.fleet_no, f"would arrive {arrive:%H:%M} at the earliest, after the window closes at {we:%H:%M}")
                    continue
                if best is None or km < best[0]:
                    best = (km, t, arrive, ws, we, total)
            if not best:
                break
            km, t, arrive, ws, we, total = best
            if route is None:
                route = Route(plan_id=plan.id, vehicle_id=v.id)
                db.add(route)
                db.flush()
            seq += 1
            stop = RouteStop(route_id=route.id, seq=seq, site_id=t.to_site_id, transfer_id=t.id, window_start=ws,
                             window_end=we, planned_arrival=arrive)
            db.add(stop)
            db.flush()
            t.route_stop_id = stop.id
            load, dist, here, clock = load + total, dist + km, sites[t.id], arrive + timedelta(minutes=SERVICE_MIN)
            del pending[t.id]
        if route:
            route.load_cages, route.distance_km = load, Decimal(str(round(dist + _dist(here, dc), 1)))
    plan.infeasible = [{"transfer": t.number, "transfer_id": t.id, "store": sites[t.id].name, "cages": t.cages,
                        "reasons": [f"{k}: {r}" for k, r in sorted(reasons[t.id].items())] or ["no vehicle available"]} for t in pending.values()]
    for t in pending.values():
        flag(db, "infeasible_route", f"{t.number} to {sites[t.id].name} could not be scheduled for {day}", severity="high",
             entity_type="transfer", entity_id=t.id, site_id=t.to_site_id, dedupe=f"route:{t.id}:{day}",
             detail="; ".join(f"{k}: {r}" for k, r in sorted(reasons[t.id].items())))
    db.flush()
    return plan


def dispatch_route(db, route, actor_id=None):
    if route.status != "planned":
        raise conflict(f"Route already {route.status}")
    for stop in db.execute(select(RouteStop).where(RouteStop.route_id == route.id)).scalars():
        tr = db.get(Transfer, stop.transfer_id)
        for line in db.execute(select(TransferLine).where(TransferLine.transfer_id == tr.id)).scalars():
            if line.qty_picked > 0:
                inv.consume_reserved(db, ref_type="transfer", ref_id=tr.id, product_id=line.product_id, qty=line.qty_picked,
                                     mtype="transfer_dispatch", dst_bucket="in_transit", dst_site_id=tr.to_site_id, actor_id=actor_id)
        inv.release(db, ref_type="transfer", ref_id=tr.id, actor_id=actor_id)  # anything reserved but unpicked
        tr.status, tr.dispatched_at, stop.status = "dispatched", now(), "en_route"
    route.status = "dispatched"
    emit(db, "route.dispatched", route.id, {"route_id": route.id})
    db.flush()
    return route


def refresh_etas(db, route):
    v = db.get(Vehicle, route.vehicle_id)
    for stop in db.execute(select(RouteStop).where(RouteStop.route_id == route.id, RouteStop.status == "en_route")).scalars():
        stop.live_eta, stop.live_eta_source = mocks.tracking.eta(v.fleet_no, stop.seq, stop.planned_arrival)
        if stop.window_end and stop.live_eta > stop.window_end:
            flag(db, "late_delivery", f"Live ETA {stop.live_eta:%H:%M} for stop {stop.seq} is after the store window", severity="medium",
                 entity_type="route_stop", entity_id=stop.id, site_id=stop.site_id, dedupe=f"eta:{stop.id}")
    db.flush()


def _in_transit_lots(db, tr, product_id):
    """Lots dispatched for this transfer line (from the ledger), so receipt books the same lots in."""
    from ..inventory.models import StockMovement
    return db.execute(select(StockMovement.lot_id, func.sum(StockMovement.qty)).where(
        StockMovement.ref_type == "transfer", StockMovement.ref_id == tr.id, StockMovement.product_id == product_id,
        StockMovement.bucket == "in_transit", StockMovement.site_id == tr.to_site_id)
        .group_by(StockMovement.lot_id).having(func.sum(StockMovement.qty) > 0)).all()


def confirm_stop(db, stop, *, received=None, receiver="store receiver", actor_id=None):
    """Store confirms receipt. received: {product_id: qty}; default = everything dispatched.
    Any shortfall is moved to 'damaged' at the store with a visible exception - nothing vanishes."""
    if stop.status != "en_route":
        raise conflict(f"Stop is {stop.status}")
    tr = db.get(Transfer, stop.transfer_id)
    for line in db.execute(select(TransferLine).where(TransferLine.transfer_id == tr.id)).scalars():
        want = dec(received.get(str(line.product_id), received.get(line.product_id, line.qty_picked))) if received else line.qty_picked
        if want > line.qty_picked:
            raise bad("Cannot receive more than was dispatched")
        left = want
        for lot_id, q in _in_transit_lots(db, tr, line.product_id):
            ok = min(q, left)
            kw = dict(site_id=tr.to_site_id, product_id=line.product_id, lot_id=lot_id, ref_type="transfer", ref_id=tr.id, actor_id=actor_id)
            if ok > 0:
                inv.move(db, src="in_transit", dst="available", qty=ok, mtype="transfer_receipt", **kw)
            if q - ok > 0:
                inv.move(db, src="in_transit", dst="damaged", qty=q - ok, mtype="transfer_shortage", reason="Not received at store", **kw)
            left -= ok
        line.qty_received = want
        if want < line.qty_picked:
            flag(db, "stock_discrepancy", f"{tr.number}: store received {want} of {line.qty_picked} dispatched", entity_type="transfer",
                 entity_id=tr.id, site_id=tr.to_site_id)
    stop.status, stop.actual_arrival = "delivered", now()
    stop.pod_ref = mocks.pod.capture(stop.id, receiver)
    tr.status, tr.received_at = "received", now()
    _maybe_complete(db, stop.route_id)
    db.flush()
    return stop


def fail_stop(db, stop, *, reason, actor_id=None):
    """Failed delivery: the load returns to the DC and goes back into available stock there."""
    if stop.status != "en_route":
        raise conflict(f"Stop is {stop.status}")
    tr = db.get(Transfer, stop.transfer_id)
    for line in db.execute(select(TransferLine).where(TransferLine.transfer_id == tr.id)).scalars():
        for lot_id, q in _in_transit_lots(db, tr, line.product_id):
            g = dict(product_id=line.product_id, lot_id=lot_id, ref_type="transfer", ref_id=tr.id, actor_id=actor_id, reason=reason)
            inv.post(db, site_id=tr.to_site_id, bucket="in_transit", qty=-q, mtype="transfer_return", **g)
            inv.post(db, site_id=tr.from_site_id, bucket="available", qty=q, mtype="transfer_return", **g)
    stop.status, stop.failure_reason, tr.status = "failed", reason, "returned"
    flag(db, "failed_delivery", f"{tr.number} delivery failed: {reason}", severity="high", entity_type="transfer", entity_id=tr.id,
         site_id=tr.to_site_id)
    _maybe_complete(db, stop.route_id)
    db.flush()
    return stop


def _maybe_complete(db, route_id):
    db.flush()
    if not db.execute(select(RouteStop.id).where(RouteStop.route_id == route_id, RouteStop.status == "en_route")).first():
        db.get(Route, route_id).status = "completed"
