from sqlalchemy import JSON, Boolean, Column, Date, DateTime, Integer, String, Text

from ...db import Base, Qty, fk, pk, ts


class Transfer(Base):
    """DC -> store allocation. One transfer per store per allocation run."""
    __tablename__ = "transfers"
    id = pk()
    number = Column(String(30), unique=True, nullable=False)
    from_site_id = fk("sites.id", nullable=False)
    to_site_id = fk("sites.id", nullable=False)
    status = Column(String(20), nullable=False, default="planned", index=True)
    # planned|picking|picked|packed|staged|dispatched|received|failed|returned
    wave_id = fk("pick_waves.id")
    route_stop_id = Column(Integer)
    cages = Column(JSON)  # {"ambient": n, "chilled": n, "frozen": n}
    created_at = ts()
    dispatched_at = Column(DateTime(timezone=True))
    received_at = Column(DateTime(timezone=True))


class TransferLine(Base):
    __tablename__ = "transfer_lines"
    id = pk()
    transfer_id = fk("transfers.id", nullable=False)
    product_id = fk("products.id", nullable=False)
    qty_requested = Column(Qty, nullable=False)   # what the store needed
    qty_allocated = Column(Qty, nullable=False)   # what the DC could reserve (fair share when short)
    qty_picked = Column(Qty, nullable=False, default=0)
    qty_received = Column(Qty, nullable=False, default=0)


class PickWave(Base):
    __tablename__ = "pick_waves"
    id = pk()
    site_id = fk("sites.id", nullable=False)
    status = Column(String(20), nullable=False, default="released")
    created_at = ts()
    created_by = Column(Integer)


class WarehouseTask(Base):
    __tablename__ = "warehouse_tasks"
    id = pk()
    site_id = fk("sites.id", nullable=False)
    kind = Column(String(20), nullable=False)  # putaway|pick|pack|stage
    status = Column(String(20), nullable=False, default="open", index=True)  # open|done
    ref_type = Column(String(30))
    ref_id = Column(Integer)
    transfer_id = fk("transfers.id")
    product_id = fk("products.id")
    lot_id = fk("lots.id")
    qty = Column(Qty)
    qty_done = Column(Qty)
    temp_class = Column(String(10))
    location_code = Column(String(30))
    scan_ref = Column(String(80))  # reference returned by the scanner adapter
    created_at = ts()
    completed_at = Column(DateTime(timezone=True))
    completed_by = Column(Integer)


class Vehicle(Base):
    __tablename__ = "vehicles"
    id = pk()
    site_id = fk("sites.id", nullable=False)
    fleet_no = Column(String(20), unique=True, nullable=False)  # fictional fleet number
    capacity_cages = Column(Integer, nullable=False)
    chilled = Column(Boolean, nullable=False, default=False)
    frozen = Column(Boolean, nullable=False, default=False)
    status = Column(String(20), nullable=False, default="available")


class RoutePlan(Base):
    __tablename__ = "route_plans"
    id = pk()
    site_id = fk("sites.id", nullable=False)
    day = Column(Date, nullable=False)
    depart_at = Column(DateTime(timezone=True), nullable=False)
    method = Column(String(80), nullable=False)
    status = Column(String(20), nullable=False, default="planned")
    infeasible = Column(JSON)  # stops that could NOT be scheduled, with the reason - never hidden
    created_at = ts()
    created_by = Column(Integer)


class Route(Base):
    __tablename__ = "routes"
    id = pk()
    plan_id = fk("route_plans.id", nullable=False)
    vehicle_id = fk("vehicles.id", nullable=False)
    status = Column(String(20), nullable=False, default="planned")  # planned|dispatched|completed
    load_cages = Column(Integer, nullable=False, default=0)
    distance_km = Column(Qty)


class RouteStop(Base):
    __tablename__ = "route_stops"
    id = pk()
    route_id = fk("routes.id", nullable=False)
    seq = Column(Integer, nullable=False)
    site_id = fk("sites.id", nullable=False)
    transfer_id = fk("transfers.id", nullable=False)
    window_start = Column(DateTime(timezone=True))
    window_end = Column(DateTime(timezone=True))
    planned_arrival = Column(DateTime(timezone=True), nullable=False)   # from the plan
    live_eta = Column(DateTime(timezone=True))                          # from vehicle tracking, may differ
    live_eta_source = Column(String(60))
    actual_arrival = Column(DateTime(timezone=True))
    status = Column(String(20), nullable=False, default="planned")  # planned|en_route|delivered|failed
    pod_ref = Column(String(80))
    failure_reason = Column(Text)
