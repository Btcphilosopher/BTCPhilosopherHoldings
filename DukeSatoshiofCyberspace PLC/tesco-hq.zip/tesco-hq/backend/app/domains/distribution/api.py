from datetime import date, time, timedelta

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import select

from ...common import audit, get_or_404, mappings, row
from ...db import get_db
from ...security import require
from . import service
from .models import Route, RoutePlan, RouteStop, WarehouseTask

router = APIRouter(prefix="/distribution", tags=["Distribution & transport"])
SC = "(:all_sites OR {c} = ANY(CAST(:sites AS int[])))"


class AllocIn(BaseModel):
    dc_id: int
    store_ids: list[int] | None = None


@router.post("/allocations/run")
def allocate(body: AllocIn, p=Depends(require("distribution.write")), db=Depends(get_db)):
    p.check("distribution.write", body.dc_id)
    trs = service.allocate(db, dc_id=body.dc_id, as_of=date.today(), actor_id=p.user.id, store_ids=body.store_ids)
    audit(db, p, "allocation.run", "site", body.dc_id, {"transfers": [t.number for t in trs]})
    db.commit()
    return {"transfers": [row(t) for t in trs]}


@router.get("/transfers")
def transfers(status: str | None = None, p=Depends(require("distribution.read")), db=Depends(get_db)):
    return mappings(db, f"""SELECT t.*, f.name from_site, s.name to_site,
          (SELECT COALESCE(SUM(qty_requested),0) FROM transfer_lines l WHERE l.transfer_id=t.id) qty_requested,
          (SELECT COALESCE(SUM(qty_allocated),0) FROM transfer_lines l WHERE l.transfer_id=t.id) qty_allocated,
          (SELECT COALESCE(SUM(qty_picked),0) FROM transfer_lines l WHERE l.transfer_id=t.id) qty_picked,
          (SELECT COALESCE(SUM(qty_received),0) FROM transfer_lines l WHERE l.transfer_id=t.id) qty_received
        FROM transfers t JOIN sites f ON f.id=t.from_site_id JOIN sites s ON s.id=t.to_site_id
        WHERE (:st IS NULL OR t.status=:st) AND ({SC.format(c='t.to_site_id')} OR {SC.format(c='t.from_site_id')}) ORDER BY t.id DESC LIMIT 300""",
                    st=status, **p.sql_sites("distribution.read"))


@router.get("/transfers/{tid}")
def transfer(tid: int, p=Depends(require("distribution.read")), db=Depends(get_db)):
    from .models import Transfer
    t = get_or_404(db, Transfer, tid)
    return row(t, lines=mappings(db, "SELECT l.*, p.sku, p.name product, p.storage_class FROM transfer_lines l JOIN products p ON p.id=l.product_id WHERE transfer_id=:t", t=tid),
               movements=mappings(db, "SELECT m.at, m.site_id, m.bucket, m.qty, m.mtype, m.lot_id FROM stock_movements m WHERE ref_type='transfer' AND ref_id=:t ORDER BY id", t=tid))


class WaveIn(BaseModel):
    dc_id: int


@router.post("/waves")
def wave(body: WaveIn, p=Depends(require("distribution.write")), db=Depends(get_db)):
    p.check("distribution.write", body.dc_id)
    w = service.release_wave(db, dc_id=body.dc_id, actor_id=p.user.id)
    db.commit()
    return row(w)


@router.get("/tasks")
def tasks(status: str | None = "open", kind: str | None = None, p=Depends(require("distribution.read")), db=Depends(get_db)):
    return mappings(db, f"""SELECT t.*, s.name site, p.sku, p.name product, l.lot_code, tr.number transfer, d.name destination
        FROM warehouse_tasks t JOIN sites s ON s.id=t.site_id LEFT JOIN products p ON p.id=t.product_id LEFT JOIN lots l ON l.id=t.lot_id
        LEFT JOIN transfers tr ON tr.id=t.transfer_id LEFT JOIN sites d ON d.id=tr.to_site_id
        WHERE (:st IS NULL OR t.status=:st) AND (:k IS NULL OR t.kind=:k) AND {SC.format(c='t.site_id')}
        ORDER BY CASE t.kind WHEN 'putaway' THEN 0 WHEN 'pick' THEN 1 WHEN 'pack' THEN 2 ELSE 3 END, t.id LIMIT 500""",
                    st=status, k=kind, **p.sql_sites("distribution.read"))


class TaskDone(BaseModel):
    qty_done: float | None = None
    location_code: str | None = None


@router.post("/tasks/{task_id}/complete")
def complete(task_id: int, body: TaskDone, p=Depends(require("distribution.write")), db=Depends(get_db)):
    t = get_or_404(db, WarehouseTask, task_id)
    p.check("distribution.write", t.site_id)
    if body.location_code:
        t.location_code = body.location_code
    service.complete_task(db, t, qty_done=body.qty_done, actor_id=p.user.id)
    db.commit()
    return row(t)


@router.post("/tasks/complete-all")
def complete_all(body: WaveIn, kind: str = "pick", p=Depends(require("distribution.write")), db=Depends(get_db)):
    """Convenience for the demo: confirm every open task of one kind at a site in full."""
    p.check("distribution.write", body.dc_id)
    n = 0
    for t in db.execute(select(WarehouseTask).where(WarehouseTask.site_id == body.dc_id, WarehouseTask.kind == kind, WarehouseTask.status == "open")).scalars().all():
        service.complete_task(db, t, actor_id=p.user.id)
        n += 1
    db.commit()
    return {"completed": n}


@router.get("/vehicles")
def vehicles(p=Depends(require("distribution.read")), db=Depends(get_db)):
    return mappings(db, "SELECT v.*, s.name site FROM vehicles v JOIN sites s ON s.id=v.site_id ORDER BY v.fleet_no")


class PlanIn(BaseModel):
    dc_id: int
    day: date | None = None
    depart: time = time(5, 0)


@router.post("/route-plans")
def plan(body: PlanIn, p=Depends(require("distribution.write")), db=Depends(get_db)):
    p.check("distribution.write", body.dc_id)
    pl = service.plan_routes(db, dc_id=body.dc_id, day=body.day or date.today() + timedelta(days=1), depart=body.depart, actor_id=p.user.id)
    audit(db, p, "route_plan.created", "route_plan", pl.id, {"infeasible": len(pl.infeasible or [])})
    db.commit()
    return row(pl)


@router.get("/route-plans")
def plans(p=Depends(require("distribution.read")), db=Depends(get_db)):
    out = []
    for pl in db.execute(select(RoutePlan).order_by(RoutePlan.id.desc()).limit(20)).scalars():
        routes = mappings(db, """SELECT r.*, v.fleet_no, v.capacity_cages, v.chilled, v.frozen FROM routes r JOIN vehicles v ON v.id=r.vehicle_id
            WHERE r.plan_id=:p ORDER BY r.id""", p=pl.id)
        for r in routes:
            r["stops"] = mappings(db, """SELECT st.*, s.name site, t.number transfer, t.cages FROM route_stops st JOIN sites s ON s.id=st.site_id
                JOIN transfers t ON t.id=st.transfer_id WHERE st.route_id=:r ORDER BY st.seq""", r=r["id"])
        out.append(row(pl, routes=routes, infeasible_count=len(pl.infeasible or [])))
    return out


@router.get("/stops")
def stops(p=Depends(require("distribution.read")), db=Depends(get_db)):
    return mappings(db, f"""SELECT st.*, s.name site, t.number transfer, v.fleet_no, r.status route_status,
          CASE WHEN st.live_eta IS NOT NULL THEN ROUND(EXTRACT(EPOCH FROM (st.live_eta - st.planned_arrival))/60) END eta_drift_min
        FROM route_stops st JOIN routes r ON r.id=st.route_id JOIN vehicles v ON v.id=r.vehicle_id JOIN sites s ON s.id=st.site_id
        JOIN transfers t ON t.id=st.transfer_id WHERE {SC.format(c='st.site_id')} OR {SC.format(c='t.from_site_id')}
        ORDER BY st.id DESC LIMIT 200""", **p.sql_sites("distribution.read"))


@router.post("/routes/{route_id}/dispatch")
def dispatch(route_id: int, p=Depends(require("distribution.write")), db=Depends(get_db)):
    r = get_or_404(db, Route, route_id)
    p.check("distribution.write", db.get(RoutePlan, r.plan_id).site_id)
    service.dispatch_route(db, r, actor_id=p.user.id)
    service.refresh_etas(db, r)
    audit(db, p, "route.dispatched", "route", r.id)
    db.commit()
    return row(r)


@router.post("/routes/{route_id}/refresh-eta")
def refresh(route_id: int, p=Depends(require("distribution.read")), db=Depends(get_db)):
    r = get_or_404(db, Route, route_id)
    service.refresh_etas(db, r)
    db.commit()
    return {"status": "refreshed"}


class StopConfirm(BaseModel):
    received: dict[str, float] | None = None
    receiver: str = "Store receiver"


@router.post("/stops/{stop_id}/confirm")
def confirm(stop_id: int, body: StopConfirm, p=Depends(require("distribution.write")), db=Depends(get_db)):
    st = get_or_404(db, RouteStop, stop_id)
    if not p.can("distribution.write", db.get(RoutePlan, db.get(Route, st.route_id).plan_id).site_id):  # driver/DC may confirm with POD
        p.check("distribution.write", st.site_id)
    service.confirm_stop(db, st, received=body.received, receiver=body.receiver, actor_id=p.user.id)
    audit(db, p, "transfer.received", "route_stop", st.id)
    db.commit()
    return row(st)


class StopFail(BaseModel):
    reason: str


@router.post("/stops/{stop_id}/fail")
def fail(stop_id: int, body: StopFail, p=Depends(require("distribution.write")), db=Depends(get_db)):
    st = get_or_404(db, RouteStop, stop_id)
    if not (p.can("distribution.write", st.site_id) or p.can("distribution.write", db.get(RoutePlan, db.get(Route, st.route_id).plan_id).site_id)):
        p.check("distribution.write", st.site_id)
    service.fail_stop(db, st, reason=body.reason, actor_id=p.user.id)
    audit(db, p, "transfer.delivery_failed", "route_stop", st.id, {"reason": body.reason})
    db.commit()
    return row(st)
