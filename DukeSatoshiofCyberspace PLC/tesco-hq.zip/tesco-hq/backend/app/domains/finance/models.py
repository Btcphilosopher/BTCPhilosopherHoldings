from sqlalchemy import JSON, CheckConstraint, Column, Date, DateTime, Integer, String, Text, UniqueConstraint

from ...db import Base, Money, fk, pk, ts


class Account(Base):
    __tablename__ = "accounts"
    id = pk()
    code = Column(String(10), unique=True, nullable=False)
    name = Column(String(120), nullable=False)
    kind = Column(String(12), nullable=False)  # asset|liability|equity|revenue|expense


class JournalEntry(Base):
    __tablename__ = "journal_entries"
    id = pk()
    number = Column(String(30), unique=True, nullable=False)
    entry_date = Column(Date, nullable=False, index=True)
    source_type = Column(String(30), nullable=False, index=True)
    source_id = Column(Integer, index=True)
    description = Column(String(300), nullable=False)
    posted_by = Column(Integer)
    posted_at = ts()
    reverses_id = fk("journal_entries.id")


class JournalLine(Base):
    """Immutable; balance per entry enforced by a deferred constraint trigger at commit."""
    __tablename__ = "journal_lines"
    id = pk()
    entry_id = fk("journal_entries.id", nullable=False)
    account_id = fk("accounts.id", nullable=False)
    site_id = fk("sites.id")
    debit = Column(Money, nullable=False, default=0)
    credit = Column(Money, nullable=False, default=0)
    memo = Column(String(200))
    __table_args__ = (CheckConstraint("debit >= 0 AND credit >= 0 AND NOT (debit > 0 AND credit > 0)",
                                      name="one_sided"),)


class SupplierPayment(Base):
    __tablename__ = "supplier_payments"
    id = pk()
    supplier_id = fk("suppliers.id", nullable=False)
    invoice_id = fk("supplier_invoices.id", nullable=False, unique=True)
    amount = Column(Money, nullable=False)
    status = Column(String(20), nullable=False, default="pending_approval")  # pending_approval|paid|rejected
    approval_id = Column(Integer)
    requested_by = Column(Integer)
    paid_at = Column(DateTime(timezone=True))
    bank_ref = Column(String(80))
    created_at = ts()


class Settlement(Base):
    """A payment-provider settlement batch: gross captured, fees withheld, net paid to bank."""
    __tablename__ = "settlements"
    id = pk()
    provider = Column(String(40), nullable=False)
    batch_ref = Column(String(60), unique=True, nullable=False)
    business_date = Column(Date, nullable=False)
    gross = Column(Money, nullable=False)
    refunds = Column(Money, nullable=False, default=0)
    fees = Column(Money, nullable=False)
    net = Column(Money, nullable=False)
    ledger_gross = Column(Money)   # what our payments table says for the same date
    difference = Column(Money)
    unmatched = Column(JSON)
    status = Column(String(20), nullable=False, default="imported")  # imported|reconciled|exception
    posted_at = Column(DateTime(timezone=True))


class CashReconciliation(Base):
    __tablename__ = "cash_reconciliations"
    id = pk()
    site_id = fk("sites.id", nullable=False)
    business_date = Column(Date, nullable=False)
    expected = Column(Money, nullable=False)
    counted = Column(Money, nullable=False)
    variance = Column(Money, nullable=False)
    status = Column(String(20), nullable=False, default="balanced")
    note = Column(Text)
    counted_by = Column(Integer)
    at = ts()
    __table_args__ = (UniqueConstraint("site_id", "business_date"),)


class Budget(Base):
    __tablename__ = "budgets"
    id = pk()
    period_start = Column(Date, nullable=False)
    period_end = Column(Date, nullable=False)
    site_id = fk("sites.id")
    metric = Column(String(30), nullable=False)  # net_sales|gross_margin|waste|operating_costs
    amount = Column(Money, nullable=False)
    version = Column(String(40), nullable=False, default="FY budget v1")


class OperatingCost(Base):
    """Operating-cost accruals fed from HR/payroll and facilities systems (imported; fictional here)."""
    __tablename__ = "operating_costs"
    id = pk()
    site_id = fk("sites.id", nullable=False)
    day = Column(Date, nullable=False, index=True)
    category = Column(String(30), nullable=False)  # wages|energy|rent_rates|logistics
    amount = Column(Money, nullable=False)
    source = Column(String(60), nullable=False)
    journal_entry_id = Column(Integer)


class LegacySalesDaily(Base):
    """Prior-year daily sales by store imported from a legacy summary; used only as the LFL comparative."""
    __tablename__ = "legacy_sales_daily"
    id = pk()
    site_id = fk("sites.id", nullable=False)
    day = Column(Date, nullable=False, index=True)
    net_sales = Column(Money, nullable=False)
    source = Column(String(60), nullable=False, default="legacy_import (fictional)")
    __table_args__ = (UniqueConstraint("site_id", "day"),)
