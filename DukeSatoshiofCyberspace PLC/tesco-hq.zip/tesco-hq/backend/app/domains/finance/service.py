"""Double-entry posting. One function creates every journal entry so the balance rule has one home."""
from datetime import date

from sqlalchemy import func, select

from ...common import ZERO, DomainError, dec, q2
from .models import Account, JournalEntry, JournalLine

CHART = [
    ("1000", "Bank - current account", "asset"), ("1010", "Cash in tills", "asset"),
    ("1020", "Card receivable (provider clearing)", "asset"), ("1200", "Inventory", "asset"),
    ("1300", "VAT input (recoverable)", "asset"),
    ("2000", "Trade payables", "liability"), ("2010", "Goods received not invoiced (accrual)", "liability"),
    ("2100", "VAT output (payable)", "liability"), ("2200", "Loyalty points liability", "liability"),
    ("2300", "Accrued operating costs", "liability"),
    ("3000", "Opening equity", "equity"),
    ("4000", "Sales revenue (net of VAT)", "revenue"), ("4010", "Sales returns", "revenue"),
    ("4020", "Loyalty points issued (contra-revenue)", "revenue"),
    ("5000", "Cost of goods sold", "expense"), ("5100", "Waste and shrink", "expense"),
    ("5200", "Purchase price variance", "expense"),
    ("6000", "Card processing fees", "expense"), ("6100", "Store wages", "expense"),
    ("6200", "Energy", "expense"), ("6300", "Rent and rates", "expense"), ("6400", "Logistics", "expense"),
    ("6900", "Cash over/short", "expense"),
]

_acct_cache = {}


def account_id(db, code):
    key = (id(db.get_bind()), code)
    if key not in _acct_cache:
        aid = db.execute(select(Account.id).where(Account.code == code)).scalar_one_or_none()
        if aid is None:
            raise DomainError(500, "config", f"Account {code} missing from chart")
        _acct_cache[key] = aid
    return _acct_cache[key]


def post_journal(db, *, entry_date: date, source_type, source_id, description, lines, posted_by=None,
                 reverses_id=None):
    """lines: iterable of (account_code, debit, credit, site_id[, memo]). Zero lines are dropped.
    Raises if debits != credits; the database re-checks at commit."""
    clean = []
    for ln in lines:
        code, dr, cr, site = ln[0], q2(ln[1] or 0), q2(ln[2] or 0), ln[3]
        if dr < 0:  # normalise negatives onto the other side
            dr, cr = ZERO, cr - dr
        if cr < 0:
            dr, cr = dr - cr, ZERO
        if dr == 0 and cr == 0:
            continue
        clean.append((code, dr, cr, site, ln[4] if len(ln) > 4 else None))
    if not clean:
        return None
    td, tc = sum(c[1] for c in clean), sum(c[2] for c in clean)
    if td != tc:
        raise DomainError(500, "unbalanced_journal", f"Journal for {source_type} {source_id} does not balance: Dr {td} / Cr {tc}")
    n = db.execute(select(func.coalesce(func.max(JournalEntry.id), 0))).scalar() + 1
    je = JournalEntry(number=f"JE-{n:07d}", entry_date=entry_date, source_type=source_type, source_id=source_id,
                      description=description[:300], posted_by=posted_by, reverses_id=reverses_id)
    db.add(je)
    db.flush()
    for code, dr, cr, site, memo in clean:
        db.add(JournalLine(entry_id=je.id, account_id=account_id(db, code), site_id=site, debit=dr, credit=cr, memo=memo))
    db.flush()
    return je


def tax_split(gross, rate):
    """VAT-inclusive gross -> (net, tax). Tax = gross - round_half_up(gross / (1 + rate))."""
    gross = q2(gross)
    net = q2(gross / (1 + dec(rate)))
    return net, gross - net
