from datetime import date, timedelta
from decimal import Decimal

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import func, select, text

from ...adapters import mocks
from ...common import ZERO, audit, bad, conflict, dec, flag, get_or_404, get_setting, mappings, now, plain, q2, row
from ...db import get_db
from ...security import require
from ..platform import approvals
from ..procurement import service as proc
from ..procurement.models import SupplierInvoice
from ..sales.models import Payment
from .models import CashReconciliation, JournalEntry, Settlement, SupplierPayment
from .service import post_journal

router = APIRouter(prefix="/finance", tags=["Finance & reconciliation"])
SC = "(:all_sites OR {c} IS NULL OR {c} = ANY(CAST(:sites AS int[])))"


@router.get("/trial-balance")
def trial_balance(date_to: date | None = None, p=Depends(require("finance.read")), db=Depends(get_db)):
    data = mappings(db, f"""SELECT a.code, a.name, a.kind, COALESCE(SUM(l.debit),0) debit, COALESCE(SUM(l.credit),0) credit,
          COALESCE(SUM(l.debit),0) - COALESCE(SUM(l.credit),0) balance
        FROM accounts a LEFT JOIN journal_lines l ON l.account_id=a.id AND {SC.format(c='l.site_id')}
          AND (CAST(:d AS date) IS NULL OR EXISTS (SELECT 1 FROM journal_entries e WHERE e.id=l.entry_id AND e.entry_date <= CAST(:d AS date)))
        GROUP BY a.id ORDER BY a.code""", d=date_to, **p.sql_sites("finance.read"))
    td, tc = sum(Decimal(r["debit"]) for r in data), sum(Decimal(r["credit"]) for r in data)
    return {"currency": "GBP", "accounts": data, "total_debit": str(td), "total_credit": str(tc), "balanced": td == tc,
            "note": "Demonstration subledger. Balanced by construction: each entry is checked in code and by a database constraint trigger."}


@router.get("/journal")
def journal(source_type: str | None = None, account: str | None = None, limit: int = 300, p=Depends(require("finance.read")), db=Depends(get_db)):
    return mappings(db, f"""SELECT e.id, e.number, e.entry_date, e.source_type, e.source_id, e.description, a.code account, a.name account_name,
          l.debit, l.credit, s.name site, l.memo
        FROM journal_lines l JOIN journal_entries e ON e.id=l.entry_id JOIN accounts a ON a.id=l.account_id LEFT JOIN sites s ON s.id=l.site_id
        WHERE (:st IS NULL OR e.source_type=:st) AND (:a IS NULL OR a.code=:a) AND {SC.format(c='l.site_id')} ORDER BY e.id DESC, l.id LIMIT :lim""",
                    st=source_type, a=account, lim=min(limit, 3000), **p.sql_sites("finance.read"))


# ---------------------------------------------------------------- supplier invoices & payments
class InvLine(BaseModel):
    po_line_id: int
    cases: int
    case_cost: Decimal


class InvoiceIn(BaseModel):
    supplier_id: int
    po_id: int
    invoice_no: str
    invoice_date: date
    net: Decimal
    tax: Decimal = Decimal(0)
    lines: list[InvLine]


@router.get("/invoices")
def invoices(status: str | None = None, p=Depends(require("finance.read")), db=Depends(get_db)):
    return mappings(db, """SELECT i.*, s.name supplier, po.number po_number,
          (SELECT status FROM supplier_payments sp WHERE sp.invoice_id=i.id) payment_status
        FROM supplier_invoices i JOIN suppliers s ON s.id=i.supplier_id LEFT JOIN purchase_orders po ON po.id=i.po_id
        WHERE (:st IS NULL OR i.status=:st) ORDER BY i.id DESC""", st=status)


@router.post("/invoices")
def register_invoice(body: InvoiceIn, p=Depends(require("finance.write")), db=Depends(get_db)):
    p.check("finance.write")
    inv_ = proc.register_invoice(db, p, **body.model_dump())
    audit(db, p, "invoice.registered", "supplier_invoice", inv_.id, {"invoice_no": inv_.invoice_no, "gross": inv_.gross})
    db.commit()
    return row(inv_)


@router.post("/invoices/{inv_id}/match")
def match(inv_id: int, p=Depends(require("finance.write")), db=Depends(get_db)):
    p.check("finance.write")
    inv_ = get_or_404(db, SupplierInvoice, inv_id)
    proc.match_invoice(db, p, inv_)
    audit(db, p, f"invoice.match_{inv_.status}", "supplier_invoice", inv_.id, inv_.match_result)
    db.commit()
    return row(inv_)


@router.post("/invoices/{inv_id}/request-payment")
def request_payment(inv_id: int, p=Depends(require("finance.write")), db=Depends(get_db)):
    """Payments are never released by the person who requested them."""
    p.check("finance.write")
    inv_ = get_or_404(db, SupplierInvoice, inv_id)
    if inv_.status != "matched":
        raise conflict(f"Only matched invoices can be paid (status: {inv_.status})")
    pay = SupplierPayment(supplier_id=inv_.supplier_id, invoice_id=inv_.id, amount=inv_.gross, requested_by=p.user.id)
    db.add(pay)
    db.flush()
    a = approvals.request(db, p, "supplier_payment", f"Pay invoice {inv_.invoice_no}: {inv_.gross}", "finance.approve",
                          entity_type="supplier_payment", entity_id=pay.id, amount=inv_.gross)
    pay.approval_id = a.id
    inv_.status = "approved_for_payment"
    db.commit()
    return row(pay)


@approvals.handler("supplier_payment")
def _payment_decided(db, a, p, approve):
    pay = db.get(SupplierPayment, a.entity_id)
    inv_ = db.get(SupplierInvoice, pay.invoice_id)
    if not approve:
        pay.status, inv_.status = "rejected", "matched"
        db.delete(pay) if False else None
        return
    pay.status, pay.paid_at, pay.bank_ref = "paid", now(), f"BACS-SIM-{pay.id:06d}"
    inv_.status = "paid"
    post_journal(db, entry_date=date.today(), source_type="supplier_payment", source_id=pay.id, posted_by=p.user.id,
                 description=f"Payment of invoice {inv_.invoice_no}", lines=[("2000", pay.amount, 0, None), ("1000", 0, pay.amount, None)])


@router.get("/supplier-balances")
def supplier_balances(p=Depends(require("finance.read")), db=Depends(get_db)):
    return mappings(db, """SELECT s.id, s.code, s.name, s.payment_terms_days,
          COALESCE(SUM(i.gross) FILTER (WHERE i.status IN ('matched','approved_for_payment')),0) payable,
          COALESCE(SUM(i.gross) FILTER (WHERE i.status IN ('matched','approved_for_payment') AND i.due_date < current_date),0) overdue,
          COALESCE(SUM(i.gross) FILTER (WHERE i.status IN ('received','exception')),0) unmatched_invoices,
          COALESCE(SUM(i.gross) FILTER (WHERE i.status='paid'),0) paid,
          (SELECT COALESCE(SUM((l.cases_received - l.cases_invoiced) * l.case_cost),0) FROM purchase_order_lines l JOIN purchase_orders po ON po.id=l.po_id WHERE po.supplier_id=s.id) received_not_invoiced
        FROM suppliers s LEFT JOIN supplier_invoices i ON i.supplier_id=s.id GROUP BY s.id ORDER BY s.name""")


# ---------------------------------------------------------------- cash and card reconciliation
class CashIn(BaseModel):
    site_id: int
    business_date: date
    counted: Decimal
    note: str | None = None


@router.get("/cash-reconciliations")
def cash_recs(p=Depends(require("finance.read")), db=Depends(get_db)):
    return mappings(db, f"""SELECT c.*, s.name site FROM cash_reconciliations c JOIN sites s ON s.id=c.site_id WHERE {SC.format(c='c.site_id')}
        ORDER BY c.business_date DESC, s.name""", **p.sql_sites("finance.read"))


def expected_cash(db, site_id, day):
    return db.execute(text("""SELECT COALESCE(SUM(CASE WHEN kind='refund' THEN -amount ELSE amount END),0) FROM payments
        WHERE site_id=:s AND method='cash' AND status='succeeded' AND at::date=:d"""), {"s": site_id, "d": day}).scalar()


@router.get("/cash-reconciliations/expected")
def cash_expected(site_id: int, business_date: date, p=Depends(require("finance.read")), db=Depends(get_db)):
    return {"expected": str(expected_cash(db, site_id, business_date)), "definition": "Cash sales less cash refunds recorded in the payments ledger for the store and date"}


@router.post("/cash-reconciliations")
def cash_rec(body: CashIn, p=Depends(require("finance.write")), db=Depends(get_db)):
    """Compare counted till cash with the ledger and bank it. A variance posts to cash over/short."""
    p.check("finance.write", body.site_id)
    if db.execute(select(CashReconciliation.id).where(CashReconciliation.site_id == body.site_id, CashReconciliation.business_date == body.business_date)).first():
        raise conflict("That store and date is already reconciled")
    exp = expected_cash(db, body.site_id, body.business_date)
    var = body.counted - exp
    c = CashReconciliation(site_id=body.site_id, business_date=body.business_date, expected=exp, counted=body.counted, variance=var,
                           status="balanced" if var == 0 else "variance", note=body.note, counted_by=p.user.id)
    db.add(c)
    db.flush()
    post_journal(db, entry_date=body.business_date, source_type="cash_reconciliation", source_id=c.id, posted_by=p.user.id,
                 description=f"Cash banked for {body.business_date}", lines=[
                     ("1000", body.counted, 0, body.site_id, "cash banked"), ("1010", 0, exp, body.site_id, "till cash cleared"),
                     ("6900", -var, 0, body.site_id, "cash over/short")])
    if abs(var) >= Decimal("5"):
        flag(db, "cash_variance", f"Cash variance of {var} on {body.business_date}", severity="medium", entity_type="cash_reconciliation",
             entity_id=c.id, site_id=body.site_id)
    audit(db, p, "cash.reconciled", "cash_reconciliation", c.id, {"variance": var})
    db.commit()
    return row(c)


class SettleIn(BaseModel):
    business_date: date


@router.get("/settlements")
def settlements(p=Depends(require("finance.read")), db=Depends(get_db)):
    return mappings(db, "SELECT * FROM settlements ORDER BY business_date DESC")


@router.post("/settlements/import")
def import_settlement(body: SettleIn, p=Depends(require("finance.write")), db=Depends(get_db)):
    """Pull the provider's settlement report for a date and reconcile it line by line against our own
    card payments. Cash is only recognised in the bank when the provider's file agrees with the ledger."""
    p.check("finance.write")
    rep = mocks.payments.settlement_report(db, body.business_date)
    if db.execute(select(Settlement.id).where(Settlement.batch_ref == rep["batch_ref"])).first():
        raise conflict("That settlement batch is already imported")
    ours = db.execute(select(Payment).where(Payment.method == "card", Payment.status == "succeeded", Payment.kind.in_(["sale", "capture", "refund"]),
                                            func.date(Payment.at) <= body.business_date, Payment.settlement_id.is_(None))).scalars().all()
    by_key = {}
    for pay in ours:
        by_key[(pay.provider_ref, pay.kind == "refund")] = pay
    unmatched, matched, refs = [], [], dict(rep["refs"])
    for ref, (kind, amount) in refs.items():
        pay = by_key.pop((ref, kind == "refund"), None)
        if pay is None or pay.amount != amount:
            unmatched.append({"provider_ref": ref, "kind": kind, "provider_amount": str(amount), "ledger_amount": str(pay.amount) if pay else None,
                              "issue": "not in our payments ledger for this period" if pay is None else "amount differs"})
        else:
            matched.append(pay)
    ledger_gross = sum((m.amount for m in matched if m.kind != "refund"), ZERO)
    ledger_refunds = sum((m.amount for m in matched if m.kind == "refund"), ZERO)
    s = Settlement(provider=rep["provider"], batch_ref=rep["batch_ref"], business_date=body.business_date, gross=rep["gross"], refunds=rep["refunds"],
                   fees=rep["fees"], net=rep["net"], ledger_gross=ledger_gross, difference=(rep["gross"] - rep["refunds"]) - (ledger_gross - ledger_refunds),
                   unmatched=unmatched, status="reconciled" if not unmatched else "exception")
    db.add(s)
    db.flush()
    for m in matched:
        m.settlement_id = s.id
    net_matched = ledger_gross - ledger_refunds
    fees = q2(ledger_gross * dec(get_setting(db, "finance.policy")["card_fee_rate"]))
    post_journal(db, entry_date=body.business_date + timedelta(days=int(get_setting(db, "finance.policy")["settlement_lag_days"])),
                 source_type="settlement", source_id=s.id, posted_by=p.user.id, description=f"Card settlement {s.batch_ref}", lines=[
                     ("1000", net_matched - fees, 0, None, "net settlement received"), ("6000", fees, 0, None, "processing fees"),
                     ("1020", 0, net_matched, None, "card receivable cleared")])
    s.posted_at = now()
    if unmatched:
        flag(db, "settlement_difference", f"Settlement {s.batch_ref}: {len(unmatched)} provider line(s) do not match the ledger", severity="high",
             entity_type="settlement", entity_id=s.id, detail=str(unmatched[:5]))
    audit(db, p, "settlement.imported", "settlement", s.id, {"matched": len(matched), "unmatched": len(unmatched)})
    db.commit()
    return row(s)


# ---------------------------------------------------------------- reports
@router.get("/budget-vs-actual")
def budget_vs_actual(p=Depends(require("finance.read")), db=Depends(get_db)):
    """Budget and actual for the current budget period, side by side. Actuals come from the journal."""
    return mappings(db, f"""
      WITH act AS (
        SELECT l.site_id,
          SUM(CASE WHEN a.code IN ('4000','4010','4020') THEN l.credit - l.debit ELSE 0 END) net_sales,
          SUM(CASE WHEN a.code IN ('4000','4010','4020') THEN l.credit - l.debit WHEN a.code='5000' THEN l.credit - l.debit ELSE 0 END) gross_margin,
          SUM(CASE WHEN a.code='5100' THEN l.debit - l.credit ELSE 0 END) waste,
          SUM(CASE WHEN a.code BETWEEN '6000' AND '6899' THEN l.debit - l.credit ELSE 0 END) operating_costs
        FROM journal_lines l JOIN journal_entries e ON e.id=l.entry_id JOIN accounts a ON a.id=l.account_id
        WHERE e.entry_date BETWEEN (SELECT MIN(period_start) FROM budgets) AND LEAST(current_date, (SELECT MAX(period_end) FROM budgets)) GROUP BY l.site_id)
      SELECT b.site_id, s.name site, b.metric, b.version, b.period_start, b.period_end,
        ROUND(b.amount * (LEAST(current_date, b.period_end) - b.period_start + 1) / (b.period_end - b.period_start + 1), 2) budget_to_date,
        b.amount budget_full_period,
        COALESCE(CASE b.metric WHEN 'net_sales' THEN act.net_sales WHEN 'gross_margin' THEN act.gross_margin WHEN 'waste' THEN act.waste ELSE act.operating_costs END, 0) actual_to_date
      FROM budgets b JOIN sites s ON s.id=b.site_id LEFT JOIN act ON act.site_id=b.site_id
      WHERE {SC.format(c='b.site_id')} ORDER BY s.name, b.metric""", **p.sql_sites("finance.read"))


@router.get("/working-capital")
def working_capital(p=Depends(require("finance.read")), db=Depends(get_db)):
    one = lambda sql: db.execute(text(sql)).scalar() or ZERO
    inv_value = one("SELECT SUM(b.qty*l.unit_cost) FROM stock_balances b JOIN lots l ON l.id=b.lot_id WHERE b.bucket IN ('available','reserved','in_transit','quarantined')")
    payables = one("SELECT SUM(gross) FROM supplier_invoices WHERE status IN ('matched','approved_for_payment')")
    grni = one("SELECT SUM(l.credit-l.debit) FROM journal_lines l JOIN accounts a ON a.id=l.account_id WHERE a.code='2010'")
    card = one("SELECT SUM(l.debit-l.credit) FROM journal_lines l JOIN accounts a ON a.id=l.account_id WHERE a.code='1020'")
    cogs28 = one("SELECT SUM(cost) FROM sales WHERE at >= now() - interval '14 days'")
    open_po = one("SELECT SUM((l.cases_ordered-l.cases_received-l.cases_damaged)*l.case_cost) FROM purchase_order_lines l JOIN purchase_orders p ON p.id=l.po_id WHERE p.status IN ('pending_approval','approved','part_received')")
    daily = cogs28 / 14 if cogs28 else ZERO
    return plain({"currency": "GBP", "as_at": now(), "items": [
        {"item": "Inventory at cost", "amount": q2(inv_value), "definition": "Sum of qty x lot unit cost for available, reserved, in-transit and quarantined stock", "source": "stock_balances, lots"},
        {"item": "Card receivable (unsettled)", "amount": q2(card), "definition": "Balance of account 1020: card takings not yet settled by the provider", "source": "journal_lines"},
        {"item": "Trade payables", "amount": q2(payables), "definition": "Matched supplier invoices not yet paid (gross)", "source": "supplier_invoices"},
        {"item": "Goods received not invoiced", "amount": q2(grni), "definition": "Balance of accrual account 2010", "source": "journal_lines"},
        {"item": "Open purchase commitments", "amount": q2(open_po), "definition": "Outstanding cases on open POs x case cost (not yet a liability)", "source": "purchase_order_lines"},
        {"item": "Net working capital (demo)", "amount": q2(inv_value + card - payables - grni), "definition": "Inventory + card receivable - payables - GRNI", "source": "derived from the rows above"},
        {"item": "Inventory days of cover", "amount": (inv_value / daily).quantize(Decimal("0.1")) if daily else None, "unit": "days",
         "definition": "Inventory at cost / average daily cost of goods sold over the last 14 days", "source": "stock_balances, sales"}]})


@router.get("/policies")
def policies(p=Depends(require("finance.read")), db=Depends(get_db)):
    return {"policy": get_setting(db, "finance.policy"), "note": "Configurable under Administration > Policies. Subject to review by Finance before any production use."}
