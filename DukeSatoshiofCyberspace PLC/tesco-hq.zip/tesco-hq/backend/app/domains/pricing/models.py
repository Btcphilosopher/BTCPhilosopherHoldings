from sqlalchemy import JSON, Boolean, Column, DateTime, Integer, String, Text, UniqueConstraint

from ...db import Base, Money, fk, pk, ts


class PriceBook(Base):
    """A scope for prices: national, a store format, or one site; for one channel or all."""
    __tablename__ = "price_books"
    id = pk()
    code = Column(String(40), unique=True, nullable=False)
    name = Column(String(160), nullable=False)
    scope_type = Column(String(12), nullable=False, default="national")  # national|format|site
    scope_id = Column(Integer)
    channel = Column(String(10), nullable=False, default="all")  # all|store|online
    active = Column(Boolean, nullable=False, default=True)


class PriceEntry(Base):
    """One version of a product's price in a book, with an effective period. Never edited in place."""
    __tablename__ = "price_entries"
    id = pk()
    price_book_id = fk("price_books.id", nullable=False)
    product_id = fk("products.id", nullable=False)
    price = Column(Money, nullable=False)  # VAT-inclusive shelf price per base unit
    effective_from = Column(DateTime(timezone=True), nullable=False)
    effective_to = Column(DateTime(timezone=True))
    status = Column(String(20), nullable=False, default="draft", index=True)
    # recommended|draft|pending_approval|approved|published|rejected|superseded
    version = Column(Integer, nullable=False, default=1)
    reason = Column(Text)
    created_by = Column(Integer)
    approved_by = Column(Integer)
    created_at = ts()
    published_at = Column(DateTime(timezone=True))


class Promotion(Base):
    __tablename__ = "promotions"
    id = pk()
    code = Column(String(40), unique=True, nullable=False)
    name = Column(String(200), nullable=False)
    kind = Column(String(20), nullable=False)  # percent_off|fixed_price|multibuy|loyalty_price|markdown
    params = Column(JSON, nullable=False, default=dict)
    channel = Column(String(10), nullable=False, default="all")
    site_ids = Column(JSON)          # null = all sites
    control_site_ids = Column(JSON)  # holdout stores for experimental evaluation
    lot_id = fk("lots.id")           # markdowns are tied to a short-dated lot
    starts_at = Column(DateTime(timezone=True), nullable=False)
    ends_at = Column(DateTime(timezone=True), nullable=False)
    priority = Column(Integer, nullable=False, default=10)
    stackable = Column(Boolean, nullable=False, default=False)
    max_qty_per_basket = Column(Integer)
    status = Column(String(20), nullable=False, default="draft", index=True)
    # draft|pending_approval|approved|published|ended|rejected
    created_by = Column(Integer)
    approved_by = Column(Integer)
    created_at = ts()
    published_at = Column(DateTime(timezone=True))
    notes = Column(Text)


class PromotionProduct(Base):
    __tablename__ = "promotion_products"
    id = pk()
    promotion_id = fk("promotions.id", nullable=False)
    product_id = fk("products.id", nullable=False)
    __table_args__ = (UniqueConstraint("promotion_id", "product_id"),)


class Coupon(Base):
    __tablename__ = "coupons"
    id = pk()
    code = Column(String(40), unique=True, nullable=False)
    description = Column(String(200))
    amount_off = Column(Money, nullable=False)
    min_spend = Column(Money, nullable=False, default=0)
    member_id = fk("loyalty_members.id")
    valid_to = Column(DateTime(timezone=True))
    status = Column(String(12), nullable=False, default="active")  # active|redeemed|void
    redeemed_sale_id = Column(Integer)
    redeemed_at = Column(DateTime(timezone=True))
    created_at = ts()


class PosTerminal(Base):
    __tablename__ = "pos_terminals"
    id = pk()
    site_id = fk("sites.id", nullable=False)
    code = Column(String(30), unique=True, nullable=False)
    kind = Column(String(16), nullable=False, default="till")  # till|self_checkout|ecommerce
    online = Column(Boolean, nullable=False, default=True)     # simulated connectivity


class PricePublication(Base):
    """Publication is not confirmation: one row per target endpoint tracks whether it acknowledged."""
    __tablename__ = "price_publications"
    id = pk()
    item_type = Column(String(12), nullable=False)  # price|promotion
    item_id = Column(Integer, nullable=False, index=True)
    terminal_id = fk("pos_terminals.id", nullable=False)
    status = Column(String(14), nullable=False, default="sent")  # sent|acknowledged|failed
    sent_at = ts()
    acknowledged_at = Column(DateTime(timezone=True))
    attempts = Column(Integer, nullable=False, default=0)
    last_error = Column(String(200))
    __table_args__ = (UniqueConstraint("item_type", "item_id", "terminal_id"),)
