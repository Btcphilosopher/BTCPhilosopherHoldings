from datetime import datetime
from decimal import Decimal

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import select

from ...cache import wake_worker
from ...common import audit, bad, get_or_404, mappings, now, plain, row, rows
from ...db import get_db
from ...security import require
from ..sales.api import BasketLine, resolve_lines
from ..sales.service import find_member
from . import service
from .engine import find_conflicts, price_basket
from .models import Coupon, PriceBook, PriceEntry, Promotion

router = APIRouter(prefix="/pricing", tags=["Pricing & promotions"])


@router.get("/policy")
def policy(p=Depends(require("pricing.read")), db=Depends(get_db)):
    from ...common import get_setting
    return get_setting(db, "pricing.policy")


@router.get("/price-books")
def books(p=Depends(require("pricing.read")), db=Depends(get_db)):
    return mappings(db, """SELECT b.*, COALESCE(s.name, f.name, 'All sites') scope_name,
        (SELECT COUNT(DISTINCT product_id) FROM price_entries e WHERE e.price_book_id=b.id AND e.status='published') products
        FROM price_books b LEFT JOIN sites s ON b.scope_type='site' AND s.id=b.scope_id
        LEFT JOIN store_formats f ON b.scope_type='format' AND f.id=b.scope_id ORDER BY b.id""")


@router.get("/prices")
def prices(price_book_id: int | None = None, status: str | None = None, q: str | None = None, p=Depends(require("pricing.read")), db=Depends(get_db)):
    return mappings(db, """
        SELECT e.*, b.code price_book, b.channel, pr.sku, pr.name product, pr.price_floor, t.rate tax_rate,
          (SELECT ROUND(sp.case_cost / pr.case_size, 4) FROM supplier_products sp WHERE sp.product_id=pr.id AND sp.is_primary LIMIT 1) unit_cost,
          (e.status='published' AND e.effective_from <= now() AND (e.effective_to IS NULL OR e.effective_to > now())
             AND NOT EXISTS (SELECT 1 FROM price_entries n WHERE n.price_book_id=e.price_book_id AND n.product_id=e.product_id
                 AND n.status='published' AND n.effective_from <= now() AND (n.effective_from, n.id) > (e.effective_from, e.id))) is_current,
          (SELECT COUNT(*) FROM price_publications x WHERE x.item_type='price' AND x.item_id=e.id) endpoints,
          (SELECT COUNT(*) FROM price_publications x WHERE x.item_type='price' AND x.item_id=e.id AND x.status='acknowledged') endpoints_confirmed
        FROM price_entries e JOIN price_books b ON b.id=e.price_book_id JOIN products pr ON pr.id=e.product_id
        JOIN tax_categories t ON t.id=pr.tax_category_id
        WHERE (:b IS NULL OR e.price_book_id=:b) AND (:st IS NULL OR e.status=:st) AND (:q IS NULL OR pr.name ILIKE :q OR pr.sku ILIKE :q)
        ORDER BY pr.sku, b.id, e.effective_from DESC LIMIT 1500""", b=price_book_id, st=status, q=f"%{q}%" if q else None)


class PriceIn(BaseModel):
    price_book_id: int
    product_id: int
    price: Decimal
    effective_from: datetime | None = None
    effective_to: datetime | None = None
    reason: str


@router.post("/prices")
def propose(body: PriceIn, p=Depends(require("pricing.write")), db=Depends(get_db)):
    book = get_or_404(db, PriceBook, body.price_book_id)
    p.check("pricing.write", book.scope_id if book.scope_type == "site" else None)
    e = service.propose_price(db, p, price_book_id=book.id, product_id=body.product_id, price=body.price,
                              effective_from=body.effective_from or now(), effective_to=body.effective_to, reason=body.reason)
    audit(db, p, "price.proposed", "price_entry", e.id, plain(body.model_dump()))
    db.commit()
    return row(e)


@router.post("/prices/{entry_id}/publish")
def publish(entry_id: int, p=Depends(require("pricing.approve")), db=Depends(get_db)):
    e = get_or_404(db, PriceEntry, entry_id)
    p.check("pricing.approve")
    service.publish_price(db, p, e)
    audit(db, p, "price.published", "price_entry", e.id, {"price": e.price, "effective_from": e.effective_from})
    db.commit()
    wake_worker()
    return row(e)


@router.get("/publications")
def publications(status: str | None = None, p=Depends(require("pricing.read")), db=Depends(get_db)):
    """Publication status per endpoint. 'published' is the intent; 'acknowledged' is the confirmation."""
    return mappings(db, """SELECT x.*, t.code terminal, t.kind terminal_kind, t.online, s.name site,
          CASE x.item_type WHEN 'price' THEN (SELECT pr.sku || ' @ ' || e.price FROM price_entries e JOIN products pr ON pr.id=e.product_id WHERE e.id=x.item_id)
               ELSE (SELECT code FROM promotions WHERE id=x.item_id) END item
        FROM price_publications x JOIN pos_terminals t ON t.id=x.terminal_id JOIN sites s ON s.id=t.site_id
        WHERE (:st IS NULL OR x.status=:st) ORDER BY (x.status='acknowledged'), x.id DESC LIMIT 500""", st=status)


@router.post("/publications/retry")
def retry(p=Depends(require("pricing.approve")), db=Depends(get_db)):
    out = service.deliver_publications(db)
    audit(db, p, "price.publication_retry", detail=out)
    db.commit()
    return out


@router.get("/recommendations")
def recommendations(p=Depends(require("pricing.read")), db=Depends(get_db)):
    """Advisory only. A recommendation changes nothing until someone proposes it and another person approves it."""
    low_margin = mappings(db, """
        SELECT pr.id product_id, pr.sku, pr.name product, e.price, t.rate tax_rate, ROUND(sp.case_cost / pr.case_size, 4) unit_cost,
               ROUND(100 * (e.price/(1+t.rate) - sp.case_cost/pr.case_size) / NULLIF(e.price/(1+t.rate),0), 1) margin_pct, e.price_book_id
        FROM price_entries e JOIN price_books b ON b.id=e.price_book_id AND b.scope_type='national' AND b.channel='all'
        JOIN products pr ON pr.id=e.product_id JOIN tax_categories t ON t.id=pr.tax_category_id
        JOIN supplier_products sp ON sp.product_id=pr.id AND sp.is_primary
        WHERE e.status='published' AND e.effective_from <= now() AND (e.effective_to IS NULL OR e.effective_to > now())
          AND NOT EXISTS (SELECT 1 FROM price_entries n WHERE n.price_book_id=e.price_book_id AND n.product_id=e.product_id AND n.status='published'
                AND n.effective_from <= now() AND (n.effective_from, n.id) > (e.effective_from, e.id))
          AND (e.price/(1+t.rate) - sp.case_cost/pr.case_size) / NULLIF(e.price/(1+t.rate),0) < 0.15 ORDER BY 7""")
    for r in low_margin:
        r.update(kind="margin_review", rationale=f"Net margin {r['margin_pct']}% is below the 15% review line (price ex-VAT vs current primary supplier cost).",
                 basis="published national price entry and primary supplier case cost")
    short = mappings(db, """
        SELECT b.site_id, s.name site, l.id lot_id, l.lot_code, l.expiry_date, pr.id product_id, pr.sku, pr.name product, SUM(b.qty) qty,
               (l.expiry_date - current_date) days_left
        FROM stock_balances b JOIN lots l ON l.id=b.lot_id JOIN products pr ON pr.id=b.product_id JOIN sites s ON s.id=b.site_id
        WHERE b.bucket='available' AND b.qty>0 AND s.kind='store' AND l.expiry_date BETWEEN current_date AND current_date + 2
          AND NOT EXISTS (SELECT 1 FROM promotions m WHERE m.lot_id=l.id AND m.status IN ('pending_approval','approved','published'))
        GROUP BY b.site_id, s.name, l.id, pr.id ORDER BY l.expiry_date LIMIT 50""")
    for r in short:
        r.update(kind="short_dated_markdown", suggested_pct=30 if r["days_left"] >= 1 else 50,
                 rationale=f"{r['qty']} units expire in {r['days_left']} day(s); a lot-specific markdown may avoid waste.",
                 basis="stock_balances and lot expiry date")
    return {"note": "Recommendations are suggestions. Use 'Propose' to start the approval workflow.", "margin_review": low_margin, "short_dated": short}


class PromoIn(BaseModel):
    code: str
    name: str
    kind: str
    params: dict
    product_ids: list[int]
    starts_at: datetime
    ends_at: datetime
    channel: str = "all"
    site_ids: list[int] | None = None
    control_site_ids: list[int] | None = None
    priority: int = 10
    stackable: bool = False
    max_qty_per_basket: int | None = None
    lot_id: int | None = None
    notes: str | None = None


@router.get("/promotions")
def promotions(status: str | None = None, p=Depends(require("pricing.read")), db=Depends(get_db)):
    return mappings(db, """SELECT m.*, (SELECT string_agg(pr.sku || ' ' || pr.name, '; ') FROM promotion_products pp JOIN products pr ON pr.id=pp.product_id WHERE pp.promotion_id=m.id) products,
          (SELECT COUNT(*) FROM price_publications x WHERE x.item_type='promotion' AND x.item_id=m.id) endpoints,
          (SELECT COUNT(*) FROM price_publications x WHERE x.item_type='promotion' AND x.item_id=m.id AND x.status='acknowledged') endpoints_confirmed,
          (m.status='published' AND m.starts_at <= now() AND m.ends_at > now()) live
        FROM promotions m WHERE (:st IS NULL OR m.status=:st) ORDER BY m.id DESC""", st=status)


@router.post("/promotions")
def create_promo(body: PromoIn, p=Depends(require("pricing.write")), db=Depends(get_db)):
    p.check("pricing.write")
    promo, conflicts = service.create_promotion(db, p, **body.model_dump())
    audit(db, p, "promotion.proposed", "promotion", promo.id, {"code": promo.code, "conflicts": conflicts})
    db.commit()
    return {"promotion": row(promo), "conflicts": conflicts}


@router.get("/promotions/{promo_id}/conflicts")
def conflicts(promo_id: int, p=Depends(require("pricing.read")), db=Depends(get_db)):
    return find_conflicts(db, get_or_404(db, Promotion, promo_id))


@router.post("/promotions/{promo_id}/publish")
def publish_promo(promo_id: int, p=Depends(require("pricing.approve")), db=Depends(get_db)):
    p.check("pricing.approve")
    promo = get_or_404(db, Promotion, promo_id)
    service.publish_promotion(db, p, promo)
    audit(db, p, "promotion.published", "promotion", promo.id)
    db.commit()
    wake_worker()
    return row(promo)


@router.get("/coupons")
def coupons(p=Depends(require("pricing.read", "loyalty.read")), db=Depends(get_db)):
    return mappings(db, "SELECT c.*, m.member_no FROM coupons c LEFT JOIN loyalty_members m ON m.id=c.member_id ORDER BY c.id DESC")


class SimIn(BaseModel):
    site_id: int
    channel: str = "store"
    terminal_id: int | None = None
    lines: list[BasketLine]
    member: str | None = None
    coupon_codes: list[str] = []
    at: datetime | None = None


@router.post("/simulate")
def simulate(body: SimIn, p=Depends(require("pricing.read")), db=Depends(get_db)):
    """Price a basket without selling it. Read-only; returns the full rule trace."""
    return plain(price_basket(db, site_id=body.site_id, channel=body.channel, lines=resolve_lines(db, body.lines), at=body.at,
                              member_id=find_member(db, body.member), coupon_codes=body.coupon_codes, terminal_id=body.terminal_id))
