"""Price calculation engine.

Pure function of stored, *published* price entries and promotions - it never invents a price and it
returns a full trace of which rule produced every penny. The same engine serves the tills, the online
channel and the simulator, so what the simulator shows is what a basket would be charged.

Precedence (configurable description in settings 'pricing.policy'):
  1. Base price: most specific published price book (site > format > national; channel-specific beats 'all'),
     then latest effective_from. A terminal that has not acknowledged a publication keeps its last confirmed price.
  2. Short-dated markdown on the scanned lot - replaces all other item promotions for those units.
  3. Exclusive promotions by priority (highest first). Within one priority the best customer saving wins,
     ties broken by lowest promotion id. Units consumed by one exclusive promotion are not discounted again.
  4. Stackable percentage promotions, applied to the already-discounted line.
  5. Product price floor - a discount can never take the unit price below it.
  6. Basket coupons (default one per basket), spread pro-rata over lines.
Prices are never individualised by personal characteristics: inputs are product, place, channel, time,
membership (yes/no) and presented coupons only."""
from collections import defaultdict
from decimal import Decimal

from sqlalchemy import select

from ...common import ZERO, bad, dec, get_setting, now, q2
from ..catalog.models import Product, TaxCategory
from ..finance.service import tax_split
from ..org.models import Site
from .models import Coupon, PriceBook, PriceEntry, PricePublication, Promotion, PromotionProduct

MARKDOWN_PRIORITY = 1000


def _unconfirmed(db, terminal_id):
    if not terminal_id:
        return set()
    return {(t, i) for t, i in db.execute(select(PricePublication.item_type, PricePublication.item_id).where(
        PricePublication.terminal_id == terminal_id, PricePublication.status != "acknowledged"))}


def base_prices(db, product_ids, site, channel, at, unconfirmed=frozenset()):
    """-> {product_id: (PriceEntry, PriceBook, [notes])}"""
    q = (select(PriceEntry, PriceBook).join(PriceBook, PriceBook.id == PriceEntry.price_book_id)
         .where(PriceEntry.product_id.in_(product_ids), PriceEntry.status == "published",
                PriceEntry.effective_from <= at, PriceBook.active.is_(True), PriceBook.channel.in_([channel, "all"])))
    best, notes = {}, defaultdict(list)
    for e, b in db.execute(q):
        if e.effective_to and e.effective_to <= at:
            continue
        if b.scope_type == "site" and b.scope_id != site.id:
            continue
        if b.scope_type == "format" and b.scope_id != site.format_id:
            continue
        if ("price", e.id) in unconfirmed:
            notes[e.product_id].append(f"Price entry #{e.id} ({e.price}) is published but not yet acknowledged by this terminal - not applied")
            continue
        rank = ({"site": 3, "format": 2, "national": 1}[b.scope_type], 1 if b.channel != "all" else 0,
                e.effective_from, e.id)
        if e.product_id not in best or rank > best[e.product_id][0]:
            best[e.product_id] = (rank, e, b)
    return {pid: (e, b, notes[pid]) for pid, (_, e, b) in best.items()}


def active_promotions(db, product_ids, site_id, channel, at, unconfirmed=frozenset()):
    q = (select(Promotion, PromotionProduct.product_id).join(PromotionProduct, PromotionProduct.promotion_id == Promotion.id)
         .where(PromotionProduct.product_id.in_(product_ids), Promotion.status == "published",
                Promotion.starts_at <= at, Promotion.ends_at > at, Promotion.channel.in_([channel, "all"])))
    promos, members = {}, defaultdict(set)
    for p, pid in db.execute(q):
        if p.site_ids and site_id not in p.site_ids:
            continue
        if ("promotion", p.id) in unconfirmed:
            continue
        promos[p.id] = p
        members[p.id].add(pid)
    return promos, members


def _unit_saving(promo, base, is_member):
    """Saving per unit for a simple promotion, or (None, reason) if it does not apply."""
    k, prm = promo.kind, promo.params or {}
    if k in ("percent_off", "markdown"):
        return q2(base * dec(prm["pct"]) / 100), None
    if k == "loyalty_price" and not is_member:
        return None, "loyalty price requires a member card"
    if k in ("fixed_price", "loyalty_price"):
        s = base - dec(prm["price"])
        return (s, None) if s > 0 else (None, "promotional price is not below the base price")
    return None, "not a unit-price promotion"


def price_basket(db, *, site_id, channel="store", lines, at=None, member_id=None, coupon_codes=(), terminal_id=None):
    at = at or now()
    site = db.get(Site, site_id)
    if not site:
        raise bad("Unknown site")
    pids = [l["product_id"] for l in lines]
    products = {p.id: p for p in db.execute(select(Product).where(Product.id.in_(pids))).scalars()}
    rates = {t.id: t.rate for t in db.execute(select(TaxCategory)).scalars()}
    unconfirmed = _unconfirmed(db, terminal_id)
    bases = base_prices(db, pids, site, channel, at, unconfirmed)
    promos, promo_products = active_promotions(db, pids, site_id, channel, at, unconfirmed)
    rules = []

    L = []
    for i, ln in enumerate(lines):
        p = products.get(ln["product_id"])
        if not p:
            raise bad(f"Unknown product id {ln['product_id']}")
        if p.status != "active":
            raise bad(f"{p.sku} is {p.status} and cannot be sold", "product_not_sellable")
        if p.id not in bases:
            raise bad(f"No published price for {p.sku} at {site.code} on channel '{channel}'", "no_price")
        qty = dec(ln["qty"])
        if qty <= 0 or (not p.is_weighted and qty != qty.to_integral_value()):
            raise bad(f"Invalid quantity {qty} for {p.sku}")
        e, b, notes = bases[p.id]
        gross_before = q2(e.price * qty)
        L.append({"i": i, "p": p, "qty": qty, "lot_id": ln.get("lot_id"), "base": e.price, "entry": e, "book": b,
                  "gross_before": gross_before, "discount": ZERO, "remaining": qty, "applied": [], "rejected": [],
                  "floor": False})
        rules.append(f"{p.sku}: base price {e.price} from price book '{b.code}' (entry #{e.id} v{e.version}, "
                     f"effective {e.effective_from.date()}) x {qty} = {gross_before}")
        rules.extend(f"{p.sku}: {n}" for n in notes)

    def apply(line, promo, saving, units, note):
        saving = q2(saving)
        if saving <= 0:
            return
        line["discount"] += saving
        line["remaining"] -= units
        line["applied"].append({"promotion_id": promo.id, "code": promo.code, "name": promo.name, "kind": promo.kind,
                                "units": units, "saving": saving, "note": note})
        rules.append(f"{line['p'].sku}: {promo.code} ({promo.kind}) on {units} unit(s) saves {saving} - {note}")

    def reject(line, promo, reason):
        line["rejected"].append({"promotion_id": promo.id, "code": promo.code, "name": promo.name, "reason": reason})
        rules.append(f"{line['p'].sku}: {promo.code} not applied - {reason}")

    def prio(pr):
        return MARKDOWN_PRIORITY if pr.kind == "markdown" else pr.priority

    exclusive = [p for p in promos.values() if not p.stackable]
    for tier in sorted({prio(p) for p in exclusive}, reverse=True):
        tier_promos = sorted((p for p in exclusive if prio(p) == tier), key=lambda p: p.id)
        # multibuy first within the tier: "N for X", mix-and-match across the promotion's products
        for pr in (p for p in tier_promos if p.kind == "multibuy"):
            n, price = int(pr.params["buy_qty"]), dec(pr.params["for_price"])
            units = []
            for ln in L:
                if ln["p"].id in promo_products[pr.id] and not ln["p"].is_weighted:
                    units += [ln] * int(ln["remaining"])
            if pr.max_qty_per_basket:
                units = units[: pr.max_qty_per_basket]
            units.sort(key=lambda l: (-l["base"], l["i"]))
            groups = len(units) // n
            if groups == 0:
                for ln in {id(u): u for u in units}.values():
                    reject(ln, pr, f"needs {n} qualifying items, basket has {len(units)}")
                continue
            for g in range(groups):
                chunk = units[g * n:(g + 1) * n]
                total = sum(u["base"] for u in chunk)
                saving = total - price
                if saving <= 0:
                    continue
                per, left = defaultdict(lambda: [ZERO, 0]), saving
                for j, u in enumerate(chunk):
                    s = left if j == len(chunk) - 1 else q2(saving * u["base"] / total)
                    left -= s
                    per[u["i"]][0] += s
                    per[u["i"]][1] += 1
                for idx, (s, cnt) in per.items():
                    apply(L[idx], pr, s, cnt, f"{n} for {price}")
        simple = [p for p in tier_promos if p.kind != "multibuy"]
        for ln in L:
            cands = []
            for pr in simple:
                if ln["p"].id not in promo_products[pr.id]:
                    continue
                if pr.kind == "markdown" and pr.lot_id != ln["lot_id"]:
                    reject(ln, pr, "markdown applies only to the short-dated lot, which was not scanned")
                    continue
                s, why = _unit_saving(pr, ln["base"], member_id is not None)
                if s is None:
                    reject(ln, pr, why)
                    continue
                cands.append((s, pr))
            if not cands:
                continue
            cands.sort(key=lambda c: (-c[0], c[1].id))
            if ln["remaining"] <= 0:
                for _, pr in cands:
                    reject(ln, pr, "all units already discounted by a higher-priority promotion")
                continue
            s, win = cands[0]
            units = ln["remaining"]
            if win.max_qty_per_basket:
                units = min(units, dec(win.max_qty_per_basket))
            apply(ln, win, s * units, units, f"priority {tier}" + (f", limit {win.max_qty_per_basket} per basket" if win.max_qty_per_basket else ""))
            for s2, pr in cands[1:]:
                reject(ln, pr, f"conflicts with {win.code} at the same priority; {win.code} gives the better or equal saving ({s} vs {s2} per unit)")

    for pr in sorted((p for p in promos.values() if p.stackable), key=lambda p: (-p.priority, p.id)):
        for ln in L:
            if ln["p"].id in promo_products[pr.id]:
                if pr.kind != "percent_off":
                    reject(ln, pr, "only percentage promotions may be stackable")
                    continue
                s = q2((ln["gross_before"] - ln["discount"]) * dec(pr.params["pct"]) / 100)
                ln["remaining"] = ln["qty"]
                apply(ln, pr, s, ln["qty"], "stackable, applied after exclusive promotions")

    for ln in L:
        floor = ln["p"].price_floor
        if floor is not None and ln["discount"] > 0:
            min_gross = q2(floor * ln["qty"])
            if ln["gross_before"] - ln["discount"] < min_gross:
                ln["discount"] = max(ZERO, ln["gross_before"] - min_gross)
                ln["floor"] = True
                rules.append(f"{ln['p'].sku}: price floor {floor} applied - discount capped at {ln['discount']}")

    coupons_out = []
    limit = int(get_setting(db, "pricing.policy").get("coupons_per_basket", 1))
    used = 0
    for code in coupon_codes or ():
        c = db.execute(select(Coupon).where(Coupon.code == code)).scalar_one_or_none()
        basket = sum(l["gross_before"] - l["discount"] for l in L)
        reason = None
        if not c:
            reason = "unknown coupon"
        elif c.status != "active":
            reason = f"coupon already {c.status}"
        elif c.valid_to and c.valid_to <= at:
            reason = "coupon expired"
        elif c.member_id and c.member_id != member_id:
            reason = "coupon belongs to a different member"
        elif basket < c.min_spend:
            reason = f"minimum spend {c.min_spend} not met (basket {basket})"
        elif used >= limit:
            reason = f"limit of {limit} coupon(s) per basket"
        if reason:
            coupons_out.append({"code": code, "status": "rejected", "reason": reason, "saving": ZERO})
            rules.append(f"Coupon {code} not applied - {reason}")
            continue
        saving, left = min(c.amount_off, basket), min(c.amount_off, basket)
        eligible = [l for l in L if l["gross_before"] - l["discount"] > 0]
        for j, ln in enumerate(eligible):
            lg = ln["gross_before"] - ln["discount"]
            s = left if j == len(eligible) - 1 else min(lg, q2(saving * lg / basket))
            s = min(s, lg)
            left -= s
            ln["discount"] += s
            ln["applied"].append({"coupon": code, "kind": "coupon", "saving": s, "units": ln["qty"], "note": "basket coupon share"})
        used += 1
        coupons_out.append({"code": code, "status": "applied", "saving": saving - left, "reason": None})
        rules.append(f"Coupon {code} applied: {saving - left} off the basket, spread pro-rata across lines")

    out_lines, tot = [], defaultdict(lambda: ZERO)
    for ln in L:
        p = ln["p"]
        gross = ln["gross_before"] - ln["discount"]
        rate = rates[p.tax_category_id]
        net, tax = tax_split(gross, rate)
        out_lines.append({
            "product_id": p.id, "sku": p.sku, "description": p.name, "product_version": p.version, "qty": ln["qty"],
            "uom": p.base_uom, "lot_id": ln["lot_id"], "base_unit_price": ln["base"],
            "price_source": {"price_book": ln["book"].code, "scope": ln["book"].scope_type, "entry_id": ln["entry"].id,
                             "version": ln["entry"].version},
            "gross_before_discount": ln["gross_before"], "discount": ln["discount"], "gross": gross, "tax_rate": rate,
            "net": net, "tax": tax, "applied": ln["applied"], "rejected": ln["rejected"], "floor_applied": ln["floor"]})
        for k, v in (("gross_before_discount", ln["gross_before"]), ("discount", ln["discount"]), ("gross", gross),
                     ("net", net), ("tax", tax)):
            tot[k] += v
    rules.append(f"VAT is included in shelf prices; tax per line = gross - round_half_up(gross / (1 + rate)). "
                 f"Basket total {tot['gross']} = net {tot['net']} + VAT {tot['tax']}")
    return {"currency": "GBP", "site_id": site_id, "site": site.code, "channel": channel, "at": at,
            "member": member_id is not None, "lines": out_lines, "coupons": coupons_out,
            "totals": {k: tot[k] for k in ("gross_before_discount", "discount", "gross", "net", "tax")}, "rules": rules}


def find_conflicts(db, promo: Promotion):
    """Other live/approved exclusive promotions overlapping this one on product, time, channel and site."""
    pids = set(db.execute(select(PromotionProduct.product_id).where(PromotionProduct.promotion_id == promo.id)).scalars())
    q = (select(Promotion, PromotionProduct.product_id).join(PromotionProduct, PromotionProduct.promotion_id == Promotion.id)
         .where(Promotion.id != promo.id, Promotion.status.in_(["approved", "published"]), Promotion.stackable.is_(False),
                Promotion.starts_at < promo.ends_at, Promotion.ends_at > promo.starts_at,
                PromotionProduct.product_id.in_(pids or {-1})))
    out = defaultdict(set)
    for other, pid in db.execute(q):
        if promo.channel != "all" and other.channel != "all" and promo.channel != other.channel:
            continue
        if promo.site_ids and other.site_ids and not set(promo.site_ids) & set(other.site_ids):
            continue
        out[other].add(pid)
    return [{"promotion_id": o.id, "code": o.code, "priority": o.priority, "product_ids": sorted(p),
             "resolution": ("higher priority wins" if o.priority != promo.priority else "same priority: best customer saving wins")}
            for o, p in out.items()]
