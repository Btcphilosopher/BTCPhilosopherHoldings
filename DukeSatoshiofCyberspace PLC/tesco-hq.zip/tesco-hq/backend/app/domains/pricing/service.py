"""Price and promotion lifecycle: recommend -> propose -> approve -> publish -> confirm per endpoint."""
from decimal import Decimal

from sqlalchemy import select, text

from ...adapters import mocks
from ...common import ZERO, bad, conflict, dec, emit, flag, get_setting, now, plain
from ..catalog.models import Product
from ..platform import approvals
from .engine import find_conflicts
from .models import PosTerminal, PriceBook, PriceEntry, PricePublication, Promotion, PromotionProduct


def current_entry(db, book_id, product_id):
    return db.execute(select(PriceEntry).where(PriceEntry.price_book_id == book_id, PriceEntry.product_id == product_id,
                                               PriceEntry.status == "published", PriceEntry.effective_from <= now())
                      .order_by(PriceEntry.effective_from.desc(), PriceEntry.id.desc())).scalars().first()


def propose_price(db, p, *, price_book_id, product_id, price, effective_from, effective_to=None, reason=None):
    book, prod = db.get(PriceBook, price_book_id), db.get(Product, product_id)
    if not book or not prod:
        raise bad("Unknown price book or product")
    price = dec(price)
    if price <= 0:
        raise bad("Price must be positive")
    if prod.price_floor is not None and price < prod.price_floor:
        raise bad(f"Price {price} is below the product floor {prod.price_floor}", "below_floor")
    cur = current_entry(db, book.id, prod.id)
    last_v = db.execute(text("SELECT COALESCE(MAX(version),0) FROM price_entries WHERE price_book_id=:b AND product_id=:p"),
                        {"b": book.id, "p": prod.id}).scalar()
    change = abs(price - cur.price) / cur.price * 100 if cur else Decimal(100)
    threshold = dec(get_setting(db, "pricing.policy")["approval_threshold_pct"])
    e = PriceEntry(price_book_id=book.id, product_id=prod.id, price=price, effective_from=effective_from, effective_to=effective_to,
                   version=last_v + 1, reason=reason, created_by=p.user.id, status="pending_approval")
    db.add(e)
    db.flush()
    site_id = book.scope_id if book.scope_type == "site" else None
    if change >= threshold:
        approvals.request(db, p, "price_change", f"{prod.sku} {prod.name}: {cur.price if cur else 'new'} -> {price} in {book.code} "
                          f"({change.quantize(Decimal('0.1'))}% change) from {effective_from:%Y-%m-%d}", "pricing.approve",
                          entity_type="price_entry", entity_id=e.id, site_id=site_id, amount=price,
                          payload=plain({"old": cur.price if cur else None, "new": price, "change_pct": change}))
    else:
        e.status = "approved"   # below the materiality threshold: no second approver required, still audited
        e.approved_by = None
    db.flush()
    return e


@approvals.handler("price_change")
def _price_decided(db, a, p, approve):
    e = db.get(PriceEntry, a.entity_id)
    e.status, e.approved_by = ("approved" if approve else "rejected"), p.user.id


def _targets(db, site_ids=None, channel="all"):
    q = select(PosTerminal)
    if site_ids:
        q = q.where(PosTerminal.site_id.in_(site_ids))
    out = []
    for t in db.execute(q).scalars():
        if channel == "store" and t.kind == "ecommerce":
            continue
        if channel == "online" and t.kind != "ecommerce":
            continue
        out.append(t)
    return out


def _publish(db, item_type, item_id, terminals):
    """Create one publication row per endpoint and hand off to the POS gateway through the outbox.
    Status stays 'sent' until the endpoint acknowledges."""
    for t in terminals:
        db.execute(text("INSERT INTO price_publications (item_type, item_id, terminal_id, status, attempts) "
                        "VALUES (:t, :i, :term, 'sent', 0) ON CONFLICT DO NOTHING"), {"t": item_type, "i": item_id, "term": t.id})
    emit(db, "price.published", f"{item_type}:{item_id}", {"item_type": item_type, "item_id": item_id})


def publish_price(db, p, entry):
    if entry.status != "approved":
        raise conflict(f"Only approved prices can be published (status: {entry.status})")
    book = db.get(PriceBook, entry.price_book_id)
    sites = None
    if book.scope_type == "site":
        sites = [book.scope_id]
    elif book.scope_type == "format":
        sites = [r[0] for r in db.execute(text("SELECT id FROM sites WHERE format_id=:f"), {"f": book.scope_id})]
    entry.status, entry.published_at = "published", now()
    _publish(db, "price", entry.id, _targets(db, sites, book.channel))
    db.flush()
    return entry


def deliver_publications(db, item_type=None, item_id=None):
    """Called by the worker (and on demand): push pending publications to endpoints and record acks."""
    q = select(PricePublication).where(PricePublication.status != "acknowledged")
    if item_type:
        q = q.where(PricePublication.item_type == item_type, PricePublication.item_id == item_id)
    acked = failed = 0
    for pub in db.execute(q.with_for_update(skip_locked=True)).scalars():
        t = db.get(PosTerminal, pub.terminal_id)
        ok, msg = mocks.pos.push(t.code, t.online, pub.item_type, pub.item_id)
        pub.attempts += 1
        if ok:
            pub.status, pub.acknowledged_at, pub.last_error = "acknowledged", now(), None
            acked += 1
            db.execute(text("UPDATE exceptions SET status='resolved', resolved_at=now(), resolution='Terminal acknowledged' "
                            "WHERE dedupe_key=:k AND status='open'"), {"k": f"pub:{pub.id}"})
        else:
            pub.status, pub.last_error = "failed", msg
            failed += 1
            flag(db, "price_not_confirmed", f"Terminal {t.code} has not confirmed {pub.item_type} #{pub.item_id}", severity="medium",
                 entity_type="price_publication", entity_id=pub.id, site_id=t.site_id, dedupe=f"pub:{pub.id}",
                 detail=f"{msg}. The till keeps charging its last confirmed price until it acknowledges.")
    db.flush()
    return {"acknowledged": acked, "failed": failed}


def create_promotion(db, p, *, code, name, kind, params, product_ids, starts_at, ends_at, channel="all", site_ids=None,
                     control_site_ids=None, priority=10, stackable=False, max_qty_per_basket=None, lot_id=None, notes=None):
    if kind not in ("percent_off", "fixed_price", "multibuy", "loyalty_price", "markdown"):
        raise bad("Unknown promotion kind")
    if kind in ("percent_off", "markdown") and not (0 < dec(params.get("pct", 0)) < 100):
        raise bad("params.pct must be between 0 and 100")
    if kind in ("fixed_price", "loyalty_price") and dec(params.get("price", 0)) <= 0:
        raise bad("params.price is required")
    if kind == "multibuy" and (int(params.get("buy_qty", 0)) < 2 or dec(params.get("for_price", 0)) <= 0):
        raise bad("params.buy_qty (>=2) and params.for_price are required")
    if kind == "markdown" and not lot_id:
        raise bad("A markdown must name the short-dated lot")
    if ends_at <= starts_at or not product_ids:
        raise bad("Promotion needs products and a valid period")
    if db.execute(select(Promotion.id).where(Promotion.code == code)).first():
        raise conflict("Promotion code already exists")
    for prod in db.execute(select(Product).where(Product.id.in_(product_ids))).scalars():
        if prod.price_floor is not None and kind in ("fixed_price", "loyalty_price") and dec(params["price"]) < prod.price_floor:
            raise bad(f"Promotional price is below the floor ({prod.price_floor}) for {prod.sku}", "below_floor")
    promo = Promotion(code=code, name=name, kind=kind, params=plain(params), channel=channel, site_ids=site_ids,
                      control_site_ids=control_site_ids, starts_at=starts_at, ends_at=ends_at, priority=priority,
                      stackable=stackable, max_qty_per_basket=max_qty_per_basket, lot_id=lot_id, notes=notes,
                      created_by=p.user.id, status="pending_approval")
    db.add(promo)
    db.flush()
    for pid in set(product_ids):
        db.add(PromotionProduct(promotion_id=promo.id, product_id=pid))
    db.flush()
    conflicts = find_conflicts(db, promo)
    approvals.request(db, p, "promotion", f"Promotion {code}: {name} ({kind}) {starts_at:%d %b} - {ends_at:%d %b}"
                      + (f" - overlaps {len(conflicts)} other promotion(s)" if conflicts else ""), "pricing.approve",
                      entity_type="promotion", entity_id=promo.id, payload={"conflicts": conflicts})
    if conflicts:
        flag(db, "promotion_conflict", f"{code} overlaps {', '.join(c['code'] for c in conflicts)} on the same products and dates",
             severity="medium", entity_type="promotion", entity_id=promo.id, dedupe=f"promo:{promo.id}",
             detail="; ".join(f"{c['code']} (priority {c['priority']}): {c['resolution']}" for c in conflicts))
    return promo, conflicts


@approvals.handler("promotion")
def _promo_decided(db, a, p, approve):
    promo = db.get(Promotion, a.entity_id)
    promo.status, promo.approved_by = ("approved" if approve else "rejected"), p.user.id


def publish_promotion(db, p, promo):
    if promo.status != "approved":
        raise conflict(f"Only approved promotions can be published (status: {promo.status})")
    promo.status, promo.published_at = "published", now()
    _publish(db, "promotion", promo.id, _targets(db, promo.site_ids, promo.channel))
    db.flush()
    return promo
