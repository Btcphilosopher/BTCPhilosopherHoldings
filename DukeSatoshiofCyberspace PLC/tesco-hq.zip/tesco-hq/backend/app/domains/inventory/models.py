from sqlalchemy import JSON, CheckConstraint, Column, Date, DateTime, Integer, String, Text, UniqueConstraint

from ...db import Base, Cost, Qty, fk, pk, ts

# Disjoint stock buckets. "On hand" (physically sellable) = available + reserved.
BUCKETS = ("available", "reserved", "in_transit", "quarantined", "damaged", "expired")


class Lot(Base):
    """Provenance unit: one supplier batch of one product. Every unit of stock belongs to a lot."""
    __tablename__ = "lots"
    id = pk()
    product_id = fk("products.id", nullable=False)
    lot_code = Column(String(60), nullable=False)
    expiry_date = Column(Date)
    supplier_id = fk("suppliers.id")
    receipt_id = Column(Integer)
    unit_cost = Column(Cost, nullable=False, default=0)
    location_id = fk("locations.id")
    created_at = ts()
    __table_args__ = (UniqueConstraint("product_id", "lot_code"),)


class StockBalance(Base):
    """Current quantity per site/product/lot/bucket. Derived from, and always equal to, the sum of
    stock_movements. The CHECK constraint makes negative stock impossible rather than merely unlikely."""
    __tablename__ = "stock_balances"
    id = pk()
    site_id = fk("sites.id", nullable=False)
    product_id = fk("products.id", nullable=False)
    lot_id = fk("lots.id", nullable=False)
    bucket = Column(String(12), nullable=False)
    qty = Column(Qty, nullable=False, default=0)
    __table_args__ = (UniqueConstraint("site_id", "product_id", "lot_id", "bucket"),
                      CheckConstraint("qty >= 0", name="non_negative"))


class StockMovement(Base):
    """Immutable ledger (UPDATE/DELETE blocked by trigger). Corrections are new movements."""
    __tablename__ = "stock_movements"
    id = pk()
    at = ts(index=True)
    site_id = fk("sites.id", nullable=False)
    product_id = fk("products.id", nullable=False)
    lot_id = fk("lots.id", nullable=False)
    bucket = Column(String(12), nullable=False)
    qty = Column(Qty, nullable=False)  # signed delta
    mtype = Column(String(30), nullable=False, index=True)
    ref_type = Column(String(40), index=True)
    ref_id = Column(Integer, index=True)
    group_id = Column(String(36), index=True)  # ties the legs of one bucket-to-bucket move
    actor_id = Column(Integer)
    reason = Column(Text)


class Reservation(Base):
    __tablename__ = "reservations"
    id = pk()
    ref_type = Column(String(40), nullable=False)
    ref_id = Column(Integer, nullable=False)
    site_id = fk("sites.id", nullable=False)
    product_id = fk("products.id", nullable=False)
    lot_id = fk("lots.id", nullable=False)
    qty = Column(Qty, nullable=False)
    status = Column(String(12), nullable=False, default="active")  # active|consumed|released
    created_at = ts()


class CycleCount(Base):
    __tablename__ = "cycle_counts"
    id = pk()
    site_id = fk("sites.id", nullable=False)
    product_id = fk("products.id", nullable=False)
    lot_id = fk("lots.id", nullable=False)
    system_qty = Column(Qty, nullable=False)
    counted_qty = Column(Qty, nullable=False)
    variance = Column(Qty, nullable=False)
    status = Column(String(20), nullable=False, default="posted")  # posted|pending_approval|rejected|no_variance
    approval_id = Column(Integer)
    counted_by = Column(Integer)
    at = ts()


class Withdrawal(Base):
    """Product withdrawal/recall. Works on stock and movements only - no customer identities."""
    __tablename__ = "withdrawals"
    id = pk()
    product_id = fk("products.id", nullable=False)
    lot_id = fk("lots.id")
    reason = Column(Text, nullable=False)
    status = Column(String(20), nullable=False, default="open")
    initiated_by = Column(Integer)
    at = ts()
    closed_at = Column(DateTime(timezone=True))
    summary = Column(JSON)


class WithdrawalItem(Base):
    __tablename__ = "withdrawal_items"
    id = pk()
    withdrawal_id = fk("withdrawals.id", nullable=False)
    site_id = fk("sites.id", nullable=False)
    lot_id = fk("lots.id", nullable=False)
    qty_quarantined = Column(Qty, nullable=False)
    from_bucket = Column(String(12), nullable=False)
