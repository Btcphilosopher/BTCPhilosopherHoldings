from datetime import date
from decimal import Decimal

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import func, select, text

from ...common import ZERO, audit, bad, conflict, dec, flag, get_or_404, get_setting, mappings, now, q2, row, run
from ...db import get_db
from ...security import require
from ..catalog.models import Product
from ..finance.service import post_journal
from ..platform import approvals
from . import service as inv
from .models import BUCKETS, CycleCount, Lot, Reservation, StockBalance, Withdrawal, WithdrawalItem

router = APIRouter(prefix="/inventory", tags=["Inventory & traceability"])
SC = "(:all_sites OR {c} = ANY(CAST(:sites AS int[])))"
PIVOT = ", ".join(f"COALESCE(SUM(b.qty) FILTER (WHERE b.bucket='{x}'),0) {x}" for x in BUCKETS)


@router.get("/stock")
def stock(site_id: int | None = None, q: str | None = None, p=Depends(require("inventory.read")), db=Depends(get_db)):
    """Stock by site and product. on_hand = available + reserved; the other buckets are not sellable."""
    return mappings(db, f"""
        SELECT b.site_id, s.name site, b.product_id, p.sku, p.name product, p.base_uom, p.storage_class, {PIVOT},
          COALESCE(SUM(b.qty) FILTER (WHERE b.bucket IN ('available','reserved')),0) on_hand,
          ROUND(COALESCE(SUM(b.qty * l.unit_cost) FILTER (WHERE b.bucket IN ('available','reserved','in_transit','quarantined')),0), 2) value,
          MIN(l.expiry_date) FILTER (WHERE b.bucket='available' AND b.qty>0) earliest_expiry
        FROM stock_balances b JOIN sites s ON s.id=b.site_id JOIN products p ON p.id=b.product_id JOIN lots l ON l.id=b.lot_id
        WHERE (:s IS NULL OR b.site_id=:s) AND (:q IS NULL OR p.name ILIKE :q OR p.sku ILIKE :q) AND {SC.format(c='b.site_id')}
        GROUP BY b.site_id, s.name, b.product_id, p.sku, p.name, p.base_uom, p.storage_class
        HAVING SUM(b.qty) > 0 ORDER BY s.name, p.sku""", s=site_id, q=f"%{q}%" if q else None, **p.sql_sites("inventory.read"))


@router.get("/lots")
def lots(site_id: int | None = None, product_id: int | None = None, expiring_days: str | None = None,
         p=Depends(require("inventory.read")), db=Depends(get_db)):
    return mappings(db, f"""
        SELECT b.site_id, s.name site, b.product_id, p.sku, p.name product, l.id lot_id, l.lot_code, l.expiry_date, l.unit_cost,
               sup.name supplier, l.receipt_id, (l.expiry_date - current_date) days_to_expiry, {PIVOT}
        FROM stock_balances b JOIN sites s ON s.id=b.site_id JOIN products p ON p.id=b.product_id JOIN lots l ON l.id=b.lot_id
        LEFT JOIN suppliers sup ON sup.id=l.supplier_id
        WHERE (:s IS NULL OR b.site_id=:s) AND (:p IS NULL OR b.product_id=:p) AND {SC.format(c='b.site_id')}
          AND (:d IS NULL OR l.expiry_date <= current_date + CAST(:d AS int))
        GROUP BY b.site_id, s.name, b.product_id, p.sku, p.name, l.id, sup.name HAVING SUM(b.qty) > 0
        ORDER BY l.expiry_date NULLS LAST, s.name LIMIT 1000""", s=site_id, p=product_id, d=expiring_days, **p.sql_sites("inventory.read"))


@router.get("/movements")
def movements(site_id: int | None = None, product_id: int | None = None, lot_id: int | None = None, ref_type: str | None = None,
              ref_id: int | None = None, mtype: str | None = None, limit: int = 300, p=Depends(require("inventory.read")), db=Depends(get_db)):
    return mappings(db, f"""
        SELECT m.*, s.name site, p.sku, p.name product, l.lot_code, u.name actor FROM stock_movements m
        JOIN sites s ON s.id=m.site_id JOIN products p ON p.id=m.product_id JOIN lots l ON l.id=m.lot_id LEFT JOIN users u ON u.id=m.actor_id
        WHERE (:s IS NULL OR m.site_id=:s) AND (:p IS NULL OR m.product_id=:p) AND (:l IS NULL OR m.lot_id=:l)
          AND (:rt IS NULL OR m.ref_type=:rt) AND (:ri IS NULL OR m.ref_id=:ri) AND (:mt IS NULL OR m.mtype=:mt) AND {SC.format(c='m.site_id')}
        ORDER BY m.id DESC LIMIT :lim""", s=site_id, p=product_id, l=lot_id, rt=ref_type, ri=ref_id, mt=mtype, lim=min(limit, 2000),
                    **p.sql_sites("inventory.read"))


@router.get("/integrity")
def integrity(p=Depends(require("inventory.read")), db=Depends(get_db)):
    """Conservation check: every balance must equal the sum of its ledger movements."""
    bad_rows = mappings(db, """
        SELECT COALESCE(b.site_id, m.site_id) site_id, COALESCE(b.product_id, m.product_id) product_id,
               COALESCE(b.lot_id, m.lot_id) lot_id, COALESCE(b.bucket, m.bucket) bucket, COALESCE(b.qty,0) balance, COALESCE(m.q,0) ledger
        FROM stock_balances b FULL JOIN (SELECT site_id, product_id, lot_id, bucket, SUM(qty) q FROM stock_movements GROUP BY 1,2,3,4) m
          ON m.site_id=b.site_id AND m.product_id=b.product_id AND m.lot_id=b.lot_id AND m.bucket=b.bucket
        WHERE COALESCE(b.qty,0) <> COALESCE(m.q,0)""")
    return {"balanced": not bad_rows, "mismatches": bad_rows,
            "movements": db.execute(text("SELECT count(*) FROM stock_movements")).scalar(),
            "negative_balances": db.execute(text("SELECT count(*) FROM stock_balances WHERE qty < 0")).scalar()}


# ---------------------------------------------------------------- adjustments, waste, counts
def apply_adjustment(db, d, actor_id):
    """d: {site_id, product_id, lot_id, bucket, qty_delta, kind, reason}. Posts stock and ledger."""
    lot = db.get(Lot, d["lot_id"])
    qty = dec(d["qty_delta"])
    inv.post(db, site_id=d["site_id"], product_id=d["product_id"], lot_id=lot.id, bucket=d["bucket"], qty=qty,
             mtype=d.get("kind", "adjustment"), ref_type=d.get("ref_type", "adjustment"), ref_id=d.get("ref_id"), actor_id=actor_id, reason=d["reason"])
    if d["bucket"] in inv.VALUED_BUCKETS:
        value = q2(abs(qty) * lot.unit_cost)
        lines = [("5100", value, 0, d["site_id"], d["reason"][:200]), ("1200", 0, value, d["site_id"], None)] if qty < 0 else \
                [("1200", value, 0, d["site_id"], None), ("5100", 0, value, d["site_id"], d["reason"][:200])]
        post_journal(db, entry_date=date.fromisoformat(d["entry_date"]) if d.get("entry_date") else date.today(), source_type="stock_" + d.get("kind", "adjustment"), source_id=lot.id,
                     description=f"Stock {d.get('kind', 'adjustment')}: {qty} of lot {lot.lot_code}", lines=lines, posted_by=actor_id)


@approvals.handler("stock_adjustment")
def _adj_decided(db, a, p, approve):
    if approve:
        apply_adjustment(db, a.payload, a.requested_by)
    if a.payload.get("cycle_count_id"):
        db.get(CycleCount, a.payload["cycle_count_id"]).status = "posted" if approve else "rejected"


def submit_adjustment(db, p, d):
    """Post immediately when below the approval value; otherwise raise a maker-checker request."""
    lot = get_or_404(db, Lot, d["lot_id"], "lot")
    value = q2(abs(dec(d["qty_delta"])) * lot.unit_cost)
    threshold = dec(get_setting(db, "inventory.policy")["adjustment_approval_value"])
    if dec(d["qty_delta"]) < 0:
        bal = db.execute(select(StockBalance.qty).where(StockBalance.site_id == d["site_id"], StockBalance.lot_id == lot.id,
                                                        StockBalance.bucket == d["bucket"])).scalar() or ZERO
        if bal + dec(d["qty_delta"]) < 0:
            raise conflict(f"Only {bal} in '{d['bucket']}' for this lot; cannot remove {-dec(d['qty_delta'])}", "insufficient_stock")
    if value > threshold:
        prod = db.get(Product, d["product_id"])
        a = approvals.request(db, p, "stock_adjustment", f"{d.get('kind', 'adjustment').title()} {d['qty_delta']} x {prod.name} "
                              f"({d['bucket']}) worth {value}: {d['reason']}", "inventory.approve", entity_type="lot", entity_id=lot.id,
                              site_id=d["site_id"], amount=value, payload=d)
        return {"status": "pending_approval", "approval_id": a.id, "value": str(value)}
    apply_adjustment(db, d, p.user.id)
    audit(db, p, f"stock.{d.get('kind', 'adjustment')}", "lot", lot.id, d)
    return {"status": "posted", "value": str(value)}


class AdjustIn(BaseModel):
    site_id: int
    product_id: int
    lot_id: int
    bucket: str = "available"
    qty_delta: Decimal
    kind: str = "adjustment"  # adjustment|waste
    reason: str


@router.post("/adjustments")
def adjust(body: AdjustIn, p=Depends(require("inventory.write")), db=Depends(get_db)):
    p.check("inventory.write", body.site_id)
    if body.bucket not in BUCKETS or body.kind not in ("adjustment", "waste"):
        raise bad("Unknown bucket or kind")
    if body.kind == "waste" and body.qty_delta >= 0:
        raise bad("Waste must be a negative quantity")
    out = submit_adjustment(db, p, body.model_dump(mode="json"))
    db.commit()
    return out


class CountIn(BaseModel):
    site_id: int
    product_id: int
    lot_id: int
    counted_qty: Decimal


@router.post("/cycle-counts")
def cycle_count(body: CountIn, p=Depends(require("inventory.write")), db=Depends(get_db)):
    p.check("inventory.write", body.site_id)
    system = db.execute(select(StockBalance.qty).where(StockBalance.site_id == body.site_id, StockBalance.lot_id == body.lot_id,
                                                       StockBalance.bucket == "available")).scalar() or ZERO
    var = body.counted_qty - system
    cc = CycleCount(site_id=body.site_id, product_id=body.product_id, lot_id=body.lot_id, system_qty=system, counted_qty=body.counted_qty,
                    variance=var, counted_by=p.user.id, status="no_variance" if var == 0 else "posted")
    db.add(cc)
    db.flush()
    res = {"status": "no_variance"}
    if var != 0:
        res = submit_adjustment(db, p, {"site_id": body.site_id, "product_id": body.product_id, "lot_id": body.lot_id, "bucket": "available",
                                        "qty_delta": str(var), "kind": "adjustment", "reason": f"Cycle count #{cc.id}: counted {body.counted_qty}, system {system}",
                                        "ref_type": "cycle_count", "ref_id": cc.id, "cycle_count_id": cc.id})
        cc.status, cc.approval_id = res["status"], res.get("approval_id")
    db.commit()
    return {"cycle_count": row(cc), **res}


@router.get("/cycle-counts")
def cycle_counts(p=Depends(require("inventory.read")), db=Depends(get_db)):
    return mappings(db, f"""SELECT c.*, s.name site, p.name product, l.lot_code FROM cycle_counts c JOIN sites s ON s.id=c.site_id
        JOIN products p ON p.id=c.product_id JOIN lots l ON l.id=c.lot_id WHERE {SC.format(c='c.site_id')} ORDER BY c.id DESC LIMIT 200""",
                    **p.sql_sites("inventory.read"))


@router.post("/expiry-sweep")
def expiry_sweep(p=Depends(require("inventory.write")), db=Depends(get_db)):
    """Move stock past its expiry date out of 'available' into 'expired' and write off its value."""
    moved = []
    for b, lot in db.execute(p.scope(select(StockBalance, Lot).join(Lot, Lot.id == StockBalance.lot_id).where(
            StockBalance.bucket == "available", StockBalance.qty > 0, Lot.expiry_date < date.today()), StockBalance.site_id, "inventory.write")
            .with_for_update(of=StockBalance)).all():
        qty = b.qty
        inv.move(db, site_id=b.site_id, product_id=b.product_id, lot_id=lot.id, src="available", dst="expired", qty=qty, mtype="expiry",
                 ref_type="expiry_sweep", ref_id=None, actor_id=p.user.id, reason=f"Expired {lot.expiry_date}")
        value = q2(qty * lot.unit_cost)
        post_journal(db, entry_date=date.today(), source_type="stock_expiry", source_id=lot.id, posted_by=p.user.id,
                     description=f"Expired stock written off: lot {lot.lot_code}",
                     lines=[("5100", value, 0, b.site_id, "expired"), ("1200", 0, value, b.site_id, None)])
        moved.append({"site_id": b.site_id, "lot": lot.lot_code, "qty": str(qty), "value": str(value)})
    audit(db, p, "stock.expiry_sweep", detail={"lots": len(moved)})
    db.commit()
    return {"moved": moved}


class SiteTransferIn(BaseModel):
    from_site_id: int
    to_site_id: int
    product_id: int
    lot_id: int
    qty: Decimal
    reason: str


@router.post("/site-transfers")
def site_transfer(body: SiteTransferIn, p=Depends(require("inventory.write")), db=Depends(get_db)):
    """Direct store-to-store move of one lot (both legs in one transaction)."""
    p.check("inventory.write", body.from_site_id)
    if body.qty <= 0 or body.from_site_id == body.to_site_id:
        raise bad("Quantity must be positive and sites must differ")
    inv.move(db, site_id=body.from_site_id, dst_site_id=body.to_site_id, product_id=body.product_id, lot_id=body.lot_id, src="available",
             dst="available", qty=body.qty, mtype="site_transfer", ref_type="site_transfer", ref_id=None, actor_id=p.user.id, reason=body.reason)
    audit(db, p, "stock.site_transfer", "lot", body.lot_id, body.model_dump(mode="json"))
    db.commit()
    return {"status": "posted"}


# ---------------------------------------------------------------- product withdrawal
class WithdrawIn(BaseModel):
    product_id: int
    lot_id: int | None = None
    reason: str


@router.post("/withdrawals")
def withdraw(body: WithdrawIn, p=Depends(require("inventory.approve")), db=Depends(get_db)):
    """Quarantine all available stock of a product (or one lot) everywhere, block further sale, and
    report where the rest is. Reports units and movements only - no customer identities are read."""
    p.check("inventory.approve")
    prod = get_or_404(db, Product, body.product_id)
    w = Withdrawal(product_id=prod.id, lot_id=body.lot_id, reason=body.reason, initiated_by=p.user.id)
    db.add(w)
    db.flush()
    q = select(StockBalance).where(StockBalance.product_id == prod.id, StockBalance.qty > 0)
    if body.lot_id:
        q = q.where(StockBalance.lot_id == body.lot_id)
    summary = {b: ZERO for b in BUCKETS}
    quarantined = ZERO
    for b in db.execute(q.with_for_update()).scalars().all():
        summary[b.bucket] += b.qty
        if b.bucket == "available":
            qty = b.qty
            inv.move(db, site_id=b.site_id, product_id=prod.id, lot_id=b.lot_id, src="available", dst="quarantined", qty=qty,
                     mtype="withdrawal", ref_type="withdrawal", ref_id=w.id, actor_id=p.user.id, reason=body.reason)
            db.add(WithdrawalItem(withdrawal_id=w.id, site_id=b.site_id, lot_id=b.lot_id, qty_quarantined=qty, from_bucket="available"))
            quarantined += qty
    sold = run(db, """SELECT COUNT(DISTINCT sl.sale_id), COALESCE(SUM(sl.qty - sl.returned_qty),0) FROM sale_lines sl
        WHERE sl.product_id=:p AND (:l IS NULL OR sl.lot_id=:l)""", p=prod.id, l=body.lot_id).one()
    if not body.lot_id:
        prod.status = "withdrawn"
    w.summary = {"quarantined_now": str(quarantined), "found": {k: str(v) for k, v in summary.items()},
                 "still_reserved_needs_action": str(summary["reserved"]), "in_transit_needs_action": str(summary["in_transit"]),
                 "sales_transactions_affected": sold[0], "units_sold_not_returned": str(sold[1]),
                 "privacy": "Counts only. Customer contact, if required, is a separate authorised process via the loyalty/CRM system."}
    flag(db, "product_withdrawal", f"Withdrawal of {prod.name}: {quarantined} units quarantined", severity="high", entity_type="withdrawal", entity_id=w.id)
    audit(db, p, "withdrawal.initiated", "withdrawal", w.id, w.summary)
    db.commit()
    return row(w)


@router.get("/withdrawals")
def withdrawals(p=Depends(require("inventory.read")), db=Depends(get_db)):
    return mappings(db, """SELECT w.*, p.sku, p.name product, l.lot_code FROM withdrawals w JOIN products p ON p.id=w.product_id
        LEFT JOIN lots l ON l.id=w.lot_id ORDER BY w.id DESC""")


@router.get("/withdrawals/{wid}")
def withdrawal(wid: int, p=Depends(require("inventory.read")), db=Depends(get_db)):
    w = get_or_404(db, Withdrawal, wid)
    return row(w, items=mappings(db, "SELECT i.*, s.name site, l.lot_code FROM withdrawal_items i JOIN sites s ON s.id=i.site_id JOIN lots l ON l.id=i.lot_id WHERE withdrawal_id=:w", w=wid),
               movements=mappings(db, """SELECT m.at, s.name site, m.mtype, m.bucket, m.qty, m.ref_type, m.ref_id, l.lot_code FROM stock_movements m
                   JOIN sites s ON s.id=m.site_id JOIN lots l ON l.id=m.lot_id WHERE m.product_id=:p AND (:l IS NULL OR m.lot_id=:l)
                   ORDER BY m.id DESC LIMIT 500""", p=w.product_id, l=w.lot_id))


@router.get("/reservations")
def reservations(p=Depends(require("inventory.read")), db=Depends(get_db)):
    return mappings(db, f"""SELECT r.*, s.name site, p.name product FROM reservations r JOIN sites s ON s.id=r.site_id JOIN products p ON p.id=r.product_id
        WHERE r.status='active' AND {SC.format(c='r.site_id')} ORDER BY r.id DESC LIMIT 500""", **p.sql_sites("inventory.read"))
