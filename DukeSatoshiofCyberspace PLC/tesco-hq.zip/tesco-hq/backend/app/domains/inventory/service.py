"""Inventory service. The only code allowed to change stock.

Every change is one or more rows in the immutable stock_movements ledger plus an atomic upsert of
stock_balances in the same transaction. Balances can never go negative: the CHECK constraint turns a
would-be negative into an error instead of a silent oversell."""
import uuid
from decimal import Decimal

from sqlalchemy import select, text
from sqlalchemy.exc import IntegrityError

from ...common import ZERO, DomainError, dec, q2
from .models import Lot, Reservation, StockBalance, StockMovement

VALUED_BUCKETS = ("available", "reserved", "in_transit", "quarantined")

_UPSERT = text("""
    INSERT INTO stock_balances (site_id, product_id, lot_id, bucket, qty)
    VALUES (:site, :product, :lot, :bucket, :qty)
    ON CONFLICT ON CONSTRAINT uq_stock_balances_site_id DO UPDATE SET qty = stock_balances.qty + EXCLUDED.qty
""")
_DECREMENT = text("""
    UPDATE stock_balances SET qty = qty + :qty
    WHERE site_id = :site AND product_id = :product AND lot_id = :lot AND bucket = :bucket
""")


class InsufficientStock(DomainError):
    def __init__(self, message, detail=None):
        super().__init__(409, "insufficient_stock", message, detail)


def post(db, *, site_id, product_id, lot_id, bucket, qty, mtype, ref_type=None, ref_id=None, actor_id=None,
         reason=None, group=None):
    """Append one ledger row and apply it to the balance. qty is a signed delta."""
    qty = dec(qty)
    if qty == 0:
        return
    params = {"site": site_id, "product": product_id, "lot": lot_id, "bucket": bucket, "qty": qty}
    msg = f"Movement of {qty} would make '{bucket}' stock negative (site {site_id}, product {product_id}, lot {lot_id})"
    try:
        with db.begin_nested():
            if qty > 0:
                db.execute(_UPSERT, params)
            elif db.execute(_DECREMENT, params).rowcount != 1:   # no balance row at all
                raise InsufficientStock(msg)
    except IntegrityError as e:  # CHECK (qty >= 0) fired
        raise InsufficientStock(msg) from e
    db.add(StockMovement(site_id=site_id, product_id=product_id, lot_id=lot_id, bucket=bucket, qty=qty, mtype=mtype,
                         ref_type=ref_type, ref_id=ref_id, actor_id=actor_id, reason=reason, group_id=group))


def move(db, *, site_id, product_id, lot_id, src, dst, qty, mtype, dst_site_id=None, **kw):
    """Move quantity between buckets (and optionally sites). Both legs share a group id and net to zero."""
    g = str(uuid.uuid4())
    post(db, site_id=site_id, product_id=product_id, lot_id=lot_id, bucket=src, qty=-dec(qty), mtype=mtype, group=g, **kw)
    post(db, site_id=dst_site_id or site_id, product_id=product_id, lot_id=lot_id, bucket=dst, qty=dec(qty),
         mtype=mtype, group=g, **kw)


def _fefo(db, site_id, product_id, bucket="available", lot_id=None):
    """Lock and return balances first-expiry-first-out. FOR UPDATE serialises concurrent allocators."""
    q = (select(StockBalance.lot_id, StockBalance.qty, Lot.unit_cost)
         .join(Lot, Lot.id == StockBalance.lot_id)
         .where(StockBalance.site_id == site_id, StockBalance.product_id == product_id,
                StockBalance.bucket == bucket, StockBalance.qty > 0)
         .order_by(Lot.expiry_date.asc().nulls_last(), Lot.id).with_for_update(of=StockBalance))
    if lot_id:
        q = q.where(StockBalance.lot_id == lot_id)
    return db.execute(q).all()


def available(db, site_id, product_id) -> Decimal:
    return sum(db.execute(select(StockBalance.qty).where(
        StockBalance.site_id == site_id, StockBalance.product_id == product_id,
        StockBalance.bucket == "available")).scalars().all(), ZERO)


def reserve(db, *, site_id, product_id, qty, ref_type, ref_id, allow_partial=False, actor_id=None) -> Decimal:
    """Allocate available stock to a document. Returns the quantity reserved.
    Two concurrent callers cannot both get the last unit: the second waits on the row lock and then
    sees the reduced balance."""
    need = dec(qty)
    lots = _fefo(db, site_id, product_id)
    total = sum((l.qty for l in lots), ZERO)
    if total < need and not allow_partial:
        raise InsufficientStock(f"Only {total} available of {need} requested", {"available": str(total)})
    done = ZERO
    for l in lots:
        if done >= need:
            break
        take = min(l.qty, need - done)
        move(db, site_id=site_id, product_id=product_id, lot_id=l.lot_id, src="available", dst="reserved", qty=take,
             mtype="reserve", ref_type=ref_type, ref_id=ref_id, actor_id=actor_id)
        db.add(Reservation(ref_type=ref_type, ref_id=ref_id, site_id=site_id, product_id=product_id, lot_id=l.lot_id,
                           qty=take))
        done += take
    db.flush()
    return done


def _active_reservations(db, ref_type, ref_id, product_id=None):
    q = select(Reservation).where(Reservation.ref_type == ref_type, Reservation.ref_id == ref_id,
                                  Reservation.status == "active").order_by(Reservation.id).with_for_update()
    if product_id:
        q = q.where(Reservation.product_id == product_id)
    return db.execute(q).scalars().all()


def release(db, *, ref_type, ref_id, product_id=None, qty=None, actor_id=None) -> Decimal:
    """Return reserved stock to available (all of it, or up to qty for one product)."""
    left = dec(qty) if qty is not None else None
    released = ZERO
    for r in _active_reservations(db, ref_type, ref_id, product_id):
        take = r.qty if left is None else min(r.qty, left)
        if take <= 0:
            continue
        move(db, site_id=r.site_id, product_id=r.product_id, lot_id=r.lot_id, src="reserved", dst="available",
             qty=take, mtype="release", ref_type=ref_type, ref_id=ref_id, actor_id=actor_id)
        r.qty -= take
        if r.qty == 0:
            r.status = "released"
        released += take
        if left is not None:
            left -= take
    db.flush()
    return released


def consume_reserved(db, *, ref_type, ref_id, product_id, qty, mtype, dst_bucket=None, dst_site_id=None,
                     out_ref_type=None, out_ref_id=None, actor_id=None):
    """Use reserved stock: either remove it (sale) or move it on (dispatch -> in_transit at the store).
    Returns (qty consumed, cost, [(lot_id, qty)])."""
    left, cost, lots = dec(qty), ZERO, []
    for r in _active_reservations(db, ref_type, ref_id, product_id):
        if left <= 0:
            break
        take = min(r.qty, left)
        unit_cost = db.get(Lot, r.lot_id).unit_cost
        kw = dict(ref_type=out_ref_type or ref_type, ref_id=out_ref_id or ref_id, actor_id=actor_id)
        if dst_bucket:
            move(db, site_id=r.site_id, product_id=product_id, lot_id=r.lot_id, src="reserved", dst=dst_bucket,
                 dst_site_id=dst_site_id, qty=take, mtype=mtype, **kw)
        else:
            post(db, site_id=r.site_id, product_id=product_id, lot_id=r.lot_id, bucket="reserved", qty=-take,
                 mtype=mtype, **kw)
        r.qty -= take
        if r.qty == 0:
            r.status = "consumed"
        left -= take
        cost += take * unit_cost
        lots.append((r.lot_id, take))
    db.flush()
    return dec(qty) - left, cost, lots


def deplete(db, *, site_id, product_id, qty, mtype, ref_type, ref_id, lot_id=None, bucket="available", actor_id=None,
            reason=None):
    """Remove stock FEFO from a bucket. Never goes negative: returns what was actually depleted so the
    caller can raise a visible discrepancy for any shortfall. Returns (depleted, cost, [(lot, qty)])."""
    left, cost, lots = dec(qty), ZERO, []
    for l in _fefo(db, site_id, product_id, bucket, lot_id):
        if left <= 0:
            break
        take = min(l.qty, left)
        post(db, site_id=site_id, product_id=product_id, lot_id=l.lot_id, bucket=bucket, qty=-take, mtype=mtype,
             ref_type=ref_type, ref_id=ref_id, actor_id=actor_id, reason=reason)
        left -= take
        cost += take * l.unit_cost
        lots.append((l.lot_id, take))
    return dec(qty) - left, cost, lots


def lot_cost(db, lot_id, qty) -> Decimal:
    return q2(dec(qty) * db.get(Lot, lot_id).unit_cost)
