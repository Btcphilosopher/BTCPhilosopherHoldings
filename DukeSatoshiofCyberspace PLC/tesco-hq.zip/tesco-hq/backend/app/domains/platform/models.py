from sqlalchemy import JSON, Boolean, Column, DateTime, Integer, String, Text, UniqueConstraint

from ...db import Base, Money, fk, pk, ts


class User(Base):
    """Console operator. Deliberately separate from loyalty members and online customers."""
    __tablename__ = "users"
    id = pk()
    email = Column(String(200), unique=True, nullable=False)
    name = Column(String(200), nullable=False)
    job_title = Column(String(200))
    password_hash = Column(String(300), nullable=False)
    active = Column(Boolean, default=True, nullable=False)
    created_at = ts()


class UserRole(Base):
    __tablename__ = "user_roles"
    id = pk()
    user_id = fk("users.id", nullable=False)
    role = Column(String(60), nullable=False)
    scope_type = Column(String(20), nullable=False, default="global")  # global|business_unit|region|site
    scope_id = Column(Integer)
    granted_by = Column(Integer)
    created_at = ts()
    __table_args__ = (UniqueConstraint("user_id", "role", "scope_type", "scope_id"),)


class AuditLog(Base):
    __tablename__ = "audit_log"
    id = pk()
    at = ts(index=True)
    user_id = Column(Integer)
    user_email = Column(String(200))
    action = Column(String(80), nullable=False, index=True)
    entity_type = Column(String(60))
    entity_id = Column(String(60))
    sensitive = Column(Boolean, default=False, nullable=False)
    detail = Column(JSON)


class Approval(Base):
    """Maker-checker request. The decider must differ from the requester."""
    __tablename__ = "approvals"
    id = pk()
    kind = Column(String(40), nullable=False, index=True)
    entity_type = Column(String(60))
    entity_id = Column(Integer)
    site_id = Column(Integer)
    summary = Column(String(400), nullable=False)
    amount = Column(Money)
    payload = Column(JSON)
    required_perm = Column(String(60), nullable=False)
    status = Column(String(20), nullable=False, default="pending", index=True)
    requested_by = fk("users.id", nullable=False)
    requested_at = ts()
    decided_by = fk("users.id")
    decided_at = Column(DateTime(timezone=True))
    decision_reason = Column(Text)


class IdempotencyKey(Base):
    __tablename__ = "idempotency_keys"
    id = pk()
    scope = Column(String(60), nullable=False)
    key = Column(String(120), nullable=False)
    request_hash = Column(String(64), nullable=False)
    response = Column(JSON)
    created_at = ts()
    __table_args__ = (UniqueConstraint("scope", "key"),)


class OutboxEvent(Base):
    """Transactional outbox: written in the same transaction as the state change, relayed by the worker."""
    __tablename__ = "outbox_events"
    id = pk()
    topic = Column(String(80), nullable=False, index=True)
    key = Column(String(120))
    payload = Column(JSON, nullable=False)
    created_at = ts()
    published_at = Column(DateTime(timezone=True), index=True)
    attempts = Column(Integer, default=0, nullable=False)


class IntegrationDelivery(Base):
    __tablename__ = "integration_deliveries"
    id = pk()
    adapter = Column(String(60), nullable=False)
    event_id = fk("outbox_events.id")
    topic = Column(String(80))
    status = Column(String(20), nullable=False)
    response = Column(JSON)
    at = ts()


class InboundMessage(Base):
    """Consumer-side de-duplication of messages from external systems."""
    __tablename__ = "inbound_messages"
    id = pk()
    source = Column(String(60), nullable=False)
    message_id = Column(String(120), nullable=False)
    received_at = ts()
    __table_args__ = (UniqueConstraint("source", "message_id"),)


class Job(Base):
    __tablename__ = "jobs"
    id = pk()
    kind = Column(String(60), nullable=False)
    payload = Column(JSON)
    status = Column(String(20), nullable=False, default="queued", index=True)
    result = Column(JSON)
    created_by = Column(Integer)
    created_at = ts()
    started_at = Column(DateTime(timezone=True))
    finished_at = Column(DateTime(timezone=True))


class Setting(Base):
    """Configurable policies (accounting, pricing, loyalty, scheduling). Changes are audited."""
    __tablename__ = "settings"
    key = Column(String(80), primary_key=True)
    value = Column(JSON, nullable=False)
    description = Column(Text)
    updated_by = Column(Integer)
    updated_at = ts()


class ExceptionCase(Base):
    """Operational exception raised by a workflow; every one points at the record that caused it."""
    __tablename__ = "exceptions"
    id = pk()
    kind = Column(String(60), nullable=False, index=True)
    severity = Column(String(10), nullable=False, default="medium")
    title = Column(String(300), nullable=False)
    detail = Column(Text)
    entity_type = Column(String(60))
    entity_id = Column(Integer)
    site_id = Column(Integer, index=True)
    status = Column(String(20), nullable=False, default="open", index=True)
    dedupe_key = Column(String(200), unique=True)
    raised_at = ts()
    resolved_by = Column(Integer)
    resolved_at = Column(DateTime(timezone=True))
    resolution = Column(Text)


class Document(Base):
    __tablename__ = "documents"
    id = pk()
    entity_type = Column(String(60), nullable=False, index=True)
    entity_id = Column(Integer, nullable=False)
    name = Column(String(300), nullable=False)
    content_type = Column(String(100))
    object_key = Column(String(400), nullable=False)
    size = Column(Integer)
    uploaded_by = Column(Integer)
    at = ts()
