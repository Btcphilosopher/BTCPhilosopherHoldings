"""Maker-checker. Material changes are requested by one person and decided by another.
Domains register a handler per approval kind; the handler applies (or discards) the change."""
from sqlalchemy import select

from ...common import DomainError, audit, conflict, not_found, now
from .models import Approval

HANDLERS = {}


def handler(kind):
    def deco(fn):
        HANDLERS[kind] = fn
        return fn
    return deco


def request(db, p, kind, summary, required_perm, *, entity_type=None, entity_id=None, site_id=None, amount=None,
            payload=None):
    a = Approval(kind=kind, summary=summary[:400], required_perm=required_perm, entity_type=entity_type,
                 entity_id=entity_id, site_id=site_id, amount=amount, payload=payload, requested_by=p.user.id)
    db.add(a)
    db.flush()
    audit(db, p, f"approval.requested:{kind}", entity_type, entity_id, {"approval_id": a.id, "summary": summary})
    return a


def decide(db, p, approval_id, approve: bool, reason=None):
    a = db.execute(select(Approval).where(Approval.id == approval_id).with_for_update()).scalar_one_or_none()
    if not a:
        raise not_found("approval")
    if a.status != "pending":
        raise conflict(f"Approval already {a.status}")
    if a.requested_by == p.user.id:
        raise DomainError(403, "maker_checker", "You cannot decide your own request (maker-checker control)")
    p.check(a.required_perm, a.site_id)
    if not approve and not reason:
        raise DomainError(422, "reason_required", "A reason is required to reject")
    a.status = "approved" if approve else "rejected"
    a.decided_by, a.decided_at, a.decision_reason = p.user.id, now(), reason
    result = HANDLERS[a.kind](db, a, p, approve)
    audit(db, p, f"approval.{a.status}:{a.kind}", a.entity_type, a.entity_id, {"approval_id": a.id, "reason": reason})
    db.flush()
    return a, result
