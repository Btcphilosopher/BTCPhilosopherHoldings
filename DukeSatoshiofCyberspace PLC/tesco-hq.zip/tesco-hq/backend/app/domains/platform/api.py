import csv
import io
from typing import Any

from fastapi import APIRouter, Depends, File, Form, Response, UploadFile
from pydantic import BaseModel
from sqlalchemy import select, text

from ... import storage
from ...cache import wake_worker
from ...common import DEFAULT_SETTINGS, DomainError, audit, bad, get_or_404, mappings, not_found, now, row, rows
from ...db import get_db
from ...permissions import PERMISSIONS, ROLES
from ...security import Principal, current_principal, issue_token, load_principal, require, verify_password
from . import approvals
from .models import (Approval, AuditLog, Document, ExceptionCase, IntegrationDelivery, Job, OutboxEvent, Setting, User,
                     UserRole)

router = APIRouter()
SCOPE = "(:all_sites OR {c} IS NULL OR {c} = ANY(CAST(:sites AS int[])))"


class Login(BaseModel):
    email: str
    password: str


def _me(p: Principal):
    return {"user": row(p.user), "roles": p.roles, "permissions": sorted(p.grants),
            "scopes": {k: (None if v is None else sorted(v)) for k, v in p.grants.items()}}


@router.post("/auth/login", tags=["Auth"])
def login(body: Login, db=Depends(get_db)):
    u = db.execute(select(User).where(User.email == body.email.lower().strip())).scalar_one_or_none()
    if not u or not u.active or not verify_password(body.password, u.password_hash):
        audit(db, None, "auth.login_failed", "user", None, {"email": body.email})
        db.commit()
        raise DomainError(401, "bad_credentials", "Email or password is incorrect")
    audit(db, u, "auth.login", "user", u.id)
    db.commit()
    return {"token": issue_token(u), **_me(load_principal(db, u))}


@router.get("/auth/me", tags=["Auth"])
def me(p=Depends(current_principal)):
    return _me(p)


# ------------------------------------------------------------------ approvals
@router.get("/approvals", tags=["Approvals"])
def list_approvals(status: str | None = "pending", p=Depends(current_principal), db=Depends(get_db)):
    q = """SELECT a.*, u.name requested_by_name, d.name decided_by_name FROM approvals a
           JOIN users u ON u.id = a.requested_by LEFT JOIN users d ON d.id = a.decided_by
           WHERE (:st IS NULL OR a.status = :st) ORDER BY a.id DESC LIMIT 300"""
    out = []
    for a in mappings(db, q, st=status):
        if not p.has(a["required_perm"]) and a["requested_by"] != p.user.id:
            continue
        a["can_decide"] = a["status"] == "pending" and a["requested_by"] != p.user.id and p.can(a["required_perm"], a["site_id"])
        a["blocked_reason"] = ("You raised this request - a different approver must decide it"
                               if a["status"] == "pending" and a["requested_by"] == p.user.id else None)
        out.append(a)
    return out


class Decision(BaseModel):
    approve: bool
    reason: str | None = None


@router.post("/approvals/{approval_id}/decision", tags=["Approvals"])
def decide(approval_id: int, body: Decision, p=Depends(current_principal), db=Depends(get_db)):
    a, _ = approvals.decide(db, p, approval_id, body.approve, body.reason)
    db.commit()
    wake_worker()
    return row(a)


# ------------------------------------------------------------------ exceptions
@router.get("/exceptions", tags=["Exceptions"])
def exceptions(status: str | None = "open", kind: str | None = None, p=Depends(require("exec.read", "admin.read", "analytics.read")),
               db=Depends(get_db)):
    perm = "exec.read" if p.has("exec.read") else ("analytics.read" if p.has("analytics.read") else "admin.read")
    return mappings(db, f"""SELECT e.*, s.name site_name FROM exceptions e LEFT JOIN sites s ON s.id = e.site_id
        WHERE (:st IS NULL OR e.status = :st) AND (:k IS NULL OR e.kind = :k) AND {SCOPE.format(c='e.site_id')}
        ORDER BY CASE e.severity WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END, e.id DESC LIMIT 500""",
                    st=status, k=kind, **p.sql_sites(perm))


class Resolve(BaseModel):
    resolution: str


@router.post("/exceptions/{ex_id}/resolve", tags=["Exceptions"])
def resolve_exception(ex_id: int, body: Resolve, p=Depends(current_principal), db=Depends(get_db)):
    e = get_or_404(db, ExceptionCase, ex_id)
    if not (p.has("admin.write") or any(p.can(x, e.site_id) for x in p.grants if x.endswith(".write") or x.endswith(".approve"))):
        raise DomainError(403, "forbidden", "No operational permission for this site")
    e.status, e.resolved_by, e.resolved_at, e.resolution = "resolved", p.user.id, now(), body.resolution
    audit(db, p, "exception.resolved", "exception", e.id, {"resolution": body.resolution})
    db.commit()
    return row(e)


# ------------------------------------------------------------------ administration
@router.get("/admin/users", tags=["Administration"])
def users(p=Depends(require("admin.read")), db=Depends(get_db)):
    grants = {}
    for g in mappings(db, """SELECT ur.*, COALESCE(s.name, r.name, b.name) scope_name FROM user_roles ur
            LEFT JOIN sites s ON ur.scope_type='site' AND s.id = ur.scope_id
            LEFT JOIN regions r ON ur.scope_type='region' AND r.id = ur.scope_id
            LEFT JOIN business_units b ON ur.scope_type='business_unit' AND b.id = ur.scope_id ORDER BY ur.id"""):
        g["role_name"] = ROLES.get(g["role"], {}).get("name", g["role"])
        grants.setdefault(g["user_id"], []).append(g)
    return [row(u, grants=grants.get(u.id, []), roles_text=", ".join(
        f"{g['role_name']} ({g['scope_name'] or 'all'})" for g in grants.get(u.id, []))) for u in db.execute(select(User).order_by(User.name)).scalars()]


@router.get("/admin/roles", tags=["Administration"])
def roles(p=Depends(require("admin.read"))):
    return {"permissions": PERMISSIONS, "roles": [{"code": k, "name": v["name"], "permissions": v["perms"],
                                                   "permission_count": len(v["perms"])} for k, v in ROLES.items()]}


class GrantRequest(BaseModel):
    user_id: int
    role: str
    scope_type: str = "global"
    scope_id: int | None = None
    revoke: bool = False
    justification: str


@router.post("/admin/role-grants", tags=["Administration"])
def request_grant(body: GrantRequest, p=Depends(require("admin.write")), db=Depends(get_db)):
    """Permission changes never apply directly: they create an approval for a second administrator."""
    if body.role not in ROLES or body.scope_type not in ("global", "business_unit", "region", "site"):
        raise bad("Unknown role or scope type")
    if (body.scope_type == "global") != (body.scope_id is None):
        raise bad("scope_id is required for non-global scope and must be empty for global")
    u = get_or_404(db, User, body.user_id)
    a = approvals.request(db, p, "role_grant", f"{'Revoke' if body.revoke else 'Grant'} role '{ROLES[body.role]['name']}' "
                          f"({body.scope_type}{' #' + str(body.scope_id) if body.scope_id else ''}) for {u.name}: {body.justification}",
                          "admin.approve", entity_type="user", entity_id=u.id, payload=body.model_dump())
    db.commit()
    return row(a)


@approvals.handler("role_grant")
def _grant_decided(db, a, p, approve):
    if not approve:
        return
    b = a.payload
    existing = db.execute(select(UserRole).where(UserRole.user_id == b["user_id"], UserRole.role == b["role"],
                                                 UserRole.scope_type == b["scope_type"], UserRole.scope_id == b["scope_id"])).scalar_one_or_none()
    if b.get("revoke"):
        if existing:
            db.delete(existing)
    elif not existing:
        db.add(UserRole(user_id=b["user_id"], role=b["role"], scope_type=b["scope_type"], scope_id=b["scope_id"], granted_by=p.user.id))


@router.get("/admin/audit", tags=["Administration"])
def audit_log(action: str | None = None, sensitive: str | None = None, limit: int = 300, p=Depends(require("audit.read")),
              db=Depends(get_db)):
    q = select(AuditLog).order_by(AuditLog.id.desc()).limit(min(limit, 1000))
    if action:
        q = q.where(AuditLog.action.ilike(f"%{action}%"))
    if sensitive in ("true", "false"):
        q = q.where(AuditLog.sensitive == (sensitive == "true"))
    return rows(db.execute(q).scalars())


@router.get("/admin/settings", tags=["Administration"])
def settings_list(p=Depends(require("admin.read", "finance.read")), db=Depends(get_db)):
    stored = {s.key: s for s in db.execute(select(Setting)).scalars()}
    return [{"key": k, "value": stored[k].value if k in stored else v, "description": d,
             "updated_at": stored[k].updated_at.isoformat() if k in stored else None,
             "is_default": k not in stored} for k, (v, d) in DEFAULT_SETTINGS.items()]


class SettingUpdate(BaseModel):
    value: dict[str, Any]
    reason: str


@router.put("/admin/settings/{key}", tags=["Administration"])
def settings_put(key: str, body: SettingUpdate, p=Depends(require("admin.write")), db=Depends(get_db)):
    p.check("admin.write")
    if key not in DEFAULT_SETTINGS:
        raise not_found("setting")
    s = db.get(Setting, key)
    before = s.value if s else DEFAULT_SETTINGS[key][0]
    if s:
        s.value, s.updated_by, s.updated_at = body.value, p.user.id, now()
    else:
        db.add(Setting(key=key, value=body.value, description=DEFAULT_SETTINGS[key][1], updated_by=p.user.id))
    audit(db, p, "policy.changed", "setting", key, {"before": before, "after": body.value, "reason": body.reason})
    db.commit()
    return {"key": key, "value": body.value}


@router.get("/admin/outbox", tags=["Administration"])
def outbox(p=Depends(require("admin.read")), db=Depends(get_db)):
    return {"events": rows(db.execute(select(OutboxEvent).order_by(OutboxEvent.id.desc()).limit(200)).scalars()),
            "deliveries": rows(db.execute(select(IntegrationDelivery).order_by(IntegrationDelivery.id.desc()).limit(200)).scalars()),
            "pending": db.execute(text("SELECT count(*) FROM outbox_events WHERE published_at IS NULL")).scalar()}


@router.get("/admin/jobs", tags=["Administration"])
def jobs(p=Depends(require("admin.read", "procurement.read", "workforce.read")), db=Depends(get_db)):
    return rows(db.execute(select(Job).order_by(Job.id.desc()).limit(100)).scalars())


@router.get("/admin/integrations", tags=["Administration"])
def integrations(p=Depends(require("admin.read"))):
    """The integration boundaries and what currently sits behind each one."""
    mk = lambda name, iface, impl, note: {"name": name, "interface": iface, "implementation": impl, "status": "simulator", "note": note}
    return [
        mk("Payment provider", "adapters.base.PaymentProvider", "MockPaymentProvider", "Card data never enters this platform; only opaque provider references are stored."),
        mk("POS / e-commerce price gateway", "adapters.base.PosGateway", "MockPosGateway", "Receives price and promotion publications; acknowledges per terminal."),
        mk("Warehouse scanners", "adapters.base.WarehouseScanner", "MockScanner", "Confirms task completion."),
        mk("Vehicle tracking", "adapters.base.VehicleTracking", "MockVehicleTracking", "Supplies live ETAs, kept separate from planned arrival."),
        mk("Proof of delivery", "adapters.base.ProofOfDelivery", "MockProofOfDelivery", "Returns a POD reference on store receipt."),
        mk("HR / payroll", "adapters.base.HrPayrollGateway", "MockHrGateway", "Timesheets are exported; payroll and employment-law rules live in the HR system."),
        mk("Supplier EDI", "adapters.base.SupplierGateway", "MockSupplierGateway", "Sends approved purchase orders."),
        mk("Loyalty programme", "adapters.base.LoyaltyProgrammeGateway", "DemoLoyaltyGateway", "Future integration point; demo policies only."),
        mk("Insight summariser", "adapters.base.InsightProvider", "RuleBasedInsights", "Deterministic; an LLM-backed provider can implement the same read-only interface."),
        mk("Document store", "storage.DocumentStore", "S3Store (MinIO) / LocalStore", "S3-compatible object storage."),
    ]


EXPORTS = {
    "sales": ("exec.read", "SELECT number, site_id, channel, at, gross, net, tax, cost, status FROM sales WHERE {scope} ORDER BY id"),
    "stock": ("inventory.read", "SELECT site_id, product_id, lot_id, bucket, qty FROM stock_balances WHERE qty <> 0 AND {scope} ORDER BY 1,2,3"),
    "journal": ("finance.read", "SELECT e.number, e.entry_date, e.source_type, e.source_id, a.code account, l.debit, l.credit, l.site_id FROM journal_lines l JOIN journal_entries e ON e.id=l.entry_id JOIN accounts a ON a.id=l.account_id WHERE {scope} ORDER BY e.id, l.id"),
}


@router.get("/admin/export/{dataset}", tags=["Administration"])
def export(dataset: str, p=Depends(require("export")), db=Depends(get_db)):
    """CSV export. Every export is written to the audit log with the row count."""
    if dataset not in EXPORTS:
        raise not_found("dataset")
    perm, sql = EXPORTS[dataset]
    if not p.has(perm):
        raise DomainError(403, "forbidden", f"Requires {perm}")
    col = "l.site_id" if dataset == "journal" else "site_id"
    data = mappings(db, sql.format(scope=SCOPE.format(c=col)), **p.sql_sites(perm))
    buf = io.StringIO()
    if data:
        w = csv.DictWriter(buf, fieldnames=list(data[0]))
        w.writeheader()
        w.writerows(data)
    audit(db, p, "export", dataset, None, {"rows": len(data)}, sensitive=True)
    db.commit()
    return Response(buf.getvalue(), media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{dataset}.csv"'})


# ------------------------------------------------------------------ documents
@router.post("/documents", tags=["Documents"])
async def upload(entity_type: str = Form(...), entity_id: int = Form(...), file: UploadFile = File(...),
                 p=Depends(require("catalog.write", "supplier.write", "procurement.write")), db=Depends(get_db)):
    data = await file.read()
    if len(data) > 10_000_000:
        raise bad("File too large (10 MB limit)")
    key = storage.store().put(file.filename, data, file.content_type or "application/octet-stream")
    d = Document(entity_type=entity_type, entity_id=entity_id, name=file.filename, content_type=file.content_type,
                 object_key=key, size=len(data), uploaded_by=p.user.id)
    db.add(d)
    audit(db, p, "document.uploaded", entity_type, entity_id, {"name": file.filename})
    db.commit()
    return row(d)


@router.get("/documents", tags=["Documents"])
def documents(entity_type: str, entity_id: int, p=Depends(current_principal), db=Depends(get_db)):
    return rows(db.execute(select(Document).where(Document.entity_type == entity_type, Document.entity_id == entity_id)).scalars())


@router.get("/documents/{doc_id}/download", tags=["Documents"])
def download(doc_id: int, p=Depends(current_principal), db=Depends(get_db)):
    d = get_or_404(db, Document, doc_id)
    audit(db, p, "document.downloaded", d.entity_type, d.entity_id, {"name": d.name})
    db.commit()
    return Response(storage.store().get(d.object_key), media_type=d.content_type or "application/octet-stream",
                    headers={"Content-Disposition": f'attachment; filename="{d.name}"'})
