from decimal import Decimal

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm.exc import StaleDataError

from ...common import audit, bad, conflict, get_or_404, mappings, row, rows
from ...db import get_db
from ...security import require
from .models import Category, Product, ProductBarcode, ProductVersion, TaxCategory

router = APIRouter(prefix="/catalog", tags=["Products"])
MATERIAL = ("name", "brand", "category_id", "tax_category_id", "storage_class", "shelf_life_days", "case_size",
            "cases_per_pallet", "price_floor", "status", "is_weighted")


def snapshot(prod):
    return {k: (str(getattr(prod, k)) if isinstance(getattr(prod, k), Decimal) else getattr(prod, k)) for k in ("sku",) + MATERIAL}


@router.get("/products")
def products(q: str | None = None, status: str | None = None, p=Depends(require("catalog.read")), db=Depends(get_db)):
    return mappings(db, """
        SELECT p.*, c.name category, t.code tax_code, t.rate tax_rate,
               (SELECT string_agg(gtin || ' (' || level || ')', ', ') FROM product_barcodes b WHERE b.product_id=p.id) barcodes,
               (SELECT s.name FROM supplier_products sp JOIN suppliers s ON s.id=sp.supplier_id WHERE sp.product_id=p.id AND sp.is_primary LIMIT 1) primary_supplier,
               (SELECT sp.case_cost FROM supplier_products sp WHERE sp.product_id=p.id AND sp.is_primary LIMIT 1) case_cost
        FROM products p JOIN categories c ON c.id=p.category_id JOIN tax_categories t ON t.id=p.tax_category_id
        WHERE (:q IS NULL OR p.name ILIKE :q OR p.sku ILIKE :q) AND (:st IS NULL OR p.status=:st) ORDER BY p.sku""",
                    q=f"%{q}%" if q else None, st=status)


@router.get("/products/{product_id}")
def product(product_id: int, p=Depends(require("catalog.read")), db=Depends(get_db)):
    prod = get_or_404(db, Product, product_id)
    return row(prod,
               pack_levels=[{"level": "consumer item", "quantity": "1 " + prod.base_uom, "note": "what the customer buys"},
                            {"level": "supplier case", "quantity": f"{prod.case_size} {prod.base_uom}", "note": "what we order and receive"},
                            {"level": "pallet", "quantity": f"{prod.cases_per_pallet} cases", "note": "transport unit"}]
               + ([{"level": "measured quantity", "quantity": "sold by weight (kg, 3 dp)", "note": "priced per kg at the scale"}] if prod.is_weighted else []),
               barcodes=rows(db.execute(select(ProductBarcode).where(ProductBarcode.product_id == product_id)).scalars()),
               versions=rows(db.execute(select(ProductVersion).where(ProductVersion.product_id == product_id).order_by(ProductVersion.version.desc())).scalars()),
               suppliers=mappings(db, "SELECT sp.*, s.name supplier, s.lead_time_days FROM supplier_products sp JOIN suppliers s ON s.id=sp.supplier_id WHERE sp.product_id=:p", p=product_id),
               cost_history=mappings(db, "SELECT ch.*, s.name supplier FROM cost_history ch JOIN supplier_products sp ON sp.id=ch.supplier_product_id JOIN suppliers s ON s.id=sp.supplier_id WHERE sp.product_id=:p ORDER BY ch.effective_from DESC", p=product_id),
               variants=mappings(db, "SELECT id, sku, name, variant_label FROM products WHERE variant_of_id=:p OR id=(SELECT variant_of_id FROM products WHERE id=:p)", p=product_id))


@router.get("/category-list")
def category_list(p=Depends(require("catalog.read")), db=Depends(get_db)):
    return rows(db.execute(select(Category).order_by(Category.name)).scalars())


@router.get("/categories")
def categories(p=Depends(require("catalog.read")), db=Depends(get_db)):
    return {"categories": rows(db.execute(select(Category).order_by(Category.name)).scalars()),
            "tax_categories": rows(db.execute(select(TaxCategory)).scalars())}


class ProductIn(BaseModel):
    sku: str
    name: str
    brand: str | None = None
    category_id: int
    tax_category_id: int
    storage_class: str = "ambient"
    shelf_life_days: int | None = None
    is_weighted: bool = False
    case_size: Decimal = Decimal(1)
    price_floor: Decimal | None = None
    barcode: str | None = None


@router.post("/products")
def create_product(body: ProductIn, p=Depends(require("catalog.write")), db=Depends(get_db)):
    p.check("catalog.write")
    if db.execute(select(Product.id).where(Product.sku == body.sku)).first():
        raise conflict("SKU already exists")
    data = body.model_dump(exclude={"barcode"})
    prod = Product(**data, base_uom="kg" if body.is_weighted else "each")
    db.add(prod)
    db.flush()
    if body.barcode:
        db.add(ProductBarcode(product_id=prod.id, gtin=body.barcode))
    db.add(ProductVersion(product_id=prod.id, version=1, snapshot=snapshot(prod), change_note="Created", changed_by=p.user.id))
    audit(db, p, "product.created", "product", prod.id, snapshot(prod))
    db.commit()
    return row(prod)


class ProductPatch(BaseModel):
    expected_version: int
    change_note: str
    name: str | None = None
    brand: str | None = None
    storage_class: str | None = None
    shelf_life_days: int | None = None
    price_floor: Decimal | None = None
    status: str | None = None


@router.patch("/products/{product_id}")
def patch_product(product_id: int, body: ProductPatch, p=Depends(require("catalog.write")), db=Depends(get_db)):
    """Optimistic concurrency: the caller states the version it edited. Material changes are versioned;
    past sales keep the description they were sold under."""
    p.check("catalog.write")
    prod = get_or_404(db, Product, product_id)
    if prod.version != body.expected_version:
        raise conflict(f"Product was changed by someone else (now version {prod.version}); reload and retry", "stale_version")
    changes = body.model_dump(exclude_none=True, exclude={"expected_version", "change_note"})
    if not changes:
        raise bad("No changes supplied")
    for k, v in changes.items():
        setattr(prod, k, v)
    try:
        db.flush()
    except StaleDataError as e:
        raise conflict("Concurrent update detected; reload and retry", "stale_version") from e
    db.add(ProductVersion(product_id=prod.id, version=prod.version, snapshot=snapshot(prod), change_note=body.change_note, changed_by=p.user.id))
    audit(db, p, "product.updated", "product", prod.id, {"changes": changes, "note": body.change_note})
    db.commit()
    return row(prod)
