from sqlalchemy import JSON, Boolean, Column, Integer, Numeric, String, Text, UniqueConstraint

from ...db import Base, Money, Qty, fk, pk, ts


class Category(Base):
    __tablename__ = "categories"
    id = pk()
    code = Column(String(30), unique=True, nullable=False)
    name = Column(String(120), nullable=False)
    parent_id = fk("categories.id")
    department = Column(String(60))


class TaxCategory(Base):
    __tablename__ = "tax_categories"
    id = pk()
    code = Column(String(20), unique=True, nullable=False)
    name = Column(String(120), nullable=False)
    rate = Column(Numeric(6, 4), nullable=False)


class Product(Base):
    """The consumer item. Its base unit is 'each' or, for weight-based goods, 'kg'.
    Supplier case and pallet are pack levels above it (case_size base units per case)."""
    __tablename__ = "products"
    id = pk()
    sku = Column(String(30), unique=True, nullable=False)
    name = Column(String(200), nullable=False)
    brand = Column(String(80))
    variant_of_id = fk("products.id")
    variant_label = Column(String(80))
    category_id = fk("categories.id", nullable=False)
    tax_category_id = fk("tax_categories.id", nullable=False)
    storage_class = Column(String(10), nullable=False, default="ambient")  # ambient|chilled|frozen
    shelf_life_days = Column(Integer)
    is_weighted = Column(Boolean, nullable=False, default=False)
    base_uom = Column(String(10), nullable=False, default="each")
    case_size = Column(Qty, nullable=False, default=1)
    cases_per_pallet = Column(Integer, nullable=False, default=40)
    price_floor = Column(Money)
    status = Column(String(20), nullable=False, default="active")  # active|delisted|withdrawn
    image_document_id = Column(Integer)
    version = Column(Integer, nullable=False, default=1)
    created_at = ts()
    __mapper_args__ = {"version_id_col": version}


class ProductVersion(Base):
    """Snapshot of every material change, so historical transactions keep their original description."""
    __tablename__ = "product_versions"
    id = pk()
    product_id = fk("products.id", nullable=False)
    version = Column(Integer, nullable=False)
    snapshot = Column(JSON, nullable=False)
    change_note = Column(Text)
    changed_by = Column(Integer)
    changed_at = ts()
    __table_args__ = (UniqueConstraint("product_id", "version"),)


class ProductBarcode(Base):
    __tablename__ = "product_barcodes"
    id = pk()
    product_id = fk("products.id", nullable=False)
    gtin = Column(String(20), unique=True, nullable=False)
    level = Column(String(10), nullable=False, default="each")  # each|case|pallet
