"""TESCO HQ - Enterprise Retail Platform (independent, Tesco-inspired concept; not affiliated with Tesco PLC).

Modular monolith: one deployable, one database, strict domain packages under app/domains/."""
import logging

from fastapi import APIRouter, FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError, OperationalError
from sqlalchemy.orm.exc import StaleDataError

from . import models_registry  # noqa: F401  (imports every model so metadata is complete)
from .common import DomainError, plain
from .config import settings
from .db import SessionLocal
from .domains.analytics import api as analytics
from .domains.catalog import api as catalog
from .domains.distribution import api as distribution
from .domains.finance import api as finance
from .domains.inventory import api as inventory
from .domains.loyalty import api as loyalty
from .domains.online import api as online
from .domains.org import api as org
from .domains.platform import api as platform
from .domains.pricing import api as pricing
from .domains.procurement import api as procurement
from .domains.sales import api as sales
from .domains.suppliers import api as suppliers
from .domains.workforce import api as workforce

log = logging.getLogger("thq")
DISCLAIMER = ("Independent concept inspired by UK supermarket retailing. Not affiliated with, endorsed by, or connected to Tesco PLC. "
              "All stores, suppliers, customers, employees and transactions are fictional.")

app = FastAPI(title="TESCO HQ - Enterprise Retail Platform (independent concept)", version="1.0.0", description=DISCLAIMER + """

**Conventions**
* All routes are versioned under `/api/v1`. Breaking changes will ship as `/api/v2`.
* Authenticate with `POST /api/v1/auth/login`, then send `Authorization: Bearer <token>`.
* Money is GBP, sent as decimal strings. Shelf prices include VAT.
* State-changing integration endpoints accept an `Idempotency-Key` header; replays return the original result with `idempotent_replay: true`.
* Errors: `{"error": {"code", "message", "detail"}}` with 401/403/404/409/422.
""")
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins.split(","), allow_methods=["*"], allow_headers=["*"])

v1 = APIRouter(prefix="/api/v1")
for mod in (platform, org, catalog, suppliers, procurement, inventory, distribution, sales, online, pricing, loyalty, workforce, finance, analytics):
    v1.include_router(mod.router)
app.include_router(v1)


def _err(status, code, message, detail=None):
    return JSONResponse(status_code=status, content={"error": {"code": code, "message": message, "detail": plain(detail)}})


@app.exception_handler(DomainError)
async def domain_error(_: Request, e: DomainError):
    return _err(e.status, e.code, e.message, e.detail)


@app.exception_handler(IntegrityError)
async def integrity_error(_: Request, e: IntegrityError):
    log.warning("integrity error: %s", e.orig)
    return _err(409, "integrity", "The change conflicts with existing data or a database rule", str(e.orig).split("\n")[0])


@app.exception_handler(StaleDataError)
async def stale(_: Request, e: StaleDataError):
    return _err(409, "stale_version", "The record was changed by someone else; reload and retry")


@app.exception_handler(OperationalError)
async def op_error(_: Request, e: OperationalError):
    return _err(409, "concurrency", "The operation could not complete due to a concurrent change; retry", str(e.orig).split("\n")[0])


@app.get("/api/v1/health", tags=["Platform"])
def health():
    with SessionLocal() as db:
        db.execute(text("SELECT 1"))
    return {"status": "ok", "disclaimer": DISCLAIMER}


@app.get("/api/v1/meta", tags=["Platform"])
def meta():
    return {"name": "TESCO HQ - Enterprise Retail Platform", "disclaimer": DISCLAIMER, "currency": settings.currency, "api_version": "v1"}
