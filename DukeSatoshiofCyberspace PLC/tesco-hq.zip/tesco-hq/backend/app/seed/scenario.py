"""The 12-step demonstration, played through the public HTTP API with the demo users' own permissions.

Because it uses the API, everything here is also possible from the console, and every guard
(permissions, maker-checker, idempotency, stock and ledger rules) is really exercised."""
from datetime import date, datetime, time, timedelta, timezone

from fastapi.testclient import TestClient

from ..db import SessionLocal
from ..main import app
from ..worker import drain

TODAY = date.today()


class Demo:
    def __init__(self, log=print):
        self.c, self.tok, self.log = TestClient(app), {}, log

    def h(self, user):
        if user not in self.tok:
            r = self.c.post("/api/v1/auth/login", json={"email": f"{user}@thq.example", "password": "demo1234"})
            self.tok[user] = r.json()["token"]
        return {"Authorization": "Bearer " + self.tok[user]}

    def call(self, user, method, path, body=None, expect=200, key=None, **kw):
        headers = self.h(user)
        if key:
            headers["Idempotency-Key"] = key
        r = self.c.request(method, "/api/v1" + path, json=body, headers=headers, **kw)
        if r.status_code != expect:
            raise AssertionError(f"{user} {method} {path}: expected {expect}, got {r.status_code}: {r.text[:600]}")
        return r.json() if r.headers.get("content-type", "").startswith("application/json") else r.text

    def get(self, user, path, **kw):
        return self.call(user, "GET", path, **kw)

    def post(self, user, path, body=None, **kw):
        return self.call(user, "POST", path, body or {}, **kw)

    def approve(self, user, kind, entity_id=None, reason="Approved"):
        for a in self.get(user, "/approvals?status=pending"):
            if a["kind"] == kind and (entity_id is None or a["entity_id"] == entity_id):
                return self.post(user, f"/approvals/{a['id']}/decision", {"approve": True, "reason": reason})
        raise AssertionError(f"no pending {kind} approval for {entity_id}")

    def step(self, n, title):
        self.log(f"\n[{n:>2}] {title}")

    def note(self, msg):
        self.log(f"     - {msg}")


def run_scenario(log=print):
    d = Demo(log)
    sites = {s["code"]: s for s in d.get("admin", "/org/sites")}
    prods = {p["sku"]: p for p in d.get("admin", "/catalog/products")}
    dc, st1 = sites["DC01"]["id"], sites["ST01"]["id"]
    terms = {t["code"]: t["id"] for t in d.get("admin", "/pos/terminals")}

    d.step(1, "Forecast demand (buyer)")
    run = d.post("buyer", "/procurement/forecasts/run", {"horizon_days": 14, "holdout_days": 14})
    ev = run["evaluation"]
    d.note(f"run #{run['id']}: chose '{run['chosen_method']}' - WAPE " + ", ".join(f"{k} {v['wape_pct']}%" for k, v in ev.items() if not k.startswith('_')))
    d.note(f"{run['censored_days']} stock-out days were un-censored so lost sales are not read as low demand")

    d.step(2, "Recommend replenishment for the distribution centre (buyer)")
    d.post("buyer", "/procurement/recommendations/run", {"site_id": dc})
    recs = d.get("buyer", "/procurement/recommendations")
    limited = [r for r in recs if r["recommended_cases"] != r["unconstrained_cases"]]
    d.note(f"{len(recs)} recommendations; {len(limited)} changed by a constraint (MOQ, capacity, expiry, calendar, supplier, working capital)")
    for r in limited[:4]:
        d.note(f"{r['sku']} {r['product']}: {r['unconstrained_cases']} -> {r['recommended_cases']} cases: " + "; ".join(c['effect'] for c in r['constraints'] if c['constraint'] != 'case_pack')[:170])
    by_sup = {}
    for r in recs:
        by_sup.setdefault(r["supplier"], []).append(r)
    overridden = False
    for sup, rs in by_sup.items():
        for r in rs:
            if r["recommended_cases"] <= 0 or not r["supplier_id"]:
                continue
            if sup and sup.startswith("Castlegate") and r["sku"] == "G6001" and not overridden:
                d.post("buyer", f"/procurement/recommendations/{r['id']}/decide", {"action": "override", "cases": r["recommended_cases"] + 2,
                       "reason": "BEANS-25 promotion uplift is not in the baseline forecast"})
                overridden = True
                d.note(f"override recorded on {r['sku']}: {r['recommended_cases']} -> {r['recommended_cases'] + 2} cases, with reason")
            elif sup and sup.startswith("Northstar"):
                continue  # leave frozen recommendations open for the console
            else:
                d.post("buyer", f"/procurement/recommendations/{r['id']}/decide", {"action": "accept"})
    reqs = [r for r in d.get("buyer", "/procurement/requisitions") if r["status"] == "open"]
    pos = {}
    for r in reqs:
        today_del = r["supplier"].startswith(("Pennine", "Hearth"))
        po = d.post("buyer", f"/procurement/requisitions/{r['id']}/convert", {"expected_date": TODAY.isoformat()} if today_del else {})
        pos[r["supplier"]] = po
        d.note(f"{po['number']} raised for {r['supplier']}: {po['net_total']} net, awaiting approval")

    d.step(3, "Approve purchase orders (procurement manager) - maker-checker")
    dairy = pos.get("Pennine Dairies Ltd") or next(iter(pos.values()))
    d.post("store.ashbourne", f"/approvals/{[a for a in d.get('admin', '/approvals?status=pending') if a['kind'] == 'purchase_order'][0]['id']}/decision",
           {"approve": True}, expect=403)
    d.note("a store manager trying to approve a PO is refused (403)")
    approved = 0
    for name, po in pos.items():
        if name.startswith(("Pennine", "Hearth", "Fenland", "Castlegate")):
            d.approve("procurement.manager", "purchase_order", po["id"], "Within weekly plan")
            approved += 1
    d.note(f"{approved} POs approved; {len(pos) - approved} left pending in the approvals inbox")

    d.step(4, "Receive a partial, late delivery with damage (warehouse)")
    det = d.get("warehouse", f"/procurement/purchase-orders/{dairy['id']}")
    lines = []
    big = max(det["lines"], key=lambda l: l["cases_ordered"])
    for l in det["lines"]:
        short = max(1, l["cases_ordered"] // 4) if l is big and l["cases_ordered"] >= 2 else 0
        dmg = 1 if (l is not big or len(det["lines"]) == 1) and l["cases_ordered"] - short >= 2 else 0
        lines.append({"po_line_id": l["id"], "cases_received": l["cases_ordered"] - short - dmg, "cases_damaged": dmg, "lot_code": f"PD-{TODAY:%y%m%d}-{l['sku']}"})
    arrived = datetime.combine(TODAY, time(9, 35), tzinfo=timezone.utc).isoformat()
    body = {"delivery_note_ref": "DN-PD-77120", "arrived_at": arrived, "lines": lines}
    r1 = d.post("warehouse", f"/procurement/purchase-orders/{dairy['id']}/receipts", body, key="demo-receipt-1")
    r2 = d.post("warehouse", f"/procurement/purchase-orders/{dairy['id']}/receipts", body, key="demo-receipt-1")
    d.note(f"{dairy['number']} now '{r1['po_status']}'; arrived 95 min after its slot -> late-delivery exception; damaged case -> supplier return")
    d.note(f"duplicate message (same Idempotency-Key) returned the original receipt: replay={r2.get('idempotent_replay')}")
    d.post("warehouse", f"/procurement/purchase-orders/{dairy['id']}/receipts", body, expect=409)
    d.note("re-keying the same delivery note without the key is rejected (409 duplicate_receipt): stock cannot be received twice")
    d.post("warehouse", "/distribution/tasks/complete-all?kind=putaway", {"dc_id": dc})

    d.step(5, "Allocate stock to stores, pick, plan routes, deliver (warehouse / stores)")
    trs = d.post("warehouse", "/distribution/allocations/run", {"dc_id": dc})["transfers"]
    d.note(f"{len(trs)} store transfers created; DC stock reserved lot-by-lot (FEFO)")
    d.post("warehouse", "/distribution/waves", {"dc_id": dc})
    picks = d.get("warehouse", "/distribution/tasks?kind=pick")
    t0 = next(t for t in picks if float(t["qty"]) >= 8)
    d.post("warehouse", f"/distribution/tasks/{t0['id']}/complete", {"qty_done": float(t0["qty"]) - float(prods[t0["sku"]]["case_size"])})
    d.note(f"short pick on {t0['transfer']} ({t0['product']}): one case not found -> reservation released, discrepancy raised")
    for kind in ("pick", "pack", "stage"):
        d.post("warehouse", f"/distribution/tasks/complete-all?kind={kind}", {"dc_id": dc})
    plan = d.post("warehouse", "/distribution/route-plans", {"dc_id": dc, "day": TODAY.isoformat(), "depart": "05:00:00"})
    for inf in plan["infeasible"]:
        d.note(f"INFEASIBLE: {inf['transfer']} to {inf['store']}: {inf['reasons'][0]}")
    plans = d.get("warehouse", "/distribution/route-plans")[0]
    stops = []
    for r in plans["routes"]:
        d.post("warehouse", f"/distribution/routes/{r['id']}/dispatch")
        d.note(f"{r['fleet_no']} dispatched with {r['load_cages']} cages, {len(r['stops'])} stop(s)")
        stops += r["stops"]
    for i, s in enumerate(stops):
        if i == len(stops) - 1 and len(stops) > 2:
            d.note(f"stop at {s['site']} left en route (planned {s['planned_arrival'][11:16]}; live ETA from tracking shown separately)")
        elif i == 1:
            d.post("warehouse", f"/distribution/stops/{s['id']}/fail", {"reason": "Store yard blocked by roadworks - could not unload"})
            d.note(f"FAILED delivery at {s['site']}: load returned to DC stock")
        else:
            d.post("warehouse", f"/distribution/stops/{s['id']}/confirm", {"receiver": "Duty manager"})
            d.note(f"{s['site']} confirmed receipt (proof of delivery captured)")

    d.step(6, "Prices and promotions: propose -> approve -> publish -> confirm per endpoint")
    t1 = datetime.combine(TODAY + timedelta(days=1), time(0, 0), tzinfo=timezone.utc)
    cola = [prods["K7001"]["id"], prods["K7002"]["id"]]
    pm = d.post("pricing.analyst", "/pricing/promotions", {"code": "FIZZ-3FOR5", "name": "3 for 5.00 on 2L soft drinks", "kind": "multibuy",
                "params": {"buy_qty": 3, "for_price": "5.00"}, "product_ids": cola, "starts_at": t1.isoformat(), "ends_at": (t1 + timedelta(days=7)).isoformat(), "priority": 20})
    d.approve("pricing.manager", "promotion", pm["promotion"]["id"], "In the trading plan")
    d.post("pricing.manager", f"/pricing/promotions/{pm['promotion']['id']}/publish")
    d.note("FIZZ-3FOR5 approved and published, scheduled to start at midnight")
    pm2 = d.post("pricing.analyst", "/pricing/promotions", {"code": "COLA-15", "name": "15% off Cola 2L", "kind": "percent_off", "params": {"pct": 15},
                 "product_ids": [prods["K7001"]["id"]], "starts_at": t1.isoformat(), "ends_at": (t1 + timedelta(days=5)).isoformat(), "priority": 10})
    d.note(f"COLA-15 overlaps {[c['code'] for c in pm2['conflicts']]} -> promotion-conflict exception; precedence: {pm2['conflicts'][0]['resolution']}")
    d.approve("pricing.manager", "promotion", pm2["promotion"]["id"], "Accepted: multibuy takes precedence")
    d.post("pricing.manager", f"/pricing/promotions/{pm2['promotion']['id']}/publish")
    lots = d.get("admin", f"/inventory/lots?site_id={st1}&product_id={prods['B3003']['id']}")
    md = d.post("pricing.analyst", "/pricing/promotions", {"code": "MD-CROISSANT", "name": "Short-dated: 30% off croissants (lot)", "kind": "markdown", "params": {"pct": 30},
                "product_ids": [prods["B3003"]["id"]], "site_ids": [st1], "lot_id": lots[0]["lot_id"], "starts_at": (datetime.now(timezone.utc) - timedelta(minutes=1)).isoformat(),
                "ends_at": (t1 + timedelta(days=1)).isoformat()})
    d.approve("pricing.manager", "promotion", md["promotion"]["id"], "Reduce waste")
    d.post("pricing.manager", f"/pricing/promotions/{md['promotion']['id']}/publish")
    nat = d.get("pricing.analyst", "/pricing/price-books")[0]["id"]
    e = d.post("pricing.analyst", "/pricing/prices", {"price_book_id": nat, "product_id": prods["B3001"]["id"], "price": "1.09", "effective_from": t1.isoformat(), "reason": "Flour cost increase"})
    d.note(f"B3001 0.99 -> 1.09 (10.1%) is above the 5% threshold: status '{e['status']}'")
    d.approve("pricing.manager", "price_change", e["id"], "Cost-driven; competitor check done")
    d.post("pricing.manager", f"/pricing/prices/{e['id']}/publish")
    e2 = d.post("pricing.analyst", "/pricing/prices", {"price_book_id": nat, "product_id": prods["D2004"]["id"], "price": "2.05", "effective_from": t1.isoformat(), "reason": "Rounding review"})
    d.note(f"D2004 1.99 -> 2.05 (3.0%) is below the threshold: status '{e2['status']}' without a second approver (still audited)")
    d.post("pricing.analyst", "/pricing/prices", {"price_book_id": nat, "product_id": prods["W9002"]["id"], "price": "8.50", "effective_from": t1.isoformat(), "reason": "Duty change"})
    d.post("pricing.analyst", "/pricing/prices", {"price_book_id": nat, "product_id": prods["W9001"]["id"], "price": "3.00", "effective_from": t1.isoformat(), "reason": "Test"}, expect=422)
    d.note("a price below the product floor is rejected outright (422 below_floor)")
    with SessionLocal() as db:
        drain(db)
    pubs = d.get("pricing.manager", "/pricing/publications")
    bad = [p for p in pubs if p["status"] != "acknowledged"]
    d.note(f"{len(pubs) - len(bad)} endpoint acknowledgements; {len(bad)} NOT confirmed (terminal {bad[0]['terminal']} offline) -> published is not the same as applied")

    d.step(7, "Simulated store sale with member card, multibuy and coupon (store manager)")
    basket = {"site_id": st1, "terminal_id": terms["ST01-TILL-1"], "member": "M-0003", "coupon_codes": ["M0003-2OFF"], "tender": "card",
              "lines": [{"sku": "D2001", "qty": 2}, {"sku": "D2003", "qty": 1}, {"sku": "G6001", "qty": 2}, {"sku": "K7001", "qty": 1},
                        {"sku": "P1001", "qty": "0.750"}, {"sku": "B3003", "qty": 1, "lot_id": lots[0]["lot_id"]}]}
    sim = d.post("pricing.analyst", "/pricing/simulate", {k: v for k, v in basket.items() if k != "tender"})
    sale = d.post("store.ashbourne", "/pos/sales", basket, key="demo-sale-1")
    again = d.post("store.ashbourne", "/pos/sales", basket, key="demo-sale-1")
    d.note(f"{sale['number']}: {sale['gross_before_discount']} before, {sale['discount']} discount, {sale['gross']} charged (net {sale['net']} + VAT {sale['tax']})")
    for rule in sim["rules"]:
        if " saves " in rule or "Coupon" in rule:
            d.note("rule: " + rule[:150])
    d.note(f"simulator total {sim['totals']['gross']} equals till total {sale['gross']}; duplicate POS message returned {again['number']} (replay={again.get('idempotent_replay')})")
    d.post("store.thornfield", "/pos/sales", basket, expect=403)
    d.note("a manager from another store cannot sell at this store (403, site scope)")

    d.step(8, "Online orders: reservation, substitution, uncertain payment, duplicate request")
    slots = [s for s in d.get("service", "/online/slots") if s["site_id"] == st1 and s["remaining"] >= 4 and s["method"] == "delivery"]
    slot = slots[-1]["id"]
    custs = {c["ref"]: c for c in d.get("service", "/online/customers")}
    ob = {"customer_id": custs["C-0001"]["id"], "slot_id": slot, "payment_token": "tok_ok",
          "lines": [{"sku": "D2001", "qty": 2}, {"sku": "B3001", "qty": 1}, {"sku": "M4002", "qty": 1}, {"sku": "G6002", "qty": 2}, {"sku": "H8001", "qty": 1}]}
    o1 = d.post("service", "/online/orders", ob, key="demo-order-1")
    o1b = d.post("service", "/online/orders", ob, key="demo-order-1")
    d.note(f"{o1['number']} placed: order={o1['order_status']}, payment={o1['payment_status']}, fulfilment={o1['fulfilment_status']}; retry returned the same order (replay={o1b.get('idempotent_replay')}), one authorisation only")
    bread = next(l for l in o1["lines"] if l["sku"] == "B3001")
    o1 = d.post("store.ashbourne", f"/online/orders/{o1['id']}/pick", {"lines": [{"line_id": bread["id"], "picked_qty": 0, "substitute_sku": "B3002"}]})
    sub = next(l for l in o1["lines"] if l["sub_sku"])
    d.note(f"substitution: {sub['description']} -> {sub['sub_description']}; shelf {sub['sub_shelf_price']}, charged {sub['sub_charged_price']} (difference {sub['sub_price_difference']} absorbed), consent pending")
    d.post("store.ashbourne", f"/online/orders/{o1['id']}/dispatch")
    o1 = d.post("store.ashbourne", f"/online/orders/{o1['id']}/handover", {"substitution_decisions": {str(sub["id"]): "accepted"}}, key="demo-handover-1")
    d.note(f"handed over: order={o1['order_status']}, payment={o1['payment_status']} ({o1['gross_final']} captured of {o1['gross_estimated']} authorised), fulfilment={o1['fulfilment_status']}")
    ob2 = dict(ob, customer_id=custs["C-0002"]["id"], payment_token="tok_timeout", lines=[{"sku": "K7003", "qty": 2}, {"sku": "G6005", "qty": 1}])
    o2 = d.post("service", "/online/orders", ob2, key="demo-order-2")
    d.note(f"{o2['number']}: provider timed out -> payment '{o2['payment_status']}', order stays '{o2['order_status']}', exception raised; no retry charge is sent")
    o2 = d.post("service", f"/online/orders/{o2['id']}/resolve-payment")
    d.note(f"provider lookup with the original key -> payment '{o2['payment_status']}', order '{o2['order_status']}' (still exactly one authorisation)")
    o3 = d.post("service", "/online/orders", dict(ob2, payment_token="tok_declined", customer_id=custs["C-0004"]["id"]), key="demo-order-3")
    d.note(f"{o3['number']}: card declined -> order '{o3['order_status']}', stock released, slot freed")
    ob4 = dict(ob, customer_id=custs["C-0003"]["id"], lines=[{"sku": "D2005", "qty": 2}, {"sku": "P1002", "qty": 1}])
    o4 = d.post("service", "/online/orders", ob4, key="demo-order-4")
    yog = next(l for l in o4["lines"] if l["sku"] == "D2005")
    d.post("store.ashbourne", f"/online/orders/{o4['id']}/pick", {"lines": [{"line_id": yog["id"], "picked_qty": 1, "substitute_sku": "D2003"}]}, expect=409)
    d.note(f"{o4['number']}: customer preference is 'no substitutions' -> substitution refused (409); line picked short instead")
    d.post("store.ashbourne", f"/online/orders/{o4['id']}/pick", {"lines": [{"line_id": yog["id"], "picked_qty": 1}]})
    d.post("store.ashbourne", f"/online/orders/{o4['id']}/dispatch")
    d.post("store.ashbourne", f"/online/orders/{o4['id']}/handover", {})
    pasta = next(l for l in o1["sale_lines"] if "Penne" in l["description"])
    rb = {"lines": [{"sale_line_id": pasta["id"], "qty": 1, "disposition": "none"}], "reason": "Item missing from delivery"}
    rf = d.post("service", f"/online/orders/{o1['id']}/refunds", rb, key="demo-refund-1")
    rf2 = d.post("service", f"/online/orders/{o1['id']}/refunds", rb, key="demo-refund-1")
    d.note(f"customer-service refund {rf['return']['number']} for {rf['return']['gross']}; double-click replay refunded nothing more (replay={rf2.get('idempotent_replay')})")
    d.post("service", "/online/cases", {"customer_id": custs["C-0001"]["id"], "order_id": o1["id"], "category": "missing_item", "subject": "Pasta missing from delivery", "note": "Refunded one unit."})

    d.step(9, "Loyalty points awarded once")
    m = d.get("loyalty", "/loyalty/members/3")
    earn = [l for l in m["ledger"] if l["ref_type"] == "sale" and l["ref_id"] == sale["id"]]
    d.note(f"member {m['member_no']}: {earn[0]['points']} points for {sale['number']} (one ledger row despite the replayed sale); balance {m['points_balance']} = ledger sum {m['ledger_sum']}")

    d.step(10, "Return an item and reverse the entries (store manager)")
    beans = next(l for l in sale["lines"] if l["sku"] == "G6001")
    rb = {"lines": [{"sale_line_id": beans["id"], "qty": 1, "disposition": "restock"}], "reason": "Customer changed mind"}
    ret = d.post("store.ashbourne", f"/sales/{sale['id']}/returns", rb, key="demo-return-1")
    d.post("store.ashbourne", f"/sales/{sale['id']}/returns", rb, key="demo-return-1")
    r = ret["return"]
    d.note(f"{r['number']}: refunded {r['gross']} at the price paid, stock back to available, {r['points_reversed']} points reversed")
    for j in ret["sale"]["journal"]:
        if j["source_type"] == "sale_return":
            d.note(f"journal {j['number']}: {j['code']} {j['account'][:34]:<34} Dr {j['debit']:>6}  Cr {j['credit']:>6}")
    d.post("store.ashbourne", f"/sales/{sale['id']}/returns", {"lines": [{"sale_line_id": beans["id"], "qty": 5, "disposition": "restock"}], "reason": "x"}, expect=409)
    d.note("returning more than was bought is refused (409 over_return)")

    d.step(11, "Three-way invoice match and payment approval (finance)")
    det = d.get("finance.clerk", f"/procurement/purchase-orders/{dairy['id']}")
    il = [{"po_line_id": l["id"], "cases": l["cases_received"], "case_cost": l["case_cost"]} for l in det["lines"] if l["cases_received"]]
    net = sum(round(x["cases"] * float(x["case_cost"]), 2) for x in il)
    inv = d.post("finance.clerk", "/finance/invoices", {"supplier_id": det["supplier_id"], "po_id": det["id"], "invoice_no": "PD-INV-90411", "invoice_date": TODAY.isoformat(), "net": f"{net:.2f}", "tax": "0.00", "lines": il})
    inv = d.post("finance.clerk", f"/finance/invoices/{inv['id']}/match")
    d.note(f"invoice {inv['invoice_no']} ({inv['gross']}): '{inv['status']}' - billed only for cases accepted, not the short or damaged ones")
    d.post("finance.clerk", f"/finance/invoices/{inv['id']}/request-payment")
    pay = [a for a in d.get("finance.clerk", "/approvals?status=pending") if a["kind"] == "supplier_payment"][0]
    d.post("finance.clerk", f"/approvals/{pay['id']}/decision", {"approve": True}, expect=403)
    d.note("the clerk who requested the payment cannot approve it (403 maker_checker)")
    d.approve("finance.controller", "supplier_payment", None, "Matched and within terms")
    over = [dict(x, cases=x["cases"] + 2) for x in il[:1]]
    inv2 = d.post("finance.clerk", "/finance/invoices", {"supplier_id": det["supplier_id"], "po_id": det["id"], "invoice_no": "PD-INV-90412", "invoice_date": TODAY.isoformat(),
                  "net": f"{over[0]['cases'] * float(over[0]['case_cost']):.2f}", "tax": "0.00", "lines": over})
    inv2 = d.post("finance.clerk", f"/finance/invoices/{inv2['id']}/match")
    d.note(f"second invoice bills cases never received -> '{inv2['status']}': {inv2['match_result']['problems'][0][:110]}")
    s = d.post("finance.clerk", "/finance/settlements/import", {"business_date": (TODAY - timedelta(days=2)).isoformat()})
    d.note(f"card settlement {s['batch_ref']}: provider gross {s['gross']}, fees {s['fees']}, net {s['net']} -> '{s['status']}'")
    tb = d.get("finance.controller", "/finance/trial-balance")
    d.note(f"trial balance: Dr {tb['total_debit']} = Cr {tb['total_credit']} (balanced={tb['balanced']})")

    d.step(12, "Review margin, waste and availability (executive)")
    # supporting activity so every workspace has something to act on
    import math
    dc_lots = [l for l in d.get("warehouse", f"/inventory/lots?site_id={dc}") if float(l["available"]) * float(l["unit_cost"]) > 45 and not l["lot_code"].startswith("PD-")]
    big = dc_lots[0]
    var = math.ceil(30 / float(big["unit_cost"]))
    cc = d.post("warehouse", "/inventory/cycle-counts", {"site_id": dc, "product_id": big["product_id"], "lot_id": big["lot_id"], "counted_qty": float(big["available"]) - var})
    d.note(f"cycle count at the DC: -{var} x {big['product']} is above the approval value -> '{cc['status']}' (a second person must approve)")
    st_lots = [l for l in d.get("store.ashbourne", f"/inventory/lots?site_id={st1}") if float(l["available"]) >= 3 and float(l["unit_cost"]) < 2]
    small = st_lots[0]
    cc2 = d.post("store.ashbourne", "/inventory/cycle-counts", {"site_id": st1, "product_id": small["product_id"], "lot_id": small["lot_id"], "counted_qty": float(small["available"]) - 1})
    d.note(f"cycle count in store: -1 x {small['product']} is immaterial -> '{cc2['status']}' immediately, with ledger entry")
    w_ = st_lots[1]
    d.post("store.ashbourne", "/inventory/adjustments", {"site_id": st1, "product_id": w_["product_id"], "lot_id": w_["lot_id"], "bucket": "available", "qty_delta": -1, "kind": "waste", "reason": "Damaged in store"})
    ice = d.get("admin", f"/inventory/lots?site_id={dc}&product_id={prods['F5003']['id']}")[0]
    w = d.post("admin", "/inventory/withdrawals", {"product_id": prods["F5003"]["id"], "lot_id": ice["lot_id"], "reason": "Supplier notification: possible undeclared allergen (demonstration)"})
    d.note(f"product withdrawal on one ice-cream lot: {w['summary']['quarantined_now']} units quarantined; {w['summary']['sales_transactions_affected']} sales counted, no customer identities read")
    emp = d.get("hr", "/workforce/employees")[0]
    sh = [x for x in d.get("hr", "/workforce/shifts?days=10") if x["employee_id"] == emp["id"]]
    if sh:
        end = datetime.fromisoformat(sh[0]["ends_at"])
        r = d.call("hr", "POST", "/workforce/shifts", {"employee_id": emp["id"], "starts_at": (end + timedelta(hours=4)).isoformat(), "ends_at": (end + timedelta(hours=10)).isoformat(), "duty": "Shop floor"}, expect=409)
        d.note("rota: " + r["error"]["message"][:150])
    csv = "employee_no,work_date,hours\n" + "\n".join(f"{e['employee_no']},{TODAY - timedelta(days=1)},{7.5 if i % 2 else 6}" for i, e in enumerate(d.get("hr", "/workforce/employees")[:12])) + "\nE9999,bad-date,x\n"
    for _ in range(2):  # the same file twice: second import is all duplicates
        d.c.post("/api/v1/workforce/timesheets/import", headers=d.h("hr"), files={"file": ("timesheets_week.csv", csv, "text/csv")})
    u = next(x for x in d.get("admin", "/admin/users") if x["email"].startswith("analyst@"))
    d.post("admin", "/admin/role-grants", {"user_id": u["id"], "role": "pricing_analyst", "scope_type": "global", "justification": "Covering pricing desk for two weeks"})
    d.post("admin", f"/approvals/{[a for a in d.get('admin', '/approvals?status=pending') if a['kind'] == 'role_grant'][0]['id']}/decision", {"approve": True}, expect=403)
    d.note("permission change requested by one administrator; they cannot approve it themselves - left pending for the security administrator")
    with SessionLocal() as db:
        drain(db)
    ov = d.get("exec", "/executive/overview?days=14")
    for mtr in ov["flow"] + ov["kpis"]:
        d.note(f"{mtr['label']}: {mtr['value']} {mtr['unit']}")
    ins = d.get("exec", "/analytics/insights")
    d.note(f"{sum(i['count'] for i in ins['items'])} open exceptions summarised with citations ({ins['provider']})")
    integ = d.get("admin", "/inventory/integrity")
    d.note(f"stock ledger conservation: balanced={integ['balanced']} over {integ['movements']} movements; loyalty ledger balanced={d.get('admin', '/loyalty/integrity')['balanced']}")
