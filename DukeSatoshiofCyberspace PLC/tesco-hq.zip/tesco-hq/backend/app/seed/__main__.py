"""python -m app.seed [--reset] [--no-scenario]

Loads fictional master data and trading history, then plays the 12-step demonstration scenario
through the public API so the console opens with realistic, fully traceable activity."""
import sys
import time

from sqlalchemy import text

from .. import ddl, models_registry  # noqa: F401
from ..cache import cache_bust
from ..db import Base, SessionLocal, engine


def main():
    reset = "--reset" in sys.argv
    with SessionLocal() as db:
        seeded = db.execute(text("SELECT to_regclass('public.users')")).scalar() and db.execute(text("SELECT count(*) FROM users")).scalar()
    if seeded and not reset:
        print("Database already contains data; nothing to do (use --reset to rebuild).")
        return
    if reset:
        print("Resetting database ...")
        with engine.begin() as c:
            c.execute(text("DROP SCHEMA public CASCADE; CREATE SCHEMA public"))
        from alembic import command
        from alembic.config import Config
        command.upgrade(Config("alembic.ini"), "head")
    t = time.time()
    from .master import seed_master
    print("Seeding fictional demonstration data ...")
    with SessionLocal() as db:
        ctx = seed_master(db)
    if "--no-scenario" not in sys.argv:
        from .scenario import run_scenario
        run_scenario()
    from ..worker import drain
    with SessionLocal() as db:
        drain(db)
    cache_bust("exec:")
    print(f"Done in {time.time() - t:.0f}s. Sign in with any demo user (password: demo1234), e.g. exec@thq.example")


if __name__ == "__main__":
    main()
