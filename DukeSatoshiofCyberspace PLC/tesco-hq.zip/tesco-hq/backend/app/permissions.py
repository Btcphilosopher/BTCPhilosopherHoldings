"""Permission catalogue and role definitions.

Role definitions are code-reviewed configuration; *grants* of roles to users are data and go
through maker-checker approval (see domains/platform/approvals.py)."""

PERMISSIONS = {
    "exec.read": "View executive overview",
    "org.read": "View stores and hierarchy", "org.write": "Maintain stores and hierarchy",
    "catalog.read": "View products", "catalog.write": "Maintain products",
    "supplier.read": "View suppliers", "supplier.write": "Maintain suppliers",
    "procurement.read": "View procurement", "procurement.write": "Raise requisitions, POs, receipts",
    "procurement.approve": "Approve purchase orders and overrides",
    "inventory.read": "View inventory", "inventory.write": "Post stock transactions",
    "inventory.approve": "Approve stock adjustments and withdrawals",
    "distribution.read": "View distribution", "distribution.write": "Operate warehouse and transport",
    "online.read": "View online orders", "online.write": "Operate online fulfilment",
    "service.write": "Handle customer-service cases and refunds",
    "pos.write": "Process store sales and returns",
    "pricing.read": "View prices and promotions", "pricing.write": "Propose prices and promotions",
    "pricing.approve": "Approve and publish prices and promotions",
    "loyalty.read": "View loyalty programme", "loyalty.write": "Administer loyalty",
    "loyalty.member.read": "View member personal data (sensitive)",
    "workforce.read": "View rotas and tasks", "workforce.write": "Maintain rotas and tasks",
    "workforce.private.read": "View employee personal data (sensitive)",
    "finance.read": "View finance", "finance.write": "Post and reconcile",
    "finance.approve": "Approve payments",
    "analytics.read": "View analytics", "export": "Export data (audited)",
    "admin.read": "View administration", "admin.write": "Request administrative changes",
    "admin.approve": "Approve permission changes", "audit.read": "View audit log",
}

# business read access: excludes personal data, the audit log and administration
_READ = [p for p in PERMISSIONS if p.endswith(".read") and "private" not in p and "member" not in p and p not in ("audit.read", "admin.read")]

ROLES = {
    "administrator": {"name": "Platform administrator", "perms": list(PERMISSIONS)},
    "executive": {"name": "Executive", "perms": _READ + ["export"]},
    "hq_analyst": {"name": "Headquarters analyst", "perms": [
        "exec.read", "org.read", "catalog.read", "supplier.read", "procurement.read", "inventory.read",
        "distribution.read", "online.read", "pricing.read", "loyalty.read", "analytics.read", "export"]},
    "buyer": {"name": "Buyer", "perms": [
        "exec.read", "org.read", "catalog.read", "catalog.write", "supplier.read", "supplier.write",
        "procurement.read", "procurement.write", "inventory.read", "pricing.read", "analytics.read"]},
    "procurement_manager": {"name": "Procurement manager", "perms": [
        "exec.read", "org.read", "catalog.read", "supplier.read", "procurement.read", "procurement.write",
        "procurement.approve", "inventory.read", "analytics.read"]},
    "pricing_analyst": {"name": "Pricing analyst", "perms": [
        "org.read", "catalog.read", "pricing.read", "pricing.write", "analytics.read"]},
    "pricing_manager": {"name": "Pricing manager", "perms": [
        "org.read", "catalog.read", "pricing.read", "pricing.write", "pricing.approve", "analytics.read", "exec.read"]},
    "finance_clerk": {"name": "Finance clerk", "perms": [
        "org.read", "catalog.read", "supplier.read", "procurement.read", "finance.read", "finance.write", "inventory.read"]},
    "finance_controller": {"name": "Finance controller", "perms": [
        "exec.read", "org.read", "supplier.read", "procurement.read", "finance.read", "finance.write",
        "finance.approve", "inventory.read", "inventory.approve", "analytics.read", "export"]},
    "hr_partner": {"name": "HR partner", "perms": [
        "org.read", "workforce.read", "workforce.write", "workforce.private.read"]},
    "regional_manager": {"name": "Regional manager", "perms": [
        "exec.read", "org.read", "catalog.read", "inventory.read", "inventory.approve", "distribution.read",
        "online.read", "pricing.read", "workforce.read", "workforce.write", "analytics.read", "procurement.read"]},
    "store_manager": {"name": "Store manager", "perms": [
        "exec.read", "org.read", "catalog.read", "inventory.read", "inventory.write", "distribution.read",
        "distribution.write", "online.read", "online.write", "pos.write", "pricing.read", "workforce.read",
        "workforce.write", "analytics.read", "loyalty.read"]},
    "warehouse_operative": {"name": "Warehouse team", "perms": [
        "org.read", "catalog.read", "inventory.read", "inventory.write", "distribution.read",
        "distribution.write", "procurement.read", "procurement.write"]},
    "customer_service": {"name": "Customer service", "perms": [
        "org.read", "catalog.read", "online.read", "service.write", "loyalty.read", "loyalty.member.read"]},
    "loyalty_manager": {"name": "Loyalty manager", "perms": [
        "catalog.read", "loyalty.read", "loyalty.write", "loyalty.member.read", "pricing.read", "analytics.read"]},
    "auditor": {"name": "Auditor (read-only)", "perms": _READ + ["audit.read", "admin.read"]},
}
