"""Redis is used only for bounded, disposable state: short-TTL read caches and worker wake-ups.
Nothing authoritative lives here; every function fails soft if Redis is unavailable."""
import json
import logging

import redis

from .config import settings

log = logging.getLogger("thq.cache")
_client = None


def client():
    global _client
    if _client is None:
        _client = redis.Redis.from_url(settings.redis_url, socket_timeout=0.5, socket_connect_timeout=0.5,
                                       decode_responses=True)
    return _client


def cache_get(key):
    try:
        raw = client().get("thq:" + key)
        return json.loads(raw) if raw else None
    except Exception:  # noqa: BLE001 - cache must never break a request
        return None


def cache_set(key, value, ttl=30):
    try:
        client().setex("thq:" + key, ttl, json.dumps(value, default=str))
    except Exception:  # noqa: BLE001
        pass


def cache_bust(prefix):
    try:
        c = client()
        for k in c.scan_iter(f"thq:{prefix}*", count=200):
            c.delete(k)
    except Exception:  # noqa: BLE001
        pass


def wake_worker():
    try:
        client().lpush("thq:wake", "1")
        client().ltrim("thq:wake", 0, 9)  # bounded
    except Exception:  # noqa: BLE001
        pass


def wait_for_wake(timeout=2):
    try:
        client().brpop("thq:wake", timeout=timeout)
    except Exception:  # noqa: BLE001
        import time
        time.sleep(timeout)
