"""Cross-cutting helpers shared by every domain: errors, serialisation, money, audit, outbox,
idempotency, exceptions and policy settings."""
import hashlib
import json
from datetime import date, datetime, time, timezone
from decimal import ROUND_HALF_UP, Decimal

from sqlalchemy import select, text
from sqlalchemy.dialects.postgresql import insert as pg_insert

from .domains.platform.models import AuditLog, ExceptionCase, IdempotencyKey, OutboxEvent, Setting

D = Decimal
ZERO = D("0")
PENNY = D("0.01")


class DomainError(Exception):
    def __init__(self, status: int, code: str, message: str, detail=None):
        super().__init__(message)
        self.status, self.code, self.message, self.detail = status, code, message, detail


def bad(message, code="invalid", status=422, detail=None):
    return DomainError(status, code, message, detail)


def conflict(message, code="conflict", detail=None):
    return DomainError(409, code, message, detail)


def not_found(what="record"):
    return DomainError(404, "not_found", f"{what} not found")


def now():
    return datetime.now(timezone.utc)


def q2(x) -> Decimal:
    """Round to pence, half-up (the configured rounding rule; see finance.policy)."""
    return D(str(x)).quantize(PENNY, rounding=ROUND_HALF_UP)


def dec(x) -> Decimal:
    return x if isinstance(x, Decimal) else D(str(x))


def plain(v):
    """Make a value JSON-safe. Decimals become strings so no precision is lost in transit."""
    if isinstance(v, Decimal):
        return format(v, "f")
    if isinstance(v, (datetime, date, time)):
        return v.isoformat()
    if isinstance(v, dict):
        return {k: plain(x) for k, x in v.items()}
    if isinstance(v, (list, tuple, set)):
        return [plain(x) for x in v]
    return v


def row(obj, **extra):
    if obj is None:
        return None
    out = {c.name: plain(getattr(obj, c.name)) for c in obj.__table__.columns if c.name != "password_hash"}
    out.update(plain(extra))
    return out


def rows(items):
    return [row(i) for i in items]


def prep(sql, params):
    """Optional filters are written `(:x IS NULL OR col = :x)`. PostgreSQL cannot infer the type of a
    bare NULL parameter, so resolve the IS NULL test here; real values stay bound parameters."""
    import re
    out = {}
    for k, v in params.items():
        if not re.search(rf":{k}\b", sql):
            continue
        if v is None or v == "":   # an empty filter value means 'no filter'
            sql = re.sub(rf":{k}\s+IS\s+NULL\b", "TRUE", sql)
            sql = re.sub(rf":{k}\b", "NULL", sql)
        else:
            sql = re.sub(rf":{k}\s+IS\s+NULL\b", "FALSE", sql)
            if re.search(rf":{k}\b", sql):
                out[k] = v
    return text(sql), out


def run(db, sql, **params):
    return db.execute(*prep(sql, params))


def mappings(db, sql, **params):
    """Run read-only SQL and return JSON-safe dicts."""
    return [plain(dict(r)) for r in run(db, sql, **params).mappings()]


def get_or_404(db, model, id_, what=None):
    obj = db.get(model, id_)
    if obj is None:
        raise not_found(what or model.__tablename__)
    return obj


# ---------------------------------------------------------------- audit / outbox / exceptions
def audit(db, actor, action, entity_type=None, entity_id=None, detail=None, sensitive=False):
    user = getattr(actor, "user", actor)
    db.add(AuditLog(user_id=getattr(user, "id", None), user_email=getattr(user, "email", "system"),
                    action=action, entity_type=entity_type, entity_id=str(entity_id) if entity_id is not None else None,
                    detail=plain(detail) if detail is not None else None, sensitive=sensitive))


def emit(db, topic, key, payload):
    db.add(OutboxEvent(topic=topic, key=str(key), payload=plain(payload)))


def flag(db, kind, title, *, severity="medium", detail=None, entity_type=None, entity_id=None, site_id=None,
         dedupe=None):
    """Raise an operational exception (idempotent when a dedupe key is given)."""
    if dedupe:
        existing = db.execute(select(ExceptionCase).where(ExceptionCase.dedupe_key == dedupe)).scalar_one_or_none()
        if existing:
            return existing
    ex = ExceptionCase(kind=kind, title=title[:300], severity=severity, detail=detail, entity_type=entity_type,
                       entity_id=entity_id, site_id=site_id, dedupe_key=dedupe)
    db.add(ex)
    db.flush()
    return ex


def insert_once(db, model, **values) -> bool:
    """INSERT ... ON CONFLICT DO NOTHING; True only if this call created the row."""
    stmt = pg_insert(model).values(**values).on_conflict_do_nothing().returning(model.__table__.c.id)
    return db.execute(stmt).first() is not None


# ---------------------------------------------------------------- idempotency
def _hash(payload):
    return hashlib.sha256(json.dumps(plain(payload), sort_keys=True).encode()).hexdigest()


def idem_begin(db, scope, key, payload):
    """Claim an idempotency key inside the current transaction.

    Returns the stored response if this key already completed (the caller must return it unchanged),
    or None if this request owns the key. A concurrent duplicate blocks on the unique index until the
    first transaction commits, then sees its response - so a retry can never create a second effect."""
    if not key:
        return None
    h = _hash(payload)
    if insert_once(db, IdempotencyKey, scope=scope, key=key, request_hash=h):
        return None
    rec = db.execute(select(IdempotencyKey).where(IdempotencyKey.scope == scope, IdempotencyKey.key == key)
                     .with_for_update()).scalar_one()
    if rec.request_hash != h:
        raise bad("Idempotency-Key was already used with a different request body", "idempotency_mismatch")
    if rec.response is None:
        raise conflict("The original request with this Idempotency-Key did not complete; retry later")
    out = dict(rec.response)
    out["idempotent_replay"] = True
    return out


def idem_finish(db, scope, key, response):
    if key:
        db.execute(text("UPDATE idempotency_keys SET response = cast(:r as json) WHERE scope=:s AND key=:k"),
                   {"r": json.dumps(plain(response)), "s": scope, "k": key})
    return response


# ---------------------------------------------------------------- policy settings
DEFAULT_SETTINGS = {
    "finance.policy": ({
        "currency": "GBP", "rounding": "ROUND_HALF_UP to 0.01 per line",
        "shelf_prices_include_vat": True, "card_fee_rate": "0.0120", "settlement_lag_days": 2,
        "revenue_recognition": "At till for store sales; at handover (delivery/collection) for online orders",
        "inventory_valuation": "Specific lot cost (supplier case cost / case size)",
        "status": "DEMONSTRATION POLICY - subject to review by Finance"},
        "Accounting policies used by the demonstration subledger."),
    "pricing.policy": ({
        "approval_threshold_pct": "5", "coupons_per_basket": 1,
        "substitution_charge": "lower_of_original_and_substitute",
        "precedence": ["short-dated markdown (lot specific)", "highest priority exclusive promotion",
                       "best customer saving within the same priority", "stackable promotions",
                       "price floor", "basket coupon"],
        "returns": "Refund at the price actually paid after promotions; coupons are not reinstated"},
        "Promotion precedence, approval threshold and return treatment."),
    "loyalty.policy": ({
        "label": "DEMONSTRATION POLICY - not the rules of any real programme",
        "points_per_pound": 1, "point_value": "0.01", "redeem_multiple": 100, "expiry_months_inactive": 24},
        "Loyalty earn/burn rules (fictional)."),
    "procurement.policy": ({
        "po_approval_threshold": "0", "working_capital_limit": "2600", "invoice_price_tolerance_pct": "1.0",
        "review_period_days": 3, "service_level_z": "1.65", "forecast_horizon_days": 14},
        "Replenishment and invoice-matching tolerances."),
    "inventory.policy": ({"adjustment_approval_value": "25.00"},
                         "Stock adjustments above this cost value need a second approver."),
    "workforce.policy": ({"min_rest_hours": 11, "max_weekly_hours": 48, "max_shift_hours": 10},
                         "Scheduling constraints (configurable; not legal advice)."),
    "analytics.policy": ({"lfl_min_weeks_open": 52},
                         "Like-for-like eligibility: store trading for at least this many weeks before the comparison period."),
}


def get_setting(db, key):
    s = db.get(Setting, key)
    return s.value if s else DEFAULT_SETTINGS[key][0]
