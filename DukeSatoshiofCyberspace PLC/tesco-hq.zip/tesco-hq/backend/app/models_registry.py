"""Import every model module so Base.metadata knows all tables (used by the app, Alembic and tests)."""
from .adapters import models as _a  # noqa: F401
from .domains.catalog import models as _c  # noqa: F401
from .domains.distribution import models as _d  # noqa: F401
from .domains.finance import models as _f  # noqa: F401
from .domains.inventory import models as _i  # noqa: F401
from .domains.loyalty import models as _l  # noqa: F401
from .domains.online import models as _o  # noqa: F401
from .domains.org import models as _g  # noqa: F401
from .domains.platform import models as _p  # noqa: F401
from .domains.pricing import models as _r  # noqa: F401
from .domains.procurement import models as _q  # noqa: F401
from .domains.sales import models as _s  # noqa: F401
from .domains.suppliers import models as _u  # noqa: F401
from .domains.workforce import models as _w  # noqa: F401
