"""Database-level guarantees that must hold regardless of application code.
Executed by the Alembic migration and by the test bootstrap."""

DDL = [
    # 1. The stock-movement ledger is append-only.
    """
    CREATE OR REPLACE FUNCTION thq_forbid_mutation() RETURNS trigger AS $$
    BEGIN
        RAISE EXCEPTION '% is an immutable ledger (% not permitted)', TG_TABLE_NAME, TG_OP;
    END; $$ LANGUAGE plpgsql;
    """,
    "DROP TRIGGER IF EXISTS trg_stock_movements_immutable ON stock_movements",
    """CREATE TRIGGER trg_stock_movements_immutable BEFORE UPDATE OR DELETE ON stock_movements
       FOR EACH ROW EXECUTE FUNCTION thq_forbid_mutation()""",
    "DROP TRIGGER IF EXISTS trg_loyalty_ledger_immutable ON loyalty_ledger",
    """CREATE TRIGGER trg_loyalty_ledger_immutable BEFORE UPDATE OR DELETE ON loyalty_ledger
       FOR EACH ROW EXECUTE FUNCTION thq_forbid_mutation()""",
    "DROP TRIGGER IF EXISTS trg_journal_lines_immutable ON journal_lines",
    """CREATE TRIGGER trg_journal_lines_immutable BEFORE UPDATE OR DELETE ON journal_lines
       FOR EACH ROW EXECUTE FUNCTION thq_forbid_mutation()""",
    "DROP TRIGGER IF EXISTS trg_audit_log_immutable ON audit_log",
    """CREATE TRIGGER trg_audit_log_immutable BEFORE UPDATE OR DELETE ON audit_log
       FOR EACH ROW EXECUTE FUNCTION thq_forbid_mutation()""",
    # 2. Every journal entry balances, checked at commit.
    """
    CREATE OR REPLACE FUNCTION thq_check_journal_balance() RETURNS trigger AS $$
    DECLARE diff numeric;
    BEGIN
        SELECT COALESCE(SUM(debit),0) - COALESCE(SUM(credit),0) INTO diff
        FROM journal_lines WHERE entry_id = NEW.entry_id;
        IF diff <> 0 THEN
            RAISE EXCEPTION 'journal entry % is unbalanced by %', NEW.entry_id, diff;
        END IF;
        RETURN NULL;
    END; $$ LANGUAGE plpgsql;
    """,
    "DROP TRIGGER IF EXISTS trg_journal_balance ON journal_lines",
    """CREATE CONSTRAINT TRIGGER trg_journal_balance AFTER INSERT ON journal_lines
       DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION thq_check_journal_balance()""",
]


def apply(connection):
    from sqlalchemy import text
    for stmt in DDL:
        connection.execute(text(stmt))
