"""Runtime configuration. All secrets come from the environment; nothing is hard-coded for production."""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = "postgresql+psycopg://thq:thq@localhost:5432/thq"
    redis_url: str = "redis://localhost:6379/0"
    jwt_secret: str = "change-me-in-production"
    jwt_ttl_minutes: int = 480
    s3_endpoint: str = ""  # empty -> local filesystem document store
    s3_access_key: str = ""
    s3_secret_key: str = ""
    s3_bucket: str = "thq-documents"
    local_storage_dir: str = "/tmp/thq-documents"
    currency: str = "GBP"
    cors_origins: str = "*"
    insights_provider: str = "rules"  # 'rules' (deterministic) – an LLM adapter can be plugged in


settings = Settings()
