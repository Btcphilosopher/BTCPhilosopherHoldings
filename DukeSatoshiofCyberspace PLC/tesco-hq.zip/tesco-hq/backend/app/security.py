import hashlib
import hmac
import os
from dataclasses import dataclass, field
from datetime import timedelta

import jwt
from fastapi import Depends, Header
from sqlalchemy import select

from .common import DomainError, audit, now
from .config import settings
from .db import get_db
from .domains.org.models import Region, Site
from .domains.platform.models import User, UserRole
from .permissions import ROLES


def hash_password(pw: str) -> str:
    salt = os.urandom(16)
    return "pbkdf2$" + salt.hex() + "$" + hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, 120_000).hex()


def verify_password(pw: str, stored: str) -> bool:
    try:
        _, salt, digest = stored.split("$")
        calc = hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 120_000).hex()
        return hmac.compare_digest(calc, digest)
    except Exception:  # noqa: BLE001
        return False


def issue_token(user: User) -> str:
    return jwt.encode({"sub": str(user.id), "exp": now() + timedelta(minutes=settings.jwt_ttl_minutes)},
                      settings.jwt_secret, algorithm="HS256")


@dataclass
class Principal:
    user: User
    grants: dict = field(default_factory=dict)  # permission -> None (all sites) | set(site ids)
    roles: list = field(default_factory=list)

    def has(self, perm):
        return perm in self.grants

    def sites(self, perm):
        """None = unrestricted; otherwise the set of site ids this permission covers."""
        return self.grants.get(perm, set())

    def can(self, perm, site_id=None, need_global=False):
        if perm not in self.grants:
            return False
        scope = self.grants[perm]
        if scope is None:
            return True
        if need_global or site_id is None:
            return False
        return site_id in scope

    def check(self, perm, site_id=None, need_global=False):
        """Authorise a write. Records with no site (national prices, suppliers) need a global grant."""
        if not self.can(perm, site_id, need_global or site_id is None):
            raise DomainError(403, "forbidden", f"Permission '{perm}' is not granted for this scope")

    def check_read(self, perm, site_id):
        scope = self.grants.get(perm, set())
        if scope is not None and site_id not in scope:
            raise DomainError(403, "forbidden", f"Permission '{perm}' is not granted for this site")

    def scope(self, query, column, perm):
        """Restrict a query to the sites covered by the permission."""
        s = self.grants.get(perm, set())
        return query if s is None else query.where(column.in_(s or {-1}))

    def sql_sites(self, perm):
        """For raw SQL: (clause_enabled, list) -> use `(:all_sites OR site_id = ANY(:sites))`."""
        s = self.grants.get(perm, set())
        return {"all_sites": s is None, "sites": list(s or [])}


def load_principal(db, user: User) -> Principal:
    p = Principal(user=user)
    for ur in db.execute(select(UserRole).where(UserRole.user_id == user.id)).scalars():
        role = ROLES.get(ur.role)
        if not role:
            continue
        p.roles.append({"role": ur.role, "name": role["name"], "scope_type": ur.scope_type, "scope_id": ur.scope_id})
        if ur.scope_type == "global":
            sites = None
        elif ur.scope_type == "site":
            sites = {ur.scope_id}
        elif ur.scope_type == "region":
            sites = set(db.execute(select(Site.id).where(Site.region_id == ur.scope_id)).scalars())
        else:  # business_unit
            sites = set(db.execute(select(Site.id).join(Region, Site.region_id == Region.id)
                                   .where(Region.business_unit_id == ur.scope_id)).scalars())
        for perm in role["perms"]:
            if perm in p.grants and p.grants[perm] is None:
                continue
            p.grants[perm] = None if sites is None else (p.grants.get(perm) or set()) | sites
    return p


def current_principal(authorization: str = Header(default=""), db=Depends(get_db)) -> Principal:
    token = authorization.removeprefix("Bearer ").strip()
    if not token:
        raise DomainError(401, "unauthenticated", "Sign in required")
    try:
        uid = int(jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])["sub"])
    except Exception as e:  # noqa: BLE001
        raise DomainError(401, "unauthenticated", "Session expired or invalid") from e
    user = db.get(User, uid)
    if not user or not user.active:
        raise DomainError(401, "unauthenticated", "Account disabled")
    return load_principal(db, user)


def require(*perms):
    """Dependency: the caller must hold at least one of the permissions (in any scope).
    Scope is then enforced per record by Principal.check / Principal.scope."""
    def dep(p: Principal = Depends(current_principal)) -> Principal:
        if not any(p.has(x) for x in perms):
            raise DomainError(403, "forbidden", f"Requires permission: {' or '.join(perms)}")
        return p
    return dep


def audited_sensitive(db, p, action, entity_type, entity_id=None, detail=None):
    audit(db, p, action, entity_type, entity_id, detail, sensitive=True)
