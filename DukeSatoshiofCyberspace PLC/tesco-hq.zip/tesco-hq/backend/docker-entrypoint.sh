#!/bin/sh
set -e
case "$1" in
  api)
    alembic upgrade head                 # schema + database-level guarantees
    python -m app.seed                   # loads fictional demo data on first start only
    exec uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 2
    ;;
  worker)
    exec python -m app.worker
    ;;
  *)
    exec "$@"
    ;;
esac
