from datetime import datetime, timedelta, timezone


def test_authentication_required(client, world):
    assert client.get("/api/v1/sales").status_code == 401
    assert client.get("/api/v1/sales", headers={"Authorization": "Bearer nonsense"}).status_code == 401
    assert client.post("/api/v1/auth/login", json={"email": "admin@t.example", "password": "wrong"}).status_code == 401


def test_store_manager_sees_and_changes_only_their_own_store(world, client, auth):
    w = world
    assert {s["id"] for s in client.get("/api/v1/org/sites", headers=auth("mgr1")).json()} == {w.s1.id}
    assert {x["site_id"] for x in client.get("/api/v1/inventory/stock", headers=auth("mgr1")).json()} == {w.s1.id}
    assert client.get(f"/api/v1/org/sites/{w.s2.id}", headers=auth("mgr1")).status_code == 403
    sale = {"site_id": w.s2.id, "lines": [{"sku": "BREAD", "qty": 1}]}
    assert client.post("/api/v1/pos/sales", headers=auth("mgr1"), json=sale).status_code == 403
    assert client.post("/api/v1/pos/sales", headers=auth("mgr2"), json=sale).status_code == 200
    adj = {"site_id": w.s2.id, "product_id": w.bread.id, "lot_id": w.lots[("S2", "BREAD")], "qty_delta": -1, "kind": "waste", "reason": "x"}
    assert client.post("/api/v1/inventory/adjustments", headers=auth("mgr1"), json=adj).status_code == 403
    assert client.post("/api/v1/inventory/adjustments", headers=auth("mgr2"), json=adj).status_code == 200


def test_regional_scope_expands_to_its_stores_only(world, client, auth):
    w = world
    ids = {s["id"] for s in client.get("/api/v1/org/sites", headers=auth("regional")).json()}
    assert ids == {w.dc.id, w.s1.id, w.s2.id} and w.s3.id not in ids
    assert {e["site_id"] for e in client.get("/api/v1/workforce/employees", headers=auth("regional")).json()} == {w.s1.id}


def test_function_boundaries(world, client, auth):
    w = world
    assert client.get("/api/v1/finance/journal", headers=auth("mgr1")).status_code == 403            # no finance access
    assert client.get("/api/v1/workforce/employees", headers=auth("buyer")).status_code == 403
    assert client.get("/api/v1/admin/audit", headers=auth("exec")).status_code == 403
    assert client.get("/api/v1/admin/audit", headers=auth("auditor")).status_code == 200
    # a site-scoped permission cannot change a national record
    assert client.post("/api/v1/suppliers/1/status", headers=auth("mgr1"), json={"status": "suspended", "reason": "x"}).status_code == 403
    # auditor is read-only everywhere
    for path, body in (("/pos/sales", {"site_id": w.s1.id, "lines": [{"sku": "BREAD", "qty": 1}]}), ("/procurement/forecasts/run", {}),
                       ("/pricing/prices", {"price_book_id": w.nat.id, "product_id": w.bread.id, "price": "1.10", "reason": "x"})):
        assert client.post("/api/v1" + path, headers=auth("auditor"), json=body).status_code == 403


def test_sensitive_personal_data_is_restricted_and_access_is_audited(world, client, auth, db):
    from sqlalchemy import text
    w = world
    r = client.get(f"/api/v1/workforce/employees/{w.emp.id}", headers=auth("mgr1")).json()
    assert "home_address" not in r["private"] and "restricted" in r["private"]
    r = client.get(f"/api/v1/workforce/employees/{w.emp.id}", headers=auth("hr")).json()
    assert r["private"]["home_address"] == "1 Secret Street"
    assert db.execute(text("SELECT count(*) FROM audit_log WHERE action='workforce.private_viewed' AND sensitive")).scalar() == 1
    members = client.get("/api/v1/loyalty/members", headers=auth("mgr1")).json()
    assert all(m["email"] is None and "•" in m["display_name"] for m in members)
    assert client.get("/api/v1/loyalty/members", headers=auth("service")).json()[0]["display_name"] == "Member One"
    from app.domains.workforce.models import Employee, EmployeePrivate, LeaveRequest
    cols = set(Employee.__table__.c.keys()) | set(EmployeePrivate.__table__.c.keys()) | set(LeaveRequest.__table__.c.keys())
    assert not any(k in c for c in cols for k in ("medical", "health", "diagnos", "sick"))
    assert client.post("/api/v1/workforce/leave", headers=auth("hr"), json={"employee_id": w.emp.id, "from_date": "2027-01-01", "to_date": "2027-01-02", "category": "sickness"}).status_code == 422


def test_maker_checker_on_price_change_and_permission_change(world, client, auth):
    w = world
    e = client.post("/api/v1/pricing/prices", headers=auth("pricer"), json={"price_book_id": w.nat.id, "product_id": w.bread.id, "price": "1.30", "reason": "cost"}).json()
    assert e["status"] == "pending_approval"                                                       # 30% change is material
    assert client.post(f"/api/v1/pricing/prices/{e['id']}/publish", headers=auth("pricer")).status_code == 409   # cannot publish unapproved
    ap = [a for a in client.get("/api/v1/approvals", headers=auth("pricer")).json() if a["kind"] == "price_change"][0]
    r = client.post(f"/api/v1/approvals/{ap['id']}/decision", headers=auth("pricer"), json={"approve": True})
    assert r.status_code == 403 and r.json()["error"]["code"] == "maker_checker"                   # even though they hold pricing.approve
    assert client.post(f"/api/v1/approvals/{ap['id']}/decision", headers=auth("analyst"), json={"approve": True}).status_code == 403   # analyst has no approve right
    assert client.post(f"/api/v1/approvals/{ap['id']}/decision", headers=auth("admin"), json={"approve": True}).status_code == 200
    assert client.post(f"/api/v1/pricing/prices/{e['id']}/publish", headers=auth("pricer")).status_code == 200
    # the till still charges 1.00 until it is live AND acknowledged by the endpoint
    sim = client.post("/api/v1/pricing/simulate", headers=auth("pricer"), json={"site_id": w.s1.id, "terminal_id": w.till1.id, "lines": [{"sku": "BREAD", "qty": 1}]}).json()
    assert sim["totals"]["gross"] == "1.00" and any("not yet acknowledged" in r for r in sim["rules"])
    client.post("/api/v1/pricing/publications/retry", headers=auth("pricer"))
    gross = lambda t: client.post("/api/v1/pricing/simulate", headers=auth("pricer"), json={"site_id": w.s1.id, "terminal_id": t, "lines": [{"sku": "BREAD", "qty": 1}]}).json()["totals"]["gross"]
    assert gross(w.till1.id) == "1.30" and gross(w.till_off.id) == "1.00"                          # the offline terminal has not confirmed
    assert client.post("/api/v1/pricing/prices", headers=auth("pricer"), json={"price_book_id": w.nat.id, "product_id": w.wine.id, "price": "4.00", "reason": "x"}).status_code == 422  # floor

    uid = w.users["mgr2"].id
    g = client.post("/api/v1/admin/role-grants", headers=auth("admin"), json={"user_id": uid, "role": "finance_controller", "scope_type": "global", "justification": "cover"})
    assert g.status_code == 200
    assert client.get("/api/v1/finance/journal", headers=auth("mgr2")).status_code == 403          # nothing granted yet
    assert client.post(f"/api/v1/approvals/{g.json()['id']}/decision", headers=auth("admin"), json={"approve": True}).status_code == 403
    assert client.post(f"/api/v1/approvals/{g.json()['id']}/decision", headers=auth("admin2"), json={"approve": True}).status_code == 200
    assert client.get("/api/v1/finance/journal", headers=auth("mgr2")).status_code == 200


def test_material_stock_adjustment_needs_second_approver(world, client, auth, db):
    from sqlalchemy import text
    w, lot = world, world.lots[("S1", "WINE")]
    q = lambda: db.execute(text("SELECT qty FROM stock_balances WHERE lot_id=:l AND site_id=:s AND bucket='available'"), {"l": lot, "s": w.s1.id}).scalar()
    q0 = q()
    r = client.post("/api/v1/inventory/adjustments", headers=auth("mgr1"), json={"site_id": w.s1.id, "product_id": w.wine.id, "lot_id": lot, "qty_delta": -10, "reason": "breakage"}).json()
    assert r["status"] == "pending_approval"            # 10 x 4.50 = 45.00 > 25.00
    db.expire_all()
    assert q() == q0
    assert client.post(f"/api/v1/approvals/{r['approval_id']}/decision", headers=auth("regional2"), json={"approve": True}).status_code == 403   # holds inventory.approve, but for another region
    assert client.post(f"/api/v1/approvals/{r['approval_id']}/decision", headers=auth("regional"), json={"approve": True}).status_code == 200
    db.expire_all()
    assert q() == q0 - 10
    small = client.post("/api/v1/inventory/adjustments", headers=auth("mgr1"), json={"site_id": w.s1.id, "product_id": w.wine.id, "lot_id": lot, "qty_delta": -1, "reason": "breakage"}).json()
    assert small["status"] == "posted"


def test_exports_are_audited_and_scheduling_constraints_enforced(world, client, auth, db):
    from sqlalchemy import text
    w = world
    assert client.get("/api/v1/admin/export/sales", headers=auth("mgr1")).status_code == 403
    assert client.get("/api/v1/admin/export/sales", headers=auth("exec")).status_code == 200
    assert db.execute(text("SELECT count(*) FROM audit_log WHERE action='export' AND sensitive")).scalar() == 1
    t = datetime.now(timezone.utc).replace(hour=8, minute=0, second=0, microsecond=0) + timedelta(days=3)
    mk = lambda s, e: client.post("/api/v1/workforce/shifts", headers=auth("mgr1"), json={"employee_id": w.emp.id, "starts_at": s.isoformat(), "ends_at": e.isoformat(), "duty": "Shop floor"})
    assert mk(t, t + timedelta(hours=8)).status_code == 200
    assert "rest" in mk(t + timedelta(hours=12), t + timedelta(hours=18)).json()["error"]["message"]
    assert mk(t + timedelta(days=1), t + timedelta(days=1, hours=11)).status_code == 409           # longer than max shift
    r = client.post("/api/v1/workforce/shifts", headers=auth("mgr1"), json={"employee_id": w.emp.id, "starts_at": (t + timedelta(days=2)).isoformat(),
                    "ends_at": (t + timedelta(days=2, hours=6)).isoformat(), "duty": "Forklift operator"})
    assert r.status_code == 409 and "Forklift licence" in r.json()["error"]["message"]
    assert client.post("/api/v1/workforce/shifts", headers=auth("mgr1"), json={"employee_id": w.emp2.id, "starts_at": t.isoformat(), "ends_at": (t + timedelta(hours=4)).isoformat(), "duty": "x"}).status_code == 403
