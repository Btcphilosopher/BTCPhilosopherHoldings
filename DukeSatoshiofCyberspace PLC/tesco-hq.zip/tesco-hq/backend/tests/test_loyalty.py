import threading

import pytest
from sqlalchemy import text

from app.common import DomainError
from app.db import SessionLocal
from app.domains.loyalty import service as loyalty


def balance(db, m):
    return db.execute(text("SELECT points_balance FROM loyalty_members WHERE id=:m"), {"m": m}).scalar()


def test_award_is_exactly_once_per_event(world, db):
    m = world.m1.id
    assert loyalty.award(db, m, 500, "sale", 9001) == 500
    assert loyalty.award(db, m, 500, "sale", 9001) == 0      # duplicate message
    assert loyalty.award(db, m, 100, "sale", 9002) == 100
    db.commit()
    assert balance(db, m) == 600


def test_redeem_rules_and_no_double_spend_under_concurrency(world, db):
    m = world.m1.id
    with pytest.raises(DomainError):
        loyalty.redeem(db, m, 150, "sale", 1)                # not a multiple of 100
    db.rollback()
    ok, barrier = [], threading.Barrier(6)

    def worker(i):
        with SessionLocal() as s:
            barrier.wait()
            try:
                loyalty.redeem(s, m, 400, "sale", 7000 + i)
                s.commit()
                ok.append(1)
            except DomainError:
                s.rollback()

    ts = [threading.Thread(target=worker, args=(i,)) for i in range(6)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    assert len(ok) == 1 and balance(db, m) == 200           # 600 points can fund only one 400 redemption
    assert loyalty.redeem(db, m, 100, "sale", 8000) == 100
    assert loyalty.redeem(db, m, 100, "sale", 8000) == 0     # same reference replayed: no second deduction
    db.commit()
    assert balance(db, m) == 100


def test_reversal_never_goes_negative_and_ledger_equals_balance(world, db):
    m = world.m1.id
    assert loyalty.reverse(db, m, 250, "sale_return", 1, "return") == 100   # only 100 left: shortfall noted, not hidden
    assert loyalty.reverse(db, m, 250, "sale_return", 1) == 0
    db.commit()
    assert balance(db, m) == 0
    note = db.execute(text("SELECT note FROM loyalty_ledger WHERE kind='reversal' AND member_id=:m"), {"m": m}).scalar()
    assert "shortfall 150" in note
    assert db.execute(text("""SELECT count(*) FROM loyalty_members m LEFT JOIN (SELECT member_id, SUM(points) s FROM loyalty_ledger GROUP BY 1) l
        ON l.member_id=m.id WHERE m.points_balance <> COALESCE(l.s,0)""")).scalar() == 0


def test_coupon_cannot_be_replayed(world, db):
    loyalty.redeem_coupon(db, "TWO", 1)
    db.commit()
    with pytest.raises(DomainError) as e:
        loyalty.redeem_coupon(db, "TWO", 2)
    assert e.value.code == "coupon_replay"
    db.rollback()


def test_member_identity_is_separate_from_authentication(world, client):
    """A member number is not a credential: it cannot be used to sign in."""
    assert client.post("/api/v1/auth/login", json={"email": "M1", "password": "M1"}).status_code == 401
    from app.domains.loyalty.models import LoyaltyMember
    assert "password_hash" not in LoyaltyMember.__table__.c
