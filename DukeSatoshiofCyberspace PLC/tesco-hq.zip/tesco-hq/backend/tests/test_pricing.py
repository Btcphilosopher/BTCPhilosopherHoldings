from datetime import timedelta
from decimal import Decimal as D

import pytest

from app.common import DomainError
from app.domains.pricing.engine import find_conflicts, price_basket
from app.domains.pricing.models import PriceEntry, PricePublication, Promotion, PromotionProduct
from tests.fixtures import NOW, PAST


def promo(db, code, kind, params, products, priority=10, **kw):
    p = Promotion(code=code, name=code, kind=kind, params=params, starts_at=PAST, ends_at=NOW + timedelta(days=5), priority=priority, status="published", **kw)
    db.add(p)
    db.flush()
    for pr in products:
        db.add(PromotionProduct(promotion_id=p.id, product_id=pr.id))
    db.flush()
    return p


def price(db, w, site, lines, **kw):
    return price_basket(db, site_id=site.id, lines=[{"product_id": p.id, "qty": D(str(q)), **({"lot_id": l} if l else {})} for p, q, *rest in lines for l in [rest[0] if rest else None]], **kw)


def test_base_price_specificity_site_then_format_then_national_and_channel(world, db):
    w = world
    unit = lambda site, **kw: price(db, w, site, [(w.milk, 1)], **kw)["lines"][0]["base_unit_price"]
    assert unit(w.s1) == D("1.50")                      # national
    assert unit(w.s2) == D("1.65")                      # Express format book beats national
    assert unit(w.s3) == D("1.40")                      # site book beats everything
    assert unit(w.s1, channel="online") == D("1.45")    # channel-specific beats 'all' at the same scope


def test_unpublished_and_future_prices_are_ignored(world, db):
    w = world
    db.add(PriceEntry(price_book_id=w.nat.id, product_id=w.bread.id, price=D("9.99"), effective_from=PAST, status="approved"))
    db.add(PriceEntry(price_book_id=w.nat.id, product_id=w.bread.id, price=D("7.77"), effective_from=NOW + timedelta(days=1), status="published"))
    db.flush()
    assert price(db, w, w.s1, [(w.bread, 1)])["lines"][0]["base_unit_price"] == D("1.00")
    assert price(db, w, w.s1, [(w.bread, 1)], at=NOW + timedelta(days=2))["lines"][0]["base_unit_price"] == D("7.77")


def test_terminal_without_acknowledgement_keeps_last_confirmed_price(world, db):
    w = world
    e = PriceEntry(price_book_id=w.nat.id, product_id=w.cola.id, price=D("2.50"), effective_from=NOW - timedelta(hours=1), status="published")
    db.add(e)
    db.flush()
    db.add(PricePublication(item_type="price", item_id=e.id, terminal_id=w.till1.id, status="acknowledged"))
    db.add(PricePublication(item_type="price", item_id=e.id, terminal_id=w.till_off.id, status="failed"))
    db.flush()
    assert price(db, w, w.s1, [(w.cola, 1)], terminal_id=w.till1.id)["lines"][0]["base_unit_price"] == D("2.50")
    assert price(db, w, w.s1, [(w.cola, 1)], terminal_id=w.till_off.id)["lines"][0]["base_unit_price"] == D("2.00")


def test_higher_priority_exclusive_promotion_wins_and_loser_is_explained(world, db):
    w = world
    promo(db, "LOW-50", "percent_off", {"pct": 50}, [w.bread], priority=5)
    hi = promo(db, "HIGH-10", "percent_off", {"pct": 10}, [w.bread], priority=50)
    ln = price(db, w, w.s1, [(w.bread, 2)])["lines"][0]
    assert [a["code"] for a in ln["applied"]] == ["HIGH-10"] and ln["discount"] == D("0.20")
    assert ln["rejected"][0]["code"] == "LOW-50" and "higher-priority" in ln["rejected"][0]["reason"]
    assert any(c["code"] == "LOW-50" for c in find_conflicts(db, hi))


def test_same_priority_best_customer_saving_wins(world, db):
    w = world
    promo(db, "A-10", "percent_off", {"pct": 10}, [w.milk])
    promo(db, "B-FIXED", "fixed_price", {"price": "1.00"}, [w.milk])
    ln = price(db, w, w.s1, [(w.milk, 1)])["lines"][0]
    assert [a["code"] for a in ln["applied"]] == ["B-FIXED"] and ln["gross"] == D("1.00")
    assert "conflicts with B-FIXED" in ln["rejected"][0]["reason"]


def test_multibuy_groups_quantity_limit_loyalty_and_stackable(world, db):
    w = world
    promo(db, "3FOR5", "multibuy", {"buy_qty": 3, "for_price": "5.00"}, [w.cola], priority=20)
    r = price(db, w, w.s3, [(w.cola, 7)])
    assert r["totals"]["gross"] == D("12.00")                 # two groups at 5.00 + one unit at 2.00
    assert price(db, w, w.s3, [(w.cola, 2)])["totals"]["discount"] == D("0")
    promo(db, "CLUB", "loyalty_price", {"price": "6.00"}, [w.wine], max_qty_per_basket=2)
    assert price(db, w, w.s1, [(w.wine, 3)])["totals"]["gross"] == D("24.00")                       # no card, no member price
    with_card = price(db, w, w.s1, [(w.wine, 3)], member_id=w.m1.id)
    assert with_card["totals"]["gross"] == D("20.00")                                               # limit 2 per basket
    promo(db, "EXTRA5", "percent_off", {"pct": 5}, [w.wine], stackable=True)
    assert price(db, w, w.s1, [(w.wine, 1)], member_id=w.m1.id)["totals"]["gross"] == D("5.70")     # 6.00 then 5% off


def test_price_floor_caps_discount(world, db):
    w = world
    promo(db, "DEEP", "percent_off", {"pct": 60}, [w.wine], priority=99)
    ln = price(db, w, w.s3, [(w.wine, 1)])["lines"][0]
    assert ln["gross"] == D("5.00") and ln["floor_applied"] is True


def test_markdown_only_on_scanned_lot_and_beats_other_promotions(world, db):
    w, lot = world, world.lots[("S1", "BAN")]
    promo(db, "MD", "markdown", {"pct": 50}, [w.bananas], lot_id=lot, priority=1)
    promo(db, "BAN-10", "percent_off", {"pct": 10}, [w.bananas], priority=90)
    assert [a["code"] for a in price(db, w, w.s1, [(w.bananas, "1.000")])["lines"][0]["applied"]] == ["BAN-10"]
    ln = price(db, w, w.s1, [(w.bananas, "1.000", lot)])["lines"][0]
    assert [a["code"] for a in ln["applied"]] == ["MD"] and ln["gross"] == D("0.55")


def test_coupons_min_spend_member_binding_limit_and_vat_split(world, db):
    w = world
    r = price(db, w, w.s3, [(w.cola, 6), (w.bread, 4)], coupon_codes=["FIVE", "TWO"])
    assert [c["status"] for c in r["coupons"]] == ["applied", "rejected"]          # one coupon per basket
    t = r["totals"]
    assert t["gross"] == t["gross_before_discount"] - t["discount"] and t["net"] + t["tax"] == t["gross"]
    assert sum(l["gross"] for l in r["lines"]) == t["gross"]
    assert price(db, w, w.s1, [(w.bread, 1)], coupon_codes=["FIVE"])["coupons"][0]["reason"].startswith("minimum spend")
    assert "different member" in price(db, w, w.s1, [(w.bread, 3)], coupon_codes=["M1ONLY"], member_id=w.m2.id)["coupons"][0]["reason"]
    # VAT: 20% inclusive on a 2.00 item -> net 1.67, tax 0.33 (half-up)
    ln = price(db, w, w.s2, [(w.cola, 1)])["lines"][0]
    assert (ln["net"], ln["tax"]) == (D("1.67"), D("0.33"))


def test_no_price_and_invalid_quantity_are_errors(world, db):
    w = world
    with pytest.raises(DomainError):
        price(db, w, w.s1, [(w.milk, "0.5")])   # not a weighted product
    assert price(db, w, w.s1, [(w.bananas, "0.455")])["lines"][0]["gross"] == D("0.50")
