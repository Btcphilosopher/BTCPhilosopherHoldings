import threading
from decimal import Decimal as D

from sqlalchemy import text

from app.domains.online.service import MACHINES


def order_body(w, **kw):
    return {"customer_id": w.cust.id, "slot_id": w.slot.id, "payment_token": "tok_ok",
            "lines": [{"sku": "MILK", "qty": 2}, {"sku": "BREAD", "qty": 1}, {"sku": "COLA", "qty": 1}], **kw}


def avail(db, w, p):
    db.expire_all()
    return db.execute(text("SELECT SUM(qty) FROM stock_balances WHERE site_id=:s AND product_id=:p AND bucket='available'"), {"s": w.s1.id, "p": p.id}).scalar()


def test_retried_order_creates_one_order_one_reservation_one_authorisation(world, client, auth, db):
    w = world
    a0 = avail(db, w, w.milk)
    results = []

    def send():
        results.append(client.post("/api/v1/online/orders", headers=auth("service", "ord-1"), json=order_body(w)))
    threads = [threading.Thread(target=send) for _ in range(5)]     # the client retries, in parallel
    auth("service")
    [t.start() for t in threads]
    [t.join() for t in threads]
    assert all(r.status_code == 200 for r in results), [r.text for r in results]
    assert len({r.json()["number"] for r in results}) == 1
    assert db.execute(text("SELECT count(*) FROM online_orders")).scalar() == 1
    assert db.execute(text("SELECT count(*) FROM mock_psp_transactions WHERE kind='authorise'")).scalar() == 1
    assert avail(db, w, w.milk) == a0 - 2
    assert client.post("/api/v1/online/orders", headers=auth("service"), json=order_body(w)).status_code == 422    # key is mandatory
    assert client.post("/api/v1/online/orders", headers=auth("service", "ord-1"), json=order_body(w, slot_id=w.slot_small.id)).status_code == 422
    world.order = results[0].json()


def test_substitution_consent_price_rule_capture_and_state_machines(world, client, auth, db):
    w, o = world, world.order
    assert (o["order_status"], o["payment_status"], o["fulfilment_status"]) == ("confirmed", "authorised", "reserved")
    assert D(o["gross_estimated"]) == D("5.90")                 # milk at the online price 2 x 1.45, bread 1.00, cola 2.00
    assert client.post(f"/api/v1/online/orders/{o['id']}/handover", headers=auth("mgr1"), json={}).status_code == 409   # not dispatched: illegal transition
    bread = next(l for l in o["lines"] if l["sku"] == "BREAD")
    cola = next(l for l in o["lines"] if l["sku"] == "COLA")
    picked = client.post(f"/api/v1/online/orders/{o['id']}/pick", headers=auth("mgr1"), json={"lines": [
        {"line_id": bread["id"], "picked_qty": 0, "substitute_sku": "WINE"}, {"line_id": cola["id"], "picked_qty": 0, "substitute_sku": "MILK"}]}).json()
    sub = {l["sku"]: l for l in picked["lines"]}
    assert D(sub["BREAD"]["sub_shelf_price"]) == D("8.00") and D(sub["BREAD"]["sub_charged_price"]) == D("1.00")   # never pays more than agreed
    assert D(sub["COLA"]["sub_charged_price"]) == D("1.45") and sub["COLA"]["sub_consent"] == "pending"             # cheaper substitute: pays the lower price
    client.post(f"/api/v1/online/orders/{o['id']}/dispatch", headers=auth("mgr1"))
    wine0 = avail(db, w, w.wine)
    done = client.post(f"/api/v1/online/orders/{o['id']}/handover", headers=auth("mgr1", "ho-1"),
                       json={"substitution_decisions": {str(bread["id"]): "rejected", str(cola["id"]): "accepted"}}).json()
    assert (done["order_status"], done["payment_status"], done["fulfilment_status"]) == ("completed", "captured", "delivered")
    assert D(done["gross_final"]) == D("4.35")                      # milk 2 x 1.45 online price + substitute 1.45; rejected wine not charged
    assert avail(db, w, w.wine) == wine0 + 1                         # rejected substitute back on the shelf
    again = client.post(f"/api/v1/online/orders/{o['id']}/handover", headers=auth("mgr1", "ho-1"), json={"substitution_decisions": {str(bread["id"]): "rejected", str(cola["id"]): "accepted"}})
    assert again.json()["idempotent_replay"] is True
    assert db.execute(text("SELECT count(*), SUM(amount) FROM mock_psp_transactions WHERE kind='capture'")).one() == (1, D("4.35"))
    assert db.execute(text("SELECT count(*) FROM sales WHERE order_id=:o"), {"o": o["id"]}).scalar() == 1
    assert db.execute(text("SELECT count(*) FROM reservations WHERE ref_type='online_order' AND ref_id=:o AND status='active'"), {"o": o["id"]}).scalar() == 0
    for machine, table in MACHINES.items():                          # every recorded transition was a legal one
        for h in done["history"]:
            if h["machine"] == machine:
                assert h["to"] in table[h["from"]]
    world.done = done


def test_refund_is_idempotent(world, client, auth, db):
    o = world.done
    line = o["sale_lines"][0]
    body = {"lines": [{"sale_line_id": line["id"], "qty": 1, "disposition": "none"}], "reason": "missing"}
    assert client.post(f"/api/v1/online/orders/{o['id']}/refunds", headers=auth("service"), json=body).status_code == 422   # key required
    rs = [client.post(f"/api/v1/online/orders/{o['id']}/refunds", headers=auth("service", "rf-1"), json=body) for _ in range(3)]
    assert all(r.status_code == 200 for r in rs)
    assert db.execute(text("SELECT count(*), SUM(amount) FROM mock_psp_transactions WHERE kind='refund'")).one() == (1, D("1.45"))
    assert rs[0].json()["order"]["payment_status"] == "part_refunded"


def test_uncertain_payment_is_resolved_by_lookup_not_by_charging_again(world, client, auth, db):
    w = world
    n0 = db.execute(text("SELECT count(*) FROM mock_psp_transactions WHERE kind='authorise'")).scalar()
    o = client.post("/api/v1/online/orders", headers=auth("service", "ord-timeout"), json=order_body(w, payment_token="tok_timeout")).json()
    assert (o["order_status"], o["payment_status"]) == ("placed", "uncertain")
    retry = client.post("/api/v1/online/orders", headers=auth("service", "ord-timeout"), json=order_body(w, payment_token="tok_timeout")).json()
    assert retry["number"] == o["number"]
    assert client.post(f"/api/v1/online/orders/{o['id']}/pick", headers=auth("mgr1"), json={"lines": []}).status_code == 409      # cannot fulfil until payment is known
    assert client.post(f"/api/v1/online/orders/{o['id']}/cancel", headers=auth("service"), json={"reason": "x"}).status_code == 409
    r = client.post(f"/api/v1/online/orders/{o['id']}/resolve-payment", headers=auth("service")).json()
    assert (r["order_status"], r["payment_status"]) == ("confirmed", "authorised")
    assert db.execute(text("SELECT count(*) FROM mock_psp_transactions WHERE kind='authorise'")).scalar() == n0 + 1
    assert db.execute(text("SELECT status FROM exceptions WHERE kind='payment_uncertain'")).scalar() == "resolved"
    c = client.post(f"/api/v1/online/orders/{o['id']}/cancel", headers=auth("service"), json={"reason": "customer request"}).json()
    assert (c["order_status"], c["payment_status"], c["fulfilment_status"]) == ("cancelled", "voided", "released")


def test_declined_payment_releases_stock_and_slot__slot_capacity__no_sub_preference(world, client, auth, db):
    w = world
    a0, booked0 = avail(db, w, w.bread), db.execute(text("SELECT booked FROM delivery_slots WHERE id=:i"), {"i": w.slot.id}).scalar()
    o = client.post("/api/v1/online/orders", headers=auth("service", "ord-decl"), json=order_body(w, payment_token="tok_declined")).json()
    assert (o["order_status"], o["payment_status"], o["fulfilment_status"]) == ("cancelled", "failed", "released")
    assert avail(db, w, w.bread) == a0
    assert db.execute(text("SELECT booked FROM delivery_slots WHERE id=:i"), {"i": w.slot.id}).scalar() == booked0
    first = client.post("/api/v1/online/orders", headers=auth("service", "small-1"), json=order_body(w, slot_id=w.slot_small.id, customer_id=w.cust_nosub.id))
    assert first.status_code == 200
    full = client.post("/api/v1/online/orders", headers=auth("service", "small-2"), json=order_body(w, slot_id=w.slot_small.id))
    assert full.status_code == 409 and full.json()["error"]["code"] == "slot_full"
    o = first.json()
    r = client.post(f"/api/v1/online/orders/{o['id']}/pick", headers=auth("mgr1"), json={"lines": [{"line_id": o["lines"][0]["id"], "picked_qty": 1, "substitute_sku": "COLA"}]})
    assert r.status_code == 409 and r.json()["error"]["code"] == "substitution_not_allowed"
    assert client.get("/api/v1/inventory/integrity", headers=auth("admin")).json()["balanced"] is True
