"""Tests run against a real PostgreSQL database (locking, constraints and triggers are what is under test).

Set TEST_DATABASE_URL, e.g. postgresql+psycopg://thq:thq@localhost:5432/thq_test . The schema is built by
running the Alembic migration, so the migration itself is exercised on every run."""
import os
import sys

os.environ["DATABASE_URL"] = os.environ.get("TEST_DATABASE_URL", "postgresql+psycopg://thq:thq@localhost:5432/thq_test")
os.environ.setdefault("REDIS_URL", "redis://localhost:6399/15")  # cache is optional; tests do not need it
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import pytest  # noqa: E402
from alembic import command  # noqa: E402
from alembic.config import Config  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402
from sqlalchemy import text  # noqa: E402

from app.db import Base, SessionLocal, engine  # noqa: E402
from app.main import app  # noqa: E402
from tests import fixtures  # noqa: E402


@pytest.fixture(scope="session", autouse=True)
def schema():
    with engine.begin() as c:
        c.execute(text("DROP SCHEMA public CASCADE; CREATE SCHEMA public"))
    cfg = Config(os.path.join(os.path.dirname(os.path.dirname(__file__)), "alembic.ini"))
    cfg.set_main_option("script_location", os.path.join(os.path.dirname(os.path.dirname(__file__)), "alembic"))
    command.upgrade(cfg, "head")
    yield


@pytest.fixture(scope="module")
def world(schema):
    """Fresh, small fictional world per test module."""
    with engine.begin() as c:
        names = ", ".join(f'"{t.name}"' for t in Base.metadata.sorted_tables)
        c.execute(text(f"TRUNCATE {names} RESTART IDENTITY CASCADE"))
    from app.domains.finance import service as fin
    fin._acct_cache.clear()
    with SessionLocal() as db:
        w = fixtures.build(db)
        db.commit()
    return w


@pytest.fixture()
def db():
    with SessionLocal() as s:
        yield s
        s.rollback()


@pytest.fixture(scope="module")
def client():
    return TestClient(app)


@pytest.fixture(scope="module")
def auth(client, world):
    cache = {}

    def _h(user, key=None):
        if user not in cache:
            r = client.post("/api/v1/auth/login", json={"email": f"{user}@t.example", "password": "pw"})
            assert r.status_code == 200, r.text
            cache[user] = r.json()["token"]
        h = {"Authorization": "Bearer " + cache[user]}
        if key:
            h["Idempotency-Key"] = key
        return h
    return _h
