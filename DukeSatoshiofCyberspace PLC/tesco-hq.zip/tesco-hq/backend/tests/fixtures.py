from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal as D
from types import SimpleNamespace

from app.domains.catalog.models import Category, Product, TaxCategory
from app.domains.distribution.models import Vehicle
from app.domains.finance.models import Account
from app.domains.finance.service import CHART, post_journal
from app.domains.inventory import service as inv
from app.domains.inventory.models import Lot
from app.domains.loyalty.models import LoyaltyMember
from app.domains.online.models import Customer, DeliverySlot
from app.domains.org.models import BusinessUnit, Region, Site, StoreFormat
from app.domains.platform.models import User, UserRole
from app.domains.pricing.models import Coupon, PosTerminal, PriceBook, PriceEntry
from app.domains.procurement.models import ReplenishmentPolicy
from app.domains.suppliers.models import Supplier, SupplierCategory, SupplierProduct
from app.domains.workforce.models import Employee, EmployeePrivate
from app.security import hash_password, load_principal

NOW = datetime.now(timezone.utc)
PAST = NOW - timedelta(days=30)


def build(db):
    w = SimpleNamespace()
    for code, name, kind in CHART:
        db.add(Account(code=code, name=name, kind=kind))
    bu = BusinessUnit(code="BU", name="BU")
    db.add(bu)
    db.flush()
    r1, r2 = Region(business_unit_id=bu.id, code="R1", name="North"), Region(business_unit_id=bu.id, code="R2", name="South")
    fmt, expr = StoreFormat(code="SUP", name="Super", replenishment_policy={"cover_days": 3}), StoreFormat(code="EXP", name="Express", replenishment_policy={"cover_days": 2})
    db.add_all([r1, r2, fmt, expr])
    db.flush()
    mk = lambda code, kind, reg, f, x: Site(code=code, name=code, kind=kind, region_id=reg.id, format_id=f.id if f else None, grid_x=x, grid_y=0,
                                           opened_on=date(2015, 1, 1), delivery_window_start=time(6), delivery_window_end=time(12))
    w.dc, w.s1, w.s2, w.s3 = mk("DC", "dc", r1, None, 0), mk("S1", "store", r1, fmt, 10), mk("S2", "store", r1, expr, 20), mk("S3", "store", r2, fmt, -10)
    db.add_all([w.dc, w.s1, w.s2, w.s3])
    zero, std = TaxCategory(code="ZERO", name="Zero", rate=D("0")), TaxCategory(code="STD", name="Std", rate=D("0.20"))
    cat = Category(code="C", name="Cat")
    db.add_all([zero, std, cat])
    db.flush()
    P = lambda sku, tax, price_floor=None, weighted=False, case=6: Product(sku=sku, name=sku + " name", category_id=cat.id, tax_category_id=tax.id, case_size=case,
                                                                          price_floor=price_floor, is_weighted=weighted, base_uom="kg" if weighted else "each", shelf_life_days=30)
    w.milk, w.cola, w.wine, w.bananas, w.bread = P("MILK", zero), P("COLA", std), P("WINE", std, D("5.00")), P("BAN", zero, weighted=True, case=18), P("BREAD", zero, case=8)
    db.add_all([w.milk, w.cola, w.wine, w.bananas, w.bread])
    w.sup = Supplier(code="SUP1", name="Supplier One", lead_time_days=1, delivery_weekdays="0,1,2,3,4,5,6")
    db.add(w.sup)
    db.flush()
    db.add(SupplierCategory(supplier_id=w.sup.id, category_id=cat.id))
    for p, c in ((w.milk, "6.00"), (w.cola, "6.00"), (w.wine, "27.00"), (w.bananas, "12.60"), (w.bread, "5.20")):
        db.add(SupplierProduct(supplier_id=w.sup.id, product_id=p.id, case_cost=D(c), moq_cases=1))
    w.nat = PriceBook(code="NAT", name="National", scope_type="national", channel="all")
    w.fmt_book = PriceBook(code="EXP", name="Express", scope_type="format", scope_id=expr.id, channel="all")
    w.online_book = PriceBook(code="ONL", name="Online", scope_type="national", channel="online")
    db.add_all([w.nat, w.fmt_book, w.online_book])
    db.flush()
    w.site_book = PriceBook(code="S3", name="S3 local", scope_type="site", scope_id=w.s3.id, channel="all")
    db.add(w.site_book)
    db.flush()
    pe = lambda book, p, price: db.add(PriceEntry(price_book_id=book.id, product_id=p.id, price=D(price), effective_from=PAST, status="published"))
    for p, price in ((w.milk, "1.50"), (w.cola, "2.00"), (w.wine, "8.00"), (w.bananas, "1.10"), (w.bread, "1.00")):
        pe(w.nat, p, price)
    pe(w.fmt_book, w.milk, "1.65"); pe(w.online_book, w.milk, "1.45"); pe(w.site_book, w.milk, "1.40")
    w.till1 = PosTerminal(site_id=w.s1.id, code="S1-T1")
    w.till_off = PosTerminal(site_id=w.s1.id, code="S1-T2", online=False)
    db.add_all([w.till1, w.till_off, PosTerminal(site_id=w.s1.id, code="S1-ECOM", kind="ecommerce")])
    users = [("admin", "administrator", "global", None), ("admin2", "administrator", "global", None), ("buyer", "buyer", "global", None),
             ("pm", "procurement_manager", "global", None), ("analyst", "pricing_analyst", "global", None), ("pricer", "pricing_manager", "global", None),
             ("clerk", "finance_clerk", "global", None), ("controller", "finance_controller", "global", None), ("hr", "hr_partner", "global", None),
             ("mgr1", "store_manager", "site", w.s1.id), ("mgr2", "store_manager", "site", w.s2.id), ("regional", "regional_manager", "region", r1.id), ("regional2", "regional_manager", "region", r2.id),
             ("wh", "warehouse_operative", "site", w.dc.id), ("service", "customer_service", "global", None), ("auditor", "auditor", "global", None),
             ("exec", "executive", "global", None)]
    w.users = {}
    pw = hash_password("pw")
    for name, role, st, sid in users:
        u = User(email=f"{name}@t.example", name=name, password_hash=pw)
        db.add(u)
        db.flush()
        db.add(UserRole(user_id=u.id, role=role, scope_type=st, scope_id=sid))
        w.users[name] = u
    db.flush()
    w.p = {k: load_principal(db, u) for k, u in w.users.items()}
    w.m1, w.m2 = LoyaltyMember(member_no="M1", display_name="Member One"), LoyaltyMember(member_no="M2", display_name="Member Two")
    db.add_all([w.m1, w.m2])
    db.flush()
    w.cust = Customer(ref="C1", name="Cust One", email="c1@example.test", member_id=w.m1.id, substitution_pref="allow")
    w.cust_nosub = Customer(ref="C2", name="Cust Two", email="c2@example.test", substitution_pref="none")
    w.slot = DeliverySlot(site_id=w.s1.id, method="delivery", starts_at=NOW + timedelta(days=1), ends_at=NOW + timedelta(days=1, hours=2), capacity=50)
    w.slot_small = DeliverySlot(site_id=w.s1.id, method="delivery", starts_at=NOW + timedelta(days=2), ends_at=NOW + timedelta(days=2, hours=2), capacity=1)
    db.add_all([w.cust, w.cust_nosub, w.slot, w.slot_small,
                Coupon(code="FIVE", amount_off=D("5"), min_spend=D("10")), Coupon(code="M1ONLY", amount_off=D("1"), member_id=w.m1.id),
                Coupon(code="TWO", amount_off=D("2")), Vehicle(site_id=w.dc.id, fleet_no="V1", capacity_cages=20, chilled=True, frozen=True)])
    w.emp = Employee(employee_no="E1", name="Emp One", site_id=w.s1.id, job_role="Assistant")
    w.emp2 = Employee(employee_no="E2", name="Emp Two", site_id=w.s3.id, job_role="Assistant")
    db.add_all([w.emp, w.emp2])
    db.flush()
    db.add(EmployeePrivate(employee_id=w.emp.id, home_address="1 Secret Street"))
    w.lots, total = {}, D(0)
    for site, qty in ((w.dc, 600), (w.s1, 200), (w.s2, 100), (w.s3, 100)):
        for p, cost in ((w.milk, "1.00"), (w.cola, "1.00"), (w.wine, "4.50"), (w.bananas, "0.70"), (w.bread, "0.65")):
            lot = Lot(product_id=p.id, lot_code=f"L-{site.code}-{p.sku}", expiry_date=date.today() + timedelta(days=20), supplier_id=w.sup.id, unit_cost=D(cost))
            db.add(lot)
            db.flush()
            w.lots[(site.code, p.sku)] = lot.id
            inv.post(db, site_id=site.id, product_id=p.id, lot_id=lot.id, bucket="available", qty=qty, mtype="opening_balance")
            total += qty * D(cost)
            db.add(ReplenishmentPolicy(site_id=site.id, product_id=p.id, safety_stock=5, max_capacity=5000))
    post_journal(db, entry_date=date.today(), source_type="opening_balance", source_id=None, description="opening", lines=[("1200", total, 0, None), ("3000", 0, total, None)])
    db.flush()
    for o in (w.dc, w.s1, w.s2, w.s3, w.milk, w.cola, w.wine, w.bananas, w.bread, w.sup, w.nat, w.fmt_book, w.online_book, w.site_book, w.till1, w.till_off,
              w.m1, w.m2, w.cust, w.cust_nosub, w.slot, w.slot_small, w.emp, w.emp2, *w.users.values()):
        db.refresh(o)
        db.expunge(o)
    return w
