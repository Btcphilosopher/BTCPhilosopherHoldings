from decimal import Decimal as D

import pytest
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError


def all_entries_balance(db):
    return db.execute(text("SELECT count(*) FROM (SELECT entry_id FROM journal_lines GROUP BY 1 HAVING SUM(debit) <> SUM(credit)) x")).scalar() == 0


def acct(db, code):
    return db.execute(text("SELECT COALESCE(SUM(l.debit - l.credit),0) FROM journal_lines l JOIN accounts a ON a.id=l.account_id WHERE a.code=:c"), {"c": code}).scalar()


def stock(db, site, product):
    return db.execute(text("SELECT COALESCE(SUM(qty),0) FROM stock_balances WHERE site_id=:s AND product_id=:p AND bucket='available'"), {"s": site, "p": product}).scalar()


def test_sale_posts_stock_loyalty_and_balanced_ledger_and_replay_is_harmless(world, client, auth, db):
    w = world
    s0, inv0, rev0, card0 = stock(db, w.s1.id, w.cola.id), acct(db, "1200"), acct(db, "4000"), acct(db, "1020")
    body = {"site_id": w.s1.id, "terminal_id": w.till1.id, "member": "M2", "tender": "card", "lines": [{"sku": "COLA", "qty": 3}, {"sku": "MILK", "qty": 2}]}
    r = client.post("/api/v1/pos/sales", headers=auth("mgr1", "sale-A"), json=body)
    assert r.status_code == 200, r.text
    sale = r.json()
    assert D(sale["gross"]) == D("9.00") and D(sale["net"]) == D("8.00") and D(sale["tax"]) == D("1.00")   # cola 6.00 @20% incl., milk 3.00 zero-rated
    assert sale["points_earned"] == 9
    for _ in range(3):
        again = client.post("/api/v1/pos/sales", headers=auth("mgr1", "sale-A"), json=body).json()
        assert again["number"] == sale["number"] and again["idempotent_replay"] is True
    db.expire_all()
    assert stock(db, w.s1.id, w.cola.id) == s0 - 3
    assert acct(db, "1200") == inv0 - D("5.00")              # 3 x 1.00 + 2 x 1.00 at lot cost
    assert acct(db, "4000") == rev0 - D("8.00")              # credit balance grows by net revenue
    assert acct(db, "1020") == card0 + D("9.00")
    assert db.execute(text("SELECT count(*) FROM sales WHERE number=:n"), {"n": sale["number"]}).scalar() == 1
    assert db.execute(text("SELECT count(*), SUM(points) FROM loyalty_ledger WHERE ref_type='sale' AND ref_id=:i"), {"i": sale["id"]}).one() == (1, 9)
    assert db.execute(text("SELECT count(*) FROM mock_psp_transactions WHERE kind='charge'")).scalar() == 1   # one charge only
    assert all_entries_balance(db)
    world.sale = sale


def test_refund_reverses_revenue_tax_stock_and_points_proportionally(world, client, auth, db):
    w, sale = world, world.sale
    cola = next(l for l in sale["lines"] if l["sku"] == "COLA")
    s0, rev = stock(db, w.s1.id, w.cola.id), acct(db, "4010")
    body = {"lines": [{"sale_line_id": cola["id"], "qty": 1, "disposition": "restock"}], "reason": "changed mind"}
    r = client.post(f"/api/v1/sales/{sale['id']}/returns", headers=auth("mgr1", "ret-A"), json=body)
    assert r.status_code == 200, r.text
    ret = r.json()["return"]
    assert (D(ret["gross"]), D(ret["net"]), D(ret["tax"])) == (D("2.00"), D("1.67"), D("0.33"))
    assert ret["points_reversed"] == 2                        # 9 points x 2.00 / 9.00
    assert client.post(f"/api/v1/sales/{sale['id']}/returns", headers=auth("mgr1", "ret-A"), json=body).json()["idempotent_replay"] is True
    db.expire_all()
    assert stock(db, w.s1.id, w.cola.id) == s0 + 1
    assert acct(db, "4010") == rev + D("1.67")
    assert db.execute(text("SELECT COALESCE(SUM(amount),0) FROM payments WHERE sale_id=:s AND kind='refund'"), {"s": sale["id"]}).scalar() == D("2.00")
    # damaged return: refunded but written off, not restocked
    r2 = client.post(f"/api/v1/sales/{sale['id']}/returns", headers=auth("mgr1"), json={"lines": [{"sale_line_id": cola["id"], "qty": 1, "disposition": "damaged"}], "reason": "leaking"})
    assert r2.status_code == 200
    db.expire_all()
    assert stock(db, w.s1.id, w.cola.id) == s0 + 1
    # cannot refund more than was sold, in quantity or in money
    r3 = client.post(f"/api/v1/sales/{sale['id']}/returns", headers=auth("mgr1"), json={"lines": [{"sale_line_id": cola["id"], "qty": 2, "disposition": "restock"}], "reason": "x"})
    assert r3.status_code == 409 and r3.json()["error"]["code"] == "over_return"
    final = client.post(f"/api/v1/sales/{sale['id']}/returns", headers=auth("mgr1"), json={"lines": [{"sale_line_id": cola["id"], "qty": 1, "disposition": "restock"},
                        {"sale_line_id": next(l for l in sale["lines"] if l["sku"] == "MILK")["id"], "qty": 2, "disposition": "restock"}], "reason": "all back"}).json()
    assert final["sale"]["status"] == "refunded" and D(final["sale"]["refunded_gross"]) == D(sale["gross"])
    db.expire_all()
    assert db.execute(text("SELECT SUM(CASE WHEN kind='refund' THEN -amount ELSE amount END) FROM payments WHERE sale_id=:s"), {"s": sale["id"]}).scalar() == 0
    assert db.execute(text("SELECT SUM(points) FROM loyalty_ledger WHERE member_id=:m"), {"m": w.m2.id}).scalar() == 0
    assert all_entries_balance(db)


def test_database_rejects_an_unbalanced_journal_entry(world, db):
    db.execute(text("INSERT INTO journal_entries (number, entry_date, source_type, description) VALUES ('BAD-1', current_date, 'test', 'bad')"))
    eid = db.execute(text("SELECT id FROM journal_entries WHERE number='BAD-1'")).scalar()
    aid = db.execute(text("SELECT id FROM accounts WHERE code='1000'")).scalar()
    db.execute(text("INSERT INTO journal_lines (entry_id, account_id, debit, credit) VALUES (:e, :a, 10, 0)"), {"e": eid, "a": aid})
    with pytest.raises(DBAPIError):
        db.commit()            # deferred constraint trigger fires at commit
    db.rollback()
    with pytest.raises(DBAPIError):
        db.execute(text("UPDATE journal_lines SET debit = debit + 1"))
    db.rollback()


def test_three_way_match_payment_maker_checker_and_trial_balance(world, client, auth, db):
    w = world
    po = client.post("/api/v1/procurement/purchase-orders", headers=auth("buyer"), json={"supplier_id": w.sup.id, "site_id": w.dc.id, "lines": [{"product_id": w.cola.id, "cases": 10}]}).json()
    assert client.post(f"/api/v1/procurement/purchase-orders/{po['id']}/receipts", headers=auth("wh"), json={"delivery_note_ref": "X", "lines": []}).status_code == 409  # not approved yet
    ap = [a for a in client.get("/api/v1/approvals", headers=auth("pm")).json() if a["entity_id"] == po["id"] and a["kind"] == "purchase_order"][0]
    client.post(f"/api/v1/approvals/{ap['id']}/decision", headers=auth("pm"), json={"approve": True})
    line = client.get(f"/api/v1/procurement/purchase-orders/{po['id']}", headers=auth("wh")).json()["lines"][0]
    grni0 = acct(db, "2010")
    client.post(f"/api/v1/procurement/purchase-orders/{po['id']}/receipts", headers=auth("wh"), json={"delivery_note_ref": "DN-9", "lines": [{"po_line_id": line["id"], "cases_received": 7}]})
    db.expire_all()
    assert acct(db, "2010") == grni0 - D("42.00")            # accrual for 7 cases x 6.00

    def invoice(no, cases, cost):
        net = D(cases) * D(cost)
        i = client.post("/api/v1/finance/invoices", headers=auth("clerk"), json={"supplier_id": w.sup.id, "po_id": po["id"], "invoice_no": no, "invoice_date": "2026-01-10",
                        "net": str(net), "tax": str((net * D("0.2")).quantize(D("0.01"))), "lines": [{"po_line_id": line["id"], "cases": cases, "case_cost": cost}]}).json()
        return client.post(f"/api/v1/finance/invoices/{i['id']}/match", headers=auth("clerk")).json()

    assert invoice("QTY", 10, "6.00")["status"] == "exception"      # billed for 10, received 7
    assert invoice("PRICE", 7, "6.50")["status"] == "exception"     # 8.3% over PO price, tolerance 1%
    db.expire_all()
    assert acct(db, "2000") == 0                                     # nothing posted for failed matches
    ok = invoice("GOOD", 7, "6.03")                                  # 0.5% variance is within tolerance
    assert ok["status"] == "matched"
    db.expire_all()
    assert acct(db, "2000") == D("-50.65") and acct(db, "5200") == D("0.21") and acct(db, "2010") == grni0
    assert invoice("AGAIN", 1, "6.00")["status"] == "exception"      # those cases are already invoiced
    assert client.post("/api/v1/finance/invoices", headers=auth("clerk"), json={"supplier_id": w.sup.id, "po_id": po["id"], "invoice_no": "GOOD", "invoice_date": "2026-01-10",
                       "net": "1", "tax": "0", "lines": []}).status_code == 409

    assert client.post(f"/api/v1/finance/invoices/{ok['id']}/request-payment", headers=auth("clerk")).status_code == 200
    ap = [a for a in client.get("/api/v1/approvals", headers=auth("clerk")).json() if a["kind"] == "supplier_payment"][0]
    assert ap["can_decide"] is False
    r = client.post(f"/api/v1/approvals/{ap['id']}/decision", headers=auth("clerk"), json={"approve": True})
    assert r.status_code == 403                                       # clerk lacks approve; and is the maker
    bank0 = acct(db, "1000")
    assert client.post(f"/api/v1/approvals/{ap['id']}/decision", headers=auth("controller"), json={"approve": True}).status_code == 200
    assert client.post(f"/api/v1/approvals/{ap['id']}/decision", headers=auth("controller"), json={"approve": True}).status_code == 409  # cannot be decided twice
    db.expire_all()
    assert acct(db, "1000") == bank0 - D("50.65") and acct(db, "2000") == 0
    tb = client.get("/api/v1/finance/trial-balance", headers=auth("controller")).json()
    assert tb["balanced"] is True and tb["total_debit"] == tb["total_credit"]
    assert all_entries_balance(db)


def test_card_settlement_reconciles_to_payments_and_recognises_fees(world, client, auth, db):
    from datetime import date
    bank0, clearing0 = acct(db, "1000"), acct(db, "1020")
    s = client.post("/api/v1/finance/settlements/import", headers=auth("clerk"), json={"business_date": date.today().isoformat()}).json()
    assert s["status"] == "reconciled" and s["unmatched"] == []
    db.expire_all()
    net_cleared = clearing0 - acct(db, "1020")
    assert net_cleared == D(s["gross"]) - D(s["refunds"])
    assert acct(db, "1000") - bank0 == net_cleared - acct(db, "6000")
    assert client.post("/api/v1/finance/settlements/import", headers=auth("clerk"), json={"business_date": date.today().isoformat()}).status_code == 409
    assert all_entries_balance(db)
