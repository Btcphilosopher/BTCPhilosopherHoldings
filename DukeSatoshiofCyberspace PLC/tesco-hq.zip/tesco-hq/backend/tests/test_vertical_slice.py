"""Purchase order -> receipt -> inventory -> approved price -> sale -> loyalty -> refund -> reconciliation -> executive report.
Each figure on the executive overview is recomputed here from the underlying rows."""
from datetime import date
from decimal import Decimal as D

from sqlalchemy import text


def test_vertical_slice(world, client, auth, db):
    w = world
    api = lambda user, method, path, body=None, key=None: client.request(method, "/api/v1" + path, headers=auth(user, key), json=body)
    stock = lambda site: D(next(x for x in api("admin", "GET", f"/inventory/stock?site_id={site}").json() if x["sku"] == "BREAD")["available"])

    # 1. purchase order, approved by someone else
    po = api("buyer", "POST", "/procurement/purchase-orders", {"supplier_id": w.sup.id, "site_id": w.dc.id, "lines": [{"product_id": w.bread.id, "cases": 20}]}).json()
    assert po["status"] == "pending_approval" and D(po["net_total"]) == D("104.00")
    ap = [a for a in api("pm", "GET", "/approvals").json() if a["entity_id"] == po["id"] and a["kind"] == "purchase_order"][0]
    assert api("buyer", "POST", f"/approvals/{ap['id']}/decision", {"approve": True}).status_code == 403
    assert api("pm", "POST", f"/approvals/{ap['id']}/decision", {"approve": True}).status_code == 200

    # 2. partial receipt into inventory at the DC, with a traceable lot
    line = api("wh", "GET", f"/procurement/purchase-orders/{po['id']}").json()["lines"][0]
    dc0 = stock(w.dc.id)
    rc = api("wh", "POST", f"/procurement/purchase-orders/{po['id']}/receipts", {"delivery_note_ref": "DN-VS", "lines": [{"po_line_id": line["id"], "cases_received": 15, "lot_code": "LOT-VS"}]}, "vs-rc").json()
    assert rc["po_status"] == "part_received" and stock(w.dc.id) == dc0 + 120
    lot = next(l for l in api("wh", "GET", f"/inventory/lots?site_id={w.dc.id}&product_id={w.bread.id}").json() if l["lot_code"] == "LOT-VS")
    assert D(lot["unit_cost"]) == D("0.65") and lot["supplier"] == "Supplier One"

    # 3. price change: proposed, approved by a second person, published, acknowledged by the till
    e = api("analyst", "POST", "/pricing/prices", {"price_book_id": w.nat.id, "product_id": w.bread.id, "price": "1.20", "reason": "cost"}).json()
    ap = [a for a in api("pricer", "GET", "/approvals").json() if a["kind"] == "price_change" and a["entity_id"] == e["id"]][0]
    assert api("pricer", "POST", f"/approvals/{ap['id']}/decision", {"approve": True}).status_code == 200
    assert api("pricer", "POST", f"/pricing/prices/{e['id']}/publish").status_code == 200
    api("pricer", "POST", "/pricing/publications/retry")

    # 4. sale at the new price, with loyalty
    s1_0 = stock(w.s1.id)
    sale = api("mgr1", "POST", "/pos/sales", {"site_id": w.s1.id, "terminal_id": w.till1.id, "member": "M1", "tender": "card", "lines": [{"sku": "BREAD", "qty": 5}]}, "vs-sale").json()
    assert D(sale["gross"]) == D("6.00") and sale["points_earned"] == 6 and stock(w.s1.id) == s1_0 - 5
    assert D(sale["cost"]) == D("3.25")
    m = api("service", "GET", f"/loyalty/members/{w.m1.id}").json()
    assert m["points_balance"] == 6 == m["ledger_sum"]

    # 5. refund of two loaves
    ret = api("mgr1", "POST", f"/sales/{sale['id']}/returns", {"lines": [{"sale_line_id": sale["lines"][0]["id"], "qty": 2, "disposition": "restock"}], "reason": "stale"}, "vs-ret").json()["return"]
    assert D(ret["gross"]) == D("2.40") and ret["points_reversed"] == 2 and stock(w.s1.id) == s1_0 - 3
    assert api("service", "GET", f"/loyalty/members/{w.m1.id}").json()["points_balance"] == 4

    # 6. reconciliation: provider settlement agrees with our payments; ledger balances
    st = api("clerk", "POST", "/finance/settlements/import", {"business_date": date.today().isoformat()}).json()
    assert st["status"] == "reconciled" and D(st["gross"]) == D("6.00") and D(st["refunds"]) == D("2.40") and D(st["difference"]) == 0
    tb = api("controller", "GET", "/finance/trial-balance").json()
    assert tb["balanced"] is True
    assert api("admin", "GET", "/inventory/integrity").json()["balanced"] is True

    # 7. executive report: every figure equals what the rows say
    ov = api("exec", "GET", "/executive/overview?days=1").json()
    f = {m["key"]: m for m in ov["flow"]}
    k = {m["key"]: m for m in ov["kpis"]}
    assert f["completed_sales"]["value"] == {"count": 1, "value": "6.00"}
    assert f["refunds"]["value"] == {"count": 1, "value": "2.40"}
    assert f["revenue"]["value"] == "3.56"                 # 6.00 - 2.40 returns - 0.04 net loyalty points issued (zero-rated, so net = gross)
    assert f["gross_profit"]["value"] == "1.61"            # 3.56 - (3.25 - 1.30 restocked)
    assert f["cash_receipts"]["value"] == "0.00"           # settlement posts on the settlement date (T+2): sold is not banked
    assert f["orders"]["value"]["count"] == 0
    inv_sql = db.execute(text("SELECT SUM(b.qty*l.unit_cost) FROM stock_balances b JOIN lots l ON l.id=b.lot_id WHERE b.bucket IN ('available','reserved','in_transit','quarantined')")).scalar()
    assert D(f["inventory_value"]["value"]) == inv_sql.quantize(D("0.01"))
    assert k["gross_margin_pct"]["value"] == "45.2"
    assert k["supplier_in_full"]["value"] == "75.0" and "15 cases accepted" in k["supplier_in_full"]["numerator"]
    for m in ov["flow"] + ov["kpis"]:                      # nothing is shown without its definition and source
        assert m["definition"] and m["source"] and m["period"] and m["unit"]
    # drill-down returns the transaction behind the number
    drill = api("exec", "GET", f["completed_sales"]["drill"]).json()
    assert [d["number"] for d in drill] == [sale["number"]]
    # scoped view: another store's manager sees none of it
    assert {m["key"]: m for m in api("mgr2", "GET", "/executive/overview?days=1").json()["flow"]}["completed_sales"]["value"]["count"] == 0
