import threading
from decimal import Decimal as D

import pytest
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError

from app.db import SessionLocal
from app.domains.inventory import service as inv
from app.domains.inventory.service import InsufficientStock


def conserved(db):
    return db.execute(text("""
        SELECT count(*) FROM stock_balances b FULL JOIN (SELECT site_id, product_id, lot_id, bucket, SUM(qty) q FROM stock_movements GROUP BY 1,2,3,4) m
          ON m.site_id=b.site_id AND m.product_id=b.product_id AND m.lot_id=b.lot_id AND m.bucket=b.bucket
        WHERE COALESCE(b.qty,0) <> COALESCE(m.q,0)""")).scalar() == 0


def test_balances_always_equal_ledger_after_mixed_operations(world, db):
    w, lot = world, world.lots[("S1", "MILK")]
    before = inv.available(db, w.s1.id, w.milk.id)
    inv.reserve(db, site_id=w.s1.id, product_id=w.milk.id, qty=10, ref_type="t", ref_id=1)
    inv.consume_reserved(db, ref_type="t", ref_id=1, product_id=w.milk.id, qty=4, mtype="sale")
    inv.release(db, ref_type="t", ref_id=1)
    inv.deplete(db, site_id=w.s1.id, product_id=w.milk.id, qty=3, mtype="waste", ref_type="x", ref_id=1)
    inv.move(db, site_id=w.s1.id, product_id=w.milk.id, lot_id=lot, src="available", dst="damaged", qty=2, mtype="damage")
    db.commit()
    assert inv.available(db, w.s1.id, w.milk.id) == before - 4 - 3 - 2
    assert conserved(db)
    # every bucket-to-bucket move nets to zero
    assert db.execute(text("SELECT count(*) FROM (SELECT group_id FROM stock_movements WHERE group_id IS NOT NULL GROUP BY 1 HAVING SUM(qty) <> 0) x")).scalar() == 0


def test_stock_cannot_go_negative(world, db):
    w = world
    with pytest.raises(InsufficientStock):
        inv.post(db, site_id=w.s2.id, product_id=w.wine.id, lot_id=w.lots[("S2", "WINE")], bucket="available", qty=-101, mtype="adjustment")
    with pytest.raises(InsufficientStock):
        inv.reserve(db, site_id=w.s2.id, product_id=w.wine.id, qty=101, ref_type="t", ref_id=2)
    with pytest.raises(InsufficientStock):  # a bucket with no row at all
        inv.post(db, site_id=w.s2.id, product_id=w.wine.id, lot_id=w.lots[("S2", "WINE")], bucket="quarantined", qty=-1, mtype="adjustment")
    db.rollback()
    assert db.execute(text("SELECT count(*) FROM stock_balances WHERE qty < 0")).scalar() == 0
    # depletion beyond stock removes what exists and reports the rest - never silently negative
    done, _, _ = inv.deplete(db, site_id=w.s2.id, product_id=w.wine.id, qty=150, mtype="sale", ref_type="x", ref_id=9)
    assert done == 100
    db.rollback()


def test_movement_ledger_is_immutable(world, db):
    for stmt in ("UPDATE stock_movements SET qty = qty + 1", "DELETE FROM stock_movements"):
        with pytest.raises(DBAPIError):
            db.execute(text(stmt))
        db.rollback()


def test_concurrent_reservations_never_double_allocate(world):
    """12 workers each try to reserve 30 of the 100 units. Exactly 3 can succeed."""
    w = world
    results, barrier = [], threading.Barrier(12)

    def worker(i):
        with SessionLocal() as s:
            barrier.wait()
            try:
                inv.reserve(s, site_id=w.s3.id, product_id=w.cola.id, qty=30, ref_type="race", ref_id=i)
                s.commit()
                results.append(True)
            except InsufficientStock:
                s.rollback()
                results.append(False)

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(12)]
    [t.start() for t in threads]
    [t.join() for t in threads]
    with SessionLocal() as s:
        assert sum(results) == 3
        assert inv.available(s, w.s3.id, w.cola.id) == D(10)
        reserved = s.execute(text("SELECT SUM(qty) FROM stock_balances WHERE site_id=:s AND product_id=:p AND bucket='reserved'"), {"s": w.s3.id, "p": w.cola.id}).scalar()
        assert reserved == D(90)
        assert conserved(s)


def test_duplicate_receipt_is_rejected_and_idempotent_replay_is_safe(world, client, auth):
    w = world
    po = client.post("/api/v1/procurement/purchase-orders", headers=auth("buyer"), json={"supplier_id": w.sup.id, "site_id": w.dc.id, "lines": [{"product_id": w.bread.id, "cases": 10}]}).json()
    ap = [a for a in client.get("/api/v1/approvals", headers=auth("pm")).json() if a["entity_id"] == po["id"] and a["kind"] == "purchase_order"][0]
    assert client.post(f"/api/v1/approvals/{ap['id']}/decision", headers=auth("pm"), json={"approve": True}).status_code == 200
    line = client.get(f"/api/v1/procurement/purchase-orders/{po['id']}", headers=auth("wh")).json()["lines"][0]
    body = {"delivery_note_ref": "DN-1", "lines": [{"po_line_id": line["id"], "cases_received": 6, "cases_damaged": 1}]}
    stock = lambda: D(next(x for x in client.get(f"/api/v1/inventory/stock?site_id={w.dc.id}", headers=auth("wh")).json() if x["sku"] == "BREAD")["available"])
    before = stock()
    r1 = client.post(f"/api/v1/procurement/purchase-orders/{po['id']}/receipts", headers=auth("wh", "k1"), json=body)
    assert r1.status_code == 200 and r1.json()["po_status"] == "part_received"
    assert stock() == before + 48  # 6 good cases x 8; the damaged case is not saleable stock
    r2 = client.post(f"/api/v1/procurement/purchase-orders/{po['id']}/receipts", headers=auth("wh", "k1"), json=body)
    assert r2.status_code == 200 and r2.json()["idempotent_replay"] is True
    r3 = client.post(f"/api/v1/procurement/purchase-orders/{po['id']}/receipts", headers=auth("wh", "k2"), json=body)
    assert r3.status_code == 409 and r3.json()["error"]["code"] == "duplicate_receipt"
    r4 = client.post(f"/api/v1/procurement/purchase-orders/{po['id']}/receipts", headers=auth("wh", "k1"), json={**body, "delivery_note_ref": "DN-OTHER"})
    assert r4.status_code == 422 and r4.json()["error"]["code"] == "idempotency_mismatch"
    assert stock() == before + 48
    over = client.post(f"/api/v1/procurement/purchase-orders/{po['id']}/receipts", headers=auth("wh"), json={"delivery_note_ref": "DN-2", "lines": [{"po_line_id": line["id"], "cases_received": 9}]})
    assert over.status_code == 422 and over.json()["error"]["code"] == "over_delivery"
    assert client.get("/api/v1/inventory/integrity", headers=auth("wh")).json()["balanced"] is True
