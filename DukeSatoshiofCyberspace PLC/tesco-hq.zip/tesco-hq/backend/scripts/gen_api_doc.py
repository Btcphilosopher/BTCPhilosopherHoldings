"""Regenerate docs/API.md from the live OpenAPI schema:  python scripts/gen_api_doc.py > ../docs/API.md"""
from collections import OrderedDict

from app.main import app

spec = app.openapi()
groups = OrderedDict()
for path, ops in spec["paths"].items():
    for method, op in ops.items():
        groups.setdefault((op.get("tags") or ["Other"])[0], []).append((method.upper(), path, op))
print("# API reference (v1)\n")
print("Interactive documentation with request/response schemas is served by the API itself: **`/docs`** (Swagger UI) and **`/openapi.json`**.")
print("This file is generated from that schema. All routes are under `/api/v1`; a future breaking revision would be published as `/api/v2` alongside it.\n")
print("""## Conventions

| Topic | Rule |
|---|---|
| Authentication | `POST /api/v1/auth/login` returns a bearer token; send `Authorization: Bearer <token>`. |
| Authorisation | Enforced on the server for every route: by function (permission), by scope (business unit / region / site) and by data sensitivity. The console only hides what the API would refuse. |
| Money | GBP. Decimal strings (`"12.34"`), never floats. Shelf prices include VAT; `net` and `tax` are always returned separately. |
| Idempotency | Marked **⟳** below. Send an `Idempotency-Key` header; a retry returns the original result with `"idempotent_replay": true`. Reusing a key with a different body is `422 idempotency_mismatch`. |
| Concurrency | Records with a `version` (products, purchase orders, online orders) use optimistic concurrency; a stale write is `409 stale_version`. |
| Errors | `{"error": {"code", "message", "detail"}}` with 401 unauthenticated, 403 forbidden / maker_checker, 404, 409 conflict, 422 invalid. |
| Optional filters | An empty query value (`?status=`) means "no filter". |

## Integration entry points

| External system | How it connects | Notes |
|---|---|---|
| POS (tills) | `POST /pos/sales`, `POST /sales/{id}/returns` ⟳ | Completed baskets and returns. Prices reach tills via the `price.published` outbox topic; acknowledgements update `price_publications`. |
| E-commerce | `POST /online/orders` ⟳ (key mandatory), `GET /online/slots`, `POST /pricing/simulate` | Order ingestion, slot availability, basket pricing. |
| Warehouse (WMS / scanners) | `POST /procurement/purchase-orders/{id}/receipts` ⟳, `POST /distribution/tasks/{id}/complete` | Receipts and task confirmations. `adapters.base.WarehouseScanner`. |
| Transport (TMS / telematics) | `POST /distribution/stops/{id}/confirm|fail`, `adapters.base.VehicleTracking`, `ProofOfDelivery` | Live ETA is stored separately from planned arrival. |
| Payment provider | `adapters.base.PaymentProvider` (server side only) | Card data never enters this platform or the browser; only opaque references are stored. |
| HR / payroll | `POST /workforce/timesheets/import`, `POST /workforce/timesheets/export-to-hr`, `adapters.base.HrPayrollGateway` | This platform plans rotas; it does not calculate pay. |
| Supplier EDI | outbox topic `purchase_order.approved` → `adapters.base.SupplierGateway` | |
| Loyalty platform | `adapters.base.LoyaltyProgrammeGateway` | Future integration point; demo policies only. |

Outbox topics: `purchase_order.approved`, `goods_receipt.posted`, `price.published`, `sale.completed`, `sale.refunded`, `online_order.placed`, `route.dispatched`.
No endpoint, payload or credential of any real retailer is assumed anywhere.
""")
IDEM = {"/api/v1/pos/sales", "/api/v1/sales/{sale_id}/returns", "/api/v1/online/orders", "/api/v1/online/orders/{oid}/handover", "/api/v1/online/orders/{oid}/refunds", "/api/v1/procurement/purchase-orders/{po_id}/receipts"}
for tag, ops in groups.items():
    print(f"## {tag}\n\n| Method | Path | Purpose |\n|---|---|---|")
    for method, path, op in ops:
        desc = (op.get("description") or op.get("summary") or "").strip().split("\n")[0]
        mark = " ⟳" if method == "POST" and path in IDEM else ""
        print(f"| {method} | `{path.replace('/api/v1', '')}`{mark} | {desc} |")
    print()
