import collections
from app import models_registry
from app.db import Base
groups = collections.OrderedDict()
MOD = {"platform": "Platform (users, approvals, audit, outbox, jobs)", "org": "Organisation", "catalog": "Product master", "suppliers": "Suppliers", "procurement": "Procurement & replenishment",
       "inventory": "Inventory", "distribution": "Distribution & transport", "pricing": "Pricing & promotions", "sales": "Sales & payments", "online": "Online & customer service",
       "loyalty": "Loyalty", "workforce": "Workforce", "finance": "Finance", "adapters": "Simulated external systems"}
for m in Base.registry.mappers:
    mod = m.class_.__module__.split(".")[-2]
    groups.setdefault(mod, []).append(m.local_table)
out = ["# Entity-relationship diagram", "", f"Generated from the SQLAlchemy models ({len(Base.metadata.tables)} tables). Regenerate with `python scripts/gen_erd.py > ../docs/ERD.md` from `backend/`.",
       "Diagrams are Mermaid `erDiagram` blocks, one per domain; they render on GitHub, GitLab and in most Markdown viewers. Only key columns are shown;",
       "`alembic/versions/0001_initial_schema.py` is the authoritative schema.", "",
       "Cross-domain references are by id (e.g. `site_id`, `product_id`); each diagram shows the foreign keys its tables declare, including those that point into another domain.", ""]
for mod in MOD:
    tabs = sorted(groups.get(mod, []), key=lambda t: t.name)
    if not tabs: continue
    out += [f"## {MOD[mod]}", "", "```mermaid", "erDiagram"]
    names = {t.name for t in tabs}
    for t in tabs:
        out.append(f"  {t.name} {{")
        for c in list(t.columns)[:9]:
            typ = str(c.type).split("(")[0].lower().replace(" ", "_")
            key = "PK" if c.primary_key else ("FK" if c.foreign_keys else "")
            out.append(f"    {typ} {c.name} {key}".rstrip())
        out.append("  }")
    seen = set()
    for t in tabs:
        for fk in t.foreign_keys:
            ref = fk.column.table.name
            k = (ref, t.name, fk.parent.name)
            if k in seen: continue
            seen.add(k)
            out.append(f'  {ref} ||--o{{ {t.name} : "{fk.parent.name}"')
    out += ["```", ""]
print("\n".join(out))
