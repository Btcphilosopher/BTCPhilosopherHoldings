# Known limitations

## What this is

A working demonstration of headquarters workflows on fictional data. It is not production software and
is not connected to any real retailer, payment provider, POS estate, warehouse or HR system.

## Verification status

| Item | Status |
|---|---|
| Backend test suite (39 tests, real PostgreSQL 16) | Run and passing in the build environment |
| Migration from an empty database, seed, and 12-step scenario | Run and passing; the scenario output is `docs/DEMO_TRANSCRIPT.txt` |
| Console | Type-checked and production-built; every workspace tab opened in a headless browser against the seeded API with no errors |
| `docker compose` deployment | **Not executed.** The build environment had no Docker daemon. The compose file passes `docker compose config`, and the same commands it runs (migration, seed, API, worker, web build) were run directly. Treat the first container start as untested |
| MinIO / S3 document storage | **Not executed.** The local-directory store was used; the S3 path is written against the standard boto3 API |
| Redis | Used for the cache and worker wake-up during development; tests run without it |

## Simulated or simplified

* **External systems are simulators** behind interfaces in `backend/app/adapters/base.py`: payment
  provider, POS/e-commerce price gateway, scanners, vehicle tracking, proof of delivery, HR/payroll,
  supplier EDI, loyalty platform. The simulated payment provider stores its state in this database
  (`mock_psp_transactions`) so reconciliation can be shown.
* **Authentication** is email + password with a signed token. No SSO, MFA, password policy, lockout or
  token revocation. Demo users share one password.
* **Finance** is a demonstration subledger, not a general ledger: no period close, no multi-currency, no
  accrual reversal, no VAT return, no fixed assets, no intercompany. Operating costs are imported
  accruals. Accounting policies are placeholders subject to review by qualified finance staff.
* **Tax**: two VAT categories with a simple inclusive calculation. Real product tax classification is
  more involved.
* **Forecasting**: three baselines. No promotions, price, weather, events or new-product handling.
  Evaluated on 14 days of holdout on synthetic data, so the error figures say nothing about real demand.
* **Replenishment** recommends for the distribution centre only; stores are replenished by allocation.
  Safety stock is a setting, not derived from service level.
* **Route planning** is a greedy baseline on a fictional planning grid with straight-line distances. It
  respects capacity, temperature compartments and delivery windows and reports infeasible stops, but it
  does not optimise, model driver hours, or use road networks.
* **Bin-level stock** is not tracked: put-away records a location on the task, balances are per site and
  lot. Store-to-store transfers are immediate rather than via in-transit.
* **Workforce**: scheduling constraints are configurable checks, not an employment-law engine, and there
  is no payroll. No medical or absence-reason data is stored by design.
* **Loyalty**: fictional earn/burn/expiry rules. Refunds of points tender re-credit points.
* **Promotion evaluation** uses a simple difference-in-differences with few stores and no significance
  test; cannibalisation and pull-forward are not measured.
* **Insights** are rule-based summaries, not a language model.
* **Picking accuracy** measures completeness (picked vs requested), not mis-picks.
* **Seeded history**: sales, receipts and settlements carry their business dates, but stock-movement rows
  are timestamped when the seed ran (the ledger is immutable, so they are not back-dated).
* **Demo scale**: seven sites, 34 products, 8 suppliers, ~800 sales. List endpoints cap rows rather than
  paginate; nothing was load-tested.
* **Console**: desktop, laptop and tablet widths; no offline mode, no localisation beyond en-GB, light
  theme only. Charts are hand-built SVG with a table alternative.
* **Site scope on shared records**: products, suppliers and national prices are visible to anyone with
  the read permission; only site-level records are scope-filtered.
* **Reorder recommendations and forecasts** run synchronously from the console by default (a background
  option exists); with real volumes they would always be jobs.

## Naming

"TESCO HQ" is the working title requested for this concept. Before any external use the product should
be renamed and the colour scheme reviewed, to avoid implying a relationship with Tesco PLC.
