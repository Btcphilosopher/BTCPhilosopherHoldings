# Demonstration walkthrough

`python -m app.seed` (run automatically on first `docker compose up`) loads fictional master data and
14 days of trading, then plays the scenario below **through the public API using each demo user's own
permissions** (`backend/app/seed/scenario.py`). Its output is recorded in `DEMO_TRANSCRIPT.txt`.

Every step can be repeated by hand in the console. Password for all users: `demo1234`.

| # | Step | Sign in as | Console path |
|---|---|---|---|
| 1 | Forecast demand | `buyer` | Procurement › Demand forecast › *Run forecast now*. Compare the three methods' holdout error; pick a product to see history, stock-out markers and the forecast |
| 2 | Recommend replenishment | `buyer` | Procurement › Reorder recommendations › *Generate for DC*. Read the Constraints column; *Accept*, *Override* (reason required) or *Reject*. Then Requisitions › *Convert to PO* |
| 3 | Approve a purchase order | `procurement.manager` | Approvals & Exceptions › *Approve*. (Signed in as `buyer` the request is visible but cannot be decided) |
| 4 | Receive a partial delivery | `warehouse` | Procurement › Goods receipt › *Receive delivery*: reduce a quantity, mark a damaged case, give a delivery-note reference. Submitting the same note again is refused |
| 5 | Allocate stock to stores | `warehouse` | Distribution › Store transfers › *Allocate stock to stores*, *Release picking wave*; Warehouse work queue › complete picks (enter less for a short pick), pack, stage; Route plans › *Plan routes*, *Dispatch*; Deliveries › *Confirm receipt* or *Delivery failed* |
| 6 | Publish a scheduled promotion | `pricing.analyst` then `pricing.manager` | Promotions › *Propose promotion*; manager approves in the inbox, then *Publish*. Pricing › Publication status shows which endpoints confirmed |
| 7 | Process a store sale | `store.ashbourne` | Pricing › Simulated till: build a basket, add member `M-0003`, *Calculate price* to read the rule trace, *Complete sale* |
| 8 | Fulfil an online order with a substitution | `service` then `store.ashbourne` | Online Orders › *New test order*; store user: *Pick* (set picked to 0 and choose a substitute), *Dispatch*, *Hand over* (accept or reject the substitution) |
| 9 | Award loyalty points | `loyalty` | Loyalty › Members › open the member: one `earn` ledger row per sale |
| 10 | Return an item | `store.ashbourne` | Pricing › Sales & returns › *Return items* on a sale; then click the sale to see the reversing journal, stock movement and loyalty entry. (`service` can refund online orders under Online Orders › *Refund*) |
| 11 | Match a supplier invoice | `finance.clerk` then `finance.controller` | Finance › Supplier invoices: choose the PO, *Enter invoice*, *Run 3-way match*, *Request payment*; controller approves in the inbox |
| 12 | Review margin, waste, availability | `exec` | Executive Overview; Analytics |

## Incidents included in the seeded data

| Incident | Where to see it |
|---|---|
| Late supplier deliveries | Procurement › Appointments; exception `late delivery`; Suppliers on-time % |
| Damaged stock on arrival, short delivery | Procurement › discrepancies and returns to supplier; Inventory › damaged bucket |
| Promotion conflict | Exception `promotion conflict` (COLA-15 overlaps FIZZ-3FOR5); Promotions › click the row for overlaps; the simulator shows which wins |
| Uncertain payment outcome | Order ON-0000002 history: `pending → uncertain → authorised`, resolved by provider lookup |
| Duplicate messages | Transcript steps 4, 7, 8, 10: replays return the original result; one receipt, one sale, one authorisation, one refund |
| Published price not confirmed | Terminal `ST04-TILL-2` is offline: Pricing › Publication status; price simulator with that terminal selected |
| Infeasible route | Distribution › Route plans: Bramley Cross Express cannot be reached inside its delivery window |
| Failed store delivery | Distribution › Deliveries: load returned to the distribution centre |
| Invoice that does not match | Finance › Supplier invoices: price outside tolerance; quantity never received |
| Stock-outs hiding demand | Procurement › Demand forecast: red markers; un-censored before forecasting |
| Material stock variance | Approvals & Exceptions: a cycle-count adjustment awaiting a second approver |
| Product withdrawal | Inventory › Product withdrawals: one ice-cream lot quarantined |
| Expiring qualifications, supplier certificate | Workforce › Training; exceptions list |
| Permission change awaiting approval | Approvals & Exceptions (sign in as `security` to decide it) |
| Cash variance | Finance › Store cash: Ravensby Metro |

## Things to try that should be refused

* As `buyer`, approve your own purchase order.
* As `finance.clerk`, approve the payment you requested.
* As `store.ashbourne`, look for another store's stock, or sell at another store via the API.
* Propose a price below a product's floor (Lager or Sauvignon Blanc).
* Plan a shift 4 hours after the same person's previous shift.
* Substitute on an order whose customer preference is "none".
* Refund more units than were sold.
