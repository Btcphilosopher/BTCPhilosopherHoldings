# Entity-relationship diagram

Generated from the SQLAlchemy models (102 tables). Regenerate with `python scripts/gen_erd.py > ../docs/ERD.md` from `backend/`.
Diagrams are Mermaid `erDiagram` blocks, one per domain; they render on GitHub, GitLab and in most Markdown viewers. Only key columns are shown;
`alembic/versions/0001_initial_schema.py` is the authoritative schema.

Cross-domain references are by id (e.g. `site_id`, `product_id`); each diagram shows the foreign keys its tables declare, including those that point into another domain.

## Platform (users, approvals, audit, outbox, jobs)

```mermaid
erDiagram
  approvals {
    integer id PK
    varchar kind
    varchar entity_type
    integer entity_id
    integer site_id
    varchar summary
    numeric amount
    json payload
    varchar required_perm
  }
  audit_log {
    integer id PK
    datetime at
    integer user_id
    varchar user_email
    varchar action
    varchar entity_type
    varchar entity_id
    boolean sensitive
    json detail
  }
  documents {
    integer id PK
    varchar entity_type
    integer entity_id
    varchar name
    varchar content_type
    varchar object_key
    integer size
    integer uploaded_by
    datetime at
  }
  exceptions {
    integer id PK
    varchar kind
    varchar severity
    varchar title
    text detail
    varchar entity_type
    integer entity_id
    integer site_id
    varchar status
  }
  idempotency_keys {
    integer id PK
    varchar scope
    varchar key
    varchar request_hash
    json response
    datetime created_at
  }
  inbound_messages {
    integer id PK
    varchar source
    varchar message_id
    datetime received_at
  }
  integration_deliveries {
    integer id PK
    varchar adapter
    integer event_id FK
    varchar topic
    varchar status
    json response
    datetime at
  }
  jobs {
    integer id PK
    varchar kind
    json payload
    varchar status
    json result
    integer created_by
    datetime created_at
    datetime started_at
    datetime finished_at
  }
  outbox_events {
    integer id PK
    varchar topic
    varchar key
    json payload
    datetime created_at
    datetime published_at
    integer attempts
  }
  settings {
    varchar key PK
    json value
    text description
    integer updated_by
    datetime updated_at
  }
  user_roles {
    integer id PK
    integer user_id FK
    varchar role
    varchar scope_type
    integer scope_id
    integer granted_by
    datetime created_at
  }
  users {
    integer id PK
    varchar email
    varchar name
    varchar job_title
    varchar password_hash
    boolean active
    datetime created_at
  }
  users ||--o{ approvals : "decided_by"
  users ||--o{ approvals : "requested_by"
  outbox_events ||--o{ integration_deliveries : "event_id"
  users ||--o{ user_roles : "user_id"
```

## Organisation

```mermaid
erDiagram
  business_units {
    integer id PK
    varchar code
    varchar name
  }
  departments {
    integer id PK
    integer site_id FK
    varchar code
    varchar name
  }
  locations {
    integer id PK
    integer site_id FK
    varchar code
    varchar kind
    varchar temp_class
    integer capacity_units
  }
  opening_hours {
    integer id PK
    integer site_id FK
    integer weekday
    time opens
    time closes
    varchar note
  }
  regions {
    integer id PK
    integer business_unit_id FK
    varchar code
    varchar name
  }
  site_contacts {
    integer id PK
    integer site_id FK
    varchar role
    varchar name
    varchar phone
    varchar email
  }
  sites {
    integer id PK
    varchar code
    varchar name
    varchar kind
    integer region_id FK
    integer format_id FK
    varchar address
    numeric grid_x
    numeric grid_y
  }
  store_formats {
    integer id PK
    varchar code
    varchar name
    varchar assortment_tier
    json replenishment_policy
  }
  sites ||--o{ departments : "site_id"
  sites ||--o{ locations : "site_id"
  sites ||--o{ opening_hours : "site_id"
  business_units ||--o{ regions : "business_unit_id"
  sites ||--o{ site_contacts : "site_id"
  store_formats ||--o{ sites : "format_id"
  regions ||--o{ sites : "region_id"
```

## Product master

```mermaid
erDiagram
  categories {
    integer id PK
    varchar code
    varchar name
    integer parent_id FK
    varchar department
  }
  product_barcodes {
    integer id PK
    integer product_id FK
    varchar gtin
    varchar level
  }
  product_versions {
    integer id PK
    integer product_id FK
    integer version
    json snapshot
    text change_note
    integer changed_by
    datetime changed_at
  }
  products {
    integer id PK
    varchar sku
    varchar name
    varchar brand
    integer variant_of_id FK
    varchar variant_label
    integer category_id FK
    integer tax_category_id FK
    varchar storage_class
  }
  tax_categories {
    integer id PK
    varchar code
    varchar name
    numeric rate
  }
  categories ||--o{ categories : "parent_id"
  products ||--o{ product_barcodes : "product_id"
  products ||--o{ product_versions : "product_id"
  tax_categories ||--o{ products : "tax_category_id"
  categories ||--o{ products : "category_id"
  products ||--o{ products : "variant_of_id"
```

## Suppliers

```mermaid
erDiagram
  cost_history {
    integer id PK
    integer supplier_product_id FK
    numeric case_cost
    date effective_from
    varchar source
    datetime recorded_at
  }
  quality_incidents {
    integer id PK
    integer supplier_id FK
    integer product_id FK
    varchar lot_code
    varchar severity
    text description
    varchar status
    datetime raised_at
  }
  supplier_categories {
    integer id PK
    integer supplier_id FK
    integer category_id FK
  }
  supplier_products {
    integer id PK
    integer supplier_id FK
    integer product_id FK
    numeric case_cost
    integer moq_cases
    boolean available
    boolean is_primary
  }
  supplier_qualifications {
    integer id PK
    integer supplier_id FK
    varchar kind
    varchar reference
    date valid_to
    varchar status
  }
  suppliers {
    integer id PK
    varchar code
    varchar name
    varchar status
    integer lead_time_days
    varchar delivery_weekdays
    varchar delivery_terms
    integer payment_terms_days
    numeric min_order_value
  }
  supplier_products ||--o{ cost_history : "supplier_product_id"
  suppliers ||--o{ quality_incidents : "supplier_id"
  products ||--o{ quality_incidents : "product_id"
  categories ||--o{ supplier_categories : "category_id"
  suppliers ||--o{ supplier_categories : "supplier_id"
  suppliers ||--o{ supplier_products : "supplier_id"
  products ||--o{ supplier_products : "product_id"
  suppliers ||--o{ supplier_qualifications : "supplier_id"
```

## Procurement & replenishment

```mermaid
erDiagram
  delivery_appointments {
    integer id PK
    integer po_id FK
    integer site_id FK
    datetime slot_start
    datetime slot_end
    varchar dock
    varchar status
    datetime actual_arrival
  }
  demand_observations {
    integer id PK
    integer site_id FK
    integer product_id FK
    date day
    numeric units_sold
    boolean stockout
    varchar source
  }
  forecast_runs {
    integer id PK
    datetime created_at
    integer created_by
    date as_of
    integer horizon_days
    integer holdout_days
    varchar chosen_method
    json evaluation
    integer series_count
  }
  forecasts {
    integer id PK
    integer run_id FK
    integer site_id FK
    integer product_id FK
    date day
    numeric qty
  }
  goods_receipt_lines {
    integer id PK
    integer receipt_id FK
    integer po_line_id FK
    integer lot_id FK
    integer cases_received
    integer cases_damaged
  }
  goods_receipts {
    integer id PK
    integer po_id FK
    integer site_id FK
    varchar delivery_note_ref
    datetime received_at
    integer received_by
  }
  purchase_order_lines {
    integer id PK
    integer po_id FK
    integer product_id FK
    varchar description
    numeric case_size
    integer cases_ordered
    numeric case_cost
    integer cases_received
    integer cases_damaged
  }
  purchase_orders {
    integer id PK
    varchar number
    integer supplier_id FK
    integer site_id FK
    varchar status
    date expected_date
    numeric net_total
    integer created_by
    integer approved_by
  }
  quotations {
    integer id PK
    integer supplier_id FK
    integer product_id FK
    numeric case_cost
    integer moq_cases
    date valid_until
    varchar status
    datetime received_at
    integer decided_by
  }
  receipt_discrepancies {
    integer id PK
    integer receipt_id FK
    integer po_line_id FK
    varchar kind
    integer cases
    varchar status
    text note
  }
  reorder_recommendations {
    integer id PK
    integer run_id FK
    integer site_id FK
    integer product_id FK
    integer supplier_id FK
    datetime created_at
    numeric need_units
    integer unconstrained_cases
    integer recommended_cases
  }
  replenishment_policies {
    integer id PK
    integer site_id FK
    integer product_id FK
    numeric safety_stock
    numeric max_capacity
  }
  requisition_lines {
    integer id PK
    integer requisition_id FK
    integer product_id FK
    integer cases
    integer recommendation_id
  }
  requisitions {
    integer id PK
    varchar number
    integer site_id FK
    integer supplier_id FK
    varchar status
    integer requested_by
    datetime created_at
    integer po_id
  }
  supplier_invoice_lines {
    integer id PK
    integer invoice_id FK
    integer po_line_id FK
    integer cases
    numeric case_cost
    numeric tax_rate
  }
  supplier_invoices {
    integer id PK
    integer supplier_id FK
    integer po_id FK
    varchar invoice_no
    date invoice_date
    date due_date
    numeric net
    numeric tax
    numeric gross
  }
  supplier_returns {
    integer id PK
    integer supplier_id FK
    integer site_id FK
    integer product_id FK
    integer lot_id FK
    numeric qty
    varchar reason
    varchar status
    datetime created_at
  }
  purchase_orders ||--o{ delivery_appointments : "po_id"
  sites ||--o{ delivery_appointments : "site_id"
  sites ||--o{ demand_observations : "site_id"
  products ||--o{ demand_observations : "product_id"
  forecast_runs ||--o{ forecasts : "run_id"
  products ||--o{ forecasts : "product_id"
  sites ||--o{ forecasts : "site_id"
  lots ||--o{ goods_receipt_lines : "lot_id"
  goods_receipts ||--o{ goods_receipt_lines : "receipt_id"
  purchase_order_lines ||--o{ goods_receipt_lines : "po_line_id"
  purchase_orders ||--o{ goods_receipts : "po_id"
  sites ||--o{ goods_receipts : "site_id"
  products ||--o{ purchase_order_lines : "product_id"
  purchase_orders ||--o{ purchase_order_lines : "po_id"
  sites ||--o{ purchase_orders : "site_id"
  suppliers ||--o{ purchase_orders : "supplier_id"
  suppliers ||--o{ quotations : "supplier_id"
  products ||--o{ quotations : "product_id"
  purchase_order_lines ||--o{ receipt_discrepancies : "po_line_id"
  goods_receipts ||--o{ receipt_discrepancies : "receipt_id"
  products ||--o{ reorder_recommendations : "product_id"
  forecast_runs ||--o{ reorder_recommendations : "run_id"
  suppliers ||--o{ reorder_recommendations : "supplier_id"
  sites ||--o{ reorder_recommendations : "site_id"
  products ||--o{ replenishment_policies : "product_id"
  sites ||--o{ replenishment_policies : "site_id"
  requisitions ||--o{ requisition_lines : "requisition_id"
  products ||--o{ requisition_lines : "product_id"
  suppliers ||--o{ requisitions : "supplier_id"
  sites ||--o{ requisitions : "site_id"
  supplier_invoices ||--o{ supplier_invoice_lines : "invoice_id"
  purchase_order_lines ||--o{ supplier_invoice_lines : "po_line_id"
  suppliers ||--o{ supplier_invoices : "supplier_id"
  purchase_orders ||--o{ supplier_invoices : "po_id"
  sites ||--o{ supplier_returns : "site_id"
  products ||--o{ supplier_returns : "product_id"
  suppliers ||--o{ supplier_returns : "supplier_id"
  lots ||--o{ supplier_returns : "lot_id"
```

## Inventory

```mermaid
erDiagram
  cycle_counts {
    integer id PK
    integer site_id FK
    integer product_id FK
    integer lot_id FK
    numeric system_qty
    numeric counted_qty
    numeric variance
    varchar status
    integer approval_id
  }
  lots {
    integer id PK
    integer product_id FK
    varchar lot_code
    date expiry_date
    integer supplier_id FK
    integer receipt_id
    numeric unit_cost
    integer location_id FK
    datetime created_at
  }
  reservations {
    integer id PK
    varchar ref_type
    integer ref_id
    integer site_id FK
    integer product_id FK
    integer lot_id FK
    numeric qty
    varchar status
    datetime created_at
  }
  stock_balances {
    integer id PK
    integer site_id FK
    integer product_id FK
    integer lot_id FK
    varchar bucket
    numeric qty
  }
  stock_movements {
    integer id PK
    datetime at
    integer site_id FK
    integer product_id FK
    integer lot_id FK
    varchar bucket
    numeric qty
    varchar mtype
    varchar ref_type
  }
  withdrawal_items {
    integer id PK
    integer withdrawal_id FK
    integer site_id FK
    integer lot_id FK
    numeric qty_quarantined
    varchar from_bucket
  }
  withdrawals {
    integer id PK
    integer product_id FK
    integer lot_id FK
    text reason
    varchar status
    integer initiated_by
    datetime at
    datetime closed_at
    json summary
  }
  products ||--o{ cycle_counts : "product_id"
  sites ||--o{ cycle_counts : "site_id"
  lots ||--o{ cycle_counts : "lot_id"
  suppliers ||--o{ lots : "supplier_id"
  products ||--o{ lots : "product_id"
  locations ||--o{ lots : "location_id"
  lots ||--o{ reservations : "lot_id"
  sites ||--o{ reservations : "site_id"
  products ||--o{ reservations : "product_id"
  sites ||--o{ stock_balances : "site_id"
  lots ||--o{ stock_balances : "lot_id"
  products ||--o{ stock_balances : "product_id"
  products ||--o{ stock_movements : "product_id"
  lots ||--o{ stock_movements : "lot_id"
  sites ||--o{ stock_movements : "site_id"
  lots ||--o{ withdrawal_items : "lot_id"
  withdrawals ||--o{ withdrawal_items : "withdrawal_id"
  sites ||--o{ withdrawal_items : "site_id"
  products ||--o{ withdrawals : "product_id"
  lots ||--o{ withdrawals : "lot_id"
```

## Distribution & transport

```mermaid
erDiagram
  pick_waves {
    integer id PK
    integer site_id FK
    varchar status
    datetime created_at
    integer created_by
  }
  route_plans {
    integer id PK
    integer site_id FK
    date day
    datetime depart_at
    varchar method
    varchar status
    json infeasible
    datetime created_at
    integer created_by
  }
  route_stops {
    integer id PK
    integer route_id FK
    integer seq
    integer site_id FK
    integer transfer_id FK
    datetime window_start
    datetime window_end
    datetime planned_arrival
    datetime live_eta
  }
  routes {
    integer id PK
    integer plan_id FK
    integer vehicle_id FK
    varchar status
    integer load_cages
    numeric distance_km
  }
  transfer_lines {
    integer id PK
    integer transfer_id FK
    integer product_id FK
    numeric qty_requested
    numeric qty_allocated
    numeric qty_picked
    numeric qty_received
  }
  transfers {
    integer id PK
    varchar number
    integer from_site_id FK
    integer to_site_id FK
    varchar status
    integer wave_id FK
    integer route_stop_id
    json cages
    datetime created_at
  }
  vehicles {
    integer id PK
    integer site_id FK
    varchar fleet_no
    integer capacity_cages
    boolean chilled
    boolean frozen
    varchar status
  }
  warehouse_tasks {
    integer id PK
    integer site_id FK
    varchar kind
    varchar status
    varchar ref_type
    integer ref_id
    integer transfer_id FK
    integer product_id FK
    integer lot_id FK
  }
  sites ||--o{ pick_waves : "site_id"
  sites ||--o{ route_plans : "site_id"
  transfers ||--o{ route_stops : "transfer_id"
  routes ||--o{ route_stops : "route_id"
  sites ||--o{ route_stops : "site_id"
  route_plans ||--o{ routes : "plan_id"
  vehicles ||--o{ routes : "vehicle_id"
  transfers ||--o{ transfer_lines : "transfer_id"
  products ||--o{ transfer_lines : "product_id"
  sites ||--o{ transfers : "from_site_id"
  sites ||--o{ transfers : "to_site_id"
  pick_waves ||--o{ transfers : "wave_id"
  sites ||--o{ vehicles : "site_id"
  sites ||--o{ warehouse_tasks : "site_id"
  products ||--o{ warehouse_tasks : "product_id"
  lots ||--o{ warehouse_tasks : "lot_id"
  transfers ||--o{ warehouse_tasks : "transfer_id"
```

## Pricing & promotions

```mermaid
erDiagram
  coupons {
    integer id PK
    varchar code
    varchar description
    numeric amount_off
    numeric min_spend
    integer member_id FK
    datetime valid_to
    varchar status
    integer redeemed_sale_id
  }
  pos_terminals {
    integer id PK
    integer site_id FK
    varchar code
    varchar kind
    boolean online
  }
  price_books {
    integer id PK
    varchar code
    varchar name
    varchar scope_type
    integer scope_id
    varchar channel
    boolean active
  }
  price_entries {
    integer id PK
    integer price_book_id FK
    integer product_id FK
    numeric price
    datetime effective_from
    datetime effective_to
    varchar status
    integer version
    text reason
  }
  price_publications {
    integer id PK
    varchar item_type
    integer item_id
    integer terminal_id FK
    varchar status
    datetime sent_at
    datetime acknowledged_at
    integer attempts
    varchar last_error
  }
  promotion_products {
    integer id PK
    integer promotion_id FK
    integer product_id FK
  }
  promotions {
    integer id PK
    varchar code
    varchar name
    varchar kind
    json params
    varchar channel
    json site_ids
    json control_site_ids
    integer lot_id FK
  }
  loyalty_members ||--o{ coupons : "member_id"
  sites ||--o{ pos_terminals : "site_id"
  products ||--o{ price_entries : "product_id"
  price_books ||--o{ price_entries : "price_book_id"
  pos_terminals ||--o{ price_publications : "terminal_id"
  promotions ||--o{ promotion_products : "promotion_id"
  products ||--o{ promotion_products : "product_id"
  lots ||--o{ promotions : "lot_id"
```

## Sales & payments

```mermaid
erDiagram
  payments {
    integer id PK
    integer sale_id FK
    integer order_id
    integer return_id
    integer site_id FK
    varchar kind
    varchar method
    numeric amount
    varchar status
  }
  sale_lines {
    integer id PK
    integer sale_id FK
    integer product_id FK
    integer product_version
    varchar description
    integer lot_id FK
    numeric qty
    numeric unit_price
    numeric gross_before_discount
  }
  sale_return_lines {
    integer id PK
    integer return_id FK
    integer sale_line_id FK
    numeric qty
    numeric gross
    varchar disposition
  }
  sale_returns {
    integer id PK
    varchar number
    integer sale_id FK
    integer site_id FK
    datetime at
    text reason
    numeric gross
    numeric net
    numeric tax
  }
  sales {
    integer id PK
    varchar number
    integer site_id FK
    integer terminal_id FK
    varchar channel
    datetime at
    integer member_id FK
    integer order_id
    numeric gross_before_discount
  }
  sites ||--o{ payments : "site_id"
  sales ||--o{ payments : "sale_id"
  sales ||--o{ sale_lines : "sale_id"
  lots ||--o{ sale_lines : "lot_id"
  products ||--o{ sale_lines : "product_id"
  sale_lines ||--o{ sale_return_lines : "sale_line_id"
  sale_returns ||--o{ sale_return_lines : "return_id"
  sites ||--o{ sale_returns : "site_id"
  sales ||--o{ sale_returns : "sale_id"
  pos_terminals ||--o{ sales : "terminal_id"
  sites ||--o{ sales : "site_id"
  loyalty_members ||--o{ sales : "member_id"
```

## Online & customer service

```mermaid
erDiagram
  customers {
    integer id PK
    varchar ref
    varchar name
    varchar email
    varchar address
    varchar substitution_pref
    integer member_id FK
    boolean synthetic
  }
  delivery_slots {
    integer id PK
    integer site_id FK
    varchar method
    datetime starts_at
    datetime ends_at
    integer capacity
    integer booked
  }
  online_order_lines {
    integer id PK
    integer order_id FK
    integer product_id FK
    varchar description
    numeric qty
    numeric unit_price
    numeric line_gross
    json pricing
    boolean allow_substitution
  }
  online_orders {
    integer id PK
    varchar number
    integer customer_id FK
    integer site_id FK
    integer slot_id FK
    varchar method
    varchar order_status
    varchar payment_status
    varchar fulfilment_status
  }
  service_cases {
    integer id PK
    varchar number
    integer customer_id FK
    integer order_id FK
    integer site_id FK
    varchar category
    varchar subject
    varchar status
    json notes
  }
  loyalty_members ||--o{ customers : "member_id"
  sites ||--o{ delivery_slots : "site_id"
  products ||--o{ online_order_lines : "product_id"
  online_orders ||--o{ online_order_lines : "order_id"
  products ||--o{ online_order_lines : "sub_product_id"
  delivery_slots ||--o{ online_orders : "slot_id"
  customers ||--o{ online_orders : "customer_id"
  sites ||--o{ online_orders : "site_id"
  online_orders ||--o{ service_cases : "order_id"
  customers ||--o{ service_cases : "customer_id"
  sites ||--o{ service_cases : "site_id"
```

## Loyalty

```mermaid
erDiagram
  loyalty_cards {
    integer id PK
    integer member_id FK
    varchar token
    varchar kind
    varchar status
  }
  loyalty_ledger {
    integer id PK
    integer member_id FK
    datetime at
    varchar kind
    integer points
    varchar ref_type
    integer ref_id
    text note
  }
  loyalty_members {
    integer id PK
    varchar member_no
    varchar display_name
    varchar email
    varchar status
    integer points_balance
    json comms_prefs
    datetime joined_at
    datetime last_activity_at
  }
  loyalty_members ||--o{ loyalty_cards : "member_id"
  loyalty_members ||--o{ loyalty_ledger : "member_id"
```

## Workforce

```mermaid
erDiagram
  availability {
    integer id PK
    integer employee_id FK
    integer weekday
    time from_time
    time to_time
  }
  employee_private {
    integer employee_id PK
    date date_of_birth
    varchar home_address
    varchar personal_phone
    varchar emergency_contact
  }
  employees {
    integer id PK
    varchar employee_no
    varchar name
    integer site_id FK
    varchar department
    varchar job_role
    numeric contract_hours
    varchar status
    date started_on
  }
  leave_requests {
    integer id PK
    integer employee_id FK
    date from_date
    date to_date
    varchar category
    varchar status
    integer decided_by
    datetime requested_at
  }
  maintenance_requests {
    integer id PK
    integer site_id FK
    varchar equipment
    text description
    varchar priority
    varchar status
    integer raised_by
    datetime raised_at
    varchar contractor_ref
  }
  shifts {
    integer id PK
    integer employee_id FK
    integer site_id FK
    datetime starts_at
    datetime ends_at
    varchar duty
    varchar status
    json warnings
    integer created_by
  }
  store_tasks {
    integer id PK
    integer site_id FK
    varchar title
    varchar category
    varchar priority
    datetime due_at
    varchar status
    integer assigned_to FK
    integer created_by
  }
  timesheet_entries {
    integer id PK
    integer employee_id FK
    date work_date
    numeric hours
    varchar source
    integer job_id
  }
  training_records {
    integer id PK
    integer employee_id FK
    varchar course
    date completed_on
    date expires_on
  }
  employees ||--o{ availability : "employee_id"
  sites ||--o{ employees : "site_id"
  employees ||--o{ leave_requests : "employee_id"
  sites ||--o{ maintenance_requests : "site_id"
  sites ||--o{ shifts : "site_id"
  employees ||--o{ shifts : "employee_id"
  sites ||--o{ store_tasks : "site_id"
  employees ||--o{ store_tasks : "assigned_to"
  employees ||--o{ timesheet_entries : "employee_id"
  employees ||--o{ training_records : "employee_id"
```

## Finance

```mermaid
erDiagram
  accounts {
    integer id PK
    varchar code
    varchar name
    varchar kind
  }
  budgets {
    integer id PK
    date period_start
    date period_end
    integer site_id FK
    varchar metric
    numeric amount
    varchar version
  }
  cash_reconciliations {
    integer id PK
    integer site_id FK
    date business_date
    numeric expected
    numeric counted
    numeric variance
    varchar status
    text note
    integer counted_by
  }
  journal_entries {
    integer id PK
    varchar number
    date entry_date
    varchar source_type
    integer source_id
    varchar description
    integer posted_by
    datetime posted_at
    integer reverses_id FK
  }
  journal_lines {
    integer id PK
    integer entry_id FK
    integer account_id FK
    integer site_id FK
    numeric debit
    numeric credit
    varchar memo
  }
  legacy_sales_daily {
    integer id PK
    integer site_id FK
    date day
    numeric net_sales
    varchar source
  }
  operating_costs {
    integer id PK
    integer site_id FK
    date day
    varchar category
    numeric amount
    varchar source
    integer journal_entry_id
  }
  settlements {
    integer id PK
    varchar provider
    varchar batch_ref
    date business_date
    numeric gross
    numeric refunds
    numeric fees
    numeric net
    numeric ledger_gross
  }
  supplier_payments {
    integer id PK
    integer supplier_id FK
    integer invoice_id FK
    numeric amount
    varchar status
    integer approval_id
    integer requested_by
    datetime paid_at
    varchar bank_ref
  }
  sites ||--o{ budgets : "site_id"
  sites ||--o{ cash_reconciliations : "site_id"
  journal_entries ||--o{ journal_entries : "reverses_id"
  sites ||--o{ journal_lines : "site_id"
  journal_entries ||--o{ journal_lines : "entry_id"
  accounts ||--o{ journal_lines : "account_id"
  sites ||--o{ legacy_sales_daily : "site_id"
  sites ||--o{ operating_costs : "site_id"
  supplier_invoices ||--o{ supplier_payments : "invoice_id"
  suppliers ||--o{ supplier_payments : "supplier_id"
```

## Simulated external systems

```mermaid
erDiagram
  mock_psp_transactions {
    integer id PK
    varchar idempotency_key
    varchar kind
    numeric amount
    varchar status
    varchar ref
    varchar parent_ref
    date business_date
    datetime created_at
  }
```

