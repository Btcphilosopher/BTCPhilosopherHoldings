# Architecture

## Shape

A **modular monolith**: one deployable API, one worker, one PostgreSQL database. Each business domain is
a package under `backend/app/domains/` with the same three files:

| File | Responsibility |
|---|---|
| `models.py` | Tables owned by the domain |
| `service.py` | Business rules. The only code allowed to change the domain's state |
| `api.py` | HTTP routes: authorise, call the service, commit, return |

| Domain | Owns | Console workspace |
|---|---|---|
| `platform` | users, role grants, approvals, audit log, idempotency keys, outbox, jobs, settings, exceptions, documents | Administration, Approvals & Exceptions |
| `org` | business units, regions, formats, sites, departments, locations, opening hours, contacts | Stores |
| `catalog` | products, variants, versions, barcodes, categories, tax categories | Products |
| `suppliers` | suppliers, approved categories, supplier products, cost history, qualifications, incidents | Suppliers |
| `procurement` | demand observations, forecasts, replenishment policies, recommendations, requisitions, quotations, POs, appointments, receipts, discrepancies, supplier returns, supplier invoices | Procurement |
| `inventory` | lots, stock balances, **stock movement ledger**, reservations, cycle counts, withdrawals | Inventory |
| `distribution` | transfers, pick waves, warehouse tasks, vehicles, route plans, routes, stops | Distribution |
| `pricing` | price books, price entries, promotions, coupons, terminals, publications; the price engine | Pricing, Promotions |
| `sales` | sales, sale lines, payments, returns | (till in Pricing), Executive Overview |
| `online` | customers, slots, online orders and lines, service cases | Online Orders |
| `loyalty` | members, cards, **points ledger** | Loyalty |
| `workforce` | employees, restricted personal record, availability, shifts, training, leave, timesheets, store tasks, maintenance | Workforce |
| `finance` | chart of accounts, **journal**, supplier payments, settlements, cash reconciliations, budgets, operating costs | Finance |
| `analytics` | no tables: read-only metrics over the others | Executive Overview, Analytics |

Dependency direction: `api → service → models`. Services call other domains' *services* (for example
`sales.service` calls `inventory.service`, `loyalty.service`, `finance.service`), never their tables
directly for writes. `analytics` only reads. A domain could be lifted into its own service by replacing
those in-process calls with its outbox topics and API; that was deliberately not done yet — complete
workflows came first.

Shared master data (sites, products, suppliers, members) is referenced by id from every transaction, so
one sale can be followed to its price entry, promotion, lot, receipt, purchase order, supplier, journal
entry, payment and settlement.

## Consistency guarantees

PostgreSQL is the only system of record for stock and money. Redis holds a 30-second read cache and a
bounded worker wake-up list — nothing that matters if it is lost.

| Risk | Mechanism | Where |
|---|---|---|
| Stock goes negative | `CHECK (qty >= 0)` on `stock_balances`; decrements are conditional updates | `inventory/service.py::post` |
| Balance drifts from history | Every change writes a movement row and updates the balance in one transaction; `/inventory/integrity` recomputes and compares | `inventory/api.py` |
| Ledger rewritten | Triggers reject `UPDATE`/`DELETE` on `stock_movements`, `loyalty_ledger`, `journal_lines`, `audit_log` | `app/ddl.py` |
| Two orders take the last unit | `SELECT … FOR UPDATE` on the lot balances, first-expiry-first-out | `inventory/service.py::reserve` |
| Slot overbooked | `UPDATE … SET booked = booked + 1 WHERE booked < capacity` | `online/service.py` |
| Delivery received twice | Unique `(po_id, delivery_note_ref)`, plus idempotency key | `procurement/models.py` |
| Retry creates a second order / charge / refund | `Idempotency-Key` claimed inside the business transaction; concurrent duplicates block on the unique index and then read the first result. The payment provider is called with a key derived from it | `common.py::idem_begin` |
| Unbalanced accounting | Checked in `post_journal`, and again by a deferred constraint trigger at commit | `finance/service.py`, `app/ddl.py` |
| Points awarded or spent twice | Unique `(member, kind, ref_type, ref_id)` on the ledger; redemption is a conditional decrement | `loyalty/service.py` |
| Coupon replay | `UPDATE … WHERE status = 'active'` must change exactly one row | `loyalty/service.py` |
| Lost update | `version` column with optimistic locking on products, purchase orders, online orders | models |
| Event lost between commit and send | Outbox row written in the same transaction; worker relays with `FOR UPDATE SKIP LOCKED` | `common.py::emit`, `worker.py` |
| Uncertain payment outcome | Order stays `placed` / `uncertain`; resolved by looking the original key up at the provider, never by charging again | `online/service.py::resolve_payment` |

## State machines

Online orders carry three independent states (`online/service.py::MACHINES`); every transition is
validated and appended to the order's history.

```
order:      placed → confirmed → completed | cancelled
payment:    pending → authorised → captured → part_refunded → refunded
            pending → failed ;  pending → uncertain → authorised | failed ;  authorised → voided
fulfilment: unallocated → reserved → picked → out_for_delivery | ready_for_collection
            → delivered | collected | failed ;  (before handover) → released
```

An order is not a sale. Revenue is recognised at handover; cash arrives at settlement (T+2 by policy).
Prices and promotions move through `pending_approval → approved → published`, and separately each
endpoint moves `sent → acknowledged | failed`. The price engine ignores a published price at a terminal
that has not acknowledged it.

## Stock buckets

`available`, `reserved`, `in_transit`, `quarantined`, `damaged`, `expired` are disjoint.
**On hand = available + reserved.** In-transit stock is recorded at the destination site. Inventory value
uses the first four buckets at specific lot cost; damaged and expired stock has been written off.

## Money, tax and rounding

* GBP, `NUMERIC(14,2)`; unit costs `NUMERIC(14,4)`; quantities `NUMERIC(14,3)` (kg for weighed goods). Python `Decimal` end to end; JSON carries decimal strings.
* Shelf prices include VAT. Per line: `net = round_half_up(gross / (1 + rate))`, `tax = gross − net`. Basket totals are sums of lines.
* Purchases are VAT-exclusive; input VAT is posted at invoice match.
* Policies (`finance.policy`, `pricing.policy`, `loyalty.policy`, `procurement.policy`, `inventory.policy`, `workforce.policy`, `analytics.policy`) are data, editable under Administration › Policies, audited, and labelled as demonstration policies subject to review.

Postings:

| Event | Debit | Credit |
|---|---|---|
| Goods receipt | 1200 Inventory | 2010 Goods received not invoiced |
| Invoice matched | 2010 GRNI, 1300 VAT input, (5200 price variance) | 2000 Trade payables |
| Supplier payment approved | 2000 Trade payables | 1000 Bank |
| Sale | 1020 Card receivable / 1010 Cash in tills / 2200 Points liability; 5000 COGS; 4020 Points issued | 4000 Revenue, 2100 VAT output; 1200 Inventory; 2200 Points liability |
| Refund | 4010 Returns, 2100 VAT output; 1200 Inventory or 5100 Waste; 2200 | Tender account; 5000 COGS; 4020 |
| Card settlement | 1000 Bank, 6000 Fees | 1020 Card receivable |
| Cash banked | 1000 Bank, (6900 over/short) | 1010 Cash in tills |
| Waste / expiry / count loss | 5100 Waste and shrink | 1200 Inventory |

## Pricing precedence

1. Base price: most specific published price book (site › format › national; channel-specific beats all-channel), then latest effective date.
2. Short-dated markdown on the scanned lot replaces other item promotions for those units.
3. Exclusive promotions by priority; within a priority the better customer saving wins, then lowest id. Units discounted once.
4. Stackable percentage promotions on the already-discounted line.
5. Product price floor caps the discount.
6. Basket coupons (one per basket by default), spread pro rata.

Returns refund the price actually paid; coupons are not reinstated. Inputs to pricing are product, place,
channel, time, membership (yes/no) and presented coupons — never personal characteristics.

## Forecasting and replenishment

Three transparent baselines (seasonal-naive, 7-day moving average, 4-week weekday profile), scored on a
fixed-origin, time-ordered holdout by WAPE, MAE and bias. Stock-out days are un-censored before fitting
so lost sales are not learned as low demand. Recommendation:
`need = forecast over (lead time + review period) + safety stock − (DC available + on order)`,
then, in order and each recorded on the recommendation: supplier availability, case pack, minimum order
quantity, storage capacity, expiry risk, delivery calendar, working-capital limit. Buyers may override
with a recorded reason.

## Permissions

Permissions are `domain.action` strings (`backend/app/permissions.py`). A role is a set of permissions; a
**grant** gives a user a role for a scope: global, business unit, region or site. Every route declares
the permission it needs; list queries are filtered to the caller's sites and writes check the target
record's site. Records with no site (national prices, suppliers, products) need a global grant.
Sensitive data has its own permissions (`workforce.private.read`, `loyalty.member.read`) and each access
is written to the audit log, as is every export.

Maker-checker (`platform/approvals.py`) covers purchase orders, price changes at or above the threshold,
promotions, supplier payments, stock adjustments above the approval value, and role grants. The decider
must hold the approval permission for the record's scope **and** must not be the requester.

Roles provided: administrator, executive, headquarters analyst, buyer, procurement manager, pricing
analyst, pricing manager, finance clerk, finance controller, HR partner, regional manager, store manager,
warehouse team, customer service, loyalty manager, auditor.

## Decision support and AI

`/analytics/insights` groups open exceptions, cites the exception and source record for every statement,
and suggests what to look at. The bundled provider is deterministic rules, not a language model; the
`InsightProvider` interface is read-only, so any provider plugged in there cannot change prices, approve
payments or alter personnel records. Pricing recommendations are likewise suggestions that enter the
normal propose → approve → publish path.

Promotion outcomes are reported as an uplift estimate (difference-in-differences) only where holdout
stores were configured; otherwise the raw before/after change is shown and labelled as not causal.

## Metric definitions

Every metric returned by `/executive/overview` and `/analytics/summary` carries `definition`, `period`,
`unit`, `source`, and for ratios `numerator`, `denominator`, `exclusions`, plus a `drill` path to the
underlying rows. The console shows these on each tile. Summary:

| Metric | Definition | Source |
|---|---|---|
| Online orders placed | Orders placed in the period at estimated value (not sales) | `online_orders` |
| Completed sales | Till sales plus online orders handed over, VAT-inclusive | `sales` |
| Revenue (net) | Accounts 4000 + 4010 + 4020 | `journal_lines` |
| Cash receipts | Debits to bank from settlements and cash banking | `journal_lines` |
| Refunds | Customer refunds at price paid | `sale_returns` |
| Gross profit / margin | Revenue − COGS (5000); margin = gross profit / revenue | `journal_lines` |
| Inventory value | qty × lot cost for available, reserved, in transit, quarantined | `stock_balances`, `lots` |
| Operating costs | Accounts 6000–6899 | `journal_lines`, `operating_costs` |
| Availability | Ranged store × product lines with available > 0 / ranged lines | `stock_balances`, `replenishment_policies` |
| Waste | Account 5100; rate = waste / revenue | `journal_lines` |
| Supplier on time / in full | Arrived by slot end / arrived; cases accepted / cases ordered | `delivery_appointments`, `purchase_order_lines` |
| Like-for-like | Eligible stores only: trading and open ≥ 52 weeks before the comparative period | `sales`, `legacy_sales_daily` |
| Forecast error | WAPE of the chosen baseline on the holdout | `forecast_runs` |

## Chart colours

Series colours (actual `#00539F`, budget `#C26A00`, forecast `#00947F`) were checked for separation under
colour-vision deficiency; each series also differs by mark (bars, dashed line, line with markers), every
chart has a table view, and red is reserved for exceptions.
