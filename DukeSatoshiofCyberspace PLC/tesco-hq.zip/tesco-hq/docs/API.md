# API reference (v1)

Interactive documentation with request/response schemas is served by the API itself: **`/docs`** (Swagger UI) and **`/openapi.json`**.
This file is generated from that schema. All routes are under `/api/v1`; a future breaking revision would be published as `/api/v2` alongside it.

## Conventions

| Topic | Rule |
|---|---|
| Authentication | `POST /api/v1/auth/login` returns a bearer token; send `Authorization: Bearer <token>`. |
| Authorisation | Enforced on the server for every route: by function (permission), by scope (business unit / region / site) and by data sensitivity. The console only hides what the API would refuse. |
| Money | GBP. Decimal strings (`"12.34"`), never floats. Shelf prices include VAT; `net` and `tax` are always returned separately. |
| Idempotency | Marked **⟳** below. Send an `Idempotency-Key` header; a retry returns the original result with `"idempotent_replay": true`. Reusing a key with a different body is `422 idempotency_mismatch`. |
| Concurrency | Records with a `version` (products, purchase orders, online orders) use optimistic concurrency; a stale write is `409 stale_version`. |
| Errors | `{"error": {"code", "message", "detail"}}` with 401 unauthenticated, 403 forbidden / maker_checker, 404, 409 conflict, 422 invalid. |
| Optional filters | An empty query value (`?status=`) means "no filter". |

## Integration entry points

| External system | How it connects | Notes |
|---|---|---|
| POS (tills) | `POST /pos/sales`, `POST /sales/{id}/returns` ⟳ | Completed baskets and returns. Prices reach tills via the `price.published` outbox topic; acknowledgements update `price_publications`. |
| E-commerce | `POST /online/orders` ⟳ (key mandatory), `GET /online/slots`, `POST /pricing/simulate` | Order ingestion, slot availability, basket pricing. |
| Warehouse (WMS / scanners) | `POST /procurement/purchase-orders/{id}/receipts` ⟳, `POST /distribution/tasks/{id}/complete` | Receipts and task confirmations. `adapters.base.WarehouseScanner`. |
| Transport (TMS / telematics) | `POST /distribution/stops/{id}/confirm|fail`, `adapters.base.VehicleTracking`, `ProofOfDelivery` | Live ETA is stored separately from planned arrival. |
| Payment provider | `adapters.base.PaymentProvider` (server side only) | Card data never enters this platform or the browser; only opaque references are stored. |
| HR / payroll | `POST /workforce/timesheets/import`, `POST /workforce/timesheets/export-to-hr`, `adapters.base.HrPayrollGateway` | This platform plans rotas; it does not calculate pay. |
| Supplier EDI | outbox topic `purchase_order.approved` → `adapters.base.SupplierGateway` | |
| Loyalty platform | `adapters.base.LoyaltyProgrammeGateway` | Future integration point; demo policies only. |

Outbox topics: `purchase_order.approved`, `goods_receipt.posted`, `price.published`, `sale.completed`, `sale.refunded`, `online_order.placed`, `route.dispatched`.
No endpoint, payload or credential of any real retailer is assumed anywhere.

## Auth

| Method | Path | Purpose |
|---|---|---|
| POST | `/auth/login` | Login |
| GET | `/auth/me` | Me |

## Approvals

| Method | Path | Purpose |
|---|---|---|
| GET | `/approvals` | List Approvals |
| POST | `/approvals/{approval_id}/decision` | Decide |

## Exceptions

| Method | Path | Purpose |
|---|---|---|
| GET | `/exceptions` | Exceptions |
| POST | `/exceptions/{ex_id}/resolve` | Resolve Exception |

## Administration

| Method | Path | Purpose |
|---|---|---|
| GET | `/admin/users` | Users |
| GET | `/admin/roles` | Roles |
| POST | `/admin/role-grants` | Permission changes never apply directly: they create an approval for a second administrator. |
| GET | `/admin/audit` | Audit Log |
| GET | `/admin/settings` | Settings List |
| PUT | `/admin/settings/{key}` | Settings Put |
| GET | `/admin/outbox` | Outbox |
| GET | `/admin/jobs` | Jobs |
| GET | `/admin/integrations` | The integration boundaries and what currently sits behind each one. |
| GET | `/admin/export/{dataset}` | CSV export. Every export is written to the audit log with the row count. |

## Documents

| Method | Path | Purpose |
|---|---|---|
| POST | `/documents` | Upload |
| GET | `/documents` | Documents |
| GET | `/documents/{doc_id}/download` | Download |

## Stores & hierarchy

| Method | Path | Purpose |
|---|---|---|
| GET | `/org/hierarchy` | Hierarchy |
| GET | `/org/regions` | Regions |
| GET | `/org/sites` | Site list with a 7-day operating summary. Every figure is a count or sum of stored rows. |
| POST | `/org/sites` | Create Site |
| GET | `/org/sites/{site_id}` | Site |
| PATCH | `/org/sites/{site_id}` | Patch Site |
| PATCH | `/org/formats/{format_id}` | Patch Format |

## Products

| Method | Path | Purpose |
|---|---|---|
| GET | `/catalog/products` | Products |
| POST | `/catalog/products` | Create Product |
| GET | `/catalog/products/{product_id}` | Product |
| PATCH | `/catalog/products/{product_id}` | Optimistic concurrency: the caller states the version it edited. Material changes are versioned; |
| GET | `/catalog/category-list` | Category List |
| GET | `/catalog/categories` | Categories |

## Suppliers

| Method | Path | Purpose |
|---|---|---|
| GET | `/suppliers` | Suppliers |
| GET | `/suppliers/{supplier_id}` | Supplier |
| POST | `/suppliers/{supplier_id}/status` | Set Status |
| POST | `/suppliers/{supplier_id}/qualifications` | Add Qualification |
| POST | `/suppliers/{supplier_id}/incidents` | Add Incident |

## Procurement & replenishment

| Method | Path | Purpose |
|---|---|---|
| POST | `/procurement/forecasts/run` | Run Forecast |
| GET | `/procurement/forecasts/runs` | Forecast Runs |
| GET | `/procurement/forecasts/series` | History (sold units, stock-out flags) and the latest forecast for one product (one store or all). |
| POST | `/procurement/recommendations/run` | Run Recs |
| GET | `/procurement/recommendations` | Recs |
| POST | `/procurement/recommendations/{rec_id}/decide` | Decide Rec |
| GET | `/procurement/requisitions` | Requisitions |
| POST | `/procurement/requisitions/{req_id}/convert` | Convert |
| POST | `/procurement/purchase-orders` | Create Po |
| GET | `/procurement/purchase-orders` | Pos |
| GET | `/procurement/purchase-orders/{po_id}` | Po Detail |
| POST | `/procurement/purchase-orders/{po_id}/receipts` ⟳ | Book a delivery. Safe to retry with the same Idempotency-Key; a delivery note can only be received once. |
| GET | `/procurement/appointments` | Appointments |
| GET | `/procurement/discrepancies` | Discrepancies |
| GET | `/procurement/supplier-returns` | Supplier Returns |
| POST | `/procurement/supplier-returns/{ret_id}/collect` | Supplier collects damaged goods: they leave the 'damaged' bucket. |
| GET | `/procurement/quotations` | Quotations |
| POST | `/procurement/quotations` | Add Quote |
| POST | `/procurement/quotations/{quote_id}/accept` | Accept Quote |

## Inventory & traceability

| Method | Path | Purpose |
|---|---|---|
| GET | `/inventory/stock` | Stock by site and product. on_hand = available + reserved; the other buckets are not sellable. |
| GET | `/inventory/lots` | Lots |
| GET | `/inventory/movements` | Movements |
| GET | `/inventory/integrity` | Conservation check: every balance must equal the sum of its ledger movements. |
| POST | `/inventory/adjustments` | Adjust |
| POST | `/inventory/cycle-counts` | Cycle Count |
| GET | `/inventory/cycle-counts` | Cycle Counts |
| POST | `/inventory/expiry-sweep` | Move stock past its expiry date out of 'available' into 'expired' and write off its value. |
| POST | `/inventory/site-transfers` | Direct store-to-store move of one lot (both legs in one transaction). |
| POST | `/inventory/withdrawals` | Quarantine all available stock of a product (or one lot) everywhere, block further sale, and |
| GET | `/inventory/withdrawals` | Withdrawals |
| GET | `/inventory/withdrawals/{wid}` | Withdrawal |
| GET | `/inventory/reservations` | Reservations |

## Distribution & transport

| Method | Path | Purpose |
|---|---|---|
| POST | `/distribution/allocations/run` | Allocate |
| GET | `/distribution/transfers` | Transfers |
| GET | `/distribution/transfers/{tid}` | Transfer |
| POST | `/distribution/waves` | Wave |
| GET | `/distribution/tasks` | Tasks |
| POST | `/distribution/tasks/{task_id}/complete` | Complete |
| POST | `/distribution/tasks/complete-all` | Convenience for the demo: confirm every open task of one kind at a site in full. |
| GET | `/distribution/vehicles` | Vehicles |
| POST | `/distribution/route-plans` | Plan |
| GET | `/distribution/route-plans` | Plans |
| GET | `/distribution/stops` | Stops |
| POST | `/distribution/routes/{route_id}/dispatch` | Dispatch |
| POST | `/distribution/routes/{route_id}/refresh-eta` | Refresh |
| POST | `/distribution/stops/{stop_id}/confirm` | Confirm |
| POST | `/distribution/stops/{stop_id}/fail` | Fail |

## Store sales (POS)

| Method | Path | Purpose |
|---|---|---|
| POST | `/pos/sales` ⟳ | Simulated till transaction. Integration point for a real POS: post completed baskets here with an |
| GET | `/sales` | Sales |
| GET | `/sales/{sale_id}` | Sale |
| POST | `/sales/{sale_id}/returns` ⟳ | Create Return |
| GET | `/pos/terminals` | Terminals |
| POST | `/pos/terminals/{terminal_id}/connectivity` | Simulator control: take a terminal offline/online to demonstrate unconfirmed price publications. |

## Online orders & customer service

| Method | Path | Purpose |
|---|---|---|
| POST | `/online/orders` ⟳ | Order ingestion endpoint for the e-commerce platform. Idempotency-Key is mandatory: a retry after a |
| GET | `/online/orders` | Orders |
| GET | `/online/orders/{oid}` | Order |
| POST | `/online/orders/{oid}/pick` | Pick |
| POST | `/online/orders/{oid}/dispatch` | Dispatch |
| POST | `/online/orders/{oid}/handover` ⟳ | Handover |
| POST | `/online/orders/{oid}/cancel` | Cancel |
| POST | `/online/orders/{oid}/resolve-payment` | Resolve Payment |
| POST | `/online/orders/{oid}/refunds` ⟳ | Customer-service refund. Idempotency-Key is mandatory so a double-click or retry cannot refund twice. |
| GET | `/online/slots` | Slots |
| GET | `/online/customers` | Synthetic demonstration customers. |
| GET | `/online/cases` | Cases |
| POST | `/online/cases` | Open Case |
| POST | `/online/cases/{cid}/notes` | Case Note |

## Pricing & promotions

| Method | Path | Purpose |
|---|---|---|
| GET | `/pricing/policy` | Policy |
| GET | `/pricing/price-books` | Books |
| GET | `/pricing/prices` | Prices |
| POST | `/pricing/prices` | Propose |
| POST | `/pricing/prices/{entry_id}/publish` | Publish |
| GET | `/pricing/publications` | Publication status per endpoint. 'published' is the intent; 'acknowledged' is the confirmation. |
| POST | `/pricing/publications/retry` | Retry |
| GET | `/pricing/recommendations` | Advisory only. A recommendation changes nothing until someone proposes it and another person approves it. |
| GET | `/pricing/promotions` | Promotions |
| POST | `/pricing/promotions` | Create Promo |
| GET | `/pricing/promotions/{promo_id}/conflicts` | Conflicts |
| POST | `/pricing/promotions/{promo_id}/publish` | Publish Promo |
| GET | `/pricing/coupons` | Coupons |
| POST | `/pricing/simulate` | Price a basket without selling it. Read-only; returns the full rule trace. |

## Loyalty

| Method | Path | Purpose |
|---|---|---|
| GET | `/loyalty/policy` | Policy |
| GET | `/loyalty/members` | Names and emails are masked unless the caller holds loyalty.member.read. |
| GET | `/loyalty/members/{member_id}` | Member |
| PUT | `/loyalty/members/{member_id}/preferences` | Prefs |
| POST | `/loyalty/coupons` | Issue Coupon |
| POST | `/loyalty/members/{member_id}/adjust` | Goodwill credit (positive only). Each adjustment is a ledger row tied to its audit record. |
| POST | `/loyalty/expiry/run` | Expiry |
| GET | `/loyalty/integrity` | Integrity |

## Workforce & store tasks

| Method | Path | Purpose |
|---|---|---|
| GET | `/workforce/employees` | Employees |
| GET | `/workforce/employees/{emp_id}` | Employee |
| GET | `/workforce/shifts` | Shifts |
| POST | `/workforce/shifts` | Create Shift |
| POST | `/workforce/shifts/{shift_id}/cancel` | Cancel Shift |
| GET | `/workforce/training` | Training |
| POST | `/workforce/training` | Add Training |
| GET | `/workforce/leave` | Leave |
| POST | `/workforce/leave` | Request Leave |
| POST | `/workforce/leave/{leave_id}/decision` | A person decides leave; the system only reports clashes with planned shifts. |
| POST | `/workforce/timesheets/import` | Queue a timesheet CSV (employee_no,work_date,hours) for the background worker. |
| GET | `/workforce/timesheets` | Timesheets |
| POST | `/workforce/timesheets/export-to-hr` | Hand approved hours to the HR/payroll system through its adapter. No pay is calculated here. |
| GET | `/workforce/tasks` | Tasks |
| POST | `/workforce/tasks` | Add Task |
| POST | `/workforce/tasks/{task_id}` | Update Task |
| GET | `/workforce/maintenance` | Maintenance |
| POST | `/workforce/maintenance` | Add Maintenance |
| POST | `/workforce/maintenance/{mid}` | Update Maintenance |

## Finance & reconciliation

| Method | Path | Purpose |
|---|---|---|
| GET | `/finance/trial-balance` | Trial Balance |
| GET | `/finance/journal` | Journal |
| GET | `/finance/invoices` | Invoices |
| POST | `/finance/invoices` | Register Invoice |
| POST | `/finance/invoices/{inv_id}/match` | Match |
| POST | `/finance/invoices/{inv_id}/request-payment` | Payments are never released by the person who requested them. |
| GET | `/finance/supplier-balances` | Supplier Balances |
| GET | `/finance/cash-reconciliations` | Cash Recs |
| POST | `/finance/cash-reconciliations` | Compare counted till cash with the ledger and bank it. A variance posts to cash over/short. |
| GET | `/finance/cash-reconciliations/expected` | Cash Expected |
| GET | `/finance/settlements` | Settlements |
| POST | `/finance/settlements/import` | Pull the provider's settlement report for a date and reconcile it line by line against our own |
| GET | `/finance/budget-vs-actual` | Budget and actual for the current budget period, side by side. Actuals come from the journal. |
| GET | `/finance/working-capital` | Working Capital |
| GET | `/finance/policies` | Policies |

## Executive overview & analytics

| Method | Path | Purpose |
|---|---|---|
| GET | `/executive/overview` | Overview |
| GET | `/analytics/summary` | Analytics |
| GET | `/analytics/insights` | Advisory summary of open exceptions with citations. Read-only by construction. |

## Platform

| Method | Path | Purpose |
|---|---|---|
| GET | `/health` | Health |
| GET | `/meta` | Meta |

