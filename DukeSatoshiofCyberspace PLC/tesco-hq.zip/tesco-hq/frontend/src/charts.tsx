import React, { useState } from "react";
import { fdate, gbp } from "./ui";

// Series colours validated for colour-vision deficiency (see docs/ARCHITECTURE.md): actual / budget / forecast.
// Red is reserved for exceptions and is never a series colour. Each series also differs by mark shape.
const C = { actual: "#00539F", budget: "#C26A00", forecast: "#00947F" };

type Pt = { day: string; actual: number | null; budget: number | null; forecast: number | null; note?: string };

export function Legend() {
  return (
    <div className="flex flex-wrap gap-4 text-[11px] text-ink-soft">
      <span className="flex items-center gap-1"><svg width="14" height="10"><rect x="2" y="1" width="10" height="9" rx="2" fill={C.actual} /></svg>Actual (bars)</span>
      <span className="flex items-center gap-1"><svg width="22" height="10"><line x1="0" y1="5" x2="22" y2="5" stroke={C.budget} strokeWidth="2" strokeDasharray="5 3" /></svg>Budget (dashed line)</span>
      <span className="flex items-center gap-1"><svg width="22" height="10"><line x1="0" y1="5" x2="22" y2="5" stroke={C.forecast} strokeWidth="2" /><circle cx="11" cy="5" r="3.5" fill={C.forecast} stroke="#fff" strokeWidth="1.5" /></svg>Forecast (line with markers)</span>
    </div>
  );
}

/** Net sales by day: actual, budget and forecast are three separately encoded series on one GBP axis. */
export function TrendChart({ points, height = 220 }: { points: Pt[]; height?: number }) {
  const [hover, setHover] = useState<number | null>(null);
  const [table, setTable] = useState(false);
  const W = 900, H = height, L = 52, R = 12, T = 10, B = 26;
  const max = Math.max(1, ...points.flatMap((p) => [p.actual || 0, p.budget || 0, p.forecast || 0])) * 1.1;
  const step = (W - L - R) / Math.max(1, points.length);
  const x = (i: number) => L + step * i + step / 2;
  const y = (v: number) => T + (H - T - B) * (1 - v / max);
  const path = (k: "budget" | "forecast") => points.map((p, i) => (p[k] == null ? null : `${x(i)},${y(p[k] as number)}`)).filter(Boolean).map((s, i) => (i ? "L" : "M") + s).join(" ");
  const ticks = [0, 0.25, 0.5, 0.75, 1].map((f) => f * max / 1.1);
  const h = hover !== null ? points[hover] : null;
  return (
    <div>
      <div className="mb-2 flex items-center justify-between"><Legend /><button className="text-[11px] font-semibold text-brand underline" onClick={() => setTable((t) => !t)}>{table ? "Show chart" : "Show as table"}</button></div>
      {table ? (
        <div className="max-h-64 overflow-auto"><table className="w-full text-xs"><thead><tr className="bg-brand-light text-left text-brand-dark"><th className="px-2 py-1">Day</th><th className="px-2 py-1 text-right">Actual</th><th className="px-2 py-1 text-right">Budget</th><th className="px-2 py-1 text-right">Forecast</th><th className="px-2 py-1">Note</th></tr></thead>
          <tbody>{points.map((p) => <tr key={p.day} className="border-b border-line/60"><td className="px-2 py-1">{fdate(p.day)}</td><td className="num px-2 py-1 text-right">{gbp(p.actual)}</td><td className="num px-2 py-1 text-right">{gbp(p.budget)}</td><td className="num px-2 py-1 text-right">{gbp(p.forecast)}</td><td className="px-2 py-1 text-ink-mute">{p.note || ""}</td></tr>)}</tbody></table></div>
      ) : (
        <div className="relative">
          <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label="Net sales per day: actual bars, budget dashed line, forecast line with markers. Use 'Show as table' for the values." onMouseLeave={() => setHover(null)}>
            {ticks.map((t) => (<g key={t}><line x1={L} x2={W - R} y1={y(t)} y2={y(t)} stroke="#E3E8ED" /><text x={L - 6} y={y(t) + 3} textAnchor="end" fontSize="10" fill="#7A8896">£{Math.round(t).toLocaleString("en-GB")}</text></g>))}
            {points.map((p, i) => p.actual != null && p.actual > 0 && (
              <path key={p.day} d={`M${x(i) - step * 0.3},${y(0)} V${y(p.actual) + 3} Q${x(i) - step * 0.3},${y(p.actual)} ${x(i) - step * 0.3 + 3},${y(p.actual)} H${x(i) + step * 0.3 - 3} Q${x(i) + step * 0.3},${y(p.actual)} ${x(i) + step * 0.3},${y(p.actual) + 3} V${y(0)} Z`} fill={C.actual} opacity={p.note ? 0.45 : hover === null || hover === i ? 1 : 0.6} />
            ))}
            <path d={path("budget")} fill="none" stroke={C.budget} strokeWidth="2" strokeDasharray="6 4" />
            <path d={path("forecast")} fill="none" stroke={C.forecast} strokeWidth="2" />
            {points.map((p, i) => p.forecast != null && <circle key={p.day} cx={x(i)} cy={y(p.forecast)} r="4" fill={C.forecast} stroke="#fff" strokeWidth="2" />)}
            {points.map((p, i) => (i % Math.ceil(points.length / 11) === 0 ? <text key={p.day} x={x(i)} y={H - 8} textAnchor="middle" fontSize="10" fill="#7A8896">{new Date(p.day).toLocaleDateString("en-GB", { day: "2-digit", month: "short", timeZone: "UTC" })}</text> : null))}
            {hover !== null && <line x1={x(hover)} x2={x(hover)} y1={T} y2={H - B} stroke="#4A5A6A" strokeDasharray="2 3" />}
            {points.map((p, i) => <rect key={p.day} x={L + step * i} y={T} width={step} height={H - T - B} fill="transparent" onMouseEnter={() => setHover(i)} />)}
          </svg>
          {h && (
            <div className="pointer-events-none absolute top-1 rounded-sm border border-line bg-white px-2 py-1.5 text-[11px] shadow" style={{ left: `${Math.min(78, Math.max(6, (x(hover!) / W) * 100 + 1))}%` }}>
              <div className="font-semibold text-ink">{fdate(h.day)}{h.note ? ` — ${h.note}` : ""}</div>
              <div className="num">Actual: {gbp(h.actual)}</div><div className="num">Budget: {gbp(h.budget)}</div><div className="num">Forecast: {gbp(h.forecast)}</div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/** Horizontal bars for comparing one measure across a handful of named items (direct-labelled; no legend needed). */
export function BarList({ rows, labelKey, valueKey, fmt = gbp, refKey, refLabel }: { rows: any[]; labelKey: string; valueKey: string; fmt?: (v: any) => string; refKey?: string; refLabel?: string }) {
  const max = Math.max(1, ...rows.flatMap((r) => [Number(r[valueKey]) || 0, refKey ? Number(r[refKey]) || 0 : 0]));
  return (
    <div className="space-y-1.5" role="list">
      {rows.map((r) => (
        <div key={r[labelKey]} role="listitem" className="grid grid-cols-[11rem_1fr_auto] items-center gap-2 text-xs" title={`${r[labelKey]}: ${fmt(r[valueKey])}${refKey ? ` (${refLabel} ${fmt(r[refKey])})` : ""}`}>
          <span className="truncate text-ink-soft">{r[labelKey]}</span>
          <div className="relative h-4 rounded-sm bg-gray-100">
            <div className="h-4 rounded-r-[4px] bg-series-actual" style={{ width: `${(100 * (Number(r[valueKey]) || 0)) / max}%` }} />
            {refKey && <div className="absolute top-[-2px] h-5 w-0.5 bg-series-budget" style={{ left: `${(100 * (Number(r[refKey]) || 0)) / max}%` }} aria-hidden />}
          </div>
          <span className="num w-40 text-right">{fmt(r[valueKey])}{refKey && <span className="text-ink-mute"> / {fmt(r[refKey])}</span>}</span>
        </div>
      ))}
      {refKey && <p className="pt-1 text-[11px] text-ink-mute"><span className="mr-1 inline-block h-3 w-0.5 bg-series-budget align-middle" />marker = {refLabel}; figures show actual / {refLabel}</p>}
    </div>
  );
}

export function LineSeries({ history, forecast, height = 180 }: { history: { day: string; v: number; flag?: boolean }[]; forecast: { day: string; v: number }[]; height?: number }) {
  const all = [...history, ...forecast];
  const W = 900, H = height, L = 40, R = 10, T = 10, B = 22;
  const max = Math.max(1, ...all.map((p) => p.v)) * 1.1;
  const x = (i: number) => L + ((W - L - R) * i) / Math.max(1, all.length - 1);
  const y = (v: number) => T + (H - T - B) * (1 - v / max);
  const d = (pts: { v: number }[], off: number) => pts.map((p, i) => `${i ? "L" : "M"}${x(i + off)},${y(p.v)}`).join(" ");
  return (
    <div>
      <div className="mb-1 flex flex-wrap gap-4 text-[11px] text-ink-soft">
        <span className="flex items-center gap-1"><svg width="22" height="8"><line x1="0" y1="4" x2="22" y2="4" stroke={C.actual} strokeWidth="2" /></svg>Units sold</span>
        <span className="flex items-center gap-1"><svg width="22" height="10"><line x1="0" y1="5" x2="22" y2="5" stroke={C.forecast} strokeWidth="2" /><circle cx="11" cy="5" r="3.5" fill={C.forecast} stroke="#fff" strokeWidth="1.5" /></svg>Forecast</span>
        <span className="flex items-center gap-1"><svg width="12" height="12"><path d="M6 1 L11 11 L1 11 Z" fill="#EE1C2E" /></svg>Stock-out day (sales understate demand)</span>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label="Units sold per day and forecast">
        {[0, 0.5, 1].map((f) => <g key={f}><line x1={L} x2={W - R} y1={y((max / 1.1) * f)} y2={y((max / 1.1) * f)} stroke="#E3E8ED" /><text x={L - 5} y={y((max / 1.1) * f) + 3} textAnchor="end" fontSize="10" fill="#7A8896">{Math.round((max / 1.1) * f)}</text></g>)}
        <path d={d(history, 0)} fill="none" stroke={C.actual} strokeWidth="2" />
        <path d={d(forecast, history.length)} fill="none" stroke={C.forecast} strokeWidth="2" />
        {forecast.map((p, i) => <circle key={p.day} cx={x(i + history.length)} cy={y(p.v)} r="3.5" fill={C.forecast} stroke="#fff" strokeWidth="1.5"><title>{`${fdate(p.day)} forecast ${p.v.toFixed(1)}`}</title></circle>)}
        {history.map((p, i) => p.flag ? <path key={p.day} d={`M${x(i)},${y(p.v) - 12} l5,9 h-10 Z`} fill="#EE1C2E"><title>{`${fdate(p.day)}: stock-out, sold ${p.v}`}</title></path> : <circle key={p.day} cx={x(i)} cy={y(p.v)} r="6" fill="transparent"><title>{`${fdate(p.day)}: sold ${p.v}`}</title></circle>)}
        {all.map((p, i) => (i % 7 === 0 ? <text key={p.day} x={x(i)} y={H - 6} textAnchor="middle" fontSize="10" fill="#7A8896">{new Date(p.day).toLocaleDateString("en-GB", { day: "2-digit", month: "short", timeZone: "UTC" })}</text> : null))}
        <line x1={x(history.length - 0.5)} x2={x(history.length - 0.5)} y1={T} y2={H - B} stroke="#7A8896" strokeDasharray="3 3" />
      </svg>
    </div>
  );
}
