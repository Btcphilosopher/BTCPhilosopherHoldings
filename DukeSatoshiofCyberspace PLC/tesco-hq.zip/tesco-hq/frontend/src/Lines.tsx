import React, { useEffect, useState } from "react";
import { newKey, options } from "./api";
import { useAuth } from "./auth";
import { Button, Field, Modal, Notice, useToast } from "./ui";

type LineCol = { name: string; label: string; type?: "number" | "select" | "text"; options?: { value: any; label: string }[]; default?: (line: any) => any; width?: string };

/** A dialog for documents with lines (receipts, picks, invoices, refunds): one row per source line with editable columns. */
export function LinesButton({ label, perm, title, load, lineLabel, cols, extra = [], submit, onDone, show = true, kind = "ghost", intro, done }: {
  label: string; perm?: string[]; title: string; load: () => Promise<any[]>; lineLabel: (l: any) => React.ReactNode; cols: LineCol[]; extra?: Field[];
  submit: (lines: { line: any; v: any }[], extra: any, key: string) => Promise<any>; onDone?: () => void; show?: boolean; kind?: "ghost" | "primary" | "secondary"; intro?: React.ReactNode; done?: (r: any) => string;
}) {
  const { can } = useAuth();
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const [lines, setLines] = useState<{ line: any; v: any }[] | null>(null);
  const [ex, setEx] = useState<any>({});
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [key, setKey] = useState("");
  useEffect(() => {
    if (!open) return;
    setLines(null); setErr(null); setKey(newKey());
    setEx(Object.fromEntries(extra.filter((f) => f.default !== undefined).map((f) => [f.name, f.default])));
    load().then((ls) => setLines(ls.map((line) => ({ line, v: Object.fromEntries(cols.map((c) => [c.name, c.default ? c.default(line) : ""])) })))).catch((e) => setErr(e.message));
  }, [open]);
  if (!show || (perm && !can(...perm))) return null;
  const set = (i: number, name: string, val: any) => setLines((ls) => ls!.map((l, j) => (j === i ? { ...l, v: { ...l.v, [name]: val } } : l)));
  return (
    <>
      <Button kind={kind} className={kind === "ghost" ? "!px-1.5 !py-0.5" : ""} onClick={() => setOpen(true)}>{label}</Button>
      {open && (
        <Modal title={title} onClose={() => setOpen(false)} wide>
          <form className="space-y-3" onSubmit={async (e) => {
            e.preventDefault(); setBusy(true); setErr(null);
            try { const r = await submit(lines || [], ex, key); toast("good", (done ? done(r) : `${label}: done`) + (r?.idempotent_replay ? " (already processed - no duplicate created)" : "")); setOpen(false); onDone?.(); }
            catch (x: any) { setErr(x.message); } finally { setBusy(false); }
          }}>
            {intro && <div className="text-xs text-ink-soft">{intro}</div>}
            {extra.length > 0 && (
              <div className="grid grid-cols-2 gap-3">
                {extra.map((f) => (
                  <label key={f.name} className="block text-[11px] font-semibold text-ink-soft">{f.label}{f.required && <span className="text-action"> *</span>}
                    {f.type === "select" && Array.isArray(f.options) ? (
                      <select className="mt-1 w-full rounded-sm border border-line px-2 py-1.5 text-xs font-normal" value={ex[f.name] ?? ""} required={f.required} onChange={(e) => setEx((o: any) => ({ ...o, [f.name]: e.target.value }))}>
                        <option value="">— select —</option>{f.options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                      </select>
                    ) : f.type === "checkbox" ? <input type="checkbox" className="ml-2" checked={!!ex[f.name]} onChange={(e) => setEx((o: any) => ({ ...o, [f.name]: e.target.checked }))} />
                      : <input className="mt-1 w-full rounded-sm border border-line px-2 py-1.5 text-xs font-normal" type={f.type === "datetime" ? "datetime-local" : f.type || "text"} step="any" required={f.required} value={ex[f.name] ?? ""} onChange={(e) => setEx((o: any) => ({ ...o, [f.name]: e.target.value }))} />}
                    {f.help && <span className="mt-0.5 block font-normal text-ink-mute">{f.help}</span>}
                  </label>
                ))}
              </div>
            )}
            {!lines && !err && <p className="text-xs text-ink-mute">Loading lines…</p>}
            {lines && (
              <table className="w-full text-xs">
                <thead><tr className="bg-brand-light text-left text-brand-dark"><th className="px-2 py-1.5">Line</th>{cols.map((c) => <th key={c.name} className="px-2 py-1.5" style={{ width: c.width || "7rem" }}>{c.label}</th>)}</tr></thead>
                <tbody>
                  {lines.map((l, i) => (
                    <tr key={i} className="border-b border-line/60">
                      <td className="px-2 py-1.5">{lineLabel(l.line)}</td>
                      {cols.map((c) => (
                        <td key={c.name} className="px-2 py-1">
                          {c.type === "select" ? (
                            <select aria-label={c.label} className="w-full rounded-sm border border-line px-1 py-1" value={l.v[c.name] ?? ""} onChange={(e) => set(i, c.name, e.target.value)}>
                              <option value="">—</option>{(c.options || []).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                            </select>
                          ) : <input aria-label={c.label} className="num w-full rounded-sm border border-line px-1 py-1 text-right" type={c.type === "text" ? "text" : "number"} step="any" min="0" value={l.v[c.name] ?? ""} onChange={(e) => set(i, c.name, e.target.value)} />}
                        </td>
                      ))}
                    </tr>
                  ))}
                  {!lines.length && <tr><td className="px-2 py-4 text-center text-ink-mute" colSpan={cols.length + 1}>No lines</td></tr>}
                </tbody>
              </table>
            )}
            {err && <Notice tone="bad">{err}</Notice>}
            <div className="flex justify-end gap-2"><Button type="button" kind="ghost" onClick={() => setOpen(false)}>Cancel</Button><Button type="submit" kind="primary" disabled={busy || !lines}>{busy ? "Working…" : label}</Button></div>
          </form>
        </Modal>
      )}
    </>
  );
}

/** Basket editor used by the price simulator, the simulated till and online order entry. */
export function Basket({ value, onChange, withSub }: { value: any[]; onChange: (v: any[]) => void; withSub?: boolean }) {
  const [prods, setProds] = useState<any[]>([]);
  useEffect(() => { options("/catalog/products").then(setProds); }, []);
  const set = (i: number, k: string, v: any) => onChange(value.map((l, j) => (j === i ? { ...l, [k]: v } : l)));
  return (
    <div className="space-y-1">
      {value.map((l, i) => (
        <div key={i} className="flex items-center gap-1">
          <select aria-label="Product" className="min-w-0 flex-1 rounded-sm border border-line bg-white px-1 py-1 text-xs" value={l.sku} onChange={(e) => set(i, "sku", e.target.value)}>
            <option value="">— product —</option>{prods.filter((p) => p.status === "active").map((p) => <option key={p.sku} value={p.sku}>{p.sku} — {p.name}{p.is_weighted ? " (kg)" : ""}</option>)}
          </select>
          <input aria-label="Quantity" type="number" step="any" min="0" className="num w-16 rounded-sm border border-line px-1 py-1 text-right text-xs" value={l.qty} onChange={(e) => set(i, "qty", e.target.value)} />
          {withSub && <label className="flex items-center gap-1 whitespace-nowrap text-[11px] text-ink-soft"><input type="checkbox" checked={l.allow_substitution !== false} onChange={(e) => set(i, "allow_substitution", e.target.checked)} />subs OK</label>}
          <button type="button" aria-label="Remove line" className="px-1 text-ink-mute hover:text-action" onClick={() => onChange(value.filter((_, j) => j !== i))}>×</button>
        </div>
      ))}
      <Button type="button" kind="ghost" onClick={() => onChange([...value, { sku: "", qty: 1 }])}>+ Add line</Button>
    </div>
  );
}
export const cleanBasket = (lines: any[]) => lines.filter((l) => l.sku && Number(l.qty) > 0).map((l) => ({ ...l, qty: String(l.qty) }));
