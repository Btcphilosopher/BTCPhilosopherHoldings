import React, { createContext, useContext, useEffect, useState } from "react";
import { api, clearOptions, token } from "./api";

type Me = { user: { id: number; name: string; email: string; job_title: string }; roles: any[]; permissions: string[]; scopes: Record<string, number[] | null> };
type Ctx = { me: Me | null; loading: boolean; signIn: (e: string, p: string) => Promise<void>; signOut: () => void; can: (...perms: string[]) => boolean };
const AuthCtx = createContext<Ctx>(null as any);
export const useAuth = () => useContext(AuthCtx);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [me, setMe] = useState<Me | null>(null);
  const [loading, setLoading] = useState(!!token.get());
  useEffect(() => {
    if (token.get()) api("/auth/me").then(setMe).catch(() => token.set(null)).finally(() => setLoading(false));
    const out = () => setMe(null);
    window.addEventListener("thq:signout", out);
    return () => window.removeEventListener("thq:signout", out);
  }, []);
  const signIn = async (email: string, password: string) => {
    const r = await api("/auth/login", { body: { email, password } });
    token.set(r.token);
    clearOptions();
    setMe(r);
  };
  const signOut = () => {
    token.set(null);
    clearOptions();
    setMe(null);
  };
  const can = (...perms: string[]) => !!me && perms.some((p) => me.permissions.includes(p));
  return <AuthCtx.Provider value={{ me, loading, signIn, signOut, can }}>{children}</AuthCtx.Provider>;
}
