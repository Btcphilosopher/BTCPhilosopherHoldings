import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { api, options } from "./api";

// ---------------------------------------------------------------- formatting
export const gbp = (v: any, dp = 2) =>
  v === null || v === undefined || v === "" || isNaN(Number(v)) ? "—" : "£" + Number(v).toLocaleString("en-GB", { minimumFractionDigits: dp, maximumFractionDigits: dp });
export const num = (v: any, dp?: number) =>
  v === null || v === undefined || v === "" || isNaN(Number(v)) ? "—" : Number(v).toLocaleString("en-GB", dp === undefined ? { maximumFractionDigits: 3 } : { minimumFractionDigits: dp, maximumFractionDigits: dp });
export const pct = (v: any) => (v === null || v === undefined || v === "" ? "—" : `${Number(v).toFixed(1)}%`);
export const fdate = (v: any) => (v ? new Date(v).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric", timeZone: "UTC" }) : "—");
export const fdatetime = (v: any) =>
  v ? new Date(v).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", timeZone: "UTC" }) : "—";
export const ftime = (v: any) => (v ? new Date(v).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", timeZone: "UTC" }) : "—");
export const label = (s: string) => String(s).replace(/_/g, " ").replace(/^\w/, (c) => c.toUpperCase());

// ---------------------------------------------------------------- status labels (one vocabulary everywhere)
const TONES: Record<string, string> = {
  good: "bg-green-50 text-ok border-green-200", bad: "bg-action-light text-action-dark border-red-200",
  warn: "bg-amber-50 text-warn border-amber-200", info: "bg-brand-light text-brand border-blue-200", mute: "bg-gray-100 text-ink-soft border-gray-200",
};
const TONE_OF: Record<string, string> = {};
const reg = (tone: string, words: string) => words.split(" ").forEach((w) => (TONE_OF[w] = tone));
reg("good", "approved published acknowledged received delivered collected completed matched paid reconciled succeeded balanced active trading valid posted done captured authorised confirmed accepted live resolved yes true eligible ok in_stock available closed converted ordered consumed");
reg("bad", "rejected failed exception late overdue expired suspended cancelled declined high urgent uncertain variance withdrawn damaged short refunded missed voided false no error mismatch quarantined");
reg("warn", "pending pending_approval part_received part_refunded expiring medium requested open sent substituted recommended overridden en_route planned picking draft queued running onboarding ask unallocated placed staged simulator");
reg("info", "reserved picked packed dispatched in_transit out_for_delivery ready_for_collection booked released assigned low normal store online dc till ecommerce self_checkout");
export function Badge({ value, tone }: { value: any; tone?: string }) {
  if (value === null || value === undefined || value === "") return <span className="text-ink-mute">—</span>;
  const key = String(value).toLowerCase();
  return <span className={`inline-block whitespace-nowrap rounded-sm border px-1.5 py-px text-[11px] font-medium ${TONES[tone || TONE_OF[key] || "mute"]}`}>{label(String(value))}</span>;
}

// ---------------------------------------------------------------- primitives
export function Button({ kind = "secondary", className = "", ...p }: React.ButtonHTMLAttributes<HTMLButtonElement> & { kind?: "primary" | "secondary" | "ghost" | "danger" }) {
  const k = {
    primary: "bg-action text-white hover:bg-action-dark border-action", danger: "bg-white text-action-dark border-action hover:bg-action-light",
    secondary: "bg-white text-brand border-brand hover:bg-brand-light", ghost: "bg-transparent text-brand border-transparent hover:bg-brand-light",
  }[kind];
  return <button {...p} className={`inline-flex items-center gap-1 rounded-sm border px-2.5 py-1 text-xs font-semibold disabled:cursor-not-allowed disabled:opacity-50 ${k} ${className}`} />;
}
export function Card({ title, right, children, className = "", pad = true }: { title?: React.ReactNode; right?: React.ReactNode; children: React.ReactNode; className?: string; pad?: boolean }) {
  return (
    <section className={`rounded-sm border border-line bg-white ${className}`}>
      {(title || right) && (
        <header className="flex items-center justify-between gap-2 border-b border-line px-3 py-2">
          <h3 className="text-[13px] font-semibold text-brand-dark">{title}</h3>
          <div className="flex items-center gap-2">{right}</div>
        </header>
      )}
      <div className={pad ? "p-3" : ""}>{children}</div>
    </section>
  );
}
export function Notice({ tone = "info", children }: { tone?: "info" | "warn" | "bad" | "good"; children: React.ReactNode }) {
  return <div className={`rounded-sm border px-3 py-2 text-xs ${TONES[tone]}`}>{children}</div>;
}
export function Empty({ children }: { children: React.ReactNode }) {
  return <div className="px-3 py-8 text-center text-xs text-ink-mute">{children}</div>;
}

// ---------------------------------------------------------------- toasts
type Toast = { id: number; tone: "good" | "bad" | "info"; text: string };
const ToastCtx = createContext<(tone: Toast["tone"], text: string) => void>(() => {});
export const useToast = () => useContext(ToastCtx);
export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<Toast[]>([]);
  const push = useCallback((tone: Toast["tone"], text: string) => {
    const id = Date.now() + Math.random();
    setItems((x) => [...x, { id, tone, text }]);
    setTimeout(() => setItems((x) => x.filter((t) => t.id !== id)), tone === "bad" ? 9000 : 4500);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="fixed bottom-4 right-4 z-[60] flex w-96 flex-col gap-2" role="status" aria-live="polite">
        {items.map((t) => (
          <div key={t.id} className={`rounded-sm border bg-white px-3 py-2 text-xs shadow-lg ${t.tone === "bad" ? "border-l-4 border-l-action" : t.tone === "good" ? "border-l-4 border-l-ok" : "border-l-4 border-l-brand"}`}>
            {t.text}
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

// ---------------------------------------------------------------- overlays
export function Modal({ title, onClose, children, wide }: { title: string; onClose: () => void; children: React.ReactNode; wide?: boolean }) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-auto bg-brand-deep/40 p-6" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div role="dialog" aria-modal="true" aria-label={title} className={`mt-10 w-full ${wide ? "max-w-3xl" : "max-w-lg"} rounded-sm border border-line bg-white shadow-xl`}>
        <header className="flex items-center justify-between border-b border-line bg-brand px-4 py-2 text-white">
          <h2 className="text-sm font-semibold">{title}</h2>
          <button onClick={onClose} aria-label="Close" className="px-1 text-lg leading-none">×</button>
        </header>
        <div className="p-4">{children}</div>
      </div>
    </div>
  );
}
export function Drawer({ title, onClose, children }: { title: React.ReactNode; onClose: () => void; children: React.ReactNode }) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-40 flex justify-end bg-brand-deep/30" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <aside role="dialog" aria-modal="true" className="flex h-full w-full max-w-4xl flex-col border-l border-line bg-surface shadow-2xl">
        <header className="flex items-center justify-between bg-brand-dark px-4 py-2.5 text-white">
          <h2 className="text-sm font-semibold">{title}</h2>
          <button onClick={onClose} aria-label="Close" className="px-1 text-lg leading-none">×</button>
        </header>
        <div className="scroll-thin flex-1 space-y-3 overflow-auto p-4">{children}</div>
      </aside>
    </div>
  );
}
export function Tabs({ tabs, value, onChange }: { tabs: { key: string; label: string; count?: number }[]; value: string; onChange: (k: string) => void }) {
  return (
    <div role="tablist" className="flex flex-wrap gap-0 border-b border-line">
      {tabs.map((t) => (
        <button key={t.key} role="tab" aria-selected={value === t.key} onClick={() => onChange(t.key)}
          className={`-mb-px border-b-2 px-3 py-2 text-xs font-semibold ${value === t.key ? "border-action text-brand-dark" : "border-transparent text-ink-soft hover:text-brand"}`}>
          {t.label}
          {t.count !== undefined && <span className="num ml-1.5 rounded-sm bg-gray-100 px-1 text-[10px] text-ink-soft">{t.count}</span>}
        </button>
      ))}
    </div>
  );
}

// ---------------------------------------------------------------- data hook
export function useData<T = any>(path: string | null, deps: any[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [tick, setTick] = useState(0);
  useEffect(() => {
    if (!path) return;
    let live = true;
    setLoading(true);
    api<T>(path).then((d) => live && (setData(d), setError(null))).catch((e) => live && setError(e.message)).finally(() => live && setLoading(false));
    return () => { live = false; };
  }, [path, tick, ...deps]);
  return { data, error, loading, reload: () => setTick((t) => t + 1) };
}

// ---------------------------------------------------------------- table
export type Col = { key: string; label?: string; fmt?: "money" | "num" | "int" | "pct" | "date" | "datetime" | "time" | "status" | "bool" | "json" | "cost"; render?: (row: any) => React.ReactNode; align?: "right"; width?: string; tone?: (row: any) => string | undefined };
export function cell(c: Col, row: any): React.ReactNode {
  if (c.render) return c.render(row);
  const v = row[c.key];
  switch (c.fmt) {
    case "money": return gbp(v);
    case "cost": return gbp(v, 4);
    case "num": return num(v);
    case "int": return num(v, 0);
    case "pct": return pct(v);
    case "date": return fdate(v);
    case "datetime": return fdatetime(v);
    case "time": return ftime(v);
    case "status": return <Badge value={v} tone={c.tone?.(row)} />;
    case "bool": return <Badge value={v ? "yes" : "no"} tone={c.tone?.(row)} />;
    case "json": return v ? <span className="text-ink-soft">{typeof v === "string" ? v : JSON.stringify(v)}</span> : "—";
    default: return v === null || v === undefined || v === "" ? <span className="text-ink-mute">—</span> : String(v);
  }
}
const NUMERIC = new Set(["money", "num", "int", "pct", "cost"]);
export function DataTable({ rows, cols, onRow, actions, empty = "No records", search = true, max = 480, toolbar, caption }: {
  rows: any[]; cols: Col[]; onRow?: (row: any) => void; actions?: (row: any) => React.ReactNode; empty?: string; search?: boolean; max?: number; toolbar?: React.ReactNode; caption?: string;
}) {
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<{ key: string; dir: 1 | -1 } | null>(null);
  const [limit, setLimit] = useState(100);
  const view = useMemo(() => {
    let r = rows;
    if (q.trim()) {
      const needle = q.toLowerCase();
      r = r.filter((row) => cols.some((c) => String(row[c.key] ?? "").toLowerCase().includes(needle)));
    }
    if (sort) {
      const c = cols.find((x) => x.key === sort.key);
      const n = c && NUMERIC.has(c.fmt || "");
      r = [...r].sort((a, b) => {
        const x = a[sort.key], y = b[sort.key];
        if (x == null) return 1;
        if (y == null) return -1;
        return (n ? Number(x) - Number(y) : String(x).localeCompare(String(y), undefined, { numeric: true })) * sort.dir;
      });
    }
    return r;
  }, [rows, q, sort, cols]);
  return (
    <div>
      {(search || toolbar) && (
        <div className="flex flex-wrap items-center gap-2 border-b border-line bg-gray-50 px-3 py-1.5">
          {search && <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search this table…" aria-label="Search table" className="w-56 rounded-sm border border-line bg-white px-2 py-1 text-xs" />}
          <span className="num text-[11px] text-ink-mute">{view.length === rows.length ? `${rows.length} rows` : `${view.length} of ${rows.length} rows`}</span>
          <div className="ml-auto flex flex-wrap items-center gap-2">{toolbar}</div>
        </div>
      )}
      <div className="scroll-thin overflow-auto" style={{ maxHeight: max }}>
        <table className="w-full text-xs">
          {caption && <caption className="sr-only">{caption}</caption>}
          <thead className="sticky top-0 z-10">
            <tr>
              {cols.map((c) => (
                <th key={c.key} scope="col" style={{ width: c.width }} aria-sort={sort?.key === c.key ? (sort.dir === 1 ? "ascending" : "descending") : undefined}
                  className={`cursor-pointer select-none whitespace-nowrap border-b border-line bg-brand-light px-2 py-1.5 font-semibold text-brand-dark ${c.align === "right" || NUMERIC.has(c.fmt || "") ? "text-right" : "text-left"}`}
                  onClick={() => setSort((s) => (s?.key === c.key ? (s.dir === 1 ? { key: c.key, dir: -1 } : null) : { key: c.key, dir: 1 }))}>
                  {c.label ?? label(c.key)}{sort?.key === c.key ? (sort.dir === 1 ? " ▲" : " ▼") : ""}
                </th>
              ))}
              {actions && <th className="border-b border-line bg-brand-light px-2 py-1.5 text-right font-semibold text-brand-dark">Actions</th>}
            </tr>
          </thead>
          <tbody>
            {view.slice(0, limit).map((row, i) => (
              <tr key={row.id ?? i} className={`${i % 2 ? "bg-gray-50/60" : "bg-white"} ${onRow ? "cursor-pointer hover:bg-brand-light/60" : ""}`}
                onClick={onRow ? () => onRow(row) : undefined} tabIndex={onRow ? 0 : undefined} onKeyDown={onRow ? (e) => e.key === "Enter" && onRow(row) : undefined}>
                {cols.map((c) => (
                  <td key={c.key} className={`border-b border-line/60 px-2 py-1 align-top ${c.align === "right" || NUMERIC.has(c.fmt || "") ? "num text-right" : ""}`}>{cell(c, row)}</td>
                ))}
                {actions && <td className="whitespace-nowrap border-b border-line/60 px-2 py-0.5 text-right" onClick={(e) => e.stopPropagation()}><div className="flex justify-end gap-1">{actions(row)}</div></td>}
              </tr>
            ))}
          </tbody>
        </table>
        {!view.length && <Empty>{empty}</Empty>}
        {view.length > limit && <div className="p-2 text-center"><Button kind="ghost" onClick={() => setLimit((l) => l + 200)}>Show more ({view.length - limit} remaining)</Button></div>}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- forms
export type Field = {
  name: string; label?: string; type?: "text" | "number" | "select" | "date" | "datetime" | "textarea" | "checkbox" | "time";
  options?: { value: any; label: string }[] | { endpoint: string; value?: string; label?: (o: any) => string; filter?: (o: any) => boolean };
  required?: boolean; default?: any; help?: string; step?: string;
};
function FieldInput({ f, value, onChange }: { f: Field; value: any; onChange: (v: any) => void }) {
  const [opts, setOpts] = useState<{ value: any; label: string }[]>(Array.isArray(f.options) ? f.options : []);
  useEffect(() => {
    if (f.options && !Array.isArray(f.options)) {
      const o = f.options;
      options(o.endpoint).then((list) => setOpts(list.filter(o.filter || (() => true)).map((x) => ({ value: x[o.value || "id"], label: o.label ? o.label(x) : x.name }))));
    }
  }, [f.options]);
  const cls = "w-full rounded-sm border border-line bg-white px-2 py-1.5 text-xs";
  if (f.type === "select") return (
    <select className={cls} value={value ?? ""} required={f.required} onChange={(e) => onChange(e.target.value === "" ? null : isNaN(Number(e.target.value)) ? e.target.value : Number(e.target.value))}>
      <option value="">— select —</option>
      {opts.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  );
  if (f.type === "textarea") return <textarea className={cls} rows={3} value={value ?? ""} required={f.required} onChange={(e) => onChange(e.target.value)} />;
  if (f.type === "checkbox") return <input type="checkbox" checked={!!value} onChange={(e) => onChange(e.target.checked)} />;
  return <input className={cls} type={f.type === "datetime" ? "datetime-local" : f.type || "text"} step={f.step || (f.type === "number" ? "any" : undefined)} value={value ?? ""} required={f.required}
    onChange={(e) => onChange(f.type === "number" ? (e.target.value === "" ? null : Number(e.target.value)) : e.target.value)} />;
}
export function Form({ fields, submit, onSubmit, onCancel, intro, danger }: { fields: Field[]; submit: string; onSubmit: (v: any) => Promise<void>; onCancel?: () => void; intro?: React.ReactNode; danger?: boolean }) {
  const [v, setV] = useState<any>(() => Object.fromEntries(fields.filter((f) => f.default !== undefined).map((f) => [f.name, f.default])));
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  return (
    <form className="space-y-3" onSubmit={async (e) => {
      e.preventDefault();
      setBusy(true); setErr(null);
      try { await onSubmit(v); } catch (x: any) { setErr(x.message); } finally { setBusy(false); }
    }}>
      {intro && <div className="text-xs text-ink-soft">{intro}</div>}
      {fields.map((f) => (
        <label key={f.name} className="block">
          <span className="mb-1 block text-[11px] font-semibold text-ink-soft">{f.label ?? label(f.name)}{f.required && <span className="text-action"> *</span>}</span>
          <FieldInput f={f} value={v[f.name]} onChange={(x) => setV((o: any) => ({ ...o, [f.name]: x }))} />
          {f.help && <span className="mt-0.5 block text-[11px] text-ink-mute">{f.help}</span>}
        </label>
      ))}
      {err && <Notice tone="bad">{err}</Notice>}
      <div className="flex justify-end gap-2 pt-1">
        {onCancel && <Button type="button" kind="ghost" onClick={onCancel}>Cancel</Button>}
        <Button type="submit" kind={danger ? "danger" : "primary"} disabled={busy}>{busy ? "Working…" : submit}</Button>
      </div>
    </form>
  );
}

// ---------------------------------------------------------------- generic record view (drill-down)
const isScalar = (v: any) => v === null || ["string", "number", "boolean"].includes(typeof v);
const guess = (k: string, v: any): React.ReactNode => {
  if (v === null || v === undefined || v === "") return <span className="text-ink-mute">—</span>;
  if (typeof v === "boolean") return <Badge value={v ? "yes" : "no"} />;
  if (/status$|^kind$|severity|^bucket$|^basis$/.test(k)) return <Badge value={v} />;
  if (/(_at|^at)$/.test(k) && typeof v === "string") return fdatetime(v);
  if (/(date|_on|^day)$/.test(k) && typeof v === "string") return fdate(v);
  if (typeof v === "string" && /^-?\d+\.\d{2}$/.test(v) && /gross|net|tax|amount|cost|price|debit|credit|value|total|discount|payable|paid|fees|expected|counted|variance|budget|actual|refund/.test(k)) return <span className="num">{gbp(v)}</span>;
  if (typeof v === "string" && /^-?\d+\.\d+$/.test(v)) return <span className="num">{num(v)}</span>;
  return String(v);
};
export function Record({ data, hide = [] }: { data: any; hide?: string[] }) {
  if (!data) return null;
  const entries = Object.entries(data).filter(([k]) => !hide.includes(k));
  const scalars = entries.filter(([, v]) => isScalar(v));
  const lists = entries.filter(([, v]) => Array.isArray(v));
  const objs = entries.filter(([, v]) => v && typeof v === "object" && !Array.isArray(v));
  return (
    <div className="space-y-3">
      <Card pad={false}>
        <dl className="grid grid-cols-2 gap-x-6 md:grid-cols-3">
          {scalars.map(([k, v]) => (
            <div key={k} className="flex justify-between gap-3 border-b border-line/60 px-3 py-1.5">
              <dt className="text-[11px] font-semibold text-ink-soft">{label(k)}</dt>
              <dd className="text-right text-xs">{guess(k, v)}</dd>
            </div>
          ))}
        </dl>
      </Card>
      {objs.map(([k, v]) => <Card key={k} title={label(k)}><Tree value={v} /></Card>)}
      {lists.map(([k, v]) => (
        <Card key={k} title={`${label(k)} (${(v as any[]).length})`} pad={false}>
          {(v as any[]).length && typeof (v as any[])[0] === "object" ? (
            <DataTable search={false} max={300} rows={v as any[]} cols={Object.keys((v as any[])[0]).filter((c) => !/_id$|^id$/.test(c) || c === "ref_id").slice(0, 12).map((c) => ({ key: c, render: (r: any) => (isScalar(r[c]) ? guess(c, r[c]) : <span className="text-[11px] text-ink-soft">{JSON.stringify(r[c])}</span>) }))} />
          ) : (v as any[]).length ? <ul className="list-disc px-6 py-2 text-xs">{(v as any[]).map((x, i) => <li key={i}>{String(x)}</li>)}</ul> : <Empty>None</Empty>}
        </Card>
      ))}
    </div>
  );
}
export function Tree({ value }: { value: any }) {
  if (isScalar(value)) return <span className="text-xs">{String(value ?? "—")}</span>;
  if (Array.isArray(value)) return <ul className="ml-4 list-disc space-y-0.5 text-xs">{value.map((v, i) => <li key={i}><Tree value={v} /></li>)}</ul>;
  return (
    <dl className="space-y-1 text-xs">
      {Object.entries(value).map(([k, v]) => (
        <div key={k} className="flex gap-2"><dt className="min-w-[10rem] font-semibold text-ink-soft">{label(k)}</dt><dd className="flex-1"><Tree value={v} /></dd></div>
      ))}
    </dl>
  );
}
