import React, { useState } from "react";
import { api, newKey } from "./api";
import { useAuth } from "./auth";
import { Button, Card, Col, DataTable, Drawer, Field, Form, Modal, Notice, Record, Tabs, useData, useToast } from "./ui";

export type Action = {
  label: string; perm?: string | string[]; fields?: Field[] | ((row: any) => Field[]); intro?: React.ReactNode | ((row: any) => React.ReactNode);
  run: (values: any, row: any, key: string) => Promise<any>; show?: (row: any) => boolean; kind?: "primary" | "secondary" | "danger";
  done?: (result: any) => string; confirm?: string | ((row: any) => string);
};
export const post = (path: string, body: any = {}, key?: string) => api(path, { method: "POST", body, key });

/** A button that performs one API action, with a form or confirmation where needed. Hidden without permission. */
export function ActionButton({ action, row, onDone, small }: { action: Action; row?: any; onDone?: () => void; small?: boolean }) {
  const { can } = useAuth();
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const [key, setKey] = useState("");
  const perms = action.perm ? (Array.isArray(action.perm) ? action.perm : [action.perm]) : [];
  if (perms.length && !can(...perms)) return null;
  if (row && action.show && !action.show(row)) return null;
  const fields = typeof action.fields === "function" ? action.fields(row) : action.fields || [];
  const intro = typeof action.intro === "function" ? action.intro(row) : action.intro;
  const confirm = typeof action.confirm === "function" ? action.confirm(row) : action.confirm;
  const exec = async (values: any, k: string) => {
    const res = await action.run(values, row, k);   // the same Idempotency-Key is reused if the user retries this dialog
    toast("good", action.done ? action.done(res) : `${action.label}: done` + (res?.idempotent_replay ? " (already processed - no duplicate created)" : ""));
    setOpen(false);
    onDone?.();
  };
  const start = () => {
    const k = newKey();
    setKey(k);
    if (fields.length || confirm || intro) setOpen(true);
    else exec({}, k).catch((e) => toast("bad", `${action.label}: ${e.message}`));
  };
  return (
    <>
      <Button kind={action.kind || (small ? "ghost" : "secondary")} className={small ? "!px-1.5 !py-0.5" : ""} onClick={start}>{action.label}</Button>
      {open && (
        <Modal title={action.label} onClose={() => setOpen(false)}>
          <Form fields={fields} submit={action.label} danger={action.kind === "danger"} intro={<>{intro}{confirm && <p className="mt-1">{confirm}</p>}</>} onCancel={() => setOpen(false)} onSubmit={(v) => exec(v, key)} />
        </Modal>
      )}
    </>
  );
}

type Filter = { name: string; label: string; options: { value: string; label: string }[]; default?: string };
export function Resource({ title, endpoint, cols, detail, actions = [], rowActions = [], note, filters = [], max, pick, detailTitle }: {
  title: string; endpoint: string; cols: Col[]; detail?: (row: any) => string | null; actions?: Action[]; rowActions?: Action[]; note?: React.ReactNode;
  filters?: Filter[]; max?: number; pick?: (data: any) => any[]; detailTitle?: (row: any) => string;
}) {
  const [f, setF] = useState<Record<string, string>>(() => Object.fromEntries(filters.map((x) => [x.name, x.default ?? ""])));
  const qs = Object.entries(f).map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join("&");
  const { data, error, loading, reload } = useData<any>(endpoint + (qs ? (endpoint.includes("?") ? "&" : "?") + qs : ""));
  const [open, setOpen] = useState<any>(null);
  const rows = data ? (pick ? pick(data) : data) : [];
  return (
    <Card title={title} pad={false} right={<>{loading && <span className="text-[11px] text-ink-mute">Loading…</span>}<Button kind="ghost" onClick={reload} aria-label={`Refresh ${title}`}>↻ Refresh</Button></>}>
      {note && <div className="border-b border-line bg-white px-3 py-2 text-xs text-ink-soft">{note}</div>}
      {error ? <div className="p-3"><Notice tone="bad">{error}</Notice></div> : (
        <DataTable rows={rows} cols={cols} max={max} caption={title} onRow={detail ? (r) => detail(r) && setOpen(r) : undefined}
          toolbar={<>
            {filters.map((x) => (
              <label key={x.name} className="flex items-center gap-1 text-[11px] text-ink-soft">{x.label}
                <select className="rounded-sm border border-line bg-white px-1 py-1 text-xs" value={f[x.name]} onChange={(e) => setF((o) => ({ ...o, [x.name]: e.target.value }))}>
                  {x.options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </label>
            ))}
            {actions.map((a) => <ActionButton key={a.label} action={a} onDone={reload} />)}
          </>}
          actions={rowActions.length ? (row) => rowActions.map((a) => <ActionButton key={a.label} action={a} row={row} onDone={reload} small />) : undefined} />
      )}
      {open && detail && <DetailDrawer path={detail(open)!} title={detailTitle ? detailTitle(open) : `${title} — ${open.number || open.name || open.sku || open.code || "#" + open.id}`} onClose={() => setOpen(null)} />}
    </Card>
  );
}

export function DetailDrawer({ path, title, onClose }: { path: string; title: string; onClose: () => void }) {
  const { data, error } = useData<any>(path);
  return (
    <Drawer title={title} onClose={onClose}>
      {error && <Notice tone="bad">{error}</Notice>}
      {!data && !error && <p className="text-xs text-ink-mute">Loading…</p>}
      {data && (Array.isArray(data) ? <Card pad={false}><DataTable rows={data} cols={Object.keys(data[0] || {}).slice(0, 12).map((k) => ({ key: k }))} /></Card> : <Record data={data} />)}
      <p className="text-[11px] text-ink-mute">Source: GET /api/v1{path}</p>
    </Drawer>
  );
}

export function Workspace({ title, subtitle, tabs }: { title: string; subtitle: string; tabs: { key: string; label: string; perm?: string[]; render: () => React.ReactNode }[] }) {
  const { can } = useAuth();
  const visible = tabs.filter((t) => !t.perm || can(...t.perm));
  const [tab, setTab] = useState(visible[0]?.key);
  const cur = visible.find((t) => t.key === tab) || visible[0];
  return (
    <div className="space-y-3">
      <div>
        <h1 className="text-lg font-bold text-brand-dark">{title}</h1>
        <p className="text-xs text-ink-soft">{subtitle}</p>
      </div>
      {visible.length > 1 && <Tabs tabs={visible} value={cur.key} onChange={setTab} />}
      {cur ? <div className="space-y-3" key={cur.key}>{cur.render()}</div> : <Notice tone="warn">Your role has no access to this workspace.</Notice>}
    </div>
  );
}

export const SITE_OPTS = { endpoint: "/org/sites", label: (s: any) => `${s.name}` };
export const STORE_OPTS = { endpoint: "/org/sites", label: (s: any) => s.name, filter: (s: any) => s.kind === "store" };
export const DC_OPTS = { endpoint: "/org/sites", label: (s: any) => s.name, filter: (s: any) => s.kind === "dc" };
export const PRODUCT_OPTS = { endpoint: "/catalog/products", label: (p: any) => `${p.sku} — ${p.name}` };
export const SKU_OPTS = { endpoint: "/catalog/products", value: "sku", label: (p: any) => `${p.sku} — ${p.name}` };
export const SUPPLIER_OPTS = { endpoint: "/suppliers", label: (s: any) => `${s.code} — ${s.name}` };
