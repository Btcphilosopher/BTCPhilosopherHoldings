import React, { useState } from "react";
import { NavLink, Navigate, Route, Routes } from "react-router-dom";
import { AuthProvider, useAuth } from "./auth";
import { Button, Notice, ToastProvider, useData } from "./ui";
import Overview from "./workspaces/Overview";
import Analytics from "./workspaces/Analytics";
import { Pricing, Promotions } from "./workspaces/Pricing";
import { Distribution, Inventory, Procurement } from "./workspaces/SupplyChain";
import { Products, Stores, Suppliers } from "./workspaces/MasterData";
import { Loyalty, OnlineOrders } from "./workspaces/Customer";
import { Administration, Finance, Inbox, Workforce } from "./workspaces/Corporate";

const NAV: { path: string; label: string; perms: string[]; el: React.ReactNode; group: string }[] = [
  { group: "Overview", path: "/", label: "Executive Overview", perms: ["exec.read"], el: <Overview /> },
  { group: "Overview", path: "/inbox", label: "Approvals & Exceptions", perms: [], el: <Inbox /> },
  { group: "Master data", path: "/stores", label: "Stores", perms: ["org.read"], el: <Stores /> },
  { group: "Master data", path: "/products", label: "Products", perms: ["catalog.read"], el: <Products /> },
  { group: "Master data", path: "/suppliers", label: "Suppliers", perms: ["supplier.read"], el: <Suppliers /> },
  { group: "Supply chain", path: "/procurement", label: "Procurement", perms: ["procurement.read"], el: <Procurement /> },
  { group: "Supply chain", path: "/inventory", label: "Inventory", perms: ["inventory.read"], el: <Inventory /> },
  { group: "Supply chain", path: "/distribution", label: "Distribution", perms: ["distribution.read"], el: <Distribution /> },
  { group: "Customer", path: "/online", label: "Online Orders", perms: ["online.read", "service.write"], el: <OnlineOrders /> },
  { group: "Customer", path: "/pricing", label: "Pricing", perms: ["pricing.read"], el: <Pricing /> },
  { group: "Customer", path: "/promotions", label: "Promotions", perms: ["pricing.read"], el: <Promotions /> },
  { group: "Customer", path: "/loyalty", label: "Loyalty", perms: ["loyalty.read"], el: <Loyalty /> },
  { group: "Corporate", path: "/workforce", label: "Workforce", perms: ["workforce.read"], el: <Workforce /> },
  { group: "Corporate", path: "/finance", label: "Finance", perms: ["finance.read"], el: <Finance /> },
  { group: "Corporate", path: "/analytics", label: "Analytics", perms: ["analytics.read"], el: <Analytics /> },
  { group: "Corporate", path: "/admin", label: "Administration", perms: ["admin.read", "audit.read"], el: <Administration /> },
];
const DISCLAIMER = "Independent concept inspired by UK supermarket retailing. Not affiliated with or endorsed by Tesco PLC. All data is fictional.";

const DEMO = [
  ["exec", "Chief Operating Officer"], ["buyer", "Category Buyer"], ["procurement.manager", "Head of Procurement"], ["warehouse", "Warehouse Team Leader (DC only)"],
  ["pricing.analyst", "Pricing Analyst"], ["pricing.manager", "Pricing Manager"], ["finance.clerk", "Accounts Payable Clerk"], ["finance.controller", "Financial Controller"],
  ["store.ashbourne", "Store Manager (one store)"], ["regional.north", "Regional Manager (one region)"], ["service", "Customer Service"], ["loyalty", "Loyalty Manager"],
  ["hr", "HR Business Partner"], ["analyst", "Commercial Analyst"], ["auditor", "Internal Auditor (read-only)"], ["admin", "Platform Administrator"], ["security", "Security Administrator"],
];

function Login() {
  const { signIn } = useAuth();
  const [email, setEmail] = useState("exec@thq.example");
  const [password, setPassword] = useState("demo1234");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const go = async (e?: React.FormEvent, as?: string) => {
    e?.preventDefault();
    setBusy(true); setErr(null);
    try { await signIn(as ? `${as}@thq.example` : email, as ? "demo1234" : password); } catch (x: any) { setErr(x.message); } finally { setBusy(false); }
  };
  return (
    <div className="flex min-h-full items-center justify-center bg-brand-dark p-6">
      <div className="grid w-full max-w-4xl overflow-hidden rounded-sm bg-white shadow-2xl md:grid-cols-2">
        <form onSubmit={go} className="space-y-4 p-8">
          <div>
            <div className="flex items-baseline gap-2"><span className="text-2xl font-extrabold tracking-tight text-brand">TESCO&nbsp;HQ</span><span className="h-1.5 w-8 bg-action" /></div>
            <p className="text-sm font-semibold text-ink">Enterprise Retail Platform</p>
            <p className="mt-1 text-[11px] text-ink-mute">{DISCLAIMER}</p>
          </div>
          <label className="block text-xs font-semibold text-ink-soft">Email<input className="mt-1 w-full rounded-sm border border-line px-2 py-2 text-sm" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="username" /></label>
          <label className="block text-xs font-semibold text-ink-soft">Password<input type="password" className="mt-1 w-full rounded-sm border border-line px-2 py-2 text-sm" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" /></label>
          {err && <Notice tone="bad">{err}</Notice>}
          <Button kind="primary" className="w-full justify-center !py-2 !text-sm" disabled={busy}>{busy ? "Signing in…" : "Sign in"}</Button>
        </form>
        <div className="border-l border-line bg-surface p-6">
          <h2 className="text-sm font-semibold text-brand-dark">Demonstration users</h2>
          <p className="mb-2 text-[11px] text-ink-soft">Each role sees different workspaces, sites and actions. Password for all: <code>demo1234</code></p>
          <div className="grid max-h-80 grid-cols-1 gap-1 overflow-auto">
            {DEMO.map(([u, t]) => (
              <button key={u} onClick={() => go(undefined, u)} className="flex items-center justify-between rounded-sm border border-line bg-white px-2 py-1.5 text-left text-xs hover:border-brand hover:bg-brand-light">
                <span className="font-semibold text-brand">{u}@thq.example</span><span className="text-ink-soft">{t}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function Shell() {
  const { me, can, signOut } = useAuth();
  const nav = NAV.filter((n) => !n.perms.length || can(...n.perms));
  const pending = useData<any[]>("/approvals?status=pending");
  const mine = (pending.data || []).filter((a) => a.can_decide).length;
  const groups = [...new Set(nav.map((n) => n.group))];
  const scope = me!.roles.map((r) => `${r.name}${r.scope_type !== "global" ? ` (${r.scope_type})` : ""}`).join(", ");
  return (
    <div className="flex h-full">
      <nav aria-label="Workspaces" className="scroll-thin flex w-52 shrink-0 flex-col overflow-y-auto bg-brand-dark text-white">
        <div className="border-b border-white/10 px-4 py-3">
          <div className="flex items-baseline gap-2"><span className="text-lg font-extrabold tracking-tight">TESCO&nbsp;HQ</span><span className="h-1 w-5 bg-action" /></div>
          <div className="text-[10px] uppercase tracking-wide text-white/60">Enterprise Retail Platform</div>
        </div>
        <div className="flex-1 py-2">
          {groups.map((g) => (
            <div key={g} className="mb-1">
              <div className="px-4 pb-0.5 pt-2 text-[10px] font-semibold uppercase tracking-wider text-white/45">{g}</div>
              {nav.filter((n) => n.group === g).map((n) => (
                <NavLink key={n.path} to={n.path} end={n.path === "/"} className={({ isActive }) => `flex items-center justify-between border-l-[3px] px-4 py-1.5 text-[13px] ${isActive ? "border-action bg-brand-deep font-semibold" : "border-transparent text-white/85 hover:bg-white/10"}`}>
                  {n.label}
                  {n.path === "/inbox" && mine > 0 && <span className="num rounded-sm bg-action px-1.5 text-[10px] font-bold" title="Approvals waiting for your decision">{mine}</span>}
                </NavLink>
              ))}
            </div>
          ))}
        </div>
        <div className="border-t border-white/10 px-4 py-2 text-[10px] leading-snug text-white/50">{DISCLAIMER}</div>
      </nav>
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between gap-4 border-b border-line bg-white px-5 py-2">
          <div className="min-w-0 text-[11px] text-ink-soft"><span className="font-semibold text-ink">Demonstration environment</span> · currency GBP · times UTC · fictional sites, suppliers, customers and staff</div>
          <div className="flex shrink-0 items-center gap-3">
            <div className="text-right leading-tight"><div className="text-xs font-semibold">{me!.user.name}</div><div className="max-w-[26rem] truncate text-[11px] text-ink-mute" title={scope}>{me!.user.job_title} · {scope}</div></div>
            <Button kind="secondary" onClick={signOut}>Sign out</Button>
          </div>
        </header>
        <main className="scroll-thin flex-1 overflow-auto p-5">
          <Routes>
            {nav.map((n) => <Route key={n.path} path={n.path} element={n.el} />)}
            <Route path="*" element={nav.length ? <Navigate to={nav[0].path} replace /> : <Notice tone="warn">Your account has no workspace access.</Notice>} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

function Gate() {
  const { me, loading } = useAuth();
  if (loading) return <div className="p-10 text-sm text-ink-mute">Loading…</div>;
  return me ? <Shell key={me.user.id} /> : <Login />;
}

export default function App() {
  return (<ToastProvider><AuthProvider><Gate /></AuthProvider></ToastProvider>);
}
