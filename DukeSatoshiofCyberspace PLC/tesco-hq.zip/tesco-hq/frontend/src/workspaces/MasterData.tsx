import React from "react";
import { api } from "../api";
import { post, Resource, Workspace } from "../Resource";
import { Notice } from "../ui";

export function Stores() {
  return <Workspace title="Stores" subtitle="Business units, regions, formats, stores and the distribution centre. All sites are fictional." tabs={[
    { key: "sites", label: "Sites", render: () => (
      <Resource title="Sites" endpoint="/org/sites" detail={(r) => `/org/sites/${r.id}`}
        note="Seven-day sales, availability, staffing, maintenance and task counts per site. Click a row for departments, locations, opening hours and contacts."
        cols={[{ key: "code" }, { key: "name" }, { key: "kind", fmt: "status" }, { key: "region" }, { key: "format" }, { key: "status", fmt: "status" }, { key: "opened_on", fmt: "date" },
          { key: "net_sales_7d", label: "Net sales 7d", fmt: "money" }, { key: "availability_pct", label: "Availability", fmt: "pct" }, { key: "shifts_today", fmt: "int" },
          { key: "open_tasks", fmt: "int" }, { key: "open_maintenance", label: "Maintenance", fmt: "int" }, { key: "open_exceptions", label: "Exceptions", fmt: "int" }]}
        actions={[{ label: "Add site", perm: "org.write", kind: "primary", fields: [{ name: "code", required: true }, { name: "name", required: true }, { name: "kind", type: "select", options: [{ value: "store", label: "Store" }, { value: "dc", label: "Distribution centre" }], default: "store" },
          { name: "region_id", label: "Region", type: "select", required: true, options: { endpoint: "/org/regions" } }, { name: "opened_on", type: "date" }], run: (v) => post("/org/sites", v) }]}
        rowActions={[{ label: "Edit window", perm: "org.write", fields: [{ name: "delivery_window_start", type: "time", required: true }, { name: "delivery_window_end", type: "time", required: true }],
          intro: (r) => `Delivery window for ${r.name}. The route planner treats this as a hard constraint.`, run: (v, r) => api(`/org/sites/${r.id}`, { method: "PATCH", body: v }) }]} />) },
    { key: "formats", label: "Formats & hierarchy", render: () => (<>
      <Resource title="Store formats (assortment tier and replenishment policy are configurable)" endpoint="/org/hierarchy" pick={(d) => d.formats} cols={[{ key: "code" }, { key: "name" }, { key: "assortment_tier", fmt: "status" }, { key: "replenishment_policy", fmt: "json" }]}
        rowActions={[{ label: "Edit policy", perm: "org.write", fields: [{ name: "cover_days", type: "number", required: true, help: "Days of forecast demand each store allocation should cover" }, { name: "assortment_tier", type: "select", options: ["full", "core", "convenience"].map((x) => ({ value: x, label: x })) }],
          run: (v, r) => api(`/org/formats/${r.id}`, { method: "PATCH", body: { replenishment_policy: { ...r.replenishment_policy, cover_days: v.cover_days }, ...(v.assortment_tier ? { assortment_tier: v.assortment_tier } : {}) } }) }]} />
      <Resource title="Regions" endpoint="/org/hierarchy" pick={(d) => d.regions} cols={[{ key: "code" }, { key: "name" }, { key: "business_unit_id", label: "Business unit" }]} />
      <Resource title="Business units" endpoint="/org/hierarchy" pick={(d) => d.business_units} cols={[{ key: "code" }, { key: "name" }]} />
    </>) },
  ]} />;
}

export function Products() {
  return <Workspace title="Products" subtitle="Consumer items, supplier cases, pallets and weighed goods; barcodes, tax, storage and versioned changes." tabs={[
    { key: "products", label: "Product master", render: () => (
      <Resource title="Products" endpoint="/catalog/products" detail={(r) => `/catalog/products/${r.id}`}
        note="Click a product for pack levels (item / case / pallet / measured quantity), barcodes, suppliers, cost history and every past version."
        cols={[{ key: "sku", label: "SKU" }, { key: "name" }, { key: "category" }, { key: "storage_class", label: "Storage", fmt: "status" }, { key: "base_uom", label: "Sold by" }, { key: "case_size", fmt: "num" },
          { key: "shelf_life_days", label: "Shelf life (d)", fmt: "int" }, { key: "tax_code", label: "VAT" }, { key: "case_cost", fmt: "money" }, { key: "price_floor", fmt: "money" }, { key: "primary_supplier" }, { key: "status", fmt: "status" }, { key: "version", label: "Ver.", fmt: "int" }]}
        actions={[{ label: "New product", perm: "catalog.write", kind: "primary", fields: [{ name: "sku", label: "SKU", required: true }, { name: "name", required: true },
          { name: "category_id", label: "Category", type: "select", required: true, options: { endpoint: "/catalog/category-list" } }, { name: "tax_category_id", label: "Tax category (1 = zero-rated, 2 = standard)", type: "number", required: true, default: 1 },
          { name: "storage_class", type: "select", default: "ambient", options: ["ambient", "chilled", "frozen"].map((x) => ({ value: x, label: x })) }, { name: "case_size", type: "number", default: 6, required: true }, { name: "shelf_life_days", type: "number" }, { name: "is_weighted", label: "Sold by weight (kg)", type: "checkbox" }, { name: "barcode", label: "Barcode (GTIN)" }],
          run: (v) => post("/catalog/products", v) }]}
        rowActions={[{ label: "Edit", perm: "catalog.write", fields: (r) => [{ name: "name", default: r.name, required: true }, { name: "shelf_life_days", type: "number", default: r.shelf_life_days }, { name: "price_floor", type: "number", default: r.price_floor },
          { name: "status", type: "select", default: r.status, options: ["active", "delisted"].map((x) => ({ value: x, label: x })) }, { name: "change_note", required: true, help: "Recorded with the new version" }],
          intro: (r) => `Editing version ${r.version}. If someone else has changed the product since you loaded it, the save is refused rather than overwriting their work.`,
          run: (v, r) => api(`/catalog/products/${r.id}`, { method: "PATCH", body: { ...v, expected_version: r.version } }) }]} />) },
  ]} />;
}

export function Suppliers() {
  return <Workspace title="Suppliers" subtitle="Approved categories, lead times, delivery terms, qualifications, incidents and measured delivery performance." tabs={[
    { key: "suppliers", label: "Suppliers", render: () => (<>
      <Notice tone="info">Supplier independence is not assumed. Parent-group information is recorded only as declared by the supplier and labelled unverified; separate supplier records may share owners or upstream sources.</Notice>
      <Resource title="Suppliers" endpoint="/suppliers" detail={(r) => `/suppliers/${r.id}`}
        cols={[{ key: "code" }, { key: "name" }, { key: "status", fmt: "status" }, { key: "approved_categories" }, { key: "lead_time_days", label: "Lead (d)", fmt: "int" }, { key: "payment_terms_days", label: "Terms (d)", fmt: "int" },
          { key: "deliveries", fmt: "int" }, { key: "on_time_pct", label: "On time", fmt: "pct" }, { key: "in_full_pct", label: "In full", fmt: "pct" }, { key: "open_incidents", label: "Open incidents", fmt: "int" },
          { key: "next_qualification_expiry", label: "Qualification expiry", fmt: "date" }, { key: "declared_parent_group", label: "Declared parent (unverified)" }]}
        rowActions={[
          { label: "Set status", perm: "supplier.write", fields: [{ name: "status", type: "select", required: true, options: ["approved", "suspended", "onboarding"].map((x) => ({ value: x, label: x })) }, { name: "reason", required: true }], run: (v, r) => post(`/suppliers/${r.id}/status`, v) },
          { label: "Add qualification", perm: "supplier.write", fields: [{ name: "kind", required: true }, { name: "reference" }, { name: "valid_to", type: "date" }], run: (v, r) => post(`/suppliers/${r.id}/qualifications`, v) },
          { label: "Raise incident", perm: ["supplier.write", "inventory.write"], fields: [{ name: "description", type: "textarea", required: true }, { name: "severity", type: "select", default: "minor", options: ["minor", "major"].map((x) => ({ value: x, label: x })) }, { name: "lot_code" }], run: (v, r) => post(`/suppliers/${r.id}/incidents`, v) }]} />
    </>) },
  ]} />;
}
