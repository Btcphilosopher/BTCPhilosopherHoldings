import React, { useState } from "react";
import { api, newKey } from "../api";
import { useAuth } from "../auth";
import { Basket, cleanBasket, LinesButton } from "../Lines";
import { DetailDrawer, post, PRODUCT_OPTS, Resource, STORE_OPTS, Workspace } from "../Resource";
import { Badge, Button, Card, DataTable, gbp, Notice, useData, useToast } from "../ui";

const PW = ["pricing.write"], PA = ["pricing.approve"];
const iso = (v: string) => (v ? new Date(v).toISOString() : null);

function Simulator({ sell }: { sell?: boolean }) {
  const { can } = useAuth();
  const toast = useToast();
  const sites = useData<any[]>("/org/sites");
  const terms = useData<any[]>("/pos/terminals");
  const stores = (sites.data || []).filter((s) => s.kind === "store");
  const [site, setSite] = useState<number | "">("");
  const [channel, setChannel] = useState("store");
  const [terminal, setTerminal] = useState<number | "">("");
  const [member, setMember] = useState("M-0003");
  const [coupons, setCoupons] = useState("");
  const [tender, setTender] = useState("card");
  const [lines, setLines] = useState<any[]>([{ sku: "D2001", qty: 2 }, { sku: "D2003", qty: 1 }, { sku: "G6001", qty: 2 }, { sku: "K7001", qty: 3 }]);
  const [res, setRes] = useState<any>(null);
  const [sale, setSale] = useState<any>(null);
  const [err, setErr] = useState<string | null>(null);
  const [key, setKey] = useState(newKey());
  const sid = site || stores[0]?.id;
  const body = () => ({ site_id: sid, channel, terminal_id: terminal || null, member: member || null, coupon_codes: coupons.split(/[ ,]+/).filter(Boolean), lines: cleanBasket(lines) });
  const run = async () => { setErr(null); setSale(null); try { setRes(await post("/pricing/simulate", body())); } catch (e: any) { setErr(e.message); setRes(null); } };
  const doSell = async () => {
    setErr(null);
    try { const s = await post("/pos/sales", { ...body(), tender }, key); setSale(s); setRes(null); toast("good", `Sale ${s.number} completed${s.idempotent_replay ? " (replayed: no duplicate)" : ""}`); }
    catch (e: any) { setErr(e.message); }
  };
  return (
    <div className="grid gap-3 xl:grid-cols-[24rem_1fr]">
      <Card title={sell ? "Simulated till" : "Basket"}>
        <div className="space-y-2">
          <label className="block text-[11px] font-semibold text-ink-soft">Store
            <select className="mt-1 w-full rounded-sm border border-line px-2 py-1.5 text-xs font-normal" value={sid || ""} onChange={(e) => { setSite(Number(e.target.value)); setTerminal(""); }}>{stores.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></label>
          <div className="grid grid-cols-2 gap-2">
            {!sell && <label className="block text-[11px] font-semibold text-ink-soft">Channel<select className="mt-1 w-full rounded-sm border border-line px-2 py-1.5 text-xs font-normal" value={channel} onChange={(e) => setChannel(e.target.value)}><option value="store">Store</option><option value="online">Online</option></select></label>}
            <label className="block text-[11px] font-semibold text-ink-soft">Terminal<select className="mt-1 w-full rounded-sm border border-line px-2 py-1.5 text-xs font-normal" value={terminal} onChange={(e) => setTerminal(e.target.value ? Number(e.target.value) : "")}>
              <option value="">(any — all published prices)</option>{(terms.data || []).filter((t) => t.site_id === sid && t.kind !== "ecommerce").map((t) => <option key={t.id} value={t.id}>{t.code}{t.online ? "" : " (offline)"}</option>)}</select></label>
            {sell && <label className="block text-[11px] font-semibold text-ink-soft">Tender<select className="mt-1 w-full rounded-sm border border-line px-2 py-1.5 text-xs font-normal" value={tender} onChange={(e) => setTender(e.target.value)}><option value="card">Card (test provider)</option><option value="cash">Cash</option></select></label>}
          </div>
          <div className="grid grid-cols-2 gap-2">
            <label className="block text-[11px] font-semibold text-ink-soft">Member card (optional)<input className="mt-1 w-full rounded-sm border border-line px-2 py-1.5 text-xs font-normal" value={member} onChange={(e) => setMember(e.target.value)} placeholder="M-0001" /></label>
            <label className="block text-[11px] font-semibold text-ink-soft">Coupons<input className="mt-1 w-full rounded-sm border border-line px-2 py-1.5 text-xs font-normal" value={coupons} onChange={(e) => setCoupons(e.target.value)} placeholder="WELCOME5" /></label>
          </div>
          <div><span className="mb-1 block text-[11px] font-semibold text-ink-soft">Items</span><Basket value={lines} onChange={(v) => { setLines(v); setKey(newKey()); }} /></div>
          <div className="flex gap-2 pt-1">
            <Button kind={sell ? "secondary" : "primary"} onClick={run}>Calculate price</Button>
            {sell && can("pos.write") && <Button kind="primary" onClick={doSell}>Complete sale</Button>}
          </div>
          {sell && <p className="text-[11px] text-ink-mute">Integration point for a real POS: <code>POST /api/v1/pos/sales</code> with an Idempotency-Key. Uses a simulated payment provider; no card data is handled.</p>}
          {err && <Notice tone="bad">{err}</Notice>}
        </div>
      </Card>
      <div className="space-y-3">
        {sale && (
          <Card title={`Sale ${sale.number} completed`} right={<Badge value={sale.status} />}>
            <p className="num text-xs">Charged <b>{gbp(sale.gross)}</b> (net {gbp(sale.net)} + VAT {gbp(sale.tax)}), discount {gbp(sale.discount)}, cost {gbp(sale.cost)}, points earned {sale.points_earned}.</p>
            <DataTable search={false} rows={sale.journal} cols={[{ key: "number", label: "Journal" }, { key: "code", label: "Account" }, { key: "account", label: "Name" }, { key: "debit", fmt: "money" }, { key: "credit", fmt: "money" }, { key: "memo" }]} />
          </Card>
        )}
        {res ? (<>
          <Card title="Result" right={<span className="num text-sm font-bold text-brand-dark">{gbp(res.totals.gross)}</span>} pad={false}>
            <DataTable search={false} rows={res.lines} cols={[{ key: "sku", label: "SKU" }, { key: "description" }, { key: "qty", fmt: "num" }, { key: "base_unit_price", label: "Base price", fmt: "money" },
              { key: "price_source", label: "Price source", render: (l) => <span className="text-[11px] text-ink-soft">{l.price_source.price_book} #{l.price_source.entry_id} v{l.price_source.version}</span> },
              { key: "gross_before_discount", label: "Before", fmt: "money" }, { key: "discount", fmt: "money" }, { key: "gross", label: "Charged", fmt: "money" }, { key: "tax", label: "VAT incl.", fmt: "money" },
              { key: "applied", label: "Applied", render: (l) => <div className="flex flex-wrap gap-1">{l.applied.map((a: any, i: number) => <Badge key={i} value={a.code || a.coupon || a.kind} tone="good" />)}{l.floor_applied && <Badge value="floor" tone="warn" />}</div> },
              { key: "rejected", label: "Not applied", render: (l) => <ul className="max-w-xs text-[11px] text-ink-soft">{l.rejected.map((r: any, i: number) => <li key={i}><b>{r.code}:</b> {r.reason}</li>)}</ul> }]} />
            <div className="num flex flex-wrap justify-end gap-5 border-t border-line px-3 py-2 text-xs">
              <span>Before discounts <b>{gbp(res.totals.gross_before_discount)}</b></span><span>Discounts <b>−{gbp(res.totals.discount)}</b></span><span>Net <b>{gbp(res.totals.net)}</b></span><span>VAT <b>{gbp(res.totals.tax)}</b></span><span className="text-sm">Total <b>{gbp(res.totals.gross)}</b></span>
            </div>
          </Card>
          <Card title="Rule trace — exactly how this total was produced">
            <ol className="list-decimal space-y-0.5 pl-5 text-xs">{res.rules.map((r: string, i: number) => <li key={i} className={/not applied|not yet acknowledged/.test(r) ? "text-warn" : / saves |applied/.test(r) ? "text-ok" : ""}>{r}</li>)}</ol>
          </Card>
        </>) : !sale && <Card><p className="text-xs text-ink-mute">Build a basket and choose “Calculate price”. The same engine prices the tills and the online channel, so the trace shown here is what a real basket would be charged. Pick a terminal to see the price that terminal has actually confirmed.</p></Card>}
      </div>
    </div>
  );
}

export function Pricing() {
  return <Workspace title="Pricing" subtitle="Versioned price books by product, location, channel and effective period. Recommend → propose → approve → publish → confirm at each endpoint." tabs={[
    { key: "prices", label: "Price entries", render: () => (
      <Resource title="Price entries" endpoint="/pricing/prices" filters={[{ name: "status", label: "Status", default: "", options: ["", "published", "approved", "pending_approval", "rejected"].map((x) => ({ value: x, label: x ? x.replace("_", " ") : "All" })) }]}
        note="Prices are never edited: each change is a new version with its own effective date. Changes at or above the approval threshold need a second person. Shelf prices include VAT."
        cols={[{ key: "sku", label: "SKU" }, { key: "product" }, { key: "price_book", label: "Book" }, { key: "channel", fmt: "status" }, { key: "version", label: "Ver.", fmt: "int" }, { key: "price", fmt: "money" }, { key: "unit_cost", fmt: "cost" }, { key: "price_floor", label: "Floor", fmt: "money" },
          { key: "effective_from", fmt: "datetime" }, { key: "status", fmt: "status" }, { key: "is_current", label: "In force", fmt: "bool" }, { key: "endpoints_confirmed", label: "Endpoints confirmed", render: (r) => (r.endpoints ? <span className={`num ${r.endpoints_confirmed < r.endpoints ? "font-semibold text-action-dark" : ""}`}>{r.endpoints_confirmed}/{r.endpoints}</span> : "—") }, { key: "reason" }]}
        actions={[{ label: "Propose price change", perm: PW, kind: "primary", fields: [{ name: "price_book_id", label: "Price book", type: "select", required: true, options: { endpoint: "/pricing/price-books", label: (b: any) => `${b.code} — ${b.scope_name} (${b.channel})` } },
          { name: "product_id", label: "Product", type: "select", required: true, options: PRODUCT_OPTS }, { name: "price", label: "New price (incl. VAT)", type: "number", required: true }, { name: "effective_from", label: "Effective from (blank = now)", type: "datetime" }, { name: "reason", required: true }],
          run: (v) => post("/pricing/prices", { ...v, effective_from: iso(v.effective_from) }), done: (e) => (e.status === "pending_approval" ? "Material change: sent for approval" : "Below the approval threshold: approved, ready to publish") }]}
        rowActions={[{ label: "Publish", perm: PA, kind: "primary", show: (r) => r.status === "approved", confirm: "Sends the price to every till and channel endpoint in scope. Each endpoint must then acknowledge it.", run: (_, r) => post(`/pricing/prices/${r.id}/publish`) }]} />) },
    { key: "pubs", label: "Publication status", render: () => (<>
      <Notice tone="warn">A published price is an instruction, not a fact at the shelf. A terminal keeps charging its last confirmed price until it acknowledges the new one.</Notice>
      <Resource title="Publication status by endpoint" endpoint="/pricing/publications" cols={[{ key: "item_type", label: "Type", fmt: "status", tone: () => "info" }, { key: "item" }, { key: "site" }, { key: "terminal" }, { key: "terminal_kind", label: "Endpoint", fmt: "status" }, { key: "status", fmt: "status" }, { key: "attempts", fmt: "int" }, { key: "sent_at", fmt: "datetime" }, { key: "acknowledged_at", fmt: "datetime" }, { key: "last_error" }]}
        actions={[{ label: "Retry unconfirmed", perm: PA, run: () => post("/pricing/publications/retry"), done: (r) => `${r.acknowledged} acknowledged, ${r.failed} still failing` }]} />
      <Resource title="Tills and channel endpoints" endpoint="/pos/terminals" max={260} cols={[{ key: "code" }, { key: "site" }, { key: "kind", fmt: "status" }, { key: "online", label: "Connected", fmt: "bool" }]}
        rowActions={[{ label: "Toggle connectivity (simulator)", perm: ["pricing.approve", "admin.write"], run: (_, r) => post(`/pos/terminals/${r.id}/connectivity`, { online: !r.online }) }]} />
    </>) },
    { key: "recs", label: "Recommendations", render: () => <Recommendations /> },
    { key: "sim", label: "Price simulator", render: () => <Simulator /> },
    { key: "till", label: "Simulated till", perm: ["pos.write"], render: () => <Simulator sell /> },
    { key: "sales", label: "Sales & returns", perm: ["exec.read", "pos.write", "finance.read"], render: () => <SalesList /> },
    { key: "books", label: "Price books", render: () => <Resource title="Price books" endpoint="/pricing/price-books" note="Precedence: site book › format book › national book; within a scope a channel-specific book beats an all-channel book; then the latest effective date." cols={[{ key: "code" }, { key: "name" }, { key: "scope_type", label: "Scope", fmt: "status", tone: () => "info" }, { key: "scope_name", label: "Applies to" }, { key: "channel", fmt: "status" }, { key: "products", label: "Products priced", fmt: "int" }, { key: "active", fmt: "bool" }]} /> },
  ]} />;
}

function SalesList() {
  const { data, reload, error } = useData<any[]>("/sales?limit=300");
  const [open, setOpen] = useState<any>(null);
  return (
    <Card title="Completed sales (most recent first)" pad={false} right={<Button kind="ghost" onClick={reload}>↻ Refresh</Button>}>
      <p className="border-b border-line px-3 py-2 text-xs text-ink-soft">Click a sale for its lines, payments, stock movements, loyalty entries and journal. A return refunds the price actually paid and reverses stock, points and ledger entries; it cannot exceed what was sold.</p>
      {error && <div className="p-3"><Notice tone="bad">{error}</Notice></div>}
      <DataTable rows={data || []} onRow={setOpen} cols={[{ key: "number" }, { key: "at", fmt: "datetime" }, { key: "site" }, { key: "channel", fmt: "status" }, { key: "gross_before_discount", label: "Before", fmt: "money" }, { key: "discount", fmt: "money" }, { key: "gross", label: "Charged", fmt: "money" },
        { key: "net", fmt: "money" }, { key: "tax", label: "VAT", fmt: "money" }, { key: "cost", fmt: "money" }, { key: "gross_profit", fmt: "money" }, { key: "refunded_gross", label: "Refunded", fmt: "money" }, { key: "points_earned", label: "Points", fmt: "int" }, { key: "status", fmt: "status" }]}
        actions={(s) => (
          <LinesButton label="Return items" perm={["pos.write", "service.write"]} show={s.status !== "refunded"} title={`Return against ${s.number}`} onDone={reload}
            load={() => api(`/sales/${s.id}`).then((d) => d.lines.filter((l: any) => Number(l.qty) > Number(l.returned_qty)))}
            lineLabel={(l) => <span>{l.sku} {l.description} <span className="text-ink-mute">· {Number(l.qty) - Number(l.returned_qty)} returnable · paid {gbp(l.gross)}</span></span>}
            cols={[{ name: "qty", label: "Qty returned", default: () => 0 }, { name: "disposition", label: "Goods", type: "select", default: () => "restock", options: [{ value: "restock", label: "Back to stock" }, { value: "damaged", label: "Write off" }, { value: "none", label: "Not returned" }], width: "10rem" }]}
            extra={[{ name: "reason", label: "Reason", required: true }]}
            submit={(lines, ex, key) => post(`/sales/${s.id}/returns`, { reason: ex.reason, lines: lines.filter(({ v }) => Number(v.qty) > 0).map(({ line, v }) => ({ sale_line_id: line.id, qty: String(v.qty), disposition: v.disposition || "restock" })) }, key)}
            done={(r) => `Refunded ${gbp(r.return.gross)}; ${r.return.points_reversed} point(s) reversed`} />
        )} />
      {open && <DetailDrawer path={`/sales/${open.id}`} title={`Sale ${open.number} — full trace`} onClose={() => setOpen(null)} />}
    </Card>
  );
}

function Recommendations() {
  const { data, error } = useData<any>("/pricing/recommendations");
  const toast = useToast();
  const { can } = useAuth();
  if (error) return <Notice tone="bad">{error}</Notice>;
  if (!data) return null;
  const markdown = async (r: any) => {
    try {
      await post("/pricing/promotions", { code: `MD-${r.sku}-${r.lot_id}`, name: `Short-dated ${r.suggested_pct}% off ${r.product}`, kind: "markdown", params: { pct: r.suggested_pct }, product_ids: [r.product_id], site_ids: [r.site_id], lot_id: r.lot_id,
        starts_at: new Date().toISOString(), ends_at: new Date(new Date(r.expiry_date).getTime() + 86400000).toISOString() });
      toast("good", "Markdown proposed and sent for approval");
    } catch (e: any) { toast("bad", e.message); }
  };
  return (<>
    <Notice tone="info">{data.note} Nothing here changes a price by itself: recommendation, approval, publication and endpoint confirmation are separate steps by design.</Notice>
    <Card title="Short-dated stock — markdown suggestions" pad={false}>
      <DataTable rows={data.short_dated} empty="No short-dated lots without a markdown" cols={[{ key: "site" }, { key: "sku", label: "SKU" }, { key: "product" }, { key: "lot_code", label: "Lot" }, { key: "expiry_date", fmt: "date" }, { key: "qty", fmt: "num" }, { key: "suggested_pct", label: "Suggested %", fmt: "int" }, { key: "rationale" }, { key: "basis", label: "Based on" }]}
        actions={can("pricing.write") ? (r) => <Button kind="ghost" className="!px-1.5 !py-0.5" onClick={() => markdown(r)}>Propose markdown</Button> : undefined} />
    </Card>
    <Card title="Margin review" pad={false}>
      <DataTable rows={data.margin_review} empty="No products below the margin review line" cols={[{ key: "sku", label: "SKU" }, { key: "product" }, { key: "price", fmt: "money" }, { key: "unit_cost", fmt: "cost" }, { key: "margin_pct", label: "Net margin", fmt: "pct" }, { key: "rationale" }, { key: "basis", label: "Based on" }]} />
    </Card>
  </>);
}

export function Promotions() {
  const kinds = [["percent_off", "Percentage off — params {\"pct\": 25}"], ["fixed_price", "Fixed price — {\"price\": \"1.00\"}"], ["multibuy", "Multibuy — {\"buy_qty\": 3, \"for_price\": \"5.00\"}"], ["loyalty_price", "Loyalty price — {\"price\": \"2.75\"}"]];
  const pol = useData<any>("/pricing/policy").data;
  return <Workspace title="Promotions" subtitle="Promotions, multibuys, loyalty prices, coupons and short-dated markdowns, with explicit precedence, limits and return treatment." tabs={[
    { key: "promos", label: "Promotions", render: () => (<>
      {pol && <Card title="Precedence and treatment (configurable policy)"><ol className="list-decimal pl-5 text-xs">{pol.precedence.map((p: string) => <li key={p}>{p}</li>)}</ol><p className="mt-1 text-xs text-ink-soft"><b>Returns:</b> {pol.returns}. <b>Coupons per basket:</b> {pol.coupons_per_basket}. Offers are never individualised by personal characteristics; eligibility depends only on product, place, channel, time, membership and presented coupons.</p></Card>}
      <Resource title="Promotions" endpoint="/pricing/promotions" detail={(r) => `/pricing/promotions/${r.id}/conflicts`} detailTitle={(r) => `Overlapping promotions for ${r.code}`}
        cols={[{ key: "code" }, { key: "name" }, { key: "kind", fmt: "status", tone: () => "info" }, { key: "params", fmt: "json" }, { key: "products" }, { key: "channel", fmt: "status" }, { key: "priority", fmt: "int" }, { key: "stackable", fmt: "bool" }, { key: "max_qty_per_basket", label: "Limit", fmt: "int" },
          { key: "starts_at", fmt: "datetime" }, { key: "ends_at", fmt: "datetime" }, { key: "status", fmt: "status" }, { key: "live", label: "Live now", fmt: "bool" }, { key: "endpoints_confirmed", label: "Confirmed", render: (r) => (r.endpoints ? <span className={`num ${r.endpoints_confirmed < r.endpoints ? "font-semibold text-action-dark" : ""}`}>{r.endpoints_confirmed}/{r.endpoints}</span> : "—") },
          { key: "control_site_ids", label: "Holdout stores", render: (r) => (r.control_site_ids?.length ? `${r.control_site_ids.length} store(s)` : "none") }]}
        actions={[{ label: "Propose promotion", perm: PW, kind: "primary", fields: [{ name: "code", required: true }, { name: "name", required: true }, { name: "kind", type: "select", required: true, options: kinds.map(([v, l]) => ({ value: v, label: l })) },
          { name: "params", label: "Parameters (JSON)", required: true, default: '{"pct": 20}' }, { name: "product_id", label: "Product", type: "select", required: true, options: PRODUCT_OPTS }, { name: "starts_at", type: "datetime", required: true }, { name: "ends_at", type: "datetime", required: true },
          { name: "priority", type: "number", default: 10, help: "Higher wins. Equal priority: the better customer saving wins." }, { name: "max_qty_per_basket", type: "number" }, { name: "stackable", type: "checkbox", help: "Percentage promotions only" },
          { name: "control_site_id", label: "Holdout store (optional, enables an uplift estimate)", type: "select", options: STORE_OPTS }],
          run: async (v) => { let params; try { params = JSON.parse(v.params); } catch { throw new Error("Parameters must be valid JSON"); }
            return post("/pricing/promotions", { code: v.code, name: v.name, kind: v.kind, params, product_ids: [v.product_id], starts_at: iso(v.starts_at), ends_at: iso(v.ends_at), priority: v.priority ?? 10, max_qty_per_basket: v.max_qty_per_basket || null, stackable: !!v.stackable, control_site_ids: v.control_site_id ? [v.control_site_id] : null }); },
          done: (r) => (r.conflicts.length ? `Sent for approval. Overlaps ${r.conflicts.map((c: any) => c.code).join(", ")} — a conflict exception was raised` : "Sent for approval") }]}
        rowActions={[{ label: "Publish", perm: PA, kind: "primary", show: (r) => r.status === "approved", confirm: "Publishes to all tills and channel endpoints in scope.", run: (_, r) => post(`/pricing/promotions/${r.id}/publish`) }]} />
    </>) },
    { key: "coupons", label: "Coupons", render: () => <Resource title="Coupons (single use)" endpoint="/pricing/coupons" note="A coupon can be redeemed once; a replayed redemption is rejected by the database update that claims it." cols={[{ key: "code" }, { key: "description" }, { key: "amount_off", fmt: "money" }, { key: "min_spend", fmt: "money" }, { key: "member_no", label: "Bound to member" }, { key: "valid_to", fmt: "datetime" }, { key: "status", fmt: "status" }, { key: "redeemed_sale_id", label: "Redeemed on sale #" }, { key: "redeemed_at", fmt: "datetime" }]} /> },
  ]} />;
}
