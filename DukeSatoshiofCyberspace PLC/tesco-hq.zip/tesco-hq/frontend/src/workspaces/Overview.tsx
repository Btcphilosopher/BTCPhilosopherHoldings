import React, { useState } from "react";
import { BarList, TrendChart } from "../charts";
import { DetailDrawer } from "../Resource";
import { Badge, Button, Card, DataTable, gbp, Notice, num, pct, useData } from "../ui";

export type Metric = { key: string; label: string; value: any; unit: string; basis: string; definition: string; source: string; numerator?: string; denominator?: string; exclusions?: string; drill?: string; period?: string };

export function fmtMetric(m: Metric): { main: string; sub?: string } {
  const v = m.value;
  if (v === null || v === undefined) return { main: "n/a", sub: "no qualifying records in the period" };
  if (typeof v === "object") {
    if ("count" in v) return { main: gbp(v.value), sub: `${num(v.count, 0)} ${m.key === "orders" ? "orders" : m.key === "refunds" ? "refunds" : "transactions"}` };
    if ("rate_pct" in v) return { main: gbp(v.value), sub: `${pct(v.rate_pct)} of revenue` };
    if ("baskets" in v) return { main: gbp(v.value), sub: `${num(v.baskets, 0)} baskets` };
    return { main: Object.entries(v).map(([k, x]) => `${x} ${k.replace(/_/g, " ")}`).join(" · ") };
  }
  if (m.unit.startsWith("%")) return { main: pct(v) };
  if (m.unit.startsWith("GBP")) return { main: gbp(v) };
  return { main: `${num(v)}`, sub: m.unit };
}

/** A KPI tile that always carries its definition, period, source and (for ratios) numerator and denominator. */
export function MetricCard({ m, onDrill }: { m: Metric; onDrill?: (m: Metric) => void }) {
  const [open, setOpen] = useState(false);
  const f = fmtMetric(m);
  return (
    <div className="flex flex-col rounded-sm border border-line bg-white">
      <div className="flex items-start justify-between gap-2 px-3 pt-2">
        <span className="text-[11px] font-semibold uppercase tracking-wide text-ink-soft">{m.label}</span>
        <Badge value={m.basis} tone={m.basis === "actual" ? "info" : "warn"} />
      </div>
      <div className="px-3 pb-1"><div className="num text-xl font-bold text-brand-dark">{f.main}</div><div className="num min-h-[1rem] text-[11px] text-ink-soft">{f.sub || m.unit}</div></div>
      <div className="mt-auto flex items-center justify-between border-t border-line/70 px-2 py-1">
        <button className="text-[11px] font-semibold text-brand underline" aria-expanded={open} onClick={() => setOpen((o) => !o)}>{open ? "Hide definition" : "Definition"}</button>
        {m.drill && onDrill && <button className="text-[11px] font-semibold text-brand underline" onClick={() => onDrill(m)}>View records →</button>}
      </div>
      {open && (
        <dl className="space-y-1 border-t border-line/70 bg-gray-50 px-3 py-2 text-[11px] text-ink-soft">
          <div><dt className="inline font-semibold">Definition: </dt><dd className="inline">{m.definition}</dd></div>
          <div><dt className="inline font-semibold">Period: </dt><dd className="inline">{m.period}</dd></div>
          <div><dt className="inline font-semibold">Unit: </dt><dd className="inline">{m.unit}</dd></div>
          {m.numerator && <div><dt className="inline font-semibold">Numerator: </dt><dd className="inline">{m.numerator}</dd></div>}
          {m.denominator && <div><dt className="inline font-semibold">Denominator: </dt><dd className="inline">{m.denominator}</dd></div>}
          {m.exclusions && <div><dt className="inline font-semibold">Exclusions: </dt><dd className="inline">{m.exclusions}</dd></div>}
          <div><dt className="inline font-semibold">Source: </dt><dd className="inline">{m.source}</dd></div>
        </dl>
      )}
    </div>
  );
}

export default function Overview() {
  const [days, setDays] = useState(14);
  const { data, error, reload, loading } = useData<any>(`/executive/overview?days=${days}`);
  const insights = useData<any>("/analytics/insights");
  const [drill, setDrill] = useState<Metric | null>(null);
  if (error) return <Notice tone="bad">{error}</Notice>;
  if (!data) return <p className="text-xs text-ink-mute">Loading overview…</p>;
  const cf = data.cash_flow_forecast;
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold text-brand-dark">Executive Overview</h1>
          <p className="text-xs text-ink-soft">{data.period.label} · {data.currency} · scope: {data.scope}. Every figure is computed from stored transactions; open “Definition” or “View records” on any tile.</p>
        </div>
        <div className="flex items-center gap-2">
          <label className="text-[11px] font-semibold text-ink-soft">Reporting period
            <select className="ml-1 rounded-sm border border-line bg-white px-2 py-1 text-xs" value={days} onChange={(e) => setDays(Number(e.target.value))}>
              <option value={1}>Today</option><option value={7}>Last 7 days</option><option value={14}>Last 14 days</option><option value={28}>Last 28 days</option>
            </select>
          </label>
          <Button onClick={reload}>{loading ? "Refreshing…" : "↻ Refresh"}</Button>
        </div>
      </div>

      <section aria-label="From order to cash">
        <h2 className="mb-1.5 text-xs font-semibold text-ink-soft">From order to cash — these are different things and are reported separately</h2>
        <div className="grid grid-cols-2 gap-2 md:grid-cols-4 2xl:grid-cols-7">{data.flow.map((m: Metric) => <MetricCard key={m.key} m={m} onDrill={setDrill} />)}</div>
      </section>
      <section aria-label="Operating performance">
        <h2 className="mb-1.5 text-xs font-semibold text-ink-soft">Operating performance</h2>
        <div className="grid grid-cols-2 gap-2 md:grid-cols-4">{data.kpis.map((m: Metric) => <MetricCard key={m.key} m={m} onDrill={setDrill} />)}</div>
      </section>

      <div className="grid gap-3 xl:grid-cols-3">
        <Card title="Net sales by day — actual, budget and forecast (GBP excl. VAT)" className="xl:col-span-2">
          <TrendChart points={data.trend.map((t: any) => ({ day: t.day, actual: t.actual_net_sales == null ? null : Number(t.actual_net_sales), budget: Number(t.budget_net_sales), forecast: t.forecast_net_sales == null ? null : Number(t.forecast_net_sales), note: t.note }))} />
          <ul className="mt-2 space-y-0.5 text-[11px] text-ink-mute">
            <li><b>Actual:</b> {data.trend_notes.actual}</li><li><b>Budget:</b> {data.trend_notes.budget}</li><li><b>Forecast:</b> {data.trend_notes.forecast}</li>
          </ul>
        </Card>
        <Card title="Outstanding exceptions" right={<a className="text-[11px] font-semibold text-brand underline" href="/inbox">Open inbox →</a>}>
          {data.exceptions.length ? (
            <ul className="divide-y divide-line/70">
              {data.exceptions.map((e: any) => (
                <li key={e.kind} className="flex items-center justify-between py-1.5 text-xs">
                  <span>{e.kind.replace(/_/g, " ")}</span>
                  <span className="flex items-center gap-2">{e.high > 0 && <Badge value={`${e.high} high`} tone="bad" />}<span className="num w-6 text-right font-semibold">{e.n}</span></span>
                </li>
              ))}
            </ul>
          ) : <p className="text-xs text-ink-mute">No open exceptions in your scope.</p>}
        </Card>
      </div>

      <div className="grid gap-3 xl:grid-cols-2">
        <Card title="Store performance — net sales vs budget for the period">
          <BarList rows={data.stores} labelKey="name" valueKey="net_sales" refKey="budget_net_sales" refLabel="budget" />
        </Card>
        <Card title="Store performance — detail" pad={false}>
          <DataTable search={false} max={260} rows={data.stores} cols={[{ key: "name", label: "Store" }, { key: "format" }, { key: "net_sales", fmt: "money" }, { key: "budget_net_sales", label: "Budget", fmt: "money" },
            { key: "gross_profit", fmt: "money" }, { key: "margin_pct", label: "Margin", fmt: "pct" }, { key: "transactions", fmt: "int" }, { key: "avg_basket", fmt: "money" }]} />
        </Card>
      </div>

      <Card title="Cash-flow forecast — next 14 days" right={<Badge value="forecast" tone="warn" />} pad={false}>
        <div className="border-b border-line px-3 py-2 text-[11px] text-ink-soft"><b>Method:</b> {cf.method} <b>Scope:</b> {cf.scope}. Opening bank balance (ledger account 1000): <span className="num font-semibold">{gbp(cf.opening_bank_balance)}</span></div>
        <DataTable search={false} max={300} rows={cf.rows} cols={[{ key: "day", fmt: "date" }, { key: "card_settlements_due", label: "Card settlements due (actual takings)", fmt: "money" }, { key: "forecast_sales_receipts", label: "Receipts from forecast sales", fmt: "money" },
          { key: "supplier_payments_due", label: "Supplier invoices due", fmt: "money" }, { key: "uninvoiced_receipts_due", label: "Received, not yet invoiced", fmt: "money" }, { key: "inflow", fmt: "money" }, { key: "outflow", fmt: "money" }, { key: "projected_bank_balance", label: "Projected bank balance", fmt: "money" }]} />
      </Card>

      <Card title="Exception summary and suggested investigations" right={<Badge value="advisory" tone="info" />}>
        {insights.data ? (
          <>
            <p className="mb-2 text-[11px] text-ink-soft">{insights.data.guardrails} Provider: {insights.data.provider}.</p>
            <div className="grid gap-2 lg:grid-cols-2">
              {insights.data.items.map((i: any) => (
                <div key={i.kind} className="rounded-sm border border-line p-2">
                  <div className="flex items-center justify-between"><span className="text-xs font-semibold">{i.summary}</span>{i.high_severity > 0 && <Badge value="high" />}</div>
                  <p className="mt-1 text-xs text-ink-soft"><b>Suggested investigation:</b> {i.suggested_investigation}</p>
                  <p className="mt-1 text-[11px] text-ink-mute">Cites: {i.citations.map((c: any) => `exception #${c.exception_id} → ${c.entity_type} #${c.entity_id}`).join("; ")}</p>
                </div>
              ))}
            </div>
          </>
        ) : <p className="text-xs text-ink-mute">{insights.error || "Loading…"}</p>}
      </Card>
      {drill && <DetailDrawer path={drill.drill!} title={`${drill.label} — underlying records`} onClose={() => setDrill(null)} />}
    </div>
  );
}
