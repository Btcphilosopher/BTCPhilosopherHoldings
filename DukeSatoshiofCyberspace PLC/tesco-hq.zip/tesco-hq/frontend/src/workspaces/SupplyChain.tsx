import React, { useState } from "react";
import { api } from "../api";
import { LineSeries } from "../charts";
import { LinesButton } from "../Lines";
import { ActionButton, DC_OPTS, post, PRODUCT_OPTS, Resource, SITE_OPTS, STORE_OPTS, SUPPLIER_OPTS, Workspace } from "../Resource";
import { Badge, Card, DataTable, fdatetime, ftime, Notice, useData } from "../ui";

const W = ["procurement.write"];

function ForecastPanel() {
  const runs = useData<any[]>("/procurement/forecasts/runs");
  const prods = useData<any[]>("/catalog/products");
  const [pid, setPid] = useState<number | null>(null);
  const product = pid ?? prods.data?.find((p) => p.sku === "D2001")?.id ?? prods.data?.[0]?.id;
  const series = useData<any>(product ? `/procurement/forecasts/series?product_id=${product}` : null);
  const run = runs.data?.[0];
  return (
    <>
      <Card title="Latest forecast run — evaluation on time-ordered holdout" right={run && <Badge value={`run #${run.id}`} tone="info" />} pad={false}>
        {run ? (<>
          <p className="border-b border-line px-3 py-2 text-[11px] text-ink-soft">{run.evaluation._protocol} Series: {run.series_count}. Chosen method: <b>{run.chosen_method}</b> (lowest WAPE).</p>
          <DataTable search={false} rows={Object.entries(run.evaluation).filter(([k]) => !k.startsWith("_")).map(([k, v]: any) => ({ method: k, ...v, chosen: k === run.chosen_method }))}
            cols={[{ key: "method" }, { key: "wape_pct", label: "WAPE %", fmt: "num" }, { key: "mae_units", label: "MAE (units)", fmt: "num" }, { key: "bias_units", label: "Bias (units)", fmt: "num" }, { key: "points", label: "Scored points", fmt: "int" }, { key: "chosen", fmt: "bool" }]} />
        </>) : <p className="p-3 text-xs text-ink-mute">No forecast run yet.</p>}
      </Card>
      <Card title="Sales history and forecast (all stores)" right={
        <select aria-label="Product" className="rounded-sm border border-line px-1 py-1 text-xs" value={product || ""} onChange={(e) => setPid(Number(e.target.value))}>
          {(prods.data || []).map((p) => <option key={p.id} value={p.id}>{p.sku} — {p.name}</option>)}
        </select>}>
        {series.data && <LineSeries history={series.data.history.map((h: any) => ({ day: h.day, v: Number(h.units_sold), flag: h.stockout }))} forecast={series.data.forecast.map((f: any) => ({ day: f.day, v: Number(f.qty) }))} />}
        <p className="mt-1 text-[11px] text-ink-mute">On stock-out days, recorded sales are below true demand; the forecast replaces them with the average of the same weekday in stock before fitting.</p>
      </Card>
    </>
  );
}

export function Procurement() {
  return <Workspace title="Procurement" subtitle="Forecast → recommendation → requisition → purchase order → appointment → receipt → discrepancy → supplier return." tabs={[
    { key: "forecast", label: "Demand forecast", render: () => (<>
      <Resource title="Forecast runs" endpoint="/procurement/forecasts/runs" max={160} cols={[{ key: "id", label: "Run" }, { key: "created_at", fmt: "datetime" }, { key: "as_of", fmt: "date" }, { key: "chosen_method" }, { key: "horizon_days", fmt: "int" }, { key: "holdout_days", fmt: "int" }, { key: "series_count", fmt: "int" }, { key: "censored_days", label: "Stock-out days un-censored", fmt: "int" }]}
        actions={[{ label: "Run forecast now", perm: W, kind: "primary", fields: [{ name: "horizon_days", type: "number", default: 14 }, { name: "holdout_days", type: "number", default: 14 }, { name: "background", label: "Run in the background worker", type: "checkbox" }],
          run: (v) => post("/procurement/forecasts/run", v), done: (r) => (r.job ? `Forecast queued as job #${r.job.id} - see Administration › Jobs` : `Forecast run #${r.id} complete: ${r.chosen_method}`) }]} />
      <ForecastPanel />
    </>) },
    { key: "recs", label: "Reorder recommendations", render: () => (
      <Resource title="Reorder recommendations" endpoint="/procurement/recommendations" filters={[{ name: "status", label: "Status", default: "open", options: [{ value: "open", label: "Open" }, { value: "", label: "All" }, { value: "ordered", label: "Ordered" }, { value: "rejected", label: "Rejected" }] }]}
        note="Need = forecast demand over lead time + review period + safety stock − (DC available + on order). The Constraints column lists, in order, everything that changed the quantity: case pack, MOQ, storage capacity, expiry risk, supplier availability, delivery calendar and the working-capital limit."
        cols={[{ key: "sku", label: "SKU" }, { key: "product" }, { key: "supplier" }, { key: "need_units", fmt: "num" }, { key: "unconstrained_cases", label: "Unconstrained", fmt: "int" }, { key: "recommended_cases", label: "Recommended", fmt: "int" }, { key: "final_cases", label: "Final", fmt: "int" },
          { key: "order_value", fmt: "money" }, { key: "expected_delivery", fmt: "date" }, { key: "status", fmt: "status" },
          { key: "constraints", render: (r) => <ul className="max-w-md list-disc pl-4 text-[11px] text-ink-soft">{(r.constraints || []).map((c: any, i: number) => <li key={i}><b>{c.constraint.replace(/_/g, " ")}:</b> {c.effect}</li>)}{r.override_reason && <li><b>override:</b> {r.override_reason}</li>}</ul> },
          { key: "inputs", label: "Working", render: (r) => <span className="text-[11px] text-ink-soft">demand {r.inputs?.demand_over_horizon} + safety {r.inputs?.safety_stock} − position {r.inputs?.position}; cover {r.inputs?.days_of_cover} d</span> }]}
        actions={[{ label: "Generate for DC", perm: W, kind: "primary", fields: [{ name: "site_id", label: "Distribution centre", type: "select", required: true, options: DC_OPTS }], run: (v) => post("/procurement/recommendations/run", v), done: (r) => `${r.created} recommendations created` }]}
        rowActions={[
          { label: "Accept", perm: W, show: (r) => r.status === "open" && r.final_cases > 0 && r.supplier_id, run: (_, r) => post(`/procurement/recommendations/${r.id}/decide`, { action: "accept" }), done: (x) => `Added to requisition ${x.requisition.number}` },
          { label: "Override", perm: W, show: (r) => r.status === "open" && r.supplier_id, fields: (r) => [{ name: "cases", type: "number", required: true, default: r.recommended_cases }, { name: "reason", type: "textarea", required: true, help: "Recorded against the recommendation and in the audit log" }], run: (v, r) => post(`/procurement/recommendations/${r.id}/decide`, { action: "override", ...v }) },
          { label: "Reject", perm: W, show: (r) => r.status === "open", fields: [{ name: "reason", required: true }], run: (v, r) => post(`/procurement/recommendations/${r.id}/decide`, { action: "reject", ...v }) }]} />) },
    { key: "reqs", label: "Requisitions & quotations", render: () => (<>
      <Resource title="Purchase requisitions" endpoint="/procurement/requisitions" max={220} cols={[{ key: "number" }, { key: "supplier" }, { key: "site" }, { key: "lines", fmt: "int" }, { key: "contents" }, { key: "status", fmt: "status" }, { key: "created_at", fmt: "datetime" }]}
        rowActions={[{ label: "Convert to PO", perm: W, show: (r) => r.status === "open", fields: [{ name: "expected_date", label: "Requested delivery date (optional)", type: "date" }], run: (v, r) => post(`/procurement/requisitions/${r.id}/convert`, v.expected_date ? v : {}), done: (po) => `${po.number} raised and sent for approval` }]} />
      <Resource title="Supplier quotations" endpoint="/procurement/quotations" max={220} cols={[{ key: "supplier" }, { key: "sku", label: "SKU" }, { key: "product" }, { key: "case_cost", label: "Quoted case cost", fmt: "cost" }, { key: "current_primary_cost", label: "Current primary cost", fmt: "cost" }, { key: "moq_cases", label: "MOQ", fmt: "int" }, { key: "valid_until", fmt: "date" }, { key: "status", fmt: "status" }]}
        actions={[{ label: "Record quotation", perm: W, fields: [{ name: "supplier_id", label: "Supplier", type: "select", required: true, options: SUPPLIER_OPTS }, { name: "product_id", label: "Product", type: "select", required: true, options: PRODUCT_OPTS }, { name: "case_cost", type: "number", required: true }, { name: "moq_cases", type: "number", default: 1 }, { name: "valid_until", type: "date" }], run: (v) => post("/procurement/quotations", v) }]}
        rowActions={[{ label: "Accept", perm: W, show: (r) => r.status === "received", confirm: "Accepting updates the supplier's agreed case cost and writes a cost-history entry.", run: (_, r) => post(`/procurement/quotations/${r.id}/accept`) }]} />
    </>) },
    { key: "pos", label: "Purchase orders", render: () => (
      <Resource title="Purchase orders" endpoint="/procurement/purchase-orders" detail={(r) => `/procurement/purchase-orders/${r.id}`}
        note="A purchase order must be approved by someone other than its creator (see Approvals & Exceptions). Receipts may be partial; a delivery note can only be booked in once."
        cols={[{ key: "number" }, { key: "supplier" }, { key: "site" }, { key: "status", fmt: "status" }, { key: "expected_date", fmt: "date" }, { key: "net_total", fmt: "money" }, { key: "cases_ordered", label: "Ordered", fmt: "int" }, { key: "cases_received", label: "Accepted", fmt: "int" },
          { key: "cases_damaged", label: "Damaged", fmt: "int" }, { key: "created_by_name", label: "Raised by" }, { key: "approved_by_name", label: "Approved by" }]}
        actions={[{ label: "New purchase order", perm: W, kind: "primary", fields: [{ name: "supplier_id", label: "Supplier", type: "select", required: true, options: SUPPLIER_OPTS }, { name: "site_id", label: "Deliver to", type: "select", required: true, options: DC_OPTS },
          { name: "product_id", label: "Product", type: "select", required: true, options: PRODUCT_OPTS }, { name: "cases", type: "number", required: true, default: 4 }, { name: "expected_date", type: "date" }],
          intro: "Single-line order. Case cost comes from the supplier agreement, not from this form.", run: (v) => post("/procurement/purchase-orders", { supplier_id: v.supplier_id, site_id: v.site_id, expected_date: v.expected_date || null, lines: [{ product_id: v.product_id, cases: v.cases }] }), done: (po) => `${po.number} raised and sent for approval` }]}
        rowActions={[]} />) },
    { key: "receive", label: "Goods receipt", perm: W, render: () => <ReceiptDesk /> },
    { key: "exceptions", label: "Appointments, discrepancies, returns", render: () => (<>
      <Resource title="Delivery appointments" endpoint="/procurement/appointments" max={240} cols={[{ key: "po_number", label: "PO" }, { key: "supplier" }, { key: "site" }, { key: "dock" }, { key: "slot_start", fmt: "datetime" }, { key: "slot_end", fmt: "time" }, { key: "actual_arrival", fmt: "datetime" }, { key: "status", fmt: "status" }]} />
      <Resource title="Receipt discrepancies" endpoint="/procurement/discrepancies" max={220} cols={[{ key: "po_number", label: "PO" }, { key: "supplier" }, { key: "delivery_note_ref", label: "Delivery note" }, { key: "description", label: "Product" }, { key: "kind", fmt: "status", tone: () => "bad" }, { key: "cases", fmt: "int" }, { key: "note" }, { key: "status", fmt: "status" }]} />
      <Resource title="Returns to supplier" endpoint="/procurement/supplier-returns" max={220} cols={[{ key: "supplier" }, { key: "product" }, { key: "lot_code", label: "Lot" }, { key: "qty", fmt: "num" }, { key: "reason" }, { key: "status", fmt: "status" }, { key: "created_at", fmt: "datetime" }]}
        rowActions={[{ label: "Mark collected", perm: W, show: (r) => r.status === "open", confirm: "The goods leave the damaged-stock bucket.", run: (_, r) => post(`/procurement/supplier-returns/${r.id}/collect`) }]} />
    </>) },
  ]} />;
}

function ReceiptDesk() {
  const { data, reload } = useData<any[]>("/procurement/purchase-orders");
  const open = (data || []).filter((p) => ["approved", "part_received"].includes(p.status));
  return (
    <Card title="Purchase orders awaiting delivery" pad={false} right={<span className="text-[11px] text-ink-mute">{open.length} open</span>}>
      <p className="border-b border-line px-3 py-2 text-xs text-ink-soft">Book in what actually arrived. Damaged cases go to the damaged bucket (not saleable) and raise a supplier return. If you submit twice, the second request is recognised and ignored.</p>
      <DataTable rows={open} cols={[{ key: "number" }, { key: "supplier" }, { key: "site" }, { key: "status", fmt: "status" }, { key: "expected_date", fmt: "date" }, { key: "cases_ordered", label: "Ordered", fmt: "int" }, { key: "cases_received", label: "Accepted so far", fmt: "int" }]}
        empty="No approved purchase orders are awaiting delivery"
        actions={(po) => (
          <LinesButton label="Receive delivery" kind="primary" perm={W} title={`Receive against ${po.number} — ${po.supplier}`} onDone={reload}
            load={() => api(`/procurement/purchase-orders/${po.id}`).then((d) => d.lines.filter((l: any) => l.cases_ordered - l.cases_received - l.cases_damaged > 0))}
            lineLabel={(l) => <span>{l.sku} {l.description}<span className="text-ink-mute"> · {l.cases_ordered - l.cases_received - l.cases_damaged} cases outstanding</span></span>}
            cols={[{ name: "cases_received", label: "Good cases", default: (l) => l.cases_ordered - l.cases_received - l.cases_damaged }, { name: "cases_damaged", label: "Damaged", default: () => 0 }, { name: "lot_code", label: "Lot code", type: "text", width: "9rem" }]}
            extra={[{ name: "delivery_note_ref", label: "Delivery note reference", required: true }, { name: "close_short", label: "Close PO short (nothing more expected)", type: "checkbox" }]}
            submit={(lines, ex, key) => post(`/procurement/purchase-orders/${po.id}/receipts`, { delivery_note_ref: ex.delivery_note_ref, close_short: !!ex.close_short,
              lines: lines.map(({ line, v }) => ({ po_line_id: line.id, cases_received: Number(v.cases_received || 0), cases_damaged: Number(v.cases_damaged || 0), lot_code: v.lot_code || null })) }, key)}
            done={(r) => `Receipt posted; PO is now ${r.po_status.replace("_", " ")}`} />
        )} />
    </Card>
  );
}

export function Inventory() {
  const integ = useData<any>("/inventory/integrity");
  const IW = ["inventory.write"];
  const lotFields = (r: any) => [{ name: "qty", type: "number" as const, required: true }, { name: "reason", required: true }];
  return <Workspace title="Inventory" subtitle="An immutable movement ledger; on hand, reserved, available, in transit, quarantined, damaged and expired are kept apart." tabs={[
    { key: "stock", label: "Stock position", render: () => (<>
      {integ.data && <Notice tone={integ.data.balanced ? "good" : "bad"}>Ledger check: {integ.data.balanced ? `every balance equals the sum of its ${integ.data.movements.toLocaleString()} movements; no negative balances.` : `${integ.data.mismatches.length} balance(s) disagree with the ledger.`} On hand = available + reserved.</Notice>}
      <Resource title="Stock by site and product" endpoint="/inventory/stock" cols={[{ key: "site" }, { key: "sku", label: "SKU" }, { key: "product" }, { key: "storage_class", label: "Storage", fmt: "status" }, { key: "on_hand", fmt: "num" }, { key: "reserved", fmt: "num" }, { key: "available", fmt: "num" },
        { key: "in_transit", fmt: "num" }, { key: "quarantined", fmt: "num" }, { key: "damaged", fmt: "num" }, { key: "expired", fmt: "num" }, { key: "base_uom", label: "Unit" }, { key: "value", label: "Value at cost", fmt: "money" }, { key: "earliest_expiry", fmt: "date" }]}
        detail={(r) => `/inventory/movements?site_id=${r.site_id}&product_id=${r.product_id}&limit=200`} detailTitle={(r) => `Movement ledger — ${r.product} at ${r.site}`}
        actions={[{ label: "Run expiry sweep", perm: IW, confirm: "Moves stock past its expiry date from available to expired and writes off its value.", run: () => post("/inventory/expiry-sweep"), done: (r) => `${r.moved.length} lot(s) moved to expired` }]} />
    </>) },
    { key: "lots", label: "Lots & expiry", render: () => (
      <Resource title="Lots (provenance and expiry)" endpoint="/inventory/lots" detail={(r) => `/inventory/movements?lot_id=${r.lot_id}&limit=300`} detailTitle={(r) => `Lot ${r.lot_code} — full movement history`}
        filters={[{ name: "expiring_days", label: "Show", default: "", options: [{ value: "", label: "All lots" }, { value: "2", label: "Expiring within 2 days" }, { value: "7", label: "Expiring within 7 days" }] }]}
        cols={[{ key: "site" }, { key: "sku", label: "SKU" }, { key: "product" }, { key: "lot_code", label: "Lot" }, { key: "supplier" }, { key: "expiry_date", fmt: "date" }, { key: "days_to_expiry", label: "Days left", fmt: "int" }, { key: "unit_cost", fmt: "cost" },
          { key: "available", fmt: "num" }, { key: "reserved", fmt: "num" }, { key: "in_transit", fmt: "num" }, { key: "quarantined", fmt: "num" }, { key: "damaged", fmt: "num" }, { key: "expired", fmt: "num" }]}
        rowActions={[
          { label: "Count", perm: IW, fields: (r) => [{ name: "counted_qty", label: `Counted quantity (system shows ${r.available} available)`, type: "number", required: true }], run: (v, r) => post("/inventory/cycle-counts", { site_id: r.site_id, product_id: r.product_id, lot_id: r.lot_id, counted_qty: v.counted_qty }),
            done: (x) => (x.status === "pending_approval" ? "Variance is material: sent for second approval, stock unchanged until approved" : x.status === "no_variance" ? "Count matches the system" : "Variance posted to the ledger") },
          { label: "Waste", perm: IW, fields: lotFields, run: (v, r) => post("/inventory/adjustments", { site_id: r.site_id, product_id: r.product_id, lot_id: r.lot_id, bucket: "available", qty_delta: -Math.abs(v.qty), kind: "waste", reason: v.reason }),
            done: (x) => (x.status === "pending_approval" ? `Worth £${x.value}: sent for approval` : `Waste of £${x.value} posted`) },
          { label: "Transfer", perm: IW, fields: [{ name: "to_site_id", label: "To store", type: "select", required: true, options: STORE_OPTS }, { name: "qty", type: "number", required: true }, { name: "reason", required: true }],
            run: (v, r) => post("/inventory/site-transfers", { from_site_id: r.site_id, product_id: r.product_id, lot_id: r.lot_id, ...v }) },
          { label: "Withdraw lot", perm: ["inventory.approve"], kind: "danger", fields: [{ name: "reason", type: "textarea", required: true }], confirm: "Quarantines every available unit of this lot at every site.", run: (v, r) => post("/inventory/withdrawals", { product_id: r.product_id, lot_id: r.lot_id, reason: v.reason }) }]} />) },
    { key: "ledger", label: "Movement ledger", render: () => (
      <Resource title="Stock movements (append-only; most recent first)" endpoint="/inventory/movements?limit=500" max={560}
        note="Rows can never be edited or deleted — the database rejects it. A correction is a new movement. The two legs of a bucket-to-bucket move share a group id and net to zero."
        cols={[{ key: "id" }, { key: "at", fmt: "datetime" }, { key: "site" }, { key: "sku", label: "SKU" }, { key: "lot_code", label: "Lot" }, { key: "bucket", fmt: "status" }, { key: "qty", label: "Δ Qty", fmt: "num" }, { key: "mtype", label: "Type" },
          { key: "ref_type", label: "Document" }, { key: "ref_id", label: "Doc #" }, { key: "actor" }, { key: "reason" }]} />) },
    { key: "counts", label: "Counts & reservations", render: () => (<>
      <Resource title="Cycle counts" endpoint="/inventory/cycle-counts" max={240} cols={[{ key: "at", fmt: "datetime" }, { key: "site" }, { key: "product" }, { key: "lot_code", label: "Lot" }, { key: "system_qty", fmt: "num" }, { key: "counted_qty", fmt: "num" }, { key: "variance", fmt: "num" }, { key: "status", fmt: "status" }]} />
      <Resource title="Active reservations" endpoint="/inventory/reservations" max={240} cols={[{ key: "site" }, { key: "product" }, { key: "qty", fmt: "num" }, { key: "ref_type", label: "Reserved for" }, { key: "ref_id", label: "Document #" }, { key: "created_at", fmt: "datetime" }]} />
    </>) },
    { key: "withdrawals", label: "Product withdrawals", render: () => (
      <Resource title="Product withdrawals" endpoint="/inventory/withdrawals" detail={(r) => `/inventory/withdrawals/${r.id}`}
        note="A withdrawal quarantines available stock everywhere, reports what is reserved or in transit, and counts affected sales. It reads stock and movement records only; no customer identities are shown."
        cols={[{ key: "id" }, { key: "at", fmt: "datetime" }, { key: "sku", label: "SKU" }, { key: "product" }, { key: "lot_code", label: "Lot (blank = all)" }, { key: "reason" }, { key: "status", fmt: "status" }, { key: "summary", fmt: "json" }]}
        actions={[{ label: "Withdraw whole product", perm: ["inventory.approve"], kind: "danger", fields: [{ name: "product_id", label: "Product", type: "select", required: true, options: PRODUCT_OPTS }, { name: "reason", type: "textarea", required: true }],
          confirm: "Quarantines all available stock at every site and blocks the product from sale.", run: (v) => post("/inventory/withdrawals", v) }]} />) },
  ]} />;
}

export function Distribution() {
  const DW = ["distribution.write"];
  return <Workspace title="Distribution" subtitle="Store allocation, warehouse work queue, picking waves, vehicle loading, route planning and store receipt." tabs={[
    { key: "transfers", label: "Store transfers", render: () => (
      <Resource title="Store transfers" endpoint="/distribution/transfers" detail={(r) => `/distribution/transfers/${r.id}`}
        note="Allocation covers each store's forecast for its format's cover days plus safety stock. If the DC is short, stores receive a proportional share and the shortfall stays visible (requested vs allocated)."
        cols={[{ key: "number" }, { key: "from_site", label: "From" }, { key: "to_site", label: "To" }, { key: "status", fmt: "status" }, { key: "qty_requested", label: "Requested", fmt: "num" }, { key: "qty_allocated", label: "Allocated", fmt: "num" }, { key: "qty_picked", label: "Picked", fmt: "num" },
          { key: "qty_received", label: "Received", fmt: "num" }, { key: "cages", label: "Cages by temperature", fmt: "json" }, { key: "dispatched_at", fmt: "datetime" }, { key: "received_at", fmt: "datetime" }]}
        actions={[{ label: "Allocate stock to stores", perm: DW, kind: "primary", fields: [{ name: "dc_id", label: "From distribution centre", type: "select", required: true, options: DC_OPTS }], run: (v) => post("/distribution/allocations/run", v), done: (r) => `${r.transfers.length} transfer(s) created and stock reserved` },
          { label: "Release picking wave", perm: DW, fields: [{ name: "dc_id", label: "Distribution centre", type: "select", required: true, options: DC_OPTS }], run: (v) => post("/distribution/waves", v), done: (r) => `Wave #${r.id} released` }]} />) },
    { key: "tasks", label: "Warehouse work queue", render: () => (
      <Resource title="Warehouse tasks" endpoint="/distribution/tasks" filters={[{ name: "status", label: "Status", default: "open", options: [{ value: "open", label: "Open" }, { value: "done", label: "Done" }, { value: "", label: "All" }] },
        { name: "kind", label: "Type", default: "", options: [{ value: "", label: "All" }, { value: "putaway", label: "Put-away" }, { value: "pick", label: "Pick" }, { value: "pack", label: "Pack" }, { value: "stage", label: "Stage" }] }]}
        note="Completing all picks for a transfer creates its pack task; packing creates the staging task. Each completion is confirmed through the scanner interface (simulated)."
        cols={[{ key: "id", label: "Task" }, { key: "kind", fmt: "status", tone: () => "info" }, { key: "status", fmt: "status" }, { key: "transfer" }, { key: "destination" }, { key: "sku", label: "SKU" }, { key: "product" }, { key: "lot_code", label: "Lot" }, { key: "temp_class", label: "Temp", fmt: "status" },
          { key: "qty", fmt: "num" }, { key: "qty_done", label: "Done", fmt: "num" }, { key: "location_code", label: "Location" }, { key: "scan_ref", label: "Scan ref" }, { key: "completed_at", fmt: "datetime" }]}
        actions={["putaway", "pick", "pack", "stage"].map((k) => ({ label: `Complete all ${k}`, perm: DW, fields: [{ name: "dc_id", label: "Site", type: "select" as const, required: true, options: DC_OPTS }], run: (v: any) => post(`/distribution/tasks/complete-all?kind=${k}`, v), done: (r: any) => `${r.completed} ${k} task(s) completed` }))}
        rowActions={[{ label: "Complete", perm: DW, show: (r) => r.status === "open", fields: (r) => (r.qty ? [{ name: "qty_done", label: `Quantity done (of ${r.qty})`, type: "number" as const, default: Number(r.qty), required: true, help: "Enter less for a short pick: the remainder is released and a discrepancy raised" }] : []).concat(r.kind === "putaway" ? [{ name: "location_code", label: "Put-away location", default: r.temp_class === "frozen" ? "F-01-01" : r.temp_class === "chilled" ? "C-01-01" : "A-01-01" } as any] : []),
          run: (v, r) => post(`/distribution/tasks/${r.id}/complete`, v) }]} />) },
    { key: "routes", label: "Route plans", render: () => <RoutePlans /> },
    { key: "stops", label: "Deliveries & proof of delivery", render: () => (
      <Resource title="Store deliveries" endpoint="/distribution/stops"
        note="Planned arrival comes from the route plan. Live ETA comes from vehicle tracking (simulated) and is shown separately, with the drift in minutes."
        cols={[{ key: "fleet_no", label: "Vehicle" }, { key: "seq", label: "Stop", fmt: "int" }, { key: "site", label: "Store" }, { key: "transfer" }, { key: "window_start", label: "Window opens", fmt: "time" }, { key: "window_end", label: "Window closes", fmt: "time" },
          { key: "planned_arrival", label: "Planned", fmt: "time" }, { key: "live_eta", label: "Live ETA", fmt: "time" }, { key: "eta_drift_min", label: "Drift (min)", fmt: "int" }, { key: "actual_arrival", label: "Arrived", fmt: "datetime" }, { key: "status", fmt: "status" }, { key: "pod_ref", label: "POD" }, { key: "failure_reason" }]}
        rowActions={[{ label: "Confirm receipt", perm: DW, show: (r) => r.status === "en_route", fields: [{ name: "receiver", default: "Duty manager", required: true }], run: (v, r) => post(`/distribution/stops/${r.id}/confirm`, v) },
          { label: "Delivery failed", perm: DW, kind: "danger", show: (r) => r.status === "en_route", fields: [{ name: "reason", required: true }], confirm: "The load is returned to the DC and put back into available stock there.", run: (v, r) => post(`/distribution/stops/${r.id}/fail`, v) }]} />) },
    { key: "fleet", label: "Vehicles", render: () => <Resource title="Vehicles" endpoint="/distribution/vehicles" cols={[{ key: "fleet_no" }, { key: "site" }, { key: "capacity_cages", fmt: "int" }, { key: "chilled", fmt: "bool" }, { key: "frozen", fmt: "bool" }, { key: "status", fmt: "status" }]} /> },
  ]} />;
}

function RoutePlans() {
  const { data, reload } = useData<any[]>("/distribution/route-plans");
  return (
    <div className="space-y-3">
      <Card title="Plan routes" right={<ActionButton action={{ label: "Plan routes for staged transfers", perm: ["distribution.write"], kind: "primary", fields: [{ name: "dc_id", label: "Distribution centre", type: "select", required: true, options: DC_OPTS }, { name: "day", type: "date" }, { name: "depart", label: "Departure time", type: "time", default: "05:00" }],
        run: (v) => post("/distribution/route-plans", { dc_id: v.dc_id, day: v.day || null, depart: (v.depart || "05:00") + ":00" }), done: (r) => `Plan #${r.id}: ${r.infeasible.length} infeasible stop(s)` }} onDone={reload} />}>
        <p className="text-xs text-ink-soft">Baseline planner: greedy nearest-neighbour per vehicle with hard capacity, temperature-compartment and delivery-window checks. Stops that cannot be scheduled are reported as infeasible, never forced into a route.</p>
      </Card>
      {(data || []).map((p) => (
        <Card key={p.id} title={`Route plan #${p.id} — ${p.day} — departs ${ftime(p.depart_at)}`} right={<Badge value={p.infeasible_count ? `${p.infeasible_count} infeasible` : "all scheduled"} tone={p.infeasible_count ? "bad" : "good"} />}>
          <p className="mb-2 text-[11px] text-ink-mute">Method: {p.method}</p>
          {p.infeasible?.map((i: any) => <Notice key={i.transfer} tone="bad"><b>Not scheduled: {i.transfer} to {i.store}</b> (cages {JSON.stringify(i.cages)}). {i.reasons.join("; ")}</Notice>)}
          <div className="mt-2 space-y-2">
            {p.routes.map((r: any) => (
              <div key={r.id} className="rounded-sm border border-line">
                <div className="flex items-center justify-between bg-gray-50 px-2 py-1.5 text-xs">
                  <span><b>{r.fleet_no}</b> · {r.load_cages}/{r.capacity_cages} cages · {r.distance_km} km · {r.chilled ? "chilled" : "no chilled"} / {r.frozen ? "frozen" : "no frozen"}</span>
                  <span className="flex items-center gap-2"><Badge value={r.status} />
                    {r.status === "planned" && <button className="rounded-sm border border-action bg-action px-2 py-0.5 text-[11px] font-semibold text-white" onClick={() => post(`/distribution/routes/${r.id}/dispatch`).then(reload).catch((e) => alert(e.message))}>Dispatch</button>}
                    {r.status === "dispatched" && <button className="rounded-sm border border-brand px-2 py-0.5 text-[11px] font-semibold text-brand" onClick={() => post(`/distribution/routes/${r.id}/refresh-eta`).then(reload)}>Refresh live ETA</button>}</span>
                </div>
                <DataTable search={false} rows={r.stops} cols={[{ key: "seq", label: "#", fmt: "int" }, { key: "site", label: "Store" }, { key: "transfer" }, { key: "window_start", label: "Window", render: (s) => `${ftime(s.window_start)}–${ftime(s.window_end)}` },
                  { key: "planned_arrival", label: "Planned", fmt: "time" }, { key: "live_eta", label: "Live ETA", fmt: "time" }, { key: "status", fmt: "status" }, { key: "pod_ref", label: "POD" }]} />
              </div>
            ))}
            {!p.routes.length && <p className="text-xs text-ink-mute">No routes could be built.</p>}
          </div>
        </Card>
      ))}
    </div>
  );
}
