import React, { useState } from "react";
import { api, token } from "../api";
import { useAuth } from "../auth";
import { LinesButton } from "../Lines";
import { ActionButton, post, Resource, SITE_OPTS, STORE_OPTS, Workspace } from "../Resource";
import { Badge, Button, Card, DataTable, fdatetime, gbp, Notice, useData, useToast } from "../ui";

const EMP_OPTS = { endpoint: "/workforce/employees", label: (e: any) => `${e.employee_no} — ${e.name} (${e.site})` };
const iso = (v: string) => (v ? new Date(v).toISOString() : null);

// ---------------------------------------------------------------- approvals & exceptions (everyone)
export function Inbox() {
  const { can } = useAuth();
  const [status, setStatus] = useState("pending");
  const ap = useData<any[]>(`/approvals?status=${status}`);
  return (
    <div className="space-y-3">
      <div><h1 className="text-lg font-bold text-brand-dark">Approvals &amp; Exceptions</h1><p className="text-xs text-ink-soft">Maker-checker requests you can see or decide, and operational exceptions raised by the workflows. Every exception links to the record that caused it.</p></div>
      <Card title="Approval requests" pad={false} right={<><select aria-label="Status" className="rounded-sm border border-line px-1 py-1 text-xs" value={status} onChange={(e) => setStatus(e.target.value)}><option value="pending">Pending</option><option value="approved">Approved</option><option value="rejected">Rejected</option><option value="">All</option></select><Button kind="ghost" onClick={ap.reload}>↻ Refresh</Button></>}>
        <p className="border-b border-line px-3 py-2 text-xs text-ink-soft">Purchase orders, material price changes, promotions, supplier payments, material stock adjustments and permission changes all need a second person. You cannot decide a request you raised.</p>
        <DataTable rows={ap.data || []} empty="Nothing to show" cols={[{ key: "id", label: "#" }, { key: "kind", fmt: "status", tone: () => "info" }, { key: "summary" }, { key: "amount", fmt: "money" }, { key: "requested_by_name", label: "Requested by" }, { key: "requested_at", fmt: "datetime" }, { key: "status", fmt: "status" },
          { key: "decided_by_name", label: "Decided by" }, { key: "decision_reason", label: "Reason" }, { key: "blocked_reason", label: "Note", render: (r) => (r.blocked_reason ? <span className="text-[11px] text-warn">{r.blocked_reason}</span> : r.status === "pending" && !r.can_decide ? <span className="text-[11px] text-ink-mute">Needs {r.required_perm}</span> : "") }]}
          actions={(a) => a.can_decide ? (<>
            <ActionButton small row={a} onDone={ap.reload} action={{ label: "Approve", kind: "primary", fields: [{ name: "reason", label: "Comment (optional)" }], intro: a.summary, run: (v) => post(`/approvals/${a.id}/decision`, { approve: true, reason: v.reason || null }) }} />
            <ActionButton small row={a} onDone={ap.reload} action={{ label: "Reject", kind: "danger", fields: [{ name: "reason", required: true }], intro: a.summary, run: (v) => post(`/approvals/${a.id}/decision`, { approve: false, reason: v.reason }) }} />
          </>) : null} />
      </Card>
      {can("exec.read", "analytics.read", "admin.read") ? (
        <Resource title="Exceptions" endpoint="/exceptions" filters={[{ name: "status", label: "Status", default: "open", options: [{ value: "open", label: "Open" }, { value: "resolved", label: "Resolved" }, { value: "", label: "All" }] }]}
          cols={[{ key: "id", label: "#" }, { key: "severity", fmt: "status" }, { key: "kind", render: (r) => r.kind.replace(/_/g, " ") }, { key: "title" }, { key: "site_name", label: "Site" }, { key: "entity_type", label: "Record", render: (r) => `${r.entity_type || ""} #${r.entity_id ?? ""}` }, { key: "detail" }, { key: "raised_at", fmt: "datetime" }, { key: "status", fmt: "status" }, { key: "resolution" }]}
          rowActions={[{ label: "Resolve", show: (r) => r.status === "open", fields: [{ name: "resolution", label: "What was done", type: "textarea", required: true }], run: (v, r) => post(`/exceptions/${r.id}/resolve`, v) }]} />
      ) : <Notice tone="info">Your role does not include the exceptions list.</Notice>}
    </div>
  );
}

// ---------------------------------------------------------------- workforce
function TimesheetImport({ onDone }: { onDone: () => void }) {
  const toast = useToast();
  const { can } = useAuth();
  if (!can("workforce.write")) return null;
  const upload = async (f: File) => {
    const form = new FormData();
    form.append("file", f);
    try { const j = await api("/workforce/timesheets/import", { method: "POST", form }); toast("good", `Import queued as job #${j.id}; the background worker will process it`); setTimeout(onDone, 2500); } catch (e: any) { toast("bad", e.message); }
  };
  return <label className="inline-flex cursor-pointer items-center rounded-sm border border-brand bg-white px-2.5 py-1 text-xs font-semibold text-brand hover:bg-brand-light">Import timesheet CSV<input type="file" accept=".csv,text/csv" className="sr-only" onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])} /></label>;
}

export function Workforce() {
  const WW = ["workforce.write"];
  const [tick, setTick] = useState(0);
  return <Workspace title="Workforce" subtitle="Rotas, availability, training and qualification expiry, leave, timesheet imports, store tasks and maintenance. Pay and employment-law rules stay in the HR/payroll system." tabs={[
    { key: "shifts", label: "Shift plan", render: () => (
      <Resource title="Shifts — next 7 days" endpoint="/workforce/shifts?days=7" note="A new shift is checked against configurable constraints: minimum rest, maximum shift and weekly hours, approved leave, stated availability and any qualification the duty requires. Violations are refused with the reason."
        cols={[{ key: "starts_at", label: "Start", fmt: "datetime" }, { key: "ends_at", label: "End", fmt: "time" }, { key: "hours", fmt: "num" }, { key: "site" }, { key: "employee" }, { key: "job_role", label: "Role" }, { key: "duty" }, { key: "status", fmt: "status" }, { key: "warnings", render: (r) => (r.warnings?.length ? <span className="text-[11px] text-warn">{r.warnings.join("; ")}</span> : "") }]}
        actions={[{ label: "Plan shift", perm: WW, kind: "primary", fields: [{ name: "employee_id", label: "Employee", type: "select", required: true, options: EMP_OPTS }, { name: "starts_at", type: "datetime", required: true }, { name: "ends_at", type: "datetime", required: true },
          { name: "duty", type: "select", required: true, default: "Shop floor", options: ["Shop floor", "Checkouts", "Bakery", "Counters", "Picking", "Forklift operator", "Alcohol sales supervisor"].map((x) => ({ value: x, label: x })) }],
          run: (v) => post("/workforce/shifts", { ...v, starts_at: iso(v.starts_at), ends_at: iso(v.ends_at) }) }]}
        rowActions={[{ label: "Cancel", perm: WW, show: (r) => r.status === "planned", confirm: "Cancel this shift?", run: (_, r) => post(`/workforce/shifts/${r.id}/cancel`) }]} />) },
    { key: "people", label: "Employees", render: () => (
      <Resource title="Employees" endpoint="/workforce/employees" detail={(r) => `/workforce/employees/${r.id}`}
        note="The general record holds work facts only. Personal details are a separate, restricted record (HR only; each view is audited). No medical information is stored in this platform."
        cols={[{ key: "employee_no", label: "No." }, { key: "name" }, { key: "site" }, { key: "job_role", label: "Role" }, { key: "contract_hours", label: "Contract h/wk", fmt: "num" }, { key: "hours_this_week", label: "Rostered this week", fmt: "num" }, { key: "next_expiry", label: "Next qualification expiry", fmt: "date" }, { key: "status", fmt: "status" }]} />) },
    { key: "training", label: "Training & qualifications", render: () => (
      <Resource title="Training records" endpoint="/workforce/training" cols={[{ key: "employee" }, { key: "site" }, { key: "course" }, { key: "completed_on", fmt: "date" }, { key: "expires_on", fmt: "date" }, { key: "days_left", fmt: "int" }, { key: "status", fmt: "status" }]}
        actions={[{ label: "Record training", perm: WW, fields: [{ name: "employee_id", label: "Employee", type: "select", required: true, options: EMP_OPTS }, { name: "course", type: "select", required: true, options: ["Food hygiene level 2", "Forklift licence", "Licensing awareness", "Pharmacy assistant certificate", "Manual handling"].map((x) => ({ value: x, label: x })) }, { name: "completed_on", type: "date", required: true }, { name: "expires_on", type: "date" }], run: (v) => post("/workforce/training", { ...v, expires_on: v.expires_on || null }) }]} />) },
    { key: "leave", label: "Leave", render: () => (
      <Resource title="Leave requests" endpoint="/workforce/leave" note="Only the dates and a broad category are recorded. A manager decides each request; the system reports any planned shifts that would need to be reassigned."
        cols={[{ key: "employee" }, { key: "site" }, { key: "from_date", fmt: "date" }, { key: "to_date", fmt: "date" }, { key: "category", fmt: "status", tone: () => "mute" }, { key: "status", fmt: "status" }, { key: "requested_at", fmt: "datetime" }]}
        actions={[{ label: "Request leave", perm: WW, fields: [{ name: "employee_id", label: "Employee", type: "select", required: true, options: EMP_OPTS }, { name: "from_date", type: "date", required: true }, { name: "to_date", type: "date", required: true }, { name: "category", type: "select", default: "annual", options: ["annual", "unpaid", "other"].map((x) => ({ value: x, label: x })) }], run: (v) => post("/workforce/leave", v) }]}
        rowActions={[{ label: "Approve", perm: WW, show: (r) => r.status === "requested", run: (_, r) => post(`/workforce/leave/${r.id}/decision`, { approve: true }), done: (x) => (x.shift_clashes_to_reassign.length ? `Approved. ${x.shift_clashes_to_reassign.length} planned shift(s) now need reassigning` : "Approved") },
          { label: "Decline", perm: WW, show: (r) => r.status === "requested", run: (_, r) => post(`/workforce/leave/${r.id}/decision`, { approve: false }) }]} />) },
    { key: "timesheets", label: "Timesheets", render: () => (<>
      <Card title="Timesheet import and HR hand-off" right={<><TimesheetImport onDone={() => setTick((t) => t + 1)} /><ActionButton action={{ label: "Export hours to HR/payroll", perm: WW, confirm: "Sends the last 14 days of hours through the HR adapter (simulated). No pay is calculated here.", run: () => post("/workforce/timesheets/export-to-hr"), done: (r) => `${r.accepted} entries accepted by ${r.system}` }} /></>}>
        <p className="text-xs text-ink-soft">CSV columns: <code>employee_no,work_date,hours</code>. Imports run in the background worker. Importing the same file twice adds nothing: rows are unique per employee, date and file. Bad rows are reported on the job, not silently dropped.</p>
      </Card>
      <div key={tick}><Resource title="Imported timesheet entries" endpoint="/workforce/timesheets" cols={[{ key: "work_date", fmt: "date" }, { key: "employee_no", label: "No." }, { key: "employee" }, { key: "site" }, { key: "hours", fmt: "num" }, { key: "source", label: "Source file" }, { key: "job_id", label: "Job #" }]} />
        <Resource title="Background jobs" endpoint="/admin/jobs" max={200} cols={[{ key: "id", label: "Job" }, { key: "kind" }, { key: "status", fmt: "status" }, { key: "created_at", fmt: "datetime" }, { key: "finished_at", fmt: "datetime" }, { key: "result", fmt: "json" }]} /></div>
    </>) },
    { key: "tasks", label: "Store tasks", render: () => (
      <Resource title="Store tasks" endpoint="/workforce/tasks" filters={[{ name: "status", label: "Status", default: "open", options: [{ value: "open", label: "Open" }, { value: "done", label: "Done" }, { value: "", label: "All" }] }]}
        cols={[{ key: "site" }, { key: "title" }, { key: "category", fmt: "status", tone: () => "mute" }, { key: "priority", fmt: "status" }, { key: "due_at", fmt: "datetime" }, { key: "overdue", fmt: "bool", tone: (r) => (r.overdue ? "bad" : "good") }, { key: "assignee" }, { key: "status", fmt: "status" }]}
        actions={[{ label: "New task", perm: WW, kind: "primary", fields: [{ name: "site_id", label: "Site", type: "select", required: true, options: SITE_OPTS }, { name: "title", required: true }, { name: "category", type: "select", default: "general", options: ["general", "availability", "compliance", "merchandising", "pricing"].map((x) => ({ value: x, label: x })) }, { name: "priority", type: "select", default: "normal", options: ["low", "normal", "high"].map((x) => ({ value: x, label: x })) }, { name: "due_at", type: "datetime" }], run: (v) => post("/workforce/tasks", { ...v, due_at: iso(v.due_at) }) }]}
        rowActions={[{ label: "Assign", perm: WW, show: (r) => r.status === "open", fields: [{ name: "assigned_to", label: "Employee", type: "select", required: true, options: EMP_OPTS }], run: (v, r) => post(`/workforce/tasks/${r.id}`, v) }, { label: "Complete", perm: WW, show: (r) => r.status === "open", run: (_, r) => post(`/workforce/tasks/${r.id}`, { complete: true }) }]} />) },
    { key: "maint", label: "Maintenance", render: () => (
      <Resource title="Equipment maintenance requests" endpoint="/workforce/maintenance" cols={[{ key: "site" }, { key: "equipment" }, { key: "description" }, { key: "priority", fmt: "status" }, { key: "status", fmt: "status" }, { key: "contractor_ref", label: "Contractor ref" }, { key: "raised_at", fmt: "datetime" }, { key: "closed_at", fmt: "datetime" }]}
        actions={[{ label: "Raise request", perm: WW, kind: "primary", fields: [{ name: "site_id", label: "Site", type: "select", required: true, options: SITE_OPTS }, { name: "equipment", required: true }, { name: "description", type: "textarea", required: true }, { name: "priority", type: "select", default: "normal", options: ["low", "normal", "urgent"].map((x) => ({ value: x, label: x })) }], run: (v) => post("/workforce/maintenance", v) }]}
        rowActions={[{ label: "Update", perm: WW, show: (r) => r.status !== "closed", fields: [{ name: "status", type: "select", required: true, options: ["assigned", "closed"].map((x) => ({ value: x, label: x })) }, { name: "contractor_ref" }], run: (v, r) => post(`/workforce/maintenance/${r.id}`, v) }]} />) },
  ]} />;
}

// ---------------------------------------------------------------- finance
function TrialBalance() {
  const { data } = useData<any>("/finance/trial-balance");
  if (!data) return null;
  return (
    <Card title="Trial balance" right={<Badge value={data.balanced ? "balanced" : "unbalanced"} />} pad={false}>
      <p className="border-b border-line px-3 py-2 text-xs text-ink-soft">{data.note}</p>
      <DataTable search={false} max={520} rows={data.accounts} cols={[{ key: "code" }, { key: "name", label: "Account" }, { key: "kind", fmt: "status", tone: () => "mute" }, { key: "debit", fmt: "money" }, { key: "credit", fmt: "money" }, { key: "balance", label: "Balance (Dr − Cr)", fmt: "money" }]} />
      <div className="num flex justify-end gap-6 border-t border-line px-3 py-2 text-xs font-semibold"><span>Total debits {gbp(data.total_debit)}</span><span>Total credits {gbp(data.total_credit)}</span></div>
    </Card>
  );
}
function WorkingCapital() {
  const { data } = useData<any>("/finance/working-capital");
  const pol = useData<any>("/finance/policies");
  return (<>
    {data && <Card title="Working capital" pad={false}><DataTable search={false} rows={data.items} cols={[{ key: "item" }, { key: "amount", render: (r) => <span className="num">{r.unit === "days" ? `${r.amount ?? "—"} days` : gbp(r.amount)}</span>, align: "right" }, { key: "definition" }, { key: "source" }]} /></Card>}
    {pol.data && <Card title="Accounting policies in force"><dl className="grid gap-x-6 gap-y-1 text-xs md:grid-cols-2">{Object.entries(pol.data.policy).map(([k, v]) => <div key={k} className="flex justify-between gap-3 border-b border-line/60 py-1"><dt className="font-semibold text-ink-soft">{k.replace(/_/g, " ")}</dt><dd className="text-right">{String(v)}</dd></div>)}</dl><p className="mt-2 text-[11px] text-ink-mute">{pol.data.note}</p></Card>}
  </>);
}
function Invoices() {
  const FW = ["finance.write"];
  const pos = useData<any[]>("/procurement/purchase-orders");
  const [po, setPo] = useState("");
  const [tick, setTick] = useState(0);
  const sel = (pos.data || []).find((p) => String(p.id) === po);
  return (<>
    <Card title="Register a supplier invoice" right={
      <><select aria-label="Purchase order" className="rounded-sm border border-line px-1 py-1 text-xs" value={po} onChange={(e) => setPo(e.target.value)}><option value="">— choose purchase order —</option>{(pos.data || []).filter((p) => ["received", "part_received"].includes(p.status)).map((p) => <option key={p.id} value={p.id}>{p.number} — {p.supplier} ({p.status.replace("_", " ")})</option>)}</select>
        {sel && <LinesButton label="Enter invoice" kind="primary" perm={FW} title={`Invoice against ${sel.number}`} onDone={() => setTick((t) => t + 1)}
          intro="Enter the invoice as the supplier sent it. Matching then compares it with the PO price and the quantity actually received."
          load={() => api(`/procurement/purchase-orders/${sel.id}`).then((d) => d.lines)} lineLabel={(l) => <span>{l.sku} {l.description}<span className="text-ink-mute"> · ordered {l.cases_ordered}, accepted {l.cases_received}, already invoiced {l.cases_invoiced}</span></span>}
          cols={[{ name: "cases", label: "Cases invoiced", default: (l) => l.cases_received - l.cases_invoiced }, { name: "case_cost", label: "Invoice case cost", default: (l) => l.case_cost }]}
          extra={[{ name: "invoice_no", label: "Invoice number", required: true }, { name: "invoice_date", label: "Invoice date", type: "date", required: true, default: new Date().toISOString().slice(0, 10) }, { name: "tax", label: "VAT on invoice", type: "number", default: "0.00", help: "Net is summed from the lines" }]}
          submit={(lines, ex) => { const ls = lines.filter(({ v }) => Number(v.cases) > 0).map(({ line, v }) => ({ po_line_id: line.id, cases: Number(v.cases), case_cost: String(v.case_cost) }));
            const net = ls.reduce((s, l) => s + Math.round(l.cases * Number(l.case_cost) * 100) / 100, 0);
            return post("/finance/invoices", { supplier_id: sel.supplier_id, po_id: sel.id, invoice_no: ex.invoice_no, invoice_date: ex.invoice_date, net: net.toFixed(2), tax: String(ex.tax || "0"), lines: ls }); }}
          done={(r) => `Invoice ${r.invoice_no} registered - now run the match`} />}</>}>
      <p className="text-xs text-ink-soft">Invoicing, goods receipt and payment are separate events. Receipt creates an accrual (goods received not invoiced); a clean three-way match converts it to a payable; approved payment clears the payable.</p>
    </Card>
    <div key={tick}>
      <Resource title="Supplier invoices" endpoint="/finance/invoices" detail={(r) => `/finance/invoices?status=`} detailTitle={() => "All invoices"}
        cols={[{ key: "invoice_no", label: "Invoice" }, { key: "supplier" }, { key: "po_number", label: "PO" }, { key: "invoice_date", fmt: "date" }, { key: "due_date", fmt: "date" }, { key: "net", fmt: "money" }, { key: "tax", label: "VAT", fmt: "money" }, { key: "gross", fmt: "money" }, { key: "status", fmt: "status" }, { key: "payment_status", label: "Payment", fmt: "status" },
          { key: "match_result", label: "Three-way match", render: (r) => (r.match_result ? (r.match_result.problems.length ? <ul className="max-w-md list-disc pl-4 text-[11px] text-action-dark">{r.match_result.problems.map((p: string, i: number) => <li key={i}>{p}</li>)}</ul> : <span className="text-[11px] text-ok">Quantity and price agree with PO and receipts (tolerance {r.match_result.tolerance_pct}%)</span>) : <span className="text-[11px] text-ink-mute">Not yet matched</span>) }]}
        rowActions={[{ label: "Run 3-way match", perm: FW, kind: "primary", show: (r) => ["received", "exception"].includes(r.status), run: (_, r) => post(`/finance/invoices/${r.id}/match`), done: (r) => (r.status === "matched" ? "Matched: payable posted" : `Mismatch: ${r.match_result.problems[0]}`) },
          { label: "Request payment", perm: FW, show: (r) => r.status === "matched", confirm: "Creates a payment request. A different person with payment-approval rights must release it.", run: (_, r) => post(`/finance/invoices/${r.id}/request-payment`) }]} />
    </div>
  </>);
}

export function Finance() {
  const FW = ["finance.write"];
  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  return <Workspace title="Finance" subtitle="A balanced double-entry demonstration subledger, three-way matching, cash and card reconciliation, budgets and working capital. GBP; gross and net shown separately." tabs={[
    { key: "ledger", label: "Ledger", render: () => (<>
      <TrialBalance />
      <Resource title="Journal (most recent first)" endpoint="/finance/journal?limit=600" max={520} note="Each row links to its source document (type and number). Entries cannot be edited; a reversal is a new entry."
        filters={[{ name: "source_type", label: "Source", default: "", options: ["", "sale", "sale_return", "goods_receipt", "supplier_invoice", "supplier_payment", "settlement", "cash_reconciliation", "stock_waste", "stock_adjustment", "stock_expiry", "operating_cost", "opening_balance"].map((x) => ({ value: x, label: x ? x.replace(/_/g, " ") : "All" })) }]}
        cols={[{ key: "number", label: "Entry" }, { key: "entry_date", fmt: "date" }, { key: "source_type", label: "Source" }, { key: "source_id", label: "Doc #" }, { key: "description" }, { key: "account" }, { key: "account_name" }, { key: "site" }, { key: "debit", fmt: "money" }, { key: "credit", fmt: "money" }, { key: "memo" }]} />
    </>) },
    { key: "invoices", label: "Supplier invoices", render: () => <Invoices /> },
    { key: "suppliers", label: "Supplier balances", render: () => <Resource title="Supplier balances" endpoint="/finance/supplier-balances" cols={[{ key: "code" }, { key: "name", label: "Supplier" }, { key: "payment_terms_days", label: "Terms (d)", fmt: "int" }, { key: "received_not_invoiced", label: "Received, not invoiced", fmt: "money" }, { key: "unmatched_invoices", label: "Invoices not matched", fmt: "money" }, { key: "payable", label: "Payable (matched)", fmt: "money" }, { key: "overdue", fmt: "money" }, { key: "paid", fmt: "money" }]} /> },
    { key: "cards", label: "Card settlements", render: () => (
      <Resource title="Payment-provider settlements" endpoint="/finance/settlements" note="Importing a settlement pulls the provider's report for a business date and matches it line by line to our card payments. Only matched takings are cleared to bank, net of fees, on the settlement date."
        cols={[{ key: "batch_ref", label: "Batch" }, { key: "provider" }, { key: "business_date", fmt: "date" }, { key: "gross", label: "Provider gross", fmt: "money" }, { key: "refunds", fmt: "money" }, { key: "fees", fmt: "money" }, { key: "net", label: "Net paid", fmt: "money" }, { key: "ledger_gross", label: "Our ledger gross", fmt: "money" }, { key: "difference", fmt: "money" }, { key: "status", fmt: "status" }, { key: "unmatched", fmt: "json" }]}
        actions={[{ label: "Import settlement", perm: FW, kind: "primary", fields: [{ name: "business_date", type: "date", required: true, default: yesterday }], run: (v) => post("/finance/settlements/import", v), done: (r) => `${r.batch_ref}: ${r.status}` }]} />) },
    { key: "cash", label: "Store cash", render: () => (
      <Resource title="Store cash reconciliation" endpoint="/finance/cash-reconciliations" note="Expected cash = cash sales less cash refunds in the payments ledger for the store and date. Counting and banking posts the cash to bank; any difference goes to cash over/short and, above £5, raises an exception."
        cols={[{ key: "business_date", fmt: "date" }, { key: "site" }, { key: "expected", fmt: "money" }, { key: "counted", fmt: "money" }, { key: "variance", fmt: "money" }, { key: "status", fmt: "status" }, { key: "note" }]}
        actions={[{ label: "Count and bank", perm: FW, kind: "primary", fields: [{ name: "site_id", label: "Store", type: "select", required: true, options: STORE_OPTS }, { name: "business_date", type: "date", required: true, default: yesterday }, { name: "counted", label: "Cash counted (£)", type: "number", required: true }, { name: "note" }], run: (v) => post("/finance/cash-reconciliations", { ...v, counted: String(v.counted) }), done: (r) => (Number(r.variance) === 0 ? "Balanced and banked" : `Banked with a variance of ${gbp(r.variance)}`) }]} />) },
    { key: "budget", label: "Budget vs actual", render: () => (
      <Resource title="Budget versus actual — period to date" endpoint="/finance/budget-vs-actual" note="Budget to date is the period budget pro-rated by elapsed days. Actuals come from the journal. They are separate columns and are never blended."
        cols={[{ key: "site" }, { key: "metric", render: (r) => r.metric.replace(/_/g, " ") }, { key: "version", label: "Budget version" }, { key: "period_start", fmt: "date" }, { key: "period_end", fmt: "date" }, { key: "budget_full_period", label: "Budget (full period)", fmt: "money" }, { key: "budget_to_date", label: "Budget to date", fmt: "money" }, { key: "actual_to_date", label: "Actual to date", fmt: "money" },
          { key: "var", label: "Variance", align: "right", render: (r) => { const v = Number(r.actual_to_date) - Number(r.budget_to_date); const good = ["waste", "operating_costs"].includes(r.metric) ? v <= 0 : v >= 0; return <span className={`num font-semibold ${good ? "text-ok" : "text-action-dark"}`}>{v >= 0 ? "+" : "−"}{gbp(Math.abs(v))}</span>; } }]} />) },
    { key: "wc", label: "Working capital & policies", render: () => <WorkingCapital /> },
  ]} />;
}

// ---------------------------------------------------------------- administration
function Policies() {
  const { data, reload } = useData<any[]>("/admin/settings");
  return (
    <div className="space-y-3">
      <Notice tone="info">Policies are configuration, not code. Each change needs a reason and is written to the audit log with before and after values.</Notice>
      {(data || []).map((s) => (
        <Card key={s.key} title={s.key} right={<><Badge value={s.is_default ? "default" : "customised"} tone={s.is_default ? "mute" : "info"} />
          <ActionButton onDone={reload} action={{ label: "Edit", perm: "admin.write", fields: [{ name: "value", label: "Value (JSON)", type: "textarea", required: true, default: JSON.stringify(s.value, null, 2) }, { name: "reason", required: true }],
            run: async (v) => { let value; try { value = JSON.parse(v.value); } catch { throw new Error("Value must be valid JSON"); } return api(`/admin/settings/${s.key}`, { method: "PUT", body: { value, reason: v.reason } }); } }} /></>}>
          <p className="mb-1 text-xs text-ink-soft">{s.description}</p>
          <pre className="scroll-thin max-h-40 overflow-auto rounded-sm bg-gray-50 p-2 text-[11px]">{JSON.stringify(s.value, null, 2)}</pre>
        </Card>
      ))}
    </div>
  );
}
function Exports() {
  const toast = useToast();
  const dl = async (name: string) => {
    const r = await fetch(`/api/v1/admin/export/${name}`, { headers: { Authorization: `Bearer ${token.get()}` } });
    if (!r.ok) return toast("bad", (await r.json()).error?.message || "Export failed");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(await r.blob()); a.download = `${name}.csv`; a.click();
    toast("good", `${name}.csv exported — recorded in the audit log`);
  };
  return <Card title="Data exports"><p className="mb-2 text-xs text-ink-soft">Exports are limited to your site scope and every export is recorded in the audit log with the row count.</p><div className="flex gap-2">{["sales", "stock", "journal"].map((n) => <Button key={n} onClick={() => dl(n)}>Export {n} (CSV)</Button>)}</div></Card>;
}

export function Administration() {
  const { can } = useAuth();
  const roles = useData<any>(can("admin.read") ? "/admin/roles" : null);
  return <Workspace title="Administration" subtitle="Users, role grants by scope, policies, audit log, integration boundaries, outbox and background jobs." tabs={[
    { key: "users", label: "Users & access", perm: ["admin.read"], render: () => (<>
      <Resource title="Users" endpoint="/admin/users" note="A role is granted for a scope: everywhere, a business unit, a region or one site. Grants and revocations are requested here and take effect only when a second administrator approves them."
        cols={[{ key: "name" }, { key: "email" }, { key: "job_title" }, { key: "roles_text", label: "Roles (scope)" }, { key: "active", fmt: "bool" }]}
        rowActions={[{ label: "Request role change", perm: "admin.write", fields: [{ name: "role", type: "select", required: true, options: (roles.data?.roles || []).map((r: any) => ({ value: r.code, label: r.name })) },
          { name: "scope_type", type: "select", required: true, default: "global", options: [{ value: "global", label: "Everywhere" }, { value: "region", label: "One region" }, { value: "site", label: "One site" }] }, { name: "scope_id", label: "Region or site id (blank for everywhere)", type: "number" }, { name: "revoke", label: "Revoke instead of grant", type: "checkbox" }, { name: "justification", required: true }],
          run: (v, r) => post("/admin/role-grants", { user_id: r.id, role: v.role, scope_type: v.scope_type, scope_id: v.scope_type === "global" ? null : v.scope_id, revoke: !!v.revoke, justification: v.justification }), done: () => "Request raised: awaiting a second administrator" }]} />
      {roles.data && <Card title="Role definitions" pad={false}><DataTable rows={roles.data.roles} cols={[{ key: "name", label: "Role" }, { key: "permission_count", label: "Permissions", fmt: "int" }, { key: "permissions", render: (r) => <span className="text-[11px] text-ink-soft">{r.permissions.join(", ")}</span> }]} /></Card>}
    </>) },
    { key: "policies", label: "Policies", perm: ["admin.read"], render: () => <Policies /> },
    { key: "audit", label: "Audit log", perm: ["audit.read"], render: () => (
      <Resource title="Audit log (append-only)" endpoint="/admin/audit?limit=500" max={560} filters={[{ name: "sensitive", label: "Show", default: "", options: [{ value: "", label: "All events" }, { value: "true", label: "Sensitive access and exports only" }] }]}
        cols={[{ key: "at", fmt: "datetime" }, { key: "user_email", label: "User" }, { key: "action" }, { key: "entity_type", label: "Record type" }, { key: "entity_id", label: "Record" }, { key: "sensitive", fmt: "bool", tone: (r) => (r.sensitive ? "warn" : "mute") }, { key: "detail", fmt: "json" }]} />) },
    { key: "integrations", label: "Integrations", perm: ["admin.read"], render: () => (<>
      <Resource title="Integration boundaries" endpoint="/admin/integrations" note="Every external system is reached through one documented interface. The implementations bundled here are simulators; none assumes any real retailer's endpoints." cols={[{ key: "name" }, { key: "interface" }, { key: "implementation" }, { key: "status", fmt: "status" }, { key: "note" }]} />
      <Resource title="Outbox events" endpoint="/admin/outbox" pick={(d) => d.events} max={260} note="Events are written in the same database transaction as the change that caused them, then relayed by the worker." cols={[{ key: "id" }, { key: "topic" }, { key: "key" }, { key: "created_at", fmt: "datetime" }, { key: "published_at", fmt: "datetime" }, { key: "attempts", fmt: "int" }, { key: "payload", fmt: "json" }]} />
      <Resource title="Integration deliveries" endpoint="/admin/outbox" pick={(d) => d.deliveries} max={260} cols={[{ key: "at", fmt: "datetime" }, { key: "adapter" }, { key: "topic" }, { key: "status", fmt: "status" }, { key: "response", fmt: "json" }]} />
    </>) },
    { key: "jobs", label: "Jobs & exports", perm: ["admin.read"], render: () => (<><Resource title="Background jobs" endpoint="/admin/jobs" cols={[{ key: "id", label: "Job" }, { key: "kind" }, { key: "status", fmt: "status" }, { key: "created_at", fmt: "datetime" }, { key: "started_at", fmt: "datetime" }, { key: "finished_at", fmt: "datetime" }, { key: "result", fmt: "json" }]} />{can("export") && <Exports />}</>) },
  ]} />;
}
