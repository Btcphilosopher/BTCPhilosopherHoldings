import React, { useState } from "react";
import { api, newKey } from "../api";
import { useAuth } from "../auth";
import { Basket, cleanBasket, LinesButton } from "../Lines";
import { ActionButton, DetailDrawer, post, Resource, Workspace } from "../Resource";
import { Badge, Button, Card, DataTable, fdatetime, gbp, Modal, Notice, useData, useToast } from "../ui";

function NewOrder({ onDone }: { onDone: () => void }) {
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const custs = useData<any[]>(open ? "/online/customers" : null);
  const slots = useData<any[]>(open ? "/online/slots" : null);
  const [c, setC] = useState(""); const [s, setS] = useState(""); const [tok, setTok] = useState("tok_ok");
  const [lines, setLines] = useState<any[]>([{ sku: "D2001", qty: 2 }, { sku: "B3001", qty: 1 }]);
  const [key, setKey] = useState(newKey()); const [err, setErr] = useState<string | null>(null);
  const go = async () => {
    setErr(null);
    try { const o = await post("/online/orders", { customer_id: Number(c), slot_id: Number(s), payment_token: tok, lines: cleanBasket(lines) }, key);
      toast(o.payment_status === "uncertain" ? "bad" : "good", `${o.number}: order ${o.order_status}, payment ${o.payment_status}${o.idempotent_replay ? " (replayed: no duplicate)" : ""}`); setOpen(false); setKey(newKey()); onDone(); }
    catch (e: any) { setErr(e.message); }
  };
  return (<>
    <Button kind="primary" onClick={() => setOpen(true)}>New test order</Button>
    {open && <Modal title="Place a test online order" onClose={() => setOpen(false)}>
      <div className="space-y-3">
        <p className="text-xs text-ink-soft">Stands in for the e-commerce platform calling <code>POST /api/v1/online/orders</code>. Pressing the button twice re-sends the same Idempotency-Key, so you get the same order and one authorisation.</p>
        <label className="block text-[11px] font-semibold text-ink-soft">Customer (synthetic)<select className="mt-1 w-full rounded-sm border border-line px-2 py-1.5 text-xs font-normal" value={c} onChange={(e) => setC(e.target.value)}><option value="">— select —</option>{(custs.data || []).map((x) => <option key={x.id} value={x.id}>{x.ref} — {x.name} · substitutions: {x.substitution_pref}</option>)}</select></label>
        <label className="block text-[11px] font-semibold text-ink-soft">Slot<select className="mt-1 w-full rounded-sm border border-line px-2 py-1.5 text-xs font-normal" value={s} onChange={(e) => setS(e.target.value)}><option value="">— select —</option>{(slots.data || []).map((x) => <option key={x.id} value={x.id} disabled={x.remaining <= 0}>{x.site} · {x.method} · {fdatetime(x.starts_at)} · {x.remaining} of {x.capacity} left</option>)}</select></label>
        <label className="block text-[11px] font-semibold text-ink-soft">Test payment outcome<select className="mt-1 w-full rounded-sm border border-line px-2 py-1.5 text-xs font-normal" value={tok} onChange={(e) => setTok(e.target.value)}><option value="tok_ok">tok_ok — authorised</option><option value="tok_declined">tok_declined — declined</option><option value="tok_timeout">tok_timeout — provider times out (outcome unknown)</option></select></label>
        <div><span className="mb-1 block text-[11px] font-semibold text-ink-soft">Items</span><Basket value={lines} onChange={setLines} withSub /></div>
        {err && <Notice tone="bad">{err}</Notice>}
        <div className="flex justify-end gap-2"><Button kind="ghost" onClick={() => setOpen(false)}>Cancel</Button><Button kind="primary" disabled={!c || !s} onClick={go}>Place order</Button></div>
      </div>
    </Modal>}
  </>);
}

function Orders() {
  const { can } = useAuth();
  const { data, reload, error } = useData<any[]>("/online/orders");
  const [open, setOpen] = useState<any>(null);
  const prods = useData<any[]>("/catalog/products");
  const subOpts = (prods.data || []).filter((p) => p.status === "active").map((p) => ({ value: p.sku, label: `${p.sku} ${p.name}` }));
  const W = ["online.write"];
  return (
    <Card title="Online orders" pad={false} right={<>{can("online.write", "service.write") && <NewOrder onDone={reload} />}<Button kind="ghost" onClick={reload}>↻ Refresh</Button></>}>
      <p className="border-b border-line px-3 py-2 text-xs text-ink-soft">Order, payment and fulfilment each have their own state. An order becomes a sale (and revenue) only at handover; the money arrives later, at settlement.</p>
      {error && <div className="p-3"><Notice tone="bad">{error}</Notice></div>}
      <DataTable rows={data || []} onRow={setOpen} cols={[{ key: "number" }, { key: "placed_at", fmt: "datetime" }, { key: "site" }, { key: "customer_ref", label: "Customer" }, { key: "method", fmt: "status" }, { key: "slot_start", label: "Slot", fmt: "datetime" },
        { key: "order_status", label: "Order", fmt: "status" }, { key: "payment_status", label: "Payment", fmt: "status" }, { key: "fulfilment_status", label: "Fulfilment", fmt: "status" }, { key: "gross_estimated", label: "Authorised", fmt: "money" }, { key: "gross_final", label: "Charged", fmt: "money" }, { key: "lines", fmt: "int" }, { key: "substitutions", label: "Subs", fmt: "int" }]}
        actions={(o) => (<>
          <ActionButton small onDone={reload} row={o} action={{ label: "Resolve payment", perm: ["online.write", "service.write", "finance.write"], kind: "primary", show: (r) => r.payment_status === "uncertain", confirm: "Asks the provider what happened to the original request (same key). No new charge is sent.", run: (_, r) => post(`/online/orders/${r.id}/resolve-payment`), done: (r) => `Payment is ${r.payment_status}` }} />
          <LinesButton label="Pick" perm={W} show={o.order_status === "confirmed" && o.fulfilment_status === "reserved"} title={`Pick ${o.number}`} onDone={reload}
            intro="Enter what was picked. For a shortfall you may offer a substitute if the customer allows it; they are charged the lower of the two prices and can refuse it at the door."
            load={() => api(`/online/orders/${o.id}`).then((d) => d.lines)} lineLabel={(l) => <span>{l.sku} {l.description} × {Number(l.qty)} <span className="text-ink-mute">· reserved {Number(l.reserved_qty)} · {l.allow_substitution ? "subs allowed" : "NO substitutions"}</span></span>}
            cols={[{ name: "picked_qty", label: "Picked", default: (l) => Number(l.reserved_qty) }, { name: "substitute_sku", label: "Substitute", type: "select", options: subOpts, width: "14rem" }]}
            submit={(lines) => post(`/online/orders/${o.id}/pick`, { lines: lines.map(({ line, v }) => ({ line_id: line.id, picked_qty: String(v.picked_qty || 0), substitute_sku: v.substitute_sku || null })) })} />
          <ActionButton small onDone={reload} row={o} action={{ label: "Dispatch", perm: W, show: (r) => r.fulfilment_status === "picked", run: (_, r) => post(`/online/orders/${r.id}/dispatch`) }} />
          <LinesButton label="Hand over" perm={W} kind="primary" show={["out_for_delivery", "ready_for_collection"].includes(o.fulfilment_status)} title={`Hand over ${o.number}`} onDone={reload}
            intro="Record the customer's decision on each substitution. Payment is captured for the final amount and the sale is recognised now."
            load={() => api(`/online/orders/${o.id}`).then((d) => d.lines.filter((l: any) => l.sub_product_id))} lineLabel={(l) => <span>{l.description} → <b>{l.sub_description}</b> at {gbp(l.sub_charged_price)} (shelf {gbp(l.sub_shelf_price)})</span>}
            cols={[{ name: "decision", label: "Customer decision", type: "select", options: [{ value: "accepted", label: "Accepted" }, { value: "rejected", label: "Rejected" }], default: () => "accepted", width: "10rem" }]}
            extra={[{ name: "failed_reason", label: "Delivery failed? Give the reason (leave blank if handed over)" }]}
            submit={(lines, ex, key) => post(`/online/orders/${o.id}/handover`, { substitution_decisions: Object.fromEntries(lines.map(({ line, v }) => [String(line.id), v.decision || "accepted"])), failed_reason: ex.failed_reason || null }, key)}
            done={(r) => `Order ${r.order_status}; payment ${r.payment_status}`} />
          <LinesButton label="Refund" perm={["service.write"]} show={!!o.gross_final && o.payment_status !== "refunded"} title={`Refund items on ${o.number}`} onDone={reload}
            load={() => api(`/online/orders/${o.id}`).then((d) => d.sale_lines.filter((l: any) => Number(l.qty) > Number(l.returned_qty)))} lineLabel={(l) => <span>{l.description} <span className="text-ink-mute">· {Number(l.qty) - Number(l.returned_qty)} refundable · paid {gbp(l.gross)}</span></span>}
            cols={[{ name: "qty", label: "Qty to refund", default: () => 0 }, { name: "disposition", label: "Goods", type: "select", default: () => "none", options: [{ value: "none", label: "Not returned" }, { value: "restock", label: "Returned: restock" }, { value: "damaged", label: "Returned: write off" }], width: "11rem" }]}
            extra={[{ name: "reason", label: "Reason", required: true }]}
            submit={(lines, ex, key) => post(`/online/orders/${o.id}/refunds`, { reason: ex.reason, lines: lines.filter(({ v }) => Number(v.qty) > 0).map(({ line, v }) => ({ sale_line_id: line.id, qty: String(v.qty), disposition: v.disposition || "none" })) }, key)}
            done={(r) => `Refunded ${gbp(r.return.gross)}`} />
          <ActionButton small onDone={reload} row={o} action={{ label: "Cancel", perm: ["online.write", "service.write"], kind: "danger", show: (r) => ["placed", "confirmed"].includes(r.order_status) && !["out_for_delivery", "ready_for_collection"].includes(r.fulfilment_status), fields: [{ name: "reason", required: true }], run: (v, r) => post(`/online/orders/${r.id}/cancel`, v) }} />
        </>)} />
      {open && <DetailDrawer path={`/online/orders/${open.id}`} title={`Online order ${open.number}`} onClose={() => setOpen(null)} />}
    </Card>
  );
}

export function OnlineOrders() {
  return <Workspace title="Online Orders" subtitle="Order ingestion, slot capacity, stock reservation, picking, substitutions, handover, cancellations, refunds and service cases. Customers and payments are synthetic." tabs={[
    { key: "orders", label: "Orders", render: () => <Orders /> },
    { key: "slots", label: "Slot capacity", render: () => <Resource title="Delivery and collection slots" endpoint="/online/slots" note="A slot is booked with a conditional update, so two simultaneous orders cannot both take the last place." cols={[{ key: "site" }, { key: "method", fmt: "status" }, { key: "starts_at", fmt: "datetime" }, { key: "ends_at", fmt: "time" }, { key: "capacity", fmt: "int" }, { key: "booked", fmt: "int" }, { key: "remaining", fmt: "int" }]} /> },
    { key: "cases", label: "Customer-service cases", render: () => (
      <Resource title="Customer-service cases" endpoint="/online/cases" cols={[{ key: "number" }, { key: "opened_at", fmt: "datetime" }, { key: "customer" }, { key: "order_number", label: "Order" }, { key: "category" }, { key: "subject" }, { key: "status", fmt: "status" }, { key: "notes", render: (r) => <ul className="max-w-md text-[11px] text-ink-soft">{(r.notes || []).map((n: any, i: number) => <li key={i}><b>{n.by}:</b> {n.text}</li>)}</ul> }]}
        actions={[{ label: "Open case", perm: ["service.write"], kind: "primary", fields: [{ name: "customer_id", label: "Customer", type: "select", options: { endpoint: "/online/customers", label: (c: any) => `${c.ref} — ${c.name}` } }, { name: "order_id", label: "Order", type: "select", options: { endpoint: "/online/orders", label: (o: any) => o.number } },
          { name: "category", type: "select", required: true, options: ["missing_item", "damaged_item", "late_delivery", "substitution", "refund_query", "other"].map((x) => ({ value: x, label: x.replace("_", " ") })) }, { name: "subject", required: true }, { name: "note", type: "textarea" }], run: (v) => post("/online/cases", v) }]}
        rowActions={[{ label: "Add note", perm: ["service.write"], show: (r) => r.status === "open", fields: [{ name: "text", type: "textarea", required: true }, { name: "close", label: "Close the case", type: "checkbox" }], run: (v, r) => post(`/online/cases/${r.id}/notes`, v) }]} />) },
    { key: "customers", label: "Customers", render: () => <Resource title="Customers (synthetic test accounts)" endpoint="/online/customers" cols={[{ key: "ref" }, { key: "name" }, { key: "substitution_pref", label: "Substitutions", fmt: "status" }, { key: "member_id", label: "Linked loyalty member #" }, { key: "synthetic", fmt: "bool" }]} /> },
  ]} />;
}

export function Loyalty() {
  const pol = useData<any>("/loyalty/policy");
  const integ = useData<any>("/loyalty/integrity");
  const LW = ["loyalty.write"];
  return <Workspace title="Loyalty" subtitle="Members, digital cards, a transactional points ledger, coupons, offers, expiry and communication preferences." tabs={[
    { key: "members", label: "Members", render: () => (<>
      {pol.data && <Notice tone="warn"><b>{pol.data.policy.label}.</b> {pol.data.notice} Earn {pol.data.policy.points_per_pound} point per £1 paid; each point worth £{pol.data.policy.point_value}; redeem in multiples of {pol.data.policy.redeem_multiple}; points lapse after {pol.data.policy.expiry_months_inactive} months without activity. External programme adapter: {pol.data.integration.note}.</Notice>}
      {integ.data && <Notice tone={integ.data.balanced ? "good" : "bad"}>Ledger check: {integ.data.balanced ? "every member's balance equals the sum of their ledger entries." : `${integ.data.mismatches.length} member balance(s) disagree with the ledger.`}</Notice>}
      <Resource title="Members" endpoint="/loyalty/members" detail={(r) => `/loyalty/members/${r.id}`}
        note="Membership identifies a shopper; it is not a login. Names and email are masked unless your role includes member personal data, and opening a member record is then audited."
        cols={[{ key: "member_no", label: "Member" }, { key: "display_name", label: "Name" }, { key: "status", fmt: "status" }, { key: "points_balance", label: "Points", fmt: "int" }, { key: "cards", fmt: "int" }, { key: "active_coupons", label: "Coupons", fmt: "int" }, { key: "comms_prefs", label: "Contact preferences", fmt: "json" }, { key: "joined_at", fmt: "date" }, { key: "last_activity_at", fmt: "datetime" }]}
        actions={[{ label: "Run expiry", perm: LW, confirm: "Expires all points of members with no activity for the policy period. Each expiry is a ledger entry.", run: () => post("/loyalty/expiry/run"), done: (r) => `${r.points_expired} points expired across ${r.members} member(s)` }]}
        rowActions={[{ label: "Goodwill points", perm: LW, fields: [{ name: "points", type: "number", required: true, help: "1 to 5,000" }, { name: "reason", required: true }], run: (v, r) => post(`/loyalty/members/${r.id}/adjust`, v) },
          { label: "Preferences", perm: ["loyalty.write", "service.write"], fields: (r) => ["email", "sms", "post"].map((k) => ({ name: k, label: `Contact by ${k}`, type: "checkbox" as const, default: !!r.comms_prefs?.[k] })), run: (v, r) => api(`/loyalty/members/${r.id}/preferences`, { method: "PUT", body: { email: !!v.email, sms: !!v.sms, post: !!v.post } }) },
          { label: "Issue coupon", perm: LW, fields: [{ name: "code", required: true }, { name: "amount_off", type: "number", required: true }, { name: "min_spend", type: "number", default: 0 }, { name: "description" }], run: (v, r) => post("/loyalty/coupons", { ...v, member_id: r.id }) }]} />
    </>) },
    { key: "coupons", label: "Coupons", render: () => <Resource title="Coupons" endpoint="/pricing/coupons" cols={[{ key: "code" }, { key: "description" }, { key: "amount_off", fmt: "money" }, { key: "min_spend", fmt: "money" }, { key: "member_no", label: "Member" }, { key: "status", fmt: "status" }, { key: "redeemed_at", fmt: "datetime" }]}
      actions={[{ label: "Issue open coupon", perm: LW, kind: "primary", fields: [{ name: "code", required: true }, { name: "amount_off", type: "number", required: true }, { name: "min_spend", type: "number", default: 0 }, { name: "description" }], run: (v) => post("/loyalty/coupons", v) }]} /> },
  ]} />;
}
