import React from "react";
import { Card, DataTable, Notice, useData } from "../ui";
import { Metric, MetricCard } from "./Overview";

export default function Analytics() {
  const { data, error } = useData<any>("/analytics/summary?days=14");
  if (error) return <Notice tone="bad">{error}</Notice>;
  if (!data) return <p className="text-xs text-ink-mute">Loading analytics…</p>;
  return (
    <div className="space-y-3">
      <div>
        <h1 className="text-lg font-bold text-brand-dark">Analytics</h1>
        <p className="text-xs text-ink-soft">Period: {data.period} · {data.currency}. Each measure shows its numerator, denominator and exclusions. Promotion uplift is only called an estimate where a control group exists.</p>
      </div>
      <div className="grid gap-3 xl:grid-cols-2">
        {data.metrics.map((m: Metric & { rows: any[] }) => (
          <Card key={m.key} pad={false}>
            <div className="grid gap-0 md:grid-cols-[16rem_1fr]">
              <div className="border-b border-line p-2 md:border-b-0 md:border-r"><MetricCard m={m} /></div>
              <div className="min-w-0">
                <dl className="space-y-0.5 border-b border-line/70 px-3 py-2 text-[11px] text-ink-soft">
                  <div><b>Numerator:</b> {m.numerator || "—"}</div><div><b>Denominator:</b> {m.denominator || "—"}</div><div><b>Exclusions:</b> {m.exclusions || "none"}</div>
                </dl>
                {m.rows?.length ? <DataTable search={false} max={220} rows={m.rows} cols={Object.keys(m.rows[0]).filter((k) => k !== "id").map((k) => ({ key: k, fmt: typeof m.rows[0][k] === "boolean" ? "bool" as const : undefined }))} /> : <p className="px-3 py-3 text-[11px] text-ink-mute">No breakdown rows for this measure.</p>}
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
