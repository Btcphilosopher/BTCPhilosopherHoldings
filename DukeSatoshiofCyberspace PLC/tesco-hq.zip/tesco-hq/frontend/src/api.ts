// Thin API client. The token lives in sessionStorage; no payment or card data ever passes through the browser.
const BASE = "/api/v1";

export class ApiError extends Error {
  constructor(public status: number, public code: string, message: string, public detail?: unknown) {
    super(message);
  }
}

export const token = {
  get: () => sessionStorage.getItem("thq.token"),
  set: (t: string | null) => (t ? sessionStorage.setItem("thq.token", t) : sessionStorage.removeItem("thq.token")),
};

export const newKey = () => (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random());

type Opts = { method?: string; body?: unknown; key?: string; form?: FormData };

export async function api<T = any>(path: string, opts: Opts = {}): Promise<T> {
  const headers: Record<string, string> = {};
  const t = token.get();
  if (t) headers.Authorization = `Bearer ${t}`;
  if (opts.key) headers["Idempotency-Key"] = opts.key;
  let body: BodyInit | undefined;
  if (opts.form) body = opts.form;
  else if (opts.body !== undefined) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(opts.body);
  }
  const res = await fetch(BASE + path, { method: opts.method || (body ? "POST" : "GET"), headers, body });
  const ct = res.headers.get("content-type") || "";
  const data = ct.includes("json") ? await res.json() : await res.text();
  if (!res.ok) {
    if (res.status === 401 && path !== "/auth/login") {
      token.set(null);
      window.dispatchEvent(new Event("thq:signout"));
    }
    const e = (data && data.error) || {};
    const msg = e.message || (data?.detail ? JSON.stringify(data.detail) : `Request failed (${res.status})`);
    throw new ApiError(res.status, e.code || "error", msg, e.detail);
  }
  return data as T;
}

const optCache = new Map<string, Promise<any[]>>();
export function options(endpoint: string): Promise<any[]> {
  if (!optCache.has(endpoint)) optCache.set(endpoint, api(endpoint).then((d) => (Array.isArray(d) ? d : d.sites || d.categories || [])).catch(() => []));
  return optCache.get(endpoint)!;
}
export const clearOptions = () => optCache.clear();
