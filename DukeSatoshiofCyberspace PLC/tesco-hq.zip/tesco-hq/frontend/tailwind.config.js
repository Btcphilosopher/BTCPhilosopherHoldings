/** Tesco-inspired palette (independent concept): blue, red, white on light-grey working surfaces. */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: { DEFAULT: "#00539F", dark: "#003A70", deep: "#002A52", light: "#E6EEF6" },
        action: { DEFAULT: "#EE1C2E", dark: "#C4101F", light: "#FDECEE" },
        surface: "#F2F4F6",
        ink: { DEFAULT: "#1B2733", soft: "#4A5A6A", mute: "#7A8896" },
        line: "#D8DEE4",
        ok: "#1F7A3D", warn: "#9A6200",
        series: { actual: "#00539F", budget: "#C26A00", forecast: "#00947F" },
      },
      fontFamily: { sans: ['"Inter"', "system-ui", "-apple-system", '"Segoe UI"', "Roboto", "Arial", "sans-serif"] },
    },
  },
  plugins: [],
};
