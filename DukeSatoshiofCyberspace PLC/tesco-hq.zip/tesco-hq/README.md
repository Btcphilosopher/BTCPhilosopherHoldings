# TESCO HQ — Enterprise Retail Platform

An integrated headquarters system for a large supermarket business: stores, a distribution centre,
suppliers, online retail and customer service, in one modular application.

> **Independent concept.** This is a Tesco-*inspired* design exercise. It is not affiliated with,
> endorsed by, or connected to Tesco PLC, and it has no access to any Tesco system, customer record or
> proprietary API. Every store, supplier, customer, employee, price and transaction in it is fictional.
> Loyalty rules are labelled demonstration policies and do not describe any real programme.

Generation model: Claude · Technology: Aureom.AI

## What is in the box

| Path | Contents |
|---|---|
| `backend/` | Python 3.12 · FastAPI · SQLAlchemy 2 · PostgreSQL · Redis. Modular monolith: `app/domains/<domain>/{models,service,api}.py` |
| `backend/alembic/` | Schema migration (102 tables) plus database-level guarantees (immutable ledgers, balanced journals) |
| `backend/app/worker.py` | Background worker: outbox relay, price-publication confirmation, forecasts, imports, housekeeping |
| `backend/app/adapters/` | Integration boundaries (interfaces) and their simulators: payments, POS, scanners, tracking, POD, HR, supplier EDI, loyalty |
| `backend/app/seed/` | Fictional master data, 14 days of trading history, and the 12-step demonstration scenario |
| `backend/tests/` | 39 automated tests against a real PostgreSQL database |
| `frontend/` | React 18 · TypeScript · Tailwind headquarters console (15 workspaces + approvals inbox) |
| `docs/` | Architecture, ERD, API reference, demonstration walkthrough and transcript, known limitations |
| `docker-compose.yml` | PostgreSQL, Redis, MinIO (object storage), API, worker, web |

## Run it with Docker

Requires Docker with Compose v2.

```bash
docker compose up --build
```

First start runs the migration and loads the demonstration data (about a minute). Then open:

* Console — http://localhost:8080
* API documentation (OpenAPI / Swagger) — http://localhost:8000/docs
* Object-storage console (MinIO) — http://localhost:9001

Sign in with any demonstration user; the password for all of them is `demo1234`. The sign-in page lists
them. Useful ones:

| User | Sees |
|---|---|
| `exec@thq.example` | Everything, read-only, all sites |
| `buyer@thq.example` / `procurement.manager@thq.example` | Raise purchase orders / approve them |
| `warehouse@thq.example` | Goods receipt, warehouse queue, routes — distribution centre only |
| `pricing.analyst@thq.example` / `pricing.manager@thq.example` | Propose prices and promotions / approve and publish |
| `store.ashbourne@thq.example` | One store: till, online picking, stock, rota |
| `finance.clerk@thq.example` / `finance.controller@thq.example` | Match invoices, request payments / approve payments |
| `service@thq.example`, `loyalty@thq.example`, `hr@thq.example`, `auditor@thq.example`, `admin@thq.example`, `security@thq.example` | Their function |

Other commands:

```bash
docker compose run --rm api pytest                     # run the test suite (uses the thq_test database)
```

```bash
docker compose run --rm api python -m app.seed --reset # wipe and rebuild the demonstration data
```

```bash
docker compose down -v                                 # stop and delete all data
```

## Run it without Docker

Requires PostgreSQL 14+, Python 3.12+, Node 20+. Redis is optional (the cache and worker wake-up fail soft).

```bash
createuser thq --pwprompt && createdb thq -O thq && createdb thq_test -O thq    # password: thq
```

```bash
cd backend && python -m venv .venv && . .venv/bin/activate && pip install -r requirements-dev.txt
```

```bash
export DATABASE_URL=postgresql+psycopg://thq:thq@localhost:5432/thq REDIS_URL=redis://localhost:6379/0
alembic upgrade head && python -m app.seed
```

```bash
uvicorn app.main:app --port 8000        # terminal 1
```

```bash
python -m app.worker                    # terminal 2 (same environment variables)
```

```bash
cd frontend && npm ci && npm run dev    # terminal 3 → http://localhost:5173 (proxies /api to :8000)
```

```bash
cd backend && TEST_DATABASE_URL=postgresql+psycopg://thq:thq@localhost:5432/thq_test pytest
```

Without `S3_ENDPOINT`, documents are stored in a local directory instead of object storage.

## Where to look first

1. **Executive Overview** — orders, completed sales, revenue, cash receipts, refunds, gross profit and
   inventory value as seven separate figures; each tile has *Definition* (formula, period, unit, source,
   numerator/denominator) and *View records* (the rows behind it). Actual, budget and forecast are
   separate series.
2. **Approvals & Exceptions** — the seeded scenario leaves purchase orders, a price change, a stock
   adjustment and a permission change waiting for a second person, and about sixty open exceptions.
3. **Pricing › Price simulator** — build a basket and read the rule trace that produced the total.
4. `docs/DEMO.md` — the 12-step walkthrough, with the console path for each step.

## Documentation

* `docs/ARCHITECTURE.md` — domain boundaries, consistency guarantees, permissions, metric definitions
* `docs/ERD.md` — entity-relationship diagrams (Mermaid), one per domain
* `docs/API.md` — versioned API reference and integration entry points
* `docs/DEMO.md` and `docs/DEMO_TRANSCRIPT.txt` — demonstration walkthrough and its recorded output
* `docs/LIMITATIONS.md` — what this is not, and what was and was not verified
