package com.example.core.model

enum class TradeUrgency { LOW_PASSIVE, MEDIUM, HIGH_AGGRESSIVE }

data class TradeIntent(
    val intentId: String,
    val sourceEngine: String, // e.g., "Curve.OS", "Treasury.OS", "Vol.OS", "Basis.OS", "Macro.OS"
    val strategyName: String,
    val instrumentId: String,
    val side: OrderSide,
    val quantity: Int,
    val targetPrice: Double? = null,
    val urgency: TradeUrgency = TradeUrgency.MEDIUM,
    val targetDv01Dollar: Double? = null,
    val notes: String = "",
    val timestampEpochMs: Long = System.currentTimeMillis()
)

enum class ExecutionAlgorithmType(val displayName: String) {
    TWAP("Time-Weighted Average Price"),
    VWAP("Volume-Weighted Average Price"),
    POV("Percentage of Volume"),
    IMPLEMENTATION_SHORTFALL("Implementation Shortfall"),
    ICEBERG("Iceberg Display Queue"),
    PASSIVE_LIMIT("Passive Pegging Limit"),
    AGGRESSIVE_LIMIT("Aggressive Cross Limit"),
    DIRECT_MARKET("Direct Market Route")
}

data class ExecutionPlan(
    val planId: String,
    val intentId: String,
    val instrumentId: String,
    val side: OrderSide,
    val totalQuantity: Int,
    val algoType: ExecutionAlgorithmType,
    val durationMinutes: Int,
    val sliceCount: Int,
    val quantityPerSlice: Int,
    val arrivalMidPrice: Double,
    val expectedImpactBps: Double,
    val targetVenue: String = "SIM_CME",
    val estimatedFeesUsd: Double
)

enum class AlgoExecutionStatus { PENDING, RUNNING, PAUSED, COMPLETED, CANCELLED }

data class AlgoSlice(
    val sliceIndex: Int,
    val scheduledTimeMs: Long,
    val targetQuantity: Int,
    val filledQuantity: Int = 0,
    val fillPrice: Double = 0.0,
    val orderId: String? = null,
    val status: String = "PENDING"
)

data class ActiveAlgoInstance(
    val planId: String,
    val name: String,
    val instrumentId: String,
    val side: OrderSide,
    val totalQuantity: Int,
    val algoType: ExecutionAlgorithmType,
    val filledQuantity: Int = 0,
    val averageExecutionPrice: Double = 0.0,
    val arrivalPrice: Double,
    val currentMarketMid: Double,
    val status: AlgoExecutionStatus = AlgoExecutionStatus.RUNNING,
    val slices: List<AlgoSlice> = emptyList(),
    val implementationShortfallBps: Double = 0.0,
    val startTimeMs: Long = System.currentTimeMillis()
)

data class SpreadLeg(
    val legIndex: Int,
    val instrumentId: String,
    val side: OrderSide,
    val ratio: Int = 1,
    val targetPrice: Double? = null
)

enum class StrategyOrderType(val displayName: String) {
    CALENDAR_SPREAD("Calendar Spread"),
    INTER_COMMODITY("Inter-Commodity Spread"),
    VERTICAL_SPREAD("Vertical Option Spread"),
    STRADDLE("Straddle"),
    STRANGLE("Strangle"),
    BUTTERFLY("Butterfly Spread"),
    CONDOR("Iron Condor"),
    CUSTOM_MULTI_LEG("User-Defined Strategy")
}

data class StrategyOrder(
    val strategyOrderId: String,
    val name: String,
    val strategyType: StrategyOrderType,
    val legs: List<SpreadLeg>,
    val netQuantity: Int,
    val targetNetPrice: Double,
    val filledQuantity: Int = 0,
    val status: String = "ACTIVE",
    val createdAtEpochMs: Long = System.currentTimeMillis()
)
