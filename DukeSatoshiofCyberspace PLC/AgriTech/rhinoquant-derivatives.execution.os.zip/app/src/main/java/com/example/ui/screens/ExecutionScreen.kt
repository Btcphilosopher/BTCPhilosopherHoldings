package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.ui.RhinoTerminalViewModel
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun ExecutionScreen(
    viewModel: RhinoTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val ticketState by viewModel.ticketState.collectAsState()
    val selectedInstId by viewModel.selectedInstrumentId.collectAsState()
    val orderBook by viewModel.activeOrderBook.collectAsState()
    val quotes by viewModel.quotes.collectAsState()
    val inst = InstrumentMaster.findById(selectedInstId) ?: InstrumentMaster.SOFR_Z6
    val currentQuote = quotes[selectedInstId]

    var lastSubmissionMessage by remember { mutableStateOf<String?>(null) }
    var lastSubmissionApproved by remember { mutableStateOf(true) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBlack)
            .padding(8.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Top Horizontal Instrument Selector Bar
        Text("SELECT DERIVATIVE INSTRUMENT", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = SteelDark)
        Spacer(modifier = Modifier.height(4.dp))
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(InstrumentMaster.ALL_INSTRUMENTS) { item ->
                val isSelected = item.instrumentId == selectedInstId
                val itemQuote = quotes[item.instrumentId]
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) RhinoSurfaceElevated else RhinoGraphite)
                        .border(1.dp, if (isSelected) RhinoGold else RhinoBorder, RoundedCornerShape(4.dp))
                        .clickable { viewModel.selectInstrument(item.instrumentId) }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = item.symbol,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) RhinoGold else SteelLight
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = item.exchange.code,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 8.sp,
                                color = SteelDark
                            )
                        }
                        if (itemQuote != null) {
                            Text(
                                text = "%.${item.pricePrecision}f".format(itemQuote.lastPrice),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (itemQuote.netChange >= 0) TerminalGreen else TerminalRed
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Selected Instrument Live Market Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(4.dp))
                .background(RhinoGraphite)
                .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(inst.name, fontFamily = FontFamily.SansSerif, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SteelLight)
                Text("Asset Class: ${inst.assetClass.displayName} • Mult: \$${inst.multiplier.toInt()} • Tick: ${inst.tickSize}", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = SteelDark)
            }
            if (currentQuote != null) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "%.${inst.pricePrecision}f".format(currentQuote.lastPrice),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (currentQuote.netChange >= 0) TerminalGreen else TerminalRed
                    )
                    Text(
                        text = "${if (currentQuote.netChange >= 0) "+" else ""}${"%.${inst.pricePrecision}f".format(currentQuote.netChange)} (%.2f%%)".format(currentQuote.percentChange),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = if (currentQuote.netChange >= 0) TerminalGreen else TerminalRed
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Main 2-Column Section: Order Ticket on Left, L2 Depth Book on Right
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // ORDER TICKET (LEFT)
            Column(
                modifier = Modifier
                    .weight(1.1f)
                    .clip(RoundedCornerShape(4.dp))
                    .background(RhinoGraphite)
                    .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("ORDER TICKET", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RhinoGold)
                    StatusBadge("SIMULATED")
                }

                Spacer(modifier = Modifier.height(8.dp))

                // BUY / SELL Toggle
                Row(modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(30.dp)
                            .clip(RoundedCornerShape(topStart = 4.dp, bottomStart = 4.dp))
                            .background(if (ticketState.side == OrderSide.BUY) TerminalGreen else RhinoSurfaceElevated)
                            .clickable { viewModel.updateTicketSide(OrderSide.BUY) }
                            .padding(4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("BUY / LONG", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (ticketState.side == OrderSide.BUY) RhinoBlack else SteelLight)
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(30.dp)
                            .clip(RoundedCornerShape(topEnd = 4.dp, bottomEnd = 4.dp))
                            .background(if (ticketState.side == OrderSide.SELL) TerminalRed else RhinoSurfaceElevated)
                            .clickable { viewModel.updateTicketSide(OrderSide.SELL) }
                            .padding(4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("SELL / SHORT", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (ticketState.side == OrderSide.SELL) RhinoBlack else SteelLight)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Order Type Selector
                Text("ORDER TYPE", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(OrderType.LIMIT, OrderType.MARKET, OrderType.STOP, OrderType.ICEBERG).forEach { ot ->
                        val isSel = ticketState.orderType == ot
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(3.dp))
                                .background(if (isSel) RhinoSurfaceElevated else RhinoBlack)
                                .border(1.dp, if (isSel) RhinoCyan else RhinoBorder, RoundedCornerShape(3.dp))
                                .clickable { viewModel.updateTicketOrderType(ot) }
                                .padding(vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(ot.displayName, fontFamily = FontFamily.Monospace, fontSize = 8.sp, fontWeight = FontWeight.SemiBold, color = if (isSel) RhinoCyan else SteelMedium)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Quantity Input & Quick Quantity Pills
                Text("QUANTITY (CONTRACTS)", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(10, 25, 50, 100, 250).forEach { q ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(3.dp))
                                .background(if (ticketState.quantity == q) RhinoGold else RhinoSurfaceElevated)
                                .clickable { viewModel.updateTicketQuantity(q) }
                                .padding(vertical = 3.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("$q", fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (ticketState.quantity == q) RhinoBlack else SteelLight)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Price Input (if Limit)
                if (ticketState.orderType != OrderType.MARKET) {
                    Text("LIMIT PRICE", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = ticketState.priceText,
                            onValueChange = { viewModel.updateTicketPrice(it) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp),
                            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = SteelLight, fontWeight = FontWeight.Bold),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = RhinoBlack,
                                unfocusedContainerColor = RhinoBlack,
                                focusedBorderColor = RhinoGold,
                                unfocusedBorderColor = RhinoBorder
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }

                // Time In Force
                Text("TIME IN FORCE", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(TimeInForce.DAY, TimeInForce.GTC, TimeInForce.IOC, TimeInForce.FOK).forEach { tif ->
                        val isSel = ticketState.timeInForce == tif
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(3.dp))
                                .background(if (isSel) RhinoSurfaceElevated else RhinoBlack)
                                .border(1.dp, if (isSel) SteelLight else RhinoBorder, RoundedCornerShape(3.dp))
                                .clickable { viewModel.updateTicketTif(tif) }
                                .padding(vertical = 3.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(tif.code, fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = if (isSel) SteelLight else SteelDark)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Pre-Trade Risk & Margin Analytics Box
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(RhinoBlack)
                        .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                        .padding(6.dp)
                ) {
                    Text("PRE-TRADE RISK VALIDATION", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = RhinoGold)
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Notional Value:", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = SteelDark)
                        Text("\$%,.2f".format(ticketState.calculatedNotional), fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = SteelLight)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Initial Margin Req:", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = SteelDark)
                        Text("\$%,.2f".format(ticketState.calculatedMargin), fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = RhinoAmber)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Est. Slippage:", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = SteelDark)
                        Text("%.2f bps".format(ticketState.expectedSlippageBps), fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = SteelMedium)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // SUBMIT ORDER BUTTON
                val btnColor = if (ticketState.side == OrderSide.BUY) TerminalGreen else TerminalRed
                Button(
                    onClick = {
                        val res = viewModel.submitOrderFromTicket()
                        if (res != null) {
                            val (ord, dec) = res
                            lastSubmissionApproved = dec.isApproved
                            lastSubmissionMessage = if (dec.isApproved) {
                                "ACKNOWLEDGED: ${ord.orderId} (${ord.state.name}) • ${ord.side} ${ord.quantity} @ ${ord.price} [${ord.venue}]"
                            } else {
                                "REJECTED: ${dec.reasonCode.code} • ${dec.message}"
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("submit_order_button"),
                    shape = RoundedCornerShape(4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = btnColor)
                ) {
                    Text(
                        text = "SUBMIT ${ticketState.side.name} ${ticketState.quantity} LOTS",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = RhinoBlack
                    )
                }

                if (lastSubmissionMessage != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (lastSubmissionApproved) TerminalGreenBg else TerminalRedBg)
                            .padding(6.dp)
                    ) {
                        Text(
                            text = lastSubmissionMessage!!,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 8.sp,
                            color = if (lastSubmissionApproved) TerminalGreen else TerminalRed
                        )
                    }
                }
            }

            // ORDER BOOK / L2 DEPTH LADDER (RIGHT)
            Column(
                modifier = Modifier
                    .weight(0.9f)
            ) {
                TerminalSectionHeader(title = "L2 DEPTH", subtitle = selectedInstId)
                OrderBookLadderView(
                    book = orderBook,
                    precision = inst.pricePrecision,
                    onPriceClick = { clickedPx ->
                        viewModel.updateTicketPrice("%.${inst.pricePrecision}f".format(clickedPx))
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Quick One-Click Execution Buttons
                Text("ONE-CLICK RAPID EXECUTION", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Button(
                        onClick = { viewModel.submitQuickOrder(selectedInstId, OrderSide.BUY, 25) },
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp),
                        shape = RoundedCornerShape(3.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = TerminalGreen.copy(alpha = 0.25f))
                    ) {
                        Text("+25 BUY", fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TerminalGreen)
                    }
                    Button(
                        onClick = { viewModel.submitQuickOrder(selectedInstId, OrderSide.SELL, 25) },
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp),
                        shape = RoundedCornerShape(3.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = TerminalRed.copy(alpha = 0.25f))
                    ) {
                        Text("-25 SELL", fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TerminalRed)
                    }
                }
            }
        }
    }
}
