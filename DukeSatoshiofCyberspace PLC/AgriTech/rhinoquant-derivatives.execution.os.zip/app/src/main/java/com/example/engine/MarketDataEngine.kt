package com.example.engine

import com.example.core.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.sin
import kotlin.random.Random

class MarketDataEngine(
    private val scope: CoroutineScope
) {
    private val _eventFlow = MutableSharedFlow<MarketDataEvent>(replay = 50, extraBufferCapacity = 500)
    val eventFlow: SharedFlow<MarketDataEvent> = _eventFlow.asSharedFlow()

    private val latestQuotes = ConcurrentHashMap<String, MarketQuote>()
    private var isOutageActive = false
    private var isHaltActive = false
    private var volatilityMultiplier = 1.0
    private var spreadMultiplier = 1.0

    private var tickJob: Job? = null

    init {
        initializeBaselineQuotes()
        startSyntheticTicker()
    }

    private fun initializeBaselineQuotes() {
        setQuote(
            MarketQuote(
                instrumentId = "SR3Z26",
                symbol = "SR3 Z6",
                bidPrice = 95.120,
                askPrice = 95.125,
                bidSize = 1450,
                askSize = 1820,
                lastPrice = 95.125,
                lastSize = 50,
                volume = 248500,
                openInterest = 890400,
                settlementPrice = 95.115,
                high = 95.160,
                low = 95.090,
                open = 95.105,
                prevClose = 95.110
            )
        )

        setQuote(
            MarketQuote(
                instrumentId = "SR3H27",
                symbol = "SR3 H7",
                bidPrice = 95.240,
                askPrice = 95.245,
                bidSize = 980,
                askSize = 1140,
                lastPrice = 95.240,
                lastSize = 100,
                volume = 185000,
                openInterest = 640000,
                settlementPrice = 95.235,
                high = 95.280,
                low = 95.210,
                open = 95.220,
                prevClose = 95.230
            )
        )

        setQuote(
            MarketQuote(
                instrumentId = "ZNZ26",
                symbol = "ZN Z6",
                bidPrice = 110.46875, // 110-15
                askPrice = 110.484375, // 110-15.5
                bidSize = 3200,
                askSize = 4100,
                lastPrice = 110.46875,
                lastSize = 25,
                volume = 1420000,
                openInterest = 3800000,
                settlementPrice = 110.4375,
                high = 110.65625,
                low = 110.3125,
                open = 110.375,
                prevClose = 110.421875
            )
        )

        setQuote(
            MarketQuote(
                instrumentId = "TNZ26",
                symbol = "TN Z6",
                bidPrice = 118.234375,
                askPrice = 118.250000,
                bidSize = 1800,
                askSize = 2200,
                lastPrice = 118.234375,
                lastSize = 50,
                volume = 720000,
                openInterest = 1950000,
                settlementPrice = 118.1875,
                high = 118.46875,
                low = 118.0625,
                open = 118.125,
                prevClose = 118.203125
            )
        )

        setQuote(
            MarketQuote(
                instrumentId = "ESZ26",
                symbol = "ES Z6",
                bidPrice = 5842.25,
                askPrice = 5842.50,
                bidSize = 85,
                askSize = 110,
                lastPrice = 5842.50,
                lastSize = 10,
                volume = 1120000,
                openInterest = 2400000,
                settlementPrice = 5835.00,
                high = 5865.50,
                low = 5820.25,
                open = 5830.00,
                prevClose = 5832.50
            )
        )

        setQuote(
            MarketQuote(
                instrumentId = "6EZ26",
                symbol = "6E Z6",
                bidPrice = 1.08450,
                askPrice = 1.08455,
                bidSize = 240,
                askSize = 310,
                lastPrice = 1.08450,
                lastSize = 5,
                volume = 320000,
                openInterest = 540000,
                settlementPrice = 1.08320,
                high = 1.08750,
                low = 1.08210,
                open = 1.08300,
                prevClose = 1.08350
            )
        )

        setQuote(
            MarketQuote(
                instrumentId = "CLZ26",
                symbol = "CL Z6",
                bidPrice = 71.45,
                askPrice = 71.47,
                bidSize = 150,
                askSize = 180,
                lastPrice = 71.45,
                lastSize = 2,
                volume = 490000,
                openInterest = 920000,
                settlementPrice = 70.85,
                high = 72.15,
                low = 70.50,
                open = 71.00,
                prevClose = 70.90
            )
        )

        setQuote(
            MarketQuote(
                instrumentId = "GCZ26",
                symbol = "GC Z6",
                bidPrice = 2654.80,
                askPrice = 2655.20,
                bidSize = 90,
                askSize = 120,
                lastPrice = 2655.00,
                lastSize = 1,
                volume = 280000,
                openInterest = 470000,
                settlementPrice = 2648.50,
                high = 2668.00,
                low = 2642.00,
                open = 2649.00,
                prevClose = 2646.00
            )
        )

        setQuote(
            MarketQuote(
                instrumentId = "SR3Z26C9525",
                symbol = "SR3 Z6 C 95.250",
                bidPrice = 0.080,
                askPrice = 0.085,
                bidSize = 450,
                askSize = 620,
                lastPrice = 0.080,
                lastSize = 20,
                volume = 48000,
                openInterest = 125000,
                settlementPrice = 0.075,
                high = 0.095,
                low = 0.065,
                open = 0.070,
                prevClose = 0.075
            )
        )

        setQuote(
            MarketQuote(
                instrumentId = "SR3Z26P9500",
                symbol = "SR3 Z6 P 95.000",
                bidPrice = 0.045,
                askPrice = 0.050,
                bidSize = 510,
                askSize = 730,
                lastPrice = 0.050,
                lastSize = 15,
                volume = 36000,
                openInterest = 98000,
                settlementPrice = 0.045,
                high = 0.060,
                low = 0.035,
                open = 0.040,
                prevClose = 0.045
            )
        )
    }

    private fun setQuote(quote: MarketQuote) {
        latestQuotes[quote.instrumentId] = quote
        scope.launch {
            _eventFlow.emit(MarketDataEvent.QuoteUpdate(quote.instrumentId, quote = quote))
        }
    }

    fun getQuote(instrumentId: String): MarketQuote? = latestQuotes[instrumentId]

    fun getAllQuotes(): List<MarketQuote> = latestQuotes.values.toList()

    private fun startSyntheticTicker() {
        tickJob?.cancel()
        tickJob = scope.launch(Dispatchers.Default) {
            var step = 0
            while (isActive) {
                delay(400) // 2.5 updates/sec across instruments
                if (isOutageActive || isHaltActive) continue

                step++
                for ((id, quote) in latestQuotes) {
                    val instrument = InstrumentMaster.findById(id) ?: continue
                    val tick = instrument.tickSize

                    // Microstructural price drift
                    val dice = Random.nextDouble()
                    if (dice < 0.45) {
                        val direction = if (Random.nextBoolean()) 1 else -1
                        val shift = direction * tick * (if (Random.nextDouble() < 0.15) 2 else 1) * volatilityMultiplier

                        val newMid = (quote.lastPrice + shift).coerceAtLeast(tick)
                        val baseSpread = (tick * spreadMultiplier).coerceAtLeast(tick)
                        val halfSpread = baseSpread / 2.0

                        val newBid = (newMid - halfSpread)
                        val newAsk = (newMid + halfSpread)
                        val newLast = if (direction > 0) newAsk else newBid
                        val newBidSize = (quote.bidSize + Random.nextInt(-30, 35)).coerceIn(50, 5000)
                        val newAskSize = (quote.askSize + Random.nextInt(-30, 35)).coerceIn(50, 5000)
                        val tradeSize = Random.nextInt(5, 75)

                        val updated = quote.copy(
                            bidPrice = newBid,
                            askPrice = newAsk,
                            bidSize = newBidSize,
                            askSize = newAskSize,
                            lastPrice = newLast,
                            lastSize = tradeSize,
                            volume = quote.volume + tradeSize,
                            high = maxOf(quote.high, newLast),
                            low = minOf(quote.low, newLast),
                            netChange = newLast - quote.prevClose,
                            percentChange = if (quote.prevClose > 0) ((newLast - quote.prevClose) / quote.prevClose) * 100.0 else 0.0,
                            timestampEpochMs = System.currentTimeMillis()
                        )
                        latestQuotes[id] = updated
                        _eventFlow.emit(MarketDataEvent.QuoteUpdate(id, quote = updated))

                        if (Random.nextDouble() < 0.2) {
                            _eventFlow.emit(
                                MarketDataEvent.TradeUpdate(
                                    instrumentId = id,
                                    tradePrice = newLast,
                                    tradeQuantity = tradeSize,
                                    aggressorSide = if (direction > 0) OrderSide.BUY else OrderSide.SELL
                                )
                            )
                        }
                    }
                }
            }
        }
    }

    // Stress scenarios
    fun injectFlashMove(instrumentId: String, pctChange: Double) {
        val curr = latestQuotes[instrumentId] ?: return
        val newPrice = curr.lastPrice * (1.0 + pctChange)
        val tick = InstrumentMaster.findById(instrumentId)?.tickSize ?: 0.01
        val updated = curr.copy(
            lastPrice = newPrice,
            bidPrice = newPrice - tick,
            askPrice = newPrice + tick,
            netChange = newPrice - curr.prevClose,
            percentChange = ((newPrice - curr.prevClose) / curr.prevClose) * 100.0,
            timestampEpochMs = System.currentTimeMillis()
        )
        setQuote(updated)
    }

    fun injectSpreadWidening(multiplier: Double) {
        spreadMultiplier = multiplier
        for ((id, quote) in latestQuotes) {
            val tick = InstrumentMaster.findById(id)?.tickSize ?: 0.01
            val halfSpread = (tick * multiplier) / 2.0
            val mid = (quote.bidPrice + quote.askPrice) / 2.0
            setQuote(quote.copy(bidPrice = mid - halfSpread, askPrice = mid + halfSpread))
        }
    }

    fun injectVolatilitySpike(multiplier: Double) {
        volatilityMultiplier = multiplier
    }

    fun injectMarketDataOutage(active: Boolean) {
        isOutageActive = active
    }

    fun injectTradingHalt(active: Boolean) {
        isHaltActive = active
        val stateName = if (active) "HALTED_LULD" else "CONTINUOUS_TRADING"
        scope.launch {
            for (id in latestQuotes.keys) {
                _eventFlow.emit(MarketDataEvent.SessionChange(id, sessionState = stateName))
            }
        }
    }

    fun resetStressState() {
        isOutageActive = false
        isHaltActive = false
        volatilityMultiplier = 1.0
        spreadMultiplier = 1.0
        initializeBaselineQuotes()
    }
}
