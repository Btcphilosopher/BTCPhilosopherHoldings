package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.ComponentHealthStatus
import com.example.ui.RhinoTerminalViewModel
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun CertificationScreen(
    viewModel: RhinoTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val certReport by viewModel.platformManager.certReport.collectAsState()
    val healthList by viewModel.platformManager.componentHealth.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBlack)
            .padding(8.dp)
    ) {
        TerminalSectionHeader(title = "EXCHANGE CONFORMANCE & SYSTEM HEALTH", subtitle = "CME Globex AutoCert+ Validation")

        // Subsystem Health Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            MetricBox(
                label = "SUBSYSTEMS",
                value = "${healthList.count { it.status == ComponentHealthStatus.UP }} / ${healthList.size} UP",
                subValue = "All Green",
                valueColor = TerminalGreen,
                modifier = Modifier.weight(1f)
            )
            MetricBox(
                label = "CONFORMANCE",
                value = "${certReport.passedCount} / ${certReport.totalTests} PASSED",
                subValue = certReport.certificationStatus,
                valueColor = if (certReport.isComplete) TerminalGreen else RhinoGold,
                modifier = Modifier.weight(1f)
            )
            MetricBox(
                label = "GATEWAY STATUS",
                value = "CERT-GATED",
                subValue = "Prod Blocked",
                valueColor = WarningYellow,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Certification Runner Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("AUTOMATED CONFORMANCE SUITE (12 TEST VECTORS)", fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = RhinoGold)
            Button(
                onClick = { viewModel.platformManager.runCertification() },
                modifier = Modifier.height(26.dp),
                shape = RoundedCornerShape(3.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RhinoGold)
            ) {
                Text("RUN CONFORMANCE SUITE", fontFamily = FontFamily.Monospace, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = RhinoBlack)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Conformance Test Vectors List
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(certReport.testCases, key = { it.testId }) { tc ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(3.dp))
                        .background(RhinoGraphite)
                        .border(1.dp, RhinoBorder, RoundedCornerShape(3.dp))
                        .padding(6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("${tc.testId}: ${tc.name}", fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SteelLight)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(tc.category, fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark)
                        }
                        Text(tc.description, fontFamily = FontFamily.SansSerif, fontSize = 8.sp, color = SteelMedium)
                        if (tc.logs.isNotEmpty()) {
                            Text(tc.logs, fontFamily = FontFamily.Monospace, fontSize = 7.sp, color = RhinoCyan)
                        }
                    }
                    StatusBadge(tc.result.name)
                }
            }
        }
    }
}
