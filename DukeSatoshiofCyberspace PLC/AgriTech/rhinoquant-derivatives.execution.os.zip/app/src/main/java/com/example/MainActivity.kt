package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.KillSwitchState
import com.example.ui.RhinoTerminalViewModel
import com.example.ui.TerminalTab
import com.example.ui.components.StatusBadge
import com.example.ui.screens.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private val viewModel: RhinoTerminalViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RhinoTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = RhinoBlack,
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    RhinoTerminalApp(
                        viewModel = viewModel,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun RhinoTerminalApp(
    viewModel: RhinoTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val currentTab by viewModel.currentTab.collectAsState()
    val killSwitchState by viewModel.platformManager.killSwitch.state.collectAsState()
    val accountState by viewModel.platformManager.accountMargin.collectAsState()
    val showKillModal by viewModel.showKillSwitchModal.collectAsState()

    var currentTimeStr by remember { mutableStateOf("") }
    val timeFmt = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }

    LaunchedEffect(Unit) {
        while (true) {
            currentTimeStr = timeFmt.format(Date())
            kotlinx.coroutines.delay(1000)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBlack)
    ) {
        // TOP INSTITUTIONAL HEADER BAR
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(RhinoGraphite)
                .border(width = 1.dp, color = RhinoBorder)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand & Environment
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (killSwitchState == KillSwitchState.TRADING) TerminalGreen else TerminalRed)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "RHINOQUANT",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = RhinoGold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "EXECUTION.OS",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = SteelLight
                )
                Spacer(modifier = Modifier.width(6.dp))
                StatusBadge("SIMULATED")
            }

            // Real-time PnL & Kill Switch
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Net PnL quick badge
                val pnl = accountState.unrealizedPnL + accountState.realizedPnL
                Text(
                    text = "${if (pnl >= 0) "+" else ""}\$%,.0f".format(pnl),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (pnl >= 0) TerminalGreen else TerminalRed
                )

                Spacer(modifier = Modifier.width(8.dp))

                // Kill Switch Action Button
                if (killSwitchState == KillSwitchState.KILLED) {
                    Button(
                        onClick = { viewModel.armKillSwitch() },
                        modifier = Modifier.height(24.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                        shape = RoundedCornerShape(2.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = WarningYellow)
                    ) {
                        Text("RESUME TRADING", fontFamily = FontFamily.Monospace, fontSize = 7.sp, fontWeight = FontWeight.Bold, color = RhinoBlack)
                    }
                } else {
                    Button(
                        onClick = { viewModel.showKillSwitchModal.value = true },
                        modifier = Modifier.height(24.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                        shape = RoundedCornerShape(2.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = TerminalRed)
                    ) {
                        Text("KILL SWITCH", fontFamily = FontFamily.Monospace, fontSize = 7.sp, fontWeight = FontWeight.Bold, color = RhinoBlack)
                    }
                }
            }
        }

        // NAVIGATION TABS BAR
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(RhinoBlack)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            TerminalTab.values().forEach { tab ->
                val isSelected = currentTab == tab
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(if (isSelected) RhinoGold else RhinoSurfaceElevated)
                        .border(1.dp, if (isSelected) RhinoGold else RhinoBorder, RoundedCornerShape(3.dp))
                        .clickable { viewModel.selectTab(tab) }
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tab.label,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) RhinoBlack else SteelLight,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }

        Divider(color = RhinoBorder, thickness = 1.dp)

        // ACTIVE SCREEN CONTENT
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            when (currentTab) {
                TerminalTab.EXECUTION -> ExecutionScreen(viewModel = viewModel)
                TerminalTab.BLOTTER -> BlotterScreen(viewModel = viewModel)
                TerminalTab.POSITIONS -> PositionsScreen(viewModel = viewModel)
                TerminalTab.MARKET -> MarketDepthScreen(viewModel = viewModel)
                TerminalTab.RISK -> RiskMarginScreen(viewModel = viewModel)
                TerminalTab.ALGOS -> AlgorithmsScreen(viewModel = viewModel)
                TerminalTab.RECONCILIATION -> ReconciliationScreen(viewModel = viewModel)
                TerminalTab.AUDIT -> AuditTrailScreen(viewModel = viewModel)
                TerminalTab.DEMOS -> SignatureDemosScreen(viewModel = viewModel)
                TerminalTab.CERTIFICATION -> CertificationScreen(viewModel = viewModel)
            }
        }
    }

    // Emergency Kill Switch Confirmation Dialog
    if (showKillModal) {
        AlertDialog(
            onDismissRequest = { viewModel.showKillSwitchModal.value = false },
            title = {
                Text(
                    text = "EMERGENCY DESK KILL SWITCH",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TerminalRed
                )
            },
            text = {
                Column {
                    Text(
                        text = "Activating the Master Kill Switch will immediately:\n1. Halt all new incoming order submissions\n2. Issue mass cancellations across all resting orders on all venues\n3. Record a critical regulatory event in the immutable audit log",
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 11.sp,
                        color = SteelLight
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.triggerKillSwitch() },
                    colors = ButtonDefaults.buttonColors(containerColor = TerminalRed)
                ) {
                    Text("TRIGGER KILL SWITCH", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = RhinoBlack)
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.showKillSwitchModal.value = false }) {
                    Text("CANCEL", fontFamily = FontFamily.Monospace, color = SteelMedium)
                }
            },
            containerColor = RhinoGraphite
        )
    }
}
