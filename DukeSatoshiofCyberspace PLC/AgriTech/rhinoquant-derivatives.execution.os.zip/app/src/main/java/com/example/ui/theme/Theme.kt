package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val RhinoDarkColorScheme = darkColorScheme(
    primary = RhinoGold,
    onPrimary = RhinoBlack,
    primaryContainer = RhinoSurfaceElevated,
    onPrimaryContainer = RhinoGoldLight,
    secondary = RhinoCyan,
    onSecondary = RhinoBlack,
    secondaryContainer = RhinoSurface,
    onSecondaryContainer = SteelLight,
    tertiary = SteelMedium,
    onTertiary = RhinoBlack,
    background = RhinoBlack,
    onBackground = SteelLight,
    surface = RhinoGraphite,
    onSurface = SteelLight,
    surfaceVariant = RhinoSurface,
    onSurfaceVariant = SteelMedium,
    outline = RhinoBorder,
    outlineVariant = RhinoBorderHighlight,
    error = TerminalRed,
    onError = RhinoBlack,
    errorContainer = TerminalRedBg,
    onErrorContainer = TerminalRed
)

@Composable
fun RhinoTheme(
    darkTheme: Boolean = true, // Force institutional dark theme by default
    content: @Composable () -> Unit
) {
    val colorScheme = RhinoDarkColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
