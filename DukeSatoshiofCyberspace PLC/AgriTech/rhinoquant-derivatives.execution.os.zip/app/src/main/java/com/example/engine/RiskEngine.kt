package com.example.engine

import com.example.core.model.*
import kotlin.math.abs

class RiskEngine(
    var policy: RiskPolicy = RiskPolicy()
) {
    fun evaluate(
        order: Order,
        instrument: Instrument,
        accountState: AccountMarginState,
        currentPosition: Position?,
        allPositions: List<Position>,
        quote: MarketQuote?,
        openOrdersCount: Int,
        killSwitchState: KillSwitchState
    ): RiskDecision {
        val startNanos = System.nanoTime()
        val violations = mutableListOf<RiskViolation>()

        // 1. Kill Switch Check
        if (killSwitchState == KillSwitchState.KILLED) {
            return RiskDecision(
                decision = RiskDecisionType.REJECTED,
                reasonCode = RiskReasonCode.KILL_SWITCH_ACTIVE,
                message = "Orders rejected: Master Kill Switch is currently KILLED.",
                latencyMicros = (System.nanoTime() - startNanos) / 1000
            )
        }
        if (killSwitchState == KillSwitchState.PAUSED) {
            return RiskDecision(
                decision = RiskDecisionType.REJECTED,
                reasonCode = RiskReasonCode.KILL_SWITCH_ACTIVE,
                message = "Orders paused: Platform is in PAUSED state.",
                latencyMicros = (System.nanoTime() - startNanos) / 1000
            )
        }

        // 2. Instrument Lifecycle Check
        if (!instrument.isTradable) {
            violations.add(
                RiskViolation(
                    ruleName = "InstrumentLifecycleRule",
                    reasonCode = RiskReasonCode.INSTRUMENT_EXPIRED,
                    currentValue = 0.0,
                    limitValue = 1.0,
                    message = "Contract ${instrument.symbol} is in state ${instrument.lifecycleState.displayName} and not eligible for trading."
                )
            )
        }

        // 3. Max Order Quantity Rule
        if (order.quantity > policy.maxOrderQuantity) {
            violations.add(
                RiskViolation(
                    ruleName = "MaxOrderQuantityRule",
                    reasonCode = RiskReasonCode.MAX_ORDER_QTY,
                    currentValue = order.quantity.toDouble(),
                    limitValue = policy.maxOrderQuantity.toDouble(),
                    message = "Order quantity ${order.quantity} exceeds max limit of ${policy.maxOrderQuantity} contracts."
                )
            )
        }

        // 4. Max Order Notional Rule
        val orderNotional = order.quantity * order.price * instrument.multiplier
        if (orderNotional > policy.maxOrderNotionalUsd) {
            violations.add(
                RiskViolation(
                    ruleName = "MaxOrderNotionalRule",
                    reasonCode = RiskReasonCode.MAX_ORDER_NOTIONAL,
                    currentValue = orderNotional,
                    limitValue = policy.maxOrderNotionalUsd,
                    message = "Order gross notional \$%,.2f exceeds per-order ceiling of \$%,.2f.".format(orderNotional, policy.maxOrderNotionalUsd)
                )
            )
        }

        // 5. Max Position Rule
        val currentQty = currentPosition?.quantity ?: 0
        val projectedQty = if (order.side == OrderSide.BUY) currentQty + order.quantity else currentQty - order.quantity
        if (abs(projectedQty) > policy.maxPositionQuantityPerInstrument) {
            violations.add(
                RiskViolation(
                    ruleName = "MaxPositionRule",
                    reasonCode = RiskReasonCode.MAX_POSITION_LIMIT,
                    currentValue = abs(projectedQty).toDouble(),
                    limitValue = policy.maxPositionQuantityPerInstrument.toDouble(),
                    message = "Projected position $projectedQty contracts breaches instrument limit of ${policy.maxPositionQuantityPerInstrument}."
                )
            )
        }

        // 6. Price Collar / Fat Finger Rule (Limit orders)
        if (quote != null && order.orderType == OrderType.LIMIT) {
            val mid = (quote.bidPrice + quote.askPrice) / 2.0
            if (mid > 0) {
                val deviationPct = (abs(order.price - mid) / mid) * 100.0
                if (deviationPct > policy.priceCollarPercent) {
                    violations.add(
                        RiskViolation(
                            ruleName = "PriceCollarRule",
                            reasonCode = RiskReasonCode.PRICE_COLLAR_VIOLATION,
                            currentValue = deviationPct,
                            limitValue = policy.priceCollarPercent,
                            message = "Order price ${order.price} deviates by %.2f%% from market mid %.3f (Collar max %.1f%%).".format(deviationPct, mid, policy.priceCollarPercent)
                        )
                    )
                }
            }
        }

        // 7. Max Open Orders Concurrency
        if (openOrdersCount >= policy.maxOpenOrders) {
            violations.add(
                RiskViolation(
                    ruleName = "MaxOpenOrdersRule",
                    reasonCode = RiskReasonCode.MAX_OPEN_ORDERS,
                    currentValue = openOrdersCount.toDouble(),
                    limitValue = policy.maxOpenOrders.toDouble(),
                    message = "Max open orders threshold reached ($openOrdersCount / ${policy.maxOpenOrders})."
                )
            )
        }

        // 8. Margin Availability Check
        val requiredMarginForOrder = order.quantity * instrument.initialMarginPerContract
        val availableMargin = accountState.availableMargin
        if (requiredMarginForOrder > availableMargin) {
            violations.add(
                RiskViolation(
                    ruleName = "MarginAvailabilityRule",
                    reasonCode = RiskReasonCode.INSUFFICIENT_MARGIN,
                    currentValue = requiredMarginForOrder,
                    limitValue = availableMargin,
                    message = "Required initial margin \$%,.2f exceeds available margin \$%,.2f.".format(requiredMarginForOrder, availableMargin)
                )
            )
        }

        // 9. Max Daily Loss Limit
        val dailyDrawdown = -(accountState.realizedPnL + accountState.unrealizedPnL)
        if (dailyDrawdown > policy.maxDailyLossLimitUsd) {
            violations.add(
                RiskViolation(
                    ruleName = "MaxDailyLossRule",
                    reasonCode = RiskReasonCode.MAX_DAILY_LOSS,
                    currentValue = dailyDrawdown,
                    limitValue = policy.maxDailyLossLimitUsd,
                    message = "Daily loss \$%,.2f breaches account max stop limit \$%,.2f.".format(dailyDrawdown, policy.maxDailyLossLimitUsd)
                )
            )
        }

        val elapsedMicros = (System.nanoTime() - startNanos) / 1000

        return if (violations.isEmpty()) {
            RiskDecision(
                decision = RiskDecisionType.APPROVED,
                reasonCode = RiskReasonCode.APPROVED,
                message = "Pre-trade risk verification passed ($elapsedMicros µs).",
                requiredMargin = requiredMarginForOrder,
                estimatedNotional = orderNotional,
                latencyMicros = elapsedMicros
            )
        } else {
            val primary = violations.first()
            RiskDecision(
                decision = RiskDecisionType.REJECTED,
                reasonCode = primary.reasonCode,
                message = primary.message,
                violations = violations,
                requiredMargin = requiredMarginForOrder,
                estimatedNotional = orderNotional,
                latencyMicros = elapsedMicros
            )
        }
    }

    fun computePortfolioRiskSnapshot(
        positions: List<Position>,
        accountState: AccountMarginState
    ): RiskSnapshot {
        var grossNotional = 0.0
        var netNotional = 0.0
        var totalDv01 = 0.0
        var totalDelta = 0.0
        var totalGamma = 0.0
        var totalVega = 0.0
        var totalTheta = 0.0
        var totalInitialMargin = 0.0

        for (pos in positions) {
            if (pos.quantity == 0) continue
            val instrument = InstrumentMaster.findById(pos.instrumentId) ?: continue
            val posNotional = abs(pos.quantity) * pos.currentMarketPrice * instrument.multiplier
            val signedNotional = pos.quantity * pos.currentMarketPrice * instrument.multiplier

            grossNotional += posNotional
            netNotional += signedNotional
            totalDv01 += pos.dv01
            totalDelta += pos.greeks.delta
            totalGamma += pos.greeks.gamma
            totalVega += pos.greeks.vega
            totalTheta += pos.greeks.theta
            totalInitialMargin += pos.initialMargin
        }

        // Parametric VaR (1-day 99% confidence = 2.326 * portfolio notional vol)
        val dailyVolEst = 0.0085 // 85 bps daily volatility
        val var99 = grossNotional * dailyVolEst * 2.326
        val expectedShortfall = var99 * 1.25 // Expected shortfall CVaR
        val stressLoss200bp = totalDv01 * 200.0 // 200bp instantaneous parallel shift

        val utilPct = if (accountState.totalEquity > 0) (totalInitialMargin / accountState.totalEquity) * 100.0 else 0.0

        return RiskSnapshot(
            grossNotionalUsd = grossNotional,
            netNotionalUsd = netNotional,
            portfolioDv01 = totalDv01,
            portfolioDelta = totalDelta,
            portfolioGamma = totalGamma,
            portfolioVega = totalVega,
            portfolioTheta = totalTheta,
            marginUsed = totalInitialMargin,
            marginUtilizationPct = utilPct,
            valueAtRisk1Day99Pct = var99,
            expectedShortfall99Pct = expectedShortfall,
            stressLoss200bpCurveShock = stressLoss200bp
        )
    }
}
