package com.example.engine

import com.example.core.model.*
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.min

class MatchingEngine {
    private val executionSequence = AtomicLong(1L)
    private val books = mutableMapOf<String, InternalBook>()

    data class QueuedOrder(
        val order: Order,
        val entryTimeNanos: Long = System.nanoTime(),
        var currentQuantity: Int = order.remainingQuantity,
        var currentDisplayQuantity: Int? = order.displayQuantity
    )

    private class InternalBook(val instrumentId: String) {
        // Bids sorted highest price first, then earliest time
        val bids = mutableListOf<QueuedOrder>()
        // Asks sorted lowest price first, then earliest time
        val asks = mutableListOf<QueuedOrder>()
    }

    private fun getOrCreateBook(instrumentId: String): InternalBook {
        return books.getOrPut(instrumentId) { InternalBook(instrumentId) }
    }

    @Synchronized
    fun match(order: Order, quote: MarketQuote? = null): MatchResult {
        val book = getOrCreateBook(order.instrumentId)
        val fills = mutableListOf<ExecutionFill>()
        var remainingQty = order.remainingQuantity
        var totalFilledQty = order.filledQuantity
        var totalNotional = order.averageFillPrice * order.filledQuantity

        val instrument = InstrumentMaster.findById(order.instrumentId)
        val multiplier = instrument?.multiplier ?: 1000.0

        if (order.orderType == OrderType.MARKET) {
            // Market orders match immediately against contra-side liquidity or synthetic quote
            val matchPrice = when (order.side) {
                OrderSide.BUY -> quote?.askPrice ?: order.price
                OrderSide.SELL -> quote?.bidPrice ?: order.price
            }

            val execId = generateExecutionId()
            val fill = ExecutionFill(
                executionId = execId,
                orderId = order.orderId,
                clientOrderId = order.clientOrderId,
                instrumentId = order.instrumentId,
                side = order.side,
                fillQuantity = remainingQty,
                fillPrice = matchPrice,
                liquidity = LiquidityIndicator.TAKER,
                fee = 0.75 * remainingQty,
                commission = 0.25 * remainingQty,
                environment = order.environment
            )
            fills.add(fill)
            totalNotional += matchPrice * remainingQty
            totalFilledQty += remainingQty
            remainingQty = 0

            return MatchResult(
                updatedOrder = order.copy(
                    state = OrderState.Filled,
                    filledQuantity = totalFilledQty,
                    remainingQuantity = 0,
                    averageFillPrice = if (totalFilledQty > 0) totalNotional / totalFilledQty else matchPrice,
                    fills = order.fills + fills,
                    updatedAtEpochMs = System.currentTimeMillis()
                ),
                fills = fills,
                orderBook = getPublicOrderBook(order.instrumentId, quote)
            )
        }

        // Limit Order Matching Logic
        if (order.side == OrderSide.BUY) {
            // Match against resting asks
            val askIterator = book.asks.iterator()
            while (askIterator.hasNext() && remainingQty > 0) {
                val resting = askIterator.next()
                if (resting.order.price <= order.price) {
                    val fillQty = min(remainingQty, resting.currentQuantity)
                    val execPrice = resting.order.price // Maker price rules

                    val fill = ExecutionFill(
                        executionId = generateExecutionId(),
                        orderId = order.orderId,
                        clientOrderId = order.clientOrderId,
                        instrumentId = order.instrumentId,
                        side = OrderSide.BUY,
                        fillQuantity = fillQty,
                        fillPrice = execPrice,
                        liquidity = LiquidityIndicator.TAKER,
                        fee = 0.75 * fillQty,
                        commission = 0.25 * fillQty,
                        environment = order.environment
                    )
                    fills.add(fill)
                    totalNotional += execPrice * fillQty
                    totalFilledQty += fillQty
                    remainingQty -= fillQty

                    resting.currentQuantity -= fillQty
                    if (resting.currentQuantity <= 0) {
                        askIterator.remove()
                    }
                } else {
                    break // Resting asks are ordered by price ascending
                }
            }

            // Also check if matches against top of simulated market ask
            if (remainingQty > 0 && quote != null && order.price >= quote.askPrice) {
                val simulatedFillQty = min(remainingQty, quote.askSize.coerceAtLeast(10))
                val execPrice = quote.askPrice
                val fill = ExecutionFill(
                    executionId = generateExecutionId(),
                    orderId = order.orderId,
                    clientOrderId = order.clientOrderId,
                    instrumentId = order.instrumentId,
                    side = OrderSide.BUY,
                    fillQuantity = simulatedFillQty,
                    fillPrice = execPrice,
                    liquidity = LiquidityIndicator.TAKER,
                    fee = 0.75 * simulatedFillQty,
                    commission = 0.25 * simulatedFillQty,
                    environment = order.environment
                )
                fills.add(fill)
                totalNotional += execPrice * simulatedFillQty
                totalFilledQty += simulatedFillQty
                remainingQty -= simulatedFillQty
            }

            // If quantity remains, rest on book (unless IOC/FOK)
            if (remainingQty > 0) {
                if (order.timeInForce == TimeInForce.IOC) {
                    // Cancel remainder
                    val avgPx = if (totalFilledQty > 0) totalNotional / totalFilledQty else 0.0
                    return MatchResult(
                        updatedOrder = order.copy(
                            state = if (totalFilledQty > 0) OrderState.PartiallyFilled else OrderState.Cancelled,
                            filledQuantity = totalFilledQty,
                            remainingQuantity = remainingQty,
                            averageFillPrice = avgPx,
                            fills = order.fills + fills,
                            updatedAtEpochMs = System.currentTimeMillis()
                        ),
                        fills = fills,
                        orderBook = getPublicOrderBook(order.instrumentId, quote)
                    )
                } else {
                    val queued = QueuedOrder(order.copy(remainingQuantity = remainingQty), currentQuantity = remainingQty)
                    book.bids.add(queued)
                    book.bids.sortByDescending { it.order.price }
                }
            }
        } else {
            // SELL Order
            val bidIterator = book.bids.iterator()
            while (bidIterator.hasNext() && remainingQty > 0) {
                val resting = bidIterator.next()
                if (resting.order.price >= order.price) {
                    val fillQty = min(remainingQty, resting.currentQuantity)
                    val execPrice = resting.order.price

                    val fill = ExecutionFill(
                        executionId = generateExecutionId(),
                        orderId = order.orderId,
                        clientOrderId = order.clientOrderId,
                        instrumentId = order.instrumentId,
                        side = OrderSide.SELL,
                        fillQuantity = fillQty,
                        fillPrice = execPrice,
                        liquidity = LiquidityIndicator.TAKER,
                        fee = 0.75 * fillQty,
                        commission = 0.25 * fillQty,
                        environment = order.environment
                    )
                    fills.add(fill)
                    totalNotional += execPrice * fillQty
                    totalFilledQty += fillQty
                    remainingQty -= fillQty

                    resting.currentQuantity -= fillQty
                    if (resting.currentQuantity <= 0) {
                        bidIterator.remove()
                    }
                } else {
                    break
                }
            }

            if (remainingQty > 0 && quote != null && order.price <= quote.bidPrice) {
                val simulatedFillQty = min(remainingQty, quote.bidSize.coerceAtLeast(10))
                val execPrice = quote.bidPrice
                val fill = ExecutionFill(
                    executionId = generateExecutionId(),
                    orderId = order.orderId,
                    clientOrderId = order.clientOrderId,
                    instrumentId = order.instrumentId,
                    side = OrderSide.SELL,
                    fillQuantity = simulatedFillQty,
                    fillPrice = execPrice,
                    liquidity = LiquidityIndicator.TAKER,
                    fee = 0.75 * simulatedFillQty,
                    commission = 0.25 * simulatedFillQty,
                    environment = order.environment
                )
                fills.add(fill)
                totalNotional += execPrice * simulatedFillQty
                totalFilledQty += simulatedFillQty
                remainingQty -= simulatedFillQty
            }

            if (remainingQty > 0) {
                if (order.timeInForce == TimeInForce.IOC) {
                    val avgPx = if (totalFilledQty > 0) totalNotional / totalFilledQty else 0.0
                    return MatchResult(
                        updatedOrder = order.copy(
                            state = if (totalFilledQty > 0) OrderState.PartiallyFilled else OrderState.Cancelled,
                            filledQuantity = totalFilledQty,
                            remainingQuantity = remainingQty,
                            averageFillPrice = avgPx,
                            fills = order.fills + fills,
                            updatedAtEpochMs = System.currentTimeMillis()
                        ),
                        fills = fills,
                        orderBook = getPublicOrderBook(order.instrumentId, quote)
                    )
                } else {
                    val queued = QueuedOrder(order.copy(remainingQuantity = remainingQty), currentQuantity = remainingQty)
                    book.asks.add(queued)
                    book.asks.sortBy { it.order.price }
                }
            }
        }

        val finalState = when {
            remainingQty == 0 -> OrderState.Filled
            totalFilledQty > 0 -> OrderState.PartiallyFilled
            else -> OrderState.Working
        }

        val avgPrice = if (totalFilledQty > 0) totalNotional / totalFilledQty else 0.0

        return MatchResult(
            updatedOrder = order.copy(
                state = finalState,
                filledQuantity = totalFilledQty,
                remainingQuantity = remainingQty,
                averageFillPrice = avgPrice,
                fills = order.fills + fills,
                updatedAtEpochMs = System.currentTimeMillis()
            ),
            fills = fills,
            orderBook = getPublicOrderBook(order.instrumentId, quote)
        )
    }

    @Synchronized
    fun cancelOrder(orderId: String, instrumentId: String): Boolean {
        val book = books[instrumentId] ?: return false
        val removedBid = book.bids.removeIf { it.order.orderId == orderId }
        val removedAsk = book.asks.removeIf { it.order.orderId == orderId }
        return removedBid || removedAsk
    }

    @Synchronized
    fun massCancelAll(): Int {
        var count = 0
        for (book in books.values) {
            count += book.bids.size + book.asks.size
            book.bids.clear()
            book.asks.clear()
        }
        return count
    }

    fun getPublicOrderBook(instrumentId: String, baseQuote: MarketQuote? = null): OrderBook {
        val book = books[instrumentId]
        val bidLevels = mutableListOf<PriceLevel>()
        val askLevels = mutableListOf<PriceLevel>()

        val baseBid = baseQuote?.bidPrice ?: 95.120
        val baseAsk = baseQuote?.askPrice ?: 95.125
        val instrument = InstrumentMaster.findById(instrumentId)
        val tick = instrument?.tickSize ?: 0.005

        // Populate synthetic background depth levels
        for (i in 0 until 5) {
            val pBid = baseBid - (i * tick)
            val pAsk = baseAsk + (i * tick)
            val qBid = (baseQuote?.bidSize ?: 120) + (i * 45) + (i * 12)
            val qAsk = (baseQuote?.askSize ?: 140) + (i * 38) + (i * 15)
            bidLevels.add(PriceLevel(pBid, qBid, 12 + i * 3))
            askLevels.add(PriceLevel(pAsk, qAsk, 14 + i * 4))
        }

        // Overlay resting user orders
        if (book != null) {
            for (queued in book.bids) {
                val existingIndex = bidLevels.indexOfFirst { kotlin.math.abs(it.price - queued.order.price) < 0.0001 }
                if (existingIndex >= 0) {
                    val curr = bidLevels[existingIndex]
                    bidLevels[existingIndex] = curr.copy(quantity = curr.quantity + queued.currentQuantity, orderCount = curr.orderCount + 1)
                } else {
                    bidLevels.add(PriceLevel(queued.order.price, queued.currentQuantity, 1))
                }
            }
            for (queued in book.asks) {
                val existingIndex = askLevels.indexOfFirst { kotlin.math.abs(it.price - queued.order.price) < 0.0001 }
                if (existingIndex >= 0) {
                    val curr = askLevels[existingIndex]
                    askLevels[existingIndex] = curr.copy(quantity = curr.quantity + queued.currentQuantity, orderCount = curr.orderCount + 1)
                } else {
                    askLevels.add(PriceLevel(queued.order.price, queued.currentQuantity, 1))
                }
            }
        }

        bidLevels.sortByDescending { it.price }
        askLevels.sortBy { it.price }

        return OrderBook(
            instrumentId = instrumentId,
            bids = bidLevels.take(5),
            asks = askLevels.take(5)
        )
    }

    private fun generateExecutionId(): String {
        val num = executionSequence.getAndIncrement()
        return "RHINO-SIM-%08d".format(num)
    }
}

data class MatchResult(
    val updatedOrder: Order,
    val fills: List<ExecutionFill>,
    val orderBook: OrderBook
)
