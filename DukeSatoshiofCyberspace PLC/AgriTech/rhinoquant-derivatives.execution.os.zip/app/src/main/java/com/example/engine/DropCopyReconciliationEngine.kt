package com.example.engine

import com.example.core.model.*
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs

class DropCopyReconciliationEngine {
    private val dropCopySequence = AtomicLong(50001L)
    private val dropCopyLog = mutableListOf<DropCopyMessage>()
    private val clearingRecords = mutableListOf<ClearingRecord>()
    private val reconLedger = ConcurrentHashMap<String, ReconciliationItem>()

    fun getDropCopyMessages(): List<DropCopyMessage> = synchronized(dropCopyLog) { dropCopyLog.toList() }
    fun getClearingRecords(): List<ClearingRecord> = synchronized(clearingRecords) { clearingRecords.toList() }
    fun getReconItems(): List<ReconciliationItem> = reconLedger.values.sortedByDescending { it.timestampEpochMs }

    @Synchronized
    fun onExecutionOccurred(fill: ExecutionFill, order: Order): ReconciliationItem {
        val seq = dropCopySequence.getAndIncrement()

        // 1. Emit independent Drop Copy message
        val dropCopy = DropCopyMessage(
            dropCopyId = "DC-GLBX-$seq",
            orderId = fill.orderId,
            executionId = fill.executionId,
            instrumentId = fill.instrumentId,
            side = fill.side,
            fillQuantity = fill.fillQuantity,
            fillPrice = fill.fillPrice,
            venueSequenceNumber = seq,
            clearingMemberId = "RHINO_CLEARING_001"
        )
        dropCopyLog.add(0, dropCopy)

        // 2. Generate simulated Clearing / Settlement record
        val instrument = InstrumentMaster.findById(fill.instrumentId)
        val multiplier = instrument?.multiplier ?: 1000.0
        val grossVal = fill.fillQuantity * fill.fillPrice * multiplier
        val clearing = ClearingRecord(
            tradeId = "CLR-${fill.executionId}",
            orderId = fill.orderId,
            instrumentId = fill.instrumentId,
            side = fill.side,
            quantity = fill.fillQuantity,
            price = fill.fillPrice,
            grossValue = grossVal,
            clearingFee = 0.50 * fill.fillQuantity,
            settlementDate = "T+1 (2026-12-16)"
        )
        clearingRecords.add(0, clearing)

        // 3. Perform 4-Way Reconciliation Match
        val item = perform4WayReconciliation(fill, dropCopy, clearing)
        reconLedger[fill.executionId] = item
        return item
    }

    private fun perform4WayReconciliation(
        fill: ExecutionFill,
        dropCopy: DropCopyMessage?,
        clearing: ClearingRecord?
    ): ReconciliationItem {
        val discrepancies = mutableListOf<String>()

        if (dropCopy == null) {
            discrepancies.add("Missing Drop Copy confirmation stream from venue")
        } else {
            if (dropCopy.fillQuantity != fill.fillQuantity) {
                discrepancies.add("Quantity mismatch: Internal ${fill.fillQuantity} vs DropCopy ${dropCopy.fillQuantity}")
            }
            if (abs(dropCopy.fillPrice - fill.fillPrice) > 0.00001) {
                discrepancies.add("Price mismatch: Internal ${fill.fillPrice} vs DropCopy ${dropCopy.fillPrice}")
            }
        }

        if (clearing == null) {
            discrepancies.add("Missing Clearing house trade record")
        } else {
            if (clearing.quantity != fill.fillQuantity) {
                discrepancies.add("Clearing qty mismatch: Internal ${fill.fillQuantity} vs Clearing ${clearing.quantity}")
            }
        }

        val status = when {
            discrepancies.isEmpty() -> ReconStatus.MATCHED
            dropCopy == null || clearing == null -> ReconStatus.MISSING_FILL
            else -> ReconStatus.MISMATCH
        }

        return ReconciliationItem(
            reconId = "REC-${fill.executionId}",
            orderId = fill.orderId,
            executionId = fill.executionId,
            internalFillQuantity = fill.fillQuantity,
            internalFillPrice = fill.fillPrice,
            dropCopyQuantity = dropCopy?.fillQuantity,
            dropCopyPrice = dropCopy?.fillPrice,
            clearingQuantity = clearing?.quantity,
            clearingPrice = clearing?.price,
            status = status,
            discrepancies = discrepancies
        )
    }

    // Ability to inject artificial discrepancy for testing
    fun injectDiscrepancy(executionId: String) {
        val existing = reconLedger[executionId] ?: return
        reconLedger[executionId] = existing.copy(
            status = ReconStatus.MISMATCH,
            dropCopyQuantity = existing.internalFillQuantity - 5,
            discrepancies = listOf("DropCopy reports 5 contracts unacknowledged at exchange gateway")
        )
    }
}
