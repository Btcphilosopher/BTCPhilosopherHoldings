package com.example.engine

import com.example.core.model.*
import com.example.venues.CmeSimulationVenue
import com.example.venues.MassCancelRequest
import com.example.venues.ReplaceRequest
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs

class TradingPlatformManager(
    private val scope: CoroutineScope
) {
    // Engine Subsystems
    val marketData = MarketDataEngine(scope)
    val matchingEngine = MatchingEngine()
    val riskEngine = RiskEngine()
    val marginEngine = MarginEngine()
    val positionPnl = PositionPnlEngine(marginEngine)
    val router = SmartOrderRouter()
    val slippageEngine = SlippageImpactEngine()
    val dropCopyRecon = DropCopyReconciliationEngine()
    val killSwitch = KillSwitchManager()
    val certificationEngine = CertificationEngine()
    val cmeVenue = CmeSimulationVenue()

    // State Flows
    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _positions = MutableStateFlow<List<Position>>(emptyList())
    val positions: StateFlow<List<Position>> = _positions.asStateFlow()

    private val _accountMargin = MutableStateFlow(AccountMarginState())
    val accountMargin: StateFlow<AccountMarginState> = _accountMargin.asStateFlow()

    private val _riskSnapshot = MutableStateFlow(RiskSnapshot())
    val riskSnapshot: StateFlow<RiskSnapshot> = _riskSnapshot.asStateFlow()

    private val _auditRecords = MutableStateFlow<List<AuditRecord>>(emptyList())
    val auditRecords: StateFlow<List<AuditRecord>> = _auditRecords.asStateFlow()

    private val _componentHealth = MutableStateFlow<List<ComponentHealth>>(emptyList())
    val componentHealth: StateFlow<List<ComponentHealth>> = _componentHealth.asStateFlow()

    private val _activeAlgos = MutableStateFlow<List<ActiveAlgoInstance>>(emptyList())
    val activeAlgos: StateFlow<List<ActiveAlgoInstance>> = _activeAlgos.asStateFlow()

    private val _certReport = MutableStateFlow(CertificationReport(testCases = certificationEngine.getDefaultTestCases()))
    val certReport: StateFlow<CertificationReport> = _certReport.asStateFlow()

    private val _activeStrategyOrders = MutableStateFlow<List<StrategyOrder>>(emptyList())
    val activeStrategyOrders: StateFlow<List<StrategyOrder>> = _activeStrategyOrders.asStateFlow()

    private val orderSequence = AtomicLong(1001L)
    private val auditSequence = AtomicLong(1L)
    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    // Idempotency cache: idempotencyKey -> Order
    private val idempotencyMap = ConcurrentHashMap<String, Order>()

    val algoEngine: AlgoExecutionEngine = AlgoExecutionEngine(scope) { planId, slice, instId, side, type ->
        handleAlgoSliceExecution(planId, slice, instId, side, type)
    }

    init {
        updateComponentHealthList()
        startMarketDataListener()
    }

    private fun startMarketDataListener() {
        scope.launch {
            marketData.eventFlow.collect { event ->
                if (event is MarketDataEvent.QuoteUpdate) {
                    // Update Mark-to-market on price tick
                    val updatedPositions = positionPnl.markToMarket(mapOf(event.instrumentId to event.quote))
                    _positions.value = updatedPositions

                    val updatedAccount = marginEngine.calculateMarginRequirements(updatedPositions, _accountMargin.value)
                    _accountMargin.value = updatedAccount

                    val snap = riskEngine.computePortfolioRiskSnapshot(updatedPositions, updatedAccount)
                    _riskSnapshot.value = snap
                }
            }
        }
    }

    private fun updateComponentHealthList() {
        _componentHealth.value = listOf(
            ComponentHealth("Market Data MDP 3.0", ComponentHealthStatus.UP, 120L, details = "2.5 updates/sec"),
            ComponentHealth("iLink3 Order Gateway", ComponentHealthStatus.UP, 145L, details = "TCP Connected / Seq: 1042"),
            ComponentHealth("Pre-Trade Risk Engine", ComponentHealthStatus.UP, 18L, details = "10 Active Rules Enforced"),
            ComponentHealth("Matching Engine SIM", ComponentHealthStatus.UP, 35L, details = "Price-Time FIFO Active"),
            ComponentHealth("Position & PnL Engine", ComponentHealthStatus.UP, 22L, details = "Real-time MTM & Greeks"),
            ComponentHealth("Margin Engine (SPAN)", ComponentHealthStatus.UP, 40L, details = "Spread Offsets Enabled"),
            ComponentHealth("Drop Copy Feed", ComponentHealthStatus.UP, 95L, details = "Independent FIX 4.4 Stream"),
            ComponentHealth("4-Way Reconciliation", ComponentHealthStatus.UP, 110L, details = "Ledger Reconciled")
        )
    }

    fun submitOrder(
        instrumentId: String,
        side: OrderSide,
        quantity: Int,
        price: Double,
        orderType: OrderType = OrderType.LIMIT,
        timeInForce: TimeInForce = TimeInForce.DAY,
        displayQuantity: Int? = null,
        idempotencyKey: String? = null,
        strategyId: String? = null
    ): Pair<Order, RiskDecision> {
        val entryNanos = System.nanoTime()

        // 1. Idempotency Check
        if (idempotencyKey != null && idempotencyMap.containsKey(idempotencyKey)) {
            val existing = idempotencyMap[idempotencyKey]!!
            logAudit("OrderManager", existing.orderId, "DUPLICATE_REQUEST_IDEMPOTENT", existing.state.name, existing.state.name, "Returned cached order for key $idempotencyKey")
            return Pair(existing, RiskDecision(RiskDecisionType.APPROVED, RiskReasonCode.APPROVED, "Idempotent duplicate returned"))
        }

        val instrument = InstrumentMaster.findById(instrumentId)
            ?: throw IllegalArgumentException("Unknown instrument: $instrumentId")

        val orderId = "RHINO-%08d".format(orderSequence.getAndIncrement())
        val clientOrderId = "CLO-${System.currentTimeMillis() % 1000000}"
        val quote = marketData.getQuote(instrumentId)

        // 2. State: CREATED -> VALIDATING
        var order = Order(
            orderId = orderId,
            clientOrderId = clientOrderId,
            instrumentId = instrumentId,
            side = side,
            quantity = quantity,
            price = price,
            orderType = orderType,
            timeInForce = timeInForce,
            displayQuantity = displayQuantity,
            strategyId = strategyId,
            state = OrderState.Created,
            idempotencyKey = idempotencyKey,
            latencies = OrderLatencies(apiEntryNanos = entryNanos)
        )

        logAudit("OrderManager", orderId, "ORDER_CREATED", null, "CREATED", "Side=$side, Qty=$quantity, Px=$price, Type=${orderType.name}")
        order = order.transitionTo(OrderState.Validating)

        // 3. PRE-TRADE RISK CHECK (MANDATORY GATEWAY INVARIANT)
        val riskStart = System.nanoTime()
        val openCount = _orders.value.count { it.isWorking }
        val decision = riskEngine.evaluate(
            order = order,
            instrument = instrument,
            accountState = _accountMargin.value,
            currentPosition = positionPnl.getPosition(instrumentId),
            allPositions = positionPnl.getPositions(),
            quote = quote,
            openOrdersCount = openCount,
            killSwitchState = killSwitch.state.value
        )
        val riskNanos = System.nanoTime()

        if (!decision.isApproved) {
            order = order.transitionTo(OrderState.Rejected, decision.message)
            order = order.copy(latencies = order.latencies.copy(riskNanos = riskNanos))
            addOrderToBlotter(order)
            logAudit("PreTradeRisk", orderId, "RISK_REJECTED", "VALIDATING", "REJECTED", "Reason: ${decision.reasonCode.code} - ${decision.message}", riskDecision = "REJECTED")
            return Pair(order, decision)
        }

        order = order.transitionTo(OrderState.RiskApproved)
        logAudit("PreTradeRisk", orderId, "RISK_APPROVED", "VALIDATING", "RISK_APPROVED", "Margin Req: \$${decision.requiredMargin}, Notional: \$${decision.estimatedNotional}", riskDecision = "APPROVED")

        // 4. SMART ORDER ROUTER
        val routingStart = System.nanoTime()
        order = order.transitionTo(OrderState.Routing)
        val routeDecision = router.route(instrument, side, quantity, quote)
        order = order.copy(venue = routeDecision.selectedVenueId)
        val routingNanos = System.nanoTime()
        logAudit("ExecutionRouter", orderId, "ORDER_ROUTED", "RISK_APPROVED", "ROUTING", "Venue=${order.venue} (${routeDecision.routingReason})")

        // 5. VENUE ACKNOWLEDGEMENT
        order = order.transitionTo(OrderState.Acknowledged)
        val ackNanos = System.nanoTime()

        // 6. MATCHING ENGINE MATCH & EXECUTION
        val matchStart = System.nanoTime()
        val matchResult = matchingEngine.match(order, quote)
        val matchEnd = System.nanoTime()

        var finalOrder = matchResult.updatedOrder.copy(
            latencies = order.latencies.copy(
                riskNanos = riskNanos,
                routingNanos = routingNanos,
                ackNanos = ackNanos,
                matchNanos = matchStart,
                fillNanos = matchEnd
            )
        )

        // Store idempotency key
        if (idempotencyKey != null) {
            idempotencyMap[idempotencyKey] = finalOrder
        }

        // 7. PROCESS FILLS -> UPDATE POSITIONS -> MARGIN -> P&L -> DROP COPY -> RECONCILIATION
        for (fill in matchResult.fills) {
            val updatedPos = positionPnl.applyFill(fill, quote)
            logAudit("MatchingEngine", orderId, "FILL_EXECUTED", "WORKING", finalOrder.state.name, "FillId=${fill.executionId}, Qty=${fill.fillQuantity} @ ${fill.fillPrice}, Fee=\$${fill.totalCost}")

            // Drop copy & 4-way reconciliation
            dropCopyRecon.onExecutionOccurred(fill, finalOrder)
            logAudit("DropCopy", orderId, "DROP_COPY_EMITTED", null, null, "Fix Msg seq emitted to clearing broker")
        }

        val allPos = positionPnl.getPositions()
        _positions.value = allPos

        val updatedAccount = marginEngine.calculateMarginRequirements(allPos, _accountMargin.value)
        _accountMargin.value = updatedAccount

        val snap = riskEngine.computePortfolioRiskSnapshot(allPos, updatedAccount)
        _riskSnapshot.value = snap

        addOrderToBlotter(finalOrder)

        logAudit("OrderManager", orderId, "ORDER_FINALIZED", "ACKNOWLEDGED", finalOrder.state.name, "Status=${finalOrder.state.name}, Filled=${finalOrder.filledQuantity}/${finalOrder.quantity}, Roundtrip: %.2fms".format(finalOrder.latencies.totalRoundtripMs))

        return Pair(finalOrder, decision)
    }

    fun cancelOrder(orderId: String): Boolean {
        val existing = _orders.value.find { it.orderId == orderId } ?: return false
        if (!existing.isWorking) return false

        val removed = matchingEngine.cancelOrder(orderId, existing.instrumentId)
        val cancelledOrder = existing.transitionTo(OrderState.Cancelled)
        addOrderToBlotter(cancelledOrder)
        logAudit("OrderManager", orderId, "ORDER_CANCELLED", existing.state.name, "CANCELLED", "User cancelled order from blotter")
        return true
    }

    fun replaceOrder(orderId: String, newQuantity: Int, newPrice: Double): Boolean {
        val existing = _orders.value.find { it.orderId == orderId } ?: return false
        if (!existing.isWorking) return false

        matchingEngine.cancelOrder(orderId, existing.instrumentId)
        val replacedOrder = existing.copy(
            quantity = newQuantity,
            price = newPrice,
            remainingQuantity = newQuantity - existing.filledQuantity,
            state = OrderState.Working,
            updatedAtEpochMs = System.currentTimeMillis()
        )
        addOrderToBlotter(replacedOrder)
        logAudit("OrderManager", orderId, "ORDER_REPLACED", existing.state.name, "WORKING", "Amended to Qty=$newQuantity @ Px=$newPrice")
        return true
    }

    fun massCancelAllWorkingOrders(reason: String = "Kill switch trigger"): Int {
        var count = 0
        val currentOrders = _orders.value
        for (ord in currentOrders) {
            if (ord.isWorking) {
                matchingEngine.cancelOrder(ord.orderId, ord.instrumentId)
                val cOrd = ord.transitionTo(OrderState.Cancelled)
                addOrderToBlotter(cOrd)
                logAudit("KillSwitch", ord.orderId, "MASS_CANCEL_EXECUTED", ord.state.name, "CANCELLED", "Reason: $reason")
                count++
            }
        }
        return count
    }

    private fun addOrderToBlotter(order: Order) {
        val current = _orders.value.toMutableList()
        val idx = current.indexOfFirst { it.orderId == order.orderId }
        if (idx >= 0) {
            current[idx] = order
        } else {
            current.add(0, order)
        }
        _orders.value = current
    }

    private fun logAudit(
        service: String,
        orderId: String?,
        eventType: String,
        oldState: String?,
        newState: String?,
        payload: String,
        riskDecision: String? = null
    ) {
        val record = AuditRecord(
            auditId = "AUD-%08d".format(auditSequence.getAndIncrement()),
            timestampFormatted = timeFormat.format(Date()),
            serviceName = service,
            orderId = orderId,
            eventType = eventType,
            oldState = oldState,
            newState = newState,
            payloadSummary = payload,
            riskDecision = riskDecision
        )
        val curr = _auditRecords.value.toMutableList()
        curr.add(0, record)
        if (curr.size > 200) {
            _auditRecords.value = curr.take(200)
        } else {
            _auditRecords.value = curr
        }
    }

    // Algorithmic execution helper
    private suspend fun handleAlgoSliceExecution(
        planId: String,
        slice: AlgoSlice,
        instrumentId: String,
        side: OrderSide,
        algoType: ExecutionAlgorithmType
    ) {
        val quote = marketData.getQuote(instrumentId)
        val tick = InstrumentMaster.findById(instrumentId)?.tickSize ?: 0.005
        val px = when (algoType) {
            ExecutionAlgorithmType.TWAP, ExecutionAlgorithmType.VWAP -> {
                // Passive or peg to best quote
                if (side == OrderSide.BUY) (quote?.askPrice ?: 95.125) else (quote?.bidPrice ?: 95.120)
            }
            ExecutionAlgorithmType.ICEBERG -> {
                if (side == OrderSide.BUY) (quote?.bidPrice ?: 95.120) else (quote?.askPrice ?: 95.125)
            }
            else -> quote?.lastPrice ?: 95.125
        }

        val (order, decision) = submitOrder(
            instrumentId = instrumentId,
            side = side,
            quantity = slice.targetQuantity,
            price = px,
            orderType = OrderType.LIMIT,
            strategyId = planId
        )

        if (order.isFilled || order.filledQuantity > 0) {
            algoEngine.updateSliceExecution(
                planId = planId,
                sliceIndex = slice.sliceIndex,
                fillQty = order.filledQuantity,
                fillPrice = order.averageFillPrice,
                orderId = order.orderId
            )
        }
        _activeAlgos.value = algoEngine.getActiveAlgos()
    }

    fun startAlgoExecution(
        name: String,
        instrumentId: String,
        side: OrderSide,
        totalQuantity: Int,
        algoType: ExecutionAlgorithmType,
        durationMinutes: Int = 10,
        sliceCount: Int = 10
    ): ActiveAlgoInstance {
        val quote = marketData.getQuote(instrumentId)
        val arrivalPx = quote?.let { (it.bidPrice + it.askPrice) / 2.0 } ?: 95.125
        val instance = algoEngine.startAlgo(
            name = name,
            instrumentId = instrumentId,
            side = side,
            totalQuantity = totalQuantity,
            algoType = algoType,
            durationMinutes = durationMinutes,
            sliceCount = sliceCount,
            arrivalPrice = arrivalPx
        )
        _activeAlgos.value = algoEngine.getActiveAlgos()
        logAudit("AlgoEngine", null, "ALGO_STARTED", null, "RUNNING", "Started $name ($totalQuantity lots) with $sliceCount slices")
        return instance
    }

    fun submitStrategyOrder(
        name: String,
        strategyType: StrategyOrderType,
        legs: List<SpreadLeg>,
        netQuantity: Int,
        targetNetPrice: Double
    ): StrategyOrder {
        val sId = "STRAT-${System.currentTimeMillis() % 100000}"
        val stratOrder = StrategyOrder(
            strategyOrderId = sId,
            name = name,
            strategyType = strategyType,
            legs = legs,
            netQuantity = netQuantity,
            targetNetPrice = targetNetPrice,
            filledQuantity = netQuantity,
            status = "FILLED"
        )

        // Execute each leg via the real pre-trade risk & matching pipeline
        for (leg in legs) {
            val inst = InstrumentMaster.findById(leg.instrumentId) ?: continue
            val quote = marketData.getQuote(leg.instrumentId)
            val legPx = leg.targetPrice ?: quote?.lastPrice ?: 95.125
            submitOrder(
                instrumentId = leg.instrumentId,
                side = leg.side,
                quantity = netQuantity * leg.ratio,
                price = legPx,
                orderType = OrderType.LIMIT,
                strategyId = sId
            )
        }

        val curr = _activeStrategyOrders.value.toMutableList()
        curr.add(0, stratOrder)
        _activeStrategyOrders.value = curr
        logAudit("StrategyEngine", sId, "STRATEGY_ORDER_FILLED", null, "FILLED", "Executed ${name} (${strategyType.displayName}) with ${legs.size} legs")
        return stratOrder
    }

    // 6 SIGNATURE DEMOS LAUNCHERS
    fun runDemo1SofrFutures() {
        val quote = marketData.getQuote("SR3Z26")
        val px = quote?.askPrice ?: 95.125
        submitOrder(
            instrumentId = "SR3Z26",
            side = OrderSide.BUY,
            quantity = 50,
            price = px,
            orderType = OrderType.LIMIT,
            strategyId = "DEMO_1_SOFR_CURVE"
        )
    }

    fun runDemo2TreasuryHedge() {
        // RhinoQuant Treasury.OS integration: Portfolio has +$18,500 DV01 long exposure
        // Needs -250 Ultra 10Y (TN) futures to neutralize DV01
        val quote = marketData.getQuote("TNZ26")
        val px = quote?.bidPrice ?: 118.234375
        submitOrder(
            instrumentId = "TNZ26",
            side = OrderSide.SELL,
            quantity = 188,
            price = px,
            orderType = OrderType.LIMIT,
            strategyId = "DEMO_2_TREASURY_HEDGE_DV01"
        )
    }

    fun runDemo3OptionsSpread() {
        // Vertical Call Spread: Buy SR3 Z6 Call 95.250 / Sell SR3 Z6 Call (represented by Put 95.000 or combo)
        submitStrategyOrder(
            name = "SOFR 3M Bull Call Spread",
            strategyType = StrategyOrderType.VERTICAL_SPREAD,
            legs = listOf(
                SpreadLeg(1, "SR3Z26C9525", OrderSide.BUY, ratio = 1, targetPrice = 0.085),
                SpreadLeg(2, "SR3Z26P9500", OrderSide.SELL, ratio = 1, targetPrice = 0.045)
            ),
            netQuantity = 100,
            targetNetPrice = 0.040
        )
    }

    fun runDemo4TwapAlgo() {
        startAlgoExecution(
            name = "SR3 Z6 Institutional 1,000 Lots TWAP",
            instrumentId = "SR3Z26",
            side = OrderSide.BUY,
            totalQuantity = 1000,
            algoType = ExecutionAlgorithmType.TWAP,
            durationMinutes = 20,
            sliceCount = 10
        )
    }

    fun runDemo5OutageRecovery() {
        scope.launch {
            logAudit("StressSimulator", null, "MARKET_DATA_OUTAGE_INJECTED", null, null, "Injecting simulated CME MDP 3.0 Multicast drop")
            marketData.injectMarketDataOutage(true)
            killSwitch.setTradingState(KillSwitchState.PAUSED, "SYSTEM_MONITOR", "Market data feed timeout > 500ms. Ingress paused.", 0)

            delay(1500)
            logAudit("FaultTolerance", null, "TCP_RECOVERY_INITIATED", null, null, "CME TCP Replay channel connected. Resending sequence gaps.")

            delay(1200)
            marketData.injectMarketDataOutage(false)
            killSwitch.setTradingState(KillSwitchState.TRADING, "SYSTEM_MONITOR", "Feed recovered. Heartbeat latency 115µs. Ingress restored.", 0)
            logAudit("FaultTolerance", null, "FEED_RESTORED", null, null, "All books and sequence numbers synchronized.")
        }
    }

    fun runDemo6MassCancelKillSwitch() {
        val affected = massCancelAllWorkingOrders("Emergency Desk Kill Switch Triggered")
        killSwitch.setTradingState(KillSwitchState.KILLED, "DESK_HEAD", "Desk kill switch activated", affected)
    }

    fun runCertification() {
        scope.launch {
            certificationEngine.runCertificationSuite { rep ->
                _certReport.value = rep
            }
        }
    }
}
