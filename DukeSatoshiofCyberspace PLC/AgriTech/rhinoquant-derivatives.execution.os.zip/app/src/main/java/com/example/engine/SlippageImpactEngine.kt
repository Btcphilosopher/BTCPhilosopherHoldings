package com.example.engine

import com.example.core.model.OrderSide
import kotlin.math.abs
import kotlin.math.sqrt

data class SlippageMetrics(
    val decisionPrice: Double,
    val arrivalPrice: Double,
    val executionPrice: Double,
    val marketVwap: Double,
    val implementationShortfallBps: Double,
    val spreadCostBps: Double,
    val modeledMarketImpactBps: Double,
    val timingCostBps: Double,
    val feeCostUsd: Double,
    val totalExecutionCostUsd: Double
)

class SlippageImpactEngine {

    fun calculateSlippageMetrics(
        side: OrderSide,
        decisionPrice: Double,
        arrivalPrice: Double,
        executionPrice: Double,
        marketVwap: Double,
        orderQuantity: Int,
        contractMultiplier: Double,
        dailyAdv: Double = 250_000.0,
        spreadBps: Double = 0.5,
        feePerContract: Double = 1.0
    ): SlippageMetrics {
        val sign = if (side == OrderSide.BUY) 1.0 else -1.0

        // Implementation Shortfall: (Execution - Decision) / Decision in basis points
        val isBps = if (decisionPrice > 0) {
            sign * ((executionPrice - decisionPrice) / decisionPrice) * 10_000.0
        } else 0.0

        // Spread Cost = Half spread in bps
        val spreadCost = spreadBps / 2.0

        // Modeled synthetic market impact: 0.1 * sigma * sqrt(Quantity / ADV)
        val participationRate = (orderQuantity.toDouble() / dailyAdv).coerceAtLeast(0.00001)
        val modeledImpactBps = 10.0 * sqrt(participationRate)

        // Timing cost = IS - Spread - Impact
        val timingCost = (isBps - spreadCost - modeledImpactBps).coerceAtLeast(0.0)

        val notional = orderQuantity * executionPrice * contractMultiplier
        val feeTotal = orderQuantity * feePerContract
        val slippageDollar = (abs(isBps) / 10_000.0) * notional
        val totalCostUsd = slippageDollar + feeTotal

        return SlippageMetrics(
            decisionPrice = decisionPrice,
            arrivalPrice = arrivalPrice,
            executionPrice = executionPrice,
            marketVwap = marketVwap,
            implementationShortfallBps = isBps,
            spreadCostBps = spreadCost,
            modeledMarketImpactBps = modeledImpactBps,
            timingCostBps = timingCost,
            feeCostUsd = feeTotal,
            totalExecutionCostUsd = totalCostUsd
        )
    }
}
