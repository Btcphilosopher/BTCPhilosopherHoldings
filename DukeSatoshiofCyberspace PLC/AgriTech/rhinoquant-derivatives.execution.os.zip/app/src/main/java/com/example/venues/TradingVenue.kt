package com.example.venues

import com.example.core.model.Order
import com.example.core.model.OrderSide
import com.example.core.model.OrderType
import com.example.core.model.TimeInForce

data class OrderAcknowledgement(
    val orderId: String,
    val clientOrderId: String,
    val venueOrderId: String,
    val accepted: Boolean,
    val message: String = "Order accepted at gateway",
    val timestampNanos: Long = System.nanoTime()
)

data class CancelResult(
    val orderId: String,
    val success: Boolean,
    val message: String
)

data class ReplaceRequest(
    val orderId: String,
    val newQuantity: Int,
    val newPrice: Double,
    val timestampEpochMs: Long = System.currentTimeMillis()
)

data class ReplaceResult(
    val orderId: String,
    val success: Boolean,
    val message: String,
    val amendedQuantity: Int,
    val amendedPrice: Double
)

data class MassCancelRequest(
    val accountId: String,
    val instrumentId: String? = null,
    val side: OrderSide? = null,
    val reason: String = "Kill switch trigger / Manual mass cancel"
)

data class MassCancelResult(
    val cancelledCount: Int,
    val orderIdsCancelled: List<String>,
    val timestampEpochMs: Long = System.currentTimeMillis()
)

interface TradingVenue {
    val venueId: String
    val isConnected: Boolean
    suspend fun connect()
    suspend fun disconnect()
    suspend fun submit(order: Order): OrderAcknowledgement
    suspend fun cancel(orderId: String): CancelResult
    suspend fun replace(request: ReplaceRequest): ReplaceResult
    suspend fun massCancel(request: MassCancelRequest): MassCancelResult
}
