package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.ui.RhinoTerminalViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun BlotterScreen(
    viewModel: RhinoTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val orders by viewModel.platformManager.orders.collectAsState()
    var filterState by remember { mutableStateOf("ALL") }
    var selectedOrderForDetail by remember { mutableStateOf<Order?>(null) }
    var orderToReplace by remember { mutableStateOf<Order?>(null) }

    val filteredOrders = remember(orders, filterState) {
        when (filterState) {
            "WORKING" -> orders.filter { it.isWorking }
            "FILLED" -> orders.filter { it.state is OrderState.Filled }
            "REJECTED" -> orders.filter { it.state is OrderState.Rejected }
            "CANCELLED" -> orders.filter { it.state is OrderState.Cancelled }
            else -> orders
        }
    }

    val timeFmt = remember { SimpleDateFormat("HH:mm:ss.SSS", Locale.US) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBlack)
            .padding(8.dp)
    ) {
        // Blotter Header & Summary Statistics
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("ORDER BLOTTER", fontFamily = FontFamily.Monospace, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = RhinoGold)
                Spacer(modifier = Modifier.width(8.dp))
                Text("(${orders.size} Total / ${orders.count { it.isWorking }} Working)", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = SteelDark)
            }

            // Mass cancel all button
            if (orders.any { it.isWorking }) {
                Button(
                    onClick = { viewModel.platformManager.massCancelAllWorkingOrders("User blotter mass cancel") },
                    modifier = Modifier.height(28.dp),
                    shape = RoundedCornerShape(3.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TerminalRed)
                ) {
                    Text("MASS CANCEL ALL", fontFamily = FontFamily.Monospace, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = RhinoBlack)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Filter Pills
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf("ALL", "WORKING", "FILLED", "REJECTED", "CANCELLED").forEach { f ->
                val isSel = filterState == f
                val count = when (f) {
                    "WORKING" -> orders.count { it.isWorking }
                    "FILLED" -> orders.count { it.state is OrderState.Filled }
                    "REJECTED" -> orders.count { it.state is OrderState.Rejected }
                    "CANCELLED" -> orders.count { it.state is OrderState.Cancelled }
                    else -> orders.size
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(if (isSel) RhinoGold else RhinoGraphite)
                        .border(1.dp, if (isSel) RhinoGold else RhinoBorder, RoundedCornerShape(3.dp))
                        .clickable { filterState = f }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "$f ($count)",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSel) RhinoBlack else SteelMedium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Table Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(RhinoSurfaceElevated)
                .padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("TIME / ID", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark, modifier = Modifier.weight(1.3f))
            Text("INSTRUMENT", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark, modifier = Modifier.weight(1.1f))
            Text("SIDE/QTY", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark, modifier = Modifier.weight(1.1f))
            Text("PRICE", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark, modifier = Modifier.weight(1.0f))
            Text("FILLED", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark, modifier = Modifier.weight(1.0f))
            Text("STATUS", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark, modifier = Modifier.weight(1.2f))
            Text("ACTION", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark, modifier = Modifier.weight(1.1f))
        }

        Spacer(modifier = Modifier.height(2.dp))

        if (filteredOrders.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(4.dp))
                    .background(RhinoGraphite)
                    .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("NO ORDERS MATCHING FILTER", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = SteelDark)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(filteredOrders, key = { it.orderId }) { order ->
                    val inst = InstrumentMaster.findById(order.instrumentId)
                    val sideColor = if (order.side == OrderSide.BUY) TerminalGreen else TerminalRed

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(RhinoGraphite)
                            .border(1.dp, if (selectedOrderForDetail?.orderId == order.orderId) RhinoGold else RhinoBorder, RoundedCornerShape(4.dp))
                            .clickable {
                                selectedOrderForDetail = if (selectedOrderForDetail?.orderId == order.orderId) null else order
                            }
                            .padding(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // TIME & ID
                            Column(modifier = Modifier.weight(1.3f)) {
                                Text(timeFmt.format(Date(order.createdAtEpochMs)), fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = SteelLight)
                                Text(order.orderId, fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark)
                            }

                            // INSTRUMENT
                            Column(modifier = Modifier.weight(1.1f)) {
                                Text(inst?.symbol ?: order.instrumentId, fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SteelLight)
                                Text(order.venue, fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark)
                            }

                            // SIDE & QTY
                            Column(modifier = Modifier.weight(1.1f)) {
                                Text(order.side.name, fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = sideColor)
                                Text("${order.quantity} lots", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelMedium)
                            }

                            // PRICE
                            Column(modifier = Modifier.weight(1.0f)) {
                                Text(
                                    if (order.orderType == OrderType.MARKET) "MKT" else "%.${inst?.pricePrecision ?: 3}f".format(order.price),
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = SteelLight
                                )
                                Text(order.orderType.displayName, fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark)
                            }

                            // FILLED
                            Column(modifier = Modifier.weight(1.0f)) {
                                Text("${order.filledQuantity}/${order.quantity}", fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (order.filledQuantity > 0) TerminalGreen else SteelMedium)
                                if (order.filledQuantity > 0) {
                                    Text("@ %.${inst?.pricePrecision ?: 3}f".format(order.averageFillPrice), fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = RhinoGold)
                                }
                            }

                            // STATUS
                            Box(modifier = Modifier.weight(1.2f)) {
                                StatusBadge(order.state.name)
                            }

                            // ACTION
                            Row(modifier = Modifier.weight(1.1f), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                if (order.isWorking) {
                                    Button(
                                        onClick = { viewModel.cancelOrder(order.orderId) },
                                        modifier = Modifier
                                            .height(24.dp)
                                            .padding(0.dp),
                                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                                        shape = RoundedCornerShape(2.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = TerminalRed)
                                    ) {
                                        Text("CXL", fontFamily = FontFamily.Monospace, fontSize = 7.sp, fontWeight = FontWeight.Bold, color = RhinoBlack)
                                    }
                                    Button(
                                        onClick = { orderToReplace = order },
                                        modifier = Modifier
                                            .height(24.dp)
                                            .padding(0.dp),
                                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                                        shape = RoundedCornerShape(2.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = RhinoCyan)
                                    ) {
                                        Text("RPL", fontFamily = FontFamily.Monospace, fontSize = 7.sp, fontWeight = FontWeight.Bold, color = RhinoBlack)
                                    }
                                }
                            }
                        }

                        // Expanded Detail Panel
                        if (selectedOrderForDetail?.orderId == order.orderId) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(RhinoBlack)
                                    .border(1.dp, RhinoBorder, RoundedCornerShape(3.dp))
                                    .padding(6.dp)
                            ) {
                                Text("TRANSACTION LATENCY & EXECUTION METRICS", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = RhinoGold)
                                Spacer(modifier = Modifier.height(2.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Roundtrip: %.2f ms".format(order.latencies.totalRoundtripMs), fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = RhinoCyan)
                                    Text("Client Order ID: ${order.clientOrderId}", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = SteelDark)
                                }
                                if (order.rejectionReason != null) {
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("Rejection Reason: ${order.rejectionReason}", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TerminalRed)
                                }
                                if (order.fills.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("EXECUTION FILLS (${order.fills.size}):", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelLight)
                                    order.fills.forEach { fill ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("${fill.executionId} • Qty: ${fill.fillQuantity} @ ${fill.fillPrice}", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TerminalGreen)
                                            Text("Fee: \$${fill.fee} • Comm: \$${fill.commission} [${fill.liquidity.name}]", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Replace Dialog
    if (orderToReplace != null) {
        val target = orderToReplace!!
        var editQty by remember { mutableStateOf(target.quantity.toString()) }
        var editPrice by remember { mutableStateOf(target.price.toString()) }

        AlertDialog(
            onDismissRequest = { orderToReplace = null },
            title = { Text("AMEND ORDER ${target.orderId}", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = RhinoGold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text("Instrument: ${target.instrumentId} • Side: ${target.side.name}", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = SteelLight)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = editQty,
                        onValueChange = { editQty = it },
                        label = { Text("New Quantity") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = editPrice,
                        onValueChange = { editPrice = it },
                        label = { Text("New Price") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val q = editQty.toIntOrNull() ?: target.quantity
                        val p = editPrice.toDoubleOrNull() ?: target.price
                        viewModel.replaceOrder(target.orderId, q, p)
                        orderToReplace = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RhinoCyan)
                ) {
                    Text("CONFIRM AMEND", fontFamily = FontFamily.Monospace, color = RhinoBlack)
                }
            },
            dismissButton = {
                TextButton(onClick = { orderToReplace = null }) {
                    Text("CANCEL", fontFamily = FontFamily.Monospace, color = SteelMedium)
                }
            },
            containerColor = RhinoGraphite
        )
    }
}
