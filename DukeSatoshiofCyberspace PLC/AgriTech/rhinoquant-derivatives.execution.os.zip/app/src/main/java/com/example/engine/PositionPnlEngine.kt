package com.example.engine

import com.example.core.model.*
import kotlin.math.*

class PositionPnlEngine(
    private val marginEngine: MarginEngine = MarginEngine()
) {
    private val positionsMap = mutableMapOf<String, Position>()

    fun getPositions(): List<Position> = positionsMap.values.toList()

    fun getPosition(instrumentId: String): Position? = positionsMap[instrumentId]

    @Synchronized
    fun applyFill(fill: ExecutionFill, currentQuote: MarketQuote?): Position {
        val instrument = InstrumentMaster.findById(fill.instrumentId)
            ?: throw IllegalArgumentException("Unknown instrument ${fill.instrumentId}")

        val existing = positionsMap[fill.instrumentId]
        val fillQtySigned = if (fill.side == OrderSide.BUY) fill.fillQuantity else -fill.fillQuantity
        val marketPrice = currentQuote?.lastPrice ?: fill.fillPrice

        val newPos = if (existing == null || existing.quantity == 0) {
            // New Position opened
            val newQty = fillQtySigned
            val (initM, maintM) = marginEngine.calculateSinglePositionMargin(instrument, newQty, marketPrice)
            val greeks = calculateGreeks(instrument, newQty, marketPrice)
            val dv01 = calculateDv01(instrument, newQty)

            Position(
                instrumentId = instrument.instrumentId,
                symbol = instrument.symbol,
                quantity = newQty,
                averageEntryPrice = fill.fillPrice,
                currentMarketPrice = marketPrice,
                realizedPnL = 0.0,
                unrealizedPnL = 0.0,
                dailyPnL = 0.0,
                initialMargin = initM,
                maintenanceMargin = maintM,
                feesPaid = fill.totalCost,
                greeks = greeks,
                dv01 = dv01,
                notionalValue = abs(newQty) * marketPrice * instrument.multiplier
            )
        } else {
            val oldQty = existing.quantity
            val oldAvg = existing.averageEntryPrice
            val newQty = oldQty + fillQtySigned

            val sameDirection = (oldQty > 0 && fillQtySigned > 0) || (oldQty < 0 && fillQtySigned < 0)

            var realizedDelta = 0.0
            val newAvg: Double

            if (sameDirection) {
                // Increasing existing position: Weighted average entry price
                val totalCostOld = abs(oldQty) * oldAvg
                val totalCostFill = abs(fillQtySigned) * fill.fillPrice
                newAvg = (totalCostOld + totalCostFill) / abs(newQty)
            } else {
                // Reducing or flipping position: Calculate realized PnL on closed quantity
                val closedQty = min(abs(oldQty), abs(fillQtySigned))
                val priceDiff = if (oldQty > 0) (fill.fillPrice - oldAvg) else (oldAvg - fill.fillPrice)
                realizedDelta = priceDiff * instrument.multiplier * closedQty

                newAvg = if (abs(newQty) == 0) 0.0 else if (abs(fillQtySigned) > abs(oldQty)) fill.fillPrice else oldAvg
            }

            val totalRealized = existing.realizedPnL + realizedDelta
            val unrealized = if (newQty == 0) 0.0 else {
                val diff = if (newQty > 0) (marketPrice - newAvg) else (newAvg - marketPrice)
                diff * instrument.multiplier * abs(newQty)
            }

            val (initM, maintM) = marginEngine.calculateSinglePositionMargin(instrument, newQty, marketPrice)
            val greeks = calculateGreeks(instrument, newQty, marketPrice)
            val dv01 = calculateDv01(instrument, newQty)

            existing.copy(
                quantity = newQty,
                averageEntryPrice = newAvg,
                currentMarketPrice = marketPrice,
                realizedPnL = totalRealized,
                unrealizedPnL = unrealized,
                dailyPnL = totalRealized + unrealized,
                initialMargin = initM,
                maintenanceMargin = maintM,
                feesPaid = existing.feesPaid + fill.totalCost,
                greeks = greeks,
                dv01 = dv01,
                notionalValue = abs(newQty) * marketPrice * instrument.multiplier,
                updatedAtEpochMs = System.currentTimeMillis()
            )
        }

        positionsMap[fill.instrumentId] = newPos
        return newPos
    }

    @Synchronized
    fun markToMarket(quotes: Map<String, MarketQuote>): List<Position> {
        val updatedList = mutableListOf<Position>()
        for ((instId, pos) in positionsMap) {
            if (pos.quantity == 0) {
                updatedList.add(pos)
                continue
            }
            val quote = quotes[instId] ?: continue
            val instrument = InstrumentMaster.findById(instId) ?: continue
            val marketPrice = quote.lastPrice

            val diff = if (pos.quantity > 0) (marketPrice - pos.averageEntryPrice) else (pos.averageEntryPrice - marketPrice)
            val unrealized = diff * instrument.multiplier * abs(pos.quantity)
            val greeks = calculateGreeks(instrument, pos.quantity, marketPrice)
            val dv01 = calculateDv01(instrument, pos.quantity)

            val updated = pos.copy(
                currentMarketPrice = marketPrice,
                unrealizedPnL = unrealized,
                dailyPnL = pos.realizedPnL + unrealized,
                greeks = greeks,
                dv01 = dv01,
                notionalValue = abs(pos.quantity) * marketPrice * instrument.multiplier,
                updatedAtEpochMs = System.currentTimeMillis()
            )
            positionsMap[instId] = updated
            updatedList.add(updated)
        }
        return updatedList
    }

    private fun calculateDv01(instrument: Instrument, quantity: Int): Double {
        return quantity * instrument.baseDv01PerContract
    }

    private fun calculateGreeks(instrument: Instrument, quantity: Int, spot: Double): OptionGreeks {
        if (!instrument.isOption || instrument.strike == null) {
            // Delta is 1.0 per contract for underlying futures
            return OptionGreeks(delta = quantity.toDouble())
        }

        val k = instrument.strike
        val t = 0.25 // ~3 months to expiration
        val sigma = 0.18 // 18% implied volatility
        val r = 0.045 // 4.5% risk-free rate

        val d1 = (ln(spot / k) + (r + 0.5 * sigma * sigma) * t) / (sigma * sqrt(t))
        val d2 = d1 - sigma * sqrt(t)

        val nd1 = standardNormalCdf(d1)
        val npd1 = standardNormalPdf(d1)

        val sign = if (quantity >= 0) 1.0 else -1.0
        val absQ = abs(quantity)

        val deltaPerContract = if (instrument.optionType == OptionType.CALL) nd1 else (nd1 - 1.0)
        val gammaPerContract = npd1 / (spot * sigma * sqrt(t))
        val vegaPerContract = spot * npd1 * sqrt(t) * 0.01
        val thetaPerContract = -(spot * npd1 * sigma) / (2 * sqrt(t)) * (1.0 / 365.0)

        return OptionGreeks(
            delta = deltaPerContract * quantity,
            gamma = gammaPerContract * quantity,
            vega = vegaPerContract * quantity,
            theta = thetaPerContract * quantity,
            rho = (if (instrument.optionType == OptionType.CALL) k * t * exp(-r * t) * standardNormalCdf(d2) else -k * t * exp(-r * t) * standardNormalCdf(-d2)) * 0.01 * quantity,
            impliedVol = sigma
        )
    }

    private fun standardNormalPdf(x: Double): Double = (1.0 / sqrt(2.0 * Math.PI)) * exp(-0.5 * x * x)

    private fun standardNormalCdf(x: Double): Double {
        val b1 = 0.319381530
        val b2 = -0.356563782
        val b3 = 1.781477937
        val b4 = -1.821255978
        val b5 = 1.330274429
        val p = 0.2316419
        val c = 0.39894228

        if (x >= 0.0) {
            val t = 1.0 / (1.0 + p * x)
            return (1.0 - c * exp(-x * x / 2.0) * t * (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1))
        } else {
            val t = 1.0 / (1.0 - p * x)
            return (c * exp(-x * x / 2.0) * t * (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1))
        }
    }
}
