package com.example.core.model

enum class ComponentHealthStatus { UP, DEGRADED, DOWN }

data class ComponentHealth(
    val name: String,
    val status: ComponentHealthStatus,
    val latencyMicros: Long,
    val lastHeartbeatMs: Long = System.currentTimeMillis(),
    val details: String = "Normal operation"
)

data class AuditRecord(
    val auditId: String,
    val timestampNanos: Long = System.nanoTime(),
    val timestampFormatted: String,
    val serviceName: String, // e.g. "PreTradeRisk", "OrderManager", "MatchingEngine", "DropCopy", "Recon"
    val accountId: String = "RHINO-TRADING-01",
    val orderId: String? = null,
    val eventType: String,
    val oldState: String? = null,
    val newState: String? = null,
    val payloadSummary: String,
    val riskDecision: String? = null,
    val venue: String = "SIM_CME"
)

enum class KillSwitchState {
    ARMED,     // Ready, monitoring, not triggered
    TRADING,   // Active trading authorized
    PAUSED,    // New orders held at gateway
    KILLED     // Emergency active: All working orders mass cancelled, ingress disabled
}
