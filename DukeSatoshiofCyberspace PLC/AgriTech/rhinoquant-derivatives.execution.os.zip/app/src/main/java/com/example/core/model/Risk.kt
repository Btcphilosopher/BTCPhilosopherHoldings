package com.example.core.model

enum class RiskDecisionType { APPROVED, REJECTED }

enum class RiskReasonCode(val code: String, val message: String) {
    APPROVED("APPROVED", "Pre-trade risk checks passed"),
    KILL_SWITCH_ACTIVE("KILL_SWITCH_ACTIVE", "Trading is halted via master kill switch"),
    ACCOUNT_SUSPENDED("ACCOUNT_SUSPENDED", "Trading account is suspended or read-only"),
    MAX_ORDER_QTY("MAX_ORDER_QUANTITY", "Order quantity exceeds maximum single order size limit"),
    MAX_ORDER_NOTIONAL("MAX_ORDER_NOTIONAL", "Order gross notional exceeds per-order ceiling limit"),
    MAX_POSITION_LIMIT("MAX_POSITION_LIMIT", "Execution would breach max position threshold for instrument"),
    MAX_GROSS_EXPOSURE("MAX_GROSS_EXPOSURE", "Account gross notional exposure limit exceeded"),
    MAX_NET_EXPOSURE("MAX_NET_EXPOSURE", "Account net directional exposure limit exceeded"),
    INSUFFICIENT_MARGIN("INSUFFICIENT_MARGIN", "Insufficient available margin balance for initial margin requirement"),
    MAX_DAILY_LOSS("MAX_DAILY_LOSS", "Account has breached maximum daily drawdown stop threshold"),
    PRICE_COLLAR_VIOLATION("PRICE_COLLAR_VIOLATION", "Order price deviates beyond fat-finger collar band from market mid"),
    INSTRUMENT_EXPIRED("INSTRUMENT_EXPIRED", "Derivative contract is expired or not in open trading state"),
    UNAUTHORIZED_INSTRUMENT("UNAUTHORIZED_INSTRUMENT", "Trader is not authorized for this asset class or product"),
    MAX_OPEN_ORDERS("MAX_OPEN_ORDERS", "Maximum working order concurrency limit reached for account"),
    CONCENTRATION_LIMIT("CONCENTRATION_LIMIT", "Order exceeds portfolio concentration limit for single asset")
}

data class RiskViolation(
    val ruleName: String,
    val reasonCode: RiskReasonCode,
    val currentValue: Double,
    val limitValue: Double,
    val message: String
)

data class RiskDecision(
    val decision: RiskDecisionType,
    val reasonCode: RiskReasonCode = RiskReasonCode.APPROVED,
    val message: String = "Risk checks passed",
    val violations: List<RiskViolation> = emptyList(),
    val requiredMargin: Double = 0.0,
    val estimatedNotional: Double = 0.0,
    val latencyMicros: Long = 18L
) {
    val isApproved: Boolean get() = decision == RiskDecisionType.APPROVED
}

data class RiskPolicy(
    val policyId: String = "INSTITUTIONAL_CORE_RATES",
    val maxOrderQuantity: Int = 2000,
    val maxOrderNotionalUsd: Double = 100_000_000.0,
    val maxPositionQuantityPerInstrument: Int = 5000,
    val maxGrossNotionalExposureUsd: Double = 250_000_000.0,
    val maxNetNotionalExposureUsd: Double = 100_000_000.0,
    val maxDailyLossLimitUsd: Double = 250_000.0,
    val priceCollarPercent: Double = 3.5, // % max deviation from mid for fat finger
    val maxOpenOrders: Int = 50,
    val maxSingleInstrumentConcentrationPct: Double = 60.0
)

data class RiskSnapshot(
    val timestampEpochMs: Long = System.currentTimeMillis(),
    val grossNotionalUsd: Double = 0.0,
    val netNotionalUsd: Double = 0.0,
    val portfolioDv01: Double = 0.0,
    val portfolioDelta: Double = 0.0,
    val portfolioGamma: Double = 0.0,
    val portfolioVega: Double = 0.0,
    val portfolioTheta: Double = 0.0,
    val marginUsed: Double = 0.0,
    val marginUtilizationPct: Double = 0.0,
    val valueAtRisk1Day99Pct: Double = 0.0, // 99% Parametric VaR
    val expectedShortfall99Pct: Double = 0.0,
    val stressLoss200bpCurveShock: Double = 0.0
)
