package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.RhinoTerminalViewModel
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun RiskMarginScreen(
    viewModel: RhinoTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val riskSnap by viewModel.platformManager.riskSnapshot.collectAsState()
    val accountState by viewModel.platformManager.accountMargin.collectAsState()
    val policy = viewModel.platformManager.riskEngine.policy

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBlack)
            .padding(8.dp)
            .verticalScroll(rememberScrollState())
    ) {
        TerminalSectionHeader(title = "PRE-TRADE RISK ENGINE & MARGIN (SPAN)", subtitle = "Microsecond Deterministic Verification")

        // Primary Risk Metrics Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            MetricBox(
                label = "GROSS NOTIONAL",
                value = "\$%,.0f".format(riskSnap.grossNotionalUsd),
                subValue = "Limit: \$%,.0f".format(policy.maxGrossNotionalExposureUsd),
                valueColor = SteelLight,
                modifier = Modifier.weight(1f)
            )
            MetricBox(
                label = "NET NOTIONAL",
                value = "${if (riskSnap.netNotionalUsd >= 0) "+" else ""}\$%,.0f".format(riskSnap.netNotionalUsd),
                subValue = "Limit: \$%,.0f".format(policy.maxNetNotionalExposureUsd),
                valueColor = RhinoGold,
                modifier = Modifier.weight(1f)
            )
            MetricBox(
                label = "1-DAY 99% VaR",
                value = "\$%,.0f".format(riskSnap.valueAtRisk1Day99Pct),
                subValue = "CVaR: \$%,.0f".format(riskSnap.expectedShortfall99Pct),
                valueColor = TerminalRed,
                modifier = Modifier.weight(1f)
            )
            MetricBox(
                label = "+200BP SHOCK",
                value = "-\$%,.0f".format(riskSnap.stressLoss200bpCurveShock),
                subValue = "Parallel Shift",
                valueColor = WarningYellow,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Pre-Trade Risk Rules Configuration & Limits Table
        Text("MANDATORY PRE-TRADE INVARIANTS & POLICIES", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RhinoGold)
        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(4.dp))
                .background(RhinoGraphite)
                .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            RiskRuleRow(name = "Single Order Size Ceiling", limit = "${policy.maxOrderQuantity} lots", status = "ENFORCED", latency = "12 µs")
            RiskRuleRow(name = "Single Order Max Notional", limit = "\$%,.0f".format(policy.maxOrderNotionalUsd), status = "ENFORCED", latency = "15 µs")
            RiskRuleRow(name = "Max Position Limit / Instrument", limit = "${policy.maxPositionQuantityPerInstrument} lots", status = "ENFORCED", latency = "18 µs")
            RiskRuleRow(name = "Fat-Finger Price Collar Band", limit = "±${policy.priceCollarPercent}% vs Market Mid", status = "ENFORCED", latency = "22 µs")
            RiskRuleRow(name = "Margin Exhaustion Guard", limit = "100% of Available Margin", status = "ENFORCED", latency = "25 µs")
            RiskRuleRow(name = "Daily Max Drawdown Stop", limit = "\$%,.0f".format(policy.maxDailyLossLimitUsd), status = "ENFORCED", latency = "14 µs")
            RiskRuleRow(name = "Max Working Orders Concurrency", limit = "${policy.maxOpenOrders} concurrent", status = "ENFORCED", latency = "10 µs")
            RiskRuleRow(name = "Master Kill Switch Invariant", limit = "Immediate Rejection on KILL", status = "ACTIVE", latency = "5 µs")
        }

        Spacer(modifier = Modifier.height(12.dp))

        // SPAN Margin Offsets & Portfolio Optimization Box
        Text("SPAN MARGIN & SPREAD DISCOUNT ENGINE", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RhinoGold)
        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(4.dp))
                .background(RhinoGraphite)
                .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Total Raw Initial Margin:", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = SteelMedium)
                Text("\$%,.2f".format(accountState.initialMarginRequired + accountState.portfolioSpanDiscount), fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = SteelLight)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("SPAN Inter-Month / Curve Offset:", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = TerminalGreen)
                Text("-\$%,.2f".format(accountState.portfolioSpanDiscount), fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TerminalGreen)
            }
            Divider(modifier = Modifier.padding(vertical = 4.dp), color = RhinoBorder)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Net Initial Margin Required:", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RhinoGold)
                Text("\$%,.2f".format(accountState.initialMarginRequired), fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RhinoGold)
            }
        }
    }
}

@Composable
private fun RiskRuleRow(name: String, limit: String, status: String, latency: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(RhinoBlack)
            .padding(horizontal = 6.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(name, fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = SteelLight)
            Text("Limit: $limit", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(latency, fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = RhinoCyan)
            Spacer(modifier = Modifier.width(6.dp))
            StatusBadge(status)
        }
    }
}
