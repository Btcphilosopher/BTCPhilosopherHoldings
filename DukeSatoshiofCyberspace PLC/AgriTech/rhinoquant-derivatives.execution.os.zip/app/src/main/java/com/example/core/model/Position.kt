package com.example.core.model

enum class PositionSide { LONG, SHORT, FLAT }

data class OptionGreeks(
    val delta: Double = 0.0,
    val gamma: Double = 0.0,
    val vega: Double = 0.0,
    val theta: Double = 0.0,
    val rho: Double = 0.0,
    val impliedVol: Double = 0.0
)

data class Position(
    val instrumentId: String,
    val symbol: String,
    val quantity: Int, // Positive for Long, Negative for Short, 0 for Flat
    val side: PositionSide = when {
        quantity > 0 -> PositionSide.LONG
        quantity < 0 -> PositionSide.SHORT
        else -> PositionSide.FLAT
    },
    val averageEntryPrice: Double,
    val currentMarketPrice: Double,
    val realizedPnL: Double = 0.0,
    val unrealizedPnL: Double = 0.0,
    val dailyPnL: Double = 0.0,
    val initialMargin: Double = 0.0,
    val maintenanceMargin: Double = 0.0,
    val feesPaid: Double = 0.0,
    val greeks: OptionGreeks = OptionGreeks(),
    val dv01: Double = 0.0, // Total dollar value of a basis point
    val notionalValue: Double = 0.0,
    val updatedAtEpochMs: Long = System.currentTimeMillis()
) {
    val netPnL: Double get() = realizedPnL + unrealizedPnL - feesPaid
    val isFlat: Boolean get() = quantity == 0
}

data class AccountMarginState(
    val accountId: String = "RHINO-TRADING-01",
    val currency: String = "USD",
    val totalEquity: Double = 5_000_000.0, // $5.0M Institutional Capital Base
    val initialMarginRequired: Double = 0.0,
    val maintenanceMarginRequired: Double = 0.0,
    val variationMargin: Double = 0.0,
    val cashBalance: Double = 5_000_000.0,
    val realizedPnL: Double = 0.0,
    val unrealizedPnL: Double = 0.0,
    val totalFeesPaid: Double = 0.0,
    val maxLeverageAllowed: Double = 10.0,
    val portfolioSpanDiscount: Double = 0.0
) {
    val availableMargin: Double
        get() = (totalEquity + unrealizedPnL - initialMarginRequired).coerceAtLeast(0.0)

    val excessLiquidity: Double
        get() = (totalEquity + unrealizedPnL - maintenanceMarginRequired).coerceAtLeast(0.0)

    val marginUtilizationPercent: Double
        get() = if (totalEquity > 0) (initialMarginRequired / totalEquity) * 100.0 else 0.0

    val netLiquidationValue: Double
        get() = totalEquity + unrealizedPnL - totalFeesPaid
}
