package com.example.core.model

enum class OrderSide { BUY, SELL }

enum class OrderType(val displayName: String) {
    MARKET("Market"),
    LIMIT("Limit"),
    STOP("Stop"),
    STOP_LIMIT("Stop Limit"),
    MARKET_IF_TOUCHED("MIT"),
    LIMIT_IF_TOUCHED("LIT"),
    ICEBERG("Iceberg"),
    POST_ONLY("Post Only"),
    REDUCE_ONLY("Reduce Only")
}

enum class TimeInForce(val code: String, val displayName: String) {
    DAY("DAY", "Day Order"),
    GTC("GTC", "Good 'Til Cancelled"),
    IOC("IOC", "Immediate or Cancel"),
    FOK("FOK", "Fill or Kill"),
    GTD("GTD", "Good 'Til Date")
}

sealed interface OrderState {
    val name: String
    val isTerminal: Boolean

    data object Created : OrderState { override val name = "CREATED"; override val isTerminal = false }
    data object Validating : OrderState { override val name = "VALIDATING"; override val isTerminal = false }
    data object RiskApproved : OrderState { override val name = "RISK_APPROVED"; override val isTerminal = false }
    data object Routing : OrderState { override val name = "ROUTING"; override val isTerminal = false }
    data object Acknowledged : OrderState { override val name = "ACKNOWLEDGED"; override val isTerminal = false }
    data object Working : OrderState { override val name = "WORKING"; override val isTerminal = false }
    data object PartiallyFilled : OrderState { override val name = "PARTIALLY_FILLED"; override val isTerminal = false }
    data object Filled : OrderState { override val name = "FILLED"; override val isTerminal = true }
    data object CancelPending : OrderState { override val name = "CANCEL_PENDING"; override val isTerminal = false }
    data object Cancelled : OrderState { override val name = "CANCELLED"; override val isTerminal = true }
    data object ReplacePending : OrderState { override val name = "REPLACE_PENDING"; override val isTerminal = false }
    data object Replaced : OrderState { override val name = "REPLACED"; override val isTerminal = false }
    data object Rejected : OrderState { override val name = "REJECTED"; override val isTerminal = true }
    data object Expired : OrderState { override val name = "EXPIRED"; override val isTerminal = true }
    data object Suspended : OrderState { override val name = "SUSPENDED"; override val isTerminal = false }
}

class IllegalOrderStateTransitionException(
    val current: OrderState,
    val target: OrderState,
    val orderId: String
) : IllegalStateException("Invalid order transition for $orderId: ${current.name} -> ${target.name}")

enum class LiquidityIndicator { MAKER, TAKER }

enum class ExecutionEnvironment(val label: String) {
    SIMULATED("SIMULATED"),
    PAPER("PAPER"),
    CERTIFICATION("CERTIFICATION"),
    PRODUCTION("PRODUCTION")
}

data class ExecutionFill(
    val executionId: String,
    val orderId: String,
    val clientOrderId: String,
    val instrumentId: String,
    val side: OrderSide,
    val fillQuantity: Int,
    val fillPrice: Double,
    val timestampNanos: Long = System.nanoTime(),
    val timestampEpochMs: Long = System.currentTimeMillis(),
    val venue: String = "SIM_CME",
    val liquidity: LiquidityIndicator = LiquidityIndicator.TAKER,
    val fee: Double = 0.75, // $0.75 exchange fee
    val commission: Double = 0.25, // $0.25 broker fee
    val slippageBps: Double = 0.0,
    val environment: ExecutionEnvironment = ExecutionEnvironment.SIMULATED
) {
    val totalCost: Double get() = fee + commission
}

data class OrderLatencies(
    val apiEntryNanos: Long = 0L,
    val riskNanos: Long = 0L,
    val routingNanos: Long = 0L,
    val matchNanos: Long = 0L,
    val ackNanos: Long = 0L,
    val fillNanos: Long = 0L
) {
    val totalRoundtripMs: Double
        get() = if (fillNanos > apiEntryNanos && apiEntryNanos > 0) {
            (fillNanos - apiEntryNanos) / 1_000_000.0
        } else if (ackNanos > apiEntryNanos && apiEntryNanos > 0) {
            (ackNanos - apiEntryNanos) / 1_000_000.0
        } else {
            0.12
        }
}

data class Order(
    val orderId: String,
    val clientOrderId: String,
    val accountId: String = "RHINO-TRADING-01",
    val traderId: String = "QUANT-DESK-01",
    val instrumentId: String,
    val side: OrderSide,
    val quantity: Int,
    val price: Double,
    val stopPrice: Double? = null,
    val orderType: OrderType = OrderType.LIMIT,
    val timeInForce: TimeInForce = TimeInForce.DAY,
    val strategyId: String? = null,
    val riskProfile: String = "STANDARD_INSTITUTIONAL",
    val venue: String = "SIM_CME",
    val state: OrderState = OrderState.Created,
    val filledQuantity: Int = 0,
    val remainingQuantity: Int = quantity,
    val averageFillPrice: Double = 0.0,
    val displayQuantity: Int? = null, // Iceberg visible size
    val peakPrice: Double? = null,
    val rejectionReason: String? = null,
    val idempotencyKey: String? = null,
    val environment: ExecutionEnvironment = ExecutionEnvironment.SIMULATED,
    val latencies: OrderLatencies = OrderLatencies(),
    val fills: List<ExecutionFill> = emptyList(),
    val createdAtEpochMs: Long = System.currentTimeMillis(),
    val updatedAtEpochMs: Long = System.currentTimeMillis()
) {
    val isFilled: Boolean get() = state is OrderState.Filled
    val isWorking: Boolean get() = state is OrderState.Working || state is OrderState.PartiallyFilled || state is OrderState.Acknowledged
    val isTerminal: Boolean get() = state.isTerminal

    fun transitionTo(newState: OrderState, rejectionReason: String? = null): Order {
        if (!isValidTransition(this.state, newState)) {
            throw IllegalOrderStateTransitionException(this.state, newState, this.orderId)
        }
        return this.copy(
            state = newState,
            rejectionReason = rejectionReason ?: this.rejectionReason,
            updatedAtEpochMs = System.currentTimeMillis()
        )
    }

    private fun isValidTransition(from: OrderState, to: OrderState): Boolean {
        if (from == to) return true
        return when (from) {
            is OrderState.Created -> to is OrderState.Validating || to is OrderState.Rejected
            is OrderState.Validating -> to is OrderState.RiskApproved || to is OrderState.Rejected
            is OrderState.RiskApproved -> to is OrderState.Routing || to is OrderState.Rejected
            is OrderState.Routing -> to is OrderState.Acknowledged || to is OrderState.Rejected
            is OrderState.Acknowledged -> to is OrderState.Working || to is OrderState.Filled || to is OrderState.Rejected || to is OrderState.Cancelled
            is OrderState.Working -> to is OrderState.PartiallyFilled || to is OrderState.Filled || to is OrderState.CancelPending || to is OrderState.ReplacePending || to is OrderState.Cancelled || to is OrderState.Expired
            is OrderState.PartiallyFilled -> to is OrderState.PartiallyFilled || to is OrderState.Filled || to is OrderState.CancelPending || to is OrderState.ReplacePending || to is OrderState.Cancelled || to is OrderState.Expired
            is OrderState.CancelPending -> to is OrderState.Cancelled || to is OrderState.Working || to is OrderState.Filled
            is OrderState.ReplacePending -> to is OrderState.Replaced || to is OrderState.Working || to is OrderState.Filled
            is OrderState.Replaced -> to is OrderState.Working || to is OrderState.PartiallyFilled || to is OrderState.Filled || to is OrderState.Cancelled
            is OrderState.Filled -> false
            is OrderState.Cancelled -> false
            is OrderState.Rejected -> false
            is OrderState.Expired -> false
            is OrderState.Suspended -> to is OrderState.Working || to is OrderState.Cancelled
        }
    }
}
