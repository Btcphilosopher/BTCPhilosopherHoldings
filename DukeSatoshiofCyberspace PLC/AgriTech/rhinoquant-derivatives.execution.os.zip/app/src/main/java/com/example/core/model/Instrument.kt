package com.example.core.model

enum class AssetClass(val displayName: String) {
    INTEREST_RATES("Interest Rates"),
    EQUITY_INDEX("Equity Index"),
    ENERGY("Energy"),
    METALS("Metals"),
    FX("Foreign Exchange"),
    AGRICULTURE("Agriculture"),
    CREDIT("Credit"),
    CRYPTO_DERIVATIVES("Crypto Derivatives")
}

enum class ExchangeVenue(val code: String, val displayName: String, val mic: String) {
    CME("CME", "Chicago Mercantile Exchange", "XCME"),
    CBOT("CBOT", "Chicago Board of Trade", "XCBT"),
    NYMEX("NYMEX", "New York Mercantile Exchange", "XNYM"),
    COMEX("COMEX", "Commodity Exchange", "XCEC"),
    ICE("ICE", "Intercontinental Exchange", "IFEU"),
    EUREX("EUREX", "European Derivatives Exchange", "XEUR"),
    SIM_EXCHANGE("SIM_CME", "RhinoQuant Simulation Exchange", "RSIM")
}

enum class ContractLifecycle(val displayName: String) {
    PRE_LISTING("Pre-Listing"),
    LISTED("Listed"),
    OPEN("Open / Trading"),
    EXPIRING("Expiring Soon"),
    EXPIRED("Expired"),
    NOTICE_PERIOD("Notice Period"),
    DELIVERY_PERIOD("Delivery Period"),
    DELIVERED("Delivered"),
    SETTLED("Settled")
}

enum class SettlementType { CASH, PHYSICAL }
enum class ExerciseStyle { AMERICAN, EUROPEAN, NONE }
enum class OptionType { CALL, PUT, NONE }

data class Instrument(
    val instrumentId: String,
    val symbol: String,
    val name: String,
    val assetClass: AssetClass,
    val exchange: ExchangeVenue,
    val venue: String,
    val contractMonth: String,
    val expiration: String,
    val currency: String = "USD",
    val multiplier: Double,
    val tickSize: Double,
    val tickValue: Double,
    val pricePrecision: Int = 3,
    val quantityPrecision: Int = 0,
    val tradingSession: String = "GLBX_ETH",
    val firstTradeDate: String,
    val lastTradeDate: String,
    val settlementType: SettlementType = SettlementType.CASH,
    val exerciseStyle: ExerciseStyle = ExerciseStyle.NONE,
    val optionType: OptionType = OptionType.NONE,
    val strike: Double? = null,
    val underlyingId: String? = null,
    val initialMarginPerContract: Double = 1250.0,
    val maintenanceMarginPerContract: Double = 1000.0,
    val lifecycleState: ContractLifecycle = ContractLifecycle.OPEN,
    val baseDv01PerContract: Double = 25.0 // For rates instruments ($ per bp)
) {
    val isOption: Boolean get() = optionType != OptionType.NONE
    val isTradable: Boolean get() = lifecycleState == ContractLifecycle.OPEN
}

object InstrumentMaster {
    val SOFR_Z6 = Instrument(
        instrumentId = "SR3Z26",
        symbol = "SR3 Z6",
        name = "Three-Month SOFR Futures Dec 2026",
        assetClass = AssetClass.INTEREST_RATES,
        exchange = ExchangeVenue.CME,
        venue = "SIM_CME",
        contractMonth = "DEC 2026",
        expiration = "2026-12-15",
        currency = "USD",
        multiplier = 2500.0,
        tickSize = 0.005, // half tick = $12.50
        tickValue = 12.50,
        pricePrecision = 3,
        firstTradeDate = "2023-01-03",
        lastTradeDate = "2026-12-15",
        settlementType = SettlementType.CASH,
        initialMarginPerContract = 1150.0,
        maintenanceMarginPerContract = 950.0,
        baseDv01PerContract = 25.0
    )

    val SOFR_H7 = Instrument(
        instrumentId = "SR3H27",
        symbol = "SR3 H7",
        name = "Three-Month SOFR Futures Mar 2027",
        assetClass = AssetClass.INTEREST_RATES,
        exchange = ExchangeVenue.CME,
        venue = "SIM_CME",
        contractMonth = "MAR 2027",
        expiration = "2027-03-16",
        currency = "USD",
        multiplier = 2500.0,
        tickSize = 0.005,
        tickValue = 12.50,
        pricePrecision = 3,
        firstTradeDate = "2023-04-03",
        lastTradeDate = "2027-03-16",
        settlementType = SettlementType.CASH,
        initialMarginPerContract = 1150.0,
        maintenanceMarginPerContract = 950.0,
        baseDv01PerContract = 25.0
    )

    val TREASURY_10Y_ZN = Instrument(
        instrumentId = "ZNZ26",
        symbol = "ZN Z6",
        name = "10-Year US Treasury Note Futures Dec 2026",
        assetClass = AssetClass.INTEREST_RATES,
        exchange = ExchangeVenue.CBOT,
        venue = "SIM_CME",
        contractMonth = "DEC 2026",
        expiration = "2026-12-21",
        currency = "USD",
        multiplier = 1000.0,
        tickSize = 0.015625, // 1/64th
        tickValue = 15.625,
        pricePrecision = 3,
        firstTradeDate = "2024-01-02",
        lastTradeDate = "2026-12-21",
        settlementType = SettlementType.PHYSICAL,
        initialMarginPerContract = 2200.0,
        maintenanceMarginPerContract = 1800.0,
        baseDv01PerContract = 74.50
    )

    val TREASURY_ULTRA_10Y_TN = Instrument(
        instrumentId = "TNZ26",
        symbol = "TN Z6",
        name = "Ultra 10-Year US Treasury Note Futures Dec 2026",
        assetClass = AssetClass.INTEREST_RATES,
        exchange = ExchangeVenue.CBOT,
        venue = "SIM_CME",
        contractMonth = "DEC 2026",
        expiration = "2026-12-21",
        currency = "USD",
        multiplier = 1000.0,
        tickSize = 0.015625,
        tickValue = 15.625,
        pricePrecision = 3,
        firstTradeDate = "2024-01-02",
        lastTradeDate = "2026-12-21",
        settlementType = SettlementType.PHYSICAL,
        initialMarginPerContract = 2850.0,
        maintenanceMarginPerContract = 2300.0,
        baseDv01PerContract = 98.20
    )

    val EMINI_SP500_ES = Instrument(
        instrumentId = "ESZ26",
        symbol = "ES Z6",
        name = "E-mini S&P 500 Futures Dec 2026",
        assetClass = AssetClass.EQUITY_INDEX,
        exchange = ExchangeVenue.CME,
        venue = "SIM_CME",
        contractMonth = "DEC 2026",
        expiration = "2026-12-18",
        currency = "USD",
        multiplier = 50.0,
        tickSize = 0.25,
        tickValue = 12.50,
        pricePrecision = 2,
        firstTradeDate = "2025-01-02",
        lastTradeDate = "2026-12-18",
        settlementType = SettlementType.CASH,
        initialMarginPerContract = 12650.0,
        maintenanceMarginPerContract = 11500.0,
        baseDv01PerContract = 0.0
    )

    val EUR_USD_6E = Instrument(
        instrumentId = "6EZ26",
        symbol = "6E Z6",
        name = "Euro FX Futures Dec 2026",
        assetClass = AssetClass.FX,
        exchange = ExchangeVenue.CME,
        venue = "SIM_CME",
        contractMonth = "DEC 2026",
        expiration = "2026-12-14",
        currency = "USD",
        multiplier = 125000.0,
        tickSize = 0.00005,
        tickValue = 6.25,
        pricePrecision = 5,
        firstTradeDate = "2025-01-02",
        lastTradeDate = "2026-12-14",
        settlementType = SettlementType.PHYSICAL,
        initialMarginPerContract = 2400.0,
        maintenanceMarginPerContract = 2000.0,
        baseDv01PerContract = 12.5
    )

    val CRUDE_OIL_CL = Instrument(
        instrumentId = "CLZ26",
        symbol = "CL Z6",
        name = "Crude Oil WTI Futures Dec 2026",
        assetClass = AssetClass.ENERGY,
        exchange = ExchangeVenue.NYMEX,
        venue = "SIM_CME",
        contractMonth = "DEC 2026",
        expiration = "2026-11-20",
        currency = "USD",
        multiplier = 1000.0,
        tickSize = 0.01,
        tickValue = 10.0,
        pricePrecision = 2,
        firstTradeDate = "2025-01-02",
        lastTradeDate = "2026-11-20",
        settlementType = SettlementType.PHYSICAL,
        initialMarginPerContract = 6800.0,
        maintenanceMarginPerContract = 5900.0,
        baseDv01PerContract = 0.0
    )

    val GOLD_GC = Instrument(
        instrumentId = "GCZ26",
        symbol = "GC Z6",
        name = "Gold Futures Dec 2026",
        assetClass = AssetClass.METALS,
        exchange = ExchangeVenue.COMEX,
        venue = "SIM_CME",
        contractMonth = "DEC 2026",
        expiration = "2026-12-28",
        currency = "USD",
        multiplier = 100.0,
        tickSize = 0.10,
        tickValue = 10.0,
        pricePrecision = 2,
        firstTradeDate = "2025-01-02",
        lastTradeDate = "2026-12-28",
        settlementType = SettlementType.PHYSICAL,
        initialMarginPerContract = 9400.0,
        maintenanceMarginPerContract = 8200.0,
        baseDv01PerContract = 0.0
    )

    val SOFR_OPT_CALL_9525 = Instrument(
        instrumentId = "SR3Z26C9525",
        symbol = "SR3 Z6 C 95.250",
        name = "SOFR Dec 26 Call Option 95.250",
        assetClass = AssetClass.INTEREST_RATES,
        exchange = ExchangeVenue.CME,
        venue = "SIM_CME",
        contractMonth = "DEC 2026",
        expiration = "2026-12-11",
        currency = "USD",
        multiplier = 2500.0,
        tickSize = 0.005,
        tickValue = 12.50,
        pricePrecision = 3,
        firstTradeDate = "2024-01-02",
        lastTradeDate = "2026-12-11",
        settlementType = SettlementType.PHYSICAL,
        exerciseStyle = ExerciseStyle.AMERICAN,
        optionType = OptionType.CALL,
        strike = 95.250,
        underlyingId = "SR3Z26",
        initialMarginPerContract = 650.0,
        maintenanceMarginPerContract = 500.0
    )

    val SOFR_OPT_PUT_9500 = Instrument(
        instrumentId = "SR3Z26P9500",
        symbol = "SR3 Z6 P 95.000",
        name = "SOFR Dec 26 Put Option 95.000",
        assetClass = AssetClass.INTEREST_RATES,
        exchange = ExchangeVenue.CME,
        venue = "SIM_CME",
        contractMonth = "DEC 2026",
        expiration = "2026-12-11",
        currency = "USD",
        multiplier = 2500.0,
        tickSize = 0.005,
        tickValue = 12.50,
        pricePrecision = 3,
        firstTradeDate = "2024-01-02",
        lastTradeDate = "2026-12-11",
        settlementType = SettlementType.PHYSICAL,
        exerciseStyle = ExerciseStyle.AMERICAN,
        optionType = OptionType.PUT,
        strike = 95.000,
        underlyingId = "SR3Z26",
        initialMarginPerContract = 620.0,
        maintenanceMarginPerContract = 480.0
    )

    val ALL_INSTRUMENTS: List<Instrument> = listOf(
        SOFR_Z6,
        SOFR_H7,
        TREASURY_10Y_ZN,
        TREASURY_ULTRA_10Y_TN,
        EMINI_SP500_ES,
        EUR_USD_6E,
        CRUDE_OIL_CL,
        GOLD_GC,
        SOFR_OPT_CALL_9525,
        SOFR_OPT_PUT_9500
    )

    fun findById(id: String): Instrument? = ALL_INSTRUMENTS.find { it.instrumentId == id || it.symbol.equals(id, ignoreCase = true) }
}
