package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.AssetClass
import com.example.core.model.InstrumentMaster
import com.example.ui.RhinoTerminalViewModel
import com.example.ui.TerminalTab
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun MarketDepthScreen(
    viewModel: RhinoTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val quotes by viewModel.quotes.collectAsState()
    var selectedCategory by remember { mutableStateOf("ALL") }

    val filteredInstruments = remember(selectedCategory) {
        when (selectedCategory) {
            "RATES" -> InstrumentMaster.ALL_INSTRUMENTS.filter { it.assetClass == AssetClass.INTEREST_RATES }
            "EQUITIES" -> InstrumentMaster.ALL_INSTRUMENTS.filter { it.assetClass == AssetClass.EQUITY_INDEX }
            "FX" -> InstrumentMaster.ALL_INSTRUMENTS.filter { it.assetClass == AssetClass.FX }
            "COMMODITIES" -> InstrumentMaster.ALL_INSTRUMENTS.filter { it.assetClass == AssetClass.ENERGY || it.assetClass == AssetClass.METALS }
            "OPTIONS" -> InstrumentMaster.ALL_INSTRUMENTS.filter { it.isOption }
            else -> InstrumentMaster.ALL_INSTRUMENTS
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBlack)
            .padding(8.dp)
    ) {
        TerminalSectionHeader(title = "DERIVATIVES MARKET WATCHLIST", subtitle = "MDP 3.0 Real-time Multicast")

        // Asset Class Filter Pills
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf("ALL", "RATES", "EQUITIES", "FX", "COMMODITIES", "OPTIONS").forEach { cat ->
                val isSel = selectedCategory == cat
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(if (isSel) RhinoGold else RhinoGraphite)
                        .border(1.dp, if (isSel) RhinoGold else RhinoBorder, RoundedCornerShape(3.dp))
                        .clickable { selectedCategory = cat }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = cat,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSel) RhinoBlack else SteelMedium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Table Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(RhinoSurfaceElevated)
                .padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("INSTRUMENT / EXCH", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark, modifier = Modifier.weight(1.4f))
            Text("BID / ASK", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark, modifier = Modifier.weight(1.3f))
            Text("LAST / CHG", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark, modifier = Modifier.weight(1.2f))
            Text("VOLUME / OI", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark, modifier = Modifier.weight(1.1f))
            Text("ACTION", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark, modifier = Modifier.weight(0.9f))
        }

        Spacer(modifier = Modifier.height(2.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(filteredInstruments, key = { it.instrumentId }) { inst ->
                val q = quotes[inst.instrumentId]
                val changeColor = if ((q?.netChange ?: 0.0) >= 0) TerminalGreen else TerminalRed

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(RhinoGraphite)
                        .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                        .clickable {
                            viewModel.selectInstrument(inst.instrumentId)
                            viewModel.selectTab(TerminalTab.EXECUTION)
                        }
                        .padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // INSTRUMENT / EXCH
                    Column(modifier = Modifier.weight(1.4f)) {
                        Text(inst.symbol, fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SteelLight)
                        Text("${inst.exchange.code} • ${inst.assetClass.displayName}", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark)
                    }

                    // BID / ASK
                    Column(modifier = Modifier.weight(1.3f)) {
                        if (q != null) {
                            Text(
                                "%.${inst.pricePrecision}f / %.${inst.pricePrecision}f".format(q.bidPrice, q.askPrice),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = SteelLight
                            )
                            Text("${q.bidSize} x ${q.askSize}", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark)
                        } else {
                            Text("---", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = SteelDark)
                        }
                    }

                    // LAST / CHG
                    Column(modifier = Modifier.weight(1.2f)) {
                        if (q != null) {
                            Text(
                                "%.${inst.pricePrecision}f".format(q.lastPrice),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = changeColor
                            )
                            Text(
                                "${if (q.netChange >= 0) "+" else ""}${"%.${inst.pricePrecision}f".format(q.netChange)} (%.2f%%)".format(q.percentChange),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 8.sp,
                                color = changeColor
                            )
                        }
                    }

                    // VOLUME / OI
                    Column(modifier = Modifier.weight(1.1f)) {
                        if (q != null) {
                            Text("Vol: %,d".format(q.volume), fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = SteelMedium)
                            Text("OI: %,d".format(q.openInterest), fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark)
                        }
                    }

                    // TRADE ACTION BUTTON
                    Box(modifier = Modifier.weight(0.9f)) {
                        Button(
                            onClick = {
                                viewModel.selectInstrument(inst.instrumentId)
                                viewModel.selectTab(TerminalTab.EXECUTION)
                            },
                            modifier = Modifier.height(26.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                            shape = RoundedCornerShape(3.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = RhinoGold)
                        ) {
                            Text("TRADE", fontFamily = FontFamily.Monospace, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = RhinoBlack)
                        }
                    }
                }
            }
        }
    }
}
