package com.example.engine

import com.example.core.model.*
import kotlinx.coroutines.*
import java.util.concurrent.ConcurrentHashMap

class AlgoExecutionEngine(
    private val scope: CoroutineScope,
    private val onSliceTrigger: suspend (instanceId: String, slice: AlgoSlice, instrumentId: String, side: OrderSide, algoType: ExecutionAlgorithmType) -> Unit
) {
    private val activeAlgos = ConcurrentHashMap<String, ActiveAlgoInstance>()
    private val algoJobs = ConcurrentHashMap<String, Job>()

    fun getActiveAlgos(): List<ActiveAlgoInstance> = activeAlgos.values.toList()

    fun getAlgoInstance(planId: String): ActiveAlgoInstance? = activeAlgos[planId]

    fun startAlgo(
        name: String,
        instrumentId: String,
        side: OrderSide,
        totalQuantity: Int,
        algoType: ExecutionAlgorithmType,
        durationMinutes: Int = 10,
        sliceCount: Int = 10,
        arrivalPrice: Double
    ): ActiveAlgoInstance {
        val planId = "ALGO-${System.currentTimeMillis() % 100000}"
        val sliceQty = totalQuantity / sliceCount
        val intervalMs = (durationMinutes * 60 * 1000L) / sliceCount

        val slices = (0 until sliceCount).map { i ->
            AlgoSlice(
                sliceIndex = i + 1,
                scheduledTimeMs = System.currentTimeMillis() + (i * intervalMs),
                targetQuantity = if (i == sliceCount - 1) (totalQuantity - (sliceQty * (sliceCount - 1))) else sliceQty,
                status = if (i == 0) "SCHEDULED" else "QUEUED"
            )
        }

        val instance = ActiveAlgoInstance(
            planId = planId,
            name = name,
            instrumentId = instrumentId,
            side = side,
            totalQuantity = totalQuantity,
            algoType = algoType,
            arrivalPrice = arrivalPrice,
            currentMarketMid = arrivalPrice,
            status = AlgoExecutionStatus.RUNNING,
            slices = slices
        )

        activeAlgos[planId] = instance

        // Launch Algo execution runner
        val job = scope.launch(Dispatchers.Default) {
            for (slice in slices) {
                if (!isActive || activeAlgos[planId]?.status != AlgoExecutionStatus.RUNNING) break

                // Wait until scheduled slice time (or accelerated simulated delay for demo)
                delay(1200) // Fast 1.2s per slice in simulation mode

                if (activeAlgos[planId]?.status != AlgoExecutionStatus.RUNNING) break

                onSliceTrigger(planId, slice, instrumentId, side, algoType)
            }

            // Mark completed
            activeAlgos[planId]?.let { curr ->
                if (curr.status == AlgoExecutionStatus.RUNNING) {
                    activeAlgos[planId] = curr.copy(status = AlgoExecutionStatus.COMPLETED)
                }
            }
        }

        algoJobs[planId] = job
        return instance
    }

    fun updateSliceExecution(
        planId: String,
        sliceIndex: Int,
        fillQty: Int,
        fillPrice: Double,
        orderId: String
    ) {
        val curr = activeAlgos[planId] ?: return
        val updatedSlices = curr.slices.map { s ->
            if (s.sliceIndex == sliceIndex) {
                s.copy(
                    filledQuantity = fillQty,
                    fillPrice = fillPrice,
                    orderId = orderId,
                    status = "FILLED"
                )
            } else s
        }

        val totalFilled = updatedSlices.sumOf { it.filledQuantity }
        val weightedNotional = updatedSlices.filter { it.filledQuantity > 0 }.sumOf { it.filledQuantity * it.fillPrice }
        val avgPx = if (totalFilled > 0) weightedNotional / totalFilled else 0.0

        val sign = if (curr.side == OrderSide.BUY) 1.0 else -1.0
        val isBps = if (curr.arrivalPrice > 0 && avgPx > 0) {
            sign * ((avgPx - curr.arrivalPrice) / curr.arrivalPrice) * 10_000.0
        } else 0.0

        activeAlgos[planId] = curr.copy(
            filledQuantity = totalFilled,
            averageExecutionPrice = avgPx,
            slices = updatedSlices,
            implementationShortfallBps = isBps,
            status = if (totalFilled >= curr.totalQuantity) AlgoExecutionStatus.COMPLETED else curr.status
        )
    }

    fun pauseAlgo(planId: String) {
        activeAlgos[planId]?.let {
            activeAlgos[planId] = it.copy(status = AlgoExecutionStatus.PAUSED)
        }
        algoJobs[planId]?.cancel()
    }

    fun cancelAlgo(planId: String) {
        activeAlgos[planId]?.let {
            activeAlgos[planId] = it.copy(status = AlgoExecutionStatus.CANCELLED)
        }
        algoJobs[planId]?.cancel()
    }
}
