package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.ui.RhinoTerminalViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlin.math.abs

@Composable
fun PositionsScreen(
    viewModel: RhinoTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val positions by viewModel.platformManager.positions.collectAsState()
    val accountState by viewModel.platformManager.accountMargin.collectAsState()
    val riskSnap by viewModel.platformManager.riskSnapshot.collectAsState()

    val openPositions = remember(positions) { positions.filter { it.quantity != 0 } }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBlack)
            .padding(8.dp)
    ) {
        TerminalSectionHeader(title = "PORTFOLIO CAPITAL & RISK BASE")

        // Top Capital & PnL Metrics
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            MetricBox(
                label = "NET LIQ VALUE",
                value = "\$%,.2f".format(accountState.netLiquidationValue),
                subValue = "Cash: \$%,.0f".format(accountState.cashBalance),
                valueColor = SteelLight,
                modifier = Modifier.weight(1f)
            )
            MetricBox(
                label = "TOTAL NET P&L",
                value = "${if (accountState.unrealizedPnL + accountState.realizedPnL >= 0) "+" else ""}\$%,.2f".format(accountState.unrealizedPnL + accountState.realizedPnL),
                subValue = "Fees: -\$%,.2f".format(accountState.totalFeesPaid),
                valueColor = if (accountState.unrealizedPnL + accountState.realizedPnL >= 0) TerminalGreen else TerminalRed,
                modifier = Modifier.weight(1f)
            )
            MetricBox(
                label = "PORTFOLIO DV01",
                value = "${if (riskSnap.portfolioDv01 >= 0) "+" else ""}\$%,.1f".format(riskSnap.portfolioDv01),
                subValue = "VaR 99%: \$%,.0f".format(riskSnap.valueAtRisk1Day99Pct),
                valueColor = RhinoGold,
                modifier = Modifier.weight(1f)
            )
            MetricBox(
                label = "MARGIN UTIL",
                value = "%.1f%%".format(accountState.marginUtilizationPercent),
                subValue = "Avail: \$%,.0f".format(accountState.availableMargin),
                valueColor = if (accountState.marginUtilizationPercent > 75.0) TerminalRed else RhinoCyan,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Open Positions Table Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("OPEN DERIVATIVES POSITIONS (${openPositions.size})", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RhinoGold)
            if (accountState.portfolioSpanDiscount > 0) {
                StatusBadge("SPAN DISCOUNT: \$%,.0f".format(accountState.portfolioSpanDiscount))
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        if (openPositions.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(4.dp))
                    .background(RhinoGraphite)
                    .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("NO OPEN POSITIONS", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = SteelDark)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Submit orders in Execution or run a Signature Demo", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = SteelDark)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(openPositions, key = { it.instrumentId }) { pos ->
                    val inst = InstrumentMaster.findById(pos.instrumentId)
                    val sideColor = if (pos.quantity > 0) TerminalGreen else TerminalRed
                    val pnlColor = if (pos.unrealizedPnL >= 0) TerminalGreen else TerminalRed

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(RhinoGraphite)
                            .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        // Top row: Symbol, Position Size, Net P&L, Flatten Button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(pos.symbol, fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SteelLight)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    StatusBadge(if (pos.quantity > 0) "LONG ${pos.quantity}" else "SHORT ${abs(pos.quantity)}")
                                }
                                Text("Entry: %.${inst?.pricePrecision ?: 3}f • MTM: %.${inst?.pricePrecision ?: 3}f".format(pos.averageEntryPrice, pos.currentMarketPrice), fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = SteelMedium)
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "${if (pos.unrealizedPnL >= 0) "+" else ""}\$%,.2f".format(pos.unrealizedPnL),
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = pnlColor
                                )
                                Text("Realized: \$%,.2f".format(pos.realizedPnL), fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark)
                            }

                            // Flatten Position Button
                            Button(
                                onClick = {
                                    val closeSide = if (pos.quantity > 0) OrderSide.SELL else OrderSide.BUY
                                    viewModel.submitQuickOrder(pos.instrumentId, closeSide, abs(pos.quantity))
                                },
                                modifier = Modifier
                                    .height(28.dp)
                                    .padding(start = 6.dp),
                                shape = RoundedCornerShape(3.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = TerminalRed.copy(alpha = 0.8f))
                            ) {
                                Text("FLATTEN", fontFamily = FontFamily.Monospace, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = RhinoBlack)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Bottom analytics bar: Greeks, DV01, Margin, Notional
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(3.dp))
                                .background(RhinoBlack)
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("DV01: \$%,.1f".format(pos.dv01), fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = RhinoGold)
                            if (inst?.isOption == true) {
                                Text("Δ: %.2f".format(pos.greeks.delta), fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = SteelLight)
                                Text("Γ: %.3f".format(pos.greeks.gamma), fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = SteelLight)
                                Text("V: %.1f".format(pos.greeks.vega), fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = SteelLight)
                                Text("Θ: %.1f".format(pos.greeks.theta), fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = SteelLight)
                            } else {
                                Text("Notional: \$%,.0f".format(pos.notionalValue), fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = SteelMedium)
                            }
                            Text("Margin: \$%,.0f".format(pos.initialMargin), fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = RhinoAmber)
                        }
                    }
                }
            }
        }
    }
}
