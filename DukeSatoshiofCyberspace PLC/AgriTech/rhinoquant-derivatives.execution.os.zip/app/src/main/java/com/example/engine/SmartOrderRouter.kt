package com.example.engine

import com.example.core.model.*

data class VenueQuoteComparison(
    val venueId: String,
    val venueName: String,
    val bidPrice: Double,
    val askPrice: Double,
    val bidSize: Int,
    val askSize: Int,
    val estimatedLatencyMicros: Long,
    val feePerContract: Double,
    val score: Double
)

data class RoutingDecision(
    val selectedVenueId: String,
    val venueComparisons: List<VenueQuoteComparison>,
    val routingReason: String,
    val expectedNetPrice: Double
)

class SmartOrderRouter {

    fun route(
        instrument: Instrument,
        side: OrderSide,
        quantity: Int,
        baseQuote: MarketQuote?
    ): RoutingDecision {
        val mid = baseQuote?.let { (it.bidPrice + it.askPrice) / 2.0 } ?: 95.125
        val tick = instrument.tickSize

        // Simulated Multi-Venue Liquidity Landscape
        val venueCme = VenueQuoteComparison(
            venueId = "SIM_CME",
            venueName = "CME Globex (SIM)",
            bidPrice = mid - (tick * 0.5),
            askPrice = mid + (tick * 0.5),
            bidSize = baseQuote?.bidSize ?: 1400,
            askSize = baseQuote?.askSize ?: 1800,
            estimatedLatencyMicros = 145L,
            feePerContract = 0.75,
            score = 98.4
        )

        val venueIce = VenueQuoteComparison(
            venueId = "SIM_ICE",
            venueName = "ICE Futures (SIM)",
            bidPrice = mid - tick,
            askPrice = mid + tick,
            bidSize = ((baseQuote?.bidSize ?: 1000) * 0.6).toInt(),
            askSize = ((baseQuote?.askSize ?: 1000) * 0.6).toInt(),
            estimatedLatencyMicros = 290L,
            feePerContract = 0.85,
            score = 88.2
        )

        val venueEurex = VenueQuoteComparison(
            venueId = "SIM_EUREX",
            venueName = "Eurex Derivatives (SIM)",
            bidPrice = mid - (tick * 1.5),
            askPrice = mid + (tick * 1.5),
            bidSize = ((baseQuote?.bidSize ?: 1000) * 0.4).toInt(),
            askSize = ((baseQuote?.askSize ?: 1000) * 0.4).toInt(),
            estimatedLatencyMicros = 480L,
            feePerContract = 0.90,
            score = 79.1
        )

        val comparisons = listOf(venueCme, venueIce, venueEurex)

        // Select venue with tightest price and deepest book on the relevant side
        val best = if (side == OrderSide.BUY) {
            comparisons.minByOrNull { it.askPrice } ?: venueCme
        } else {
            comparisons.maxByOrNull { it.bidPrice } ?: venueCme
        }

        val expectedPx = if (side == OrderSide.BUY) best.askPrice else best.bidPrice

        return RoutingDecision(
            selectedVenueId = best.venueId,
            venueComparisons = comparisons,
            routingReason = "Selected ${best.venueName} for optimal net price ($expectedPx), lowest latency (${best.estimatedLatencyMicros}µs) and lowest fee ($${best.feePerContract}/lot).",
            expectedNetPrice = expectedPx
        )
    }
}
