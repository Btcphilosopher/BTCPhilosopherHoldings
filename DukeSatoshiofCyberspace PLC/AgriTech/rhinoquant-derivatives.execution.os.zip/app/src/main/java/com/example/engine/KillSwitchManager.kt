package com.example.engine

import com.example.core.model.KillSwitchState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class KillSwitchAuditEntry(
    val timestampMs: Long = System.currentTimeMillis(),
    val previousState: KillSwitchState,
    val newState: KillSwitchState,
    val triggeredBy: String,
    val reason: String,
    val affectedOrdersCount: Int = 0
)

class KillSwitchManager {
    private val _state = MutableStateFlow(KillSwitchState.TRADING)
    val state: StateFlow<KillSwitchState> = _state.asStateFlow()

    private val auditHistory = mutableListOf<KillSwitchAuditEntry>()

    fun getAuditHistory(): List<KillSwitchAuditEntry> = synchronized(auditHistory) { auditHistory.toList() }

    @Synchronized
    fun setTradingState(newState: KillSwitchState, user: String, reason: String, affectedCount: Int = 0): KillSwitchAuditEntry {
        val prev = _state.value
        _state.value = newState
        val entry = KillSwitchAuditEntry(
            previousState = prev,
            newState = newState,
            triggeredBy = user,
            reason = reason,
            affectedOrdersCount = affectedCount
        )
        auditHistory.add(0, entry)
        return entry
    }

    fun isTradingAllowed(): Boolean = _state.value == KillSwitchState.TRADING || _state.value == KillSwitchState.ARMED
}
