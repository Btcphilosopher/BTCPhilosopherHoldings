package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.model.*
import com.example.engine.TradingPlatformManager
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.math.abs

enum class TerminalTab(val label: String) {
    EXECUTION("EXECUTION"),
    BLOTTER("BLOTTER"),
    POSITIONS("POSITIONS"),
    MARKET("MARKET"),
    RISK("RISK & MARGIN"),
    ALGOS("ALGOS"),
    RECONCILIATION("RECON"),
    AUDIT("AUDIT"),
    DEMOS("DEMOS & STRESS"),
    CERTIFICATION("SYSTEM")
}

data class OrderTicketState(
    val selectedInstrumentId: String = "SR3Z26",
    val side: OrderSide = OrderSide.BUY,
    val quantity: Int = 50,
    val priceText: String = "95.125",
    val orderType: OrderType = OrderType.LIMIT,
    val timeInForce: TimeInForce = TimeInForce.DAY,
    val isIceberg: Boolean = false,
    val displayQuantityText: String = "10",
    val calculatedMargin: Double = 0.0,
    val calculatedNotional: Double = 0.0,
    val expectedSlippageBps: Double = 0.12,
    val riskStatus: String = "PRE-APPROVED"
)

class RhinoTerminalViewModel : ViewModel() {

    val platformManager = TradingPlatformManager(viewModelScope)

    private val _currentTab = MutableStateFlow(TerminalTab.EXECUTION)
    val currentTab: StateFlow<TerminalTab> = _currentTab.asStateFlow()

    private val _ticketState = MutableStateFlow(OrderTicketState())
    val ticketState: StateFlow<OrderTicketState> = _ticketState.asStateFlow()

    private val _selectedInstrumentId = MutableStateFlow("SR3Z26")
    val selectedInstrumentId: StateFlow<String> = _selectedInstrumentId.asStateFlow()

    private val _activeOrderBook = MutableStateFlow(
        platformManager.matchingEngine.getPublicOrderBook("SR3Z26", platformManager.marketData.getQuote("SR3Z26"))
    )
    val activeOrderBook: StateFlow<OrderBook> = _activeOrderBook.asStateFlow()

    private val _quotes = MutableStateFlow<Map<String, MarketQuote>>(emptyMap())
    val quotes: StateFlow<Map<String, MarketQuote>> = _quotes.asStateFlow()

    // Dialog state
    var selectedOrderForReplace = MutableStateFlow<Order?>(null)
    var showKillSwitchModal = MutableStateFlow(false)
    var activeDemoBanner = MutableStateFlow<String?>(null)

    init {
        // Collect market data events
        viewModelScope.launch {
            val initMap = mutableMapOf<String, MarketQuote>()
            for (inst in InstrumentMaster.ALL_INSTRUMENTS) {
                platformManager.marketData.getQuote(inst.instrumentId)?.let { initMap[inst.instrumentId] = it }
            }
            _quotes.value = initMap

            platformManager.marketData.eventFlow.collect { event ->
                if (event is MarketDataEvent.QuoteUpdate) {
                    val updated = _quotes.value.toMutableMap()
                    updated[event.instrumentId] = event.quote
                    _quotes.value = updated

                    if (event.instrumentId == _selectedInstrumentId.value) {
                        _activeOrderBook.value = platformManager.matchingEngine.getPublicOrderBook(event.instrumentId, event.quote)
                    }
                }
            }
        }

        updateTicketCalculations()
    }

    fun selectTab(tab: TerminalTab) {
        _currentTab.value = tab
    }

    fun selectInstrument(instrumentId: String) {
        _selectedInstrumentId.value = instrumentId
        val q = platformManager.marketData.getQuote(instrumentId)
        val defaultPx = if (q != null) "%.${InstrumentMaster.findById(instrumentId)?.pricePrecision ?: 3}f".format(q.lastPrice) else "95.125"
        _ticketState.value = _ticketState.value.copy(
            selectedInstrumentId = instrumentId,
            priceText = defaultPx
        )
        _activeOrderBook.value = platformManager.matchingEngine.getPublicOrderBook(instrumentId, q)
        updateTicketCalculations()
    }

    fun updateTicketSide(side: OrderSide) {
        _ticketState.value = _ticketState.value.copy(side = side)
        updateTicketCalculations()
    }

    fun updateTicketQuantity(qty: Int) {
        _ticketState.value = _ticketState.value.copy(quantity = qty.coerceAtLeast(1))
        updateTicketCalculations()
    }

    fun updateTicketPrice(priceText: String) {
        _ticketState.value = _ticketState.value.copy(priceText = priceText)
        updateTicketCalculations()
    }

    fun updateTicketOrderType(type: OrderType) {
        _ticketState.value = _ticketState.value.copy(orderType = type)
        updateTicketCalculations()
    }

    fun updateTicketTif(tif: TimeInForce) {
        _ticketState.value = _ticketState.value.copy(timeInForce = tif)
    }

    fun toggleIceberg(enabled: Boolean) {
        _ticketState.value = _ticketState.value.copy(isIceberg = enabled)
    }

    fun updateDisplayQuantity(qtyText: String) {
        _ticketState.value = _ticketState.value.copy(displayQuantityText = qtyText)
    }

    private fun updateTicketCalculations() {
        val s = _ticketState.value
        val inst = InstrumentMaster.findById(s.selectedInstrumentId) ?: return
        val px = s.priceText.toDoubleOrNull() ?: 95.125
        val notional = s.quantity * px * inst.multiplier
        val margin = s.quantity * inst.initialMarginPerContract

        _ticketState.value = s.copy(
            calculatedNotional = notional,
            calculatedMargin = margin
        )
    }

    fun submitOrderFromTicket(): Pair<Order, RiskDecision>? {
        val s = _ticketState.value
        val px = s.priceText.toDoubleOrNull() ?: return null
        val displayQty = if (s.isIceberg) s.displayQuantityText.toIntOrNull() else null

        val result = platformManager.submitOrder(
            instrumentId = s.selectedInstrumentId,
            side = s.side,
            quantity = s.quantity,
            price = px,
            orderType = s.orderType,
            timeInForce = s.timeInForce,
            displayQuantity = displayQty
        )

        // Refresh book
        val q = platformManager.marketData.getQuote(s.selectedInstrumentId)
        _activeOrderBook.value = platformManager.matchingEngine.getPublicOrderBook(s.selectedInstrumentId, q)
        return result
    }

    fun submitQuickOrder(instrumentId: String, side: OrderSide, quantity: Int = 10) {
        val q = platformManager.marketData.getQuote(instrumentId)
        val px = if (side == OrderSide.BUY) (q?.askPrice ?: 95.125) else (q?.bidPrice ?: 95.120)
        platformManager.submitOrder(
            instrumentId = instrumentId,
            side = side,
            quantity = quantity,
            price = px,
            orderType = OrderType.LIMIT
        )
        _activeOrderBook.value = platformManager.matchingEngine.getPublicOrderBook(instrumentId, q)
    }

    fun cancelOrder(orderId: String) {
        platformManager.cancelOrder(orderId)
        val q = platformManager.marketData.getQuote(_selectedInstrumentId.value)
        _activeOrderBook.value = platformManager.matchingEngine.getPublicOrderBook(_selectedInstrumentId.value, q)
    }

    fun replaceOrder(orderId: String, newQty: Int, newPx: Double) {
        platformManager.replaceOrder(orderId, newQty, newPx)
        val q = platformManager.marketData.getQuote(_selectedInstrumentId.value)
        _activeOrderBook.value = platformManager.matchingEngine.getPublicOrderBook(_selectedInstrumentId.value, q)
        selectedOrderForReplace.value = null
    }

    fun triggerKillSwitch() {
        platformManager.runDemo6MassCancelKillSwitch()
        showKillSwitchModal.value = false
    }

    fun armKillSwitch() {
        platformManager.killSwitch.setTradingState(KillSwitchState.TRADING, "DESK_HEAD", "Desk trading resumed")
    }

    fun runSignatureDemo(demoIndex: Int) {
        when (demoIndex) {
            1 -> {
                activeDemoBanner.value = "Demo 1: SOFR 3M Futures (SR3 Z6) Execution Chain"
                platformManager.runDemo1SofrFutures()
            }
            2 -> {
                activeDemoBanner.value = "Demo 2: Treasury.OS DV01 Portfolio Hedge (-188 TN Z6)"
                platformManager.runDemo2TreasuryHedge()
            }
            3 -> {
                activeDemoBanner.value = "Demo 3: Options Strategy (SR3 Call Spread with Greeks)"
                platformManager.runDemo3OptionsSpread()
            }
            4 -> {
                activeDemoBanner.value = "Demo 4: Institutional TWAP Execution Algo (1,000 lots)"
                platformManager.runDemo4TwapAlgo()
                selectTab(TerminalTab.ALGOS)
            }
            5 -> {
                activeDemoBanner.value = "Demo 5: Simulated CME Market Data Outage & Gap Recovery"
                platformManager.runDemo5OutageRecovery()
            }
            6 -> {
                activeDemoBanner.value = "Demo 6: Kill Switch Activated - Mass Cancel of all books"
                platformManager.runDemo6MassCancelKillSwitch()
            }
        }
    }
}
