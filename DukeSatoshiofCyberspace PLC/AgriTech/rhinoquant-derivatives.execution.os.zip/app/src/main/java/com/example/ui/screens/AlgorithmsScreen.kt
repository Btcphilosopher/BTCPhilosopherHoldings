package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.ui.RhinoTerminalViewModel
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun AlgorithmsScreen(
    viewModel: RhinoTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val activeAlgos by viewModel.platformManager.activeAlgos.collectAsState()

    var algoType by remember { mutableStateOf(ExecutionAlgorithmType.TWAP) }
    var instId by remember { mutableStateOf("SR3Z26") }
    var side by remember { mutableStateOf(OrderSide.BUY) }
    var totalQty by remember { mutableStateOf(500) }
    var durationMins by remember { mutableStateOf(10) }
    var sliceCount by remember { mutableStateOf(10) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBlack)
            .padding(8.dp)
    ) {
        TerminalSectionHeader(title = "INSTITUTIONAL EXECUTION ALGORITHMS", subtitle = "TWAP • VWAP • POV • Iceberg")

        // Algo Launcher Form Box
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(4.dp))
                .background(RhinoGraphite)
                .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Text("LAUNCH NEW EXECUTION STRATEGY", fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = RhinoGold)
            Spacer(modifier = Modifier.height(6.dp))

            // Algo Type Selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf(ExecutionAlgorithmType.TWAP, ExecutionAlgorithmType.VWAP, ExecutionAlgorithmType.ICEBERG, ExecutionAlgorithmType.IMPLEMENTATION_SHORTFALL).forEach { at ->
                    val isSel = algoType == at
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (isSel) RhinoSurfaceElevated else RhinoBlack)
                            .border(1.dp, if (isSel) RhinoGold else RhinoBorder, RoundedCornerShape(3.dp))
                            .clickable { algoType = at }
                            .padding(vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(at.name, fontFamily = FontFamily.Monospace, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = if (isSel) RhinoGold else SteelMedium)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Quantity & Side Selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // BUY/SELL
                Row(modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(28.dp)
                            .clip(RoundedCornerShape(topStart = 3.dp, bottomStart = 3.dp))
                            .background(if (side == OrderSide.BUY) TerminalGreen else RhinoBlack)
                            .clickable { side = OrderSide.BUY }
                            .padding(2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("BUY", fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (side == OrderSide.BUY) RhinoBlack else SteelLight)
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(28.dp)
                            .clip(RoundedCornerShape(topEnd = 3.dp, bottomEnd = 3.dp))
                            .background(if (side == OrderSide.SELL) TerminalRed else RhinoBlack)
                            .clickable { side = OrderSide.SELL }
                            .padding(2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("SELL", fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (side == OrderSide.SELL) RhinoBlack else SteelLight)
                    }
                }

                // Lots selector
                Row(
                    modifier = Modifier.weight(1.5f),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(250, 500, 1000, 2000).forEach { q ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(3.dp))
                                .background(if (totalQty == q) RhinoGold else RhinoBlack)
                                .clickable { totalQty = q }
                                .padding(vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("$q", fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (totalQty == q) RhinoBlack else SteelLight)
                        }
                    }
                }

                // Launch Button
                Button(
                    onClick = {
                        viewModel.platformManager.startAlgoExecution(
                            name = "$instId ${algoType.name} $totalQty lots",
                            instrumentId = instId,
                            side = side,
                            totalQuantity = totalQty,
                            algoType = algoType,
                            durationMinutes = durationMins,
                            sliceCount = sliceCount
                        )
                    },
                    modifier = Modifier
                        .weight(1.2f)
                        .height(30.dp),
                    shape = RoundedCornerShape(3.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = RhinoGold)
                ) {
                    Text("START ALGO", fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = RhinoBlack)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Active Algos List
        Text("ACTIVE STRATEGY INSTANCES (${activeAlgos.size})", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RhinoGold)
        Spacer(modifier = Modifier.height(6.dp))

        if (activeAlgos.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(4.dp))
                    .background(RhinoGraphite)
                    .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("NO ACTIVE ALGORITHMIC INSTANCES", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = SteelDark)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(activeAlgos, key = { it.planId }) { algo ->
                    val progress = if (algo.totalQuantity > 0) algo.filledQuantity.toFloat() / algo.totalQuantity else 0f

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(RhinoGraphite)
                            .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(algo.name, fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SteelLight)
                                Text("${algo.planId} • ${algo.algoType.displayName}", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark)
                            }
                            StatusBadge(algo.status.name)
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Progress Bar
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = TerminalGreen,
                            trackColor = RhinoBlack
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Filled: ${algo.filledQuantity} / ${algo.totalQuantity} (%.0f%%)".format(progress * 100), fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = SteelLight)
                            Text("Avg Px: %.3f".format(algo.averageExecutionPrice), fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = RhinoGold)
                            Text("Shortfall: %.2f bps".format(algo.implementationShortfallBps), fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = if (algo.implementationShortfallBps <= 0) TerminalGreen else WarningYellow)
                        }
                    }
                }
            }
        }
    }
}
