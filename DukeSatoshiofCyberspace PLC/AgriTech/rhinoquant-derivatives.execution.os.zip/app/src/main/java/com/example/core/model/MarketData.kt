package com.example.core.model

data class PriceLevel(
    val price: Double,
    val quantity: Int,
    val orderCount: Int
)

data class OrderBook(
    val instrumentId: String,
    val bids: List<PriceLevel>, // Sorted descending by price
    val asks: List<PriceLevel>, // Sorted ascending by price
    val timestampNanos: Long = System.nanoTime()
) {
    val bestBid: PriceLevel? get() = bids.firstOrNull()
    val bestAsk: PriceLevel? get() = asks.firstOrNull()
    val spread: Double get() {
        val b = bestBid?.price ?: return 0.0
        val a = bestAsk?.price ?: return 0.0
        return (a - b).coerceAtLeast(0.0)
    }
    val midPrice: Double get() {
        val b = bestBid?.price ?: return 0.0
        val a = bestAsk?.price ?: return b
        return (a + b) / 2.0
    }
    val microPrice: Double get() {
        val b = bestBid ?: return midPrice
        val a = bestAsk ?: return midPrice
        val totalQty = b.quantity + a.quantity
        return if (totalQty > 0) {
            (b.price * a.quantity + a.price * b.quantity) / totalQty
        } else midPrice
    }
}

data class MarketQuote(
    val instrumentId: String,
    val symbol: String,
    val bidPrice: Double,
    val askPrice: Double,
    val bidSize: Int,
    val askSize: Int,
    val lastPrice: Double,
    val lastSize: Int,
    val volume: Long,
    val openInterest: Long,
    val settlementPrice: Double,
    val high: Double,
    val low: Double,
    val open: Double,
    val prevClose: Double,
    val netChange: Double = lastPrice - prevClose,
    val percentChange: Double = if (prevClose > 0) ((lastPrice - prevClose) / prevClose) * 100.0 else 0.0,
    val timestampEpochMs: Long = System.currentTimeMillis()
)

sealed interface MarketDataEvent {
    val instrumentId: String
    val timestampNanos: Long

    data class QuoteUpdate(
        override val instrumentId: String,
        override val timestampNanos: Long = System.nanoTime(),
        val quote: MarketQuote
    ) : MarketDataEvent

    data class BookUpdate(
        override val instrumentId: String,
        override val timestampNanos: Long = System.nanoTime(),
        val book: OrderBook
    ) : MarketDataEvent

    data class TradeUpdate(
        override val instrumentId: String,
        override val timestampNanos: Long = System.nanoTime(),
        val tradePrice: Double,
        val tradeQuantity: Int,
        val aggressorSide: OrderSide
    ) : MarketDataEvent

    data class SessionChange(
        override val instrumentId: String,
        override val timestampNanos: Long = System.nanoTime(),
        val sessionState: String
    ) : MarketDataEvent
}
