package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.RhinoTerminalViewModel
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun AuditTrailScreen(
    viewModel: RhinoTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val auditLogs by viewModel.platformManager.auditRecords.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBlack)
            .padding(8.dp)
    ) {
        TerminalSectionHeader(title = "IMMUTABLE AUDIT TRAIL", subtitle = "WORM Compliant • Nanosecond Precision")

        Text("TRANSACTION & RISK EVENT LOG (${auditLogs.size} EVENTS)", fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = RhinoGold)
        Spacer(modifier = Modifier.height(6.dp))

        if (auditLogs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(4.dp))
                    .background(RhinoGraphite)
                    .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("AUDIT STREAM INITIALIZING...", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = SteelDark)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(auditLogs, key = { it.auditId }) { rec ->
                    val isRiskEvent = rec.serviceName == "PreTradeRisk"
                    val isKillEvent = rec.serviceName == "KillSwitch"

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(3.dp))
                            .background(RhinoGraphite)
                            .border(1.dp, if (isKillEvent) TerminalRed else RhinoBorder, RoundedCornerShape(3.dp))
                            .padding(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(rec.timestampFormatted, fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = SteelLight)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(rec.serviceName, fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = RhinoGold)
                            }
                            StatusBadge(rec.eventType)
                        }

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = rec.payloadSummary,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 8.sp,
                            color = SteelMedium
                        )

                        if (rec.orderId != null) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Order: ${rec.orderId}", fontFamily = FontFamily.Monospace, fontSize = 7.sp, color = SteelDark)
                                if (rec.oldState != null && rec.newState != null) {
                                    Text("Transition: ${rec.oldState} -> ${rec.newState}", fontFamily = FontFamily.Monospace, fontSize = 7.sp, color = RhinoCyan)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
