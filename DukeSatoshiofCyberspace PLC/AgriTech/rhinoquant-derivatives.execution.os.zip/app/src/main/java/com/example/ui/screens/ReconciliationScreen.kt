package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.RhinoTerminalViewModel
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun ReconciliationScreen(
    viewModel: RhinoTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val dropCopyEngine = viewModel.platformManager.dropCopyRecon
    val reconItems = dropCopyEngine.getReconItems()
    val dropCopyMessages = dropCopyEngine.getDropCopyMessages()

    val matchedCount = reconItems.count { it.status.name == "MATCHED" }
    val mismatchCount = reconItems.count { it.status.name == "MISMATCH" || it.status.name == "MISSING_FILL" }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBlack)
            .padding(8.dp)
    ) {
        TerminalSectionHeader(title = "4-WAY RECONCILIATION & DROP COPY LEDGER", subtitle = "Internal Blotter ↔ Exchange Gateway ↔ Drop Copy ↔ Clearing")

        // Summary Metric Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            MetricBox(
                label = "TOTAL TRADES",
                value = "${reconItems.size}",
                subValue = "100% Processed",
                valueColor = SteelLight,
                modifier = Modifier.weight(1f)
            )
            MetricBox(
                label = "MATCHED (4-WAY)",
                value = "$matchedCount",
                subValue = "Zero Variance",
                valueColor = TerminalGreen,
                modifier = Modifier.weight(1f)
            )
            MetricBox(
                label = "DISCREPANCIES",
                value = "$mismatchCount",
                subValue = if (mismatchCount > 0) "Action Required" else "Clean Ledger",
                valueColor = if (mismatchCount > 0) TerminalRed else SteelMedium,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Reconciliation Items Table
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("TRADE RECONCILIATION LEDGER (${reconItems.size})", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RhinoGold)

            // Inject discrepancy test button
            if (reconItems.isNotEmpty()) {
                Button(
                    onClick = { dropCopyEngine.injectDiscrepancy(reconItems.first().executionId) },
                    modifier = Modifier.height(26.dp),
                    shape = RoundedCornerShape(3.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = WarningYellow)
                ) {
                    Text("INJECT RECON TEST DISCREPANCY", fontFamily = FontFamily.Monospace, fontSize = 7.sp, fontWeight = FontWeight.Bold, color = RhinoBlack)
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        if (reconItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(4.dp))
                    .background(RhinoGraphite)
                    .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("NO TRADES RECONCILED YET — EXECUTE ORDERS TO POPULATE", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = SteelDark)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(reconItems, key = { it.reconId }) { item ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(RhinoGraphite)
                            .border(1.dp, if (item.status.name == "MATCHED") RhinoBorder else TerminalRed, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(item.executionId, fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SteelLight)
                                Text("Order: ${item.orderId}", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark)
                            }
                            StatusBadge(item.status.name)
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // 4-Way Comparison Grid
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(3.dp))
                                .background(RhinoBlack)
                                .padding(6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("1. INTERNAL", fontFamily = FontFamily.Monospace, fontSize = 7.sp, color = SteelDark)
                                Text("${item.internalFillQuantity} @ ${item.internalFillPrice}", fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = SteelLight)
                            }
                            Column {
                                Text("2. DROP COPY", fontFamily = FontFamily.Monospace, fontSize = 7.sp, color = SteelDark)
                                Text("${item.dropCopyQuantity ?: "--"} @ ${item.dropCopyPrice ?: "--"}", fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = SteelLight)
                            }
                            Column {
                                Text("3. CLEARING", fontFamily = FontFamily.Monospace, fontSize = 7.sp, color = SteelDark)
                                Text("${item.clearingQuantity ?: "--"} @ ${item.clearingPrice ?: "--"}", fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = SteelLight)
                            }
                        }

                        if (item.discrepancies.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            item.discrepancies.forEach { disc ->
                                Text("⚠ $disc", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TerminalRed)
                            }
                        }
                    }
                }
            }
        }
    }
}
