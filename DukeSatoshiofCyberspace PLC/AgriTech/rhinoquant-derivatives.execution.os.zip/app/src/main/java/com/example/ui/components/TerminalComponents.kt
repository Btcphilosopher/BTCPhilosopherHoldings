package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.OrderBook
import com.example.core.model.OrderSide
import com.example.core.model.PriceLevel
import com.example.ui.theme.*

@Composable
fun MonospacePriceText(
    price: Double,
    precision: Int = 3,
    modifier: Modifier = Modifier,
    color: Color = SteelLight,
    fontSize: Int = 13,
    fontWeight: FontWeight = FontWeight.Bold
) {
    val formatted = "%.${precision}f".format(price)
    Text(
        text = formatted,
        fontFamily = FontFamily.Monospace,
        fontWeight = fontWeight,
        fontSize = fontSize.sp,
        color = color,
        modifier = modifier
    )
}

@Composable
fun StatusBadge(
    status: String,
    modifier: Modifier = Modifier
) {
    val (bg, fg) = when (status.uppercase()) {
        "FILLED", "MATCHED", "APPROVED", "PASS", "UP", "OPEN" -> Pair(TerminalGreenBg, TerminalGreen)
        "WORKING", "SCHEDULED", "RUNNING", "TRADING" -> Pair(InfoBlueBg, InfoBlue)
        "REJECTED", "FAIL", "DOWN", "KILLED", "EXCEPTION", "MISMATCH" -> Pair(TerminalRedBg, TerminalRed)
        "CANCELLED", "EXPIRED", "PAUSED", "WARNING", "DEGRADED" -> Pair(WarningYellowBg, WarningYellow)
        "SIMULATED" -> Pair(Color(0x339C27B0), Color(0xFFCE93D8))
        "PAPER" -> Pair(Color(0x330288D1), Color(0xFF81D4FA))
        "CERTIFICATION" -> Pair(Color(0x33F57C00), Color(0xFFFFB74D))
        "PRODUCTION" -> Pair(Color(0x33D50000), Color(0xFFFF8A80))
        else -> Pair(RhinoSurfaceElevated, SteelMedium)
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(3.dp))
            .background(bg)
            .border(1.dp, fg.copy(alpha = 0.4f), RoundedCornerShape(3.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = status.uppercase(),
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = fg,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun MetricBox(
    label: String,
    value: String,
    subValue: String? = null,
    valueColor: Color = SteelLight,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(RhinoGraphite)
            .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = label.uppercase(),
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            color = SteelDark,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = valueColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        if (subValue != null) {
            Spacer(modifier = Modifier.height(1.dp))
            Text(
                text = subValue,
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                color = SteelDark,
                maxLines = 1
            )
        }
    }
}

@Composable
fun TerminalSectionHeader(
    title: String,
    subtitle: String? = null,
    trailingContent: @Composable (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(width = 3.dp, height = 12.dp)
                    .background(RhinoGold)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title.uppercase(),
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = SteelLight,
                letterSpacing = 1.sp
            )
            if (subtitle != null) {
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "• $subtitle",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = SteelDark
                )
            }
        }
        trailingContent?.invoke()
    }
}

@Composable
fun OrderBookLadderView(
    book: OrderBook,
    precision: Int = 3,
    onPriceClick: (Double) -> Unit,
    modifier: Modifier = Modifier
) {
    val maxQty = maxOf(
        (book.bids.maxOfOrNull { it.quantity } ?: 100),
        (book.asks.maxOfOrNull { it.quantity } ?: 100)
    ).coerceAtLeast(1)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(RhinoGraphite)
            .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
            .padding(6.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("SIZE / ORDERS", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark)
            Text("BID / ASK", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelDark)
            Text("SPREAD: ${"%.${precision}f".format(book.spread)}", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = RhinoGold)
        }

        // Asks (Reverse so highest is top, best ask is lowest)
        book.asks.reversed().forEach { level ->
            DepthLevelRow(level = level, maxQty = maxQty, side = OrderSide.SELL, precision = precision, onClick = { onPriceClick(level.price) })
        }

        // Mid Market Spread Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 3.dp)
                .background(RhinoSurfaceElevated)
                .padding(vertical = 2.dp, horizontal = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("MID: ${"%.${precision}f".format(book.midPrice)}", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = SteelMedium)
                Text("MICRO: ${"%.${precision}f".format(book.microPrice)}", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = RhinoCyan)
            }
        }

        // Bids (Best bid top)
        book.bids.forEach { level ->
            DepthLevelRow(level = level, maxQty = maxQty, side = OrderSide.BUY, precision = precision, onClick = { onPriceClick(level.price) })
        }
    }
}

@Composable
private fun DepthLevelRow(
    level: PriceLevel,
    maxQty: Int,
    side: OrderSide,
    precision: Int,
    onClick: () -> Unit
) {
    val barFraction = (level.quantity.toFloat() / maxQty).coerceIn(0.05f, 1.0f)
    val color = if (side == OrderSide.BUY) TerminalGreen else TerminalRed
    val barColor = if (side == OrderSide.BUY) TerminalGreen.copy(alpha = 0.15f) else TerminalRed.copy(alpha = 0.15f)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(20.dp)
            .clickable { onClick() }
    ) {
        // Visual depth fill bar
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(barFraction)
                .align(if (side == OrderSide.BUY) Alignment.CenterStart else Alignment.CenterEnd)
                .background(barColor)
        )

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${level.quantity} (${level.orderCount})",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = SteelMedium
            )
            Text(
                text = "%.${precision}f".format(level.price),
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }
    }
}
