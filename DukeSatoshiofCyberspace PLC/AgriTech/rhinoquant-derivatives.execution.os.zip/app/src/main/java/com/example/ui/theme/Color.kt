package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// RhinoQuant Institutional Color Palette
// British Financial Engineering & Modern Derivatives Exchange Infrastructure
val RhinoBlack = Color(0xFF06090E)
val RhinoGraphite = Color(0xFF0D141F)
val RhinoSurface = Color(0xFF131D2D)
val RhinoSurfaceElevated = Color(0xFF1B283D)
val RhinoBorder = Color(0xFF243650)
val RhinoBorderHighlight = Color(0xFF3B5377)

// Monochromatic Slate & Metals
val SteelLight = Color(0xFFE2E8F0)
val SteelMedium = Color(0xFF94A3B8)
val SteelDark = Color(0xFF64748B)
val SteelMuted = Color(0xFF475569)

// Quantitative Accent Colors (Strict, Restrained)
val RhinoGold = Color(0xFFD4AF37)
val RhinoGoldLight = Color(0xFFE5C158)
val RhinoAmber = Color(0xFFFFB300)
val RhinoCyan = Color(0xFF00E5FF)
val RhinoBlue = Color(0xFF2979FF)

// Market State Indicators (Terminal Green & Dark Orange-Red)
val TerminalGreen = Color(0xFF00E676)
val TerminalGreenDark = Color(0xFF00897B)
val TerminalGreenBg = Color(0x1A00E676)

val TerminalRed = Color(0xFFFF5252)
val TerminalRedDark = Color(0xFFC62828)
val TerminalRedBg = Color(0x1AFF5252)

val WarningYellow = Color(0xFFFFD600)
val WarningYellowBg = Color(0x1AFFD600)

val InfoBlue = Color(0xFF40C4FF)
val InfoBlueBg = Color(0x1A40C4FF)

// Environment Badges
val SimulationPurple = Color(0xFF9C27B0)
val PaperBlue = Color(0xFF0288D1)
val CertificationAmber = Color(0xFFF57C00)
val ProductionRed = Color(0xFFD50000)
