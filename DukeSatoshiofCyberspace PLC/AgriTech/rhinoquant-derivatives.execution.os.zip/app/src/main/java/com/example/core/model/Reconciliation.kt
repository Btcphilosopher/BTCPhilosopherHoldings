package com.example.core.model

enum class ReconStatus(val displayName: String) {
    MATCHED("MATCHED"),
    MISMATCH("MISMATCH"),
    MISSING_FILL("MISSING FILL"),
    DUPLICATE_FILL("DUPLICATE FILL"),
    EXCEPTION("EXCEPTION"),
    PENDING("PENDING")
}

data class DropCopyMessage(
    val dropCopyId: String,
    val orderId: String,
    val executionId: String,
    val instrumentId: String,
    val side: OrderSide,
    val fillQuantity: Int,
    val fillPrice: Double,
    val venueSequenceNumber: Long,
    val clearingMemberId: String = "RHINO_CLEARING_001",
    val timestampEpochMs: Long = System.currentTimeMillis()
)

data class ClearingRecord(
    val tradeId: String,
    val orderId: String,
    val instrumentId: String,
    val side: OrderSide,
    val quantity: Int,
    val price: Double,
    val grossValue: Double,
    val clearingFee: Double,
    val settlementDate: String,
    val status: String = "CLEARED"
)

data class ReconciliationItem(
    val reconId: String,
    val orderId: String,
    val executionId: String,
    val internalFillQuantity: Int,
    val internalFillPrice: Double,
    val dropCopyQuantity: Int?,
    val dropCopyPrice: Double?,
    val clearingQuantity: Int?,
    val clearingPrice: Double?,
    val status: ReconStatus,
    val discrepancies: List<String> = emptyList(),
    val timestampEpochMs: Long = System.currentTimeMillis()
)
