package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.RhinoTerminalViewModel
import com.example.ui.components.*
import com.example.ui.theme.*

data class DemoCardItem(
    val index: Int,
    val title: String,
    val subtitle: String,
    val description: String,
    val badge: String,
    val isEmergency: Boolean = false
)

@Composable
fun SignatureDemosScreen(
    viewModel: RhinoTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val activeBanner by viewModel.activeDemoBanner.collectAsState()

    val demos = listOf(
        DemoCardItem(1, "DEMO 1: SOFR FUTURES EXECUTION CHAIN", "RhinoQuant Curve.OS 10Y View -> Buy 50 SR3 Z6", "Takes trade intent from Curve.OS, validates pre-trade risk, routes to CME iLink3, matches in price-time FIFO, records fill, updates position & SPAN margin.", "CORE"),
        DemoCardItem(2, "DEMO 2: TREASURY.OS DV01 PORTFOLIO HEDGE", "Neutralize +\$18,500 DV01 -> Sell 188 TN Z6", "RhinoQuant Treasury.OS integration: Reads net positive duration DV01 exposure and executes precise Ultra 10Y futures hedge to bring portfolio DV01 to zero.", "HEDGING"),
        DemoCardItem(3, "DEMO 3: OPTIONS MULTI-LEG SPREAD", "SR3 Z6 Bull Call Spread + Real-time Greeks", "Executes multi-leg derivative strategy with automatic Black-Scholes Delta, Gamma, Vega, Theta computation and SPAN margin relief offset.", "OPTIONS"),
        DemoCardItem(4, "DEMO 4: INSTITUTIONAL TWAP ALGO", "1,000 Lots Sliced Execution with Slippage Tracking", "Launches institutional TWAP execution algorithm. Slices order into deterministic chunks, minimizes market impact, and computes Implementation Shortfall bps.", "ALGO"),
        DemoCardItem(5, "DEMO 5: SIMULATED MARKET DATA OUTAGE & RECOVERY", "CME MDP 3.0 Drop -> Sequence Gap Replay", "Simulates multicast network drop, activates gateway pause, initiates TCP historical replay channel, recovers sequence gaps, and restores continuous trading.", "RESILIENCE"),
        DemoCardItem(6, "DEMO 6: MASTER KILL SWITCH & MASS CANCEL", "Emergency Circuit Breaker -> Mass Cancel All Books", "Instantly triggers desk kill switch. Halts all incoming order ingress, cancels all resting orders across all trading venues, and emits regulatory audit trail.", "SAFETY", isEmergency = true)
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBlack)
            .padding(8.dp)
    ) {
        TerminalSectionHeader(title = "RHINOQUANT SIGNATURE DEMOS & STRESS LAB", subtitle = "Deterministic End-to-End Workflows")

        if (activeBanner != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TerminalGreenBg)
                    .border(1.dp, TerminalGreen, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ACTIVE: ${activeBanner!!}",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = TerminalGreen
                    )
                    Text(
                        text = "DISMISS",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 8.sp,
                        color = SteelLight,
                        modifier = Modifier.clickable { viewModel.activeDemoBanner.value = null }
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
        }

        // MARKET STRESS TESTING TOOLS
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(4.dp))
                .background(RhinoGraphite)
                .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Text("MARKET MICROSTRUCTURE STRESS INJECTORS", fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = RhinoGold)
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Button(
                    onClick = { viewModel.platformManager.marketData.injectFlashMove("SR3Z26", -0.015) },
                    modifier = Modifier
                        .weight(1f)
                        .height(28.dp),
                    shape = RoundedCornerShape(3.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TerminalRed)
                ) {
                    Text("-1.5% FLASH", fontFamily = FontFamily.Monospace, fontSize = 7.sp, fontWeight = FontWeight.Bold, color = RhinoBlack)
                }
                Button(
                    onClick = { viewModel.platformManager.marketData.injectSpreadWidening(5.0) },
                    modifier = Modifier
                        .weight(1f)
                        .height(28.dp),
                    shape = RoundedCornerShape(3.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = WarningYellow)
                ) {
                    Text("5X SPREAD", fontFamily = FontFamily.Monospace, fontSize = 7.sp, fontWeight = FontWeight.Bold, color = RhinoBlack)
                }
                Button(
                    onClick = { viewModel.platformManager.marketData.injectVolatilitySpike(4.0) },
                    modifier = Modifier
                        .weight(1f)
                        .height(28.dp),
                    shape = RoundedCornerShape(3.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = RhinoCyan)
                ) {
                    Text("4X VOL", fontFamily = FontFamily.Monospace, fontSize = 7.sp, fontWeight = FontWeight.Bold, color = RhinoBlack)
                }
                Button(
                    onClick = { viewModel.platformManager.marketData.resetStressState() },
                    modifier = Modifier
                        .weight(1f)
                        .height(28.dp),
                    shape = RoundedCornerShape(3.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TerminalGreen)
                ) {
                    Text("RESET", fontFamily = FontFamily.Monospace, fontSize = 7.sp, fontWeight = FontWeight.Bold, color = RhinoBlack)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Demos List
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(demos, key = { it.index }) { demo ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(RhinoGraphite)
                        .border(1.dp, if (demo.isEmergency) TerminalRed else RhinoBorder, RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(demo.title, fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (demo.isEmergency) TerminalRed else SteelLight)
                            Text(demo.subtitle, fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = RhinoGold)
                        }
                        StatusBadge(demo.badge)
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(demo.description, fontFamily = FontFamily.SansSerif, fontSize = 9.sp, color = SteelMedium)
                    Spacer(modifier = Modifier.height(6.dp))

                    Button(
                        onClick = { viewModel.runSignatureDemo(demo.index) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(30.dp),
                        shape = RoundedCornerShape(3.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = if (demo.isEmergency) TerminalRed else RhinoGold)
                    ) {
                        Text("EXECUTE ${demo.title}", fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = RhinoBlack)
                    }
                }
            }
        }
    }
}
