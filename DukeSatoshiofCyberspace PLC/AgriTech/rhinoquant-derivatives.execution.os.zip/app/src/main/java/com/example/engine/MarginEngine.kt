package com.example.engine

import com.example.core.model.AccountMarginState
import com.example.core.model.Instrument
import com.example.core.model.InstrumentMaster
import com.example.core.model.Position
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MarginEngine {

    fun calculateMarginRequirements(
        positions: List<Position>,
        currentAccountState: AccountMarginState
    ): AccountMarginState {
        var rawInitialMargin = 0.0
        var rawMaintenanceMargin = 0.0
        var totalRealized = 0.0
        var totalUnrealized = 0.0
        var totalFees = 0.0

        for (p in positions) {
            rawInitialMargin += p.initialMargin
            rawMaintenanceMargin += p.maintenanceMargin
            totalRealized += p.realizedPnL
            totalUnrealized += p.unrealizedPnL
            totalFees += p.feesPaid
        }

        // Apply SPAN-like Calendar Spread Margin Offsets
        val spreadDiscount = calculateSpreadOffsets(positions)
        val netInitialMargin = max(0.0, rawInitialMargin - spreadDiscount)
        val netMaintenanceMargin = max(0.0, rawMaintenanceMargin - (spreadDiscount * 0.85))

        return currentAccountState.copy(
            initialMarginRequired = netInitialMargin,
            maintenanceMarginRequired = netMaintenanceMargin,
            variationMargin = totalUnrealized,
            realizedPnL = totalRealized,
            unrealizedPnL = totalUnrealized,
            totalFeesPaid = totalFees,
            portfolioSpanDiscount = spreadDiscount
        )
    }

    private fun calculateSpreadOffsets(positions: List<Position>): Double {
        var discount = 0.0

        // Check for SR3 Z6 vs SR3 H7 Calendar Spread offset
        val z6Pos = positions.find { it.instrumentId == "SR3Z26" }?.quantity ?: 0
        val h7Pos = positions.find { it.instrumentId == "SR3H27" }?.quantity ?: 0

        if (z6Pos != 0 && h7Pos != 0 && (z6Pos > 0 && h7Pos < 0 || z6Pos < 0 && h7Pos > 0)) {
            val matchedSpreadLegs = min(abs(z6Pos), abs(h7Pos))
            // CME SOFR Calendar spread credit: 80% margin relief on paired legs
            val grossLegMargin = matchedSpreadLegs * (1150.0 + 1150.0)
            discount += grossLegMargin * 0.80
        }

        // Check for 10Y Note (ZN) vs Ultra 10Y (TN) curve spread
        val znPos = positions.find { it.instrumentId == "ZNZ26" }?.quantity ?: 0
        val tnPos = positions.find { it.instrumentId == "TNZ26" }?.quantity ?: 0
        if (znPos != 0 && tnPos != 0 && (znPos > 0 && tnPos < 0 || znPos < 0 && tnPos > 0)) {
            val matchedPairs = min(abs(znPos), abs(tnPos))
            val grossLegMargin = matchedPairs * (2200.0 + 2850.0)
            discount += grossLegMargin * 0.65
        }

        return discount
    }

    fun calculateSinglePositionMargin(
        instrument: Instrument,
        quantity: Int,
        marketPrice: Double
    ): Pair<Double, Double> {
        if (quantity == 0) return Pair(0.0, 0.0)
        val absQty = abs(quantity)

        return if (!instrument.isOption) {
            val init = absQty * instrument.initialMarginPerContract
            val maint = absQty * instrument.maintenanceMarginPerContract
            Pair(init, maint)
        } else {
            if (quantity > 0) {
                // Long Option: Premium paid is full maximum risk
                val premium = absQty * marketPrice * instrument.multiplier
                Pair(premium, premium)
            } else {
                // Short Option Margin: Higher requirement
                val nakedMargin = absQty * (instrument.initialMarginPerContract * 1.5)
                Pair(nakedMargin, nakedMargin * 0.8)
            }
        }
    }
}
