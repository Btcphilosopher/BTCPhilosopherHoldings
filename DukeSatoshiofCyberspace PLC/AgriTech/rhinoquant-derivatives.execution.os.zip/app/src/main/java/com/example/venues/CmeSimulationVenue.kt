package com.example.venues

import com.example.core.model.Order
import com.example.core.model.OrderSide
import kotlinx.coroutines.delay

class ReferenceDataAdapter {
    fun getProductSpecifications(symbol: String): Map<String, String> {
        return mapOf(
            "protocol" to "MDP 3.0 / SBE",
            "marketSegment" to "RATES_USD_SOFR",
            "orderTypesSupported" to "LIMIT,MARKET,STOP,STOP_LIMIT,ICEBERG",
            "tifSupported" to "DAY,GTC,IOC,FOK",
            "impliedSpreadEligible" to "TRUE"
        )
    }
}

class CmeOrderEntryAdapter {
    private var sequenceNumber = 10001L

    suspend fun sendNewOrderSingle(order: Order): OrderAcknowledgement {
        delay(1) // Simulated wire latency 1ms
        val venueAssignedId = "CME-GLBX-${sequenceNumber++}"
        return OrderAcknowledgement(
            orderId = order.orderId,
            clientOrderId = order.clientOrderId,
            venueOrderId = venueAssignedId,
            accepted = true,
            message = "iLink3 MSGW Acknowledged"
        )
    }

    suspend fun sendOrderCancel(orderId: String): CancelResult {
        delay(1)
        return CancelResult(orderId, true, "CME iLink3 OrderCancelAck received")
    }

    suspend fun sendOrderReplace(request: ReplaceRequest): ReplaceResult {
        delay(1)
        return ReplaceResult(
            orderId = request.orderId,
            success = true,
            message = "CME iLink3 OrderCancelReplaceAck confirmed",
            amendedQuantity = request.newQuantity,
            amendedPrice = request.newPrice
        )
    }
}

class CmeDropCopyAdapter {
    fun emitDropCopy(orderId: String, execId: String, qty: Int, px: Double): String {
        return "FIX.4.4|35=8|37=$orderId|17=$execId|32=$qty|31=$px|150=F|39=2|"
    }
}

class CmeClearingAdapter {
    fun recordClearPortTransaction(tradeId: String, notional: Double): String {
        return "CME_CLEARPORT_SETTLED_TX_$tradeId"
    }
}

class CmeRiskAdapter {
    fun checkCmeCreditLimit(accountId: String, requiredMargin: Double): Boolean {
        return true // CME Globex Credit Controls (GCC) check passed
    }
}

class CmeSimulationVenue : TradingVenue {
    override val venueId: String = "CME_GLOBEX_SIM"
    override var isConnected: Boolean = true
        private set

    val referenceData = ReferenceDataAdapter()
    val orderEntry = CmeOrderEntryAdapter()
    val dropCopy = CmeDropCopyAdapter()
    val clearing = CmeClearingAdapter()
    val risk = CmeRiskAdapter()

    override suspend fun connect() {
        delay(50)
        isConnected = true
    }

    override suspend fun disconnect() {
        isConnected = false
    }

    override suspend fun submit(order: Order): OrderAcknowledgement {
        if (!isConnected) {
            return OrderAcknowledgement(order.orderId, order.clientOrderId, "", false, "Venue disconnected")
        }
        return orderEntry.sendNewOrderSingle(order)
    }

    override suspend fun cancel(orderId: String): CancelResult {
        if (!isConnected) return CancelResult(orderId, false, "Venue disconnected")
        return orderEntry.sendOrderCancel(orderId)
    }

    override suspend fun replace(request: ReplaceRequest): ReplaceResult {
        if (!isConnected) return ReplaceResult(request.orderId, false, "Venue disconnected", 0, 0.0)
        return orderEntry.sendOrderReplace(request)
    }

    override suspend fun massCancel(request: MassCancelRequest): MassCancelResult {
        return MassCancelResult(
            cancelledCount = 0,
            orderIdsCancelled = emptyList()
        )
    }
}

class ProductionVenueAdapter(
    override val venueId: String = "CME_GLOBEX_PROD",
    private val isCertified: Boolean = false,
    private val isProductionEnabled: Boolean = false
) : TradingVenue {
    override val isConnected: Boolean = false

    override suspend fun connect() {
        if (!isCertified || !isProductionEnabled) {
            throw SecurityException("PRODUCTION ACCESS BLOCKED: Certification gate not passed or RHINOQUANT_ENV != PRODUCTION")
        }
    }

    override suspend fun disconnect() {}

    override suspend fun submit(order: Order): OrderAcknowledgement {
        throw SecurityException("PRODUCTION ACCESS GATED: Real exchange order entry requires explicit venue certification token and live credentials.")
    }

    override suspend fun cancel(orderId: String): CancelResult = CancelResult(orderId, false, "Production gated")
    override suspend fun replace(request: ReplaceRequest): ReplaceResult = ReplaceResult(request.orderId, false, "Production gated", 0, 0.0)
    override suspend fun massCancel(request: MassCancelRequest): MassCancelResult = MassCancelResult(0, emptyList())
}
