package com.example

import com.example.core.model.*
import com.example.engine.*
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test

class ExecutionEngineTest {

    @Test
    fun testOrderStateMachineTransitions() {
        var order = Order(
            orderId = "RHINO-00000001",
            clientOrderId = "CLO-100",
            instrumentId = "SR3Z26",
            side = OrderSide.BUY,
            quantity = 50,
            price = 95.125
        )
        assertEquals(OrderState.Created, order.state)

        order = order.transitionTo(OrderState.Validating)
        assertEquals(OrderState.Validating, order.state)

        order = order.transitionTo(OrderState.RiskApproved)
        assertEquals(OrderState.RiskApproved, order.state)

        order = order.transitionTo(OrderState.Routing)
        assertEquals(OrderState.Routing, order.state)

        order = order.transitionTo(OrderState.Acknowledged)
        assertEquals(OrderState.Acknowledged, order.state)

        order = order.transitionTo(OrderState.Filled)
        assertEquals(OrderState.Filled, order.state)
        assertTrue(order.isTerminal)

        // Attempting to transition from terminal FILLED to WORKING must throw IllegalOrderStateTransitionException
        try {
            order.transitionTo(OrderState.Working)
            fail("Expected IllegalOrderStateTransitionException when transitioning from Filled to Working")
        } catch (e: IllegalOrderStateTransitionException) {
            assertEquals("FILLED", e.current.name)
            assertEquals("WORKING", e.target.name)
        }
    }

    @Test
    fun testPreTradeRiskEngineFatFingerRejection() {
        val riskEngine = RiskEngine()
        val instrument = InstrumentMaster.SOFR_Z6
        val accountState = AccountMarginState()
        val quote = MarketQuote(
            instrumentId = "SR3Z26",
            symbol = "SR3 Z6",
            bidPrice = 95.120,
            askPrice = 95.130,
            bidSize = 1000,
            askSize = 1000,
            lastPrice = 95.125,
            lastSize = 10,
            volume = 100000,
            openInterest = 500000,
            settlementPrice = 95.125,
            high = 95.20,
            low = 95.00,
            open = 95.10,
            prevClose = 95.125
        )

        // Order with 10% price deviation (beyond 3.5% collar)
        val fatFingerOrder = Order(
            orderId = "RHINO-RISK-01",
            clientOrderId = "CLO-FAT",
            instrumentId = "SR3Z26",
            side = OrderSide.BUY,
            quantity = 10,
            price = 105.00, // Mid is ~95.125
            orderType = OrderType.LIMIT
        )

        val decision = riskEngine.evaluate(
            order = fatFingerOrder,
            instrument = instrument,
            accountState = accountState,
            currentPosition = null,
            allPositions = emptyList(),
            quote = quote,
            openOrdersCount = 0,
            killSwitchState = KillSwitchState.TRADING
        )

        assertFalse(decision.isApproved)
        assertEquals(RiskReasonCode.PRICE_COLLAR_VIOLATION, decision.reasonCode)
    }

    @Test
    fun testMatchingEnginePriceTimePriority() {
        val matchingEngine = MatchingEngine()
        val quote = MarketQuote(
            instrumentId = "SR3Z26",
            symbol = "SR3 Z6",
            bidPrice = 95.120,
            askPrice = 95.125,
            bidSize = 100,
            askSize = 100,
            lastPrice = 95.125,
            lastSize = 10,
            volume = 100000,
            openInterest = 500000,
            settlementPrice = 95.125,
            high = 95.20,
            low = 95.00,
            open = 95.10,
            prevClose = 95.125
        )

        // Resting Ask: Sell 50 @ 95.125
        val restingSell = Order(
            orderId = "MAKER-01",
            clientOrderId = "MAKER-CLO",
            instrumentId = "SR3Z26",
            side = OrderSide.SELL,
            quantity = 50,
            price = 95.125,
            orderType = OrderType.LIMIT
        )
        val restResult = matchingEngine.match(restingSell, quote)
        assertEquals(OrderState.Working, restResult.updatedOrder.state)

        // Incoming Taker Buy: Buy 50 @ 95.125
        val takerBuy = Order(
            orderId = "TAKER-01",
            clientOrderId = "TAKER-CLO",
            instrumentId = "SR3Z26",
            side = OrderSide.BUY,
            quantity = 50,
            price = 95.125,
            orderType = OrderType.LIMIT
        )
        val takerResult = matchingEngine.match(takerBuy, quote)

        assertEquals(OrderState.Filled, takerResult.updatedOrder.state)
        assertEquals(50, takerResult.updatedOrder.filledQuantity)
        assertEquals(95.125, takerResult.updatedOrder.averageFillPrice, 0.0001)
        assertEquals(1, takerResult.fills.size)
        assertEquals(50, takerResult.fills[0].fillQuantity)
    }

    @Test
    fun testSpanMarginSpreadDiscount() {
        val marginEngine = MarginEngine()
        val sofrZ6 = InstrumentMaster.SOFR_Z6
        val sofrH7 = InstrumentMaster.SOFR_H7

        val posZ6 = Position(
            instrumentId = sofrZ6.instrumentId,
            symbol = sofrZ6.symbol,
            quantity = 100, // Long 100 Z6
            averageEntryPrice = 95.125,
            currentMarketPrice = 95.125,
            initialMargin = 100 * sofrZ6.initialMarginPerContract,
            maintenanceMargin = 100 * sofrZ6.maintenanceMarginPerContract
        )

        val posH7 = Position(
            instrumentId = sofrH7.instrumentId,
            symbol = sofrH7.symbol,
            quantity = -100, // Short 100 H7
            averageEntryPrice = 95.245,
            currentMarketPrice = 95.245,
            initialMargin = 100 * sofrH7.initialMarginPerContract,
            maintenanceMargin = 100 * sofrH7.maintenanceMarginPerContract
        )

        val account = AccountMarginState(totalEquity = 1_000_000.0)
        val result = marginEngine.calculateMarginRequirements(listOf(posZ6, posH7), account)

        // Total raw initial margin = 100 * 1150 + 100 * 1150 = $230,000
        // Spread offset discount = 80% of $230,000 = $184,000
        // Net initial margin = $46,000
        assertEquals(184_000.0, result.portfolioSpanDiscount, 0.01)
        assertEquals(46_000.0, result.initialMarginRequired, 0.01)
    }

    @Test
    fun testDropCopy4WayReconciliation() {
        val reconEngine = DropCopyReconciliationEngine()
        val fill = ExecutionFill(
            executionId = "RHINO-SIM-000001",
            orderId = "RHINO-1001",
            clientOrderId = "CLO-1001",
            instrumentId = "SR3Z26",
            side = OrderSide.BUY,
            fillQuantity = 50,
            fillPrice = 95.125
        )
        val order = Order(
            orderId = "RHINO-1001",
            clientOrderId = "CLO-1001",
            instrumentId = "SR3Z26",
            side = OrderSide.BUY,
            quantity = 50,
            price = 95.125,
            state = OrderState.Filled,
            filledQuantity = 50
        )

        val item = reconEngine.onExecutionOccurred(fill, order)
        assertEquals(ReconStatus.MATCHED, item.status)
        assertEquals(0, item.discrepancies.size)
        assertEquals(50, item.internalFillQuantity)
        assertEquals(50, item.dropCopyQuantity)
        assertEquals(50, item.clearingQuantity)
    }
}
