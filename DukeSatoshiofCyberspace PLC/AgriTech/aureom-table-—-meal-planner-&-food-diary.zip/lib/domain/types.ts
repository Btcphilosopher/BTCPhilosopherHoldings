export type CurrencyCode = 'GBP';

export type MealSlot = 'breakfast' | 'lunch' | 'dinner' | 'snack';

export type PlannedMealKind =
  | 'recipe'
  | 'simple'
  | 'eating_out'
  | 'takeaway'
  | 'leftover';

export type PlannedMealStatus = 'planned' | 'cooked' | 'skipped';

export type StorageLocation = 'fridge' | 'freezer' | 'cupboard';

export type DateMarkingType = 'use_by' | 'best_before' | 'user_estimate';

export type MerchantCategory =
  | 'supermarket'
  | 'greengrocer'
  | 'butcher'
  | 'bakery'
  | 'specialist'
  | 'prepared';

export type FulfilmentModel = 'separate' | 'consolidated';

export type BasketStrategy =
  | 'baseline'
  | 'lowest_cost'
  | 'fewest_merchants'
  | 'preferred_merchants'
  | 'earliest_delivery'
  | 'least_surplus';

export type SubstitutionPreference =
  | 'allow_equivalent'
  | 'require_approval'
  | 'refund_if_missing';

export type DiaryVisibility = 'private' | 'household';

export type DiaryEntrySource =
  | 'planned_meal'
  | 'recipe'
  | 'manual'
  | 'product'
  | 'photo';

export interface Household {
  id: string;
  name: string;
  address_line1: string;
  city: string;
  postcode: string;
  currency: CurrencyCode;
  weekly_budget_minor: number;
  preferred_merchant_ids: string[];
  default_fulfilment_model: FulfilmentModel;
  share_delivery_details_with_merchants: boolean;
  track_calories_in_diary: boolean;
  notification_prefs: {
    expiry_reminders: boolean;
    delivery_updates: boolean;
    substitution_alerts: boolean;
  };
  created_at: string;
}

export interface HouseholdMember {
  id: string;
  household_id: string;
  name: string;
  role: 'admin' | 'adult' | 'child';
  dietary_preferences: string[];
  dislikes: string[];
  excluded_ingredients: string[];
  allergens: string[];
  portion_multiplier: number;
  created_at: string;
}

export interface IngredientIdentity {
  id: string;
  canonical_name: string;
  form_variety: string;
  default_unit: string;
  is_pantry_staple: boolean;
  documented_conversion?: {
    from_unit: string;
    to_unit: string;
    factor: number;
    source: string;
  };
}

export interface RecipeIngredient {
  id: string;
  ingredient_id: string;
  display_name: string;
  form_variety: string;
  quantity: number;
  unit: string;
  is_optional: boolean;
  is_garnish: boolean;
  is_pantry_staple: boolean;
  documented_conversion?: {
    from_unit: string;
    to_unit: string;
    factor: number;
    source: string;
  };
}

export interface RecipeNutrition {
  kcal: number;
  protein_g: number;
  carbs_g: number;
  fat_g: number;
  source: string;
  is_verified: boolean;
}

export interface Recipe {
  id: string;
  title: string;
  description: string;
  image_url: string;
  image_source: string;
  servings: number;
  prep_minutes: number;
  cook_minutes: number;
  instructions: string[];
  dietary_tags: string[];
  allergens: string[];
  allergen_provenance: string;
  nutrition_per_serving?: RecipeNutrition;
  storage_notes?: string;
  leftover_notes?: string;
  ingredients: RecipeIngredient[];
}

export interface MealPlanWeek {
  id: string;
  household_id: string;
  week_start_date: string;
  title: string;
  weekly_budget_minor: number;
  is_template: boolean;
  shared_with_household: boolean;
  created_at: string;
}

export interface PlannedMeal {
  id: string;
  week_id: string;
  household_id: string;
  date: string;
  slot: MealSlot;
  kind: PlannedMealKind;
  recipe_id?: string | null;
  title: string;
  servings: number;
  assigned_member_ids: string[];
  leftover_source_meal_id?: string | null;
  leftover_portions_yielded: number;
  status: PlannedMealStatus;
  notes?: string;
  prep_minutes: number;
  cook_minutes: number;
  linked_order_ids: string[];
}

export interface PantryItem {
  id: string;
  household_id: string;
  ingredient_id: string;
  product_name: string;
  barcode?: string | null;
  quantity: number;
  unit: string;
  storage_location: StorageLocation;
  purchase_or_opened_date: string;
  recorded_expiry_date?: string | null;
  date_marking_type: DateMarkingType;
  reserved_quantity: number;
  updated_at: string;
}

export interface PantryTransaction {
  id: string;
  household_id: string;
  pantry_item_id: string;
  action:
    | 'manual_add'
    | 'barcode_lookup'
    | 'delivery_confirmed'
    | 'meal_cooked'
    | 'consumed'
    | 'discarded'
    | 'corrected'
    | 'replenished'
    | 'reserved'
    | 'released';
  quantity_delta: number;
  unit: string;
  note: string;
  created_at: string;
}

export interface DeliverySlot {
  id: string;
  label: string;
  window_start: string;
  window_end: string;
  is_available: boolean;
  earliest_rank: number;
}

export interface Merchant {
  id: string;
  name: string;
  category: MerchantCategory;
  description: string;
  delivery_areas: string[];
  min_order_minor: number;
  delivery_fee_minor: number;
  participates_in_consolidated_hub: boolean;
  consolidated_partner_name?: string | null;
  consolidated_fee_minor?: number | null;
  slots: DeliverySlot[];
}

export interface MerchantProduct {
  id: string;
  merchant_id: string;
  ingredient_id: string;
  sku: string;
  title: string;
  brand: string;
  pack_quantity: number;
  pack_unit: string;
  price_minor: number;
  currency: CurrencyCode;
  availability: 'in_stock' | 'low_stock' | 'unavailable';
  source_name: string;
  price_updated_at: string;
  allergens: string[];
  allergen_metadata_complete: boolean;
  nutrition_verified: boolean;
  nutrition_summary?: {
    kcal_per_100g?: number;
    protein_g?: number;
    source: string;
  };
  proposed_substitute_product_id?: string | null;
}

export interface ContributingMealRef {
  meal_id: string;
  meal_title: string;
  date: string;
  slot: MealSlot;
  required_qty: number;
  unit: string;
}

export interface AggregatedRequirement {
  key: string;
  ingredient_id: string;
  display_name: string;
  form_variety: string;
  unit: string;
  total_required: number;
  pantry_available: number;
  pantry_reserved_here: number;
  remaining_to_buy: number;
  is_optional: boolean;
  is_garnish: boolean;
  is_pantry_staple: boolean;
  conversion_note?: string;
  contributing_meals: ContributingMealRef[];
}

export interface BasketLine {
  requirement_key: string;
  ingredient_id: string;
  display_name: string;
  unit: string;
  remaining_needed: number;
  product_id: string;
  product_title: string;
  merchant_id: string;
  merchant_name: string;
  packs_to_buy: number;
  pack_quantity: number;
  pack_unit: string;
  total_purchased_qty: number;
  expected_surplus_qty: number;
  unit_price_minor: number;
  line_total_minor: number;
  availability: 'in_stock' | 'low_stock' | 'unavailable';
  locked: boolean;
  allergen_metadata_complete: boolean;
  proposed_substitute?: {
    product_id: string;
    title: string;
    price_minor: number;
    allergens: string[];
    allergen_metadata_complete: boolean;
    changes_allergen_info: boolean;
    violates_household_restriction: boolean;
    requires_explicit_approval: boolean;
    safety_note: string;
  };
}

export interface MerchantOrderPreview {
  merchant_id: string;
  merchant_name: string;
  category: MerchantCategory;
  fulfilment_model: FulfilmentModel;
  fulfilment_group_label: string;
  subtotal_minor: number;
  min_order_minor: number;
  meets_minimum: boolean;
  shortfall_minor: number;
  delivery_fee_minor: number;
  selected_slot_id: string;
  lines: BasketLine[];
}

export interface BasketAllocationResult {
  strategy: BasketStrategy;
  fulfilment_model: FulfilmentModel;
  merchants_count: number;
  items_subtotal_minor: number;
  delivery_fees_minor: number;
  total_cost_minor: number;
  total_surplus_items: number;
  estimated_earliest_rank: number;
  trade_off_summary: string;
  baseline_delta_minor: number;
  merchant_groups: MerchantOrderPreview[];
  unfulfilled_requirements: AggregatedRequirement[];
}

export type MerchantOrderStatus =
  | 'pending_authorisation'
  | 'confirmed'
  | 'failed'
  | 'partially_fulfilled'
  | 'out_for_delivery'
  | 'delivered'
  | 'cancelled';

export interface OrderLineItem {
  id: string;
  order_id: string;
  ingredient_id: string;
  product_id: string;
  product_title: string;
  pack_quantity: number;
  pack_unit: string;
  ordered_packs: number;
  delivered_packs?: number | null;
  unit_price_minor: number;
  line_total_minor: number;
  substitution_preference: SubstitutionPreference;
  substitution_status:
    | 'none'
    | 'proposed'
    | 'approved'
    | 'rejected';
  proposed_substitute_product_id?: string | null;
  proposed_substitute_title?: string | null;
  proposed_substitute_price_minor?: number | null;
  proposed_substitute_allergens?: string[];
  proposed_substitute_metadata_complete?: boolean;
  requires_explicit_approval: boolean;
  substitution_warning?: string | null;
  linked_meal_ids: string[];
}

export interface PaymentLedgerEntry {
  id: string;
  parent_checkout_id: string;
  merchant_order_id?: string | null;
  entry_type: 'authorisation' | 'capture' | 'refund' | 'merchant_settlement';
  amount_minor: number;
  currency: CurrencyCode;
  status: 'recorded' | 'pending' | 'reversed';
  note: string;
  created_at: string;
}

export interface MerchantOrder {
  id: string;
  parent_checkout_id: string;
  merchant_id: string;
  merchant_name: string;
  fulfilment_model: FulfilmentModel;
  fulfilment_partner_name?: string | null;
  slot_label: string;
  status: MerchantOrderStatus;
  failure_reason?: string | null;
  subtotal_minor: number;
  delivery_fee_minor: number;
  total_minor: number;
  refunded_minor: number;
  delivery_confirmed_into_pantry: boolean;
  created_at: string;
  lines: OrderLineItem[];
}

export interface ParentCheckout {
  id: string;
  household_id: string;
  idempotency_key: string;
  delivery_address: string;
  delivery_postcode: string;
  currency: CurrencyCode;
  total_authorised_minor: number;
  total_captured_minor: number;
  total_refunded_minor: number;
  status: 'completed' | 'partial_failure' | 'cancelled';
  created_at: string;
  merchant_orders: MerchantOrder[];
  ledger: PaymentLedgerEntry[];
}

export interface FoodDiaryEntry {
  id: string;
  household_id: string;
  member_id: string;
  member_name: string;
  visibility: DiaryVisibility;
  source: DiaryEntrySource;
  planned_meal_id?: string | null;
  recipe_id?: string | null;
  product_id?: string | null;
  title: string;
  date: string;
  time: string;
  portion_label: string;
  differed_from_plan: boolean;
  difference_reason?: string | null;
  satisfaction?: number | null;
  hunger_note?: string | null;
  practical_notes?: string | null;
  photo_url?: string | null;
  nutrition_summary?: {
    kcal: number;
    protein_g?: number;
    source: string;
    is_verified: boolean;
  } | null;
  created_at: string;
}

export interface AiSuggestedMeal {
  date: string;
  slot: MealSlot;
  recipe_id: string;
  title: string;
  servings: number;
  prep_minutes: number;
  cook_minutes: number;
  reason: string;
  pantry_matches: string[];
  validation_passed: boolean;
  validation_warnings: string[];
}
