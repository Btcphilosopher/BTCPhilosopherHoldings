import {DatabaseSync} from 'node:sqlite';
import {
  AggregatedRequirement,
  BasketAllocationResult,
  BasketLine,
  BasketStrategy,
  FulfilmentModel,
  IngredientIdentity,
  Merchant,
  MerchantOrderPreview,
  MerchantProduct,
  PantryItem,
  PlannedMeal,
  Recipe,
} from '@/lib/domain/types';
import {ensureSeeded, HOUSEHOLD_ID} from '../seed';
import {withTransaction} from '../db';
import {getHouseholdContext} from './identity';
import {listIngredientIdentities, listRecipes, scaleRecipeIngredients} from './recipes';
import {getPlanningState} from './planning';
import {listPantryItems} from './pantry';
import {listMerchantProducts, listMerchants} from './catalogue';

export interface ShoppingConfigState {
  include_optional: boolean;
  include_garnish: boolean;
  include_pantry_staples: boolean;
  locked_assignments: Record<string, string>; // requirement_key -> product_id
}

export function getShoppingConfig(db: DatabaseSync): ShoppingConfigState {
  ensureSeeded(db);
  const row = db
    .prepare('SELECT * FROM shopping_config WHERE household_id = ?')
    .get(HOUSEHOLD_ID) as Record<string, unknown> | undefined;
  if (!row) {
    return {
      include_optional: false,
      include_garnish: true,
      include_pantry_staples: false,
      locked_assignments: {},
    };
  }
  return {
    include_optional: Boolean(row.include_optional),
    include_garnish: Boolean(row.include_garnish),
    include_pantry_staples: Boolean(row.include_pantry_staples),
    locked_assignments: JSON.parse(String(row.locked_assignments_json)),
  };
}

export function updateShoppingConfig(
  db: DatabaseSync,
  updates: Partial<ShoppingConfigState>
): ShoppingConfigState {
  const current = getShoppingConfig(db);
  const next: ShoppingConfigState = {
    include_optional: updates.include_optional ?? current.include_optional,
    include_garnish: updates.include_garnish ?? current.include_garnish,
    include_pantry_staples:
      updates.include_pantry_staples ?? current.include_pantry_staples,
    locked_assignments: updates.locked_assignments ?? current.locked_assignments,
  };
  db.prepare(
    `UPDATE shopping_config SET
      include_optional = ?, include_garnish = ?, include_pantry_staples = ?, locked_assignments_json = ?
     WHERE household_id = ?`
  ).run(
    next.include_optional ? 1 : 0,
    next.include_garnish ? 1 : 0,
    next.include_pantry_staples ? 1 : 0,
    JSON.stringify(next.locked_assignments),
    HOUSEHOLD_ID
  );
  return next;
}

/**
 * Pure unit compatibility helper.
 * Compatible mass units: g <-> kg
 * Compatible volume units: ml <-> l
 * Never converts volume <-> mass without an explicit documented_conversion!
 */
export function convertToCanonicalUnit(
  qty: number,
  unit: string,
  identity?: IngredientIdentity
): {quantity: number; unit: string; conversion_note?: string} {
  const u = unit.toLowerCase().trim();
  if (u === 'kg') {
    return {quantity: qty * 1000, unit: 'g', conversion_note: 'Converted kg to g (1 kg = 1000 g)'};
  }
  if (u === 'l') {
    return {quantity: qty * 1000, unit: 'ml', conversion_note: 'Converted l to ml (1 l = 1000 ml)'};
  }
  if (
    identity?.documented_conversion &&
    identity.documented_conversion.from_unit.toLowerCase() === u
  ) {
    return {
      quantity: qty * identity.documented_conversion.factor,
      unit: identity.documented_conversion.to_unit,
      conversion_note: identity.documented_conversion.source,
    };
  }
  return {quantity: qty, unit: u};
}

/**
 * Pure Aggregation Engine (also used directly in unit tests).
 * - Excludes eating_out, takeaway, skipped, and leftover meals (accounting for leftover portions yielded).
 * - Preserves distinctions between forms/varieties and incompatible units.
 * - Subtracts available pantry quantities without double-allocating the same stock!
 */
export function aggregateIngredientsPure(params: {
  meals: PlannedMeal[];
  recipes: Recipe[];
  identities: IngredientIdentity[];
  pantryItems: PantryItem[];
  config: Pick<
    ShoppingConfigState,
    'include_optional' | 'include_garnish' | 'include_pantry_staples'
  >;
}): AggregatedRequirement[] {
  const recipeMap = new Map(params.recipes.map((r) => [r.id, r]));
  const identityMap = new Map(params.identities.map((i) => [i.id, i]));

  // Track leftover portions yielded vs consumed so we can warn if leftovers exceed yield,
  // and ensure leftover meals do not double-count ingredients.
  const yieldedBySource = new Map<string, number>();
  for (const m of params.meals) {
    if (m.leftover_portions_yielded > 0) {
      yieldedBySource.set(m.id, m.leftover_portions_yielded);
    }
  }

  const aggMap = new Map<string, AggregatedRequirement>();

  for (const meal of params.meals) {
    if (
      meal.status === 'skipped' ||
      meal.status === 'cooked' ||
      meal.kind === 'eating_out' ||
      meal.kind === 'takeaway' ||
      meal.kind === 'leftover' ||
      meal.kind === 'simple' ||
      !meal.recipe_id
    ) {
      continue;
    }

    const recipe = recipeMap.get(meal.recipe_id);
    if (!recipe) continue;

    const scaled = scaleRecipeIngredients(recipe, meal.servings);
    for (const ing of scaled) {
      if (ing.is_optional && !params.config.include_optional) continue;
      if (ing.is_garnish && !params.config.include_garnish) continue;
      if (ing.is_pantry_staple && !params.config.include_pantry_staples) continue;

      const identity = identityMap.get(ing.ingredient_id);
      const norm = convertToCanonicalUnit(ing.quantity, ing.unit, identity);

      // Key preserves ingredient_id + form_variety + normalized unit
      // so different forms or unconvertible units never silently merge!
      const key = `${ing.ingredient_id}::${ing.form_variety.toLowerCase()}::${norm.unit}`;
      const existing = aggMap.get(key);
      const contrib = {
        meal_id: meal.id,
        meal_title: meal.title,
        date: meal.date,
        slot: meal.slot,
        required_qty: Math.round(norm.quantity * 100) / 100,
        unit: norm.unit,
      };

      if (existing) {
        existing.total_required =
          Math.round((existing.total_required + norm.quantity) * 100) / 100;
        existing.contributing_meals.push(contrib);
      } else {
        aggMap.set(key, {
          key,
          ingredient_id: ing.ingredient_id,
          display_name: ing.display_name,
          form_variety: ing.form_variety,
          unit: norm.unit,
          total_required: Math.round(norm.quantity * 100) / 100,
          pantry_available: 0,
          pantry_reserved_here: 0,
          remaining_to_buy: Math.round(norm.quantity * 100) / 100,
          is_optional: ing.is_optional,
          is_garnish: ing.is_garnish,
          is_pantry_staple: ing.is_pantry_staple,
          conversion_note: norm.conversion_note,
          contributing_meals: [contrib],
        });
      }
    }
  }

  // Non-double-allocation pantry pool: track remaining unallocated quantity per pantry item id
  const availablePool = new Map<string, number>();
  for (const p of params.pantryItems) {
    const normP = convertToCanonicalUnit(
      Math.max(0, p.quantity - p.reserved_quantity),
      p.unit,
      identityMap.get(p.ingredient_id)
    );
    availablePool.set(p.id, normP.quantity);
  }

  const results = Array.from(aggMap.values());
  for (const req of results) {
    let totalAvailForIngredient = 0;
    let allocated = 0;
    for (const p of params.pantryItems) {
      if (p.ingredient_id !== req.ingredient_id) continue;
      const normP = convertToCanonicalUnit(
        p.quantity,
        p.unit,
        identityMap.get(p.ingredient_id)
      );
      if (normP.unit !== req.unit) continue; // Never mix incompatible units!

      const poolLeft = availablePool.get(p.id) ?? 0;
      totalAvailForIngredient += poolLeft;
      const stillNeeded = Math.max(0, req.total_required - allocated);
      const take = Math.min(poolLeft, stillNeeded);
      if (take > 0) {
        allocated += take;
        availablePool.set(p.id, Math.round((poolLeft - take) * 100) / 100);
      }
    }

    req.pantry_available = Math.round(totalAvailForIngredient * 100) / 100;
    req.pantry_reserved_here = Math.round(allocated * 100) / 100;
    req.remaining_to_buy = Math.max(
      0,
      Math.round((req.total_required - allocated) * 100) / 100
    );
  }

  return results.sort((a, b) => a.display_name.localeCompare(b.display_name));
}

export function getAggregatedRequirements(db: DatabaseSync): AggregatedRequirement[] {
  const {meals} = getPlanningState(db);
  const recipes = listRecipes(db);
  const identities = listIngredientIdentities(db);
  const pantryItems = listPantryItems(db);
  const config = getShoppingConfig(db);

  return aggregateIngredientsPure({
    meals,
    recipes,
    identities,
    pantryItems,
    config,
  });
}

/**
 * Transactionally reserves available pantry quantities for the current week
 * so the same pantry stock cannot be allocated twice.
 */
export function reservePantryForWeek(db: DatabaseSync): {
  reserved_lines: number;
  total_units_reserved: number;
} {
  ensureSeeded(db);
  const {current_week, meals} = getPlanningState(db);
  const recipes = listRecipes(db);
  const identities = listIngredientIdentities(db);
  const config = getShoppingConfig(db);

  return withTransaction(db, () => {
    // Release prior reservations for this week before recomputing cleanly
    const prior = db
      .prepare('SELECT pantry_item_id, reserved_qty FROM pantry_reservations WHERE week_id = ?')
      .all(current_week.id) as Array<Record<string, unknown>>;
    for (const row of prior) {
      db.prepare(
        'UPDATE pantry_items SET reserved_quantity = MAX(0, reserved_quantity - ?) WHERE id = ?'
      ).run(Number(row.reserved_qty), String(row.pantry_item_id));
    }
    db.prepare('DELETE FROM pantry_reservations WHERE week_id = ?').run(current_week.id);

    const pantryItems = listPantryItems(db);
    const reqs = aggregateIngredientsPure({
      meals,
      recipes,
      identities,
      pantryItems,
      config,
    });

    let reservedLines = 0;
    let totalUnits = 0;
    const now = new Date().toISOString();

    for (const req of reqs) {
      if (req.pantry_reserved_here <= 0) continue;
      let leftToReserve = req.pantry_reserved_here;
      for (const p of pantryItems) {
        if (p.ingredient_id !== req.ingredient_id || p.unit !== req.unit) continue;
        const free = Math.max(0, p.quantity - p.reserved_quantity);
        const take = Math.min(free, leftToReserve);
        if (take > 0) {
          db.prepare(
            'UPDATE pantry_items SET reserved_quantity = reserved_quantity + ?, updated_at = ? WHERE id = ?'
          ).run(take, now, p.id);
          db.prepare(
            `INSERT INTO pantry_reservations (
              id, household_id, pantry_item_id, week_id, ingredient_id, reserved_qty, unit, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
          ).run(
            `pres_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
            HOUSEHOLD_ID,
            p.id,
            current_week.id,
            req.ingredient_id,
            take,
            req.unit,
            now
          );
          leftToReserve -= take;
          reservedLines += 1;
          totalUnits += take;
        }
      }
    }

    return {
      reserved_lines: reservedLines,
      total_units_reserved: Math.round(totalUnits * 100) / 100,
    };
  });
}

/**
 * Pure Basket Allocation & Multi-Merchant Optimisation Engine.
 * Compares 5 strategies against a transparent Baseline Greedy Allocation.
 */
export function allocateBasketPure(params: {
  requirements: AggregatedRequirement[];
  merchants: Merchant[];
  products: MerchantProduct[];
  preferredMerchantIds: string[];
  householdExcludedAllergens: string[];
  strategy: BasketStrategy;
  fulfilmentModel: FulfilmentModel;
  lockedAssignments: Record<string, string>;
}): BasketAllocationResult {
  const merchantMap = new Map(params.merchants.map((m) => [m.id, m]));
  const productMap = new Map(params.products.map((p) => [p.id, p]));
  const toBuy = params.requirements.filter((r) => r.remaining_to_buy > 0);

  const buildCandidateLine = (
    req: AggregatedRequirement,
    product: MerchantProduct,
    locked: boolean
  ): BasketLine => {
    const merchant = merchantMap.get(product.merchant_id)!;
    const packs = Math.max(1, Math.ceil(req.remaining_to_buy / product.pack_quantity));
    const purchasedQty = Math.round(packs * product.pack_quantity * 100) / 100;
    const surplus = Math.max(
      0,
      Math.round((purchasedQty - req.remaining_to_buy) * 100) / 100
    );

    let proposedSub: BasketLine['proposed_substitute'] = undefined;
    if (product.proposed_substitute_product_id) {
      const subProd = productMap.get(product.proposed_substitute_product_id);
      if (subProd) {
        const changesAllergens =
          JSON.stringify([...subProd.allergens].sort()) !==
          JSON.stringify([...product.allergens].sort());
        const violatesHousehold = subProd.allergens.some((a) =>
          params.householdExcludedAllergens.includes(a.toLowerCase())
        );
        const incompleteMeta = !subProd.allergen_metadata_complete;
        const requiresApproval =
          changesAllergens || violatesHousehold || incompleteMeta;

        proposedSub = {
          product_id: subProd.id,
          title: subProd.title,
          price_minor: subProd.price_minor,
          allergens: subProd.allergens,
          allergen_metadata_complete: subProd.allergen_metadata_complete,
          changes_allergen_info: changesAllergens,
          violates_household_restriction: violatesHousehold,
          requires_explicit_approval: requiresApproval,
          safety_note: violatesHousehold
            ? `Contains excluded allergen(s): ${subProd.allergens.join(', ')}. Explicit approval required.`
            : incompleteMeta
            ? 'Allergen metadata incomplete — cannot be assumed allergy-safe without explicit review.'
            : changesAllergens
            ? 'Substitute changes allergen profile — explicit approval required.'
            : 'Equivalent substitute available.',
        };
      }
    }

    return {
      requirement_key: req.key,
      ingredient_id: req.ingredient_id,
      display_name: req.display_name,
      unit: req.unit,
      remaining_needed: req.remaining_to_buy,
      product_id: product.id,
      product_title: product.title,
      merchant_id: product.merchant_id,
      merchant_name: merchant.name,
      packs_to_buy: packs,
      pack_quantity: product.pack_quantity,
      pack_unit: product.pack_unit,
      total_purchased_qty: purchasedQty,
      expected_surplus_qty: surplus,
      unit_price_minor: product.price_minor,
      line_total_minor: packs * product.price_minor,
      availability: product.availability,
      locked,
      allergen_metadata_complete: product.allergen_metadata_complete,
      proposed_substitute: proposedSub,
    };
  };

  const pickProductForStrategy = (
    req: AggregatedRequirement,
    strategy: BasketStrategy,
    activeMerchantIds: Set<string>
  ): BasketLine | null => {
    const lockedId = params.lockedAssignments[req.key];
    if (lockedId && productMap.has(lockedId)) {
      return buildCandidateLine(req, productMap.get(lockedId)!, true);
    }

    const candidates = params.products.filter(
      (p) =>
        p.ingredient_id === req.ingredient_id &&
        p.pack_unit === req.unit &&
        p.availability !== 'unavailable'
    );
    if (candidates.length === 0) {
      return null;
    }

    const scored = candidates.map((p) => {
      const line = buildCandidateLine(req, p, false);
      const merchant = merchantMap.get(p.merchant_id)!;
      const earliestSlotRank = Math.min(
        ...merchant.slots.filter((s) => s.is_available).map((s) => s.earliest_rank)
      );
      const alreadyActive = activeMerchantIds.has(p.merchant_id);
      const isPreferred = params.preferredMerchantIds.includes(p.merchant_id);

      let score = line.line_total_minor;
      if (strategy === 'baseline') {
        // Transparent greedy baseline: pick cheapest item price regardless of fees/merchants
        score = line.line_total_minor;
      } else if (strategy === 'lowest_cost') {
        // Account for merchant delivery fee if merchant is not yet in basket
        const feePenalty = alreadyActive ? 0 : merchant.delivery_fee_minor;
        score = line.line_total_minor + feePenalty;
      } else if (strategy === 'fewest_merchants') {
        // Heavy bonus to consolidate into already-active or broad-catalogue merchant (Cotswold)
        const activeBonus = alreadyActive ? -50000 : 0;
        const superBonus = merchant.category === 'supermarket' ? -10000 : 0;
        score = activeBonus + superBonus + line.line_total_minor;
      } else if (strategy === 'preferred_merchants') {
        const prefBonus = isPreferred ? -40000 : 0;
        const activeBonus = alreadyActive ? -5000 : 0;
        score = prefBonus + activeBonus + line.line_total_minor;
      } else if (strategy === 'earliest_delivery') {
        score = earliestSlotRank * 10000 + line.line_total_minor;
      } else if (strategy === 'least_surplus') {
        score = line.expected_surplus_qty * 1000 + line.line_total_minor * 0.01;
      }
      return {line, score};
    });

    scored.sort((a, b) => a.score - b.score);
    return scored[0].line;
  };

  const runAllocation = (strategy: BasketStrategy): BasketAllocationResult => {
    const lines: BasketLine[] = [];
    const unfulfilled: AggregatedRequirement[] = [];
    const activeMerchantIds = new Set<string>();

    // First register locked merchants so optimiser respects them
    for (const req of toBuy) {
      const lockedId = params.lockedAssignments[req.key];
      if (lockedId && productMap.has(lockedId)) {
        activeMerchantIds.add(productMap.get(lockedId)!.merchant_id);
      }
    }

    // Order requirements so merchants with wide overlap get picked early in fewest_merchants
    for (const req of toBuy) {
      const chosen = pickProductForStrategy(req, strategy, activeMerchantIds);
      if (!chosen) {
        unfulfilled.push(req);
      } else {
        activeMerchantIds.add(chosen.merchant_id);
        lines.push(chosen);
      }
    }

    // Group by merchant
    const groupMap = new Map<string, BasketLine[]>();
    for (const line of lines) {
      const arr = groupMap.get(line.merchant_id) ?? [];
      arr.push(line);
      groupMap.set(line.merchant_id, arr);
    }

    let consolidatedFeeCharged = false;
    const merchantGroups: MerchantOrderPreview[] = [];

    for (const [merchantId, mLines] of groupMap.entries()) {
      const merchant = merchantMap.get(merchantId)!;
      const subtotal = mLines.reduce((acc, l) => acc + l.line_total_minor, 0);
      const meetsMinimum = subtotal >= merchant.min_order_minor;
      const shortfall = Math.max(0, merchant.min_order_minor - subtotal);

      const useHub =
        params.fulfilmentModel === 'consolidated' &&
        merchant.participates_in_consolidated_hub;

      let fee = merchant.delivery_fee_minor;
      let groupLabel = `Separate delivery from ${merchant.name}`;
      if (useHub) {
        groupLabel = `Consolidated via ${merchant.consolidated_partner_name}`;
        if (!consolidatedFeeCharged) {
          fee = merchant.consolidated_fee_minor ?? 550;
          consolidatedFeeCharged = true;
        } else {
          fee = 0; // Single shared consolidated hub fee across participating merchants
        }
      }

      const earliestSlot = [...merchant.slots].sort(
        (a, b) => a.earliest_rank - b.earliest_rank
      )[0];

      merchantGroups.push({
        merchant_id: merchant.id,
        merchant_name: merchant.name,
        category: merchant.category,
        fulfilment_model: useHub ? 'consolidated' : 'separate',
        fulfilment_group_label: groupLabel,
        subtotal_minor: subtotal,
        min_order_minor: merchant.min_order_minor,
        meets_minimum: meetsMinimum,
        shortfall_minor: shortfall,
        delivery_fee_minor: fee,
        selected_slot_id: earliestSlot?.id ?? '',
        lines: mLines,
      });
    }

    const itemsSubtotal = merchantGroups.reduce(
      (sum, g) => sum + g.subtotal_minor,
      0
    );
    const deliveryFees = merchantGroups.reduce(
      (sum, g) => sum + g.delivery_fee_minor,
      0
    );
    const totalCost = itemsSubtotal + deliveryFees;
    const totalSurplus = lines.filter((l) => l.expected_surplus_qty > 0).length;
    const earliestRank = merchantGroups.reduce((maxRank, g) => {
      const m = merchantMap.get(g.merchant_id)!;
      const r = Math.min(...m.slots.map((s) => s.earliest_rank));
      return Math.max(maxRank, r);
    }, 1);

    return {
      strategy,
      fulfilment_model: params.fulfilmentModel,
      merchants_count: merchantGroups.length,
      items_subtotal_minor: itemsSubtotal,
      delivery_fees_minor: deliveryFees,
      total_cost_minor: totalCost,
      total_surplus_items: totalSurplus,
      estimated_earliest_rank: earliestRank,
      trade_off_summary: '',
      baseline_delta_minor: 0,
      merchant_groups: merchantGroups,
      unfulfilled_requirements: unfulfilled,
    };
  };

  const baseline = runAllocation('baseline');
  const target =
    params.strategy === 'baseline' ? baseline : runAllocation(params.strategy);

  const delta = target.total_cost_minor - baseline.total_cost_minor;
  target.baseline_delta_minor = delta;

  const deltaStr =
    delta === 0
      ? 'matches baseline total'
      : delta < 0
      ? `saves £${(Math.abs(delta) / 100).toFixed(2)} vs. greedy baseline`
      : `adds £${(delta / 100).toFixed(2)} vs. greedy baseline`;

  if (params.strategy === 'baseline') {
    target.trade_off_summary = `Greedy baseline picks the cheapest per-pack price across ${target.merchants_count} merchants, incurring £${(target.delivery_fees_minor / 100).toFixed(2)} in delivery fees.`;
  } else if (params.strategy === 'lowest_cost') {
    target.trade_off_summary = `Balances pack price against merchant delivery fees across ${target.merchants_count} merchant(s) (${deltaStr}).`;
  } else if (params.strategy === 'fewest_merchants') {
    target.trade_off_summary = `Consolidates basket into ${target.merchants_count} merchant(s) to cut multiple delivery fees (${deltaStr}).`;
  } else if (params.strategy === 'preferred_merchants') {
    target.trade_off_summary = `Prioritises Meadowbrook Greengrocer & Hearthstone Bakery where stocked (${deltaStr}).`;
  } else if (params.strategy === 'earliest_delivery') {
    target.trade_off_summary = `Prioritises merchants with earliest Monday morning/midday delivery slots (${deltaStr}).`;
  } else if (params.strategy === 'least_surplus') {
    target.trade_off_summary = `Selects smaller pack sizes to minimise leftover surplus (${target.total_surplus_items} items with surplus; ${deltaStr}).`;
  }

  return target;
}

export function compareAllBasketStrategies(
  db: DatabaseSync,
  fulfilmentModel: FulfilmentModel
): {
  requirements: AggregatedRequirement[];
  comparisons: Record<BasketStrategy, BasketAllocationResult>;
} {
  const ctx = getHouseholdContext(db);
  const requirements = getAggregatedRequirements(db);
  const merchants = listMerchants(db);
  const products = listMerchantProducts(db);
  const config = getShoppingConfig(db);

  const excludedAllergens = Array.from(
    new Set(
      ctx.members.flatMap((m) => [
        ...m.allergens.map((a) => a.toLowerCase()),
        ...m.excluded_ingredients.map((e) => e.toLowerCase()),
      ])
    )
  );

  const strategies: BasketStrategy[] = [
    'baseline',
    'lowest_cost',
    'fewest_merchants',
    'preferred_merchants',
    'earliest_delivery',
    'least_surplus',
  ];

  const comparisons = {} as Record<BasketStrategy, BasketAllocationResult>;
  for (const s of strategies) {
    comparisons[s] = allocateBasketPure({
      requirements,
      merchants,
      products,
      preferredMerchantIds: ctx.household.preferred_merchant_ids,
      householdExcludedAllergens: excludedAllergens,
      strategy: s,
      fulfilmentModel,
      lockedAssignments: config.locked_assignments,
    });
  }

  return {requirements, comparisons};
}
