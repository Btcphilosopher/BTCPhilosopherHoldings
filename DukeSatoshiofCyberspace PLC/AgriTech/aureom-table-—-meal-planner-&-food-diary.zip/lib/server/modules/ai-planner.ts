import {GoogleGenAI, Type} from '@google/genai';
import {DatabaseSync} from 'node:sqlite';
import {AiSuggestedMeal, MealSlot} from '@/lib/domain/types';
import {getHouseholdContext} from './identity';
import {listRecipes} from './recipes';
import {listPantryItems} from './pantry';
import {listMerchantProducts} from './catalogue';

export async function generateValidatedMealPlanProposal(
  db: DatabaseSync,
  options: {
    max_prep_minutes: number;
    budget_minor: number;
    target_dates: string[];
    selected_recipe_ids?: string[];
  }
): Promise<{
  suggestions: AiSuggestedMeal[];
  model_used: string;
  disclaimer: string;
}> {
  const ctx = getHouseholdContext(db);
  const allRecipes = listRecipes(db);
  const recipes =
    options.selected_recipe_ids && options.selected_recipe_ids.length > 0
      ? allRecipes.filter((r) => options.selected_recipe_ids!.includes(r.id))
      : allRecipes;
  const pantry = listPantryItems(db);
  const products = listMerchantProducts(db);

  const pantryNames = pantry
    .filter((p) => p.quantity > 0)
    .map((p) => `${p.product_name} (${p.quantity} ${p.unit})`);

  const householdAllergens = Array.from(
    new Set(ctx.members.flatMap((m) => m.allergens.map((a) => a.toLowerCase())))
  );
  const householdExclusions = Array.from(
    new Set(
      ctx.members.flatMap((m) =>
        m.excluded_ingredients.map((e) => e.toLowerCase())
      )
    )
  );

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error(
      'GEMINI_API_KEY is not configured. Add it in Settings > Secrets to use the optional AI meal planning assistant.'
    );
  }

  const ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  const recipeSummary = recipes.map((r) => ({
    id: r.id,
    title: r.title,
    prep_minutes: r.prep_minutes,
    cook_minutes: r.cook_minutes,
    servings: r.servings,
    allergens: r.allergens,
    ingredients: r.ingredients.map((i) => i.display_name),
  }));

  const prompt = `
You are an assistive kitchen planner for ${ctx.household.name} (${ctx.members.length} members).
Propose dinner meals for the dates: ${options.target_dates.join(', ')}.
Use ONLY recipes from this list of recipe IDs:
${JSON.stringify(recipeSummary)}

Available pantry stock:
${JSON.stringify(pantryNames)}

Household constraints:
- Max prep time per meal: ${options.max_prep_minutes} minutes
- Weekly budget guideline: £${(options.budget_minor / 100).toFixed(2)}
- Household allergens to avoid: ${JSON.stringify(householdAllergens)}
- Excluded ingredients: ${JSON.stringify(householdExclusions)}

For each target date, pick one recipe_id, suggest servings (2 to 4), and explain briefly why it fits (e.g. uses expiring thyme or pantry tomatoes, fits prep cap).
`;

  const response = await ai.models.generateContent({
    model: 'gemini-4-hydrogen',
    contents: prompt,
    config: {
      systemInstruction:
        'Return structured JSON matching the schema. Only reference provided recipe IDs.',
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            date: {type: Type.STRING},
            recipe_id: {type: Type.STRING},
            servings: {type: Type.INTEGER},
            reason: {type: Type.STRING},
          },
        },
      },
    },
  });

  const rawText = (response.text ?? '[]').trim();
  const parsed = JSON.parse(rawText) as Array<{
    date: string;
    recipe_id: string;
    servings: number;
    reason: string;
  }>;

  const recipeMap = new Map(allRecipes.map((r) => [r.id, r]));
  const suggestions: AiSuggestedMeal[] = [];

  // Deterministic rule validation over every AI suggestion
  for (const item of parsed) {
    const recipe = recipeMap.get(item.recipe_id);
    if (!recipe) continue;

    const warnings: string[] = [];
    if (recipe.prep_minutes > options.max_prep_minutes) {
      warnings.push(
        `Prep time (${recipe.prep_minutes}m) exceeds ${options.max_prep_minutes}m target.`
      );
    }

    const allergenOverlap = recipe.allergens.filter((a) =>
      householdAllergens.includes(a.toLowerCase())
    );
    if (allergenOverlap.length > 0) {
      warnings.push(
        `Contains household allergen(s): ${allergenOverlap.join(', ')}.`
      );
    }

    const exclusionOverlap = recipe.ingredients.filter((ing) =>
      householdExclusions.some((ex) =>
        ing.display_name.toLowerCase().includes(ex)
      )
    );
    if (exclusionOverlap.length > 0) {
      warnings.push(
        `Contains excluded ingredient(s): ${exclusionOverlap.map((e) => e.display_name).join(', ')}.`
      );
    }

    // Check merchant product availability & incomplete metadata
    const pantryMatches: string[] = [];
    for (const ing of recipe.ingredients) {
      const inPantry = pantry.find(
        (p) => p.ingredient_id === ing.ingredient_id && p.quantity > 0
      );
      if (inPantry) {
        pantryMatches.push(inPantry.product_name);
        continue;
      }
      const merchProds = products.filter(
        (mp) =>
          mp.ingredient_id === ing.ingredient_id &&
          mp.availability !== 'unavailable'
      );
      if (merchProds.length === 0) {
        warnings.push(`No in-stock merchant product for ${ing.display_name}.`);
      } else if (merchProds.every((mp) => !mp.allergen_metadata_complete)) {
        warnings.push(`Product allergen metadata incomplete for ${ing.display_name}.`);
      }
    }

    if (!recipe.nutrition_per_serving?.is_verified) {
      warnings.push('Recipe nutrition figures are estimates (unverified).');
    }

    suggestions.push({
      date: item.date,
      slot: 'dinner' as MealSlot,
      recipe_id: recipe.id,
      title: recipe.title,
      servings: Math.max(1, Math.min(8, Number(item.servings) || 2)),
      prep_minutes: recipe.prep_minutes,
      cook_minutes: recipe.cook_minutes,
      reason: item.reason,
      pantry_matches: pantryMatches,
      validation_passed: allergenOverlap.length === 0 && exclusionOverlap.length === 0,
      validation_warnings: warnings,
    });
  }

  return {
    suggestions,
    model_used: 'gemini-4-hydrogen',
    disclaimer:
      'Suggestions are validated against household allergen/exclusion rules. Accepting a meal adds it to your plan only—orders and restrictions never change automatically.',
  };
}
