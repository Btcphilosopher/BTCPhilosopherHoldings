import {DatabaseSync} from 'node:sqlite';
import {
  DiaryEntrySource,
  DiaryVisibility,
  FoodDiaryEntry,
} from '@/lib/domain/types';
import {ensureSeeded, HOUSEHOLD_ID} from '../seed';
import {getHouseholdContext} from './identity';

function mapDiaryRow(row: Record<string, unknown>): FoodDiaryEntry {
  return {
    id: String(row.id),
    household_id: String(row.household_id),
    member_id: String(row.member_id),
    member_name: String(row.member_name),
    visibility: row.visibility as DiaryVisibility,
    source: row.source as DiaryEntrySource,
    planned_meal_id: row.planned_meal_id ? String(row.planned_meal_id) : null,
    recipe_id: row.recipe_id ? String(row.recipe_id) : null,
    product_id: row.product_id ? String(row.product_id) : null,
    title: String(row.title),
    date: String(row.date),
    time: String(row.time),
    portion_label: String(row.portion_label),
    differed_from_plan: Boolean(row.differed_from_plan),
    difference_reason: row.difference_reason
      ? String(row.difference_reason)
      : null,
    satisfaction:
      row.satisfaction !== null && row.satisfaction !== undefined
        ? Number(row.satisfaction)
        : null,
    hunger_note: row.hunger_note ? String(row.hunger_note) : null,
    practical_notes: row.practical_notes ? String(row.practical_notes) : null,
    photo_url: row.photo_url ? String(row.photo_url) : null,
    nutrition_summary: row.nutrition_summary_json
      ? JSON.parse(String(row.nutrition_summary_json))
      : null,
    created_at: String(row.created_at),
  };
}

/**
 * Strictly enforces server-side diary privacy:
 * Private entries are ONLY returned when requestingMemberId === row.member_id.
 * Household administrators do NOT gain access to another adult's private entries.
 */
export function listVisibleDiaryEntries(
  db: DatabaseSync,
  requestingMemberId: string
): FoodDiaryEntry[] {
  ensureSeeded(db);
  const rows = db
    .prepare(
      `SELECT * FROM food_diary_entries
       WHERE household_id = ?
         AND (visibility = 'household' OR member_id = ?)
       ORDER BY date DESC, time DESC, created_at DESC`
    )
    .all(HOUSEHOLD_ID, requestingMemberId) as Array<Record<string, unknown>>;

  return rows.map(mapDiaryRow);
}

export function createDiaryEntry(
  db: DatabaseSync,
  input: {
    member_id: string;
    visibility: DiaryVisibility;
    source: DiaryEntrySource;
    planned_meal_id?: string | null;
    recipe_id?: string | null;
    product_id?: string | null;
    title: string;
    date: string;
    time: string;
    portion_label: string;
    differed_from_plan: boolean;
    difference_reason?: string | null;
    satisfaction?: number | null;
    hunger_note?: string | null;
    practical_notes?: string | null;
    photo_url?: string | null;
    nutrition_summary?: FoodDiaryEntry['nutrition_summary'];
  }
): FoodDiaryEntry {
  const ctx = getHouseholdContext(db);
  const member = ctx.members.find((m) => m.id === input.member_id);
  if (!member) {
    throw new Error('Member not found');
  }

  // Validate photo URL (allow local /images/ paths or safe data:image/jpeg|png|webp)
  let safePhotoUrl: string | null = null;
  if (input.photo_url) {
    if (
      input.photo_url.startsWith('/images/') ||
      input.photo_url.startsWith('data:image/jpeg;base64,') ||
      input.photo_url.startsWith('data:image/png;base64,') ||
      input.photo_url.startsWith('data:image/webp;base64,')
    ) {
      safePhotoUrl = input.photo_url;
    } else {
      throw new Error('Unsupported photo attachment format');
    }
  }

  const id = `dia_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const now = new Date().toISOString();

  db.prepare(
    `INSERT INTO food_diary_entries (
      id, household_id, member_id, member_name, visibility, source,
      planned_meal_id, recipe_id, product_id, title, date, time,
      portion_label, differed_from_plan, difference_reason, satisfaction,
      hunger_note, practical_notes, photo_url, nutrition_summary_json, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    id,
    HOUSEHOLD_ID,
    member.id,
    member.name,
    input.visibility,
    input.source,
    input.planned_meal_id ?? null,
    input.recipe_id ?? null,
    input.product_id ?? null,
    input.title,
    input.date,
    input.time,
    input.portion_label,
    input.differed_from_plan ? 1 : 0,
    input.difference_reason ?? null,
    input.satisfaction ?? null,
    input.hunger_note ?? null,
    input.practical_notes ?? null,
    safePhotoUrl,
    input.nutrition_summary ? JSON.stringify(input.nutrition_summary) : null,
    now
  );

  const row = db
    .prepare('SELECT * FROM food_diary_entries WHERE id = ?')
    .get(id) as Record<string, unknown>;
  return mapDiaryRow(row);
}

export function deleteDiaryEntry(
  db: DatabaseSync,
  entryId: string,
  requestingMemberId: string
): boolean {
  ensureSeeded(db);
  const row = db
    .prepare('SELECT member_id FROM food_diary_entries WHERE id = ? AND household_id = ?')
    .get(entryId, HOUSEHOLD_ID) as Record<string, unknown> | undefined;
  if (!row) {
    throw new Error('Diary entry not found');
  }
  if (String(row.member_id) !== requestingMemberId) {
    throw new Error('Only the entry author can delete this diary entry');
  }
  db.prepare('DELETE FROM food_diary_entries WHERE id = ?').run(entryId);
  return true;
}
