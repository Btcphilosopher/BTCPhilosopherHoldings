import {DatabaseSync} from 'node:sqlite';
import {
  DateMarkingType,
  PantryItem,
  PantryTransaction,
  StorageLocation,
} from '@/lib/domain/types';
import {ensureSeeded, HOUSEHOLD_ID} from '../seed';
import {withTransaction} from '../db';

const BARCODE_CATALOGUE: Record<
  string,
  {
    ingredient_id: string;
    product_name: string;
    quantity: number;
    unit: string;
    storage_location: StorageLocation;
    default_shelf_days: number;
    date_marking_type: DateMarkingType;
  }
> = {
  '5010029001123': {
    ingredient_id: 'ing_chopped_tomatoes',
    product_name: 'Mutti Polpa Chopped Tomatoes (400 g tin)',
    quantity: 400,
    unit: 'g',
    storage_location: 'cupboard',
    default_shelf_days: 365,
    date_marking_type: 'best_before',
  },
  '5012345678901': {
    ingredient_id: 'ing_chestnut_mushrooms',
    product_name: 'Organic Chestnut Mushrooms (250 g)',
    quantity: 250,
    unit: 'g',
    storage_location: 'fridge',
    default_shelf_days: 5,
    date_marking_type: 'best_before',
  },
  '8001420001122': {
    ingredient_id: 'ing_arborio_rice',
    product_name: 'Riso Gallo Arborio Risotto Rice (500 g)',
    quantity: 500,
    unit: 'g',
    storage_location: 'cupboard',
    default_shelf_days: 240,
    date_marking_type: 'best_before',
  },
  '5010029004411': {
    ingredient_id: 'ing_sourdough',
    product_name: 'Hearthstone Country Sourdough Boule',
    quantity: 1,
    unit: 'loaf',
    storage_location: 'cupboard',
    default_shelf_days: 4,
    date_marking_type: 'best_before',
  },
  '5010029008811': {
    ingredient_id: 'ing_white_miso',
    product_name: 'Clearspring Sweet White Miso (300 g)',
    quantity: 300,
    unit: 'g',
    storage_location: 'fridge',
    default_shelf_days: 180,
    date_marking_type: 'best_before',
  },
};

function mapPantryRow(row: Record<string, unknown>): PantryItem {
  return {
    id: String(row.id),
    household_id: String(row.household_id),
    ingredient_id: String(row.ingredient_id),
    product_name: String(row.product_name),
    barcode: row.barcode ? String(row.barcode) : null,
    quantity: Number(row.quantity),
    unit: String(row.unit),
    storage_location: row.storage_location as StorageLocation,
    purchase_or_opened_date: String(row.purchase_or_opened_date),
    recorded_expiry_date: row.recorded_expiry_date
      ? String(row.recorded_expiry_date)
      : null,
    date_marking_type: row.date_marking_type as DateMarkingType,
    reserved_quantity: Number(row.reserved_quantity),
    updated_at: String(row.updated_at),
  };
}

export function listPantryItems(db: DatabaseSync): PantryItem[] {
  ensureSeeded(db);
  const rows = db
    .prepare(
      'SELECT * FROM pantry_items WHERE household_id = ? ORDER BY recorded_expiry_date ASC NULLS LAST, product_name ASC'
    )
    .all(HOUSEHOLD_ID) as Array<Record<string, unknown>>;
  return rows.map(mapPantryRow);
}

export function listPantryTransactions(db: DatabaseSync): PantryTransaction[] {
  ensureSeeded(db);
  const rows = db
    .prepare(
      'SELECT * FROM pantry_transactions WHERE household_id = ? ORDER BY created_at DESC LIMIT 40'
    )
    .all(HOUSEHOLD_ID) as Array<Record<string, unknown>>;
  return rows.map((r) => ({
    id: String(r.id),
    household_id: String(r.household_id),
    pantry_item_id: String(r.pantry_item_id),
    action: r.action as PantryTransaction['action'],
    quantity_delta: Number(r.quantity_delta),
    unit: String(r.unit),
    note: String(r.note),
    created_at: String(r.created_at),
  }));
}

export function lookupBarcode(barcode: string): {
  found: boolean;
  barcode: string;
  match?: (typeof BARCODE_CATALOGUE)[string];
} {
  const clean = barcode.trim();
  const match = BARCODE_CATALOGUE[clean];
  return match ? {found: true, barcode: clean, match} : {found: false, barcode: clean};
}

export function getExpiringSoonItems(
  db: DatabaseSync,
  referenceDate = '2026-11-23',
  withinDays = 4
): Array<PantryItem & {days_until_recorded_date: number}> {
  const items = listPantryItems(db);
  const refMs = Date.parse(referenceDate);
  const results: Array<PantryItem & {days_until_recorded_date: number}> = [];
  for (const item of items) {
    if (item.quantity <= 0 || !item.recorded_expiry_date) continue;
    const expMs = Date.parse(item.recorded_expiry_date);
    if (Number.isNaN(expMs)) continue;
    const diffDays = Math.ceil((expMs - refMs) / (1000 * 60 * 60 * 24));
    if (diffDays <= withinDays) {
      results.push({...item, days_until_recorded_date: diffDays});
    }
  }
  return results.sort(
    (a, b) => a.days_until_recorded_date - b.days_until_recorded_date
  );
}

export function addPantryItem(
  db: DatabaseSync,
  input: {
    ingredient_id: string;
    product_name: string;
    barcode?: string | null;
    quantity: number;
    unit: string;
    storage_location: StorageLocation;
    purchase_or_opened_date: string;
    recorded_expiry_date?: string | null;
    date_marking_type: DateMarkingType;
    source_action?: 'manual_add' | 'barcode_lookup' | 'delivery_confirmed';
    note?: string;
  }
): PantryItem {
  ensureSeeded(db);
  const now = new Date().toISOString();
  const id = `pan_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;

  withTransaction(db, () => {
    db.prepare(
      `INSERT INTO pantry_items (
        id, household_id, ingredient_id, product_name, barcode, quantity, unit,
        storage_location, purchase_or_opened_date, recorded_expiry_date,
        date_marking_type, reserved_quantity, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)`
    ).run(
      id,
      HOUSEHOLD_ID,
      input.ingredient_id,
      input.product_name,
      input.barcode ?? null,
      input.quantity,
      input.unit,
      input.storage_location,
      input.purchase_or_opened_date,
      input.recorded_expiry_date ?? null,
      input.date_marking_type,
      now
    );

    db.prepare(
      `INSERT INTO pantry_transactions (
        id, household_id, pantry_item_id, action, quantity_delta, unit, note, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      `ptx_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      HOUSEHOLD_ID,
      id,
      input.source_action ?? 'manual_add',
      input.quantity,
      input.unit,
      input.note ?? 'Added to household pantry',
      now
    );
  });

  const row = db
    .prepare('SELECT * FROM pantry_items WHERE id = ?')
    .get(id) as Record<string, unknown>;
  return mapPantryRow(row);
}

export function adjustPantryStock(
  db: DatabaseSync,
  pantryItemId: string,
  action: 'consumed' | 'discarded' | 'corrected' | 'replenished' | 'meal_cooked',
  amount: number,
  note?: string
): PantryItem {
  ensureSeeded(db);
  const now = new Date().toISOString();

  return withTransaction(db, () => {
    const row = db
      .prepare('SELECT * FROM pantry_items WHERE id = ? AND household_id = ?')
      .get(pantryItemId, HOUSEHOLD_ID) as Record<string, unknown> | undefined;
    if (!row) {
      throw new Error('Pantry item not found');
    }
    const item = mapPantryRow(row);
    let nextQty = item.quantity;
    let delta = 0;

    if (action === 'consumed' || action === 'discarded' || action === 'meal_cooked') {
      const deduct = Math.min(item.quantity, Math.max(0, amount));
      nextQty = Math.round((item.quantity - deduct) * 100) / 100;
      delta = -deduct;
    } else if (action === 'replenished') {
      const add = Math.max(0, amount);
      nextQty = Math.round((item.quantity + add) * 100) / 100;
      delta = add;
    } else if (action === 'corrected') {
      nextQty = Math.max(0, Math.round(amount * 100) / 100);
      delta = Math.round((nextQty - item.quantity) * 100) / 100;
    }

    const nextReserved = Math.min(item.reserved_quantity, nextQty);

    db.prepare(
      'UPDATE pantry_items SET quantity = ?, reserved_quantity = ?, updated_at = ? WHERE id = ?'
    ).run(nextQty, nextReserved, now, pantryItemId);

    db.prepare(
      `INSERT INTO pantry_transactions (
        id, household_id, pantry_item_id, action, quantity_delta, unit, note, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      `ptx_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      HOUSEHOLD_ID,
      pantryItemId,
      action,
      delta,
      item.unit,
      note ?? `Stock ${action}`,
      now
    );

    const updated = db
      .prepare('SELECT * FROM pantry_items WHERE id = ?')
      .get(pantryItemId) as Record<string, unknown>;
    return mapPantryRow(updated);
  });
}

/**
 * Confirms cooking a planned meal with explicit user-confirmed pantry deductions.
 * Requires explicit confirmation; never silently deducts on planning alone.
 */
export function confirmCookMealWithPantryDeductions(
  db: DatabaseSync,
  mealId: string,
  confirmedDeductions: Array<{pantry_item_id: string; deduct_qty: number}>
): void {
  ensureSeeded(db);
  withTransaction(db, () => {
    db.prepare(
      `UPDATE planned_meals SET status = 'cooked' WHERE id = ? AND household_id = ?`
    ).run(mealId, HOUSEHOLD_ID);

    for (const d of confirmedDeductions) {
      if (d.deduct_qty > 0) {
        adjustPantryStock(
          db,
          d.pantry_item_id,
          'meal_cooked',
          d.deduct_qty,
          `Confirmed cooked meal ${mealId}`
        );
      }
    }
  });
}
