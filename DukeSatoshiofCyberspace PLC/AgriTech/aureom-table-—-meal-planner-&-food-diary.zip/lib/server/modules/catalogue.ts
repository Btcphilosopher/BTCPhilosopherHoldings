import {DatabaseSync} from 'node:sqlite';
import {
  DeliverySlot,
  Merchant,
  MerchantCategory,
  MerchantProduct,
} from '@/lib/domain/types';
import {ensureSeeded} from '../seed';

export function listMerchants(db: DatabaseSync): Merchant[] {
  ensureSeeded(db);
  const rows = db
    .prepare('SELECT * FROM merchants ORDER BY name ASC')
    .all() as Array<Record<string, unknown>>;

  return rows.map((r) => ({
    id: String(r.id),
    name: String(r.name),
    category: r.category as MerchantCategory,
    description: String(r.description),
    delivery_areas: JSON.parse(String(r.delivery_areas_json)),
    min_order_minor: Number(r.min_order_minor),
    delivery_fee_minor: Number(r.delivery_fee_minor),
    participates_in_consolidated_hub: Boolean(r.participates_in_consolidated_hub),
    consolidated_partner_name: r.consolidated_partner_name
      ? String(r.consolidated_partner_name)
      : null,
    consolidated_fee_minor:
      r.consolidated_fee_minor !== null && r.consolidated_fee_minor !== undefined
        ? Number(r.consolidated_fee_minor)
        : null,
    slots: JSON.parse(String(r.slots_json)) as DeliverySlot[],
  }));
}

export function listMerchantProducts(db: DatabaseSync): MerchantProduct[] {
  ensureSeeded(db);
  const rows = db
    .prepare('SELECT * FROM merchant_products ORDER BY title ASC')
    .all() as Array<Record<string, unknown>>;

  return rows.map((r) => ({
    id: String(r.id),
    merchant_id: String(r.merchant_id),
    ingredient_id: String(r.ingredient_id),
    sku: String(r.sku),
    title: String(r.title),
    brand: String(r.brand),
    pack_quantity: Number(r.pack_quantity),
    pack_unit: String(r.pack_unit),
    price_minor: Number(r.price_minor),
    currency: 'GBP',
    availability: r.availability as MerchantProduct['availability'],
    source_name: String(r.source_name),
    price_updated_at: String(r.price_updated_at),
    allergens: JSON.parse(String(r.allergens_json)),
    allergen_metadata_complete: Boolean(r.allergen_metadata_complete),
    nutrition_verified: Boolean(r.nutrition_verified),
    nutrition_summary: r.nutrition_summary_json
      ? JSON.parse(String(r.nutrition_summary_json))
      : undefined,
    proposed_substitute_product_id: r.proposed_substitute_product_id
      ? String(r.proposed_substitute_product_id)
      : null,
  }));
}

export function getFeedAgeLabel(isoTimestamp: string, referenceNow = '2026-11-22T23:14:00.000Z'): string {
  const diffMs = Date.parse(referenceNow) - Date.parse(isoTimestamp);
  if (Number.isNaN(diffMs) || diffMs < 0) return 'Updated recently';
  const hours = Math.floor(diffMs / (1000 * 60 * 60));
  if (hours < 1) return 'Updated <1h ago';
  if (hours < 24) return `Updated ${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `Updated ${days}d ago`;
}
