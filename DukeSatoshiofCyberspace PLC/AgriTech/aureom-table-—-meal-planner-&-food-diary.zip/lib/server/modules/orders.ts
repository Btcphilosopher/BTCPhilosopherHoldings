import {DatabaseSync} from 'node:sqlite';
import {
  FulfilmentModel,
  MerchantOrder,
  OrderLineItem,
  ParentCheckout,
  PaymentLedgerEntry,
  SubstitutionPreference,
} from '@/lib/domain/types';
import {ensureSeeded, HOUSEHOLD_ID} from '../seed';
import {withTransaction} from '../db';
import {listMerchantProducts, listMerchants} from './catalogue';
import {getHouseholdContext} from './identity';

export function listCheckouts(db: DatabaseSync): ParentCheckout[] {
  ensureSeeded(db);
  const checkouts = db
    .prepare(
      'SELECT * FROM parent_checkouts WHERE household_id = ? ORDER BY created_at DESC'
    )
    .all(HOUSEHOLD_ID) as Array<Record<string, unknown>>;

  return checkouts.map((c) => hydrateCheckout(db, c));
}

export function getCheckoutById(
  db: DatabaseSync,
  checkoutId: string
): ParentCheckout | null {
  ensureSeeded(db);
  const row = db
    .prepare('SELECT * FROM parent_checkouts WHERE id = ? AND household_id = ?')
    .get(checkoutId, HOUSEHOLD_ID) as Record<string, unknown> | undefined;
  return row ? hydrateCheckout(db, row) : null;
}

function hydrateCheckout(
  db: DatabaseSync,
  c: Record<string, unknown>
): ParentCheckout {
  const checkoutId = String(c.id);
  const orderRows = db
    .prepare(
      'SELECT * FROM merchant_orders WHERE parent_checkout_id = ? ORDER BY created_at ASC'
    )
    .all(checkoutId) as Array<Record<string, unknown>>;

  const merchantOrders: MerchantOrder[] = orderRows.map((o) => {
    const orderId = String(o.id);
    const lineRows = db
      .prepare('SELECT * FROM order_line_items WHERE order_id = ?')
      .all(orderId) as Array<Record<string, unknown>>;

    const lines: OrderLineItem[] = lineRows.map((l) => ({
      id: String(l.id),
      order_id: orderId,
      ingredient_id: String(l.ingredient_id),
      product_id: String(l.product_id),
      product_title: String(l.product_title),
      pack_quantity: Number(l.pack_quantity),
      pack_unit: String(l.pack_unit),
      ordered_packs: Number(l.ordered_packs),
      delivered_packs:
        l.delivered_packs !== null && l.delivered_packs !== undefined
          ? Number(l.delivered_packs)
          : null,
      unit_price_minor: Number(l.unit_price_minor),
      line_total_minor: Number(l.line_total_minor),
      substitution_preference: l.substitution_preference as SubstitutionPreference,
      substitution_status: l.substitution_status as OrderLineItem['substitution_status'],
      proposed_substitute_product_id: l.proposed_substitute_product_id
        ? String(l.proposed_substitute_product_id)
        : null,
      proposed_substitute_title: l.proposed_substitute_title
        ? String(l.proposed_substitute_title)
        : null,
      proposed_substitute_price_minor:
        l.proposed_substitute_price_minor !== null &&
        l.proposed_substitute_price_minor !== undefined
          ? Number(l.proposed_substitute_price_minor)
          : null,
      proposed_substitute_allergens: l.proposed_substitute_allergens_json
        ? JSON.parse(String(l.proposed_substitute_allergens_json))
        : undefined,
      proposed_substitute_metadata_complete:
        l.proposed_substitute_metadata_complete !== null &&
        l.proposed_substitute_metadata_complete !== undefined
          ? Boolean(l.proposed_substitute_metadata_complete)
          : undefined,
      requires_explicit_approval: Boolean(l.requires_explicit_approval),
      substitution_warning: l.substitution_warning
        ? String(l.substitution_warning)
        : null,
      linked_meal_ids: JSON.parse(String(l.linked_meal_ids_json)),
    }));

    return {
      id: orderId,
      parent_checkout_id: checkoutId,
      merchant_id: String(o.merchant_id),
      merchant_name: String(o.merchant_name),
      fulfilment_model: o.fulfilment_model as FulfilmentModel,
      fulfilment_partner_name: o.fulfilment_partner_name
        ? String(o.fulfilment_partner_name)
        : null,
      slot_label: String(o.slot_label),
      status: o.status as MerchantOrder['status'],
      failure_reason: o.failure_reason ? String(o.failure_reason) : null,
      subtotal_minor: Number(o.subtotal_minor),
      delivery_fee_minor: Number(o.delivery_fee_minor),
      total_minor: Number(o.total_minor),
      refunded_minor: Number(o.refunded_minor),
      delivery_confirmed_into_pantry: Boolean(o.delivery_confirmed_into_pantry),
      created_at: String(o.created_at),
      lines,
    };
  });

  const ledgerRows = db
    .prepare(
      'SELECT * FROM payment_ledger WHERE parent_checkout_id = ? ORDER BY created_at ASC'
    )
    .all(checkoutId) as Array<Record<string, unknown>>;

  const ledger: PaymentLedgerEntry[] = ledgerRows.map((l) => ({
    id: String(l.id),
    parent_checkout_id: checkoutId,
    merchant_order_id: l.merchant_order_id ? String(l.merchant_order_id) : null,
    entry_type: l.entry_type as PaymentLedgerEntry['entry_type'],
    amount_minor: Number(l.amount_minor),
    currency: 'GBP',
    status: l.status as PaymentLedgerEntry['status'],
    note: String(l.note),
    created_at: String(l.created_at),
  }));

  return {
    id: checkoutId,
    household_id: String(c.household_id),
    idempotency_key: String(c.idempotency_key),
    delivery_address: String(c.delivery_address),
    delivery_postcode: String(c.delivery_postcode),
    currency: 'GBP',
    total_authorised_minor: Number(c.total_authorised_minor),
    total_captured_minor: Number(c.total_captured_minor),
    total_refunded_minor: Number(c.total_refunded_minor),
    status: c.status as ParentCheckout['status'],
    created_at: String(c.created_at),
    merchant_orders: merchantOrders,
    ledger,
  };
}

export interface CheckoutInput {
  idempotency_key: string;
  delivery_address: string;
  delivery_postcode: string;
  simulate_partial_failure_merchant_id?: string | null;
  groups: Array<{
    merchant_id: string;
    fulfilment_model: FulfilmentModel;
    slot_id: string;
    delivery_fee_minor: number;
    lines: Array<{
      product_id: string;
      packs_to_buy: number;
      substitution_preference: SubstitutionPreference;
      linked_meal_ids: string[];
    }>;
  }>;
}

export function validateUkPostcodeAndAddress(
  address: string,
  postcode: string
): {valid: boolean; reason?: string; outcode?: string} {
  const cleanAddr = address.trim();
  const cleanPc = postcode.trim().toUpperCase();
  if (cleanAddr.length < 5) {
    return {valid: false, reason: 'Please enter a full street address.'};
  }
  const match = cleanPc.match(/^([A-Z]{1,2}\d[A-Z\d]?)\s*\d[A-Z]{2}$/);
  if (!match) {
    return {
      valid: false,
      reason: 'Postcode must be a valid UK postcode (e.g. OX2 6JL).',
    };
  }
  return {valid: true, outcode: match[1]};
}

/**
 * Creates an idempotent parent checkout with separate merchant orders and
 * payment authorisation / capture / refund / settlement ledger entries.
 * Supports partial merchant failure cleanly without pretending atomicity.
 */
export function executeCheckout(
  db: DatabaseSync,
  input: CheckoutInput
): {checkout: ParentCheckout; replayed_idempotency: boolean} {
  ensureSeeded(db);

  // 1. Idempotency check
  const existing = db
    .prepare('SELECT * FROM parent_checkouts WHERE idempotency_key = ?')
    .get(input.idempotency_key) as Record<string, unknown> | undefined;
  if (existing) {
    return {
      checkout: hydrateCheckout(db, existing),
      replayed_idempotency: true,
    };
  }

  // 2. Address validation
  const addrCheck = validateUkPostcodeAndAddress(
    input.delivery_address,
    input.delivery_postcode
  );
  if (!addrCheck.valid) {
    throw new Error(addrCheck.reason || 'Invalid delivery address');
  }

  const merchants = listMerchants(db);
  const products = listMerchantProducts(db);
  const ctx = getHouseholdContext(db);
  const merchantMap = new Map(merchants.map((m) => [m.id, m]));
  const productMap = new Map(products.map((p) => [p.id, p]));

  const householdExclusions = new Set(
    ctx.members.flatMap((m) => [
      ...m.allergens.map((a) => a.toLowerCase()),
      ...m.excluded_ingredients.map((e) => e.toLowerCase()),
    ])
  );

  const now = new Date().toISOString();
  const checkoutId = `chk_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;

  let totalAuthorised = 0;
  let totalCaptured = 0;
  let totalRefunded = 0;
  let anyFailed = false;

  const builtOrders: Array<{
    orderId: string;
    merchantId: string;
    merchantName: string;
    fulfilmentModel: FulfilmentModel;
    partnerName: string | null;
    slotLabel: string;
    status: MerchantOrder['status'];
    failureReason: string | null;
    subtotal: number;
    fee: number;
    total: number;
    lines: Array<{
      lineId: string;
      product: ReturnType<typeof listMerchantProducts>[number];
      packs: number;
      lineTotal: number;
      subPref: SubstitutionPreference;
      subStatus: OrderLineItem['substitution_status'];
      subProd: ReturnType<typeof listMerchantProducts>[number] | null;
      requiresApproval: boolean;
      subWarning: string | null;
      linkedMeals: string[];
    }>;
  }> = [];

  for (const g of input.groups) {
    const merchant = merchantMap.get(g.merchant_id);
    if (!merchant) {
      throw new Error(`Unknown merchant ${g.merchant_id}`);
    }
    if (addrCheck.outcode && !merchant.delivery_areas.includes(addrCheck.outcode)) {
      throw new Error(
        `${merchant.name} does not deliver to ${addrCheck.outcode}. Covered areas: ${merchant.delivery_areas.join(', ')}.`
      );
    }

    const slot =
      merchant.slots.find((s) => s.id === g.slot_id) ?? merchant.slots[0];
    const orderId = `ord_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;

    let subtotal = 0;
    const builtLines: (typeof builtOrders)[number]['lines'] = [];

    for (const item of g.lines) {
      const prod = productMap.get(item.product_id);
      if (!prod) {
        throw new Error(`Product ${item.product_id} not found during price revalidation`);
      }
      if (prod.availability === 'unavailable') {
        throw new Error(`Product ${prod.title} is currently unavailable`);
      }

      const lineTotal = prod.price_minor * item.packs_to_buy;
      subtotal += lineTotal;

      // Check if low-stock item triggers a proposed substitution for demonstration
      let subProd: typeof prod | null = null;
      let subStatus: OrderLineItem['substitution_status'] = 'none';
      let requiresApproval = false;
      let subWarning: string | null = null;

      if (prod.proposed_substitute_product_id) {
        const candidate = productMap.get(prod.proposed_substitute_product_id) ?? null;
        if (candidate) {
          subProd = candidate;
          subStatus = 'proposed';
          const changesAllergens =
            JSON.stringify([...candidate.allergens].sort()) !==
            JSON.stringify([...prod.allergens].sort());
          const violatesHousehold = candidate.allergens.some((a) =>
            householdExclusions.has(a.toLowerCase())
          );
          const incompleteMeta = !candidate.allergen_metadata_complete;
          requiresApproval =
            changesAllergens ||
            violatesHousehold ||
            incompleteMeta ||
            item.substitution_preference === 'require_approval';

          if (violatesHousehold || incompleteMeta || changesAllergens) {
            subWarning = violatesHousehold
              ? `Blocked auto-substitution: ${candidate.title} contains excluded allergen (${candidate.allergens.join(', ')}).`
              : incompleteMeta
              ? `Blocked auto-substitution: incomplete allergen metadata on ${candidate.title}; cannot mark allergy-safe.`
              : `Substitute changes recorded allergen information.`;
          }
        }
      }

      builtLines.push({
        lineId: `oli_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        product: prod,
        packs: item.packs_to_buy,
        lineTotal,
        subPref: item.substitution_preference,
        subStatus,
        subProd,
        requiresApproval,
        subWarning,
        linkedMeals: item.linked_meal_ids,
      });
    }

    const total = subtotal + g.delivery_fee_minor;
    totalAuthorised += total;

    const isSimulatedFailure =
      input.simulate_partial_failure_merchant_id === g.merchant_id;

    if (isSimulatedFailure) {
      anyFailed = true;
      totalRefunded += total;
    } else {
      totalCaptured += total;
    }

    builtOrders.push({
      orderId,
      merchantId: merchant.id,
      merchantName: merchant.name,
      fulfilmentModel: g.fulfilment_model,
      partnerName:
        g.fulfilment_model === 'consolidated'
          ? merchant.consolidated_partner_name ?? 'Aureom Consolidated Hub'
          : null,
      slotLabel: slot?.label ?? 'Standard Window',
      status: isSimulatedFailure ? 'failed' : 'confirmed',
      failureReason: isSimulatedFailure
        ? `${merchant.name} slot reservation expired at merchant gateway. Remaining merchant orders were confirmed; choose a recovery action below.`
        : null,
      subtotal,
      fee: g.delivery_fee_minor,
      total,
      lines: builtLines,
    });
  }

  withTransaction(db, () => {
    db.prepare(
      `INSERT INTO parent_checkouts (
        id, household_id, idempotency_key, delivery_address, delivery_postcode,
        currency, total_authorised_minor, total_captured_minor, total_refunded_minor,
        status, created_at
      ) VALUES (?, ?, ?, ?, ?, 'GBP', ?, ?, ?, ?, ?)`
    ).run(
      checkoutId,
      HOUSEHOLD_ID,
      input.idempotency_key,
      input.delivery_address,
      input.delivery_postcode.toUpperCase(),
      totalAuthorised,
      totalCaptured,
      totalRefunded,
      anyFailed ? 'partial_failure' : 'completed',
      now
    );

    const insOrder = db.prepare(
      `INSERT INTO merchant_orders (
        id, parent_checkout_id, merchant_id, merchant_name, fulfilment_model,
        fulfilment_partner_name, slot_label, status, failure_reason,
        subtotal_minor, delivery_fee_minor, total_minor, refunded_minor,
        delivery_confirmed_into_pantry, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)`
    );

    const insLine = db.prepare(
      `INSERT INTO order_line_items (
        id, order_id, ingredient_id, product_id, product_title, pack_quantity, pack_unit,
        ordered_packs, delivered_packs, unit_price_minor, line_total_minor,
        substitution_preference, substitution_status, proposed_substitute_product_id,
        proposed_substitute_title, proposed_substitute_price_minor,
        proposed_substitute_allergens_json, proposed_substitute_metadata_complete,
        requires_explicit_approval, substitution_warning, linked_meal_ids_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );

    const insLedger = db.prepare(
      `INSERT INTO payment_ledger (
        id, parent_checkout_id, merchant_order_id, entry_type, amount_minor, currency, status, note, created_at
      ) VALUES (?, ?, ?, ?, ?, 'GBP', ?, ?, ?)`
    );

    insLedger.run(
      `led_${Date.now()}_auth`,
      checkoutId,
      null,
      'authorisation',
      totalAuthorised,
      'recorded',
      `Card pre-authorisation across ${builtOrders.length} merchant order(s)`,
      now
    );

    for (const bo of builtOrders) {
      insOrder.run(
        bo.orderId,
        checkoutId,
        bo.merchantId,
        bo.merchantName,
        bo.fulfilmentModel,
        bo.partnerName,
        bo.slotLabel,
        bo.status,
        bo.failureReason,
        bo.subtotal,
        bo.fee,
        bo.total,
        bo.status === 'failed' ? bo.total : 0,
        now
      );

      for (const l of bo.lines) {
        insLine.run(
          l.lineId,
          bo.orderId,
          l.product.ingredient_id,
          l.product.id,
          l.product.title,
          l.product.pack_quantity,
          l.product.pack_unit,
          l.packs,
          l.product.price_minor,
          l.lineTotal,
          l.subPref,
          l.subStatus,
          l.subProd?.id ?? null,
          l.subProd?.title ?? null,
          l.subProd?.price_minor ?? null,
          l.subProd ? JSON.stringify(l.subProd.allergens) : null,
          l.subProd ? (l.subProd.allergen_metadata_complete ? 1 : 0) : null,
          l.requiresApproval ? 1 : 0,
          l.subWarning,
          JSON.stringify(l.linkedMeals)
        );
      }

      if (bo.status === 'failed') {
        insLedger.run(
          `led_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
          checkoutId,
          bo.orderId,
          'refund',
          bo.total,
          'recorded',
          `Released authorisation for failed merchant order (${bo.merchantName})`,
          now
        );
      } else {
        insLedger.run(
          `led_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
          checkoutId,
          bo.orderId,
          'capture',
          bo.total,
          'recorded',
          `Captured payment for confirmed order (${bo.merchantName})`,
          now
        );
        insLedger.run(
          `led_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
          checkoutId,
          bo.orderId,
          'merchant_settlement',
          bo.total,
          'pending',
          `Scheduled merchant settlement (${bo.merchantName})`,
          now
        );
      }
    }
  });

  const saved = getCheckoutById(db, checkoutId)!;
  return {checkout: saved, replayed_idempotency: false};
}

export function retryFailedMerchantOrder(
  db: DatabaseSync,
  orderId: string,
  newSlotLabel?: string
): ParentCheckout {
  ensureSeeded(db);
  const orderRow = db
    .prepare('SELECT * FROM merchant_orders WHERE id = ?')
    .get(orderId) as Record<string, unknown> | undefined;
  if (!orderRow) throw new Error('Merchant order not found');
  if (String(orderRow.status) !== 'failed') {
    throw new Error('Only failed merchant orders can be retried');
  }

  const checkoutId = String(orderRow.parent_checkout_id);
  const total = Number(orderRow.total_minor);
  const merchantName = String(orderRow.merchant_name);
  const now = new Date().toISOString();

  withTransaction(db, () => {
    db.prepare(
      `UPDATE merchant_orders SET
        status = 'confirmed',
        failure_reason = NULL,
        refunded_minor = 0,
        slot_label = COALESCE(?, slot_label)
       WHERE id = ?`
    ).run(newSlotLabel ?? null, orderId);

    db.prepare(
      `UPDATE parent_checkouts SET
        total_captured_minor = total_captured_minor + ?,
        total_refunded_minor = MAX(0, total_refunded_minor - ?),
        status = 'completed'
       WHERE id = ?`
    ).run(total, total, checkoutId);

    db.prepare(
      `INSERT INTO payment_ledger (
        id, parent_checkout_id, merchant_order_id, entry_type, amount_minor, currency, status, note, created_at
      ) VALUES (?, ?, ?, 'capture', ?, 'GBP', 'recorded', ?, ?)`
    ).run(
      `led_${Date.now()}_retry`,
      checkoutId,
      orderId,
      total,
      `Captured payment on recovery retry for ${merchantName}`,
      now
    );
  });

  return getCheckoutById(db, checkoutId)!;
}

export function resolveSubstitutionDecision(
  db: DatabaseSync,
  lineId: string,
  decision: 'approved' | 'rejected'
): ParentCheckout {
  ensureSeeded(db);
  const lineRow = db
    .prepare('SELECT * FROM order_line_items WHERE id = ?')
    .get(lineId) as Record<string, unknown> | undefined;
  if (!lineRow) throw new Error('Order line not found');

  const orderRow = db
    .prepare('SELECT * FROM merchant_orders WHERE id = ?')
    .get(String(lineRow.order_id)) as Record<string, unknown>;
  const checkoutId = String(orderRow.parent_checkout_id);
  const now = new Date().toISOString();

  withTransaction(db, () => {
    if (decision === 'approved') {
      const subTitle = lineRow.proposed_substitute_title
        ? String(lineRow.proposed_substitute_title)
        : String(lineRow.product_title);
      const subPrice = lineRow.proposed_substitute_price_minor
        ? Number(lineRow.proposed_substitute_price_minor)
        : Number(lineRow.unit_price_minor);
      const orderedPacks = Number(lineRow.ordered_packs);
      const newLineTotal = subPrice * orderedPacks;
      const diff = newLineTotal - Number(lineRow.line_total_minor);

      db.prepare(
        `UPDATE order_line_items SET
          substitution_status = 'approved',
          product_title = ?,
          unit_price_minor = ?,
          line_total_minor = ?
         WHERE id = ?`
      ).run(subTitle, subPrice, newLineTotal, lineId);

      if (diff !== 0) {
        db.prepare(
          `UPDATE merchant_orders SET subtotal_minor = subtotal_minor + ?, total_minor = total_minor + ? WHERE id = ?`
        ).run(diff, diff, String(orderRow.id));
        db.prepare(
          `UPDATE parent_checkouts SET total_captured_minor = total_captured_minor + ? WHERE id = ?`
        ).run(diff, checkoutId);
      }
    } else {
      const refundAmt = Number(lineRow.line_total_minor);
      db.prepare(
        `UPDATE order_line_items SET
          substitution_status = 'rejected',
          delivered_packs = 0
         WHERE id = ?`
      ).run(lineId);

      db.prepare(
        `UPDATE merchant_orders SET refunded_minor = refunded_minor + ? WHERE id = ?`
      ).run(refundAmt, String(orderRow.id));

      db.prepare(
        `UPDATE parent_checkouts SET total_refunded_minor = total_refunded_minor + ? WHERE id = ?`
      ).run(refundAmt, checkoutId);

      db.prepare(
        `INSERT INTO payment_ledger (
          id, parent_checkout_id, merchant_order_id, entry_type, amount_minor, currency, status, note, created_at
        ) VALUES (?, ?, ?, 'refund', ?, 'GBP', 'recorded', ?, ?)`
      ).run(
        `led_${Date.now()}_subref`,
        checkoutId,
        String(orderRow.id),
        refundAmt,
        `Refunded rejected substitute for ${String(lineRow.product_title)}`,
        now
      );
    }
  });

  return getCheckoutById(db, checkoutId)!;
}

export function cancelMerchantOrder(
  db: DatabaseSync,
  orderId: string
): ParentCheckout {
  ensureSeeded(db);
  const orderRow = db
    .prepare('SELECT * FROM merchant_orders WHERE id = ?')
    .get(orderId) as Record<string, unknown> | undefined;
  if (!orderRow) throw new Error('Merchant order not found');
  const checkoutId = String(orderRow.parent_checkout_id);
  const currentStatus = String(orderRow.status);
  if (currentStatus === 'delivered' || currentStatus === 'cancelled') {
    throw new Error(`Cannot cancel order in status ${currentStatus}`);
  }

  const remainingToRefund = Math.max(
    0,
    Number(orderRow.total_minor) - Number(orderRow.refunded_minor)
  );
  const now = new Date().toISOString();

  withTransaction(db, () => {
    db.prepare(
      `UPDATE merchant_orders SET status = 'cancelled', refunded_minor = total_minor WHERE id = ?`
    ).run(orderId);

    if (remainingToRefund > 0) {
      db.prepare(
        `UPDATE parent_checkouts SET total_refunded_minor = total_refunded_minor + ? WHERE id = ?`
      ).run(remainingToRefund, checkoutId);

      db.prepare(
        `INSERT INTO payment_ledger (
          id, parent_checkout_id, merchant_order_id, entry_type, amount_minor, currency, status, note, created_at
        ) VALUES (?, ?, ?, 'refund', ?, 'GBP', 'recorded', ?, ?)`
      ).run(
        `led_${Date.now()}_cancel`,
        checkoutId,
        orderId,
        remainingToRefund,
        `Order cancelled by household (${String(orderRow.merchant_name)})`,
        now
      );
    }
  });

  return getCheckoutById(db, checkoutId)!;
}

/**
 * Duplicate-safe webhook handler for simulated merchant/payment events.
 */
export function processWebhookEvent(
  db: DatabaseSync,
  eventId: string,
  provider: string,
  payload: Record<string, unknown>
): {duplicate: boolean; processed: boolean} {
  ensureSeeded(db);
  const seen = db
    .prepare('SELECT event_id FROM webhook_events WHERE event_id = ?')
    .get(eventId);
  if (seen) {
    return {duplicate: true, processed: false};
  }
  db.prepare(
    'INSERT INTO webhook_events (event_id, provider, payload_json, processed_at) VALUES (?, ?, ?, ?)'
  ).run(eventId, provider, JSON.stringify(payload), new Date().toISOString());
  return {duplicate: false, processed: true};
}
