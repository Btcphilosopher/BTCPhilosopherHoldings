import {DatabaseSync} from 'node:sqlite';
import {IngredientIdentity, Recipe, RecipeIngredient} from '@/lib/domain/types';
import {ensureSeeded} from '../seed';
import {withTransaction} from '../db';

export function listIngredientIdentities(db: DatabaseSync): IngredientIdentity[] {
  ensureSeeded(db);
  const rows = db
    .prepare('SELECT * FROM ingredient_identities ORDER BY canonical_name ASC')
    .all() as Array<Record<string, unknown>>;

  return rows.map((r) => ({
    id: String(r.id),
    canonical_name: String(r.canonical_name),
    form_variety: String(r.form_variety),
    default_unit: String(r.default_unit),
    is_pantry_staple: Boolean(r.is_pantry_staple),
    documented_conversion: r.documented_conversion_json
      ? JSON.parse(String(r.documented_conversion_json))
      : undefined,
  }));
}

export function listRecipes(db: DatabaseSync): Recipe[] {
  ensureSeeded(db);
  const recipeRows = db
    .prepare('SELECT * FROM recipes ORDER BY title ASC')
    .all() as Array<Record<string, unknown>>;
  const ingRows = db
    .prepare('SELECT * FROM recipe_ingredients')
    .all() as Array<Record<string, unknown>>;

  const ingByRecipe = new Map<string, RecipeIngredient[]>();
  for (const row of ingRows) {
    const rid = String(row.recipe_id);
    const list = ingByRecipe.get(rid) ?? [];
    list.push({
      id: String(row.id),
      ingredient_id: String(row.ingredient_id),
      display_name: String(row.display_name),
      form_variety: String(row.form_variety),
      quantity: Number(row.quantity),
      unit: String(row.unit),
      is_optional: Boolean(row.is_optional),
      is_garnish: Boolean(row.is_garnish),
      is_pantry_staple: Boolean(row.is_pantry_staple),
      documented_conversion: row.documented_conversion_json
        ? JSON.parse(String(row.documented_conversion_json))
        : undefined,
    });
    ingByRecipe.set(rid, list);
  }

  return recipeRows.map((r) => ({
    id: String(r.id),
    title: String(r.title),
    description: String(r.description),
    image_url: String(r.image_url),
    image_source: String(r.image_source),
    servings: Number(r.servings),
    prep_minutes: Number(r.prep_minutes),
    cook_minutes: Number(r.cook_minutes),
    instructions: JSON.parse(String(r.instructions_json)),
    dietary_tags: JSON.parse(String(r.dietary_tags_json)),
    allergens: JSON.parse(String(r.allergens_json)),
    allergen_provenance: String(r.allergen_provenance),
    nutrition_per_serving: r.nutrition_json
      ? JSON.parse(String(r.nutrition_json))
      : undefined,
    storage_notes: r.storage_notes ? String(r.storage_notes) : undefined,
    leftover_notes: r.leftover_notes ? String(r.leftover_notes) : undefined,
    ingredients: ingByRecipe.get(String(r.id)) ?? [],
  }));
}

export function scaleRecipeIngredients(
  recipe: Recipe,
  targetServings: number
): RecipeIngredient[] {
  if (targetServings <= 0 || recipe.servings <= 0) {
    throw new Error('Servings must be greater than zero');
  }
  const ratio = targetServings / recipe.servings;
  return recipe.ingredients.map((ing) => ({
    ...ing,
    quantity: Math.round(ing.quantity * ratio * 100) / 100,
  }));
}

export function createRecipe(
  db: DatabaseSync,
  input: {
    title: string;
    description: string;
    servings: number;
    prep_minutes: number;
    cook_minutes: number;
    instructions: string[];
    dietary_tags: string[];
    allergens: string[];
    allergen_provenance: string;
    storage_notes?: string;
    leftover_notes?: string;
    image_url?: string;
    image_source?: string;
    ingredients: Array<{
      ingredient_id: string;
      display_name: string;
      form_variety: string;
      quantity: number;
      unit: string;
      is_optional?: boolean;
      is_garnish?: boolean;
      is_pantry_staple?: boolean;
    }>;
  }
): Recipe {
  ensureSeeded(db);
  const id = `rec_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const imgUrl = input.image_url || '/images/hero_kitchen_table.jpg';
  const imgSrc =
    input.image_source || 'Aureom Studio Culinary Archive · User Recipe Photo';

  withTransaction(db, () => {
    db.prepare(
      `INSERT INTO recipes (
        id, title, description, image_url, image_source, servings,
        prep_minutes, cook_minutes, instructions_json, dietary_tags_json,
        allergens_json, allergen_provenance, nutrition_json, storage_notes, leftover_notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      id,
      input.title,
      input.description,
      imgUrl,
      imgSrc,
      input.servings,
      input.prep_minutes,
      input.cook_minutes,
      JSON.stringify(input.instructions),
      JSON.stringify(input.dietary_tags),
      JSON.stringify(input.allergens),
      input.allergen_provenance,
      null,
      input.storage_notes ?? null,
      input.leftover_notes ?? null
    );

    const insertIng = db.prepare(
      `INSERT INTO recipe_ingredients (
        id, recipe_id, ingredient_id, display_name, form_variety, quantity, unit,
        is_optional, is_garnish, is_pantry_staple, documented_conversion_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    input.ingredients.forEach((ing, idx) => {
      insertIng.run(
        `ri_${id}_${idx}`,
        id,
        ing.ingredient_id,
        ing.display_name,
        ing.form_variety,
        ing.quantity,
        ing.unit,
        ing.is_optional ? 1 : 0,
        ing.is_garnish ? 1 : 0,
        ing.is_pantry_staple ? 1 : 0,
        null
      );
    });
  });

  const created = listRecipes(db).find((r) => r.id === id);
  if (!created) {
    throw new Error('Failed to persist recipe');
  }
  return created;
}
