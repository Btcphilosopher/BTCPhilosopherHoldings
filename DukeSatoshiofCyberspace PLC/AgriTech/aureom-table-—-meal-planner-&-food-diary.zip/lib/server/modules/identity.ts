import {DatabaseSync} from 'node:sqlite';
import {Household, HouseholdMember} from '@/lib/domain/types';
import {ensureSeeded, HOUSEHOLD_ID} from '../seed';
import {withTransaction} from '../db';

export interface HouseholdContext {
  household: Household;
  members: HouseholdMember[];
  active_member_id: string;
  active_member: HouseholdMember;
}

export function getHouseholdContext(db: DatabaseSync): HouseholdContext {
  ensureSeeded(db);
  const hhRow = db
    .prepare('SELECT * FROM households WHERE id = ?')
    .get(HOUSEHOLD_ID) as Record<string, unknown> | undefined;
  if (!hhRow) {
    throw new Error('Household not found');
  }

  const memberRows = db
    .prepare('SELECT * FROM household_members WHERE household_id = ? ORDER BY created_at ASC')
    .all(HOUSEHOLD_ID) as Array<Record<string, unknown>>;

  const members: HouseholdMember[] = memberRows.map((m) => ({
    id: String(m.id),
    household_id: String(m.household_id),
    name: String(m.name),
    role: m.role as HouseholdMember['role'],
    dietary_preferences: JSON.parse(String(m.dietary_preferences_json)),
    dislikes: JSON.parse(String(m.dislikes_json)),
    excluded_ingredients: JSON.parse(String(m.excluded_ingredients_json)),
    allergens: JSON.parse(String(m.allergens_json)),
    portion_multiplier: Number(m.portion_multiplier),
    created_at: String(m.created_at),
  }));

  const activeMemberId = String(hhRow.active_member_id);
  const activeMember =
    members.find((m) => m.id === activeMemberId) ?? members[0];

  const household: Household = {
    id: String(hhRow.id),
    name: String(hhRow.name),
    address_line1: String(hhRow.address_line1),
    city: String(hhRow.city),
    postcode: String(hhRow.postcode),
    currency: 'GBP',
    weekly_budget_minor: Number(hhRow.weekly_budget_minor),
    preferred_merchant_ids: JSON.parse(String(hhRow.preferred_merchant_ids_json)),
    default_fulfilment_model: hhRow.default_fulfilment_model as Household['default_fulfilment_model'],
    share_delivery_details_with_merchants: Boolean(hhRow.share_delivery_details_with_merchants),
    track_calories_in_diary: Boolean(hhRow.track_calories_in_diary),
    notification_prefs: JSON.parse(String(hhRow.notification_prefs_json)),
    created_at: String(hhRow.created_at),
  };

  return {
    household,
    members,
    active_member_id: activeMember.id,
    active_member: activeMember,
  };
}

export function setActiveMember(db: DatabaseSync, memberId: string): HouseholdContext {
  const ctx = getHouseholdContext(db);
  const found = ctx.members.find((m) => m.id === memberId);
  if (!found) {
    throw new Error('Member not found in household');
  }
  db.prepare('UPDATE households SET active_member_id = ? WHERE id = ?').run(
    memberId,
    HOUSEHOLD_ID
  );
  return getHouseholdContext(db);
}

export function updateHouseholdSettings(
  db: DatabaseSync,
  updates: Partial<{
    name: string;
    address_line1: string;
    city: string;
    postcode: string;
    weekly_budget_minor: number;
    preferred_merchant_ids: string[];
    default_fulfilment_model: 'separate' | 'consolidated';
    share_delivery_details_with_merchants: boolean;
    track_calories_in_diary: boolean;
    notification_prefs: Household['notification_prefs'];
  }>
): HouseholdContext {
  const ctx = getHouseholdContext(db);
  const h = ctx.household;
  db.prepare(
    `UPDATE households SET
      name = ?, address_line1 = ?, city = ?, postcode = ?,
      weekly_budget_minor = ?, preferred_merchant_ids_json = ?,
      default_fulfilment_model = ?, share_delivery_details_with_merchants = ?,
      track_calories_in_diary = ?, notification_prefs_json = ?
     WHERE id = ?`
  ).run(
    updates.name ?? h.name,
    updates.address_line1 ?? h.address_line1,
    updates.city ?? h.city,
    updates.postcode ?? h.postcode,
    updates.weekly_budget_minor ?? h.weekly_budget_minor,
    JSON.stringify(updates.preferred_merchant_ids ?? h.preferred_merchant_ids),
    updates.default_fulfilment_model ?? h.default_fulfilment_model,
    (updates.share_delivery_details_with_merchants ?? h.share_delivery_details_with_merchants) ? 1 : 0,
    (updates.track_calories_in_diary ?? h.track_calories_in_diary) ? 1 : 0,
    JSON.stringify(updates.notification_prefs ?? h.notification_prefs),
    HOUSEHOLD_ID
  );
  return getHouseholdContext(db);
}

export function updateMemberPreferences(
  db: DatabaseSync,
  memberId: string,
  updates: Partial<{
    name: string;
    dietary_preferences: string[];
    dislikes: string[];
    excluded_ingredients: string[];
    allergens: string[];
    portion_multiplier: number;
  }>
): HouseholdContext {
  const ctx = getHouseholdContext(db);
  const existing = ctx.members.find((m) => m.id === memberId);
  if (!existing) {
    throw new Error('Member not found');
  }
  db.prepare(
    `UPDATE household_members SET
      name = ?, dietary_preferences_json = ?, dislikes_json = ?,
      excluded_ingredients_json = ?, allergens_json = ?, portion_multiplier = ?
     WHERE id = ? AND household_id = ?`
  ).run(
    updates.name ?? existing.name,
    JSON.stringify(updates.dietary_preferences ?? existing.dietary_preferences),
    JSON.stringify(updates.dislikes ?? existing.dislikes),
    JSON.stringify(updates.excluded_ingredients ?? existing.excluded_ingredients),
    JSON.stringify(updates.allergens ?? existing.allergens),
    updates.portion_multiplier ?? existing.portion_multiplier,
    memberId,
    HOUSEHOLD_ID
  );
  return getHouseholdContext(db);
}

export function addHouseholdMember(
  db: DatabaseSync,
  input: {
    name: string;
    role: 'adult' | 'child';
    dietary_preferences: string[];
    dislikes: string[];
    excluded_ingredients: string[];
    allergens: string[];
    portion_multiplier: number;
  }
): HouseholdContext {
  ensureSeeded(db);
  const id = `mem_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  db.prepare(
    `INSERT INTO household_members (
      id, household_id, name, role, dietary_preferences_json, dislikes_json,
      excluded_ingredients_json, allergens_json, portion_multiplier, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    id,
    HOUSEHOLD_ID,
    input.name,
    input.role,
    JSON.stringify(input.dietary_preferences),
    JSON.stringify(input.dislikes),
    JSON.stringify(input.excluded_ingredients),
    JSON.stringify(input.allergens),
    input.portion_multiplier,
    new Date().toISOString()
  );
  return getHouseholdContext(db);
}

export function deleteHouseholdMember(
  db: DatabaseSync,
  memberId: string
): HouseholdContext {
  const ctx = getHouseholdContext(db);
  if (ctx.members.length <= 1) {
    throw new Error('Cannot remove the last remaining household member');
  }
  if (memberId === ctx.active_member_id) {
    throw new Error('Switch to another member before removing this account');
  }
  withTransaction(db, () => {
    db.prepare('DELETE FROM household_members WHERE id = ? AND household_id = ?').run(
      memberId,
      HOUSEHOLD_ID
    );
  });
  return getHouseholdContext(db);
}

export function exportHouseholdDataForMember(
  db: DatabaseSync,
  requestingMemberId: string
): Record<string, unknown> {
  const ctx = getHouseholdContext(db);
  const memberExists = ctx.members.some((m) => m.id === requestingMemberId);
  if (!memberExists) {
    throw new Error('Unauthorized member for export');
  }
  const meals = db
    .prepare('SELECT * FROM planned_meals WHERE household_id = ?')
    .all(HOUSEHOLD_ID);
  const pantry = db
    .prepare('SELECT * FROM pantry_items WHERE household_id = ?')
    .all(HOUSEHOLD_ID);
  const orders = db
    .prepare('SELECT * FROM parent_checkouts WHERE household_id = ?')
    .all(HOUSEHOLD_ID);
  // Privacy rule: export ONLY shared household diary entries or entries owned by requestingMemberId
  const diary = db
    .prepare(
      `SELECT * FROM food_diary_entries
       WHERE household_id = ? AND (visibility = 'household' OR member_id = ?)`
    )
    .all(HOUSEHOLD_ID, requestingMemberId);

  return {
    exported_at: new Date().toISOString(),
    exported_for_member_id: requestingMemberId,
    household: ctx.household,
    members: ctx.members,
    planned_meals: meals,
    pantry_items: pantry,
    orders,
    diary_entries_visible_to_member: diary,
  };
}
