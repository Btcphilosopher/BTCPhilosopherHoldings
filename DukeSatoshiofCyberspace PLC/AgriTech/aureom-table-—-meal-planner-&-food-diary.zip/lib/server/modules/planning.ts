import {DatabaseSync} from 'node:sqlite';
import {
  MealPlanWeek,
  MealSlot,
  PlannedMeal,
  PlannedMealKind,
} from '@/lib/domain/types';
import {CURRENT_WEEK_ID, ensureSeeded, HOUSEHOLD_ID} from '../seed';
import {withTransaction} from '../db';
import {listRecipes, scaleRecipeIngredients} from './recipes';

function mapMealRow(row: Record<string, unknown>): PlannedMeal {
  return {
    id: String(row.id),
    week_id: String(row.week_id),
    household_id: String(row.household_id),
    date: String(row.date),
    slot: row.slot as MealSlot,
    kind: row.kind as PlannedMealKind,
    recipe_id: row.recipe_id ? String(row.recipe_id) : null,
    title: String(row.title),
    servings: Number(row.servings),
    assigned_member_ids: JSON.parse(String(row.assigned_member_ids_json)),
    leftover_source_meal_id: row.leftover_source_meal_id
      ? String(row.leftover_source_meal_id)
      : null,
    leftover_portions_yielded: Number(row.leftover_portions_yielded),
    status: row.status as PlannedMeal['status'],
    notes: row.notes ? String(row.notes) : undefined,
    prep_minutes: Number(row.prep_minutes),
    cook_minutes: Number(row.cook_minutes),
    linked_order_ids: JSON.parse(String(row.linked_order_ids_json)),
  };
}

export function getPlanningState(db: DatabaseSync): {
  current_week: MealPlanWeek;
  templates: MealPlanWeek[];
  meals: PlannedMeal[];
} {
  ensureSeeded(db);
  const weekRows = db
    .prepare('SELECT * FROM meal_plan_weeks WHERE household_id = ? ORDER BY is_template ASC, week_start_date DESC')
    .all(HOUSEHOLD_ID) as Array<Record<string, unknown>>;

  const weeks: MealPlanWeek[] = weekRows.map((w) => ({
    id: String(w.id),
    household_id: String(w.household_id),
    week_start_date: String(w.week_start_date),
    title: String(w.title),
    weekly_budget_minor: Number(w.weekly_budget_minor),
    is_template: Boolean(w.is_template),
    shared_with_household: Boolean(w.shared_with_household),
    created_at: String(w.created_at),
  }));

  const currentWeek =
    weeks.find((w) => w.id === CURRENT_WEEK_ID) ??
    weeks.find((w) => !w.is_template) ??
    weeks[0];

  const templates = weeks.filter((w) => w.is_template);
  const mealRows = db
    .prepare(
      'SELECT * FROM planned_meals WHERE week_id = ? ORDER BY date ASC, slot ASC'
    )
    .all(currentWeek.id) as Array<Record<string, unknown>>;

  return {
    current_week: currentWeek,
    templates,
    meals: mealRows.map(mapMealRow),
  };
}

export function addPlannedMeal(
  db: DatabaseSync,
  input: {
    date: string;
    slot: MealSlot;
    kind: PlannedMealKind;
    recipe_id?: string | null;
    title: string;
    servings: number;
    assigned_member_ids: string[];
    leftover_source_meal_id?: string | null;
    leftover_portions_yielded?: number;
    notes?: string;
    prep_minutes?: number;
    cook_minutes?: number;
  }
): PlannedMeal {
  const {current_week} = getPlanningState(db);
  const id = `pm_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;

  let prep = input.prep_minutes ?? 0;
  let cook = input.cook_minutes ?? 0;
  if (input.recipe_id && (prep === 0 || cook === 0)) {
    const rec = listRecipes(db).find((r) => r.id === input.recipe_id);
    if (rec) {
      prep = input.prep_minutes ?? rec.prep_minutes;
      cook = input.cook_minutes ?? rec.cook_minutes;
    }
  }

  db.prepare(
    `INSERT INTO planned_meals (
      id, week_id, household_id, date, slot, kind, recipe_id, title, servings,
      assigned_member_ids_json, leftover_source_meal_id, leftover_portions_yielded,
      status, notes, prep_minutes, cook_minutes, linked_order_ids_json
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'planned', ?, ?, ?, '[]')`
  ).run(
    id,
    current_week.id,
    HOUSEHOLD_ID,
    input.date,
    input.slot,
    input.kind,
    input.recipe_id ?? null,
    input.title,
    input.servings,
    JSON.stringify(input.assigned_member_ids),
    input.leftover_source_meal_id ?? null,
    input.leftover_portions_yielded ?? 0,
    input.notes ?? null,
    prep,
    cook
  );

  const row = db
    .prepare('SELECT * FROM planned_meals WHERE id = ?')
    .get(id) as Record<string, unknown>;
  return mapMealRow(row);
}

/**
 * Updates or moves a planned meal.
 * INVARIANT: Editing or moving a planned meal NEVER silently modifies any existing order.
 * If linked orders exist, we return `order_immutability_notice` explicitly.
 */
export function updatePlannedMeal(
  db: DatabaseSync,
  mealId: string,
  updates: Partial<{
    date: string;
    slot: MealSlot;
    servings: number;
    title: string;
    kind: PlannedMealKind;
    assigned_member_ids: string[];
    leftover_portions_yielded: number;
    notes: string;
    status: PlannedMeal['status'];
  }>
): {meal: PlannedMeal; order_immutability_notice: string | null} {
  ensureSeeded(db);
  const row = db
    .prepare('SELECT * FROM planned_meals WHERE id = ? AND household_id = ?')
    .get(mealId, HOUSEHOLD_ID) as Record<string, unknown> | undefined;
  if (!row) {
    throw new Error('Planned meal not found');
  }
  const existing = mapMealRow(row);

  db.prepare(
    `UPDATE planned_meals SET
      date = ?, slot = ?, servings = ?, title = ?, kind = ?,
      assigned_member_ids_json = ?, leftover_portions_yielded = ?,
      notes = ?, status = ?
     WHERE id = ?`
  ).run(
    updates.date ?? existing.date,
    updates.slot ?? existing.slot,
    updates.servings ?? existing.servings,
    updates.title ?? existing.title,
    updates.kind ?? existing.kind,
    JSON.stringify(updates.assigned_member_ids ?? existing.assigned_member_ids),
    updates.leftover_portions_yielded ?? existing.leftover_portions_yielded,
    updates.notes !== undefined ? updates.notes : existing.notes ?? null,
    updates.status ?? existing.status,
    mealId
  );

  const updatedRow = db
    .prepare('SELECT * FROM planned_meals WHERE id = ?')
    .get(mealId) as Record<string, unknown>;
  const updated = mapMealRow(updatedRow);

  const notice =
    existing.linked_order_ids.length > 0
      ? `Meal updated in calendar. Existing placed order(s) (${existing.linked_order_ids.join(', ')}) were not altered.`
      : null;

  return {meal: updated, order_immutability_notice: notice};
}

export function deletePlannedMeal(
  db: DatabaseSync,
  mealId: string
): {deleted: boolean; order_immutability_notice: string | null} {
  ensureSeeded(db);
  const row = db
    .prepare('SELECT * FROM planned_meals WHERE id = ? AND household_id = ?')
    .get(mealId, HOUSEHOLD_ID) as Record<string, unknown> | undefined;
  if (!row) {
    throw new Error('Planned meal not found');
  }
  const existing = mapMealRow(row);
  db.prepare('DELETE FROM planned_meals WHERE id = ?').run(mealId);
  const notice =
    existing.linked_order_ids.length > 0
      ? `Meal removed from plan. Existing order(s) (${existing.linked_order_ids.join(', ')}) remain unchanged.`
      : null;
  return {deleted: true, order_immutability_notice: notice};
}

export function copyDayMeals(
  db: DatabaseSync,
  sourceDate: string,
  targetDate: string
): PlannedMeal[] {
  const {current_week, meals} = getPlanningState(db);
  const dayMeals = meals.filter((m) => m.date === sourceDate);
  if (dayMeals.length === 0) {
    return [];
  }
  const created: PlannedMeal[] = [];
  withTransaction(db, () => {
    for (const m of dayMeals) {
      const id = `pm_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
      db.prepare(
        `INSERT INTO planned_meals (
          id, week_id, household_id, date, slot, kind, recipe_id, title, servings,
          assigned_member_ids_json, leftover_source_meal_id, leftover_portions_yielded,
          status, notes, prep_minutes, cook_minutes, linked_order_ids_json
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'planned', ?, ?, ?, '[]')`
      ).run(
        id,
        current_week.id,
        HOUSEHOLD_ID,
        targetDate,
        m.slot,
        m.kind,
        m.recipe_id ?? null,
        m.title,
        m.servings,
        JSON.stringify(m.assigned_member_ids),
        m.leftover_source_meal_id ?? null,
        m.leftover_portions_yielded,
        m.notes ?? null,
        m.prep_minutes,
        m.cook_minutes
      );
      const row = db
        .prepare('SELECT * FROM planned_meals WHERE id = ?')
        .get(id) as Record<string, unknown>;
      created.push(mapMealRow(row));
    }
  });
  return created;
}

export function saveWeekAsTemplate(
  db: DatabaseSync,
  title: string
): MealPlanWeek {
  const {current_week, meals} = getPlanningState(db);
  const tplId = `week_tpl_${Date.now()}`;
  const now = new Date().toISOString();

  withTransaction(db, () => {
    db.prepare(
      `INSERT INTO meal_plan_weeks (
        id, household_id, week_start_date, title, weekly_budget_minor,
        is_template, shared_with_household, created_at
      ) VALUES (?, ?, ?, ?, ?, 1, 1, ?)`
    ).run(
      tplId,
      HOUSEHOLD_ID,
      current_week.week_start_date,
      title,
      current_week.weekly_budget_minor,
      now
    );

    const ins = db.prepare(
      `INSERT INTO planned_meals (
        id, week_id, household_id, date, slot, kind, recipe_id, title, servings,
        assigned_member_ids_json, leftover_source_meal_id, leftover_portions_yielded,
        status, notes, prep_minutes, cook_minutes, linked_order_ids_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'planned', ?, ?, ?, '[]')`
    );
    meals.forEach((m, idx) => {
      ins.run(
        `pm_tpl_${tplId}_${idx}`,
        tplId,
        HOUSEHOLD_ID,
        m.date,
        m.slot,
        m.kind,
        m.recipe_id ?? null,
        m.title,
        m.servings,
        JSON.stringify(m.assigned_member_ids),
        null,
        m.leftover_portions_yielded,
        m.notes ?? null,
        m.prep_minutes,
        m.cook_minutes
      );
    });
  });

  const row = db
    .prepare('SELECT * FROM meal_plan_weeks WHERE id = ?')
    .get(tplId) as Record<string, unknown>;
  return {
    id: String(row.id),
    household_id: String(row.household_id),
    week_start_date: String(row.week_start_date),
    title: String(row.title),
    weekly_budget_minor: Number(row.weekly_budget_minor),
    is_template: Boolean(row.is_template),
    shared_with_household: Boolean(row.shared_with_household),
    created_at: String(row.created_at),
  };
}

export function previewCookMealPantryDeductions(
  db: DatabaseSync,
  mealId: string
): Array<{
  pantry_item_id: string;
  product_name: string;
  ingredient_id: string;
  available_qty: number;
  suggested_deduct_qty: number;
  unit: string;
}> {
  ensureSeeded(db);
  const mealRow = db
    .prepare('SELECT * FROM planned_meals WHERE id = ? AND household_id = ?')
    .get(mealId, HOUSEHOLD_ID) as Record<string, unknown> | undefined;
  if (!mealRow) {
    throw new Error('Planned meal not found');
  }
  const meal = mapMealRow(mealRow);
  if (!meal.recipe_id) {
    return [];
  }
  const recipe = listRecipes(db).find((r) => r.id === meal.recipe_id);
  if (!recipe) {
    return [];
  }
  const scaled = scaleRecipeIngredients(recipe, meal.servings);
  const pantryRows = db
    .prepare('SELECT * FROM pantry_items WHERE household_id = ? AND quantity > 0')
    .all(HOUSEHOLD_ID) as Array<Record<string, unknown>>;

  const deductions: Array<{
    pantry_item_id: string;
    product_name: string;
    ingredient_id: string;
    available_qty: number;
    suggested_deduct_qty: number;
    unit: string;
  }> = [];

  for (const reqIng of scaled) {
    const match = pantryRows.find(
      (p) =>
        String(p.ingredient_id) === reqIng.ingredient_id &&
        String(p.unit) === reqIng.unit
    );
    if (match) {
      const avail = Number(match.quantity);
      const deduct = Math.min(avail, reqIng.quantity);
      if (deduct > 0) {
        deductions.push({
          pantry_item_id: String(match.id),
          product_name: String(match.product_name),
          ingredient_id: String(match.ingredient_id),
          available_qty: avail,
          suggested_deduct_qty: Math.round(deduct * 100) / 100,
          unit: String(match.unit),
        });
      }
    }
  }
  return deductions;
}
