import {DatabaseSync} from 'node:sqlite';
import {ParentCheckout, StorageLocation} from '@/lib/domain/types';
import {ensureSeeded, HOUSEHOLD_ID} from '../seed';
import {withTransaction} from '../db';
import {addPantryItem} from './pantry';
import {getCheckoutById} from './orders';

export function confirmDeliveryIntoPantry(
  db: DatabaseSync,
  orderId: string,
  confirmedLines: Array<{
    line_id: string;
    delivered_packs: number;
    storage_location: StorageLocation;
    recorded_expiry_date?: string | null;
  }>
): ParentCheckout {
  ensureSeeded(db);
  const orderRow = db
    .prepare('SELECT * FROM merchant_orders WHERE id = ?')
    .get(orderId) as Record<string, unknown> | undefined;
  if (!orderRow) {
    throw new Error('Merchant order not found');
  }
  if (Boolean(orderRow.delivery_confirmed_into_pantry)) {
    throw new Error('Delivery has already been confirmed into pantry');
  }

  const checkoutId = String(orderRow.parent_checkout_id);
  const now = new Date().toISOString();
  const today = now.slice(0, 10);

  withTransaction(db, () => {
    const lineRows = db
      .prepare('SELECT * FROM order_line_items WHERE order_id = ?')
      .all(orderId) as Array<Record<string, unknown>>;

    const confirmedMap = new Map(confirmedLines.map((c) => [c.line_id, c]));
    let anyShort = false;
    let shortRefundMinor = 0;

    for (const lr of lineRows) {
      const lid = String(lr.id);
      const conf = confirmedMap.get(lid);
      const orderedPacks = Number(lr.ordered_packs);
      const deliveredPacks = conf
        ? Math.max(0, Math.min(orderedPacks, conf.delivered_packs))
        : Number(lr.delivered_packs ?? orderedPacks);

      db.prepare('UPDATE order_line_items SET delivered_packs = ? WHERE id = ?').run(
        deliveredPacks,
        lid
      );

      if (deliveredPacks < orderedPacks) {
        anyShort = true;
        // Only compute extra refund if not already refunded in seed
        if (lr.delivered_packs === null) {
          shortRefundMinor +=
            (orderedPacks - deliveredPacks) * Number(lr.unit_price_minor);
        }
      }

      if (deliveredPacks > 0) {
        const totalQty =
          Math.round(deliveredPacks * Number(lr.pack_quantity) * 100) / 100;
        addPantryItem(db, {
          ingredient_id: String(lr.ingredient_id),
          product_name: String(lr.product_title),
          quantity: totalQty,
          unit: String(lr.pack_unit),
          storage_location: conf?.storage_location ?? 'fridge',
          purchase_or_opened_date: today,
          recorded_expiry_date: conf?.recorded_expiry_date ?? null,
          date_marking_type: conf?.recorded_expiry_date
            ? 'best_before'
            : 'user_estimate',
          source_action: 'delivery_confirmed',
          note: `Confirmed delivery from ${String(orderRow.merchant_name)} (${deliveredPacks}/${orderedPacks} packs)`,
        });
      }
    }

    db.prepare(
      `UPDATE merchant_orders SET
        status = ?,
        delivery_confirmed_into_pantry = 1,
        refunded_minor = refunded_minor + ?
       WHERE id = ?`
    ).run(
      anyShort ? 'partially_fulfilled' : 'delivered',
      shortRefundMinor,
      orderId
    );

    if (shortRefundMinor > 0) {
      db.prepare(
        `UPDATE parent_checkouts SET total_refunded_minor = total_refunded_minor + ? WHERE id = ?`
      ).run(shortRefundMinor, checkoutId);
      db.prepare(
        `INSERT INTO payment_ledger (
          id, parent_checkout_id, merchant_order_id, entry_type, amount_minor, currency, status, note, created_at
        ) VALUES (?, ?, ?, 'refund', ?, 'GBP', 'recorded', ?, ?)`
      ).run(
        `led_${Date.now()}_short`,
        checkoutId,
        orderId,
        shortRefundMinor,
        `Short-delivery adjustment refund for ${String(orderRow.merchant_name)}`,
        now
      );
    }
  });

  return getCheckoutById(db, checkoutId)!;
}
