import {getDb} from './db';
import {getHouseholdContext} from './modules/identity';
import {listIngredientIdentities, listRecipes} from './modules/recipes';
import {getPlanningState} from './modules/planning';
import {
  getExpiringSoonItems,
  listPantryItems,
  listPantryTransactions,
} from './modules/pantry';
import {listMerchantProducts, listMerchants} from './modules/catalogue';
import {
  compareAllBasketStrategies,
  getShoppingConfig,
} from './modules/basket';
import {listCheckouts} from './modules/orders';
import {listVisibleDiaryEntries} from './modules/diary';

export function loadWorkspaceSnapshot() {
  const db = getDb();
  const identity = getHouseholdContext(db);
  const ingredients = listIngredientIdentities(db);
  const recipes = listRecipes(db);
  const planning = getPlanningState(db);
  const pantry = listPantryItems(db);
  const pantry_transactions = listPantryTransactions(db);
  const expiring_soon = getExpiringSoonItems(db);
  const merchants = listMerchants(db);
  const products = listMerchantProducts(db);
  const shopping_config = getShoppingConfig(db);
  const basket_separate = compareAllBasketStrategies(db, 'separate');
  const basket_consolidated = compareAllBasketStrategies(db, 'consolidated');
  const checkouts = listCheckouts(db);
  const diary = listVisibleDiaryEntries(db, identity.active_member_id);

  return {
    identity,
    ingredients,
    recipes,
    planning,
    pantry,
    pantry_transactions,
    expiring_soon,
    merchants,
    products,
    shopping_config,
    requirements: basket_separate.requirements,
    basket_comparisons: {
      separate: basket_separate.comparisons,
      consolidated: basket_consolidated.comparisons,
    },
    checkouts,
    diary,
  };
}
