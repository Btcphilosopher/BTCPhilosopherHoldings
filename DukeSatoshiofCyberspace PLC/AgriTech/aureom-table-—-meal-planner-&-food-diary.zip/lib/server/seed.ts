import {DatabaseSync} from 'node:sqlite';
import {withTransaction} from './db';

export const HOUSEHOLD_ID = 'hh_lin_mercer';
export const MEMBER_MAYA_ID = 'mem_maya';
export const MEMBER_OWEN_ID = 'mem_owen';
export const CURRENT_WEEK_ID = 'week_2026_11_23';

export function ensureSeeded(db: DatabaseSync): void {
  const existing = db
    .prepare('SELECT id FROM households WHERE id = ?')
    .get(HOUSEHOLD_ID);
  if (existing) {
    return;
  }
  seedAll(db);
}

export function resetAndSeed(db: DatabaseSync): void {
  withTransaction(db, () => {
    db.exec(`
      DELETE FROM food_diary_entries;
      DELETE FROM webhook_events;
      DELETE FROM payment_ledger;
      DELETE FROM order_line_items;
      DELETE FROM merchant_orders;
      DELETE FROM parent_checkouts;
      DELETE FROM merchant_products;
      DELETE FROM merchants;
      DELETE FROM pantry_reservations;
      DELETE FROM pantry_transactions;
      DELETE FROM pantry_items;
      DELETE FROM planned_meals;
      DELETE FROM meal_plan_weeks;
      DELETE FROM recipe_ingredients;
      DELETE FROM recipes;
      DELETE FROM ingredient_identities;
      DELETE FROM shopping_config;
      DELETE FROM household_members;
      DELETE FROM households;
    `);
  });
  seedAll(db);
}

function seedAll(db: DatabaseSync): void {
  withTransaction(db, () => {
    const now = '2026-11-22T23:00:00.000Z';

    // 1. Household & Members
    db.prepare(
      `INSERT INTO households (
        id, name, address_line1, city, postcode, currency, weekly_budget_minor,
        preferred_merchant_ids_json, default_fulfilment_model,
        share_delivery_details_with_merchants, track_calories_in_diary,
        notification_prefs_json, active_member_id, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      HOUSEHOLD_ID,
      'Lin-Mercer Kitchen',
      '42 St Giles Crescent',
      'Oxford',
      'OX2 6JL',
      'GBP',
      9500,
      JSON.stringify(['mer_meadowbrook', 'mer_hearthstone']),
      'separate',
      1,
      1,
      JSON.stringify({
        expiry_reminders: true,
        delivery_updates: true,
        substitution_alerts: true,
      }),
      MEMBER_MAYA_ID,
      now
    );

    const insertMember = db.prepare(
      `INSERT INTO household_members (
        id, household_id, name, role, dietary_preferences_json, dislikes_json,
        excluded_ingredients_json, allergens_json, portion_multiplier, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );

    insertMember.run(
      MEMBER_MAYA_ID,
      HOUSEHOLD_ID,
      'Maya Lin',
      'admin',
      JSON.stringify(['whole-foods', 'mediterranean']),
      JSON.stringify(['celery']),
      JSON.stringify(['peanuts', 'shellfish']),
      JSON.stringify(['peanuts', 'crustaceans']),
      1.0,
      now
    );

    insertMember.run(
      MEMBER_OWEN_ID,
      HOUSEHOLD_ID,
      'Owen Mercer',
      'adult',
      JSON.stringify(['high-protein']),
      JSON.stringify(['coriander', 'olives']),
      JSON.stringify([]),
      JSON.stringify([]),
      1.0,
      now
    );

    db.prepare(
      `INSERT INTO shopping_config (
        household_id, include_optional, include_garnish, include_pantry_staples, locked_assignments_json
      ) VALUES (?, ?, ?, ?, ?)`
    ).run(HOUSEHOLD_ID, 0, 1, 0, JSON.stringify({}));

    // 2. Canonical Ingredient Identities (separated from merchant products)
    const ingredients: Array<{
      id: string;
      name: string;
      form: string;
      unit: string;
      staple: number;
      conv?: {from_unit: string; to_unit: string; factor: number; source: string};
    }> = [
      {id: 'ing_chicken_thighs', name: 'Chicken Thighs', form: 'bone-in skin-on', unit: 'g', staple: 0},
      {id: 'ing_orzo', name: 'Orzo Pasta', form: 'dried', unit: 'g', staple: 0},
      {
        id: 'ing_olive_oil',
        name: 'Extra Virgin Olive Oil',
        form: 'cold-pressed',
        unit: 'ml',
        staple: 1,
        conv: {from_unit: 'tbsp', to_unit: 'ml', factor: 15, source: 'UK culinary standard 1 tbsp = 15 ml'},
      },
      {id: 'ing_garlic', name: 'Garlic', form: 'fresh cloves', unit: 'clove', staple: 0},
      {id: 'ing_yellow_onion', name: 'Yellow Onion', form: 'whole medium', unit: 'count', staple: 0},
      {id: 'ing_thyme', name: 'Fresh Thyme', form: 'sprigs / leaves', unit: 'g', staple: 0},
      {id: 'ing_lemon', name: 'Unwaxed Lemon', form: 'whole', unit: 'count', staple: 0},
      {id: 'ing_chopped_tomatoes', name: 'Chopped Tomatoes', form: 'tinned in juice', unit: 'g', staple: 0},
      {id: 'ing_red_lentils', name: 'Red Split Lentils', form: 'dried', unit: 'g', staple: 0},
      {id: 'ing_rigatoni', name: 'Rigatoni Pasta', form: 'dried bronze-die', unit: 'g', staple: 0},
      {id: 'ing_pecorino', name: 'Aged Pecorino', form: 'wedge', unit: 'g', staple: 0},
      {id: 'ing_basil', name: 'Fresh Sweet Basil', form: 'leaves', unit: 'g', staple: 0},
      {id: 'ing_salmon_fillet', name: 'Atlantic Salmon Fillets', form: 'skin-on fillets', unit: 'g', staple: 0},
      {id: 'ing_white_miso', name: 'White Miso Paste', form: 'sweet fermented', unit: 'g', staple: 0},
      {id: 'ing_broccolini', name: 'Tenderstem Broccolini', form: 'fresh stems', unit: 'g', staple: 0},
      {id: 'ing_jasmine_rice', name: 'Jasmine Rice', form: 'dried long-grain', unit: 'g', staple: 0},
      {id: 'ing_chestnut_mushrooms', name: 'Chestnut Mushrooms', form: 'fresh whole', unit: 'g', staple: 0},
      {id: 'ing_arborio_rice', name: 'Arborio Risotto Rice', form: 'dried', unit: 'g', staple: 0},
      {id: 'ing_veg_stock', name: 'Vegetable Stock', form: 'liquid low-salt', unit: 'ml', staple: 1},
      {id: 'ing_sage', name: 'Fresh Sage', form: 'leaves', unit: 'g', staple: 0},
      {id: 'ing_cauliflower', name: 'Cauliflower', form: 'whole head', unit: 'count', staple: 0},
      {id: 'ing_chickpeas', name: 'Chickpeas', form: 'tinned in water (drained)', unit: 'g', staple: 0},
      {id: 'ing_tahini', name: 'Roasted Sesame Tahini', form: 'smooth paste', unit: 'g', staple: 0},
      {id: 'ing_parsley', name: 'Flat-Leaf Parsley', form: 'fresh bunch', unit: 'g', staple: 0},
      {id: 'ing_sourdough', name: 'Country Sourdough Boule', form: 'sliced or whole loaf', unit: 'loaf', staple: 0},
      {id: 'ing_pork_sausage', name: 'Pork & Herb Sausages', form: 'fresh links', unit: 'g', staple: 0},
    ];

    const insertIng = db.prepare(
      `INSERT INTO ingredient_identities (
        id, canonical_name, form_variety, default_unit, is_pantry_staple, documented_conversion_json
      ) VALUES (?, ?, ?, ?, ?, ?)`
    );
    for (const ing of ingredients) {
      insertIng.run(
        ing.id,
        ing.name,
        ing.form,
        ing.unit,
        ing.staple,
        ing.conv ? JSON.stringify(ing.conv) : null
      );
    }

    // 3. Recipes (rich metadata, documented image sources, nutrition + allergen provenance)
    const recipesData = [
      {
        id: 'rec_herb_chicken_orzo',
        title: 'Skillet Herb Chicken & Lemon Orzo',
        description:
          'Crisp bone-in chicken thighs braised over toasted garlic orzo with charred lemon, fresh thyme, and spinach.',
        image_url: '/images/recipe_herb_chicken_orzo.jpg',
        image_source: 'Aureom Studio Culinary Archive · Local Asset (recipe_herb_chicken_orzo.jpg)',
        servings: 4,
        prep_minutes: 15,
        cook_minutes: 30,
        instructions: [
          'Season chicken thighs with sea salt and black pepper. Sear skin-side down in olive oil for 7 minutes until deep golden.',
          'Remove chicken briefly; sauté diced yellow onion and crushed garlic cloves in the rendered pan juices.',
          'Stir in dried orzo, fresh thyme sprigs, and stock or water; nestle chicken back in and simmer covered for 16 minutes.',
          'Finish with halved charred lemon juice and fold through grated pecorino.',
        ],
        dietary_tags: ['High-Protein', 'Nut-Free'],
        allergens: ['gluten', 'dairy'],
        allergen_provenance: 'Derived from orzo wheat pasta (gluten) and optional pecorino (dairy).',
        nutrition: {
          kcal: 540,
          protein_g: 36,
          carbs_g: 44,
          fat_g: 23,
          source: 'McCance & Widdowson UK Food Composition Estimate (unverified home prep)',
          is_verified: false,
        },
        storage_notes: 'Cool within 90 minutes and refrigerate in a sealed container up to 3 days.',
        leftover_notes: 'Reheats well with 2 tbsp water; ideal for Tuesday lunch boxes.',
        ingredients: [
          {id: 'ri_1', ing: 'ing_chicken_thighs', name: 'Chicken Thighs', form: 'bone-in skin-on', qty: 600, unit: 'g', opt: 0, gar: 0, stp: 0},
          {id: 'ri_2', ing: 'ing_orzo', name: 'Orzo Pasta', form: 'dried', qty: 300, unit: 'g', opt: 0, gar: 0, stp: 0},
          {id: 'ri_3', ing: 'ing_yellow_onion', name: 'Yellow Onion', form: 'whole medium', qty: 1, unit: 'count', opt: 0, gar: 0, stp: 0},
          {id: 'ri_4', ing: 'ing_garlic', name: 'Garlic', form: 'fresh cloves', qty: 3, unit: 'clove', opt: 0, gar: 0, stp: 0},
          {id: 'ri_5', ing: 'ing_thyme', name: 'Fresh Thyme', form: 'sprigs / leaves', qty: 10, unit: 'g', opt: 0, gar: 0, stp: 0},
          {id: 'ri_6', ing: 'ing_lemon', name: 'Unwaxed Lemon', form: 'whole', qty: 1, unit: 'count', opt: 0, gar: 0, stp: 0},
          {id: 'ri_7', ing: 'ing_olive_oil', name: 'Extra Virgin Olive Oil', form: 'cold-pressed', qty: 30, unit: 'ml', opt: 0, gar: 0, stp: 1},
          {id: 'ri_8', ing: 'ing_pecorino', name: 'Aged Pecorino', form: 'wedge', qty: 40, unit: 'g', opt: 1, gar: 1, stp: 0},
        ],
      },
      {
        id: 'rec_tomato_lentil_ragu',
        title: 'Roasted Tomato & Red Lentil Ragu',
        description:
          'Slow-simmered tinned chopped tomatoes and red split lentils tossed with bronze-die rigatoni and torn sweet basil.',
        image_url: '/images/recipe_tomato_lentil_ragu.jpg',
        image_source: 'Aureom Studio Culinary Archive · Local Asset (recipe_tomato_lentil_ragu.jpg)',
        servings: 4,
        prep_minutes: 10,
        cook_minutes: 30,
        instructions: [
          'Soften diced yellow onion and sliced garlic cloves in extra virgin olive oil for 6 minutes.',
          'Add rinsed red split lentils, tinned chopped tomatoes, and 250 ml water; simmer gently for 20 minutes until thick.',
          'Boil rigatoni until al dente, reserve a splash of pasta water, and toss into the ragu.',
          'Serve topped with torn sweet basil and shaved pecorino.',
        ],
        dietary_tags: ['Vegetarian', 'High-Fibre', 'Nut-Free'],
        allergens: ['gluten', 'dairy'],
        allergen_provenance: 'Wheat rigatoni (gluten); pecorino garnish (dairy, omit for vegan).',
        nutrition: {
          kcal: 495,
          protein_g: 22,
          carbs_g: 74,
          fat_g: 11,
          source: 'UK CoFID Estimated Recipe Breakdown',
          is_verified: false,
        },
        storage_notes: 'Keeps refrigerated for 4 days or freezes up to 2 months.',
        leftover_notes: 'Sauce thickens overnight; loosen with warm water when reheating.',
        ingredients: [
          {id: 'ri_9', ing: 'ing_chopped_tomatoes', name: 'Chopped Tomatoes', form: 'tinned in juice', qty: 800, unit: 'g', opt: 0, gar: 0, stp: 0},
          {id: 'ri_10', ing: 'ing_red_lentils', name: 'Red Split Lentils', form: 'dried', qty: 200, unit: 'g', opt: 0, gar: 0, stp: 0},
          {id: 'ri_11', ing: 'ing_rigatoni', name: 'Rigatoni Pasta', form: 'dried bronze-die', qty: 400, unit: 'g', opt: 0, gar: 0, stp: 0},
          {id: 'ri_12', ing: 'ing_yellow_onion', name: 'Yellow Onion', form: 'whole medium', qty: 1, unit: 'count', opt: 0, gar: 0, stp: 0},
          {id: 'ri_13', ing: 'ing_garlic', name: 'Garlic', form: 'fresh cloves', qty: 3, unit: 'clove', opt: 0, gar: 0, stp: 0},
          {id: 'ri_14', ing: 'ing_olive_oil', name: 'Extra Virgin Olive Oil', form: 'cold-pressed', qty: 30, unit: 'ml', opt: 0, gar: 0, stp: 1},
          {id: 'ri_15', ing: 'ing_basil', name: 'Fresh Sweet Basil', form: 'leaves', qty: 15, unit: 'g', opt: 0, gar: 1, stp: 0},
          {id: 'ri_16', ing: 'ing_pecorino', name: 'Aged Pecorino', form: 'wedge', qty: 60, unit: 'g', opt: 0, gar: 1, stp: 0},
        ],
      },
      {
        id: 'rec_miso_salmon_greens',
        title: 'Miso-Glazed Salmon & Charred Broccolini',
        description:
          'Umami sweet white miso glaze caramelised under the grill on Atlantic salmon fillets with sesame broccolini and jasmine rice.',
        image_url: '/images/recipe_miso_salmon_greens.jpg',
        image_source: 'Aureom Studio Culinary Archive · Local Asset (recipe_miso_salmon_greens.jpg)',
        servings: 2,
        prep_minutes: 10,
        cook_minutes: 15,
        instructions: [
          'Rinse jasmine rice and steam gently for 12 minutes.',
          'Whisk white miso paste with 1 tbsp warm water and grated garlic; brush over salmon fillets.',
          'Roast salmon and olive-oil tossed broccolini at 210°C for 11 minutes until glazed and tender.',
        ],
        dietary_tags: ['Pescatarian', 'Dairy-Free', 'Gluten-Free'],
        allergens: ['fish', 'soy'],
        allergen_provenance: 'Atlantic salmon (fish); fermented white miso paste (soy).',
        nutrition: {
          kcal: 590,
          protein_g: 39,
          carbs_g: 52,
          fat_g: 24,
          source: 'Estimated from standard UK salmon & steamed rice values',
          is_verified: false,
        },
        storage_notes: 'Best eaten fresh; cooked salmon keeps 2 days chilled.',
        leftover_notes: 'Flake cold leftover salmon into grain bowls.',
        ingredients: [
          {id: 'ri_17', ing: 'ing_salmon_fillet', name: 'Atlantic Salmon Fillets', form: 'skin-on fillets', qty: 300, unit: 'g', opt: 0, gar: 0, stp: 0},
          {id: 'ri_18', ing: 'ing_white_miso', name: 'White Miso Paste', form: 'sweet fermented', qty: 45, unit: 'g', opt: 0, gar: 0, stp: 0},
          {id: 'ri_19', ing: 'ing_broccolini', name: 'Tenderstem Broccolini', form: 'fresh stems', qty: 200, unit: 'g', opt: 0, gar: 0, stp: 0},
          {id: 'ri_20', ing: 'ing_jasmine_rice', name: 'Jasmine Rice', form: 'dried long-grain', qty: 180, unit: 'g', opt: 0, gar: 0, stp: 0},
          {id: 'ri_21', ing: 'ing_garlic', name: 'Garlic', form: 'fresh cloves', qty: 2, unit: 'clove', opt: 0, gar: 0, stp: 0},
          {id: 'ri_22', ing: 'ing_olive_oil', name: 'Extra Virgin Olive Oil', form: 'cold-pressed', qty: 15, unit: 'ml', opt: 0, gar: 0, stp: 1},
        ],
      },
      {
        id: 'rec_mushroom_risotto',
        title: 'Wild Chestnut Mushroom & Thyme Risotto',
        description:
          'Velvety Arborio risotto folded with roasted chestnut mushrooms, fresh thyme, crispy sage, and aged pecorino.',
        image_url: '/images/recipe_mushroom_risotto.jpg',
        image_source: 'Aureom Studio Culinary Archive · Local Asset (recipe_mushroom_risotto.jpg)',
        servings: 3,
        prep_minutes: 15,
        cook_minutes: 25,
        instructions: [
          'Roast or pan-brown sliced chestnut mushrooms with thyme and olive oil until nutty.',
          'Sweat finely diced yellow onion and garlic; toast Arborio rice for 2 minutes.',
          'Ladle in warm vegetable stock gradually over 18 minutes, stirring gently.',
          'Fold through mushrooms, pecorino, and crisp fried sage leaves.',
        ],
        dietary_tags: ['Vegetarian', 'Gluten-Free'],
        allergens: ['dairy'],
        allergen_provenance: 'Pecorino cheese (dairy). Check stock cube/liquid label for celery.',
        nutrition: {
          kcal: 515,
          protein_g: 16,
          carbs_g: 68,
          fat_g: 17,
          source: 'Estimated culinary composition',
          is_verified: false,
        },
        storage_notes: 'Chill quickly; keeps 2 days.',
        leftover_notes: 'Great shaped into pan-seared risotto cakes.',
        ingredients: [
          {id: 'ri_23', ing: 'ing_chestnut_mushrooms', name: 'Chestnut Mushrooms', form: 'fresh whole', qty: 300, unit: 'g', opt: 0, gar: 0, stp: 0},
          {id: 'ri_24', ing: 'ing_arborio_rice', name: 'Arborio Risotto Rice', form: 'dried', qty: 270, unit: 'g', opt: 0, gar: 0, stp: 0},
          {id: 'ri_25', ing: 'ing_yellow_onion', name: 'Yellow Onion', form: 'whole medium', qty: 1, unit: 'count', opt: 0, gar: 0, stp: 0},
          {id: 'ri_26', ing: 'ing_garlic', name: 'Garlic', form: 'fresh cloves', qty: 2, unit: 'clove', opt: 0, gar: 0, stp: 0},
          {id: 'ri_27', ing: 'ing_thyme', name: 'Fresh Thyme', form: 'sprigs / leaves', qty: 8, unit: 'g', opt: 0, gar: 0, stp: 0},
          {id: 'ri_28', ing: 'ing_sage', name: 'Fresh Sage', form: 'leaves', qty: 10, unit: 'g', opt: 1, gar: 1, stp: 0},
          {id: 'ri_29', ing: 'ing_veg_stock', name: 'Vegetable Stock', form: 'liquid low-salt', qty: 900, unit: 'ml', opt: 0, gar: 0, stp: 1},
          {id: 'ri_30', ing: 'ing_pecorino', name: 'Aged Pecorino', form: 'wedge', qty: 45, unit: 'g', opt: 0, gar: 0, stp: 0},
          {id: 'ri_31', ing: 'ing_olive_oil', name: 'Extra Virgin Olive Oil', form: 'cold-pressed', qty: 30, unit: 'ml', opt: 0, gar: 0, stp: 1},
        ],
      },
      {
        id: 'rec_spiced_cauliflower_bowl',
        title: 'Roasted Cauliflower & Crispy Chickpea Tahini Bowl',
        description:
          'Golden roasted cauliflower florets and spiced chickpeas drizzled with bright lemon-tahini dressing and fresh parsley.',
        image_url: '/images/recipe_spiced_cauliflower_bowl.jpg',
        image_source: 'Aureom Studio Culinary Archive · Local Asset (recipe_spiced_cauliflower_bowl.jpg)',
        servings: 2,
        prep_minutes: 12,
        cook_minutes: 25,
        instructions: [
          'Toss cauliflower florets and drained chickpeas in olive oil, cumin, and sea salt; roast at 220°C for 25 minutes.',
          'Whisk roasted sesame tahini with lemon juice, minced garlic, and cold water until silky.',
          'Plate warm and top with chopped flat-leaf parsley.',
        ],
        dietary_tags: ['Vegan', 'Dairy-Free', 'Gluten-Free'],
        allergens: ['sesame'],
        allergen_provenance: 'Contains sesame from tahini paste.',
        nutrition: {
          kcal: 470,
          protein_g: 17,
          carbs_g: 42,
          fat_g: 25,
          source: 'Estimated culinary composition',
          is_verified: false,
        },
        storage_notes: 'Keep dressing separate; roasted florets keep 3 days.',
        leftover_notes: 'Delicious cold or tucked into warm flatbread.',
        ingredients: [
          {id: 'ri_32', ing: 'ing_cauliflower', name: 'Cauliflower', form: 'whole head', qty: 1, unit: 'count', opt: 0, gar: 0, stp: 0},
          {id: 'ri_33', ing: 'ing_chickpeas', name: 'Chickpeas', form: 'tinned in water (drained)', qty: 240, unit: 'g', opt: 0, gar: 0, stp: 0},
          {id: 'ri_34', ing: 'ing_tahini', name: 'Roasted Sesame Tahini', form: 'smooth paste', qty: 50, unit: 'g', opt: 0, gar: 0, stp: 0},
          {id: 'ri_35', ing: 'ing_lemon', name: 'Unwaxed Lemon', form: 'whole', qty: 1, unit: 'count', opt: 0, gar: 0, stp: 0},
          {id: 'ri_36', ing: 'ing_garlic', name: 'Garlic', form: 'fresh cloves', qty: 1, unit: 'clove', opt: 0, gar: 0, stp: 0},
          {id: 'ri_37', ing: 'ing_parsley', name: 'Flat-Leaf Parsley', form: 'fresh bunch', qty: 15, unit: 'g', opt: 0, gar: 1, stp: 0},
          {id: 'ri_38', ing: 'ing_olive_oil', name: 'Extra Virgin Olive Oil', form: 'cold-pressed', qty: 30, unit: 'ml', opt: 0, gar: 0, stp: 1},
        ],
      },
      {
        id: 'rec_tomato_lentil_sourdough',
        title: 'Smoky Tomato Lentil Pot with Charred Sourdough',
        description:
          'Hearty one-pot red lentil and chopped tomato stew finished with lemon zest and served alongside toasted country sourdough.',
        image_url: '/images/hero_kitchen_table.jpg',
        image_source: 'Aureom Studio Culinary Archive · Local Asset (hero_kitchen_table.jpg)',
        servings: 2,
        prep_minutes: 10,
        cook_minutes: 25,
        instructions: [
          'Sweat yellow onion and garlic in olive oil.',
          'Simmer red split lentils with chopped tomatoes and vegetable stock for 20 minutes.',
          'Toast thick slices of sourdough drizzled with olive oil and rub with garlic.',
        ],
        dietary_tags: ['Vegan', 'Dairy-Free'],
        allergens: ['gluten'],
        allergen_provenance: 'Wheat country sourdough loaf (gluten).',
        nutrition: {
          kcal: 440,
          protein_g: 18,
          carbs_g: 64,
          fat_g: 10,
          source: 'Estimated culinary composition',
          is_verified: false,
        },
        storage_notes: 'Soup freezes brilliantly for 3 months.',
        leftover_notes: 'Sourdough best toasted fresh.',
        ingredients: [
          {id: 'ri_39', ing: 'ing_chopped_tomatoes', name: 'Chopped Tomatoes', form: 'tinned in juice', qty: 400, unit: 'g', opt: 0, gar: 0, stp: 0},
          {id: 'ri_40', ing: 'ing_red_lentils', name: 'Red Split Lentils', form: 'dried', qty: 150, unit: 'g', opt: 0, gar: 0, stp: 0},
          {id: 'ri_41', ing: 'ing_yellow_onion', name: 'Yellow Onion', form: 'whole medium', qty: 1, unit: 'count', opt: 0, gar: 0, stp: 0},
          {id: 'ri_42', ing: 'ing_garlic', name: 'Garlic', form: 'fresh cloves', qty: 2, unit: 'clove', opt: 0, gar: 0, stp: 0},
          {id: 'ri_43', ing: 'ing_sourdough', name: 'Country Sourdough Boule', form: 'sliced or whole loaf', qty: 0.5, unit: 'loaf', opt: 0, gar: 0, stp: 0},
          {id: 'ri_44', ing: 'ing_veg_stock', name: 'Vegetable Stock', form: 'liquid low-salt', qty: 400, unit: 'ml', opt: 0, gar: 0, stp: 1},
        ],
      },
    ];

    const insertRecipe = db.prepare(
      `INSERT INTO recipes (
        id, title, description, image_url, image_source, servings,
        prep_minutes, cook_minutes, instructions_json, dietary_tags_json,
        allergens_json, allergen_provenance, nutrition_json, storage_notes, leftover_notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    const insertRecIng = db.prepare(
      `INSERT INTO recipe_ingredients (
        id, recipe_id, ingredient_id, display_name, form_variety, quantity, unit,
        is_optional, is_garnish, is_pantry_staple, documented_conversion_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );

    for (const r of recipesData) {
      insertRecipe.run(
        r.id,
        r.title,
        r.description,
        r.image_url,
        r.image_source,
        r.servings,
        r.prep_minutes,
        r.cook_minutes,
        JSON.stringify(r.instructions),
        JSON.stringify(r.dietary_tags),
        JSON.stringify(r.allergens),
        r.allergen_provenance,
        JSON.stringify(r.nutrition),
        r.storage_notes,
        r.leftover_notes
      );
      for (const ing of r.ingredients) {
        insertRecIng.run(
          ing.id,
          r.id,
          ing.ing,
          ing.name,
          ing.form,
          ing.qty,
          ing.unit,
          ing.opt,
          ing.gar,
          ing.stp,
          null
        );
      }
    }

    // 4. Meal Plan Week (Mon Nov 23 – Sun Nov 29, 2026) + 1 Reusable Template
    db.prepare(
      `INSERT INTO meal_plan_weeks (
        id, household_id, week_start_date, title, weekly_budget_minor, is_template, shared_with_household, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      CURRENT_WEEK_ID,
      HOUSEHOLD_ID,
      '2026-11-23',
      'Late November Autumn Table',
      9500,
      0,
      1,
      now
    );

    db.prepare(
      `INSERT INTO meal_plan_weeks (
        id, household_id, week_start_date, title, weekly_budget_minor, is_template, shared_with_household, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      'week_template_weeknight',
      HOUSEHOLD_ID,
      '2026-11-16',
      'Quick 30-Minute Weeknights (Saved Template)',
      8500,
      1,
      1,
      now
    );

    const plannedMeals = [
      {
        id: 'pm_mon_din',
        week_id: CURRENT_WEEK_ID,
        date: '2026-11-23',
        slot: 'dinner',
        kind: 'recipe',
        recipe_id: 'rec_herb_chicken_orzo',
        title: 'Skillet Herb Chicken & Lemon Orzo',
        servings: 4,
        members: [MEMBER_MAYA_ID, MEMBER_OWEN_ID],
        leftover_source: null,
        leftover_yield: 2,
        status: 'planned',
        notes: 'Cook 4 portions so 2 portions become Tuesday lunch.',
        prep: 15,
        cook: 30,
        orders: ['ord_seed_partial_01'],
      },
      {
        id: 'pm_tue_lun',
        week_id: CURRENT_WEEK_ID,
        date: '2026-11-24',
        slot: 'lunch',
        kind: 'leftover',
        recipe_id: null,
        title: 'Leftover Herb Chicken & Lemon Orzo',
        servings: 2,
        members: [MEMBER_MAYA_ID, MEMBER_OWEN_ID],
        leftover_source: 'pm_mon_din',
        leftover_yield: 0,
        status: 'planned',
        notes: 'Uses 2 portions yielded from Monday dinner (zero extra shopping).',
        prep: 0,
        cook: 5,
        orders: [],
      },
      {
        id: 'pm_tue_din',
        week_id: CURRENT_WEEK_ID,
        date: '2026-11-24',
        slot: 'dinner',
        kind: 'recipe',
        recipe_id: 'rec_tomato_lentil_ragu',
        title: 'Roasted Tomato & Red Lentil Ragu',
        servings: 4,
        members: [MEMBER_MAYA_ID, MEMBER_OWEN_ID],
        leftover_source: null,
        leftover_yield: 0,
        status: 'planned',
        notes: 'Extra servings for midweek flexibility.',
        prep: 10,
        cook: 30,
        orders: [],
      },
      {
        id: 'pm_wed_din',
        week_id: CURRENT_WEEK_ID,
        date: '2026-11-25',
        slot: 'dinner',
        kind: 'recipe',
        recipe_id: 'rec_miso_salmon_greens',
        title: 'Miso-Glazed Salmon & Charred Broccolini',
        servings: 2,
        members: [MEMBER_MAYA_ID, MEMBER_OWEN_ID],
        leftover_source: null,
        leftover_yield: 0,
        status: 'planned',
        notes: 'Quick midweek omega-rich dinner.',
        prep: 10,
        cook: 15,
        orders: [],
      },
      {
        id: 'pm_thu_din',
        week_id: CURRENT_WEEK_ID,
        date: '2026-11-26',
        slot: 'dinner',
        kind: 'recipe',
        recipe_id: 'rec_mushroom_risotto',
        title: 'Wild Chestnut Mushroom & Thyme Risotto',
        servings: 3,
        members: [MEMBER_MAYA_ID, MEMBER_OWEN_ID],
        leftover_source: null,
        leftover_yield: 1,
        status: 'planned',
        notes: 'Use fresh thyme from fridge before expiry.',
        prep: 15,
        cook: 25,
        orders: [],
      },
      {
        id: 'pm_fri_din_maya',
        week_id: CURRENT_WEEK_ID,
        date: '2026-11-27',
        slot: 'dinner',
        kind: 'recipe',
        recipe_id: 'rec_spiced_cauliflower_bowl',
        title: 'Roasted Cauliflower & Crispy Chickpea Tahini Bowl',
        servings: 2,
        members: [MEMBER_MAYA_ID],
        leftover_source: null,
        leftover_yield: 0,
        status: 'planned',
        notes: 'Split dinner: Maya prefers plant-based tahini bowl.',
        prep: 12,
        cook: 25,
        orders: [],
      },
      {
        id: 'pm_fri_din_owen',
        week_id: CURRENT_WEEK_ID,
        date: '2026-11-27',
        slot: 'dinner',
        kind: 'simple',
        recipe_id: null,
        title: 'Grilled Chicken & Warm Sourdough Toast (Owen)',
        servings: 1,
        members: [MEMBER_OWEN_ID],
        leftover_source: null,
        leftover_yield: 0,
        status: 'planned',
        notes: 'Simple non-recipe meal for Owen on split dinner night.',
        prep: 5,
        cook: 15,
        orders: [],
      },
      {
        id: 'pm_sat_din',
        week_id: CURRENT_WEEK_ID,
        date: '2026-11-28',
        slot: 'dinner',
        kind: 'recipe',
        recipe_id: 'rec_tomato_lentil_sourdough',
        title: 'Smoky Tomato Lentil Pot with Charred Sourdough',
        servings: 2,
        members: [MEMBER_MAYA_ID, MEMBER_OWEN_ID],
        leftover_source: null,
        leftover_yield: 0,
        status: 'planned',
        notes: 'Cosy Saturday supper.',
        prep: 10,
        cook: 25,
        orders: [],
      },
      {
        id: 'pm_sun_din',
        week_id: CURRENT_WEEK_ID,
        date: '2026-11-29',
        slot: 'dinner',
        kind: 'eating_out',
        recipe_id: null,
        title: 'Sunday Supper at Jericho Bistro',
        servings: 2,
        members: [MEMBER_MAYA_ID, MEMBER_OWEN_ID],
        leftover_source: null,
        leftover_yield: 0,
        status: 'planned',
        notes: 'Eating out — excluded from shopping aggregation.',
        prep: 0,
        cook: 0,
        orders: [],
      },
    ];

    const insertMeal = db.prepare(
      `INSERT INTO planned_meals (
        id, week_id, household_id, date, slot, kind, recipe_id, title, servings,
        assigned_member_ids_json, leftover_source_meal_id, leftover_portions_yielded,
        status, notes, prep_minutes, cook_minutes, linked_order_ids_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    for (const pm of plannedMeals) {
      insertMeal.run(
        pm.id,
        pm.week_id,
        HOUSEHOLD_ID,
        pm.date,
        pm.slot,
        pm.kind,
        pm.recipe_id,
        pm.title,
        pm.servings,
        JSON.stringify(pm.members),
        pm.leftover_source,
        pm.leftover_yield,
        pm.status,
        pm.notes,
        pm.prep,
        pm.cook,
        JSON.stringify(pm.orders)
      );
    }

    // 5. Pantry Stock (with approaching expiry dates)
    const pantryItems = [
      {
        id: 'pan_olive_oil',
        ing: 'ing_olive_oil',
        name: 'Cotswold Cold-Pressed Extra Virgin Olive Oil (500 ml)',
        barcode: '5010029001001',
        qty: 500,
        unit: 'ml',
        loc: 'cupboard',
        opened: '2026-10-12',
        expiry: '2027-06-01',
        marking: 'best_before',
      },
      {
        id: 'pan_onion',
        ing: 'ing_yellow_onion',
        name: 'Meadowbrook Yellow Onions',
        barcode: null,
        qty: 2,
        unit: 'count',
        loc: 'cupboard',
        opened: '2026-11-18',
        expiry: '2026-11-29',
        marking: 'best_before',
      },
      {
        id: 'pan_tomatoes',
        ing: 'ing_chopped_tomatoes',
        name: 'Mutti Polpa Chopped Tomatoes (400 g tin)',
        barcode: '5010029001123',
        qty: 400,
        unit: 'g',
        loc: 'cupboard',
        opened: '2026-10-05',
        expiry: '2027-08-01',
        marking: 'best_before',
      },
      {
        id: 'pan_thyme',
        ing: 'ing_thyme',
        name: 'Fresh Garden Thyme Bunch',
        barcode: null,
        qty: 15,
        unit: 'g',
        loc: 'fridge',
        opened: '2026-11-19',
        expiry: '2026-11-24',
        marking: 'use_by',
      },
      {
        id: 'pan_sourdough',
        ing: 'ing_sourdough',
        name: 'Hearthstone Country Sourdough Boule',
        barcode: '5010029004411',
        qty: 1,
        unit: 'loaf',
        loc: 'cupboard',
        opened: '2026-11-20',
        expiry: '2026-11-24',
        marking: 'best_before',
      },
      {
        id: 'pan_arborio',
        ing: 'ing_arborio_rice',
        name: 'Riso Gallo Arborio Risotto Rice (500 g)',
        barcode: '8001420001122',
        qty: 500,
        unit: 'g',
        loc: 'cupboard',
        opened: '2026-09-14',
        expiry: '2027-03-15',
        marking: 'best_before',
      },
    ];

    const insertPantry = db.prepare(
      `INSERT INTO pantry_items (
        id, household_id, ingredient_id, product_name, barcode, quantity, unit,
        storage_location, purchase_or_opened_date, recorded_expiry_date,
        date_marking_type, reserved_quantity, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    const insertPantryTx = db.prepare(
      `INSERT INTO pantry_transactions (
        id, household_id, pantry_item_id, action, quantity_delta, unit, note, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    );

    for (const p of pantryItems) {
      insertPantry.run(
        p.id,
        HOUSEHOLD_ID,
        p.ing,
        p.name,
        p.barcode,
        p.qty,
        p.unit,
        p.loc,
        p.opened,
        p.expiry,
        p.marking,
        0,
        now
      );
      insertPantryTx.run(
        `ptx_seed_${p.id}`,
        HOUSEHOLD_ID,
        p.id,
        'manual_add',
        p.qty,
        p.unit,
        'Initial household stock record',
        now
      );
    }

    // 6. Merchants (6 simulated merchants across all requested categories)
    const merchantsData = [
      {
        id: 'mer_cotswold',
        name: 'Cotswold Grocer & Supermarket',
        category: 'supermarket',
        desc: 'Broad everyday grocery range with competitive staple packs.',
        areas: ['OX1', 'OX2', 'OX3', 'OX4'],
        minOrder: 2500,
        fee: 450,
        hub: 1,
        hubPartner: 'Aureom Consolidated Hub',
        hubFee: 550,
        slots: [
          {id: 'slot_cot_1', label: 'Mon 23 Nov · 16:00–18:00', window_start: '2026-11-23T16:00:00Z', window_end: '2026-11-23T18:00:00Z', is_available: true, earliest_rank: 2},
          {id: 'slot_cot_2', label: 'Tue 24 Nov · 09:00–11:00', window_start: '2026-11-24T09:00:00Z', window_end: '2026-11-24T11:00:00Z', is_available: true, earliest_rank: 3},
        ],
      },
      {
        id: 'mer_meadowbrook',
        name: 'Meadowbrook Greengrocer',
        category: 'greengrocer',
        desc: 'Oxfordshire farm produce, herbs, and seasonal vegetables.',
        areas: ['OX1', 'OX2', 'OX3'],
        minOrder: 1500,
        fee: 350,
        hub: 1,
        hubPartner: 'Aureom Consolidated Hub',
        hubFee: 550,
        slots: [
          {id: 'slot_mea_1', label: 'Mon 23 Nov · 11:00–13:00', window_start: '2026-11-23T11:00:00Z', window_end: '2026-11-23T13:00:00Z', is_available: true, earliest_rank: 1},
          {id: 'slot_mea_2', label: 'Tue 24 Nov · 11:00–13:00', window_start: '2026-11-24T11:00:00Z', window_end: '2026-11-24T13:00:00Z', is_available: true, earliest_rank: 4},
        ],
      },
      {
        id: 'mer_alder',
        name: 'Alder & Sons Family Butcher',
        category: 'butcher',
        desc: 'Free-range poultry, dry-aged cuts, and sustainably sourced fish.',
        areas: ['OX1', 'OX2'],
        minOrder: 2000,
        fee: 500,
        hub: 0,
        hubPartner: null,
        hubFee: null,
        slots: [
          {id: 'slot_ald_1', label: 'Mon 23 Nov · 14:00–16:00 (Chilled Van)', window_start: '2026-11-23T14:00:00Z', window_end: '2026-11-23T16:00:00Z', is_available: true, earliest_rank: 2},
          {id: 'slot_ald_2', label: 'Wed 25 Nov · 10:00–12:00 (Chilled Van)', window_start: '2026-11-25T10:00:00Z', window_end: '2026-11-25T12:00:00Z', is_available: true, earliest_rank: 5},
        ],
      },
      {
        id: 'mer_hearthstone',
        name: 'Hearthstone Sourdough Bakery',
        category: 'bakery',
        desc: 'Long-fermented stoneground loaves and morning pastries.',
        areas: ['OX1', 'OX2', 'OX3', 'OX4'],
        minOrder: 1000,
        fee: 250,
        hub: 1,
        hubPartner: 'Aureom Consolidated Hub',
        hubFee: 550,
        slots: [
          {id: 'slot_hea_1', label: 'Mon 23 Nov · 08:00–10:00', window_start: '2026-11-23T08:00:00Z', window_end: '2026-11-23T10:00:00Z', is_available: true, earliest_rank: 1},
        ],
      },
      {
        id: 'mer_umami',
        name: 'Umami & Spice Specialist',
        category: 'specialist',
        desc: 'Fermented pastes, single-origin grains, tahini, and pulses.',
        areas: ['OX1', 'OX2', 'OX3', 'OX4'],
        minOrder: 1800,
        fee: 495,
        hub: 0,
        hubPartner: null,
        hubFee: null,
        slots: [
          {id: 'slot_uma_1', label: 'Tue 24 Nov · 13:00–16:00 (Courier)', window_start: '2026-11-24T13:00:00Z', window_end: '2026-11-24T16:00:00Z', is_available: true, earliest_rank: 4},
        ],
      },
      {
        id: 'mer_tableready',
        name: 'TableReady Prepared Kitchen',
        category: 'prepared',
        desc: 'Small-batch cooked grains, sauces, and ready-to-heat sides.',
        areas: ['OX1', 'OX2'],
        minOrder: 2200,
        fee: 395,
        hub: 0,
        hubPartner: null,
        hubFee: null,
        slots: [
          {id: 'slot_tab_1', label: 'Mon 23 Nov · 17:00–19:00', window_start: '2026-11-23T17:00:00Z', window_end: '2026-11-23T19:00:00Z', is_available: true, earliest_rank: 3},
        ],
      },
    ];

    const insertMerchant = db.prepare(
      `INSERT INTO merchants (
        id, name, category, description, delivery_areas_json, min_order_minor,
        delivery_fee_minor, participates_in_consolidated_hub, consolidated_partner_name,
        consolidated_fee_minor, slots_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    for (const m of merchantsData) {
      insertMerchant.run(
        m.id,
        m.name,
        m.category,
        m.desc,
        JSON.stringify(m.areas),
        m.minOrder,
        m.fee,
        m.hub,
        m.hubPartner,
        m.hubFee,
        JSON.stringify(m.slots)
      );
    }

    // 7. Merchant Products (varying pack sizes, prices, availability, and substitution scenarios)
    const feedTimeRecent = '2026-11-22T21:15:00.000Z';
    const feedTimeOlder = '2026-11-22T14:30:00.000Z';

    const products = [
      // Chicken Thighs
      {id: 'prd_cot_chicken', mer: 'mer_cotswold', ing: 'ing_chicken_thighs', sku: 'COT-CHK-600', title: 'Cotswold Free-Range Chicken Thighs 600g', brand: 'Cotswold Farms', qty: 600, unit: 'g', price: 540, avail: 'in_stock', src: 'Cotswold EDI Feed (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 1, nut: {kcal_per_100g: 175, protein_g: 19, source: 'Pack nutrition label'}, sub: null},
      {id: 'prd_ald_chicken', mer: 'mer_alder', ing: 'ing_chicken_thighs', sku: 'ALD-CHK-500', title: 'Alder Pasture Chicken Thighs 500g', brand: 'Alder & Sons', qty: 500, unit: 'g', price: 620, avail: 'in_stock', src: 'Alder Daily Stock Sheet (8h ago)', upd: feedTimeOlder, allergens: [], complete: 1, nutVer: 0, nut: null, sub: null},

      // Orzo
      {id: 'prd_cot_orzo', mer: 'mer_cotswold', ing: 'ing_orzo', sku: 'COT-ORZ-500', title: 'De Cecco Orzo Pasta 500g', brand: 'De Cecco', qty: 500, unit: 'g', price: 215, avail: 'in_stock', src: 'Cotswold EDI Feed (2h ago)', upd: feedTimeRecent, allergens: ['gluten'], complete: 1, nutVer: 1, nut: {kcal_per_100g: 352, protein_g: 12, source: 'Manufacturer pack label'}, sub: null},
      {id: 'prd_uma_orzo', mer: 'mer_umami', ing: 'ing_orzo', sku: 'UMA-ORZ-250', title: 'Artisan Bronze Orzo 250g', brand: 'Rustichella', qty: 250, unit: 'g', price: 280, avail: 'in_stock', src: 'Umami Feed (2h ago)', upd: feedTimeRecent, allergens: ['gluten'], complete: 1, nutVer: 1, nut: {kcal_per_100g: 350, protein_g: 13, source: 'Pack label'}, sub: null},

      // Garlic
      {id: 'prd_cot_garlic', mer: 'mer_cotswold', ing: 'ing_garlic', sku: 'COT-GAR-24', title: 'Garlic Bulbs 3-Pack (~24 cloves)', brand: 'Cotswold', qty: 24, unit: 'clove', price: 110, avail: 'in_stock', src: 'Cotswold EDI Feed (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 0, nut: null, sub: null},
      {id: 'prd_mea_garlic', mer: 'mer_meadowbrook', ing: 'ing_garlic', sku: 'MEA-GAR-16', title: 'Oxfordshire Heritage Garlic 2-Pack (~16 cloves)', brand: 'Meadowbrook', qty: 16, unit: 'clove', price: 145, avail: 'in_stock', src: 'Meadowbrook Morning Harvest (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 0, nut: null, sub: null},

      // Yellow Onions
      {id: 'prd_cot_onion', mer: 'mer_cotswold', ing: 'ing_yellow_onion', sku: 'COT-ONI-5', title: 'Brown & Yellow Onions 5-Pack', brand: 'Cotswold', qty: 5, unit: 'count', price: 135, avail: 'in_stock', src: 'Cotswold EDI Feed (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 0, nut: null, sub: null},
      {id: 'prd_mea_onion', mer: 'mer_meadowbrook', ing: 'ing_yellow_onion', sku: 'MEA-ONI-3', title: 'Farmhouse Yellow Onions 3-Pack', brand: 'Meadowbrook', qty: 3, unit: 'count', price: 115, avail: 'in_stock', src: 'Meadowbrook Morning Harvest (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 0, nut: null, sub: null},

      // Fresh Thyme
      {id: 'prd_cot_thyme', mer: 'mer_cotswold', ing: 'ing_thyme', sku: 'COT-THY-20', title: 'Fresh Thyme Pack 20g', brand: 'Cotswold', qty: 20, unit: 'g', price: 105, avail: 'in_stock', src: 'Cotswold EDI Feed (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 0, nut: null, sub: null},
      {id: 'prd_mea_thyme', mer: 'mer_meadowbrook', ing: 'ing_thyme', sku: 'MEA-THY-25', title: 'Garden Cut Thyme Bunch 25g', brand: 'Meadowbrook', qty: 25, unit: 'g', price: 120, avail: 'in_stock', src: 'Meadowbrook Morning Harvest (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 0, nut: null, sub: null},

      // Lemon
      {id: 'prd_cot_lemon', mer: 'mer_cotswold', ing: 'ing_lemon', sku: 'COT-LEM-4', title: 'Unwaxed Lemons 4-Pack', brand: 'Cotswold', qty: 4, unit: 'count', price: 160, avail: 'in_stock', src: 'Cotswold EDI Feed (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 0, nut: null, sub: null},
      {id: 'prd_mea_lemon', mer: 'mer_meadowbrook', ing: 'ing_lemon', sku: 'MEA-LEM-2', title: 'Amalfi Unwaxed Lemons 2-Pack', brand: 'Meadowbrook', qty: 2, unit: 'count', price: 140, avail: 'in_stock', src: 'Meadowbrook Morning Harvest (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 0, nut: null, sub: null},

      // Chopped Tomatoes
      {id: 'prd_cot_tomatoes', mer: 'mer_cotswold', ing: 'ing_chopped_tomatoes', sku: 'COT-TOM-400', title: 'Mutti Polpa Chopped Tomatoes 400g Tin', brand: 'Mutti', qty: 400, unit: 'g', price: 125, avail: 'in_stock', src: 'Cotswold EDI Feed (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 1, nut: {kcal_per_100g: 26, protein_g: 1.2, source: 'Mutti label'}, sub: null},
      {id: 'prd_uma_tomatoes', mer: 'mer_umami', ing: 'ing_chopped_tomatoes', sku: 'UMA-TOM-800', title: 'San Marzano Crushed Tomatoes 800g', brand: 'Gustarosso', qty: 800, unit: 'g', price: 320, avail: 'in_stock', src: 'Umami Feed (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 1, nut: {kcal_per_100g: 24, protein_g: 1.1, source: 'Pack label'}, sub: null},

      // Red Lentils
      {id: 'prd_cot_lentils', mer: 'mer_cotswold', ing: 'ing_red_lentils', sku: 'COT-LEN-500', title: 'Cotswold Red Split Lentils 500g', brand: 'Cotswold', qty: 500, unit: 'g', price: 175, avail: 'in_stock', src: 'Cotswold EDI Feed (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 1, nut: {kcal_per_100g: 318, protein_g: 24, source: 'Pack label'}, sub: null},
      {id: 'prd_uma_lentils', mer: 'mer_umami', ing: 'ing_red_lentils', sku: 'UMA-LEN-1000', title: 'Organic Red Split Lentils 1kg', brand: 'Hodmedods', qty: 1000, unit: 'g', price: 340, avail: 'in_stock', src: 'Umami Feed (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 1, nut: {kcal_per_100g: 320, protein_g: 25, source: 'Pack label'}, sub: null},

      // Rigatoni
      {id: 'prd_cot_rigatoni', mer: 'mer_cotswold', ing: 'ing_rigatoni', sku: 'COT-RIG-500', title: 'Rummo Rigatoni Pasta 500g', brand: 'Rummo', qty: 500, unit: 'g', price: 210, avail: 'in_stock', src: 'Cotswold EDI Feed (2h ago)', upd: feedTimeRecent, allergens: ['gluten'], complete: 1, nutVer: 1, nut: {kcal_per_100g: 356, protein_g: 14, source: 'Pack label'}, sub: null},

      // Pecorino
      {id: 'prd_cot_pecorino', mer: 'mer_cotswold', ing: 'ing_pecorino', sku: 'COT-PEC-150', title: 'Pecorino Romano Wedge 150g', brand: 'Cotswold Deli', qty: 150, unit: 'g', price: 315, avail: 'in_stock', src: 'Cotswold EDI Feed (2h ago)', upd: feedTimeRecent, allergens: ['dairy'], complete: 1, nutVer: 1, nut: {kcal_per_100g: 387, protein_g: 26, source: 'Pack label'}, sub: null},

      // Fresh Basil
      {id: 'prd_mea_basil', mer: 'mer_meadowbrook', ing: 'ing_basil', sku: 'MEA-BAS-30', title: 'Living Sweet Basil Bunch 30g', brand: 'Meadowbrook', qty: 30, unit: 'g', price: 155, avail: 'in_stock', src: 'Meadowbrook Morning Harvest (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 0, nut: null, sub: null},
      {id: 'prd_cot_basil', mer: 'mer_cotswold', ing: 'ing_basil', sku: 'COT-BAS-25', title: 'Fresh Basil Pack 25g', brand: 'Cotswold', qty: 25, unit: 'g', price: 115, avail: 'in_stock', src: 'Cotswold EDI Feed (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 0, nut: null, sub: null},

      // Salmon Fillets (includes Alder unavailable/proposed allergen-changing sub + Cotswold in-stock)
      {id: 'prd_cot_salmon', mer: 'mer_cotswold', ing: 'ing_salmon_fillet', sku: 'COT-SAL-300', title: 'Scottish Salmon Fillets 2 x 150g', brand: 'Cotswold Fish', qty: 300, unit: 'g', price: 590, avail: 'in_stock', src: 'Cotswold EDI Feed (2h ago)', upd: feedTimeRecent, allergens: ['fish'], complete: 1, nutVer: 1, nut: {kcal_per_100g: 208, protein_g: 20, source: 'Pack label'}, sub: null},
      {id: 'prd_ald_salmon', mer: 'mer_alder', ing: 'ing_salmon_fillet', sku: 'ALD-SAL-300', title: 'Wild Atlantic Salmon Fillets 300g', brand: 'Alder Fishmonger', qty: 300, unit: 'g', price: 720, avail: 'low_stock', src: 'Alder Daily Stock Sheet (8h ago)', upd: feedTimeOlder, allergens: ['fish'], complete: 1, nutVer: 0, nut: null, sub: 'prd_ald_salmon_sub'},
      {id: 'prd_ald_salmon_sub', mer: 'mer_alder', ing: 'ing_salmon_fillet', sku: 'ALD-SAL-SUB', title: 'Glazed Salmon Fillets (Peanut-Sesame Crust)', brand: 'Alder Kitchen', qty: 300, unit: 'g', price: 740, avail: 'in_stock', src: 'Alder Daily Stock Sheet (8h ago)', upd: feedTimeOlder, allergens: ['fish', 'peanuts', 'sesame'], complete: 0, nutVer: 0, nut: null, sub: null},

      // White Miso
      {id: 'prd_uma_miso', mer: 'mer_umami', ing: 'ing_white_miso', sku: 'UMA-MIS-300', title: 'Clearspring Sweet White Miso 300g', brand: 'Clearspring', qty: 300, unit: 'g', price: 390, avail: 'in_stock', src: 'Umami Feed (2h ago)', upd: feedTimeRecent, allergens: ['soy'], complete: 1, nutVer: 1, nut: {kcal_per_100g: 198, protein_g: 10, source: 'Pack label'}, sub: null},
      {id: 'prd_cot_miso', mer: 'mer_cotswold', ing: 'ing_white_miso', sku: 'COT-MIS-150', title: 'Miso Paste Pouch 150g', brand: 'Yutaka', qty: 150, unit: 'g', price: 245, avail: 'in_stock', src: 'Cotswold EDI Feed (2h ago)', upd: feedTimeRecent, allergens: ['soy'], complete: 1, nutVer: 1, nut: {kcal_per_100g: 190, protein_g: 9, source: 'Pack label'}, sub: null},

      // Broccolini
      {id: 'prd_mea_broccolini', mer: 'mer_meadowbrook', ing: 'ing_broccolini', sku: 'MEA-BRO-200', title: 'Tenderstem Broccolini 200g', brand: 'Meadowbrook', qty: 200, unit: 'g', price: 220, avail: 'in_stock', src: 'Meadowbrook Morning Harvest (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 0, nut: null, sub: null},
      {id: 'prd_cot_broccolini', mer: 'mer_cotswold', ing: 'ing_broccolini', sku: 'COT-BRO-200', title: 'Tenderstem Broccoli 200g', brand: 'Cotswold', qty: 200, unit: 'g', price: 200, avail: 'in_stock', src: 'Cotswold EDI Feed (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 0, nut: null, sub: null},

      // Jasmine Rice
      {id: 'prd_cot_jasmine', mer: 'mer_cotswold', ing: 'ing_jasmine_rice', sku: 'COT-JAS-500', title: 'Fragrant Jasmine Rice 500g', brand: 'Tilda', qty: 500, unit: 'g', price: 230, avail: 'in_stock', src: 'Cotswold EDI Feed (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 1, nut: {kcal_per_100g: 350, protein_g: 7, source: 'Pack label'}, sub: null},
      {id: 'prd_uma_jasmine', mer: 'mer_umami', ing: 'ing_jasmine_rice', sku: 'UMA-JAS-1000', title: 'Thai Hom Mali Jasmine Rice 1kg', brand: 'Umami', qty: 1000, unit: 'g', price: 360, avail: 'in_stock', src: 'Umami Feed (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 1, nut: {kcal_per_100g: 350, protein_g: 7, source: 'Pack label'}, sub: null},

      // Chestnut Mushrooms
      {id: 'prd_mea_mushrooms', mer: 'mer_meadowbrook', ing: 'ing_chestnut_mushrooms', sku: 'MEA-MUS-250', title: 'Organic Chestnut Mushrooms 250g', brand: 'Meadowbrook', qty: 250, unit: 'g', price: 240, avail: 'in_stock', src: 'Meadowbrook Morning Harvest (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 0, nut: null, sub: null},
      {id: 'prd_cot_mushrooms', mer: 'mer_cotswold', ing: 'ing_chestnut_mushrooms', sku: 'COT-MUS-300', title: 'Chestnut Mushrooms 300g', brand: 'Cotswold', qty: 300, unit: 'g', price: 185, avail: 'in_stock', src: 'Cotswold EDI Feed (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 0, nut: null, sub: null},

      // Sage
      {id: 'prd_mea_sage', mer: 'mer_meadowbrook', ing: 'ing_sage', sku: 'MEA-SAG-20', title: 'Fresh Sage Leaves 20g', brand: 'Meadowbrook', qty: 20, unit: 'g', price: 110, avail: 'in_stock', src: 'Meadowbrook Morning Harvest (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 0, nut: null, sub: null},
      {id: 'prd_cot_sage', mer: 'mer_cotswold', ing: 'ing_sage', sku: 'COT-SAG-20', title: 'Fresh Sage Pack 20g', brand: 'Cotswold', qty: 20, unit: 'g', price: 100, avail: 'in_stock', src: 'Cotswold EDI Feed (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 0, nut: null, sub: null},

      // Cauliflower
      {id: 'prd_mea_cauliflower', mer: 'mer_meadowbrook', ing: 'ing_cauliflower', sku: 'MEA-CAU-1', title: 'Oxfordshire Whole Cauliflower 1 Head', brand: 'Meadowbrook', qty: 1, unit: 'count', price: 195, avail: 'in_stock', src: 'Meadowbrook Morning Harvest (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 0, nut: null, sub: null},
      {id: 'prd_cot_cauliflower', mer: 'mer_cotswold', ing: 'ing_cauliflower', sku: 'COT-CAU-1', title: 'British Cauliflower 1 Head', brand: 'Cotswold', qty: 1, unit: 'count', price: 145, avail: 'in_stock', src: 'Cotswold EDI Feed (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 0, nut: null, sub: null},

      // Chickpeas
      {id: 'prd_cot_chickpeas', mer: 'mer_cotswold', ing: 'ing_chickpeas', sku: 'COT-CHK-240', title: 'Organic Chickpeas in Water (240g drained)', brand: 'Biona', qty: 240, unit: 'g', price: 120, avail: 'in_stock', src: 'Cotswold EDI Feed (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 1, nut: {kcal_per_100g: 125, protein_g: 7, source: 'Pack label'}, sub: null},

      // Tahini
      {id: 'prd_uma_tahini', mer: 'mer_umami', ing: 'ing_tahini', sku: 'UMA-TAH-270', title: 'Belazu Roasted Sesame Tahini 270g', brand: 'Belazu', qty: 270, unit: 'g', price: 340, avail: 'in_stock', src: 'Umami Feed (2h ago)', upd: feedTimeRecent, allergens: ['sesame'], complete: 1, nutVer: 1, nut: {kcal_per_100g: 620, protein_g: 21, source: 'Pack label'}, sub: null},
      {id: 'prd_cot_tahini', mer: 'mer_cotswold', ing: 'ing_tahini', sku: 'COT-TAH-170', title: 'Light Tahini Jar 170g', brand: 'Cypressa', qty: 170, unit: 'g', price: 240, avail: 'in_stock', src: 'Cotswold EDI Feed (2h ago)', upd: feedTimeRecent, allergens: ['sesame'], complete: 1, nutVer: 1, nut: {kcal_per_100g: 615, protein_g: 20, source: 'Pack label'}, sub: null},

      // Parsley
      {id: 'prd_mea_parsley', mer: 'mer_meadowbrook', ing: 'ing_parsley', sku: 'MEA-PAR-30', title: 'Flat-Leaf Parsley Bunch 30g', brand: 'Meadowbrook', qty: 30, unit: 'g', price: 115, avail: 'in_stock', src: 'Meadowbrook Morning Harvest (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 0, nut: null, sub: null},
      {id: 'prd_cot_parsley', mer: 'mer_cotswold', ing: 'ing_parsley', sku: 'COT-PAR-25', title: 'Flat-Leaf Parsley 25g', brand: 'Cotswold', qty: 25, unit: 'g', price: 95, avail: 'in_stock', src: 'Cotswold EDI Feed (2h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 0, nut: null, sub: null},

      // Sourdough & Unavailable Sausage & Prepared Side
      {id: 'prd_hea_sourdough', mer: 'mer_hearthstone', ing: 'ing_sourdough', sku: 'HEA-SOU-1', title: 'Hearthstone Country Sourdough Boule', brand: 'Hearthstone', qty: 1, unit: 'loaf', price: 420, avail: 'in_stock', src: 'Hearthstone Morning Bake (1h ago)', upd: feedTimeRecent, allergens: ['gluten'], complete: 1, nutVer: 0, nut: null, sub: null},
      {id: 'prd_ald_sausage_unavail', mer: 'mer_alder', ing: 'ing_pork_sausage', sku: 'ALD-SAU-400', title: 'Alder Outdoor-Reared Pork & Herb Sausages 400g', brand: 'Alder & Sons', qty: 400, unit: 'g', price: 480, avail: 'unavailable', src: 'Alder Daily Stock Sheet (8h ago)', upd: feedTimeOlder, allergens: ['sulphites'], complete: 1, nutVer: 0, nut: null, sub: null},
      {id: 'prd_tab_ragu_prep', mer: 'mer_tableready', ing: 'ing_chopped_tomatoes', sku: 'TAB-TOM-600', title: 'TableReady Slow-Roasted Tomato Base 600g', brand: 'TableReady', qty: 600, unit: 'g', price: 495, avail: 'in_stock', src: 'TableReady Kitchen Feed (3h ago)', upd: feedTimeRecent, allergens: [], complete: 1, nutVer: 1, nut: {kcal_per_100g: 45, protein_g: 1.5, source: 'Kitchen batch specification'}, sub: null},
    ];

    const insertProduct = db.prepare(
      `INSERT INTO merchant_products (
        id, merchant_id, ingredient_id, sku, title, brand, pack_quantity, pack_unit,
        price_minor, currency, availability, source_name, price_updated_at,
        allergens_json, allergen_metadata_complete, nutrition_verified,
        nutrition_summary_json, proposed_substitute_product_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    for (const p of products) {
      insertProduct.run(
        p.id,
        p.mer,
        p.ing,
        p.sku,
        p.title,
        p.brand,
        p.qty,
        p.unit,
        p.price,
        'GBP',
        p.avail,
        p.src,
        p.upd,
        JSON.stringify(p.allergens),
        p.complete,
        p.nutVer,
        p.nut ? JSON.stringify(p.nut) : null,
        p.sub
      );
    }

    // 8. Seed 1 Partially Fulfilled Parent Checkout + Ledger (Demonstrating partial fulfilment & pending delivery confirmation + substitution requiring approval)
    const checkoutId = 'chk_seed_01';
    const orderCotswoldId = 'ord_seed_partial_01';
    const orderAlderId = 'ord_seed_sub_02';

    db.prepare(
      `INSERT INTO parent_checkouts (
        id, household_id, idempotency_key, delivery_address, delivery_postcode,
        currency, total_authorised_minor, total_captured_minor, total_refunded_minor,
        status, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      checkoutId,
      HOUSEHOLD_ID,
      'seed-idem-2026-11-22-01',
      '42 St Giles Crescent, Oxford',
      'OX2 6JL',
      'GBP',
      2980,
      2740,
      240,
      'completed',
      '2026-11-22T10:15:00.000Z'
    );

    // Order 1: Meadowbrook Greengrocer — partially fulfilled (2 mushroom packs ordered, 1 delivered; £2.40 refunded; awaiting confirmation into pantry)
    db.prepare(
      `INSERT INTO merchant_orders (
        id, parent_checkout_id, merchant_id, merchant_name, fulfilment_model,
        fulfilment_partner_name, slot_label, status, failure_reason,
        subtotal_minor, delivery_fee_minor, total_minor, refunded_minor,
        delivery_confirmed_into_pantry, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      orderCotswoldId,
      checkoutId,
      'mer_meadowbrook',
      'Meadowbrook Greengrocer',
      'consolidated',
      'Aureom Consolidated Hub',
      'Sun 22 Nov · 17:00–19:00',
      'partially_fulfilled',
      'Short-picked 1 x Organic Chestnut Mushrooms 250g due to harvest limit',
      710,
      550,
      1260,
      240,
      0,
      '2026-11-22T10:15:00.000Z'
    );

    db.prepare(
      `INSERT INTO order_line_items (
        id, order_id, ingredient_id, product_id, product_title, pack_quantity, pack_unit,
        ordered_packs, delivered_packs, unit_price_minor, line_total_minor,
        substitution_preference, substitution_status, requires_explicit_approval, linked_meal_ids_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      'oli_seed_1',
      orderCotswoldId,
      'ing_chestnut_mushrooms',
      'prd_mea_mushrooms',
      'Organic Chestnut Mushrooms 250g',
      250,
      'g',
      2,
      1,
      240,
      480,
      'refund_if_missing',
      'none',
      0,
      JSON.stringify(['pm_thu_din'])
    );

    db.prepare(
      `INSERT INTO order_line_items (
        id, order_id, ingredient_id, product_id, product_title, pack_quantity, pack_unit,
        ordered_packs, delivered_packs, unit_price_minor, line_total_minor,
        substitution_preference, substitution_status, requires_explicit_approval, linked_meal_ids_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      'oli_seed_2',
      orderCotswoldId,
      'ing_yellow_onion',
      'prd_mea_onion',
      'Farmhouse Yellow Onions 3-Pack',
      3,
      'count',
      2,
      2,
      115,
      230,
      'allow_equivalent',
      'none',
      0,
      JSON.stringify(['pm_mon_din', 'pm_tue_din'])
    );

    // Order 2: Alder Butcher — has a proposed substitution requiring explicit approval (peanut-sesame glaze + incomplete allergen metadata!)
    db.prepare(
      `INSERT INTO merchant_orders (
        id, parent_checkout_id, merchant_id, merchant_name, fulfilment_model,
        fulfilment_partner_name, slot_label, status, failure_reason,
        subtotal_minor, delivery_fee_minor, total_minor, refunded_minor,
        delivery_confirmed_into_pantry, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      orderAlderId,
      checkoutId,
      'mer_alder',
      'Alder & Sons Family Butcher',
      'separate',
      null,
      'Mon 23 Nov · 14:00–16:00 (Chilled Van)',
      'confirmed',
      null,
      1220,
      500,
      1720,
      0,
      0,
      '2026-11-22T10:15:00.000Z'
    );

    db.prepare(
      `INSERT INTO order_line_items (
        id, order_id, ingredient_id, product_id, product_title, pack_quantity, pack_unit,
        ordered_packs, delivered_packs, unit_price_minor, line_total_minor,
        substitution_preference, substitution_status, proposed_substitute_product_id,
        proposed_substitute_title, proposed_substitute_price_minor,
        proposed_substitute_allergens_json, proposed_substitute_metadata_complete,
        requires_explicit_approval, substitution_warning, linked_meal_ids_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      'oli_seed_3',
      orderAlderId,
      'ing_salmon_fillet',
      'prd_ald_salmon',
      'Wild Atlantic Salmon Fillets 300g',
      300,
      'g',
      1,
      null,
      720,
      720,
      'require_approval',
      'proposed',
      'prd_ald_salmon_sub',
      'Glazed Salmon Fillets (Peanut-Sesame Crust)',
      740,
      JSON.stringify(['fish', 'peanuts', 'sesame']),
      0,
      1,
      'Blocked automatic substitution: substitute introduces Peanuts (Maya Lin exclusion) and has incomplete allergen metadata.',
      JSON.stringify(['pm_wed_din'])
    );

    db.prepare(
      `INSERT INTO order_line_items (
        id, order_id, ingredient_id, product_id, product_title, pack_quantity, pack_unit,
        ordered_packs, delivered_packs, unit_price_minor, line_total_minor,
        substitution_preference, substitution_status, requires_explicit_approval, linked_meal_ids_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      'oli_seed_4',
      orderAlderId,
      'ing_chicken_thighs',
      'prd_ald_chicken',
      'Alder Pasture Chicken Thighs 500g',
      500,
      'g',
      1,
      null,
      500,
      500,
      'allow_equivalent',
      'none',
      0,
      JSON.stringify(['pm_mon_din'])
    );

    const insertLedger = db.prepare(
      `INSERT INTO payment_ledger (
        id, parent_checkout_id, merchant_order_id, entry_type, amount_minor, currency, status, note, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    insertLedger.run('led_1', checkoutId, null, 'authorisation', 2980, 'GBP', 'recorded', 'Initial card pre-authorisation across 2 merchant orders', '2026-11-22T10:15:00.000Z');
    insertLedger.run('led_2', checkoutId, orderCotswoldId, 'capture', 1020, 'GBP', 'recorded', 'Captured delivered items + consolidated fee for Meadowbrook', '2026-11-22T17:45:00.000Z');
    insertLedger.run('led_3', checkoutId, orderCotswoldId, 'refund', 240, 'GBP', 'recorded', 'Automatic short-pick refund for 1 missing mushroom pack', '2026-11-22T17:46:00.000Z');
    insertLedger.run('led_4', checkoutId, orderCotswoldId, 'merchant_settlement', 1020, 'GBP', 'pending', 'Scheduled settlement to Meadowbrook Greengrocer', '2026-11-22T17:46:00.000Z');
    insertLedger.run('led_5', checkoutId, orderAlderId, 'capture', 1720, 'GBP', 'recorded', 'Captured Alder & Sons chilled order', '2026-11-22T10:16:00.000Z');

    // 9. Food Diary Entries (1 shared household entry + 1 private adult entry to demonstrate privacy)
    const insertDiary = db.prepare(
      `INSERT INTO food_diary_entries (
        id, household_id, member_id, member_name, visibility, source,
        planned_meal_id, recipe_id, product_id, title, date, time,
        portion_label, differed_from_plan, difference_reason, satisfaction,
        hunger_note, practical_notes, photo_url, nutrition_summary_json, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );

    insertDiary.run(
      'dia_maya_shared_1',
      HOUSEHOLD_ID,
      MEMBER_MAYA_ID,
      'Maya Lin',
      'household',
      'recipe',
      null,
      'rec_tomato_lentil_ragu',
      null,
      'Roasted Tomato & Red Lentil Ragu',
      '2026-11-22',
      '19:30',
      '1 generous bowl',
      0,
      null,
      5,
      'Hungry after evening walk, felt comfortably full.',
      'Doubled the basil garnish; worked very well with rigatoni.',
      '/images/recipe_tomato_lentil_ragu.jpg',
      JSON.stringify({
        kcal: 495,
        protein_g: 22,
        source: 'UK CoFID Estimated Recipe Breakdown (unverified home portion)',
        is_verified: false,
      }),
      '2026-11-22T20:10:00.000Z'
    );

    insertDiary.run(
      'dia_owen_private_1',
      HOUSEHOLD_ID,
      MEMBER_OWEN_ID,
      'Owen Mercer',
      'private',
      'manual',
      null,
      null,
      null,
      'Toasted sourdough with almond butter & sliced banana',
      '2026-11-22',
      '13:15',
      '2 thick slices',
      1,
      'Skipped planned soup because work call ran late',
      4,
      'Moderate hunger; wanted something quick before afternoon errands.',
      'Private note: felt noticeably steadier energy than usual lunch.',
      null,
      null,
      '2026-11-22T13:30:00.000Z'
    );
  });
}
