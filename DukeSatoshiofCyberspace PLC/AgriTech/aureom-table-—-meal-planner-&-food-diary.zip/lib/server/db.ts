import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';

let dbInstance: DatabaseSync | null = null;

function getDbPath(): string {
  if (process.env.AUREOM_DB_PATH) {
    return process.env.AUREOM_DB_PATH;
  }
  const dataDir = path.join(process.cwd(), '.data');
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, {recursive: true});
  }
  return path.join(dataDir, 'aureom_table.db');
}

export function getDb(): DatabaseSync {
  if (dbInstance) {
    return dbInstance;
  }
  const dbPath = getDbPath();
  const db = new DatabaseSync(dbPath);
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec('PRAGMA journal_mode = WAL;');
  runMigrations(db);
  dbInstance = db;
  return db;
}

export function resetDbConnectionForTests(): void {
  if (dbInstance) {
    dbInstance.close();
    dbInstance = null;
  }
}

export function withTransaction<T>(db: DatabaseSync, fn: () => T): T {
  db.exec('BEGIN IMMEDIATE;');
  try {
    const result = fn();
    db.exec('COMMIT;');
    return result;
  } catch (err) {
    db.exec('ROLLBACK;');
    throw err;
  }
}

function runMigrations(db: DatabaseSync): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version TEXT PRIMARY KEY,
      applied_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS households (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      address_line1 TEXT NOT NULL,
      city TEXT NOT NULL,
      postcode TEXT NOT NULL,
      currency TEXT NOT NULL DEFAULT 'GBP',
      weekly_budget_minor INTEGER NOT NULL,
      preferred_merchant_ids_json TEXT NOT NULL,
      default_fulfilment_model TEXT NOT NULL,
      share_delivery_details_with_merchants INTEGER NOT NULL DEFAULT 1,
      track_calories_in_diary INTEGER NOT NULL DEFAULT 1,
      notification_prefs_json TEXT NOT NULL,
      active_member_id TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS household_members (
      id TEXT PRIMARY KEY,
      household_id TEXT NOT NULL REFERENCES households(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      role TEXT NOT NULL,
      dietary_preferences_json TEXT NOT NULL,
      dislikes_json TEXT NOT NULL,
      excluded_ingredients_json TEXT NOT NULL,
      allergens_json TEXT NOT NULL,
      portion_multiplier REAL NOT NULL DEFAULT 1.0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ingredient_identities (
      id TEXT PRIMARY KEY,
      canonical_name TEXT NOT NULL,
      form_variety TEXT NOT NULL,
      default_unit TEXT NOT NULL,
      is_pantry_staple INTEGER NOT NULL DEFAULT 0,
      documented_conversion_json TEXT
    );

    CREATE TABLE IF NOT EXISTS recipes (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      image_url TEXT NOT NULL,
      image_source TEXT NOT NULL,
      servings INTEGER NOT NULL,
      prep_minutes INTEGER NOT NULL,
      cook_minutes INTEGER NOT NULL,
      instructions_json TEXT NOT NULL,
      dietary_tags_json TEXT NOT NULL,
      allergens_json TEXT NOT NULL,
      allergen_provenance TEXT NOT NULL,
      nutrition_json TEXT,
      storage_notes TEXT,
      leftover_notes TEXT
    );

    CREATE TABLE IF NOT EXISTS recipe_ingredients (
      id TEXT PRIMARY KEY,
      recipe_id TEXT NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
      ingredient_id TEXT NOT NULL REFERENCES ingredient_identities(id),
      display_name TEXT NOT NULL,
      form_variety TEXT NOT NULL,
      quantity REAL NOT NULL,
      unit TEXT NOT NULL,
      is_optional INTEGER NOT NULL DEFAULT 0,
      is_garnish INTEGER NOT NULL DEFAULT 0,
      is_pantry_staple INTEGER NOT NULL DEFAULT 0,
      documented_conversion_json TEXT
    );

    CREATE TABLE IF NOT EXISTS meal_plan_weeks (
      id TEXT PRIMARY KEY,
      household_id TEXT NOT NULL REFERENCES households(id) ON DELETE CASCADE,
      week_start_date TEXT NOT NULL,
      title TEXT NOT NULL,
      weekly_budget_minor INTEGER NOT NULL,
      is_template INTEGER NOT NULL DEFAULT 0,
      shared_with_household INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS planned_meals (
      id TEXT PRIMARY KEY,
      week_id TEXT NOT NULL REFERENCES meal_plan_weeks(id) ON DELETE CASCADE,
      household_id TEXT NOT NULL REFERENCES households(id) ON DELETE CASCADE,
      date TEXT NOT NULL,
      slot TEXT NOT NULL,
      kind TEXT NOT NULL,
      recipe_id TEXT REFERENCES recipes(id),
      title TEXT NOT NULL,
      servings INTEGER NOT NULL,
      assigned_member_ids_json TEXT NOT NULL,
      leftover_source_meal_id TEXT,
      leftover_portions_yielded INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'planned',
      notes TEXT,
      prep_minutes INTEGER NOT NULL DEFAULT 0,
      cook_minutes INTEGER NOT NULL DEFAULT 0,
      linked_order_ids_json TEXT NOT NULL DEFAULT '[]'
    );

    CREATE TABLE IF NOT EXISTS pantry_items (
      id TEXT PRIMARY KEY,
      household_id TEXT NOT NULL REFERENCES households(id) ON DELETE CASCADE,
      ingredient_id TEXT NOT NULL REFERENCES ingredient_identities(id),
      product_name TEXT NOT NULL,
      barcode TEXT,
      quantity REAL NOT NULL,
      unit TEXT NOT NULL,
      storage_location TEXT NOT NULL,
      purchase_or_opened_date TEXT NOT NULL,
      recorded_expiry_date TEXT,
      date_marking_type TEXT NOT NULL,
      reserved_quantity REAL NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS pantry_transactions (
      id TEXT PRIMARY KEY,
      household_id TEXT NOT NULL REFERENCES households(id) ON DELETE CASCADE,
      pantry_item_id TEXT NOT NULL,
      action TEXT NOT NULL,
      quantity_delta REAL NOT NULL,
      unit TEXT NOT NULL,
      note TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS pantry_reservations (
      id TEXT PRIMARY KEY,
      household_id TEXT NOT NULL REFERENCES households(id) ON DELETE CASCADE,
      pantry_item_id TEXT NOT NULL REFERENCES pantry_items(id) ON DELETE CASCADE,
      week_id TEXT NOT NULL REFERENCES meal_plan_weeks(id) ON DELETE CASCADE,
      ingredient_id TEXT NOT NULL,
      reserved_qty REAL NOT NULL,
      unit TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS merchants (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      category TEXT NOT NULL,
      description TEXT NOT NULL,
      delivery_areas_json TEXT NOT NULL,
      min_order_minor INTEGER NOT NULL,
      delivery_fee_minor INTEGER NOT NULL,
      participates_in_consolidated_hub INTEGER NOT NULL DEFAULT 0,
      consolidated_partner_name TEXT,
      consolidated_fee_minor INTEGER,
      slots_json TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS merchant_products (
      id TEXT PRIMARY KEY,
      merchant_id TEXT NOT NULL REFERENCES merchants(id) ON DELETE CASCADE,
      ingredient_id TEXT NOT NULL REFERENCES ingredient_identities(id),
      sku TEXT NOT NULL,
      title TEXT NOT NULL,
      brand TEXT NOT NULL,
      pack_quantity REAL NOT NULL,
      pack_unit TEXT NOT NULL,
      price_minor INTEGER NOT NULL,
      currency TEXT NOT NULL DEFAULT 'GBP',
      availability TEXT NOT NULL,
      source_name TEXT NOT NULL,
      price_updated_at TEXT NOT NULL,
      allergens_json TEXT NOT NULL,
      allergen_metadata_complete INTEGER NOT NULL DEFAULT 1,
      nutrition_verified INTEGER NOT NULL DEFAULT 0,
      nutrition_summary_json TEXT,
      proposed_substitute_product_id TEXT
    );

    CREATE TABLE IF NOT EXISTS parent_checkouts (
      id TEXT PRIMARY KEY,
      household_id TEXT NOT NULL REFERENCES households(id) ON DELETE CASCADE,
      idempotency_key TEXT NOT NULL UNIQUE,
      delivery_address TEXT NOT NULL,
      delivery_postcode TEXT NOT NULL,
      currency TEXT NOT NULL DEFAULT 'GBP',
      total_authorised_minor INTEGER NOT NULL,
      total_captured_minor INTEGER NOT NULL,
      total_refunded_minor INTEGER NOT NULL,
      status TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS merchant_orders (
      id TEXT PRIMARY KEY,
      parent_checkout_id TEXT NOT NULL REFERENCES parent_checkouts(id) ON DELETE CASCADE,
      merchant_id TEXT NOT NULL,
      merchant_name TEXT NOT NULL,
      fulfilment_model TEXT NOT NULL,
      fulfilment_partner_name TEXT,
      slot_label TEXT NOT NULL,
      status TEXT NOT NULL,
      failure_reason TEXT,
      subtotal_minor INTEGER NOT NULL,
      delivery_fee_minor INTEGER NOT NULL,
      total_minor INTEGER NOT NULL,
      refunded_minor INTEGER NOT NULL DEFAULT 0,
      delivery_confirmed_into_pantry INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS order_line_items (
      id TEXT PRIMARY KEY,
      order_id TEXT NOT NULL REFERENCES merchant_orders(id) ON DELETE CASCADE,
      ingredient_id TEXT NOT NULL,
      product_id TEXT NOT NULL,
      product_title TEXT NOT NULL,
      pack_quantity REAL NOT NULL,
      pack_unit TEXT NOT NULL,
      ordered_packs INTEGER NOT NULL,
      delivered_packs INTEGER,
      unit_price_minor INTEGER NOT NULL,
      line_total_minor INTEGER NOT NULL,
      substitution_preference TEXT NOT NULL,
      substitution_status TEXT NOT NULL DEFAULT 'none',
      proposed_substitute_product_id TEXT,
      proposed_substitute_title TEXT,
      proposed_substitute_price_minor INTEGER,
      proposed_substitute_allergens_json TEXT,
      proposed_substitute_metadata_complete INTEGER,
      requires_explicit_approval INTEGER NOT NULL DEFAULT 0,
      substitution_warning TEXT,
      linked_meal_ids_json TEXT NOT NULL DEFAULT '[]'
    );

    CREATE TABLE IF NOT EXISTS payment_ledger (
      id TEXT PRIMARY KEY,
      parent_checkout_id TEXT NOT NULL REFERENCES parent_checkouts(id) ON DELETE CASCADE,
      merchant_order_id TEXT,
      entry_type TEXT NOT NULL,
      amount_minor INTEGER NOT NULL,
      currency TEXT NOT NULL DEFAULT 'GBP',
      status TEXT NOT NULL,
      note TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS webhook_events (
      event_id TEXT PRIMARY KEY,
      provider TEXT NOT NULL,
      payload_json TEXT NOT NULL,
      processed_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS food_diary_entries (
      id TEXT PRIMARY KEY,
      household_id TEXT NOT NULL REFERENCES households(id) ON DELETE CASCADE,
      member_id TEXT NOT NULL REFERENCES household_members(id) ON DELETE CASCADE,
      member_name TEXT NOT NULL,
      visibility TEXT NOT NULL,
      source TEXT NOT NULL,
      planned_meal_id TEXT,
      recipe_id TEXT,
      product_id TEXT,
      title TEXT NOT NULL,
      date TEXT NOT NULL,
      time TEXT NOT NULL,
      portion_label TEXT NOT NULL,
      differed_from_plan INTEGER NOT NULL DEFAULT 0,
      difference_reason TEXT,
      satisfaction INTEGER,
      hunger_note TEXT,
      practical_notes TEXT,
      photo_url TEXT,
      nutrition_summary_json TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS shopping_config (
      household_id TEXT PRIMARY KEY REFERENCES households(id) ON DELETE CASCADE,
      include_optional INTEGER NOT NULL DEFAULT 0,
      include_garnish INTEGER NOT NULL DEFAULT 1,
      include_pantry_staples INTEGER NOT NULL DEFAULT 0,
      locked_assignments_json TEXT NOT NULL DEFAULT '{}'
    );
  `);

  const hasMigration = db
    .prepare('SELECT 1 FROM schema_migrations WHERE version = ?')
    .get('001_initial');
  if (!hasMigration) {
    db.prepare(
      'INSERT INTO schema_migrations (version, applied_at) VALUES (?, ?)'
    ).run('001_initial', new Date().toISOString());
  }
}
