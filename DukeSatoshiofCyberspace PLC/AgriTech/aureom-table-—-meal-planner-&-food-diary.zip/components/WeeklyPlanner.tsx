'use client';

import {useState} from 'react';
import {
  ArrowLeftRight,
  BookmarkPlus,
  Check,
  ChefHat,
  Copy,
  GripVertical,
  Plus,
  Sparkles,
  Trash2,
  Utensils,
} from 'lucide-react';
import {
  AiSuggestedMeal,
  MealSlot,
  PlannedMeal,
  PlannedMealKind,
} from '@/lib/domain/types';
import {formatMoney, WEEK_DAYS, WorkspaceSnapshot} from './types';

interface Props {
  snapshot: WorkspaceSnapshot;
  onRefresh: (next: WorkspaceSnapshot) => void;
  onNotify: (msg: string, tone?: 'info' | 'warning') => void;
  onLogMealFromPlan: (meal: PlannedMeal) => void;
}

const SLOTS: MealSlot[] = ['breakfast', 'lunch', 'dinner', 'snack'];

export default function WeeklyPlanner({
  snapshot,
  onRefresh,
  onNotify,
  onLogMealFromPlan,
}: Props) {
  const [draggingMealId, setDraggingMealId] = useState<string | null>(null);
  const [showOptionalSnacks, setShowOptionalSnacks] = useState(true);

  // Add Meal Modal
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [addDate, setAddDate] = useState(WEEK_DAYS[0].date);
  const [addSlot, setAddSlot] = useState<MealSlot>('dinner');
  const [addKind, setAddKind] = useState<PlannedMealKind>('recipe');
  const [addRecipeId, setAddRecipeId] = useState(snapshot.recipes[0]?.id ?? '');
  const [addTitle, setAddTitle] = useState('');
  const [addServings, setAddServings] = useState(2);
  const [addLeftoverYield, setAddLeftoverYield] = useState(0);
  const [addLeftoverSourceId, setAddLeftoverSourceId] = useState('');
  const [addMemberIds, setAddMemberIds] = useState<string[]>(
    snapshot.identity.members.map((m) => m.id)
  );

  // Accessible Move Modal (non-drag alternative)
  const [movingMeal, setMovingMeal] = useState<PlannedMeal | null>(null);
  const [moveDate, setMoveDate] = useState(WEEK_DAYS[0].date);
  const [moveSlot, setMoveSlot] = useState<MealSlot>('dinner');

  // Cook Confirmation Modal
  const [cookingMeal, setCookingMeal] = useState<PlannedMeal | null>(null);
  const [cookDeductions, setCookDeductions] = useState<
    Array<{
      pantry_item_id: string;
      product_name: string;
      available_qty: number;
      deduct_qty: number;
      unit: string;
    }>
  >([]);

  // Copy Day & Save Template
  const [copySource, setCopySource] = useState(WEEK_DAYS[0].date);
  const [copyTarget, setCopyTarget] = useState(WEEK_DAYS[6].date);
  const [templateTitle, setTemplateTitle] = useState('');

  // Optional AI Meal Assistant
  const [aiOpen, setAiOpen] = useState(false);
  const [aiMaxPrep, setAiMaxPrep] = useState(20);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [aiSuggestions, setAiSuggestions] = useState<AiSuggestedMeal[]>([]);
  const [aiDisclaimer, setAiDisclaimer] = useState<string | null>(null);

  const visibleSlots = showOptionalSnacks
    ? SLOTS
    : SLOTS.filter((s) => s !== 'snack');

  const handleMoveMeal = async (
    mealId: string,
    targetDate: string,
    targetSlot: MealSlot
  ) => {
    try {
      const res = await fetch('/api/planning', {
        method: 'PATCH',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          meal_id: mealId,
          date: targetDate,
          slot: targetSlot,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      if (data.order_immutability_notice) {
        onNotify(data.order_immutability_notice, 'info');
      } else {
        onNotify(`Moved meal to ${targetDate} (${targetSlot}).`);
      }
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Move failed', 'warning');
    }
  };

  const handleUpdateServings = async (meal: PlannedMeal, delta: number) => {
    const next = Math.max(1, meal.servings + delta);
    try {
      const res = await fetch('/api/planning', {
        method: 'PATCH',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({meal_id: meal.id, servings: next}),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      if (data.order_immutability_notice) {
        onNotify(data.order_immutability_notice);
      }
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Update failed', 'warning');
    }
  };

  const handleDeleteMeal = async (mealId: string) => {
    try {
      const res = await fetch(`/api/planning?meal_id=${encodeURIComponent(mealId)}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      if (data.order_immutability_notice) {
        onNotify(data.order_immutability_notice);
      } else {
        onNotify('Removed planned meal.');
      }
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Delete failed', 'warning');
    }
  };

  const handleAddMealSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const rec = snapshot.recipes.find((r) => r.id === addRecipeId);
    const title =
      addKind === 'recipe' && rec
        ? rec.title
        : addTitle.trim() || 'Planned Meal';

    try {
      const res = await fetch('/api/planning', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          action: 'add_meal',
          date: addDate,
          slot: addSlot,
          kind: addKind,
          recipe_id: addKind === 'recipe' ? addRecipeId : null,
          title,
          servings: addServings,
          assigned_member_ids:
            addMemberIds.length > 0
              ? addMemberIds
              : [snapshot.identity.active_member_id],
          leftover_source_meal_id:
            addKind === 'leftover' && addLeftoverSourceId
              ? addLeftoverSourceId
              : null,
          leftover_portions_yielded: addLeftoverYield,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      setAddModalOpen(false);
      setAddTitle('');
      onNotify(`Scheduled ${title} on ${addDate}.`);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Add failed', 'warning');
    }
  };

  const handleOpenCookConfirm = async (meal: PlannedMeal) => {
    try {
      const res = await fetch('/api/planning', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({action: 'preview_cook', meal_id: meal.id}),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setCookDeductions(
        (data.deductions ?? []).map(
          (d: {
            pantry_item_id: string;
            product_name: string;
            available_qty: number;
            suggested_deduct_qty: number;
            unit: string;
          }) => ({
            pantry_item_id: d.pantry_item_id,
            product_name: d.product_name,
            available_qty: d.available_qty,
            deduct_qty: d.suggested_deduct_qty,
            unit: d.unit,
          })
        )
      );
      setCookingMeal(meal);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Preview failed', 'warning');
    }
  };

  const handleConfirmCook = async () => {
    if (!cookingMeal) return;
    try {
      const res = await fetch('/api/planning', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          action: 'confirm_cook',
          meal_id: cookingMeal.id,
          deductions: cookDeductions.map((d) => ({
            pantry_item_id: d.pantry_item_id,
            deduct_qty: d.deduct_qty,
          })),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      const cookedTitle = cookingMeal.title;
      setCookingMeal(null);
      onNotify(`Marked "${cookedTitle}" as cooked and updated confirmed pantry quantities.`);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Cook update failed', 'warning');
    }
  };

  const handleCopyDay = async () => {
    try {
      const res = await fetch('/api/planning', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          action: 'copy_day',
          source_date: copySource,
          target_date: copyTarget,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      onNotify(`Copied ${data.created.length} meal(s) from ${copySource} to ${copyTarget}.`);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Copy failed', 'warning');
    }
  };

  const handleSaveTemplate = async () => {
    if (!templateTitle.trim()) return;
    try {
      const res = await fetch('/api/planning', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          action: 'save_template',
          title: templateTitle.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      setTemplateTitle('');
      onNotify(`Saved reusable template: ${data.template.title}`);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Save failed', 'warning');
    }
  };

  const handleAskAiPlanner = async () => {
    setAiLoading(true);
    setAiError(null);
    try {
      const res = await fetch('/api/ai/plan', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          max_prep_minutes: aiMaxPrep,
          budget_minor: snapshot.planning.current_week.weekly_budget_minor,
          target_dates: ['2026-11-25', '2026-11-26', '2026-11-28'],
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setAiSuggestions(data.suggestions ?? []);
      setAiDisclaimer(data.disclaimer ?? null);
    } catch (err) {
      setAiError(
        err instanceof Error ? err.message : 'AI meal suggestion failed'
      );
    } finally {
      setAiLoading(false);
    }
  };

  const handleAcceptAiSuggestion = async (s: AiSuggestedMeal) => {
    try {
      const res = await fetch('/api/planning', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          action: 'add_meal',
          date: s.date,
          slot: s.slot,
          kind: 'recipe',
          recipe_id: s.recipe_id,
          title: s.title,
          servings: s.servings,
          assigned_member_ids: snapshot.identity.members.map((m) => m.id),
          prep_minutes: s.prep_minutes,
          cook_minutes: s.cook_minutes,
          notes: `Suggested: ${s.reason}`,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      setAiSuggestions((prev) =>
        prev.filter((item) => !(item.date === s.date && item.recipe_id === s.recipe_id))
      );
      onNotify(`Added AI-proposed "${s.title}" to ${s.date}.`);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Accept failed', 'warning');
    }
  };

  const memberNameMap = new Map(
    snapshot.identity.members.map((m) => [m.id, m.name.split(' ')[0]])
  );

  const leftoverYieldMeals = snapshot.planning.meals.filter(
    (m) => m.leftover_portions_yielded > 0
  );

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <div className="bg-white border border-[#E5DEC9] rounded-xl p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="text-xs text-[#5A635C]">
            {snapshot.planning.current_week.title} · Budget{' '}
            <span className="font-mono tabular-nums font-semibold text-[#18392B]">
              {formatMoney(snapshot.planning.current_week.weekly_budget_minor)}
            </span>{' '}
            · Shared with household ({snapshot.identity.members.length} members)
          </div>
          <p className="text-xs text-[#5A635C]">
            Drag meals between slots or use the accessible Move button. Editing a plan never alters orders already placed.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <label className="inline-flex items-center gap-2 text-xs text-[#1F2421] px-3 py-2 rounded-lg border border-[#E5DEC9] bg-[#FAF7F2] cursor-pointer">
            <input
              type="checkbox"
              checked={showOptionalSnacks}
              onChange={(e) => setShowOptionalSnacks(e.target.checked)}
              className="accent-[#18392B]"
            />
            <span>Show Snack Slots</span>
          </label>
          <button
            type="button"
            onClick={() => setAiOpen((v) => !v)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[40px] rounded-lg border border-[#18392B] text-[#18392B] text-xs font-semibold hover:bg-[#EFE9DC] whitespace-nowrap cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Optional AI Plan Assistant</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setAddDate(WEEK_DAYS[0].date);
              setAddSlot('dinner');
              setAddModalOpen(true);
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[40px] rounded-lg bg-[#C85A28] text-white text-xs font-semibold hover:bg-[#B04C20] whitespace-nowrap cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Meal</span>
          </button>
        </div>
      </div>

      {/* Optional AI Assistant Drawer */}
      {aiOpen && (
        <section className="bg-white border border-[#18392B]/30 rounded-xl p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h2 className="font-serif text-lg font-semibold text-[#1F2421]">
                Optional AI Meal Proposal Assistant
              </h2>
              <p className="text-xs text-[#5A635C]">
                Proposes meals from your recipes, pantry stock, prep time, and household allergen rules. Every suggestion is rule-checked before you decide.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <label className="text-xs text-[#5A635C] flex items-center gap-2">
                <span>Max prep (min):</span>
                <input
                  type="number"
                  min={5}
                  max={90}
                  value={aiMaxPrep}
                  onChange={(e) => setAiMaxPrep(Number(e.target.value))}
                  className="w-16 px-2 py-1.5 rounded-lg border border-[#D4CCB8] text-xs font-mono tabular-nums"
                />
              </label>
              <button
                type="button"
                disabled={aiLoading}
                onClick={handleAskAiPlanner}
                className="px-4 py-2 min-h-[40px] rounded-lg bg-[#18392B] text-white text-xs font-semibold hover:bg-[#122B20] disabled:opacity-60 cursor-pointer"
              >
                {aiLoading ? 'Generating...' : 'Generate Proposal'}
              </button>
            </div>
          </div>

          {aiError && (
            <div className="p-3 rounded-lg bg-[#FFF4EE] border border-[#C85A28]/40 text-xs text-[#8E3511]">
              {aiError}
            </div>
          )}

          {aiDisclaimer && (
            <p className="text-xs text-[#5A635C]">{aiDisclaimer}</p>
          )}

          {aiSuggestions.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {aiSuggestions.map((s) => (
                <div
                  key={`${s.date}_${s.recipe_id}`}
                  className="p-4 rounded-lg bg-[#FAF7F2] border border-[#E5DEC9] space-y-2 flex flex-col justify-between"
                >
                  <div className="space-y-1.5">
                    <p className="text-xs text-[#5A635C] tabular-nums">
                      {s.date} · {s.servings} servings · Prep {s.prep_minutes}m
                    </p>
                    <h3 className="font-semibold text-sm text-[#1F2421]">
                      {s.title}
                    </h3>
                    <p className="text-xs text-[#5A635C]">{s.reason}</p>
                    {s.pantry_matches.length > 0 && (
                      <p className="text-[11px] text-[#18392B]">
                        Uses pantry: {s.pantry_matches.join(', ')}
                      </p>
                    )}
                    {s.validation_warnings.length > 0 && (
                      <p className="text-[11px] text-[#C85A28]">
                        Rule check notes: {s.validation_warnings.join(' ')}
                      </p>
                    )}
                  </div>
                  <div className="pt-2 flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleAcceptAiSuggestion(s)}
                      className="px-3 py-1.5 min-h-[36px] rounded-lg bg-[#18392B] text-white text-xs font-semibold cursor-pointer"
                    >
                      Accept to Plan
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setAiSuggestions((prev) =>
                          prev.filter((i) => i.date !== s.date)
                        )
                      }
                      className="px-3 py-1.5 min-h-[36px] rounded-lg border border-[#D4CCB8] text-xs cursor-pointer"
                    >
                      Dismiss
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      )}

      {/* Day Copy & Reusable Templates Bar */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white border border-[#E5DEC9] rounded-xl p-4 flex flex-wrap items-center gap-2 text-xs">
          <Copy className="w-4 h-4 text-[#18392B] shrink-0" />
          <span className="font-semibold text-[#1F2421]">Copy Day:</span>
          <select
            value={copySource}
            onChange={(e) => setCopySource(e.target.value)}
            aria-label="Copy source day"
            className="px-2.5 py-1.5 rounded-lg border border-[#D4CCB8] bg-[#FAF7F2]"
          >
            {WEEK_DAYS.map((d) => (
              <option key={d.date} value={d.date}>
                {d.short}
              </option>
            ))}
          </select>
          <span>to</span>
          <select
            value={copyTarget}
            onChange={(e) => setCopyTarget(e.target.value)}
            aria-label="Copy target day"
            className="px-2.5 py-1.5 rounded-lg border border-[#D4CCB8] bg-[#FAF7F2]"
          >
            {WEEK_DAYS.map((d) => (
              <option key={d.date} value={d.date}>
                {d.short}
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={handleCopyDay}
            className="px-3 py-1.5 min-h-[36px] rounded-lg border border-[#D4CCB8] font-medium hover:bg-[#FAF7F2] cursor-pointer"
          >
            Copy Meals
          </button>
        </div>

        <div className="bg-white border border-[#E5DEC9] rounded-xl p-4 flex flex-wrap items-center gap-2 text-xs">
          <BookmarkPlus className="w-4 h-4 text-[#18392B] shrink-0" />
          <input
            type="text"
            value={templateTitle}
            onChange={(e) => setTemplateTitle(e.target.value)}
            placeholder="Save week as reusable template..."
            className="flex-1 min-w-[160px] px-3 py-1.5 rounded-lg border border-[#D4CCB8] bg-[#FAF7F2]"
          />
          <button
            type="button"
            onClick={handleSaveTemplate}
            className="px-3 py-1.5 min-h-[36px] rounded-lg bg-[#18392B] text-white font-semibold hover:bg-[#122B20] cursor-pointer"
          >
            Save Template
          </button>
          <span className="text-[#5A635C]">
            ({snapshot.planning.templates.length} saved)
          </span>
        </div>
      </div>

      {/* 7-Day Planner Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-7 gap-3">
        {WEEK_DAYS.map((day) => (
          <div
            key={day.date}
            className="bg-white border border-[#E5DEC9] rounded-xl p-3.5 flex flex-col gap-3"
          >
            <div className="flex items-center justify-between border-b border-[#EFE9DC] pb-2">
              <h3 className="font-serif text-base font-semibold text-[#18392B] tabular-nums">
                {day.short}
              </h3>
              <button
                type="button"
                aria-label={`Add meal on ${day.full}`}
                onClick={() => {
                  setAddDate(day.date);
                  setAddSlot('dinner');
                  setAddModalOpen(true);
                }}
                className="w-8 h-8 rounded-lg hover:bg-[#FAF7F2] flex items-center justify-center text-[#5A635C] hover:text-[#18392B] cursor-pointer"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2.5 flex-1">
              {visibleSlots.map((slot) => {
                const slotMeals = snapshot.planning.meals.filter(
                  (m) => m.date === day.date && m.slot === slot
                );
                return (
                  <div
                    key={slot}
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={(e) => {
                      e.preventDefault();
                      const mealId =
                        e.dataTransfer.getData('text/plain') || draggingMealId;
                      if (mealId) {
                        handleMoveMeal(mealId, day.date, slot);
                        setDraggingMealId(null);
                      }
                    }}
                    className={`rounded-lg p-2 min-h-[68px] border transition-colors ${
                      draggingMealId
                        ? 'border-dashed border-[#18392B]/50 bg-[#FAF7F2]'
                        : 'border-[#EFE9DC] bg-[#FAF7F2]/60'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[11px] font-semibold text-[#5A635C] capitalize">
                        {slot}
                      </span>
                    </div>

                    {slotMeals.length === 0 ? (
                      <button
                        type="button"
                        onClick={() => {
                          setAddDate(day.date);
                          setAddSlot(slot);
                          setAddModalOpen(true);
                        }}
                        className="w-full text-left text-[11px] text-[#5A635C]/80 hover:text-[#18392B] py-1 cursor-pointer"
                      >
                        + Plan {slot}
                      </button>
                    ) : (
                      <div className="space-y-2">
                        {slotMeals.map((meal) => {
                          const assignedNames = meal.assigned_member_ids
                            .map((id) => memberNameMap.get(id))
                            .filter(Boolean)
                            .join(' & ');
                          return (
                            <div
                              key={meal.id}
                              draggable
                              onDragStart={(e) => {
                                e.dataTransfer.setData('text/plain', meal.id);
                                setDraggingMealId(meal.id);
                              }}
                              onDragEnd={() => setDraggingMealId(null)}
                              className="p-2.5 rounded-lg bg-white border border-[#E5DEC9] space-y-1.5"
                            >
                              <div className="flex items-start justify-between gap-1">
                                <span className="text-[11px] text-[#5A635C] capitalize">
                                  {meal.kind.replace('_', ' ')} · {assignedNames}
                                </span>
                                <GripVertical
                                  className="w-3.5 h-3.5 text-[#5A635C] shrink-0 cursor-grab"
                                  aria-hidden="true"
                                />
                              </div>

                              <p className="text-xs font-semibold text-[#1F2421] leading-snug">
                                {meal.title}
                              </p>

                              <div className="flex items-center justify-between text-[11px] text-[#5A635C] tabular-nums">
                                <span>{meal.servings} serv.</span>
                                <div className="flex items-center gap-1">
                                  <button
                                    type="button"
                                    aria-label="Decrease portions"
                                    onClick={() => handleUpdateServings(meal, -1)}
                                    className="w-6 h-6 rounded border border-[#E5DEC9] hover:bg-[#FAF7F2] cursor-pointer"
                                  >
                                    -
                                  </button>
                                  <button
                                    type="button"
                                    aria-label="Increase portions"
                                    onClick={() => handleUpdateServings(meal, 1)}
                                    className="w-6 h-6 rounded border border-[#E5DEC9] hover:bg-[#FAF7F2] cursor-pointer"
                                  >
                                    +
                                  </button>
                                </div>
                              </div>

                              {meal.linked_order_ids.length > 0 && (
                                <p className="text-[10px] text-[#18392B]">
                                  Order #{meal.linked_order_ids[0].slice(-6)} placed (locked)
                                </p>
                              )}

                              {meal.status === 'cooked' && (
                                <p className="text-[11px] font-medium text-[#18392B] inline-flex items-center gap-1">
                                  <Check className="w-3 h-3" />
                                  <span>Cooked</span>
                                </p>
                              )}

                              <div className="flex flex-wrap items-center gap-1 pt-1 border-t border-[#EFE9DC]">
                                <button
                                  type="button"
                                  title="Move meal date or slot"
                                  onClick={() => {
                                    setMovingMeal(meal);
                                    setMoveDate(meal.date);
                                    setMoveSlot(meal.slot);
                                  }}
                                  className="px-2 py-1 rounded text-[11px] text-[#18392B] hover:bg-[#FAF7F2] inline-flex items-center gap-1 cursor-pointer"
                                >
                                  <ArrowLeftRight className="w-3 h-3" />
                                  <span>Move</span>
                                </button>
                                {meal.status !== 'cooked' &&
                                  meal.kind === 'recipe' && (
                                    <button
                                      type="button"
                                      onClick={() => handleOpenCookConfirm(meal)}
                                      className="px-2 py-1 rounded text-[11px] text-[#C85A28] hover:bg-[#FFF4EE] inline-flex items-center gap-1 cursor-pointer"
                                    >
                                      <ChefHat className="w-3 h-3" />
                                      <span>Cook</span>
                                    </button>
                                  )}
                                <button
                                  type="button"
                                  onClick={() => onLogMealFromPlan(meal)}
                                  className="px-2 py-1 rounded text-[11px] text-[#5A635C] hover:bg-[#FAF7F2] inline-flex items-center gap-1 cursor-pointer"
                                >
                                  <Utensils className="w-3 h-3" />
                                  <span>Diary</span>
                                </button>
                                <button
                                  type="button"
                                  aria-label={`Remove ${meal.title}`}
                                  onClick={() => handleDeleteMeal(meal.id)}
                                  className="ml-auto p-1 rounded text-[#5A635C] hover:text-[#B91C1C] cursor-pointer"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Add Meal Modal */}
      {addModalOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/45 flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Add meal to plan"
        >
          <form
            onSubmit={handleAddMealSubmit}
            className="bg-white border border-[#E5DEC9] rounded-xl max-w-md w-full p-6 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h2 className="font-serif text-xl font-semibold text-[#1F2421]">
                Schedule Meal
              </h2>
              <button
                type="button"
                onClick={() => setAddModalOpen(false)}
                className="text-xs text-[#5A635C] hover:text-[#1F2421] cursor-pointer"
              >
                Close
              </button>
            </div>

            <div className="space-y-3 text-sm">
              <div className="grid grid-cols-2 gap-2">
                <label className="space-y-1">
                  <span className="text-xs text-[#5A635C]">Date</span>
                  <select
                    value={addDate}
                    onChange={(e) => setAddDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] bg-white"
                  >
                    {WEEK_DAYS.map((d) => (
                      <option key={d.date} value={d.date}>
                        {d.short}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="space-y-1">
                  <span className="text-xs text-[#5A635C]">Slot</span>
                  <select
                    value={addSlot}
                    onChange={(e) => setAddSlot(e.target.value as MealSlot)}
                    className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] bg-white"
                  >
                    {SLOTS.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </label>
              </div>

              <label className="block space-y-1">
                <span className="text-xs text-[#5A635C]">Meal Type</span>
                <select
                  value={addKind}
                  onChange={(e) =>
                    setAddKind(e.target.value as PlannedMealKind)
                  }
                  className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] bg-white"
                >
                  <option value="recipe">Saved Recipe</option>
                  <option value="simple">Simple Meal (No Recipe)</option>
                  <option value="leftover">Planned Leftovers</option>
                  <option value="eating_out">Eating Out (Restaurant)</option>
                  <option value="takeaway">Takeaway</option>
                </select>
              </label>

              {addKind === 'recipe' ? (
                <label className="block space-y-1">
                  <span className="text-xs text-[#5A635C]">Select Recipe</span>
                  <select
                    value={addRecipeId}
                    onChange={(e) => setAddRecipeId(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] bg-white"
                  >
                    {snapshot.recipes.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.title} ({r.prep_minutes + r.cook_minutes}m)
                      </option>
                    ))}
                  </select>
                </label>
              ) : (
                <label className="block space-y-1">
                  <span className="text-xs text-[#5A635C]">Meal Title</span>
                  <input
                    required
                    value={addTitle}
                    onChange={(e) => setAddTitle(e.target.value)}
                    placeholder="e.g. Leftover Orzo or Thai Takeaway"
                    className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8]"
                  />
                </label>
              )}

              {addKind === 'leftover' && leftoverYieldMeals.length > 0 && (
                <label className="block space-y-1">
                  <span className="text-xs text-[#5A635C]">
                    Leftover Source Meal
                  </span>
                  <select
                    value={addLeftoverSourceId}
                    onChange={(e) => setAddLeftoverSourceId(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] bg-white"
                  >
                    <option value="">Select source meal...</option>
                    {leftoverYieldMeals.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.title} ({m.date} · {m.leftover_portions_yielded} portions)
                      </option>
                    ))}
                  </select>
                </label>
              )}

              <div className="grid grid-cols-2 gap-2">
                <label className="space-y-1">
                  <span className="text-xs text-[#5A635C]">Servings</span>
                  <input
                    type="number"
                    min={1}
                    max={12}
                    value={addServings}
                    onChange={(e) => setAddServings(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8]"
                  />
                </label>
                {addKind === 'recipe' && (
                  <label className="space-y-1">
                    <span className="text-xs text-[#5A635C]">
                      Yields Leftovers
                    </span>
                    <input
                      type="number"
                      min={0}
                      max={8}
                      value={addLeftoverYield}
                      onChange={(e) =>
                        setAddLeftoverYield(Number(e.target.value))
                      }
                      className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8]"
                    />
                  </label>
                )}
              </div>

              <div className="space-y-1">
                <span className="text-xs text-[#5A635C]">Household Members</span>
                <div className="flex flex-wrap gap-3">
                  {snapshot.identity.members.map((m) => (
                    <label
                      key={m.id}
                      className="inline-flex items-center gap-1.5 text-xs"
                    >
                      <input
                        type="checkbox"
                        checked={addMemberIds.includes(m.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setAddMemberIds((p) => [...p, m.id]);
                          } else {
                            setAddMemberIds((p) => p.filter((x) => x !== m.id));
                          }
                        }}
                        className="accent-[#18392B]"
                      />
                      <span>{m.name}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setAddModalOpen(false)}
                className="px-4 py-2 min-h-[40px] rounded-lg border border-[#D4CCB8] text-sm cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 min-h-[40px] rounded-lg bg-[#18392B] text-white text-sm font-semibold cursor-pointer"
              >
                Save to Plan
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Accessible Move Modal */}
      {movingMeal && (
        <div
          className="fixed inset-0 z-50 bg-black/45 flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Move planned meal"
        >
          <div className="bg-white border border-[#E5DEC9] rounded-xl max-w-sm w-full p-6 space-y-4">
            <h2 className="font-serif text-lg font-semibold text-[#1F2421]">
              Move “{movingMeal.title}”
            </h2>
            {movingMeal.linked_order_ids.length > 0 && (
              <p className="text-xs text-[#18392B] bg-[#FAF7F2] p-3 rounded-lg border border-[#E5DEC9]">
                Note: This meal is linked to placed order(s){' '}
                {movingMeal.linked_order_ids.join(', ')}. Moving it will update your plan only and will not alter any existing order.
              </p>
            )}
            <div className="grid grid-cols-2 gap-3 text-sm">
              <label className="space-y-1">
                <span className="text-xs text-[#5A635C]">New Date</span>
                <select
                  value={moveDate}
                  onChange={(e) => setMoveDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] bg-white"
                >
                  {WEEK_DAYS.map((d) => (
                    <option key={d.date} value={d.date}>
                      {d.short}
                    </option>
                  ))}
                </select>
              </label>
              <label className="space-y-1">
                <span className="text-xs text-[#5A635C]">New Slot</span>
                <select
                  value={moveSlot}
                  onChange={(e) => setMoveSlot(e.target.value as MealSlot)}
                  className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] bg-white"
                >
                  {SLOTS.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </label>
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setMovingMeal(null)}
                className="px-4 py-2 min-h-[40px] rounded-lg border border-[#D4CCB8] text-sm cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={async () => {
                  await handleMoveMeal(movingMeal.id, moveDate, moveSlot);
                  setMovingMeal(null);
                }}
                className="px-4 py-2 min-h-[40px] rounded-lg bg-[#18392B] text-white text-sm font-semibold cursor-pointer"
              >
                Confirm Move
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Cook Meal -> Confirm Pantry Deductions Modal */}
      {cookingMeal && (
        <div
          className="fixed inset-0 z-50 bg-black/45 flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Confirm cooked meal and pantry deductions"
        >
          <div className="bg-white border border-[#E5DEC9] rounded-xl max-w-md w-full p-6 space-y-4">
            <h2 className="font-serif text-lg font-semibold text-[#1F2421]">
              Confirm Cooking: {cookingMeal.title}
            </h2>
            <p className="text-xs text-[#5A635C]">
              Confirm actual pantry quantities used. Pantry stock is never deducted automatically without your confirmation.
            </p>
            {cookDeductions.length === 0 ? (
              <p className="text-sm text-[#5A635C]">
                No matching in-stock pantry items need deduction for this meal.
              </p>
            ) : (
              <div className="space-y-2.5 max-h-[240px] overflow-y-auto">
                {cookDeductions.map((d, idx) => (
                  <div
                    key={d.pantry_item_id}
                    className="flex items-center justify-between gap-3 text-xs p-2.5 rounded-lg bg-[#FAF7F2] border border-[#E5DEC9]"
                  >
                    <div>
                      <p className="font-medium text-[#1F2421]">{d.product_name}</p>
                      <p className="text-[#5A635C] tabular-nums">
                        In pantry: {d.available_qty} {d.unit}
                      </p>
                    </div>
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        step="0.5"
                        min={0}
                        max={d.available_qty}
                        value={d.deduct_qty}
                        onChange={(e) => {
                          const val = Number(e.target.value);
                          setCookDeductions((prev) =>
                            prev.map((item, i) =>
                              i === idx ? {...item, deduct_qty: val} : item
                            )
                          );
                        }}
                        className="w-20 px-2 py-1.5 rounded border border-[#D4CCB8] bg-white font-mono tabular-nums text-right"
                      />
                      <span className="text-[#5A635C]">{d.unit}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setCookingMeal(null)}
                className="px-4 py-2 min-h-[40px] rounded-lg border border-[#D4CCB8] text-sm cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmCook}
                className="px-4 py-2 min-h-[40px] rounded-lg bg-[#C85A28] text-white text-sm font-semibold cursor-pointer"
              >
                Confirm Cooked & Update Pantry
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
