'use client';

import {useState} from 'react';
import {
  Barcode,
  Check,
  Clock,
  Minus,
  Plus,
  RefreshCw,
  Trash2,
} from 'lucide-react';
import {
  DateMarkingType,
  PantryItem,
  StorageLocation,
} from '@/lib/domain/types';
import {WorkspaceSnapshot} from './types';

interface Props {
  snapshot: WorkspaceSnapshot;
  onRefresh: (next: WorkspaceSnapshot) => void;
  onNotify: (msg: string, tone?: 'info' | 'warning') => void;
}

export default function PantryManager({
  snapshot,
  onRefresh,
  onNotify,
}: Props) {
  const [locFilter, setLocFilter] = useState<'all' | StorageLocation>('all');
  const [barcodeInput, setBarcodeInput] = useState('5012345678901');
  const [showAddForm, setShowAddForm] = useState(false);

  const [ingId, setIngId] = useState(snapshot.ingredients[0]?.id ?? 'ing_olive_oil');
  const [productName, setProductName] = useState('');
  const [quantity, setQuantity] = useState(250);
  const [unit, setUnit] = useState('g');
  const [storageLoc, setStorageLoc] = useState<StorageLocation>('fridge');
  const [openedDate, setOpenedDate] = useState('2026-11-23');
  const [expiryDate, setExpiryDate] = useState('2026-11-28');
  const [markingType, setMarkingType] = useState<DateMarkingType>('best_before');
  const [sourceAction, setSourceAction] = useState<'manual_add' | 'barcode_lookup'>('manual_add');

  // Correct modal
  const [correctingItem, setCorrectingItem] = useState<PantryItem | null>(null);
  const [correctedQty, setCorrectedQty] = useState<number>(0);

  const filtered = snapshot.pantry.filter(
    (p) => locFilter === 'all' || p.storage_location === locFilter
  );

  const handleBarcodeLookup = async () => {
    try {
      const res = await fetch(
        `/api/pantry?barcode=${encodeURIComponent(barcodeInput)}`
      );
      const data = await res.json();
      if (!data.found) {
        onNotify(
          `No match for barcode ${barcodeInput}. Try 5012345678901, 5010029001123, or 8001420001122.`,
          'warning'
        );
        return;
      }
      const m = data.match;
      setIngId(m.ingredient_id);
      setProductName(m.product_name);
      setQuantity(m.quantity);
      setUnit(m.unit);
      setStorageLoc(m.storage_location);
      setMarkingType(m.date_marking_type);
      setSourceAction('barcode_lookup');
      setShowAddForm(true);
      onNotify(`Barcode matched: ${m.product_name}. Review and save to pantry.`);
    } catch {
      onNotify('Barcode lookup failed', 'warning');
    }
  };

  const handleAddPantry = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/pantry', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          ingredient_id: ingId,
          product_name: productName.trim(),
          barcode: sourceAction === 'barcode_lookup' ? barcodeInput.trim() : null,
          quantity,
          unit,
          storage_location: storageLoc,
          purchase_or_opened_date: openedDate,
          recorded_expiry_date: expiryDate || null,
          date_marking_type: markingType,
          source_action: sourceAction,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      setShowAddForm(false);
      setProductName('');
      onNotify(`Added ${data.item.product_name} to ${data.item.storage_location}.`);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Add failed', 'warning');
    }
  };

  const handleQuickAdjust = async (
    item: PantryItem,
    action: 'consumed' | 'discarded' | 'corrected' | 'replenished',
    amount: number,
    note?: string
  ) => {
    try {
      const res = await fetch('/api/pantry', {
        method: 'PATCH',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          pantry_item_id: item.id,
          action,
          amount,
          note,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      onNotify(`Updated ${item.product_name} (${action}).`);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Adjustment failed', 'warning');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Controls: Barcode Lookup + Manual Add */}
      <div className="bg-white border border-[#E5DEC9] rounded-xl p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2">
            <Barcode className="w-4 h-4 text-[#18392B]" />
            <input
              type="text"
              value={barcodeInput}
              onChange={(e) => setBarcodeInput(e.target.value)}
              placeholder="Barcode (e.g. 5012345678901)"
              aria-label="Barcode lookup"
              className="px-3 py-2 min-h-[40px] text-xs font-mono rounded-lg border border-[#D4CCB8] bg-[#FAF7F2] w-48"
            />
            <button
              type="button"
              onClick={handleBarcodeLookup}
              className="px-3.5 py-2 min-h-[40px] rounded-lg border border-[#18392B] text-[#18392B] text-xs font-semibold hover:bg-[#EFE9DC] cursor-pointer"
            >
              Lookup Barcode
            </button>
          </div>
          <span className="text-[11px] text-[#5A635C]">
            Sample codes: 5012345678901, 5010029001123, 5010029008811
          </span>
        </div>

        <button
          type="button"
          onClick={() => {
            setSourceAction('manual_add');
            setShowAddForm((v) => !v);
          }}
          className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[40px] rounded-lg bg-[#18392B] text-white text-xs font-semibold hover:bg-[#122B20] cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Stock Manually</span>
        </button>
      </div>

      {/* Add Pantry Form */}
      {showAddForm && (
        <form
          onSubmit={handleAddPantry}
          className="bg-white border border-[#18392B]/40 rounded-xl p-5 space-y-4 text-sm"
        >
          <h3 className="font-serif text-lg font-semibold text-[#1F2421]">
            Record Pantry Item ({sourceAction.replace('_', ' ')})
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <label className="space-y-1">
              <span className="text-xs text-[#5A635C]">Ingredient Identity</span>
              <select
                value={ingId}
                onChange={(e) => {
                  setIngId(e.target.value);
                  const found = snapshot.ingredients.find(
                    (i) => i.id === e.target.value
                  );
                  if (found) setUnit(found.default_unit);
                }}
                className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] bg-white text-xs"
              >
                {snapshot.ingredients.map((i) => (
                  <option key={i.id} value={i.id}>
                    {i.canonical_name} ({i.form_variety})
                  </option>
                ))}
              </select>
            </label>
            <label className="space-y-1">
              <span className="text-xs text-[#5A635C]">Product / Label</span>
              <input
                required
                value={productName}
                onChange={(e) => setProductName(e.target.value)}
                placeholder="e.g. Organic Chestnut Mushrooms"
                className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] text-xs"
              />
            </label>
            <div className="grid grid-cols-2 gap-2">
              <label className="space-y-1">
                <span className="text-xs text-[#5A635C]">Quantity</span>
                <input
                  type="number"
                  step="0.5"
                  min={0.5}
                  required
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] text-xs font-mono tabular-nums"
                />
              </label>
              <label className="space-y-1">
                <span className="text-xs text-[#5A635C]">Unit</span>
                <input
                  required
                  value={unit}
                  onChange={(e) => setUnit(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] text-xs"
                />
              </label>
            </div>
            <label className="space-y-1">
              <span className="text-xs text-[#5A635C]">Location</span>
              <select
                value={storageLoc}
                onChange={(e) =>
                  setStorageLoc(e.target.value as StorageLocation)
                }
                className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] bg-white text-xs"
              >
                <option value="fridge">Fridge</option>
                <option value="freezer">Freezer</option>
                <option value="cupboard">Cupboard</option>
              </select>
            </label>
            <label className="space-y-1">
              <span className="text-xs text-[#5A635C]">Purchase / Opened</span>
              <input
                type="date"
                value={openedDate}
                onChange={(e) => setOpenedDate(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] text-xs font-mono"
              />
            </label>
            <label className="space-y-1">
              <span className="text-xs text-[#5A635C]">Recorded Date</span>
              <input
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] text-xs font-mono"
              />
            </label>
            <label className="space-y-1">
              <span className="text-xs text-[#5A635C]">Date Marking Type</span>
              <select
                value={markingType}
                onChange={(e) =>
                  setMarkingType(e.target.value as DateMarkingType)
                }
                className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] bg-white text-xs"
              >
                <option value="best_before">Best before (supplier)</option>
                <option value="use_by">Use by (supplier)</option>
                <option value="user_estimate">User estimate</option>
              </select>
            </label>
            <div className="flex items-end gap-2">
              <button
                type="submit"
                className="px-4 py-2 min-h-[38px] rounded-lg bg-[#C85A28] text-white text-xs font-semibold cursor-pointer"
              >
                Save Item
              </button>
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-3 py-2 min-h-[38px] rounded-lg border border-[#D4CCB8] text-xs cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </form>
      )}

      {/* Safety Notice & Storage Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-1 p-1 bg-white border border-[#E5DEC9] rounded-lg w-fit">
          {(['all', 'fridge', 'freezer', 'cupboard'] as const).map((loc) => (
            <button
              key={loc}
              type="button"
              onClick={() => setLocFilter(loc)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md capitalize cursor-pointer ${
                locFilter === loc
                  ? 'bg-[#18392B] text-white'
                  : 'text-[#5A635C] hover:text-[#1F2421]'
              }`}
            >
              {loc}
            </button>
          ))}
        </div>
        <p className="text-xs text-[#5A635C] inline-flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5 text-[#C85A28]" />
          <span>
            Expiry reminders are based on recorded dates only, not guarantees of food safety.
          </span>
        </p>
      </div>

      {/* Pantry Table */}
      <div className="bg-white border border-[#E5DEC9] rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-[#E5DEC9] bg-[#FAF7F2] text-xs text-[#5A635C]">
                <th className="py-3 px-4 font-semibold">Item</th>
                <th className="py-3 px-4 font-semibold">Location</th>
                <th className="py-3 px-4 font-semibold">Dates</th>
                <th className="py-3 px-4 font-semibold text-right">In Stock</th>
                <th className="py-3 px-4 font-semibold text-right">Reserved</th>
                <th className="py-3 px-4 font-semibold text-right">Quick Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#EFE9DC]">
              {filtered.map((item) => {
                const isLowDate = snapshot.expiring_soon.some(
                  (e) => e.id === item.id
                );
                const step = item.unit === 'g' || item.unit === 'ml' ? 50 : 1;
                return (
                  <tr key={item.id} className="hover:bg-[#FAF7F2]/60">
                    <td className="py-3 px-4">
                      <p className="font-medium text-[#1F2421]">
                        {item.product_name}
                      </p>
                      <p className="text-xs text-[#5A635C]">
                        {item.barcode ? `Barcode ${item.barcode}` : 'Manual record'}
                      </p>
                    </td>
                    <td className="py-3 px-4 capitalize text-xs text-[#5A635C]">
                      {item.storage_location}
                    </td>
                    <td className="py-3 px-4 text-xs">
                      <p className="font-mono tabular-nums text-[#1F2421]">
                        {item.recorded_expiry_date ?? 'No date'}
                      </p>
                      <p
                        className={
                          isLowDate
                            ? 'text-[#C85A28] font-medium'
                            : 'text-[#5A635C]'
                        }
                      >
                        {item.date_marking_type.replace('_', ' ')}
                        {isLowDate ? ' · Approaching' : ''}
                      </p>
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold text-[#18392B]">
                      {item.quantity} {item.unit}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-xs text-[#5A635C]">
                      {item.reserved_quantity} {item.unit}
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          title={`Consume ${step} ${item.unit}`}
                          onClick={() =>
                            handleQuickAdjust(item, 'consumed', step)
                          }
                          className="px-2.5 py-1.5 min-h-[34px] rounded border border-[#D4CCB8] text-xs hover:bg-[#FAF7F2] inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Minus className="w-3 h-3" />
                          <span>Consume</span>
                        </button>
                        <button
                          type="button"
                          title={`Replenish ${step} ${item.unit}`}
                          onClick={() =>
                            handleQuickAdjust(item, 'replenished', step)
                          }
                          className="px-2.5 py-1.5 min-h-[34px] rounded border border-[#D4CCB8] text-xs hover:bg-[#FAF7F2] inline-flex items-center gap-1 cursor-pointer"
                        >
                          <RefreshCw className="w-3 h-3" />
                          <span>Replenish</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setCorrectingItem(item);
                            setCorrectedQty(item.quantity);
                          }}
                          className="px-2.5 py-1.5 min-h-[34px] rounded border border-[#D4CCB8] text-xs hover:bg-[#FAF7F2] cursor-pointer"
                        >
                          Correct
                        </button>
                        <button
                          type="button"
                          title="Discard remaining stock"
                          onClick={() =>
                            handleQuickAdjust(
                              item,
                              'discarded',
                              item.quantity,
                              'Discarded from pantry'
                            )
                          }
                          className="px-2 py-1.5 min-h-[34px] rounded border border-[#D4CCB8] text-xs text-[#B91C1C] hover:bg-[#FEF2F2] cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Audit Log */}
      <section className="bg-white border border-[#E5DEC9] rounded-xl p-5 space-y-3">
        <h3 className="font-serif text-lg font-semibold text-[#1F2421]">
          Recent Pantry Stock Transactions
        </h3>
        <div className="divide-y divide-[#EFE9DC] max-h-[220px] overflow-y-auto text-xs">
          {snapshot.pantry_transactions.slice(0, 12).map((tx) => (
            <div
              key={tx.id}
              className="py-2 flex items-center justify-between gap-4"
            >
              <div>
                <span className="font-semibold capitalize text-[#18392B]">
                  {tx.action.replace('_', ' ')}
                </span>
                <span className="text-[#5A635C]"> · {tx.note}</span>
              </div>
              <span className="font-mono tabular-nums text-[#1F2421] shrink-0">
                {tx.quantity_delta >= 0 ? `+${tx.quantity_delta}` : tx.quantity_delta}{' '}
                {tx.unit}
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* Correct Quantity Modal */}
      {correctingItem && (
        <div
          className="fixed inset-0 z-50 bg-black/45 flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Correct pantry stock quantity"
        >
          <div className="bg-white border border-[#E5DEC9] rounded-xl max-w-sm w-full p-6 space-y-4">
            <h3 className="font-serif text-lg font-semibold text-[#1F2421]">
              Correct Stock: {correctingItem.product_name}
            </h3>
            <label className="block space-y-1 text-sm">
              <span className="text-xs text-[#5A635C]">
                Actual measured quantity ({correctingItem.unit})
              </span>
              <input
                type="number"
                step="0.5"
                min={0}
                value={correctedQty}
                onChange={(e) => setCorrectedQty(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] font-mono tabular-nums"
              />
            </label>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setCorrectingItem(null)}
                className="px-4 py-2 min-h-[40px] rounded-lg border border-[#D4CCB8] text-sm cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={async () => {
                  await handleQuickAdjust(
                    correctingItem,
                    'corrected',
                    correctedQty,
                    'Manual pantry stock count correction'
                  );
                  setCorrectingItem(null);
                }}
                className="px-4 py-2 min-h-[40px] rounded-lg bg-[#18392B] text-white text-sm font-semibold inline-flex items-center gap-1 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>Save Count</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
