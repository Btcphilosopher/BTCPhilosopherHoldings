'use client';

import {useState} from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Lock,
  ShieldAlert,
  ShoppingBag,
  Store,
  Truck,
  Unlock,
} from 'lucide-react';
import {
  BasketStrategy,
  FulfilmentModel,
  SubstitutionPreference,
} from '@/lib/domain/types';
import {formatMoney, WorkspaceSnapshot} from './types';

interface Props {
  snapshot: WorkspaceSnapshot;
  onRefresh: (next: WorkspaceSnapshot) => void;
  onNotify: (msg: string, tone?: 'info' | 'warning') => void;
  onOrderPlaced: () => void;
}

const STRATEGY_LABELS: Record<BasketStrategy, string> = {
  baseline: 'Baseline (Greedy Cheapest Item)',
  lowest_cost: 'Lowest Total (Fee-Adjusted)',
  fewest_merchants: 'Fewest Merchants',
  preferred_merchants: 'Preferred Merchants',
  earliest_delivery: 'Earliest Delivery',
  least_surplus: 'Least Pack Surplus',
};

export default function ShoppingWorkspace({
  snapshot,
  onRefresh,
  onNotify,
  onOrderPlaced,
}: Props) {
  const [strategy, setStrategy] = useState<BasketStrategy>('lowest_cost');
  const [fulfilmentModel, setFulfilmentModel] = useState<FulfilmentModel>(
    snapshot.identity.household.default_fulfilment_model
  );
  const [reserving, setReserving] = useState(false);

  // Checkout drawer / modal state
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [address, setAddress] = useState(
    `${snapshot.identity.household.address_line1}, ${snapshot.identity.household.city}`
  );
  const [postcode, setPostcode] = useState(snapshot.identity.household.postcode);
  const [subPrefs, setSubPrefs] = useState<Record<string, SubstitutionPreference>>({});
  const [selectedSlots, setSelectedSlots] = useState<Record<string, string>>({});
  const [simulatePartialFailureMerchant, setSimulatePartialFailureMerchant] =
    useState<string>('');
  const [idempotencyKey, setIdempotencyKey] = useState(
    () => `chk-${Date.now().toString(36)}`
  );
  const [submittingCheckout, setSubmittingCheckout] = useState(false);

  const comparisons = snapshot.basket_comparisons[fulfilmentModel];
  const activeBasket = comparisons[strategy];

  const handleToggleConfig = async (
    field: 'include_optional' | 'include_garnish' | 'include_pantry_staples',
    value: boolean
  ) => {
    try {
      const res = await fetch('/api/shopping', {
        method: 'PATCH',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({[field]: value}),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Update failed', 'warning');
    }
  };

  const handleLockProduct = async (
    requirementKey: string,
    productId: string | null
  ) => {
    try {
      const res = await fetch('/api/shopping', {
        method: 'PATCH',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          lock_requirement_key: requirementKey,
          lock_product_id: productId,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      onNotify(
        productId
          ? 'Locked product choice for basket recalculation.'
          : 'Unlocked product choice.'
      );
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Lock update failed', 'warning');
    }
  };

  const handleReservePantry = async () => {
    setReserving(true);
    try {
      const res = await fetch('/api/shopping', {method: 'POST'});
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      onNotify(
        `Reserved ${data.reservation.reserved_lines} pantry line(s) transactionally for this week.`
      );
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Reservation failed', 'warning');
    } finally {
      setReserving(false);
    }
  };

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmittingCheckout(true);
    try {
      const groupsPayload = activeBasket.merchant_groups.map((g) => ({
        merchant_id: g.merchant_id,
        fulfilment_model: g.fulfilment_model,
        slot_id: selectedSlots[g.merchant_id] || g.selected_slot_id,
        delivery_fee_minor: g.delivery_fee_minor,
        lines: g.lines.map((l) => ({
          product_id: l.product_id,
          packs_to_buy: l.packs_to_buy,
          substitution_preference: subPrefs[l.product_id] ?? 'require_approval',
          linked_meal_ids:
            snapshot.requirements
              .find((r) => r.key === l.requirement_key)
              ?.contributing_meals.map((c) => c.meal_id) ?? [],
        })),
      }));

      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          idempotency_key: idempotencyKey,
          delivery_address: address,
          delivery_postcode: postcode,
          simulate_partial_failure_merchant_id:
            simulatePartialFailureMerchant || null,
          groups: groupsPayload,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      setCheckoutOpen(false);
      setIdempotencyKey(`chk-${Date.now().toString(36)}`);
      if (data.replayed_idempotency) {
        onNotify('Duplicate checkout prevented via idempotency key — returning existing order.');
      } else if (data.checkout.status === 'partial_failure') {
        onNotify(
          'Parent checkout completed with a partial merchant failure. Review recovery options in Deliveries.',
          'warning'
        );
      } else {
        onNotify('Parent checkout confirmed across merchant orders.');
      }
      onOrderPlaced();
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Checkout failed', 'warning');
    } finally {
      setSubmittingCheckout(false);
    }
  };

  const unavailProducts = snapshot.products.filter(
    (p) => p.availability === 'unavailable'
  );

  return (
    <div className="space-y-6">
      {/* Top Aggregation Config + Fulfilment Model Switch */}
      <div className="bg-white border border-[#E5DEC9] rounded-xl p-5 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <h2 className="font-serif text-xl font-semibold text-[#1F2421]">
              Aggregated Week Requirements & Pantry Deduction
            </h2>
            <p className="text-xs text-[#5A635C]">
              Combines compatible units across planned meals, preserves incompatible forms, subtracts unreserved pantry stock, and links each item to contributing meals.
            </p>
          </div>
          <button
            type="button"
            disabled={reserving}
            onClick={handleReservePantry}
            className="px-4 py-2.5 min-h-[40px] rounded-lg bg-[#18392B] text-white text-xs font-semibold hover:bg-[#122B20] disabled:opacity-60 whitespace-nowrap shrink-0 cursor-pointer"
          >
            {reserving ? 'Reserving...' : 'Reserve Pantry Stock for Week'}
          </button>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 pt-3 border-t border-[#EFE9DC]">
          <div className="flex flex-wrap items-center gap-4 text-xs">
            <label className="inline-flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={snapshot.shopping_config.include_optional}
                onChange={(e) =>
                  handleToggleConfig('include_optional', e.target.checked)
                }
                className="accent-[#18392B]"
              />
              <span>Include optional ingredients</span>
            </label>
            <label className="inline-flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={snapshot.shopping_config.include_garnish}
                onChange={(e) =>
                  handleToggleConfig('include_garnish', e.target.checked)
                }
                className="accent-[#18392B]"
              />
              <span>Include garnish</span>
            </label>
            <label className="inline-flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={snapshot.shopping_config.include_pantry_staples}
                onChange={(e) =>
                  handleToggleConfig('include_pantry_staples', e.target.checked)
                }
                className="accent-[#18392B]"
              />
              <span>Include pantry staples</span>
            </label>
          </div>

          <div className="flex items-center gap-1 p-1 bg-[#FAF7F2] border border-[#E5DEC9] rounded-lg">
            <button
              type="button"
              onClick={() => setFulfilmentModel('separate')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap cursor-pointer ${
                fulfilmentModel === 'separate'
                  ? 'bg-[#18392B] text-white'
                  : 'text-[#5A635C]'
              }`}
            >
              Separate Merchant Deliveries
            </button>
            <button
              type="button"
              onClick={() => setFulfilmentModel('consolidated')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap cursor-pointer ${
                fulfilmentModel === 'consolidated'
                  ? 'bg-[#18392B] text-white'
                  : 'text-[#5A635C]'
              }`}
            >
              Consolidated Hub (Partnered Merchants)
            </button>
          </div>
        </div>
      </div>

      {/* Strategy Comparison Matrix */}
      <section className="bg-white border border-[#E5DEC9] rounded-xl p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="font-serif text-xl font-semibold text-[#1F2421]">
              Basket Optimisation vs. Baseline
            </h2>
            <p className="text-xs text-[#5A635C]">
              Compare transparent baseline greedy picking against 5 constrained strategies. Consolidated delivery only applies to merchants partnered with Aureom Consolidated Hub.
            </p>
          </div>
          <button
            type="button"
            disabled={activeBasket.merchant_groups.length === 0}
            onClick={() => setCheckoutOpen(true)}
            className="inline-flex items-center gap-2 px-5 py-2.5 min-h-[44px] rounded-lg bg-[#C85A28] text-white text-sm font-semibold hover:bg-[#B04C20] disabled:opacity-50 cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>
              Review & Checkout ({formatMoney(activeBasket.total_cost_minor)})
            </span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
          {(Object.keys(STRATEGY_LABELS) as BasketStrategy[]).map((key) => {
            const res = comparisons[key];
            const isActive = strategy === key;
            return (
              <button
                key={key}
                type="button"
                onClick={() => setStrategy(key)}
                className={`text-left p-4 rounded-xl border transition-all cursor-pointer space-y-2 ${
                  isActive
                    ? 'border-[#18392B] bg-[#FAF7F2] ring-2 ring-[#18392B]/20'
                    : 'border-[#E5DEC9] bg-white hover:border-[#18392B]/40'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-[#18392B]">
                    {STRATEGY_LABELS[key]}
                  </span>
                  <span className="font-mono tabular-nums text-base font-bold text-[#1F2421]">
                    {formatMoney(res.total_cost_minor)}
                  </span>
                </div>
                <div className="text-xs text-[#5A635C] tabular-nums">
                  Items {formatMoney(res.items_subtotal_minor)} · Fees{' '}
                  {formatMoney(res.delivery_fees_minor)} · {res.merchants_count}{' '}
                  merchant(s) · {res.total_surplus_items} pack surplus
                </div>
                <p className="text-xs text-[#1F2421] leading-relaxed">
                  {res.trade_off_summary}
                </p>
              </button>
            );
          })}
        </div>
      </section>

      {/* Active Basket Breakdown by Merchant */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-7 space-y-4">
          {activeBasket.merchant_groups.map((group) => (
            <section
              key={group.merchant_id}
              className="bg-white border border-[#E5DEC9] rounded-xl p-5 space-y-4"
            >
              <div className="flex flex-wrap items-start justify-between gap-3 border-b border-[#EFE9DC] pb-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Store className="w-4 h-4 text-[#18392B]" />
                    <h3 className="font-serif text-lg font-semibold text-[#1F2421]">
                      {group.merchant_name}
                    </h3>
                  </div>
                  <p className="text-xs text-[#5A635C]">
                    {group.fulfilment_group_label} · Min order{' '}
                    <span className="font-mono tabular-nums">
                      {formatMoney(group.min_order_minor)}
                    </span>
                  </p>
                </div>
                <div className="text-right font-mono tabular-nums">
                  <p className="text-sm font-semibold text-[#1F2421]">
                    Subtotal {formatMoney(group.subtotal_minor)}
                  </p>
                  <p className="text-xs text-[#5A635C]">
                    Delivery fee {formatMoney(group.delivery_fee_minor)}
                  </p>
                </div>
              </div>

              {!group.meets_minimum && (
                <div className="p-3 rounded-lg bg-[#FFF4EE] border border-[#C85A28]/40 text-xs text-[#8E3511] flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>
                    Below merchant minimum by {formatMoney(group.shortfall_minor)}.
                    Consider switching strategy to Fewest Merchants or locking products into Cotswold Grocer.
                  </span>
                </div>
              )}

              <div className="divide-y divide-[#EFE9DC]">
                {group.lines.map((line) => {
                  const alternatives = snapshot.products.filter(
                    (p) =>
                      p.ingredient_id === line.ingredient_id &&
                      p.pack_unit === line.unit &&
                      p.availability !== 'unavailable'
                  );
                  return (
                    <div key={line.requirement_key} className="py-3 space-y-2">
                      <div className="flex items-start justify-between gap-3">
                        <div className="space-y-0.5">
                          <p className="text-sm font-semibold text-[#1F2421]">
                            {line.product_title}
                          </p>
                          <p className="text-xs text-[#5A635C] tabular-nums">
                            Need {line.remaining_needed} {line.unit} · Buying{' '}
                            {line.packs_to_buy} × {line.pack_quantity} {line.pack_unit} ={' '}
                            {line.total_purchased_qty} {line.pack_unit}
                            {line.expected_surplus_qty > 0 &&
                              ` (+${line.expected_surplus_qty} ${line.pack_unit} surplus)`}
                          </p>
                        </div>
                        <div className="text-right shrink-0">
                          <p className="font-mono tabular-nums text-sm font-semibold text-[#18392B]">
                            {formatMoney(line.line_total_minor)}
                          </p>
                          <button
                            type="button"
                            onClick={() =>
                              handleLockProduct(
                                line.requirement_key,
                                line.locked ? null : line.product_id
                              )
                            }
                            className="inline-flex items-center gap-1 text-[11px] text-[#5A635C] hover:text-[#18392B] cursor-pointer"
                          >
                            {line.locked ? (
                              <>
                                <Lock className="w-3 h-3 text-[#C85A28]" />
                                <span>Locked</span>
                              </>
                            ) : (
                              <>
                                <Unlock className="w-3 h-3" />
                                <span>Lock choice</span>
                              </>
                            )}
                          </button>
                        </div>
                      </div>

                      {alternatives.length > 1 && (
                        <div className="flex flex-wrap items-center gap-2 text-xs">
                          <span className="text-[#5A635C]">Switch & lock:</span>
                          <select
                            value={line.product_id}
                            aria-label={`Select merchant product for ${line.display_name}`}
                            onChange={(e) =>
                              handleLockProduct(
                                line.requirement_key,
                                e.target.value
                              )
                            }
                            className="px-2.5 py-1 rounded border border-[#D4CCB8] bg-[#FAF7F2] text-xs"
                          >
                            {alternatives.map((alt) => {
                              const m = snapshot.merchants.find(
                                (mr) => mr.id === alt.merchant_id
                              );
                              return (
                                <option key={alt.id} value={alt.id}>
                                  {alt.title} ({m?.name} ·{' '}
                                  {formatMoney(alt.price_minor)})
                                </option>
                              );
                            })}
                          </select>
                        </div>
                      )}

                      {line.proposed_substitute && (
                        <div className="p-2.5 rounded-lg bg-[#FFF4EE] border border-[#C85A28]/40 text-xs text-[#8E3511] flex items-start gap-2">
                          <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
                          <span>
                            Low stock warning — proposed substitute:{' '}
                            <strong>{line.proposed_substitute.title}</strong>.{' '}
                            {line.proposed_substitute.safety_note}
                          </span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </section>
          ))}
        </div>

        {/* Right: Requirement Provenance + Feed Freshness & Unavailable Catalogue Notice */}
        <div className="lg:col-span-5 space-y-4">
          <section className="bg-white border border-[#E5DEC9] rounded-xl p-5 space-y-3">
            <h3 className="font-serif text-lg font-semibold text-[#1F2421]">
              Ingredient Provenance & Pantry Offsets
            </h3>
            <div className="divide-y divide-[#EFE9DC] max-h-[380px] overflow-y-auto pr-1">
              {snapshot.requirements.map((req) => (
                <div key={req.key} className="py-2.5 space-y-1 text-xs">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-[#1F2421]">
                      {req.display_name} ({req.form_variety})
                    </span>
                    <span className="font-mono tabular-nums text-[#18392B]">
                      Need {req.total_required} · Pantry -{req.pantry_reserved_here} →{' '}
                      <strong>
                        Buy {req.remaining_to_buy} {req.unit}
                      </strong>
                    </span>
                  </div>
                  <p className="text-[#5A635C]">
                    Meals:{' '}
                    {req.contributing_meals
                      .map(
                        (c) =>
                          `${c.meal_title} (${c.date}: ${c.required_qty} ${c.unit})`
                      )
                      .join('; ')}
                  </p>
                </div>
              ))}
            </div>
          </section>

          <section className="bg-white border border-[#E5DEC9] rounded-xl p-5 space-y-3">
            <h3 className="font-serif text-lg font-semibold text-[#1F2421]">
              Catalogue Feed Freshness & Unavailable Items
            </h3>
            <p className="text-xs text-[#5A635C]">
              Cotswold EDI Feed & Meadowbrook Morning Harvest updated ~2h ago; Alder Daily Stock Sheet updated ~8h ago.
            </p>
            {unavailProducts.length > 0 && (
              <div className="space-y-2 pt-1">
                {unavailProducts.map((up) => (
                  <div
                    key={up.id}
                    className="p-3 rounded-lg bg-[#FAF7F2] border border-[#E5DEC9] text-xs"
                  >
                    <p className="font-semibold text-[#1F2421]">{up.title}</p>
                    <p className="text-[#C85A28]">
                      Currently unavailable ({up.source_name}) — excluded from auto-allocation.
                    </p>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      </div>

      {/* Checkout Modal */}
      {checkoutOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/45 flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Review and complete simulated checkout"
        >
          <form
            onSubmit={handlePlaceOrder}
            className="bg-white border border-[#E5DEC9] rounded-xl max-w-2xl w-full p-6 space-y-5 max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between border-b border-[#EFE9DC] pb-3">
              <div>
                <h2 className="font-serif text-xl font-semibold text-[#1F2421]">
                  Parent Checkout & Merchant Orders
                </h2>
                <p className="text-xs text-[#5A635C] font-mono">
                  Idempotency Key: {idempotencyKey}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setCheckoutOpen(false)}
                className="text-xs text-[#5A635C] hover:text-[#1F2421] cursor-pointer"
              >
                Close
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-sm">
              <label className="sm:col-span-2 space-y-1">
                <span className="text-xs text-[#5A635C]">Delivery Address</span>
                <input
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8]"
                />
              </label>
              <label className="space-y-1">
                <span className="text-xs text-[#5A635C]">UK Postcode</span>
                <input
                  required
                  value={postcode}
                  onChange={(e) => setPostcode(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] font-mono uppercase"
                />
              </label>
            </div>

            <div className="space-y-3">
              <h3 className="text-xs font-semibold text-[#18392B]">
                Merchant Slots & Substitution Preferences
              </h3>
              {activeBasket.merchant_groups.map((g) => {
                const merchant = snapshot.merchants.find(
                  (m) => m.id === g.merchant_id
                )!;
                return (
                  <div
                    key={g.merchant_id}
                    className="p-3.5 rounded-lg bg-[#FAF7F2] border border-[#E5DEC9] space-y-2.5"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2 text-sm font-semibold">
                        <Truck className="w-4 h-4 text-[#18392B]" />
                        <span>{g.merchant_name}</span>
                      </div>
                      <select
                        value={selectedSlots[g.merchant_id] || g.selected_slot_id}
                        onChange={(e) =>
                          setSelectedSlots((prev) => ({
                            ...prev,
                            [g.merchant_id]: e.target.value,
                          }))
                        }
                        className="px-2.5 py-1.5 rounded border border-[#D4CCB8] bg-white text-xs"
                      >
                        {merchant.slots.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.label}
                          </option>
                        ))}
                      </select>
                    </div>
                    <p className="text-xs text-[#5A635C]">
                      {g.fulfilment_group_label} · Subtotal{' '}
                      {formatMoney(g.subtotal_minor)} + Fee{' '}
                      {formatMoney(g.delivery_fee_minor)}
                    </p>
                    <div className="space-y-1.5">
                      {g.lines.map((l) => (
                        <div
                          key={l.product_id}
                          className="flex flex-wrap items-center justify-between gap-2 text-xs"
                        >
                          <span>
                            {l.packs_to_buy}× {l.product_title}
                          </span>
                          <select
                            value={subPrefs[l.product_id] ?? 'require_approval'}
                            onChange={(e) =>
                              setSubPrefs((prev) => ({
                                ...prev,
                                [l.product_id]: e.target
                                  .value as SubstitutionPreference,
                              }))
                            }
                            className="px-2 py-1 rounded border border-[#D4CCB8] bg-white text-[11px]"
                          >
                            <option value="require_approval">
                              Require explicit approval for substitute
                            </option>
                            <option value="allow_equivalent">
                              Allow equivalent (allergen-checked)
                            </option>
                            <option value="refund_if_missing">
                              Refund if unavailable
                            </option>
                          </select>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Optional Partial Merchant Failure Simulation */}
            <div className="p-3.5 rounded-lg border border-[#E5DEC9] bg-[#FAF7F2] space-y-2 text-xs">
              <label className="flex flex-wrap items-center justify-between gap-2">
                <span className="font-semibold text-[#1F2421]">
                  Simulate partial merchant failure (demo):
                </span>
                <select
                  value={simulatePartialFailureMerchant}
                  onChange={(e) =>
                    setSimulatePartialFailureMerchant(e.target.value)
                  }
                  className="px-2.5 py-1.5 rounded border border-[#D4CCB8] bg-white"
                >
                  <option value="">None (All merchants accept)</option>
                  {activeBasket.merchant_groups.map((g) => (
                    <option key={g.merchant_id} value={g.merchant_id}>
                      Fail {g.merchant_name} at gateway
                    </option>
                  ))}
                </select>
              </label>
              <p className="text-[#5A635C]">
                Demonstrates non-atomic checkout: accepted merchants are captured while a failed merchant releases authorisation and offers recovery actions.
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-[#EFE9DC]">
              <div className="text-sm font-mono tabular-nums">
                Authorise Total:{' '}
                <strong className="text-base text-[#18392B]">
                  {formatMoney(activeBasket.total_cost_minor)}
                </strong>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setCheckoutOpen(false)}
                  className="px-4 py-2 min-h-[40px] rounded-lg border border-[#D4CCB8] text-sm cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingCheckout}
                  className="inline-flex items-center gap-2 px-5 py-2 min-h-[40px] rounded-lg bg-[#C85A28] text-white text-sm font-semibold hover:bg-[#B04C20] disabled:opacity-60 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    {submittingCheckout
                      ? 'Authorising...'
                      : 'Confirm Simulated Payment'}
                  </span>
                </button>
              </div>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
