'use client';

import {useState} from 'react';
import {Download, RotateCcw, ShieldCheck, Trash2, UserPlus} from 'lucide-react';
import {formatMoney, WorkspaceSnapshot} from './types';

interface Props {
  snapshot: WorkspaceSnapshot;
  onRefresh: (next: WorkspaceSnapshot) => void;
  onNotify: (msg: string, tone?: 'info' | 'warning') => void;
}

export default function HouseholdSettings({
  snapshot,
  onRefresh,
  onNotify,
}: Props) {
  const hh = snapshot.identity.household;
  const [budgetPounds, setBudgetPounds] = useState(
    (hh.weekly_budget_minor / 100).toFixed(2)
  );
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberAllergens, setNewMemberAllergens] = useState('');
  const [resetting, setResetting] = useState(false);

  const handleUpdateHousehold = async (patch: Record<string, unknown>) => {
    try {
      const res = await fetch('/api/household', {
        method: 'PATCH',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({action: 'update_household', ...patch}),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      onNotify('Updated household preferences.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Update failed', 'warning');
    }
  };

  const handleUpdateMember = async (
    memberId: string,
    patch: Record<string, unknown>
  ) => {
    try {
      const res = await fetch('/api/household', {
        method: 'PATCH',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          action: 'update_member',
          member_id: memberId,
          ...patch,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      onNotify('Updated member dietary rules.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Update failed', 'warning');
    }
  };

  const handleAddMember = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemberName.trim()) return;
    try {
      const res = await fetch('/api/household', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          name: newMemberName.trim(),
          role: 'adult',
          dietary_preferences: [],
          dislikes: [],
          excluded_ingredients: newMemberAllergens
            .split(',')
            .map((s) => s.trim().toLowerCase())
            .filter(Boolean),
          allergens: newMemberAllergens
            .split(',')
            .map((s) => s.trim().toLowerCase())
            .filter(Boolean),
          portion_multiplier: 1.0,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      setNewMemberName('');
      setNewMemberAllergens('');
      onNotify('Added household member.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Add failed', 'warning');
    }
  };

  const handleDeleteMember = async (memberId: string) => {
    try {
      const res = await fetch(
        `/api/household?member_id=${encodeURIComponent(memberId)}`,
        {method: 'DELETE'}
      );
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      onNotify('Removed member account.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Delete failed', 'warning');
    }
  };

  const handleExport = async () => {
    try {
      const res = await fetch('/api/household');
      const data = await res.json();
      const blob = new Blob([JSON.stringify(data, null, 2)], {
        type: 'application/json',
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `aureom-export-${snapshot.identity.active_member.name
        .toLowerCase()
        .replace(/\s+/g, '-')}.json`;
      a.click();
      URL.revokeObjectURL(url);
      onNotify(
        `Exported data visible to ${snapshot.identity.active_member.name} (private entries of other adults excluded).`
      );
    } catch {
      onNotify('Export failed', 'warning');
    }
  };

  const handleResetDemo = async () => {
    setResetting(true);
    try {
      const res = await fetch('/api/workspace', {method: 'POST'});
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      onNotify('Reset demonstration dataset to initial Lin-Mercer state.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Reset failed', 'warning');
    } finally {
      setResetting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Members & Allergen / Dislike Profiles */}
      <section className="bg-white border border-[#E5DEC9] rounded-xl p-6 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="font-serif text-xl font-semibold text-[#1F2421]">
              Household Members & Individual Restrictions
            </h2>
            <p className="text-xs text-[#5A635C]">
              Active member: <strong>{snapshot.identity.active_member.name}</strong> ({snapshot.identity.active_member.role}). Household admins cannot read another adult’s private diary entries.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleExport}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[40px] rounded-lg border border-[#D4CCB8] text-xs font-semibold hover:bg-[#FAF7F2] cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export My Data (JSON)</span>
            </button>
            <button
              type="button"
              disabled={resetting}
              onClick={handleResetDemo}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[40px] rounded-lg border border-[#C85A28] text-[#C85A28] text-xs font-semibold hover:bg-[#FFF4EE] cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{resetting ? 'Resetting...' : 'Reset Demo Data'}</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {snapshot.identity.members.map((member) => {
            const isActive = member.id === snapshot.identity.active_member_id;
            return (
              <div
                key={member.id}
                className={`p-4 rounded-xl border space-y-3 ${
                  isActive
                    ? 'border-[#18392B] bg-[#FAF7F2]'
                    : 'border-[#E5DEC9] bg-white'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <h3 className="font-serif text-lg font-semibold text-[#1F2421]">
                      {member.name}
                    </h3>
                    <p className="text-xs text-[#5A635C] capitalize">
                      {member.role} · Portion scale {member.portion_multiplier}×
                    </p>
                  </div>
                  {!isActive && (
                    <button
                      type="button"
                      onClick={() => handleDeleteMember(member.id)}
                      className="p-2 rounded-lg text-[#5A635C] hover:text-[#B91C1C] cursor-pointer"
                      title="Delete member account"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>

                <div className="space-y-2 text-xs">
                  <label className="block space-y-1">
                    <span className="text-[#5A635C]">
                      Allergens (triggers substitution safety gate)
                    </span>
                    <input
                      defaultValue={member.allergens.join(', ')}
                      onBlur={(e) =>
                        handleUpdateMember(member.id, {
                          allergens: e.target.value
                            .split(',')
                            .map((s) => s.trim().toLowerCase())
                            .filter(Boolean),
                        })
                      }
                      className="w-full px-3 py-1.5 rounded-lg border border-[#D4CCB8] bg-white"
                    />
                  </label>
                  <label className="block space-y-1">
                    <span className="text-[#5A635C]">Dislikes</span>
                    <input
                      defaultValue={member.dislikes.join(', ')}
                      onBlur={(e) =>
                        handleUpdateMember(member.id, {
                          dislikes: e.target.value
                            .split(',')
                            .map((s) => s.trim().toLowerCase())
                            .filter(Boolean),
                        })
                      }
                      className="w-full px-3 py-1.5 rounded-lg border border-[#D4CCB8] bg-white"
                    />
                  </label>
                  <label className="block space-y-1">
                    <span className="text-[#5A635C]">Dietary Preferences</span>
                    <input
                      defaultValue={member.dietary_preferences.join(', ')}
                      onBlur={(e) =>
                        handleUpdateMember(member.id, {
                          dietary_preferences: e.target.value
                            .split(',')
                            .map((s) => s.trim().toLowerCase())
                            .filter(Boolean),
                        })
                      }
                      className="w-full px-3 py-1.5 rounded-lg border border-[#D4CCB8] bg-white"
                    />
                  </label>
                </div>
              </div>
            );
          })}
        </div>

        <form
          onSubmit={handleAddMember}
          className="pt-3 border-t border-[#EFE9DC] flex flex-wrap items-end gap-3 text-xs"
        >
          <label className="space-y-1">
            <span className="text-[#5A635C]">New Member Name</span>
            <input
              value={newMemberName}
              onChange={(e) => setNewMemberName(e.target.value)}
              placeholder="e.g. Samira Patel"
              className="px-3 py-2 rounded-lg border border-[#D4CCB8] bg-white"
            />
          </label>
          <label className="space-y-1">
            <span className="text-[#5A635C]">Allergens (optional)</span>
            <input
              value={newMemberAllergens}
              onChange={(e) => setNewMemberAllergens(e.target.value)}
              placeholder="e.g. tree nuts"
              className="px-3 py-2 rounded-lg border border-[#D4CCB8] bg-white"
            />
          </label>
          <button
            type="submit"
            className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[38px] rounded-lg bg-[#18392B] text-white font-semibold cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>Add Member</span>
          </button>
        </form>
      </section>

      {/* Budget, Privacy, Notifications & Merchant Sharing Controls */}
      <section className="bg-white border border-[#E5DEC9] rounded-xl p-6 space-y-4">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-[#18392B]" />
          <h2 className="font-serif text-xl font-semibold text-[#1F2421]">
            Budget, Privacy & Merchant Data Controls
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
          <div className="space-y-3">
            <label className="block space-y-1">
              <span className="text-xs text-[#5A635C]">
                Weekly Household Budget (GBP) · Currently{' '}
                <span className="font-mono tabular-nums font-semibold">
                  {formatMoney(hh.weekly_budget_minor)}
                </span>
              </span>
              <div className="flex gap-2">
                <input
                  type="number"
                  step="1"
                  min={10}
                  value={budgetPounds}
                  onChange={(e) => setBudgetPounds(e.target.value)}
                  className="px-3 py-2 rounded-lg border border-[#D4CCB8] font-mono tabular-nums w-32"
                />
                <button
                  type="button"
                  onClick={() =>
                    handleUpdateHousehold({
                      weekly_budget_minor: Math.round(
                        Number(budgetPounds) * 100
                      ),
                    })
                  }
                  className="px-4 py-2 rounded-lg border border-[#D4CCB8] text-xs font-semibold hover:bg-[#FAF7F2] cursor-pointer"
                >
                  Update Budget
                </button>
              </div>
            </label>

            <label className="flex items-center gap-2.5 text-xs cursor-pointer">
              <input
                type="checkbox"
                checked={hh.track_calories_in_diary}
                onChange={(e) =>
                  handleUpdateHousehold({
                    track_calories_in_diary: e.target.checked,
                  })
                }
                className="accent-[#18392B]"
              />
              <span>
                Show optional nutrition/calorie estimates in Food Diary (never prescribes targets)
              </span>
            </label>

            <label className="flex items-center gap-2.5 text-xs cursor-pointer">
              <input
                type="checkbox"
                checked={hh.share_delivery_details_with_merchants}
                onChange={(e) =>
                  handleUpdateHousehold({
                    share_delivery_details_with_merchants: e.target.checked,
                  })
                }
                className="accent-[#18392B]"
              />
              <span>
                Share delivery address & slot notes only with merchants in placed orders
              </span>
            </label>
          </div>

          <div className="space-y-2.5 text-xs">
            <p className="font-semibold text-[#18392B]">Notification Preferences</p>
            <label className="flex items-center gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={hh.notification_prefs.expiry_reminders}
                onChange={(e) =>
                  handleUpdateHousehold({
                    notification_prefs: {
                      ...hh.notification_prefs,
                      expiry_reminders: e.target.checked,
                    },
                  })
                }
                className="accent-[#18392B]"
              />
              <span>Recorded expiry date reminders (informational only)</span>
            </label>
            <label className="flex items-center gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={hh.notification_prefs.delivery_updates}
                onChange={(e) =>
                  handleUpdateHousehold({
                    notification_prefs: {
                      ...hh.notification_prefs,
                      delivery_updates: e.target.checked,
                    },
                  })
                }
                className="accent-[#18392B]"
              />
              <span>Merchant order & delivery window notifications</span>
            </label>
            <label className="flex items-center gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={hh.notification_prefs.substitution_alerts}
                onChange={(e) =>
                  handleUpdateHousehold({
                    notification_prefs: {
                      ...hh.notification_prefs,
                      substitution_alerts: e.target.checked,
                    },
                  })
                }
                className="accent-[#18392B]"
              />
              <span>Allergen-gated substitution approval alerts</span>
            </label>
          </div>
        </div>
      </section>
    </div>
  );
}
