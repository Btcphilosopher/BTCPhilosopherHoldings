'use client';

import Image from 'next/image';
import {
  ArrowRight,
  CalendarDays,
  CheckCircle2,
  Clock,
  Package,
  ShoppingBasket,
  Utensils,
} from 'lucide-react';
import {formatMoney, NavSection, WEEK_DAYS, WorkspaceSnapshot} from './types';

interface Props {
  snapshot: WorkspaceSnapshot;
  onNavigate: (section: NavSection) => void;
  onQuickLogMeal: (prefillMealId?: string) => void;
}

export default function HomeOverview({
  snapshot,
  onNavigate,
  onQuickLogMeal,
}: Props) {
  const todayDate = '2026-11-23';
  const todaysMeals = snapshot.planning.meals.filter((m) => m.date === todayDate);
  const stillNeeded = snapshot.requirements.filter(
    (r) => r.remaining_to_buy > 0
  );

  const activeDeliveries = snapshot.checkouts
    .flatMap((c) => c.merchant_orders)
    .filter((o) => o.status !== 'cancelled');

  const estimatedLowestTotal =
    snapshot.basket_comparisons.separate.lowest_cost.total_cost_minor;

  const actualNetCharged = snapshot.checkouts.reduce(
    (sum, c) => sum + (c.total_captured_minor - c.total_refunded_minor),
    0
  );

  const pendingApprovals = activeDeliveries.flatMap((o) =>
    o.lines.filter(
      (l) => l.requires_explicit_approval && l.substitution_status === 'proposed'
    )
  );

  return (
    <div className="space-y-8">
      {/* Editorial Hero Split */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch bg-white border border-[#E5DEC9] rounded-xl overflow-hidden">
        <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between gap-6">
          <div className="space-y-3">
            <p className="text-xs font-medium text-[#5A635C]">
              {snapshot.identity.household.name} · Week of 23 Nov 2026 · Signed in as{' '}
              <span className="text-[#18392B] font-semibold">
                {snapshot.identity.active_member.name}
              </span>
            </p>
            <h1 className="font-serif text-3xl sm:text-4xl font-semibold text-[#1F2421] leading-tight text-balance">
              Plan the week once, shop honestly across local merchants.
            </h1>
            <p className="text-sm sm:text-base text-[#5A635C] max-w-xl leading-relaxed">
              Planned meals, placed merchant orders, confirmed pantry stock, and
              what you actually ate stay cleanly separated so your kitchen record
              always reflects reality.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => onQuickLogMeal()}
              className="inline-flex items-center gap-2 px-5 py-2.5 min-h-[44px] rounded-lg bg-[#C85A28] text-white text-sm font-semibold hover:bg-[#B04C20] transition-colors cursor-pointer"
            >
              <Utensils className="w-4 h-4" />
              <span>Record a Meal</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('shopping')}
              className="inline-flex items-center gap-2 px-4 py-2.5 min-h-[44px] rounded-lg border border-[#D4CCB8] bg-[#FAF7F2] text-[#18392B] text-sm font-medium hover:bg-[#EFE9DC] transition-colors cursor-pointer"
            >
              <ShoppingBasket className="w-4 h-4" />
              <span>Compare Merchant Baskets</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="lg:col-span-5 relative min-h-[220px] lg:min-h-[280px] bg-[#EFE9DC]">
          <Image
            src="/images/hero_kitchen_table.jpg"
            alt="Sunlit oak kitchen table with sourdough loaf, heirloom tomatoes, olive oil, and herbs"
            fill
            priority
            referrerPolicy="no-referrer"
            className="object-cover"
            sizes="(max-width: 1024px) 100vw, 42vw"
          />
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/75 via-black/35 to-transparent p-4">
            <p className="text-xs text-[#FAF7F2]/90">
              Aureom Studio Culinary Archive · Local Asset (hero_kitchen_table.jpg)
            </p>
          </div>
        </div>
      </section>

      {/* 4-Column Weekly Snapshot KPI Strip */}
      <section className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <div className="bg-white border border-[#E5DEC9] rounded-xl p-5 flex flex-col justify-between gap-2">
          <span className="text-xs font-medium text-[#5A635C]">
            Estimated Week Basket (Lowest Fee-Adjusted)
          </span>
          <div className="flex items-baseline justify-between gap-2">
            <span className="font-mono tabular-nums text-2xl font-semibold text-[#1F2421]">
              {formatMoney(estimatedLowestTotal)}
            </span>
            <span className="text-xs text-[#5A635C] tabular-nums">
              Budget {formatMoney(snapshot.planning.current_week.weekly_budget_minor)}
            </span>
          </div>
        </div>

        <div className="bg-white border border-[#E5DEC9] rounded-xl p-5 flex flex-col justify-between gap-2">
          <span className="text-xs font-medium text-[#5A635C]">
            Actual Net Charges (Placed Orders)
          </span>
          <div className="flex items-baseline justify-between gap-2">
            <span className="font-mono tabular-nums text-2xl font-semibold text-[#18392B]">
              {formatMoney(actualNetCharged)}
            </span>
            <span className="text-xs text-[#5A635C] tabular-nums">
              {activeDeliveries.length} merchant order(s)
            </span>
          </div>
        </div>

        <div className="bg-white border border-[#E5DEC9] rounded-xl p-5 flex flex-col justify-between gap-2">
          <span className="text-xs font-medium text-[#5A635C]">
            Ingredients Still Needed
          </span>
          <div className="flex items-baseline justify-between gap-2">
            <span className="font-mono tabular-nums text-2xl font-semibold text-[#1F2421]">
              {stillNeeded.length}
            </span>
            <span className="text-xs text-[#5A635C] tabular-nums">
              of {snapshot.requirements.length} total lines
            </span>
          </div>
        </div>

        <div className="bg-white border border-[#E5DEC9] rounded-xl p-5 flex flex-col justify-between gap-2">
          <span className="text-xs font-medium text-[#5A635C]">
            Action Items
          </span>
          <div className="flex items-baseline justify-between gap-2">
            <span className="font-mono tabular-nums text-2xl font-semibold text-[#C85A28]">
              {pendingApprovals.length + snapshot.expiring_soon.length}
            </span>
            <span className="text-xs text-[#5A635C] tabular-nums">
              {pendingApprovals.length} sub approval · {snapshot.expiring_soon.length} expiry
            </span>
          </div>
        </div>
      </section>

      {/* Main 2-Column Operational Workspace */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        {/* Left: Today's Meals & Weekly Calendar Strip */}
        <div className="xl:col-span-7 space-y-6">
          <section className="bg-white border border-[#E5DEC9] rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between gap-4">
              <div>
                <h2 className="font-serif text-xl font-semibold text-[#1F2421]">
                  Today’s Planned Meals
                </h2>
                <p className="text-xs text-[#5A635C]">
                  Monday 23 November 2026 · Separate from actual food diary logs
                </p>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('week')}
                className="text-xs font-semibold text-[#18392B] hover:underline inline-flex items-center gap-1 min-h-[40px] px-2 cursor-pointer"
              >
                <span>Open Planner</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {todaysMeals.length === 0 ? (
              <p className="text-sm text-[#5A635C] py-4">
                No meals scheduled for today yet. Add a recipe or simple meal in My Week.
              </p>
            ) : (
              <div className="divide-y divide-[#EFE9DC]">
                {todaysMeals.map((meal) => (
                  <div
                    key={meal.id}
                    className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="text-xs text-[#5A635C]">
                        <span className="capitalize font-medium text-[#18392B]">
                          {meal.slot}
                        </span>
                        <span aria-hidden="true"> · </span>
                        <span className="tabular-nums">{meal.servings} servings</span>
                        <span aria-hidden="true"> · </span>
                        <span className="tabular-nums">
                          {meal.prep_minutes + meal.cook_minutes} min total
                        </span>
                      </div>
                      <h3 className="text-base font-semibold text-[#1F2421]">
                        {meal.title}
                      </h3>
                      {meal.notes && (
                        <p className="text-xs text-[#5A635C]">{meal.notes}</p>
                      )}
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => onQuickLogMeal(meal.id)}
                        className="px-3.5 py-2 min-h-[40px] rounded-lg border border-[#D4CCB8] text-xs font-medium text-[#1F2421] hover:bg-[#FAF7F2] transition-colors cursor-pointer"
                      >
                        Log in Diary
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Weekly Meal Strip */}
          <section className="bg-white border border-[#E5DEC9] rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <CalendarDays className="w-4 h-4 text-[#18392B]" />
                <h2 className="font-serif text-xl font-semibold text-[#1F2421]">
                  This Week’s Meal Calendar
                </h2>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('week')}
                className="text-xs font-semibold text-[#18392B] hover:underline cursor-pointer"
              >
                Edit / Drag & Drop
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {WEEK_DAYS.map((day) => {
                const dayMeals = snapshot.planning.meals.filter(
                  (m) => m.date === day.date
                );
                return (
                  <div
                    key={day.date}
                    className="p-3.5 rounded-lg bg-[#FAF7F2] border border-[#E5DEC9] space-y-2"
                  >
                    <div className="text-xs font-semibold text-[#18392B] tabular-nums">
                      {day.short}
                    </div>
                    {dayMeals.length === 0 ? (
                      <p className="text-xs text-[#5A635C]">Open slot</p>
                    ) : (
                      <ul className="space-y-1.5">
                        {dayMeals.map((m) => (
                          <li key={m.id} className="text-xs text-[#1F2421]">
                            <span className="text-[#5A635C] capitalize">
                              {m.slot}:{' '}
                            </span>
                            <span className="font-medium">{m.title}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        </div>

        {/* Right: Ingredients Needed, Deliveries, Expiry Reminders */}
        <div className="xl:col-span-5 space-y-6">
          {/* Ingredients Still Needed */}
          <section className="bg-white border border-[#E5DEC9] rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between gap-4">
              <h2 className="font-serif text-xl font-semibold text-[#1F2421]">
                Ingredients Still Needed
              </h2>
              <button
                type="button"
                onClick={() => onNavigate('shopping')}
                className="text-xs font-semibold text-[#C85A28] hover:underline cursor-pointer"
              >
                Open Basket
              </button>
            </div>
            <div className="divide-y divide-[#EFE9DC] max-h-[240px] overflow-y-auto pr-1">
              {stillNeeded.slice(0, 8).map((req) => (
                <div
                  key={req.key}
                  className="py-2.5 flex items-center justify-between gap-3 text-sm"
                >
                  <div className="min-w-0">
                    <p className="font-medium text-[#1F2421] truncate">
                      {req.display_name}
                    </p>
                    <p className="text-xs text-[#5A635C] truncate">
                      For {req.contributing_meals.map((c) => c.meal_title).join(', ')}
                    </p>
                  </div>
                  <div className="font-mono tabular-nums text-xs font-semibold text-[#18392B] shrink-0">
                    {req.remaining_to_buy} {req.unit}
                  </div>
                </div>
              ))}
            </div>
            {stillNeeded.length > 8 && (
              <p className="text-xs text-[#5A635C]">
                +{stillNeeded.length - 8} more items in Shopping.
              </p>
            )}
          </section>

          {/* Upcoming Deliveries */}
          <section className="bg-white border border-[#E5DEC9] rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <Package className="w-4 h-4 text-[#18392B]" />
                <h2 className="font-serif text-xl font-semibold text-[#1F2421]">
                  Upcoming & Active Deliveries
                </h2>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('deliveries')}
                className="text-xs font-semibold text-[#18392B] hover:underline cursor-pointer"
              >
                Manage
              </button>
            </div>

            {activeDeliveries.length === 0 ? (
              <p className="text-sm text-[#5A635C]">No placed orders yet.</p>
            ) : (
              <div className="space-y-3">
                {activeDeliveries.map((order) => (
                  <div
                    key={order.id}
                    className="p-3.5 rounded-lg bg-[#FAF7F2] border border-[#E5DEC9] space-y-1.5"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-semibold text-[#1F2421]">
                        {order.merchant_name}
                      </span>
                      <span className="font-mono tabular-nums text-xs font-semibold text-[#18392B]">
                        {formatMoney(order.total_minor - order.refunded_minor)}
                      </span>
                    </div>
                    <p className="text-xs text-[#5A635C]">
                      {order.slot_label} · Status:{' '}
                      <span className="font-medium text-[#1F2421] capitalize">
                        {order.status.replaceAll('_', ' ')}
                      </span>
                    </p>
                    {!order.delivery_confirmed_into_pantry && (
                      <p className="text-xs text-[#C85A28] font-medium inline-flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Awaiting pantry quantity confirmation</span>
                      </p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Food Approaching Recorded Expiry Date */}
          <section className="bg-white border border-[#E5DEC9] rounded-xl p-6 space-y-3">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#C85A28]" />
                <h2 className="font-serif text-xl font-semibold text-[#1F2421]">
                  Approaching Recorded Dates
                </h2>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('pantry')}
                className="text-xs font-semibold text-[#18392B] hover:underline cursor-pointer"
              >
                Pantry
              </button>
            </div>
            <p className="text-xs text-[#5A635C]">
              Reminders are based on recorded dates and are not a guarantee of food safety.
            </p>
            {snapshot.expiring_soon.length === 0 ? (
              <p className="text-sm text-[#5A635C]">
                No recorded items approaching expiry within 4 days.
              </p>
            ) : (
              <div className="divide-y divide-[#EFE9DC]">
                {snapshot.expiring_soon.map((item) => (
                  <div
                    key={item.id}
                    className="py-2.5 flex items-center justify-between gap-3 text-sm"
                  >
                    <div>
                      <p className="font-medium text-[#1F2421]">
                        {item.product_name}
                      </p>
                      <p className="text-xs text-[#5A635C]">
                        {item.storage_location} · {item.date_marking_type.replace('_', ' ')}:{' '}
                        <span className="font-mono tabular-nums">
                          {item.recorded_expiry_date}
                        </span>
                      </p>
                    </div>
                    <span className="font-mono tabular-nums text-xs font-semibold text-[#C85A28]">
                      {item.days_until_recorded_date <= 0
                        ? 'Today'
                        : `In ${item.days_until_recorded_date}d`}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}
