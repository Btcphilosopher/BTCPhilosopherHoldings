'use client';

import {useState} from 'react';
import Image from 'next/image';
import {
  AlertTriangle,
  CalendarPlus,
  ChefHat,
  Clock,
  Minus,
  Plus,
  Search,
  UtensilsCrossed,
} from 'lucide-react';
import {Recipe} from '@/lib/domain/types';
import {WEEK_DAYS, WorkspaceSnapshot} from './types';

interface Props {
  snapshot: WorkspaceSnapshot;
  onRefresh: (next: WorkspaceSnapshot) => void;
  onNotify: (msg: string, tone?: 'info' | 'warning') => void;
}

export default function RecipesLibrary({
  snapshot,
  onRefresh,
  onNotify,
}: Props) {
  const [search, setSearch] = useState('');
  const [dietFilter, setDietFilter] = useState<string>('all');
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(
    snapshot.recipes[0] ?? null
  );
  const [scaledServings, setScaledServings] = useState<number>(
    snapshot.recipes[0]?.servings ?? 4
  );
  const [planDate, setPlanDate] = useState(WEEK_DAYS[0].date);
  const [planSlot, setPlanSlot] = useState<'breakfast' | 'lunch' | 'dinner' | 'snack'>('dinner');
  const [addingToPlan, setAddingToPlan] = useState(false);

  // Create recipe modal state
  const [showCreate, setShowCreate] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newServings, setNewServings] = useState(2);
  const [newPrep, setNewPrep] = useState(10);
  const [newCook, setNewCook] = useState(20);
  const [newAllergens, setNewAllergens] = useState('');
  const [newAllergenProv, setNewAllergenProv] = useState('User-entered recipe specification');
  const [newInstructions, setNewInstructions] = useState('1. Prep ingredients.\n2. Cook and serve.');
  const [newIngId, setNewIngId] = useState(snapshot.ingredients[0]?.id ?? 'ing_olive_oil');
  const [newIngQty, setNewIngQty] = useState(200);
  const [newIngUnit, setNewIngUnit] = useState('g');
  const [savingRecipe, setSavingRecipe] = useState(false);

  const filtered = snapshot.recipes.filter((r) => {
    const matchesSearch =
      r.title.toLowerCase().includes(search.toLowerCase()) ||
      r.description.toLowerCase().includes(search.toLowerCase());
    const matchesDiet =
      dietFilter === 'all' ||
      r.dietary_tags.some((t) => t.toLowerCase() === dietFilter.toLowerCase());
    return matchesSearch && matchesDiet;
  });

  const handleSelectRecipe = (recipe: Recipe) => {
    setSelectedRecipe(recipe);
    setScaledServings(recipe.servings);
  };

  const handleAddToWeek = async () => {
    if (!selectedRecipe) return;
    setAddingToPlan(true);
    try {
      const res = await fetch('/api/planning', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          action: 'add_meal',
          date: planDate,
          slot: planSlot,
          kind: 'recipe',
          recipe_id: selectedRecipe.id,
          title: selectedRecipe.title,
          servings: scaledServings,
          assigned_member_ids: snapshot.identity.members.map((m) => m.id),
          prep_minutes: selectedRecipe.prep_minutes,
          cook_minutes: selectedRecipe.cook_minutes,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      onNotify(
        `Added ${selectedRecipe.title} (${scaledServings} servings) to ${planDate} ${planSlot}.`
      );
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Failed to add meal', 'warning');
    } finally {
      setAddingToPlan(false);
    }
  };

  const handleCreateRecipe = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingRecipe(true);
    try {
      const ingMeta = snapshot.ingredients.find((i) => i.id === newIngId);
      const res = await fetch('/api/recipes', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          title: newTitle.trim(),
          description: newDesc.trim(),
          servings: newServings,
          prep_minutes: newPrep,
          cook_minutes: newCook,
          instructions: newInstructions
            .split('\n')
            .map((s) => s.trim())
            .filter(Boolean),
          dietary_tags: ['Home Kitchen'],
          allergens: newAllergens
            .split(',')
            .map((s) => s.trim().toLowerCase())
            .filter(Boolean),
          allergen_provenance: newAllergenProv.trim(),
          ingredients: [
            {
              ingredient_id: newIngId,
              display_name: ingMeta?.canonical_name ?? newIngId,
              form_variety: ingMeta?.form_variety ?? 'standard',
              quantity: newIngQty,
              unit: newIngUnit,
              is_optional: false,
              is_garnish: false,
              is_pantry_staple: Boolean(ingMeta?.is_pantry_staple),
            },
          ],
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      setSelectedRecipe(data.recipe);
      setScaledServings(data.recipe.servings);
      setShowCreate(false);
      setNewTitle('');
      setNewDesc('');
      onNotify(`Saved new recipe: ${data.recipe.title}`);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Failed to save recipe', 'warning');
    } finally {
      setSavingRecipe(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Toolbar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white border border-[#E5DEC9] rounded-xl p-5">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-[#5A635C] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search recipes..."
              aria-label="Search recipes"
              className="pl-9 pr-4 py-2 min-h-[40px] text-sm rounded-lg border border-[#D4CCB8] bg-[#FAF7F2] text-[#1F2421] focus:outline-none focus:ring-2 focus:ring-[#18392B]"
            />
          </div>

          <div className="flex items-center gap-1 p-1 bg-[#FAF7F2] border border-[#E5DEC9] rounded-lg">
            {['all', 'Vegetarian', 'Vegan', 'Pescatarian', 'High-Protein'].map(
              (tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => setDietFilter(tag)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                    dietFilter === tag
                      ? 'bg-[#18392B] text-white'
                      : 'text-[#5A635C] hover:text-[#1F2421]'
                  }`}
                >
                  {tag === 'all' ? 'All Recipes' : tag}
                </button>
              )
            )}
          </div>
        </div>

        <button
          type="button"
          onClick={() => setShowCreate(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 min-h-[44px] rounded-lg bg-[#18392B] text-white text-sm font-semibold hover:bg-[#122B20] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>New Recipe</span>
        </button>
      </div>

      {/* Main Split: Recipe Grid + Recipe Detail */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        <div className="xl:col-span-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
          {filtered.map((recipe) => {
            const isSelected = selectedRecipe?.id === recipe.id;
            return (
              <button
                key={recipe.id}
                type="button"
                onClick={() => handleSelectRecipe(recipe)}
                className={`text-left bg-white rounded-xl overflow-hidden border transition-all cursor-pointer flex flex-col ${
                  isSelected
                    ? 'border-[#18392B] ring-2 ring-[#18392B]/20'
                    : 'border-[#E5DEC9] hover:border-[#18392B]/50'
                }`}
              >
                <div className="relative w-full aspect-[4/3] bg-[#EFE9DC]">
                  <Image
                    src={recipe.image_url}
                    alt={recipe.title}
                    fill
                    referrerPolicy="no-referrer"
                    className="object-cover"
                    sizes="(max-width: 768px) 100vw, 25vw"
                  />
                </div>
                <div className="p-4 space-y-2 flex-1 flex flex-col justify-between">
                  <div className="space-y-1.5">
                    <p className="text-xs text-[#5A635C] tabular-nums">
                      {recipe.prep_minutes + recipe.cook_minutes} min · {recipe.servings} servings ·{' '}
                      {recipe.dietary_tags.join(' · ')}
                    </p>
                    <h3 className="font-serif text-lg font-semibold text-[#1F2421] leading-snug">
                      {recipe.title}
                    </h3>
                    <p className="text-xs text-[#5A635C] line-clamp-2">
                      {recipe.description}
                    </p>
                  </div>
                  <p className="text-[11px] text-[#5A635C] pt-2 border-t border-[#EFE9DC] truncate">
                    {recipe.image_source}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Detail Panel */}
        <div className="xl:col-span-6 bg-white border border-[#E5DEC9] rounded-xl p-6 space-y-6">
          {!selectedRecipe ? (
            <div className="py-12 text-center text-sm text-[#5A635C]">
              Select a recipe card to inspect ingredients, serving scaling, and provenance.
            </div>
          ) : (
            <>
              <div className="space-y-2">
                <div className="flex flex-wrap items-center gap-2 text-xs text-[#5A635C]">
                  <span className="inline-flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    Prep {selectedRecipe.prep_minutes}m · Cook {selectedRecipe.cook_minutes}m
                  </span>
                  <span>·</span>
                  <span>{selectedRecipe.dietary_tags.join(', ')}</span>
                </div>
                <h2 className="font-serif text-2xl font-semibold text-[#1F2421]">
                  {selectedRecipe.title}
                </h2>
                <p className="text-sm text-[#5A635C] leading-relaxed">
                  {selectedRecipe.description}
                </p>
                <p className="text-xs text-[#5A635C]">
                  Photo source: {selectedRecipe.image_source}
                </p>
              </div>

              {/* Serving Scaler + Add to Week */}
              <div className="p-4 rounded-xl bg-[#FAF7F2] border border-[#E5DEC9] space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <span className="text-xs font-semibold text-[#18392B]">
                      Scale Servings
                    </span>
                    <p className="text-xs text-[#5A635C]">
                      Base recipe makes {selectedRecipe.servings} servings
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      aria-label="Decrease servings"
                      onClick={() => setScaledServings((s) => Math.max(1, s - 1))}
                      className="w-10 h-10 rounded-lg border border-[#D4CCB8] bg-white flex items-center justify-center hover:bg-[#EFE9DC] cursor-pointer"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="font-mono tabular-nums text-base font-semibold w-8 text-center">
                      {scaledServings}
                    </span>
                    <button
                      type="button"
                      aria-label="Increase servings"
                      onClick={() => setScaledServings((s) => Math.min(16, s + 1))}
                      className="w-10 h-10 rounded-lg border border-[#D4CCB8] bg-white flex items-center justify-center hover:bg-[#EFE9DC] cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-[#E5DEC9]">
                  <select
                    value={planDate}
                    onChange={(e) => setPlanDate(e.target.value)}
                    aria-label="Target meal date"
                    className="px-3 py-2 min-h-[40px] text-xs rounded-lg border border-[#D4CCB8] bg-white text-[#1F2421]"
                  >
                    {WEEK_DAYS.map((d) => (
                      <option key={d.date} value={d.date}>
                        {d.full}
                      </option>
                    ))}
                  </select>
                  <select
                    value={planSlot}
                    onChange={(e) =>
                      setPlanSlot(
                        e.target.value as 'breakfast' | 'lunch' | 'dinner' | 'snack'
                      )
                    }
                    aria-label="Target meal slot"
                    className="px-3 py-2 min-h-[40px] text-xs rounded-lg border border-[#D4CCB8] bg-white text-[#1F2421]"
                  >
                    <option value="breakfast">Breakfast</option>
                    <option value="lunch">Lunch</option>
                    <option value="dinner">Dinner</option>
                    <option value="snack">Snack</option>
                  </select>
                  <button
                    type="button"
                    disabled={addingToPlan}
                    onClick={handleAddToWeek}
                    className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[40px] rounded-lg bg-[#C85A28] text-white text-xs font-semibold hover:bg-[#B04C20] disabled:opacity-60 cursor-pointer"
                  >
                    <CalendarPlus className="w-4 h-4" />
                    <span>{addingToPlan ? 'Adding...' : 'Add to My Week'}</span>
                  </button>
                </div>
              </div>

              {/* Scaled Ingredient List */}
              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-[#18392B]">
                  Canonical Ingredients (for {scaledServings} servings)
                </h3>
                <ul className="divide-y divide-[#EFE9DC] text-sm">
                  {selectedRecipe.ingredients.map((ing) => {
                    const scaledQty =
                      Math.round(
                        ing.quantity *
                          (scaledServings / selectedRecipe.servings) *
                          100
                      ) / 100;
                    const flags = [
                      ing.form_variety,
                      ing.is_optional ? 'Optional' : null,
                      ing.is_garnish ? 'Garnish' : null,
                      ing.is_pantry_staple ? 'Pantry staple' : null,
                    ].filter(Boolean);
                    return (
                      <li
                        key={ing.id}
                        className="py-2.5 flex items-center justify-between gap-4"
                      >
                        <div>
                          <span className="font-medium text-[#1F2421]">
                            {ing.display_name}
                          </span>
                          <span className="block text-xs text-[#5A635C]">
                            {flags.join(' · ')}
                          </span>
                        </div>
                        <span className="font-mono tabular-nums text-xs font-semibold text-[#18392B] shrink-0">
                          {scaledQty} {ing.unit}
                        </span>
                      </li>
                    );
                  })}
                </ul>
              </div>

              {/* Instructions */}
              <div className="space-y-2">
                <h3 className="text-sm font-semibold text-[#18392B] flex items-center gap-1.5">
                  <ChefHat className="w-4 h-4" />
                  <span>Method</span>
                </h3>
                <ol className="space-y-2 text-sm text-[#1F2421] list-decimal list-inside">
                  {selectedRecipe.instructions.map((step, i) => (
                    <li key={i} className="leading-relaxed">
                      {step}
                    </li>
                  ))}
                </ol>
              </div>

              {/* Allergen Provenance, Nutrition Source & Storage */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-[#EFE9DC] text-xs">
                <div className="space-y-1">
                  <p className="font-semibold text-[#1F2421] inline-flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5 text-[#C85A28]" />
                    <span>
                      Allergens:{' '}
                      {selectedRecipe.allergens.length > 0
                        ? selectedRecipe.allergens.join(', ')
                        : 'None declared'}
                    </span>
                  </p>
                  <p className="text-[#5A635C]">
                    {selectedRecipe.allergen_provenance}
                  </p>
                </div>

                {selectedRecipe.nutrition_per_serving && (
                  <div className="space-y-1">
                    <p className="font-semibold text-[#1F2421] tabular-nums">
                      Nutrition / serving: {selectedRecipe.nutrition_per_serving.kcal} kcal ·{' '}
                      {selectedRecipe.nutrition_per_serving.protein_g}g protein
                    </p>
                    <p className="text-[#5A635C]">
                      {selectedRecipe.nutrition_per_serving.source} (
                      {selectedRecipe.nutrition_per_serving.is_verified
                        ? 'Verified product data'
                        : 'Estimated'}
                      )
                    </p>
                  </div>
                )}

                {(selectedRecipe.storage_notes || selectedRecipe.leftover_notes) && (
                  <div className="sm:col-span-2 space-y-1 pt-2 border-t border-[#EFE9DC]">
                    {selectedRecipe.storage_notes && (
                      <p className="text-[#5A635C]">
                        <span className="font-semibold text-[#1F2421]">Storage: </span>
                        {selectedRecipe.storage_notes}
                      </p>
                    )}
                    {selectedRecipe.leftover_notes && (
                      <p className="text-[#5A635C]">
                        <span className="font-semibold text-[#1F2421]">Leftovers: </span>
                        {selectedRecipe.leftover_notes}
                      </p>
                    )}
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Create Recipe Modal */}
      {showCreate && (
        <div
          className="fixed inset-0 z-50 bg-black/45 flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Create new recipe"
        >
          <form
            onSubmit={handleCreateRecipe}
            className="bg-white border border-[#E5DEC9] rounded-xl max-w-lg w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between">
              <h2 className="font-serif text-xl font-semibold text-[#1F2421] flex items-center gap-2">
                <UtensilsCrossed className="w-5 h-5 text-[#18392B]" />
                <span>Create Recipe</span>
              </h2>
              <button
                type="button"
                onClick={() => setShowCreate(false)}
                className="text-sm text-[#5A635C] hover:text-[#1F2421] px-2 py-1 cursor-pointer"
              >
                Close
              </button>
            </div>

            <div className="space-y-3 text-sm">
              <label className="block space-y-1">
                <span className="text-xs font-medium text-[#5A635C]">Title</span>
                <input
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Lemon Garlic Chickpea Skillet"
                  className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8]"
                />
              </label>

              <label className="block space-y-1">
                <span className="text-xs font-medium text-[#5A635C]">Description</span>
                <textarea
                  required
                  rows={2}
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8]"
                />
              </label>

              <div className="grid grid-cols-3 gap-3">
                <label className="block space-y-1">
                  <span className="text-xs font-medium text-[#5A635C]">Servings</span>
                  <input
                    type="number"
                    min={1}
                    max={20}
                    value={newServings}
                    onChange={(e) => setNewServings(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8]"
                  />
                </label>
                <label className="block space-y-1">
                  <span className="text-xs font-medium text-[#5A635C]">Prep (min)</span>
                  <input
                    type="number"
                    min={0}
                    value={newPrep}
                    onChange={(e) => setNewPrep(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8]"
                  />
                </label>
                <label className="block space-y-1">
                  <span className="text-xs font-medium text-[#5A635C]">Cook (min)</span>
                  <input
                    type="number"
                    min={0}
                    value={newCook}
                    onChange={(e) => setNewCook(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8]"
                  />
                </label>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <label className="sm:col-span-2 block space-y-1">
                  <span className="text-xs font-medium text-[#5A635C]">
                    Primary Ingredient
                  </span>
                  <select
                    value={newIngId}
                    onChange={(e) => setNewIngId(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] bg-white"
                  >
                    {snapshot.ingredients.map((i) => (
                      <option key={i.id} value={i.id}>
                        {i.canonical_name} ({i.default_unit})
                      </option>
                    ))}
                  </select>
                </label>
                <div className="grid grid-cols-2 gap-1.5">
                  <label className="block space-y-1">
                    <span className="text-xs font-medium text-[#5A635C]">Qty</span>
                    <input
                      type="number"
                      min={1}
                      value={newIngQty}
                      onChange={(e) => setNewIngQty(Number(e.target.value))}
                      className="w-full px-2 py-2 rounded-lg border border-[#D4CCB8]"
                    />
                  </label>
                  <label className="block space-y-1">
                    <span className="text-xs font-medium text-[#5A635C]">Unit</span>
                    <input
                      value={newIngUnit}
                      onChange={(e) => setNewIngUnit(e.target.value)}
                      className="w-full px-2 py-2 rounded-lg border border-[#D4CCB8]"
                    />
                  </label>
                </div>
              </div>

              <label className="block space-y-1">
                <span className="text-xs font-medium text-[#5A635C]">
                  Allergens (comma-separated)
                </span>
                <input
                  value={newAllergens}
                  onChange={(e) => setNewAllergens(e.target.value)}
                  placeholder="e.g. dairy, sesame"
                  className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8]"
                />
              </label>

              <label className="block space-y-1">
                <span className="text-xs font-medium text-[#5A635C]">
                  Allergen Provenance
                </span>
                <input
                  required
                  value={newAllergenProv}
                  onChange={(e) => setNewAllergenProv(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8]"
                />
              </label>

              <label className="block space-y-1">
                <span className="text-xs font-medium text-[#5A635C]">
                  Instructions (one per line)
                </span>
                <textarea
                  rows={3}
                  value={newInstructions}
                  onChange={(e) => setNewInstructions(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8]"
                />
              </label>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowCreate(false)}
                className="px-4 py-2 min-h-[40px] rounded-lg border border-[#D4CCB8] text-sm cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={savingRecipe}
                className="px-4 py-2 min-h-[40px] rounded-lg bg-[#18392B] text-white text-sm font-semibold hover:bg-[#122B20] cursor-pointer"
              >
                {savingRecipe ? 'Saving...' : 'Save Recipe'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
