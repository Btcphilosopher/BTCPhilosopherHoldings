import {
  AggregatedRequirement,
  BasketAllocationResult,
  BasketStrategy,
  FoodDiaryEntry,
  FulfilmentModel,
  Household,
  HouseholdMember,
  IngredientIdentity,
  MealPlanWeek,
  Merchant,
  MerchantProduct,
  PantryItem,
  PantryTransaction,
  ParentCheckout,
  PlannedMeal,
  Recipe,
} from '@/lib/domain/types';

export type NavSection =
  | 'home'
  | 'week'
  | 'recipes'
  | 'shopping'
  | 'pantry'
  | 'deliveries'
  | 'diary'
  | 'household';

export interface WorkspaceSnapshot {
  identity: {
    household: Household;
    members: HouseholdMember[];
    active_member_id: string;
    active_member: HouseholdMember;
  };
  ingredients: IngredientIdentity[];
  recipes: Recipe[];
  planning: {
    current_week: MealPlanWeek;
    templates: MealPlanWeek[];
    meals: PlannedMeal[];
  };
  pantry: PantryItem[];
  pantry_transactions: PantryTransaction[];
  expiring_soon: Array<PantryItem & {days_until_recorded_date: number}>;
  merchants: Merchant[];
  products: MerchantProduct[];
  shopping_config: {
    include_optional: boolean;
    include_garnish: boolean;
    include_pantry_staples: boolean;
    locked_assignments: Record<string, string>;
  };
  requirements: AggregatedRequirement[];
  basket_comparisons: {
    separate: Record<BasketStrategy, BasketAllocationResult>;
    consolidated: Record<BasketStrategy, BasketAllocationResult>;
  };
  checkouts: ParentCheckout[];
  diary: FoodDiaryEntry[];
}

export function formatMoney(minor: number): string {
  const sign = minor < 0 ? '-' : '';
  return `${sign}£${(Math.abs(minor) / 100).toFixed(2)}`;
}

export const WEEK_DAYS: Array<{date: string; short: string; full: string}> = [
  {date: '2026-11-23', short: 'Mon 23', full: 'Monday 23 Nov'},
  {date: '2026-11-24', short: 'Tue 24', full: 'Tuesday 24 Nov'},
  {date: '2026-11-25', short: 'Wed 25', full: 'Wednesday 25 Nov'},
  {date: '2026-11-26', short: 'Thu 26', full: 'Thursday 26 Nov'},
  {date: '2026-11-27', short: 'Fri 27', full: 'Friday 27 Nov'},
  {date: '2026-11-28', short: 'Sat 28', full: 'Saturday 28 Nov'},
  {date: '2026-11-29', short: 'Sun 29', full: 'Sunday 29 Nov'},
];

export function formatSlotLabel(slot: string): string {
  return slot.charAt(0).toUpperCase() + slot.slice(1);
}

export function getFulfilmentLabel(model: FulfilmentModel): string {
  return model === 'consolidated'
    ? 'Consolidated Hub (where partnered)'
    : 'Separate Merchant Deliveries';
}
