'use client';

import {useState} from 'react';
import {AnimatePresence, motion} from 'motion/react';
import {
  Archive,
  BookOpen,
  CalendarDays,
  Home,
  Menu,
  NotebookPen,
  ShoppingBasket,
  Truck,
  Users,
  Utensils,
  X,
} from 'lucide-react';
import {PlannedMeal} from '@/lib/domain/types';
import {NavSection, WorkspaceSnapshot} from './types';
import HomeOverview from './HomeOverview';
import WeeklyPlanner from './WeeklyPlanner';
import RecipesLibrary from './RecipesLibrary';
import ShoppingWorkspace from './ShoppingWorkspace';
import PantryManager from './PantryManager';
import DeliveriesLedger from './DeliveriesLedger';
import FoodDiaryView from './FoodDiaryView';
import HouseholdSettings from './HouseholdSettings';

interface Props {
  initialSnapshot: WorkspaceSnapshot;
}

const NAV_ITEMS: Array<{
  id: NavSection;
  label: string;
  icon: React.ComponentType<{className?: string}>;
}> = [
  {id: 'home', label: 'Home', icon: Home},
  {id: 'week', label: 'My Week', icon: CalendarDays},
  {id: 'recipes', label: 'Recipes', icon: BookOpen},
  {id: 'shopping', label: 'Shopping', icon: ShoppingBasket},
  {id: 'pantry', label: 'Pantry', icon: Archive},
  {id: 'deliveries', label: 'Deliveries', icon: Truck},
  {id: 'diary', label: 'Food Diary', icon: NotebookPen},
  {id: 'household', label: 'Household', icon: Users},
];

export default function AureomApp({initialSnapshot}: Props) {
  const [snapshot, setSnapshot] = useState<WorkspaceSnapshot>(initialSnapshot);
  const [section, setSection] = useState<NavSection>('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [diaryPrefillMealId, setDiaryPrefillMealId] = useState<string | null>(
    null
  );
  const [toast, setToast] = useState<{
    message: string;
    tone: 'info' | 'warning';
  } | null>(null);

  const notify = (message: string, tone: 'info' | 'warning' = 'info') => {
    setToast({message, tone});
  };

  const handleSwitchMember = async (memberId: string) => {
    try {
      const res = await fetch('/api/household', {
        method: 'PATCH',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({action: 'switch_member', member_id: memberId}),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setSnapshot(data.snapshot);
      notify(
        `Switched active household member to ${data.snapshot.identity.active_member.name}. Private diary entries updated.`
      );
    } catch (err) {
      notify(
        err instanceof Error ? err.message : 'Failed to switch member',
        'warning'
      );
    }
  };

  const handleQuickLogMeal = (prefillMealId?: string) => {
    setDiaryPrefillMealId(prefillMealId ?? null);
    setSection('diary');
  };

  const handleLogMealFromPlan = (meal: PlannedMeal) => {
    setDiaryPrefillMealId(meal.id);
    setSection('diary');
  };

  const currentNav = NAV_ITEMS.find((n) => n.id === section) ?? NAV_ITEMS[0];

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-[#FAF7F2] text-[#1F2421]">
      {/* Desktop Forest-Green Navigation Sidebar */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:shrink-0 bg-[#18392B] text-[#FAF7F2] min-h-screen sticky top-0 max-h-screen">
        <div className="px-6 py-6 border-b border-white/10">
          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              setSection('home');
            }}
            className="font-serif text-2xl font-semibold tracking-tight text-[#FAF7F2] whitespace-nowrap block"
          >
            Aureom Table
          </a>
        </div>

        <nav
          aria-label="Primary kitchen navigation"
          className="flex-1 px-3 py-5 space-y-1 overflow-y-auto"
        >
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = section === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setSection(item.id)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 min-h-[44px] rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                  active
                    ? 'bg-[#C85A28] text-white'
                    : 'text-[#E8EFEA]/85 hover:bg-white/10 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-white/10 text-xs text-[#E8EFEA]/75 space-y-1">
          <p className="font-medium text-[#FAF7F2]">
            {snapshot.identity.household.name}
          </p>
          <p>
            {snapshot.identity.household.city} ·{' '}
            {snapshot.identity.household.postcode}
          </p>
        </div>
      </aside>

      {/* Mobile Header (compact single row, <= 56px, well under 15% mobile sticky cap) */}
      <header className="lg:hidden sticky top-0 z-40 h-14 bg-[#18392B] text-[#FAF7F2] px-4 flex items-center justify-between gap-4">
        <button
          type="button"
          onClick={() => setSection('home')}
          className="font-serif text-lg font-semibold whitespace-nowrap cursor-pointer"
        >
          Aureom Table
        </button>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => handleQuickLogMeal()}
            className="px-3 py-1.5 min-h-[36px] rounded-lg bg-[#C85A28] text-white text-xs font-semibold whitespace-nowrap cursor-pointer"
          >
            Log Meal
          </button>
          <button
            type="button"
            aria-label="Toggle navigation menu"
            onClick={() => setMobileMenuOpen((v) => !v)}
            className="w-10 h-10 rounded-lg hover:bg-white/10 flex items-center justify-center cursor-pointer"
          >
            {mobileMenuOpen ? (
              <X className="w-5 h-5" />
            ) : (
              <Menu className="w-5 h-5" />
            )}
          </button>
        </div>
      </header>

      {/* Mobile Slide-down Menu */}
      {mobileMenuOpen && (
        <nav
          aria-label="Mobile navigation"
          className="lg:hidden bg-[#18392B] text-[#FAF7F2] px-4 pb-4 space-y-1 border-t border-white/10"
        >
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = section === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setSection(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 min-h-[44px] rounded-lg text-sm font-medium cursor-pointer ${
                  active ? 'bg-[#C85A28] text-white' : 'text-[#E8EFEA]'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      )}

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Workspace Top Bar (3-zone contract: Breadcrumb/Title — Member Switcher — Primary CTA) */}
        <div className="bg-white border-b border-[#E5DEC9] px-5 sm:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-sm">
            <span className="text-[#5A635C]">Kitchen</span>
            <span className="text-[#5A635C]" aria-hidden="true">
              /
            </span>
            <span className="font-serif text-lg font-semibold text-[#1F2421]">
              {currentNav.label}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2 text-xs text-[#5A635C]">
              <span className="hidden sm:inline">Member:</span>
              <select
                aria-label="Active household member"
                value={snapshot.identity.active_member_id}
                onChange={(e) => handleSwitchMember(e.target.value)}
                className="px-3 py-1.5 min-h-[38px] rounded-lg border border-[#D4CCB8] bg-[#FAF7F2] text-xs font-medium text-[#1F2421] cursor-pointer"
              >
                {snapshot.identity.members.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name} ({m.role})
                  </option>
                ))}
              </select>
            </label>

            <button
              type="button"
              onClick={() => handleQuickLogMeal()}
              className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2 min-h-[38px] rounded-lg bg-[#C85A28] text-white text-xs font-semibold hover:bg-[#B04C20] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Utensils className="w-3.5 h-3.5" />
              <span>Quick Log Meal</span>
            </button>
          </div>
        </div>

        {/* Dismissible Notice / Feedback Banner */}
        {toast && (
          <div
            role="status"
            className={`mx-5 sm:mx-8 mt-4 px-4 py-3 rounded-lg border text-xs flex items-center justify-between gap-4 ${
              toast.tone === 'warning'
                ? 'bg-[#FFF4EE] border-[#C85A28]/50 text-[#8E3511]'
                : 'bg-white border-[#18392B]/30 text-[#18392B]'
            }`}
          >
            <span>{toast.message}</span>
            <button
              type="button"
              onClick={() => setToast(null)}
              className="font-semibold underline cursor-pointer shrink-0"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Active Viewport */}
        <main className="flex-1 p-5 sm:p-8 max-w-[1320px] w-full mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={section}
              initial={{opacity: 0, y: 6}}
              animate={{opacity: 1, y: 0}}
              exit={{opacity: 0, y: -4}}
              transition={{duration: 0.16, ease: [0.16, 1, 0.3, 1]}}
            >
              {section === 'home' && (
                <HomeOverview
                  snapshot={snapshot}
                  onNavigate={setSection}
                  onQuickLogMeal={handleQuickLogMeal}
                />
              )}
              {section === 'week' && (
                <WeeklyPlanner
                  snapshot={snapshot}
                  onRefresh={setSnapshot}
                  onNotify={notify}
                  onLogMealFromPlan={handleLogMealFromPlan}
                />
              )}
              {section === 'recipes' && (
                <RecipesLibrary
                  snapshot={snapshot}
                  onRefresh={setSnapshot}
                  onNotify={notify}
                />
              )}
              {section === 'shopping' && (
                <ShoppingWorkspace
                  snapshot={snapshot}
                  onRefresh={setSnapshot}
                  onNotify={notify}
                  onOrderPlaced={() => setSection('deliveries')}
                />
              )}
              {section === 'pantry' && (
                <PantryManager
                  snapshot={snapshot}
                  onRefresh={setSnapshot}
                  onNotify={notify}
                />
              )}
              {section === 'deliveries' && (
                <DeliveriesLedger
                  snapshot={snapshot}
                  onRefresh={setSnapshot}
                  onNotify={notify}
                />
              )}
              {section === 'diary' && (
                <FoodDiaryView
                  snapshot={snapshot}
                  onRefresh={setSnapshot}
                  onNotify={notify}
                  prefillPlannedMealId={diaryPrefillMealId}
                />
              )}
              {section === 'household' && (
                <HouseholdSettings
                  snapshot={snapshot}
                  onRefresh={setSnapshot}
                  onNotify={notify}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
