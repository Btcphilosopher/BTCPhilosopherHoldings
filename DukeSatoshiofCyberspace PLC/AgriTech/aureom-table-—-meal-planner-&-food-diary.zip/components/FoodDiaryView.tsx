'use client';

import {useState} from 'react';
import Image from 'next/image';
import {Camera, Lock, Plus, Trash2, Users} from 'lucide-react';
import {DiaryEntrySource, DiaryVisibility} from '@/lib/domain/types';
import {WorkspaceSnapshot} from './types';

interface Props {
  snapshot: WorkspaceSnapshot;
  onRefresh: (next: WorkspaceSnapshot) => void;
  onNotify: (msg: string, tone?: 'info' | 'warning') => void;
  prefillPlannedMealId?: string | null;
}

export default function FoodDiaryView({
  snapshot,
  onRefresh,
  onNotify,
  prefillPlannedMealId,
}: Props) {
  const prefilledMeal = prefillPlannedMealId
    ? snapshot.planning.meals.find((m) => m.id === prefillPlannedMealId)
    : null;

  const [source, setSource] = useState<DiaryEntrySource>(
    prefilledMeal ? 'planned_meal' : 'manual'
  );
  const [plannedMealId, setPlannedMealId] = useState<string>(
    prefilledMeal?.id ?? snapshot.planning.meals[0]?.id ?? ''
  );
  const [recipeId, setRecipeId] = useState<string>(
    snapshot.recipes[0]?.id ?? ''
  );
  const [productId, setProductId] = useState<string>(
    snapshot.products[0]?.id ?? ''
  );
  const [title, setTitle] = useState(
    prefilledMeal?.title ?? ''
  );
  const [date, setDate] = useState('2026-11-23');
  const [time, setTime] = useState('19:30');
  const [portionLabel, setPortionLabel] = useState('1 regular portion');
  const [visibility, setVisibility] = useState<DiaryVisibility>('private');
  const [differed, setDiffered] = useState(false);
  const [diffReason, setDiffReason] = useState('');
  const [satisfaction, setSatisfaction] = useState<number>(4);
  const [hungerNote, setHungerNote] = useState('');
  const [practicalNotes, setPracticalNotes] = useState('');
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 1_500_000) {
      onNotify('Please pick an image under 1.5 MB.', 'warning');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setPhotoUrl(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      let resolvedTitle = title.trim();
      let resolvedRecipeId: string | null = null;
      let resolvedMealId: string | null = null;
      let resolvedProductId: string | null = null;
      let nutritionSummary = null;

      if (source === 'planned_meal') {
        const m = snapshot.planning.meals.find((x) => x.id === plannedMealId);
        resolvedMealId = m?.id ?? null;
        resolvedRecipeId = m?.recipe_id ?? null;
        if (!resolvedTitle && m) resolvedTitle = m.title;
      } else if (source === 'recipe') {
        const r = snapshot.recipes.find((x) => x.id === recipeId);
        resolvedRecipeId = r?.id ?? null;
        if (!resolvedTitle && r) resolvedTitle = r.title;
        if (r?.nutrition_per_serving && snapshot.identity.household.track_calories_in_diary) {
          nutritionSummary = {
            kcal: r.nutrition_per_serving.kcal,
            protein_g: r.nutrition_per_serving.protein_g,
            source: r.nutrition_per_serving.source,
            is_verified: r.nutrition_per_serving.is_verified,
          };
        }
      } else if (source === 'product') {
        const p = snapshot.products.find((x) => x.id === productId);
        resolvedProductId = p?.id ?? null;
        if (!resolvedTitle && p) resolvedTitle = p.title;
        if (p?.nutrition_summary && snapshot.identity.household.track_calories_in_diary) {
          nutritionSummary = {
            kcal: p.nutrition_summary.kcal_per_100g ?? 0,
            protein_g: p.nutrition_summary.protein_g,
            source: `${p.nutrition_summary.source} (per 100g)`,
            is_verified: p.nutrition_verified,
          };
        }
      }

      if (!resolvedTitle) {
        throw new Error('Please enter what you ate.');
      }

      const res = await fetch('/api/diary', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          visibility,
          source,
          planned_meal_id: resolvedMealId,
          recipe_id: resolvedRecipeId,
          product_id: resolvedProductId,
          title: resolvedTitle,
          date,
          time,
          portion_label: portionLabel,
          differed_from_plan: differed,
          difference_reason: differed ? diffReason || null : null,
          satisfaction,
          hunger_note: hungerNote || null,
          practical_notes: practicalNotes || null,
          photo_url: photoUrl,
          nutrition_summary: nutritionSummary,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      setTitle('');
      setDiffReason('');
      setHungerNote('');
      setPracticalNotes('');
      setPhotoUrl(null);
      onNotify(
        `Logged "${data.entry.title}" (${data.entry.visibility} entry for ${snapshot.identity.active_member.name}).`
      );
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Failed to log meal', 'warning');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (entryId: string) => {
    try {
      const res = await fetch(
        `/api/diary?entry_id=${encodeURIComponent(entryId)}`,
        {method: 'DELETE'}
      );
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      onNotify('Deleted diary entry.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Delete failed', 'warning');
    }
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
      {/* Left: Record Actual Meal Form */}
      <form
        onSubmit={handleSubmit}
        className="xl:col-span-5 bg-white border border-[#E5DEC9] rounded-xl p-6 space-y-4 text-sm"
      >
        <div className="space-y-1">
          <h2 className="font-serif text-xl font-semibold text-[#1F2421]">
            Record What You Actually Ate
          </h2>
          <p className="text-xs text-[#5A635C]">
            Recording as <strong>{snapshot.identity.active_member.name}</strong>. Private entries remain invisible to other household members, including admins.
          </p>
        </div>

        <div className="flex flex-wrap gap-1 p-1 bg-[#FAF7F2] border border-[#E5DEC9] rounded-lg">
          {(
            [
              ['planned_meal', 'Planned Meal'],
              ['recipe', 'Recipe'],
              ['manual', 'Manual'],
              ['product', 'Product'],
              ['photo', 'Photo'],
            ] as Array<[DiaryEntrySource, string]>
          ).map(([val, label]) => (
            <button
              key={val}
              type="button"
              onClick={() => setSource(val)}
              className={`px-2.5 py-1.5 text-xs font-medium rounded-md cursor-pointer ${
                source === val
                  ? 'bg-[#18392B] text-white'
                  : 'text-[#5A635C] hover:text-[#1F2421]'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {source === 'planned_meal' && (
          <label className="block space-y-1">
            <span className="text-xs text-[#5A635C]">Select Planned Meal</span>
            <select
              value={plannedMealId}
              onChange={(e) => {
                setPlannedMealId(e.target.value);
                const m = snapshot.planning.meals.find(
                  (x) => x.id === e.target.value
                );
                if (m) setTitle(m.title);
              }}
              className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] bg-white text-xs"
            >
              {snapshot.planning.meals.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.date} {m.slot}: {m.title}
                </option>
              ))}
            </select>
          </label>
        )}

        {source === 'recipe' && (
          <label className="block space-y-1">
            <span className="text-xs text-[#5A635C]">Select Saved Recipe</span>
            <select
              value={recipeId}
              onChange={(e) => {
                setRecipeId(e.target.value);
                const r = snapshot.recipes.find((x) => x.id === e.target.value);
                if (r) setTitle(r.title);
              }}
              className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] bg-white text-xs"
            >
              {snapshot.recipes.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.title}
                </option>
              ))}
            </select>
          </label>
        )}

        {source === 'product' && (
          <label className="block space-y-1">
            <span className="text-xs text-[#5A635C]">Select Product</span>
            <select
              value={productId}
              onChange={(e) => {
                setProductId(e.target.value);
                const p = snapshot.products.find(
                  (x) => x.id === e.target.value
                );
                if (p) setTitle(p.title);
              }}
              className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] bg-white text-xs"
            >
              {snapshot.products.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.title}
                </option>
              ))}
            </select>
          </label>
        )}

        <label className="block space-y-1">
          <span className="text-xs text-[#5A635C]">Meal / Food Description</span>
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. Herb chicken orzo with extra salad"
            className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] text-xs"
          />
        </label>

        <div className="grid grid-cols-3 gap-2">
          <label className="space-y-1">
            <span className="text-xs text-[#5A635C]">Date</span>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-2.5 py-2 rounded-lg border border-[#D4CCB8] text-xs font-mono"
            />
          </label>
          <label className="space-y-1">
            <span className="text-xs text-[#5A635C]">Time</span>
            <input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              className="w-full px-2.5 py-2 rounded-lg border border-[#D4CCB8] text-xs font-mono"
            />
          </label>
          <label className="space-y-1">
            <span className="text-xs text-[#5A635C]">Portion</span>
            <input
              value={portionLabel}
              onChange={(e) => setPortionLabel(e.target.value)}
              className="w-full px-2.5 py-2 rounded-lg border border-[#D4CCB8] text-xs"
            />
          </label>
        </div>

        {/* Photo Attachment (explicitly does not infer calories from photo) */}
        <div className="space-y-1.5">
          <span className="text-xs text-[#5A635C] flex items-center gap-1.5">
            <Camera className="w-3.5 h-3.5" />
            <span>Photo Attachment (optional · stored as visual memory only)</span>
          </span>
          <input
            type="file"
            accept="image/jpeg,image/png,image/webp"
            onChange={handlePhotoUpload}
            className="block w-full text-xs text-[#5A635C]"
          />
          {photoUrl && (
            <p className="text-[11px] text-[#18392B]">
              Photo attached. No automatic ingredient or calorie inference is performed from photos.
            </p>
          )}
        </div>

        <label className="flex items-center gap-2 text-xs cursor-pointer">
          <input
            type="checkbox"
            checked={differed}
            onChange={(e) => setDiffered(e.target.checked)}
            className="accent-[#18392B]"
          />
          <span>This differed from the weekly plan</span>
        </label>

        {differed && (
          <input
            value={diffReason}
            onChange={(e) => setDiffReason(e.target.value)}
            placeholder="Why it differed (e.g. swapped for quicker meal)"
            className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] text-xs"
          />
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <label className="space-y-1">
            <span className="text-xs text-[#5A635C]">
              Satisfaction (1–5, neutral reflection)
            </span>
            <select
              value={satisfaction}
              onChange={(e) => setSatisfaction(Number(e.target.value))}
              className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] bg-white text-xs"
            >
              <option value={5}>5 — Very satisfying</option>
              <option value={4}>4 — Good</option>
              <option value={3}>3 — Neutral</option>
              <option value={2}>2 — Underwhelming</option>
              <option value={1}>1 — Didn’t enjoy</option>
            </select>
          </label>
          <label className="space-y-1">
            <span className="text-xs text-[#5A635C]">Visibility</span>
            <select
              value={visibility}
              onChange={(e) =>
                setVisibility(e.target.value as DiaryVisibility)
              }
              className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] bg-white text-xs"
            >
              <option value="private">Private (only {snapshot.identity.active_member.name})</option>
              <option value="household">Shared with Household</option>
            </select>
          </label>
        </div>

        <input
          value={hungerNote}
          onChange={(e) => setHungerNote(e.target.value)}
          placeholder="Hunger / fullness observation (optional)"
          className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] text-xs"
        />

        <textarea
          rows={2}
          value={practicalNotes}
          onChange={(e) => setPracticalNotes(e.target.value)}
          placeholder="Practical kitchen notes (e.g. seasoning, reheating)"
          className="w-full px-3 py-2 rounded-lg border border-[#D4CCB8] text-xs"
        />

        <button
          type="submit"
          disabled={submitting}
          className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 min-h-[44px] rounded-lg bg-[#C85A28] text-white text-sm font-semibold hover:bg-[#B04C20] cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>{submitting ? 'Saving...' : 'Save Diary Entry'}</span>
        </button>
      </form>

      {/* Right: Visible Diary Timeline */}
      <div className="xl:col-span-7 space-y-4">
        <div className="bg-white border border-[#E5DEC9] rounded-xl p-5 flex items-center justify-between gap-4">
          <div>
            <h2 className="font-serif text-xl font-semibold text-[#1F2421]">
              Diary Entries Visible to {snapshot.identity.active_member.name}
            </h2>
            <p className="text-xs text-[#5A635C]">
              Switch household member in the top bar (Maya Lin ↔ Owen Mercer) to verify private entries remain isolated.
            </p>
          </div>
          <span className="font-mono tabular-nums text-xs font-semibold text-[#18392B]">
            {snapshot.diary.length} visible
          </span>
        </div>

        {snapshot.diary.length === 0 ? (
          <div className="bg-white border border-[#E5DEC9] rounded-xl p-8 text-center text-sm text-[#5A635C]">
            No visible diary entries for {snapshot.identity.active_member.name} yet.
          </div>
        ) : (
          <div className="space-y-3">
            {snapshot.diary.map((entry) => {
              const isOwner = entry.member_id === snapshot.identity.active_member_id;
              return (
                <article
                  key={entry.id}
                  className="bg-white border border-[#E5DEC9] rounded-xl p-5 space-y-3"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="space-y-1">
                      <div className="text-xs text-[#5A635C] flex flex-wrap items-center gap-2">
                        <span className="font-mono tabular-nums">
                          {entry.date} {entry.time}
                        </span>
                        <span>·</span>
                        <span>{entry.member_name}</span>
                        <span>·</span>
                        <span className="inline-flex items-center gap-1 font-medium text-[#18392B]">
                          {entry.visibility === 'private' ? (
                            <>
                              <Lock className="w-3 h-3" />
                              <span>Private</span>
                            </>
                          ) : (
                            <>
                              <Users className="w-3 h-3" />
                              <span>Household</span>
                            </>
                          )}
                        </span>
                        {entry.differed_from_plan && (
                          <>
                            <span>·</span>
                            <span className="text-[#C85A28] font-medium">
                              Differed from plan
                            </span>
                          </>
                        )}
                      </div>
                      <h3 className="font-serif text-lg font-semibold text-[#1F2421]">
                        {entry.title}
                      </h3>
                      <p className="text-xs text-[#5A635C]">
                        Portion: {entry.portion_label}
                        {entry.satisfaction ? ` · Satisfaction: ${entry.satisfaction}/5` : ''}
                      </p>
                    </div>

                    {isOwner && (
                      <button
                        type="button"
                        aria-label={`Delete diary entry ${entry.title}`}
                        onClick={() => handleDelete(entry.id)}
                        className="p-2 rounded-lg text-[#5A635C] hover:text-[#B91C1C] hover:bg-[#FEF2F2] cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>

                  {entry.photo_url && (
                    <div className="relative w-full max-w-xs aspect-[4/3] rounded-lg overflow-hidden border border-[#E5DEC9]">
                      <Image
                        src={entry.photo_url}
                        alt={entry.title}
                        fill
                        referrerPolicy="no-referrer"
                        className="object-cover"
                        unoptimized={entry.photo_url.startsWith('data:')}
                      />
                    </div>
                  )}

                  {(entry.difference_reason || entry.hunger_note || entry.practical_notes) && (
                    <div className="space-y-1 text-xs text-[#1F2421] bg-[#FAF7F2] p-3 rounded-lg border border-[#EFE9DC]">
                      {entry.difference_reason && (
                        <p>
                          <strong className="text-[#5A635C]">Plan change: </strong>
                          {entry.difference_reason}
                        </p>
                      )}
                      {entry.hunger_note && (
                        <p>
                          <strong className="text-[#5A635C]">Hunger / fullness: </strong>
                          {entry.hunger_note}
                        </p>
                      )}
                      {entry.practical_notes && (
                        <p>
                          <strong className="text-[#5A635C]">Notes: </strong>
                          {entry.practical_notes}
                        </p>
                      )}
                    </div>
                  )}

                  {entry.nutrition_summary &&
                    snapshot.identity.household.track_calories_in_diary && (
                      <p className="text-[11px] text-[#5A635C] tabular-nums">
                        Optional summary: {entry.nutrition_summary.kcal} kcal
                        {entry.nutrition_summary.protein_g
                          ? ` · ${entry.nutrition_summary.protein_g}g protein`
                          : ''}{' '}
                        — {entry.nutrition_summary.source} (
                        {entry.nutrition_summary.is_verified
                          ? 'Verified product'
                          : 'Estimated'}
                        )
                      </p>
                    )}
                </article>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
