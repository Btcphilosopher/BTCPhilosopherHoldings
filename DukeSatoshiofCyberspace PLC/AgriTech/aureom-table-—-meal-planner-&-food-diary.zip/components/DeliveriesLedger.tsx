'use client';

import {useState} from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  PackageCheck,
  RefreshCw,
  ShieldAlert,
  XCircle,
} from 'lucide-react';
import {MerchantOrder, StorageLocation} from '@/lib/domain/types';
import {formatMoney, WorkspaceSnapshot} from './types';

interface Props {
  snapshot: WorkspaceSnapshot;
  onRefresh: (next: WorkspaceSnapshot) => void;
  onNotify: (msg: string, tone?: 'info' | 'warning') => void;
}

export default function DeliveriesLedger({
  snapshot,
  onRefresh,
  onNotify,
}: Props) {
  const [confirmingOrder, setConfirmingOrder] = useState<MerchantOrder | null>(
    null
  );
  const [deliveryLines, setDeliveryLines] = useState<
    Array<{
      line_id: string;
      product_title: string;
      ordered_packs: number;
      delivered_packs: number;
      pack_quantity: number;
      pack_unit: string;
      storage_location: StorageLocation;
      recorded_expiry_date: string;
    }>
  >([]);

  const openConfirmModal = (order: MerchantOrder) => {
    setDeliveryLines(
      order.lines.map((l) => ({
        line_id: l.id,
        product_title: l.product_title,
        ordered_packs: l.ordered_packs,
        delivered_packs: l.delivered_packs ?? l.ordered_packs,
        pack_quantity: l.pack_quantity,
        pack_unit: l.pack_unit,
        storage_location: 'fridge',
        recorded_expiry_date: '2026-11-29',
      }))
    );
    setConfirmingOrder(order);
  };

  const handleConfirmDelivery = async () => {
    if (!confirmingOrder) return;
    try {
      const res = await fetch('/api/orders', {
        method: 'PATCH',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          action: 'confirm_delivery',
          order_id: confirmingOrder.id,
          lines: deliveryLines.map((l) => ({
            line_id: l.line_id,
            delivered_packs: l.delivered_packs,
            storage_location: l.storage_location,
            recorded_expiry_date: l.recorded_expiry_date || null,
          })),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      setConfirmingOrder(null);
      onNotify(
        'Delivery quantities verified and added to your pantry stock.'
      );
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Confirmation failed', 'warning');
    }
  };

  const handleResolveSubstitution = async (
    lineId: string,
    decision: 'approved' | 'rejected'
  ) => {
    try {
      const res = await fetch('/api/orders', {
        method: 'PATCH',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          action: 'resolve_substitution',
          line_id: lineId,
          decision,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      onNotify(
        decision === 'approved'
          ? 'Explicitly approved substitute.'
          : 'Rejected substitute and recorded refund in payment ledger.'
      );
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Action failed', 'warning');
    }
  };

  const handleRetryFailedOrder = async (orderId: string) => {
    try {
      const res = await fetch('/api/orders', {
        method: 'PATCH',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          action: 'retry_failed_order',
          order_id: orderId,
          new_slot_label: 'Tue 24 Nov · 10:00–12:00 (Recovery Slot)',
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      onNotify('Retried merchant order with recovery slot and captured payment.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Retry failed', 'warning');
    }
  };

  const handleCancelOrder = async (orderId: string) => {
    try {
      const res = await fetch('/api/orders', {
        method: 'PATCH',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({action: 'cancel_order', order_id: orderId}),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onRefresh(data.snapshot);
      onNotify('Order cancelled and refund recorded in ledger.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Cancel failed', 'warning');
    }
  };

  return (
    <div className="space-y-6">
      {snapshot.checkouts.length === 0 ? (
        <div className="bg-white border border-[#E5DEC9] rounded-xl p-8 text-center text-sm text-[#5A635C]">
          No checkouts placed yet. Build a basket in Shopping to arrange deliveries.
        </div>
      ) : (
        snapshot.checkouts.map((checkout) => (
          <section
            key={checkout.id}
            className="bg-white border border-[#E5DEC9] rounded-xl p-6 space-y-5"
          >
            {/* Parent Checkout Header */}
            <div className="flex flex-wrap items-start justify-between gap-4 border-b border-[#EFE9DC] pb-4">
              <div className="space-y-1">
                <p className="text-xs text-[#5A635C] font-mono">
                  Parent Checkout {checkout.id} · {checkout.delivery_address},{' '}
                  {checkout.delivery_postcode}
                </p>
                <h2 className="font-serif text-xl font-semibold text-[#1F2421]">
                  {checkout.merchant_orders.length} Merchant Order(s) · Status:{' '}
                  <span className="capitalize text-[#18392B]">
                    {checkout.status.replace('_', ' ')}
                  </span>
                </h2>
              </div>

              <div className="flex flex-wrap gap-4 font-mono tabular-nums text-xs">
                <div>
                  <span className="text-[#5A635C] block">Authorised</span>
                  <span className="text-sm font-semibold text-[#1F2421]">
                    {formatMoney(checkout.total_authorised_minor)}
                  </span>
                </div>
                <div>
                  <span className="text-[#5A635C] block">Captured</span>
                  <span className="text-sm font-semibold text-[#18392B]">
                    {formatMoney(checkout.total_captured_minor)}
                  </span>
                </div>
                <div>
                  <span className="text-[#5A635C] block">Refunded</span>
                  <span className="text-sm font-semibold text-[#C85A28]">
                    {formatMoney(checkout.total_refunded_minor)}
                  </span>
                </div>
              </div>
            </div>

            {/* Individual Merchant Orders */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {checkout.merchant_orders.map((order) => (
                <div
                  key={order.id}
                  className="p-4 rounded-xl bg-[#FAF7F2] border border-[#E5DEC9] space-y-3 flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h3 className="font-serif text-lg font-semibold text-[#1F2421]">
                          {order.merchant_name}
                        </h3>
                        <p className="text-xs text-[#5A635C]">
                          {order.fulfilment_model === 'consolidated'
                            ? `Consolidated via ${order.fulfilment_partner_name}`
                            : 'Separate merchant delivery'}{' '}
                          · {order.slot_label}
                        </p>
                      </div>
                      <span className="font-mono tabular-nums text-xs font-semibold capitalize text-[#18392B]">
                        {order.status.replaceAll('_', ' ')}
                      </span>
                    </div>

                    {order.failure_reason && (
                      <div className="p-3 rounded-lg bg-[#FFF4EE] border border-[#C85A28]/40 text-xs text-[#8E3511] flex items-start gap-2">
                        <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                        <span>{order.failure_reason}</span>
                      </div>
                    )}

                    <div className="divide-y divide-[#E5DEC9] text-xs">
                      {order.lines.map((line) => (
                        <div key={line.id} className="py-2.5 space-y-2">
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-medium text-[#1F2421]">
                              {line.ordered_packs}× {line.product_title}
                              {line.delivered_packs !== null &&
                                line.delivered_packs !== undefined && (
                                  <span className="text-[#5A635C] font-normal">
                                    {' '}
                                    (delivered: {line.delivered_packs})
                                  </span>
                                )}
                            </span>
                            <span className="font-mono tabular-nums text-[#18392B]">
                              {formatMoney(line.line_total_minor)}
                            </span>
                          </div>

                          {/* Allergen & Metadata Safety Gate for Proposed Substitutions */}
                          {line.substitution_status === 'proposed' && (
                            <div className="p-3 rounded-lg bg-white border border-[#C85A28]/50 space-y-2">
                              <div className="flex items-start gap-2 text-[#8E3511]">
                                <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
                                <div className="space-y-1">
                                  <p className="font-semibold">
                                    Proposed Substitute: {line.proposed_substitute_title}{' '}
                                    ({formatMoney(line.proposed_substitute_price_minor ?? line.unit_price_minor)})
                                  </p>
                                  <p>{line.substitution_warning}</p>
                                  <p className="text-[#5A635C]">
                                    Declared allergens:{' '}
                                    {line.proposed_substitute_allergens?.join(', ') ||
                                      'Unverified'}{' '}
                                    · Metadata complete:{' '}
                                    {line.proposed_substitute_metadata_complete
                                      ? 'Yes'
                                      : 'No — cannot assume allergy-safe'}
                                  </p>
                                </div>
                              </div>
                              <div className="flex items-center gap-2 pt-1">
                                <button
                                  type="button"
                                  onClick={() =>
                                    handleResolveSubstitution(line.id, 'approved')
                                  }
                                  className="px-3 py-1.5 min-h-[34px] rounded bg-[#18392B] text-white font-semibold cursor-pointer"
                                >
                                  Explicitly Approve Substitute
                                </button>
                                <button
                                  type="button"
                                  onClick={() =>
                                    handleResolveSubstitution(line.id, 'rejected')
                                  }
                                  className="px-3 py-1.5 min-h-[34px] rounded border border-[#D4CCB8] text-[#1F2421] bg-[#FAF7F2] cursor-pointer"
                                >
                                  Reject & Refund ({formatMoney(line.line_total_minor)})
                                </button>
                              </div>
                            </div>
                          )}

                          {line.substitution_status === 'approved' && (
                            <p className="text-[11px] text-[#18392B] font-medium">
                              Substitute explicitly approved by household.
                            </p>
                          )}
                          {line.substitution_status === 'rejected' && (
                            <p className="text-[11px] text-[#C85A28] font-medium">
                              Substitute rejected — item refunded.
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Order Actions */}
                  <div className="pt-3 border-t border-[#E5DEC9] flex flex-wrap items-center justify-between gap-2 text-xs">
                    <span className="font-mono tabular-nums text-[#5A635C]">
                      Total {formatMoney(order.total_minor)} · Refunded{' '}
                      {formatMoney(order.refunded_minor)}
                    </span>
                    <div className="flex flex-wrap items-center gap-2">
                      {order.status === 'failed' && (
                        <button
                          type="button"
                          onClick={() => handleRetryFailedOrder(order.id)}
                          className="inline-flex items-center gap-1 px-3 py-1.5 min-h-[36px] rounded-lg bg-[#C85A28] text-white font-semibold cursor-pointer"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                          <span>Retry with Alternate Slot</span>
                        </button>
                      )}

                      {!order.delivery_confirmed_into_pantry &&
                        order.status !== 'failed' &&
                        order.status !== 'cancelled' && (
                          <button
                            type="button"
                            onClick={() => openConfirmModal(order)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 min-h-[36px] rounded-lg bg-[#18392B] text-white font-semibold cursor-pointer"
                          >
                            <PackageCheck className="w-3.5 h-3.5" />
                            <span>Confirm Delivery into Pantry</span>
                          </button>
                        )}

                      {order.delivery_confirmed_into_pantry && (
                        <span className="inline-flex items-center gap-1 text-[#18392B] font-semibold">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Stock Confirmed in Pantry</span>
                        </span>
                      )}

                      {order.status !== 'cancelled' &&
                        order.status !== 'delivered' &&
                        !order.delivery_confirmed_into_pantry && (
                          <button
                            type="button"
                            onClick={() => handleCancelOrder(order.id)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 min-h-[36px] rounded-lg border border-[#D4CCB8] text-[#5A635C] hover:text-[#B91C1C] cursor-pointer"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Cancel</span>
                          </button>
                        )}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Payment & Settlement Ledger */}
            <div className="pt-3 border-t border-[#EFE9DC] space-y-2">
              <h3 className="text-xs font-semibold text-[#18392B]">
                Payment Authorisation, Capture, Refund & Merchant Settlement Ledger
              </h3>
              <div className="divide-y divide-[#EFE9DC] text-xs">
                {checkout.ledger.map((entry) => (
                  <div
                    key={entry.id}
                    className="py-2 flex flex-wrap items-center justify-between gap-2"
                  >
                    <div>
                      <span className="font-semibold capitalize text-[#1F2421]">
                        {entry.entry_type.replace('_', ' ')}
                      </span>
                      <span className="text-[#5A635C]"> · {entry.note}</span>
                    </div>
                    <div className="font-mono tabular-nums flex items-center gap-3">
                      <span className="text-[#5A635C] capitalize">
                        {entry.status}
                      </span>
                      <span className="font-semibold text-[#1F2421]">
                        {formatMoney(entry.amount_minor)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>
        ))
      )}

      {/* Confirm Delivery into Pantry Modal */}
      {confirmingOrder && (
        <div
          className="fixed inset-0 z-50 bg-black/45 flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Confirm delivered quantities into pantry"
        >
          <div className="bg-white border border-[#E5DEC9] rounded-xl max-w-lg w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <h2 className="font-serif text-xl font-semibold text-[#1F2421]">
              Confirm Delivered Quantities ({confirmingOrder.merchant_name})
            </h2>
            <p className="text-xs text-[#5A635C]">
              Verify actual arrived packs before adding to pantry stock. Any shortfall automatically records a refund adjustment.
            </p>
            <div className="space-y-3">
              {deliveryLines.map((line, idx) => (
                <div
                  key={line.line_id}
                  className="p-3 rounded-lg bg-[#FAF7F2] border border-[#E5DEC9] space-y-2 text-xs"
                >
                  <p className="font-semibold text-[#1F2421]">
                    {line.product_title} (ordered {line.ordered_packs} packs)
                  </p>
                  <div className="grid grid-cols-3 gap-2">
                    <label className="space-y-1">
                      <span className="text-[#5A635C]">Delivered packs</span>
                      <input
                        type="number"
                        min={0}
                        max={line.ordered_packs}
                        value={line.delivered_packs}
                        onChange={(e) => {
                          const v = Number(e.target.value);
                          setDeliveryLines((prev) =>
                            prev.map((item, i) =>
                              i === idx ? {...item, delivered_packs: v} : item
                            )
                          );
                        }}
                        className="w-full px-2 py-1.5 rounded border border-[#D4CCB8] bg-white font-mono tabular-nums"
                      />
                    </label>
                    <label className="space-y-1">
                      <span className="text-[#5A635C]">Storage</span>
                      <select
                        value={line.storage_location}
                        onChange={(e) => {
                          const v = e.target.value as StorageLocation;
                          setDeliveryLines((prev) =>
                            prev.map((item, i) =>
                              i === idx ? {...item, storage_location: v} : item
                            )
                          );
                        }}
                        className="w-full px-2 py-1.5 rounded border border-[#D4CCB8] bg-white"
                      >
                        <option value="fridge">Fridge</option>
                        <option value="freezer">Freezer</option>
                        <option value="cupboard">Cupboard</option>
                      </select>
                    </label>
                    <label className="space-y-1">
                      <span className="text-[#5A635C]">Best before</span>
                      <input
                        type="date"
                        value={line.recorded_expiry_date}
                        onChange={(e) => {
                          const v = e.target.value;
                          setDeliveryLines((prev) =>
                            prev.map((item, i) =>
                              i === idx
                                ? {...item, recorded_expiry_date: v}
                                : item
                            )
                          );
                        }}
                        className="w-full px-2 py-1.5 rounded border border-[#D4CCB8] bg-white font-mono"
                      />
                    </label>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setConfirmingOrder(null)}
                className="px-4 py-2 min-h-[40px] rounded-lg border border-[#D4CCB8] text-sm cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelivery}
                className="px-4 py-2 min-h-[40px] rounded-lg bg-[#18392B] text-white text-sm font-semibold cursor-pointer"
              >
                Confirm into Pantry
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
