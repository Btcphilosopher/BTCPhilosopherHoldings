import type {Metadata} from 'next';
import {Fraunces, Plus_Jakarta_Sans, JetBrains_Mono} from 'next/font/google';
import './globals.css';

const fraunces = Fraunces({
  subsets: ['latin'],
  variable: '--font-fraunces',
  weight: ['500', '600', '700'],
});

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  variable: '--font-jakarta',
  weight: ['400', '500', '600', '700'],
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-jetbrains',
  weight: ['400', '500'],
});

export const metadata: Metadata = {
  title: 'Aureom Table — Meal Planner & Food Diary',
  description:
    'Personal kitchen companion connecting weekly meal planning, ingredient aggregation, pantry stock, multi-merchant shopping, deliveries, and a private food diary.',
  openGraph: {
    title: 'Aureom Table — Meal Planner & Food Diary',
    description:
      'Personal kitchen companion connecting weekly meal planning, ingredient aggregation, pantry stock, multi-merchant shopping, deliveries, and a private food diary.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Aureom Table — Meal Planner & Food Diary',
    description:
      'Personal kitchen companion connecting weekly meal planning, ingredient aggregation, pantry stock, multi-merchant shopping, deliveries, and a private food diary.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html
      lang="en"
      className={`${fraunces.variable} ${plusJakarta.variable} ${jetbrainsMono.variable}`}
    >
      <body
        className="bg-[#FAF7F2] text-[#1F2421] font-sans antialiased selection:bg-[#18392B] selection:text-[#FAF7F2]"
        suppressHydrationWarning
      >
        {children}
      </body>
    </html>
  );
}
