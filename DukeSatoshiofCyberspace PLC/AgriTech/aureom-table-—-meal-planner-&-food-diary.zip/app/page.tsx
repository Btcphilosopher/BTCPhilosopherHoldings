import AureomApp from '@/components/AureomApp';
import {loadWorkspaceSnapshot} from '@/lib/server/workspace';

export const dynamic = 'force-dynamic';

export default function HomePage() {
  const snapshot = loadWorkspaceSnapshot();
  return <AureomApp initialSnapshot={snapshot} />;
}
