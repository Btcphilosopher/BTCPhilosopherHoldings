import {NextRequest, NextResponse} from 'next/server';
import {z} from 'zod';
import {getDb} from '@/lib/server/db';
import {createRecipe} from '@/lib/server/modules/recipes';
import {loadWorkspaceSnapshot} from '@/lib/server/workspace';

const createRecipeSchema = z.object({
  title: z.string().min(2).max(140),
  description: z.string().min(4).max(500),
  servings: z.number().int().min(1).max(20),
  prep_minutes: z.number().int().min(0).max(400),
  cook_minutes: z.number().int().min(0).max(600),
  instructions: z.array(z.string().min(1)).min(1),
  dietary_tags: z.array(z.string()).default([]),
  allergens: z.array(z.string()).default([]),
  allergen_provenance: z.string().min(2).max(300),
  storage_notes: z.string().max(300).optional(),
  leftover_notes: z.string().max(300).optional(),
  ingredients: z
    .array(
      z.object({
        ingredient_id: z.string().min(1),
        display_name: z.string().min(1),
        form_variety: z.string().min(1),
        quantity: z.number().positive(),
        unit: z.string().min(1),
        is_optional: z.boolean().optional(),
        is_garnish: z.boolean().optional(),
        is_pantry_staple: z.boolean().optional(),
      })
    )
    .min(1),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = createRecipeSchema.parse(body);
    const db = getDb();
    const recipe = createRecipe(db, parsed);
    return NextResponse.json({recipe, snapshot: loadWorkspaceSnapshot()});
  } catch (err) {
    return NextResponse.json(
      {error: err instanceof Error ? err.message : 'Failed to create recipe'},
      {status: 400}
    );
  }
}
