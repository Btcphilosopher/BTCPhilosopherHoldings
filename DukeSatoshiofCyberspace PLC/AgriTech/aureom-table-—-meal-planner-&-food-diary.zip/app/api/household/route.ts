import {NextRequest, NextResponse} from 'next/server';
import {z} from 'zod';
import {getDb} from '@/lib/server/db';
import {
  addHouseholdMember,
  deleteHouseholdMember,
  exportHouseholdDataForMember,
  getHouseholdContext,
  setActiveMember,
  updateHouseholdSettings,
  updateMemberPreferences,
} from '@/lib/server/modules/identity';
import {loadWorkspaceSnapshot} from '@/lib/server/workspace';

export async function GET() {
  try {
    const db = getDb();
    const ctx = getHouseholdContext(db);
    const exported = exportHouseholdDataForMember(db, ctx.active_member_id);
    return NextResponse.json(exported);
  } catch (err) {
    return NextResponse.json(
      {error: err instanceof Error ? err.message : 'Export failed'},
      {status: 500}
    );
  }
}

const patchSchema = z.discriminatedUnion('action', [
  z.object({
    action: z.literal('switch_member'),
    member_id: z.string().min(1),
  }),
  z.object({
    action: z.literal('update_household'),
    name: z.string().min(2).max(100).optional(),
    address_line1: z.string().min(3).max(160).optional(),
    city: z.string().min(2).max(80).optional(),
    postcode: z.string().min(4).max(12).optional(),
    weekly_budget_minor: z.number().int().min(1000).max(200000).optional(),
    preferred_merchant_ids: z.array(z.string()).optional(),
    default_fulfilment_model: z.enum(['separate', 'consolidated']).optional(),
    share_delivery_details_with_merchants: z.boolean().optional(),
    track_calories_in_diary: z.boolean().optional(),
    notification_prefs: z
      .object({
        expiry_reminders: z.boolean(),
        delivery_updates: z.boolean(),
        substitution_alerts: z.boolean(),
      })
      .optional(),
  }),
  z.object({
    action: z.literal('update_member'),
    member_id: z.string().min(1),
    dietary_preferences: z.array(z.string()).optional(),
    dislikes: z.array(z.string()).optional(),
    excluded_ingredients: z.array(z.string()).optional(),
    allergens: z.array(z.string()).optional(),
    portion_multiplier: z.number().min(0.5).max(3.0).optional(),
  }),
]);

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = patchSchema.parse(body);
    const db = getDb();

    if (parsed.action === 'switch_member') {
      setActiveMember(db, parsed.member_id);
    } else if (parsed.action === 'update_household') {
      const {action: _ignored, ...updates} = parsed;
      void _ignored;
      updateHouseholdSettings(db, updates);
    } else if (parsed.action === 'update_member') {
      const {action: _ignored, member_id, ...updates} = parsed;
      void _ignored;
      updateMemberPreferences(db, member_id, updates);
    }
    return NextResponse.json({snapshot: loadWorkspaceSnapshot()});
  } catch (err) {
    return NextResponse.json(
      {error: err instanceof Error ? err.message : 'Household update failed'},
      {status: 400}
    );
  }
}

const addMemberSchema = z.object({
  name: z.string().min(1).max(80),
  role: z.enum(['adult', 'child']),
  dietary_preferences: z.array(z.string()).default([]),
  dislikes: z.array(z.string()).default([]),
  excluded_ingredients: z.array(z.string()).default([]),
  allergens: z.array(z.string()).default([]),
  portion_multiplier: z.number().min(0.5).max(3.0).default(1.0),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = addMemberSchema.parse(body);
    const db = getDb();
    addHouseholdMember(db, parsed);
    return NextResponse.json({snapshot: loadWorkspaceSnapshot()});
  } catch (err) {
    return NextResponse.json(
      {error: err instanceof Error ? err.message : 'Failed to add member'},
      {status: 400}
    );
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const memberId = req.nextUrl.searchParams.get('member_id');
    if (!memberId) {
      return NextResponse.json({error: 'member_id required'}, {status: 400});
    }
    const db = getDb();
    deleteHouseholdMember(db, memberId);
    return NextResponse.json({snapshot: loadWorkspaceSnapshot()});
  } catch (err) {
    return NextResponse.json(
      {error: err instanceof Error ? err.message : 'Failed to remove member'},
      {status: 400}
    );
  }
}
