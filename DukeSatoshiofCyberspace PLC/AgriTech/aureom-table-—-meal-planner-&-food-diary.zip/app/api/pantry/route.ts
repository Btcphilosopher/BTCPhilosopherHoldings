import {NextRequest, NextResponse} from 'next/server';
import {z} from 'zod';
import {getDb} from '@/lib/server/db';
import {
  addPantryItem,
  adjustPantryStock,
  lookupBarcode,
} from '@/lib/server/modules/pantry';
import {loadWorkspaceSnapshot} from '@/lib/server/workspace';

export async function GET(req: NextRequest) {
  const barcode = req.nextUrl.searchParams.get('barcode') ?? '';
  if (!barcode) {
    return NextResponse.json({error: 'barcode query required'}, {status: 400});
  }
  return NextResponse.json(lookupBarcode(barcode));
}

const addPantrySchema = z.object({
  ingredient_id: z.string().min(1),
  product_name: z.string().min(1).max(160),
  barcode: z.string().nullable().optional(),
  quantity: z.number().positive(),
  unit: z.string().min(1).max(24),
  storage_location: z.enum(['fridge', 'freezer', 'cupboard']),
  purchase_or_opened_date: z.string().min(8),
  recorded_expiry_date: z.string().nullable().optional(),
  date_marking_type: z.enum(['use_by', 'best_before', 'user_estimate']),
  source_action: z.enum(['manual_add', 'barcode_lookup']).optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = addPantrySchema.parse(body);
    const db = getDb();
    const item = addPantryItem(db, parsed);
    return NextResponse.json({item, snapshot: loadWorkspaceSnapshot()});
  } catch (err) {
    return NextResponse.json(
      {error: err instanceof Error ? err.message : 'Failed to add pantry item'},
      {status: 400}
    );
  }
}

const adjustSchema = z.object({
  pantry_item_id: z.string().min(1),
  action: z.enum(['consumed', 'discarded', 'corrected', 'replenished']),
  amount: z.number().min(0),
  note: z.string().max(240).optional(),
});

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = adjustSchema.parse(body);
    const db = getDb();
    const item = adjustPantryStock(
      db,
      parsed.pantry_item_id,
      parsed.action,
      parsed.amount,
      parsed.note
    );
    return NextResponse.json({item, snapshot: loadWorkspaceSnapshot()});
  } catch (err) {
    return NextResponse.json(
      {error: err instanceof Error ? err.message : 'Failed to adjust pantry stock'},
      {status: 400}
    );
  }
}
