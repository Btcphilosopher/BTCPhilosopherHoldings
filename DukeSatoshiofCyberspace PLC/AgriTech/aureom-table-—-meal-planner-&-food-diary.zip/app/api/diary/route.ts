import {NextRequest, NextResponse} from 'next/server';
import {z} from 'zod';
import {getDb} from '@/lib/server/db';
import {getHouseholdContext} from '@/lib/server/modules/identity';
import {createDiaryEntry, deleteDiaryEntry} from '@/lib/server/modules/diary';
import {loadWorkspaceSnapshot} from '@/lib/server/workspace';

const createDiarySchema = z.object({
  visibility: z.enum(['private', 'household']),
  source: z.enum(['planned_meal', 'recipe', 'manual', 'product', 'photo']),
  planned_meal_id: z.string().nullable().optional(),
  recipe_id: z.string().nullable().optional(),
  product_id: z.string().nullable().optional(),
  title: z.string().min(1).max(160),
  date: z.string().min(8),
  time: z.string().min(4),
  portion_label: z.string().min(1).max(80),
  differed_from_plan: z.boolean().default(false),
  difference_reason: z.string().max(300).nullable().optional(),
  satisfaction: z.number().int().min(1).max(5).nullable().optional(),
  hunger_note: z.string().max(300).nullable().optional(),
  practical_notes: z.string().max(500).nullable().optional(),
  photo_url: z.string().nullable().optional(),
  nutrition_summary: z
    .object({
      kcal: z.number().min(0),
      protein_g: z.number().min(0).optional(),
      source: z.string().min(2),
      is_verified: z.boolean(),
    })
    .nullable()
    .optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = createDiarySchema.parse(body);
    const db = getDb();
    const ctx = getHouseholdContext(db);
    const entry = createDiaryEntry(db, {
      ...parsed,
      member_id: ctx.active_member_id,
    });
    return NextResponse.json({entry, snapshot: loadWorkspaceSnapshot()});
  } catch (err) {
    return NextResponse.json(
      {error: err instanceof Error ? err.message : 'Failed to log diary entry'},
      {status: 400}
    );
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const entryId = req.nextUrl.searchParams.get('entry_id');
    if (!entryId) {
      return NextResponse.json({error: 'entry_id is required'}, {status: 400});
    }
    const db = getDb();
    const ctx = getHouseholdContext(db);
    deleteDiaryEntry(db, entryId, ctx.active_member_id);
    return NextResponse.json({deleted: true, snapshot: loadWorkspaceSnapshot()});
  } catch (err) {
    return NextResponse.json(
      {error: err instanceof Error ? err.message : 'Failed to delete entry'},
      {status: 403}
    );
  }
}
