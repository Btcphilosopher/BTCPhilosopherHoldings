import {NextRequest, NextResponse} from 'next/server';
import {z} from 'zod';
import {getDb} from '@/lib/server/db';
import {
  cancelMerchantOrder,
  executeCheckout,
  resolveSubstitutionDecision,
  retryFailedMerchantOrder,
} from '@/lib/server/modules/orders';
import {confirmDeliveryIntoPantry} from '@/lib/server/modules/delivery';
import {loadWorkspaceSnapshot} from '@/lib/server/workspace';

const checkoutSchema = z.object({
  idempotency_key: z.string().min(6),
  delivery_address: z.string().min(5),
  delivery_postcode: z.string().min(4),
  simulate_partial_failure_merchant_id: z.string().nullable().optional(),
  groups: z
    .array(
      z.object({
        merchant_id: z.string().min(1),
        fulfilment_model: z.enum(['separate', 'consolidated']),
        slot_id: z.string().min(1),
        delivery_fee_minor: z.number().int().min(0),
        lines: z
          .array(
            z.object({
              product_id: z.string().min(1),
              packs_to_buy: z.number().int().min(1),
              substitution_preference: z.enum([
                'allow_equivalent',
                'require_approval',
                'refund_if_missing',
              ]),
              linked_meal_ids: z.array(z.string()).default([]),
            })
          )
          .min(1),
      })
    )
    .min(1),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = checkoutSchema.parse(body);
    const db = getDb();
    const result = executeCheckout(db, parsed);
    return NextResponse.json({
      ...result,
      snapshot: loadWorkspaceSnapshot(),
    });
  } catch (err) {
    return NextResponse.json(
      {error: err instanceof Error ? err.message : 'Checkout failed'},
      {status: 400}
    );
  }
}

const patchSchema = z.discriminatedUnion('action', [
  z.object({
    action: z.literal('retry_failed_order'),
    order_id: z.string().min(1),
    new_slot_label: z.string().optional(),
  }),
  z.object({
    action: z.literal('resolve_substitution'),
    line_id: z.string().min(1),
    decision: z.enum(['approved', 'rejected']),
  }),
  z.object({
    action: z.literal('cancel_order'),
    order_id: z.string().min(1),
  }),
  z.object({
    action: z.literal('confirm_delivery'),
    order_id: z.string().min(1),
    lines: z.array(
      z.object({
        line_id: z.string().min(1),
        delivered_packs: z.number().int().min(0),
        storage_location: z.enum(['fridge', 'freezer', 'cupboard']),
        recorded_expiry_date: z.string().nullable().optional(),
      })
    ),
  }),
]);

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = patchSchema.parse(body);
    const db = getDb();

    if (parsed.action === 'retry_failed_order') {
      const checkout = retryFailedMerchantOrder(
        db,
        parsed.order_id,
        parsed.new_slot_label
      );
      return NextResponse.json({checkout, snapshot: loadWorkspaceSnapshot()});
    }
    if (parsed.action === 'resolve_substitution') {
      const checkout = resolveSubstitutionDecision(
        db,
        parsed.line_id,
        parsed.decision
      );
      return NextResponse.json({checkout, snapshot: loadWorkspaceSnapshot()});
    }
    if (parsed.action === 'cancel_order') {
      const checkout = cancelMerchantOrder(db, parsed.order_id);
      return NextResponse.json({checkout, snapshot: loadWorkspaceSnapshot()});
    }
    if (parsed.action === 'confirm_delivery') {
      const checkout = confirmDeliveryIntoPantry(
        db,
        parsed.order_id,
        parsed.lines
      );
      return NextResponse.json({checkout, snapshot: loadWorkspaceSnapshot()});
    }
    return NextResponse.json({error: 'Unsupported action'}, {status: 400});
  } catch (err) {
    return NextResponse.json(
      {error: err instanceof Error ? err.message : 'Order update failed'},
      {status: 400}
    );
  }
}
