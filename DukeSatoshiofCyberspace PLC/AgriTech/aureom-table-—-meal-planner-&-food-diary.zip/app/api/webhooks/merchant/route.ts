import {NextRequest, NextResponse} from 'next/server';
import {z} from 'zod';
import {getDb} from '@/lib/server/db';
import {processWebhookEvent} from '@/lib/server/modules/orders';

const webhookSchema = z.object({
  event_id: z.string().min(3),
  provider: z.string().min(2),
  payload: z.record(z.string(), z.unknown()).default({}),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = webhookSchema.parse(body);
    const db = getDb();
    const res = processWebhookEvent(
      db,
      parsed.event_id,
      parsed.provider,
      parsed.payload
    );
    return NextResponse.json(res);
  } catch (err) {
    return NextResponse.json(
      {error: err instanceof Error ? err.message : 'Invalid webhook event'},
      {status: 400}
    );
  }
}
