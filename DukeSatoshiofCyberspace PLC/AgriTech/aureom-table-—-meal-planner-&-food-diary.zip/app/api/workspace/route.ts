import {NextResponse} from 'next/server';
import {getDb} from '@/lib/server/db';
import {resetAndSeed} from '@/lib/server/seed';
import {loadWorkspaceSnapshot} from '@/lib/server/workspace';

export async function GET() {
  try {
    const snapshot = loadWorkspaceSnapshot();
    return NextResponse.json(snapshot);
  } catch (err) {
    return NextResponse.json(
      {error: err instanceof Error ? err.message : 'Failed to load workspace'},
      {status: 500}
    );
  }
}

export async function POST() {
  try {
    const db = getDb();
    resetAndSeed(db);
    const snapshot = loadWorkspaceSnapshot();
    return NextResponse.json({reset: true, snapshot});
  } catch (err) {
    return NextResponse.json(
      {error: err instanceof Error ? err.message : 'Failed to reset demo data'},
      {status: 500}
    );
  }
}
