import {NextRequest, NextResponse} from 'next/server';
import {z} from 'zod';
import {getDb} from '@/lib/server/db';
import {generateValidatedMealPlanProposal} from '@/lib/server/modules/ai-planner';

const aiPlanSchema = z.object({
  max_prep_minutes: z.number().int().min(5).max(120).default(20),
  budget_minor: z.number().int().min(1000).max(25000).default(9500),
  target_dates: z
    .array(z.string().min(8))
    .min(1)
    .max(7)
    .default(['2026-11-23', '2026-11-24', '2026-11-25']),
  selected_recipe_ids: z.array(z.string()).optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = aiPlanSchema.parse(body);
    const db = getDb();
    const result = await generateValidatedMealPlanProposal(db, parsed);
    return NextResponse.json(result);
  } catch (err) {
    const message =
      err instanceof Error ? err.message : 'Failed to generate AI plan proposal';
    return NextResponse.json({error: message}, {status: 500});
  }
}
