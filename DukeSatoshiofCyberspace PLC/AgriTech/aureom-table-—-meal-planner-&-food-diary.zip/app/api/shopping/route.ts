import {NextRequest, NextResponse} from 'next/server';
import {z} from 'zod';
import {getDb} from '@/lib/server/db';
import {
  getShoppingConfig,
  reservePantryForWeek,
  updateShoppingConfig,
} from '@/lib/server/modules/basket';
import {loadWorkspaceSnapshot} from '@/lib/server/workspace';

export async function POST() {
  try {
    const db = getDb();
    const reservation = reservePantryForWeek(db);
    return NextResponse.json({reservation, snapshot: loadWorkspaceSnapshot()});
  } catch (err) {
    return NextResponse.json(
      {error: err instanceof Error ? err.message : 'Failed to reserve pantry stock'},
      {status: 400}
    );
  }
}

const configPatchSchema = z.object({
  include_optional: z.boolean().optional(),
  include_garnish: z.boolean().optional(),
  include_pantry_staples: z.boolean().optional(),
  lock_requirement_key: z.string().optional(),
  lock_product_id: z.string().nullable().optional(),
});

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = configPatchSchema.parse(body);
    const db = getDb();
    const current = getShoppingConfig(db);
    const locked = {...current.locked_assignments};

    if (parsed.lock_requirement_key !== undefined) {
      if (parsed.lock_product_id) {
        locked[parsed.lock_requirement_key] = parsed.lock_product_id;
      } else {
        delete locked[parsed.lock_requirement_key];
      }
    }

    const updated = updateShoppingConfig(db, {
      include_optional: parsed.include_optional,
      include_garnish: parsed.include_garnish,
      include_pantry_staples: parsed.include_pantry_staples,
      locked_assignments: locked,
    });
    return NextResponse.json({
      shopping_config: updated,
      snapshot: loadWorkspaceSnapshot(),
    });
  } catch (err) {
    return NextResponse.json(
      {error: err instanceof Error ? err.message : 'Failed to update shopping settings'},
      {status: 400}
    );
  }
}
