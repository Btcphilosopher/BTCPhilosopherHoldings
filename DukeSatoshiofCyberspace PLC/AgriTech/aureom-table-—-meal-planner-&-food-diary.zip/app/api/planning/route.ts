import {NextRequest, NextResponse} from 'next/server';
import {z} from 'zod';
import {getDb} from '@/lib/server/db';
import {
  addPlannedMeal,
  copyDayMeals,
  deletePlannedMeal,
  previewCookMealPantryDeductions,
  saveWeekAsTemplate,
  updatePlannedMeal,
} from '@/lib/server/modules/planning';
import {confirmCookMealWithPantryDeductions} from '@/lib/server/modules/pantry';
import {loadWorkspaceSnapshot} from '@/lib/server/workspace';

const addMealSchema = z.object({
  action: z.literal('add_meal'),
  date: z.string().min(8),
  slot: z.enum(['breakfast', 'lunch', 'dinner', 'snack']),
  kind: z.enum(['recipe', 'simple', 'eating_out', 'takeaway', 'leftover']),
  recipe_id: z.string().nullable().optional(),
  title: z.string().min(1).max(160),
  servings: z.number().int().min(1).max(20),
  assigned_member_ids: z.array(z.string()).min(1),
  leftover_source_meal_id: z.string().nullable().optional(),
  leftover_portions_yielded: z.number().int().min(0).max(12).optional(),
  notes: z.string().max(400).optional(),
  prep_minutes: z.number().int().min(0).max(600).optional(),
  cook_minutes: z.number().int().min(0).max(600).optional(),
});

const copyDaySchema = z.object({
  action: z.literal('copy_day'),
  source_date: z.string().min(8),
  target_date: z.string().min(8),
});

const saveTemplateSchema = z.object({
  action: z.literal('save_template'),
  title: z.string().min(2).max(120),
});

const previewCookSchema = z.object({
  action: z.literal('preview_cook'),
  meal_id: z.string().min(1),
});

const confirmCookSchema = z.object({
  action: z.literal('confirm_cook'),
  meal_id: z.string().min(1),
  deductions: z.array(
    z.object({
      pantry_item_id: z.string().min(1),
      deduct_qty: z.number().min(0),
    })
  ),
});

const postSchema = z.discriminatedUnion('action', [
  addMealSchema,
  copyDaySchema,
  saveTemplateSchema,
  previewCookSchema,
  confirmCookSchema,
]);

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = postSchema.parse(body);
    const db = getDb();

    if (parsed.action === 'add_meal') {
      const meal = addPlannedMeal(db, parsed);
      return NextResponse.json({meal, snapshot: loadWorkspaceSnapshot()});
    }
    if (parsed.action === 'copy_day') {
      const created = copyDayMeals(db, parsed.source_date, parsed.target_date);
      return NextResponse.json({created, snapshot: loadWorkspaceSnapshot()});
    }
    if (parsed.action === 'save_template') {
      const template = saveWeekAsTemplate(db, parsed.title);
      return NextResponse.json({template, snapshot: loadWorkspaceSnapshot()});
    }
    if (parsed.action === 'preview_cook') {
      const deductions = previewCookMealPantryDeductions(db, parsed.meal_id);
      return NextResponse.json({deductions});
    }
    if (parsed.action === 'confirm_cook') {
      confirmCookMealWithPantryDeductions(
        db,
        parsed.meal_id,
        parsed.deductions
      );
      return NextResponse.json({snapshot: loadWorkspaceSnapshot()});
    }
    return NextResponse.json({error: 'Unsupported action'}, {status: 400});
  } catch (err) {
    return NextResponse.json(
      {error: err instanceof Error ? err.message : 'Invalid planning request'},
      {status: 400}
    );
  }
}

const patchSchema = z.object({
  meal_id: z.string().min(1),
  date: z.string().min(8).optional(),
  slot: z.enum(['breakfast', 'lunch', 'dinner', 'snack']).optional(),
  servings: z.number().int().min(1).max(20).optional(),
  title: z.string().min(1).max(160).optional(),
  kind: z.enum(['recipe', 'simple', 'eating_out', 'takeaway', 'leftover']).optional(),
  assigned_member_ids: z.array(z.string()).min(1).optional(),
  leftover_portions_yielded: z.number().int().min(0).max(12).optional(),
  notes: z.string().max(400).optional(),
  status: z.enum(['planned', 'cooked', 'skipped']).optional(),
});

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = patchSchema.parse(body);
    const db = getDb();
    const {meal_id, ...updates} = parsed;
    const result = updatePlannedMeal(db, meal_id, updates);
    return NextResponse.json({
      ...result,
      snapshot: loadWorkspaceSnapshot(),
    });
  } catch (err) {
    return NextResponse.json(
      {error: err instanceof Error ? err.message : 'Failed to update meal'},
      {status: 400}
    );
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const mealId = req.nextUrl.searchParams.get('meal_id');
    if (!mealId) {
      return NextResponse.json({error: 'meal_id is required'}, {status: 400});
    }
    const db = getDb();
    const result = deletePlannedMeal(db, mealId);
    return NextResponse.json({
      ...result,
      snapshot: loadWorkspaceSnapshot(),
    });
  } catch (err) {
    return NextResponse.json(
      {error: err instanceof Error ? err.message : 'Failed to delete meal'},
      {status: 400}
    );
  }
}
