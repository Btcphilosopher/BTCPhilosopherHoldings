package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.quant.BondPricingEngine
import com.example.ui.CbxUiState
import com.example.ui.CbxViewModel
import com.example.ui.CbxWorkspace
import com.example.ui.components.CbxMetricTile
import com.example.ui.components.CbxSimulatedBanner
import com.example.ui.components.CbxTerminalCard
import com.example.ui.theme.*

@Composable
fun BondMonitorScreen(
    uiState: CbxUiState,
    viewModel: CbxViewModel,
    modifier: Modifier = Modifier
) {
    val bond = uiState.selectedInstrument
    val cashFlows = BondPricingEngine.generateCashFlows(
        couponRate = bond.couponRate,
        frequency = bond.couponFrequency,
        maturityYears = bond.maturityYears,
        ytmPercent = bond.ytm
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            CbxSimulatedBanner()
        }

        // Instrument Master Header
        item {
            CbxTerminalCard(
                title = "Instrument Reference Master",
                badgeText = bond.verifiedRating
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column {
                        Text(
                            text = bond.ticker,
                            color = CbxTextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = bond.name,
                            color = CbxEdinburghGold,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Issuer: ${bond.issuer} (LEI: ${bond.issuerLei})",
                            color = CbxTextSecondary,
                            fontSize = 11.sp
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = { viewModel.selectWorkspace(CbxWorkspace.ORDER_BOOK) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CbxEdinburghGold,
                                contentColor = CbxNavyDark
                            ),
                            shape = RoundedCornerShape(2.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("monitor_to_order_book")
                        ) {
                            Text("TRADE BOOK", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Button(
                            onClick = { viewModel.selectWorkspace(CbxWorkspace.RFQ_DESK) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CbxNavyElevated,
                                contentColor = CbxCaledonianBlue
                            ),
                            shape = RoundedCornerShape(2.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("monitor_to_rfq")
                        ) {
                            Text("RFQ DESK", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Metadata Metrics Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CbxMetricTile("ISIN", bond.isin, modifier = Modifier.weight(1.3f))
                    CbxMetricTile("Day Count", bond.dayCount.label, modifier = Modifier.weight(1.2f))
                    CbxMetricTile("Governing Law", bond.governingLaw.label, modifier = Modifier.weight(1f))
                    CbxMetricTile("Seniority", bond.seniority.label, modifier = Modifier.weight(1.2f))
                }
            }
        }

        // Analytical & Valuation Sensitivities
        item {
            CbxTerminalCard(
                title = "Pricing & Fixed-Income Sensitivities",
                badgeText = "ANALYTICS ENGINE"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CbxMetricTile("Clean Price", "£%.2f".format(bond.cleanPrice), valueColor = CbxTextPrimary, modifier = Modifier.weight(1f))
                    CbxMetricTile("Accrued Interest", "£%.2f".format(bond.accruedInterest), valueColor = CbxTextSecondary, modifier = Modifier.weight(1f))
                    CbxMetricTile("Dirty Price", "£%.2f".format(bond.dirtyPrice), valueColor = CbxEdinburghGold, modifier = Modifier.weight(1f))
                    CbxMetricTile("Yield to Maturity", "%.2f%%".format(bond.ytm), valueColor = CbxProfitGreen, modifier = Modifier.weight(1f))
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CbxMetricTile("Macaulay Duration", "%.2f yrs".format(bond.macaulayDuration), modifier = Modifier.weight(1f))
                    CbxMetricTile("Modified Duration", "%.2f".format(bond.modifiedDuration), modifier = Modifier.weight(1f))
                    CbxMetricTile("Convexity", "%.2f".format(bond.convexity), modifier = Modifier.weight(1f))
                    CbxMetricTile("DV01 / £100k", "£%.2f".format(bond.dv01Per100k), valueColor = CbxCaledonianBlue, modifier = Modifier.weight(1f))
                }
            }
        }

        // Scheduled Cash Flows Table
        item {
            CbxTerminalCard(
                title = "Contractual Cash Flow Schedule",
                badgeText = "${cashFlows.size} PERIODS"
            ) {
                // Table Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CbxNavyElevated)
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("PERIOD", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                    Text("DATE", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                    Text("COUPON", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text("PRINCIPAL", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text("TOTAL CF", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text("DISCOUNT", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text("PV (GBP)", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                }

                cashFlows.forEach { flow ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 6.dp, vertical = 3.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${flow.period}", color = CbxTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                        Text(flow.paymentDate, color = CbxTextPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                        Text("£%.2f".format(flow.couponAmount), color = CbxTextPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text(if (flow.principalAmount > 0) "£%.2f".format(flow.principalAmount) else "-", color = CbxTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text("£%.2f".format(flow.totalCashFlow), color = CbxEdinburghGold, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text("%.4f".format(flow.discountFactor), color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text("£%.2f".format(flow.presentValue), color = CbxCaledonianBlue, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                    }
                    Divider(color = CbxNavyBorderSubtle, thickness = 1.dp)
                }
            }
        }
    }
}
