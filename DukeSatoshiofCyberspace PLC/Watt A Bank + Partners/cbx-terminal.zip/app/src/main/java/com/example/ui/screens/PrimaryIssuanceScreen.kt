package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.CbxUiState
import com.example.ui.CbxViewModel
import com.example.ui.components.CbxMetricTile
import com.example.ui.components.CbxSimulatedBanner
import com.example.ui.components.CbxTerminalCard
import com.example.ui.theme.*

@Composable
fun PrimaryIssuanceScreen(
    uiState: CbxUiState,
    viewModel: CbxViewModel,
    modifier: Modifier = Modifier
) {
    val selectedDeal = uiState.primaryDeals.find { it.dealId == uiState.selectedDealId } ?: uiState.primaryDeals[0]

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            CbxSimulatedBanner()
        }

        // Deal Selector Tab Bar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                uiState.primaryDeals.forEach { deal ->
                    val isSelected = deal.dealId == selectedDeal.dealId
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(if (isSelected) CbxNavyElevated else CbxNavySurface, RoundedCornerShape(2.dp))
                            .border(1.dp, if (isSelected) CbxEdinburghGold else CbxNavyBorder, RoundedCornerShape(2.dp))
                            .clickable { viewModel.selectPrimaryDeal(deal.dealId) }
                            .padding(8.dp)
                            .testTag("select_deal_${deal.dealId.lowercase()}")
                    ) {
                        Column {
                            Text(
                                text = deal.issuerName,
                                color = if (isSelected) CbxEdinburghGold else CbxTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "Target: £%,dM • ${deal.status.label}".format(deal.targetNominalGbp / 1_000_000L),
                                color = CbxTextSecondary,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Deal Master Terms Card
        item {
            CbxTerminalCard(
                title = "Primary Deal Profile — ${selectedDeal.ticker}",
                badgeText = selectedDeal.status.label
            ) {
                Text(
                    text = selectedDeal.programmeTitle,
                    color = CbxTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Sector: ${selectedDeal.sector} • Legal: ${selectedDeal.governingLaw.label}",
                    color = CbxTextSecondary,
                    fontSize = 11.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CbxMetricTile("Target Principal", "£%,dM".format(selectedDeal.targetNominalGbp / 1_000_000L), modifier = Modifier.weight(1f))
                    CbxMetricTile("Tenor", "${selectedDeal.tenorYears} Years", modifier = Modifier.weight(0.8f))
                    CbxMetricTile("Price Guidance", selectedDeal.indicativeSpreadGuidanceBps, valueColor = CbxCaledonianBlue, modifier = Modifier.weight(1.3f))
                    CbxMetricTile("Expected Coupon", "%.2f%%".format(selectedDeal.expectedCouponRate), valueColor = CbxEdinburghGold, modifier = Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Bookbuilding Progress Bar
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "ORDER BOOK COVERAGE: £%,dM Subscribed (%.2fx Covered)".format(
                                selectedDeal.totalOrderBookGbp / 1_000_000L,
                                selectedDeal.bookCoverRatio
                            ),
                            color = CbxProfitGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Target: £%,dM".format(selectedDeal.targetNominalGbp / 1_000_000L),
                            color = CbxTextMuted,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    LinearProgressIndicator(
                        progress = { (selectedDeal.totalOrderBookGbp.toFloat() / (selectedDeal.targetNominalGbp * 3f)).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp),
                        color = CbxProfitGreen,
                        trackColor = CbxNavyDark,
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Use of Proceeds: ${selectedDeal.useOfProceeds}",
                    color = CbxTextSecondary,
                    fontSize = 10.sp,
                    lineHeight = 14.sp
                )
                Text(
                    text = "Syndicate Leads: ${selectedDeal.leadManagers.joinToString(", ")}",
                    color = CbxTextMuted,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Institutional Syndicate Allocations
        item {
            CbxTerminalCard(
                title = "Syndicate Order Book & Allocations",
                badgeText = "${selectedDeal.orders.size} INSTITUTIONAL ACCOUNTS"
            ) {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CbxNavyElevated)
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("INVESTOR ACCOUNT", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.8f))
                    Text("TYPE", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                    Text("BID (SPREAD)", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text("ORDER", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text("ALLOCATED", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                }

                selectedDeal.orders.forEach { order ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.8f)) {
                            Text(order.institutionName, color = CbxTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                            Text(order.jurisdiction, color = CbxTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        }
                        Text(order.institutionType, color = CbxTextSecondary, fontSize = 9.sp, modifier = Modifier.weight(1.2f))
                        Text("+${order.bidYieldSpreadBps} bps", color = CbxCaledonianBlue, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text("£%,dM".format(order.orderNominalGbp / 1_000_000L), color = CbxTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text("£%,dM".format(order.allocatedNominalGbp / 1_000_000L), color = CbxEdinburghGold, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                    }
                    Divider(color = CbxNavyBorderSubtle, thickness = 1.dp)
                }
            }
        }
    }
}
