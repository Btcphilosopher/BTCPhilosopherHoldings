package com.example.model

enum class CurveCategory(val label: String) {
    UK_GILTS("UK Conventional Gilts"),
    SONIA_OIS("Sterling SONIA OIS Benchmark"),
    STERLING_CORP_BBB("Sterling Corporate BBB Spread"),
    CBX_SCOTTISH_BENCHMARK("CBX Scottish Growth Yield Curve")
}

data class CurvePoint(
    val tenorLabel: String,
    val tenorYears: Double,
    val parYield: Double,
    val zeroRate: Double,
    val forwardRate: Double,
    val discountFactor: Double
)

data class YieldCurve(
    val id: String,
    val name: String,
    val category: CurveCategory,
    val currency: String = "GBP",
    val points: List<CurvePoint>,
    val valuationTimestamp: String,
    val methodology: String = "Svensson Parametric & Nelson-Siegel Fit",
    val isSimulated: Boolean = true
)
