package com.example.model

data class DebtMaturityBucket(
    val yearLabel: String,
    val amountGbpM: Double,
    val instrumentType: String,
    val couponPct: Double
)

data class FinancialStatementYear(
    val fiscalYear: String,
    val revenueGbpM: Double,
    val grossProfitGbpM: Double,
    val ebitdaGbpM: Double,
    val operatingIncomeGbpM: Double,
    val netIncomeGbpM: Double,
    val operatingCashFlowGbpM: Double,
    val capexGbpM: Double,
    val freeCashFlowGbpM: Double,
    val totalDebtGbpM: Double,
    val cashEquivalentsGbpM: Double,
    val netDebtGbpM: Double,
    val netLeverage: Double,
    val interestCoverage: Double
)

data class CovenantRule(
    val name: String,
    val thresholdText: String,
    val currentLevelText: String,
    val headroomPercent: Double,
    val isCompliant: Boolean
)

data class IssuerCreditProfile(
    val issuerId: String,
    val legalName: String,
    val shortName: String,
    val sector: String,
    val headquarters: String,
    val lei: String,
    val cbxInternalRating: String, // e.g. "CBX Tier-2 (A- equivalent)"
    val ratingOutlook: String, // "Stable", "Positive", "Under Review"
    val externalBenchmarkRating: String,
    val financials: List<FinancialStatementYear>,
    val debtMaturityProfile: List<DebtMaturityBucket>,
    val covenants: List<CovenantRule>,
    val analystCommentary: String,
    val keyStrengths: List<String>,
    val keyCreditRisks: List<String>,
    val lastReviewDate: String,
    val leadAnalyst: String
)
