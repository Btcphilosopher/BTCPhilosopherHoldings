package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.CbxUiState
import com.example.ui.CbxViewModel
import com.example.ui.components.CbxMetricTile
import com.example.ui.components.CbxSimulatedBanner
import com.example.ui.components.CbxTerminalCard
import com.example.ui.components.CbxYieldCurveChart
import com.example.ui.theme.*

@Composable
fun YieldCurvesScreen(
    uiState: CbxUiState,
    viewModel: CbxViewModel,
    modifier: Modifier = Modifier
) {
    val giltCurve = uiState.giltCurve
    val p2y = giltCurve.points.find { it.tenorLabel == "2Y" }?.parYield ?: 4.15
    val p10y = giltCurve.points.find { it.tenorLabel == "10Y" }?.parYield ?: 4.24
    val p30y = giltCurve.points.find { it.tenorLabel == "30Y" }?.parYield ?: 4.62
    val slope2s10sBps = ((p10y - p2y) * 100).toInt()
    val slope10s30sBps = ((p30y - p10y) * 100).toInt()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            CbxSimulatedBanner()
        }

        // Curve Canvas & Visualizer
        item {
            CbxTerminalCard(
                title = "Sterling Term Structure of Interest Rates",
                badgeText = giltCurve.methodology
            ) {
                CbxYieldCurveChart(
                    giltCurve = giltCurve,
                    scottishCurve = uiState.scottishCurve,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CbxMetricTile("2Y Benchmark", "%.2f%%".format(p2y), modifier = Modifier.weight(1f))
                    CbxMetricTile("10Y Benchmark", "%.2f%%".format(p10y), valueColor = CbxEdinburghGold, modifier = Modifier.weight(1f))
                    CbxMetricTile("30Y Benchmark", "%.2f%%".format(p30y), modifier = Modifier.weight(1f))
                    CbxMetricTile("2s10s Slope", "${if (slope2s10sBps >= 0) "+$slope2s10sBps" else "$slope2s10sBps"} bps", valueColor = CbxCaledonianBlue, modifier = Modifier.weight(1f))
                    CbxMetricTile("10s30s Slope", "${if (slope10s30sBps >= 0) "+$slope10s30sBps" else "$slope10s30sBps"} bps", valueColor = CbxScottishHeather, modifier = Modifier.weight(1f))
                }
            }
        }

        // Scenario & Shift Controls
        item {
            CbxTerminalCard(
                title = "Yield Curve Shift & Shock Controls",
                badgeText = "SENSITIVITY ANALYSIS"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Parallel Curve Shift: ${if (uiState.curveShiftBps >= 0) "+${uiState.curveShiftBps}" else "${uiState.curveShiftBps}"} bps",
                        color = CbxTextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Button(
                            onClick = { viewModel.adjustCurveShift(-25) },
                            colors = ButtonDefaults.buttonColors(containerColor = CbxNavyElevated, contentColor = CbxEdinburghGold),
                            shape = RoundedCornerShape(2.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(28.dp).testTag("shift_minus_25")
                        ) {
                            Text("-25 bps", fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                        Button(
                            onClick = { viewModel.adjustCurveShift(0) },
                            colors = ButtonDefaults.buttonColors(containerColor = CbxNavyElevated, contentColor = CbxTextSecondary),
                            shape = RoundedCornerShape(2.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(28.dp).testTag("shift_reset")
                        ) {
                            Text("Reset", fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                        Button(
                            onClick = { viewModel.adjustCurveShift(+25) },
                            colors = ButtonDefaults.buttonColors(containerColor = CbxNavyElevated, contentColor = CbxEdinburghGold),
                            shape = RoundedCornerShape(2.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(28.dp).testTag("shift_plus_25")
                        ) {
                            Text("+25 bps", fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                        Button(
                            onClick = { viewModel.adjustCurveShift(+100) },
                            colors = ButtonDefaults.buttonColors(containerColor = CbxNavyElevated, contentColor = CbxLossRed),
                            shape = RoundedCornerShape(2.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(28.dp).testTag("shift_plus_100")
                        ) {
                            Text("+100 bps", fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // Tenor Points Grid
        item {
            CbxTerminalCard(
                title = "Term Structure Tenor Points",
                badgeText = "DISCOUNT FACTORS & ZERO RATES"
            ) {
                // Table Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CbxNavyElevated)
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("TENOR", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                    Text("YEARS", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                    Text("PAR YIELD", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text("ZERO RATE", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text("FORWARD", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text("DISCOUNT FACTOR", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                }

                giltCurve.points.forEach { pt ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 6.dp, vertical = 3.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(pt.tenorLabel, color = CbxEdinburghGold, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                        Text("%.2f".format(pt.tenorYears), color = CbxTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                        Text("%.3f%%".format(pt.parYield), color = CbxTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text("%.3f%%".format(pt.zeroRate), color = CbxCaledonianBlue, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text("%.3f%%".format(pt.forwardRate), color = CbxTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text("%.4f".format(pt.discountFactor), color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                    }
                    Divider(color = CbxNavyBorderSubtle, thickness = 1.dp)
                }
            }
        }
    }
}
