package com.example.quant

import com.example.model.BondInstrument
import com.example.model.CouponType
import com.example.model.ScheduledCashFlow
import kotlin.math.abs
import kotlin.math.pow

object BondPricingEngine {

    /**
     * Generates the scheduled coupon and principal cash flows for an instrument.
     */
    fun generateCashFlows(
        couponRate: Double,
        frequency: Int,
        maturityYears: Double,
        ytmPercent: Double,
        denomination: Double = 100.0
    ): List<ScheduledCashFlow> {
        val totalPeriods = (maturityYears * frequency).toInt().coerceAtLeast(1)
        val couponPerPeriod = (couponRate / frequency) * (denomination / 100.0)
        val periodicRate = (ytmPercent / 100.0) / frequency
        val flows = mutableListOf<ScheduledCashFlow>()

        for (i in 1..totalPeriods) {
            val isFinal = (i == totalPeriods)
            val couponAmount = couponPerPeriod
            val principalAmount = if (isFinal) denomination else 0.0
            val total = couponAmount + principalAmount
            val discountFactor = 1.0 / (1.0 + periodicRate).pow(i)
            val presentValue = total * discountFactor
            val yearsFromNow = i.toDouble() / frequency

            flows.add(
                ScheduledCashFlow(
                    period = i,
                    paymentDate = "+%.1f yrs".format(yearsFromNow),
                    couponAmount = couponAmount,
                    principalAmount = principalAmount,
                    totalCashFlow = total,
                    discountFactor = discountFactor,
                    presentValue = presentValue
                )
            )
        }
        return flows
    }

    /**
     * Calculates dirty price from yield-to-maturity.
     */
    fun dirtyPriceFromYield(
        couponRate: Double,
        frequency: Int,
        maturityYears: Double,
        ytmPercent: Double,
        denomination: Double = 100.0
    ): Double {
        val totalPeriods = (maturityYears * frequency).toInt().coerceAtLeast(1)
        val couponPerPeriod = (couponRate / frequency) * (denomination / 100.0)
        val periodicRate = (ytmPercent / 100.0) / frequency

        if (periodicRate <= -0.99) return denomination * 2.0 // safety bound

        var pv = 0.0
        for (i in 1..totalPeriods) {
            val cf = if (i == totalPeriods) couponPerPeriod + denomination else couponPerPeriod
            pv += cf / (1.0 + periodicRate).pow(i)
        }
        return pv
    }

    /**
     * Derivative of dirty price with respect to annual yield (for Newton-Raphson).
     */
    private fun dirtyPriceDerivative(
        couponRate: Double,
        frequency: Int,
        maturityYears: Double,
        ytmPercent: Double,
        denomination: Double = 100.0
    ): Double {
        val totalPeriods = (maturityYears * frequency).toInt().coerceAtLeast(1)
        val couponPerPeriod = (couponRate / frequency) * (denomination / 100.0)
        val periodicRate = (ytmPercent / 100.0) / frequency

        var deriv = 0.0
        for (i in 1..totalPeriods) {
            val cf = if (i == totalPeriods) couponPerPeriod + denomination else couponPerPeriod
            deriv += -i * cf / (frequency * (1.0 + periodicRate).pow(i + 1))
        }
        return deriv / 100.0 // wrt yield in percent
    }

    /**
     * Yield to maturity solver using robust Newton-Raphson with bisection fallback.
     */
    fun solveYieldToMaturity(
        targetDirtyPrice: Double,
        couponRate: Double,
        frequency: Int,
        maturityYears: Double,
        denomination: Double = 100.0
    ): Double {
        if (targetDirtyPrice <= 0.0) return 0.0

        var yieldGuess = couponRate.coerceAtLeast(0.5) // Initial guess
        val maxIterations = 50
        val tolerance = 0.0001

        // Newton-Raphson
        for (iter in 0 until maxIterations) {
            val price = dirtyPriceFromYield(couponRate, frequency, maturityYears, yieldGuess, denomination)
            val diff = price - targetDirtyPrice
            if (abs(diff) < tolerance) {
                return yieldGuess
            }
            val deriv = dirtyPriceDerivative(couponRate, frequency, maturityYears, yieldGuess, denomination)
            if (abs(deriv) < 1e-7) break // slope too flat, switch to bisection

            val nextGuess = yieldGuess - (diff / deriv)
            if (nextGuess < -5.0 || nextGuess > 50.0) break // exploded, switch to bisection
            yieldGuess = nextGuess
        }

        // Bisection Fallback
        var lowYield = -2.0
        var highYield = 35.0
        for (iter in 0 until 60) {
            val midYield = (lowYield + highYield) / 2.0
            val price = dirtyPriceFromYield(couponRate, frequency, maturityYears, midYield, denomination)
            val diff = price - targetDirtyPrice
            if (abs(diff) < tolerance) return midYield

            // Price is inversely related to yield
            if (price > targetDirtyPrice) {
                lowYield = midYield
            } else {
                highYield = midYield
            }
        }
        return (lowYield + highYield) / 2.0
    }

    /**
     * Calculates Macaulay and Modified Duration.
     */
    fun calculateDuration(
        couponRate: Double,
        frequency: Int,
        maturityYears: Double,
        ytmPercent: Double,
        dirtyPrice: Double,
        denomination: Double = 100.0
    ): Pair<Double, Double> {
        if (dirtyPrice <= 0.0) return Pair(0.0, 0.0)

        val totalPeriods = (maturityYears * frequency).toInt().coerceAtLeast(1)
        val couponPerPeriod = (couponRate / frequency) * (denomination / 100.0)
        val periodicRate = (ytmPercent / 100.0) / frequency

        var weightedTimeSum = 0.0
        for (i in 1..totalPeriods) {
            val cf = if (i == totalPeriods) couponPerPeriod + denomination else couponPerPeriod
            val pv = cf / (1.0 + periodicRate).pow(i)
            val years = i.toDouble() / frequency
            weightedTimeSum += years * pv
        }

        val macaulayDuration = weightedTimeSum / dirtyPrice
        val modifiedDuration = macaulayDuration / (1.0 + periodicRate)
        return Pair(macaulayDuration, modifiedDuration)
    }

    /**
     * Calculates Convexity.
     */
    fun calculateConvexity(
        couponRate: Double,
        frequency: Int,
        maturityYears: Double,
        ytmPercent: Double,
        dirtyPrice: Double,
        denomination: Double = 100.0
    ): Double {
        if (dirtyPrice <= 0.0) return 0.0

        val totalPeriods = (maturityYears * frequency).toInt().coerceAtLeast(1)
        val couponPerPeriod = (couponRate / frequency) * (denomination / 100.0)
        val periodicRate = (ytmPercent / 100.0) / frequency

        var sum = 0.0
        for (i in 1..totalPeriods) {
            val cf = if (i == totalPeriods) couponPerPeriod + denomination else couponPerPeriod
            val t = i.toDouble() / frequency
            val term = (t * (t + 1.0 / frequency)) * cf / (1.0 + periodicRate).pow(i + 2)
            sum += term
        }
        return sum / dirtyPrice
    }

    /**
     * Calculates DV01 (Dollar Value of 01 basis point) per £100,000 nominal.
     */
    fun calculateDV01(dirtyPrice: Double, modifiedDuration: Double, nominal: Double = 100_000.0): Double {
        // Price change for 1 bp = Price * ModDur * 0.0001
        return (dirtyPrice / 100.0) * modifiedDuration * 0.0001 * nominal
    }

    /**
     * Accrued Interest estimate for ICMA / 182-day semi-annual cycle.
     */
    fun calculateAccruedInterest(couponRate: Double, daysSinceLastCoupon: Int = 74, daysInPeriod: Int = 182): Double {
        return (couponRate / 2.0) * (daysSinceLastCoupon.toDouble() / daysInPeriod.toDouble())
    }

    /**
     * Recalculates full analytics for an instrument when price or yield changes.
     */
    fun enrichInstrument(inst: BondInstrument) {
        if (inst.couponType == CouponType.ZERO) {
            inst.accruedInterest = 0.0
            inst.dirtyPrice = inst.cleanPrice
            inst.ytm = ((inst.denomination / inst.cleanPrice).pow(1.0 / inst.maturityYears) - 1.0) * 100.0
            inst.macaulayDuration = inst.maturityYears
            inst.modifiedDuration = inst.maturityYears / (1.0 + inst.ytm / 100.0)
            inst.convexity = inst.maturityYears * (inst.maturityYears + 1.0) / (1.0 + inst.ytm / 100.0).pow(2)
            inst.dv01Per100k = calculateDV01(inst.dirtyPrice, inst.modifiedDuration, 100_000.0)
            return
        }

        inst.accruedInterest = calculateAccruedInterest(inst.couponRate)
        inst.dirtyPrice = inst.cleanPrice + inst.accruedInterest

        inst.ytm = solveYieldToMaturity(
            targetDirtyPrice = inst.dirtyPrice,
            couponRate = inst.couponRate,
            frequency = inst.couponFrequency,
            maturityYears = inst.maturityYears,
            denomination = inst.denomination
        )

        val (macDur, modDur) = calculateDuration(
            couponRate = inst.couponRate,
            frequency = inst.couponFrequency,
            maturityYears = inst.maturityYears,
            ytmPercent = inst.ytm,
            dirtyPrice = inst.dirtyPrice,
            denomination = inst.denomination
        )
        inst.macaulayDuration = macDur
        inst.modifiedDuration = modDur

        inst.convexity = calculateConvexity(
            couponRate = inst.couponRate,
            frequency = inst.couponFrequency,
            maturityYears = inst.maturityYears,
            ytmPercent = inst.ytm,
            dirtyPrice = inst.dirtyPrice,
            denomination = inst.denomination
        )

        inst.dv01Per100k = calculateDV01(inst.dirtyPrice, inst.modifiedDuration, 100_000.0)

        // Quotes spread
        inst.bidPrice = inst.cleanPrice - 0.15
        inst.askPrice = inst.cleanPrice + 0.15
        inst.bidYield = inst.ytm + 0.03
        inst.askYield = inst.ytm - 0.03
    }
}
