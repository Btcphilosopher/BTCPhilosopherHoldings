package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.CbxUiState
import com.example.ui.CbxViewModel
import com.example.ui.components.CbxSimulatedBanner
import com.example.ui.components.CbxTerminalCard
import com.example.ui.theme.*

@Composable
fun ResearchScreen(
    uiState: CbxUiState,
    viewModel: CbxViewModel,
    modifier: Modifier = Modifier
) {
    val articles = uiState.researchArticles

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            CbxSimulatedBanner()
        }

        item {
            CbxTerminalCard(
                title = "Caledonian Fixed-Income Strategy & Research",
                badgeText = "EDINBURGH DESK INTELLIGENCE"
            ) {
                Text(
                    text = "Institutional macro outlook, Gilt curve dynamics, and Scottish mid-market credit research produced by the Caledonian Bond Exchange quantitative research group.",
                    color = CbxTextSecondary,
                    fontSize = 11.sp
                )
            }
        }

        items(articles) { art ->
            CbxTerminalCard(
                title = art.title,
                badgeText = art.sector
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Author: ${art.author}",
                        color = CbxEdinburghGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = art.date,
                        color = CbxTextMuted,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = art.summary,
                    color = CbxTextPrimary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Key Analytical Takeaways:",
                    color = CbxCaledonianBlue,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )

                art.keyTakeaways.forEach { point ->
                    Text(
                        text = "• $point",
                        color = CbxTextSecondary,
                        fontSize = 10.sp,
                        lineHeight = 14.sp
                    )
                }
            }
        }
    }
}
