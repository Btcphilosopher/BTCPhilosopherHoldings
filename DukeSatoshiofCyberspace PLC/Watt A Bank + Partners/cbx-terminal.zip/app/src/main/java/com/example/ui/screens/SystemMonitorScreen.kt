package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.CbxUiState
import com.example.ui.CbxViewModel
import com.example.ui.components.CbxMetricTile
import com.example.ui.components.CbxSimulatedBanner
import com.example.ui.components.CbxTerminalCard
import com.example.ui.theme.*

@Composable
fun SystemMonitorScreen(
    uiState: CbxUiState,
    viewModel: CbxViewModel,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            CbxSimulatedBanner()
        }

        item {
            CbxTerminalCard(
                title = "Deterministic Matching Engine Telemetry",
                badgeText = "EDINBURGH NODE 01"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CbxMetricTile("Engine Ticks", "${uiState.engineTicks}", "Processed", valueColor = CbxEdinburghGold, modifier = Modifier.weight(1.2f))
                    CbxMetricTile("Matching Latency", "${uiState.executionLatencyMicros} µs", "Tick-to-Trade", valueColor = CbxProfitGreen, modifier = Modifier.weight(1.2f))
                    CbxMetricTile("Sequence Counter", "SEQ-${uiState.engineTicks * 3}", valueColor = CbxCaledonianBlue, modifier = Modifier.weight(1.3f))
                    CbxMetricTile("Sync Node", "EDIN-01-LOCAL", valueColor = CbxTextPrimary, modifier = Modifier.weight(1.2f))
                }
            }
        }

        item {
            CbxTerminalCard(
                title = "Subsystem Health & Architectural Contracts",
                badgeText = "ALL SERVICES HEALTHY"
            ) {
                val subsystems = listOf(
                    Triple("Deterministic Matching Core (Rust / Native Architecture)", "Continuous price-time priority limit order book with integer tick representation", "100% HEALTHY"),
                    Triple("Fixed-Income Pricing Engine (Python / Kotlin Service)", "Svensson yield curve bootstrapping, cash flow discount engine, Newton-Raphson YTM solver", "100% HEALTHY"),
                    Triple("Quantitative Risk Service", "Macaulay/Modified duration, convexity, DV01, macro curve parallel & steepener shocks", "100% HEALTHY"),
                    Triple("Bilateral RFQ Distributor", "Institutional quote distribution, dealer countdown expiry, CREST allocation pipelines", "100% HEALTHY"),
                    Triple("Primary Debt Bookbuilder", "Corporate bond syndication, investor allocation ledger, legal covenant checks", "100% HEALTHY"),
                    Triple("MiFIR RTS 25 Nanosecond Audit Stamping", "Immutable audit log event pipeline with legal entity identifier validation", "100% HEALTHY")
                )

                subsystems.forEach { (name, desc, status) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(2.2f)) {
                            Text(name, color = CbxTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Text(desc, color = CbxTextSecondary, fontSize = 9.sp, lineHeight = 13.sp)
                        }
                        Box(
                            modifier = Modifier
                                .background(CbxGreenBackground, RoundedCornerShape(2.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(status, color = CbxProfitGreen, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                    Divider(color = CbxNavyBorderSubtle, thickness = 1.dp)
                }
            }
        }
    }
}
