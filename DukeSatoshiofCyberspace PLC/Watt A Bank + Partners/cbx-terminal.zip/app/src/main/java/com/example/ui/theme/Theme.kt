package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val CbxColorScheme = darkColorScheme(
    primary = CbxEdinburghGold,
    onPrimary = CbxNavyDark,
    primaryContainer = CbxNavyElevated,
    onPrimaryContainer = CbxEdinburghGold,
    secondary = CbxCaledonianBlue,
    onSecondary = CbxNavyDark,
    secondaryContainer = CbxNavyElevated,
    onSecondaryContainer = CbxCaledonianBlue,
    tertiary = CbxScottishHeather,
    onTertiary = CbxNavyDark,
    background = CbxNavyDark,
    onBackground = CbxTextPrimary,
    surface = CbxNavySurface,
    onSurface = CbxTextPrimary,
    surfaceVariant = CbxNavyElevated,
    onSurfaceVariant = CbxTextSecondary,
    outline = CbxNavyBorder,
    outlineVariant = CbxNavyBorderSubtle,
    error = CbxLossRed,
    onError = CbxTextPrimary
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CbxColorScheme,
        typography = Typography,
        content = content
    )
}
