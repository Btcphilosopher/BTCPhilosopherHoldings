package com.example.model

data class PortfolioHolding(
    val holdingId: String,
    val instrumentId: String,
    val isin: String,
    val instrumentName: String,
    val issuer: String,
    val bondType: BondType,
    val nominalGbp: Long,
    val bookPrice: Double,
    val currentCleanPrice: Double,
    val dirtyPrice: Double,
    val marketValueGbp: Double,
    val unrealizedPnlGbp: Double,
    val ytm: Double,
    val modifiedDuration: Double,
    val dv01Gbp: Double,
    val portfolioWeightPct: Double
)

data class PortfolioSummary(
    val portfolioName: String,
    val mandate: String,
    val totalAumGbp: Double,
    val totalDv01Gbp: Double,
    val weightedYield: Double,
    val weightedDuration: Double,
    val weightedConvexity: Double,
    val holdings: List<PortfolioHolding>
)

data class StressTestResult(
    val scenarioName: String,
    val scenarioDescription: String,
    val shiftBps: Int,
    val pnlImpactGbp: Double,
    val percentImpact: Double,
    val newPortfolioValueGbp: Double
)
