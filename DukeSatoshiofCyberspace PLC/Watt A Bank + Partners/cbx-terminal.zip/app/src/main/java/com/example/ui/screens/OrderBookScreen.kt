package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.OrderSide
import com.example.model.OrderType
import com.example.ui.CbxUiState
import com.example.ui.CbxViewModel
import com.example.ui.components.CbxMetricTile
import com.example.ui.components.CbxSimulatedBanner
import com.example.ui.components.CbxTerminalCard
import com.example.ui.theme.*

@Composable
fun OrderBookScreen(
    uiState: CbxUiState,
    viewModel: CbxViewModel,
    modifier: Modifier = Modifier
) {
    val bond = uiState.selectedInstrument

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            CbxSimulatedBanner()
        }

        // Instrument Header & Spread Bar
        item {
            CbxTerminalCard(
                title = "Order Book — ${bond.ticker}",
                badgeText = "DETERMINISTIC SIMULATION"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = bond.name,
                            color = CbxTextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "ISIN: ${bond.isin} • Currency: GBP",
                            color = CbxTextSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    val spread = (bond.askPrice - bond.bidPrice)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CbxMetricTile("Best Bid", "£%.2f".format(bond.bidPrice), valueColor = CbxProfitGreen)
                        CbxMetricTile("Best Ask", "£%.2f".format(bond.askPrice), valueColor = CbxLossRed)
                        CbxMetricTile("Spread", "£%.2f".format(spread), valueColor = CbxEdinburghGold)
                    }
                }
            }
        }

        // Depth Ladder (Bids & Asks side-by-side or stacked)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Bids Ladder
                CbxTerminalCard(
                    title = "Bids (Buy Orders)",
                    badgeText = "${uiState.bidDepth.size} LEVELS",
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().background(CbxNavyElevated).padding(4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("PRICE", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        Text("SIZE (GBP)", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    }
                    uiState.bidDepth.forEach { level ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                        ) {
                            // Depth background bar
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(level.depthPercentage)
                                    .background(CbxBidDepthBar)
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 4.dp, vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "£%.2f".format(level.price),
                                    color = CbxProfitGreen,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "£%,d".format(level.size),
                                    color = CbxTextPrimary,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }

                // Asks Ladder
                CbxTerminalCard(
                    title = "Asks (Sell Orders)",
                    badgeText = "${uiState.askDepth.size} LEVELS",
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().background(CbxNavyElevated).padding(4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("PRICE", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        Text("SIZE (GBP)", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    }
                    uiState.askDepth.forEach { level ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                        ) {
                            // Depth background bar
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(level.depthPercentage)
                                    .background(CbxAskDepthBar)
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 4.dp, vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "£%.2f".format(level.price),
                                    color = CbxLossRed,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "£%,d".format(level.size),
                                    color = CbxTextPrimary,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        // Order Entry Ticket
        item {
            CbxTerminalCard(
                title = "Order Entry Ticket",
                badgeText = "PRE-TRADE RISK OK"
            ) {
                // Side Selector: Buy vs Sell
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.setOrderSide(OrderSide.BUY) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (uiState.orderInputSide == OrderSide.BUY) CbxProfitGreen else CbxNavyElevated,
                            contentColor = if (uiState.orderInputSide == OrderSide.BUY) CbxNavyDark else CbxTextSecondary
                        ),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.weight(1f).testTag("select_buy_side")
                    ) {
                        Text("BUY / BID", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                    Button(
                        onClick = { viewModel.setOrderSide(OrderSide.SELL) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (uiState.orderInputSide == OrderSide.SELL) CbxLossRed else CbxNavyElevated,
                            contentColor = if (uiState.orderInputSide == OrderSide.SELL) CbxNavyDark else CbxTextSecondary
                        ),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.weight(1f).testTag("select_sell_side")
                    ) {
                        Text("SELL / OFFER", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Price and Quantity Input
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = uiState.orderInputPriceText,
                        onValueChange = { viewModel.setOrderPriceText(it) },
                        label = { Text("Limit Clean Price (£)", fontSize = 10.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = CbxTextPrimary,
                            unfocusedTextColor = CbxTextPrimary,
                            focusedBorderColor = CbxEdinburghGold,
                            unfocusedBorderColor = CbxNavyBorder
                        ),
                        modifier = Modifier.weight(1f).testTag("order_price_input")
                    )
                    OutlinedTextField(
                        value = uiState.orderInputQtyText,
                        onValueChange = { viewModel.setOrderQtyText(it) },
                        label = { Text("Nominal Size (GBP)", fontSize = 10.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = CbxTextPrimary,
                            unfocusedTextColor = CbxTextPrimary,
                            focusedBorderColor = CbxEdinburghGold,
                            unfocusedBorderColor = CbxNavyBorder
                        ),
                        modifier = Modifier.weight(1f).testTag("order_qty_input")
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Quick Size Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("250000", "500000", "1000000", "2500000").forEach { sizeStr ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(CbxNavyElevated, RoundedCornerShape(2.dp))
                                .border(1.dp, CbxNavyBorder, RoundedCornerShape(2.dp))
                                .clickable { viewModel.setOrderQtyText(sizeStr) }
                                .padding(vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "£${sizeStr.toLong() / 1000}k",
                                color = CbxEdinburghGold,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Submit Button
                Button(
                    onClick = { viewModel.submitOrder() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CbxEdinburghGold,
                        contentColor = CbxNavyDark
                    ),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.fillMaxWidth().height(42.dp).testTag("submit_order_button")
                ) {
                    Text(
                        text = "SUBMIT ${uiState.orderInputSide.name} ORDER → MATCHING ENGINE",
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Execution Blotter Tape
        item {
            CbxTerminalCard(
                title = "Recent Execution Prints Tape",
                badgeText = "DETERMINISTIC FILLS"
            ) {
                if (uiState.recentTrades.isEmpty()) {
                    Text(
                        text = "No trades matched on current session yet. Submit an order to trigger execution.",
                        color = CbxTextMuted,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )
                } else {
                    uiState.recentTrades.take(5).forEach { trade ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "${trade.tradeId} • ${trade.timestamp}",
                                    color = CbxTextSecondary,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "${trade.side.name} £%,d of ${trade.instrumentName}".format(trade.quantity),
                                    color = CbxTextPrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "£%.2f".format(trade.price),
                                    color = if (trade.side == OrderSide.BUY) CbxProfitGreen else CbxLossRed,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "YTM %.2f%%".format(trade.yield),
                                    color = CbxEdinburghGold,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                        Divider(color = CbxNavyBorderSubtle, thickness = 1.dp)
                    }
                }
            }
        }
    }
}
