package com.example.model

enum class SettlementStatus(val label: String) {
    PENDING_MATCH("Pending CREST Match"),
    MATCHED("Matched / Settlement Scheduled"),
    SETTLED("Settled (DVP London)"),
    FAILED("Exception / Failed Settlement"),
    CANCELLED("Cancelled")
}

data class SettlementInstruction(
    val instructionId: String,
    val tradeId: String,
    val isin: String,
    val instrumentName: String,
    val buyer: String,
    val seller: String,
    val nominalGbp: Long,
    val settlementAmountGbp: Double, // dirty cash consideration
    val tradeDate: String,
    val settlementDate: String,
    var status: SettlementStatus,
    val crestReference: String,
    val depository: String = "Euroclear UK & International (CREST)"
)
