package com.example.model

enum class VenueMode(val label: String, val badge: String) {
    SIMULATION_SANDBOX("Local Matching Simulation", "SIM-LOCAL"),
    BILATERAL_RFQ("Bilateral Institutional RFQ", "RFQ-DEALER"),
    RESEARCH_ANALYTICS("Analytical & Valuation Terminal", "VAL-TERM")
}

data class AuditLogEntry(
    val logId: String,
    val timestamp: String,
    val category: String, // e.g. "ORDER_EXECUTION", "RFQ_ACCEPT", "RISK_CHECK", "SETTLEMENT"
    val actor: String,
    val details: String,
    val rts25TimestampNanos: Long = System.currentTimeMillis() * 1_000_000L,
    val status: String = "VERIFIED_AUDIT"
)

data class ResearchArticle(
    val articleId: String,
    val title: String,
    val author: String,
    val date: String,
    val sector: String,
    val summary: String,
    val keyTakeaways: List<String>
)
