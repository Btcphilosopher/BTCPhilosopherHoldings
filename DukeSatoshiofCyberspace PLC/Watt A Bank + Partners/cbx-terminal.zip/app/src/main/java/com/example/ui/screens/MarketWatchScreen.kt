package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BondInstrument
import com.example.model.BondType
import com.example.ui.CbxUiState
import com.example.ui.CbxViewModel
import com.example.ui.CbxWorkspace
import com.example.ui.components.CbxSimulatedBanner
import com.example.ui.theme.*

@Composable
fun MarketWatchScreen(
    uiState: CbxUiState,
    viewModel: CbxViewModel,
    modifier: Modifier = Modifier
) {
    val filteredBonds = uiState.instruments.filter { bond ->
        val matchesType = uiState.activeBondTypeFilter == null || bond.bondType == uiState.activeBondTypeFilter
        val matchesSearch = uiState.searchQuery.isEmpty() ||
                bond.ticker.contains(uiState.searchQuery, ignoreCase = true) ||
                bond.name.contains(uiState.searchQuery, ignoreCase = true) ||
                bond.isin.contains(uiState.searchQuery, ignoreCase = true) ||
                bond.issuer.contains(uiState.searchQuery, ignoreCase = true)
        matchesType && matchesSearch
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp)
    ) {
        CbxSimulatedBanner()
        Spacer(modifier = Modifier.height(6.dp))

        // Sector / Type Filter Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FilterChip(
                selected = uiState.activeBondTypeFilter == null,
                onClick = { viewModel.setBondTypeFilter(null) },
                label = { Text("ALL BONDS (${uiState.instruments.size})", fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = CbxEdinburghGold,
                    selectedLabelColor = CbxNavyDark,
                    containerColor = CbxNavyElevated,
                    labelColor = CbxTextSecondary
                ),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.testTag("filter_all_bonds")
            )
            BondType.values().forEach { bType ->
                FilterChip(
                    selected = uiState.activeBondTypeFilter == bType,
                    onClick = { viewModel.setBondTypeFilter(bType) },
                    label = { Text(bType.label.uppercase(), fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CbxEdinburghGold,
                        selectedLabelColor = CbxNavyDark,
                        containerColor = CbxNavyElevated,
                        labelColor = CbxTextSecondary
                    ),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.testTag("filter_type_${bType.name.lowercase()}")
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Table Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CbxNavyElevated)
                .border(1.dp, CbxNavyBorder)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("INSTRUMENT / ISIN", color = CbxTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(2f))
            Text("PRICE (BID/ASK)", color = CbxTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
            Text("YTM", color = CbxTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
            Text("G-SPREAD", color = CbxTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
            Text("DV01", color = CbxTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
            Text("ACTIONS", color = CbxTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
        }

        // Table Rows
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            items(filteredBonds) { bond ->
                val isSelected = bond.id == uiState.selectedInstrument.id
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (isSelected) CbxNavyElevated else CbxNavySurface)
                        .border(1.dp, if (isSelected) CbxEdinburghGold.copy(alpha = 0.5f) else CbxNavyBorder)
                        .clickable { viewModel.selectInstrument(bond) }
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Col 1: Instrument & Ticker
                    Column(modifier = Modifier.weight(2f)) {
                        Text(
                            text = bond.ticker,
                            color = CbxTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = bond.name,
                            color = CbxTextSecondary,
                            fontSize = 9.sp,
                            maxLines = 1
                        )
                        Text(
                            text = "${bond.isin} • ${bond.governingLaw.label}",
                            color = CbxTextMuted,
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // Col 2: Bid / Ask Clean Price
                    Column(modifier = Modifier.weight(1.3f)) {
                        Text(
                            text = "%.2f / %.2f".format(bond.bidPrice, bond.askPrice),
                            color = CbxTextPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Mid: %.2f".format(bond.cleanPrice),
                            color = CbxTextMuted,
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // Col 3: YTM
                    Text(
                        text = "%.2f%%".format(bond.ytm),
                        color = CbxEdinburghGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.weight(0.9f)
                    )

                    // Col 4: G-Spread
                    Text(
                        text = "${if (bond.giltSpreadBps >= 0) "+${bond.giltSpreadBps}" else "${bond.giltSpreadBps}"} bp",
                        color = CbxCaledonianBlue,
                        fontWeight = FontWeight.Medium,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.weight(1f)
                    )

                    // Col 5: DV01
                    Text(
                        text = "£%.1f".format(bond.dv01Per100k),
                        color = CbxTextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.weight(0.8f)
                    )

                    // Col 6: Actions
                    Row(
                        modifier = Modifier.weight(1.2f),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.selectInstrument(bond)
                                viewModel.selectWorkspace(CbxWorkspace.ORDER_BOOK)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CbxNavyDark,
                                contentColor = CbxEdinburghGold
                            ),
                            shape = RoundedCornerShape(2.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.height(24.dp).testTag("trade_bond_${bond.id.lowercase()}")
                        ) {
                            Text("BOOK", fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        }
                        Button(
                            onClick = {
                                viewModel.selectInstrument(bond)
                                viewModel.selectWorkspace(CbxWorkspace.BOND_MONITOR)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CbxNavyDark,
                                contentColor = CbxCaledonianBlue
                            ),
                            shape = RoundedCornerShape(2.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.height(24.dp).testTag("view_bond_${bond.id.lowercase()}")
                        ) {
                            Text("VIEW", fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}
