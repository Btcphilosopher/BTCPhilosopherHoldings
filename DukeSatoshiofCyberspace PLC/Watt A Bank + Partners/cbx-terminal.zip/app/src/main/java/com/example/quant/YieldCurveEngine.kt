package com.example.quant

import com.example.model.CurveCategory
import com.example.model.CurvePoint
import com.example.model.YieldCurve
import kotlin.math.exp
import kotlin.math.pow

object YieldCurveEngine {

    /**
     * Interpolates the yield at any tenor using Nelson-Siegel model:
     * y(t) = beta0 + beta1 * ((1 - exp(-t/lambda))/(t/lambda)) + beta2 * (((1 - exp(-t/lambda))/(t/lambda)) - exp(-t/lambda))
     */
    fun evaluateNelsonSiegel(
        tenorYears: Double,
        beta0: Double,
        beta1: Double,
        beta2: Double,
        lambda: Double = 2.0
    ): Double {
        if (tenorYears <= 0.05) return beta0 + beta1
        val m = tenorYears / lambda
        val term1 = (1.0 - exp(-m)) / m
        val term2 = term1 - exp(-m)
        return beta0 + beta1 * term1 + beta2 * term2
    }

    /**
     * Constructs standard UK benchmark curve points.
     */
    fun generateGiltCurve(parallelShiftBps: Int = 0, slopeShiftBps: Int = 0): YieldCurve {
        val shiftPct = parallelShiftBps / 100.0
        val slopePct = slopeShiftBps / 100.0

        val tenors = listOf(
            Pair("1M", 0.083),
            Pair("3M", 0.25),
            Pair("6M", 0.5),
            Pair("1Y", 1.0),
            Pair("2Y", 2.0),
            Pair("3Y", 3.0),
            Pair("5Y", 5.0),
            Pair("7Y", 7.0),
            Pair("10Y", 10.0),
            Pair("15Y", 15.0),
            Pair("20Y", 20.0),
            Pair("30Y", 30.0)
        )

        // Baseline UK Gilts par yields: inverted/flat front-end transitioning into flat long-end
        val b0 = 4.35 + shiftPct
        val b1 = 0.85 - slopePct
        val b2 = -1.10

        val points = tenors.map { (label, years) ->
            val parYield = evaluateNelsonSiegel(years, b0, b1, b2).coerceAtLeast(0.1)
            val zeroRate = parYield + 0.04
            val forwardRate = parYield + 0.08 * (years / 10.0)
            val discountFactor = 1.0 / (1.0 + zeroRate / 100.0).pow(years)

            CurvePoint(
                tenorLabel = label,
                tenorYears = years,
                parYield = (parYield * 1000).toInt() / 1000.0,
                zeroRate = (zeroRate * 1000).toInt() / 1000.0,
                forwardRate = (forwardRate * 1000).toInt() / 1000.0,
                discountFactor = (discountFactor * 10000).toInt() / 10000.0
            )
        }

        return YieldCurve(
            id = "CRV-UKT-BENCHMARK",
            name = "UK Conventional Gilt Curve",
            category = CurveCategory.UK_GILTS,
            points = points,
            valuationTimestamp = "11:30:00 BST (Edinburgh Market Close)",
            methodology = "Bank of England Svensson Model Re-estimation",
            isSimulated = true
        )
    }

    /**
     * Constructs Sterling SONIA Overnight Index Swap curve.
     */
    fun generateSoniaCurve(): YieldCurve {
        val tenors = listOf(
            Pair("1M", 0.083),
            Pair("3M", 0.25),
            Pair("6M", 0.5),
            Pair("1Y", 1.0),
            Pair("2Y", 2.0),
            Pair("3Y", 3.0),
            Pair("5Y", 5.0),
            Pair("7Y", 7.0),
            Pair("10Y", 10.0),
            Pair("15Y", 15.0),
            Pair("20Y", 20.0),
            Pair("30Y", 30.0)
        )

        val points = tenors.map { (label, years) ->
            val parYield = (4.75 - 0.04 * years).coerceAtLeast(3.80)
            val discountFactor = 1.0 / (1.0 + parYield / 100.0).pow(years)
            CurvePoint(
                tenorLabel = label,
                tenorYears = years,
                parYield = (parYield * 1000).toInt() / 1000.0,
                zeroRate = ((parYield + 0.02) * 1000).toInt() / 1000.0,
                forwardRate = ((parYield + 0.05) * 1000).toInt() / 1000.0,
                discountFactor = (discountFactor * 10000).toInt() / 10000.0
            )
        }

        return YieldCurve(
            id = "CRV-SONIA-OIS",
            name = "Sterling SONIA OIS Benchmark",
            category = CurveCategory.SONIA_OIS,
            points = points,
            valuationTimestamp = "11:30:00 BST",
            methodology = "Bootstrapped from Sterling OIS Money Market Quotes",
            isSimulated = true
        )
    }

    /**
     * Constructs Scottish Corporate Growth indicative curve.
     */
    fun generateScottishCorporateCurve(giltCurve: YieldCurve): YieldCurve {
        val points = giltCurve.points.map { pt ->
            val corpYield = pt.parYield + 1.85 // +185 bps credit spread
            val discountFactor = 1.0 / (1.0 + corpYield / 100.0).pow(pt.tenorYears)
            CurvePoint(
                tenorLabel = pt.tenorLabel,
                tenorYears = pt.tenorYears,
                parYield = (corpYield * 1000).toInt() / 1000.0,
                zeroRate = ((corpYield + 0.05) * 1000).toInt() / 1000.0,
                forwardRate = ((corpYield + 0.12) * 1000).toInt() / 1000.0,
                discountFactor = (discountFactor * 10000).toInt() / 10000.0
            )
        }

        return YieldCurve(
            id = "CRV-CBX-SCOTTISH-CORP",
            name = "CBX Scottish Growth Corporate Curve",
            category = CurveCategory.CBX_SCOTTISH_BENCHMARK,
            points = points,
            valuationTimestamp = "11:30:00 BST",
            methodology = "Gilt Reference + Sector Spread Matrix",
            isSimulated = true
        )
    }
}
