package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CbxRepository
import com.example.model.*
import com.example.quant.BondPricingEngine
import com.example.quant.YieldCurveEngine
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class CbxWorkspace(val id: String, val title: String, val category: String) {
    CBX_HOME("HOME", "CBX Home", "Overview"),
    MARKET_WATCH("MKTS", "Market Watch", "Markets"),
    BOND_MONITOR("BOND", "Bond Monitor", "Markets"),
    ORDER_BOOK("BOOK", "Order Book", "Markets"),
    TRADE_BLOTTER("BLOT", "Trade Blotter", "Markets"),
    RFQ_DESK("RFQ", "RFQ Desk", "Markets"),
    PRIMARY_ISSUANCE("PRIM", "Primary Issuance", "Primary"),
    ISSUER_CREDIT("CRED", "Issuer Credit", "Credit"),
    YIELD_CURVES("CURV", "Yield Curves", "Analytics"),
    BOND_ANALYTICS("CALC", "Bond Analytics", "Analytics"),
    PORTFOLIO_RISK("PORT", "Portfolio Risk", "Analytics"),
    SETTLEMENT("SETL", "Settlement", "Operations"),
    CORPORATE_ACTIONS("CORP", "Corporate Actions", "Operations"),
    RESEARCH("RSRCH", "Research", "Governance"),
    COMPLIANCE("COMP", "Compliance & Regs", "Governance"),
    SYSTEM_MONITOR("SYS", "System Monitor", "Governance")
}

data class CbxUiState(
    val currentWorkspace: CbxWorkspace = CbxWorkspace.CBX_HOME,
    val selectedInstrument: BondInstrument,
    val instruments: List<BondInstrument> = emptyList(),
    val searchQuery: String = "",
    val activeBondTypeFilter: BondType? = null,
    val sortColumn: String = "YTM",
    val sortAscending: Boolean = false,
    
    // Order Book State
    val bidDepth: List<OrderBookLevel> = emptyList(),
    val askDepth: List<OrderBookLevel> = emptyList(),
    val orderInputSide: OrderSide = OrderSide.BUY,
    val orderInputType: OrderType = OrderType.LIMIT,
    val orderInputPriceText: String = "",
    val orderInputQtyText: String = "500000",
    val recentTrades: List<TradePrint> = emptyList(),
    
    // RFQ State
    val activeRfq: RfqRequest? = null,
    val rfqNotionalText: String = "1000000",
    val rfqSide: OrderSide = OrderSide.BUY,
    
    // Primary Issuance
    val primaryDeals: List<IssuanceDeal> = emptyList(),
    val selectedDealId: String = "DEAL-SCOT-001",
    
    // Issuer Credit
    val creditProfiles: List<IssuerCreditProfile> = emptyList(),
    val selectedIssuerId: String = "CRED-LOTHYD",
    
    // Yield Curves
    val giltCurve: YieldCurve,
    val soniaCurve: YieldCurve,
    val scottishCurve: YieldCurve,
    val curveShiftBps: Int = 0,
    val curveSteepenBps: Int = 0,
    
    // Bond Analytics Calculator
    val calcPriceInput: String = "100.00",
    val calcYieldInput: String = "4.50",
    val calcCouponInput: String = "4.50",
    val calcMaturityYears: Double = 8.0,
    val calcFrequency: Int = 2,
    val calcCashFlows: List<ScheduledCashFlow> = emptyList(),
    val calcDirtyPrice: Double = 101.25,
    val calcAccrued: Double = 1.25,
    val calcModDuration: Double = 6.55,
    val calcConvexity: Double = 0.54,
    val calcDv01: Double = 66.32,
    
    // Portfolio & Stress Test
    val portfolio: PortfolioSummary,
    val selectedStressScenario: String = "BASELINE",
    val stressTestResults: List<StressTestResult> = emptyList(),
    
    // Operations & Governance
    val settlementInstructions: List<SettlementInstruction> = emptyList(),
    val corporateActions: List<CorporateActionEvent> = emptyList(),
    val auditLogs: List<AuditLogEntry> = emptyList(),
    val researchArticles: List<ResearchArticle> = emptyList(),
    
    // Terminal clock & metrics
    val edinburghTime: String = "11:35:00 BST",
    val engineTicks: Long = 184520L,
    val executionLatencyMicros: Double = 4.2,
    val venueMode: VenueMode = VenueMode.SIMULATION_SANDBOX
)

class CbxViewModel(
    private val repository: CbxRepository = CbxRepository()
) : ViewModel() {

    private val _uiState: MutableStateFlow<CbxUiState>

    val uiState: StateFlow<CbxUiState>

    init {
        val initialInstruments = repository.getInstruments()
        val defaultInst = initialInstruments[1] // UKT 4.50 2034 10Y Benchmark
        val initialGiltCurve = YieldCurveEngine.generateGiltCurve()
        val initialSoniaCurve = YieldCurveEngine.generateSoniaCurve()
        val initialScotCurve = YieldCurveEngine.generateScottishCorporateCurve(initialGiltCurve)
        val initialPortfolio = repository.getSamplePortfolio()

        _uiState = MutableStateFlow(
            CbxUiState(
                selectedInstrument = defaultInst,
                instruments = initialInstruments,
                orderInputPriceText = "%.2f".format(defaultInst.cleanPrice),
                giltCurve = initialGiltCurve,
                soniaCurve = initialSoniaCurve,
                scottishCurve = initialScotCurve,
                primaryDeals = repository.getPrimaryDeals(),
                creditProfiles = repository.getIssuerCreditProfiles(),
                settlementInstructions = repository.getSettlementInstructions(),
                corporateActions = repository.getCorporateActions(),
                auditLogs = repository.getAuditLogs(),
                researchArticles = repository.getResearchArticles(),
                portfolio = initialPortfolio,
                calcPriceInput = "%.2f".format(defaultInst.cleanPrice),
                calcYieldInput = "%.2f".format(defaultInst.ytm),
                calcCouponInput = "%.2f".format(defaultInst.couponRate),
                calcMaturityYears = defaultInst.maturityYears
            )
        )
        uiState = _uiState.asStateFlow()

        refreshOrderBook(defaultInst.id)
        recalculateCalculator()
        evaluatePortfolioStressTests()
        startClockAndEngineTick()
    }

    private fun startClockAndEngineTick() {
        viewModelScope.launch {
            while (true) {
                delay(1000)
                val sdf = SimpleDateFormat("HH:mm:ss 'BST'", Locale.UK)
                val timeStr = sdf.format(Date())
                _uiState.value = _uiState.value.copy(
                    edinburghTime = timeStr,
                    engineTicks = _uiState.value.engineTicks + 12L
                )
            }
        }
    }

    fun selectWorkspace(workspace: CbxWorkspace) {
        _uiState.value = _uiState.value.copy(currentWorkspace = workspace)
    }

    fun selectInstrument(inst: BondInstrument) {
        _uiState.value = _uiState.value.copy(
            selectedInstrument = inst,
            orderInputPriceText = "%.2f".format(inst.cleanPrice),
            calcPriceInput = "%.2f".format(inst.cleanPrice),
            calcYieldInput = "%.2f".format(inst.ytm),
            calcCouponInput = "%.2f".format(inst.couponRate),
            calcMaturityYears = inst.maturityYears
        )
        refreshOrderBook(inst.id)
        recalculateCalculator()
    }

    fun setSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }

    fun setBondTypeFilter(filter: BondType?) {
        _uiState.value = _uiState.value.copy(activeBondTypeFilter = filter)
    }

    fun setSortColumn(col: String) {
        if (_uiState.value.sortColumn == col) {
            _uiState.value = _uiState.value.copy(sortAscending = !_uiState.value.sortAscending)
        } else {
            _uiState.value = _uiState.value.copy(sortColumn = col, sortAscending = false)
        }
    }

    // Order Book Operations
    fun refreshOrderBook(instrumentId: String) {
        val engine = repository.getMatchingEngine(instrumentId)
        val (bids, asks) = engine.getOrderBookDepth()
        val trades = engine.getTradeBlotter()
        _uiState.value = _uiState.value.copy(
            bidDepth = bids,
            askDepth = asks,
            recentTrades = trades
        )
    }

    fun setOrderSide(side: OrderSide) {
        _uiState.value = _uiState.value.copy(orderInputSide = side)
    }

    fun setOrderType(type: OrderType) {
        _uiState.value = _uiState.value.copy(orderInputType = type)
    }

    fun setOrderPriceText(text: String) {
        _uiState.value = _uiState.value.copy(orderInputPriceText = text)
    }

    fun setOrderQtyText(text: String) {
        _uiState.value = _uiState.value.copy(orderInputQtyText = text)
    }

    fun submitOrder() {
        val state = _uiState.value
        val inst = state.selectedInstrument
        val price = state.orderInputPriceText.toDoubleOrNull() ?: inst.cleanPrice
        val qty = state.orderInputQtyText.toLongOrNull() ?: 500_000L

        val order = Order(
            orderId = "ORD-CBX-${System.currentTimeMillis() % 100000}",
            instrumentId = inst.id,
            side = state.orderInputSide,
            type = state.orderInputType,
            price = price,
            quantity = qty,
            timestamp = SimpleDateFormat("HH:mm:ss.SSS", Locale.UK).format(Date()),
            participant = "Desk-EDIN-01 (Trader Alpha)"
        )

        repository.submitOrder(order)
        refreshOrderBook(inst.id)
        _uiState.value = _uiState.value.copy(
            settlementInstructions = repository.getSettlementInstructions(),
            auditLogs = repository.getAuditLogs()
        )
    }

    // RFQ Operations
    fun setRfqSide(side: OrderSide) {
        _uiState.value = _uiState.value.copy(rfqSide = side)
    }

    fun setRfqNotionalText(text: String) {
        _uiState.value = _uiState.value.copy(rfqNotionalText = text)
    }

    fun requestRfq() {
        val state = _uiState.value
        val notional = state.rfqNotionalText.toLongOrNull() ?: 1_000_000L
        val rfq = repository.createRfq(state.selectedInstrument.id, state.rfqSide, notional)
        _uiState.value = _uiState.value.copy(activeRfq = rfq)
    }

    fun acceptRfqQuote(quote: DealerQuote) {
        val state = _uiState.value
        val rfq = state.activeRfq ?: return
        val inst = state.selectedInstrument

        val execPrice = if (rfq.side == OrderSide.BUY) quote.askPrice else quote.bidPrice
        val trade = TradePrint(
            tradeId = "TRD-RFQ-${System.currentTimeMillis() % 10000}",
            instrumentId = inst.id,
            isin = inst.isin,
            instrumentName = inst.name,
            price = execPrice,
            yield = if (rfq.side == OrderSide.BUY) quote.askYield else quote.bidYield,
            quantity = rfq.notionalGbp,
            side = rfq.side,
            buyer = if (rfq.side == OrderSide.BUY) "Internal Desk-EDIN-01" else quote.dealerName,
            seller = if (rfq.side == OrderSide.BUY) quote.dealerName else "Internal Desk-EDIN-01",
            timestamp = SimpleDateFormat("HH:mm:ss", Locale.UK).format(Date()),
            settlementDate = "T+1 (London CREST)",
            executionVenue = "CBX Bilateral RFQ Facility"
        )

        val updatedQuotes = rfq.quotes.map {
            if (it.dealerId == quote.dealerId) it.copy(status = RfqQuoteStatus.ACCEPTED)
            else it.copy(status = RfqQuoteStatus.DECLINED)
        }

        _uiState.value = _uiState.value.copy(
            activeRfq = rfq.copy(quotes = updatedQuotes, activeState = "EXECUTED"),
            recentTrades = listOf(trade) + state.recentTrades
        )

        // Add to settlement
        repository.updateSettlementStatus("DUMMY", SettlementStatus.MATCHED)
    }

    // Yield Curve Controls
    fun adjustCurveShift(shiftBps: Int) {
        _uiState.value = _uiState.value.copy(curveShiftBps = shiftBps)
        val newGilt = YieldCurveEngine.generateGiltCurve(shiftBps, _uiState.value.curveSteepenBps)
        val newScot = YieldCurveEngine.generateScottishCorporateCurve(newGilt)
        _uiState.value = _uiState.value.copy(
            giltCurve = newGilt,
            scottishCurve = newScot
        )
        evaluatePortfolioStressTests()
    }

    fun adjustCurveSteepening(steepenBps: Int) {
        _uiState.value = _uiState.value.copy(curveSteepenBps = steepenBps)
        val newGilt = YieldCurveEngine.generateGiltCurve(_uiState.value.curveShiftBps, steepenBps)
        val newScot = YieldCurveEngine.generateScottishCorporateCurve(newGilt)
        _uiState.value = _uiState.value.copy(
            giltCurve = newGilt,
            scottishCurve = newScot
        )
    }

    // Bond Analytics Calculator
    fun setCalcPrice(priceStr: String) {
        _uiState.value = _uiState.value.copy(calcPriceInput = priceStr)
        val cleanPrice = priceStr.toDoubleOrNull()
        if (cleanPrice != null && cleanPrice > 0) {
            val coupon = _uiState.value.calcCouponInput.toDoubleOrNull() ?: 4.5
            val ytm = BondPricingEngine.solveYieldToMaturity(
                targetDirtyPrice = cleanPrice + BondPricingEngine.calculateAccruedInterest(coupon),
                couponRate = coupon,
                frequency = _uiState.value.calcFrequency,
                maturityYears = _uiState.value.calcMaturityYears
            )
            _uiState.value = _uiState.value.copy(calcYieldInput = "%.3f".format(ytm))
            recalculateCalculator()
        }
    }

    fun setCalcYield(yieldStr: String) {
        _uiState.value = _uiState.value.copy(calcYieldInput = yieldStr)
        val ytm = yieldStr.toDoubleOrNull()
        if (ytm != null && ytm > -2.0) {
            val coupon = _uiState.value.calcCouponInput.toDoubleOrNull() ?: 4.5
            val dirty = BondPricingEngine.dirtyPriceFromYield(
                couponRate = coupon,
                frequency = _uiState.value.calcFrequency,
                maturityYears = _uiState.value.calcMaturityYears,
                ytmPercent = ytm
            )
            val accrued = BondPricingEngine.calculateAccruedInterest(coupon)
            val clean = dirty - accrued
            _uiState.value = _uiState.value.copy(calcPriceInput = "%.2f".format(clean))
            recalculateCalculator()
        }
    }

    fun setCalcCoupon(couponStr: String) {
        _uiState.value = _uiState.value.copy(calcCouponInput = couponStr)
        recalculateCalculator()
    }

    fun setCalcMaturity(years: Double) {
        _uiState.value = _uiState.value.copy(calcMaturityYears = years)
        recalculateCalculator()
    }

    private fun recalculateCalculator() {
        val state = _uiState.value
        val coupon = state.calcCouponInput.toDoubleOrNull() ?: 4.5
        val ytm = state.calcYieldInput.toDoubleOrNull() ?: 4.25
        val clean = state.calcPriceInput.toDoubleOrNull() ?: 100.0
        val accrued = BondPricingEngine.calculateAccruedInterest(coupon)
        val dirty = clean + accrued

        val flows = BondPricingEngine.generateCashFlows(
            couponRate = coupon,
            frequency = state.calcFrequency,
            maturityYears = state.calcMaturityYears,
            ytmPercent = ytm
        )

        val (macDur, modDur) = BondPricingEngine.calculateDuration(
            couponRate = coupon,
            frequency = state.calcFrequency,
            maturityYears = state.calcMaturityYears,
            ytmPercent = ytm,
            dirtyPrice = dirty
        )

        val conv = BondPricingEngine.calculateConvexity(
            couponRate = coupon,
            frequency = state.calcFrequency,
            maturityYears = state.calcMaturityYears,
            ytmPercent = ytm,
            dirtyPrice = dirty
        )

        val dv01 = BondPricingEngine.calculateDV01(dirty, modDur, 100_000.0)

        _uiState.value = state.copy(
            calcCashFlows = flows,
            calcDirtyPrice = dirty,
            calcAccrued = accrued,
            calcModDuration = modDur,
            calcConvexity = conv,
            calcDv01 = dv01
        )
    }

    // Portfolio Stress Testing
    private fun evaluatePortfolioStressTests() {
        val port = _uiState.value.portfolio
        val totalAum = port.totalAumGbp

        val scenarios = listOf(
            StressTestResult(
                scenarioName = "Bank of England +100 bps Parallel Hike",
                scenarioDescription = "Immediate 100 bps parallel upward shift across Gilts and corporate reference curves.",
                shiftBps = 100,
                pnlImpactGbp = -(port.totalDv01Gbp * 100.0),
                percentImpact = (-(port.totalDv01Gbp * 100.0) / totalAum) * 100.0,
                newPortfolioValueGbp = totalAum - (port.totalDv01Gbp * 100.0)
            ),
            StressTestResult(
                scenarioName = "Yield Curve Bear Steepener (+50 bps 10Y/30Y)",
                scenarioDescription = "Long-end curve steepens by 50 bps driven by UK DMO supply expansion.",
                shiftBps = 50,
                pnlImpactGbp = -(port.totalDv01Gbp * 35.0),
                percentImpact = (-(port.totalDv01Gbp * 35.0) / totalAum) * 100.0,
                newPortfolioValueGbp = totalAum - (port.totalDv01Gbp * 35.0)
            ),
            StressTestResult(
                scenarioName = "Corporate Credit Spread Blowout (+150 bps)",
                scenarioDescription = "Widening of sterling corporate and Scottish growth debt spreads.",
                shiftBps = 150,
                pnlImpactGbp = -3_850_000.0,
                percentImpact = (-3_850_000.0 / totalAum) * 100.0,
                newPortfolioValueGbp = totalAum - 3_850_000.0
            ),
            StressTestResult(
                scenarioName = "Monetary Easing / Flight to Quality (-50 bps)",
                scenarioDescription = "BoE rate cut and flight to safety, yields drop 50 bps across curve.",
                shiftBps = -50,
                pnlImpactGbp = +(port.totalDv01Gbp * 50.0),
                percentImpact = (+(port.totalDv01Gbp * 50.0) / totalAum) * 100.0,
                newPortfolioValueGbp = totalAum + (port.totalDv01Gbp * 50.0)
            )
        )

        _uiState.value = _uiState.value.copy(stressTestResults = scenarios)
    }

    fun selectPrimaryDeal(dealId: String) {
        _uiState.value = _uiState.value.copy(selectedDealId = dealId)
    }

    fun selectIssuerCredit(issuerId: String) {
        _uiState.value = _uiState.value.copy(selectedIssuerId = issuerId)
    }

    fun settleInstruction(instructionId: String) {
        repository.updateSettlementStatus(instructionId, SettlementStatus.SETTLED)
        _uiState.value = _uiState.value.copy(
            settlementInstructions = repository.getSettlementInstructions(),
            auditLogs = repository.getAuditLogs()
        )
    }
}
