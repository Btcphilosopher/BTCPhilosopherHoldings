package com.example.model

enum class BondType(val label: String) {
    GILT("UK Gilt"),
    STERLING_CORP("Sterling Corporate"),
    SCOTTISH_GROWTH("Scottish Growth"),
    GREEN_BOND("Green / ESG Bond"),
    SUPRANATIONAL("Supranational")
}

enum class CouponType(val label: String) {
    FIXED("Fixed Rate"),
    FLOATING("Floating Rate (SONIA+)"),
    ZERO("Zero Coupon")
}

enum class DayCount(val label: String) {
    ACT_ACT_ICMA("ACT/ACT ICMA"),
    THIRTY_360("30/360 Bond Basis"),
    ACT_360("ACT/360 Money Market")
}

enum class Seniority(val label: String) {
    SENIOR_SECURED("Senior Secured"),
    SENIOR_UNSECURED("Senior Unsecured"),
    SUBORDINATED("Subordinated"),
    TIER_2("Tier 2 Regulatory Capital")
}

enum class GoverningLaw(val label: String) {
    SCOTS_LAW("Scots Law"),
    ENGLISH_LAW("English Law")
}

data class ScheduledCashFlow(
    val period: Int,
    val paymentDate: String,
    val couponAmount: Double,
    val principalAmount: Double,
    val totalCashFlow: Double,
    val discountFactor: Double,
    val presentValue: Double
)

data class BondInstrument(
    val id: String,
    val isin: String,
    val ticker: String,
    val name: String,
    val issuer: String,
    val issuerLei: String,
    val currency: String = "GBP",
    val bondType: BondType,
    val couponType: CouponType = CouponType.FIXED,
    val couponRate: Double, // e.g. 4.25 for 4.25%
    val couponFrequency: Int = 2, // 2 for semi-annual, 1 for annual
    val dayCount: DayCount = DayCount.ACT_ACT_ICMA,
    val issueDate: String,
    val maturityDate: String,
    val maturityYears: Double,
    val denomination: Double = 100.0,
    val outstandingPrincipal: Long, // in GBP, e.g. 500_000_000
    val seniority: Seniority = Seniority.SENIOR_UNSECURED,
    val governingLaw: GoverningLaw = GoverningLaw.SCOTS_LAW,
    val listingVenue: String = "CBX Fixed Income Exchange",
    val verifiedRating: String = "A+",
    
    // Live / Indicative Pricing
    var cleanPrice: Double,
    var dirtyPrice: Double,
    var accruedInterest: Double,
    var ytm: Double, // Yield to maturity %
    var bidPrice: Double,
    var askPrice: Double,
    var bidYield: Double,
    var askYield: Double,
    var giltSpreadBps: Int,
    var swapSpreadBps: Int,
    
    // Risk & Quant Sensitivities
    var macaulayDuration: Double,
    var modifiedDuration: Double,
    var convexity: Double,
    var dv01Per100k: Double, // DV01 per £100,000 nominal
    var dailyChangeBps: Double = 0.0,
    
    val isSimulated: Boolean = true,
    val dataProvenance: String = "CBX Edinburgh Synthetic Engine"
)
