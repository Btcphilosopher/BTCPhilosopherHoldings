package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.YieldCurve
import com.example.ui.theme.*

@Composable
fun CbxYieldCurveChart(
    giltCurve: YieldCurve,
    scottishCurve: YieldCurve?,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(CbxNavyDark, RoundedCornerShape(4.dp))
            .border(1.dp, CbxNavyBorder, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        // Legend
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(modifier = Modifier.size(8.dp).background(CbxEdinburghGold))
                    Text("UK Conventional Gilts", color = CbxTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
                if (scottishCurve != null) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Box(modifier = Modifier.size(8.dp).background(CbxCaledonianBlue))
                        Text("Scottish Growth Spread (+185bps)", color = CbxCaledonianBlue, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
            Text("YTM (%) vs Tenor", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Canvas Area
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
        ) {
            val width = size.width
            val height = size.height
            val padLeft = 35f
            val padBottom = 20f
            val chartW = width - padLeft - 10f
            val chartH = height - padBottom - 10f

            val minY = 3.0f
            val maxY = 7.0f

            // Grid lines
            val ySteps = 4
            for (i in 0..ySteps) {
                val yVal = minY + (maxY - minY) * (i.toFloat() / ySteps)
                val yPos = (height - padBottom) - (i.toFloat() / ySteps) * chartH
                drawLine(
                    color = CbxNavyBorder,
                    start = Offset(padLeft, yPos),
                    end = Offset(width, yPos),
                    strokeWidth = 1f
                )
            }

            // Gilt Curve Path
            val giltPoints = giltCurve.points
            if (giltPoints.isNotEmpty()) {
                val giltPath = Path()
                giltPoints.forEachIndexed { idx, pt ->
                    val x = padLeft + (idx.toFloat() / (giltPoints.size - 1).toFloat()) * chartW
                    val normalizedY = ((pt.parYield.toFloat() - minY) / (maxY - minY)).coerceIn(0f, 1f)
                    val y = (height - padBottom) - normalizedY * chartH
                    if (idx == 0) giltPath.moveTo(x, y) else giltPath.lineTo(x, y)
                    drawCircle(color = CbxEdinburghGold, radius = 3.5f, center = Offset(x, y))
                }
                drawPath(
                    path = giltPath,
                    color = CbxEdinburghGold,
                    style = Stroke(width = 2.5f)
                )
            }

            // Scottish Growth Curve Path
            if (scottishCurve != null && scottishCurve.points.isNotEmpty()) {
                val scotPath = Path()
                scottishCurve.points.forEachIndexed { idx, pt ->
                    val x = padLeft + (idx.toFloat() / (scottishCurve.points.size - 1).toFloat()) * chartW
                    val normalizedY = ((pt.parYield.toFloat() - minY) / (maxY - minY)).coerceIn(0f, 1f)
                    val y = (height - padBottom) - normalizedY * chartH
                    if (idx == 0) scotPath.moveTo(x, y) else scotPath.lineTo(x, y)
                    drawCircle(color = CbxCaledonianBlue, radius = 3f, center = Offset(x, y))
                }
                drawPath(
                    path = scotPath,
                    color = CbxCaledonianBlue,
                    style = Stroke(width = 2f)
                )
            }
        }
    }
}
