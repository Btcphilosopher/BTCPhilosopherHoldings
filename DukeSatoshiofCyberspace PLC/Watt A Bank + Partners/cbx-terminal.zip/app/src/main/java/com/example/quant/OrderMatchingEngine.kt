package com.example.quant

import com.example.model.BondInstrument
import com.example.model.Order
import com.example.model.OrderBookLevel
import com.example.model.OrderSide
import com.example.model.OrderStatus
import com.example.model.OrderType
import com.example.model.TradePrint
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.roundToLong

class OrderMatchingEngine(val instrumentId: String) {

    private val sequenceCounter = AtomicLong(1000L)
    private val buyOrders = mutableListOf<Order>()  // Sorted price DESC, timestamp ASC
    private val sellOrders = mutableListOf<Order>() // Sorted price ASC, timestamp ASC
    private val executionBlotter = mutableListOf<TradePrint>()

    /**
     * Rebuilds aggregate depth levels for UI display.
     */
    fun getOrderBookDepth(): Pair<List<OrderBookLevel>, List<OrderBookLevel>> {
        synchronized(this) {
            val bidLevels = buyOrders
                .filter { it.status == OrderStatus.WORKING || it.status == OrderStatus.PARTIALLY_FILLED }
                .groupBy { (it.price * 100).roundToLong() / 100.0 }
                .map { (price, orders) ->
                    OrderBookLevel(
                        price = price,
                        size = orders.sumOf { it.quantity - it.filledQuantity },
                        orderCount = orders.size
                    )
                }
                .sortedByDescending { it.price }

            val askLevels = sellOrders
                .filter { it.status == OrderStatus.WORKING || it.status == OrderStatus.PARTIALLY_FILLED }
                .groupBy { (it.price * 100).roundToLong() / 100.0 }
                .map { (price, orders) ->
                    OrderBookLevel(
                        price = price,
                        size = orders.sumOf { it.quantity - it.filledQuantity },
                        orderCount = orders.size
                    )
                }
                .sortedBy { it.price }

            // Calculate cumulative and percentage for depth ladder bars
            val maxBidCum = bidLevels.sumOf { it.size }.coerceAtLeast(1L)
            var cumBid = 0L
            val bidResults = bidLevels.map {
                cumBid += it.size
                it.copy(
                    cumulativeSize = cumBid,
                    depthPercentage = (cumBid.toFloat() / maxBidCum.toFloat()).coerceIn(0.05f, 1f)
                )
            }

            val maxAskCum = askLevels.sumOf { it.size }.coerceAtLeast(1L)
            var cumAsk = 0L
            val askResults = askLevels.map {
                cumAsk += it.size
                it.copy(
                    cumulativeSize = cumAsk,
                    depthPercentage = (cumAsk.toFloat() / maxAskCum.toFloat()).coerceIn(0.05f, 1f)
                )
            }

            return Pair(bidResults, askResults)
        }
    }

    /**
     * Submits an order and deterministically executes against opposite resting orders.
     */
    fun submitOrder(order: Order, instrument: BondInstrument): List<TradePrint> {
        val executedTrades = mutableListOf<TradePrint>()
        synchronized(this) {
            var remainingQty = order.quantity - order.filledQuantity

            if (order.side == OrderSide.BUY) {
                // Match against resting SELL orders (price-time priority: lowest ask first)
                val it = sellOrders.iterator()
                while (it.hasNext() && remainingQty > 0) {
                    val restingAsk = it.next()
                    if (order.type == OrderType.LIMIT && restingAsk.price > order.price) {
                        break // Cannot cross price limit
                    }
                    val restingRemaining = restingAsk.quantity - restingAsk.filledQuantity
                    val matchQty = minOf(remainingQty, restingRemaining)
                    val executionPrice = restingAsk.price // Price priority to resting order

                    val trade = TradePrint(
                        tradeId = "TRD-CBX-${sequenceCounter.incrementAndGet()}",
                        instrumentId = instrument.id,
                        isin = instrument.isin,
                        instrumentName = instrument.name,
                        price = executionPrice,
                        yield = instrument.ytm,
                        quantity = matchQty,
                        side = OrderSide.BUY,
                        buyer = order.participant,
                        seller = restingAsk.participant,
                        timestamp = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.UK).format(java.util.Date()),
                        settlementDate = "T+1 (London)",
                        executionVenue = "CBX Matching Engine (Edinburgh)"
                    )
                    executedTrades.add(trade)
                    executionBlotter.add(trade)

                    remainingQty -= matchQty
                    val updatedRestingFilled = restingAsk.filledQuantity + matchQty
                    val restingIndex = sellOrders.indexOf(restingAsk)
                    if (restingIndex != -1) {
                        if (updatedRestingFilled >= restingAsk.quantity) {
                            sellOrders.removeAt(restingIndex)
                        } else {
                            sellOrders[restingIndex] = restingAsk.copy(
                                filledQuantity = updatedRestingFilled,
                                status = OrderStatus.PARTIALLY_FILLED
                            )
                        }
                    }
                }

                if (remainingQty > 0 && order.type == OrderType.LIMIT) {
                    val remainingOrder = order.copy(
                        filledQuantity = order.quantity - remainingQty,
                        status = if (remainingQty == order.quantity) OrderStatus.WORKING else OrderStatus.PARTIALLY_FILLED
                    )
                    buyOrders.add(remainingOrder)
                    buyOrders.sortWith(compareByDescending<Order> { it.price }.thenBy { it.timestamp })
                }
            } else {
                // Match against resting BUY orders (highest bid first)
                val it = buyOrders.iterator()
                while (it.hasNext() && remainingQty > 0) {
                    val restingBid = it.next()
                    if (order.type == OrderType.LIMIT && restingBid.price < order.price) {
                        break // Price limit barrier
                    }
                    val restingRemaining = restingBid.quantity - restingBid.filledQuantity
                    val matchQty = minOf(remainingQty, restingRemaining)
                    val executionPrice = restingBid.price

                    val trade = TradePrint(
                        tradeId = "TRD-CBX-${sequenceCounter.incrementAndGet()}",
                        instrumentId = instrument.id,
                        isin = instrument.isin,
                        instrumentName = instrument.name,
                        price = executionPrice,
                        yield = instrument.ytm,
                        quantity = matchQty,
                        side = OrderSide.SELL,
                        buyer = restingBid.participant,
                        seller = order.participant,
                        timestamp = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.UK).format(java.util.Date()),
                        settlementDate = "T+1 (London)",
                        executionVenue = "CBX Matching Engine (Edinburgh)"
                    )
                    executedTrades.add(trade)
                    executionBlotter.add(trade)

                    remainingQty -= matchQty
                    val updatedRestingFilled = restingBid.filledQuantity + matchQty
                    val restingIndex = buyOrders.indexOf(restingBid)
                    if (restingIndex != -1) {
                        if (updatedRestingFilled >= restingBid.quantity) {
                            buyOrders.removeAt(restingIndex)
                        } else {
                            buyOrders[restingIndex] = restingBid.copy(
                                filledQuantity = updatedRestingFilled,
                                status = OrderStatus.PARTIALLY_FILLED
                            )
                        }
                    }
                }

                if (remainingQty > 0 && order.type == OrderType.LIMIT) {
                    val remainingOrder = order.copy(
                        filledQuantity = order.quantity - remainingQty,
                        status = if (remainingQty == order.quantity) OrderStatus.WORKING else OrderStatus.PARTIALLY_FILLED
                    )
                    sellOrders.add(remainingOrder)
                    sellOrders.sortWith(compareBy<Order> { it.price }.thenBy { it.timestamp })
                }
            }
        }
        return executedTrades
    }

    /**
     * Seeds realistic resting liquidity around the fair value.
     */
    fun seedLiquidity(midPrice: Double) {
        synchronized(this) {
            buyOrders.clear()
            sellOrders.clear()
            val time = "09:00:00"

            val bidDeltas = listOf(0.08, 0.15, 0.24, 0.35, 0.50)
            val bidSizes = listOf(250_000L, 500_000L, 1_000_000L, 1_500_000L, 3_000_000L)
            val bidDealers = listOf("Charlotte Square MM", "Waverley Securities", "Bailie Gifford Synth", "Standard Life Desk", "Caledonian Fixed")

            for (i in bidDeltas.indices) {
                buyOrders.add(
                    Order(
                        orderId = "REST-B-$i",
                        instrumentId = instrumentId,
                        side = OrderSide.BUY,
                        type = OrderType.LIMIT,
                        price = ((midPrice - bidDeltas[i]) * 100).roundToLong() / 100.0,
                        quantity = bidSizes[i],
                        timestamp = "$time.${100 + i * 20}",
                        participant = bidDealers[i]
                    )
                )
            }

            val askDeltas = listOf(0.08, 0.16, 0.25, 0.38, 0.52)
            val askSizes = listOf(300_000L, 600_000L, 850_000L, 2_000_000L, 2_500_000L)
            val askDealers = listOf("Holyrood Debt MMs", "Lothian Liquidity", "St Andrew Gilts", "Highland Capital", "Scottish Widows Desk")

            for (i in askDeltas.indices) {
                sellOrders.add(
                    Order(
                        orderId = "REST-A-$i",
                        instrumentId = instrumentId,
                        side = OrderSide.SELL,
                        type = OrderType.LIMIT,
                        price = ((midPrice + askDeltas[i]) * 100).roundToLong() / 100.0,
                        quantity = askSizes[i],
                        timestamp = "$time.${100 + i * 20}",
                        participant = askDealers[i]
                    )
                )
            }
        }
    }

    fun getTradeBlotter(): List<TradePrint> = synchronized(this) { executionBlotter.toList() }
}
