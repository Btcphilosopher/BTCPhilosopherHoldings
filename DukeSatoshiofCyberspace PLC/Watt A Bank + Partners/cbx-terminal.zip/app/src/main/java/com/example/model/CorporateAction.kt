package com.example.model

enum class CorporateActionType(val label: String) {
    COUPON_PAYMENT("Scheduled Coupon Payment"),
    PRINCIPAL_REDEMPTION("Final Principal Maturity"),
    CALL_OPTION("Issuer Call Notice"),
    SINKING_FUND("Sinking Fund Amortisation")
}

data class CorporateActionEvent(
    val eventId: String,
    val isin: String,
    val instrumentName: String,
    val type: CorporateActionType,
    val exDate: String,
    val recordDate: String,
    val paymentDate: String,
    val ratePerCent: Double,
    val estimatedDisbursementGbp: Long,
    val status: String = "UPCOMING SCHEDULED"
)
