package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.CbxUiState
import com.example.ui.CbxViewModel
import com.example.ui.components.CbxMetricTile
import com.example.ui.components.CbxSimulatedBanner
import com.example.ui.components.CbxTerminalCard
import com.example.ui.theme.*

@Composable
fun IssuerCreditScreen(
    uiState: CbxUiState,
    viewModel: CbxViewModel,
    modifier: Modifier = Modifier
) {
    val selectedProfile = uiState.creditProfiles.find { it.issuerId == uiState.selectedIssuerId } ?: uiState.creditProfiles[0]

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            CbxSimulatedBanner()
        }

        // Issuer Selection Strip
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                uiState.creditProfiles.forEach { prof ->
                    val isSelected = prof.issuerId == selectedProfile.issuerId
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(if (isSelected) CbxNavyElevated else CbxNavySurface, RoundedCornerShape(2.dp))
                            .border(1.dp, if (isSelected) CbxEdinburghGold else CbxNavyBorder, RoundedCornerShape(2.dp))
                            .clickable { viewModel.selectIssuerCredit(prof.issuerId) }
                            .padding(8.dp)
                            .testTag("select_credit_${prof.issuerId.lowercase()}")
                    ) {
                        Column {
                            Text(
                                text = prof.shortName,
                                color = if (isSelected) CbxEdinburghGold else CbxTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                            Text(
                                text = prof.cbxInternalRating,
                                color = CbxCaledonianBlue,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Issuer Credit Summary Card
        item {
            CbxTerminalCard(
                title = "Credit Research Assessment — ${selectedProfile.shortName}",
                badgeText = selectedProfile.cbxInternalRating
            ) {
                Text(
                    text = selectedProfile.legalName,
                    color = CbxTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Sector: ${selectedProfile.sector} • HQ: ${selectedProfile.headquarters}",
                    color = CbxTextSecondary,
                    fontSize = 10.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                val latestFin = selectedProfile.financials[0]
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CbxMetricTile("Net Leverage", "%.2fx".format(latestFin.netLeverage), "Net Debt/EBITDA", valueColor = CbxEdinburghGold, modifier = Modifier.weight(1f))
                    CbxMetricTile("Interest Coverage", "%.2fx".format(latestFin.interestCoverage), "EBITDA/Interest", valueColor = CbxProfitGreen, modifier = Modifier.weight(1f))
                    CbxMetricTile("EBITDA (FY24)", "£%.1fM".format(latestFin.ebitdaGbpM), valueColor = CbxTextPrimary, modifier = Modifier.weight(1f))
                    CbxMetricTile("Free Cash Flow", "£%.1fM".format(latestFin.freeCashFlowGbpM), valueColor = CbxCaledonianBlue, modifier = Modifier.weight(1f))
                }
            }
        }

        // Multi-Year Financial Statements Table
        item {
            CbxTerminalCard(
                title = "Historical Financial Performance (GBP Millions)",
                badgeText = "3-YEAR TREND"
            ) {
                // Table Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CbxNavyElevated)
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("METRIC", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                    selectedProfile.financials.forEach { fin ->
                        Text(fin.fiscalYear, color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    }
                }

                val metricRows = listOf(
                    Triple("Revenue", { f: com.example.model.FinancialStatementYear -> "£%.1fM".format(f.revenueGbpM) }, CbxTextPrimary),
                    Triple("EBITDA", { f: com.example.model.FinancialStatementYear -> "£%.1fM".format(f.ebitdaGbpM) }, CbxEdinburghGold),
                    Triple("Operating Cash Flow", { f: com.example.model.FinancialStatementYear -> "£%.1fM".format(f.operatingCashFlowGbpM) }, CbxTextPrimary),
                    Triple("Capital Expenditure", { f: com.example.model.FinancialStatementYear -> "£%.1fM".format(f.capexGbpM) }, CbxLossRed),
                    Triple("Free Cash Flow", { f: com.example.model.FinancialStatementYear -> "£%.1fM".format(f.freeCashFlowGbpM) }, CbxProfitGreen),
                    Triple("Net Debt", { f: com.example.model.FinancialStatementYear -> "£%.1fM".format(f.netDebtGbpM) }, CbxTextSecondary),
                    Triple("Net Leverage Ratio", { f: com.example.model.FinancialStatementYear -> "%.2fx".format(f.netLeverage) }, CbxCaledonianBlue),
                    Triple("Interest Coverage", { f: com.example.model.FinancialStatementYear -> "%.2fx".format(f.interestCoverage) }, CbxProfitGreen)
                )

                metricRows.forEach { (name, extractor, color) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 6.dp, vertical = 3.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(name, color = CbxTextSecondary, fontSize = 9.sp, modifier = Modifier.weight(1.5f))
                        selectedProfile.financials.forEach { fin ->
                            Text(extractor(fin), color = color, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        }
                    }
                    Divider(color = CbxNavyBorderSubtle, thickness = 1.dp)
                }
            }
        }

        // Financial Covenants Monitor
        item {
            CbxTerminalCard(
                title = "Bond Indenture Financial Covenants",
                badgeText = "SCOTS LAW TEST"
            ) {
                selectedProfile.covenants.forEach { cov ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(2f)) {
                            Text(cov.name, color = CbxTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Text(cov.thresholdText, color = CbxTextSecondary, fontSize = 9.sp)
                        }
                        Column(modifier = Modifier.weight(1.2f), horizontalAlignment = Alignment.End) {
                            Text(cov.currentLevelText, color = CbxEdinburghGold, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Text("${cov.headroomPercent.toInt()}% Headroom", color = CbxProfitGreen, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        }
                        Box(
                            modifier = Modifier
                                .padding(start = 8.dp)
                                .background(CbxGreenBackground, RoundedCornerShape(2.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("COMPLIANT", color = CbxProfitGreen, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                    Divider(color = CbxNavyBorderSubtle, thickness = 1.dp)
                }
            }
        }

        // Debt Maturity Profile
        item {
            CbxTerminalCard(
                title = "Debt Maturity Schedule & Concentration",
                badgeText = "REFINANCING PROFILE"
            ) {
                selectedProfile.debtMaturityProfile.forEach { bucket ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Maturity: ${bucket.yearLabel}", color = CbxTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Text(bucket.instrumentType, color = CbxTextSecondary, fontSize = 9.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("£%.1fM".format(bucket.amountGbpM), color = CbxEdinburghGold, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Text("Coupon: %.2f%%".format(bucket.couponPct), color = CbxTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                    Divider(color = CbxNavyBorderSubtle, thickness = 1.dp)
                }
            }
        }

        // Credit Commentary Card
        item {
            CbxTerminalCard(
                title = "Lead Analyst Credit Commentary",
                badgeText = selectedProfile.leadAnalyst
            ) {
                Text(
                    text = selectedProfile.analystCommentary,
                    color = CbxTextPrimary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Key Credit Strengths:",
                    color = CbxProfitGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
                selectedProfile.keyStrengths.forEach { str ->
                    Text("• $str", color = CbxTextSecondary, fontSize = 9.sp, lineHeight = 13.sp)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Key Credit Risks:",
                    color = CbxLossRed,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
                selectedProfile.keyCreditRisks.forEach { risk ->
                    Text("• $risk", color = CbxTextSecondary, fontSize = 9.sp, lineHeight = 13.sp)
                }
            }
        }
    }
}
