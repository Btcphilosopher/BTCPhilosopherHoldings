package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.CbxUiState
import com.example.ui.CbxViewModel
import com.example.ui.components.CbxMetricTile
import com.example.ui.components.CbxSimulatedBanner
import com.example.ui.components.CbxTerminalCard
import com.example.ui.theme.*

@Composable
fun CorporateActionsScreen(
    uiState: CbxUiState,
    viewModel: CbxViewModel,
    modifier: Modifier = Modifier
) {
    val events = uiState.corporateActions

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            CbxSimulatedBanner()
        }

        item {
            CbxTerminalCard(
                title = "Corporate Actions & Coupon Payment Calendar",
                badgeText = "SCHEDULED ENTITLEMENTS"
            ) {
                Text(
                    text = "Upcoming scheduled coupon payments, principal redemptions, and ex-dividend cut-off dates for Scottish and Sterling debt.",
                    color = CbxTextSecondary,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CbxMetricTile("Upcoming Events", "${events.size}", modifier = Modifier.weight(1f))
                    CbxMetricTile("Next Coupon Event", events[0].paymentDate, valueColor = CbxEdinburghGold, modifier = Modifier.weight(1.5f))
                    CbxMetricTile("Total Disbursements", "£%,dM".format(events.sumOf { it.estimatedDisbursementGbp } / 1_000_000L), valueColor = CbxCaledonianBlue, modifier = Modifier.weight(1.5f))
                }
            }
        }

        item {
            CbxTerminalCard(
                title = "Corporate Action Diary & Payment Schedule",
                badgeText = "DIARY ENTRIES"
            ) {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CbxNavyElevated)
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("EVENT / INSTRUMENT", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.8f))
                    Text("EX-DATE", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text("RECORD DATE", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text("PAYMENT DATE", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text("DISBURSEMENT", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                }

                events.forEach { ev ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.8f)) {
                            Text(ev.type.label, color = CbxEdinburghGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("${ev.instrumentName} (${ev.isin})", color = CbxTextPrimary, fontSize = 9.sp)
                        }
                        Text(ev.exDate, color = CbxTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text(ev.recordDate, color = CbxTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text(ev.paymentDate, color = CbxProfitGreen, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text("£%,d".format(ev.estimatedDisbursementGbp), color = CbxCaledonianBlue, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                    }
                    Divider(color = CbxNavyBorderSubtle, thickness = 1.dp)
                }
            }
        }
    }
}
