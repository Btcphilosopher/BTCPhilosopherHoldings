package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Caledonian Bond Exchange Institutional Terminal Palette
val CbxNavyDark = Color(0xFF090D1A)        // Deep Royal Navy background
val CbxNavyBackground = Color(0xFF0D1322)  // Primary workspace canvas
val CbxNavySurface = Color(0xFF131C31)     // Card & dense panel surface
val CbxNavyElevated = Color(0xFF1B2640)    // Elevated surface / modal / active tab
val CbxNavyBorder = Color(0xFF243252)      // Precision border & divider
val CbxNavyBorderSubtle = Color(0xFF19243C)// Subtle divider

// Scottish Heritage Accents
val CbxEdinburghGold = Color(0xFFD4AF37)   // Edinburgh thistle gold (accents, active indicators)
val CbxGoldMuted = Color(0xFF9E8329)       // Secondary gold
val CbxCaledonianBlue = Color(0xFF38BDF8)  // Market data info blue
val CbxCaledonianBlueDim = Color(0xFF0284C7)
val CbxScottishHeather = Color(0xFFA78BFA)  // Primary issuance / corporate action purple

// Financial Indicators
val CbxProfitGreen = Color(0xFF10B981)     // Yield down / price up / firm bid
val CbxGreenBackground = Color(0x1A10B981)
val CbxLossRed = Color(0xFFF43F5E)         // Yield up / price down / firm ask
val CbxRedBackground = Color(0x1AF43F5E)
val CbxWarningAmber = Color(0xFFF59E0B)    // Regulatory / exception / pending
val CbxAmberBackground = Color(0x1AF59E0B)

// Typography & Text
val CbxTextPrimary = Color(0xFFF8FAFC)     // Warm ivory / crisp numbers
val CbxTextSecondary = Color(0xFF94A3B8)   // Slate gray metadata
val CbxTextMuted = Color(0xFF64748B)       // Dim table column headers
val CbxTextDisabled = Color(0xFF475569)

// Depth & Terminal Colors
val CbxBidDepthBar = Color(0x3310B981)
val CbxAskDepthBar = Color(0x33F43F5E)
val CbxSimulatedBadge = Color(0xFF6366F1)
