package com.example.data

import com.example.model.*
import com.example.quant.BondPricingEngine
import com.example.quant.OrderMatchingEngine
import com.example.quant.YieldCurveEngine

class CbxRepository {

    private val instruments = mutableListOf<BondInstrument>()
    private val matchingEngines = mutableMapOf<String, OrderMatchingEngine>()
    private val primaryDeals = mutableListOf<IssuanceDeal>()
    private val issuerCreditProfiles = mutableListOf<IssuerCreditProfile>()
    private val settlementInstructions = mutableListOf<SettlementInstruction>()
    private val corporateActions = mutableListOf<CorporateActionEvent>()
    private val auditLogs = mutableListOf<AuditLogEntry>()
    private val researchArticles = mutableListOf<ResearchArticle>()
    private val activeRfqs = mutableListOf<RfqRequest>()

    init {
        seedInstruments()
        seedOrderBooks()
        seedPrimaryDeals()
        seedCreditProfiles()
        seedSettlementData()
        seedCorporateActions()
        seedAuditLogs()
        seedResearch()
    }

    private fun seedInstruments() {
        val list = listOf(
            BondInstrument(
                id = "INST-001",
                isin = "GB00BNNGP668",
                ticker = "UKT 4.25 27",
                name = "United Kingdom Gilt 4.25% 2027",
                issuer = "HM Treasury / UK Debt Management Office",
                issuerLei = "213800CO14P2C4CUKT44",
                bondType = BondType.GILT,
                couponRate = 4.25,
                couponFrequency = 2,
                dayCount = DayCount.ACT_ACT_ICMA,
                issueDate = "2022-07-12",
                maturityDate = "2027-12-07",
                maturityYears = 1.65,
                outstandingPrincipal = 34_500_000_000L,
                seniority = Seniority.SENIOR_UNSECURED,
                governingLaw = GoverningLaw.ENGLISH_LAW,
                listingVenue = "London Stock Exchange / DMO",
                verifiedRating = "AA",
                cleanPrice = 100.15,
                dirtyPrice = 101.45,
                accruedInterest = 1.30,
                ytm = 4.15,
                bidPrice = 100.12,
                askPrice = 100.18,
                bidYield = 4.17,
                askYield = 4.13,
                giltSpreadBps = 0,
                swapSpreadBps = -12,
                macaulayDuration = 1.58,
                modifiedDuration = 1.54,
                convexity = 0.03,
                dv01Per100k = 15.62,
                dailyChangeBps = -2.4
            ),
            BondInstrument(
                id = "INST-002",
                isin = "GB00BM8Z2S69",
                ticker = "UKT 4.50 34",
                name = "United Kingdom Gilt 4.50% 2034 (10Y Benchmark)",
                issuer = "HM Treasury / UK Debt Management Office",
                issuerLei = "213800CO14P2C4CUKT44",
                bondType = BondType.GILT,
                couponRate = 4.50,
                couponFrequency = 2,
                dayCount = DayCount.ACT_ACT_ICMA,
                issueDate = "2024-03-01",
                maturityDate = "2034-09-07",
                maturityYears = 8.40,
                outstandingPrincipal = 28_200_000_000L,
                seniority = Seniority.SENIOR_UNSECURED,
                governingLaw = GoverningLaw.ENGLISH_LAW,
                listingVenue = "London Stock Exchange / DMO",
                verifiedRating = "AA",
                cleanPrice = 101.80,
                dirtyPrice = 103.15,
                accruedInterest = 1.35,
                ytm = 4.24,
                bidPrice = 101.76,
                askPrice = 101.84,
                bidYield = 4.25,
                askYield = 4.23,
                giltSpreadBps = 0,
                swapSpreadBps = -18,
                macaulayDuration = 6.95,
                modifiedDuration = 6.81,
                convexity = 0.58,
                dv01Per100k = 70.25,
                dailyChangeBps = +1.8
            ),
            BondInstrument(
                id = "INST-003",
                isin = "GB00B52WSQ31",
                ticker = "UKT 3.75 53",
                name = "United Kingdom Gilt 3.75% 2053 (30Y Ultra-Long)",
                issuer = "HM Treasury / UK Debt Management Office",
                issuerLei = "213800CO14P2C4CUKT44",
                bondType = BondType.GILT,
                couponRate = 3.75,
                couponFrequency = 2,
                dayCount = DayCount.ACT_ACT_ICMA,
                issueDate = "2021-09-15",
                maturityDate = "2053-10-22",
                maturityYears = 27.50,
                outstandingPrincipal = 21_700_000_000L,
                seniority = Seniority.SENIOR_UNSECURED,
                governingLaw = GoverningLaw.ENGLISH_LAW,
                listingVenue = "London Stock Exchange / DMO",
                verifiedRating = "AA",
                cleanPrice = 86.40,
                dirtyPrice = 87.55,
                accruedInterest = 1.15,
                ytm = 4.62,
                bidPrice = 86.32,
                askPrice = 86.48,
                bidYield = 4.63,
                askYield = 4.61,
                giltSpreadBps = 0,
                swapSpreadBps = -25,
                macaulayDuration = 16.80,
                modifiedDuration = 16.42,
                convexity = 3.85,
                dv01Per100k = 143.76,
                dailyChangeBps = +3.1
            ),
            BondInstrument(
                id = "INST-004",
                isin = "XS2438619447",
                ticker = "SSE 3.875 29",
                name = "SSE PLC 3.875% 2029 (Perth)",
                issuer = "SSE PLC (Scottish and Southern Energy)",
                issuerLei = "549300KI75VYLL8PL573",
                bondType = BondType.STERLING_CORP,
                couponRate = 3.875,
                couponFrequency = 1,
                dayCount = DayCount.ACT_ACT_ICMA,
                issueDate = "2022-09-04",
                maturityDate = "2029-09-04",
                maturityYears = 3.40,
                outstandingPrincipal = 500_000_000L,
                seniority = Seniority.SENIOR_UNSECURED,
                governingLaw = GoverningLaw.SCOTS_LAW,
                listingVenue = "London Stock Exchange / Euro MTF",
                verifiedRating = "BBB+",
                cleanPrice = 96.85,
                dirtyPrice = 97.90,
                accruedInterest = 1.05,
                ytm = 4.88,
                bidPrice = 96.70,
                askPrice = 97.00,
                bidYield = 4.93,
                askYield = 4.83,
                giltSpreadBps = 72,
                swapSpreadBps = 64,
                macaulayDuration = 3.15,
                modifiedDuration = 3.00,
                convexity = 0.12,
                dv01Per100k = 29.37,
                dailyChangeBps = -1.2
            ),
            BondInstrument(
                id = "INST-005",
                isin = "XS2250153782",
                ticker = "NWG 5.125 31",
                name = "NatWest Group PLC 5.125% 2031 (Tier 2 Edinburgh)",
                issuer = "NatWest Group PLC (St Andrew Square, Edinburgh)",
                issuerLei = "2138005O9XJIJN4JPN90",
                bondType = BondType.STERLING_CORP,
                couponRate = 5.125,
                couponFrequency = 1,
                dayCount = DayCount.ACT_ACT_ICMA,
                issueDate = "2020-11-15",
                maturityDate = "2031-01-15",
                maturityYears = 4.75,
                outstandingPrincipal = 750_000_000L,
                seniority = Seniority.TIER_2,
                governingLaw = GoverningLaw.SCOTS_LAW,
                listingVenue = "CBX Fixed Income / LSE",
                verifiedRating = "BBB",
                cleanPrice = 99.40,
                dirtyPrice = 100.85,
                accruedInterest = 1.45,
                ytm = 5.27,
                bidPrice = 99.25,
                askPrice = 99.55,
                bidYield = 5.31,
                askYield = 5.23,
                giltSpreadBps = 108,
                swapSpreadBps = 95,
                macaulayDuration = 4.20,
                modifiedDuration = 3.99,
                convexity = 0.22,
                dv01Per100k = 40.24,
                dailyChangeBps = -0.5
            ),
            BondInstrument(
                id = "INST-006",
                isin = "GB00CBX001A8",
                ticker = "LOTHYD 6.25 29",
                name = "Lothian Hydrogen & Renewables PLC 6.25% 2029",
                issuer = "Lothian Hydrogen & Renewables PLC",
                issuerLei = "213800EDIN001LOTH99",
                bondType = BondType.SCOTTISH_GROWTH,
                couponRate = 6.25,
                couponFrequency = 2,
                dayCount = DayCount.ACT_ACT_ICMA,
                issueDate = "2024-03-15",
                maturityDate = "2029-03-15",
                maturityYears = 2.90,
                outstandingPrincipal = 120_000_000L,
                seniority = Seniority.SENIOR_SECURED,
                governingLaw = GoverningLaw.SCOTS_LAW,
                listingVenue = "CBX Scottish Growth Segment",
                verifiedRating = "CBX Tier-2 (BBB-)",
                cleanPrice = 101.20,
                dirtyPrice = 102.50,
                accruedInterest = 1.30,
                ytm = 5.80,
                bidPrice = 100.95,
                askPrice = 101.45,
                bidYield = 5.90,
                askYield = 5.70,
                giltSpreadBps = 162,
                swapSpreadBps = 148,
                macaulayDuration = 2.65,
                modifiedDuration = 2.57,
                convexity = 0.08,
                dv01Per100k = 26.34,
                dailyChangeBps = +2.0
            ),
            BondInstrument(
                id = "INST-007",
                isin = "GB00CBX002B6",
                ticker = "CALPHO 7.10 28",
                name = "Caledonian Silicon Photonics Ltd 7.10% 2028",
                issuer = "Caledonian Silicon Photonics Ltd (Livingston)",
                issuerLei = "213800LIVI002CALP88",
                bondType = BondType.SCOTTISH_GROWTH,
                couponRate = 7.10,
                couponFrequency = 2,
                dayCount = DayCount.ACT_ACT_ICMA,
                issueDate = "2023-09-20",
                maturityDate = "2028-09-20",
                maturityYears = 2.40,
                outstandingPrincipal = 45_000_000L,
                seniority = Seniority.SENIOR_SECURED,
                governingLaw = GoverningLaw.SCOTS_LAW,
                listingVenue = "CBX Scottish Growth Segment",
                verifiedRating = "CBX Tier-3 (BB+)",
                cleanPrice = 102.40,
                dirtyPrice = 103.88,
                accruedInterest = 1.48,
                ytm = 6.00,
                bidPrice = 102.10,
                askPrice = 102.70,
                bidYield = 6.14,
                askYield = 5.86,
                giltSpreadBps = 185,
                swapSpreadBps = 168,
                macaulayDuration = 2.22,
                modifiedDuration = 2.15,
                convexity = 0.06,
                dv01Per100k = 22.33,
                dailyChangeBps = 0.0
            ),
            BondInstrument(
                id = "INST-008",
                isin = "GB00CBX003C4",
                ticker = "FORTHD 5.85 32",
                name = "Forth Valley Distillers Group PLC 5.85% 2032",
                issuer = "Forth Valley Distillers Group PLC (Stirling)",
                issuerLei = "213800STIR003FORT77",
                bondType = BondType.SCOTTISH_GROWTH,
                couponRate = 5.85,
                couponFrequency = 2,
                dayCount = DayCount.ACT_ACT_ICMA,
                issueDate = "2024-06-30",
                maturityDate = "2032-06-30",
                maturityYears = 6.20,
                outstandingPrincipal = 80_000_000L,
                seniority = Seniority.SENIOR_SECURED,
                governingLaw = GoverningLaw.SCOTS_LAW,
                listingVenue = "CBX Scottish Growth Segment",
                verifiedRating = "CBX Tier-2 (BBB)",
                cleanPrice = 99.80,
                dirtyPrice = 101.12,
                accruedInterest = 1.32,
                ytm = 5.89,
                bidPrice = 99.55,
                askPrice = 100.05,
                bidYield = 5.94,
                askYield = 5.84,
                giltSpreadBps = 168,
                swapSpreadBps = 152,
                macaulayDuration = 5.10,
                modifiedDuration = 4.95,
                convexity = 0.32,
                dv01Per100k = 50.05,
                dailyChangeBps = -1.5
            ),
            BondInstrument(
                id = "INST-009",
                isin = "GB00CBX005E0",
                ticker = "EDNAIR 4.95 35",
                name = "Edinburgh Airport Decarbonisation Green Notes 4.95% 2035",
                issuer = "Edinburgh Airport Infrastructure Capital",
                issuerLei = "213800EDI005AIRP55",
                bondType = BondType.GREEN_BOND,
                couponRate = 4.95,
                couponFrequency = 1,
                dayCount = DayCount.ACT_ACT_ICMA,
                issueDate = "2023-05-05",
                maturityDate = "2035-05-05",
                maturityYears = 9.10,
                outstandingPrincipal = 250_000_000L,
                seniority = Seniority.SENIOR_SECURED,
                governingLaw = GoverningLaw.SCOTS_LAW,
                listingVenue = "CBX Green Debt Platform",
                verifiedRating = "A-",
                cleanPrice = 98.15,
                dirtyPrice = 99.45,
                accruedInterest = 1.30,
                ytm = 5.21,
                bidPrice = 97.90,
                askPrice = 98.40,
                bidYield = 5.25,
                askYield = 5.17,
                giltSpreadBps = 98,
                swapSpreadBps = 84,
                macaulayDuration = 7.30,
                modifiedDuration = 7.12,
                convexity = 0.62,
                dv01Per100k = 70.81,
                dailyChangeBps = +0.8
            )
        )

        for (inst in list) {
            BondPricingEngine.enrichInstrument(inst)
            instruments.add(inst)
        }
    }

    private fun seedOrderBooks() {
        for (inst in instruments) {
            val engine = OrderMatchingEngine(inst.id)
            engine.seedLiquidity(inst.cleanPrice)
            matchingEngines[inst.id] = engine
        }
    }

    private fun seedPrimaryDeals() {
        primaryDeals.add(
            IssuanceDeal(
                dealId = "DEAL-SCOT-001",
                issuerName = "Lothian Hydrogen & Renewables PLC",
                sector = "Clean Energy & Hydrogen Infrastructure",
                ticker = "LOTHYD",
                programmeTitle = "£120,000,000 6.25% Senior Secured Green Notes due 2029",
                targetNominalGbp = 120_000_000L,
                tenorYears = 5,
                indicativeSpreadGuidanceBps = "G+160 bps to G+175 bps",
                expectedCouponRate = 6.25,
                governingLaw = GoverningLaw.SCOTS_LAW,
                listingVenue = "CBX Scottish Growth Segment",
                status = IssuanceStatus.BOOKBUILDING,
                totalOrderBookGbp = 315_000_000L,
                bookCoverRatio = 2.62,
                leadManagers = listOf("Caledonian Capital Markets", "Charlotte Square Securities", "Bank of Scotland Fixed Income"),
                prospectusDocRef = "DOC-CBX-PROSPECTUS-LOTHYD-2024-V3.PDF",
                useOfProceeds = "Financing Leith Docks green electrolyser facility and Lothian fleet hydrogen distribution infrastructure.",
                orders = listOf(
                    SyndicateOrder("ORD-SYN-101", "Scottish Widows Fixed Income", "Life & Pensions", "Edinburgh, UK", 162, 45_000_000L, 20_000_000L),
                    SyndicateOrder("ORD-SYN-102", "Baillie Gifford Synthetic Desk", "Asset Manager", "Edinburgh, UK", 160, 60_000_000L, 25_000_000L),
                    SyndicateOrder("ORD-SYN-103", "Standard Life Simulated Mandate", "Insurance", "Edinburgh, UK", 165, 50_000_000L, 22_000_000L),
                    SyndicateOrder("ORD-SYN-104", "abrdn Sterling Credit Desk", "Asset Manager", "Edinburgh, UK", 168, 70_000_000L, 28_000_000L),
                    SyndicateOrder("ORD-SYN-105", "Strathclyde Pension Fund Allocations", "Local Government Pension", "Glasgow, UK", 164, 40_000_000L, 15_000_000L),
                    SyndicateOrder("ORD-SYN-106", "Waverley Private Wealth Mandate", "Wealth Manager", "Edinburgh, UK", 170, 50_000_000L, 10_000_000L)
                )
            )
        )

        primaryDeals.add(
            IssuanceDeal(
                dealId = "DEAL-SCOT-002",
                issuerName = "Forth Valley Distillers Group PLC",
                sector = "Food & Beverage / Whisky Infrastructure",
                ticker = "FORTHD",
                programmeTitle = "£80,000,000 5.85% Secured Maturation Facility Notes due 2032",
                targetNominalGbp = 80_000_000L,
                tenorYears = 8,
                indicativeSpreadGuidanceBps = "G+165 bps to G+175 bps",
                expectedCouponRate = 5.85,
                governingLaw = GoverningLaw.SCOTS_LAW,
                listingVenue = "CBX Scottish Growth Segment",
                status = IssuanceStatus.PRICED,
                totalOrderBookGbp = 210_000_000L,
                bookCoverRatio = 2.63,
                leadManagers = listOf("Caledonian Capital Markets", "Highland & Islands Financial"),
                prospectusDocRef = "DOC-CBX-PROSPECTUS-FORTHD-FINAL.PDF",
                useOfProceeds = "Construction of climate-controlled bonded maturation warehouses in Clackmannanshire and barrel inventory collateralisation.",
                orders = listOf(
                    SyndicateOrder("ORD-SYN-201", "Walter Scott Global Desk", "Asset Manager", "Edinburgh, UK", 168, 40_000_000L, 22_000_000L),
                    SyndicateOrder("ORD-SYN-202", "Martin Currie UK Equity & Credit", "Asset Manager", "Edinburgh, UK", 166, 35_000_000L, 18_000_000L),
                    SyndicateOrder("ORD-SYN-203", "St Andrews Endowment Desk", "University Endowment", "St Andrews, UK", 172, 25_000_000L, 12_000_000L),
                    SyndicateOrder("ORD-SYN-204", "Holyrood Credit Opportunities Fund", "Alternative Credit", "Edinburgh, UK", 170, 60_000_000L, 28_000_000L)
                )
            )
        )
    }

    private fun seedCreditProfiles() {
        issuerCreditProfiles.add(
            IssuerCreditProfile(
                issuerId = "CRED-LOTHYD",
                legalName = "Lothian Hydrogen & Renewables Public Limited Company",
                shortName = "Lothian Hydrogen",
                sector = "Renewables & Cleantech Infrastructure",
                headquarters = "Leith Docks, Edinburgh, EH6 7DN",
                lei = "213800EDIN001LOTH99",
                cbxInternalRating = "CBX Tier-2 (BBB- Investment Grade Equivalent)",
                ratingOutlook = "Stable",
                externalBenchmarkRating = "Indicative Moody's / S&P: Baa3 / BBB-",
                financials = listOf(
                    FinancialStatementYear(
                        fiscalYear = "FY2024 (Actual)",
                        revenueGbpM = 148.5,
                        grossProfitGbpM = 62.4,
                        ebitdaGbpM = 44.8,
                        operatingIncomeGbpM = 31.2,
                        netIncomeGbpM = 22.6,
                        operatingCashFlowGbpM = 38.5,
                        capexGbpM = 26.0,
                        freeCashFlowGbpM = 12.5,
                        totalDebtGbpM = 120.0,
                        cashEquivalentsGbpM = 24.5,
                        netDebtGbpM = 95.5,
                        netLeverage = 2.13,
                        interestCoverage = 5.97
                    ),
                    FinancialStatementYear(
                        fiscalYear = "FY2023 (Actual)",
                        revenueGbpM = 122.0,
                        grossProfitGbpM = 49.5,
                        ebitdaGbpM = 35.0,
                        operatingIncomeGbpM = 24.1,
                        netIncomeGbpM = 17.0,
                        operatingCashFlowGbpM = 29.8,
                        capexGbpM = 22.5,
                        freeCashFlowGbpM = 7.3,
                        totalDebtGbpM = 95.0,
                        cashEquivalentsGbpM = 18.2,
                        netDebtGbpM = 76.8,
                        netLeverage = 2.19,
                        interestCoverage = 5.38
                    ),
                    FinancialStatementYear(
                        fiscalYear = "FY2022 (Actual)",
                        revenueGbpM = 94.2,
                        grossProfitGbpM = 36.8,
                        ebitdaGbpM = 24.5,
                        operatingIncomeGbpM = 15.6,
                        netIncomeGbpM = 10.4,
                        operatingCashFlowGbpM = 20.1,
                        capexGbpM = 16.0,
                        freeCashFlowGbpM = 4.1,
                        totalDebtGbpM = 65.0,
                        cashEquivalentsGbpM = 12.0,
                        netDebtGbpM = 53.0,
                        netLeverage = 2.16,
                        interestCoverage = 4.90
                    )
                ),
                debtMaturityProfile = listOf(
                    DebtMaturityBucket("2025", 8.0, "Bank Term Loan A", 5.75),
                    DebtMaturityBucket("2026", 12.0, "Scottish Enterprise R&D Facility", 4.25),
                    DebtMaturityBucket("2027", 15.0, "Equipment Lease Notes", 6.00),
                    DebtMaturityBucket("2029", 120.0, "CBX Senior Secured Green Bond", 6.25)
                ),
                covenants = listOf(
                    CovenantRule("Net Leverage Cap", "Max 3.50x Net Debt / EBITDA", "Current: 2.13x", 39.1, true),
                    CovenantRule("Interest Coverage Floor", "Min 3.50x EBITDA / Interest", "Current: 5.97x", 70.5, true),
                    CovenantRule("Negative Pledge", "No prior ranking charges on Leith site", "Compliant - First Fixed Charge", 100.0, true),
                    CovenantRule("Minimum Liquidity Headroom", "Min £15.0M unencumbered cash", "Current: £24.5M", 63.3, true)
                ),
                analystCommentary = "Lothian Hydrogen demonstrates consistent operational cash flow growth backed by 15-year offtake contracts with municipal transport operators in Edinburgh and Fife. Strong fixed-asset backing on renewable production capacity provides 1.65x asset cover.",
                keyStrengths = listOf(
                    "Long-term indexed take-or-pay hydrogen contracts with Lothian Buses and industrial partners",
                    "Modern, dedicated grid interconnection in Leith Docks with Scottish Power Energy Networks",
                    "Disciplined net leverage at 2.13x with significant headroom against 3.50x covenant"
                ),
                keyCreditRisks = listOf(
                    "Execution risk on Phase 2 50MW electrolyser expansion during 2025-2026",
                    "Volatility in wholesale electricity input prices, partially hedged through power purchase agreements"
                ),
                lastReviewDate = "15 September 2026",
                leadAnalyst = "Alasdair MacLeod, CFA (Head of Credit Research)"
            )
        )

        issuerCreditProfiles.add(
            IssuerCreditProfile(
                issuerId = "CRED-FORTHD",
                legalName = "Forth Valley Distillers Group Public Limited Company",
                shortName = "Forth Valley Distillers",
                sector = "Consumer Staples / Premium Scotch Whisky",
                headquarters = "Stirling Business Park, FK9 4NF",
                lei = "213800STIR003FORT77",
                cbxInternalRating = "CBX Tier-2 (BBB Investment Grade Equivalent)",
                ratingOutlook = "Positive",
                externalBenchmarkRating = "Indicative Fitch: BBB",
                financials = listOf(
                    FinancialStatementYear(
                        fiscalYear = "FY2024",
                        revenueGbpM = 210.0,
                        grossProfitGbpM = 115.5,
                        ebitdaGbpM = 58.0,
                        operatingIncomeGbpM = 48.0,
                        netIncomeGbpM = 36.5,
                        operatingCashFlowGbpM = 49.0,
                        capexGbpM = 20.0,
                        freeCashFlowGbpM = 29.0,
                        totalDebtGbpM = 105.0,
                        cashEquivalentsGbpM = 32.0,
                        netDebtGbpM = 73.0,
                        netLeverage = 1.26,
                        interestCoverage = 9.45
                    ),
                    FinancialStatementYear(
                        fiscalYear = "FY2023",
                        revenueGbpM = 188.0,
                        grossProfitGbpM = 101.5,
                        ebitdaGbpM = 50.2,
                        operatingIncomeGbpM = 41.0,
                        netIncomeGbpM = 30.5,
                        operatingCashFlowGbpM = 41.5,
                        capexGbpM = 18.0,
                        freeCashFlowGbpM = 23.5,
                        totalDebtGbpM = 90.0,
                        cashEquivalentsGbpM = 24.0,
                        netDebtGbpM = 66.0,
                        netLeverage = 1.31,
                        interestCoverage = 8.80
                    )
                ),
                debtMaturityProfile = listOf(
                    DebtMaturityBucket("2026", 15.0, "Working Capital Barrel Revolver", 5.20),
                    DebtMaturityBucket("2028", 10.0, "Bank Term Loan", 5.50),
                    DebtMaturityBucket("2032", 80.0, "CBX Senior Secured 5.85% Bond", 5.85)
                ),
                covenants = listOf(
                    CovenantRule("Net Leverage Cap", "Max 3.25x Net Debt / EBITDA", "Current: 1.26x", 61.2, true),
                    CovenantRule("Whisky Stock Asset Cover", "Min 2.0x Maturing Inventory / Net Debt", "Current: 3.42x", 71.0, true),
                    CovenantRule("Interest Coverage", "Min 4.0x EBITDA / Interest", "Current: 9.45x", 136.2, true)
                ),
                analystCommentary = "Whisky inventory acts as an appreciating hard-commodity collateral pool with over 450,000 casks maturing across Lowland and Highland warehouses. Low net leverage of 1.26x provides best-in-class downside cushion.",
                keyStrengths = listOf(
                    "High gross margin (55%) driven by single malt export pricing in North America and Asia",
                    "Asset coverage of 3.42x based on independent valuation of maturing cask stock",
                    "Conservative debt profile with no near-term refinancing cliffs"
                ),
                keyCreditRisks = listOf(
                    "Tariff exposure on spirits entering select overseas jurisdictions",
                    "Working capital lockup during mandatory multi-year aging cycle"
                ),
                lastReviewDate = "02 October 2026",
                leadAnalyst = "Fiona Campbell (Senior Credit Analyst)"
            )
        )
    }

    private fun seedSettlementData() {
        settlementInstructions.add(
            SettlementInstruction(
                instructionId = "SETTL-2026-901",
                tradeId = "TRD-CBX-1044",
                isin = "GB00BM8Z2S69",
                instrumentName = "UK Gilt 4.50% 2034 (10Y)",
                buyer = "Charlotte Square Fixed Income",
                seller = "Standard Life Simulated Mandate",
                nominalGbp = 2_000_000L,
                settlementAmountGbp = 2_063_000.0,
                tradeDate = "2026-10-12 09:15:22",
                settlementDate = "2026-10-13 (T+1 London)",
                status = SettlementStatus.MATCHED,
                crestReference = "CRST-LON-88912300"
            )
        )
        settlementInstructions.add(
            SettlementInstruction(
                instructionId = "SETTL-2026-902",
                tradeId = "TRD-CBX-1039",
                isin = "GB00CBX001A8",
                instrumentName = "Lothian Hydrogen 6.25% 2029",
                buyer = "Baillie Gifford Synthetic Desk",
                seller = "Lothian Liquidity Provider",
                nominalGbp = 500_000L,
                settlementAmountGbp = 512_500.0,
                tradeDate = "2026-10-11 14:40:11",
                settlementDate = "2026-10-12 (T+1 London)",
                status = SettlementStatus.SETTLED,
                crestReference = "CRST-LON-77219941"
            )
        )
        settlementInstructions.add(
            SettlementInstruction(
                instructionId = "SETTL-2026-903",
                tradeId = "TRD-CBX-1028",
                isin = "XS2250153782",
                instrumentName = "NatWest Group 5.125% 2031",
                buyer = "Waverley Wealth Management",
                seller = "St Andrew Gilts & Credit",
                nominalGbp = 1_000_000L,
                settlementAmountGbp = 1_008_500.0,
                tradeDate = "2026-10-11 11:20:05",
                settlementDate = "2026-10-12 (T+1 London)",
                status = SettlementStatus.SETTLED,
                crestReference = "CRST-LON-66301128"
            )
        )
    }

    private fun seedCorporateActions() {
        corporateActions.add(
            CorporateActionEvent(
                eventId = "CA-2026-081",
                isin = "GB00BNNGP668",
                instrumentName = "United Kingdom Gilt 4.25% 2027",
                type = CorporateActionType.COUPON_PAYMENT,
                exDate = "2026-11-26",
                recordDate = "2026-11-27",
                paymentDate = "2026-12-07",
                ratePerCent = 2.125, // Semi-annual half of 4.25%
                estimatedDisbursementGbp = 733_125_000L
            )
        )
        corporateActions.add(
            CorporateActionEvent(
                eventId = "CA-2026-082",
                isin = "GB00CBX001A8",
                instrumentName = "Lothian Hydrogen & Renewables 6.25% 2029",
                type = CorporateActionType.COUPON_PAYMENT,
                exDate = "2027-03-01",
                recordDate = "2027-03-03",
                paymentDate = "2027-03-15",
                ratePerCent = 3.125,
                estimatedDisbursementGbp = 3_750_000L
            )
        )
        corporateActions.add(
            CorporateActionEvent(
                eventId = "CA-2026-083",
                isin = "XS2438619447",
                instrumentName = "SSE PLC 3.875% 2029",
                type = CorporateActionType.COUPON_PAYMENT,
                exDate = "2027-08-20",
                recordDate = "2027-08-22",
                paymentDate = "2027-09-04",
                ratePerCent = 3.875,
                estimatedDisbursementGbp = 19_375_000L
            )
        )
    }

    private fun seedAuditLogs() {
        auditLogs.add(
            AuditLogEntry(
                logId = "AUD-0091",
                timestamp = "11:28:44 BST",
                category = "PRE_TRADE_LIMIT_CHECK",
                actor = "RiskGateway-EDIN",
                details = "Pre-trade credit limit check approved for £5M notional UKT 4.50 34 by Desk-EDIN-01. Counterparty headroom 92%."
            )
        )
        auditLogs.add(
            AuditLogEntry(
                logId = "AUD-0092",
                timestamp = "11:29:10 BST",
                category = "ORDER_SUBMITTED",
                actor = "Desk-EDIN-01",
                details = "Order submitted: BUY 1,000,000 GBP LOTHYD 6.25 29 @ 101.20 Limit. Status: WORKING on CBX Matching Engine."
            )
        )
        auditLogs.add(
            AuditLogEntry(
                logId = "AUD-0093",
                timestamp = "11:29:12 BST",
                category = "EXECUTION_MATCH",
                actor = "CBX_MATCH_CORE",
                details = "Deterministic Match: TRD-CBX-1048. 1,000,000 GBP @ 101.20 against Resting Offer REST-A-0. RTS 25 Nanosecond audit stamped."
            )
        )
        auditLogs.add(
            AuditLogEntry(
                logId = "AUD-0094",
                timestamp = "11:30:00 BST",
                category = "MIFIR_TRANSACTION_REPORTING",
                actor = "ComplianceEngine",
                details = "MiFIR RTS 22 / RTS 25 simulated XML payload generated for TRD-CBX-1048. Legal entity identifier checks passed."
            )
        )
    }

    private fun seedResearch() {
        researchArticles.add(
            ResearchArticle(
                articleId = "RES-001",
                title = "Scottish Corporate Debt & Gilt Spread Dynamics in Autumn 2026",
                author = "Hamish Crawford, Chief Fixed-Income Strategist",
                date = "10 October 2026",
                sector = "Macro & Gilts Strategy",
                summary = "An analysis of the 10-year Gilt benchmark spread against Scottish mid-market infrastructure credits, highlighting covenant protection advantages in Scots Law documentation.",
                keyTakeaways = listOf(
                    "Gilt yields have stabilized in the 4.15% - 4.30% corridor following BoE inflation data.",
                    "Scottish Growth issuers offer an attractive 160-185 bps spread over benchmark Gilts with hard-asset collateral cover.",
                    "First-ranking floating charges under Scots Law provide enhanced creditor protection relative to unsecured English corporate debentures."
                )
            )
        )
        researchArticles.add(
            ResearchArticle(
                articleId = "RES-002",
                title = "The Decarbonisation Pipeline: Financing Scotland's Green Hydrogen Corridor",
                author = "Moira Sutherland, Head of ESG & Infrastructure Research",
                date = "05 October 2026",
                sector = "Green Bonds & Renewables",
                summary = "Examining the inaugural green note issuances from Leith Docks and Aberdeen energy hubs under the ICMA Green Bond Principles.",
                keyTakeaways = listOf(
                    "Investor demand for Scottish green bonds remains heavily oversubscribed (2.6x book cover average).",
                    "Verification frameworks conform to the UK Green Taxonomy draft standard.",
                    "Secondary market liquidity on the CBX Green Segment shows tight 10 bps bid-offer spreads."
                )
            )
        )
    }

    // Public Getters and Mutators
    fun getInstruments(): List<BondInstrument> = instruments.toList()

    fun getInstrument(id: String): BondInstrument? = instruments.find { it.id == id }

    fun getMatchingEngine(instrumentId: String): OrderMatchingEngine {
        return matchingEngines.getOrPut(instrumentId) {
            val engine = OrderMatchingEngine(instrumentId)
            val inst = getInstrument(instrumentId)
            if (inst != null) engine.seedLiquidity(inst.cleanPrice)
            engine
        }
    }

    fun submitOrder(order: Order): List<TradePrint> {
        val inst = getInstrument(order.instrumentId) ?: return emptyList()
        val engine = getMatchingEngine(order.instrumentId)
        val trades = engine.submitOrder(order, inst)

        if (trades.isNotEmpty()) {
            for (t in trades) {
                auditLogs.add(
                    0,
                    AuditLogEntry(
                        logId = "AUD-${System.currentTimeMillis() % 10000}",
                        timestamp = t.timestamp,
                        category = "TRADE_EXECUTED",
                        actor = order.participant,
                        details = "Executed ${t.quantity} GBP of ${inst.ticker} @ ${t.price} with ${t.seller}. Trade ID: ${t.tradeId}"
                    )
                )

                // Add to post-trade settlement pipeline
                settlementInstructions.add(
                    0,
                    SettlementInstruction(
                        instructionId = "SETTL-${System.currentTimeMillis() % 100000}",
                        tradeId = t.tradeId,
                        isin = t.isin,
                        instrumentName = t.instrumentName,
                        buyer = t.buyer,
                        seller = t.seller,
                        nominalGbp = t.quantity,
                        settlementAmountGbp = (t.quantity / 100.0) * inst.dirtyPrice,
                        tradeDate = t.timestamp,
                        settlementDate = "T+1 (London CREST)",
                        status = SettlementStatus.MATCHED,
                        crestReference = "CRST-LON-${System.currentTimeMillis() % 90000000 + 10000000}"
                    )
                )
            }
        }
        return trades
    }

    fun getAllTradeBlotters(): List<TradePrint> {
        val all = mutableListOf<TradePrint>()
        for (engine in matchingEngines.values) {
            all.addAll(engine.getTradeBlotter())
        }
        return all.sortedByDescending { it.tradeId }
    }

    fun getPrimaryDeals(): List<IssuanceDeal> = primaryDeals.toList()

    fun getIssuerCreditProfiles(): List<IssuerCreditProfile> = issuerCreditProfiles.toList()

    fun getSettlementInstructions(): List<SettlementInstruction> = settlementInstructions.toList()

    fun updateSettlementStatus(instructionId: String, newStatus: SettlementStatus) {
        val item = settlementInstructions.find { it.instructionId == instructionId }
        if (item != null) {
            item.status = newStatus
            auditLogs.add(
                0,
                AuditLogEntry(
                    logId = "AUD-${System.currentTimeMillis() % 10000}",
                    timestamp = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.UK).format(java.util.Date()),
                    category = "SETTLEMENT_STATUS_CHANGE",
                    actor = "CREST-Gateway",
                    details = "Settlement ${item.crestReference} updated to ${newStatus.label}"
                )
            )
        }
    }

    fun getCorporateActions(): List<CorporateActionEvent> = corporateActions.toList()

    fun getAuditLogs(): List<AuditLogEntry> = auditLogs.toList()

    fun getResearchArticles(): List<ResearchArticle> = researchArticles.toList()

    // Institutional Portfolio (£250M sample)
    fun getSamplePortfolio(): PortfolioSummary {
        val holdings = listOf(
            PortfolioHolding(
                holdingId = "HOLD-01",
                instrumentId = "INST-001",
                isin = "GB00BNNGP668",
                instrumentName = "United Kingdom Gilt 4.25% 2027",
                issuer = "UK DMO",
                bondType = BondType.GILT,
                nominalGbp = 60_000_000L,
                bookPrice = 99.80,
                currentCleanPrice = 100.15,
                dirtyPrice = 101.45,
                marketValueGbp = 60_870_000.0,
                unrealizedPnlGbp = 210_000.0,
                ytm = 4.15,
                modifiedDuration = 1.54,
                dv01Gbp = 9_372.0,
                portfolioWeightPct = 24.3
            ),
            PortfolioHolding(
                holdingId = "HOLD-02",
                instrumentId = "INST-002",
                isin = "GB00BM8Z2S69",
                instrumentName = "UK Gilt 4.50% 2034 (10Y Benchmark)",
                issuer = "UK DMO",
                bondType = BondType.GILT,
                nominalGbp = 75_000_000L,
                bookPrice = 101.10,
                currentCleanPrice = 101.80,
                dirtyPrice = 103.15,
                marketValueGbp = 77_362_500.0,
                unrealizedPnlGbp = 525_000.0,
                ytm = 4.24,
                modifiedDuration = 6.81,
                dv01Gbp = 52_687.0,
                portfolioWeightPct = 30.9
            ),
            PortfolioHolding(
                holdingId = "HOLD-03",
                instrumentId = "INST-004",
                isin = "XS2438619447",
                instrumentName = "SSE PLC 3.875% 2029",
                issuer = "SSE PLC",
                bondType = BondType.STERLING_CORP,
                nominalGbp = 35_000_000L,
                bookPrice = 97.20,
                currentCleanPrice = 96.85,
                dirtyPrice = 97.90,
                marketValueGbp = 34_265_000.0,
                unrealizedPnlGbp = -122_500.0,
                ytm = 4.88,
                modifiedDuration = 3.00,
                dv01Gbp = 10_279.0,
                portfolioWeightPct = 13.7
            ),
            PortfolioHolding(
                holdingId = "HOLD-04",
                instrumentId = "INST-005",
                isin = "XS2250153782",
                instrumentName = "NatWest Group 5.125% 2031 Tier 2",
                issuer = "NatWest Group",
                bondType = BondType.STERLING_CORP,
                nominalGbp = 30_000_000L,
                bookPrice = 98.90,
                currentCleanPrice = 99.40,
                dirtyPrice = 100.85,
                marketValueGbp = 30_255_000.0,
                unrealizedPnlGbp = 150_000.0,
                ytm = 5.27,
                modifiedDuration = 3.99,
                dv01Gbp = 12_072.0,
                portfolioWeightPct = 12.1
            ),
            PortfolioHolding(
                holdingId = "HOLD-05",
                instrumentId = "INST-006",
                isin = "GB00CBX001A8",
                instrumentName = "Lothian Hydrogen 6.25% 2029",
                issuer = "Lothian Hydrogen & Renewables",
                bondType = BondType.SCOTTISH_GROWTH,
                nominalGbp = 25_000_000L,
                bookPrice = 100.00,
                currentCleanPrice = 101.20,
                dirtyPrice = 102.50,
                marketValueGbp = 25_625_000.0,
                unrealizedPnlGbp = 300_000.0,
                ytm = 5.80,
                modifiedDuration = 2.57,
                dv01Gbp = 6_585.0,
                portfolioWeightPct = 10.2
            ),
            PortfolioHolding(
                holdingId = "HOLD-06",
                instrumentId = "INST-008",
                isin = "GB00CBX003C4",
                instrumentName = "Forth Valley Distillers 5.85% 2032",
                issuer = "Forth Valley Distillers",
                bondType = BondType.SCOTTISH_GROWTH,
                nominalGbp = 22_000_000L,
                bookPrice = 99.50,
                currentCleanPrice = 99.80,
                dirtyPrice = 101.12,
                marketValueGbp = 22_246_400.0,
                unrealizedPnlGbp = 66_000.0,
                ytm = 5.89,
                modifiedDuration = 4.95,
                dv01Gbp = 11_011.0,
                portfolioWeightPct = 8.8
            )
        )

        val totalAum = holdings.sumOf { it.marketValueGbp }
        val totalDv01 = holdings.sumOf { it.dv01Gbp }
        val weightedYield = holdings.sumOf { it.ytm * (it.marketValueGbp / totalAum) }
        val weightedDuration = holdings.sumOf { it.modifiedDuration * (it.marketValueGbp / totalAum) }

        return PortfolioSummary(
            portfolioName = "Caledonian Institutional Sterling Fixed Income Mandate",
            mandate = "UK Gilts & Scottish Growth High-Grade Debt (Benchmark: Markit iBoxx £ Collateralized)",
            totalAumGbp = totalAum,
            totalDv01Gbp = totalDv01,
            weightedYield = weightedYield,
            weightedDuration = weightedDuration,
            weightedConvexity = 0.88,
            holdings = holdings
        )
    }

    // RFQ Generation
    fun createRfq(instrumentId: String, side: OrderSide, notionalGbp: Long): RfqRequest {
        val inst = getInstrument(instrumentId) ?: instruments[0]
        val quotes = listOf(
            DealerQuote(
                dealerId = "DLR-CHARLOTTE",
                dealerName = "Charlotte Square Capital Markets",
                dealerDesk = "Edinburgh Gilt & Credit Desk",
                bidPrice = inst.cleanPrice - 0.08,
                askPrice = inst.cleanPrice + 0.07,
                bidYield = inst.ytm + 0.02,
                askYield = inst.ytm - 0.02,
                notionalOffered = notionalGbp,
                validSecondsRemaining = 45
            ),
            DealerQuote(
                dealerId = "DLR-WAVERLEY",
                dealerName = "Waverley Securities (Scotland)",
                dealerDesk = "Sterling Liquidity Solutions",
                bidPrice = inst.cleanPrice - 0.06,
                askPrice = inst.cleanPrice + 0.09,
                bidYield = inst.ytm + 0.015,
                askYield = inst.ytm - 0.025,
                notionalOffered = notionalGbp,
                validSecondsRemaining = 42
            ),
            DealerQuote(
                dealerId = "DLR-HOLYROOD",
                dealerName = "Holyrood Debt Partners",
                dealerDesk = "Institutional Debt Syndication",
                bidPrice = inst.cleanPrice - 0.12,
                askPrice = inst.cleanPrice + 0.05,
                bidYield = inst.ytm + 0.03,
                askYield = inst.ytm - 0.012,
                notionalOffered = notionalGbp,
                validSecondsRemaining = 38
            )
        )

        val rfq = RfqRequest(
            rfqId = "RFQ-CBX-${System.currentTimeMillis() % 100000}",
            instrumentId = inst.id,
            isin = inst.isin,
            instrumentName = inst.name,
            side = side,
            notionalGbp = notionalGbp,
            createdAt = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.UK).format(java.util.Date()),
            quotes = quotes
        )
        activeRfqs.add(0, rfq)
        return rfq
    }

    fun getActiveRfqs(): List<RfqRequest> = activeRfqs.toList()
}
