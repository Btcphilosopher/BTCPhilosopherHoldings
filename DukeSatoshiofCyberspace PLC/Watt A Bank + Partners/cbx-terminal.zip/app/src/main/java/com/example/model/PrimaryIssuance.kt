package com.example.model

enum class IssuanceStatus(val label: String) {
    ANNOUNCED("Mandate Announced"),
    ROADSHOW("Investor Roadshow"),
    BOOKBUILDING("Bookbuilding Open"),
    PRICED("Priced / Books Closed"),
    ALLOCATED("Allocated & Settling"),
    LISTED("Admission to Trading")
}

data class SyndicateOrder(
    val orderId: String,
    val institutionName: String,
    val institutionType: String, // Pension Fund, Life Insurer, Sovereign Wealth, Wealth Manager
    val jurisdiction: String,
    val bidYieldSpreadBps: Int,
    val orderNominalGbp: Long,
    var allocatedNominalGbp: Long
)

data class IssuanceDeal(
    val dealId: String,
    val issuerName: String,
    val sector: String,
    val ticker: String,
    val programmeTitle: String,
    val targetNominalGbp: Long,
    val tenorYears: Int,
    val indicativeSpreadGuidanceBps: String, // e.g. "G+185 bps to G+195 bps"
    val couponType: CouponType = CouponType.FIXED,
    val expectedCouponRate: Double,
    val governingLaw: GoverningLaw = GoverningLaw.SCOTS_LAW,
    val listingVenue: String = "CBX Scottish Growth Segment",
    val status: IssuanceStatus,
    val totalOrderBookGbp: Long,
    val bookCoverRatio: Double, // e.g. 2.85x
    val leadManagers: List<String>,
    val prospectusDocRef: String,
    val useOfProceeds: String,
    val orders: List<SyndicateOrder>
)
