package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BondInstrument
import com.example.ui.CbxUiState
import com.example.ui.CbxViewModel
import com.example.ui.CbxWorkspace
import com.example.ui.components.CbxMetricTile
import com.example.ui.components.CbxSimulatedBanner
import com.example.ui.components.CbxTerminalCard
import com.example.ui.components.CbxYieldCurveChart
import com.example.ui.theme.*

@Composable
fun CbxHomeScreen(
    uiState: CbxUiState,
    viewModel: CbxViewModel,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            CbxSimulatedBanner()
        }

        // Scottish Financial Desk Briefing Banner
        item {
            CbxTerminalCard(
                title = "Edinburgh Desk Market Briefing",
                badgeText = "OCT 2026 EDITION"
            ) {
                Text(
                    text = "Sterling fixed-income markets opened steady in Edinburgh. The 10-year UK Gilt benchmark sits at 4.24% YTM with steady demand across domestic pension mandates. Scottish growth-company debt spreads remain well-anchored, with the Lothian Hydrogen green syndication closing today at 2.62x book cover.",
                    color = CbxTextPrimary,
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CbxMetricTile(
                        label = "10Y Gilt Benchmark",
                        value = "4.24%",
                        subValue = "UKT 4.50 34",
                        valueColor = CbxEdinburghGold,
                        modifier = Modifier.weight(1f)
                    )
                    CbxMetricTile(
                        label = "2Y Front-End Gilt",
                        value = "4.15%",
                        subValue = "UKT 4.25 27",
                        valueColor = CbxCaledonianBlue,
                        modifier = Modifier.weight(1f)
                    )
                    CbxMetricTile(
                        label = "Scot Corp Spread",
                        value = "+165 bps",
                        subValue = "Gilt Ref",
                        valueColor = CbxScottishHeather,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Interactive Yield Curve Chart Card
        item {
            CbxTerminalCard(
                title = "Benchmark Sterling Yield Curves",
                badgeText = "SVENSSON MODEL"
            ) {
                CbxYieldCurveChart(
                    giltCurve = uiState.giltCurve,
                    scottishCurve = uiState.scottishCurve
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Curve Shift: ${if (uiState.curveShiftBps >= 0) "+${uiState.curveShiftBps}" else "${uiState.curveShiftBps}"} bps",
                        color = CbxTextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Button(
                        onClick = { viewModel.selectWorkspace(CbxWorkspace.YIELD_CURVES) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CbxNavyElevated,
                            contentColor = CbxEdinburghGold
                        ),
                        shape = RoundedCornerShape(2.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("nav_to_curves")
                    ) {
                        Text("Open Curve Analytics →", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // Quick Workspace Nav Launchpad
        item {
            CbxTerminalCard(
                title = "Institutional Desks Launchpad",
                badgeText = "16 WORKSPACES"
            ) {
                val launchpadItems = listOf(
                    Triple(CbxWorkspace.MARKET_WATCH, "Market Watch", "Browse full sterling bond monitor & spreads"),
                    Triple(CbxWorkspace.ORDER_BOOK, "Order Book", "Simulated LOB with price-time priority"),
                    Triple(CbxWorkspace.RFQ_DESK, "RFQ Desk", "Bilateral institutional dealer quotes"),
                    Triple(CbxWorkspace.PRIMARY_ISSUANCE, "Primary Syndication", "Corporate debt bookbuilding & allocations"),
                    Triple(CbxWorkspace.ISSUER_CREDIT, "Credit Research", "Balance sheet, leverage & Scots covenants"),
                    Triple(CbxWorkspace.BOND_ANALYTICS, "Bond Analytics", "Duration, Convexity, DV01 & YTM solver"),
                    Triple(CbxWorkspace.PORTFOLIO_RISK, "Portfolio Risk", "£250M AUM stress testing & scenarios"),
                    Triple(CbxWorkspace.SETTLEMENT, "Settlement Ops", "Post-trade CREST instructions & clearing")
                )

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    launchpadItems.chunked(2).forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            row.forEach { (ws, name, desc) ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(CbxNavyElevated, RoundedCornerShape(2.dp))
                                        .border(1.dp, CbxNavyBorder, RoundedCornerShape(2.dp))
                                        .clickable { viewModel.selectWorkspace(ws) }
                                        .padding(8.dp)
                                        .testTag("launch_${ws.id.lowercase()}")
                                ) {
                                    Column {
                                        Text(
                                            text = "[ ${ws.id} ] $name",
                                            color = CbxEdinburghGold,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Text(
                                            text = desc,
                                            color = CbxTextSecondary,
                                            fontSize = 9.sp,
                                            lineHeight = 13.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Active Watchlist Snapshot
        item {
            CbxTerminalCard(
                title = "Active Sterling Quotes & Depth",
                badgeText = "${uiState.instruments.size} BONDS"
            ) {
                uiState.instruments.take(4).forEach { bond ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.selectInstrument(bond)
                                viewModel.selectWorkspace(CbxWorkspace.BOND_MONITOR)
                            }
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = bond.ticker,
                                color = CbxTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = bond.name,
                                color = CbxTextSecondary,
                                fontSize = 10.sp
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "%.2f".format(bond.cleanPrice),
                                    color = CbxTextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "YTM %.2f%%".format(bond.ytm),
                                    color = CbxEdinburghGold,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "${if (bond.giltSpreadBps >= 0) "+${bond.giltSpreadBps}" else "${bond.giltSpreadBps}"} bps",
                                    color = CbxCaledonianBlue,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "DV01 £%.1f".format(bond.dv01Per100k),
                                    color = CbxTextMuted,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                    Divider(color = CbxNavyBorderSubtle, thickness = 1.dp)
                }
            }
        }
    }
}
