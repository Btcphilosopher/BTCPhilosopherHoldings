package com.example.model

enum class OrderSide(val label: String) {
    BUY("BUY / BID"),
    SELL("SELL / OFFER")
}

enum class OrderType(val label: String) {
    LIMIT("Limit Order"),
    MARKET("Market Order")
}

enum class TimeInForce(val label: String) {
    DAY("Day Order"),
    GTC("Good Till Cancelled"),
    IOC("Immediate Or Cancel"),
    FOK("Fill Or Kill")
}

enum class OrderStatus(val label: String) {
    PENDING("Pending"),
    WORKING("Working"),
    PARTIALLY_FILLED("Partial Fill"),
    FILLED("Filled"),
    CANCELLED("Cancelled"),
    REJECTED("Rejected")
}

data class OrderBookLevel(
    val price: Double,
    val size: Long,
    val orderCount: Int,
    val cumulativeSize: Long = 0L,
    val depthPercentage: Float = 0f
)

data class Order(
    val orderId: String,
    val instrumentId: String,
    val side: OrderSide,
    val type: OrderType,
    val price: Double,
    val quantity: Long, // Nominal GBP
    val filledQuantity: Long = 0L,
    val timeInForce: TimeInForce = TimeInForce.DAY,
    val status: OrderStatus = OrderStatus.WORKING,
    val timestamp: String,
    val participant: String = "Internal Desk (Desk-EDIN-01)"
)

data class TradePrint(
    val tradeId: String,
    val instrumentId: String,
    val isin: String,
    val instrumentName: String,
    val price: Double,
    val yield: Double,
    val quantity: Long,
    val side: OrderSide,
    val buyer: String,
    val seller: String,
    val timestamp: String,
    val settlementDate: String,
    val executionVenue: String = "CBX Matching Engine"
)
