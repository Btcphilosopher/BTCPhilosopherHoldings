package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.CbxTopBar
import com.example.ui.screens.*
import com.example.ui.theme.*

@Composable
fun CbxTerminalShell(
    viewModel: CbxViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // Handle back button to return to HOME if in secondary workspace
    BackHandler(enabled = uiState.currentWorkspace != CbxWorkspace.CBX_HOME) {
        viewModel.selectWorkspace(CbxWorkspace.CBX_HOME)
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(CbxNavyDark),
        topBar = {
            CbxTopBar(
                currentWorkspace = uiState.currentWorkspace,
                onWorkspaceSelected = { viewModel.selectWorkspace(it) },
                searchQuery = uiState.searchQuery,
                onSearchQueryChange = { viewModel.setSearchQuery(it) },
                edinburghTime = uiState.edinburghTime,
                venueMode = uiState.venueMode
            )
        },
        bottomBar = {
            // High-density quick category switcher bar
            Surface(
                color = CbxNavySurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(width = 1.dp, color = CbxNavyBorder)
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val quickWorkspaces = listOf(
                        CbxWorkspace.CBX_HOME,
                        CbxWorkspace.MARKET_WATCH,
                        CbxWorkspace.ORDER_BOOK,
                        CbxWorkspace.RFQ_DESK,
                        CbxWorkspace.PRIMARY_ISSUANCE,
                        CbxWorkspace.ISSUER_CREDIT,
                        CbxWorkspace.YIELD_CURVES,
                        CbxWorkspace.BOND_ANALYTICS,
                        CbxWorkspace.PORTFOLIO_RISK,
                        CbxWorkspace.SETTLEMENT,
                        CbxWorkspace.COMPLIANCE,
                        CbxWorkspace.SYSTEM_MONITOR
                    )

                    quickWorkspaces.forEach { ws ->
                        val isSelected = ws == uiState.currentWorkspace
                        Button(
                            onClick = { viewModel.selectWorkspace(ws) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) CbxEdinburghGold else CbxNavyElevated,
                                contentColor = if (isSelected) CbxNavyDark else CbxTextSecondary
                            ),
                            shape = RoundedCornerShape(2.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("quick_tab_${ws.id.lowercase()}")
                        ) {
                            Text(
                                text = ws.id,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(CbxNavyDark)
        ) {
            when (uiState.currentWorkspace) {
                CbxWorkspace.CBX_HOME -> CbxHomeScreen(uiState = uiState, viewModel = viewModel)
                CbxWorkspace.MARKET_WATCH -> MarketWatchScreen(uiState = uiState, viewModel = viewModel)
                CbxWorkspace.BOND_MONITOR -> BondMonitorScreen(uiState = uiState, viewModel = viewModel)
                CbxWorkspace.ORDER_BOOK -> OrderBookScreen(uiState = uiState, viewModel = viewModel)
                CbxWorkspace.TRADE_BLOTTER -> TradeBlotterScreen(uiState = uiState, viewModel = viewModel)
                CbxWorkspace.RFQ_DESK -> RfqDeskScreen(uiState = uiState, viewModel = viewModel)
                CbxWorkspace.PRIMARY_ISSUANCE -> PrimaryIssuanceScreen(uiState = uiState, viewModel = viewModel)
                CbxWorkspace.ISSUER_CREDIT -> IssuerCreditScreen(uiState = uiState, viewModel = viewModel)
                CbxWorkspace.YIELD_CURVES -> YieldCurvesScreen(uiState = uiState, viewModel = viewModel)
                CbxWorkspace.BOND_ANALYTICS -> BondAnalyticsScreen(uiState = uiState, viewModel = viewModel)
                CbxWorkspace.PORTFOLIO_RISK -> PortfolioRiskScreen(uiState = uiState, viewModel = viewModel)
                CbxWorkspace.SETTLEMENT -> SettlementScreen(uiState = uiState, viewModel = viewModel)
                CbxWorkspace.CORPORATE_ACTIONS -> CorporateActionsScreen(uiState = uiState, viewModel = viewModel)
                CbxWorkspace.RESEARCH -> ResearchScreen(uiState = uiState, viewModel = viewModel)
                CbxWorkspace.COMPLIANCE -> ComplianceScreen(uiState = uiState, viewModel = viewModel)
                CbxWorkspace.SYSTEM_MONITOR -> SystemMonitorScreen(uiState = uiState, viewModel = viewModel)
            }
        }
    }
}
