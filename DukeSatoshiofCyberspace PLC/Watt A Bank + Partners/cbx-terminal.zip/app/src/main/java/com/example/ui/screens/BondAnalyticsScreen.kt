package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.CbxUiState
import com.example.ui.CbxViewModel
import com.example.ui.components.CbxMetricTile
import com.example.ui.components.CbxSimulatedBanner
import com.example.ui.components.CbxTerminalCard
import com.example.ui.theme.*

@Composable
fun BondAnalyticsScreen(
    uiState: CbxUiState,
    viewModel: CbxViewModel,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            CbxSimulatedBanner()
        }

        // Quant Inputs Ticket
        item {
            CbxTerminalCard(
                title = "Fixed-Income Quant Pricing & Yield Solver",
                badgeText = "NEWTON-RAPHSON ENGINE"
            ) {
                Text(
                    text = "Input bond characteristics to solve for Yield to Maturity (YTM), Dirty Price, Accrued Interest, Duration, Convexity, and DV01.",
                    color = CbxTextSecondary,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = uiState.calcPriceInput,
                        onValueChange = { viewModel.setCalcPrice(it) },
                        label = { Text("Clean Price (£)", fontSize = 10.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = CbxTextPrimary,
                            unfocusedTextColor = CbxTextPrimary,
                            focusedBorderColor = CbxEdinburghGold,
                            unfocusedBorderColor = CbxNavyBorder
                        ),
                        modifier = Modifier.weight(1f).testTag("calc_price_input")
                    )
                    OutlinedTextField(
                        value = uiState.calcYieldInput,
                        onValueChange = { viewModel.setCalcYield(it) },
                        label = { Text("Yield to Maturity (%)", fontSize = 10.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = CbxTextPrimary,
                            unfocusedTextColor = CbxTextPrimary,
                            focusedBorderColor = CbxProfitGreen,
                            unfocusedBorderColor = CbxNavyBorder
                        ),
                        modifier = Modifier.weight(1f).testTag("calc_yield_input")
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = uiState.calcCouponInput,
                        onValueChange = { viewModel.setCalcCoupon(it) },
                        label = { Text("Coupon Rate (%)", fontSize = 10.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = CbxTextPrimary,
                            unfocusedTextColor = CbxTextPrimary,
                            focusedBorderColor = CbxEdinburghGold,
                            unfocusedBorderColor = CbxNavyBorder
                        ),
                        modifier = Modifier.weight(1f).testTag("calc_coupon_input")
                    )
                    OutlinedTextField(
                        value = "%.1f".format(uiState.calcMaturityYears),
                        onValueChange = {
                            val y = it.toDoubleOrNull()
                            if (y != null && y > 0) viewModel.setCalcMaturity(y)
                        },
                        label = { Text("Tenor (Years)", fontSize = 10.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = CbxTextPrimary,
                            unfocusedTextColor = CbxTextPrimary,
                            focusedBorderColor = CbxEdinburghGold,
                            unfocusedBorderColor = CbxNavyBorder
                        ),
                        modifier = Modifier.weight(1f).testTag("calc_maturity_input")
                    )
                }
            }
        }

        // Solved Sensitivities
        item {
            CbxTerminalCard(
                title = "Calculated Sensitivities & Greeks",
                badgeText = "EXACT CONVERGENCE"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CbxMetricTile("Dirty Price", "£%.2f".format(uiState.calcDirtyPrice), valueColor = CbxEdinburghGold, modifier = Modifier.weight(1f))
                    CbxMetricTile("Accrued Interest", "£%.2f".format(uiState.calcAccrued), valueColor = CbxTextSecondary, modifier = Modifier.weight(1f))
                    CbxMetricTile("Modified Duration", "%.2f".format(uiState.calcModDuration), valueColor = CbxCaledonianBlue, modifier = Modifier.weight(1f))
                    CbxMetricTile("Convexity", "%.2f".format(uiState.calcConvexity), modifier = Modifier.weight(1f))
                    CbxMetricTile("DV01 / £100k", "£%.2f".format(uiState.calcDv01), valueColor = CbxProfitGreen, modifier = Modifier.weight(1f))
                }
            }
        }

        // Taylor Series Duration + Convexity Price Shock Matrix
        item {
            CbxTerminalCard(
                title = "Rate Shock & Price Impact Matrix",
                badgeText = "TAYLOR EXPANSION (DUR + CONV)"
            ) {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CbxNavyElevated)
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("RATE SHOCK", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                    Text("DURATION ONLY", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                    Text("DUR + CONVEXITY", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                    Text("ESTIMATED PRICE", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                }

                val shockBpsList = listOf(-100, -50, -25, +25, +50, +100)
                shockBpsList.forEach { bps ->
                    val dy = bps / 10000.0
                    val durEffect = -uiState.calcModDuration * dy * 100.0
                    val convEffect = 0.5 * uiState.calcConvexity * (dy * dy) * 100.0
                    val totalPct = durEffect + convEffect
                    val newPrice = uiState.calcDirtyPrice * (1.0 + totalPct / 100.0)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 6.dp, vertical = 3.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${if (bps >= 0) "+$bps" else "$bps"} bps",
                            color = if (bps < 0) CbxProfitGreen else CbxLossRed,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.weight(1.2f)
                        )
                        Text(
                            text = "%.2f%%".format(durEffect),
                            color = CbxTextSecondary,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.weight(1.2f)
                        )
                        Text(
                            text = "%.2f%%".format(totalPct),
                            color = if (totalPct >= 0) CbxProfitGreen else CbxLossRed,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.weight(1.2f)
                        )
                        Text(
                            text = "£%.2f".format(newPrice),
                            color = CbxEdinburghGold,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.weight(1.2f)
                        )
                    }
                    Divider(color = CbxNavyBorderSubtle, thickness = 1.dp)
                }
            }
        }
    }
}
