package com.example.model

enum class RfqQuoteStatus(val label: String) {
    PENDING("Awaiting Quote"),
    STREAMING("Firm Streaming"),
    ACCEPTED("Executed"),
    DECLINED("Declined"),
    EXPIRED("Expired")
}

data class DealerQuote(
    val dealerId: String,
    val dealerName: String,
    val dealerDesk: String,
    val bidPrice: Double,
    val askPrice: Double,
    val bidYield: Double,
    val askYield: Double,
    val notionalOffered: Long,
    val validSecondsRemaining: Int,
    val status: RfqQuoteStatus = RfqQuoteStatus.STREAMING
)

data class RfqRequest(
    val rfqId: String,
    val instrumentId: String,
    val isin: String,
    val instrumentName: String,
    val side: OrderSide,
    val notionalGbp: Long,
    val targetSettlement: String = "T+1 (London/CREST)",
    val createdAt: String,
    val quotes: List<DealerQuote>,
    val activeState: String = "IN_FLIGHT"
)
