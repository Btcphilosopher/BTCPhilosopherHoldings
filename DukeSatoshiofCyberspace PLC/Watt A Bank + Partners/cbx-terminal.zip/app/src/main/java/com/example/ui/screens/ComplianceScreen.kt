package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.CbxUiState
import com.example.ui.CbxViewModel
import com.example.ui.components.CbxMetricTile
import com.example.ui.components.CbxSimulatedBanner
import com.example.ui.components.CbxTerminalCard
import com.example.ui.theme.*

@Composable
fun ComplianceScreen(
    uiState: CbxUiState,
    viewModel: CbxViewModel,
    modifier: Modifier = Modifier
) {
    val auditLogs = uiState.auditLogs

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            CbxSimulatedBanner()
        }

        // Regulatory Perimeter Statement
        item {
            CbxTerminalCard(
                title = "UK Regulatory Perimeter & Venue Governance",
                badgeText = "REGULATORY NOTICE"
            ) {
                Text(
                    text = "Caledonian Bond Exchange (CBX) operates this release strictly as an institutional financial technology, valuation, and simulated matching environment. It is not currently authorised as a UK Multilateral Trading Facility (MTF) or Recognised Investment Exchange. Real-world execution requires authorized regulatory permissions under the Financial Services and Markets Act 2000 (FSMA).",
                    color = CbxTextPrimary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CbxMetricTile("Perimeter Mode", "SIMULATED SANDBOX", "Tech Platform", valueColor = CbxEdinburghGold, modifier = Modifier.weight(1.5f))
                    CbxMetricTile("Pre-Trade Risk", "ENFORCED OK", "Max £10M Notional", valueColor = CbxProfitGreen, modifier = Modifier.weight(1.2f))
                    CbxMetricTile("Clock Precision", "RTS 25 Microsec", "UTC / BST Sync", valueColor = CbxCaledonianBlue, modifier = Modifier.weight(1.3f))
                }
            }
        }

        // Pre-Trade Risk Controls
        item {
            CbxTerminalCard(
                title = "Automated Pre-Trade Risk Gates",
                badgeText = "GATEWAY STATUS"
            ) {
                val gates = listOf(
                    Triple("Single Order Maximum Nominal Limit", "Max £10,000,000 GBP per ticket", "ACTIVE - PASSED"),
                    Triple("Price Deviation / Fat-Finger Collar", "Max +/- 3.50% from CBX Reference Mid", "ACTIVE - PASSED"),
                    Triple("Counterparty Credit Limit Headroom", "Min 15% headroom required on bilateral credit lines", "ACTIVE - PASSED"),
                    Triple("Market Abuse Surveillance (MAR)", "Real-time spoofing, wash-sale, and layering heuristic filter", "ACTIVE - CLEAN")
                )

                gates.forEach { (name, rule, status) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(2f)) {
                            Text(name, color = CbxTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Text(rule, color = CbxTextSecondary, fontSize = 9.sp)
                        }
                        Box(
                            modifier = Modifier
                                .background(CbxGreenBackground, RoundedCornerShape(2.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(status, color = CbxProfitGreen, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                    Divider(color = CbxNavyBorderSubtle, thickness = 1.dp)
                }
            }
        }

        // Immutable Audit Trail (MiFIR RTS 25)
        item {
            CbxTerminalCard(
                title = "MiFIR RTS 25 Transaction Audit Log",
                badgeText = "${auditLogs.size} ENTRIES"
            ) {
                auditLogs.forEach { log ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1.2f)) {
                            Text(log.logId, color = CbxEdinburghGold, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Text(log.timestamp, color = CbxTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            Text(log.category, color = CbxCaledonianBlue, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        }
                        Column(modifier = Modifier.weight(2.5f)) {
                            Text(log.details, color = CbxTextPrimary, fontSize = 10.sp, lineHeight = 13.sp)
                            Text("Actor: ${log.actor}", color = CbxTextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        }
                        Box(
                            modifier = Modifier
                                .background(CbxNavyElevated, RoundedCornerShape(2.dp))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text("AUDIT OK", color = CbxProfitGreen, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                    Divider(color = CbxNavyBorderSubtle, thickness = 1.dp)
                }
            }
        }
    }
}
