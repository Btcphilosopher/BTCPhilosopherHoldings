package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.VenueMode
import com.example.ui.CbxWorkspace
import com.example.ui.theme.*

@Composable
fun CbxTopBar(
    currentWorkspace: CbxWorkspace,
    onWorkspaceSelected: (CbxWorkspace) -> Unit,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    edinburghTime: String,
    venueMode: VenueMode,
    modifier: Modifier = Modifier
) {
    var showWorkspaceMenu by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(CbxNavyDark)
            .border(width = 1.dp, color = CbxNavyBorder)
    ) {
        // Institutional Header Ribbon
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand Logo & Venue
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .background(CbxEdinburghGold, shape = RoundedCornerShape(2.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "CBX",
                        color = CbxNavyDark,
                        fontWeight = FontWeight.Black,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Column {
                    Text(
                        text = "CALEDONIAN BOND EXCHANGE",
                        color = CbxTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "Edinburgh Institutional Fixed-Income Terminal",
                        color = CbxTextSecondary,
                        fontSize = 9.sp
                    )
                }

                // Venue Mode Tag
                Box(
                    modifier = Modifier
                        .background(CbxNavyElevated, RoundedCornerShape(2.dp))
                        .border(1.dp, CbxSimulatedBadge.copy(alpha = 0.5f), RoundedCornerShape(2.dp))
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = venueMode.badge,
                        color = CbxSimulatedBadge,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Right status: Time and System Node
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .background(CbxNavyElevated, RoundedCornerShape(2.dp))
                        .border(1.dp, CbxNavyBorder, RoundedCornerShape(2.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = edinburghTime,
                        color = CbxEdinburghGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Box(
                    modifier = Modifier
                        .background(CbxGreenBackground, RoundedCornerShape(2.dp))
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "NODE-01 OK",
                        color = CbxProfitGreen,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Action Ribbon: Workspace Selector & Command Search
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CbxNavySurface)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Current Workspace Button
            Box {
                Button(
                    onClick = { showWorkspaceMenu = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CbxNavyElevated,
                        contentColor = CbxEdinburghGold
                    ),
                    shape = RoundedCornerShape(4.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("workspace_menu_button")
                ) {
                    Text(
                        text = "[ ${currentWorkspace.id} ]  ${currentWorkspace.title}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.ArrowDropDown,
                        contentDescription = "Select Workspace",
                        modifier = Modifier.size(16.dp)
                    )
                }

                DropdownMenu(
                    expanded = showWorkspaceMenu,
                    onDismissRequest = { showWorkspaceMenu = false },
                    modifier = Modifier
                        .background(CbxNavyElevated)
                        .border(1.dp, CbxNavyBorder)
                ) {
                    CbxWorkspace.values().forEach { ws ->
                        DropdownMenuItem(
                            text = {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${ws.id} - ${ws.title}",
                                        color = if (ws == currentWorkspace) CbxEdinburghGold else CbxTextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = if (ws == currentWorkspace) FontWeight.Bold else FontWeight.Normal,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = ws.category,
                                        color = CbxTextMuted,
                                        fontSize = 10.sp
                                    )
                                }
                            },
                            onClick = {
                                onWorkspaceSelected(ws)
                                showWorkspaceMenu = false
                            },
                            modifier = Modifier.testTag("select_workspace_${ws.id.lowercase()}")
                        )
                    }
                }
            }

            // Quick Command Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = {
                    Text(
                        text = "Command / ISIN / Issuer search (e.g. UKT, LOTHYD, RFQ)...",
                        color = CbxTextMuted,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = CbxTextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(
                            onClick = { onSearchQueryChange("") },
                            modifier = Modifier.size(16.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Clear",
                                tint = CbxTextSecondary
                            )
                        }
                    }
                },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = CbxNavyDark,
                    unfocusedContainerColor = CbxNavyDark,
                    focusedTextColor = CbxTextPrimary,
                    unfocusedTextColor = CbxTextPrimary,
                    focusedBorderColor = CbxEdinburghGold,
                    unfocusedBorderColor = CbxNavyBorder
                ),
                textStyle = LocalTextStyle.current.copy(
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                ),
                modifier = Modifier
                    .weight(1f)
                    .height(38.dp)
                    .testTag("command_search_input")
            )
        }
    }
}
