package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SettlementStatus
import com.example.ui.CbxUiState
import com.example.ui.CbxViewModel
import com.example.ui.components.CbxMetricTile
import com.example.ui.components.CbxSimulatedBanner
import com.example.ui.components.CbxTerminalCard
import com.example.ui.theme.*

@Composable
fun SettlementScreen(
    uiState: CbxUiState,
    viewModel: CbxViewModel,
    modifier: Modifier = Modifier
) {
    val items = uiState.settlementInstructions
    val settledCount = items.count { it.status == SettlementStatus.SETTLED }
    val pendingCount = items.count { it.status == SettlementStatus.MATCHED || it.status == SettlementStatus.PENDING_MATCH }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            CbxSimulatedBanner()
        }

        // Settlement Header Ribbon
        item {
            CbxTerminalCard(
                title = "Post-Trade Clearing & Settlement Operations",
                badgeText = "EUROCLEAR UK & CREST"
            ) {
                Text(
                    text = "Automated Delivery-Versus-Payment (DVP) instructions, CREST reference tracking, and settlement exception reconciliation.",
                    color = CbxTextSecondary,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CbxMetricTile("Total Instructions", "${items.size}", modifier = Modifier.weight(1f))
                    CbxMetricTile("Matched / Pending", "$pendingCount", valueColor = CbxWarningAmber, modifier = Modifier.weight(1.2f))
                    CbxMetricTile("Settled (DVP OK)", "$settledCount", valueColor = CbxProfitGreen, modifier = Modifier.weight(1.2f))
                    CbxMetricTile("Cycle Standard", "T+1 (London)", modifier = Modifier.weight(1f))
                }
            }
        }

        // Instructions List
        item {
            CbxTerminalCard(
                title = "Settlement Instructions Queue",
                badgeText = "DVP PIPELINE"
            ) {
                items.forEach { inst ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CbxNavyElevated, RoundedCornerShape(2.dp))
                            .border(1.dp, CbxNavyBorder, RoundedCornerShape(2.dp))
                            .padding(8.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${inst.instructionId} • CREST: ${inst.crestReference}",
                                        color = CbxEdinburghGold,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = "${inst.instrumentName} (${inst.isin})",
                                        color = CbxTextPrimary,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (inst.status == SettlementStatus.SETTLED) CbxGreenBackground else CbxAmberBackground,
                                            RoundedCornerShape(2.dp)
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = inst.status.label,
                                        color = if (inst.status == SettlementStatus.SETTLED) CbxProfitGreen else CbxWarningAmber,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Buyer: ${inst.buyer} → Seller: ${inst.seller}",
                                    color = CbxTextSecondary,
                                    fontSize = 9.sp
                                )
                                Text(
                                    text = "Consideration: £%,.0f".format(inst.settlementAmountGbp),
                                    color = CbxTextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            if (inst.status != SettlementStatus.SETTLED) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Button(
                                    onClick = { viewModel.settleInstruction(inst.instructionId) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = CbxProfitGreen,
                                        contentColor = CbxNavyDark
                                    ),
                                    shape = RoundedCornerShape(2.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(26.dp).testTag("settle_button_${inst.instructionId.lowercase()}")
                                ) {
                                    Text("CONFIRM DVP SETTLEMENT (CREST) →", fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }
            }
        }
    }
}
