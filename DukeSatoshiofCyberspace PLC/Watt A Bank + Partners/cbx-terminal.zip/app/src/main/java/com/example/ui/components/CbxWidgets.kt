package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun CbxMetricTile(
    label: String,
    value: String,
    subValue: String? = null,
    valueColor: Color = CbxTextPrimary,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(CbxNavySurface, RoundedCornerShape(2.dp))
            .border(1.dp, CbxNavyBorder, RoundedCornerShape(2.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = label.uppercase(),
                color = CbxTextMuted,
                fontSize = 9.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 0.5.sp
            )
            Text(
                text = value,
                color = valueColor,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            if (subValue != null) {
                Text(
                    text = subValue,
                    color = CbxTextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun CbxTerminalCard(
    title: String,
    badgeText: String? = null,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(CbxNavySurface, RoundedCornerShape(4.dp))
            .border(1.dp, CbxNavyBorder, RoundedCornerShape(4.dp))
    ) {
        // Card Header Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CbxNavyElevated)
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title.uppercase(),
                color = CbxEdinburghGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 0.5.sp
            )
            if (badgeText != null) {
                Box(
                    modifier = Modifier
                        .background(CbxNavyDark, RoundedCornerShape(2.dp))
                        .border(1.dp, CbxNavyBorder, RoundedCornerShape(2.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = badgeText,
                        color = CbxCaledonianBlue,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Body
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            content = content
        )
    }
}

@Composable
fun CbxSimulatedBanner() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CbxNavyElevated)
            .border(1.dp, CbxSimulatedBadge.copy(alpha = 0.3f))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "EDINBURGH LOCAL SIMULATION MODE",
            color = CbxSimulatedBadge,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = "SYNTHETIC STERLING BENCHMARKS • NO CAPITAL AT RISK",
            color = CbxTextMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}
