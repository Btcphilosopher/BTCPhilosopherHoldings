package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.CbxUiState
import com.example.ui.CbxViewModel
import com.example.ui.components.CbxMetricTile
import com.example.ui.components.CbxSimulatedBanner
import com.example.ui.components.CbxTerminalCard
import com.example.ui.theme.*

@Composable
fun PortfolioRiskScreen(
    uiState: CbxUiState,
    viewModel: CbxViewModel,
    modifier: Modifier = Modifier
) {
    val port = uiState.portfolio

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            CbxSimulatedBanner()
        }

        // Portfolio Summary Ribbon
        item {
            CbxTerminalCard(
                title = port.portfolioName,
                badgeText = "AUM £%,.0fM".format(port.totalAumGbp / 1_000_000.0)
            ) {
                Text(
                    text = port.mandate,
                    color = CbxTextSecondary,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CbxMetricTile("Total AUM", "£%,.1fM".format(port.totalAumGbp / 1_000_000.0), valueColor = CbxEdinburghGold, modifier = Modifier.weight(1.2f))
                    CbxMetricTile("Portfolio DV01", "£%,.0f".format(port.totalDv01Gbp), "Risk per 1 bp", valueColor = CbxCaledonianBlue, modifier = Modifier.weight(1.2f))
                    CbxMetricTile("Weighted Yield", "%.2f%%".format(port.weightedYield), valueColor = CbxProfitGreen, modifier = Modifier.weight(1f))
                    CbxMetricTile("Weighted Duration", "%.2f yrs".format(port.weightedDuration), modifier = Modifier.weight(1f))
                }
            }
        }

        // Stress Testing Scenarios
        item {
            CbxTerminalCard(
                title = "Macro & Curve Stress Scenarios",
                badgeText = "INSTITUTIONAL RISK"
            ) {
                uiState.stressTestResults.forEach { test ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CbxNavyElevated, RoundedCornerShape(2.dp))
                            .border(1.dp, CbxNavyBorder, RoundedCornerShape(2.dp))
                            .padding(8.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = test.scenarioName,
                                    color = CbxTextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "${if (test.pnlImpactGbp >= 0) "+£" else "-£"}%,.0f (%.2f%%)".format(
                                        kotlin.math.abs(test.pnlImpactGbp),
                                        test.percentImpact
                                    ),
                                    color = if (test.pnlImpactGbp >= 0) CbxProfitGreen else CbxLossRed,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Text(
                                text = test.scenarioDescription,
                                color = CbxTextSecondary,
                                fontSize = 10.sp,
                                lineHeight = 14.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Post-Shock Portfolio Value: £%,.1fM".format(test.newPortfolioValueGbp / 1_000_000.0),
                                color = CbxTextMuted,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }
            }
        }

        // Detailed Holdings Table
        item {
            CbxTerminalCard(
                title = "Portfolio Holdings & Risk Contributions",
                badgeText = "${port.holdings.size} POSITIONS"
            ) {
                // Table Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CbxNavyElevated)
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("INSTRUMENT", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.8f))
                    Text("NOMINAL", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text("MKT VALUE", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                    Text("UNREAL PNL", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                    Text("DV01", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                    Text("WEIGHT", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                }

                port.holdings.forEach { h ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.8f)) {
                            Text(h.instrumentName, color = CbxTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                            Text(h.isin, color = CbxTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        }
                        Text("£%,dM".format(h.nominalGbp / 1_000_000L), color = CbxTextPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text("£%,.1fM".format(h.marketValueGbp / 1_000_000.0), color = CbxEdinburghGold, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                        Text(
                            text = "${if (h.unrealizedPnlGbp >= 0) "+£" else "-£"}%,.0f".format(kotlin.math.abs(h.unrealizedPnlGbp)),
                            color = if (h.unrealizedPnlGbp >= 0) CbxProfitGreen else CbxLossRed,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.weight(1.1f)
                        )
                        Text("£%,.0f".format(h.dv01Gbp), color = CbxCaledonianBlue, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                        Text("%.1f%%".format(h.portfolioWeightPct), color = CbxTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                    }
                    Divider(color = CbxNavyBorderSubtle, thickness = 1.dp)
                }
            }
        }
    }
}
