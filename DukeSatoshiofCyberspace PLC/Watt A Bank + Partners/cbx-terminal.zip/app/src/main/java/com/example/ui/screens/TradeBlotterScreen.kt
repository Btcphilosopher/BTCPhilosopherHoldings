package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.OrderSide
import com.example.ui.CbxUiState
import com.example.ui.CbxViewModel
import com.example.ui.components.CbxMetricTile
import com.example.ui.components.CbxSimulatedBanner
import com.example.ui.components.CbxTerminalCard
import com.example.ui.theme.*

@Composable
fun TradeBlotterScreen(
    uiState: CbxUiState,
    viewModel: CbxViewModel,
    modifier: Modifier = Modifier
) {
    val trades = uiState.recentTrades
    val totalVolume = trades.sumOf { it.quantity }
    val totalCashConsideration = trades.sumOf { (it.quantity / 100.0) * it.price }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            CbxSimulatedBanner()
        }

        // Summary Ribbon
        item {
            CbxTerminalCard(
                title = "Institutional Execution Blotter",
                badgeText = "SESSION 2026-10-12"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CbxMetricTile(
                        label = "Total Trades",
                        value = "${trades.size}",
                        valueColor = CbxEdinburghGold,
                        modifier = Modifier.weight(1f)
                    )
                    CbxMetricTile(
                        label = "Turnover (Nominal)",
                        value = "£%,d".format(totalVolume),
                        valueColor = CbxTextPrimary,
                        modifier = Modifier.weight(1.5f)
                    )
                    CbxMetricTile(
                        label = "Gross Consideration",
                        value = "£%,.0f".format(totalCashConsideration),
                        valueColor = CbxCaledonianBlue,
                        modifier = Modifier.weight(1.5f)
                    )
                }
            }
        }

        // Trades Table
        item {
            CbxTerminalCard(
                title = "Trade Records & Counterparty Confirmations",
                badgeText = "MiFIR RTS 25 AUDIT"
            ) {
                if (trades.isEmpty()) {
                    Text(
                        text = "No trades recorded in current blotter. Execute an order in the Order Book or RFQ Desk to generate executed trades.",
                        color = CbxTextMuted,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                } else {
                    // Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CbxNavyElevated)
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("TRADE ID / TIME", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                        Text("INSTRUMENT", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                        Text("SIDE", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.6f))
                        Text("PRICE", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                        Text("NOMINAL", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                        Text("COUNTERPARTY", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                    }

                    trades.forEach { trade ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1.2f)) {
                                Text(trade.tradeId, color = CbxEdinburghGold, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text(trade.timestamp, color = CbxTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            }
                            Column(modifier = Modifier.weight(1.5f)) {
                                Text(trade.instrumentName, color = CbxTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                Text(trade.isin, color = CbxTextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            }
                            Text(
                                text = trade.side.name,
                                color = if (trade.side == OrderSide.BUY) CbxProfitGreen else CbxLossRed,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.weight(0.6f)
                            )
                            Column(modifier = Modifier.weight(0.9f)) {
                                Text("£%.2f".format(trade.price), color = CbxTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text("%.2f%%".format(trade.yield), color = CbxEdinburghGold, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            }
                            Text("£%,d".format(trade.quantity), color = CbxTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                            Column(modifier = Modifier.weight(1.5f)) {
                                Text("B: ${trade.buyer}", color = CbxTextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                Text("S: ${trade.seller}", color = CbxTextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                        Divider(color = CbxNavyBorderSubtle, thickness = 1.dp)
                    }
                }
            }
        }
    }
}
