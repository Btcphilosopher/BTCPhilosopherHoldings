package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.OrderSide
import com.example.model.RfqQuoteStatus
import com.example.ui.CbxUiState
import com.example.ui.CbxViewModel
import com.example.ui.components.CbxMetricTile
import com.example.ui.components.CbxSimulatedBanner
import com.example.ui.components.CbxTerminalCard
import com.example.ui.theme.*

@Composable
fun RfqDeskScreen(
    uiState: CbxUiState,
    viewModel: CbxViewModel,
    modifier: Modifier = Modifier
) {
    val bond = uiState.selectedInstrument

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            CbxSimulatedBanner()
        }

        // RFQ Request Parameters Card
        item {
            CbxTerminalCard(
                title = "Institutional Request-For-Quote (RFQ)",
                badgeText = "BILATERAL FACILITY"
            ) {
                Text(
                    text = "Request competitive two-way prices from verified Edinburgh liquidity providers for block sizes and less liquid sterling debt.",
                    color = CbxTextSecondary,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CbxMetricTile("Selected Instrument", bond.ticker, bond.isin, valueColor = CbxEdinburghGold, modifier = Modifier.weight(1.5f))
                    CbxMetricTile("Current Mid Price", "£%.2f".format(bond.cleanPrice), "YTM %.2f%%".format(bond.ytm), modifier = Modifier.weight(1f))
                    CbxMetricTile("Settlement", "T+1 CREST", "London DVP", modifier = Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Side Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.setRfqSide(OrderSide.BUY) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (uiState.rfqSide == OrderSide.BUY) CbxProfitGreen else CbxNavyElevated,
                            contentColor = if (uiState.rfqSide == OrderSide.BUY) CbxNavyDark else CbxTextSecondary
                        ),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.weight(1f).testTag("rfq_side_buy")
                    ) {
                        Text("I WANT TO BUY (BID)", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                    Button(
                        onClick = { viewModel.setRfqSide(OrderSide.SELL) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (uiState.rfqSide == OrderSide.SELL) CbxLossRed else CbxNavyElevated,
                            contentColor = if (uiState.rfqSide == OrderSide.SELL) CbxNavyDark else CbxTextSecondary
                        ),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.weight(1f).testTag("rfq_side_sell")
                    ) {
                        Text("I WANT TO SELL (OFFER)", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Notional Size Input
                OutlinedTextField(
                    value = uiState.rfqNotionalText,
                    onValueChange = { viewModel.setRfqNotionalText(it) },
                    label = { Text("Requested Notional Amount (GBP)", fontSize = 10.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = CbxTextPrimary,
                        unfocusedTextColor = CbxTextPrimary,
                        focusedBorderColor = CbxEdinburghGold,
                        unfocusedBorderColor = CbxNavyBorder
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("rfq_notional_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = { viewModel.requestRfq() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CbxEdinburghGold,
                        contentColor = CbxNavyDark
                    ),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.fillMaxWidth().height(40.dp).testTag("submit_rfq_request")
                ) {
                    Text(
                        text = "SOLICIT DEALER QUOTES (3 PARTICIPANTS) →",
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Dealer Responses Stream
        item {
            val rfq = uiState.activeRfq
            CbxTerminalCard(
                title = "Streaming Dealer Responses",
                badgeText = if (rfq != null) rfq.activeState else "AWAITING SOLICITATION"
            ) {
                if (rfq == null) {
                    Text(
                        text = "No active RFQ in flight. Click 'Solicit Dealer Quotes' above to stream firm prices.",
                        color = CbxTextMuted,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                } else {
                    Text(
                        text = "RFQ ID: ${rfq.rfqId} • Requested: £%,d of ${rfq.instrumentName}".format(rfq.notionalGbp),
                        color = CbxTextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    rfq.quotes.forEach { quote ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CbxNavyElevated, RoundedCornerShape(4.dp))
                                .border(1.dp, CbxNavyBorder, RoundedCornerShape(4.dp))
                                .padding(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1.5f)) {
                                    Text(
                                        text = quote.dealerName,
                                        color = CbxEdinburghGold,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = quote.dealerDesk,
                                        color = CbxTextSecondary,
                                        fontSize = 10.sp
                                    )
                                    Text(
                                        text = "Expires in: ${quote.validSecondsRemaining}s",
                                        color = CbxWarningAmber,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }

                                Column(
                                    modifier = Modifier.weight(1.2f),
                                    horizontalAlignment = Alignment.End
                                ) {
                                    val price = if (rfq.side == OrderSide.BUY) quote.askPrice else quote.bidPrice
                                    val yield = if (rfq.side == OrderSide.BUY) quote.askYield else quote.bidYield
                                    Text(
                                        text = "£%.2f".format(price),
                                        color = CbxTextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = "Yield: %.2f%%".format(yield),
                                        color = CbxCaledonianBlue,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                if (quote.status == RfqQuoteStatus.ACCEPTED) {
                                    Box(
                                        modifier = Modifier
                                            .background(CbxGreenBackground, RoundedCornerShape(2.dp))
                                            .padding(horizontal = 8.dp, vertical = 6.dp)
                                    ) {
                                        Text("EXECUTED", color = CbxProfitGreen, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                    }
                                } else if (quote.status == RfqQuoteStatus.DECLINED) {
                                    Text("DECLINED", color = CbxTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                } else {
                                    Button(
                                        onClick = { viewModel.acceptRfqQuote(quote) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = CbxProfitGreen,
                                            contentColor = CbxNavyDark
                                        ),
                                        shape = RoundedCornerShape(2.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        modifier = Modifier.testTag("accept_quote_${quote.dealerId.lowercase()}")
                                    ) {
                                        Text("ACCEPT", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                }
            }
        }
    }
}
