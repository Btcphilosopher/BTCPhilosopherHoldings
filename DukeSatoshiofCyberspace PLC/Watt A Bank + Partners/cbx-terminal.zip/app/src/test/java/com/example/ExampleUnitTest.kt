package com.example

import com.example.model.*
import com.example.quant.BondPricingEngine
import com.example.quant.OrderMatchingEngine
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testParBondPricing() {
        // A bond with coupon 5.0% and yield 5.0% must price at par (100.0)
        val dirty = BondPricingEngine.dirtyPriceFromYield(
            couponRate = 5.0,
            frequency = 2,
            maturityYears = 5.0,
            ytmPercent = 5.0,
            denomination = 100.0
        )
        // With semi-annual coupons, sum of discounted CFs equals 100.0
        assertEquals(100.0, dirty, 0.01)
    }

    @Test
    fun testNewtonRaphsonYtmSolverConvergence() {
        val originalCoupon = 4.50
        val originalYield = 4.25
        val freq = 2
        val tenor = 10.0

        val dirtyPrice = BondPricingEngine.dirtyPriceFromYield(
            couponRate = originalCoupon,
            frequency = freq,
            maturityYears = tenor,
            ytmPercent = originalYield
        )

        val solvedYield = BondPricingEngine.solveYieldToMaturity(
            targetDirtyPrice = dirtyPrice,
            couponRate = originalCoupon,
            frequency = freq,
            maturityYears = tenor
        )

        assertEquals(originalYield, solvedYield, 0.005)
    }

    @Test
    fun testDurationAndConvexityProperties() {
        val coupon = 4.50
        val yield = 4.25
        val freq = 2
        val tenor = 10.0
        val dirty = BondPricingEngine.dirtyPriceFromYield(coupon, freq, tenor, yield)

        val (macDur, modDur) = BondPricingEngine.calculateDuration(coupon, freq, tenor, yield, dirty)
        val conv = BondPricingEngine.calculateConvexity(coupon, freq, tenor, yield, dirty)

        // Modified Duration must be slightly less than Macaulay Duration
        assertTrue("ModDur must be < MacDur", modDur < macDur)
        assertTrue("ModDur must be positive", modDur > 0.0)
        assertTrue("Convexity must be positive", conv > 0.0)
    }

    @Test
    fun testOrderMatchingEnginePriceTimePriority() {
        val engine = OrderMatchingEngine("TEST-INST")
        engine.seedLiquidity(100.0)

        val dummyInstrument = BondInstrument(
            id = "TEST-INST",
            isin = "GB00TEST1234",
            ticker = "TEST 4.0 30",
            name = "Test Bond",
            issuer = "Test Issuer",
            issuerLei = "1234567890",
            bondType = BondType.GILT,
            couponRate = 4.0,
            issueDate = "2024-01-01",
            maturityDate = "2030-01-01",
            maturityYears = 5.0,
            outstandingPrincipal = 100_000_000L,
            cleanPrice = 100.0,
            dirtyPrice = 101.0,
            accruedInterest = 1.0,
            ytm = 4.0,
            bidPrice = 99.85,
            askPrice = 100.15,
            bidYield = 4.02,
            askYield = 3.98,
            giltSpreadBps = 0,
            swapSpreadBps = 0,
            macaulayDuration = 4.5,
            modifiedDuration = 4.4,
            convexity = 0.25,
            dv01Per100k = 44.0
        )

        // Submit aggressive Buy Limit Order crossing the resting ask
        val buyOrder = Order(
            orderId = "BUY-001",
            instrumentId = "TEST-INST",
            side = OrderSide.BUY,
            type = OrderType.LIMIT,
            price = 100.50, // crosses lowest ask (around 100.08)
            quantity = 300_000L,
            timestamp = "10:00:00.000",
            participant = "Aggressive Buyer"
        )

        val fills = engine.submitOrder(buyOrder, dummyInstrument)
        assertTrue("Order crossing spread must execute fills", fills.isNotEmpty())
        assertEquals(300_000L, fills.sumOf { it.quantity })
    }
}
