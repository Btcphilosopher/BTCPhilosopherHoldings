# Dependency, compatibility and licence verification

Checked on 2026-11-26. Versions are what was installed and tested in this delivery; licences were read from each
package's own metadata (`importlib.metadata` / `package.json`). Re-run these checks before every release.

## Python (backend, simulator) — Python 3.13

| Package | Tested version | Licence | Notes |
|---|---|---|---|
| fastapi | 0.165.0 | MIT | |
| starlette | 1.10.0 | BSD-3-Clause | |
| uvicorn | 0.54.0 | BSD-3-Clause | |
| sqlalchemy | 2.1.9 | MIT | 2.x API |
| psycopg (binary) | 3.3.9 | LGPL-3.0-only | Used unmodified as a library. Confirm your organisation's policy on LGPL dependencies |
| alembic | 1.20.1 | MIT | |
| pydantic / pydantic-settings | 2.14.4 / 2.16.3 | MIT | |
| pyjwt[crypto] | 2.15.1 | MIT | |
| argon2-cffi | 25.1.0 | MIT | |
| pyotp | 2.12.1 | MIT | |
| phonenumbers | 9.0.44 | Apache-2.0 | Note: Ofcom drama *mobile* numbers (07700 900xxx) are reported invalid by libphonenumber, so the synthetic data uses drama *landline* ranges (0113 496 0xxx, 0161 496 0xxx) |
| cryptography | 50.0.2 | Apache-2.0 OR BSD-3-Clause | |
| httpx | 0.29.0 | BSD-3-Clause | |
| python-multipart | 0.0.34 | Apache-2.0 | |
| anthropic (optional `[ai]`) | 2.14.0 | Apache-2.0 | `beta.messages.create` signature confirmed to accept `output_config`, `fallbacks` and `betas` in this version |
| pytest / pytest-timeout (tests) | 9.2.0 / 2.4.0 | MIT | |

## JavaScript (web) — Node.js 22

| Package | Tested version | Licence | Notes |
|---|---|---|---|
| next | 16.4.6 | MIT | Requires Node ≥ 20.9 (from the package's `engines`); peer React ^18.2 or ^19 |
| react / react-dom | 19.3.1 | MIT | |
| typescript | 5.9.3 | Apache-2.0 | TypeScript 7 (native compiler) was available; 5.x was pinned because Next.js's build-time type check uses the TypeScript JavaScript API |
| @types/react / @types/node | 19.3.3 / 22.20.7 | MIT | |

No other runtime dependencies: styles are hand-written CSS; charts are inline SVG.

## Container images

| Image | Use | Licence | Notes |
|---|---|---|---|
| postgres:16-alpine | database | PostgreSQL Licence | PostgreSQL 16 is supported until November 2028; newer majors exist (18, 19). 16 was used because it is what the delivery was tested with |
| python:3.13-slim | backend, simulator | PSF and Debian packages | |
| node:22-alpine | web | MIT and Alpine packages | |
| axllent/mailpit:v1.27 | demo SMTP capture | MIT | Default ports 1025 (SMTP) and 8025 (UI) |

## Decisions informed by current documentation

A research agent consulted official sources on 2026-11-26. Its web fetches to some vendor sites failed, so several
findings rest on search-engine extracts of official pages rather than full page reads; treat them as leads to
re-confirm.

* **Object storage:** the MinIO README (github.com/minio/minio) states the community edition is AGPLv3, distributed
  as source only, and no longer maintained, pointing to commercial editions. MinIO was therefore **not** used. The
  delivery uses an encrypted local object store behind permission-checked endpoints; an S3-compatible backend is a
  documented extension point.
* **Mailpit:** MIT licence, `axllent/mailpit` image, SMTP 1025 / UI 8025 — confirmed (github.com/axllent/mailpit,
  mailpit.axllent.org).
* **Next.js:** latest stable major 16 (16.4 released October 2026); Node.js ≥ 20.9; React 19 (nextjs.org blog and
  upgrade guide).
* **PostgreSQL:** 16 supported until 9 November 2028; 19 released 19 November 2026 (postgresql.org versioning policy).
* **Twilio:** see [telephony-adapters.md](telephony-adapters.md) for the facts used and their verification status.
* **Claude API:** model id `claude-opus-5-5`, structured outputs via `output_config.format`, server-side refusal
  fallbacks (`server-side-fallback-2026-07-01`, `fallbacks: "default"`) per the bundled Claude API reference
  (cached 2026-11-03); call shape confirmed against the installed SDK's signatures, not against the live API.

## Not done

No automated licence scan (e.g. SBOM generation) or vulnerability scan was run. Add both to CI before release.
