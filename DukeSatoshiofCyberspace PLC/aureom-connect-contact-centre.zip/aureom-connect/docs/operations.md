# Operations

## Configuration

All settings are environment variables with the prefix `AUREOM_` (see `backend/aureom_connect/config.py` and
`.env.example`). Key ones:

| Variable | Purpose |
|---|---|
| `AUREOM_ENVIRONMENT` | `development` \| `test` \| `production` (production refuses development secrets and demo mode) |
| `AUREOM_DATABASE_URL` | SQLAlchemy URL (`postgresql+psycopg://…`) |
| `AUREOM_JWT_SECRET`, `AUREOM_MASTER_KEY` | token signing key; Fernet key encrypting TOTP secrets, provider secrets and stored objects |
| `AUREOM_TELEPHONY_PROVIDER` | `simulated` \| `twilio` (partial) \| `none` |
| `AUREOM_SIMULATOR_URL` / `AUREOM_SIMULATOR_PUBLIC_URL` | simulator for the API / for browsers |
| `AUREOM_SMTP_HOST`, `AUREOM_SMTP_PORT`, `AUREOM_SMTP_FROM` | outbound e-mail (unset → messages stored as `captured_not_sent`) |
| `AUREOM_AI_PROVIDER` | `disabled` \| `heuristic` \| `anthropic` (+ `AUREOM_ANTHROPIC_API_KEY`, `AUREOM_ANTHROPIC_MODEL`) |
| `AUREOM_OIDC_*` | organisational sign-in |
| `AUREOM_STORAGE_DIR` | encrypted object store location |
| `AUREOM_CORS_ORIGINS` | allowed browser origins |

## Processes

| Process | Command | Scale |
|---|---|---|
| API | `uvicorn aureom_connect.main:app` | stateless; several replicas possible (see rate-limit caveat in security.md) |
| Worker | `python -m aureom_connect.cli worker` | one or more (jobs use `SKIP LOCKED`, routing uses advisory locks) |
| Bootstrap | `python -m aureom_connect.cli bootstrap` | run once per deploy: migrations, then demo seed only if empty |
| Simulator | `python -m aureom_sim` | demo/test only |
| Web | `node server.js` (Next.js standalone) | stateless |

## Database migrations

```bash
python -m aureom_connect.cli migrate          # alembic upgrade head
alembic check                                  # verifies models and migrations agree
alembic downgrade base                         # full rollback (tested)
```

## Backups and restoration

```bash
scripts/backup.sh backups/2026-11-26           # pg_dump (custom format) + encrypted object store + checksums
scripts/verify_restore.sh backups/2026-11-26   # restore into a scratch DB and prove it
scripts/restore.sh backups/2026-11-26 --into-live   # planned recovery only (stops api/worker)
```

`verify_restore.sh` checks the SHA-256 manifest, restores into `aureom_restore_check`, compares row counts for 14
key tables, verifies the audit hash chain and decrypts every stored object against its recorded SHA-256. Keep
`AUREOM_MASTER_KEY` in a separate secrets store: objects cannot be read without it. Schedule backups, copy them
off-site and rehearse restoration regularly (the procedure above was executed during delivery — see
test-results.md).

## Retention

The worker applies recording retention every minute: media past `retention_until` is deleted (unless under legal
hold), the stored object is tombstoned and an audit entry written. Retention periods come from the recording policy
and are illustrative in the seed.

## Health and monitoring

* `GET /healthz` (API liveness; used by the container health check).
* `GET /v1/providers/status` — provider connection status, capabilities and recent events with ingestion lag.
* Live operations page — routing failures, missed offers, overdue after-call work, reconciliation flags.
* Reports → data quality — provider events by processing status, ingestion lag p50/p95, interactions needing
  reconciliation.

## Production checklist (not done in this delivery)

TLS termination and HSTS; backend-for-frontend with HttpOnly cookies and CSP; secrets manager; real OIDC IdP; a
real telephony provider with a complete adapter and media integration, tested end to end; distributed rate limiting;
HA PostgreSQL with PITR; centralised logs and alerting; dependency and container scanning; penetration test;
accessibility audit; legal and regulatory review (compliance-research.md).
