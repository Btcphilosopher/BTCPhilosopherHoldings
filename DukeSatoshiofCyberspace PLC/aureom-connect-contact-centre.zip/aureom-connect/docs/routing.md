# Routing

## Baseline algorithm (transparent by design)

1. **Work selection.** Interactions in `queued` with no pending offer, ordered by
   queue routing priority (desc) → interaction routing priority (desc) → `routable_since` (oldest first).
2. **Eligibility.** For each interaction every agent is evaluated and each exclusion reason recorded:
   * state `available` (voice) or `available`/`on_interaction` with spare chat/e-mail capacity;
   * application connected (WebSocket heartbeats, 30 s grace);
   * provider-confirmed telephony registration (voice only) — *a connected browser is not enough*;
   * no pending reconciliation;
   * member of the queue; all required skills; language match;
   * has not already declined or missed this interaction.
3. **Agent selection.** Longest idle (`available_since`) among eligible agents.
4. **Offer.** Expires after the queue's `offer_timeout_seconds` (20 s). Agent state → `call_offered`.
5. **Record.** A `routing_decision` stores candidates and reasons; supervisors see it via *Why?* on Live operations.

## Priority versus urgency

`routing_priority` is an operational ordering set on queues. `urgency_flag` (e.g. a safeguarding concern raised in
the IVR or by an agent) is a **label** shown prominently but never changes routing automatically. Any change in
priority for clinical, emergency or legal reasons must be a deliberate, documented configuration decision.

## Business hours, holidays and the IVR

* `business_hours.weekly` lists open intervals per ISO weekday in the hours' timezone; `holidays` override a date
  with no intervals (closed) or reduced intervals.
* The IVR (`ivr_menus.definition`) maps DTMF digits to `queue`, `menu`, `voicemail` or `callback`, optionally setting a
  language (Pennine option 4 → Welsh-speaking agents). Out of hours, the menu's `closed_action` applies.
* The demo seeds two calendars: *Standard UK contact hours* (with Christmas/New Year holidays) and a clearly
  labelled *Demo: extended hours (24×7)* used by the queues so the demonstration works at any time.
  `python -m aureom_connect.cli seed --standard-hours` uses the realistic calendar.

## Overflow, voicemail, callbacks

* Overflow: after `overflow_after_seconds`, the worker closes the queue entry (`exit_reason=overflow`) and enqueues
  into `overflow_queue_id`. The wait clock (`routable_since`) is preserved — the caller keeps their place.
* Voicemail: the interaction leaves the queue as `voicemail` and a follow-up task is created (no audio is captured
  by the simulator).
* Callback from the IVR: the caller's number is used with confirmation method `ani_confirmed_in_ivr`; the promise is a
  target window, never an exact time.

## Missed and rejected offers

* Rejected: the interaction goes back to the queue with its original wait; the agent returns to `available` and is
  excluded for that interaction.
* Missed (expired): the agent becomes `unavailable` (reason `missed_offer`) so work is not offered to an absent
  person; the interaction is re-offered immediately to the next eligible agent.

## Ownership

Acceptance uses a guarded update; only one agent can own an interaction. Warm transfer moves ownership only when
the provider confirms `transfer.completed`.
