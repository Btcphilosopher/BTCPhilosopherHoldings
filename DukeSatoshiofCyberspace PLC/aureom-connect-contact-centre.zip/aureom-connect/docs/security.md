# Security and resilience

## Sign-in and MFA

| Path | Use | MFA evidence | Status |
|---|---|---|---|
| OIDC authorization code + PKCE (`/v1/auth/oidc/start`, `/callback`) | Organisational sign-in via the customer's IdP (Entra ID, Okta, Keycloak…) | ID token `amr` contains one of `AUREOM_OIDC_MFA_AMR_VALUES` (default `mfa, otp, hwk, swk`) | Externally integrated: ID-token validation (signature, issuer, audience, expiry, nonce, `amr`) is unit-tested with locally generated RSA keys; not run against a live IdP |
| Password + TOTP (`/v1/auth/login`) | Demonstration and break-glass | RFC 6238 TOTP (secrets encrypted at rest) | Implemented |

* Roles listed in the organisation's `mfa_required_roles` (default: admin, compliance officer) cannot sign in without
  MFA. Sensitive permissions (`admin.*`, `provider.manage`, `recording.delete`, `rules.manage`, `audit.read`, legal
  hold) are refused unless the *session* satisfied MFA.
* Access tokens: HS256, 30 minutes. Refresh tokens: random, stored hashed, rotated on every use; re-use of a rotated
  token revokes the user's whole token family.
* Passwords: Argon2id.

## Authorisation

Every endpoint checks a permission server-side and scopes queries to the caller's organisation. Agents can act only
on interactions they own (or participate in for consultations).

| Role | Highlights |
|---|---|
| agent | handle interactions, verify customers, cases/tasks, dial (eligible numbers only), approved messages, knowledge, own schedule, own QA results |
| supervisor | agent permissions + live operations, queue management, campaign management, reports, QA review, listen/coach monitoring, case overrides, recording access (per policy) |
| quality_reviewer | QA review, rubric, recording access (per policy), reports |
| workforce_manager | schedules, forecasts, shift-change decisions |
| compliance_officer | recording access/deletion/legal hold, audit, calling rules, suppression lists (MFA) |
| knowledge_editor | author/approve knowledge (four-eyes), message templates |
| admin | users and roles, configuration, providers, audit (MFA) |

## Customer data

* Telephone numbers and e-mail addresses are **matching hints**. Restricted data (balance, address, tariff) is
  returned only to the owning agent of a live interaction whose customer passed the verification policy.
* Verification answers are compared with Argon2 hashes server-side and are never stored, logged or displayed;
  verification factors themselves are never shown, even after verification. Three failures lock verification for
  the interaction.
* Records are never merged automatically; possible duplicates create a back-office review task.

## Recordings and transcripts

* Recording starts only per queue policy (purpose, jurisdiction, mode, notice, retention, access roles) and is shown
  as active only after provider confirmation.
* Media is encrypted at rest (Fernet: AES-128-CBC + HMAC-SHA256 with `AUREOM_MASTER_KEY`), stored on a private
  volume, and served only through `/v1/recordings/{id}/media?purpose=…` after checking: permission, role allowed by
  the recording's policy, permitted purpose, retention, deletion. **Every attempt, allowed or refused, is audited.**
* Retention: the worker deletes media after `retention_until` unless under legal hold, keeping a tombstone.
* Card payments: the provider's secure capture pauses the recording (pause must be confirmed); the application
  never receives card data. Logs and audit details mask card-like digit sequences regardless.

## Telephony and provider security

* Provider webhooks are verified before they are stored (HMAC-SHA256 with timestamp, 300 s tolerance; Twilio
  signature for the Twilio adapter). Invalid requests are rejected and audited.
* Provider credentials are configuration secrets; the `provider_configs` table stores secrets encrypted and the API
  never returns them.
* Browser media credentials are short-lived (10 min) and renewed; the browser registers directly with the provider.
* Caller identity is limited to owned, verified, outbound-enabled numbers.

## AI assistance safeguards

* Proposals only; no tools; cannot call any endpoint or take any action.
* Customer messages, transcripts and retrieved articles are treated as untrusted data: wrapped in labelled blocks for
  the model, scanned for instruction-like text (flagged to the agent), and never able to change permissions.
* Sentences that would commit the organisation (refunds, compensation, write-offs, contract changes) are stripped
  from drafts and flagged.
* Saving a summary or sending a message requires an explicit `reviewed: true` from the agent; messages are rendered
  server-side from approved templates only.

## Logging and audit

* A logging filter redacts phone numbers, e-mail addresses, bearer tokens, JWTs and card-like numbers; audit details
  are redacted the same way and sensitive keys (`password`, `token`, `answers`, `code`…) are replaced.
* The audit log is append-only and hash-chained (`prev_hash`, `hash`); `python -m aureom_connect.cli verify-audit`
  and **Administration → Audit history → Verify** detect modification or deletion (tested).

## Rate limiting

Sliding-window limits per token/IP (600/min) and per IP for sign-in (20/min) and web-chat. **Limitation:** the limiter
is in-process, so with several API replicas each enforces its own window. A shared store is required before horizontal
scaling (Deferred).

## Resilience

* Duplicate, delayed, missing and out-of-order provider events are handled (see architecture.md).
* Provider disconnection disables controls; reconciliation runs before consequential actions are allowed again;
  unknown dial/transfer/end outcomes are never repeated automatically.
* Browser refresh: state is server-side; the event stream resumes from its last cursor; a 30-second presence grace
  period avoids penalising a refresh.
* Backups: `scripts/backup.sh`, `scripts/restore.sh`, `scripts/verify_restore.sh` — restoration was executed and
  verified (row counts, audit chain, decryption of every object). See test-results.md.

## Known gaps before production (Deferred)

* The demo web app keeps tokens in `sessionStorage`. Production should use a backend-for-frontend with `HttpOnly`,
  `Secure`, `SameSite` cookies and a strict Content-Security-Policy.
* TLS termination, HSTS and a reverse proxy are not part of the Compose file.
* Secrets come from environment variables; use a secrets manager and rotate `AUREOM_MASTER_KEY` with re-encryption.
* Distributed rate limiting, WAF, dependency scanning in CI, penetration testing and a formal threat model.
* High availability PostgreSQL, point-in-time recovery and off-site backup copies.
* The application refuses to start with `AUREOM_ENVIRONMENT=production` while development secrets or demo mode remain.
