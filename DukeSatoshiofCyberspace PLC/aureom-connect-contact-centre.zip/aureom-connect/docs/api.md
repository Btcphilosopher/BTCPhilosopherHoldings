# API

* Interactive reference: `http://localhost:8000/docs` (Swagger UI) and `/redoc`.
* Machine-readable: [`openapi.json`](openapi.json) (118 paths, exported from the running code).
* Base path `/v1`. JSON in and out. Times are ISO 8601 with timezone (UTC from the server).

## Conventions

| Concern | Rule |
|---|---|
| Authentication | `Authorization: Bearer <access token>` (30 min). `POST /v1/auth/refresh` rotates refresh tokens; reuse of a rotated token revokes the whole family. |
| Authorisation | Server-side, per endpoint, from roles → permissions (`security/permissions.py`), scoped to the caller's organisation. Some permissions additionally require MFA in the session. |
| Idempotency | `Idempotency-Key` header **required** for accept/reject, call actions, outbound calls, callbacks, cases, tasks, messages and wrap-up. Same key + same body → stored response replayed (`Idempotent-Replayed: true`); same key + different body → `422 IDEMPOTENCY_KEY_REUSED`; concurrent duplicate → `409 IDEMPOTENCY_IN_PROGRESS`. Call controls and dials are additionally de-duplicated on the control/attempt row, so a retry can never re-send to the provider. |
| Version checks | `expected_version` in the body (interactions, cases, tasks, callbacks, campaigns, shifts, agent state). Mismatch → `409 VERSION_CONFLICT` with `current_version`. |
| Errors | `{"error": {"code", "message", "details", "request_id"}}`. Every response carries `X-Request-Id`. |
| Control outcomes | `202` with `status: requested` means *the provider accepted the request*. The call changes only when the provider confirms it; read `GET /v1/interactions/{id}` → `controls[]` (`requested` / `acknowledged` / `failed` / `unknown`). |
| Rate limits | 600 requests/min per token or IP; 20 sign-ins/min per IP → `429 RATE_LIMITED` with `retry_after_seconds`. |

### Common error codes

`UNAUTHENTICATED`, `TOKEN_EXPIRED`, `MFA_REQUIRED`, `PERMISSION_DENIED`, `NOT_FOUND`, `VALIDATION_FAILED`,
`VERSION_CONFLICT`, `OWNERSHIP_CONFLICT`, `OFFER_NOT_PENDING`, `OFFER_EXPIRED`, `INVALID_STATE_TRANSITION`,
`NOT_READY`, `STATE_NOT_REQUESTABLE`, `RECONCILIATION_REQUIRED`, `PROVIDER_UNAVAILABLE`, `UNSUPPORTED_BY_PROVIDER`,
`VERIFICATION_REQUIRED`, `OUTBOUND_NOT_PERMITTED`, `DUPLICATE_ATTEMPT`, `FOUR_EYES_REQUIRED`, `REASON_REQUIRED`,
`OUTCOME_REQUIRED`, `REVIEW_REQUIRED`, `TEMPLATE_NOT_APPROVED`, `PUBLISHED_SCHEDULE_IMMUTABLE`, `INVALID_SIGNATURE`,
`IDEMPOTENCY_KEY_REQUIRED`, `RATE_LIMITED`.

## Required endpoints → implementation

| Requested | Implemented as |
|---|---|
| `GET /v1/agent/workspace` | same – agent, readiness, provider status/capabilities, offers, active work, tasks, queues, event cursor |
| `PUT /v1/agents/me/availability` | same – `{state, reason, expected_version}`; only available/break/unavailable/offline |
| `GET /v1/queues` | same – configuration, live snapshot, SLA (internal vs contractual) |
| `GET /v1/interactions/{interaction_id}` | same – call, legs, participations, queue entries, controls + `available_controls` with reasons, candidates, verification, (masked) customer record, recordings, transcripts, timeline, summaries, messages, cases, tasks, monitoring, payments, AI proposals |
| `POST /v1/interactions/{interaction_id}/accept` | same – `{offer_id, expected_version}`; guarded single ownership |
| `POST /v1/interactions/{interaction_id}/actions` | same – `{action, params}`: `hold`, `resume`, `mute`, `unmute`, `warm_transfer_start`, `warm_transfer_complete`, `warm_transfer_cancel`, `blind_transfer`, `conference`, `end`, `start_secure_payment`, `answer`, `reject` |
| `POST /v1/outbound-calls` | same – click-to-call, callback or preview dial; eligibility evaluated and stored; `422 OUTBOUND_NOT_PERMITTED` lists failed checks. `POST /v1/outbound-calls/eligibility` previews checks |
| `POST /v1/callbacks` | same – plus `GET /v1/callbacks`, `GET /v1/callbacks/{id}`, `POST /v1/callbacks/{id}/cancel` |
| `GET /v1/customers` | same – search; `GET /v1/customers/{id}?interaction_id=` returns restricted data only in a verified context |
| `POST /v1/cases` | same – plus `PATCH /v1/cases/{id}` (reason required to reopen/override), `/escalate`, `/interactions` |
| `POST /v1/tasks` | same – plus `GET /v1/tasks`, `PATCH /v1/tasks/{id}` |
| `POST /v1/providers/{provider}/events` | same – signed webhooks only (`INVALID_SIGNATURE` otherwise) |
| `WS /v1/events` | same – see below |

Further areas: `/v1/auth/*` (password+TOTP, OIDC), `/v1/agents/*` (media credential, presence, reconcile, directory,
supervisor state), `/v1/interactions/{id}/{reject,wrap-up,customer,verification,summary,messages,transcripts/…,reconcile,skip-preview}`,
`/v1/knowledge/*`, `/v1/ai/*`, `/v1/messages`, `/v1/message-templates`, `/v1/recordings/*`, `/v1/quality/*`,
`/v1/monitoring`, `/v1/workforce/*`, `/v1/reports/*`, `/v1/ops/*`, `/v1/campaigns/*`, `/v1/calling-rules`,
`/v1/channels/*`, `/v1/admin/*`, `/v1/audit`, `/v1/providers/*`, `/v1/simulator/*` (demo mode only).

## WebSocket `/v1/events`

Application events only – media never travels here.

```text
client → {"type":"auth","token":"<access token>"}        first message, within 5 s (token is never put in the URL)
server → {"type":"ready","cursor":0,"agent":{"state":…,"reconcile_required":…}}
client → {"type":"subscribe","since":<last event id>,"interactions":["<id>",…]}
server → {"type":"event","id":1234,"event":"offer.created","audience":"agent:<id>","payload":{…},"at":"…"}
client → {"type":"ping"}                                   every ≤ 15 s; refreshes application presence
server → {"type":"pong","agent":{…},"server_time":"…"}
```

Events are signals (`offer.created`, `interaction.updated`, `agent.state`, `control.updated`, `transfer.failed`,
`provider.status`, `monitoring.started`, …). Clients re-read authoritative state over REST. After a reconnect the
client resubscribes with its last id so nothing is missed. Audiences: `org`, `user:<id>`, `agent:<id>`,
`role:supervisor`, `interaction:<id>`.

## Provider webhooks (simulator)

`POST /v1/providers/simulated/events` with headers `X-Sim-Timestamp` (Unix seconds) and
`X-Sim-Signature: v1=<hex HMAC-SHA256(secret, "<timestamp>." + raw body)>`. Requests older than 300 s are rejected.
Body: `{"events":[{"id","type","occurred_at","sequence","call_id","leg_id","request_id","data"}]}`.
