# Interface guide

Screenshots from the final end-to-end run are in [`screenshots/`](screenshots/).

## Agent workspace (three panels)

| Left: queue & tasks | Centre: customer conversation | Right: customer context & knowledge |
|---|---|---|
| Offers with countdown, **Accept (Alt+A)** / Decline (Alt+R); my active work; my queues; tasks; preview campaigns | Reference, channel, live-call timer (teal), queue, *simulated* label, customer identity and verification status; persistent call controls; chat/e-mail thread or dial panel; after-call work, summary, follow-up task, case, approved message; transcript (labelled unverified, correctable); timeline (provider time, ingestion time on hover) | Possible matches with reasons (hints only); verification form; record (restricted data withheld until verified); consent & objections; knowledge search and AI suggestions with internal/customer-visible labels |

Top bar: explicit agent state and availability buttons; **provider-confirmed** device registration shown separately
from the browser softphone's own status; provider connection; *Simulated telephony · no audio*; reconcile button
when call state needs checking.

### Call controls

| Control | Look | Meaning |
|---|---|---|
| Mute | slate outline, microphone icon, “your microphone” | provider-side mute of your leg; the call stays connected |
| Hold / Resume | indigo outline (filled when held), pause icon, “customer (provider)” | the customer hears hold audio; confirmed by a provider event |
| Transfer | teal outline, arrows, “warm · blind” | opens warm (consult → complete / conference / cancel) and blind-to-queue options |
| End call | solid red pill | asks for confirmation |

Each control shows its last outcome — **Requested**, **Confirmed**, **Failed** or **⚠ Outcome unknown** — and
disabled controls say why (unsupported by provider, provider disconnected, awaiting confirmation, reconcile first).

### Keyboard

| Keys | Action |
|---|---|
| Tab / Shift+Tab | move between controls (visible focus ring); first Tab reveals *Skip to main content* |
| Alt+A / Alt+R | accept / decline the first offer |
| Alt+M | mute / unmute |
| Alt+H | hold / resume |
| Alt+T | open transfer options |
| Alt+E | end call (with confirmation) |
| Alt+K | focus knowledge search |

Offers are announced through an assertive live region; control outcomes and messages through polite live regions.
Warnings always include a text label and icon (never colour alone).

## Supervisor console

* **Live operations** — KPI tiles, queues (open/closed with reason), waiting interactions with *Why?* routing
  explanations, agents (state, application, provider registration, readiness blockers), listen/coach monitoring
  (reason required; agent notified), routing failures, backlog.
* **Queues** — configuration incl. internal vs contractual service levels, edits with audited reason, callback backlog
  with promise text.
* **Agents** — roster; schedules with conflicts and publish; shift-change requests; forecast vs observed chart with
  80 % range, Erlang C staffing and gaps (table view included).
* **Campaigns** — preview campaigns, CSV import validation, review summary, four-eyes activation, rule sets.
* **Quality** — sampling, rubric with guidance, scoring with evidence, disputes, permissioned recording playback.
* **Reports** — presets, queue filter, synthetic-history toggle, metrics with definitions, per-agent workload.
* **Administration** — simulator and fault injection (demo only), provider capabilities and events, routing
  configuration (hours, holidays, IVR, numbers, recording policies), audit history with hash-chain verification,
  users and roles (administrator with MFA).

## Design tokens

Midnight navy `#0b1530` navigation; pale grey `#f3f5f8` workspace with white panels; teal `#0b8a7d` for active
calls; amber `#8a4b00` on `#fff6e0` for labelled warnings; red `#b42318` on `#fdecea` for failures; focus ring
`#2563eb`. Chart series use the validated palette slots blue `#257de0` and orange `#f47230`.

## Not done

No formal WCAG 2.2 audit or screen-reader testing; no dark mode; no responsive layout for phones (the agent
workspace is designed for desktop screens ≥ 1280 px, with a single-column fallback below 860 px).
