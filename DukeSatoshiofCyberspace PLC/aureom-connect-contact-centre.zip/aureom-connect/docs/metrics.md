# Metric definitions

Implemented in `backend/aureom_connect/services/reports.py` (the same definitions are returned by
`GET /v1/reports/definitions` and shown on the Reports page). Arithmetic is covered by
`tests/test_reports_security_channels.py::test_report_arithmetic` using constructed data with known answers.

## Basis

* **Time basis: provider event time** (queue entry, connection, end). Ingestion time is stored separately on every
  provider event and reported as *ingestion lag* (p50/p95) under data quality.
* **Population:** inbound voice interactions whose **first** queue entry falls in `[start, end)`.
* **One contact per interaction.** Transfers, overflow and re-queueing never create additional contacts; the contact
  is attributed to its first queue.
* **Synthetic history** (seeded, `source=synthetic_history`) can be excluded with `include_synthetic_history=false`.
* Parameters (organisation settings): short-abandon threshold 5 s; repeat-contact window 7 days; service-level
  threshold from the queue's SLA policy (Billing 20 s, Care 30 s, Technical 30 s).

| Metric | Definition | Denominator | Exclusions | Transfers |
|---|---|---|---|---|
| Offered | Population size | – | Calls ending in the IVR; outbound calls | Counted once, first queue |
| Answered | Offered interactions with a provider-confirmed agent connection | offered | – | Counted once |
| Abandoned | Caller hung up before connection after waiting ≥ short-abandon threshold | offered − short abandons | Short abandons; voicemail and callback deflections (reported separately) | – |
| Short abandoned | Abandoned within the threshold | – | – | – |
| Service level | Answered within the queue threshold ÷ (offered − short abandons) | offered − short abandons | Short abandons. Deflections count against service level | Wait = first queue entry → first connection |
| Queue wait / ASA | First queue entry → first connection (answered); → end (abandoned). ASA = mean over answered; also p90 | answered | – | Includes overflow queues |
| Talk time | Σ over participations of (end − connection) − hold | answered | – | All agents on the interaction summed |
| Hold time | Σ provider-confirmed hold intervals (held → resumed events) | answered | – | Summed across agents |
| After-call work | Σ (wrap end − wrap start) per participation | answered | Wrap-up still open | Each agent's ACW counted |
| Handling time | (talk + hold + ACW) ÷ answered interactions | answered | – | Per interaction, so a transfer is not two contacts |
| Transfers | Answered interactions with ≥ 1 completed transfer | answered | Failed/cancelled consultations | – |
| Callback completion | Callbacks requested in the window that reached `completed` ÷ those that reached a final state | requested − cancelled − still open | Cancelled; still-open reported separately | – |
| Repeat contacts | Offered interactions with an identified customer who had another interaction in the preceding 7 days | offered with identified customer | Unidentified callers | Transferred call = one contact |
| Customer feedback | Survey scores 1–5; CSAT = share of 4–5; response rate = responses ÷ answered | responses | – | – |
| Case resolution | Cases created in the window that were **explicitly** resolved with an outcome. FCR = resolved, exactly one linked interaction, never reopened | cases created | – | – |

## Interpretation rules

* **A call ending never resolves a case.** Resolution is an explicit action with a structured outcome.
* **Handling time is not a quality measure.** The Reports page and API say so next to the number; per-agent figures
  are labelled *workload, not quality* and must not be used to rank people.
* **Quality scores** come from human reviewers using the published rubric (see Quality page); they are never
  produced by AI and describe one interaction, not overall performance.
