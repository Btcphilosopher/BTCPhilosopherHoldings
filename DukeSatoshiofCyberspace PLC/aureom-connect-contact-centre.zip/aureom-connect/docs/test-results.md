# Test results

Actual results from this delivery, produced on 2026-11-26 in the build environment (Linux, Python 3.13, PostgreSQL 16, Node 22, Docker 29) from the final code. Nothing on this page is projected or estimated.

## Summary

| Check | Result |
|---|---|
| Backend + simulator test suite (pytest, real PostgreSQL) | **70/70 passed** — `70 passed in 45.56s` |
| Browser end-to-end smoke test (Playwright/Chromium against the Docker stack) | **16/16 checks passed** |
| 14-step demonstration (`scripts/demo.py` against the Docker stack) | **14/14 steps completed** |
| Backup → restore → verification (Docker stack) | **passed** — row counts match (14 tables), audit chain valid, every encrypted object decrypts to its SHA-256 |
| Alembic: `upgrade head` → `check` → `downgrade base` → `upgrade head` | **passed** — “No new upgrade operations detected” |
| Docker Compose: build all images and start from empty volumes | **passed** — all services up; API health check healthy |
| Web: `tsc --noEmit` and `next build` | **passed** — 16 routes, no type errors |
| Static analysis: pyflakes over backend + simulator | **clean** (only intentional `models/__init__` re-exports reported) |
| Chart palette validation (dataviz validator, light mode) | **all checks pass**; orange below 3:1 on white → table view provided |

Everything ran against **simulated telephony** (signalling only, no audio) and synthetic data.

## How to reproduce

```bash
# backend tests (needs a PostgreSQL superuser URL; creates and drops its own databases)
cd backend && AUREOM_TEST_ADMIN_URL=postgresql://postgres@127.0.0.1:5432/postgres pytest -v

# full stack, demo and browser test
docker compose up --build -d
python3 scripts/demo.py --api http://localhost:8000 --sim http://localhost:8090
cd web && node e2e/smoke.mjs

# backup and verified restore
scripts/backup.sh backups/test && scripts/verify_restore.sh backups/test
```

## Backend test suite

Each test gets its own database cloned from a migrated, seeded template; the real FastAPI app and the real simulator run in-process, and simulator webhooks are delivered with genuine HMAC signatures.

### Core path (inbound → queue → offer → acceptance → workspace → disposition → after-call work) — `test_core_flow.py`

| Test | Result | Time (s) |
|---|---|---|
| `test_inbound_to_wrap_up` | ✅ passed | 6.65 |

### Routing eligibility, ordering, business hours, overflow, ownership concurrency — `test_routing_and_ownership.py`

| Test | Result | Time (s) |
|---|---|---|
| `test_requires_skill_language_membership_and_registration` | ✅ passed | 0.62 |
| `test_connected_browser_is_not_enough` | ✅ passed | 0.26 |
| `test_longest_waiting_and_longest_idle` | ✅ passed | 0.83 |
| `test_urgency_flag_does_not_change_routing_priority` | ✅ passed | 0.47 |
| `test_closed_queue_goes_to_voicemail` | ✅ passed | 0.44 |
| `test_overflow_keeps_wait_clock` | ✅ passed | 0.37 |
| `test_concurrent_accept_has_single_owner` | ✅ passed | 0.58 |
| `test_accept_is_idempotent_and_expired_offers_cannot_be_accepted` | ✅ passed | 0.47 |
| `test_missed_offer_makes_agent_unavailable_and_reroutes` | ✅ passed | 0.89 |

### Agent state, provider events (signature, duplicates, order, gaps), call controls — `test_state_events_controls.py`

| Test | Result | Time (s) |
|---|---|---|
| `test_system_states_cannot_be_requested` | ✅ passed | 0.32 |
| `test_cannot_go_offline_mid_call_and_version_checked` | ✅ passed | 0.64 |
| `test_device_loss_while_available_makes_unavailable` | ✅ passed | 0.34 |
| `test_device_loss_on_call_requires_reconciliation` | ✅ passed | 0.55 |
| `test_browser_disconnect_sweep` | ✅ passed | 0.34 |
| `test_invalid_signature_rejected` | ✅ passed | 0.17 |
| `test_duplicate_events_are_not_reapplied` | ✅ passed | 0.67 |
| `test_out_of_order_events_do_not_regress_state` | ✅ passed | 0.69 |
| `test_early_events_are_buffered_then_applied` | ✅ passed | 0.47 |
| `test_sequence_gap_schedules_reconciliation` | ✅ passed | 0.70 |
| `test_hold_is_requested_then_acknowledged_by_event` | ✅ passed | 1.28 |
| `test_action_retry_does_not_resend` | ✅ passed | 0.67 |
| `test_provider_refusal_marks_failed` | ✅ passed | 0.73 |
| `test_unsupported_controls_are_refused_not_simulated` | ✅ passed | 0.72 |
| `test_wrap_up_does_not_make_available_with_live_leg` | ✅ passed | 0.88 |

### Warm/blind transfer incl. failure, provider disconnection and reconnection — `test_transfer_and_reconnect.py`

| Test | Result | Time (s) |
|---|---|---|
| `test_warm_transfer_success_keeps_one_interaction` | ✅ passed | 1.36 |
| `test_warm_transfer_rejected_preserves_original_call` | ✅ passed | 0.98 |
| `test_warm_transfer_no_answer` | ✅ passed | 1.40 |
| `test_blind_transfer_requeues_same_interaction` | ✅ passed | 0.92 |
| `test_provider_disconnection_and_recovery` | ✅ passed | 0.81 |
| `test_call_ended_during_outage_is_reconciled` | ✅ passed | 0.92 |

### Outbound eligibility & suppression, callbacks, campaigns — `test_outbound_callbacks_campaigns.py`

| Test | Result | Time (s) |
|---|---|---|
| `test_eligibility_rules` | ✅ passed | 0.37 |
| `test_calling_window_blocks` | ✅ passed | 0.30 |
| `test_place_eligible_call_and_refusal_recorded` | ✅ passed | 0.81 |
| `test_attempt_limits_and_active_attempts` | ✅ passed | 0.37 |
| `test_callback_promise_wording_and_capacity` | ✅ passed | 0.32 |
| `test_callback_processing_retry_and_ownership` | ✅ passed | 1.04 |
| `test_callback_cancel_requires_reason` | ✅ passed | 0.32 |
| `test_campaign_import_review_and_four_eyes` | ✅ passed | 0.42 |
| `test_preview_campaign_rechecks_at_dial` | ✅ passed | 0.50 |

### Customer matching & verification, cases & tasks, recording permissions & retention — `test_customers_cases_recordings.py`

| Test | Result | Time (s) |
|---|---|---|
| `test_shared_number_candidates_and_no_auto_merge` | ✅ passed | 0.68 |
| `test_verification_gates_restricted_data_and_sensitive_actions` | ✅ passed | 0.91 |
| `test_verification_locks_after_failures` | ✅ passed | 0.84 |
| `test_case_resolution_reopen_and_override` | ✅ passed | 1.18 |
| `test_follow_up_task` | ✅ passed | 0.67 |
| `test_recording_permissions_retention_and_payment` | ✅ passed | 1.05 |
| `test_date_of_birth_formats_are_normalised` | ✅ passed | 0.00 |

### Knowledge, AI guardrails, messages, QA, monitoring, workforce, forecasting — `test_knowledge_ai_quality_wfm.py`

| Test | Result | Time (s) |
|---|---|---|
| `test_knowledge_only_approved_effective` | ✅ passed | 0.29 |
| `test_knowledge_four_eyes` | ✅ passed | 0.29 |
| `test_ai_summary_requires_review_and_flags_injection` | ✅ passed | 0.90 |
| `test_messages_only_from_approved_templates_after_review` | ✅ passed | 0.75 |
| `test_quality_review_rubric_and_dispute` | ✅ passed | 0.34 |
| `test_monitoring_is_permissioned_and_visible` | ✅ passed | 0.82 |
| `test_published_schedule_is_immutable_and_changes_need_approval` | ✅ passed | 0.42 |
| `test_forecast_is_separate_from_observed_and_shows_gaps` | ✅ passed | 0.60 |
| `test_erlang_c_sanity` | ✅ passed | 0.00 |

### Report arithmetic, security controls, channels, WebSocket, Twilio adapter — `test_reports_security_channels.py`

| Test | Result | Time (s) |
|---|---|---|
| `test_report_arithmetic` | ✅ passed | 0.16 |
| `test_mfa_required_for_admin` | ✅ passed | 0.32 |
| `test_permissions_enforced_server_side` | ✅ passed | 0.34 |
| `test_org_scoping` | ✅ passed | 0.25 |
| `test_refresh_rotation_and_reuse_detection` | ✅ passed | 0.27 |
| `test_rate_limit_login` | ✅ passed | 0.32 |
| `test_log_redaction` | ✅ passed | 0.00 |
| `test_audit_chain_detects_tampering` | ✅ passed | 0.53 |
| `test_oidc_id_token_validation_and_mfa_evidence` | ✅ passed | 0.04 |
| `test_secrets_encrypted_at_rest` | ✅ passed | 0.12 |
| `test_webchat_flow` | ✅ passed | 0.49 |
| `test_email_channel` | ✅ passed | 0.53 |
| `test_websocket_auth_and_resume` | ✅ passed | 0.28 |
| `test_twilio_adapter_signature_token_and_capabilities` | ✅ passed | 0.03 |

### Requirement → test mapping

| Required test area | Tests |
|---|---|
| Routing eligibility | test_requires_skill_language_membership_and_registration, test_connected_browser_is_not_enough, test_longest_waiting_and_longest_idle, test_closed_queue_goes_to_voicemail, test_overflow_keeps_wait_clock |
| Ownership concurrency | test_concurrent_accept_has_single_owner, test_accept_is_idempotent_and_expired_offers_cannot_be_accepted |
| Call-state transitions | test_system_states_cannot_be_requested, test_cannot_go_offline_mid_call_and_version_checked, test_device_loss_while_available_makes_unavailable, test_device_loss_on_call_requires_reconciliation, test_browser_disconnect_sweep, test_wrap_up_does_not_make_available_with_live_leg, test_missed_offer_makes_agent_unavailable_and_reroutes |
| Duplicate / out-of-order / early / missing events | test_duplicate_events_are_not_reapplied, test_out_of_order_events_do_not_regress_state, test_early_events_are_buffered_then_applied, test_sequence_gap_schedules_reconciliation, test_invalid_signature_rejected |
| Transfer failure | test_warm_transfer_rejected_preserves_original_call, test_warm_transfer_no_answer (success paths: test_warm_transfer_success_keeps_one_interaction, test_blind_transfer_requeues_same_interaction) |
| Suppression rules | test_eligibility_rules, test_place_eligible_call_and_refusal_recorded, test_preview_campaign_rechecks_at_dial, test_calling_window_blocks, test_attempt_limits_and_active_attempts |
| Recording permissions | test_recording_permissions_retention_and_payment |
| Reconnection | test_provider_disconnection_and_recovery, test_call_ended_during_outage_is_reconciled, test_websocket_auth_and_resume |
| Report arithmetic | test_report_arithmetic (plus report assertions in test_warm_transfer_success_keeps_one_interaction) |

## Browser end-to-end smoke test

`web/e2e/smoke.mjs`, run at 2026-11-26T18:39:40.215Z against the Docker Compose stack. Screenshots from this run are in [`screenshots/`](screenshots/).

| Check | Result |
|---|---|
| browser softphone registered and provider confirmed registration | ✅ PASS |
| agent became available after readiness checks | ✅ PASS |
| offer shown in queue panel | ✅ PASS |
| keyboard accept (Alt+A) → live call indicator (teal) after provider confirmation | ✅ PASS |
| restricted data withheld before verification | ✅ PASS |
| verification recorded; restricted data shown to owning agent | ✅ PASS |
| approved knowledge search | ✅ PASS |
| hold confirmed by provider event, distinct from mute | ✅ PASS |
| call ended via provider → after-call work | ✅ PASS |
| AI draft cannot be saved until reviewed | ✅ PASS |
| after-call work completed with disposition; agent available again | ✅ PASS |
| supervisor live operations shows agents | ✅ PASS |
| reports show today's offered contacts — offered=3 | ✅ PASS |
| forecast generated with band and staffing table | ✅ PASS |
| audit history and hash-chain verification | ✅ PASS |
| no browser console errors on agent page | ✅ PASS |

## Demonstration run

The full console output of the 14-step scenario against the Docker stack is in [demo.md](demo.md); the machine-readable log is [`demo-run.json`](demo-run.json).

## Backup and restoration (executed)

```text
Backing up database…
Backing up protected object store…
Backup written to /tmp/claude-0/backup-final
db.dump: OK
objects.tgz: OK
row-counts.json: OK
DROP DATABASE
CREATE DATABASE
Database restored into aureom_restore_check
{"row_counts_match": true, "tables_checked": 14, "differences": {}}
{"valid": true, "checked": 83, "head": "54ce2d5f4f8965f13152db2e738b4fdbc9915a680b07c5a97812d0617415a444"}
{"objects_verified": 4, "objects_failed": 0}
Restore verified.
```

## Issues found by testing and fixed during delivery

* Session autoflush was disabled, so queries could miss pending changes (an agent stayed in after-call work) — enabled.
* Seeded callbacks that were already due were (correctly) routed before the scenario's inbound call — the demo and e2e setup clear the due backlog through the audited API.
* The state machine lacked offer → on_interaction for callback/chat work and available → on_interaction for preview — added.
* Reconciliation resolved unknown controls correctly but labelled them `provider_event` — the resolution source is now carried explicitly.
* Status value `captured_not_sent` overflowed a 16-character column; audit details containing datetimes were not JSON-safe; a non-ASCII HTTP header value; a keyword-argument clash in the timeline helper — all fixed.
* The autogenerated migration silently omitted two deferred foreign keys on `interactions` — added explicitly; `alembic check` is clean.
* The heuristic article suggester returned nothing during live calls (no transcript yet) — it falls back to the queue topic.
* A UK-format date of birth (21/07/1979) failed verification against the stored ISO date — answers are now normalised before comparison (tested).
* UI: the pressed Hold button lost its label on hover; End call wrapped to a second row; verification factors (date of birth) were displayed after verification — fixed (factors are never displayed).

## Not tested

* Real telephony, real media/audio, and the Twilio adapter against a live account (only offline unit checks).
* OIDC against a live identity provider (token validation unit-tested with locally generated keys).
* The Claude-backed AI adapter against the live API (no key in the build environment); the heuristic baseline is tested.
* Load, soak and multi-replica behaviour; formal accessibility (WCAG) audit; penetration test; browsers other than Chromium.
