# Demonstration

Pennine Customer Services is entirely fictional. Telephony is **simulated**: the simulator emits provider-style signalling events and **no audio is carried anywhere**.

## Run it

```bash
docker compose up --build -d          # wait until `docker compose ps` shows api healthy
python3 -m pip install httpx          # the demo driver's only dependency
python3 scripts/demo.py --api http://localhost:8000 --sim http://localhost:8090
```

The driver signs in three agents, registers their (simulated) devices directly with the simulator as a browser would, keeps their presence alive and walks the 14 steps below. It first cancels any seeded callback that is already due (through the audited API) so the run is deterministic. Calling windows are real rules: the outbound steps pick a fictional customer whose local time is inside the permitted window, or show the refusal if none is.

## Accounts (demo only)

Password for every seeded account: `Pennine-Demo-2026!`. The administrator and compliance officer also need a TOTP code: `docker compose exec api python -m aureom_connect.cli totp kit.admin@pennine.example`.

| Account | Role |
|---|---|
| amira.khan@pennine.example | agent — billing, care, outbound |
| ben.hughes@pennine.example | agent — technical, care, Welsh |
| chloe.dawson@pennine.example | agent — billing, technical |
| dev.patel@pennine.example | agent — technical, care |
| eilidh.fraser@pennine.example | agent — care, billing |
| femi.adeyemi@pennine.example | agent — billing, outbound, care |
| grace.thornton@pennine.example, sam.okafor@pennine.example | supervisors |
| harriet.lowe@pennine.example | quality reviewer |
| ian.rowe@pennine.example | workforce manager |
| jo.pickering@pennine.example | compliance officer (MFA) |
| kit.admin@pennine.example | administrator (MFA) |
| lena.ward@pennine.example | knowledge editor |

## Try it in the browser

1. Open http://localhost:3000 and sign in as `amira.khan@pennine.example`. The softphone registers with the simulator; wait for *Device registered (provider-confirmed)*, then choose **Available**.
2. In another browser profile sign in as `grace.thornton@pennine.example` → **Administration → Simulator → Place call** (option 1, Billing).
3. Accept the offer (**Alt+A**), choose the caller under *Possible matches*, and verify with date of birth `21/07/1979` and postcode `OL14 6QT` (Rhys Morgan). Try Hold, a warm transfer to another signed-in agent, end the call and complete after-call work.
4. As the supervisor, watch **Live operations**, inject a provider outage in **Administration → Simulator**, and review **Reports** and **Audit history**.
5. For web chat, open http://localhost:3000/chat-demo as a customer and accept the chat as Ben Hughes (technical).

## Actual output (run against the Docker stack during delivery)

```text
AUREOM CONNECT – Pennine Customer Services demonstration
SIMULATED telephony: provider events only, no audio, fictional customers.

Setup: supervisor cancelled seeded callback CB-1001 (audited) for a deterministic run

[01] Receive an incoming call (simulated PSTN caller → IVR option 1, Billing)
     • Simulator placed call CA7648a6d750ef4d2ba622 from a fictional caller (0113 496 0145) to the main line

[02] Route it to an eligible agent
     • Offered to Amira Khan: Longest-idle eligible agent selected (Amira Khan) among 3 eligible.
     • Amira Khan: eligible
     • Ben Hughes: excluded: state is offline; application not connected; no provider-confirmed telephony registration; not a member of queue BILLING; missing skills: billing
     • Chloe Dawson: excluded: state is offline; application not connected; no provider-confirmed telephony registration
     • Dev Patel: excluded: state is offline; application not connected; no provider-confirmed telephony registration; not a member of queue BILLING; missing skills: billing
     • Eilidh Fraser: eligible
     • Femi Adeyemi: eligible

[03] Accept it without competing ownership
     • Eilidh Fraser tries to accept without an offer → 409 OFFER_NOT_PENDING
     • Accepted (200); retry with the same Idempotency-Key replayed (replayed=true) without a second connection request
     • Provider confirmed agent leg; control 'answer' is acknowledged; recording status active (confirmed by provider event)

[04] Review possible customer matches
     • Telephone number is a matching hint, not proof of identity.
     • Candidate PCS-100245 Rhys Morgan: Caller number matches home phone on record, number is the primary contact, number was previously verified
     • Selected as probable match → status selected_unverified; restricted data withheld_until_verified

[05] Record verification
     • Customer gave a wrong date of birth → {'date_of_birth': False}, status in_progress
     • Two factors confirmed → status verified (answers checked server-side, never stored)
     • Restricted data now visible to the owning agent: balance £212.55 overdue

[06] Search approved knowledge
     • Setting up a payment arrangement v2 [customer_visible] owner Billing, effective 2026-10-27
     • Assistant (heuristic: aureom-rules-1.0 (not a language model)) suggested ['payment-arrangements'] with confidence 0.13 – a proposal only

[07] Complete a warm transfer (after one rejected consultation)
     • Femi Adeyemi declined → transfer failed (rejected); customer leg answered, on hold True, still owned by Amira Khan
     • Eilidh Fraser answered the consultation
     • Transfer completed by provider event; same interaction INT-100113 now owned by Eilidh Fraser; transfer_count=1

[08] Save a reviewed summary
     • Draft (proposal, confidence 0.75): Contact via voice (call to Billing & Payments). Identity verification status: verified. The call was transferred to a colleague within the s…
     • Uncertainty notes: ['Rule-based extract, not a language model.', 'Quoted statements come from a machine transcript and are not verified facts.', 'Review and correct before saving.']
     • Saved after agent review (source=ai_draft_reviewed); unreviewed saves are refused

[09] Create a follow-up task
     • Task 'Send payment arrangement confirmation letter' due 2026-11-27T18:39 – SLA Internal target
     • Approved template message queued (status queued); the worker sends via the e-mail adapter

[10] Complete after-call work
     • Amira Khan wrapped their part → state available
     • Eilidh Fraser ended the call (confirmed by provider), dispositioned 'payment_arrangement' → interaction completed, agent available

[11] Process a callback
     • Callback CB-1003 for Aisha Rahman (Europe/London); promise: We aim to call between Thu 26 Nov 18:39 and Thu 26 Nov 20:39. This is a target window, not a guaranteed time.
     • Routed to and owned by Femi Adeyemi (callback status in_progress)
     • Eligibility passed (10 checks, rule set v2); dialling
     • Callback completed after 1 attempt(s): [{'attempt': 1, 'agent_id': 'c3c7a745-b946-4230-a87d-a277dec619c6', 'started_at': '2026-11-26T18:39:24.343833Z', 'ended_at': '2026-11-26T18:39:26.185563Z', 'result': 'connected'}]

[12] Place an eligible manual outbound call (and see an ineligible one refused)
     • Call to a number on the internal do-not-call list → 422 OUTBOUND_NOT_PERMITTED: ['basis', 'suppression']
     • Pre-check for Daniel Okoro: eligible=True; number_valid=ok, caller_id_owned=ok, rule_set_active=ok, basis=ok, suppression=ok, objection=ok, preference=ok, calling_window=ok, attempt_limit=ok, no_active_attempt=ok
     • Connected (provider-confirmed) presenting owned caller ID +441614960100

[13] Recover from a provider disconnection
     • Simulator outage injected: requests are applied but responses and events are lost
     • Hold request outcome: unknown (GATEWAY_TIMEOUT) – not retried
     • Provider marked disconnected; 11 voice controls disabled; agent reconcile_required=True
     • End-call attempted during outage → 409 RECONCILIATION_REQUIRED
     • Reconciled from provider state: hold acknowledged (resolved_by=reconciliation), customer on_hold=True; hold sent to provider 1 time(s)
     • Agent reconcile_required=False
     • Call resumed, ended and dispositioned normally after recovery

[14] Review reports and audit history
     • Today (excluding synthetic history): volumes {'offered': 2, 'answered': 2, 'abandoned': 0, 'short_abandoned': 0, 'voicemail': 0, 'callback_requested': 0, 'in_progress_or_other': 0}
     • Rates {'answer_rate_pct': 100.0, 'abandon_rate_pct': 0.0, 'service_level_pct': 100.0, 'transfer_rate_pct': 50.0, 'repeat_contact_rate_pct': 100.0}; AHT 3.4 s; transfers {'interactions_transferred': 1}; callbacks {'requested': 3, 'completed': 1, 'still_open': 1, 'cancelled': 1, 'completion_rate_pct': 100.0}
     • Data quality: {'provider_events_by_status': {'applied': 55}, 'ingestion_lag_ms_p50': 6.5, 'ingestion_lag_ms_p95': 81.2, 'interactions_needing_reconciliation': 0}
     • audit #23 18:39:21 Amira Khan: call.warm_transfer_start
     • audit #24 18:39:21 Eilidh Fraser: interaction.accepted
     • audit #27 18:39:22 Amira Khan: call.warm_transfer_complete
     • audit #29 18:39:22 Eilidh Fraser: ai.draft_summary
     • audit #30 18:39:22 Eilidh Fraser: interaction.summary_saved
     • audit #33 18:39:22 Amira Khan: interaction.wrap_up_completed
     • audit #34 18:39:22 Eilidh Fraser: call.end
     • audit #37 18:39:23 Eilidh Fraser: interaction.wrap_up_completed
     • Audit hash chain valid=True over 56 entries
     • Interaction timeline has 35 events; first/last: call.received → transcript.available

Log written to /tmp/claude-0/-home-user-Aureom-AI/e0db7fe9-0690-5fd6-8223-e34dacfe6f5a/scratchpad/aureom-connect/docs/demo-run.json
```
