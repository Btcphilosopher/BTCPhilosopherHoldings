# Telephony adapters

## Contract

`backend/aureom_connect/adapters/telephony/base.py` defines the `TelephonyProvider` protocol. Rules every adapter
follows:

1. **Declare capabilities** (`ProviderCapabilities`). The UI and API disable anything not declared — unsupported
   controls are refused with `422 UNSUPPORTED_BY_PROVIDER`, never simulated.
2. **`ControlResult.outcome` describes the request, not the call:** `accepted` (provider took the request),
   `rejected` (definitely not applied — e.g. connection refused, 4xx, 503), `unknown` (timeout or lost response —
   it may or may not have been applied). State changes are learned only from verified events or state queries.
3. **Verify webhooks** before parsing, and normalise them into `NormalizedEvent` (provider event id, type, provider
   time, call/leg ids, optional sequence, request id).
4. **Answer state queries** (`get_call_state`, `list_active_calls`) for reconciliation.
5. **Mint short-lived media credentials** for the browser's own device registration.

Select the adapter explicitly with `AUREOM_TELEPHONY_PROVIDER` = `simulated` | `twilio` | `none`.

## Simulated provider (default)

`simulator/aureom_sim` is a separate service (its own image in Docker Compose) with an HTTP API and a signalling
engine. **It carries no audio.** It models calls, legs, device registrations, recording, secure payment and
monitoring, and emits HMAC-signed webhooks with per-call sequence numbers and provider timestamps.

| Area | Behaviour |
|---|---|
| Devices | Browser registers with a JWT media credential; heartbeats every 15 s; timeout after 45 s → `device.unregistered` |
| Inbound | `POST /v1/demo/inbound` stands in for a PSTN caller (from/to number, IVR digits, consent digit, scripted transcript) |
| Agent connection | Rings the agent's device, auto-answers 0.25 s later if registered (`leg.failed device_unavailable` otherwise) |
| Hold / mute | Customer-leg hold, agent-leg mute; confirmed by `leg.held/resumed/muted/unmuted` |
| Warm transfer | Consult leg; customer held; target answers via the app; **failure behaviour: customer returns to the original agent (still on hold)** |
| Blind transfer, conference | Supported |
| Outbound | Agent leg then customer leg; outcome configurable (answer / no answer / busy) |
| Recording | Confirmed by `recording.started`; paused during secure payment; media = synthetic tone (`X-Synthetic-Media`) |
| Monitoring | Listen and coach; **barge not offered** (capability false → disabled in UI) |
| Faults (`PUT /v1/demo/faults`) | `outage` (`refuse` or `blackhole`), `duplicate_next`, `reorder_next`, `drop_types`, `delay_ms`, `agent_answer_fails`, `consult_target_behaviour`, `outbound_outcome`, `customer_hangup_after_seconds` |

Supervisors can drive these from **Administration → Simulator** (demo mode only; every use is audited).

## Twilio adapter — partial, externally integrated, not live-tested

`adapters/telephony/twilio.py` is intentionally narrow. It is **not suitable for routing live calls** in this
release.

| Implemented (untested against a live account) | Disabled (capability `false`) |
|---|---|
| Webhook validation: `X-Twilio-Signature` = Base64(HMAC-SHA1(auth token, URL + sorted POST params)); JSON bodies via `bodySHA256` | Agent connection (requires TwiML `<Dial><Client>` endpoints) |
| Voice SDK access token: HS256, `cty: twilio-fpa;v=1`, `iss` = API key SID, `sub` = account SID, `grants.identity`, `grants.voice.incoming/outgoing`; TTL ≤ 24 h; identities sanitised to letters, digits, underscore | Hold, mute, transfers, conference (Twilio exposes hold/mute on **conference participants**; a conference-based call architecture is required) |
| Status callbacks → normalised events (`SequenceNumber` used when present; it is not guaranteed on every callback) | Recording control, secure payment, monitoring |
| Hang-up (`Status=completed` on the Call resource), call state query | Browser SDK integration in the web app |

### How these facts were checked

A research agent searched Twilio's official documentation on 2026-11-26. Direct page fetches to twilio.com were not
possible from the build environment, so the findings rest on search-engine extracts of official pages, not full
page reads. Pages cited: twilio.com/docs/usage/webhooks/webhooks-security, /docs/usage/security,
/docs/usage/webhooks/webhook-configuration, /docs/iam/access-tokens, /docs/api/errors/20102,
/docs/voice/api/call-resource, /docs/voice/tutorials/how-to-modify-calls-in-progress,
/docs/voice/api/conference-participant-resource, /docs/voice/twiml/client. Notable points: Twilio may add
parameters without notice (sign all received parameters), callbacks can arrive out of order (use `Timestamp` as a
fallback), and a newer HMAC-SHA256 webhook signing option exists for new integrations. **Re-verify against the live
documentation and a test account before enabling.**

## Media

No local media demonstration is included, because no real media adapter is implemented. Adding one means
integrating a maintained WebRTC/SIP platform's browser SDK in `web/lib/softphone.ts` behind the same media-credential
flow, and declaring `media: "webrtc"` in the adapter's capabilities.
