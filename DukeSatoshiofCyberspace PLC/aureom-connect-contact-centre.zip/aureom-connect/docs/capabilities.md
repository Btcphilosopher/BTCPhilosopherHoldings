# Capability status

Every capability is labelled with exactly one status:

| Status | Meaning |
|---|---|
| **Implemented** | Working code in this delivery, exercised by automated tests and/or the demo. |
| **Simulated** | Works end to end, but against the bundled telephony simulator or synthetic data – not a real network, real media or real customers. |
| **Externally integrated** | Code written against a third party's documented interface but **not exercised against the live service** in this delivery (no credentials available). Treat as untested. |
| **Deferred** | Not built. Listed so nobody assumes it exists. |

The single most important simulated item: **there is no audio anywhere in this delivery.** The telephony simulator produces provider-style signalling events only. The UI shows *“Simulated telephony · no audio”* wherever this matters.

## 1. Core workflows

| Capability | Status | Notes |
|---|---|---|
| Inbound: call → IVR → queue → routing → offer → answer → verification → conversation → outcome → follow-up | Implemented · Simulated telephony | `tests/test_core_flow.py`, demo steps 1–10 |
| Outbound: list → eligibility → agent-initiated call → conversation → disposition → next action | Implemented · Simulated telephony | Click-to-call, callbacks and preview campaigns |
| Voice, e-mail and web-chat queues through separate channel adapters | Implemented | Voice via telephony adapter; e-mail via SMTP adapter (Mailpit in Compose); chat via public session endpoints. Inbound e-mail is injected by a demo endpoint (a real mail-provider webhook is Deferred) |
| Predictive / progressive dialling | Deferred (by design) | Preview only |

## 2. Interface

| Capability | Status | Notes |
|---|---|---|
| Agent navigation: Workspace · Customers · Inbox · Tasks · Knowledge · My schedule | Implemented | Next.js 16 / React 19 |
| Supervisor navigation: Live operations · Queues · Agents · Campaigns · Quality · Reports · Administration | Implemented | Workforce scheduling lives under Agents |
| Three-panel agent layout (queue & tasks · conversation · context & knowledge) | Implemented | |
| Midnight-navy navigation, pale-grey workspace, teal active call, labelled amber warnings, red failures | Implemented | Warnings always carry a text label and icon, never colour alone |
| Persistent, visually distinct mute / hold / transfer / end controls | Implemented | Different shapes, colours and icons; keyboard shortcuts |
| Keyboard-accessible workflows | Implemented | Skip link, focus rings, Alt+A/R/H/M/T/E/K shortcuts, ARIA live regions. No formal WCAG audit performed (Deferred) |
| Dark mode | Deferred | Light enterprise theme only |

## 3. Architecture

| Capability | Status | Notes |
|---|---|---|
| Next.js + React + TypeScript applications | Implemented | One app containing the agent workspace and supervisor console |
| Python / FastAPI backend, PostgreSQL, Alembic migrations | Implemented | 81 tables; migration verified with `alembic check` |
| WebSocket application events (separate from media) | Implemented | Transactional outbox + `LISTEN/NOTIFY`; resumable cursor |
| Background worker (imports, notifications, reconciliation, retention, timers) | Implemented | `SKIP LOCKED` job queue |
| Protected object storage for recordings and attachments | Implemented (local) / Deferred (S3) | Encrypted at rest on a private volume, served only via permission-checked, audited endpoints. MinIO was not used: its community edition is no longer distributed as binaries/images (see dependency-verification.md). An S3-compatible backend is Deferred |
| Docker Compose | Implemented | Built and run in this environment; see test-results.md |
| Typed telephony adapter; Python orchestrates, provider handles media | Implemented | `adapters/telephony/base.py` |

## 4. Customer records

| Capability | Status |
|---|---|
| Customer and organisation (account) identifiers, contact points, preferences, consent, objections, cases, interaction history, open tasks, source-system references | Implemented (synthetic data) |
| Phone number treated as a hint; possible matches shown with reasons | Implemented |
| Verification required before restricted data or sensitive actions | Implemented (server-side; answers never stored or shown) |
| Uncertain matches without automatic merge; duplicate flag → back-office task | Implemented |
| Synchronisation with real CRM / billing systems | Deferred (source references are stored, no connector) |

## 5. Call and conversation model

Interaction, call, call leg, agent participation, queue entry, offer, recording, transcript, case and task are separate tables. Provider identifiers, provider event time, ingestion time and the full event history are stored. A transferred call is one interaction (tests assert `offered == 1` after a warm transfer). **Implemented.**

## 6. Inbound routing

| Capability | Status |
|---|---|
| Business hours and holidays (incl. reduced-hours days) | Implemented |
| Configurable, versioned IVR menus (DTMF; language option) | Implemented · IVR prompts are simulated (no audio) |
| Language and skill requirements; queue priorities; overflow queues | Implemented |
| Voicemail | Simulated (the request and follow-up task are real; no audio is captured) |
| Callback requests (IVR and agent) | Implemented |
| Transparent baseline: eligibility → longest waiting → longest idle; decisions stored with per-agent reasons | Implemented |
| Routing priority separate from urgency flags | Implemented |
| Transactional single ownership | Implemented (concurrency test with two simultaneous accepts) |
| IVR editor UI | Deferred (configuration is viewable; edited via API/seed) |

## 7. Agent state

Explicit states (offline, available, call offered, connecting, on interaction, after-call work, break, unavailable); application presence, provider-confirmed telephony registration and call state tracked separately; missed offers, browser refresh (grace period + resumable events), device loss and provider disconnection handled; agents are not made available while conflicting call state exists. **Implemented** (device registration is with the simulator).

## 8. Call controls

| Control | Simulated provider | Twilio adapter |
|---|---|---|
| Answer / reject | Implemented | Disabled (not implemented) |
| Mute (provider-side, agent leg) | Implemented | Disabled |
| Hold / resume (customer leg) | Implemented | Disabled |
| Warm transfer (consult, complete, cancel; failure preserves original call) | Implemented | Disabled |
| Blind transfer to queue | Implemented | Disabled |
| Conference | Implemented | Disabled |
| End call | Implemented | Externally integrated |
| Requested / acknowledged / failed / unknown outcomes shown | Implemented | – |
| Local (browser-only) microphone mute | Deferred – there is no browser audio in this delivery |

## 9. Callbacks

Requested number with confirmation method, time window, queue/skills, attempt limits, cancellation with reason, attempt history, honest promise text (exact times only when slot capacity is reserved), owned work items with duplicate-attempt protection. **Implemented · Simulated telephony.**

## 10. Outbound calling and campaigns

| Capability | Status |
|---|---|
| Click-to-call and preview campaigns | Implemented · Simulated telephony |
| Pre-dial checks: purpose/basis (consent etc.), suppression lists, objections, preferences, local calling window, attempt limits and spacing, existing active attempts, owned caller ID | Implemented |
| Jurisdiction-specific, versioned rule sets | Implemented – **the seeded GB and US rule contents are illustrative and unverified** |
| Import validation and review screen; four-eyes activation | Implemented |
| Caller-ID spoofing | Not possible by design (only owned, verified numbers) |
| Real national registry (e.g. TPS) screening feed | Deferred – a synthetic snapshot list stands in |

## 11. Cases and back-office tasks

Create/update cases, structured outcomes, notes, tasks with assignees and due dates, escalation, linking interactions, approved follow-up messages, attributable after-call work, reasons required for reopen/override, internal targets vs contractual commitments. **Implemented.**

## 12. Knowledge and AI assistance

| Capability | Status |
|---|---|
| Versioned knowledge base: search, approval (four-eyes), effective dates, ownership, review dates, internal vs customer-visible | Implemented |
| Article suggestions, summary drafts, message drafts, case classification with sources and uncertainty | Implemented with the **heuristic baseline** (rule-based, explicitly *not* a language model) |
| Claude-backed assistant (`AUREOM_AI_PROVIDER=anthropic`) | Externally integrated – written against the official `anthropic` SDK 2.14, not run against the live API here |
| Agent review before saving summaries / sending messages; no autonomous decisions; untrusted-input handling | Implemented (server-enforced) |

## 13. Recording and transcription

| Capability | Status |
|---|---|
| Policy by queue, purpose and jurisdiction; notice; consent mode | Implemented |
| “Active” only after provider confirmation; pause intervals; retention date; deletion; legal hold; access permissions with stated purpose and audit | Implemented |
| Recording media | **Simulated** – a synthetic tone labelled `X-Synthetic-Media` |
| Transcripts with provenance; corrections stored separately from machine output | Implemented · transcript text is scripted by the simulator |
| Secure payment capture with provider-confirmed recording pause; no card data in the application | Simulated provider workflow |
| Real speech-to-text or redaction | Deferred |

## 14. Supervisor tools

Live queue state, waiting interactions with routing explanations, agent state, routing failures, callback backlog, case workload, service-level reporting, quality-review queue. Listen/coach monitoring is permissioned, requires a reason, is audited and always visible to the agent; barge is disabled because the provider does not support it. QA uses a documented rubric with human scoring, evidence per criterion, acknowledgement and dispute. **Implemented** (monitoring audio is simulated).

## 15. Workforce scheduling

Availability, skills, shifts with breaks, leave, queue assignments, draft/published schedules, shift-change requests with approval, conflicts (overlap, leave clash, rest, missing break, outside availability), staffing gaps, transparent forecast (same-weekday mean with 80 % range, Erlang C) stored separately from observed demand; published shifts never changed automatically. **Implemented** – forecast history is imported synthetic data. A drag-and-drop schedule editor is Deferred (draft shifts are edited via API).

## 16. Reporting

All listed metrics with documented definitions, denominators, exclusions and transfer treatment; provider event time vs ingestion time; per-agent workload with explicit caution. **Implemented**, arithmetic covered by `test_report_arithmetic`. Exports (CSV/BI) are Deferred.

## 17. Security and resilience

| Capability | Status |
|---|---|
| Local password + TOTP MFA (break-glass/demo) | Implemented |
| Organisational OIDC sign-in with MFA via `amr` | Externally integrated (token validation unit-tested with locally generated keys; no live IdP) |
| Role- and organisation-scoped permissions | Implemented |
| Restricted recording access | Implemented |
| Protected provider credentials (encrypted at rest, never returned) | Implemented (storage model); credential management UI Deferred |
| Short-lived browser media credentials | Implemented (10 min, renewed) |
| Verified provider events (HMAC + timestamp; Twilio signature) | Implemented / Twilio externally integrated |
| Rate limits | Implemented – in-process (single instance); shared store Deferred |
| Redacted logs, hash-chained audit trail | Implemented |
| Backups and tested restoration | Implemented and executed (see test-results.md) |
| Duplicate, delayed, missing and out-of-order events; reconciliation before consequential actions; no automatic repeat of unknown dial/transfer/end | Implemented |
| Production hardening (TLS termination, secrets manager, WAF, HA Postgres, penetration test) | Deferred |
| Legal/regulatory review | Deferred – see compliance-research.md |

## 18. API and adapters

All required endpoints exist (see api.md for the mapping), with idempotency keys, version checks, structured errors and server-side authorisation; media is kept off the event WebSocket. **Implemented.**

## 19. Working demonstration

Pennine Customer Services (3 queues, 6 agents, synthetic customers, cases, knowledge, one active and one draft preview campaign, callbacks, simulated provider). All 14 scenario steps run by `scripts/demo.py` – **Simulated telephony**.
