# Architecture

## Components

```
 Browser (Next.js app)                                Telephony provider
 ┌───────────────────────────┐   media credential    ┌──────────────────────────────┐
 │ Agent workspace           │──── device register ─▶│ Simulator (aureom_sim)       │
 │ Supervisor console        │      + heartbeats     │  signalling only, NO AUDIO   │
 │ Simulated softphone       │                       │  fault injection             │
 └──────┬──────────▲─────────┘                       └───────┬──────────▲───────────┘
   REST │          │ WS /v1/events (signals only)    signed  │          │ REST control
        ▼          │                                webhooks │          │ (adapter)
 ┌────────────────────────────────────────────────────────── ▼ ─────────┴──────────┐
 │ API (FastAPI)                                                                    │
 │  routers → services (routing, interactions, calls, provider_events,             │
 │  reconciliation, customers, callbacks, outbound, cases, knowledge, ai,          │
 │  recording, quality, workforce, reports, audit)                                  │
 │  adapters: telephony (simulated | twilio-partial | none), channels (voice,      │
 │  e-mail, chat), storage (encrypted local), AI (heuristic | anthropic)           │
 └───────┬─────────────────────────────────▲───────────────────────────────────────┘
         │ SQL (one transaction per change │ LISTEN/NOTIFY wake-ups
         ▼  + outbox event)                │
 ┌─────────────────────┐          ┌────────┴───────────┐        ┌─────────────────┐
 │ PostgreSQL 16       │◀────────▶│ Worker             │──SMTP─▶│ Mailpit (demo)  │
 │ 81 tables, Alembic  │          │ timers, jobs,      │        └─────────────────┘
 └─────────────────────┘          │ health, reconcile  │
                                  └────────────────────┘
```

* **Python orchestrates; it never handles media.** Codecs, media transport and signalling belong to the provider. The adapter contract (`backend/aureom_connect/adapters/telephony/base.py`) is typed with Pydantic models: `ProviderCapabilities`, `ControlResult`, `NormalizedEvent`, `ProviderCallState`, `MediaCredential`.
* **The browser registers its device directly with the provider** using a 10-minute media credential minted by the API, as real WebRTC SDKs do. The API learns that the device is registered only from the provider's signed `device.registered` event.
* **The WebSocket carries application events only.** Events are signals; the UI re-reads state over REST, so a lost or duplicated event can never corrupt the screen.

## Data model (the separations that matter)

| Entity | One row per… | Why it is separate |
|---|---|---|
| `interactions` | customer contact, end to end | a transfer, overflow or re-queue does **not** create a new contact |
| `calls` | provider call | an interaction can have zero (chat, preview) or more calls |
| `call_legs` | party connection (customer, agent, consult, supervisor) | hold, mute and transfer act on legs; each leg tracks its last applied provider sequence |
| `agent_participations` | agent's involvement | talk, hold and after-call work are attributed per agent; transfers produce several |
| `queue_entries` | stay in one queue | overflow and blind transfer add entries; wait is measured from the first |
| `offers` | work offered to one agent | expiry, rejection, consult offers, routing decision link |
| `routing_decisions` | routing evaluation | per-agent eligibility and reasons, shown to supervisors |
| `call_controls` | requested control | requested → acknowledged / failed / unknown, idempotency key, who resolved it |
| `provider_events` | verified provider event | provider time vs ingestion time, sequence, dedupe count, processing status |
| `interaction_events` | timeline entry | human-readable history (source: provider/agent/system/supervisor) |
| `recordings`, `transcripts`, `transcript_corrections` | media artefacts | status confirmed by provider; corrections never overwrite machine output |
| `cases`, `case_events`, `case_interactions`, `tasks` | back-office work | resolution is explicit; reopen/override reasons recorded |
| `customers`, `customer_secrets`, `customer_restricted`, `contact_points`, `consents`, `objections`, `communication_preferences`, `source_system_refs`, `possible_duplicates` | identity | verification factors are hashed and never displayed; duplicates are flagged, never merged |

## Consistency and concurrency

* **Single owner.** Acceptance is a guarded `UPDATE interactions … WHERE owner_agent_id IS NULL AND status='offered' [AND version=…]`; the loser gets `409 OWNERSHIP_CONFLICT`. Covered by a two-thread race test.
* **Routing passes** take a per-organisation advisory lock and `FOR UPDATE SKIP LOCKED` row locks, so the API and any number of workers can route safely.
* **Controls are persisted before they are sent.** A retry with the same `Idempotency-Key` returns the stored control and never re-sends. After the provider responds, rows are reloaded with `populate_existing` so a confirmation event that arrived first is never overwritten.
* **Transactional outbox.** Each state change writes its `app_events` rows in the same transaction; `pg_notify` wakes WebSocket gateways in any process; a 1-second poll is the fallback.
* **Audit trail** rows are hash-chained under an advisory lock; `verify-audit` detects edits or deletions.

## Provider events: duplicates, delays, gaps and order

1. Signature and timestamp verified (HMAC-SHA256, 300 s tolerance) before anything is stored.
2. `(provider, provider_event_id)` is unique: duplicates are counted, not re-applied.
3. Events for unknown calls are stored as `unmatched` and re-processed when the call appears (e.g. a webhook racing the dial response).
4. Each leg applies an event only if its sequence is newer (`stale_ignored` otherwise), so a late "resumed" cannot undo a newer "held".
5. A sequence gap schedules a `reconcile_call` job that reads the provider's authoritative state.

## Disconnection and reconciliation

The worker checks provider health every second. Two failures mark the provider `disconnected`: outstanding controls become `unknown`, live interactions and agents are flagged for reconciliation, and every voice control is disabled in the UI and refused by the API (`RECONCILIATION_REQUIRED`). When the provider returns, `reconcile_org` compares each live call with the provider's state and applies differences through synthetic events labelled `source: reconciliation`. Unknown controls are resolved **by observation only** – a dial, transfer or hang-up with an unknown outcome is never re-sent. The demo (step 13) and `test_provider_disconnection_and_recovery` prove the hold was sent exactly once.

## Agent state machine

```
offline ─▶ available ─▶ call_offered ─▶ connecting ─▶ on_interaction ─▶ after_call_work ─▶ available
   ▲          │  ▲           │  │             │              │ (transfer)        │
   │          ▼  │           ▼  ▼             ▼              ▼                   ▼
   └────── break / unavailable ◀── missed offer / connect failed / device lost ── break / offline
```

Agents may request only `available`, `break`, `unavailable`, `offline`. `available` additionally requires: application connected, provider-confirmed device registration, no pending reconciliation, no live legs, no open participations, no pending offer. Browser disconnects get a 30-second grace period; device loss while idle makes the agent unavailable, during a call it flags reconciliation (the call continues at the provider).

## Routing

See [routing.md](routing.md).

## Security

See [security.md](security.md).

## Code map

```
backend/aureom_connect/
  api/            HTTP routers (one per area) + views + idempotency helper
  services/       domain logic (no HTTP)
  adapters/       telephony, channels, storage, AI
  models/         SQLAlchemy models (81 tables)
  security/       auth (password+TOTP, OIDC), permissions, crypto, redaction, rate limit
  realtime/ws.py  WebSocket gateway
  worker/main.py  timers, jobs, health, reconciliation, retention
  seed/pennine.py synthetic demonstration data
backend/migrations/  Alembic (0001 initial schema)
backend/tests/       pytest suite (real PostgreSQL, in-process simulator)
simulator/aureom_sim/ telephony simulator (FastAPI + engine)
web/              Next.js app (app/agent/*, app/supervisor/*, components/, lib/)
scripts/          demo.py, backup.sh, restore.sh, verify_restore.sh
```
