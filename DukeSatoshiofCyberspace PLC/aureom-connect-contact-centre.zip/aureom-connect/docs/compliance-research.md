# Requirements to research before live deployment

**This is not legal advice and has not been verified for currency.** It is a checklist of areas the organisation
must research with current official sources and qualified advisers before connecting real customers, real
telephone numbers or real staff. The seeded calling rules, recording notices, retention periods and monitoring
settings are *illustrative configuration*, not statements of what the law requires.

The demonstration organisation is a fictional UK water services company. Obligations differ by country, sector and
the organisation's own contracts; repeat this exercise for every jurisdiction you operate or call into.

| Area | What to establish | Where to look (official sources, United Kingdom first) |
|---|---|---|
| Telecommunications | Rules on silent/abandoned calls, persistent misuse, caller line identification (presenting a valid, returnable number), number allocation and porting, emergency calls | Ofcom General Conditions of Entitlement; Ofcom persistent misuse policy statement; provider's acceptable-use terms. US: FCC rules (TCPA implementation, STIR/SHAKEN); other regulators as applicable |
| Marketing calls | When consent is required, screening against preference registers, objection handling, identification at the start of a call, time-of-day limits | Privacy and Electronic Communications Regulations (PECR) and ICO direct-marketing guidance; Telephone Preference Service / Corporate TPS rules. US: TCPA, Telemarketing Sales Rule, National Do Not Call Registry, state laws |
| Privacy and data protection | Lawful basis for each purpose, transparency notices, data minimisation, retention schedules, rights requests, international transfers, DPIAs for recording/monitoring/AI | UK GDPR and Data Protection Act 2018; ICO guidance. EU: GDPR and ePrivacy rules; national supervisory authorities |
| Call recording | Whether and how callers and staff must be told; consent requirements in each jurisdiction called; lawful purposes; access controls; retention | Investigatory Powers Act 2016 and the Lawful Business Practice regulations; ICO guidance. US: federal and state one-/all-party consent laws; sector regulators |
| Payment cards | Keeping card data out of scope: secure capture, recording pause/redaction, scope reduction, attestation | PCI DSS (current version) and PCI SSC guidance on telephone payments; acquirer requirements |
| Employment and staff monitoring | Proportionality, transparency and consultation for listening, coaching, quality scoring and workforce analytics; automated decision-making rules | ICO guidance on monitoring workers; employment law and works-council/union agreements where applicable; Equality Act 2010 considerations for scoring |
| Accessibility | Accessible staff tools and customer channels, reasonable adjustments, alternative formats | Equality Act 2010; WCAG 2.2 (W3C); sector-specific vulnerable-customer obligations |
| Sector rules (water, in this demo) | Customer service standards, priority services/vulnerability, complaint handling, guaranteed standards | Sector regulator and ombudsman requirements (for a water company in England and Wales: Ofwat and the relevant ombudsman scheme) |
| AI assistance | Transparency to staff/customers, human oversight, record keeping, provider data handling | ICO guidance on AI and data protection; EU AI Act where applicable; the AI provider's terms and data-retention settings |

## How the platform supports compliance (it does not provide it)

* Versioned, jurisdiction-specific calling rule sets with source notes and approval; every dial stores the rule-set
  version and the result of each check.
* Consent, objection, preference and suppression data checked before every outbound call.
* Recording policies per queue, purpose and jurisdiction with notices, consent mode, retention and access roles;
  status only after provider confirmation; audited access; legal hold.
* Monitoring is permissioned, reasoned, audited and always visible to the agent.
* Human-reviewed quality scores against a published rubric, with dispute.
* Audit trail with tamper evidence; tested backup and restore.
