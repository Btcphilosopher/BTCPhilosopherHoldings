"""AUREOM telephony simulator: signalling-only stand-in for a real provider (no audio)."""
__version__ = "0.3.0"
