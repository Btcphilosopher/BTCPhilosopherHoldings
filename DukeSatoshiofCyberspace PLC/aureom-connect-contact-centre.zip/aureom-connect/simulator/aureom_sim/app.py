"""HTTP API for the telephony simulator.

Two kinds of caller:

* the AUREOM backend adapter (``X-Sim-Api-Key``) – call control, state queries;
* the agent's browser "simulated softphone" (media token) – device registration
  and heartbeats only. This mirrors how a real WebRTC SDK registers directly
  with the provider using a short-lived token minted by the application.

Demo/test endpoints under ``/v1/demo`` stand in for the outside world
(a customer dialling in, hanging up, a network fault).
"""
from __future__ import annotations

import hashlib
import hmac
import io
import json
import logging
import math
import os
import queue
import struct
import threading
import time
import wave
from typing import Any, Callable

import httpx
import jwt
from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel

from .engine import DEFAULT_FAULTS, OutageError, SimEngine

log = logging.getLogger("aureom.sim")


class SimConfig(BaseModel):
    api_key: str = os.environ.get("SIM_API_KEY", "dev-insecure-change-me-sim-api")
    webhook_secret: str = os.environ.get("SIM_WEBHOOK_SECRET", "dev-insecure-change-me-sim-webhook")
    webhook_url: str = os.environ.get("SIM_WEBHOOK_URL", "http://127.0.0.1:8000/v1/providers/simulated/events")
    cors_origins: list[str] = [o for o in os.environ.get("SIM_CORS_ORIGINS", "http://localhost:3000,http://127.0.0.1:3000").split(",") if o]
    realtime: bool = True


def sign(secret: str, timestamp: str, body: bytes) -> str:
    return "v1=" + hmac.new(secret.encode(), timestamp.encode() + b"." + body, hashlib.sha256).hexdigest()


class WebhookDispatcher:
    """Delivers events in order on a background thread, with retries (which may create duplicates)."""

    def __init__(self, cfg: SimConfig):
        self.cfg = cfg
        self.q: queue.Queue[dict[str, Any]] = queue.Queue()
        self.delivered = 0
        self.failed = 0
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True, name="sim-webhooks")
        self._client = httpx.Client(timeout=5.0)

    def start(self) -> None:
        self._thread.start()

    def submit(self, event: dict[str, Any]) -> None:
        self.q.put(event)

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                event = self.q.get(timeout=0.2)
            except queue.Empty:
                continue
            delay = (event.get("_delay_ms") or 0) / 1000
            if delay:
                time.sleep(delay)
            body = json.dumps({"events": [{k: v for k, v in event.items() if not k.startswith("_")}]}).encode()
            for attempt in range(4):
                ts = str(int(time.time()))
                try:
                    r = self._client.post(self.cfg.webhook_url, content=body, headers={
                        "Content-Type": "application/json", "X-Sim-Timestamp": ts,
                        "X-Sim-Signature": sign(self.cfg.webhook_secret, ts, body)})
                    if r.status_code < 300:
                        self.delivered += 1
                        break
                    log.warning("webhook rejected status=%s attempt=%s", r.status_code, attempt)
                except httpx.HTTPError as exc:
                    log.warning("webhook delivery error %s attempt=%s", type(exc).__name__, attempt)
                time.sleep(0.5 * (2 ** attempt))
            else:
                self.failed += 1


def synthetic_wav(seconds: float = 2.0) -> bytes:
    """A short synthetic tone. Clearly not a call recording: the simulator has no audio."""
    rate = 8000
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        frames = b"".join(struct.pack("<h", int(8000 * math.sin(2 * math.pi * 440 * i / rate)))
                          for i in range(int(rate * max(0.5, min(seconds, 5.0)))))
        w.writeframes(frames)
    return buf.getvalue()


class InboundCall(BaseModel):
    from_number: str
    to_number: str
    ivr_digits: str | None = None
    consent_digit: str | None = None
    script: list[dict[str, Any]] = []
    hangup_after_seconds: float | None = None


class Ident(BaseModel):
    identity: str
    request_id: str


class ReqOnly(BaseModel):
    request_id: str


class Dial(BaseModel):
    from_number: str
    to_number: str
    identity: str
    request_id: str


class Notice(BaseModel):
    text: str
    request_id: str


class Payment(BaseModel):
    amount_minor: int
    currency: str = "GBP"
    request_id: str


class Monitor(BaseModel):
    identity: str
    mode: str
    request_id: str


class DeviceAuth(BaseModel):
    token: str


def create_app(cfg: SimConfig | None = None, *, emit: Callable[[dict[str, Any]], None] | None = None,
               start_threads: bool = True) -> FastAPI:
    cfg = cfg or SimConfig()
    dispatcher: WebhookDispatcher | None = None
    if emit is None:
        dispatcher = WebhookDispatcher(cfg)
        emit = dispatcher.submit
    engine = SimEngine(lambda ev: emit({**ev, "_delay_ms": engine.faults.get("delay_ms", 0)}), realtime=cfg.realtime)

    app = FastAPI(title="AUREOM Telephony Simulator", version="0.3.0",
                  description="Signalling-only simulator. No audio is carried.")
    app.state.engine = engine
    app.state.cfg = cfg
    app.add_middleware(CORSMiddleware, allow_origins=cfg.cors_origins, allow_methods=["*"], allow_headers=["*"])

    if start_threads:
        if dispatcher:
            dispatcher.start()

        def tick() -> None:
            while True:
                try:
                    engine.run_due()
                except Exception:  # pragma: no cover
                    log.exception("timer failure")
                time.sleep(0.05)

        threading.Thread(target=tick, daemon=True, name="sim-timers").start()

    def api_key(x_sim_api_key: str | None = Header(default=None)) -> None:
        if not x_sim_api_key or not hmac.compare_digest(x_sim_api_key, cfg.api_key):
            raise HTTPException(401, "invalid api key")

    def outage_wrap(fn: Callable[[], Any], *, status: int = 202) -> Response:
        try:
            result = fn()
        except OutageError:
            return JSONResponse(status_code=503, content={"error": "provider_unavailable"})
        except KeyError as exc:
            return JSONResponse(status_code=404, content={"error": "not_found", "id": str(exc)})
        except ValueError as exc:
            return JSONResponse(status_code=409, content={"error": str(exc)})
        if engine.lost_response():
            # Blackhole outage: the request was applied but the response is lost in transit.
            return JSONResponse(status_code=504, content={"error": "gateway_timeout"})
        return JSONResponse(status_code=status, content=result or {"accepted": True})

    @app.get("/v1/health")
    def health() -> Response:
        if engine.faults.get("outage"):
            return JSONResponse(status_code=503, content={"status": "unavailable"})
        return JSONResponse({"status": "ok", "media": "none_simulated", "active_calls": len(engine.active_calls())})

    # -------------------------------------------------------------- devices (browser)
    def device_identity(token: str) -> str:
        try:
            claims = jwt.decode(token, cfg.api_key, algorithms=["HS256"], audience="aureom-sim")
        except jwt.PyJWTError as exc:
            raise HTTPException(401, f"invalid media token: {type(exc).__name__}")
        return claims["sub"]

    @app.post("/v1/devices/register")
    def register(body: DeviceAuth) -> Response:
        identity = device_identity(body.token)
        return outage_wrap(lambda: {"device_id": engine.register_device(identity).device_id, "identity": identity,
                                    "media": "none_simulated"}, status=200)

    @app.post("/v1/devices/heartbeat")
    def heartbeat(body: DeviceAuth) -> Response:
        identity = device_identity(body.token)
        return outage_wrap(lambda: {"registered": engine.heartbeat(identity)}, status=200)

    @app.post("/v1/devices/unregister")
    def unregister(body: DeviceAuth) -> Response:
        identity = device_identity(body.token)
        engine.unregister_device(identity)
        return JSONResponse({"ok": True})

    # -------------------------------------------------------------- call control (backend)
    @app.post("/v1/calls/{call_id}/connect", dependencies=[Depends(api_key)])
    def connect(call_id: str, b: Ident) -> Response:
        return outage_wrap(lambda: {"leg_id": engine.connect_agent(call_id, b.identity, b.request_id).id})

    @app.post("/v1/calls/{call_id}/legs/{leg_id}/answer", dependencies=[Depends(api_key)])
    def answer(call_id: str, leg_id: str, b: ReqOnly) -> Response:
        return outage_wrap(lambda: engine.answer_leg(call_id, leg_id, b.request_id))

    @app.post("/v1/calls/{call_id}/legs/{leg_id}/reject", dependencies=[Depends(api_key)])
    def reject(call_id: str, leg_id: str, b: ReqOnly) -> Response:
        return outage_wrap(lambda: engine.reject_leg(call_id, leg_id, b.request_id))

    @app.post("/v1/calls/{call_id}/legs/{leg_id}/hold", dependencies=[Depends(api_key)])
    def hold(call_id: str, leg_id: str, b: ReqOnly) -> Response:
        return outage_wrap(lambda: engine.hold(call_id, leg_id, b.request_id, True))

    @app.post("/v1/calls/{call_id}/legs/{leg_id}/resume", dependencies=[Depends(api_key)])
    def resume(call_id: str, leg_id: str, b: ReqOnly) -> Response:
        return outage_wrap(lambda: engine.hold(call_id, leg_id, b.request_id, False))

    @app.post("/v1/calls/{call_id}/legs/{leg_id}/mute", dependencies=[Depends(api_key)])
    def mute(call_id: str, leg_id: str, b: ReqOnly) -> Response:
        return outage_wrap(lambda: engine.mute(call_id, leg_id, b.request_id, True))

    @app.post("/v1/calls/{call_id}/legs/{leg_id}/unmute", dependencies=[Depends(api_key)])
    def unmute(call_id: str, leg_id: str, b: ReqOnly) -> Response:
        return outage_wrap(lambda: engine.mute(call_id, leg_id, b.request_id, False))

    @app.post("/v1/calls/{call_id}/consult", dependencies=[Depends(api_key)])
    def consult(call_id: str, b: Ident) -> Response:
        return outage_wrap(lambda: {"leg_id": engine.start_consult(call_id, b.identity, b.request_id).id})

    @app.post("/v1/calls/{call_id}/legs/{leg_id}/complete-transfer", dependencies=[Depends(api_key)])
    def complete(call_id: str, leg_id: str, b: ReqOnly) -> Response:
        return outage_wrap(lambda: engine.complete_transfer(call_id, leg_id, b.request_id))

    @app.post("/v1/calls/{call_id}/legs/{leg_id}/cancel-consult", dependencies=[Depends(api_key)])
    def cancel(call_id: str, leg_id: str, b: ReqOnly) -> Response:
        return outage_wrap(lambda: engine.cancel_consult(call_id, leg_id, b.request_id))

    @app.post("/v1/calls/{call_id}/legs/{leg_id}/blind-transfer", dependencies=[Depends(api_key)])
    def blind(call_id: str, leg_id: str, b: ReqOnly) -> Response:
        return outage_wrap(lambda: engine.blind_transfer(call_id, leg_id, b.request_id))

    @app.post("/v1/calls/{call_id}/legs/{leg_id}/conference", dependencies=[Depends(api_key)])
    def conf(call_id: str, leg_id: str, b: ReqOnly) -> Response:
        return outage_wrap(lambda: engine.conference(call_id, leg_id, b.request_id))

    @app.post("/v1/calls/{call_id}/hangup", dependencies=[Depends(api_key)])
    def hangup(call_id: str, b: ReqOnly) -> Response:
        return outage_wrap(lambda: engine.hangup(call_id, b.request_id))

    @app.post("/v1/calls/outbound", dependencies=[Depends(api_key)])
    def dial(b: Dial) -> Response:
        def go() -> dict[str, Any]:
            call = engine.dial(b.from_number, b.to_number, b.identity, b.request_id)
            return {"call_id": call.id, "agent_leg_id": call.agent_leg_id or next(
                lg.id for lg in call.legs.values() if lg.leg_type == "agent"), "customer_leg_id": call.customer_leg_id}
        return outage_wrap(go)

    @app.post("/v1/calls/{call_id}/notice", dependencies=[Depends(api_key)])
    def notice(call_id: str, b: Notice) -> Response:
        return outage_wrap(lambda: engine.play_notice(call_id, b.text, b.request_id))

    @app.post("/v1/calls/{call_id}/recording/start", dependencies=[Depends(api_key)])
    def rec_start(call_id: str, b: ReqOnly) -> Response:
        return outage_wrap(lambda: {"recording_id": engine.start_recording(call_id, b.request_id)})

    @app.post("/v1/calls/{call_id}/recording/pause", dependencies=[Depends(api_key)])
    def rec_pause(call_id: str, b: ReqOnly) -> Response:
        return outage_wrap(lambda: engine.set_recording_paused(call_id, True, b.request_id))

    @app.post("/v1/calls/{call_id}/recording/resume", dependencies=[Depends(api_key)])
    def rec_resume(call_id: str, b: ReqOnly) -> Response:
        return outage_wrap(lambda: engine.set_recording_paused(call_id, False, b.request_id))

    @app.post("/v1/calls/{call_id}/payments", dependencies=[Depends(api_key)])
    def payment(call_id: str, b: Payment) -> Response:
        return outage_wrap(lambda: {"payment_session_id": engine.start_secure_payment(
            call_id, b.amount_minor, b.currency, b.request_id)})

    @app.post("/v1/calls/{call_id}/monitor", dependencies=[Depends(api_key)])
    def monitor(call_id: str, b: Monitor) -> Response:
        return outage_wrap(lambda: {"leg_id": engine.start_monitoring(call_id, b.identity, b.mode, b.request_id).id})

    @app.post("/v1/calls/{call_id}/legs/{leg_id}/monitor-stop", dependencies=[Depends(api_key)])
    def monitor_stop(call_id: str, leg_id: str, b: ReqOnly) -> Response:
        return outage_wrap(lambda: engine.stop_monitoring(call_id, leg_id, b.request_id))

    @app.get("/v1/calls/{call_id}", dependencies=[Depends(api_key)])
    def get_call(call_id: str) -> Response:
        return outage_wrap(lambda: engine.call_state(call_id), status=200)

    @app.get("/v1/calls", dependencies=[Depends(api_key)])
    def list_calls() -> Response:
        return outage_wrap(lambda: {"calls": engine.active_calls()}, status=200)

    @app.get("/v1/recordings/{recording_id}/media", dependencies=[Depends(api_key)])
    def media(recording_id: str) -> Response:
        rec = engine.recordings.get(recording_id)
        if rec is None:
            raise HTTPException(404)
        return Response(synthetic_wav(rec.get("duration", 2.0)), media_type="audio/wav",
                        headers={"X-Synthetic-Media": "true"})

    # -------------------------------------------------------------- demo world
    @app.post("/v1/demo/inbound", dependencies=[Depends(api_key)])
    def demo_inbound(b: InboundCall) -> Response:
        return outage_wrap(lambda: {"call_id": engine.inbound_call(
            b.from_number, b.to_number, ivr_digits=b.ivr_digits, consent_digit=b.consent_digit, script=b.script,
            hangup_after_seconds=b.hangup_after_seconds).id})

    @app.post("/v1/demo/calls/{call_id}/customer-hangup", dependencies=[Depends(api_key)])
    def demo_hangup(call_id: str) -> Response:
        engine.customer_hangup(call_id)
        return JSONResponse({"ok": True})

    @app.post("/v1/demo/calls/{call_id}/dtmf", dependencies=[Depends(api_key)])
    def demo_dtmf(call_id: str, body: dict[str, str]) -> Response:
        engine.send_dtmf(call_id, body["digits"])
        return JSONResponse({"ok": True})

    @app.post("/v1/demo/devices/{identity}/drop", dependencies=[Depends(api_key)])
    def demo_drop_device(identity: str) -> Response:
        engine.unregister_device(identity, "network_lost")
        return JSONResponse({"ok": True})

    @app.get("/v1/demo/faults", dependencies=[Depends(api_key)])
    def get_faults() -> Response:
        return JSONResponse(engine.faults)

    @app.put("/v1/demo/faults", dependencies=[Depends(api_key)])
    def set_faults(body: dict[str, Any]) -> Response:
        unknown = set(body) - set(DEFAULT_FAULTS)
        if unknown:
            raise HTTPException(422, f"unknown faults: {sorted(unknown)}")
        engine.faults.update(body)
        if body.get("outage") is None and "outage" in body:
            engine.flush_reorder_buffer()
        return JSONResponse(engine.faults)

    @app.post("/v1/demo/faults/reset", dependencies=[Depends(api_key)])
    def reset_faults() -> Response:
        engine.faults.clear()
        engine.faults.update(DEFAULT_FAULTS)
        return JSONResponse(engine.faults)

    @app.get("/v1/demo/events", dependencies=[Depends(api_key)])
    def event_log(limit: int = 100) -> Response:
        return JSONResponse({"events": engine.event_log[-limit:]})

    return app


def main() -> None:  # pragma: no cover
    import uvicorn

    logging.basicConfig(level=logging.INFO)
    uvicorn.run(create_app(), host=os.environ.get("SIM_HOST", "0.0.0.0"), port=int(os.environ.get("SIM_PORT", "8090")))


if __name__ == "__main__":  # pragma: no cover
    main()
