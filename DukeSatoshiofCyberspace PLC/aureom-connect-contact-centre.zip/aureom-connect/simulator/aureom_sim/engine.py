"""Simulated telephony provider engine.

This is a *signalling* simulator. It models calls, legs, devices, recording
and transfers, and emits provider-style webhook events. It carries **no
audio** and does not implement codecs or media transport.

Deliberate realism:
* control requests are acknowledged asynchronously via events;
* events carry a per-call sequence number and provider timestamp;
* faults can be injected: duplicate, reordered, delayed or dropped events,
  provider outage (refuse / blackhole), devices that fail to answer,
  consult targets that reject, unanswered outbound calls.
"""
from __future__ import annotations

import heapq
import itertools
import threading
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable

TERMINAL = {"completed", "failed", "no_answer", "busy", "rejected"}


def _id(prefix: str) -> str:
    return f"{prefix}{uuid.uuid4().hex[:20]}"


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class SimLeg:
    id: str
    call_id: str
    leg_type: str  # customer | agent | consult | supervisor
    identity: str | None = None
    number: str | None = None
    status: str = "initiated"
    on_hold: bool = False
    muted: bool = False
    end_reason: str | None = None


@dataclass
class SimCall:
    id: str
    direction: str
    from_number: str
    to_number: str
    status: str = "in_progress"
    legs: dict[str, SimLeg] = field(default_factory=dict)
    seq: int = 0
    agent_leg_id: str | None = None
    customer_leg_id: str | None = None
    consult_leg_id: str | None = None
    recording: dict[str, Any] | None = None
    script: list[dict[str, Any]] = field(default_factory=list)
    end_reason: str | None = None
    created_at: float = field(default_factory=time.time)


@dataclass
class SimDevice:
    identity: str
    device_id: str
    registered: bool
    last_heartbeat: float
    seq: int = 0


DEFAULT_FAULTS: dict[str, Any] = {
    "outage": None,  # None | "refuse" | "blackhole"
    "duplicate_next": 0,  # deliver the next N events twice
    "reorder_next": 0,  # swap delivery order of the next N event pairs
    "drop_types": [],  # event types silently dropped
    "delay_ms": 0,
    "agent_answer_fails": False,
    "consult_target_behaviour": "app_controlled",  # app_controlled | reject | no_answer
    "outbound_outcome": "answer",  # answer | no_answer | busy
    "customer_hangup_after_seconds": None,
}


class OutageError(Exception):
    def __init__(self, mode: str):
        super().__init__(mode)
        self.mode = mode


class SimEngine:
    """Thread-safe simulator core. ``emit`` receives fully-formed event dicts."""

    def __init__(self, emit: Callable[[dict[str, Any]], None], *, realtime: bool = True,
                 device_timeout_seconds: float = 45.0, consult_timeout_seconds: float = 30.0):
        self._emit_fn = emit
        self.realtime = realtime
        self.lock = threading.RLock()
        self.calls: dict[str, SimCall] = {}
        self.devices: dict[str, SimDevice] = {}
        self.recordings: dict[str, dict[str, Any]] = {}
        self.faults: dict[str, Any] = dict(DEFAULT_FAULTS)
        self._timers: list[tuple[float, int, Callable[[], None]]] = []
        self._counter = itertools.count()
        self._held_for_reorder: list[dict[str, Any]] = []
        self.device_timeout_seconds = device_timeout_seconds
        self.consult_timeout_seconds = consult_timeout_seconds
        self.event_log: list[dict[str, Any]] = []
        self._consult_reported: set[str] = set()

    # ------------------------------------------------------------------ scheduling
    def schedule(self, delay: float, fn: Callable[[], None]) -> None:
        with self.lock:
            heapq.heappush(self._timers, (time.monotonic() + delay, next(self._counter), fn))

    def run_due(self) -> int:
        """Run timers that are due (realtime mode). Returns number executed."""
        ran = 0
        while True:
            with self.lock:
                if not self._timers or self._timers[0][0] > time.monotonic():
                    break
                _, _, fn = heapq.heappop(self._timers)
            fn()
            ran += 1
        self._check_device_timeouts()
        return ran

    def run_all(self, max_steps: int = 1000) -> int:
        """Run every scheduled timer regardless of due time (deterministic tests)."""
        ran = 0
        while ran < max_steps:
            with self.lock:
                if not self._timers:
                    break
                _, _, fn = heapq.heappop(self._timers)
            fn()
            ran += 1
        return ran

    def pending_timers(self) -> int:
        return len(self._timers)

    # ------------------------------------------------------------------ outage
    def guard(self) -> None:
        mode = self.faults.get("outage")
        if mode == "refuse":
            raise OutageError("refuse")

    def lost_response(self) -> bool:
        return self.faults.get("outage") == "blackhole"

    # ------------------------------------------------------------------ events
    def _emit(self, type_: str, call: SimCall | None = None, leg: SimLeg | None = None, *,
              request_id: str | None = None, device: SimDevice | None = None, **data: Any) -> None:
        with self.lock:
            if call is not None:
                call.seq += 1
                seq = call.seq
            elif device is not None:
                device.seq += 1
                seq = device.seq
            else:
                seq = None
            event = {
                "id": _id("EV"), "type": type_, "occurred_at": _now_iso(), "sequence": seq,
                "call_id": call.id if call else None, "leg_id": leg.id if leg else None,
                "request_id": request_id, "data": data,
            }
            self.event_log.append(event)
            if self.faults.get("outage") in ("refuse", "blackhole"):
                event["_dropped"] = "outage"
                return
            if type_ in (self.faults.get("drop_types") or []):
                event["_dropped"] = "fault"
                return
            deliveries = [event]
            if self.faults.get("duplicate_next", 0) > 0:
                self.faults["duplicate_next"] -= 1
                deliveries.append(dict(event))
            if self.faults.get("reorder_next", 0) > 0 and not self._held_for_reorder:
                self.faults["reorder_next"] -= 1
                self._held_for_reorder.append(event)
                return
            if self._held_for_reorder:
                deliveries.extend(self._held_for_reorder)
                self._held_for_reorder.clear()
        for ev in deliveries:
            self._emit_fn(ev)

    def flush_reorder_buffer(self) -> None:
        with self.lock:
            held = list(self._held_for_reorder)
            self._held_for_reorder.clear()
        for ev in held:
            self._emit_fn(ev)

    # ------------------------------------------------------------------ devices
    def register_device(self, identity: str) -> SimDevice:
        self.guard()
        with self.lock:
            dev = self.devices.get(identity)
            if dev is None:
                dev = SimDevice(identity=identity, device_id=_id("DV"), registered=True, last_heartbeat=time.time())
                self.devices[identity] = dev
            else:
                dev.registered = True
                dev.last_heartbeat = time.time()
                dev.device_id = _id("DV")
        self._emit("device.registered", device=dev, identity=identity, device_id=dev.device_id)
        return dev

    def heartbeat(self, identity: str) -> bool:
        self.guard()
        with self.lock:
            dev = self.devices.get(identity)
            if dev is None or not dev.registered:
                return False
            dev.last_heartbeat = time.time()
            return True

    def unregister_device(self, identity: str, reason: str = "client_unregistered") -> None:
        with self.lock:
            dev = self.devices.get(identity)
            if dev is None or not dev.registered:
                return
            dev.registered = False
        self._emit("device.unregistered", device=dev, identity=identity, reason=reason)

    def _check_device_timeouts(self) -> None:
        cutoff = time.time() - self.device_timeout_seconds
        stale = [d.identity for d in list(self.devices.values()) if d.registered and d.last_heartbeat < cutoff]
        for identity in stale:
            self.unregister_device(identity, "heartbeat_timeout")

    def device_ok(self, identity: str) -> bool:
        dev = self.devices.get(identity)
        return bool(dev and dev.registered)

    # ------------------------------------------------------------------ calls
    def _call(self, call_id: str) -> SimCall:
        call = self.calls.get(call_id)
        if call is None:
            raise KeyError(call_id)
        return call

    def _leg(self, call: SimCall, leg_id: str) -> SimLeg:
        leg = call.legs.get(leg_id)
        if leg is None:
            raise KeyError(leg_id)
        return leg

    def inbound_call(self, from_number: str, to_number: str, *, ivr_digits: str | None = None,
                     consent_digit: str | None = None, script: list[dict[str, Any]] | None = None,
                     hangup_after_seconds: float | None = None) -> SimCall:
        self.guard()
        with self.lock:
            call = SimCall(id=_id("CA"), direction="inbound", from_number=from_number, to_number=to_number,
                           script=script or [])
            leg = SimLeg(id=_id("LG"), call_id=call.id, leg_type="customer", number=from_number, status="answered")
            call.legs[leg.id] = leg
            call.customer_leg_id = leg.id
            self.calls[call.id] = call
        self._emit("call.initiated", call, leg, direction="inbound", from_number=from_number, to_number=to_number,
                   customer_leg_id=leg.id)
        self._emit("leg.answered", call, leg, leg_type="customer", answered_by="ivr")
        if ivr_digits:
            self.schedule(0.3, lambda: self._ivr(call.id, ivr_digits, consent_digit))
        if hangup_after_seconds:
            self.schedule(hangup_after_seconds, lambda: self.customer_hangup(call.id))
        return call

    def _ivr(self, call_id: str, digits: str, consent_digit: str | None) -> None:
        call = self.calls.get(call_id)
        if call is None or call.status != "in_progress":
            return
        self._emit("ivr.input", call, call.legs[call.customer_leg_id], digits=digits, consent_digit=consent_digit)

    def send_dtmf(self, call_id: str, digits: str) -> None:
        call = self._call(call_id)
        self._emit("ivr.input", call, call.legs[call.customer_leg_id], digits=digits)

    def connect_agent(self, call_id: str, identity: str, request_id: str) -> SimLeg:
        self.guard()
        with self.lock:
            call = self._call(call_id)
            if call.status != "in_progress":
                raise ValueError("call_not_in_progress")
            leg = SimLeg(id=_id("LG"), call_id=call.id, leg_type="agent", identity=identity, status="ringing")
            call.legs[leg.id] = leg
        self._emit("leg.ringing", call, leg, leg_type="agent", identity=identity, request_id=request_id)

        def answer() -> None:
            with self.lock:
                if leg.status != "ringing" or call.status != "in_progress":
                    return
                if not self.device_ok(identity):
                    leg.status, leg.end_reason = "failed", "device_unavailable"
                elif self.faults.get("agent_answer_fails"):
                    leg.status, leg.end_reason = "failed", "no_answer"
                else:
                    leg.status = "answered"
                    call.agent_leg_id = leg.id
            if leg.status == "answered":
                self._emit("leg.answered", call, leg, leg_type="agent", identity=identity, request_id=request_id)
                self._maybe_auto_customer_hangup(call)
            else:
                self._emit("leg.failed", call, leg, leg_type="agent", identity=identity, reason=leg.end_reason,
                           request_id=request_id)

        self.schedule(0.25, answer)
        return leg

    def _maybe_auto_customer_hangup(self, call: SimCall) -> None:
        after = self.faults.get("customer_hangup_after_seconds")
        if after:
            self.schedule(float(after), lambda: self.customer_hangup(call.id))

    def answer_leg(self, call_id: str, leg_id: str, request_id: str) -> None:
        self.guard()
        call = self._call(call_id)
        leg = self._leg(call, leg_id)
        with self.lock:
            if leg.status != "ringing":
                raise ValueError("leg_not_ringing")
            if leg.identity and not self.device_ok(leg.identity):
                leg.status, leg.end_reason = "failed", "device_unavailable"
            else:
                leg.status = "answered"
        if leg.status == "answered":
            self._emit("leg.answered", call, leg, leg_type=leg.leg_type, identity=leg.identity, request_id=request_id)
        else:
            self._consult_failed(call, leg, "device_unavailable", request_id)

    def reject_leg(self, call_id: str, leg_id: str, request_id: str) -> None:
        self.guard()
        call = self._call(call_id)
        leg = self._leg(call, leg_id)
        with self.lock:
            if leg.status in TERMINAL:
                raise ValueError("leg_already_ended")
            if leg.leg_type != "consult":
                leg.status, leg.end_reason = "rejected", "rejected"
        if leg.leg_type == "consult":
            self._consult_failed(call, leg, "rejected", request_id)
        else:
            self._emit("leg.failed", call, leg, leg_type=leg.leg_type, identity=leg.identity, reason="rejected",
                       request_id=request_id)

    def hold(self, call_id: str, leg_id: str, request_id: str, held: bool) -> None:
        self.guard()
        call = self._call(call_id)
        leg = self._leg(call, leg_id)
        with self.lock:
            if leg.status != "answered":
                raise ValueError("leg_not_answered")
            leg.on_hold = held
        self._emit("leg.held" if held else "leg.resumed", call, leg, leg_type=leg.leg_type, request_id=request_id)
        if call.recording and call.recording["status"] in ("active", "paused"):
            # Provider policy in the simulator: recording continues through hold (hold music recorded).
            pass

    def mute(self, call_id: str, leg_id: str, request_id: str, muted: bool) -> None:
        self.guard()
        call = self._call(call_id)
        leg = self._leg(call, leg_id)
        with self.lock:
            if leg.status != "answered":
                raise ValueError("leg_not_answered")
            leg.muted = muted
        self._emit("leg.muted" if muted else "leg.unmuted", call, leg, leg_type=leg.leg_type, request_id=request_id)

    def start_consult(self, call_id: str, identity: str, request_id: str) -> SimLeg:
        self.guard()
        call = self._call(call_id)
        with self.lock:
            if call.status != "in_progress":
                raise ValueError("call_not_in_progress")
            if call.consult_leg_id and call.legs[call.consult_leg_id].status not in TERMINAL:
                raise ValueError("consult_already_active")
            cust = call.legs[call.customer_leg_id]
            was_held = cust.on_hold
            cust.on_hold = True
            leg = SimLeg(id=_id("LG"), call_id=call.id, leg_type="consult", identity=identity, status="ringing")
            call.legs[leg.id] = leg
            call.consult_leg_id = leg.id
        if not was_held:
            self._emit("leg.held", call, cust, leg_type="customer", reason="consult_started", request_id=request_id)
        self._emit("leg.ringing", call, leg, leg_type="consult", identity=identity, request_id=request_id)
        behaviour = self.faults.get("consult_target_behaviour", "app_controlled")
        if not self.device_ok(identity):
            self.schedule(0.2, lambda: self._consult_failed(call, leg, "device_unavailable", request_id))
        elif behaviour == "reject":
            self.schedule(0.5, lambda: self._consult_failed(call, leg, "rejected", request_id))
        elif behaviour == "no_answer":
            self.schedule(self.consult_timeout_seconds if self.realtime else 1.0,
                          lambda: self._consult_failed(call, leg, "no_answer", request_id))
        else:
            self.schedule(self.consult_timeout_seconds, lambda: self._consult_failed(call, leg, "no_answer", request_id))
        return leg

    def _consult_failed(self, call: SimCall, leg: SimLeg, reason: str, request_id: str | None) -> None:
        with self.lock:
            # Report each consult failure exactly once; ignore timers for answered/cancelled legs.
            if leg.id in self._consult_reported or leg.status == "answered":
                return
            if leg.status == "completed":  # cancelled by the original agent
                return
            self._consult_reported.add(leg.id)
            leg.status = "rejected" if reason == "rejected" else "failed"
            leg.end_reason = reason
            if call.consult_leg_id == leg.id:
                call.consult_leg_id = None
            cust = call.legs.get(call.customer_leg_id)
        self._emit("leg.failed", call, leg, leg_type="consult", identity=leg.identity, reason=reason,
                   request_id=request_id)
        # Configured behaviour: the customer stays on hold with the original agent.
        self._emit("transfer.failed", call, leg, reason=reason, behaviour="return_to_original",
                   customer_leg_id=cust.id if cust else None, customer_on_hold=bool(cust and cust.on_hold),
                   request_id=request_id)

    def complete_transfer(self, call_id: str, consult_leg_id: str, request_id: str) -> None:
        self.guard()
        call = self._call(call_id)
        consult = self._leg(call, consult_leg_id)
        with self.lock:
            if consult.status != "answered":
                raise ValueError("consult_not_answered")
            old_agent = call.legs.get(call.agent_leg_id) if call.agent_leg_id else None
            if old_agent:
                old_agent.status, old_agent.end_reason = "completed", "transferred"
            cust = call.legs[call.customer_leg_id]
            cust.on_hold = False
            call.agent_leg_id = consult.id
            call.consult_leg_id = None
        if old_agent:
            self._emit("leg.completed", call, old_agent, leg_type="agent", identity=old_agent.identity,
                       reason="transferred", request_id=request_id)
        self._emit("leg.resumed", call, cust, leg_type="customer", reason="transfer_completed", request_id=request_id)
        self._emit("transfer.completed", call, consult, mode="warm", from_leg_id=old_agent.id if old_agent else None,
                   to_leg_id=consult.id, to_identity=consult.identity, request_id=request_id)

    def cancel_consult(self, call_id: str, consult_leg_id: str, request_id: str) -> None:
        self.guard()
        call = self._call(call_id)
        consult = self._leg(call, consult_leg_id)
        with self.lock:
            if consult.status in TERMINAL:
                raise ValueError("consult_already_ended")
            consult.status, consult.end_reason = "completed", "cancelled"
            call.consult_leg_id = None
        self._emit("leg.completed", call, consult, leg_type="consult", identity=consult.identity, reason="cancelled",
                   request_id=request_id)
        self._emit("transfer.cancelled", call, consult, request_id=request_id)

    def blind_transfer(self, call_id: str, agent_leg_id: str, request_id: str) -> None:
        self.guard()
        call = self._call(call_id)
        leg = self._leg(call, agent_leg_id)
        with self.lock:
            leg.status, leg.end_reason = "completed", "blind_transferred"
            call.agent_leg_id = None
            cust = call.legs[call.customer_leg_id]
            cust.on_hold = True
        self._emit("leg.completed", call, leg, leg_type="agent", identity=leg.identity, reason="blind_transferred",
                   request_id=request_id)
        self._emit("transfer.completed", call, cust, mode="blind", from_leg_id=leg.id, request_id=request_id)

    def conference(self, call_id: str, consult_leg_id: str, request_id: str) -> None:
        self.guard()
        call = self._call(call_id)
        consult = self._leg(call, consult_leg_id)
        with self.lock:
            if consult.status != "answered":
                raise ValueError("consult_not_answered")
            cust = call.legs[call.customer_leg_id]
            cust.on_hold = False
            call.consult_leg_id = None
        self._emit("leg.resumed", call, cust, leg_type="customer", reason="conference", request_id=request_id)
        self._emit("conference.started", call, consult,
                   legs=[lg.id for lg in call.legs.values() if lg.status == "answered"], request_id=request_id)

    def hangup(self, call_id: str, request_id: str | None, reason: str = "agent_hangup") -> None:
        if request_id is not None:
            self.guard()
        call = self._call(call_id)
        with self.lock:
            if call.status != "in_progress":
                raise ValueError("call_not_in_progress")
            call.status, call.end_reason = "completed", reason
            ended = [lg for lg in call.legs.values() if lg.status not in TERMINAL]
            for lg in ended:
                lg.status, lg.end_reason = ("completed" if lg.status == "answered" else "failed"), reason
        for lg in ended:
            self._emit("leg.completed", call, lg, leg_type=lg.leg_type, identity=lg.identity, reason=reason,
                       request_id=request_id)
        self._emit("call.completed", call, None, end_reason=reason, request_id=request_id)
        self._finish_recording(call)
        if call.script:
            self.schedule(0.4, lambda: self._emit("transcript.available", call, None,
                                                  engine="aureom-sim-transcriber", engine_version="0.3.0",
                                                  simulated=True, language="en", segments=call.script))

    def customer_hangup(self, call_id: str) -> None:
        call = self.calls.get(call_id)
        if call is None or call.status != "in_progress":
            return
        self.hangup(call_id, None, reason="customer_hangup")

    def dial(self, from_number: str, to_number: str, identity: str, request_id: str) -> SimCall:
        self.guard()
        with self.lock:
            call = SimCall(id=_id("CA"), direction="outbound", from_number=from_number, to_number=to_number)
            agent_leg = SimLeg(id=_id("LG"), call_id=call.id, leg_type="agent", identity=identity, status="ringing")
            cust = SimLeg(id=_id("LG"), call_id=call.id, leg_type="customer", number=to_number, status="initiated")
            call.legs[agent_leg.id] = agent_leg
            call.legs[cust.id] = cust
            call.customer_leg_id = cust.id
            self.calls[call.id] = call
        self._emit("call.initiated", call, None, direction="outbound", from_number=from_number, to_number=to_number,
                   customer_leg_id=cust.id, agent_leg_id=agent_leg.id, request_id=request_id)

        def agent_answers() -> None:
            if not self.device_ok(identity):
                agent_leg.status = "failed"
                self._emit("leg.failed", call, agent_leg, leg_type="agent", identity=identity,
                           reason="device_unavailable", request_id=request_id)
                self.hangup(call.id, None, reason="agent_device_unavailable")
                return
            agent_leg.status = "answered"
            call.agent_leg_id = agent_leg.id
            self._emit("leg.answered", call, agent_leg, leg_type="agent", identity=identity, request_id=request_id)
            cust.status = "ringing"
            self._emit("leg.ringing", call, cust, leg_type="customer", number=to_number, request_id=request_id)
            outcome = self.faults.get("outbound_outcome", "answer")
            if to_number.endswith("0000"):
                outcome = "no_answer"
            self.schedule(1.0 if outcome == "answer" else 2.0, lambda: customer_outcome(outcome))

        def customer_outcome(outcome: str) -> None:
            if call.status != "in_progress" or cust.status != "ringing":
                return
            if outcome == "answer":
                cust.status = "answered"
                self._emit("leg.answered", call, cust, leg_type="customer", number=to_number, request_id=request_id)
                self._maybe_auto_customer_hangup(call)
            else:
                cust.status = outcome
                self._emit("leg.failed", call, cust, leg_type="customer", number=to_number, reason=outcome,
                           request_id=request_id)
                self.hangup(call.id, None, reason=outcome)

        self.schedule(0.2, agent_answers)
        return call

    # ------------------------------------------------------------------ recording / notices / payment
    def play_notice(self, call_id: str, text: str, request_id: str) -> None:
        self.guard()
        call = self._call(call_id)
        self.schedule(0.2, lambda: self._emit("notice.played", call, None, text=text, request_id=request_id))

    def start_recording(self, call_id: str, request_id: str) -> str:
        self.guard()
        call = self._call(call_id)
        with self.lock:
            if call.status != "in_progress":
                raise ValueError("call_not_in_progress")
            if call.recording and call.recording["status"] in ("active", "paused"):
                return call.recording["id"]
            rec = {"id": _id("RE"), "status": "active", "started": time.time(), "call_id": call.id}
            call.recording = rec
            self.recordings[rec["id"]] = rec
        self.schedule(0.15, lambda: self._emit("recording.started", call, None, recording_id=rec["id"],
                                               request_id=request_id))
        return rec["id"]

    def set_recording_paused(self, call_id: str, paused: bool, request_id: str | None, reason: str = "agent") -> None:
        if request_id is not None:
            self.guard()
        call = self._call(call_id)
        with self.lock:
            rec = call.recording
            if not rec or rec["status"] not in ("active", "paused"):
                raise ValueError("not_recording")
            rec["status"] = "paused" if paused else "active"
        self._emit("recording.paused" if paused else "recording.resumed", call, None, recording_id=rec["id"],
                   reason=reason, request_id=request_id)

    def _finish_recording(self, call: SimCall) -> None:
        rec = call.recording
        if not rec or rec["status"] not in ("active", "paused"):
            return
        rec["status"] = "stopped"
        rec["duration"] = round(time.time() - rec["started"], 1)
        self._emit("recording.stopped", call, None, recording_id=rec["id"])
        self.schedule(0.3, lambda: self._emit("recording.available", call, None, recording_id=rec["id"],
                                              content_type="audio/wav", duration_seconds=rec["duration"],
                                              synthetic_media=True))

    def start_secure_payment(self, call_id: str, amount_minor: int, currency: str, request_id: str) -> str:
        self.guard()
        call = self._call(call_id)
        session_id = _id("PY")
        rec_active = bool(call.recording and call.recording["status"] == "active")
        if rec_active:
            self.set_recording_paused(call_id, True, None, reason="secure_payment")
        self._emit("payment.started", call, None, payment_session_id=session_id, amount_minor=amount_minor,
                   currency=currency, recording_paused=rec_active, request_id=request_id)

        def done() -> None:
            # The simulator never receives or emits card data; it reports an opaque reference only.
            self._emit("payment.completed", call, None, payment_session_id=session_id, result="approved",
                       reference=_id("PAYREF"), request_id=request_id)
            if rec_active and call.status == "in_progress":
                self.set_recording_paused(call_id, False, None, reason="secure_payment_finished")

        self.schedule(1.5, done)
        return session_id

    def start_monitoring(self, call_id: str, identity: str, mode: str, request_id: str) -> SimLeg:
        self.guard()
        call = self._call(call_id)
        with self.lock:
            leg = SimLeg(id=_id("LG"), call_id=call.id, leg_type="supervisor", identity=identity, status="answered")
            call.legs[leg.id] = leg
        self._emit("monitor.started", call, leg, mode=mode, identity=identity, request_id=request_id)
        return leg

    def stop_monitoring(self, call_id: str, leg_id: str, request_id: str) -> None:
        self.guard()
        call = self._call(call_id)
        leg = self._leg(call, leg_id)
        leg.status = "completed"
        self._emit("monitor.ended", call, leg, request_id=request_id)

    # ------------------------------------------------------------------ queries
    def call_state(self, call_id: str) -> dict[str, Any]:
        call = self._call(call_id)
        return {
            "provider_call_id": call.id, "status": call.status, "sequence": call.seq, "end_reason": call.end_reason,
            "recording_status": call.recording["status"] if call.recording else None,
            "legs": [{"provider_leg_id": lg.id, "leg_type": lg.leg_type, "identity": lg.identity, "number": lg.number,
                      "status": lg.status, "on_hold": lg.on_hold, "muted": lg.muted} for lg in call.legs.values()],
        }

    def active_calls(self) -> list[dict[str, Any]]:
        return [self.call_state(c.id) for c in self.calls.values() if c.status == "in_progress"]
