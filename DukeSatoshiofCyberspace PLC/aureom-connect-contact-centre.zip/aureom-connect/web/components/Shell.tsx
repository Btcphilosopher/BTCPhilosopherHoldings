"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Fragment, useEffect, useState, type ComponentType, type ReactNode } from "react";
import { api, getSession, setSession, type Session } from "@/lib/api";
import { EventsProvider, useEvents } from "@/lib/events";
import { softphone } from "@/lib/softphone";
import { Badge } from "./ui";

export interface NavItem {
  href: string;
  label: string;
  icon: string;
}

export const AGENT_NAV: NavItem[] = [
  { href: "/agent", label: "Workspace", icon: "▣" },
  { href: "/agent/customers", label: "Customers", icon: "◉" },
  { href: "/agent/inbox", label: "Inbox", icon: "✉" },
  { href: "/agent/tasks", label: "Tasks", icon: "☑" },
  { href: "/agent/knowledge", label: "Knowledge", icon: "❖" },
  { href: "/agent/schedule", label: "My schedule", icon: "◷" },
];

export const SUPERVISOR_NAV: NavItem[] = [
  { href: "/supervisor", label: "Live operations", icon: "◎" },
  { href: "/supervisor/queues", label: "Queues", icon: "≡" },
  { href: "/supervisor/agents", label: "Agents", icon: "☺" },
  { href: "/supervisor/campaigns", label: "Campaigns", icon: "➚" },
  { href: "/supervisor/quality", label: "Quality", icon: "★" },
  { href: "/supervisor/reports", label: "Reports", icon: "▤" },
  { href: "/supervisor/admin", label: "Administration", icon: "⚙" },
];

function ConnectionBadge() {
  const { connected } = useEvents();
  return connected ? (
    <Badge tone="green" title="Application event stream connected">Events: connected</Badge>
  ) : (
    <Badge tone="amber" title="Reconnecting; state will be re-read on reconnect">⚠ Events: reconnecting</Badge>
  );
}

type FrameProps = { nav: NavItem[]; area: string; children: ReactNode; topbar?: ReactNode;
  provider?: ComponentType<{ children: ReactNode }> };

function Frame({ nav, area, children, topbar, provider }: FrameProps) {
  const path = usePathname();
  const router = useRouter();
  const [session, setS] = useState<Session | null>(null);
  useEffect(() => {
    const s = getSession();
    if (!s) router.replace("/");
    else setS(s);
  }, [router]);
  if (!session) return null;
  const logout = async () => {
    try {
      await softphone.unregister();
      if (session.user.agent_id) {
        await api("/v1/agents/me/availability", { method: "PUT", body: { state: "offline", reason: "signed out" } })
          .catch(() => undefined);
      }
      await api("/v1/auth/logout", { body: { refresh_token: session.refreshToken } });
    } catch {
      /* best effort */
    }
    setSession(null);
    router.replace("/");
  };
  const Wrap = provider ?? Fragment;
  const canSupervise = session.user.permissions.includes("ops.read");
  const isAgent = !!session.user.agent_id;
  return (
    <div className="shell">
      <a href="#main" className="skip-link">Skip to main content</a>
      <nav className="nav" aria-label={`${area} navigation`}>
        <div className="nav-brand">
          <strong>AUREOM CONNECT</strong>
          <span>Contact Centre · {area}</span>
        </div>
        <ul>
          {nav.map((n) => {
            const active = n.href === path || (n.href !== "/agent" && n.href !== "/supervisor" && path.startsWith(n.href));
            return (
              <li key={n.href}>
                <Link href={n.href} aria-current={active ? "page" : undefined}>
                  <span aria-hidden>{n.icon}</span> {n.label}
                </Link>
              </li>
            );
          })}
        </ul>
        <div className="nav-foot">
          <div>{session.user.display_name}</div>
          <div className="small">{session.user.roles.join(", ")}{session.user.mfa ? " · MFA" : ""}</div>
          {canSupervise && area === "Agent" ? <div><Link href="/supervisor" style={{ color: "#5eead4" }}>Supervisor console →</Link></div> : null}
          {isAgent && area !== "Agent" ? <div><Link href="/agent" style={{ color: "#5eead4" }}>Agent workspace →</Link></div> : null}
          <button className="btn btn-sm" onClick={logout}>Sign out</button>
        </div>
      </nav>
      <div className="main">
        <Wrap>
          <header className="topbar">
            {topbar}
            <span className="spacer" />
            <ConnectionBadge />
          </header>
          <main id="main" className="content" tabIndex={-1}>
            {children}
          </main>
        </Wrap>
      </div>
    </div>
  );
}

export function AppFrame(props: FrameProps) {
  return (
    <EventsProvider>
      <Frame {...props} />
    </EventsProvider>
  );
}
