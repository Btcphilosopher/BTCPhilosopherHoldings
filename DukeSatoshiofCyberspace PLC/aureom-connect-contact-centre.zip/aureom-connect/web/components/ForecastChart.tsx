"use client";

/**
 * Forecast (expected line + 80 % band) vs observed demand (bars), one y-axis.
 * Palette slots 1 (blue) and 2 (orange) validated with the dataviz validator:
 * all checks pass; orange is below 3:1 on white, so a table view is always present.
 */
import { useMemo, useState } from "react";
import type { Json } from "@/lib/api";

const FORECAST = "#257de0";
const OBSERVED = "#f47230";
const GRID = "#e6e9ef";
const TEXT = "#586174";

export function ForecastChart({ rows }: { rows: Json[] }) {
  const [hover, setHover] = useState<number | null>(null);
  const data = useMemo(() => rows.filter((r) => r.forecast_expected !== null || r.observed_offered), [rows]);
  if (!data.length) return <p className="muted small">No forecast or observed intervals for this day.</p>;
  const W = 1200, H = 300, padL = 44, padR = 12, padT = 14, padB = 32;
  const max = Math.max(1, ...data.map((r) => Math.max(r.forecast_range?.[1] ?? 0, r.observed_offered ?? 0)));
  const niceMax = Math.ceil(max / 4) * 4;
  const step = (W - padL - padR) / data.length;
  const x = (i: number) => padL + step * i + step / 2;
  const y = (v: number) => padT + (H - padT - padB) * (1 - v / niceMax);
  const bw = Math.min(24, step * 0.55);
  const band = data.map((r, i) => `${x(i)},${y(r.forecast_range?.[1] ?? r.forecast_expected ?? 0)}`).join(" ") + " " +
    [...data].reverse().map((r, j) => `${x(data.length - 1 - j)},${y(r.forecast_range?.[0] ?? r.forecast_expected ?? 0)}`).join(" ");
  const line = data.map((r, i) => `${i ? "L" : "M"}${x(i)},${y(r.forecast_expected ?? 0)}`).join(" ");
  const ticks = [0, niceMax / 4, niceMax / 2, (3 * niceMax) / 4, niceMax];
  const label = (iso: string) => new Date(iso).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
  const h = hover !== null ? data[hover] : null;
  return (
    <figure style={{ margin: 0 }}>
      <figcaption className="row small" style={{ marginBottom: 6 }}>
        <strong>Contacts per 30 minutes</strong>
        <span className="row"><svg width="18" height="8" aria-hidden><line x1="0" y1="4" x2="18" y2="4" stroke={FORECAST} strokeWidth="2" /></svg>Forecast (expected)</span>
        <span className="row"><svg width="14" height="10" aria-hidden><rect width="14" height="10" fill={FORECAST} opacity="0.1" /></svg>80% range</span>
        <span className="row"><svg width="10" height="10" aria-hidden><rect width="10" height="10" rx="2" fill={OBSERVED} /></svg>Observed (today)</span>
      </figcaption>
      <div style={{ position: "relative" }}>
        <svg viewBox={`0 0 ${W} ${H}`} width="100%" role="img" aria-label="Forecast band and expected volume compared with observed contacts"
          onPointerLeave={() => setHover(null)}>
          {ticks.map((t) => (
            <g key={t}>
              <line x1={padL} x2={W - padR} y1={y(t)} y2={y(t)} stroke={GRID} strokeWidth="1" />
              <text x={padL - 6} y={y(t) + 4} fontSize="12" textAnchor="end" fill={TEXT}>{t}</text>
            </g>
          ))}
          <polygon points={band} fill={FORECAST} opacity="0.1" />
          {data.map((r, i) => r.observed_offered ? (
            <path key={`b${i}`} fill={OBSERVED}
              d={`M${x(i) - bw / 2},${y(0)} V${y(r.observed_offered) + 4} q0,-4 4,-4 H${x(i) + bw / 2 - 4} q4,0 4,4 V${y(0)} Z`} />
          ) : null)}
          <path d={line} fill="none" stroke={FORECAST} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
          {data.map((r, i) => (i % Math.max(1, Math.round(data.length / 10)) === 0 ? (
            <text key={`t${i}`} x={x(i)} y={H - 10} fontSize="12" textAnchor="middle" fill={TEXT}>{label(r.interval)}</text>
          ) : null))}
          <line x1={padL} x2={W - padR} y1={y(0)} y2={y(0)} stroke="#c3cad6" strokeWidth="1" />
          {hover !== null ? <line x1={x(hover)} x2={x(hover)} y1={padT} y2={y(0)} stroke="#98a2b3" strokeWidth="1" /> : null}
          {data.map((r, i) => (
            <rect key={`h${i}`} x={x(i) - step / 2} y={padT} width={step} height={H - padT - padB} fill="transparent"
              tabIndex={0} aria-label={`${label(r.interval)}: expected ${r.forecast_expected ?? "n/a"}, observed ${r.observed_offered ?? 0}`}
              onPointerMove={() => setHover(i)} onFocus={() => setHover(i)} onBlur={() => setHover(null)} />
          ))}
        </svg>
        {h ? (
          <div role="tooltip" style={{ position: "absolute", top: 4, left: `min(calc(${(x(hover!) / W) * 100}% + 12px), calc(100% - 210px))`,
            background: "#fff", border: "1px solid var(--border)", borderRadius: 6, padding: "6px 8px", boxShadow: "var(--shadow)",
            fontSize: 12, width: 200, pointerEvents: "none" }}>
            <div className="muted">{label(h.interval)}</div>
            <div><strong>{h.forecast_expected ?? "—"}</strong> <span className="muted">expected ({h.forecast_range ? `${h.forecast_range[0]}–${h.forecast_range[1]}` : "—"})</span></div>
            <div><strong>{h.observed_offered ?? 0}</strong> <span className="muted">observed</span></div>
            <div><strong>{h.scheduled_agents}</strong> <span className="muted">scheduled / {h.required_agents} required</span></div>
          </div>
        ) : null}
      </div>
      <details>
        <summary className="small">Table view</summary>
        <div className="scroll">
          <table>
            <thead><tr><th>Interval</th><th>Expected</th><th>80% range</th><th>Observed</th><th>Required</th><th>Scheduled</th><th>Gap</th></tr></thead>
            <tbody>{data.map((r) => (
              <tr key={r.interval}><td>{label(r.interval)}</td><td>{r.forecast_expected ?? "—"}</td>
                <td>{r.forecast_range ? `${r.forecast_range[0]}–${r.forecast_range[1]}` : "—"}</td><td>{r.observed_offered ?? "—"}</td>
                <td>{r.required_agents}</td><td>{r.scheduled_agents}</td>
                <td>{r.status === "short" ? <span className="badge badge-amber">⚠ short {r.gap}</span> : r.gap}</td></tr>
            ))}</tbody>
          </table>
        </div>
      </details>
    </figure>
  );
}
