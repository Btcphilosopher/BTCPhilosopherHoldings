"use client";

import type { ReactNode } from "react";

type Tone = "teal" | "amber" | "red" | "green" | "blue" | "navy" | "neutral";

export function Badge({ tone = "neutral", children, title }: { tone?: Tone; children: ReactNode; title?: string }) {
  return (
    <span className={`badge ${tone === "neutral" ? "" : `badge-${tone}`}`} title={title}>
      {children}
    </span>
  );
}

/** Warnings are always labelled in text, never conveyed by colour alone. */
export function Banner({ kind, title, children }: { kind: "warn" | "error" | "info" | "teal"; title: string; children?: ReactNode }) {
  const role = kind === "error" ? "alert" : "status";
  const label = { warn: "Warning", error: "Failure", info: "Note", teal: "Live" }[kind];
  return (
    <div className={`banner banner-${kind}`} role={role}>
      <strong>
        {kind === "warn" ? "⚠ " : kind === "error" ? "✖ " : kind === "teal" ? "● " : "ℹ "}
        {label}:
      </strong>
      <div>
        <strong style={{ fontWeight: 700 }}>{title}</strong>
        {children ? <div className="small">{children}</div> : null}
      </div>
    </div>
  );
}

export function ErrorText({ error }: { error?: string | null }) {
  if (!error) return null;
  return (
    <div className="banner banner-error" role="alert">
      <strong>✖ Failure:</strong>
      <div className="small">{error}</div>
    </div>
  );
}

export function OkText({ message }: { message?: string | null }) {
  if (!message) return null;
  return (
    <div className="banner banner-info" role="status">
      <strong>ℹ Note:</strong>
      <div className="small">{message}</div>
    </div>
  );
}

const STATE_LABEL: Record<string, [string, Tone]> = {
  offline: ["Offline", "neutral"],
  available: ["Available", "green"],
  call_offered: ["Call offered", "blue"],
  connecting: ["Connecting", "blue"],
  on_interaction: ["On interaction", "teal"],
  after_call_work: ["After-call work", "navy"],
  break: ["Break", "neutral"],
  unavailable: ["Unavailable", "amber"],
};

export function AgentStateBadge({ state }: { state: string }) {
  const [label, tone] = STATE_LABEL[state] ?? [state, "neutral"];
  return (
    <Badge tone={tone}>
      <span className="dot" aria-hidden /> {label}
    </Badge>
  );
}

const CONTROL_LABEL: Record<string, [string, Tone, string]> = {
  requested: ["Requested", "blue", "Sent to the provider; waiting for confirmation"],
  acknowledged: ["Confirmed", "green", "The provider confirmed the change"],
  failed: ["Failed", "red", "The provider did not apply the change"],
  unknown: ["Outcome unknown", "amber", "No reliable response. Not retried. Reconcile before continuing."],
};

export function ControlStatus({ status }: { status: string }) {
  const [label, tone, title] = CONTROL_LABEL[status] ?? [status, "neutral", ""];
  return (
    <Badge tone={tone} title={title}>
      {tone === "amber" ? "⚠ " : tone === "red" ? "✖ " : ""}
      {label}
    </Badge>
  );
}

export function VerificationBadge({ status }: { status?: string | null }) {
  const map: Record<string, [string, Tone]> = {
    verified: ["Identity verified", "green"],
    in_progress: ["Verification in progress", "blue"],
    unverified: ["Not verified", "amber"],
    failed: ["Verification failed", "red"],
    locked: ["Verification locked", "red"],
  };
  const [label, tone] = map[status ?? "unverified"] ?? [status ?? "Not verified", "amber"];
  return <Badge tone={tone}>{tone === "amber" ? "⚠ " : tone === "red" ? "✖ " : "✔ "}{label}</Badge>;
}

export function Panel({ title, actions, children, className, id }: { title?: ReactNode; actions?: ReactNode;
  children: ReactNode; className?: string; id?: string }) {
  return (
    <section className={`panel ${className ?? ""}`} aria-labelledby={id ? `${id}-title` : undefined} id={id}>
      {title ? (
        <div className="panel-title">
          <h2 id={id ? `${id}-title` : undefined}>{title}</h2>
          {actions}
        </div>
      ) : null}
      {children}
    </section>
  );
}

export function Stat({ label, value, hint }: { label: string; value: ReactNode; hint?: string }) {
  return (
    <div className="stat" title={hint}>
      <div className="value">{value}</div>
      <div className="label">{label}</div>
    </div>
  );
}

export function Field({ label, id, children, hint }: { label: string; id: string; children: ReactNode; hint?: string }) {
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      {children}
      {hint ? <div className="small muted">{hint}</div> : null}
    </div>
  );
}

export function SimulatedBadge() {
  return (
    <Badge tone="amber" title="Telephony is simulated: provider events only, no audio is carried">
      ⚠ Simulated telephony · no audio
    </Badge>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return <p className="muted small">{children}</p>;
}
