"use client";

import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { api, type Json } from "@/lib/api";
import { useAction, useResource } from "@/lib/hooks";
import { softphone, type SoftphoneStatus } from "@/lib/softphone";
import { AgentStateBadge, Badge, SimulatedBadge } from "./ui";

interface Ctx {
  ws: Json | null;
  reload: () => void;
  error: string | null;
  phone: SoftphoneStatus;
}

const WorkspaceCtx = createContext<Ctx>({ ws: null, reload: () => {}, error: null,
  phone: { state: "idle", detail: "", media: "" } });

export function WorkspaceProvider({ children }: { children: ReactNode }) {
  const { data, reload, error } = useResource<Json>("/v1/agent/workspace", { pollMs: 4000 });
  const [phone, setPhone] = useState<SoftphoneStatus>(softphone.status);
  useEffect(() => softphone.on(setPhone), []);
  useEffect(() => {
    if (softphone.status.state === "idle") softphone.register();
  }, []);
  return <WorkspaceCtx.Provider value={{ ws: data, reload, error, phone }}>{children}</WorkspaceCtx.Provider>;
}

export function useWorkspace(): Ctx {
  return useContext(WorkspaceCtx);
}

const REQUESTABLE = [
  ["available", "Available"],
  ["break", "Break"],
  ["unavailable", "Unavailable"],
  ["offline", "Offline"],
] as const;

export function AgentStatusBar() {
  const { ws, reload, phone } = useWorkspace();
  const act = useAction();
  if (!ws) return <span className="muted">Loading workspace…</span>;
  const a = ws.agent;
  const busy = ["call_offered", "connecting", "on_interaction"].includes(a.state);
  const set = (state: string) =>
    act.run(async () => {
      await api("/v1/agents/me/availability", { method: "PUT", body: { state, expected_version: a.state_version } });
      reload();
    });
  const reconcile = () =>
    act.run(async () => {
      const r = await api<Json>("/v1/agents/me/reconcile", { method: "POST" });
      reload();
      return r;
    }, (r: Json) => (r.cleared ? "Call state reconciled with the provider." : `Still inconsistent: ${r.conflicts.join("; ")}`));
  const provider = ws.provider.status;
  return (
    <div className="row" style={{ flex: 1 }}>
      <AgentStateBadge state={a.state} />
      <span className="small muted">since {new Date(a.state_since).toLocaleTimeString("en-GB")}</span>
      <div className="row" role="group" aria-label="Set your availability">
        {REQUESTABLE.map(([s, label]) => (
          <button key={s} className={`btn btn-sm ${a.state === s ? "btn-primary" : ""}`} disabled={busy || act.busy || a.state === s}
            onClick={() => set(s)} aria-pressed={a.state === s}>{label}</button>
        ))}
      </div>
      <Badge tone={a.telephony_registration === "registered" ? "green" : "amber"}
        title="Registration as confirmed by the telephony provider (not by this browser)">
        {a.telephony_registration === "registered" ? "✔ Device registered (provider-confirmed)" : "⚠ Device not registered"}
      </Badge>
      <Badge tone={phone.state === "registered" ? "neutral" : phone.state === "failed" ? "red" : "amber"} title={phone.detail}>
        Browser softphone: {phone.state}
      </Badge>
      {phone.state !== "registered" ? (
        <button className="btn btn-sm" onClick={() => softphone.register()}>Register device</button>
      ) : null}
      <Badge tone={provider === "connected" ? "green" : provider === "disconnected" ? "red" : "amber"}>
        {provider === "connected" ? "Provider connected" : `${provider === "disconnected" ? "✖" : "⚠"} Provider ${provider}`}
      </Badge>
      {ws.provider.simulated ? <SimulatedBadge /> : null}
      {a.reconcile_required ? (
        <button className="btn btn-sm" onClick={reconcile} disabled={act.busy}
          title={a.reconcile_reason ?? ""}>⚠ Reconcile call state</button>
      ) : null}
      {act.error ? <span className="badge badge-red" role="alert">✖ {act.error}</span> : null}
      {act.message ? <span className="badge badge-blue" role="status">{act.message}</span> : null}
      {a.state === "unavailable" || a.state === "offline" ? (
        a.readiness && !a.readiness.ready ? (
          <span className="small" style={{ color: "var(--amber)" }} role="status">
            ⚠ Not ready: {a.readiness.blockers.join("; ")}
          </span>
        ) : null
      ) : null}
    </div>
  );
}
