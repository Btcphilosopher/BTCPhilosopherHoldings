"use client";

import { useState } from "react";
import { api, getSession, type Json } from "@/lib/api";
import { useAction, useResource } from "@/lib/hooks";
import { Badge, ErrorText, OkText } from "../ui";

export function WrapUpPanel({ detail, reload }: { detail: Json; reload: () => void }) {
  const me = getSession()?.user.agent_id;
  const myPart = (detail.participations as Json[]).find((p) => p.agent_id === me && !p.wrap_ended_at);
  const inWrap = !!myPart?.wrap_started_at;
  const canNote = ["active", "wrap_up"].includes(detail.status) || inWrap;
  if (!canNote && !detail.summaries.length) return null;
  return (
    <div style={{ marginTop: 12 }}>
      {inWrap || (detail.channel !== "voice" && detail.status === "active" && detail.owner_agent_id === me) ? (
        <Disposition detail={detail} reload={reload} />
      ) : null}
      <div className="grid-2" style={{ marginTop: 10 }}>
        <Summary detail={detail} reload={reload} />
        <FollowUp detail={detail} reload={reload} />
      </div>
    </div>
  );
}

function Disposition({ detail, reload }: { detail: Json; reload: () => void }) {
  const { data: codes } = useResource<Json[]>("/v1/outcome-codes", { live: false, pollMs: 0 });
  const [code, setCode] = useState("");
  const [note, setNote] = useState("");
  const act = useAction();
  const submit = () => act.run(async () => {
    const r = await api<Json>(`/v1/interactions/${detail.id}/wrap-up`, {
      body: { disposition_code: code, note, expected_version: detail.version }, idempotent: true });
    reload();
    return r;
  }, (r: Json) => `After-call work complete. Your state: ${r.agent_state.replaceAll("_", " ")}.`);
  return (
    <div className="panel" style={{ borderColor: "var(--nav)", borderWidth: 2 }}>
      <div className="row between">
        <h2 style={{ margin: 0 }}>After-call work</h2>
        <Badge tone="navy">Attributed to you · visible to supervisors</Badge>
      </div>
      <div className="grid-2" style={{ marginTop: 8 }}>
        <div className="field">
          <label htmlFor="disp">Outcome (required)</label>
          <select id="disp" value={code} onChange={(e) => setCode(e.target.value)}>
            <option value="">Choose outcome…</option>
            {(codes ?? []).map((c) => <option key={c.code} value={c.code}>{c.label}</option>)}
          </select>
          <p className="small muted">Ending a call never resolves a case. Resolve cases explicitly.</p>
        </div>
        <div className="field">
          <label htmlFor="dnote">Note</label>
          <textarea id="dnote" value={note} onChange={(e) => setNote(e.target.value)} style={{ minHeight: 60 }} />
        </div>
      </div>
      <button className="btn btn-primary" disabled={!code || act.busy} onClick={submit}>Complete after-call work</button>
      <OkText message={act.message} />
      <ErrorText error={act.error} />
    </div>
  );
}

function Summary({ detail, reload }: { detail: Json; reload: () => void }) {
  const [text, setText] = useState("");
  const [draft, setDraft] = useState<Json | null>(null);
  const [reviewed, setReviewed] = useState(false);
  const act = useAction();
  const getDraft = () => act.run(async () => {
    const s = await api<Json>("/v1/ai/draft-summary", { body: { interaction_id: detail.id, notes: text } });
    setDraft(s);
    setText(s.output.summary);
    setReviewed(false);
  });
  const save = () => act.run(async () => {
    await api(`/v1/interactions/${detail.id}/summary`, {
      body: { body: text, ai_suggestion_id: draft?.id ?? null, reviewed } });
    setDraft(null);
    setText("");
    setReviewed(false);
    reload();
  }, () => "Summary saved.");
  const saved = detail.summaries[0];
  return (
    <div className="panel">
      <h3>Interaction summary</h3>
      {saved ? (
        <div className="list-item small" style={{ marginBottom: 8 }}>
          <Badge tone="green">Saved · {saved.source.replaceAll("_", " ")}</Badge>
          <p style={{ marginTop: 4 }}>{saved.body}</p>
        </div>
      ) : null}
      <label htmlFor="summary">Your summary</label>
      <textarea id="summary" value={text} onChange={(e) => { setText(e.target.value); setReviewed(false); }} />
      {draft ? (
        <div className="small" style={{ marginTop: 6 }}>
          <Badge tone="amber">⚠ AI proposal — review before saving</Badge>{" "}
          <span className="muted">{draft.provider} · {draft.model} · confidence {draft.uncertainty.confidence}</span>
          <ul>{(draft.uncertainty.notes as string[]).map((n) => <li key={n}>{n}</li>)}</ul>
          {draft.safety_flags.length ? <p><Badge tone="amber">⚠ {draft.safety_flags.join(", ").replaceAll("_", " ")}</Badge></p> : null}
          <p className="muted">Sources: {(draft.sources as Json[]).map((s) => `${s.type}:${s.ref}`).join(", ") || "none"}</p>
        </div>
      ) : null}
      <label className="row" style={{ fontWeight: 400, marginTop: 6 }}>
        <input type="checkbox" style={{ width: "auto" }} checked={reviewed} onChange={(e) => setReviewed(e.target.checked)} />
        I have reviewed and corrected this summary
      </label>
      <div className="row" style={{ marginTop: 6 }}>
        <button className="btn btn-sm" onClick={getDraft} disabled={act.busy}>Draft with assistant</button>
        <button className="btn btn-primary btn-sm" onClick={save} disabled={act.busy || text.trim().length < 10 || !reviewed}>
          Save summary</button>
      </div>
      <OkText message={act.message} />
      <ErrorText error={act.error} />
    </div>
  );
}

function FollowUp({ detail, reload }: { detail: Json; reload: () => void }) {
  const [title, setTitle] = useState("");
  const [due, setDue] = useState("");
  const [queue, setQueue] = useState("");
  const [caseTitle, setCaseTitle] = useState("");
  const [category, setCategory] = useState("billing");
  const act = useAction();
  const customerId = detail.customer_record?.id ?? detail.customer?.id ?? null;
  const addTask = () => act.run(async () => {
    await api("/v1/tasks", { idempotent: true, body: {
      title, interaction_id: detail.id, customer_id: customerId, assignee_queue: queue || null,
      assignee_agent_id: queue ? null : getSession()?.user.agent_id, due_at: due ? new Date(due).toISOString() : null } });
    setTitle("");
    reload();
  }, () => "Follow-up task created.");
  const addCase = () => act.run(async () => {
    const c = await api<Json>("/v1/cases", { idempotent: true, body: {
      title: caseTitle, category, customer_id: customerId, interaction_id: detail.id } });
    setCaseTitle("");
    reload();
    return c;
  }, (c: Json) => `Case ${c.case_ref} created and linked (${c.sla?.label ?? "no SLA"}).`);
  return (
    <div className="panel">
      <h3>Follow-up</h3>
      <div className="field"><label htmlFor="task-title">Task</label>
        <input id="task-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Send confirmation letter" /></div>
      <div style={{ display: "grid", gridTemplateColumns: "minmax(0, 3fr) minmax(0, 2fr)", gap: 8, marginTop: 8 }}>
        <div><label htmlFor="task-due">Due</label>
          <input id="task-due" type="datetime-local" value={due} onChange={(e) => setDue(e.target.value)} /></div>
        <div><label htmlFor="task-q">Assign to</label>
          <select id="task-q" value={queue} onChange={(e) => setQueue(e.target.value)}>
            <option value="">Me</option><option value="BILLING">Billing queue</option>
            <option value="TECH">Technical queue</option><option value="CARE">Care queue</option></select></div>
      </div>
      <button className="btn btn-sm" style={{ marginTop: 6 }} disabled={act.busy || title.length < 3} onClick={addTask}>Create task</button>
      {detail.tasks.length ? <ul className="small">{detail.tasks.map((t: Json) => <li key={t.id}>{t.title} — {t.status}</li>)}</ul> : null}
      <hr style={{ border: 0, borderTop: "1px solid var(--border)", margin: "10px 0" }} />
      <div className="field"><label htmlFor="case-title">New case</label>
        <input id="case-title" value={caseTitle} onChange={(e) => setCaseTitle(e.target.value)} placeholder="Case title" /></div>
      <div className="row">
        <select aria-label="Case category" value={category} onChange={(e) => setCategory(e.target.value)} style={{ flex: 1 }}>
          {["billing", "billing_dispute", "technical", "complaint", "accounts", "general"].map((c) => <option key={c}>{c}</option>)}
        </select>
        <button className="btn btn-sm" disabled={act.busy || caseTitle.length < 3} onClick={addCase}>Create &amp; link case</button>
      </div>
      {detail.cases.length ? <ul className="small">{detail.cases.map((c: Json) => <li key={c.id}>{c.case_ref} {c.title} — {c.status}</li>)}</ul> : null}
      <FollowUpMessage detail={detail} customerId={customerId} />
      <OkText message={act.message} />
      <ErrorText error={act.error} />
    </div>
  );
}

function FollowUpMessage({ detail, customerId }: { detail: Json; customerId: string | null }) {
  const { data: tpls } = useResource<Json[]>("/v1/message-templates", { live: false, pollMs: 0 });
  const [tid, setTid] = useState("");
  const [values, setValues] = useState<Record<string, string>>({});
  const [reviewed, setReviewed] = useState(false);
  const act = useAction();
  const tpl = (tpls ?? []).find((t) => t.id === tid);
  if (!customerId) return null;
  const draft = () => act.run(async () => {
    const s = await api<Json>("/v1/ai/draft-message", { body: { interaction_id: detail.id, template_id: tid } });
    setValues({ ...values, ...Object.fromEntries(Object.entries(s.output.placeholder_values).filter(([, v]) => v)) as Record<string, string> });
  });
  const send = () => act.run(() => api<Json>("/v1/messages", { idempotent: true, body: {
    template_id: tid, customer_id: customerId, interaction_id: detail.id, placeholder_values: values, reviewed } }),
    (m: Json) => `Message ${m.status.replaceAll("_", " ")}.`);
  return (
    <details style={{ marginTop: 8 }}>
      <summary className="small"><strong>Send an approved follow-up message</strong></summary>
      <select aria-label="Template" value={tid} onChange={(e) => { setTid(e.target.value); setValues({}); setReviewed(false); }}>
        <option value="">Choose template…</option>
        {(tpls ?? []).map((t) => <option key={t.id} value={t.id} disabled={!t.approved}>{t.name}{t.approved ? "" : " (not approved)"}</option>)}
      </select>
      {tpl ? (
        <div className="stack" style={{ marginTop: 6 }}>
          {(tpl.placeholders as string[]).map((ph) => (
            <input key={ph} aria-label={ph} placeholder={ph} value={values[ph] ?? ""}
              onChange={(e) => { setValues({ ...values, [ph]: e.target.value }); setReviewed(false); }} />
          ))}
          <pre className="small" style={{ whiteSpace: "pre-wrap", background: "var(--panel-2)", padding: 8, borderRadius: 6 }}>
            {(tpl.body as string).replace(/\{([a-z_]+)\}/g, (_m: string, k: string) => values[k] || `{${k}}`)}</pre>
          <label className="row" style={{ fontWeight: 400 }}><input type="checkbox" style={{ width: "auto" }} checked={reviewed}
            onChange={(e) => setReviewed(e.target.checked)} /> I have reviewed this message</label>
          <div className="row">
            <button className="btn btn-sm" onClick={draft} disabled={act.busy}>Suggest values</button>
            <button className="btn btn-primary btn-sm" onClick={send} disabled={act.busy || !reviewed}>Send</button>
          </div>
        </div>
      ) : null}
      <OkText message={act.message} />
      <ErrorText error={act.error} />
    </details>
  );
}
