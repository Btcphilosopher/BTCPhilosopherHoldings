"use client";

import { Fragment, useEffect, useRef, useState } from "react";
import { api, type Json } from "@/lib/api";
import { fmtDateTime, useAction } from "@/lib/hooks";
import { Badge, Banner, ErrorText, OkText, Panel, VerificationBadge } from "../ui";

export function ContextPanel({ detail, reload }: { detail: Json | null; reload: () => void }) {
  return (
    <div>
      {detail ? <CustomerContext detail={detail} reload={reload} /> : (
        <Panel title="Customer context"><p className="muted small">Customer details appear here for the selected interaction.</p></Panel>
      )}
      <Knowledge detail={detail} />
    </div>
  );
}

function CustomerContext({ detail, reload }: { detail: Json; reload: () => void }) {
  const act = useAction();
  const rec = detail.customer_record;
  const owner = detail.available_controls !== undefined;
  const select = (id: string) => act.run(async () => {
    await api(`/v1/interactions/${detail.id}/customer`, { body: { customer_id: id } });
    reload();
  });
  return (
    <Panel title="Customer context" id="customer-context">
      <p className="small muted">{detail.match_note}</p>
      {!rec || detail.customer_match_status !== "verified" ? (
        <div>
          <h3>Possible matches</h3>
          {(detail.candidates as Json[]).length === 0 ? <p className="small">No record matches this contact. Search Customers
            to find the record, or continue as an unidentified caller.</p> : null}
          {(detail.candidates as Json[]).map((c) => (
            <div key={c.customer_id} className="list-item">
              <div className="row between">
                <strong>{c.display_name}</strong>
                <Badge>{c.customer_ref}</Badge>
              </div>
              <ul className="small" style={{ margin: "4px 0" }}>{(c.match_reasons ?? []).map((r: string) => <li key={r}>{r}</li>)}</ul>
              {c.shared_number ? <Badge tone="amber">⚠ Shared number — confirm who is calling</Badge> : null}
              <button className="btn btn-sm" style={{ marginTop: 4 }} disabled={act.busy || rec?.id === c.customer_id}
                onClick={() => select(c.customer_id)}>{rec?.id === c.customer_id ? "Selected" : "This is the caller"}</button>
            </div>
          ))}
        </div>
      ) : null}
      {rec ? <Verification detail={detail} reload={reload} /> : null}
      {rec ? <Record rec={rec} detail={detail} reload={reload} /> : null}
      <ErrorText error={act.error} />
      {!owner ? <p className="small muted">Read-only view.</p> : null}
    </Panel>
  );
}

function Verification({ detail, reload }: { detail: Json; reload: () => void }) {
  const v = detail.verification;
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const act = useAction();
  if (!v) return null;
  const submit = () => act.run(async () => {
    const r = await api<Json>(`/v1/interactions/${detail.id}/verification`, { body: { answers } });
    setAnswers({});
    reload();
    return r;
  }, (r: Json) => {
    const failed = Object.entries(r.last_results).filter(([, ok]) => !ok).map(([k]) => k);
    return failed.length ? `Not matched: ${failed.join(", ")}` : undefined;
  });
  return (
    <div style={{ marginTop: 10 }}>
      <div className="row between"><h3 style={{ margin: 0 }}>Verification</h3><VerificationBadge status={v.status} /></div>
      {v.status === "verified" ? (
        <p className="small">Passed: {v.passed_factors.join(", ")}. Restricted information and sensitive actions are now available.</p>
      ) : v.status === "locked" ? (
        <Banner kind="error" title="Verification locked">Too many failed answers. Do not disclose restricted information.
          Offer an alternative route (e.g. a letter to the address on file).</Banner>
      ) : (
        <>
          <p className="small">Ask the customer. Answers are checked by the server and never shown or stored. Need {v.required_passes} of
            {" "}{v.available_factors.length}; failures {v.failed_attempts}/{v.max_failures}.</p>
          {v.available_factors.map((f: Json) => (
            <div className="field" key={f.code}>
              <label htmlFor={`f-${f.code}`}>{f.label} {v.passed_factors.includes(f.code) ? "✔" : ""}</label>
              <input id={`f-${f.code}`} autoComplete="off" disabled={v.passed_factors.includes(f.code)}
                placeholder={f.code === "date_of_birth" ? "e.g. 21/07/1979" : f.code === "account_last4" ? "4 digits" : ""}
                value={answers[f.code] ?? ""} onChange={(e) => setAnswers({ ...answers, [f.code]: e.target.value })} />
            </div>
          ))}
          <button className="btn btn-sm btn-primary" style={{ marginTop: 6 }} disabled={act.busy || !Object.values(answers).some(Boolean)}
            onClick={submit}>Check answers</button>
        </>
      )}
      <OkText message={act.message} />
      <ErrorText error={act.error} />
    </div>
  );
}

function Record({ rec, detail, reload }: { rec: Json; detail: Json; reload: () => void }) {
  const act = useAction();
  const object = (scope: string) => act.run(async () => {
    await api(`/v1/customers/${rec.id}/objections`, { body: { scope, note: `Recorded during ${detail.reference}`,
      interaction_id: detail.id } });
    reload();
  }, () => "Objection recorded. It applies to future outbound checks immediately.");
  return (
    <div style={{ marginTop: 10 }}>
      <h3>Record</h3>
      <dl className="kv">
        <dt>Name</dt><dd>{rec.display_name} {rec.account ? <span className="muted">({rec.account.name})</span> : null}</dd>
        <dt>Reference</dt><dd>{rec.customer_ref}</dd>
        <dt>Language</dt><dd>{rec.preferred_language} · {rec.timezone}</dd>
        {rec.contact_points.map((c: Json) => <Fragment key={c.id}><dt>{c.kind} ({c.label})</dt><dd>{c.value}</dd></Fragment>)}
        {rec.restricted ? Object.entries(rec.restricted).map(([k, v]) => (
          <Fragment key={k}><dt>{k.replaceAll("_", " ")}</dt><dd>{String(v)}</dd></Fragment>
        )) : <><dt>Restricted</dt><dd><Badge tone="amber">⚠ Withheld until verified</Badge></dd></>}
      </dl>
      {rec.support_flags.length ? <p className="small"><Badge tone="blue">Support needs: {rec.support_flags.join(", ").replaceAll("_", " ")}</Badge></p> : null}
      <h3 style={{ marginTop: 8 }}>Consent &amp; objections</h3>
      <ul className="small">
        {rec.consents.map((c: Json) => <li key={c.id}>{c.purpose.replaceAll("_", " ")}: {c.status} ({c.basis}, {c.source})</li>)}
        {rec.objections.filter((o: Json) => o.active).map((o: Json) => <li key={o.id}><Badge tone="amber">⚠ Objection: {o.scope.replaceAll("_", " ")}</Badge></li>)}
      </ul>
      <div className="row">
        <button className="btn btn-sm" onClick={() => object("telephone_marketing")} disabled={act.busy}>Record: no marketing calls</button>
        <button className="btn btn-sm" onClick={() => object("all_telephone")} disabled={act.busy}>Record: no calls at all</button>
      </div>
      <p className="small muted">Source systems: {rec.source_refs.map((s: Json) => `${s.system} ${s.external_id}`).join(", ")}</p>
      <OkText message={act.message} />
      <ErrorText error={act.error} />
    </div>
  );
}

function Knowledge({ detail }: { detail: Json | null }) {
  const [q, setQ] = useState("");
  const [results, setResults] = useState<Json[]>([]);
  const [open, setOpen] = useState<Json | null>(null);
  const [sug, setSug] = useState<Json | null>(null);
  const act = useAction();
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.altKey && e.key.toLowerCase() === "k") { e.preventDefault(); ref.current?.focus(); } };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);
  const search = (query = q) => act.run(async () => setResults((await api<Json>(`/v1/knowledge/search?q=${encodeURIComponent(query)}`)).results));
  const suggest = () => detail && act.run(async () => {
    const s = await api<Json>("/v1/ai/suggest-articles", { body: { interaction_id: detail.id } });
    setSug(s);
  });
  const view = (articleId: string) => act.run(async () => setOpen(await api<Json>(`/v1/knowledge/articles/${articleId}`)));
  return (
    <Panel title="Knowledge" id="knowledge">
      <form className="row" onSubmit={(e) => { e.preventDefault(); search(); }}>
        <label htmlFor="kq" className="sr-only">Search approved knowledge</label>
        <input id="kq" ref={ref} value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search approved articles (Alt+K)" style={{ flex: 1 }} />
        <button className="btn btn-sm" type="submit">Search</button>
      </form>
      {detail ? <button className="btn btn-sm btn-ghost" onClick={suggest} disabled={act.busy}>Suggest for this contact</button> : null}
      {sug ? (
        <div className="small" style={{ margin: "6px 0" }}>
          <Badge tone="amber">⚠ Assistant proposal</Badge> {sug.provider} · confidence {sug.uncertainty.confidence}
          {sug.output.articles.length === 0 ? <p className="muted">No suggestions.</p> : null}
          {sug.output.articles.map((a: Json) => (
            <div key={a.slug}><button className="btn btn-ghost btn-sm" onClick={() => { setQ(a.title); search(a.title); }}>{a.title}</button></div>
          ))}
        </div>
      ) : null}
      <div className="scroll">
        {results.map((r) => (
          <div key={r.version_id} className="list-item">
            <button className="btn btn-ghost list-button" onClick={() => view(r.article_id)}>
              <strong>{r.title}</strong> <span className="muted small">v{r.version}</span>
            </button>
            <div className="row small">
              <Badge tone={r.visibility === "internal" ? "navy" : "green"}>{r.visibility === "internal" ? "Internal only" : "Customer-visible"}</Badge>
              <span className="muted">{r.owner_team} · effective {fmtDateTime(r.effective_from)}</span>
              {r.review_overdue ? <Badge tone="amber">⚠ Review overdue</Badge> : null}
            </div>
            {/* snippet markers come from the server; render as text */}
            <p className="small muted" style={{ marginTop: 4 }}>{String(r.snippet ?? "").replaceAll("«", "").replaceAll("»", "")}</p>
          </div>
        ))}
      </div>
      {open?.current ? (
        <div className="panel" style={{ marginTop: 8, background: "var(--panel-2)" }} aria-live="polite">
          <div className="row between"><strong>{open.current.title}</strong>
            <button className="btn btn-sm" onClick={() => setOpen(null)} aria-label="Close article">Close</button></div>
          <p className="small muted">Version {open.current.version} · approved by {open.current.reviewed_by ?? "—"} ·
            owner {open.owner_team} · {open.visibility === "internal" ? "internal only" : "may be shared with customers"}</p>
          <p style={{ whiteSpace: "pre-wrap" }}>{open.current.body}</p>
        </div>
      ) : null}
      <ErrorText error={act.error} />
    </Panel>
  );
}
