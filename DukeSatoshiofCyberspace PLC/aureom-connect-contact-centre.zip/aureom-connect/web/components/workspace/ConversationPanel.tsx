"use client";

import { useState } from "react";
import { api, type Json } from "@/lib/api";
import { fmtDuration, fmtTime, since, useAction, useNow } from "@/lib/hooks";
import { Badge, Banner, ErrorText, OkText, VerificationBadge } from "../ui";
import { CallControls } from "./CallControls";
import { WrapUpPanel } from "./WrapUpPanel";

export function ConversationPanel({ detail, reload }: { detail: Json | null; reload: () => void }) {
  useNow(1000);
  if (!detail) {
    return (
      <section className="panel" aria-label="Customer conversation">
        <h2>Customer conversation</h2>
        <p className="muted">No interaction selected. Accept an offer or choose an item from your work list.</p>
      </section>
    );
  }
  const live = detail.channel === "voice" && detail.status === "active";
  const cust = detail.customer_record;
  const recording = (detail.recordings ?? [])[0];
  const monitoring = (detail.monitoring ?? [])[0];
  return (
    <section className={`panel ${live ? "active-call" : ""}`} aria-label="Customer conversation">
      <div className="row between">
        <div>
          <h2 style={{ marginBottom: 2 }}>
            {detail.reference} · {detail.channel} · {detail.direction}
          </h2>
          <div className="row small">
            {live ? <span className="live-indicator"><span className="dot" aria-hidden /> Live call · {fmtDuration(since(detail.connected_at))}</span>
              : <Badge tone={detail.status === "wrap_up" ? "navy" : "neutral"}>{detail.status.replaceAll("_", " ")}</Badge>}
            {detail.queue ? <Badge>{detail.queue.name}</Badge> : null}
            {detail.is_simulated ? <Badge tone="amber">⚠ Simulated · no audio</Badge> : null}
            {detail.transfer_count ? <Badge tone="blue">Transferred ×{detail.transfer_count}</Badge> : null}
            {detail.urgency_flag ? <Badge tone="amber">⚠ {detail.urgency_flag} (does not change routing)</Badge> : null}
          </div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontWeight: 700, fontSize: 15 }}>
            {cust ? cust.display_name : detail.customer_match_status === "candidates" ? "Unconfirmed caller" : "Unidentified caller"}
          </div>
          <div className="row" style={{ justifyContent: "flex-end" }}>
            {cust ? <Badge>{cust.customer_ref}</Badge> : null}
            <VerificationBadge status={detail.verification?.status ?? "unverified"} />
          </div>
          {detail.caller ? <div className="small muted">Caller ID (hint only): {detail.caller}</div> : null}
        </div>
      </div>

      {detail.needs_reconciliation ? (
        <Banner kind="warn" title="Call state may differ from the provider">
          A control outcome is unknown. Nothing will be retried automatically. Use “Check call state” to reconcile.
          <div><ReconcileButton id={detail.id} onDone={reload} /></div>
        </Banner>
      ) : null}
      {detail.provider_status !== "connected" && detail.channel === "voice" ? (
        <Banner kind="error" title={`Telephony provider ${detail.provider_status}`}>Voice controls are disabled until
          the provider reconnects and call state is reconciled.</Banner>
      ) : null}
      {monitoring ? <Banner kind="info" title={`A supervisor is monitoring this call (${monitoring.mode})`}>
        Monitoring is always visible to you and recorded in the audit trail.</Banner> : null}
      {detail.channel === "voice" && recording ? (
        <p className="small" style={{ margin: "6px 0" }}>
          Recording: <Badge tone={recording.status === "active" ? "teal" : recording.status === "paused" ? "amber" : "neutral"}>
            {recording.confirmed_by_provider ? recording.status : `${recording.status} (not yet confirmed)`}</Badge>
          {" "}purpose {recording.purpose.replaceAll("_", " ")} · {recording.jurisdiction}
          {recording.is_synthetic_media ? " · synthetic media" : ""}
        </p>
      ) : null}

      {detail.channel === "voice" && detail.call ? <CallControls detail={detail} onChange={reload} /> : null}
      {detail.channel === "voice" && !detail.call && detail.status === "active" ? <DialPanel detail={detail} reload={reload} /> : null}
      {detail.channel !== "voice" ? <MessageThread detail={detail} reload={reload} /> : null}

      <WrapUpPanel detail={detail} reload={reload} />
      <TranscriptView detail={detail} reload={reload} />
      <details style={{ marginTop: 10 }} open={detail.status !== "active"}>
        <summary><strong>Timeline</strong> <span className="small muted">({detail.timeline.length} events · provider
          time shown; ingestion time on hover)</span></summary>
        <ul className="timeline scroll" style={{ marginTop: 8 }}>
          {detail.timeline.map((e: Json) => (
            <li key={e.id} className={`src-${e.source}`} title={`recorded ${fmtTime(e.recorded_at)}`}>
              <span className="mono">{fmtTime(e.occurred_at)}</span> <strong>{e.type}</strong>{" "}
              <span className="muted">[{e.source}]</span>{" "}
              <span className="muted">{summariseData(e.data)}</span>
            </li>
          ))}
        </ul>
      </details>
    </section>
  );
}

function summariseData(d: Json): string {
  const keys = ["agent", "queue", "action", "reason", "status", "disposition", "note", "to_agent", "mode", "case", "task"];
  return keys.filter((k) => d?.[k] !== undefined && d?.[k] !== null).map((k) => `${k}: ${d[k]}`).join(" · ");
}

function ReconcileButton({ id, onDone }: { id: string; onDone: () => void }) {
  const act = useAction();
  return (
    <>
      <button className="btn btn-sm" disabled={act.busy} onClick={() =>
        act.run(() => api<Json>(`/v1/interactions/${id}/reconcile`, { method: "POST" }),
          (r: Json) => { onDone(); return r.changes.length ? `Reconciled: ${r.changes.join("; ")}` : "Provider state matches."; })}>
        Check call state with provider</button>
      <OkText message={act.message} />
      <ErrorText error={act.error} />
    </>
  );
}

function DialPanel({ detail, reload }: { detail: Json; reload: () => void }) {
  const act = useAction();
  const [elig, setElig] = useState<Json | null>(null);
  const check = () => act.run(async () => setElig(await api<Json>("/v1/outbound-calls/eligibility", {
    body: { interaction_id: detail.id, callback_id: detail.callback_id, campaign_contact_id: detail.campaign_contact_id,
      purpose: "service", customer_id: detail.customer?.id } })));
  const dial = () => act.run(async () => {
    const r = await api<Json>("/v1/outbound-calls", { body: { interaction_id: detail.id }, idempotent: true });
    reload();
    return r;
  }, () => "Dial requested. Connection is shown only when the provider confirms it.");
  const skip = () => act.run(async () => {
    await api(`/v1/interactions/${detail.id}/skip-preview`, { body: { reason: "skipped by agent" } });
    reload();
  });
  return (
    <div className="panel" style={{ background: "var(--panel-2)" }}>
      <h3>{detail.callback_id ? "Callback" : "Preview call"}</h3>
      <p className="small">Eligibility is checked again by the server immediately before dialling.</p>
      <div className="row">
        <button className="btn btn-sm" onClick={check} disabled={act.busy}>Check eligibility</button>
        <button className="btn btn-teal" onClick={dial} disabled={act.busy}>✆ Dial</button>
        {detail.campaign_contact_id ? <button className="btn btn-sm" onClick={skip} disabled={act.busy}>Skip contact</button> : null}
      </div>
      {elig ? (
        <table style={{ marginTop: 8 }}>
          <tbody>
            {elig.checks.map((c: Json) => (
              <tr key={c.check}><td>{c.passed ? <Badge tone="green">pass</Badge> : <Badge tone="red">✖ fail</Badge>}</td>
                <td className="mono">{c.check}</td><td className="small">{c.detail}</td></tr>
            ))}
          </tbody>
        </table>
      ) : null}
      <OkText message={act.message} />
      <ErrorText error={act.error} />
    </div>
  );
}

function MessageThread({ detail, reload }: { detail: Json; reload: () => void }) {
  const [text, setText] = useState("");
  const act = useAction();
  const send = () => act.run(async () => {
    await api(`/v1/interactions/${detail.id}/messages`, { body: { body: text } });
    setText("");
    reload();
  });
  return (
    <div style={{ marginTop: 8 }}>
      <p className="small muted">Customer messages are untrusted content and are shown as text only.</p>
      <div className="scroll panel" style={{ background: "var(--panel-2)", maxHeight: 260 }} aria-live="polite">
        {detail.messages.map((m: Json) => (
          <div key={m.id} className={`chat-bubble ${m.sender === "customer" ? "chat-customer" : "chat-agent"}`}>
            <div className="small muted">{m.sender} · {fmtTime(m.sent_at)}{m.subject ? ` · ${m.subject}` : ""}</div>
            <div style={{ whiteSpace: "pre-wrap" }}>{m.body}</div>
          </div>
        ))}
      </div>
      {detail.status === "active" ? (
        <div className="row" style={{ marginTop: 6 }}>
          <label htmlFor="reply" className="sr-only">Reply</label>
          <textarea id="reply" value={text} onChange={(e) => setText(e.target.value)} style={{ minHeight: 50, flex: 1 }}
            placeholder={`Reply by ${detail.channel}…`} />
          <button className="btn btn-primary" disabled={!text.trim() || act.busy} onClick={send}>Send</button>
        </div>
      ) : null}
      <ErrorText error={act.error} />
    </div>
  );
}

function TranscriptView({ detail, reload }: { detail: Json; reload: () => void }) {
  const [editing, setEditing] = useState<number | null>(null);
  const [text, setText] = useState("");
  const [reason, setReason] = useState("");
  const act = useAction();
  const t = (detail.transcripts ?? [])[0];
  if (!t) return null;
  const corrected = new Map<number, Json>((t.corrections as Json[]).map((c) => [c.segment_index, c]));
  const save = (i: number) => act.run(async () => {
    await api(`/v1/interactions/${detail.id}/transcripts/${t.id}/corrections`,
      { body: { segment_index: i, corrected_text: text, reason } });
    setEditing(null);
    reload();
  });
  return (
    <details style={{ marginTop: 10 }}>
      <summary><strong>Transcript</strong> <Badge tone="amber">⚠ {t.label}</Badge></summary>
      <p className="small muted">Engine {t.provenance.engine} {t.provenance.engine_version}
        {t.provenance.simulated ? " (simulated)" : ""}. Corrections are stored separately; the original output is kept.</p>
      {t.segments.map((s: Json) => {
        const c = corrected.get(s.i);
        return (
          <div key={s.i} className="list-item small">
            <strong>{s.speaker}</strong>: {c ? <><s>{s.text}</s> <ins>{c.corrected_text}</ins> <span className="muted">({c.reason})</span></> : s.text}
            {s.confidence ? <span className="muted"> · conf {s.confidence}</span> : null}
            {editing === s.i ? (
              <div className="stack" style={{ marginTop: 4 }}>
                <input aria-label="Corrected text" value={text} onChange={(e) => setText(e.target.value)} />
                <input aria-label="Reason for correction" placeholder="Reason" value={reason} onChange={(e) => setReason(e.target.value)} />
                <div className="row"><button className="btn btn-sm" onClick={() => save(s.i)} disabled={!text || reason.length < 3}>Save correction</button>
                  <button className="btn btn-sm" onClick={() => setEditing(null)}>Cancel</button></div>
              </div>
            ) : (
              <button className="btn btn-ghost btn-sm" onClick={() => { setEditing(s.i); setText(s.text); setReason(""); }}>Correct</button>
            )}
          </div>
        );
      })}
      <ErrorText error={act.error} />
    </details>
  );
}
