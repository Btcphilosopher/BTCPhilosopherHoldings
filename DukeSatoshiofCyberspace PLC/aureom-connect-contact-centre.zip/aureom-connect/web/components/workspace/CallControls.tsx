"use client";

import { useEffect, useRef, useState } from "react";
import { api, type Json } from "@/lib/api";
import { useAction, useResource } from "@/lib/hooks";
import { Badge, ControlStatus, ErrorText } from "../ui";

function latest(detail: Json, actions: string[]): Json | undefined {
  return (detail.controls as Json[]).find((c) => actions.includes(c.action));
}

export function CallControls({ detail, onChange }: { detail: Json; onChange: () => void }) {
  const act = useAction();
  const [showTransfer, setShowTransfer] = useState(false);
  const [confirmEnd, setConfirmEnd] = useState(false);
  const transferBtn = useRef<HTMLButtonElement>(null);
  const ac: Record<string, { enabled: boolean; reason: string }> = detail.available_controls ?? {};
  const legs: Json[] = detail.call?.legs ?? [];
  const cust = legs.find((l) => l.leg_type === "customer");
  const mine = legs.find((l) => (l.leg_type === "agent" || l.leg_type === "consult") && l.status === "answered");
  const muted = !!mine?.provider_muted;
  const held = !!cust?.on_hold;
  const ts = detail.transfer_state ?? {};

  const send = (action: string, params: Json = {}) =>
    act.run(async () => {
      const r = await api<Json>(`/v1/interactions/${detail.id}/actions`, { body: { action, params }, idempotent: true });
      onChange();
      return r;
    }, (r: Json) => (r.status === "failed" ? `Provider did not apply '${action}': ${r.error_code}` : undefined));

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!e.altKey) return;
      const k = e.key.toLowerCase();
      if (k === "h") { e.preventDefault(); held ? ac.resume?.enabled && send("resume") : ac.hold?.enabled && send("hold"); }
      if (k === "m") { e.preventDefault(); muted ? ac.unmute?.enabled && send("unmute") : ac.mute?.enabled && send("mute"); }
      if (k === "t") { e.preventDefault(); setShowTransfer(true); transferBtn.current?.focus(); }
      if (k === "e") { e.preventDefault(); if (ac.end?.enabled) setConfirmEnd(true); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const holdCtl = latest(detail, ["hold", "resume"]);
  const muteCtl = latest(detail, ["mute", "unmute"]);
  const xferCtl = latest(detail, ["warm_transfer_start", "warm_transfer_complete", "warm_transfer_cancel", "blind_transfer", "conference"]);
  const endCtl = latest(detail, ["end"]);
  const why = (a: string) => (ac[a]?.enabled ? undefined : ac[a]?.reason);

  return (
    <div>
      <div className="callbar" role="toolbar" aria-label="Call controls">
        <button className="btn ctl ctl-mute" aria-pressed={muted} aria-keyshortcuts="Alt+M"
          disabled={act.busy || !(muted ? ac.unmute?.enabled : ac.mute?.enabled)} title={why(muted ? "unmute" : "mute")}
          onClick={() => send(muted ? "unmute" : "mute")}>
          <span aria-hidden>🎙</span>{muted ? "Unmute" : "Mute"}
          <span className="ctl-note">your microphone</span>
        </button>
        <button className="btn ctl ctl-hold" aria-pressed={held} aria-keyshortcuts="Alt+H"
          disabled={act.busy || !(held ? ac.resume?.enabled : ac.hold?.enabled)} title={why(held ? "resume" : "hold")}
          onClick={() => send(held ? "resume" : "hold")}>
          <span aria-hidden>⏸</span>{held ? "Resume" : "Hold"}
          <span className="ctl-note">customer (provider)</span>
        </button>
        <button ref={transferBtn} className="btn ctl ctl-transfer" aria-expanded={showTransfer} aria-keyshortcuts="Alt+T"
          disabled={act.busy || !(ac.warm_transfer_start?.enabled || ac.blind_transfer?.enabled ||
            ac.warm_transfer_complete?.enabled || ac.warm_transfer_cancel?.enabled)}
          title={why("warm_transfer_start")} onClick={() => setShowTransfer((v) => !v)}>
          <span aria-hidden>⇄</span>Transfer
          <span className="ctl-note">warm · blind</span>
        </button>
        <button className="btn ctl ctl-end" aria-keyshortcuts="Alt+E" disabled={act.busy || !ac.end?.enabled}
          title={why("end")} onClick={() => setConfirmEnd(true)}>
          <span aria-hidden>✆</span>End call
        </button>
      </div>
      <div className="row small" style={{ marginTop: 6 }} aria-live="polite">
        {muteCtl ? <span>Mute: <ControlStatus status={muteCtl.status} /></span> : null}
        {holdCtl ? <span>Hold: <ControlStatus status={holdCtl.status} /></span> : null}
        {xferCtl ? <span>Transfer: <ControlStatus status={xferCtl.status} /></span> : null}
        {endCtl ? <span>End: <ControlStatus status={endCtl.status} /></span> : null}
        {muted ? <Badge tone="neutral">Microphone muted at provider</Badge> : null}
        {held ? <Badge tone="blue">Customer on hold (provider-confirmed)</Badge> : null}
        <span className="muted">Shortcuts: Alt+M mute · Alt+H hold · Alt+T transfer · Alt+E end</span>
      </div>
      {ac.end && !ac.end.enabled && ac.end.reason ? (
        <p className="small muted" style={{ marginTop: 4 }}>Controls unavailable: {ac.end.reason}</p>
      ) : null}
      {confirmEnd ? (
        <div className="banner banner-warn" role="alertdialog" aria-labelledby="end-q">
          <strong>⚠ Warning:</strong>
          <div>
            <div id="end-q">End this call for everyone?</div>
            <div className="row" style={{ marginTop: 6 }}>
              <button className="btn btn-danger btn-sm" autoFocus onClick={() => { setConfirmEnd(false); send("end"); }}>
                Yes, end call</button>
              <button className="btn btn-sm" onClick={() => setConfirmEnd(false)}>Cancel</button>
            </div>
          </div>
        </div>
      ) : null}
      {ts.status === "failed" ? (
        <div className="banner banner-warn" role="status">
          <strong>⚠ Warning:</strong>
          <div className="small">Transfer to {ts.target_agent ?? "colleague"} did not connect ({ts.failure_reason}).
            The original call was preserved{ts.customer_on_hold ? " — the customer is still on hold with you; resume when ready" : ""}.</div>
        </div>
      ) : null}
      {ts.status === "consult_ringing" ? <div className="banner banner-info"><strong>ℹ Note:</strong>
        <div className="small">Consulting {ts.target_agent}: ringing. The customer is on hold.</div></div> : null}
      {ts.status === "consult_connected" ? <div className="banner banner-teal"><strong>● Live:</strong>
        <div className="small">Speaking with {ts.target_agent}. Complete the transfer, add them to a conference, or cancel.</div></div> : null}
      {showTransfer ? <TransferPanel detail={detail} send={send} busy={act.busy} /> : null}
      <SecurePayment detail={detail} send={send} busy={act.busy} />
      <ErrorText error={act.error} />
      {act.message ? <ErrorText error={act.message} /> : null}
    </div>
  );
}

function TransferPanel({ detail, send, busy }: { detail: Json; send: (a: string, p?: Json) => void; busy: boolean }) {
  const { data: agents } = useResource<Json[]>("/v1/agents/directory");
  const { data: queues } = useResource<Json[]>("/v1/queues", { live: false, pollMs: 0 });
  const [target, setTarget] = useState("");
  const [queue, setQueue] = useState("");
  const ac = detail.available_controls ?? {};
  const ts = detail.transfer_state ?? {};
  return (
    <div className="panel" style={{ marginTop: 8 }} aria-label="Transfer">
      <div className="grid-2">
        <div>
          <h3>Warm transfer (consult first)</h3>
          <label htmlFor="xfer-agent">Colleague</label>
          <select id="xfer-agent" value={target} onChange={(e) => setTarget(e.target.value)}>
            <option value="">Choose…</option>
            {(agents ?? []).map((a) => (
              <option key={a.id} value={a.id} disabled={!a.can_take_consult}>
                {a.display_name} — {a.can_take_consult ? "available" : a.state} ({a.skills.join(", ")})
              </option>
            ))}
          </select>
          <div className="row" style={{ marginTop: 6 }}>
            <button className="btn btn-teal btn-sm" disabled={busy || !target || !ac.warm_transfer_start?.enabled}
              onClick={() => send("warm_transfer_start", { target_agent_id: target })}>Start consultation</button>
            <button className="btn btn-sm" disabled={busy || !ac.warm_transfer_complete?.enabled}
              onClick={() => send("warm_transfer_complete")}>Complete transfer</button>
            <button className="btn btn-sm" disabled={busy || !ac.conference?.enabled}
              onClick={() => send("conference")}>Conference</button>
            <button className="btn btn-sm" disabled={busy || !ac.warm_transfer_cancel?.enabled}
              onClick={() => send("warm_transfer_cancel")}>Cancel consultation</button>
          </div>
          <p className="small muted">If the colleague declines or does not answer, the customer stays with you
            ({detail.capabilities?.warm_transfer_failure_behaviour?.replaceAll("_", " ")}).</p>
          {ts.status ? <Badge tone="blue">Consultation: {ts.status.replaceAll("_", " ")}</Badge> : null}
        </div>
        <div>
          <h3>Blind transfer to a queue</h3>
          <label htmlFor="xfer-queue">Queue</label>
          <select id="xfer-queue" value={queue} onChange={(e) => setQueue(e.target.value)}>
            <option value="">Choose…</option>
            {(queues ?? []).map((q) => <option key={q.id} value={q.id}>{q.name}</option>)}
          </select>
          <button className="btn btn-sm" style={{ marginTop: 6 }} disabled={busy || !queue || !ac.blind_transfer?.enabled}
            onClick={() => send("blind_transfer", { target_queue_id: queue })}>Transfer to queue</button>
          <p className="small muted">The interaction keeps its history and waiting time; it is not a new contact.</p>
        </div>
      </div>
    </div>
  );
}

function SecurePayment({ detail, send, busy }: { detail: Json; send: (a: string, p?: Json) => void; busy: boolean }) {
  const [amount, setAmount] = useState("");
  const ac = detail.available_controls ?? {};
  const pay = (detail.payments ?? [])[0];
  if (!detail.capabilities?.secure_payment) return null;
  return (
    <details style={{ marginTop: 8 }}>
      <summary className="small">Take a card payment securely</summary>
      <div className="row" style={{ marginTop: 6 }}>
        <label htmlFor="amt" className="sr-only">Amount in pounds</label>
        <input id="amt" style={{ width: 120 }} placeholder="£ amount" value={amount} onChange={(e) => setAmount(e.target.value)} />
        <button className="btn btn-sm" disabled={busy || !ac.start_secure_payment?.enabled || !(Number(amount) > 0)}
          onClick={() => send("start_secure_payment", { amount_minor: Math.round(Number(amount) * 100), currency: "GBP" })}>
          Start secure capture</button>
      </div>
      <p className="small muted">The customer keys card details into the provider&apos;s secure system. Card data never
        reaches this application; recording is paused by the provider and the pause must be confirmed.</p>
      {pay ? (
        <p className="small">Payment: <Badge tone={pay.status === "completed" ? "green" : "blue"}>{pay.status}</Badge>
          {" "}recording paused (confirmed): {pay.recording_paused_confirmed ? "yes" : "not yet"}
          {pay.result_reference ? ` · ref ${pay.result_reference}` : ""}</p>
      ) : null}
    </details>
  );
}
