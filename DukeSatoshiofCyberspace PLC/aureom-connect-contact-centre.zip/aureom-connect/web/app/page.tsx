"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { API_URL, getSession, setSession } from "@/lib/api";

const DEMO_USERS = [
  ["amira.khan", "Agent · Billing, Care"],
  ["ben.hughes", "Agent · Technical, Welsh"],
  ["eilidh.fraser", "Agent · Care, Billing"],
  ["femi.adeyemi", "Agent · Billing, Outbound"],
  ["grace.thornton", "Supervisor"],
  ["harriet.lowe", "Quality reviewer"],
  ["ian.rowe", "Workforce manager"],
  ["kit.admin", "Administrator (MFA)"],
];

export default function Login() {
  const router = useRouter();
  const [org, setOrg] = useState("pennine");
  const [email, setEmail] = useState("amira.khan@pennine.example");
  const [password, setPassword] = useState("");
  const [totp, setTotp] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [oidc, setOidc] = useState<{ enabled: boolean; status: string } | null>(null);

  useEffect(() => {
    const s = getSession();
    if (s) router.replace(s.user.agent_id ? "/agent" : "/supervisor");
    fetch(`${API_URL}/v1/auth/oidc/config`).then((r) => r.json()).then(setOidc).catch(() => setOidc(null));
  }, [router]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const r = await fetch(`${API_URL}/v1/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ organisation: org, email, password, totp_code: totp || null }),
      });
      const j = await r.json();
      if (!r.ok) throw new Error(`${j.error?.message ?? "Sign-in failed"} [${j.error?.code ?? r.status}]`);
      setSession({ accessToken: j.access_token, refreshToken: j.refresh_token, user: j.user });
      router.replace(j.user.agent_id ? "/agent" : "/supervisor");
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="login-wrap">
      <main className="panel login-card" aria-labelledby="login-title">
        <div style={{ background: "var(--nav)", color: "#fff", margin: -14, marginBottom: 14, padding: "16px 18px",
          borderRadius: "8px 8px 0 0" }}>
          <strong style={{ letterSpacing: ".08em" }}>AUREOM CONNECT</strong>
          <div className="small" style={{ color: "var(--nav-text)" }}>Contact Centre · organisational sign-in</div>
        </div>
        <h1 id="login-title">Sign in</h1>
        <div className="banner banner-warn" role="note">
          <strong>⚠ Warning:</strong>
          <div className="small">Demonstration environment: fictional customers and <strong>simulated telephony</strong>
            (provider events only, no audio).</div>
        </div>
        <form onSubmit={submit} className="stack">
          <div className="field"><label htmlFor="org">Organisation</label>
            <input id="org" value={org} onChange={(e) => setOrg(e.target.value)} autoComplete="organization" /></div>
          <div className="field"><label htmlFor="email">E-mail</label>
            <input id="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="username" /></div>
          <div className="field"><label htmlFor="password">Password</label>
            <input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password" /></div>
          <div className="field"><label htmlFor="totp">One-time code (required for administrators)</label>
            <input id="totp" inputMode="numeric" value={totp} onChange={(e) => setTotp(e.target.value)}
              autoComplete="one-time-code" placeholder="6 digits" /></div>
          {error ? <div className="banner banner-error" role="alert"><strong>✖ Failure:</strong><div className="small">{error}</div></div> : null}
          <button className="btn btn-primary" disabled={busy} type="submit">{busy ? "Signing in…" : "Sign in"}</button>
        </form>
        <p className="small muted" style={{ marginTop: 10 }}>
          Organisational single sign-on (OIDC): {oidc?.enabled ? "configured" : "not configured in this environment"}.
        </p>
        <details style={{ marginTop: 8 }}>
          <summary className="small">Demo accounts (password in README)</summary>
          <ul className="small">
            {DEMO_USERS.map(([u, r]) => (
              <li key={u}><button type="button" className="btn btn-ghost btn-sm"
                onClick={() => setEmail(`${u}@pennine.example`)}>{u}@pennine.example</button> — {r}</li>
            ))}
          </ul>
        </details>
      </main>
    </div>
  );
}
