"use client";

import { useEffect, useState } from "react";
import { API_URL } from "@/lib/api";

interface Msg { id: string; sender: string; body: string; sent_at: string }

export default function ChatDemo() {
  const [name, setName] = useState("");
  const [first, setFirst] = useState("");
  const [topic, setTopic] = useState("TECH");
  const [session, setSession] = useState<{ id: string; token: string; reference: string } | null>(null);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [status, setStatus] = useState("");
  const [joined, setJoined] = useState(false);
  const [text, setText] = useState("");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!session) return;
    const poll = async () => {
      const r = await fetch(`${API_URL}/v1/channels/webchat/sessions/${session.id}/messages`, {
        headers: { Authorization: `Bearer ${session.token}` } });
      if (r.ok) {
        const j = await r.json();
        setMsgs(j.messages);
        setStatus(j.status);
        setJoined(j.agent_joined);
      }
    };
    poll();
    const i = setInterval(poll, 2000);
    return () => clearInterval(i);
  }, [session]);

  const start = async () => {
    setError(null);
    const r = await fetch(`${API_URL}/v1/channels/webchat/sessions`, { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, topic, first_message: first }) });
    const j = await r.json();
    if (!r.ok) { setError(j.error?.message ?? "Could not start chat"); return; }
    setSession({ id: j.session_id, token: j.token, reference: j.reference });
  };
  const send = async () => {
    await fetch(`${API_URL}/v1/channels/webchat/sessions/${session!.id}/messages`, { method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${session!.token}` }, body: JSON.stringify({ body: text }) });
    setText("");
  };
  return (
    <main style={{ maxWidth: 520, margin: "32px auto", padding: 16 }}>
      <div className="panel">
        <h1>Pennine web chat (demo)</h1>
        <p className="small muted">A fictional customer-facing chat for the demonstration. Do not enter real personal details.</p>
        {!session ? (
          <div className="stack">
            <div className="field"><label htmlFor="n">Your name</label><input id="n" value={name} onChange={(e) => setName(e.target.value)} /></div>
            <div className="field"><label htmlFor="t">Topic</label><select id="t" value={topic} onChange={(e) => setTopic(e.target.value)}>
              <option value="TECH">Problem with my supply</option><option value="CARE">Something else</option></select></div>
            <div className="field"><label htmlFor="f">How can we help?</label><textarea id="f" value={first} onChange={(e) => setFirst(e.target.value)} /></div>
            <button className="btn btn-primary" disabled={!name || !first} onClick={start}>Start chat</button>
            {error ? <p role="alert" className="badge badge-red">{error}</p> : null}
          </div>
        ) : (
          <>
            <p className="small">Reference {session.reference} · {joined ? "An adviser has joined" : "Waiting for an adviser…"} · {status}</p>
            <div className="panel" style={{ background: "var(--panel-2)", minHeight: 200 }} aria-live="polite">
              {msgs.map((m) => (
                <div key={m.id} className={`chat-bubble ${m.sender === "customer" ? "chat-agent" : "chat-customer"}`}>
                  <div className="small muted">{m.sender === "customer" ? "You" : "Adviser"}</div>{m.body}</div>
              ))}
            </div>
            <div className="row" style={{ marginTop: 8 }}>
              <label htmlFor="m" className="sr-only">Message</label>
              <input id="m" value={text} onChange={(e) => setText(e.target.value)} style={{ flex: 1 }} />
              <button className="btn btn-primary" disabled={!text} onClick={send}>Send</button>
            </div>
          </>
        )}
      </div>
    </main>
  );
}
