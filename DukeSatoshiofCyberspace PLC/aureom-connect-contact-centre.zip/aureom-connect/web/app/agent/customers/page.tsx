"use client";

import { Fragment, useState } from "react";
import { Badge, Banner, ErrorText, Panel } from "@/components/ui";
import { api, type Json } from "@/lib/api";
import { fmtDateTime, useAction } from "@/lib/hooks";

export default function Customers() {
  const [q, setQ] = useState("");
  const [rows, setRows] = useState<Json[]>([]);
  const [rec, setRec] = useState<Json | null>(null);
  const act = useAction();
  const search = () => act.run(async () => setRows(await api<Json[]>(`/v1/customers?q=${encodeURIComponent(q)}`)));
  const open = (id: string) => act.run(async () => setRec(await api<Json>(`/v1/customers/${id}`)));
  return (
    <>
      <h1>Customers</h1>
      <div className="grid-2">
        <Panel title="Search">
          <form className="row" onSubmit={(e) => { e.preventDefault(); search(); }}>
            <label htmlFor="cq" className="sr-only">Name, reference, phone or e-mail</label>
            <input id="cq" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Name, reference, phone or e-mail" style={{ flex: 1 }} />
            <button className="btn btn-primary" type="submit">Search</button>
          </form>
          <table style={{ marginTop: 8 }}>
            <thead><tr><th>Name</th><th>Reference</th><th>Flags</th></tr></thead>
            <tbody>
              {rows.map((c) => (
                <tr key={c.id} className={rec?.id === c.id ? "selected" : ""}>
                  <td><button className="btn btn-ghost btn-sm" onClick={() => open(c.id)}>{c.display_name}</button></td>
                  <td className="mono">{c.customer_ref}</td>
                  <td>{c.support_flags.map((f: string) => <Badge key={f} tone="blue">{f.replaceAll("_", " ")}</Badge>)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <ErrorText error={act.error} />
        </Panel>
        {rec ? (
          <Panel title={`${rec.display_name} · ${rec.customer_ref}`}>
            <Banner kind="warn" title="Restricted details withheld">Restricted information is shown only inside an
              interaction you own after the customer has been verified.</Banner>
            <dl className="kv">
              {rec.contact_points.map((c: Json) => <Fragment key={c.id}><dt>{c.kind} ({c.label})</dt><dd>{c.value}</dd></Fragment>)}
              <dt>Language</dt><dd>{rec.preferred_language}</dd>
              <dt>Timezone</dt><dd>{rec.timezone}</dd>
              <dt>Account</dt><dd>{rec.account?.name ?? "—"}</dd>
            </dl>
            <h3 style={{ marginTop: 10 }}>Consent &amp; objections</h3>
            <ul className="small">
              {rec.consents.map((c: Json) => <li key={c.id}>{c.purpose}: {c.status} ({c.basis}) {fmtDateTime(c.captured_at)}</li>)}
              {rec.objections.map((o: Json) => <li key={o.id}><Badge tone="amber">⚠ objection {o.scope}</Badge> {o.note}</li>)}
              {rec.preferences.map((p: Json) => <li key={`${p.channel}-${p.purpose}`}>{p.channel}/{p.purpose}: {p.allowed ? "allowed" : "not wanted"}</li>)}
            </ul>
            <h3>Cases</h3>
            <ul className="small">{rec.cases.map((c: Json) => <li key={c.id}>{c.case_ref} {c.title} — <Badge>{c.status}</Badge>
              {c.sla ? <Badge tone={c.sla.state === "breached" ? "red" : c.sla.state === "at_risk" ? "amber" : "neutral"}>
                {c.sla.label}: {c.sla.state}</Badge> : null}</li>)}</ul>
            <h3>Open tasks</h3>
            <ul className="small">{rec.open_tasks.map((t: Json) => <li key={t.id}>{t.title} · due {fmtDateTime(t.due_at)}</li>)}</ul>
            <h3>Interaction history</h3>
            <table><thead><tr><th>When</th><th>Ref</th><th>Channel</th><th>Outcome</th></tr></thead>
              <tbody>{rec.interactions.map((i: Json) => (
                <tr key={i.id}><td>{fmtDateTime(i.created_at)}</td><td className="mono">{i.reference}</td>
                  <td>{i.channel} {i.direction}{i.transfer_count ? " · transferred" : ""}</td><td>{i.disposition_code ?? i.status}</td></tr>
              ))}</tbody></table>
            <p className="small muted">Source systems: {rec.source_refs.map((s: Json) => `${s.system}:${s.external_id}`).join(", ")}</p>
          </Panel>
        ) : <Panel title="Record"><p className="muted small">Select a customer.</p></Panel>}
      </div>
    </>
  );
}
