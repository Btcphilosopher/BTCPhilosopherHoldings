"use client";

import { useEffect, useState } from "react";
import { useWorkspace } from "@/components/AgentContext";
import { Badge, Banner, ErrorText, Panel } from "@/components/ui";
import { ContextPanel } from "@/components/workspace/ContextPanel";
import { ConversationPanel } from "@/components/workspace/ConversationPanel";
import { api, type Json } from "@/lib/api";
import { useEvents } from "@/lib/events";
import { fmtDuration, since, useAction, useNow, useResource } from "@/lib/hooks";

export default function Workspace() {
  const { ws, reload: reloadWs, error } = useWorkspace();
  const { watch } = useEvents();
  const [selected, setSelected] = useState<string | null>(null);
  const act = useAction();
  useNow(1000);

  const active: Json[] = ws?.active ?? [];
  useEffect(() => {
    if (!ws) return;
    const ids = active.map((a) => String(a.id));
    if (selected && !ids.includes(selected) && !ws.offers.some((o: Json) => String(o.interaction.id) === selected)) {
      // keep showing a just-completed interaction until the agent moves on
    }
    if (!selected && ids.length) setSelected(ids[0]);
    watch(ids);
  }, [ws]); // eslint-disable-line react-hooks/exhaustive-deps

  const { data: detail, reload: reloadDetail } = useResource<Json>(selected ? `/v1/interactions/${selected}` : null,
    { pollMs: 3000 });
  const reload = () => { reloadWs(); reloadDetail(); };

  const accept = (o: Json) => act.run(async () => {
    await api(`/v1/interactions/${o.interaction.id}/accept`, { body: { offer_id: o.id }, idempotent: true });
    setSelected(String(o.interaction.id));
    reload();
  });
  const reject = (o: Json) => act.run(async () => {
    await api(`/v1/interactions/${o.interaction.id}/reject`, { body: { offer_id: o.id, reason: "declined by agent" },
      idempotent: true });
    reload();
  });
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const o = ws?.offers?.[0];
      if (!e.altKey || !o) return;
      if (e.key.toLowerCase() === "a") { e.preventDefault(); accept(o); }
      if (e.key.toLowerCase() === "r") { e.preventDefault(); reject(o); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  if (!ws) return <p>{error ?? "Loading…"}</p>;
  return (
    <>
      <h1 className="sr-only">Agent workspace</h1>
      {ws.provider.status !== "connected" ? (
        <Banner kind="error" title={`Telephony provider ${ws.provider.status}`}>Voice controls are disabled. Calls in
          progress continue at the provider; state is reconciled when it reconnects.</Banner>
      ) : null}
      {ws.agent.reconcile_required ? (
        <Banner kind="warn" title="Call state needs reconciling">{ws.agent.reconcile_reason}. You will not receive new
          work until your call state matches the provider. Use “Reconcile call state” in the top bar.</Banner>
      ) : null}
      <div className="grid-3">
        {/* ------------------------------------------------ left: queue & tasks */}
        <div>
          <Panel title="Offers" id="offers">
            <div aria-live="assertive">
              {ws.offers.length === 0 ? <p className="small muted">No offers. You receive work when you are
                available, connected and your device registration is confirmed.</p> : null}
              {ws.offers.map((o: Json) => {
                const left = Math.max(0, (new Date(o.expires_at).getTime() - Date.now()) / 1000);
                return (
                  <div key={o.id} className="offer-card" role="alert">
                    <div className="row between">
                      <strong>{o.kind === "consult" ? "Consultation request" : `Incoming ${o.interaction.channel}`}</strong>
                      <Badge tone="teal">{Math.ceil(left)}s</Badge>
                    </div>
                    <div className="small">{o.interaction.reference} · {o.interaction.queue?.name ?? "—"}
                      {o.interaction.caller ? ` · caller ${o.interaction.caller}` : ""}
                      {o.interaction.callback_id ? " · callback" : ""}</div>
                    <div className="row" style={{ marginTop: 8 }}>
                      <button className="btn btn-teal" onClick={() => accept(o)} disabled={act.busy} aria-keyshortcuts="Alt+A">Accept (Alt+A)</button>
                      <button className="btn" onClick={() => reject(o)} disabled={act.busy} aria-keyshortcuts="Alt+R">Decline</button>
                    </div>
                  </div>
                );
              })}
            </div>
            <ErrorText error={act.error} />
          </Panel>
          <Panel title="My work">
            {active.length === 0 ? <p className="small muted">Nothing in progress.</p> : null}
            {active.map((it) => (
              <button key={it.id} className={`btn list-button list-item ${selected === String(it.id) ? "selected" : ""}`}
                style={{ borderColor: selected === String(it.id) ? "var(--blue)" : undefined }}
                aria-current={selected === String(it.id)} onClick={() => setSelected(String(it.id))}>
                <div className="row between">
                  <strong>{it.reference}</strong>
                  {it.status === "active" && it.channel === "voice" ? <span className="live-indicator small"><span className="dot" />live</span>
                    : <Badge>{it.status.replaceAll("_", " ")}</Badge>}
                </div>
                <div className="small muted">{it.channel} · {it.direction} · {it.customer?.display_name ?? "unidentified"}
                  {it.connected_at ? ` · ${fmtDuration(since(it.connected_at))}` : ""}</div>
              </button>
            ))}
          </Panel>
          <Panel title="My queues">
            <table>
              <thead><tr><th>Queue</th><th>Waiting</th><th>Longest</th></tr></thead>
              <tbody>
                {ws.queues.map((q: Json) => (
                  <tr key={q.id}><td>{q.name}{!q.open ? <div><Badge tone="amber">⚠ closed</Badge></div> : null}</td>
                    <td>{q.waiting}</td><td>{fmtDuration(q.longest_wait_seconds)}</td></tr>
                ))}
              </tbody>
            </table>
          </Panel>
          <Panel title="Tasks" actions={<a href="/agent/tasks" className="small">All tasks</a>}>
            {ws.tasks.slice(0, 6).map((t: Json) => (
              <div key={t.id} className="list-item small">
                <strong>{t.title}</strong>
                <div className="row">
                  {t.overdue ? <Badge tone="amber">⚠ overdue</Badge> : null}
                  <span className="muted">{t.assigned_to_me ? "you" : "queue"} · due {t.due_at ? new Date(t.due_at).toLocaleString("en-GB") : "—"}</span>
                </div>
              </div>
            ))}
            <CampaignPreview />
          </Panel>
        </div>
        {/* ------------------------------------------------ centre: conversation */}
        <div>
          <ConversationPanel detail={detail} reload={reload} />
        </div>
        {/* ------------------------------------------------ right: context & knowledge */}
        <div>
          <ContextPanel detail={detail} reload={reload} />
        </div>
      </div>
    </>
  );
}

function CampaignPreview() {
  const { data } = useResource<Json[]>("/v1/campaigns", { live: false, pollMs: 0 });
  const act = useAction();
  const active = (data ?? []).filter((c) => c.status === "active");
  if (!active.length) return null;
  return (
    <div style={{ marginTop: 10 }}>
      <h3>Preview campaigns</h3>
      {active.map((c) => (
        <div key={c.id} className="row between small">
          <span>{c.name} <span className="muted">({c.purpose})</span></span>
          <button className="btn btn-sm" disabled={act.busy} onClick={() => act.run(() =>
            api(`/v1/campaigns/${c.id}/next`, { method: "POST" }))}>Preview next</button>
        </div>
      ))}
      <ErrorText error={act.error} />
    </div>
  );
}
