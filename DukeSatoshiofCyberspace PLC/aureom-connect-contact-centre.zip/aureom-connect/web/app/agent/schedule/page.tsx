"use client";

import { useState } from "react";
import { Badge, ErrorText, OkText, Panel } from "@/components/ui";
import { api, type Json } from "@/lib/api";
import { fmtDateTime, useAction, useResource } from "@/lib/hooks";

export default function MySchedule() {
  const { data, reload } = useResource<Json>("/v1/workforce/my-schedule", { live: false, pollMs: 30000 });
  const [shift, setShift] = useState("");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [reason, setReason] = useState("");
  const act = useAction();
  const request = () => act.run(async () => {
    await api("/v1/workforce/shift-change-requests", { body: { shift_id: shift, kind: "change",
      proposed_start_at: new Date(start).toISOString(), proposed_end_at: new Date(end).toISOString(), reason } });
    reload();
  }, () => "Request sent to workforce management. Your published shift stays as it is until approved.");
  return (
    <>
      <h1>My schedule</h1>
      <div className="grid-2">
        <Panel title="Published shifts (next 14 days)">
          <table>
            <thead><tr><th>Day</th><th>Time</th><th>Breaks</th><th>Queues</th></tr></thead>
            <tbody>
              {(data?.shifts ?? []).map((s: Json) => (
                <tr key={s.id}>
                  <td>{new Date(s.start_at).toLocaleDateString("en-GB", { weekday: "short", day: "2-digit", month: "short" })}</td>
                  <td>{new Date(s.start_at).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}–
                    {new Date(s.end_at).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}
                    {s.note ? <div className="small muted">{s.note}</div> : null}</td>
                  <td className="small">{s.activities.map((a: Json) => `${a.kind} ${new Date(a.start).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}`).join(", ")}</td>
                  <td className="small">{s.queue_codes.join(", ")}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Panel>
        <Panel title="Request a change">
          <div className="field"><label htmlFor="sh">Shift</label>
            <select id="sh" value={shift} onChange={(e) => setShift(e.target.value)}>
              <option value="">Choose…</option>
              {(data?.shifts ?? []).map((s: Json) => <option key={s.id} value={s.id}>{fmtDateTime(s.start_at)}</option>)}
            </select></div>
          <div className="row">
            <div style={{ flex: 1 }}><label htmlFor="st">New start</label><input id="st" type="datetime-local" value={start} onChange={(e) => setStart(e.target.value)} /></div>
            <div style={{ flex: 1 }}><label htmlFor="en">New end</label><input id="en" type="datetime-local" value={end} onChange={(e) => setEnd(e.target.value)} /></div>
          </div>
          <div className="field"><label htmlFor="rs">Reason</label><input id="rs" value={reason} onChange={(e) => setReason(e.target.value)} /></div>
          <button className="btn btn-primary" style={{ marginTop: 8 }} disabled={!shift || !start || !end || reason.length < 3 || act.busy}
            onClick={request}>Send request</button>
          <OkText message={act.message} />
          <ErrorText error={act.error} />
          <h3 style={{ marginTop: 12 }}>My requests</h3>
          <ul className="small">{(data?.change_requests ?? []).map((r: Json) => (
            <li key={r.id}><Badge tone={r.status === "approved" ? "green" : r.status === "declined" ? "red" : "blue"}>{r.status}</Badge> {r.kind}: {r.reason}
              {r.decision_note ? ` — ${r.decision_note}` : ""}</li>))}</ul>
          <h3>Leave</h3>
          <ul className="small">{(data?.leave ?? []).map((l: Json) => <li key={l.id}>{l.kind} {fmtDateTime(l.start_at)} → {fmtDateTime(l.end_at)} · {l.status}</li>)}</ul>
        </Panel>
      </div>
    </>
  );
}
