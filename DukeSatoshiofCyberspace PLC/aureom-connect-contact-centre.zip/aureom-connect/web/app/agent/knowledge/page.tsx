"use client";

import { useState } from "react";
import { Badge, ErrorText, Panel } from "@/components/ui";
import { api, type Json } from "@/lib/api";
import { fmtDateTime, useAction, useResource } from "@/lib/hooks";

export default function Knowledge() {
  const [q, setQ] = useState("");
  const [results, setResults] = useState<Json[] | null>(null);
  const [open, setOpen] = useState<Json | null>(null);
  const { data: all } = useResource<Json[]>("/v1/knowledge/articles", { live: false, pollMs: 0 });
  const act = useAction();
  const search = () => act.run(async () => setResults((await api<Json>(`/v1/knowledge/search?q=${encodeURIComponent(q)}`)).results));
  const view = (id: string) => act.run(async () => setOpen(await api<Json>(`/v1/knowledge/articles/${id}`)));
  const list = results ?? (all ?? []).filter((a) => a.current).map((a) => ({ ...a.current, article_id: a.id, title: a.current.title,
    visibility: a.visibility, owner_team: a.owner_team, version_id: a.current.id }));
  return (
    <>
      <h1>Knowledge</h1>
      <p className="muted">Only approved versions that are effective today are shown. Internal articles must not be read out
        or sent to customers.</p>
      <div className="grid-2">
        <Panel title="Articles">
          <form className="row" onSubmit={(e) => { e.preventDefault(); search(); }}>
            <label htmlFor="kq" className="sr-only">Search</label>
            <input id="kq" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search approved knowledge" style={{ flex: 1 }} />
            <button className="btn btn-primary" type="submit">Search</button>
            {results ? <button className="btn" type="button" onClick={() => setResults(null)}>Clear</button> : null}
          </form>
          {list.map((r: Json) => (
            <div key={r.version_id} className="list-item" style={{ marginTop: 6 }}>
              <button className="btn btn-ghost list-button" onClick={() => view(r.article_id)}><strong>{r.title}</strong></button>
              <div className="row small">
                <Badge tone={r.visibility === "internal" ? "navy" : "green"}>{r.visibility === "internal" ? "Internal only" : "Customer-visible"}</Badge>
                <span className="muted">v{r.version} · {r.owner_team} · effective {fmtDateTime(r.effective_from)}</span>
              </div>
            </div>
          ))}
          <ErrorText error={act.error} />
        </Panel>
        <Panel title="Article">
          {open?.current ? (
            <>
              <h2>{open.current.title}</h2>
              <dl className="kv small">
                <dt>Version</dt><dd>{open.current.version} ({open.current.status})</dd>
                <dt>Owner</dt><dd>{open.owner ?? "—"} · {open.owner_team}</dd>
                <dt>Approved by</dt><dd>{open.current.reviewed_by ?? "—"} on {fmtDateTime(open.current.approved_at)}</dd>
                <dt>Effective</dt><dd>{fmtDateTime(open.current.effective_from)} → {open.current.effective_to ? fmtDateTime(open.current.effective_to) : "open"}</dd>
                <dt>Next review</dt><dd>{fmtDateTime(open.current.review_due_at)}</dd>
                <dt>Visibility</dt><dd>{open.visibility}</dd>
              </dl>
              <p style={{ whiteSpace: "pre-wrap", marginTop: 10 }}>{open.current.body}</p>
            </>
          ) : <p className="muted small">Select an article.</p>}
        </Panel>
      </div>
    </>
  );
}
