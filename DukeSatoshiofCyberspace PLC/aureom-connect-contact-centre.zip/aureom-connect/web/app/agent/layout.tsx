"use client";

import { AgentStatusBar, WorkspaceProvider } from "@/components/AgentContext";
import { AGENT_NAV, AppFrame } from "@/components/Shell";

export default function AgentLayout({ children }: { children: React.ReactNode }) {
  return (
    <AppFrame nav={AGENT_NAV} area="Agent" provider={WorkspaceProvider} topbar={<AgentStatusBar />}>
      {children}
    </AppFrame>
  );
}
