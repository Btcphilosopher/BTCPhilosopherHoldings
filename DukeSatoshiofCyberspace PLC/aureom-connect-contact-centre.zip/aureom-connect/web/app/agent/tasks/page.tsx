"use client";

import { useState } from "react";
import { Badge, ErrorText, Panel } from "@/components/ui";
import { api, type Json } from "@/lib/api";
import { fmtDateTime, useAction, useResource } from "@/lib/hooks";

export default function Tasks() {
  const [status, setStatus] = useState("open,in_progress");
  const { data, reload } = useResource<Json[]>(`/v1/tasks?scope=mine&status=${status}`);
  const { data: cases, reload: reloadCases } = useResource<Json[]>("/v1/cases?mine=true&status=open,pending_customer,pending_internal");
  const act = useAction();
  const update = (t: Json, body: Json) => act.run(async () => {
    await api(`/v1/tasks/${t.id}`, { method: "PATCH", body: { expected_version: t.version, ...body } });
    reload();
  });
  return (
    <>
      <h1>Tasks &amp; cases</h1>
      <div className="tabs" role="tablist">
        {[["open,in_progress", "Open"], ["done", "Done"], ["cancelled", "Cancelled"]].map(([v, l]) => (
          <button key={v} role="tab" aria-selected={status === v} onClick={() => setStatus(v)}>{l}</button>
        ))}
      </div>
      <Panel title="Tasks (mine and my queues)">
        <table>
          <thead><tr><th>Task</th><th>Due</th><th>Service level</th><th>Assigned</th><th>Actions</th></tr></thead>
          <tbody>
            {(data ?? []).map((t) => (
              <tr key={t.id}>
                <td><strong>{t.title}</strong><div className="small muted">{t.kind} · {t.priority}</div></td>
                <td>{fmtDateTime(t.due_at)}</td>
                <td>{t.sla ? <Badge tone={t.sla.state === "breached" ? "red" : t.sla.state === "at_risk" ? "amber" : "neutral"}>
                  {t.sla.state === "breached" ? "✖ " : t.sla.state === "at_risk" ? "⚠ " : ""}{t.sla.label}: {t.sla.state}</Badge> : "—"}</td>
                <td>{t.assignee ?? t.assignee_queue ?? "—"}</td>
                <td className="row">
                  {t.status === "open" ? <button className="btn btn-sm" onClick={() => update(t, { status: "in_progress" })}>Start</button> : null}
                  {["open", "in_progress"].includes(t.status) ? <button className="btn btn-sm btn-primary"
                    onClick={() => update(t, { status: "done", note: "completed" })}>Complete</button> : null}
                  {["done", "cancelled"].includes(t.status) ? <button className="btn btn-sm"
                    onClick={() => { const reason = prompt("Reason for reopening (required)"); if (reason) update(t, { status: "open", reason }); }}>
                    Reopen…</button> : null}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <ErrorText error={act.error} />
      </Panel>
      <Panel title="My open cases">
        <table>
          <thead><tr><th>Case</th><th>Status</th><th>Due</th><th>Service level</th><th></th></tr></thead>
          <tbody>
            {(cases ?? []).map((c) => (
              <tr key={c.id}>
                <td><strong>{c.case_ref}</strong> {c.title}<div className="small muted">{c.category} · escalation {c.escalation_level}</div></td>
                <td><Badge>{c.status.replaceAll("_", " ")}</Badge></td>
                <td>{fmtDateTime(c.due_at)}</td>
                <td>{c.sla ? <Badge tone={c.sla.kind === "contractual_commitment" ? "navy" : "neutral"}>{c.sla.label}: {c.sla.state}</Badge> : "—"}</td>
                <td><CaseActions c={c} onDone={reloadCases} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>
    </>
  );
}

function CaseActions({ c, onDone }: { c: Json; onDone: () => void }) {
  const act = useAction();
  const resolve = () => {
    const outcome = prompt("Outcome code (e.g. resolved_first_contact, info_provided)");
    if (!outcome) return;
    act.run(async () => {
      await api(`/v1/cases/${c.id}`, { method: "PATCH", body: { expected_version: c.version, status: "resolved", outcome_code: outcome } });
      onDone();
    });
  };
  const escalate = () => {
    const reason = prompt("Escalation reason");
    if (!reason) return;
    act.run(async () => {
      await api(`/v1/cases/${c.id}/escalate`, { body: { expected_version: c.version, reason } });
      onDone();
    });
  };
  return (
    <div className="row">
      <button className="btn btn-sm" onClick={resolve} disabled={act.busy}>Resolve…</button>
      <button className="btn btn-sm" onClick={escalate} disabled={act.busy}>Escalate…</button>
      {act.error ? <span className="badge badge-red">{act.error}</span> : null}
    </div>
  );
}
