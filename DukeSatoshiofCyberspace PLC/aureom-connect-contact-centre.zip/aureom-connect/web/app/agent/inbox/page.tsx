"use client";

import Link from "next/link";
import { useWorkspace } from "@/components/AgentContext";
import { Badge, Panel } from "@/components/ui";
import type { Json } from "@/lib/api";
import { fmtDateTime } from "@/lib/hooks";

export default function Inbox() {
  const { ws } = useWorkspace();
  const items: Json[] = (ws?.active ?? []).filter((i: Json) => i.channel !== "voice");
  const offers: Json[] = (ws?.offers ?? []).filter((o: Json) => o.interaction.channel !== "voice");
  return (
    <>
      <h1>Inbox</h1>
      <p className="muted">E-mail and web-chat work arrives through their own channel adapters and is routed like calls.
        Accept offers and reply from the <Link href="/agent">Workspace</Link>.</p>
      <div className="grid-2">
        <Panel title={`Offered (${offers.length})`}>
          {offers.length === 0 ? <p className="small muted">No e-mail or chat offers.</p> : null}
          {offers.map((o) => (
            <div key={o.id} className="list-item"><strong>{o.interaction.reference}</strong> <Badge tone="teal">{o.interaction.channel}</Badge>
              <div className="small muted">{o.interaction.subject ?? ""} · expires {fmtDateTime(o.expires_at)}</div></div>
          ))}
        </Panel>
        <Panel title={`In progress (${items.length})`}>
          {items.length === 0 ? <p className="small muted">Nothing in progress.</p> : null}
          {items.map((i) => (
            <div key={i.id} className="list-item"><strong>{i.reference}</strong> <Badge>{i.channel}</Badge> <Badge>{i.status}</Badge>
              <div className="small muted">{i.subject ?? ""} · {i.customer?.display_name ?? "unidentified"}</div></div>
          ))}
        </Panel>
      </div>
      <Panel title="Try the customer web chat">
        <p className="small">Open <Link href="/chat-demo" target="_blank">the demo chat page</Link> in another window to
          start a chat as a (fictional) customer. Supervisors can inject a simulated inbound e-mail from Administration.</p>
      </Panel>
    </>
  );
}
