import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AUREOM CONNECT – Contact Centre",
  description: "Agent workspace and supervisor console (demonstration with simulated telephony)",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-GB">
      <body>{children}</body>
    </html>
  );
}
