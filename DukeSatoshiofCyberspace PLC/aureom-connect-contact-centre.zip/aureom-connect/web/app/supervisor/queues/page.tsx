"use client";

import { useState } from "react";
import { Badge, ErrorText, OkText, Panel } from "@/components/ui";
import { api, has, type Json } from "@/lib/api";
import { fmtDuration, useAction, useResource } from "@/lib/hooks";

export default function Queues() {
  const { data, reload } = useResource<Json[]>("/v1/queues");
  const { data: cbs } = useResource<Json[]>("/v1/callbacks");
  const [edit, setEdit] = useState<Json | null>(null);
  const act = useAction();
  const save = () => act.run(async () => {
    const reason = prompt("Reason for this change (audited)");
    if (!reason) return;
    await api(`/v1/admin/queues/${edit!.id}`, { method: "PATCH", body: {
      routing_priority: Number(edit!.routing_priority), offer_timeout_seconds: Number(edit!.offer_timeout_seconds),
      overflow_after_seconds: edit!.overflow_after_seconds ? Number(edit!.overflow_after_seconds) : null, reason } });
    setEdit(null);
    reload();
  }, () => "Queue updated.");
  return (
    <>
      <h1>Queues</h1>
      <Panel title="Configuration">
        <table>
          <thead><tr><th>Queue</th><th>Channels</th><th>Requirements</th><th>Routing priority</th><th>Overflow</th><th>Service level</th><th>Now</th><th></th></tr></thead>
          <tbody>{(data ?? []).map((q) => (
            <tr key={q.id}>
              <td><strong>{q.name}</strong><div className="mono small">{q.code}</div></td>
              <td className="small">{q.channel}</td>
              <td className="small">skills: {q.required_skills.join(", ") || "none"}{q.required_language ? ` · lang ${q.required_language}` : ""}</td>
              <td>{q.routing_priority}<div className="small muted">operational order only</div></td>
              <td className="small">{q.overflow_queue_id ? `after ${q.overflow_after_seconds}s` : "—"}</td>
              <td className="small">{q.sla ? <>
                <Badge tone={q.sla.kind === "contractual_commitment" ? "navy" : "neutral"}>{q.sla.kind === "contractual_commitment" ? "Contractual" : "Internal target"}</Badge>
                <div>{q.sla.target_percent}% in {q.sla.target_seconds}s</div>{q.sla.contract_ref ? <div className="muted">{q.sla.contract_ref}</div> : null}</> : "—"}</td>
              <td className="small">{q.waiting} waiting · longest {fmtDuration(q.longest_wait_seconds)}<div>{q.open ? "open" : "⚠ closed"}</div></td>
              <td>{has("queue.manage") ? <button className="btn btn-sm" onClick={() => setEdit({ ...q })}>Edit</button> : null}</td>
            </tr>
          ))}</tbody>
        </table>
        {edit ? (
          <div className="panel" style={{ marginTop: 10, background: "var(--panel-2)" }}>
            <h3>Edit {edit.name}</h3>
            <div className="row">
              <div><label htmlFor="rp">Routing priority (0–10)</label><input id="rp" type="number" value={edit.routing_priority}
                onChange={(e) => setEdit({ ...edit, routing_priority: e.target.value })} /></div>
              <div><label htmlFor="ot">Offer timeout (s)</label><input id="ot" type="number" value={edit.offer_timeout_seconds}
                onChange={(e) => setEdit({ ...edit, offer_timeout_seconds: e.target.value })} /></div>
              <div><label htmlFor="ov">Overflow after (s)</label><input id="ov" type="number" value={edit.overflow_after_seconds ?? ""}
                onChange={(e) => setEdit({ ...edit, overflow_after_seconds: e.target.value })} /></div>
            </div>
            <div className="row" style={{ marginTop: 8 }}><button className="btn btn-primary btn-sm" onClick={save}>Save</button>
              <button className="btn btn-sm" onClick={() => setEdit(null)}>Cancel</button></div>
          </div>
        ) : null}
        <OkText message={act.message} />
        <ErrorText error={act.error} />
      </Panel>
      <Panel title="Callback backlog">
        <table>
          <thead><tr><th>Ref</th><th>Queue</th><th>Window</th><th>Status</th><th>Attempts</th><th>Promise</th></tr></thead>
          <tbody>{(cbs ?? []).map((c) => (
            <tr key={c.id}><td className="mono">{c.reference}</td><td>{c.queue}</td>
              <td className="small">{new Date(c.window_start).toLocaleString("en-GB")} → {new Date(c.window_end).toLocaleTimeString("en-GB")}</td>
              <td><Badge>{c.status}</Badge>{c.capacity_reserved ? <Badge tone="green">reserved</Badge> : null}</td>
              <td>{c.attempts}/{c.max_attempts}</td><td className="small">{c.promise_text}</td></tr>
          ))}</tbody>
        </table>
      </Panel>
    </>
  );
}
