"use client";

import { useState } from "react";
import { Badge, Banner, ErrorText, OkText, Panel } from "@/components/ui";
import { API_URL, api, getSession, type Json } from "@/lib/api";
import { fmtDateTime, useAction, useResource } from "@/lib/hooks";

export default function Quality() {
  const { data: rubric } = useResource<Json>("/v1/quality/rubric", { live: false, pollMs: 0 });
  const { data: reviews, reload } = useResource<Json[]>("/v1/quality/reviews");
  const { data: recs } = useResource<Json[]>("/v1/recordings", { live: false, pollMs: 10000 });
  const [sel, setSel] = useState<Json | null>(null);
  const [scores, setScores] = useState<Record<string, { score: number; evidence: string }>>({});
  const [comments, setComments] = useState("");
  const act = useAction();
  const sample = () => act.run(async () => { const r = await api<Json>("/v1/quality/sample", { method: "POST" }); reload(); return r; },
    (r: Json) => `${r.queued} queued. ${r.method}`);
  const submit = () => act.run(async () => {
    const r = await api<Json>(`/v1/quality/reviews/${sel!.id}/submit`, { body: { scores, comments } });
    setSel(null);
    setScores({});
    reload();
    return r;
  }, (r: Json) => `Submitted: ${r.total_percent}% against rubric v${r.rubric_version}.`);
  return (
    <>
      <h1>Quality</h1>
      <Banner kind="info" title="People score interactions against a published rubric">Scores describe one interaction,
        are reviewable by the agent (acknowledge or dispute), and are never produced by AI.</Banner>
      <div className="grid-2">
        <Panel title="Review queue" actions={<button className="btn btn-sm" onClick={sample} disabled={act.busy}>Sample interactions</button>}>
          <table><thead><tr><th>Interaction</th><th>Reason</th><th>Status</th><th>Score</th><th></th></tr></thead>
            <tbody>{(reviews ?? []).map((r) => (
              <tr key={r.id}><td className="mono">{r.interaction_reference}</td><td className="small">{r.selection_reason.replaceAll("_", " ")}</td>
                <td><Badge tone={r.status === "disputed" ? "amber" : r.status === "acknowledged" ? "green" : "neutral"}>{r.status}</Badge></td>
                <td>{r.total_percent ?? "—"}</td>
                <td>{["queued", "in_progress", "disputed"].includes(r.status) ? <button className="btn btn-sm" onClick={() => { setSel(r); setScores({}); }}>Review</button> : null}</td></tr>
            ))}</tbody></table>
        </Panel>
        <Panel title={sel ? `Review ${sel.interaction_reference}` : `Rubric: ${rubric?.name ?? ""} v${rubric?.version ?? ""}`}>
          <p className="small muted">{rubric?.documentation}</p>
          {sel?.dispute_note ? <Banner kind="warn" title="Agent dispute">{sel.dispute_note}</Banner> : null}
          {(rubric?.criteria ?? []).map((c: Json) => (
            <div key={c.id} className="list-item">
              <div className="row between"><strong>{c.label}</strong><span className="small muted">weight {c.weight}</span></div>
              <div className="small muted">{Object.entries(c.guidance).map(([k, v]) => `${k}: ${v}`).join(" · ")}</div>
              {sel ? (
                <div className="row" style={{ marginTop: 4 }}>
                  {c.scale.map((v: number) => (
                    <label key={v} className="row" style={{ fontWeight: 400 }}>
                      <input type="radio" name={`s-${c.id}`} style={{ width: "auto" }} checked={scores[c.id]?.score === v}
                        onChange={() => setScores({ ...scores, [c.id]: { score: v, evidence: scores[c.id]?.evidence ?? "" } })} />{v}
                    </label>
                  ))}
                  <input aria-label={`Evidence for ${c.label}`} placeholder="Evidence (required)" style={{ flex: 1 }}
                    value={scores[c.id]?.evidence ?? ""} onChange={(e) => setScores({ ...scores, [c.id]: { score: scores[c.id]?.score ?? 0, evidence: e.target.value } })} />
                </div>
              ) : null}
            </div>
          ))}
          {sel ? (
            <>
              <div className="field"><label htmlFor="qc">Comments</label><textarea id="qc" value={comments} onChange={(e) => setComments(e.target.value)} /></div>
              <button className="btn btn-primary" style={{ marginTop: 8 }} onClick={submit} disabled={act.busy}>Submit review</button>
            </>
          ) : null}
          <OkText message={act.message} />
          <ErrorText error={act.error} />
        </Panel>
      </div>
      <Panel title="Recordings">
        <p className="small muted">Listening requires the recording permission, a role allowed by the recording&apos;s policy and a stated
          purpose. Every attempt — allowed or refused — is written to the audit trail.</p>
        <table><thead><tr><th>Interaction</th><th>Status</th><th>Purpose / policy roles</th><th>Retention</th><th>Access</th></tr></thead>
          <tbody>{(recs ?? []).map((r) => <RecordingRow key={r.id} r={r} />)}</tbody></table>
      </Panel>
    </>
  );
}

function RecordingRow({ r }: { r: Json }) {
  const [url, setUrl] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const listen = async () => {
    setErr(null);
    const res = await fetch(`${API_URL}/v1/recordings/${r.id}/media?purpose=quality_review`, {
      headers: { Authorization: `Bearer ${getSession()?.accessToken}` } });
    if (!res.ok) { setErr((await res.json()).error?.message ?? "Access denied"); return; }
    setUrl(URL.createObjectURL(await res.blob()));
  };
  return (
    <tr>
      <td className="mono">{r.interaction_reference}</td>
      <td><Badge tone={r.status === "available" ? "green" : r.status === "deleted" ? "neutral" : "blue"}>{r.status}</Badge>
        {r.is_synthetic_media ? <Badge tone="amber">⚠ synthetic tone</Badge> : null}
        {r.pause_intervals.length ? <div className="small muted">paused {r.pause_intervals.length}× ({r.pause_intervals.map((p: Json) => p.reason).join(", ")})</div> : null}</td>
      <td className="small">{r.purpose.replaceAll("_", " ")} · {r.access_roles.join(", ")}</td>
      <td className="small">{fmtDateTime(r.retention_until)}{r.legal_hold ? " · legal hold" : ""}</td>
      <td>{r.you_can_listen ? (url ? <audio controls src={url} aria-label="Recording playback (synthetic)" /> :
        <button className="btn btn-sm" onClick={listen}>Listen (quality review)</button>) : <span className="small muted">{r.access_note}</span>}
        {err ? <div className="badge badge-red">{err}</div> : null}</td>
    </tr>
  );
}
