"use client";

import { useState } from "react";
import { Badge, Banner, ErrorText, OkText, Panel } from "@/components/ui";
import { api, type Json } from "@/lib/api";
import { fmtDateTime, useAction, useResource } from "@/lib/hooks";

export default function Campaigns() {
  const { data: list, reload } = useResource<Json[]>("/v1/campaigns");
  const [sel, setSel] = useState<string | null>(null);
  const { data: c, reload: reloadC } = useResource<Json>(sel ? `/v1/campaigns/${sel}` : null, { pollMs: 3000 });
  const { data: rules } = useResource<Json[]>("/v1/calling-rules", { live: false, pollMs: 0 });
  const [file, setFile] = useState<File | null>(null);
  const act = useAction();
  const upload = () => act.run(async () => {
    const fd = new FormData();
    fd.append("file", file!);
    await api(`/v1/campaigns/${sel}/imports`, { form: fd });
    reloadC();
    reload();
  }, () => "Uploaded. The worker validates every row; review the results before activating.");
  const activate = () => act.run(async () => {
    await api(`/v1/campaigns/${sel}/activate`, { body: { expected_version: c!.version } });
    reloadC();
    reload();
  }, () => "Campaign activated.");
  const pause = () => act.run(async () => { await api(`/v1/campaigns/${sel}/pause`, { method: "POST" }); reloadC(); reload(); });
  return (
    <>
      <h1>Campaigns</h1>
      <Banner kind="info" title="Preview dialling only">Agents review each contact and dial themselves. Predictive or
        progressive dialling is not part of this release. Eligibility is re-checked before every dial.</Banner>
      <div className="grid-2" style={{ gridTemplateColumns: "320px 1fr" }}>
        <Panel title="Campaigns">
          {(list ?? []).map((x) => (
            <button key={x.id} className="btn list-button list-item" onClick={() => setSel(x.id)} aria-current={sel === x.id}>
              <strong>{x.name}</strong>
              <div className="row small"><Badge tone={x.status === "active" ? "green" : x.status === "review" ? "blue" : "neutral"}>{x.status}</Badge>
                <span className="muted">{x.purpose} · {x.queue} · caller ID {x.caller_id}</span></div>
            </button>
          ))}
        </Panel>
        <Panel title={c ? c.name : "Campaign"} actions={c ? <div className="row">
          {c.status === "review" ? <button className="btn btn-primary btn-sm" onClick={activate} disabled={act.busy}>Approve &amp; activate</button> : null}
          {c.status === "active" ? <button className="btn btn-sm" onClick={pause} disabled={act.busy}>Pause</button> : null}
        </div> : null}>
          {!c ? <p className="small muted">Select a campaign.</p> : (
            <>
              <p className="small">{c.description}</p>
              <dl className="kv small">
                <dt>Purpose</dt><dd>{c.purpose} ({c.jurisdiction} rules)</dd>
                <dt>Dial mode</dt><dd>{c.dial_mode}</dd>
                <dt>Caller ID</dt><dd>{c.caller_id} (owned, verified)</dd>
                <dt>Attempts</dt><dd>max {c.max_attempts_per_contact} per contact</dd>
                <dt>Activated</dt><dd>{fmtDateTime(c.activated_at)}</dd>
              </dl>
              {["draft", "review"].includes(c.status) ? (
                <div className="panel" style={{ marginTop: 10, background: "var(--panel-2)" }}>
                  <h3>Import contacts (CSV: name, phone, customer_ref, timezone)</h3>
                  <div className="row"><input type="file" accept=".csv,text/csv" aria-label="CSV file" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
                    <button className="btn btn-sm" disabled={!file || act.busy} onClick={upload}>Upload &amp; validate</button></div>
                  <p className="small muted">A different person must approve activation (four-eyes).</p>
                </div>
              ) : null}
              {c.imports.map((i: Json) => (
                <div key={i.id} className="list-item small" style={{ marginTop: 8 }}>
                  <strong>{i.filename}</strong> <Badge>{i.status}</Badge> {i.total_rows} rows · {i.valid_rows} valid · {i.invalid_rows} invalid
                  {i.errors.length ? <ul>{i.errors.slice(0, 8).map((e: Json) => <li key={e.row}>row {e.row}: {(e.errors ?? [e.error]).join(", ")}</li>)}</ul> : null}
                </div>
              ))}
              {c.review_summary?.total_contacts !== undefined ? (
                <div style={{ marginTop: 10 }}>
                  <h3>Review summary</h3>
                  <p className="small">{c.review_summary.total_contacts} contacts · {Object.entries(c.review_summary.by_status).map(([k, v]) => `${k}: ${v}`).join(" · ")}</p>
                  <p className="small">Pre-check failures: {Object.entries(c.review_summary.precheck_failures).map(([k, v]) => `${k}: ${v}`).join(" · ") || "none"}</p>
                  <p className="small muted">{c.review_summary.note}</p>
                </div>
              ) : null}
              {c.contacts ? (
                <div className="scroll" style={{ marginTop: 8 }}>
                  <table><thead><tr><th>Contact</th><th>Number</th><th>TZ</th><th>Status</th><th>Attempts</th><th>Pre-check</th></tr></thead>
                    <tbody>{c.contacts.map((x: Json) => (
                      <tr key={x.id}><td>{x.display_name}</td><td className="mono">{x.number}</td><td className="small">{x.timezone}</td>
                        <td><Badge tone={x.status === "excluded" ? "amber" : "neutral"}>{x.status}</Badge></td><td>{x.attempts}</td>
                        <td className="small">{(x.precheck?.checks ?? []).filter((k: Json) => !k.passed).map((k: Json) => k.check).join(", ") || "—"}</td></tr>
                    ))}</tbody></table>
                </div>
              ) : null}
            </>
          )}
          <OkText message={act.message} />
          <ErrorText error={act.error} />
        </Panel>
      </div>
      <Panel title="Calling rule sets (jurisdiction-specific, versioned)">
        <table><thead><tr><th>Jurisdiction</th><th>Version</th><th>Status</th><th>Effective</th><th>Windows (Mon / Sat / Sun)</th><th>Notes</th></tr></thead>
          <tbody>{(rules ?? []).map((r) => (
            <tr key={r.id}><td>{r.jurisdiction}</td><td>v{r.version}</td><td><Badge tone={r.status === "active" ? "green" : "neutral"}>{r.status}</Badge></td>
              <td className="small">{fmtDateTime(r.effective_from)} → {r.effective_to ? fmtDateTime(r.effective_to) : "open"}</td>
              <td className="small">{JSON.stringify(r.rules.calling_windows["1"])} / {JSON.stringify(r.rules.calling_windows["6"])} / {JSON.stringify(r.rules.calling_windows["7"])}</td>
              <td className="small">{r.source_notes}</td></tr>
          ))}</tbody></table>
      </Panel>
    </>
  );
}
