"use client";

import { useState } from "react";
import { AgentStateBadge, Badge, Banner, ErrorText, OkText, Panel, Stat } from "@/components/ui";
import { api, type Json } from "@/lib/api";
import { fmtDuration, fmtTime, useAction, useNow, useResource } from "@/lib/hooks";

export default function LiveOps() {
  const { data, error, reload } = useResource<Json>("/v1/ops/live", { pollMs: 3000 });
  const act = useAction();
  const [why, setWhy] = useState<Json | null>(null);
  useNow(1000);
  if (!data) return <p>{error ?? "Loading…"}</p>;
  const counts = data.agent_state_counts as Record<string, number>;
  const longest = Math.max(0, ...data.queues.map((q: Json) => q.longest_wait_seconds));
  const monitor = (a: Json, mode: string) => {
    const reason = prompt(`Reason for ${mode} monitoring of ${a.display_name} (recorded and shown to the agent)`);
    if (!reason || !a.current_interaction_id) return;
    act.run(() => api(`/v1/monitoring`, { body: { interaction_id: a.current_interaction_id, mode, reason } }),
      () => `${mode} requested — ${a.display_name} is notified.`);
  };
  const explain = (iid: string) => act.run(async () => setWhy({ iid, rows: await api<Json[]>(`/v1/ops/routing-decisions/${iid}`) }));
  return (
    <>
      <h1>Live operations</h1>
      {data.provider.status !== "connected" ? (
        <Banner kind="error" title={`Telephony provider ${data.provider.status}`}>Voice controls are disabled for agents;
          calls are reconciled when the provider reconnects.</Banner>
      ) : null}
      <div className="grid-4" style={{ marginBottom: 12 }}>
        <Stat label="Waiting now" value={data.waiting.length} />
        <Stat label="Longest wait" value={fmtDuration(longest)} />
        <Stat label="Agents available" value={counts.available ?? 0} hint="State available + connected + device confirmed" />
        <Stat label="On interaction / ACW" value={`${counts.on_interaction ?? 0} / ${counts.after_call_work ?? 0}`} />
        <Stat label="Missed offers (1h)" value={data.missed_offers_last_hour} />
        <Stat label="Callbacks due ≤30 min" value={data.callback_backlog.due_within_30_min} />
        <Stat label="Cases past due" value={data.case_workload.past_due} />
        <Stat label="QA reviews queued" value={data.quality_queue} />
      </div>
      <OkText message={act.message} />
      <ErrorText error={act.error} />
      <div className="grid-2">
        <Panel title="Queues">
          <table>
            <thead><tr><th>Queue</th><th>Status</th><th>Waiting</th><th>Longest</th><th>Priority</th></tr></thead>
            <tbody>{data.queues.map((q: Json) => (
              <tr key={q.id}><td><strong>{q.name}</strong><div className="small muted">{q.code}</div></td>
                <td>{q.open ? <Badge tone="green">open</Badge> : <Badge tone="amber">⚠ closed</Badge>}<div className="small muted">{q.hours_status}</div></td>
                <td>{q.waiting}</td><td>{fmtDuration(q.longest_wait_seconds)}</td><td>{q.routing_priority}</td></tr>
            ))}</tbody>
          </table>
        </Panel>
        <Panel title={`Waiting interactions (${data.waiting.length})`}>
          {data.waiting.length === 0 ? <p className="small muted">No one is waiting.</p> : null}
          <table>
            <thead><tr><th>Ref</th><th>Queue</th><th>Waiting</th><th>Status</th><th></th></tr></thead>
            <tbody>{data.waiting.map((w: Json) => (
              <tr key={w.id}><td className="mono">{w.reference}{w.callback_id ? <div><Badge>callback</Badge></div> : null}
                {w.urgency_flag ? <div><Badge tone="amber">⚠ {w.urgency_flag}</Badge></div> : null}</td>
                <td>{w.queue?.code}</td><td>{fmtDuration(w.wait_seconds)}</td><td><Badge>{w.status}</Badge></td>
                <td><button className="btn btn-sm" onClick={() => explain(w.id)}>Why?</button></td></tr>
            ))}</tbody>
          </table>
          {why ? (
            <div className="panel" style={{ marginTop: 8, background: "var(--panel-2)" }}>
              <div className="row between"><strong>Routing decisions</strong><button className="btn btn-sm" onClick={() => setWhy(null)}>Close</button></div>
              {why.rows.slice(-1).map((d: Json) => (
                <div key={d.decided_at} className="small">
                  <p>{fmtTime(d.decided_at)} · <strong>{d.outcome}</strong> — {d.explanation}</p>
                  <ul>{d.candidates.map((c: Json) => <li key={c.agent_id}>{c.agent}: {c.eligible ? "eligible" : c.reasons.join("; ")}</li>)}</ul>
                </div>
              ))}
            </div>
          ) : null}
        </Panel>
      </div>
      <Panel title="Agents">
        <table>
          <thead><tr><th>Agent</th><th>State</th><th>Application</th><th>Telephony (provider)</th><th>Skills / queues</th><th>Notes</th><th>Monitoring</th></tr></thead>
          <tbody>{data.agents.map((a: Json) => (
            <tr key={a.id}>
              <td><strong>{a.display_name}</strong><div className="small muted">{a.team} · {a.languages.join(", ")}</div></td>
              <td><AgentStateBadge state={a.state} /><div className="small muted">{a.state_reason ?? ""} · {fmtDuration((Date.now() - new Date(a.state_since).getTime()) / 1000)}</div></td>
              <td>{a.presence === "online" ? <Badge tone="green">connected</Badge> : <Badge>offline</Badge>}</td>
              <td>{a.telephony_registration === "registered" ? <Badge tone="green">registered</Badge> : <Badge tone="amber">⚠ {a.telephony_registration}</Badge>}</td>
              <td className="small">{a.skills.join(", ")}<div className="muted">{a.queues.join(", ")}</div></td>
              <td className="small">{a.reconcile_required ? <Badge tone="amber">⚠ reconcile: {a.reconcile_reason}</Badge> : null}
                {!a.readiness.ready && a.state !== "on_interaction" ? <div className="muted">{a.readiness.blockers.join("; ")}</div> : null}</td>
              <td>{a.state === "on_interaction" && a.current_interaction_id ? (
                <div className="row"><button className="btn btn-sm" onClick={() => monitor(a, "listen")}>Listen</button>
                  <button className="btn btn-sm" onClick={() => monitor(a, "coach")}>Coach</button></div>) : <span className="muted small">—</span>}</td>
            </tr>
          ))}</tbody>
        </table>
        <p className="small muted">Monitoring requires permission and a reason, is audited, and the agent always sees it. Barge-in is
          disabled because the current provider does not support it.</p>
      </Panel>
      <div className="grid-2">
        <Panel title="Routing failures (last hour)">
          {data.routing_failures.length === 0 ? <p className="small muted">None.</p> : null}
          {data.routing_failures.map((f: Json, i: number) => (
            <div key={i} className="list-item small"><strong>{fmtTime(f.decided_at)}</strong> {f.explanation}
              <ul>{f.excluded.map((c: Json) => <li key={c.agent_id}>{c.agent}: {c.reasons.join("; ")}</li>)}</ul></div>
          ))}
        </Panel>
        <Panel title="Backlog">
          <h3>Callbacks</h3>
          <p className="small">{Object.entries(data.callback_backlog.by_status).map(([k, v]) => `${k}: ${v}`).join(" · ") || "none"}</p>
          <h3>Cases &amp; tasks</h3>
          <p className="small">{Object.entries(data.case_workload.by_status).map(([k, v]) => `${k}: ${v}`).join(" · ")}</p>
          <p className="small">Tasks open {data.case_workload.tasks_open} · overdue {data.case_workload.tasks_overdue}</p>
          <h3>After-call work running long</h3>
          {data.after_call_work_overdue.length === 0 ? <p className="small muted">None.</p> :
            <ul className="small">{data.after_call_work_overdue.map((x: Json) => <li key={x.interaction_id}>{x.agent}: {fmtDuration(x.seconds)}</li>)}</ul>}
          <h3>Active monitoring</h3>
          {data.active_monitoring.length === 0 ? <p className="small muted">None.</p> :
            <ul className="small">{data.active_monitoring.map((m: Json) => <li key={m.id}>{m.mode} since {fmtTime(m.started_at)} (agent notified)
              <button className="btn btn-sm" style={{ marginLeft: 6 }} onClick={() => act.run(async () => { await api(`/v1/monitoring/${m.id}/stop`, { method: "POST" }); reload(); })}>Stop</button></li>)}</ul>}
        </Panel>
      </div>
    </>
  );
}
