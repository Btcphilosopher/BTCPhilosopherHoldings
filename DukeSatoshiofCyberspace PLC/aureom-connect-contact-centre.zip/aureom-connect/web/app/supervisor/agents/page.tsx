"use client";

import { useState } from "react";
import { ForecastChart } from "@/components/ForecastChart";
import { AgentStateBadge, Badge, ErrorText, OkText, Panel, Stat } from "@/components/ui";
import { api, has, type Json } from "@/lib/api";
import { fmtDateTime, useAction, useResource } from "@/lib/hooks";

export default function Agents() {
  const [tab, setTab] = useState("roster");
  return (
    <>
      <h1>Agents</h1>
      <div className="tabs" role="tablist" aria-label="Agent views">
        {[["roster", "Roster & state"], ["schedules", "Schedules"], ["requests", "Shift change requests"], ["forecast", "Forecast & staffing"]].map(([k, l]) => (
          <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)}>{l}</button>
        ))}
      </div>
      {tab === "roster" ? <Roster /> : tab === "schedules" ? <Schedules /> : tab === "requests" ? <Requests /> : <Forecast />}
    </>
  );
}

function Roster() {
  const { data, reload } = useResource<Json[]>("/v1/agents");
  const act = useAction();
  const setState = (a: Json, state: string) => {
    const reason = prompt(`Reason for setting ${a.display_name} to ${state}`);
    if (!reason) return;
    act.run(async () => { await api(`/v1/agents/${a.id}/state`, { method: "PUT", body: { state, reason } }); reload(); });
  };
  return (
    <Panel title="Roster">
      <table>
        <thead><tr><th>Agent</th><th>State</th><th>Presence / telephony</th><th>Skills</th><th>Queues</th><th>Readiness</th><th></th></tr></thead>
        <tbody>{(data ?? []).map((a) => (
          <tr key={a.id}>
            <td><strong>{a.display_name}</strong><div className="small muted">{a.team}</div></td>
            <td><AgentStateBadge state={a.state} /><div className="small muted">{a.state_reason}</div></td>
            <td className="small">{a.presence} / {a.telephony_registration}</td>
            <td className="small">{a.skills.join(", ")}</td>
            <td className="small">{a.queues.join(", ")}</td>
            <td className="small">{a.readiness.ready ? <Badge tone="green">ready</Badge> : a.readiness.blockers.join("; ")}</td>
            <td>{has("agent.manage_state") && !["on_interaction", "connecting", "call_offered"].includes(a.state) ? (
              <button className="btn btn-sm" onClick={() => setState(a, "unavailable")}>Set unavailable…</button>) : null}</td>
          </tr>
        ))}</tbody>
      </table>
      <p className="small muted">Supervisors cannot make an agent available: only the agent can, once their application and
        telephony device are connected and call state is consistent.</p>
      <ErrorText error={act.error} />
    </Panel>
  );
}

function Schedules() {
  const { data: list } = useResource<Json[]>("/v1/workforce/schedules", { live: false, pollMs: 0 });
  const [sel, setSel] = useState<string | null>(null);
  const { data: s, reload } = useResource<Json>(sel ? `/v1/workforce/schedules/${sel}` : null, { live: false, pollMs: 0 });
  const act = useAction();
  const publish = () => act.run(async () => {
    const r = await api<Json>(`/v1/workforce/schedules/${sel}/publish`, { method: "POST" });
    reload();
    return r;
  }, (r: Json) => `Published with ${r.warnings.length} warning(s).`);
  return (
    <div className="grid-2" style={{ gridTemplateColumns: "280px 1fr" }}>
      <Panel title="Schedules">
        {(list ?? []).map((x) => (
          <button key={x.id} className="btn list-button list-item" onClick={() => setSel(x.id)} aria-current={sel === x.id}>
            <strong>{x.name}</strong> <Badge tone={x.status === "published" ? "green" : "blue"}>{x.status}</Badge></button>
        ))}
      </Panel>
      <Panel title={s ? s.name : "Schedule"} actions={s?.status === "draft" && has("schedule.manage") ?
        <button className="btn btn-primary btn-sm" onClick={publish} disabled={act.busy}>Publish</button> : null}>
        {!s ? <p className="small muted">Select a schedule.</p> : (
          <>
            {s.status === "published" ? <p className="small"><Badge tone="green">Published</Badge> Shifts can only change through an
              approved shift-change request. Forecasts never change published shifts.</p> : null}
            <h3>Conflicts &amp; checks</h3>
            {s.conflicts.length === 0 ? <p className="small muted">No conflicts.</p> : (
              <ul className="small">{s.conflicts.map((c: Json, i: number) => (
                <li key={i}><Badge tone={c.severity === "blocking" ? "red" : "amber"}>{c.severity === "blocking" ? "✖ blocking" : "⚠ warning"}</Badge>{" "}
                  {c.type.replaceAll("_", " ")} — {c.agent}{c.detail ? `: ${c.detail}` : ""}</li>))}</ul>)}
            <div className="scroll" style={{ maxHeight: 420 }}>
              <table>
                <thead><tr><th>Agent</th><th>Start</th><th>End</th><th>Activities</th><th>Queues</th></tr></thead>
                <tbody>{s.shifts.map((sh: Json) => (
                  <tr key={sh.id}><td>{sh.agent}</td><td>{fmtDateTime(sh.start_at)}</td><td>{fmtDateTime(sh.end_at)}</td>
                    <td className="small">{sh.activities.map((a: Json) => a.kind).join(", ")}</td><td className="small">{sh.queue_codes.join(", ")}</td></tr>
                ))}</tbody>
              </table>
            </div>
          </>
        )}
        <OkText message={act.message} />
        <ErrorText error={act.error} />
      </Panel>
    </div>
  );
}

function Requests() {
  const { data, reload } = useResource<Json[]>("/v1/workforce/shift-change-requests");
  const act = useAction();
  const decide = (id: string, approve: boolean) => act.run(async () => {
    const note = prompt(approve ? "Approval note" : "Reason for declining") ?? "";
    await api(`/v1/workforce/shift-change-requests/${id}/decide`, { body: { approve, note } });
    reload();
  });
  return (
    <Panel title="Shift change requests">
      <table>
        <thead><tr><th>Agent</th><th>Kind</th><th>Proposed</th><th>Reason</th><th>Status</th><th></th></tr></thead>
        <tbody>{(data ?? []).map((r) => (
          <tr key={r.id}><td>{r.agent}</td><td>{r.kind}</td>
            <td className="small">{fmtDateTime(r.proposed_start_at)} → {fmtDateTime(r.proposed_end_at)}</td>
            <td className="small">{r.reason}</td><td><Badge>{r.status}</Badge></td>
            <td>{r.status === "requested" && has("schedule.manage") ? <div className="row">
              <button className="btn btn-sm btn-primary" onClick={() => decide(r.id, true)}>Approve</button>
              <button className="btn btn-sm" onClick={() => decide(r.id, false)}>Decline</button></div> : null}</td></tr>
        ))}</tbody>
      </table>
      {!has("schedule.manage") ? <p className="small muted">Decisions are made by workforce management.</p> : null}
      <ErrorText error={act.error} />
    </Panel>
  );
}

function Forecast() {
  const tomorrow = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
  const [queue, setQueue] = useState("BILLING");
  const [day, setDay] = useState(tomorrow);
  const [res, setRes] = useState<Json | null>(null);
  const act = useAction();
  const run = () => act.run(async () => setRes(await api<Json>("/v1/workforce/forecasts", { body: { queue, target_date: day } })));
  const gaps = (res?.staffing ?? []).filter((r: Json) => r.status === "short");
  return (
    <>
      <div className="row" style={{ marginBottom: 12 }}>
        <div><label htmlFor="fq">Queue</label><select id="fq" value={queue} onChange={(e) => setQueue(e.target.value)}>
          <option>BILLING</option><option>TECH</option><option>CARE</option></select></div>
        <div><label htmlFor="fd">Day</label><input id="fd" type="date" value={day} onChange={(e) => setDay(e.target.value)} /></div>
        <button className="btn btn-primary" style={{ alignSelf: "flex-end" }} onClick={run} disabled={act.busy}>Generate forecast</button>
      </div>
      <ErrorText error={act.error} />
      {res ? (
        <>
          <div className="grid-4" style={{ marginBottom: 12 }}>
            <Stat label="Forecast contacts" value={Math.round(res.intervals.reduce((s: number, i: Json) => s + i.expected, 0))} />
            <Stat label="Peak required agents" value={Math.max(0, ...res.intervals.map((i: Json) => i.required_agents))} />
            <Stat label="Intervals short of staff" value={gaps.length} />
            <Stat label="History used" value={`${res.parameters.weeks} weeks`} />
          </div>
          <Panel title="Forecast vs observed">
            <ForecastChart rows={res.staffing} />
            <p className="small muted" style={{ marginTop: 8 }}>Method: {res.method.replaceAll("_", " ")} · range {res.parameters.range} ·
              shrinkage {res.parameters.shrinkage * 100}% · target {res.parameters.service_target.percent}% in
              {" "}{res.parameters.service_target.seconds}s (Erlang C). {res.notes} {res.policy}</p>
          </Panel>
        </>
      ) : <p className="muted small">Forecasts are generated on request and stored separately from observed demand.</p>}
    </>
  );
}
