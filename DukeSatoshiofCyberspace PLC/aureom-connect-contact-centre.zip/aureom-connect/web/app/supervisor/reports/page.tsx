"use client";

import { useMemo, useState } from "react";
import { Banner, Panel, Stat } from "@/components/ui";
import type { Json } from "@/lib/api";
import { fmtDuration, useResource } from "@/lib/hooks";

const PRESETS: [string, number][] = [["Today", 0], ["Last 7 days", 7], ["Last 30 days", 30]];

export default function Reports() {
  const [days, setDays] = useState(0);
  const [synthetic, setSynthetic] = useState(false);
  const [queue, setQueue] = useState("");
  const { data: queues } = useResource<Json[]>("/v1/queues", { live: false, pollMs: 0 });
  const start = useMemo(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - days);
    return d.toISOString();
  }, [days]);
  const qs = `start=${encodeURIComponent(start)}&include_synthetic_history=${synthetic}${queue ? `&queue_id=${queue}` : ""}`;
  const { data: r, loading } = useResource<Json>(`/v1/reports/summary?${qs}`, { pollMs: 10000 });
  const { data: agents } = useResource<Json>(`/v1/reports/agents?start=${encodeURIComponent(start)}`, { pollMs: 15000 });
  const pct = (v: number | null) => (v === null || v === undefined ? "—" : `${v}%`);
  return (
    <>
      <h1>Reports</h1>
      <div className="row" style={{ marginBottom: 12 }} role="group" aria-label="Report filters">
        {PRESETS.map(([l, d]) => <button key={l} className={`btn btn-sm ${days === d ? "btn-primary" : ""}`} aria-pressed={days === d}
          onClick={() => setDays(d)}>{l}</button>)}
        <label htmlFor="rq" className="sr-only">Queue</label>
        <select id="rq" value={queue} onChange={(e) => setQueue(e.target.value)} style={{ width: 200 }}>
          <option value="">All queues</option>{(queues ?? []).map((q) => <option key={q.id} value={q.id}>{q.name}</option>)}</select>
        <label className="row" style={{ fontWeight: 400 }}><input type="checkbox" style={{ width: "auto" }} checked={synthetic}
          onChange={(e) => setSynthetic(e.target.checked)} /> Include synthetic history</label>
      </div>
      {!r ? <p>Loading…</p> : (
        <div style={{ opacity: loading ? 0.6 : 1 }}>
          <p className="small muted">Window {new Date(r.window.start).toLocaleString("en-GB")} → {new Date(r.window.end).toLocaleString("en-GB")} ·
            basis: {r.window.time_basis} · short abandon &lt; {r.parameters.short_abandon_seconds}s · repeat window {r.parameters.repeat_contact_days} days</p>
          <div className="grid-4" style={{ marginBottom: 12 }}>
            <Stat label="Offered" value={r.volumes.offered} />
            <Stat label="Answered" value={`${r.volumes.answered} (${pct(r.rates.answer_rate_pct)})`} />
            <Stat label="Abandoned (excl. short)" value={`${r.volumes.abandoned} (${pct(r.rates.abandon_rate_pct)})`} />
            <Stat label="Service level" value={pct(r.rates.service_level_pct)} hint="Answered within threshold ÷ (offered − short abandons)" />
            <Stat label="Average speed of answer" value={fmtDuration(r.times_seconds.average_speed_of_answer)} />
            <Stat label="Average handling time" value={fmtDuration(r.times_seconds.average_handling_time)} />
            <Stat label="Transfers (counted once)" value={`${r.transfers.interactions_transferred} (${pct(r.rates.transfer_rate_pct)})`} />
            <Stat label="Repeat contacts" value={`${r.repeat_contacts.repeats} of ${r.repeat_contacts.identified_contacts}`} />
          </div>
          <Banner kind="warn" title="Handling time is not a quality measure on its own">{r.caution}</Banner>
          <div className="grid-2">
            <Panel title="Times">
              <dl className="kv">
                <dt>Talk (total / avg)</dt><dd>{fmtDuration(r.times_seconds.talk_total)} / {fmtDuration(r.times_seconds.average_talk)}</dd>
                <dt>Hold (total / avg)</dt><dd>{fmtDuration(r.times_seconds.hold_total)} / {fmtDuration(r.times_seconds.average_hold)}</dd>
                <dt>After-call work</dt><dd>{fmtDuration(r.times_seconds.acw_total)} / {fmtDuration(r.times_seconds.average_acw)}</dd>
                <dt>P90 wait (answered)</dt><dd>{fmtDuration(r.times_seconds.p90_queue_wait_answered)}</dd>
                <dt>Deflected</dt><dd>voicemail {r.volumes.voicemail} · callback {r.volumes.callback_requested}</dd>
              </dl>
            </Panel>
            <Panel title="Outcomes">
              <dl className="kv">
                <dt>Callbacks</dt><dd>{r.callbacks.completed} completed of {r.callbacks.requested} requested · {r.callbacks.still_open} open ·
                  completion {pct(r.callbacks.completion_rate_pct)}</dd>
                <dt>Customer feedback</dt><dd>{r.customer_feedback.responses} responses ({pct(r.customer_feedback.response_rate_pct)}) ·
                  mean {r.customer_feedback.mean_score ?? "—"} · CSAT {pct(r.customer_feedback.csat_pct)}</dd>
                <dt>Cases</dt><dd>{r.cases.resolved} resolved of {r.cases.created} created · FCR {r.cases.first_contact_resolution}</dd>
                <dt>Outbound</dt><dd>{Object.entries(r.outbound.attempts_by_status).map(([k, v]) => `${k} ${v}`).join(" · ") || "none"}
                  {Object.keys(r.outbound.refusal_reasons).length ? <div className="small muted">refused for: {Object.entries(r.outbound.refusal_reasons).map(([k, v]) => `${k} ${v}`).join(", ")}</div> : null}</dd>
                <dt>Data quality</dt><dd className="small">events {Object.entries(r.data_quality.provider_events_by_status).map(([k, v]) => `${k} ${v}`).join(" · ")} ·
                  ingestion lag p50 {r.data_quality.ingestion_lag_ms_p50 ?? "—"} ms, p95 {r.data_quality.ingestion_lag_ms_p95 ?? "—"} ms ·
                  needing reconciliation {r.data_quality.interactions_needing_reconciliation}</dd>
              </dl>
            </Panel>
          </div>
          <Panel title="By agent (workload, not quality)">
            <table><thead><tr><th>Agent</th><th>Handled</th><th>Transferred out</th><th>Avg talk</th><th>Avg hold</th><th>Avg ACW</th></tr></thead>
              <tbody>{(agents?.agents ?? []).map((a: Json) => (
                <tr key={a.agent_id}><td>{a.agent}</td><td>{a.handled}</td><td>{a.transferred_out}</td><td>{fmtDuration(a.average_talk_seconds)}</td>
                  <td>{fmtDuration(a.average_hold_seconds)}</td><td>{fmtDuration(a.average_acw_seconds)}</td></tr>
              ))}</tbody></table>
            <p className="small muted">{agents?.caution}</p>
          </Panel>
          <Panel title="Metric definitions">
            <table><thead><tr><th>Metric</th><th>Definition</th><th>Denominator</th><th>Exclusions</th><th>Transfers</th></tr></thead>
              <tbody>{Object.entries(r.definitions).map(([k, d]: [string, Json]) => (
                <tr key={k}><td className="mono">{k}</td><td className="small">{d.definition}</td><td className="small">{d.denominator}</td>
                  <td className="small">{d.exclusions}</td><td className="small">{d.transfers}</td></tr>
              ))}</tbody></table>
          </Panel>
        </div>
      )}
    </>
  );
}
