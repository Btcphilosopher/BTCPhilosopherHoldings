"use client";

import { useState } from "react";
import { Badge, Banner, ErrorText, OkText, Panel } from "@/components/ui";
import { api, has, type Json } from "@/lib/api";
import { fmtDateTime, fmtTime, useAction, useResource } from "@/lib/hooks";

export default function Admin() {
  const [tab, setTab] = useState("simulator");
  const tabs = [["simulator", "Simulator"], ["provider", "Provider & events"], ["routing", "Routing configuration"],
    ["audit", "Audit history"], ["users", "Users & roles"]];
  return (
    <>
      <h1>Administration</h1>
      <div className="tabs" role="tablist">
        {tabs.map(([k, l]) => <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)}>{l}</button>)}
      </div>
      {tab === "simulator" ? <Simulator /> : tab === "provider" ? <Provider /> : tab === "routing" ? <Routing /> :
        tab === "audit" ? <Audit /> : <Users />}
    </>
  );
}

function Simulator() {
  const act = useAction();
  const { data: faults, reload } = useResource<Json>("/v1/simulator/faults", { live: false, pollMs: 4000 });
  const { data: live } = useResource<Json[]>("/v1/interactions?status=ivr,queued,offered,connecting,active", { pollMs: 3000 });
  const [from, setFrom] = useState("+441134960145");
  const [digits, setDigits] = useState("1");
  const call = () => act.run(() => api<Json>("/v1/simulator/inbound-call", { body: { from_number: from, ivr_digits: digits,
    script: [{ i: 0, speaker: "customer", text: "Hello, I have a question about my latest bill." },
      { i: 1, speaker: "agent", text: "Thanks for calling. Let me check that for you." }] } }),
    (r: Json) => `Simulated call ${r.call_id} placed. ${r.note}`);
  const setFault = (body: Json) => act.run(async () => { await api("/v1/simulator/faults", { method: "PUT", body }); reload(); },
    () => "Fault settings updated.");
  const email = () => act.run(() => api<Json>("/v1/channels/email/inbound", { body: { from_address: "rhys.morgan@example.org",
    subject: "Question about my bill", body: "Hello, my bill seems higher than usual this month. Can you check?", queue: "BILLING" } }),
    (r: Json) => `Simulated e-mail ${r.reference} queued.`);
  return (
    <>
      <Banner kind="warn" title="Simulation controls">These stand in for the outside world (a caller, a network fault). They
        exist only in demo mode with the simulated provider and every use is audited.</Banner>
      <div className="grid-2">
        <Panel title="Place a simulated inbound call">
          <div className="row">
            <div style={{ flex: 1 }}><label htmlFor="from">Caller number (fictional)</label>
              <select id="from" value={from} onChange={(e) => setFrom(e.target.value)}>
                <option value="+441134960145">0113 496 0145 — Rhys Morgan</option>
                <option value="+441134960101">0113 496 0101 — shared household (Ellison)</option>
                <option value="+441134960201">0113 496 0201 — Daniel Okoro</option>
                <option value="+441134960999">0113 496 0999 — unknown caller</option>
              </select></div>
            <div><label htmlFor="dg">IVR digits</label>
              <select id="dg" value={digits} onChange={(e) => setDigits(e.target.value)}>
                <option value="1">1 Billing</option><option value="2">2 Technical</option><option value="3">3 Care</option>
                <option value="4">4 Welsh (Care)</option><option value="8">8 Request callback</option><option value="9">9 Voicemail</option>
              </select></div>
          </div>
          <button className="btn btn-teal" style={{ marginTop: 8 }} onClick={call} disabled={act.busy}>Place call</button>
          <button className="btn" style={{ marginTop: 8, marginLeft: 8 }} onClick={email} disabled={act.busy}>Inject inbound e-mail</button>
          <h3 style={{ marginTop: 12 }}>Calls in progress</h3>
          {(live ?? []).filter((i) => i.channel === "voice").map((i) => (
            <div key={i.id} className="row small list-item"><span className="mono">{i.reference}</span><Badge>{i.status}</Badge>
              <span className="muted">{i.queue?.code}</span>
              <CustomerHangup id={i.id} /></div>
          ))}
        </Panel>
        <Panel title="Fault injection">
          {faults ? (
            <div className="stack">
              <div className="row"><strong>Provider outage:</strong> <Badge tone={faults.outage ? "red" : "green"}>{faults.outage ?? "none"}</Badge></div>
              <div className="row">
                <button className="btn btn-sm" onClick={() => setFault({ outage: "blackhole" })}>Blackhole (responses &amp; events lost)</button>
                <button className="btn btn-sm" onClick={() => setFault({ outage: "refuse" })}>Refuse requests</button>
                <button className="btn btn-sm btn-primary" onClick={() => setFault({ outage: null })}>Restore</button>
              </div>
              <div className="row"><button className="btn btn-sm" onClick={() => setFault({ duplicate_next: 10 })}>Duplicate next 10 events</button>
                <button className="btn btn-sm" onClick={() => setFault({ reorder_next: 3 })}>Reorder next 3 events</button>
                <button className="btn btn-sm" onClick={() => setFault({ delay_ms: faults.delay_ms ? 0 : 1500 })}>{faults.delay_ms ? "Remove" : "Add"} 1.5 s delay</button></div>
              <div className="row"><label htmlFor="cb" style={{ margin: 0 }}>Consult target</label>
                <select id="cb" style={{ width: 200 }} value={faults.consult_target_behaviour} onChange={(e) => setFault({ consult_target_behaviour: e.target.value })}>
                  <option value="app_controlled">answers when accepted</option><option value="reject">device rejects</option><option value="no_answer">no answer</option></select></div>
              <div className="row"><label htmlFor="oo" style={{ margin: 0 }}>Outbound outcome</label>
                <select id="oo" style={{ width: 200 }} value={faults.outbound_outcome} onChange={(e) => setFault({ outbound_outcome: e.target.value })}>
                  <option value="answer">answer</option><option value="no_answer">no answer</option><option value="busy">busy</option></select></div>
              <p className="small muted">Pending duplicates: {faults.duplicate_next} · reorders: {faults.reorder_next}</p>
            </div>
          ) : <p className="small muted">Simulator unavailable.</p>}
          <OkText message={act.message} />
          <ErrorText error={act.error} />
        </Panel>
      </div>
    </>
  );
}

function CustomerHangup({ id }: { id: string }) {
  const act = useAction();
  const hang = () => act.run(async () => {
    const d = await api<Json>(`/v1/interactions/${id}`);
    if (d.call) await api(`/v1/simulator/calls/${d.call.provider_call_id}/customer-hangup`, { method: "POST" });
  });
  return <button className="btn btn-sm" onClick={hang} disabled={act.busy}>Caller hangs up</button>;
}

function Provider() {
  const { data } = useResource<Json>("/v1/providers/status", { pollMs: 3000 });
  if (!data) return <p>Loading…</p>;
  const caps = data.capabilities;
  const flags = Object.entries(caps).filter(([, v]) => typeof v === "boolean");
  return (
    <div className="grid-2">
      <Panel title={`Provider: ${data.provider}`}>
        <p><Badge tone={data.connection_status === "connected" ? "green" : "red"}>{data.connection_status}</Badge>{" "}
          <span className="small muted">since {fmtDateTime(data.status_changed_at)} · last heartbeat {fmtTime(data.last_heartbeat_ok_at)}</span></p>
        <p className="small">Media: <strong>{caps.media.replaceAll("_", " ")}</strong></p>
        <ul className="small">{caps.notes.map((n: string) => <li key={n}>{n}</li>)}</ul>
        <h3>Capabilities (unsupported controls are disabled, never simulated)</h3>
        <div className="row">{flags.map(([k, v]) => <Badge key={k} tone={v ? "green" : "neutral"}>{v ? "✔" : "✖"} {k.replaceAll("_", " ")}</Badge>)}</div>
        <p className="small" style={{ marginTop: 8 }}>Warm-transfer failure behaviour: {caps.warm_transfer_failure_behaviour.replaceAll("_", " ")}</p>
      </Panel>
      <Panel title="Recent verified provider events">
        <div className="scroll" style={{ maxHeight: 520 }}>
          <table><thead><tr><th>Type</th><th>Seq</th><th>Event time</th><th>Lag</th><th>Status</th></tr></thead>
            <tbody>{data.recent_events.map((e: Json) => (
              <tr key={e.provider_event_id}><td className="mono small">{e.type}{e.synthetic ? <div><Badge tone="blue">reconciliation</Badge></div> : null}</td>
                <td>{e.sequence ?? "—"}</td><td className="small">{fmtTime(e.occurred_at)}</td><td className="small">{e.ingestion_lag_ms} ms</td>
                <td><Badge tone={e.status === "applied" ? "green" : e.status === "error" ? "red" : "amber"}>{e.status}</Badge>
                  {e.duplicates ? <div className="small muted">+{e.duplicates} duplicate(s)</div> : null}
                  {e.note ? <div className="small muted">{e.note}</div> : null}</td></tr>
            ))}</tbody></table>
        </div>
      </Panel>
    </div>
  );
}

function Routing() {
  const { data } = useResource<Json>("/v1/admin/routing-config", { live: false, pollMs: 0 });
  if (!data) return <p>Loading…</p>;
  return (
    <>
      <Panel title="Routing algorithm"><p className="small">{data.routing_algorithm}</p></Panel>
      <div className="grid-2">
        <Panel title="Business hours & holidays">
          {data.business_hours.map((b: Json) => (
            <div key={b.id} className="list-item small">
              <strong>{b.name}</strong> <Badge tone={b.open_now[0] ? "green" : "amber"}>{b.open_now[1]}</Badge>
              <div>{Object.entries(b.weekly).map(([d, iv]) => `${["", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"][Number(d)]} ${(iv as string[][]).map((x) => x.join("–")).join(", ") || "closed"}`).join(" · ")}</div>
              {b.holidays.length ? <ul>{b.holidays.map((h: Json) => <li key={h.id}>{h.day} {h.name}: {h.intervals.length ? h.intervals.map((x: string[]) => x.join("–")).join(", ") : "closed"}</li>)}</ul> : null}
            </div>
          ))}
        </Panel>
        <Panel title="IVR & numbers">
          {data.ivr_menus.map((m: Json) => (
            <div key={m.id} className="small">
              <strong>{m.name} v{m.version}</strong> {m.published ? <Badge tone="green">published</Badge> : null}
              {Object.entries(m.definition.nodes).map(([id, n]: [string, Json]) => (
                <div key={id} className="list-item"><div className="muted">{n.prompt}</div>
                  <ul>{Object.entries(n.options).map(([dg, o]: [string, Json]) => <li key={dg}>{dg} → {o.action} {o.target ?? ""}{o.language ? ` (lang ${o.language})` : ""}</li>)}</ul></div>
              ))}
              <p>Out of hours: {m.closed_action.action}</p>
            </div>
          ))}
          <table><thead><tr><th>Number</th><th>Label</th><th>Outbound caller ID</th></tr></thead>
            <tbody>{data.numbers.map((n: Json) => <tr key={n.id}><td className="mono">{n.e164}</td><td className="small">{n.label}</td>
              <td>{n.outbound_allowed && n.verified ? <Badge tone="green">owned · verified</Badge> : "—"}</td></tr>)}</tbody></table>
        </Panel>
      </div>
      <Panel title="Recording policies">
        <table><thead><tr><th>Policy</th><th>Jurisdiction</th><th>Purpose</th><th>Mode</th><th>Notice</th><th>Retention</th><th>Access roles</th></tr></thead>
          <tbody>{data.recording_policies.map((r: Json) => <tr key={r.id}><td>{r.name} v{r.version}</td><td>{r.jurisdiction}</td>
            <td>{r.purpose.replaceAll("_", " ")}</td><td>{r.mode.replaceAll("_", " ")}</td><td className="small">{r.notice_text}</td>
            <td>{r.retention_days} days</td><td className="small">{r.access_roles.join(", ")}</td></tr>)}</tbody></table>
      </Panel>
    </>
  );
}

function Audit() {
  const [target, setTarget] = useState("");
  const [action, setAction] = useState("");
  const { data, reload } = useResource<Json[]>(`/v1/audit?limit=200${target ? `&target_id=${encodeURIComponent(target)}` : ""}${action ? `&action=${encodeURIComponent(action)}` : ""}`,
    { live: false, pollMs: 0 });
  const verify = useAction();
  return (
    <Panel title="Audit history" actions={<button className="btn btn-sm" onClick={() => verify.run(() => api<Json>("/v1/audit/verify"),
      (r: Json) => (r.valid ? `Hash chain valid over ${r.checked} entries.` : `CHAIN BROKEN at #${r.broken_at_seq}`))}>Verify hash chain</button>}>
      <div className="row" style={{ marginBottom: 8 }}>
        <input aria-label="Target id" placeholder="Target id (interaction, case, recording…)" value={target} onChange={(e) => setTarget(e.target.value)} style={{ flex: 2 }} />
        <input aria-label="Action prefix" placeholder="Action prefix (e.g. call., recording.)" value={action} onChange={(e) => setAction(e.target.value)} style={{ flex: 1 }} />
        <button className="btn btn-sm" onClick={reload}>Filter</button>
      </div>
      <OkText message={verify.message} />
      <ErrorText error={verify.error} />
      {!has("audit.read") ? <p className="small muted">Security events (sign-ins, configuration) need the audit role with MFA.</p> : null}
      <div className="scroll" style={{ maxHeight: 560 }}>
        <table><thead><tr><th>#</th><th>When</th><th>Actor</th><th>Action</th><th>Target</th><th>Details (redacted)</th></tr></thead>
          <tbody>{(data ?? []).map((a) => (
            <tr key={a.seq}><td>{a.seq}</td><td className="small">{fmtDateTime(a.at)}</td><td className="small">{a.actor}</td>
              <td className="mono small">{a.action}</td><td className="small mono">{a.target_type}{a.target_id ? `:${String(a.target_id).slice(0, 8)}` : ""}</td>
              <td className="small mono" style={{ maxWidth: 360, overflowWrap: "anywhere" }}>{JSON.stringify(a.details)}</td></tr>
          ))}</tbody></table>
      </div>
    </Panel>
  );
}

function Users() {
  const ok = has("admin.users");
  const { data, error } = useResource<Json[]>(ok ? "/v1/admin/users" : null, { live: false, pollMs: 0 });
  if (!ok) return <Banner kind="info" title="Administrator role with MFA required">Sign in as the administrator (with a one-time code) to manage users.</Banner>;
  return (
    <Panel title="Users & roles">
      <ErrorText error={error} />
      <table><thead><tr><th>Name</th><th>E-mail</th><th>Roles</th><th>MFA</th><th>SSO linked</th><th>Last sign-in</th></tr></thead>
        <tbody>{(data ?? []).map((u) => <tr key={u.id}><td>{u.display_name}</td><td className="small">{u.email}</td><td className="small">{u.roles.join(", ")}</td>
          <td>{u.mfa_enrolled ? "enrolled" : "—"}</td><td>{u.oidc_linked ? "yes" : "—"}</td><td className="small">{fmtDateTime(u.last_login_at)}</td></tr>)}</tbody></table>
    </Panel>
  );
}
