"use client";

import { AppFrame, SUPERVISOR_NAV } from "@/components/Shell";
import { Badge } from "@/components/ui";

export default function SupervisorLayout({ children }: { children: React.ReactNode }) {
  return (
    <AppFrame nav={SUPERVISOR_NAV} area="Supervisor" topbar={<Badge tone="navy">Supervisor console</Badge>}>
      {children}
    </AppFrame>
  );
}
