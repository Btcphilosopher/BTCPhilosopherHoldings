// Browser end-to-end smoke test against a running stack (web :3000, api :8000, simulator :8090).
//   node e2e/smoke.mjs [--shots ./e2e/screenshots]
// Uses the pre-installed Playwright. Telephony is simulated (no audio).
import { createRequire } from "node:module";
import fs from "node:fs";

const require = createRequire(import.meta.url);
const { chromium } = require("playwright");
const WEB = process.env.WEB_URL ?? "http://localhost:3000";
const API = process.env.API_URL ?? "http://localhost:8000";
const SIM = process.env.SIM_URL ?? "http://localhost:8090";
const SIM_KEY = process.env.SIM_API_KEY ?? "dev-insecure-change-me-sim-api";
const PASSWORD = "Pennine-Demo-2026!";
const shotsIdx = process.argv.indexOf("--shots");
const SHOTS = shotsIdx > 0 ? process.argv[shotsIdx + 1] : null;
if (SHOTS) fs.mkdirSync(SHOTS, { recursive: true });

const results = [];
const check = (name, ok, detail = "") => {
  results.push({ name, ok, detail });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${detail ? ` — ${detail}` : ""}`);
};
const shot = async (page, name) => SHOTS && page.screenshot({ path: `${SHOTS}/${name}.png`, fullPage: true });

async function login(page, user) {
  await page.goto(WEB);
  await page.fill("#email", `${user}@pennine.example`);
  await page.fill("#password", PASSWORD);
  await page.click("button[type=submit]");
}

// Deterministic start: a seeded callback that is already due would (correctly) be routed first.
{
  const r = await fetch(`${API}/v1/auth/login`, { method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ organisation: "pennine", email: "grace.thornton@pennine.example", password: PASSWORD }) });
  const tok = (await r.json()).access_token;
  const h = { Authorization: `Bearer ${tok}`, "Content-Type": "application/json" };
  for (const cb of await (await fetch(`${API}/v1/callbacks?status=pending,ready`, { headers: h })).json()) {
    if (new Date(cb.window_start) <= new Date()) {
      await fetch(`${API}/v1/callbacks/${cb.id}/cancel`, { method: "POST", headers: h,
        body: JSON.stringify({ reason: "e2e setup: clearing due seeded backlog", expected_version: cb.version }) });
    }
  }
}

const browser = await chromium.launch();
try {
  // ---- agent signs in; browser softphone registers with the provider; agent becomes available
  const agentCtx = await browser.newContext({ viewport: { width: 1600, height: 1000 }, deviceScaleFactor: Number(process.env.SCALE ?? 1) });
  const agent = await agentCtx.newPage();
  const consoleErrors = [];
  agent.on("console", (m) => m.type() === "error" && consoleErrors.push(m.text()));
  await login(agent, "amira.khan");
  await agent.waitForURL(/\/agent$/);
  await agent.getByText("Device registered (provider-confirmed)").waitFor({ timeout: 15000 });
  check("browser softphone registered and provider confirmed registration", true);
  await shot(agent, "01-agent-offline");
  const availableBtn = agent.getByRole("button", { name: "Available", exact: true });
  if (await availableBtn.isEnabled()) await availableBtn.click();  // may already be available from an earlier run
  await agent.locator(".badge", { hasText: "Available" }).first().waitFor();
  check("agent became available after readiness checks", true);

  // ---- simulated caller dials the main line, IVR option 1 (Billing)
  await fetch(`${SIM}/v1/demo/inbound`, { method: "POST", headers: { "Content-Type": "application/json", "X-Sim-Api-Key": SIM_KEY },
    body: JSON.stringify({ from_number: "+441134960145", to_number: "+441614960100", ivr_digits: "1",
      script: [{ i: 0, speaker: "customer", text: "I'd like to set up a payment plan for my water bill." },
        { i: 1, speaker: "agent", text: "I can help with that once I've confirmed a few details." }] }) });
  await agent.getByText("Incoming voice").waitFor({ timeout: 15000 });
  check("offer shown in queue panel", true);
  await shot(agent, "02-offer");
  await agent.keyboard.press("Alt+a");
  await agent.locator(".live-indicator").first().waitFor({ timeout: 15000 });
  check("keyboard accept (Alt+A) → live call indicator (teal) after provider confirmation", true);

  // ---- identity: possible match → select → verify
  await agent.getByText("Telephone number is a matching hint").first().waitFor();
  await agent.getByRole("button", { name: "This is the caller" }).click();
  await agent.getByText("Withheld until verified").waitFor();
  check("restricted data withheld before verification", true);
  await agent.fill("#f-date_of_birth", "1979-07-21");
  await agent.fill("#f-postcode", "OL14 6QT");
  await agent.getByRole("button", { name: "Check answers" }).click();
  await agent.getByText("Identity verified").first().waitFor({ timeout: 10000 });
  const balanceVisible = await agent.getByText("£212.55 overdue").isVisible();
  check("verification recorded; restricted data shown to owning agent", balanceVisible);

  // ---- knowledge search
  await agent.fill("#kq", "payment arrangement");
  await agent.keyboard.press("Enter");
  await agent.getByText("Setting up a payment arrangement").first().waitFor();
  check("approved knowledge search", true);

  // ---- hold: requested → confirmed (provider event)
  await agent.getByRole("button", { name: /Hold/ }).click();
  await agent.getByText("Customer on hold (provider-confirmed)").waitFor({ timeout: 10000 });
  check("hold confirmed by provider event, distinct from mute", await agent.getByRole("button", { name: /Mute/ }).isVisible());
  await shot(agent, "03-active-call-verified-on-hold");
  await agent.getByRole("button", { name: /Resume/ }).click();
  await agent.getByRole("button", { name: /Hold/ }).waitFor({ timeout: 10000 });

  // ---- end call (with confirmation) → after-call work
  await agent.keyboard.press("Alt+e");
  await agent.getByRole("button", { name: "Yes, end call" }).click();
  await agent.getByText("After-call work").first().waitFor({ timeout: 10000 });
  check("call ended via provider → after-call work", true);
  await agent.getByRole("button", { name: "Draft with assistant" }).click();
  await agent.getByText("AI proposal — review before saving").waitFor({ timeout: 10000 });
  const saveDisabled = await agent.getByRole("button", { name: "Save summary" }).isDisabled();
  check("AI draft cannot be saved until reviewed", saveDisabled);
  await agent.getByLabel("I have reviewed and corrected this summary").check();
  await agent.getByRole("button", { name: "Save summary" }).click();
  await agent.getByText(/Saved · ai draft reviewed/).waitFor({ timeout: 10000 });
  await agent.fill("#task-title", "Send payment arrangement letter");
  await agent.getByRole("button", { name: "Create task" }).click();
  await agent.getByText("Follow-up task created.").waitFor();
  await agent.selectOption("#disp", "payment_arrangement");
  await shot(agent, "04-after-call-work");
  await agent.getByRole("button", { name: "Complete after-call work" }).click();
  await agent.getByText(/After-call work complete/).waitFor({ timeout: 10000 });
  check("after-call work completed with disposition; agent available again", true);

  // ---- supervisor console
  const supCtx = await browser.newContext({ viewport: { width: 1600, height: 1100 }, deviceScaleFactor: Number(process.env.SCALE ?? 1) });
  const sup = await supCtx.newPage();
  await login(sup, "grace.thornton");
  await sup.waitForURL(/\/supervisor$/);
  await sup.getByRole("heading", { name: "Live operations" }).waitFor();
  await sup.getByText("Amira Khan").first().waitFor();
  check("supervisor live operations shows agents", true);
  await shot(sup, "05-supervisor-live");
  await sup.goto(`${WEB}/supervisor/reports`);
  await sup.getByText("Metric definitions").waitFor({ timeout: 10000 });
  const offered = await sup.locator(".stat", { hasText: "Offered" }).locator(".value").innerText();
  check("reports show today's offered contacts", Number(offered) >= 1, `offered=${offered}`);
  await shot(sup, "06-reports");
  await sup.goto(`${WEB}/supervisor/agents`);
  await sup.getByRole("tab", { name: "Forecast & staffing" }).click();
  await sup.getByRole("button", { name: "Generate forecast" }).click();
  await sup.getByText("Forecast vs observed").waitFor({ timeout: 15000 });
  check("forecast generated with band and staffing table", true);
  await shot(sup, "07-forecast");
  await sup.goto(`${WEB}/supervisor/admin`);
  await sup.getByRole("tab", { name: "Audit history" }).click();
  await sup.getByRole("button", { name: "Verify hash chain" }).click();
  await sup.getByText(/Hash chain valid over/).waitFor({ timeout: 10000 });
  check("audit history and hash-chain verification", true);
  await shot(sup, "08-audit");
  check("no browser console errors on agent page", consoleErrors.length === 0, consoleErrors.slice(0, 3).join(" | "));
} catch (e) {
  check("unexpected failure", false, String(e).slice(0, 300));
} finally {
  await browser.close();
}
const failed = results.filter((r) => !r.ok).length;
console.log(`\n${results.length - failed}/${results.length} checks passed`);
fs.writeFileSync(new URL("./last-run.json", import.meta.url), JSON.stringify({ at: new Date().toISOString(), results }, null, 2));
process.exit(failed ? 1 : 0);
