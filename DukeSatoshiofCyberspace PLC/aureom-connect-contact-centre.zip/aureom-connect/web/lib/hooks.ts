"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { api, describeError, type Json } from "./api";
import { useEvents } from "./events";

/** Fetch a resource; refetch whenever an application event arrives and on a slow poll as a fallback. */
export function useResource<T = Json>(path: string | null, opts: { pollMs?: number; live?: boolean } = {}) {
  const { tick } = useEvents();
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const inflight = useRef(false);
  const load = useCallback(async () => {
    if (!path || inflight.current) return;
    inflight.current = true;
    setLoading(true);
    try {
      setData(await api<T>(path));
      setError(null);
    } catch (e) {
      setError(describeError(e));
    } finally {
      inflight.current = false;
      setLoading(false);
    }
  }, [path]);
  useEffect(() => {
    load();
  }, [load]);
  useEffect(() => {
    if (opts.live === false) return;
    const t = setTimeout(load, 120);
    return () => clearTimeout(t);
  }, [tick]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    const ms = opts.pollMs ?? 5000;
    if (!ms) return;
    const i = setInterval(load, ms);
    return () => clearInterval(i);
  }, [load, opts.pollMs]);
  return { data, error, loading, reload: load, setData };
}

/** Run a mutation with busy/error state. */
export function useAction() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const run = useCallback(async <T,>(fn: () => Promise<T>, ok?: (r: T) => string | void): Promise<T | undefined> => {
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      const r = await fn();
      const m = ok?.(r);
      if (m) setMessage(m);
      return r;
    } catch (e) {
      setError(describeError(e));
      return undefined;
    } finally {
      setBusy(false);
    }
  }, []);
  return { busy, error, message, run, setError, setMessage };
}

export function fmtTime(iso?: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

export function fmtDateTime(iso?: string | null): string {
  if (!iso) return "—";
  return new Date(iso).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
}

export function fmtDuration(seconds?: number | null): string {
  if (seconds === null || seconds === undefined) return "—";
  const s = Math.max(0, Math.round(seconds));
  const m = Math.floor(s / 60);
  return m ? `${m}m ${s % 60}s` : `${s}s`;
}

export function since(iso?: string | null): number {
  return iso ? (Date.now() - new Date(iso).getTime()) / 1000 : 0;
}

/** Re-render every second (for live timers). */
export function useNow(intervalMs = 1000): number {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const i = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(i);
  }, [intervalMs]);
  return now;
}
