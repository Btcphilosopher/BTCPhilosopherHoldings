"use client";

/**
 * Application event stream (WS /v1/events). Media never travels here.
 * Events are signals: on any event the UI re-reads authoritative state.
 * On reconnect the client resubscribes from its last cursor, so nothing is
 * missed, and the server reports whether call state must be reconciled.
 */
import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { API_URL, getSession } from "./api";

export interface AppEvent {
  id: number;
  event: string;
  audience: string;
  payload: Record<string, unknown>;
  at: string;
}

interface EventsState {
  connected: boolean;
  tick: number;
  last: AppEvent | null;
  recent: AppEvent[];
  watch: (interactionIds: string[]) => void;
}

const Ctx = createContext<EventsState>({ connected: false, tick: 0, last: null, recent: [], watch: () => {} });

export function EventsProvider({ children }: { children: ReactNode }) {
  const [connected, setConnected] = useState(false);
  const [tick, setTick] = useState(0);
  const [last, setLast] = useState<AppEvent | null>(null);
  const [recent, setRecent] = useState<AppEvent[]>([]);
  const cursor = useRef(0);
  const wsRef = useRef<WebSocket | null>(null);
  const watched = useRef<string[]>([]);
  const retry = useRef(0);

  const subscribe = useCallback(() => {
    const ws = wsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: "subscribe", since: cursor.current, interactions: watched.current }));
    }
  }, []);

  const watch = useCallback(
    (ids: string[]) => {
      const next = [...new Set(ids)].sort();
      if (next.join() !== watched.current.join()) {
        watched.current = next;
        subscribe();
      }
    },
    [subscribe],
  );

  useEffect(() => {
    let closed = false;
    let ping: ReturnType<typeof setInterval> | undefined;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const open = () => {
      const s = getSession();
      if (!s || closed) return;
      const ws = new WebSocket(API_URL.replace(/^http/, "ws") + "/v1/events");
      wsRef.current = ws;
      ws.onopen = () => ws.send(JSON.stringify({ type: "auth", token: s.accessToken }));
      ws.onmessage = (m) => {
        const msg = JSON.parse(m.data);
        if (msg.type === "ready") {
          setConnected(true);
          retry.current = 0;
          if (cursor.current === 0) cursor.current = Number(window.sessionStorage.getItem("aureom.cursor") ?? 0);
          subscribe();
          setTick((t) => t + 1);
          ping = setInterval(() => ws.readyState === WebSocket.OPEN && ws.send(JSON.stringify({ type: "ping" })), 10000);
        } else if (msg.type === "event") {
          cursor.current = Math.max(cursor.current, msg.id);
          try {
            window.sessionStorage.setItem("aureom.cursor", String(cursor.current));
          } catch {
            /* ignore */
          }
          setLast(msg);
          setRecent((r) => [msg, ...r].slice(0, 30));
          setTick((t) => t + 1);
        }
      };
      ws.onclose = () => {
        setConnected(false);
        if (ping) clearInterval(ping);
        if (!closed) {
          retry.current = Math.min(retry.current + 1, 6);
          timer = setTimeout(open, 500 * 2 ** retry.current);
        }
      };
    };
    open();
    return () => {
      closed = true;
      if (ping) clearInterval(ping);
      if (timer) clearTimeout(timer);
      wsRef.current?.close();
    };
  }, [subscribe]);

  return <Ctx.Provider value={{ connected, tick, last, recent, watch }}>{children}</Ctx.Provider>;
}

export function useEvents(): EventsState {
  return useContext(Ctx);
}
