"use client";

/**
 * Simulated softphone.
 *
 * Mirrors how a real WebRTC SDK works: the application mints a short-lived
 * media credential and the *browser registers directly with the provider*.
 * The application only learns that the device is registered when the
 * provider sends a verified `device.registered` event. With the bundled
 * simulator there is NO audio: this registers a signalling identity only.
 */
import { api } from "./api";

export interface SoftphoneStatus {
  state: "idle" | "registering" | "registered" | "failed";
  detail: string;
  media: string;
  expiresAt?: string;
}

type Listener = (s: SoftphoneStatus) => void;

class Softphone {
  private token: string | null = null;
  private endpoint: string | null = null;
  private expires = 0;
  private hb: ReturnType<typeof setInterval> | null = null;
  status: SoftphoneStatus = { state: "idle", detail: "Not registered", media: "unknown" };
  private listeners = new Set<Listener>();

  on(l: Listener): () => void {
    this.listeners.add(l);
    l(this.status);
    return () => this.listeners.delete(l);
  }

  private set(s: SoftphoneStatus) {
    this.status = s;
    this.listeners.forEach((l) => l(s));
  }

  async register(): Promise<void> {
    this.set({ state: "registering", detail: "Requesting short-lived media credential…", media: "unknown" });
    try {
      const cred = await api<{ token: string; endpoint: string; expires_at: string; media_available: boolean;
        provider: string; notes: string }>("/v1/agents/me/media-credential", { method: "POST" });
      this.token = cred.token;
      this.endpoint = cred.endpoint;
      this.expires = new Date(cred.expires_at).getTime();
      if (cred.provider !== "simulated") {
        this.set({ state: "failed", detail: `Browser SDK for provider '${cred.provider}' is not integrated in this build`,
          media: "none" });
        return;
      }
      const r = await fetch(`${this.endpoint}/v1/devices/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: this.token }),
      });
      if (!r.ok) throw new Error(`provider refused registration (HTTP ${r.status})`);
      this.set({ state: "registered", detail: "Registered with simulated provider (signalling only — no audio)",
        media: cred.media_available ? "available" : "none (simulated)", expiresAt: cred.expires_at });
      this.startHeartbeat();
    } catch (e) {
      this.set({ state: "failed", detail: `Device registration failed: ${(e as Error).message}`, media: "none" });
    }
  }

  private startHeartbeat() {
    if (this.hb) clearInterval(this.hb);
    this.hb = setInterval(async () => {
      if (!this.token || !this.endpoint) return;
      if (Date.now() > this.expires - 60_000) {
        await this.register(); // renew before the credential expires
        return;
      }
      try {
        const r = await fetch(`${this.endpoint}/v1/devices/heartbeat`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ token: this.token }),
        });
        const j = await r.json().catch(() => ({}));
        if (!r.ok || j.registered === false) {
          this.set({ state: "failed", detail: "Provider no longer recognises this device", media: "none" });
        }
      } catch {
        this.set({ state: "failed", detail: "Cannot reach the provider from this browser", media: "none" });
      }
    }, 15_000);
  }

  async unregister(): Promise<void> {
    if (this.hb) clearInterval(this.hb);
    if (this.token && this.endpoint) {
      await fetch(`${this.endpoint}/v1/devices/unregister`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: this.token }),
      }).catch(() => undefined);
    }
    this.token = null;
    this.set({ state: "idle", detail: "Not registered", media: "unknown" });
  }
}

export const softphone = new Softphone();
