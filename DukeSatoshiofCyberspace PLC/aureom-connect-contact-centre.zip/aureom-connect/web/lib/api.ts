"use client";

/**
 * Thin API client. The server is authoritative: every response is re-read
 * after a change and nothing is assumed from a 2xx alone. Mutations with an
 * external effect send an Idempotency-Key so a retry never repeats them.
 */
export const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

export type Json = any; // eslint-disable-line @typescript-eslint/no-explicit-any

export interface Session {
  accessToken: string;
  refreshToken: string;
  user: {
    id: string;
    email: string;
    display_name: string;
    roles: string[];
    agent_id: string | null;
    mfa: boolean;
    permissions: string[];
  };
}

const KEY = "aureom.session";

export function getSession(): Session | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.sessionStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Session) : null;
  } catch {
    return null;
  }
}

export function setSession(s: Session | null): void {
  try {
    if (s) window.sessionStorage.setItem(KEY, JSON.stringify(s));
    else window.sessionStorage.removeItem(KEY);
  } catch {
    /* storage unavailable: session lives only in memory for this tab */
  }
}

export class ApiError extends Error {
  status: number;
  code: string;
  details: Json;
  requestId?: string;
  constructor(status: number, code: string, message: string, details: Json, requestId?: string) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
    this.requestId = requestId;
  }
}

export function newKey(): string {
  return typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

let refreshing: Promise<boolean> | null = null;

async function refresh(): Promise<boolean> {
  const s = getSession();
  if (!s) return false;
  const r = await fetch(`${API_URL}/v1/auth/refresh`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ refresh_token: s.refreshToken }),
  });
  if (!r.ok) {
    setSession(null);
    return false;
  }
  const j = await r.json();
  setSession({ ...s, accessToken: j.access_token, refreshToken: j.refresh_token });
  return true;
}

export async function api<T = Json>(
  path: string,
  opts: { method?: string; body?: unknown; idempotent?: boolean; idempotencyKey?: string; form?: FormData } = {},
): Promise<T> {
  const s = getSession();
  const headers: Record<string, string> = {};
  if (s) headers.Authorization = `Bearer ${s.accessToken}`;
  if (opts.body !== undefined) headers["Content-Type"] = "application/json";
  if (opts.idempotent || opts.idempotencyKey) headers["Idempotency-Key"] = opts.idempotencyKey ?? newKey();
  const doFetch = () =>
    fetch(`${API_URL}${path}`, {
      method: opts.method ?? (opts.body !== undefined || opts.form ? "POST" : "GET"),
      headers,
      body: opts.form ?? (opts.body !== undefined ? JSON.stringify(opts.body) : undefined),
    });
  let r = await doFetch();
  if (r.status === 401 && s) {
    refreshing ??= refresh().finally(() => (refreshing = null));
    if (await refreshing) {
      headers.Authorization = `Bearer ${getSession()!.accessToken}`;
      r = await doFetch();
    }
  }
  const text = await r.text();
  const data = text ? JSON.parse(text) : null;
  if (!r.ok) {
    const e = data?.error ?? {};
    throw new ApiError(r.status, e.code ?? `HTTP_${r.status}`, e.message ?? r.statusText, e.details ?? {}, e.request_id);
  }
  return data as T;
}

export function describeError(e: unknown): string {
  if (e instanceof ApiError) {
    const blockers = e.details?.blockers as string[] | undefined;
    const failed = e.details?.failed as { check: string; detail: string }[] | undefined;
    let extra = "";
    if (blockers?.length) extra = `: ${blockers.join("; ")}`;
    else if (failed?.length) extra = `: ${failed.map((f) => `${f.check} (${f.detail})`).join("; ")}`;
    else if (e.details?.reason) extra = `: ${e.details.reason}`;
    return `${e.message}${extra} [${e.code}]`;
  }
  return e instanceof Error ? e.message : String(e);
}

export function has(perm: string): boolean {
  return !!getSession()?.user.permissions.includes(perm);
}
