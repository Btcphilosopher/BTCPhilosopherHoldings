#!/usr/bin/env python3
"""Reproducible 14-step demonstration against a running AUREOM CONNECT stack.

Everything here is SIMULATED SIGNALLING: the telephony simulator generates
provider-style events; no audio is carried and no real telephone network is
used. Customers, numbers and accounts are fictional.

    python scripts/demo.py --api http://localhost:8000 --sim http://localhost:8090

Writes a machine-readable log (``--out``, default docs/demo-run.json).
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import threading
import time
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Callable
from zoneinfo import ZoneInfo

import httpx

PASSWORD = os.environ.get("DEMO_PASSWORD", "Pennine-Demo-2026!")
SIM_KEY = os.environ.get("SIM_API_KEY", "dev-insecure-change-me-sim-api")
MAIN_LINE = "+441614960100"


class Demo:
    def __init__(self, api: str, sim: str):
        self.api = httpx.Client(base_url=api, timeout=15)
        self.sim = httpx.Client(base_url=sim, timeout=15, headers={"X-Sim-Api-Key": SIM_KEY})
        self.tokens: dict[str, str] = {}
        self.users: dict[str, dict[str, Any]] = {}
        self.media: dict[str, str] = {}
        self.log: list[dict[str, Any]] = []
        self.step_no = 0
        self._stop = threading.Event()

    # ------------------------------------------------------------------ helpers
    def h(self, who: str, idem: bool = False) -> dict[str, str]:
        hd = {"Authorization": f"Bearer {self.tokens[who]}"}
        if idem:
            hd["Idempotency-Key"] = uuid.uuid4().hex
        return hd

    def login(self, who: str) -> None:
        r = self.api.post("/v1/auth/login", json={"organisation": "pennine", "email": f"{who}@pennine.example",
                                                  "password": PASSWORD})
        r.raise_for_status()
        self.tokens[who] = r.json()["access_token"]
        self.users[who] = r.json()["user"]

    def get(self, who: str, path: str) -> Any:
        r = self.api.get(path, headers=self.h(who))
        r.raise_for_status()
        return r.json()

    def post(self, who: str, path: str, body: dict | None = None, idem: bool = False, ok=(200, 201, 202)) -> Any:
        r = self.api.post(path, headers=self.h(who, idem), json=body or {})
        if r.status_code not in ok:
            raise RuntimeError(f"POST {path} -> {r.status_code} {r.text}")
        return r.json()

    def wait(self, what: str, fn: Callable[[], Any], timeout: float = 20.0, interval: float = 0.3) -> Any:
        end = time.time() + timeout
        while time.time() < end:
            val = fn()
            if val:
                return val
            time.sleep(interval)
        raise TimeoutError(f"timed out waiting for: {what}")

    def step(self, title: str) -> None:
        self.step_no += 1
        print(f"\n\033[1;36m[{self.step_no:02d}] {title}\033[0m")
        self.log.append({"step": self.step_no, "title": title, "at": datetime.now(timezone.utc).isoformat(),
                         "observations": []})

    def note(self, text: str, **data: Any) -> None:
        print(f"     • {text}")
        self.log[-1]["observations"].append({"text": text, **({"data": data} if data else {})})

    def heartbeat_loop(self) -> None:
        while not self._stop.wait(8):
            for who, tok in list(self.media.items()):
                try:
                    self.api.post("/v1/agents/me/presence", headers=self.h(who))
                    self.sim.post("/v1/devices/heartbeat", json={"token": tok})
                except httpx.HTTPError:
                    pass

    def ready(self, who: str) -> None:
        self.login(who)
        self.post(who, "/v1/agents/me/presence")
        cred = self.post(who, "/v1/agents/me/media-credential")
        self.media[who] = cred["token"]
        self.sim.post("/v1/devices/register", json={"token": cred["token"]}).raise_for_status()
        self.wait(f"{who} registration", lambda: self.get(who, "/v1/agent/workspace")["agent"][
            "telephony_registration"] == "registered")
        r = self.api.put("/v1/agents/me/availability", headers=self.h(who), json={"state": "available"})
        r.raise_for_status()

    def offer_for(self, who: str) -> dict[str, Any]:
        return self.wait(f"offer for {who}", lambda: (self.get(who, "/v1/agent/workspace")["offers"] or [None])[0])

    def interaction(self, who: str, iid: str) -> dict[str, Any]:
        return self.get(who, f"/v1/interactions/{iid}")

    def control(self, d: dict[str, Any], action: str) -> dict[str, Any] | None:
        return next((c for c in d["controls"] if c["action"] == action), None)

    @staticmethod
    def within_window(tz: str) -> bool:
        local = datetime.now(ZoneInfo(tz))
        wd, hm = local.isoweekday(), local.strftime("%H:%M")
        if wd <= 5:
            return "08:00" <= hm < "21:00"
        if wd == 6:
            return "09:00" <= hm < "17:00"
        return False

    # ------------------------------------------------------------------ scenario
    def run(self) -> None:
        print("\033[1mAUREOM CONNECT – Pennine Customer Services demonstration\033[0m")
        print("SIMULATED telephony: provider events only, no audio, fictional customers.\n")
        threading.Thread(target=self.heartbeat_loop, daemon=True).start()
        self.login("grace.thornton")
        self.wait("provider connected", lambda: self.get("grace.thornton", "/v1/providers/status")[
            "connection_status"] == "connected")
        # Deterministic start: seeded callbacks that are already due would (correctly) be routed first.
        for cb in self.get("grace.thornton", "/v1/callbacks?status=pending,ready"):
            if cb["window_start"] <= datetime.now(timezone.utc).isoformat():
                self.post("grace.thornton", f"/v1/callbacks/{cb['id']}/cancel",
                          {"reason": "demo setup: clearing due seeded backlog", "expected_version": cb["version"]})
                print(f"Setup: supervisor cancelled seeded callback {cb['reference']} (audited) for a deterministic run")
        for who in ("amira.khan", "eilidh.fraser", "femi.adeyemi"):
            self.ready(who)
        self.sim.post("/v1/demo/faults/reset")

        # 1 ---------------------------------------------------------------
        self.step("Receive an incoming call (simulated PSTN caller → IVR option 1, Billing)")
        script = [{"i": 0, "speaker": "customer", "start": 0, "end": 4, "confidence": 0.91,
                   "text": "Hi, I've fallen behind on my water bill and I'd like to set up a payment plan."},
                  {"i": 1, "speaker": "agent", "start": 4, "end": 8, "confidence": 0.94,
                   "text": "Of course. I can help with a payment arrangement once I've confirmed a few details."},
                  {"i": 2, "speaker": "customer", "start": 8, "end": 12, "confidence": 0.88,
                   "text": "Could you also send me something in writing afterwards?"}]
        r = self.sim.post("/v1/demo/inbound", json={"from_number": "+441134960145", "to_number": MAIN_LINE,
                                                    "ivr_digits": "1", "script": script})
        call_id = r.json()["call_id"]
        self.note(f"Simulator placed call {call_id} from a fictional caller (0113 496 0145) to the main line")

        # 2 ---------------------------------------------------------------
        self.step("Route it to an eligible agent")
        def inbound_offer():
            for w in ("amira.khan", "eilidh.fraser", "femi.adeyemi"):
                for o in self.get(w, "/v1/agent/workspace")["offers"]:
                    if o["interaction"]["direction"] == "inbound" and o["interaction"]["channel"] == "voice":
                        return {**o, "who": w}
            return None

        offer = self.wait("an offer", inbound_offer)
        first = offer["who"]
        iid = str(offer["interaction"]["id"])
        decisions = self.get("grace.thornton", f"/v1/ops/routing-decisions/{iid}")
        last = decisions[-1]
        self.note(f"Offered to {self.users[first]['display_name']}: {last['explanation']}")
        for c in last["candidates"]:
            mark = "eligible" if c["eligible"] else "excluded: " + "; ".join(c["reasons"])
            self.note(f"{c['agent']}: {mark}")

        # 3 ---------------------------------------------------------------
        self.step("Accept it without competing ownership")
        others = [w for w in ("amira.khan", "eilidh.fraser", "femi.adeyemi") if w != first]
        rival = self.api.post(f"/v1/interactions/{iid}/accept", headers=self.h(others[0], True), json={})
        self.note(f"{self.users[others[0]]['display_name']} tries to accept without an offer → "
                  f"{rival.status_code} {rival.json()['error']['code']}")
        key = uuid.uuid4().hex
        hd = {**self.h(first), "Idempotency-Key": key}
        r1 = self.api.post(f"/v1/interactions/{iid}/accept", headers=hd, json={"offer_id": offer["id"]})
        r2 = self.api.post(f"/v1/interactions/{iid}/accept", headers=hd, json={"offer_id": offer["id"]})
        self.note(f"Accepted ({r1.status_code}); retry with the same Idempotency-Key replayed "
                  f"(replayed={r2.headers.get('Idempotent-Replayed')}) without a second connection request")
        d = self.wait("agent leg and recording confirmed", lambda: (lambda x: x if x["status"] == "active" and
                      x["recordings"] and x["recordings"][0]["status"] == "active" else None)(self.interaction(first, iid)))
        self.note(f"Provider confirmed agent leg; control 'answer' is {self.control(d, 'answer')['status']}; "
                  f"recording status {d['recordings'][0]['status'] if d['recordings'] else 'n/a'} "
                  "(confirmed by provider event)")

        # 4 ---------------------------------------------------------------
        self.step("Review possible customer matches")
        self.note(d["match_note"])
        for c in d["candidates"]:
            self.note(f"Candidate {c['customer_ref']} {c['display_name']}: {', '.join(c['match_reasons'])}")
        cust_id = str(d["candidates"][0]["customer_id"])
        d = self.post(first, f"/v1/interactions/{iid}/customer", {"customer_id": cust_id})
        self.note(f"Selected as probable match → status {d['customer_match_status']}; restricted data "
                  f"{d['customer_record']['restricted_access']}")

        # 5 ---------------------------------------------------------------
        self.step("Record verification")
        v = self.post(first, f"/v1/interactions/{iid}/verification", {"answers": {"date_of_birth": "1979-07-22"}})
        self.note(f"Customer gave a wrong date of birth → {v['last_results']}, status {v['status']}")
        v = self.post(first, f"/v1/interactions/{iid}/verification",
                      {"answers": {"date_of_birth": "1979-07-21", "postcode": "OL14 6QT"}})
        self.note(f"Two factors confirmed → status {v['status']} (answers checked server-side, never stored)")
        d = self.interaction(first, iid)
        self.note(f"Restricted data now visible to the owning agent: balance {d['customer_record']['restricted']['balance']}")

        # 6 ---------------------------------------------------------------
        self.step("Search approved knowledge")
        res = self.get(first, "/v1/knowledge/search?q=payment arrangement")["results"]
        for x in res[:2]:
            self.note(f"{x['title']} v{x['version']} [{x['visibility']}] owner {x['owner_team']}, effective "
                      f"{x['effective_from'][:10]}")
        sug = self.post(first, "/v1/ai/suggest-articles", {"interaction_id": iid})
        self.note(f"Assistant ({sug['provider']}: {sug['model']}) suggested "
                  f"{[a['slug'] for a in sug['output']['articles']]} with confidence "
                  f"{sug['uncertainty']['confidence']} – a proposal only")

        # 7 ---------------------------------------------------------------
        self.step("Complete a warm transfer (after one rejected consultation)")
        target_reject = next(w for w in others if w == "femi.adeyemi")
        target_ok = next(w for w in others if w != target_reject)
        self.post(first, f"/v1/interactions/{iid}/actions",
                  {"action": "warm_transfer_start", "params": {"target_agent_id": self.users[target_reject]["agent_id"]}},
                  idem=True)
        o = self.offer_for(target_reject)
        self.post(target_reject, f"/v1/interactions/{iid}/reject", {"offer_id": o["id"], "reason": "on a break request"},
                  idem=True)
        d = self.wait("transfer failure", lambda: (lambda x: x if x["transfer_state"].get("status") == "failed"
                                                   else None)(self.interaction(first, iid)))
        cust_leg = next(lg for lg in d["call"]["legs"] if lg["leg_type"] == "customer")
        self.note(f"{self.users[target_reject]['display_name']} declined → transfer failed "
                  f"({d['transfer_state']['failure_reason']}); customer leg {cust_leg['status']}, on hold "
                  f"{cust_leg['on_hold']}, still owned by {self.users[first]['display_name']}")
        self.post(first, f"/v1/interactions/{iid}/actions",
                  {"action": "warm_transfer_start", "params": {"target_agent_id": self.users[target_ok]["agent_id"]}},
                  idem=True)
        o = self.offer_for(target_ok)
        self.post(target_ok, f"/v1/interactions/{iid}/accept", {"offer_id": o["id"]}, idem=True)
        self.wait("consult connected", lambda: self.interaction(first, iid)["transfer_state"].get("status")
                  == "consult_connected")
        self.note(f"{self.users[target_ok]['display_name']} answered the consultation")
        self.post(first, f"/v1/interactions/{iid}/actions", {"action": "warm_transfer_complete"}, idem=True)
        d = self.wait("transfer complete", lambda: (lambda x: x if x["transfer_state"].get("status") == "completed"
                                                    else None)(self.interaction(target_ok, iid)))
        self.note(f"Transfer completed by provider event; same interaction {d['reference']} now owned by "
                  f"{self.users[target_ok]['display_name']}; transfer_count={d['transfer_count']}")
        owner = target_ok

        # 8 ---------------------------------------------------------------
        self.step("Save a reviewed summary")
        draft = self.post(owner, "/v1/ai/draft-summary", {"interaction_id": iid, "notes": "Agreed monthly plan"})
        self.note(f"Draft (proposal, confidence {draft['uncertainty']['confidence']}): {draft['output']['summary'][:140]}…")
        self.note(f"Uncertainty notes: {draft['uncertainty']['notes']}")
        final = draft["output"]["summary"] + " Agent confirmed a monthly payment arrangement of £25 from 1 Dec."
        s = self.post(owner, f"/v1/interactions/{iid}/summary",
                      {"body": final, "ai_suggestion_id": draft["id"], "reviewed": True})
        self.note(f"Saved after agent review (source={s['source']}); unreviewed saves are refused")

        # 9 ---------------------------------------------------------------
        self.step("Create a follow-up task")
        t = self.post(owner, "/v1/tasks", {"title": "Send payment arrangement confirmation letter",
                                           "interaction_id": iid, "customer_id": cust_id,
                                           "due_at": (datetime.now(timezone.utc) + timedelta(days=1)).isoformat(),
                                           "assignee_queue": "BILLING", "priority": "normal"}, idem=True)
        self.note(f"Task '{t['title']}' due {t['due_at'][:16]} – SLA {t['sla']['label'] if t['sla'] else 'none'}")
        tpl = next(x for x in self.get(owner, "/v1/message-templates") if x["code"] == "payment_arrangement_confirmation")
        m = self.post(owner, "/v1/messages", {"template_id": tpl["id"], "customer_id": cust_id, "interaction_id": iid,
                                              "placeholder_values": {"customer_name": "Rhys", "amount": "£25",
                                                                     "frequency": "monthly", "start_date": "1 December",
                                                                     "reference": d["reference"]},
                                              "reviewed": True}, idem=True)
        self.note(f"Approved template message queued (status {m['status']}); the worker sends via the e-mail adapter")

        # 10 --------------------------------------------------------------
        self.step("Complete after-call work")
        w1 = self.post(first, f"/v1/interactions/{iid}/wrap-up", {"disposition_code": "transferred"}, idem=True)
        self.note(f"{self.users[first]['display_name']} wrapped their part → state {w1['agent_state']}")
        self.post(owner, f"/v1/interactions/{iid}/actions", {"action": "end"}, idem=True)
        self.wait("wrap-up", lambda: self.interaction(owner, iid)["status"] == "wrap_up")
        w2 = self.post(owner, f"/v1/interactions/{iid}/wrap-up",
                       {"disposition_code": "payment_arrangement", "note": "Monthly £25"}, idem=True)
        self.note(f"{self.users[owner]['display_name']} ended the call (confirmed by provider), dispositioned "
                  f"'payment_arrangement' → interaction {w2['status']}, agent {w2['agent_state']}")
        main_iid = iid

        # 11 --------------------------------------------------------------
        self.step("Process a callback")
        cands = [("PCS-100260", "+441134960160", "Europe/London"), ("PCS-100318", "+441134960218", "Australia/Sydney")]
        ref, number, tz = next((c for c in cands if self.within_window(c[2])), cands[0])
        customers = self.get("femi.adeyemi", f"/v1/customers?q={ref}")
        now = datetime.now(timezone.utc)
        cb = self.post("femi.adeyemi", "/v1/callbacks", {
            "phone_number": number, "number_confirmation_method": "verified_contact_point", "timezone": tz,
            "window_start": (now - timedelta(seconds=5)).isoformat(), "window_end": (now + timedelta(hours=2)).isoformat(),
            "queue": "BILLING", "customer_id": customers[0]["id"], "reason": "Customer asked to be called back"},
            idem=True)
        self.note(f"Callback {cb['reference']} for {customers[0]['display_name']} ({tz}); promise: {cb['promise_text']}")
        holder = self.wait("callback offer", lambda: next(
            (w for w in ("amira.khan", "eilidh.fraser", "femi.adeyemi")
             if any(o["interaction"].get("callback_id") == cb["id"] for o in self.get(w, "/v1/agent/workspace")["offers"])),
            None), timeout=30)
        o = next(o for o in self.get(holder, "/v1/agent/workspace")["offers"] if o["interaction"]["callback_id"] == cb["id"])
        cb_iid = str(o["interaction"]["id"])
        self.post(holder, f"/v1/interactions/{cb_iid}/accept", {"offer_id": o["id"]}, idem=True)
        self.note(f"Routed to and owned by {self.users[holder]['display_name']} (callback status "
                  f"{self.get(holder, '/v1/callbacks/' + cb['id'])['status']})")
        att = self.api.post("/v1/outbound-calls", headers=self.h(holder, True), json={"interaction_id": cb_iid})
        if att.status_code != 202:
            self.note(f"Dial refused by eligibility checks: {att.json()['error']['details'].get('failed')}")
        else:
            self.note(f"Eligibility passed ({len(att.json()['eligibility']['checks'])} checks, rule set "
                      f"v{att.json()['rule_set_version']}); dialling")
            self.wait("callback answered", lambda: self.interaction(holder, cb_iid)["status"] == "active")
            self.post(holder, f"/v1/interactions/{cb_iid}/actions", {"action": "end"}, idem=True)
            self.wait("callback wrap", lambda: self.interaction(holder, cb_iid)["status"] == "wrap_up")
            self.post(holder, f"/v1/interactions/{cb_iid}/wrap-up", {"disposition_code": "callback_completed"}, idem=True)
            cbv = self.get(holder, f"/v1/callbacks/{cb['id']}")
            self.note(f"Callback {cbv['status']} after {cbv['attempts']} attempt(s): {cbv['attempt_history']}")

        # 12 --------------------------------------------------------------
        self.step("Place an eligible manual outbound call (and see an ineligible one refused)")
        caller = "femi.adeyemi"
        bad = self.api.post("/v1/outbound-calls", headers=self.h(caller, True),
                            json={"number": "+441134960188", "purpose": "service"})
        self.note(f"Call to a number on the internal do-not-call list → {bad.status_code} "
                  f"{bad.json()['error']['code']}: {[c['check'] for c in bad.json()['error']['details']['failed']]}")
        cands = [("PCS-100301", "+441134960201", "Europe/London"), ("PCS-100318", "+441134960218", "Australia/Sydney")]
        ref, number, tz = next((c for c in cands if self.within_window(c[2])), cands[0])
        cust = self.get(caller, f"/v1/customers?q={ref}")[0]
        el = self.post(caller, "/v1/outbound-calls/eligibility", {"number": number, "purpose": "service",
                                                                   "customer_id": cust["id"]})
        self.note(f"Pre-check for {cust['display_name']}: eligible={el['eligible']}; "
                  + ", ".join(f"{c['check']}={'ok' if c['passed'] else 'FAIL'}" for c in el["checks"]))
        if el["eligible"]:
            att = self.post(caller, "/v1/outbound-calls", {"number": number, "purpose": "service",
                                                           "customer_id": cust["id"]}, idem=True)
            out_iid = str(att["interaction_id"])
            self.wait("outbound answered", lambda: self.interaction(caller, out_iid)["status"] == "active")
            d = self.interaction(caller, out_iid)
            self.note(f"Connected (provider-confirmed) presenting owned caller ID {d['call']['from_number']}")
            self.post(caller, f"/v1/interactions/{out_iid}/actions", {"action": "end"}, idem=True)
            self.wait("outbound wrap", lambda: self.interaction(caller, out_iid)["status"] == "wrap_up")
            self.post(caller, f"/v1/interactions/{out_iid}/wrap-up", {"disposition_code": "info_provided"}, idem=True)
        else:
            self.note("Outside permitted calling windows for every demo recipient: the call is correctly refused.")

        # 13 --------------------------------------------------------------
        self.step("Recover from a provider disconnection")
        self.sim.post("/v1/demo/inbound", json={"from_number": "+441134960201", "to_number": MAIN_LINE,
                                                "ivr_digits": "1"})
        who = self.wait("offer", lambda: next((w for w in ("amira.khan", "eilidh.fraser", "femi.adeyemi")
                                               if self.get(w, "/v1/agent/workspace")["offers"]), None))
        o = self.get(who, "/v1/agent/workspace")["offers"][0]
        r_iid = str(o["interaction"]["id"])
        self.post(who, f"/v1/interactions/{r_iid}/accept", {"offer_id": o["id"]}, idem=True)
        self.wait("connected", lambda: self.interaction(who, r_iid)["status"] == "active")
        self.sim.put("/v1/demo/faults", json={"outage": "blackhole"})
        self.note("Simulator outage injected: requests are applied but responses and events are lost")
        res = self.post(who, f"/v1/interactions/{r_iid}/actions", {"action": "hold"}, idem=True)
        self.note(f"Hold request outcome: {res['status']} ({res['error_code']}) – not retried")
        self.wait("disconnected", lambda: self.get(who, "/v1/agent/workspace")["provider"]["status"] == "disconnected")
        d = self.interaction(who, r_iid)
        disabled = [k for k, v in d["available_controls"].items() if not v["enabled"]]
        self.note(f"Provider marked disconnected; {len(disabled)} voice controls disabled; agent "
                  f"reconcile_required={self.get(who, '/v1/agent/workspace')['agent']['reconcile_required']}")
        blocked = self.api.post(f"/v1/interactions/{r_iid}/actions", headers=self.h(who, True), json={"action": "end"})
        self.note(f"End-call attempted during outage → {blocked.status_code} {blocked.json()['error']['code']}")
        self.sim.put("/v1/demo/faults", json={"outage": None})
        self.wait("connected again", lambda: self.get(who, "/v1/agent/workspace")["provider"]["status"] == "connected",
                  timeout=30)
        d = self.interaction(who, r_iid)
        hold = self.control(d, "hold")
        cust_leg = next(lg for lg in d["call"]["legs"] if lg["leg_type"] == "customer")
        held_events = [e for e in self.sim.get("/v1/demo/events?limit=500").json()["events"]
                       if e["type"] == "leg.held" and e["call_id"] == d["call"]["provider_call_id"]]
        self.note(f"Reconciled from provider state: hold {hold['status']} (resolved_by={hold['resolved_by']}), "
                  f"customer on_hold={cust_leg['on_hold']}; hold sent to provider {len(held_events)} time(s)")
        self.note(f"Agent reconcile_required={self.get(who, '/v1/agent/workspace')['agent']['reconcile_required']}")
        self.post(who, f"/v1/interactions/{r_iid}/actions", {"action": "resume"}, idem=True)
        self.wait("resumed", lambda: not next(lg for lg in self.interaction(who, r_iid)["call"]["legs"]
                                              if lg["leg_type"] == "customer")["on_hold"])
        self.post(who, f"/v1/interactions/{r_iid}/actions", {"action": "end"}, idem=True)
        self.wait("wrap", lambda: self.interaction(who, r_iid)["status"] == "wrap_up")
        self.post(who, f"/v1/interactions/{r_iid}/wrap-up", {"disposition_code": "info_provided"}, idem=True)
        self.note("Call resumed, ended and dispositioned normally after recovery")

        # 14 --------------------------------------------------------------
        self.step("Review reports and audit history")
        rep = self.get("grace.thornton", "/v1/reports/summary?include_synthetic_history=false")
        self.note(f"Today (excluding synthetic history): volumes {rep['volumes']}")
        self.note(f"Rates {rep['rates']}; AHT {rep['times_seconds']['average_handling_time']} s; "
                  f"transfers {rep['transfers']}; callbacks {rep['callbacks']}")
        self.note(f"Data quality: {rep['data_quality']}")
        trail = self.get("grace.thornton", f"/v1/audit?target_id={main_iid}")
        for a in reversed(trail[:8]):
            self.note(f"audit #{a['seq']} {a['at'][11:19]} {a['actor']}: {a['action']}")
        chain = self.get("grace.thornton", "/v1/audit/verify")
        self.note(f"Audit hash chain valid={chain['valid']} over {chain['checked']} entries")
        timeline = self.interaction("grace.thornton", main_iid)["timeline"]
        self.note(f"Interaction timeline has {len(timeline)} events; first/last: {timeline[0]['type']} → "
                  f"{timeline[-1]['type']}")
        self._stop.set()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--api", default=os.environ.get("API_URL", "http://localhost:8000"))
    ap.add_argument("--sim", default=os.environ.get("SIM_URL", "http://localhost:8090"))
    ap.add_argument("--out", default=os.path.join(os.path.dirname(__file__), "..", "docs", "demo-run.json"))
    args = ap.parse_args()
    demo = Demo(args.api, args.sim)
    try:
        demo.run()
        ok = True
    except Exception as exc:  # report and keep the partial log
        print(f"\n\033[1;31mDemo stopped: {exc}\033[0m")
        demo.log.append({"error": str(exc)})
        ok = False
    with open(args.out, "w") as f:
        json.dump({"completed": ok, "simulated": True, "steps": demo.log}, f, indent=2, default=str)
    print(f"\nLog written to {os.path.abspath(args.out)}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
