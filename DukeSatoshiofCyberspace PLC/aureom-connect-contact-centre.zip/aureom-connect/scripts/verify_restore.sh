#!/usr/bin/env bash
# Rehearse a restore and prove it: restore into a scratch database, then compare row counts,
# verify the audit hash chain and decrypt every stored object against its recorded SHA-256.
#   scripts/verify_restore.sh <backup-dir>
set -euo pipefail
cd "$(dirname "$0")/.."
IN="${1:?backup directory required}"
scripts/restore.sh "$IN"
PW="${POSTGRES_PASSWORD:-aureom-dev-password}"
URL="postgresql+psycopg://aureom:${PW}@db:5432/aureom_restore_check"
ABS=$(cd "$IN" && pwd)
docker compose run --rm --no-deps -T -e AUREOM_DATABASE_URL="$URL" -v "$ABS:/restore:ro" --entrypoint sh api -c '
  set -e
  mkdir -p /tmp/r && tar -xzf /restore/objects.tgz -C /tmp/r
  python -m aureom_connect.cli row-counts > /tmp/restored.json
  python - <<PY
import json
a = json.load(open("/restore/row-counts.json")); b = json.load(open("/tmp/restored.json"))
diff = {k: (a[k], b.get(k)) for k in a if a[k] != b.get(k)}
print(json.dumps({"row_counts_match": not diff, "tables_checked": len(a), "differences": diff}))
raise SystemExit(1 if diff else 0)
PY
  python -m aureom_connect.cli verify-audit
  python -m aureom_connect.cli verify-objects /tmp/r/objects
'
echo "Restore verified."
