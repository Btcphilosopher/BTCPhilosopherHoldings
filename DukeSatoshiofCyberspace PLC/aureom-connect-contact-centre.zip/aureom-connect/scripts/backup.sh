#!/usr/bin/env bash
# Back up the database (pg_dump custom format) and the protected object store.
# Objects stay encrypted with AUREOM_MASTER_KEY: store that key separately (e.g. a secrets manager);
# a backup without the key cannot be read, and the key without the backup is useless.
#   scripts/backup.sh [output-dir]
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="${1:-backups/$(date -u +%Y%m%dT%H%M%SZ)}"
mkdir -p "$OUT"
echo "Backing up database…"
docker compose exec -T db pg_dump -U aureom -d aureom --format=custom --no-owner > "$OUT/db.dump"
echo "Backing up protected object store…"
docker compose run --rm --no-deps -T --entrypoint tar api -czf - -C /data objects > "$OUT/objects.tgz"
docker compose run --rm --no-deps -T api python -m aureom_connect.cli row-counts > "$OUT/row-counts.json"
REV=$(docker compose exec -T db psql -U aureom -d aureom -tAc "select version_num from alembic_version")
( cd "$OUT" && sha256sum db.dump objects.tgz row-counts.json > SHA256SUMS )
cat > "$OUT/manifest.json" <<JSON
{"created_utc": "$(date -u +%FT%TZ)", "schema_revision": "$REV", "app_version": "1.0.0",
 "files": ["db.dump", "objects.tgz", "row-counts.json"], "objects_encrypted_with": "AUREOM_MASTER_KEY (not included)"}
JSON
echo "Backup written to $OUT"
