#!/usr/bin/env bash
# Restore a backup. By default into a SEPARATE database ("aureom_restore_check") so a restore can be
# rehearsed without touching live data. Use --into-live only during a planned recovery with the stack stopped.
#   scripts/restore.sh <backup-dir> [--into-live]
set -euo pipefail
cd "$(dirname "$0")/.."
IN="${1:?backup directory required}"
TARGET="aureom_restore_check"
[ "${2:-}" = "--into-live" ] && TARGET="aureom"
( cd "$IN" && sha256sum -c SHA256SUMS )
if [ "$TARGET" = "aureom" ]; then
  echo "Restoring INTO LIVE database. Stopping application services…"
  docker compose stop api worker
fi
docker compose exec -T db psql -U aureom -d postgres -v ON_ERROR_STOP=1 \
  -c "DROP DATABASE IF EXISTS $TARGET WITH (FORCE)" -c "CREATE DATABASE $TARGET"
docker compose exec -T db pg_restore -U aureom -d "$TARGET" --no-owner --exit-on-error < "$IN/db.dump"
echo "Database restored into $TARGET"
if [ "$TARGET" = "aureom" ]; then
  docker compose run --rm --no-deps -T --entrypoint sh api -c "rm -rf /data/objects/* && tar -xzf - -C /data" < "$IN/objects.tgz"
  docker compose start api worker
fi
