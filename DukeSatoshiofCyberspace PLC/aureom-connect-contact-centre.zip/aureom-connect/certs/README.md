# Optional extra CA certificates

Leave this folder empty unless your network uses a TLS-inspecting proxy.
Any `*.crt` (PEM) files placed here are trusted while building and running the
containers (pip, npm and outbound HTTPS from the API/worker). Never commit a
private key here.
