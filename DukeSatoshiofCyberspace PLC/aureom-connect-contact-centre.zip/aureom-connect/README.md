# AUREOM CONNECT — Contact Centre

A contact-centre platform for inbound calls, outbound campaigns, customer records, agent scheduling, quality
assurance and back-office work: a browser-based **agent workspace**, a **supervisor console**, a **Python/FastAPI
backend** on **PostgreSQL**, a **background worker**, and a reproducible **telephony demonstration** built around
the fictional *Pennine Customer Services*.

> **Simulated telephony — no audio.** The bundled provider is a signalling simulator. It produces signed,
> provider-style events (calls, legs, holds, transfers, recordings) but carries no audio and connects to no telephone
> network. Real telephony sits behind an explicitly configured adapter. Customers, numbers and accounts are fictional.

## Quick start (Docker)

```bash
docker compose up --build -d
docker compose ps            # wait for "api … (healthy)"
```

| URL | What |
|---|---|
| http://localhost:3000 | Agent workspace and supervisor console |
| http://localhost:8000/docs | API (OpenAPI / Swagger) |
| http://localhost:8090/v1/health | Telephony simulator |
| http://localhost:8025 | Mailpit — captured follow-up e-mails (nothing is delivered) |

Sign in with any seeded account, e.g. `amira.khan@pennine.example` (agent) or `grace.thornton@pennine.example`
(supervisor). Password: `Pennine-Demo-2026!` (demo only). Administrators also need a TOTP code:
`docker compose exec api python -m aureom_connect.cli totp kit.admin@pennine.example`.

Run the 14-step demonstration against the stack:

```bash
python3 -m pip install httpx
python3 scripts/demo.py --api http://localhost:8000 --sim http://localhost:8090
```

Copy `.env.example` to `.env` to change settings. **The defaults are development values.** With
`AUREOM_ENVIRONMENT=production` the API refuses to start until every secret is replaced and demo mode is off.
If your network uses a TLS-inspecting proxy, put its CA certificate in `certs/` before building.

## Local development (without Docker)

Requirements: Python 3.12+, Node 20.9+, PostgreSQL 14+ (tested with 16).

```bash
python3 -m venv .venv && . .venv/bin/activate
pip install -e simulator -e "backend[test,ai]"
export AUREOM_DATABASE_URL=postgresql+psycopg://postgres@localhost:5432/aureom
cd backend && python -m aureom_connect.cli bootstrap        # migrations + demo data
uvicorn aureom_connect.main:app --port 8000 &                # API
python -m aureom_connect.cli worker &                        # worker
SIM_WEBHOOK_URL=http://127.0.0.1:8000/v1/providers/simulated/events python -m aureom_sim &   # simulator :8090
cd ../web && npm ci && npm run dev                           # web :3000
```

## Tests

```bash
cd backend && AUREOM_TEST_ADMIN_URL=postgresql://postgres@localhost:5432/postgres pytest -v   # 70 tests
cd web && npx tsc --noEmit && npm run build
cd web && node e2e/smoke.mjs          # browser end-to-end against a running stack (Playwright)
scripts/backup.sh backups/test && scripts/verify_restore.sh backups/test
```

Actual results from this delivery: [docs/test-results.md](docs/test-results.md).

## What is implemented, simulated, externally integrated or deferred

The full matrix is in **[docs/capabilities.md](docs/capabilities.md)**. In brief:

* **Implemented:** inbound flow (IVR, hours/holidays, skills/language routing, overflow, voicemail, callbacks),
  transactional single ownership, explicit agent state with separate presence / provider registration / call state,
  call controls with requested → confirmed/failed/unknown outcomes, warm/blind transfer and conference with failure
  preservation, reconciliation after provider outages, customer matching and verification, cases/tasks with SLAs,
  versioned knowledge, AI-assist guardrails (heuristic baseline), recording policy/access/retention, QA with a
  published rubric, workforce scheduling and transparent forecasting, outbound eligibility with versioned
  jurisdiction rules, preview campaigns, reports with definitions, audit chain, backups with tested restore,
  Docker Compose.
* **Simulated:** all telephony signalling, IVR prompts, voicemail capture, recording media (synthetic tone),
  transcripts (scripted), secure payment capture, monitoring audio, inbound e-mail injection, forecast history.
* **Externally integrated (not live-tested):** Twilio adapter (partial: signature validation, access tokens,
  status callbacks, hang-up, state query), OIDC sign-in, Claude-backed AI assistant.
* **Deferred:** real media/WebRTC, a complete real-provider adapter, predictive dialling, S3 storage,
  distributed rate limiting, production hardening, legal review.

## Documentation

| Document | Contents |
|---|---|
| [capabilities.md](docs/capabilities.md) | Status of every requirement |
| [architecture.md](docs/architecture.md) | Components, data model, consistency, events, reconciliation, agent states |
| [routing.md](docs/routing.md) | Routing baseline, hours, IVR, overflow, missed offers |
| [api.md](docs/api.md) · [openapi.json](docs/openapi.json) | Conventions, endpoint mapping, WebSocket protocol |
| [telephony-adapters.md](docs/telephony-adapters.md) | Adapter contract, simulator and faults, Twilio adapter status |
| [metrics.md](docs/metrics.md) | Report definitions, denominators, exclusions, transfer treatment |
| [security.md](docs/security.md) | Sign-in, MFA, permissions, data protection, audit, known gaps |
| [compliance-research.md](docs/compliance-research.md) | What to research with official sources before going live |
| [operations.md](docs/operations.md) | Configuration, processes, migrations, backups, retention |
| [ui-guide.md](docs/ui-guide.md) | Layout, call controls, keyboard shortcuts, design tokens |
| [demo.md](docs/demo.md) | Running the demonstration and the actual recorded run |
| [test-results.md](docs/test-results.md) | Actual test, demo, Docker and restore results |
| [dependency-verification.md](docs/dependency-verification.md) | Versions, licences, compatibility decisions |

## Repository layout

```
backend/     FastAPI app, services, adapters, models, Alembic migrations, tests, Dockerfile
simulator/   telephony simulator (signalling only), Dockerfile
web/         Next.js agent workspace + supervisor console, e2e smoke test, Dockerfile
scripts/     demo.py, backup.sh, restore.sh, verify_restore.sh
docs/        documentation, OpenAPI, screenshots, demo log
certs/       optional extra CA certificates for builds behind TLS-inspecting proxies (empty)
docker-compose.yml, .env.example
```
