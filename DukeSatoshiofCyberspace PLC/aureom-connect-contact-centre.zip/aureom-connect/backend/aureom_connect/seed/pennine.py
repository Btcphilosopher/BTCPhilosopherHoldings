"""Synthetic demonstration data: Pennine Customer Services (entirely fictional).

All people, numbers, addresses and accounts are invented. Telephone numbers
use Ofcom's drama ranges (e.g. 0161 496 0xxx, 0113 496 0xxx) or the North
American 555-01xx fictional range, so they cannot reach real subscribers.

Run:  python -m aureom_connect.cli seed
"""
from __future__ import annotations

import random
import uuid
from datetime import date, datetime, time, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import utcnow
from ..models import (Account, Agent, AgentAvailability, AgentParticipation, AgentQueueMembership, AgentSkill,
                      BusinessHours, CallingRuleSet, Campaign, CampaignContact, Case, CaseEvent, CaseNote,
                      CommunicationPreference, Consent, ContactPoint, Customer, CustomerRestricted, CustomerSecret,
                      Feedback, Holiday, Interaction, IvrMenu, KnowledgeArticle, KnowledgeVersion, LeaveRequest,
                      MessageTemplate, Objection, ObservedDemand, Organisation, OutcomeCode, PhoneNumber,
                      ProviderConfig, QaRubric, Queue, QueueEntry, RecordingPolicy, Schedule, Shift,
                      ShiftChangeRequest, Skill, SlaPolicy, SourceSystemRef, SuppressionEntry, SuppressionList, Task,
                      User, VerificationPolicy)
from ..security.crypto import encrypt_str, hash_password, hash_secret_value
from ..services import refs

DEMO_PASSWORD = "Pennine-Demo-2026!"
DEMO_TOTP = {"kit.admin@pennine.example": "KRSXG5CTMVRXEZLUKN2XAZLSKNSWG4TF",
             "jo.pickering@pennine.example": "MFRGGZDFMZTWQ2LKNNWG23TPOBYXE43U"}
MAIN_LINE = "+441614960100"
OUTBOUND_LINE = "+441614960199"
UK = ZoneInfo("Europe/London")


def _bh_always() -> dict[str, list[list[str]]]:
    return {str(d): [["00:00", "23:59"]] for d in range(1, 8)}


def _bh_standard() -> dict[str, list[list[str]]]:
    w = {str(d): [["08:00", "20:00"]] for d in range(1, 6)}
    w["6"] = [["09:00", "17:00"]]
    w["7"] = []
    return w


CUSTOMERS: list[dict[str, Any]] = [
    dict(ref="PCS-100231", name="Margaret Ellison", phone="+441134960101", email="m.ellison@example.org", dob="1956-03-14",
         postcode="HX1 2AB", last4="4417", tz="Europe/London", lang="en", balance="£84.20 in credit",
         address="12 Mill Lane, Halifax HX1 2AB", plan="Standard water & sewerage", flags=["prefers_slower_pace"],
         consents=[("service_calls", "contract", "granted")]),
    dict(ref="PCS-100232", name="Tom Ellison", phone="+441134960101", email="tom.ellison@example.org", dob="1988-11-02",
         postcode="HX1 2AB", last4="8820", tz="Europe/London", lang="en", balance="£0.00",
         address="12 Mill Lane, Halifax HX1 2AB", plan="Standard water & sewerage", flags=[],
         consents=[("service_calls", "contract", "granted")], note="shares a household number with Margaret Ellison"),
    dict(ref="PCS-100245", name="Rhys Morgan", phone="+441134960145", email="rhys.morgan@example.org", dob="1979-07-21",
         postcode="OL14 6QT", last4="1093", tz="Europe/London", lang="cy", balance="£212.55 overdue",
         address="3 Cragg Vale Road, Todmorden OL14 6QT", plan="Metered", flags=[],
         consents=[("service_calls", "contract", "granted")]),
    dict(ref="PCS-100260", name="Aisha Rahman", phone="+441134960160", email="aisha.rahman@example.org", dob="1992-01-30",
         postcode="BD7 1DP", last4="5561", tz="Europe/London", lang="en", balance="£35.10 due 5 Dec",
         address="Flat 4, 88 Great Horton Road, Bradford BD7 1DP", plan="Metered", flags=[],
         consents=[("service_calls", "contract", "granted"), ("marketing_calls", "consent", "granted")]),
    dict(ref="PCS-100277", name="George Whitaker", phone="+441134960177", email="g.whitaker@example.org",
         dob="1948-09-09", postcode="HD1 3LT", last4="7002", tz="Europe/London", lang="en", balance="£0.00",
         address="27 Westgate, Huddersfield HD1 3LT", plan="WaterSure assessed charge",
         flags=["registered_priority_services"], consents=[("service_calls", "contract", "granted")],
         objections=[("telephone_marketing", "customer told agent 2026-09-02")]),
    dict(ref="PCS-100288", name="Lucy Barraclough", phone="+441134960188", email="lucy.b@example.org", dob="1985-05-17",
         postcode="LS28 5HP", last4="3388", tz="Europe/London", lang="en", balance="£61.00 due 1 Dec",
         address="9 Owlcotes Road, Pudsey LS28 5HP", plan="Metered", flags=[],
         consents=[("service_calls", "contract", "granted"), ("marketing_calls", "consent", "withdrawn")],
         suppressed="internal_dnc"),
    dict(ref="PCS-100301", name="Daniel Okoro", phone="+441134960201", email="d.okoro@example.org", dob="1990-12-12",
         postcode="HX3 6AJ", last4="9014", tz="Europe/London", lang="en", balance="£148.90 overdue",
         address="44 Shibden Hall Road, Halifax HX3 6AJ", plan="Metered", flags=[],
         consents=[("service_calls", "contract", "granted"), ("marketing_calls", "consent", "granted")]),
    dict(ref="PCS-100318", name="Priya Nair", phone="+441134960218", email="priya.nair@example.org", dob="1983-04-04",
         postcode="HG1 1BX", last4="2231", tz="Australia/Sydney", lang="en", balance="£19.75 due 12 Dec",
         address="c/o 5 Station Parade, Harrogate HG1 1BX (customer temporarily living in Sydney)",
         plan="Standard water & sewerage", flags=[],
         consents=[("service_calls", "contract", "granted"), ("marketing_calls", "consent", "granted")]),
    dict(ref="PCS-100325", name="Hannah Sutcliffe", phone="+441134960225", email="hannah.s@example.org",
         dob="1997-08-25", postcode="HX7 8AE", last4="6650", tz="Europe/London", lang="en", balance="£0.00",
         address="2 Bridge Gate, Hebden Bridge HX7 8AE", plan="Metered", flags=[],
         consents=[("service_calls", "contract", "granted")], account="ACC-3001", kind="organisation_contact"),
    dict(ref="PCS-100339", name="Marcus Lee", phone="+12025550142", email="marcus.lee@example.org", dob="1975-02-28",
         postcode="HX5 0QW", last4="4100", tz="America/New_York", lang="en", balance="£302.00 overdue",
         address="Holiday let: 1 Elland Riorges Link, Elland HX5 0QW (owner resides in Washington DC)",
         plan="Non-household", flags=[], consents=[("service_calls", "contract", "granted")]),
    dict(ref="PCS-100342", name="Sofia Marino", phone="+441134960242", email="sofia.marino@example.org",
         dob="1969-06-11", postcode="BD16 1AU", last4="7751", tz="Europe/London", lang="it", balance="£12.40 due 20 Dec",
         address="17 Main Street, Bingley BD16 1AU", plan="Metered", flags=[],
         consents=[("service_calls", "contract", "granted"), ("marketing_calls", "consent", "granted")]),
    dict(ref="PCS-100356", name="Owen Pickles", phone="+441134960256", email="owen.pickles@example.org", dob="2001-10-03",
         postcode="HX2 0TT", last4="1180", tz="Europe/London", lang="en", balance="£77.60 overdue",
         address="6 Wainhouse Terrace, Halifax HX2 0TT", plan="Metered", flags=[],
         consents=[("service_calls", "contract", "granted")]),
]

ARTICLES: list[dict[str, Any]] = [
    dict(slug="payment-arrangements", vis="customer_visible", team="Billing", title="Setting up a payment arrangement",
         summary="How to agree an affordable instalment plan for arrears.",
         body="Offer a payment arrangement when a customer has arrears or expects difficulty paying. Confirm the "
              "customer's identity first. Agree weekly, fortnightly or monthly instalments. Arrangements under 12 months "
              "can be agreed by any billing agent; longer plans need team leader approval. Send the 'Payment "
              "arrangement confirmation' template after the call. Never take card details verbally: use the secure "
              "payment option, which pauses recording.", tags=["billing", "arrears", "payment"]),
    dict(slug="priority-services-register", vis="customer_visible", team="Care",
         title="Priority Services Register: eligibility and support",
         summary="Extra help for customers who need it, and how to register them.",
         body="Customers may join the Priority Services Register if they are of pensionable age, have a disability or "
              "long-term condition, have young children, or need temporary support. Offer alternative formats, "
              "nominee contact, and advance notice of supply interruptions. Record only the support needed, not "
              "medical details, and ask permission before recording anything.", tags=["care", "support", "psr"]),
    dict(slug="no-water-supply", vis="internal", team="Technical", title="No water supply: triage script",
         summary="Internal triage steps for loss of supply reports.",
         body="Check the incident map for planned work or bursts at the customer's postcode. Ask whether neighbours "
              "are affected. If an incident exists, give the reference and estimated restoration time from the map, "
              "noting that times are estimates. If no incident, raise a 'loss of supply' job and create a follow-up "
              "task due within 4 hours. Priority Services customers get bottled water deliveries; escalate to the "
              "duty manager.", tags=["technical", "supply", "outage", "water"]),
    dict(slug="low-pressure", vis="customer_visible", team="Technical", title="Low water pressure: what to check",
         summary="Customer-facing checks for low pressure.",
         body="Ask the customer to check that their internal stop tap is fully open and whether all taps are "
              "affected. Low pressure at peak times can be normal. If pressure is low at all times, raise a pressure "
              "investigation; the network team will contact them within 5 working days.", tags=["technical", "pressure"]),
    dict(slug="meter-reading-dispute", vis="internal", team="Billing", title="Disputed meter readings",
         summary="Handling customers who dispute a meter reading.",
         body="Ask for a photo of the meter and reading. If the bill used an estimated reading, re-bill using the "
              "customer reading. If the reading was actual and is disputed, create a case in category 'billing "
              "dispute' and a meter accuracy test task. Do not promise refunds before investigation.",
         tags=["billing", "meter", "dispute"]),
    dict(slug="complaints-process", vis="customer_visible", team="Care", title="Making a complaint",
         summary="Our complaints process and timescales.",
         body="We log every complaint as a case. We aim to respond within 10 working days. If the customer is not "
              "satisfied with the final response they can escalate to the independent water ombudsman. Agents must "
              "not discourage complaints.", tags=["complaints", "care"]),
    dict(slug="moving-home", vis="customer_visible", team="Accounts", title="Moving home: closing and opening accounts",
         summary="Final readings and account changes when moving.",
         body="Take the moving date and a final meter reading. Changes to the account holder require verification. "
              "Send the closing bill to the forwarding address provided.", tags=["accounts", "move"]),
    dict(slug="vulnerable-callers-guidance", vis="internal", team="Care", title="Supporting customers in vulnerable situations",
         summary="Internal guidance on recognising and responding to vulnerability.",
         body="Listen for cues such as confusion, distress, financial hardship or mention of health conditions. Take "
              "extra time; do not rush. With permission, note the support needed. If there is an immediate risk to "
              "life, follow the emergency escalation procedure. Routing priority is never changed automatically "
              "because of vulnerability.", tags=["care", "vulnerability", "safeguarding"]),
]


def seed(db: Session, *, history_days: int = 7, rng_seed: int = 20261126, always_open: bool = True) -> dict[str, Any]:
    rng = random.Random(rng_seed)
    if db.scalar(select(Organisation).where(Organisation.slug == "pennine")):
        raise RuntimeError("Pennine Customer Services is already seeded")
    now = utcnow()
    org = Organisation(slug="pennine", name="Pennine Customer Services", timezone="Europe/London", jurisdiction="GB",
                       settings={"mfa_required_roles": ["admin", "compliance_officer"], "monitoring_enabled": True,
                                 "monitoring_requires_reason": True, "short_abandon_seconds": 5,
                                 "repeat_contact_days": 7, "four_eyes_campaigns": True,
                                 "callback_slots_per_interval": 2, "service_level_threshold_seconds": 20,
                                 "demo": True})
    db.add(org)
    db.flush()
    O = org.id

    # ------------------------------------------------------------------ users & agents
    def user(email: str, name: str, roles: list[str]) -> User:
        u = User(org_id=O, email=email, display_name=name, roles=roles, password_hash=hash_password(DEMO_PASSWORD),
                 active=True)
        if email in DEMO_TOTP:
            u.totp_secret_enc = encrypt_str(DEMO_TOTP[email])
            u.mfa_enrolled = True
        db.add(u)
        db.flush()
        return u

    skills = {}
    for code, name in [("billing", "Billing & payments"), ("technical", "Technical support"),
                       ("care", "Customer care & complaints"), ("outbound", "Outbound service calls"),
                       ("welsh", "Welsh language service")]:
        s = Skill(org_id=O, code=code, name=name)
        db.add(s)
        skills[code] = s
    db.flush()

    sla = {
        "billing": SlaPolicy(org_id=O, name="Billing answer target", applies_to="queue_answer", target_seconds=20,
                             target_percent=80, kind="internal_target"),
        "care": SlaPolicy(org_id=O, name="Care line answer commitment", applies_to="queue_answer", target_seconds=30,
                          target_percent=90, kind="contractual_commitment",
                          contract_ref="Pennine Water Services Agreement 2026, Schedule 3 §2.1 (fictional)"),
        "tech": SlaPolicy(org_id=O, name="Technical answer target", applies_to="queue_answer", target_seconds=30,
                          target_percent=80, kind="internal_target"),
        "case": SlaPolicy(org_id=O, name="Case resolution target (10 days)", applies_to="case_resolution",
                          target_seconds=10 * 86400, kind="internal_target"),
        "complaint": SlaPolicy(org_id=O, name="Complaint response commitment", applies_to="case_resolution",
                               target_seconds=10 * 86400, kind="contractual_commitment",
                               contract_ref="Customer Charter 2026 §5 (fictional)"),
        "task": SlaPolicy(org_id=O, name="Follow-up task target (2 days)", applies_to="task_completion",
                          target_seconds=2 * 86400, kind="internal_target"),
    }
    for s in sla.values():
        db.add(s)
    hours_demo = BusinessHours(org_id=O, name="Demo: extended hours (24×7, demonstration only)",
                               timezone="Europe/London", weekly=_bh_always())
    hours_std = BusinessHours(org_id=O, name="Standard UK contact hours", timezone="Europe/London",
                              weekly=_bh_standard())
    db.add_all([hours_demo, hours_std])
    db.flush()
    for d, n in [(date(2026, 12, 25), "Christmas Day"), (date(2026, 12, 26), "Boxing Day"),
                 (date(2026, 12, 28), "Boxing Day (substitute)"), (date(2027, 1, 1), "New Year's Day")]:
        db.add(Holiday(org_id=O, business_hours_id=hours_std.id, day=d, name=n, intervals=[]))
    db.add(Holiday(org_id=O, business_hours_id=hours_std.id, day=date(2026, 12, 24), name="Christmas Eve (reduced)",
                   intervals=[["09:00", "13:00"]]))

    rp_quality = RecordingPolicy(org_id=O, name="GB quality & training", jurisdiction="GB", purpose="quality_training",
                                 mode="notify_and_record", retention_days=90,
                                 notice_text="Calls are recorded for quality and training. Card payments are taken "
                                             "through a secure system and are not recorded.",
                                 access_roles=["quality_reviewer", "compliance_officer", "supervisor"])
    rp_care = RecordingPolicy(org_id=O, name="GB complaints & disputes", jurisdiction="GB",
                              purpose="dispute_resolution", mode="notify_and_record", retention_days=365,
                              notice_text="Calls are recorded so we can investigate complaints and disputes.",
                              access_roles=["compliance_officer", "supervisor"])
    db.add_all([rp_quality, rp_care])
    db.flush()
    bh = hours_demo if always_open else hours_std
    q_care = Queue(org_id=O, code="CARE", name="General Enquiries & Care", channel="voice,email,chat",
                   routing_priority=6, required_skills=["care"], business_hours_id=bh.id,
                   recording_policy_id=rp_care.id, sla_policy_id=sla["care"].id, offer_timeout_seconds=20)
    db.add(q_care)
    db.flush()
    q_billing = Queue(org_id=O, code="BILLING", name="Billing & Payments", channel="voice,email",
                      routing_priority=5, required_skills=["billing"], business_hours_id=bh.id,
                      overflow_queue_id=q_care.id, overflow_after_seconds=180, recording_policy_id=rp_quality.id,
                      sla_policy_id=sla["billing"].id, offer_timeout_seconds=20)
    q_tech = Queue(org_id=O, code="TECH", name="Technical Support", channel="voice,chat", routing_priority=4,
                   required_skills=["technical"], business_hours_id=bh.id, overflow_queue_id=q_care.id,
                   overflow_after_seconds=120, recording_policy_id=rp_quality.id, sla_policy_id=sla["tech"].id,
                   offer_timeout_seconds=20)
    db.add_all([q_billing, q_tech])
    db.flush()
    queues = {"CARE": q_care, "BILLING": q_billing, "TECH": q_tech}

    agent_defs = [
        ("amira.khan@pennine.example", "Amira Khan", ["billing", "care", "outbound"], ["en", "ur"], ["BILLING", "CARE"], "Team North"),
        ("ben.hughes@pennine.example", "Ben Hughes", ["technical", "care", "welsh"], ["en", "cy"], ["TECH", "CARE"], "Team North"),
        ("chloe.dawson@pennine.example", "Chloe Dawson", ["billing", "technical"], ["en"], ["BILLING", "TECH"], "Team North"),
        ("dev.patel@pennine.example", "Dev Patel", ["technical", "care"], ["en", "gu"], ["TECH", "CARE"], "Team South"),
        ("eilidh.fraser@pennine.example", "Eilidh Fraser", ["care", "billing"], ["en", "gd"], ["CARE", "BILLING"], "Team South"),
        ("femi.adeyemi@pennine.example", "Femi Adeyemi", ["billing", "outbound", "care"], ["en", "yo"], ["BILLING", "CARE"], "Team South"),
    ]
    agents: dict[str, Agent] = {}
    for email, name, sk, langs, qs, team in agent_defs:
        u = user(email, name, ["agent"])
        a = Agent(org_id=O, user_id=u.id, display_name=name, languages=langs, state="offline", state_since=now,
                  team=team, telephony_registration="unregistered", presence="offline")
        db.add(a)
        db.flush()
        for code in sk:
            db.add(AgentSkill(agent_id=a.id, skill_id=skills[code].id, proficiency=rng.randint(3, 5)))
        for qc in qs:
            db.add(AgentQueueMembership(agent_id=a.id, queue_id=queues[qc].id))
        for wd in range(1, 6):
            db.add(AgentAvailability(org_id=O, agent_id=a.id, weekday=wd, intervals=[["08:00", "18:00"]]))
        agents[name.split()[0].lower()] = a
    staff = {
        "grace": user("grace.thornton@pennine.example", "Grace Thornton", ["supervisor"]),
        "sam": user("sam.okafor@pennine.example", "Sam Okafor", ["supervisor"]),
        "harriet": user("harriet.lowe@pennine.example", "Harriet Lowe", ["quality_reviewer"]),
        "ian": user("ian.rowe@pennine.example", "Ian Rowe", ["workforce_manager"]),
        "jo": user("jo.pickering@pennine.example", "Jo Pickering", ["compliance_officer"]),
        "kit": user("kit.admin@pennine.example", "Kit Admin", ["admin"]),
        "lena": user("lena.ward@pennine.example", "Lena Ward", ["knowledge_editor"]),
    }

    # ------------------------------------------------------------------ IVR, numbers, provider
    ivr = IvrMenu(org_id=O, name="Pennine main menu", version=3, published=True,
                  definition={"start": "main", "hours_queue": "CARE", "nodes": {
                      "main": {"prompt": "Welcome to Pennine Customer Services. For billing and payments press 1. "
                                         "For a problem with your supply press 2. For anything else press 3. "
                                         "Am Gymraeg, pwyswch 4. To request a call back press 8.",
                               "options": {"1": {"action": "queue", "target": "BILLING"},
                                           "2": {"action": "queue", "target": "TECH"},
                                           "3": {"action": "queue", "target": "CARE"},
                                           "4": {"action": "queue", "target": "CARE", "language": "cy"},
                                           "8": {"action": "callback", "target": "CARE"},
                                           "9": {"action": "voicemail"}},
                               "timeout_action": {"action": "queue", "target": "CARE"}}}},
                  closed_action={"action": "voicemail", "prompt": "We are closed. Please leave a message."})
    db.add(ivr)
    db.flush()
    db.add(PhoneNumber(org_id=O, e164=MAIN_LINE, label="Main customer line (0161 496 0100)", ivr_menu_id=ivr.id,
                       provider="simulated", outbound_allowed=True, verified_at=now))
    out_line = PhoneNumber(org_id=O, e164=OUTBOUND_LINE, label="Outbound service line (0161 496 0199)",
                           provider="simulated", outbound_allowed=True, verified_at=now)
    db.add(out_line)
    db.add(ProviderConfig(org_id=O, provider="simulated", enabled=True,
                          public_settings={"note": "Bundled simulator; signalling only, no audio."},
                          connection_status="unknown"))
    db.flush()

    # ------------------------------------------------------------------ outcomes, templates, verification
    for code, label, cat, follow in [
        ("resolved_first_contact", "Resolved on this contact", "resolved", False),
        ("info_provided", "Information provided", "contact_made", False),
        ("payment_arrangement", "Payment arrangement agreed", "contact_made", True),
        ("payment_taken_secure", "Payment taken (secure capture)", "contact_made", False),
        ("fault_reported", "Fault reported – job raised", "follow_up", True),
        ("escalated", "Escalated", "follow_up", True),
        ("complaint_logged", "Complaint logged", "follow_up", True),
        ("transferred", "Transferred to colleague", "contact_made", False),
        ("callback_completed", "Callback completed", "contact_made", False),
        ("no_answer", "No answer", "no_contact", False),
        ("busy", "Line busy", "no_contact", False),
        ("voicemail_left", "Voicemail left", "no_contact", False),
        ("wrong_party", "Wrong person answered", "no_contact", False),
        ("do_not_call_requested", "Customer asked not to be called", "do_not_call", False),
        ("preview_skipped", "Preview skipped", "no_contact", False),
    ]:
        db.add(OutcomeCode(org_id=O, code=code, label=label, category=cat, applies_to=["interaction", "outbound"],
                           requires_follow_up=follow))
    db.add(VerificationPolicy(org_id=O, name="Standard knowledge-based verification",
                              factors=["date_of_birth", "postcode", "account_last4"], required_passes=2,
                              max_failures=3))
    db.add_all([
        MessageTemplate(org_id=O, code="payment_arrangement_confirmation", name="Payment arrangement confirmation",
                        channel="email", subject="Your payment arrangement with Pennine",
                        body="Dear {customer_name},\n\nThank you for speaking with us today. We have set up a payment "
                             "arrangement of {amount} {frequency}, starting {start_date}.\n\nReference: {reference}\n\n"
                             "Pennine Customer Services",
                        placeholders=["customer_name", "amount", "frequency", "start_date", "reference"],
                        approved=True, approved_by=staff["lena"].id),
        MessageTemplate(org_id=O, code="fault_reference", name="Fault reference follow-up", channel="email",
                        subject="Your fault reference {reference}",
                        body="Dear {customer_name},\n\nWe have logged your report. Your reference is {reference}. "
                             "{next_steps}\n\nPennine Customer Services",
                        placeholders=["customer_name", "reference", "next_steps"], approved=True,
                        approved_by=staff["lena"].id),
        MessageTemplate(org_id=O, code="callback_missed", name="We missed you (draft)", channel="email",
                        subject="We tried to call you", body="Dear {customer_name}, we tried to call you today.",
                        placeholders=["customer_name"], approved=False),
    ])

    # ------------------------------------------------------------------ customers
    acc = Account(org_id=O, account_ref="ACC-3001", name="Calder Valley Bakery Ltd (fictional)",
                  registration_number="00000001")
    db.add(acc)
    db.flush()
    dnc = SuppressionList(org_id=O, code="internal_dnc", name="Pennine internal do-not-call list",
                          source="Customer requests recorded by agents", refreshed_at=now)
    reg = SuppressionList(org_id=O, code="national_registry", name="National preference registry snapshot (synthetic)",
                          source="Synthetic stand-in for a national telephone preference register screening file",
                          refreshed_at=now - timedelta(days=3))
    db.add_all([dnc, reg])
    db.flush()
    db.add(SuppressionEntry(org_id=O, list_id=reg.id, normalized_number="+441134960256",
                            reason="registered (synthetic)", added_at=now - timedelta(days=30)))
    customers: dict[str, Customer] = {}
    for c in CUSTOMERS:
        cust = Customer(org_id=O, customer_ref=c["ref"], display_name=c["name"], preferred_language=c["lang"],
                        timezone=c["tz"], kind=c.get("kind", "person"), support_flags=c["flags"],
                        account_id=acc.id if c.get("account") else None)
        db.add(cust)
        db.flush()
        customers[c["ref"]] = cust
        db.add(ContactPoint(org_id=O, customer_id=cust.id, kind="phone", value=c["phone"], normalized=c["phone"],
                            label="mobile" if c["phone"].startswith("+447") else "home", is_primary=True,
                            verified_at=now - timedelta(days=200)))
        db.add(ContactPoint(org_id=O, customer_id=cust.id, kind="email", value=c["email"], normalized=c["email"].lower(),
                            label="personal", is_primary=True))
        for factor, val in [("date_of_birth", c["dob"]), ("postcode", c["postcode"]), ("account_last4", c["last4"])]:
            db.add(CustomerSecret(customer_id=cust.id, factor=factor, value_hash=hash_secret_value(val)))
        # Verification factors (date of birth, postcode, account digits) are never displayed, even after verification.
        db.add(CustomerRestricted(customer_id=cust.id, data={"balance": c["balance"], "address": c["address"],
                                                             "tariff": c["plan"]}))
        for purpose, basis, status in c["consents"]:
            db.add(Consent(org_id=O, customer_id=cust.id, purpose=purpose, basis=basis, status=status,
                           source="account opening" if basis == "contract" else "web preference centre",
                           captured_at=now - timedelta(days=rng.randint(60, 900)),
                           withdrawn_at=now - timedelta(days=20) if status == "withdrawn" else None))
        for scope, note in c.get("objections", []):
            db.add(Objection(org_id=O, customer_id=cust.id, scope=scope, source="phone", note=note,
                             recorded_at=now - timedelta(days=85)))
        if c.get("suppressed") == "internal_dnc":
            db.add(SuppressionEntry(org_id=O, list_id=dnc.id, normalized_number=c["phone"],
                                    reason="customer request 2026-10-30", added_at=now - timedelta(days=27)))
        db.add(CommunicationPreference(customer_id=cust.id, channel="email", purpose="service", allowed=True,
                                       preferred_window={}))
        if c["ref"] == "PCS-100277":
            db.add(CommunicationPreference(customer_id=cust.id, channel="phone", purpose="marketing", allowed=False,
                                           preferred_window={}))
        db.add(SourceSystemRef(customer_id=cust.id, system="crm", external_id=f"CRM-{c['ref'][4:]}", synced_at=now))
        db.add(SourceSystemRef(customer_id=cust.id, system="billing", external_id=f"BIL-{rng.randint(10**7, 10**8)}",
                               synced_at=now - timedelta(hours=6)))

    # ------------------------------------------------------------------ rules
    gb_rules = {
        "calling_windows": {**{str(d): [["08:00", "21:00"]] for d in range(1, 6)}, "6": [["09:00", "17:00"]], "7": []},
        "max_attempts_per_day": 2, "max_attempts_per_7_days": 6, "min_minutes_between_attempts": 60,
        "purposes": {"marketing": {"basis_required": ["consent"], "screen_lists": ["internal_dnc", "national_registry"]},
                     "service": {"basis_required": ["contract", "consent", "customer_request", "legitimate_interest"],
                                 "screen_lists": ["internal_dnc"]}},
        "objection_scopes": {"marketing": ["all_marketing", "telephone_marketing", "all_telephone"],
                             "service": ["all_telephone"]},
    }
    db.add(CallingRuleSet(org_id=O, jurisdiction="GB", version=1, status="retired",
                          effective_from=now - timedelta(days=400), effective_to=now - timedelta(days=60),
                          rules={**gb_rules, "max_attempts_per_day": 3},
                          source_notes="Superseded. Illustrative configuration only."))
    db.add(CallingRuleSet(org_id=O, jurisdiction="GB", version=2, status="active",
                          effective_from=now - timedelta(days=60), rules=gb_rules, approved_by=staff["jo"].id,
                          source_notes="ILLUSTRATIVE configuration for the demonstration. Must be validated against "
                                       "current official sources (e.g. Ofcom persistent misuse policy, ICO PECR "
                                       "guidance, TPS screening obligations) before live use."))
    us_rules = {**gb_rules, "calling_windows": {str(d): [["08:00", "21:00"]] for d in range(1, 8)},
                "max_attempts_per_day": 1}
    db.add(CallingRuleSet(org_id=O, jurisdiction="US", version=1, status="active",
                          effective_from=now - timedelta(days=30), rules=us_rules, approved_by=staff["jo"].id,
                          source_notes="ILLUSTRATIVE only. US federal and state rules (e.g. TCPA, state "
                                       "mini-TCPA laws, calling-hour limits) must be reviewed by counsel."))

    # ------------------------------------------------------------------ knowledge
    for i, a in enumerate(ARTICLES):
        art = KnowledgeArticle(org_id=O, slug=a["slug"], owner_user_id=staff["lena"].id, owner_team=a["team"],
                               visibility=a["vis"])
        db.add(art)
        db.flush()
        v = KnowledgeVersion(org_id=O, article_id=art.id, version=2 if i < 3 else 1, title=a["title"],
                             summary=a["summary"], body=a["body"], tags=a["tags"], status="approved",
                             effective_from=now - timedelta(days=30), review_due_at=now + timedelta(days=150 - i * 20),
                             authored_by=staff["lena"].id, reviewed_by=staff["grace"].id,
                             approved_at=now - timedelta(days=31), change_note="Annual review")
        db.add(v)
        if i < 3:
            db.add(KnowledgeVersion(org_id=O, article_id=art.id, version=1, title=a["title"] + " (old)",
                                    summary=a["summary"], body="Superseded wording.", tags=a["tags"], status="retired",
                                    effective_from=now - timedelta(days=400), effective_to=now - timedelta(days=30),
                                    authored_by=staff["lena"].id, reviewed_by=staff["grace"].id))
        db.flush()
        art.current_version_id = v.id
    art = KnowledgeArticle(org_id=O, slug="winter-tariff-2027", owner_user_id=staff["lena"].id, owner_team="Billing",
                           visibility="customer_visible")
    db.add(art)
    db.flush()
    db.add(KnowledgeVersion(org_id=O, article_id=art.id, version=1, title="2027 tariff changes (effective 1 April 2027)",
                            summary="Not yet effective.", body="New charges apply from 1 April 2027.",
                            tags=["billing", "tariff"], status="approved", effective_from=datetime(2027, 4, 1, tzinfo=UK),
                            authored_by=staff["lena"].id, reviewed_by=staff["grace"].id))
    db.add(KnowledgeVersion(org_id=O, article_id=art.id, version=2, title="2027 tariff changes – draft FAQ",
                            summary="Draft", body="Draft FAQ awaiting review.", tags=["billing"], status="in_review",
                            authored_by=staff["lena"].id))

    # ------------------------------------------------------------------ QA rubric
    db.add(QaRubric(org_id=O, name="Pennine Service Quality", version=2, status="active", criteria=[
        {"id": "verify", "label": "Verified identity before restricted information", "weight": 3, "scale": [0, 1, 2],
         "guidance": {"0": "Disclosed restricted data before verification", "1": "Partly", "2": "Fully followed policy"}},
        {"id": "understand", "label": "Understood the customer's need", "weight": 2, "scale": [0, 1, 2],
         "guidance": {"0": "Need not established", "1": "Partly", "2": "Confirmed back to the customer"}},
        {"id": "accurate", "label": "Accurate information from approved knowledge", "weight": 3, "scale": [0, 1, 2],
         "guidance": {"0": "Inaccurate", "1": "Minor gaps", "2": "Accurate and sourced"}},
        {"id": "next_steps", "label": "Clear next steps and follow-up recorded", "weight": 2, "scale": [0, 1, 2],
         "guidance": {"0": "None", "1": "Stated but not recorded", "2": "Stated and recorded"}},
        {"id": "care", "label": "Treated the customer with care and respect", "weight": 2, "scale": [0, 1, 2],
         "guidance": {"0": "Poor", "1": "Adequate", "2": "Good"}},
    ], documentation="Score = Σ(score × weight) ÷ Σ(max × weight) × 100. Reviews are done by a person using the "
                     "recording, transcript and timeline. Agents may acknowledge or dispute; disputes are re-reviewed. "
                     "Scores describe one interaction against this rubric, not overall performance. No AI scoring."))

    # ------------------------------------------------------------------ cases & tasks
    def case(cust_ref: str, title: str, cat: str, status: str, owner: Agent | None, days_old: int, sla_key: str,
             priority: str = "normal") -> Case:
        cs = Case(org_id=O, case_ref=refs.next_ref(db, O, "case"), customer_id=customers[cust_ref].id, title=title,
                  category=cat, status=status, priority=priority, owner_agent_id=owner.id if owner else None,
                  owner_queue_id=q_care.id if cat == "complaint" else q_billing.id, sla_policy_id=sla[sla_key].id,
                  due_at=now - timedelta(days=days_old) + timedelta(seconds=sla[sla_key].target_seconds),
                  created_by=staff["grace"].id)
        cs.created_at = now - timedelta(days=days_old)
        db.add(cs)
        db.flush()
        db.add(CaseEvent(org_id=O, case_id=cs.id, type="created", actor_user_id=staff["grace"].id,
                         at=cs.created_at, data={"status": status}))
        return cs

    case("PCS-100245", "Arrears – request for payment arrangement", "billing", "open", agents["amira"], 3, "case")
    c2 = case("PCS-100231", "Disputed estimated bill (Oct)", "billing_dispute", "pending_internal", agents["eilidh"], 6, "case")
    c3 = case("PCS-100277", "Complaint: missed appointment for meter fit", "complaint", "open", agents["eilidh"], 9,
              "complaint", "high")
    c4 = case("PCS-100301", "Low pressure investigation", "technical", "pending_customer", agents["dev"], 2, "case")
    c5 = case("PCS-100342", "Name change on account", "accounts", "resolved", agents["femi"], 12, "case")
    c5.resolved_at = now - timedelta(days=10)
    c5.outcome_code = "resolved_first_contact"
    db.add(CaseNote(org_id=O, case_id=c3.id, author_user_id=agents["eilidh"].user_id,
                    body="Customer is a Priority Services member; apologised for the missed appointment.",
                    created_at=now - timedelta(days=9)))
    for title, cs, ag, due_days in [("Send meter accuracy test form", c2, agents["eilidh"], 1),
                                    ("Call customer with pressure test results", c4, agents["dev"], 2),
                                    ("Final response letter to complaint", c3, agents["eilidh"], -1)]:
        db.add(Task(org_id=O, kind="follow_up", title=title, case_id=cs.id, customer_id=cs.customer_id,
                    assignee_agent_id=ag.id, due_at=now + timedelta(days=due_days), sla_policy_id=sla["task"].id,
                    created_by=staff["grace"].id, priority="high" if due_days < 0 else "normal"))
    db.add(Task(org_id=O, kind="back_office", title="Review direct debit mandate returns", assignee_queue_id=q_billing.id,
                due_at=now + timedelta(hours=6), created_by=staff["grace"].id))

    # ------------------------------------------------------------------ campaign (preview) and callbacks
    camp = Campaign(org_id=O, name="Winter payment support check-in", purpose="service", dial_mode="preview",
                    status="active", queue_id=q_billing.id, jurisdiction="GB", caller_id_number_id=out_line.id,
                    max_attempts_per_contact=3, created_by=staff["grace"].id, approved_by=staff["sam"].id,
                    activated_at=now - timedelta(days=1),
                    description="Service call to customers with arrears, offering payment arrangements. Preview only.",
                    review_summary={})
    db.add(camp)
    db.flush()
    for ref in ["PCS-100245", "PCS-100301", "PCS-100356", "PCS-100288", "PCS-100318", "PCS-100339"]:
        c = next(x for x in CUSTOMERS if x["ref"] == ref)
        db.add(CampaignContact(org_id=O, campaign_id=camp.id, customer_id=customers[ref].id, display_name=c["name"],
                               normalized_number=c["phone"], timezone=c["tz"], precheck={},
                               status="excluded" if c.get("suppressed") else "ready"))
    db.flush()
    from ..services.outbound import review_summary

    camp.review_summary = review_summary(db, camp)
    db.add(Campaign(org_id=O, name="Smart meter appointment offer (marketing)", purpose="marketing", dial_mode="preview",
                    status="draft", queue_id=q_billing.id, jurisdiction="GB", caller_id_number_id=out_line.id,
                    max_attempts_per_contact=2, created_by=staff["grace"].id,
                    description="Draft. Import a list and review before activation.", review_summary={}))
    from ..services.callbacks import create_callback

    cb1 = create_callback(db, O, phone_number="+441134960242", number_confirmation_method="customer_confirmed",
                          window_start=now - timedelta(minutes=5), window_end=now + timedelta(hours=3), queue=q_billing,
                          customer_id=customers["PCS-100342"].id, origin_interaction_id=None,
                          created_by=agents["chloe"].user_id, created_via="agent",
                          reason="Customer wants to discuss a bill query once at home", reserve_capacity=False)
    create_callback(db, O, phone_number="+441134960160", number_confirmation_method="verified_contact_point",
                    window_start=now + timedelta(hours=20), window_end=now + timedelta(hours=22), queue=q_tech,
                    customer_id=customers["PCS-100260"].id, origin_interaction_id=None,
                    created_by=agents["dev"].user_id, created_via="agent", reason="Follow up on pressure test",
                    reserve_capacity=True)

    # ------------------------------------------------------------------ workforce
    monday = (now.astimezone(UK).date() - timedelta(days=now.astimezone(UK).weekday()))
    sched = Schedule(org_id=O, name=f"Week of {monday:%d %b %Y}", period_start=monday,
                     period_end=monday + timedelta(days=6), status="published", published_at=now - timedelta(days=5),
                     published_by=staff["ian"].id)
    nxt = Schedule(org_id=O, name=f"Week of {(monday + timedelta(days=7)):%d %b %Y} (draft)",
                   period_start=monday + timedelta(days=7), period_end=monday + timedelta(days=13), status="draft")
    db.add_all([sched, nxt])
    db.flush()
    starts = {"amira": 8, "ben": 9, "chloe": 8, "dev": 10, "eilidh": 12, "femi": 9}
    first_shift = None
    for wk, sc in [(0, sched), (7, nxt)]:
        for d in range(5):
            day = monday + timedelta(days=wk + d)
            for key, ag in agents.items():
                if key == "dev" and wk == 0 and d == 2:
                    continue  # approved leave
                st = datetime.combine(day, time(starts[key], 0), UK)
                en = st + timedelta(hours=8)
                sh = Shift(org_id=O, schedule_id=sc.id, agent_id=ag.id, start_at=st, end_at=en,
                           activities=[{"kind": "break", "start": (st + timedelta(hours=2)).isoformat(),
                                        "end": (st + timedelta(hours=2, minutes=15)).isoformat()},
                                       {"kind": "lunch", "start": (st + timedelta(hours=4)).isoformat(),
                                        "end": (st + timedelta(hours=4, minutes=45)).isoformat()}],
                           queue_codes=[q.code for q in queues.values()
                                        if q.id in {m for m in db.scalars(select(AgentQueueMembership.queue_id).where(
                                            AgentQueueMembership.agent_id == ag.id))}])
                db.add(sh)
                if first_shift is None and key == "ben" and wk == 0 and d >= now.astimezone(UK).weekday():
                    first_shift = sh
    db.add(LeaveRequest(org_id=O, agent_id=agents["dev"].id, kind="annual", status="approved",
                        start_at=datetime.combine(monday + timedelta(days=2), time(0), UK),
                        end_at=datetime.combine(monday + timedelta(days=3), time(0), UK), decided_by=staff["ian"].id))
    db.flush()
    if first_shift is not None:
        db.add(ShiftChangeRequest(org_id=O, shift_id=first_shift.id, requested_by_agent_id=agents["ben"].id,
                                  kind="change", proposed_start_at=first_shift.start_at + timedelta(hours=1),
                                  proposed_end_at=first_shift.end_at + timedelta(hours=1),
                                  reason="Dentist appointment in the morning"))

    # ------------------------------------------------------------------ synthetic history
    hist = _history(db, O, rng, queues, agents, customers, now, history_days)
    _observed_history(db, O, rng, queues, now)
    db.flush()
    return {"org_id": O, "agents": {k: a.id for k, a in agents.items()}, "queues": {k: q.id for k, q in queues.items()},
            "customers": {k: c.id for k, c in customers.items()}, "campaign_id": camp.id, "callback_id": cb1.id,
            "history_interactions": hist}


def _history(db: Session, O: uuid.UUID, rng: random.Random, queues: dict[str, Queue], agents: dict[str, Agent],
             customers: dict[str, Customer], now: datetime, days: int) -> int:
    """Completed synthetic interactions for reports and QA. Labelled source='synthetic_history'."""
    n = 0
    members = {
        "BILLING": ["amira", "chloe", "eilidh", "femi"], "TECH": ["ben", "chloe", "dev"],
        "CARE": ["amira", "ben", "dev", "eilidh", "femi"]}
    cust_list = list(customers.values())
    for d in range(days, 0, -1):
        day = (now - timedelta(days=d)).astimezone(UK).date()
        if day.isoweekday() == 7:
            continue
        for qc, q in queues.items():
            for _ in range(rng.randint(4, 9)):
                start = datetime.combine(day, time(rng.randint(8, 18), rng.randint(0, 59)), UK)
                wait = int(rng.expovariate(1 / 25))
                abandoned = rng.random() < 0.08
                cust = rng.choice(cust_list) if rng.random() < 0.8 else None
                it = Interaction(org_id=O, reference=refs.next_ref(db, O, "interaction"), channel="voice",
                                 direction="inbound", status="abandoned" if abandoned else "completed",
                                 source="synthetic_history", is_simulated=True, customer_id=cust.id if cust else None,
                                 customer_match_status="verified" if cust else "unmatched", match_hint={},
                                 current_queue_id=q.id, required_skills=q.required_skills, first_queued_at=start,
                                 routable_since=start, ivr_path=[], transfer_state={})
                it.created_at = start
                db.add(it)
                db.flush()
                qe = QueueEntry(org_id=O, interaction_id=it.id, queue_id=q.id, sequence=1, entered_at=start,
                                left_at=start + timedelta(seconds=wait), exit_reason="abandoned" if abandoned else "answered")
                db.add(qe)
                n += 1
                if abandoned:
                    it.ended_at = qe.left_at
                    continue
                ag = agents[rng.choice(members[qc])]
                talk = int(rng.gauss(260, 90))
                talk = max(45, talk)
                hold = rng.choice([0, 0, 0, 30, 60])
                acw = max(10, int(rng.gauss(55, 20)))
                conn = qe.left_at
                end = conn + timedelta(seconds=talk + hold)
                it.connected_at, it.ended_at = conn, end
                it.owner_agent_id = ag.id
                it.wrap_completed_at = end + timedelta(seconds=acw)
                it.disposition_code = rng.choice(["resolved_first_contact", "info_provided", "payment_arrangement",
                                                  "fault_reported", "escalated"])
                transferred = rng.random() < 0.07
                db.add(AgentParticipation(org_id=O, interaction_id=it.id, agent_id=ag.id, role="primary",
                                          accepted_at=conn, connected_at=conn,
                                          ended_at=end if not transferred else conn + timedelta(seconds=talk // 2),
                                          wrap_started_at=end, wrap_ended_at=end + timedelta(seconds=acw),
                                          hold_seconds=hold, outcome="transferred_out" if transferred else "handled"))
                if transferred:
                    it.transfer_count = 1
                    other = agents[rng.choice([k for k in members["CARE"] if agents[k].id != ag.id])]
                    it.owner_agent_id = other.id
                    mid = conn + timedelta(seconds=talk // 2)
                    db.add(AgentParticipation(org_id=O, interaction_id=it.id, agent_id=other.id,
                                              role="transfer_receiver", accepted_at=mid, connected_at=mid, ended_at=end,
                                              wrap_started_at=end, wrap_ended_at=end + timedelta(seconds=acw),
                                              hold_seconds=0, outcome="handled"))
                if rng.random() < 0.3:
                    db.add(Feedback(org_id=O, interaction_id=it.id, score=rng.choices([1, 2, 3, 4, 5],
                                                                                      [3, 4, 10, 35, 48])[0],
                                    received_at=end + timedelta(minutes=2), channel="ivr_survey"))
    return n


def _observed_history(db: Session, O: uuid.UUID, rng: random.Random, queues: dict[str, Queue], now: datetime) -> None:
    """Six weeks of imported synthetic interval history for transparent forecasting."""
    base = {"BILLING": 6.0, "TECH": 4.0, "CARE": 5.0}
    profile = {8: .6, 9: 1.2, 10: 1.4, 11: 1.3, 12: 1.0, 13: 1.1, 14: 1.2, 15: 1.0, 16: .9, 17: .8, 18: .5, 19: .3}
    today = now.astimezone(UK).date()
    for d in range(42, 0, -1):
        day = today - timedelta(days=d)
        wd = day.isoweekday()
        if wd == 7:
            continue
        for qc, q in queues.items():
            for h, f in profile.items():
                if wd == 6 and not 9 <= h < 17:
                    continue
                for half in (0, 30):
                    lam = base[qc] * f * (0.7 if wd == 6 else 1.0) * (1.15 if wd == 1 else 1.0)
                    offered = max(0, int(rng.gauss(lam, lam ** 0.5)))
                    db.add(ObservedDemand(org_id=O, queue_id=q.id,
                                          interval_start=datetime.combine(day, time(h, half), UK),
                                          interval_minutes=30, offered=offered,
                                          answered=max(0, offered - int(offered * rng.uniform(0, .1))),
                                          avg_handle_seconds=rng.gauss(330, 30), source="imported_synthetic_history"))
