"""Structured application errors.

Every error response has the shape::

    {"error": {"code": "OWNERSHIP_CONFLICT", "message": "...", "details": {...}, "request_id": "..."}}
"""
from __future__ import annotations

from typing import Any


class AppError(Exception):
    status_code = 400
    code = "BAD_REQUEST"

    def __init__(self, message: str, *, code: str | None = None, status_code: int | None = None,
                 details: dict[str, Any] | None = None):
        super().__init__(message)
        self.message = message
        if code:
            self.code = code
        if status_code:
            self.status_code = status_code
        self.details = details or {}


class NotFound(AppError):
    status_code = 404
    code = "NOT_FOUND"


class Unauthorized(AppError):
    status_code = 401
    code = "UNAUTHENTICATED"


class Forbidden(AppError):
    status_code = 403
    code = "FORBIDDEN"


class Conflict(AppError):
    status_code = 409
    code = "CONFLICT"


class VersionConflict(Conflict):
    code = "VERSION_CONFLICT"


class OwnershipConflict(Conflict):
    code = "OWNERSHIP_CONFLICT"


class InvalidTransition(Conflict):
    code = "INVALID_STATE_TRANSITION"


class ReconciliationRequired(Conflict):
    code = "RECONCILIATION_REQUIRED"


class Unsupported(AppError):
    status_code = 422
    code = "UNSUPPORTED_BY_PROVIDER"


class ValidationFailed(AppError):
    status_code = 422
    code = "VALIDATION_FAILED"


class VerificationRequired(Forbidden):
    code = "VERIFICATION_REQUIRED"


class RateLimited(AppError):
    status_code = 429
    code = "RATE_LIMITED"


class ProviderUnavailable(AppError):
    status_code = 503
    code = "PROVIDER_UNAVAILABLE"
