"""Runtime configuration.

All settings come from environment variables (prefix ``AUREOM_``) so that the
same image runs in development, CI and production. Secrets are never given
defaults that would be safe to deploy: the development defaults below are
deliberately labelled and the application refuses to start in ``production``
mode while they are still in use.
"""
from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

DEV_INSECURE = "dev-insecure-change-me"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="AUREOM_", env_file=".env", extra="ignore")

    environment: Literal["development", "test", "production"] = "development"
    demo_mode: bool = True

    database_url: str = "postgresql+psycopg://postgres@127.0.0.1:55432/aureom_dev"

    # Signing key for short-lived application access tokens (HS256).
    jwt_secret: str = DEV_INSECURE + "-jwt"
    access_token_minutes: int = 30
    refresh_token_days: int = 7

    # Key-encryption key for secrets at rest (provider credentials, TOTP
    # secrets, stored objects). 32 url-safe base64 bytes (Fernet format).
    master_key: str = "x8ZpQ2b0n0zq3vK0m3bH6m2sY9d1c4pL7rT5u8wA0eE="

    cors_origins: list[str] = Field(default_factory=lambda: ["http://localhost:3000", "http://127.0.0.1:3000"])

    # --- Telephony -------------------------------------------------------
    # "simulated" uses the bundled telephony simulator (no audio).
    # "twilio" requires explicit credentials below and is disabled otherwise.
    telephony_provider: Literal["simulated", "twilio", "none"] = "simulated"
    simulator_url: str = "http://127.0.0.1:8090"
    # Browser-facing simulator URL (may differ from the internal service URL in Docker).
    simulator_public_url: str = "http://localhost:8090"
    simulator_webhook_secret: str = DEV_INSECURE + "-sim-webhook"
    simulator_api_key: str = DEV_INSECURE + "-sim-api"
    provider_event_tolerance_seconds: int = 300

    twilio_account_sid: str | None = None
    twilio_api_key_sid: str | None = None
    twilio_api_key_secret: str | None = None
    twilio_auth_token: str | None = None
    twilio_twiml_app_sid: str | None = None
    twilio_public_webhook_base: str | None = None

    # --- Channels --------------------------------------------------------
    smtp_host: str | None = None  # e.g. mailpit in docker compose
    smtp_port: int = 1025
    smtp_from: str = "service@pennine.example"

    # --- Storage ---------------------------------------------------------
    storage_dir: str = "./var/objects"

    # --- AI assistance ---------------------------------------------------
    ai_provider: Literal["disabled", "heuristic", "anthropic"] = "heuristic"
    anthropic_api_key: str | None = None
    anthropic_model: str = "claude-opus-5-5"

    # --- Auth ------------------------------------------------------------
    oidc_issuer: str | None = None
    oidc_client_id: str | None = None
    oidc_client_secret: str | None = None
    oidc_redirect_uri: str | None = None
    oidc_mfa_amr_values: list[str] = Field(default_factory=lambda: ["mfa", "otp", "hwk", "swk"])

    # --- Operational behaviour ------------------------------------------
    offer_timeout_seconds: int = 20
    transfer_consult_timeout_seconds: int = 30
    presence_grace_seconds: int = 30
    device_heartbeat_timeout_seconds: int = 45
    rate_limit_per_minute: int = 600
    login_rate_limit_per_minute: int = 20

    def assert_safe_for_production(self) -> None:
        if self.environment != "production":
            return
        bad = [
            name
            for name in ("jwt_secret", "simulator_webhook_secret", "simulator_api_key")
            if DEV_INSECURE in getattr(self, name)
        ]
        if self.master_key.startswith("x8ZpQ2b0"):
            bad.append("master_key")
        if self.demo_mode:
            bad.append("demo_mode")
        if bad:
            raise RuntimeError(f"Refusing to start in production with development values: {bad}")


@lru_cache
def get_settings() -> Settings:
    return Settings()
