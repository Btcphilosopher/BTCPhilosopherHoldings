"""Protected object storage.

Objects are encrypted at rest (Fernet / AES-128-CBC + HMAC-SHA256 with the
master key) and are only ever served through API endpoints that check
permissions and write an audit record. There is no public URL.

``LocalProtectedStorage`` stores ciphertext on a private volume. An
S3-compatible implementation can satisfy the same interface; it is listed
as an external integration in docs/capabilities.md.
"""
from __future__ import annotations

import hashlib
import os
import uuid
from pathlib import Path
from typing import Protocol

from ..config import get_settings
from ..security.crypto import decrypt_bytes, encrypt_bytes


class ObjectStorage(Protocol):
    def put(self, data: bytes, *, prefix: str) -> tuple[str, str, int]: ...

    def get(self, key: str) -> bytes: ...

    def delete(self, key: str) -> bool: ...

    def exists(self, key: str) -> bool: ...


class LocalProtectedStorage:
    def __init__(self, root: str | None = None):
        self.root = Path(root or get_settings().storage_dir).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        os.chmod(self.root, 0o700)

    def _path(self, key: str) -> Path:
        if ".." in key or key.startswith("/"):
            raise ValueError("invalid key")
        return self.root / key

    def put(self, data: bytes, *, prefix: str) -> tuple[str, str, int]:
        key = f"{prefix}/{uuid.uuid4().hex}.bin"
        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(encrypt_bytes(data))
        os.chmod(p, 0o600)
        return key, hashlib.sha256(data).hexdigest(), len(data)

    def get(self, key: str) -> bytes:
        return decrypt_bytes(self._path(key).read_bytes())

    def delete(self, key: str) -> bool:
        p = self._path(key)
        if p.exists():
            p.unlink()
            return True
        return False

    def exists(self, key: str) -> bool:
        return self._path(key).exists()


_storage: ObjectStorage | None = None


def get_storage() -> ObjectStorage:
    global _storage
    if _storage is None:
        _storage = LocalProtectedStorage()
    return _storage


def set_storage(s: ObjectStorage | None) -> None:
    global _storage
    _storage = s
