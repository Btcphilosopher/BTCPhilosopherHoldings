"""Typed telephony provider adapter contract.

The application orchestrates *workflow*; codecs, media transport and
telephone signalling belong to the provider. Every adapter:

* declares its capabilities explicitly — the UI disables anything unsupported;
* returns a ``ControlResult`` whose ``outcome`` describes only whether the
  provider *accepted the request for processing*. Remote call state changes
  are learned exclusively from verified provider events or state queries;
* verifies inbound webhooks and normalises them into ``NormalizedEvent``.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, Literal, Protocol, runtime_checkable

from pydantic import BaseModel, Field


class ProviderCapabilities(BaseModel):
    provider: str
    media: Literal["none_simulated", "webrtc", "pstn_only"]
    answer: bool = False
    reject: bool = False
    mute: bool = False  # provider-side mute of the agent's leg
    hold: bool = False
    resume: bool = False
    warm_transfer: bool = False
    blind_transfer: bool = False
    conference: bool = False
    end: bool = False
    outbound_dial: bool = False
    recording: bool = False
    recording_pause: bool = False
    secure_payment: bool = False
    monitoring_listen: bool = False
    monitoring_coach: bool = False
    monitoring_barge: bool = False
    device_registration: bool = False
    state_query: bool = False
    warm_transfer_failure_behaviour: Literal["return_to_original", "drop_call", "not_applicable"] = "not_applicable"
    notes: list[str] = Field(default_factory=list)


class ControlResult(BaseModel):
    """Outcome of *sending* a request; never proof that the remote state changed."""

    outcome: Literal["accepted", "rejected", "unknown"]
    provider_request_id: str | None = None
    provider_call_id: str | None = None
    provider_leg_id: str | None = None
    error_code: str | None = None
    error_message: str | None = None
    data: dict[str, Any] = Field(default_factory=dict)


class ProviderLegState(BaseModel):
    provider_leg_id: str
    leg_type: str
    identity: str | None = None
    number: str | None = None
    status: str
    on_hold: bool = False
    muted: bool = False


class ProviderCallState(BaseModel):
    provider_call_id: str
    status: str  # initiated | in_progress | completed | failed
    legs: list[ProviderLegState] = Field(default_factory=list)
    recording_status: str | None = None
    end_reason: str | None = None
    sequence: int = 0


class NormalizedEvent(BaseModel):
    provider_event_id: str
    type: str
    occurred_at: datetime
    provider_call_id: str | None = None
    provider_leg_id: str | None = None
    sequence: int | None = None
    request_id: str | None = None
    data: dict[str, Any] = Field(default_factory=dict)


class MediaCredential(BaseModel):
    provider: str
    token: str
    identity: str
    expires_at: datetime
    media_available: bool
    endpoint: str | None = None
    notes: str = ""


@runtime_checkable
class TelephonyProvider(Protocol):
    name: str

    def capabilities(self) -> ProviderCapabilities: ...

    def health(self) -> bool: ...

    def issue_media_credential(self, identity: str, ttl_seconds: int = 600) -> MediaCredential: ...

    def connect_agent(self, provider_call_id: str, agent_identity: str, *, request_id: str) -> ControlResult: ...

    def answer_leg(self, provider_call_id: str, provider_leg_id: str, *, request_id: str) -> ControlResult: ...

    def reject_leg(self, provider_call_id: str, provider_leg_id: str, *, request_id: str) -> ControlResult: ...

    def hold(self, provider_call_id: str, provider_leg_id: str, *, request_id: str) -> ControlResult: ...

    def resume(self, provider_call_id: str, provider_leg_id: str, *, request_id: str) -> ControlResult: ...

    def mute(self, provider_call_id: str, provider_leg_id: str, muted: bool, *, request_id: str) -> ControlResult: ...

    def start_consult(self, provider_call_id: str, target_identity: str, *, request_id: str) -> ControlResult: ...

    def complete_transfer(self, provider_call_id: str, consult_leg_id: str, *, request_id: str) -> ControlResult: ...

    def cancel_consult(self, provider_call_id: str, consult_leg_id: str, *, request_id: str) -> ControlResult: ...

    def blind_transfer(self, provider_call_id: str, agent_leg_id: str, *, request_id: str) -> ControlResult: ...

    def conference(self, provider_call_id: str, consult_leg_id: str, *, request_id: str) -> ControlResult: ...

    def hangup(self, provider_call_id: str, *, request_id: str) -> ControlResult: ...

    def dial(self, from_number: str, to_number: str, agent_identity: str, *, request_id: str) -> ControlResult: ...

    def play_notice(self, provider_call_id: str, text: str, *, request_id: str) -> ControlResult: ...

    def start_recording(self, provider_call_id: str, *, request_id: str) -> ControlResult: ...

    def pause_recording(self, provider_call_id: str, *, request_id: str) -> ControlResult: ...

    def resume_recording(self, provider_call_id: str, *, request_id: str) -> ControlResult: ...

    def start_secure_payment(self, provider_call_id: str, amount_minor: int, currency: str, *,
                             request_id: str) -> ControlResult: ...

    def start_monitoring(self, provider_call_id: str, supervisor_identity: str, mode: str, *,
                         request_id: str) -> ControlResult: ...

    def stop_monitoring(self, provider_call_id: str, provider_leg_id: str, *, request_id: str) -> ControlResult: ...

    def get_call_state(self, provider_call_id: str) -> ProviderCallState | None: ...

    def list_active_calls(self) -> list[ProviderCallState]: ...

    def fetch_recording(self, provider_recording_id: str) -> tuple[bytes, str]: ...

    def verify_webhook(self, headers: dict[str, str], body: bytes, url: str) -> bool: ...

    def parse_events(self, body: bytes, headers: dict[str, str]) -> list[NormalizedEvent]: ...


class NoProvider:
    """Used when telephony is not configured: every control is disabled."""

    name = "none"

    def capabilities(self) -> ProviderCapabilities:
        return ProviderCapabilities(provider="none", media="pstn_only",
                                    notes=["No telephony provider configured; voice controls disabled."])

    def health(self) -> bool:
        return False

    def __getattr__(self, item: str):  # pragma: no cover - defensive
        def _unsupported(*_a: Any, **_k: Any) -> ControlResult:
            return ControlResult(outcome="rejected", error_code="NO_PROVIDER",
                                 error_message="No telephony provider configured")

        return _unsupported
