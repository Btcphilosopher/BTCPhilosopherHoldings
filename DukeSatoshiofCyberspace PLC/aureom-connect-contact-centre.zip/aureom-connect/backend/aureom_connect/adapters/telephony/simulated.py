"""Adapter for the bundled telephony simulator (signalling only, no audio)."""
from __future__ import annotations

import json
import time
from datetime import datetime, timedelta, timezone
from typing import Any

import httpx
import jwt

from ...security.crypto import constant_time_equals, hmac_sha256_hex
from .base import (ControlResult, MediaCredential, NormalizedEvent, ProviderCallState, ProviderCapabilities,
                   ProviderLegState)


class SimulatedTelephonyAdapter:
    name = "simulated"

    def __init__(self, *, base_url: str, api_key: str, webhook_secret: str, public_url: str | None = None,
                 tolerance_seconds: int = 300, client: httpx.Client | None = None, timeout: float = 3.0):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.webhook_secret = webhook_secret
        self.public_url = public_url or base_url
        self.tolerance = tolerance_seconds
        self.client = client or httpx.Client(base_url=self.base_url, timeout=timeout)
        self.client.headers["X-Sim-Api-Key"] = api_key

    # ------------------------------------------------------------------ capabilities
    def capabilities(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            provider=self.name, media="none_simulated", answer=True, reject=True, mute=True, hold=True, resume=True,
            warm_transfer=True, blind_transfer=True, conference=True, end=True, outbound_dial=True, recording=True,
            recording_pause=True, secure_payment=True, monitoring_listen=True, monitoring_coach=True,
            monitoring_barge=False, device_registration=True, state_query=True,
            warm_transfer_failure_behaviour="return_to_original",
            notes=["Simulated provider: call signalling and events only. No audio is transmitted.",
                   "Recording media is a synthetic tone, flagged as synthetic.",
                   "Barge-in is not offered by the simulator and is therefore disabled."],
        )

    # ------------------------------------------------------------------ transport
    def _post(self, path: str, body: dict[str, Any]) -> ControlResult:
        try:
            r = self.client.post(path, json=body)
        except httpx.TimeoutException:
            return ControlResult(outcome="unknown", provider_request_id=body.get("request_id"),
                                 error_code="TIMEOUT", error_message="No response from provider; outcome unknown")
        except httpx.TransportError as exc:
            return ControlResult(outcome="rejected", provider_request_id=body.get("request_id"),
                                 error_code="PROVIDER_UNREACHABLE", error_message=type(exc).__name__)
        data: dict[str, Any] = {}
        try:
            data = r.json()
        except ValueError:
            pass
        if 200 <= r.status_code < 300:
            return ControlResult(outcome="accepted", provider_request_id=body.get("request_id"), data=data,
                                 provider_call_id=data.get("call_id"), provider_leg_id=data.get("leg_id"))
        if r.status_code in (502, 504):
            return ControlResult(outcome="unknown", provider_request_id=body.get("request_id"),
                                 error_code="GATEWAY_TIMEOUT", error_message="Response lost; outcome unknown")
        if r.status_code == 503:
            return ControlResult(outcome="rejected", provider_request_id=body.get("request_id"),
                                 error_code="PROVIDER_UNAVAILABLE", error_message="Provider refused the request")
        return ControlResult(outcome="rejected", provider_request_id=body.get("request_id"),
                             error_code=str(data.get("error", f"HTTP_{r.status_code}")).upper(),
                             error_message=json.dumps(data)[:300])

    def _get(self, path: str) -> dict[str, Any] | None:
        try:
            r = self.client.get(path)
        except httpx.HTTPError:
            return None
        if r.status_code != 200:
            return None
        return r.json()

    def health(self) -> bool:
        try:
            return self.client.get("/v1/health").status_code == 200
        except httpx.HTTPError:
            return False

    # ------------------------------------------------------------------ media credentials
    def issue_media_credential(self, identity: str, ttl_seconds: int = 600) -> MediaCredential:
        exp = datetime.now(timezone.utc) + timedelta(seconds=ttl_seconds)
        token = jwt.encode({"sub": identity, "aud": "aureom-sim", "iss": "aureom-connect", "exp": exp,
                            "iat": datetime.now(timezone.utc)}, self.api_key, algorithm="HS256")
        return MediaCredential(provider=self.name, token=token, identity=identity, expires_at=exp,
                               media_available=False, endpoint=self.public_url,
                               notes="Simulated device registration only. No audio path exists.")

    # ------------------------------------------------------------------ controls
    def connect_agent(self, provider_call_id, agent_identity, *, request_id):
        return self._post(f"/v1/calls/{provider_call_id}/connect", {"identity": agent_identity, "request_id": request_id})

    def answer_leg(self, provider_call_id, provider_leg_id, *, request_id):
        return self._post(f"/v1/calls/{provider_call_id}/legs/{provider_leg_id}/answer", {"request_id": request_id})

    def reject_leg(self, provider_call_id, provider_leg_id, *, request_id):
        return self._post(f"/v1/calls/{provider_call_id}/legs/{provider_leg_id}/reject", {"request_id": request_id})

    def hold(self, provider_call_id, provider_leg_id, *, request_id):
        return self._post(f"/v1/calls/{provider_call_id}/legs/{provider_leg_id}/hold", {"request_id": request_id})

    def resume(self, provider_call_id, provider_leg_id, *, request_id):
        return self._post(f"/v1/calls/{provider_call_id}/legs/{provider_leg_id}/resume", {"request_id": request_id})

    def mute(self, provider_call_id, provider_leg_id, muted, *, request_id):
        op = "mute" if muted else "unmute"
        return self._post(f"/v1/calls/{provider_call_id}/legs/{provider_leg_id}/{op}", {"request_id": request_id})

    def start_consult(self, provider_call_id, target_identity, *, request_id):
        return self._post(f"/v1/calls/{provider_call_id}/consult", {"identity": target_identity, "request_id": request_id})

    def complete_transfer(self, provider_call_id, consult_leg_id, *, request_id):
        return self._post(f"/v1/calls/{provider_call_id}/legs/{consult_leg_id}/complete-transfer",
                          {"request_id": request_id})

    def cancel_consult(self, provider_call_id, consult_leg_id, *, request_id):
        return self._post(f"/v1/calls/{provider_call_id}/legs/{consult_leg_id}/cancel-consult", {"request_id": request_id})

    def blind_transfer(self, provider_call_id, agent_leg_id, *, request_id):
        return self._post(f"/v1/calls/{provider_call_id}/legs/{agent_leg_id}/blind-transfer", {"request_id": request_id})

    def conference(self, provider_call_id, consult_leg_id, *, request_id):
        return self._post(f"/v1/calls/{provider_call_id}/legs/{consult_leg_id}/conference", {"request_id": request_id})

    def hangup(self, provider_call_id, *, request_id):
        return self._post(f"/v1/calls/{provider_call_id}/hangup", {"request_id": request_id})

    def dial(self, from_number, to_number, agent_identity, *, request_id):
        return self._post("/v1/calls/outbound", {"from_number": from_number, "to_number": to_number,
                                                 "identity": agent_identity, "request_id": request_id})

    def play_notice(self, provider_call_id, text, *, request_id):
        return self._post(f"/v1/calls/{provider_call_id}/notice", {"text": text, "request_id": request_id})

    def start_recording(self, provider_call_id, *, request_id):
        return self._post(f"/v1/calls/{provider_call_id}/recording/start", {"request_id": request_id})

    def pause_recording(self, provider_call_id, *, request_id):
        return self._post(f"/v1/calls/{provider_call_id}/recording/pause", {"request_id": request_id})

    def resume_recording(self, provider_call_id, *, request_id):
        return self._post(f"/v1/calls/{provider_call_id}/recording/resume", {"request_id": request_id})

    def start_secure_payment(self, provider_call_id, amount_minor, currency, *, request_id):
        return self._post(f"/v1/calls/{provider_call_id}/payments",
                          {"amount_minor": amount_minor, "currency": currency, "request_id": request_id})

    def start_monitoring(self, provider_call_id, supervisor_identity, mode, *, request_id):
        return self._post(f"/v1/calls/{provider_call_id}/monitor",
                          {"identity": supervisor_identity, "mode": mode, "request_id": request_id})

    def stop_monitoring(self, provider_call_id, provider_leg_id, *, request_id):
        return self._post(f"/v1/calls/{provider_call_id}/legs/{provider_leg_id}/monitor-stop", {"request_id": request_id})

    # ------------------------------------------------------------------ queries
    @staticmethod
    def _state(d: dict[str, Any]) -> ProviderCallState:
        return ProviderCallState(provider_call_id=d["provider_call_id"], status=d["status"], sequence=d.get("sequence", 0),
                                 end_reason=d.get("end_reason"), recording_status=d.get("recording_status"),
                                 legs=[ProviderLegState(**lg) for lg in d.get("legs", [])])

    def get_call_state(self, provider_call_id: str) -> ProviderCallState | None:
        d = self._get(f"/v1/calls/{provider_call_id}")
        return self._state(d) if d else None

    def list_active_calls(self) -> list[ProviderCallState]:
        d = self._get("/v1/calls")
        if d is None:
            raise ConnectionError("provider state query failed")
        return [self._state(c) for c in d.get("calls", [])]

    def fetch_recording(self, provider_recording_id: str) -> tuple[bytes, str]:
        r = self.client.get(f"/v1/recordings/{provider_recording_id}/media")
        r.raise_for_status()
        return r.content, r.headers.get("content-type", "audio/wav")

    # ------------------------------------------------------------------ webhooks
    def verify_webhook(self, headers: dict[str, str], body: bytes, url: str) -> bool:
        h = {k.lower(): v for k, v in headers.items()}
        ts, sig = h.get("x-sim-timestamp"), h.get("x-sim-signature")
        if not ts or not sig:
            return False
        try:
            age = abs(time.time() - int(ts))
        except ValueError:
            return False
        if age > self.tolerance:
            return False
        expected = "v1=" + hmac_sha256_hex(self.webhook_secret, ts.encode() + b"." + body)
        return constant_time_equals(expected, sig)

    def parse_events(self, body: bytes, headers: dict[str, str]) -> list[NormalizedEvent]:
        payload = json.loads(body)
        out = []
        for ev in payload.get("events", []):
            out.append(NormalizedEvent(provider_event_id=ev["id"], type=ev["type"],
                                       occurred_at=datetime.fromisoformat(ev["occurred_at"]),
                                       provider_call_id=ev.get("call_id"), provider_leg_id=ev.get("leg_id"),
                                       sequence=ev.get("sequence"), request_id=ev.get("request_id"),
                                       data=ev.get("data") or {}))
        return out
