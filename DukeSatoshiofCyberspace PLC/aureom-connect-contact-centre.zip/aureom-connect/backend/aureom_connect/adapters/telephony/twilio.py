"""Twilio Programmable Voice adapter – PARTIAL, externally integrated, not live-tested.

Implemented against Twilio's public documentation (see docs/telephony-adapters.md
for the pages consulted and their verification status):

* webhook validation – ``X-Twilio-Signature`` = Base64(HMAC-SHA1(auth token,
  full URL + each POST parameter name+value sorted by name)); for JSON bodies
  the URL carries ``bodySHA256`` (hex SHA-256 of the raw body);
* Voice SDK access tokens – HS256 JWT with ``cty: twilio-fpa;v=1``, ``iss`` =
  API key SID, ``sub`` = account SID, ``grants.identity`` and
  ``grants.voice.{incoming,outgoing}``; identities limited to letters, digits
  and underscores;
* call status callbacks → normalised events (``SequenceNumber`` is optional);
* hang-up (``Status=completed``) and call state queries via the REST API.

Deliberately **not** implemented (capabilities are False, so controls are
disabled rather than simulated): agent connection, hold/mute/transfer/conference
(these require a conference-based call architecture with TwiML endpoints),
recording control, secure payments and monitoring. Do not enable Twilio for
routing until those are built and tested against a real account.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import re
import time
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from typing import Any
from urllib.parse import parse_qsl, urlparse, parse_qs

import httpx
import jwt

from .base import (ControlResult, MediaCredential, NormalizedEvent, ProviderCallState, ProviderCapabilities,
                   ProviderLegState)

API = "https://api.twilio.com/2010-04-01"
STATUS_MAP = {"queued": "initiated", "initiated": "initiated", "ringing": "ringing", "in-progress": "in_progress",
              "completed": "completed", "busy": "completed", "failed": "failed", "no-answer": "completed",
              "canceled": "completed"}


def sanitise_identity(identity: str) -> str:
    return re.sub(r"[^A-Za-z0-9_]", "_", identity)[:121]


def twilio_signature(auth_token: str, url: str, params: dict[str, str]) -> str:
    data = url + "".join(f"{k}{params[k]}" for k in sorted(params))
    return base64.b64encode(hmac.new(auth_token.encode(), data.encode(), hashlib.sha1).digest()).decode()


class TwilioAdapter:
    name = "twilio"

    def __init__(self, *, account_sid: str, api_key_sid: str, api_key_secret: str, auth_token: str,
                 twiml_app_sid: str | None, client: httpx.Client | None = None):
        self.account_sid = account_sid
        self.api_key_sid = api_key_sid
        self.api_key_secret = api_key_secret
        self.auth_token = auth_token
        self.twiml_app_sid = twiml_app_sid
        self.client = client or httpx.Client(timeout=5.0, auth=(api_key_sid, api_key_secret))

    @classmethod
    def from_settings(cls, s) -> "TwilioAdapter":
        missing = [n for n in ("twilio_account_sid", "twilio_api_key_sid", "twilio_api_key_secret", "twilio_auth_token")
                   if not getattr(s, n)]
        if missing:
            raise RuntimeError(f"Twilio provider selected but not configured: {missing}")
        return cls(account_sid=s.twilio_account_sid, api_key_sid=s.twilio_api_key_sid,
                   api_key_secret=s.twilio_api_key_secret, auth_token=s.twilio_auth_token,
                   twiml_app_sid=s.twilio_twiml_app_sid)

    def capabilities(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            provider=self.name, media="webrtc", end=True, state_query=True,
            notes=["Partial adapter: hang-up, state query, webhook validation and access tokens only.",
                   "Hold, mute, transfers and conferencing need a conference-based architecture (deferred).",
                   "Not exercised against a live Twilio account in this delivery."])

    def health(self) -> bool:
        try:
            r = self.client.get(f"{API}/Accounts/{self.account_sid}.json")
            return r.status_code == 200
        except httpx.HTTPError:
            return False

    def issue_media_credential(self, identity: str, ttl_seconds: int = 600) -> MediaCredential:
        ttl = min(ttl_seconds, 86400)
        now = int(time.time())
        ident = sanitise_identity(identity)
        grants: dict[str, Any] = {"identity": ident, "voice": {"incoming": {"allow": True}}}
        if self.twiml_app_sid:
            grants["voice"]["outgoing"] = {"application_sid": self.twiml_app_sid}
        token = jwt.encode({"jti": f"{self.api_key_sid}-{now}", "iss": self.api_key_sid, "sub": self.account_sid,
                            "iat": now, "nbf": now, "exp": now + ttl, "grants": grants}, self.api_key_secret,
                           algorithm="HS256", headers={"cty": "twilio-fpa;v=1", "typ": "JWT"})
        return MediaCredential(provider=self.name, token=token, identity=ident,
                               expires_at=datetime.fromtimestamp(now + ttl, tz=timezone.utc), media_available=True,
                               notes="For the Twilio Voice JavaScript SDK (browser integration deferred).")

    def _unsupported(self, *_a: Any, **kw: Any) -> ControlResult:
        return ControlResult(outcome="rejected", provider_request_id=kw.get("request_id"),
                             error_code="NOT_SUPPORTED_BY_ADAPTER",
                             error_message="Not implemented in the Twilio adapter; control is disabled.")

    connect_agent = answer_leg = reject_leg = hold = resume = mute = start_consult = _unsupported
    complete_transfer = cancel_consult = blind_transfer = conference = dial = play_notice = _unsupported
    start_recording = pause_recording = resume_recording = start_secure_payment = _unsupported
    start_monitoring = stop_monitoring = _unsupported

    def hangup(self, provider_call_id: str, *, request_id: str) -> ControlResult:
        try:
            r = self.client.post(f"{API}/Accounts/{self.account_sid}/Calls/{provider_call_id}.json",
                                 data={"Status": "completed"})
        except httpx.TimeoutException:
            return ControlResult(outcome="unknown", provider_request_id=request_id, error_code="TIMEOUT")
        except httpx.TransportError as exc:
            return ControlResult(outcome="rejected", provider_request_id=request_id,
                                 error_code="PROVIDER_UNREACHABLE", error_message=type(exc).__name__)
        if r.status_code < 300:
            return ControlResult(outcome="accepted", provider_request_id=request_id, provider_call_id=provider_call_id)
        if r.status_code >= 500:
            return ControlResult(outcome="unknown", provider_request_id=request_id, error_code=f"HTTP_{r.status_code}")
        return ControlResult(outcome="rejected", provider_request_id=request_id, error_code=f"HTTP_{r.status_code}",
                             error_message=r.text[:300])

    def get_call_state(self, provider_call_id: str) -> ProviderCallState | None:
        try:
            r = self.client.get(f"{API}/Accounts/{self.account_sid}/Calls/{provider_call_id}.json")
        except httpx.HTTPError:
            return None
        if r.status_code != 200:
            return None
        d = r.json()
        st = STATUS_MAP.get(d.get("status", ""), "in_progress")
        return ProviderCallState(provider_call_id=provider_call_id, status=st, end_reason=d.get("status"),
                                 legs=[ProviderLegState(provider_leg_id=provider_call_id, leg_type="customer",
                                                        number=d.get("from"), status=d.get("status", ""))])

    def list_active_calls(self) -> list[ProviderCallState]:
        r = self.client.get(f"{API}/Accounts/{self.account_sid}/Calls.json", params={"Status": "in-progress"})
        if r.status_code != 200:
            raise ConnectionError("Twilio call list failed")
        return [ProviderCallState(provider_call_id=c["sid"], status="in_progress") for c in r.json().get("calls", [])]

    def fetch_recording(self, provider_recording_id: str) -> tuple[bytes, str]:  # pragma: no cover
        raise NotImplementedError("Recording retrieval is not implemented in the Twilio adapter")

    def verify_webhook(self, headers: dict[str, str], body: bytes, url: str) -> bool:
        h = {k.lower(): v for k, v in headers.items()}
        sig = h.get("x-twilio-signature")
        if not sig:
            return False
        ctype = h.get("content-type", "")
        if ctype.startswith("application/json"):
            q = parse_qs(urlparse(url).query)
            expected_hash = (q.get("bodySHA256") or [""])[0]
            if not hmac.compare_digest(expected_hash, hashlib.sha256(body).hexdigest()):
                return False
            params: dict[str, str] = {}
        else:
            params = dict(parse_qsl(body.decode(), keep_blank_values=True))
        return hmac.compare_digest(twilio_signature(self.auth_token, url, params), sig)

    def parse_events(self, body: bytes, headers: dict[str, str]) -> list[NormalizedEvent]:
        params = dict(parse_qsl(body.decode(), keep_blank_values=True))
        status = params.get("CallStatus", "")
        sid = params.get("CallSid")
        seq = params.get("SequenceNumber")
        try:
            occurred = parsedate_to_datetime(params["Timestamp"]) if params.get("Timestamp") else datetime.now(timezone.utc)
        except (TypeError, ValueError):
            occurred = datetime.now(timezone.utc)
        if status in ("queued", "initiated"):
            typ = "call.initiated"
        elif status == "ringing":
            typ = "leg.ringing"
        elif status == "in-progress":
            typ = "leg.answered"
        else:
            typ = "call.completed"
        data = {"from_number": params.get("From"), "to_number": params.get("To"),
                "direction": "inbound" if params.get("Direction", "").startswith("inbound") else "outbound",
                "leg_type": "customer", "end_reason": status.replace("-", "_"),
                "customer_leg_id": sid}
        return [NormalizedEvent(provider_event_id=f"{sid}:{status}:{seq or params.get('Timestamp', '')}", type=typ,
                                occurred_at=occurred, provider_call_id=sid, provider_leg_id=sid,
                                sequence=int(seq) + 1 if seq and seq.isdigit() else None, data=data)]
