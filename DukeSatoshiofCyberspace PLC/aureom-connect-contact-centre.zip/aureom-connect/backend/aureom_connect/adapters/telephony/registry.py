"""Process-wide telephony provider selection (explicit configuration only)."""
from __future__ import annotations

from ...config import get_settings
from .base import NoProvider, TelephonyProvider

_provider: TelephonyProvider | None = None


def get_provider() -> TelephonyProvider:
    global _provider
    if _provider is None:
        s = get_settings()
        if s.telephony_provider == "simulated":
            from .simulated import SimulatedTelephonyAdapter

            _provider = SimulatedTelephonyAdapter(base_url=s.simulator_url, api_key=s.simulator_api_key,
                                                  webhook_secret=s.simulator_webhook_secret,
                                                  public_url=s.simulator_public_url,
                                                  tolerance_seconds=s.provider_event_tolerance_seconds)
        elif s.telephony_provider == "twilio":
            from .twilio import TwilioAdapter

            _provider = TwilioAdapter.from_settings(s)
        else:
            _provider = NoProvider()
    return _provider


def set_provider(provider: TelephonyProvider | None) -> None:
    """Testing hook."""
    global _provider
    _provider = provider
