"""Channel adapters: voice, e-mail and web chat each have their own adapter.

* Voice     – delegates to the telephony provider adapter (no message bodies).
* E-mail    – inbound via a signed webhook (or the demo endpoint); outbound via
              SMTP when configured (Mailpit in Docker Compose), otherwise the
              message is stored as *captured, not sent* and labelled as such.
* Web chat  – customer messages arrive through the public chat endpoints with a
              session token; agent messages are stored and polled/streamed.
"""
from __future__ import annotations

import smtplib
import uuid
from email.message import EmailMessage
from typing import Protocol

from sqlalchemy.orm import Session

from ...config import get_settings
from ...models import ChatMessage, Interaction


class ChannelAdapter(Protocol):
    name: str

    def deliver_agent_message(self, db: Session, it: Interaction, msg: ChatMessage) -> str: ...


class VoiceChannel:
    name = "voice"

    def deliver_agent_message(self, db, it, msg) -> str:  # pragma: no cover - not applicable
        raise ValueError("Voice interactions do not carry text messages")


def send_email(to: str, subject: str, body: str) -> tuple[str, str]:
    """Returns (status, message_id). status is 'sent' (SMTP accepted) or 'captured' (no SMTP configured)."""
    s = get_settings()
    mid = f"<{uuid.uuid4().hex}@aureom-connect>"
    if not s.smtp_host:
        return "captured", mid
    m = EmailMessage()
    m["From"], m["To"], m["Subject"], m["Message-ID"] = s.smtp_from, to, subject, mid
    m.set_content(body)
    with smtplib.SMTP(s.smtp_host, s.smtp_port, timeout=10) as smtp:
        smtp.send_message(m)
    return "sent", mid


class EmailChannel:
    name = "email"

    def deliver_agent_message(self, db, it, msg) -> str:
        to = (it.match_hint or {}).get("from_address")
        if not to:
            raise ValueError("No reply address for this e-mail interaction")
        status, mid = send_email(to, f"Re: {it.subject or 'Your enquiry'} [{it.reference}]", msg.body)
        msg.channel_message_id = mid
        return status


class ChatChannel:
    name = "chat"

    def deliver_agent_message(self, db, it, msg) -> str:
        # Delivery is the stored message; the customer's chat client polls the session endpoint.
        return "stored"


_CHANNELS = {"voice": VoiceChannel(), "email": EmailChannel(), "chat": ChatChannel()}


def channel_for(name: str) -> ChannelAdapter:
    return _CHANNELS[name]
