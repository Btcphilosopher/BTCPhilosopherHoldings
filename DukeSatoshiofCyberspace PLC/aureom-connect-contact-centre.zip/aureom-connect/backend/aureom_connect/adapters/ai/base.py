"""AI assistance contract.

Every AI capability returns a *proposal*:

    {"output": {...}, "sources": [...], "uncertainty": {"confidence": 0..1, "notes": [...]},
     "safety_flags": [...], "provider": str, "model": str}

Rules enforced by the application (not by the model):
* the assistant has **no tools** and cannot call any endpoint;
* customer messages, transcripts and retrieved articles are passed as
  *untrusted data* and scanned for instruction-like content;
* proposals are never saved as authoritative records or sent to customers
  without an agent's explicit review;
* the assistant may not authorise refunds, change contracts, disclose
  restricted data or make consequential decisions – such suggestions are
  stripped and flagged.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Protocol

INJECTION_PATTERNS = [
    r"ignore (all|any|the|previous|prior) (instructions|rules)", r"disregard (the|your|all) (instructions|policy)",
    r"system prompt", r"you are now", r"act as (an?|the) (admin|administrator|supervisor)",
    r"(issue|approve|authori[sz]e|process) (a |the )?refund", r"transfer (money|funds|£|\$)",
    r"reveal (the|your|all)", r"(change|cancel|terminate) (my|the) contract", r"developer mode",
    r"<\s*/?\s*(system|instructions?)\s*>",
]
CONSEQUENTIAL_PATTERNS = [r"\brefund\b", r"\bwrite[- ]off\b", r"\bcompensation\b", r"\bcontract (change|variation)\b",
                          r"\bwaive\b", r"\bcredit (the|their) account\b"]
ALLOWED_CATEGORIES = ["billing", "billing_dispute", "technical", "complaint", "accounts", "general"]


@dataclass
class AiContext:
    interaction_ref: str
    channel: str
    queue: str | None
    subject: str | None
    transcript: list[dict[str, Any]] = field(default_factory=list)  # [{"i","speaker","text"}] UNTRUSTED
    messages: list[dict[str, Any]] = field(default_factory=list)  # chat/email bodies UNTRUSTED
    timeline: list[dict[str, Any]] = field(default_factory=list)  # system facts (trusted)
    notes: str = ""  # agent's own notes (trusted author, but free text)
    verification_status: str | None = None
    articles: list[dict[str, Any]] = field(default_factory=list)  # retrieved knowledge UNTRUSTED for instructions


def scan_untrusted(texts: list[str]) -> list[str]:
    flags: list[str] = []
    joined = "\n".join(t for t in texts if t).lower()
    if any(re.search(p, joined) for p in INJECTION_PATTERNS):
        flags.append("untrusted_input_contains_instruction_like_text")
    return flags


def strip_consequential(text: str) -> tuple[str, bool]:
    """Remove sentences that would commit the organisation to a consequential decision."""
    sentences = re.split(r"(?<=[.!?])\s+", text)
    kept = [s for s in sentences if not any(re.search(p, s.lower()) for p in CONSEQUENTIAL_PATTERNS)]
    return " ".join(kept).strip(), len(kept) != len(sentences)


class AiAssistant(Protocol):
    provider: str
    model: str

    def summarise(self, ctx: AiContext) -> dict[str, Any]: ...

    def classify(self, ctx: AiContext) -> dict[str, Any]: ...

    def draft_message(self, ctx: AiContext, template: dict[str, Any]) -> dict[str, Any]: ...

    def article_query(self, ctx: AiContext) -> str: ...
