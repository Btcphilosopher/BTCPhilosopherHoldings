"""Transparent, deterministic baseline assistant – NOT a language model.

Used by default in the demo and tests so that behaviour is reproducible and
explainable. Every output lists the rules and source segments it used.
"""
from __future__ import annotations

import re
from collections import Counter
from typing import Any

from .base import ALLOWED_CATEGORIES, AiContext

STOP = set("""a an the and or but if then so to of in on at for from with by is are was were be been it this that
these those i you he she we they me my your our their there here not no yes do does did have has had can could would
should will just about please thank thanks hello hi okay ok um uh yeah well also""".split())

CATEGORY_RULES = {
    "billing_dispute": ["dispute", "disputed", "estimated", "wrong reading", "overcharged", "too high"],
    "billing": ["bill", "payment", "pay", "arrears", "balance", "direct debit", "instalment", "owe"],
    "technical": ["leak", "pressure", "no water", "supply", "burst", "meter fault", "discoloured", "sewer"],
    "complaint": ["complaint", "complain", "unhappy", "missed appointment", "ombudsman", "unacceptable"],
    "accounts": ["moving", "move home", "name change", "close account", "new address", "tenant"],
}


def _keywords(texts: list[str], n: int = 6) -> list[str]:
    words = re.findall(r"[a-z][a-z'-]{2,}", " ".join(texts).lower())
    counts = Counter(w for w in words if w not in STOP)
    return [w for w, _ in counts.most_common(n)]


class HeuristicAssistant:
    provider = "heuristic"
    model = "aureom-rules-1.0 (not a language model)"

    def article_query(self, ctx: AiContext) -> str:
        customer = [s["text"] for s in ctx.transcript if s.get("speaker") == "customer"]
        customer += [m["body"] for m in ctx.messages if m.get("sender") == "customer"]
        terms = _keywords(customer + [ctx.subject or "", ctx.notes], 5)
        if not terms and ctx.queue:
            # No customer text yet (live call, transcript arrives after the call): fall back to the queue topic.
            terms = _keywords([ctx.queue], 3)
        return " ".join(terms)

    def summarise(self, ctx: AiContext) -> dict[str, Any]:
        sources: list[dict[str, Any]] = []
        lines: list[str] = []
        reason = ctx.subject or (f"call to {ctx.queue}" if ctx.queue else "enquiry")
        cust = [s for s in ctx.transcript if s.get("speaker") == "customer"]
        cust += [{"i": f"m{k}", "text": m["body"]} for k, m in enumerate(ctx.messages) if m.get("sender") == "customer"]
        if cust:
            first = cust[0]
            lines.append(f"Customer contacted {ctx.queue or 'us'} about: \"{first['text'][:160]}\"")
            sources.append({"type": "transcript_segment" if isinstance(first["i"], int) else "message",
                            "ref": first["i"], "note": "first customer statement (unverified machine output)"})
        else:
            lines.append(f"Contact via {ctx.channel} ({reason}).")
        facts = {e["type"]: e for e in ctx.timeline}
        if ctx.verification_status:
            lines.append(f"Identity verification status: {ctx.verification_status}.")
            sources.append({"type": "system_fact", "ref": "verification"})
        if "transfer.completed" in facts:
            lines.append("The call was transferred to a colleague within the same interaction.")
            sources.append({"type": "timeline", "ref": "transfer.completed"})
        if "transfer.failed" in facts:
            lines.append("A transfer was attempted but did not connect; the original agent kept the call.")
            sources.append({"type": "timeline", "ref": "transfer.failed"})
        if "payment.completed" in facts:
            lines.append("A payment was taken through the secure payment service (no card details recorded).")
            sources.append({"type": "timeline", "ref": "payment.completed"})
        agent_lines = [s for s in ctx.transcript if s.get("speaker") == "agent"]
        if agent_lines:
            last = agent_lines[-1]
            lines.append(f"Agent's closing statement: \"{last['text'][:160]}\"")
            sources.append({"type": "transcript_segment", "ref": last["i"]})
        if ctx.articles:
            lines.append("Knowledge consulted: " + ", ".join(a["title"] for a in ctx.articles[:3]) + ".")
            sources += [{"type": "knowledge_article", "ref": a["slug"], "version": a.get("version")}
                        for a in ctx.articles[:3]]
        if ctx.notes:
            lines.append(f"Agent notes: {ctx.notes[:300]}")
        confidence = 0.35 + 0.1 * min(4, len(sources))
        return {"output": {"summary": " ".join(lines),
                           "key_points": [s["text"][:140] for s in cust[:3]],
                           "follow_up_suggested": any(k in " ".join(s["text"] for s in cust).lower()
                                                      for k in ("call me back", "follow up", "let me know", "send me"))},
                "sources": sources,
                "uncertainty": {"confidence": round(min(confidence, 0.8), 2), "notes": [
                    "Rule-based extract, not a language model.",
                    "Quoted statements come from a machine transcript and are not verified facts.",
                    "Review and correct before saving."]}}

    def classify(self, ctx: AiContext) -> dict[str, Any]:
        text = " ".join([s["text"] for s in ctx.transcript] + [m["body"] for m in ctx.messages] +
                        [ctx.subject or "", ctx.notes]).lower()
        scores = {cat: [kw for kw in kws if kw in text] for cat, kws in CATEGORY_RULES.items()}
        ranked = sorted(scores.items(), key=lambda kv: -len(kv[1]))
        best, hits = ranked[0]
        total = sum(len(v) for v in scores.values())
        if not hits:
            best, conf = "general", 0.2
        else:
            conf = round(len(hits) / max(total, 1) * 0.8, 2)
        assert best in ALLOWED_CATEGORIES
        priority = "high" if scores["complaint"] or "no water" in text else "normal"
        return {"output": {"category": best, "priority": priority,
                           "rationale": f"Matched keywords: {', '.join(hits) or 'none'}",
                           "alternatives": [{"category": c, "matched": k} for c, k in ranked[1:3] if k]},
                "sources": [{"type": "keyword_rule", "ref": best, "matched": hits}],
                "uncertainty": {"confidence": conf, "notes": ["Keyword rules; ambiguous contacts score low.",
                                                              "The agent chooses the final classification."]}}

    def draft_message(self, ctx: AiContext, template: dict[str, Any]) -> dict[str, Any]:
        values: dict[str, str] = {}
        sources = []
        for ph in template.get("placeholders", []):
            if ph == "reference":
                values[ph] = ctx.interaction_ref
                sources.append({"type": "system_fact", "ref": "interaction.reference"})
            elif ph == "next_steps" and ctx.articles:
                values[ph] = ctx.articles[0].get("summary", "")
                sources.append({"type": "knowledge_article", "ref": ctx.articles[0]["slug"],
                                "visibility": ctx.articles[0].get("visibility")})
            else:
                values[ph] = ""
        return {"output": {"template_code": template["code"], "placeholder_values": values},
                "sources": sources,
                "uncertainty": {"confidence": 0.5, "notes": ["Empty placeholders must be completed by the agent.",
                                                             "Only customer-visible knowledge is used."]}}
