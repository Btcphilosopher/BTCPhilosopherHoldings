"""FastAPI application factory."""
from __future__ import annotations

import logging
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .api.deps import error_body
from .config import get_settings
from .errors import AppError, RateLimited
from .security.ratelimit import limiter
from .security.redaction import install_log_redaction

log = logging.getLogger("aureom")

API_DESCRIPTION = """
**AUREOM CONNECT — Contact Centre API.**

* Every mutating call that has an external effect requires an `Idempotency-Key` header.
* Version checks use `expected_version` (409 `VERSION_CONFLICT` on mismatch).
* Errors are structured: `{"error": {"code", "message", "details", "request_id"}}`.
* Call-control responses report whether the provider *accepted the request*; the call state changes
  only when the provider confirms it (see `GET /v1/interactions/{id}` → `controls`).
* Application events stream on `WS /v1/events`; media never travels on this socket.
"""


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    settings.assert_safe_for_production()
    install_log_redaction()
    if settings.environment != "test":
        from .realtime.ws import hub

        hub.start_listener()
    yield


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(title="AUREOM CONNECT – Contact Centre API", version="1.0.0", description=API_DESCRIPTION,
                  lifespan=lifespan)
    app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins, allow_credentials=False,
                       allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
                       allow_headers=["Authorization", "Content-Type", "Idempotency-Key", "X-Request-Id"],
                       expose_headers=["X-Request-Id", "Idempotent-Replayed"])

    @app.middleware("http")
    async def request_context(request: Request, call_next):
        rid = request.headers.get("X-Request-Id") or uuid.uuid4().hex[:16]
        request.state.request_id = rid
        if not request.url.path.startswith("/v1/providers/") and request.url.path != "/healthz":
            ip = request.client.host if request.client else "unknown"
            auth = request.headers.get("authorization", "")
            key = f"api:{auth[-24:]}" if auth else f"ip:{ip}"
            try:
                limiter.check(key, settings.rate_limit_per_minute)
            except RateLimited as exc:
                resp = JSONResponse(status_code=429, content=error_body(exc, rid))
                resp.headers["X-Request-Id"] = rid
                return resp
        response = await call_next(request)
        response.headers["X-Request-Id"] = rid
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Cache-Control"] = "no-store"
        return response

    @app.exception_handler(AppError)
    async def app_error(request: Request, exc: AppError):
        return JSONResponse(status_code=exc.status_code,
                            content=error_body(exc, getattr(request.state, "request_id", None)))

    @app.exception_handler(RequestValidationError)
    async def validation_error(request: Request, exc: RequestValidationError):
        err = AppError("Request validation failed", code="VALIDATION_FAILED", status_code=422,
                       details={"errors": [{"loc": list(e.get("loc", [])), "msg": e.get("msg")} for e in exc.errors()]})
        return JSONResponse(status_code=422, content=error_body(err, getattr(request.state, "request_id", None)))

    @app.exception_handler(Exception)
    async def unhandled(request: Request, exc: Exception):
        log.exception("unhandled error")
        err = AppError("Internal error", code="INTERNAL", status_code=500)
        return JSONResponse(status_code=500, content=error_body(err, getattr(request.state, "request_id", None)))

    @app.get("/healthz", tags=["system"])
    def healthz() -> dict:
        return {"status": "ok"}

    from .api import routers

    for r in routers():
        app.include_router(r)
    return app


app = create_app()
