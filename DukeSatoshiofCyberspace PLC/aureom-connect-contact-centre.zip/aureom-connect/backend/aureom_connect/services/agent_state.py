"""Explicit agent state machine.

States: offline, available, call_offered, connecting, on_interaction,
after_call_work, break, unavailable.

* Agent-requestable states: available, break, unavailable, offline.
* System-only states: call_offered, connecting, on_interaction, after_call_work.

Becoming *available* requires (a) the application to be connected, (b) the
provider to have confirmed a device registration, (c) no pending
reconciliation and (d) no conflicting live call state for the agent.
"""
from __future__ import annotations

import uuid

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import utcnow
from ..errors import InvalidTransition, ReconciliationRequired, ValidationFailed
from ..models import Agent, AgentParticipation, AgentStateHistory, CallLeg, Offer
from ..models.enums import AgentState as S
from ..models.enums import Presence, TelephonyRegistration
from . import events

ALLOWED: dict[str, set[str]] = {
    S.OFFLINE: {S.AVAILABLE, S.BREAK, S.UNAVAILABLE},
    S.AVAILABLE: {S.CALL_OFFERED, S.CONNECTING, S.ON_INTERACTION, S.BREAK, S.UNAVAILABLE, S.OFFLINE},  # preview / chat
    S.CALL_OFFERED: {S.CONNECTING, S.ON_INTERACTION, S.AVAILABLE, S.UNAVAILABLE},  # callback/chat items go straight to work
    S.CONNECTING: {S.ON_INTERACTION, S.AVAILABLE, S.UNAVAILABLE, S.AFTER_CALL_WORK},
    S.ON_INTERACTION: {S.AFTER_CALL_WORK, S.ON_INTERACTION, S.UNAVAILABLE},
    S.AFTER_CALL_WORK: {S.AVAILABLE, S.BREAK, S.UNAVAILABLE, S.OFFLINE, S.CONNECTING, S.ON_INTERACTION},
    S.BREAK: {S.AVAILABLE, S.UNAVAILABLE, S.OFFLINE},
    S.UNAVAILABLE: {S.AVAILABLE, S.BREAK, S.OFFLINE, S.CONNECTING},
}
AGENT_REQUESTABLE = {S.AVAILABLE, S.BREAK, S.UNAVAILABLE, S.OFFLINE}
BUSY = {S.CALL_OFFERED, S.CONNECTING, S.ON_INTERACTION}


def transition(db: Session, agent: Agent, to: str, *, reason: str | None, source: str,
               actor_user_id: uuid.UUID | None = None, force: bool = False) -> None:
    frm = agent.state
    if frm == to and to != S.ON_INTERACTION:
        return
    if not force and to not in ALLOWED.get(frm, set()):
        raise InvalidTransition(f"Agent cannot move from {frm} to {to}", details={"from": frm, "to": to})
    now = utcnow()
    agent.state = to
    agent.state_reason = reason
    agent.state_since = now
    agent.state_version += 1
    if to == S.AVAILABLE:
        agent.available_since = now
        agent.missed_offer_count = 0
    db.add(AgentStateHistory(org_id=agent.org_id, agent_id=agent.id, from_state=frm, to_state=to, reason=reason,
                             source=source, actor_user_id=actor_user_id, at=now))
    events.to_agent(db, agent.org_id, agent.id, "agent.state", state=to, previous=frm, reason=reason,
                    version=agent.state_version)
    events.to_supervisors(db, agent.org_id, "agent.state", agent_id=agent.id, state=to, previous=frm, reason=reason)


def conflicting_call_state(db: Session, agent: Agent) -> list[str]:
    """Return human-readable reasons why the agent may still be on a call."""
    reasons: list[str] = []
    live_legs = db.scalars(select(CallLeg).where(CallLeg.agent_id == agent.id,
                                                 CallLeg.status.in_(["initiated", "ringing", "answered", "held"]))).all()
    if live_legs:
        reasons.append(f"{len(live_legs)} call leg(s) still live at the provider")
    open_parts = db.scalars(select(AgentParticipation).where(
        AgentParticipation.agent_id == agent.id, AgentParticipation.ended_at.is_(None),
        AgentParticipation.role.in_(["primary", "consult", "transfer_receiver", "conference"]))).all()
    if open_parts:
        reasons.append(f"{len(open_parts)} participation(s) not ended")
    pending = db.scalar(select(Offer).where(Offer.agent_id == agent.id, Offer.status == "pending"))
    if pending:
        reasons.append("an offer is pending")
    return reasons


def readiness(db: Session, agent: Agent) -> dict[str, object]:
    """Explain whether the agent could be made available right now."""
    blockers: list[str] = []
    if agent.presence != Presence.ONLINE:
        blockers.append("Agent application is not connected")
    if agent.telephony_registration != TelephonyRegistration.REGISTERED:
        blockers.append("Telephony device registration has not been confirmed by the provider")
    if agent.reconcile_required:
        blockers.append(f"Call state must be reconciled first ({agent.reconcile_reason or 'pending'})")
    blockers.extend(conflicting_call_state(db, agent))
    return {"ready": not blockers, "blockers": blockers}


def request_state(db: Session, agent: Agent, to: str, *, reason: str | None, actor_user_id: uuid.UUID,
                  expected_version: int | None, source: str = "agent") -> None:
    if to not in AGENT_REQUESTABLE:
        raise ValidationFailed(f"'{to}' cannot be requested; it is set by the system", code="STATE_NOT_REQUESTABLE")
    if expected_version is not None and agent.state_version != expected_version:
        raise InvalidTransition("Agent state changed since it was read", code="VERSION_CONFLICT",
                                details={"current_version": agent.state_version, "state": agent.state})
    if agent.state in BUSY:
        raise InvalidTransition(f"Cannot change availability while {agent.state}",
                                details={"state": agent.state})
    if to == S.AVAILABLE:
        r = readiness(db, agent)
        if agent.reconcile_required:
            raise ReconciliationRequired("Reconcile call state before becoming available",
                                         details={"blockers": r["blockers"]})
        if not r["ready"]:
            raise InvalidTransition("Agent is not ready to receive work", code="NOT_READY",
                                    details={"blockers": r["blockers"]})
    if to == S.OFFLINE and agent.state == S.AFTER_CALL_WORK:
        raise InvalidTransition("Complete after-call work before signing out")
    transition(db, agent, to, reason=reason, source=source, actor_user_id=actor_user_id)


def mark_reconcile(db: Session, agent: Agent, reason: str) -> None:
    if not agent.reconcile_required:
        agent.reconcile_required = True
        agent.reconcile_reason = reason
        events.to_agent(db, agent.org_id, agent.id, "agent.reconcile_required", reason=reason)
        events.to_supervisors(db, agent.org_id, "agent.reconcile_required", agent_id=agent.id, reason=reason)
    if agent.state == S.AVAILABLE:
        transition(db, agent, S.UNAVAILABLE, reason=f"reconcile:{reason}", source="system")
