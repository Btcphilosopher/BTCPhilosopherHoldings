"""AI assistance orchestration: builds context, enforces guardrails, stores proposals."""
from __future__ import annotations

import uuid
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..adapters.ai.base import AiAssistant, AiContext, scan_untrusted, strip_consequential
from ..config import get_settings
from ..db import utcnow
from ..errors import Forbidden, NotFound, ValidationFailed
from ..models import (AiSuggestion, ChatMessage, Interaction, InteractionEvent, MessageTemplate, Queue, Transcript)
from . import customers, knowledge

_assistant: AiAssistant | None = None


def get_assistant() -> AiAssistant | None:
    global _assistant
    s = get_settings()
    if s.ai_provider == "disabled":
        return None
    if _assistant is None:
        if s.ai_provider == "anthropic" and s.anthropic_api_key:
            from ..adapters.ai.anthropic_adapter import AnthropicAssistant

            _assistant = AnthropicAssistant(s.anthropic_api_key, s.anthropic_model)
        else:
            from ..adapters.ai.heuristic import HeuristicAssistant

            _assistant = HeuristicAssistant()
    return _assistant


def build_context(db: Session, it: Interaction, notes: str = "") -> AiContext:
    tr = db.scalar(select(Transcript).where(Transcript.interaction_id == it.id).order_by(Transcript.created_at.desc()))
    q = db.get(Queue, it.current_queue_id) if it.current_queue_id else None
    v = customers.verification_status(db, it) if it.customer_id else None
    return AiContext(
        interaction_ref=it.reference, channel=it.channel, queue=q.name if q else None, subject=it.subject,
        transcript=[{"i": s.get("i"), "speaker": s.get("speaker"), "text": s.get("text", "")} for s in
                    (tr.segments if tr else [])],
        messages=[{"sender": m.sender, "body": m.body} for m in db.scalars(
            select(ChatMessage).where(ChatMessage.interaction_id == it.id).order_by(ChatMessage.sent_at))],
        timeline=[{"type": e.type} for e in db.scalars(select(InteractionEvent).where(
            InteractionEvent.interaction_id == it.id).order_by(InteractionEvent.recorded_at))],
        notes=notes, verification_status=v["status"] if v else None)


def _store(db: Session, p, it: Interaction | None, kind: str, assistant: AiAssistant, result: dict[str, Any],
           flags: list[str]) -> AiSuggestion:
    sug = AiSuggestion(org_id=p.org_id, interaction_id=it.id if it else None, kind=kind, provider=assistant.provider,
                       model=assistant.model, output=result["output"], sources=result.get("sources", []),
                       uncertainty=result.get("uncertainty", {}),
                       safety_flags=sorted(set(flags + result.get("extra_flags", []))), status="proposed",
                       requested_by=p.user_id, created_at=utcnow())
    db.add(sug)
    db.flush()
    return sug


def _require(p, it: Interaction) -> None:
    p.require("ai.use")
    if it.org_id != p.org_id:
        raise NotFound("Interaction not found")
    if it.owner_agent_id != p.agent_id and not p.has("qa.review"):
        raise Forbidden("AI assistance is available to the agent handling the interaction")


def suggest_articles(db: Session, p, it: Interaction) -> AiSuggestion:
    _require(p, it)
    a = get_assistant()
    if a is None:
        raise ValidationFailed("AI assistance is disabled", code="AI_DISABLED")
    ctx = build_context(db, it)
    query = a.article_query(ctx)
    hits = knowledge.search(db, p.org_id, query, limit=5) if query else []
    flags = scan_untrusted([s["text"] for s in ctx.transcript] + [m["body"] for m in ctx.messages])
    result = {"output": {"query": query, "articles": [{"slug": h["slug"], "title": h["title"],
                                                       "visibility": h["visibility"], "version": h["version"],
                                                       "snippet": h["snippet"], "score": h["score"]} for h in hits]},
              "sources": [{"type": "knowledge_article", "ref": h["slug"], "version": h["version"]} for h in hits],
              "uncertainty": {"confidence": round(min(0.9, hits[0]["score"] * 5), 2) if hits else 0.0,
                              "notes": ["Only approved, currently effective articles are searched.",
                                        "Relevance is a text-match score, not a judgement of correctness."]}}
    return _store(db, p, it, "article_suggestion", a, result, flags)


def draft_summary(db: Session, p, it: Interaction, notes: str) -> AiSuggestion:
    _require(p, it)
    a = get_assistant()
    if a is None:
        raise ValidationFailed("AI assistance is disabled", code="AI_DISABLED")
    ctx = build_context(db, it, notes)
    ctx.articles = knowledge.search(db, p.org_id, a.article_query(ctx), limit=3)
    flags = scan_untrusted([s["text"] for s in ctx.transcript] + [m["body"] for m in ctx.messages] +
                           [x["summary"] for x in ctx.articles])
    result = a.summarise(ctx)
    cleaned, removed = strip_consequential(result["output"].get("summary", ""))
    if removed:
        flags.append("consequential_statement_removed")
        result["output"]["summary"] = cleaned
    return _store(db, p, it, "summary_draft", a, result, flags)


def classify(db: Session, p, it: Interaction) -> AiSuggestion:
    _require(p, it)
    a = get_assistant()
    if a is None:
        raise ValidationFailed("AI assistance is disabled", code="AI_DISABLED")
    ctx = build_context(db, it)
    flags = scan_untrusted([s["text"] for s in ctx.transcript] + [m["body"] for m in ctx.messages])
    return _store(db, p, it, "case_classification", a, a.classify(ctx), flags)


def draft_message(db: Session, p, it: Interaction, template_id: uuid.UUID) -> AiSuggestion:
    _require(p, it)
    a = get_assistant()
    if a is None:
        raise ValidationFailed("AI assistance is disabled", code="AI_DISABLED")
    t = db.get(MessageTemplate, template_id)
    if t is None or t.org_id != p.org_id or not t.approved:
        raise ValidationFailed("Only approved templates can be drafted")
    ctx = build_context(db, it)
    ctx.articles = knowledge.search(db, p.org_id, a.article_query(ctx), limit=3, visibility="customer_visible")
    flags = scan_untrusted([s["text"] for s in ctx.transcript] + [m["body"] for m in ctx.messages])
    result = a.draft_message(ctx, {"code": t.code, "placeholders": t.placeholders})
    for k, v in list(result["output"]["placeholder_values"].items()):
        cleaned, removed = strip_consequential(v)
        if removed:
            result["output"]["placeholder_values"][k] = cleaned
            flags.append("consequential_statement_removed")
    result["output"]["template_id"] = str(t.id)
    return _store(db, p, it, "message_draft", a, result, flags)


def review(db: Session, p, suggestion_id: uuid.UUID, decision: str) -> AiSuggestion:
    s = db.get(AiSuggestion, suggestion_id)
    if s is None or s.org_id != p.org_id:
        raise NotFound("Suggestion not found")
    if decision not in ("accepted", "rejected", "edited"):
        raise ValidationFailed("decision must be accepted, edited or rejected")
    s.status = decision
    s.reviewed_by = p.user_id
    s.reviewed_at = utcnow()
    return s
