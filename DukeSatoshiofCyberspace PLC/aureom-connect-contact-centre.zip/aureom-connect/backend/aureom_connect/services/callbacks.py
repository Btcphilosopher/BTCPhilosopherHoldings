"""Callback requests as owned work items.

* No exact time is promised unless capacity for that slot was reserved.
* Ownership is taken through the routing offer + guarded accept; dialling a
  callback requires ownership and refuses if another attempt is still live.
* Attempts are limited and recorded with their results.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import utcnow
from ..errors import InvalidTransition, NotFound, ValidationFailed, VersionConflict
from ..models import Callback, CallbackAttempt, Interaction, OutcomeCode, Queue, Task
from . import events, refs
from .customers import normalise_phone

SLOT_MINUTES = 30
RETRY_DELAY_MINUTES = 30


def _slot(dt: datetime) -> datetime:
    return dt.replace(minute=(dt.minute // SLOT_MINUTES) * SLOT_MINUTES, second=0, microsecond=0)


def _fmt(dt: datetime, tz: str) -> str:
    return dt.astimezone(ZoneInfo(tz)).strftime("%a %d %b %H:%M")


def create_callback(db: Session, org_id: uuid.UUID, *, phone_number: str | None, number_confirmation_method: str | None,
                    window_start: datetime, window_end: datetime, queue: Queue, customer_id: uuid.UUID | None,
                    origin_interaction_id: uuid.UUID | None, created_by: uuid.UUID | None, created_via: str,
                    reason: str, reserve_capacity: bool, max_attempts: int = 3, timezone: str = "Europe/London",
                    slots_per_interval: int = 2) -> Callback:
    norm = normalise_phone(phone_number)
    if not norm:
        raise ValidationFailed("A valid callback telephone number is required", details={"field": "phone_number"})
    if window_end <= window_start:
        raise ValidationFailed("Callback window end must be after its start")
    if window_end - window_start > timedelta(days=7):
        raise ValidationFailed("Callback window may not exceed 7 days")
    if window_end < utcnow():
        raise ValidationFailed("Callback window is entirely in the past")
    if not 1 <= max_attempts <= 5:
        raise ValidationFailed("max_attempts must be between 1 and 5")
    cb = Callback(org_id=org_id, reference=refs.next_ref(db, org_id, "callback"), customer_id=customer_id,
                  origin_interaction_id=origin_interaction_id, phone_number=norm,
                  number_confirmed=number_confirmation_method is not None,
                  number_confirmation_method=number_confirmation_method, window_start=window_start,
                  window_end=window_end, timezone=timezone, queue_id=queue.id,
                  required_skills=list(queue.required_skills or []), reason=reason, status="pending",
                  max_attempts=max_attempts, created_by=created_by, created_via=created_via)
    if reserve_capacity:
        slot = _slot(window_start)
        taken = db.scalar(select(func.count()).select_from(Callback).where(
            Callback.org_id == org_id, Callback.queue_id == queue.id, Callback.capacity_reserved.is_(True),
            Callback.reserved_slot_start == slot, Callback.status.notin_(["cancelled", "completed", "expired"]))) or 0
        if taken < slots_per_interval:
            cb.capacity_reserved = True
            cb.reserved_slot_start = slot
            end = slot + timedelta(minutes=SLOT_MINUTES)
            cb.promise_text = (f"Reserved: we will call between {_fmt(slot, timezone)} and "
                               f"{end.astimezone(ZoneInfo(timezone)).strftime('%H:%M')}.")
        else:
            cb.promise_text = (f"No reserved slot was available. We aim to call between {_fmt(window_start, timezone)} "
                               f"and {_fmt(window_end, timezone)}; this time is not guaranteed.")
    else:
        cb.promise_text = (f"We aim to call between {_fmt(window_start, timezone)} and {_fmt(window_end, timezone)}. "
                           "This is a target window, not a guaranteed time.")
    db.add(cb)
    db.flush()
    events.to_supervisors(db, org_id, "callback.created", callback_id=cb.id, reference=cb.reference)
    return cb


def get(db: Session, org_id: uuid.UUID, cb_id: uuid.UUID, lock: bool = False) -> Callback:
    q = select(Callback).where(Callback.id == cb_id, Callback.org_id == org_id)
    cb = db.scalar(q.with_for_update() if lock else q)
    if cb is None:
        raise NotFound("Callback not found")
    return cb


def cancel(db: Session, org_id: uuid.UUID, cb_id: uuid.UUID, reason: str, expected_version: int | None,
           by: uuid.UUID) -> Callback:
    cb = get(db, org_id, cb_id, lock=True)
    if expected_version is not None and cb.version != expected_version:
        raise VersionConflict("Callback changed", details={"current_version": cb.version})
    if cb.status in ("completed", "cancelled", "exhausted", "expired"):
        raise InvalidTransition(f"Callback already {cb.status}")
    if cb.status == "in_progress":
        raise InvalidTransition("Callback is being worked by an agent; ask them to complete it")
    if not reason.strip():
        raise ValidationFailed("A cancellation reason is required")
    cb.status = "cancelled"
    cb.cancelled_reason = reason
    cb.version += 1
    it = db.scalar(select(Interaction).where(Interaction.callback_id == cb.id,
                                             Interaction.status.in_(["queued", "offered"])))
    if it:
        from .interactions import close_queue_entry, withdraw_offers

        withdraw_offers(db, it, "callback_cancelled")
        close_queue_entry(db, it, "cancelled")
        it.status = "completed"
        it.end_reason = "callback_cancelled"
        it.version += 1
    return cb


def make_ready(db: Session, now: datetime | None = None) -> int:
    """Worker: open callbacks whose window has started become routable work."""
    from .interactions import enqueue, new_interaction

    now = now or utcnow()
    n = 0
    for cb in db.scalars(select(Callback).where(Callback.status == "pending", Callback.window_start <= now)
                         .with_for_update(skip_locked=True)):
        if cb.window_end < now:
            _expire(db, cb)
            continue
        q = db.get(Queue, cb.queue_id)
        it = new_interaction(db, cb.org_id, channel="voice", direction="outbound", status="ivr", source="callback",
                             customer_id=cb.customer_id, callback_id=cb.id,
                             customer_match_status="selected_unverified" if cb.customer_id else "unmatched",
                             subject=f"Callback {cb.reference}", match_hint={"callback_number": cb.phone_number})
        enqueue(db, it, q, reason="callback")
        it.routable_since = cb.reserved_slot_start or cb.window_start
        cb.status = "ready"
        cb.version += 1
        events.timeline(db, it, "callback.ready", "system", callback=cb.reference, attempt=cb.attempts + 1,
                        max_attempts=cb.max_attempts)
        n += 1
    for cb in db.scalars(select(Callback).where(Callback.status == "ready", Callback.window_end < now)):
        _expire(db, cb)
    return n


def _expire(db: Session, cb: Callback) -> None:
    cb.status = "expired"
    cb.version += 1
    db.add(Task(org_id=cb.org_id, kind="back_office", title=f"Callback {cb.reference} window passed",
                description="The callback window ended before contact was made. Review and contact the customer.",
                customer_id=cb.customer_id, assignee_queue_id=cb.queue_id, priority="high",
                due_at=utcnow() + timedelta(hours=2)))
    it = db.scalar(select(Interaction).where(Interaction.callback_id == cb.id,
                                             Interaction.status.in_(["queued", "offered"])))
    if it:
        from .interactions import close_queue_entry, withdraw_offers

        withdraw_offers(db, it, "callback_expired")
        close_queue_entry(db, it, "expired")
        it.status = "completed"
        it.end_reason = "callback_window_expired"


def start_attempt(db: Session, cb: Callback, agent_id: uuid.UUID, interaction_id: uuid.UUID) -> CallbackAttempt:
    if cb.status != "in_progress" or cb.owner_agent_id != agent_id:
        raise InvalidTransition("You do not own this callback", code="NOT_OWNER")
    live = db.scalar(select(CallbackAttempt).where(CallbackAttempt.callback_id == cb.id,
                                                   CallbackAttempt.ended_at.is_(None)))
    if live:
        raise InvalidTransition("Another attempt for this callback is still in progress",
                                code="DUPLICATE_ATTEMPT", details={"attempt_id": str(live.id)})
    if cb.attempts >= cb.max_attempts:
        raise InvalidTransition("Callback attempt limit reached", code="ATTEMPT_LIMIT")
    cb.attempts += 1
    cb.version += 1
    att = CallbackAttempt(org_id=cb.org_id, callback_id=cb.id, attempt_number=cb.attempts, agent_id=agent_id,
                          interaction_id=interaction_id, started_at=utcnow())
    db.add(att)
    return att


def on_interaction_completed(db: Session, it: Interaction, disposition_code: str) -> None:
    cb = db.get(Callback, it.callback_id)
    if cb is None:
        return
    oc = db.scalar(select(OutcomeCode).where(OutcomeCode.org_id == it.org_id, OutcomeCode.code == disposition_code))
    contact_made = bool(oc and oc.category != "no_contact")
    att = db.scalar(select(CallbackAttempt).where(CallbackAttempt.callback_id == cb.id,
                                                  CallbackAttempt.ended_at.is_(None)))
    if att:
        att.ended_at = utcnow()
        att.result = "connected" if contact_made else disposition_code
    cb.owner_agent_id = None
    cb.version += 1
    if contact_made:
        cb.status = "completed"
        cb.completed_at = utcnow()
    elif cb.attempts >= cb.max_attempts:
        cb.status = "exhausted"
        db.add(Task(org_id=cb.org_id, kind="back_office", title=f"Callback {cb.reference}: attempts exhausted",
                    description=f"{cb.attempts} attempts without contact.", customer_id=cb.customer_id,
                    assignee_queue_id=cb.queue_id))
    else:
        nxt = utcnow() + timedelta(minutes=RETRY_DELAY_MINUTES)
        if nxt > cb.window_end:
            cb.status = "expired"
        else:
            cb.status = "pending"
            cb.window_start = nxt
    events.to_supervisors(db, cb.org_id, "callback.updated", callback_id=cb.id, status=cb.status)


def view(db: Session, cb: Callback) -> dict[str, Any]:
    attempts = db.scalars(select(CallbackAttempt).where(CallbackAttempt.callback_id == cb.id)
                          .order_by(CallbackAttempt.attempt_number)).all()
    q = db.get(Queue, cb.queue_id)
    return {"id": cb.id, "reference": cb.reference, "customer_id": cb.customer_id, "phone_number": cb.phone_number,
            "number_confirmed": cb.number_confirmed, "number_confirmation_method": cb.number_confirmation_method,
            "window_start": cb.window_start, "window_end": cb.window_end, "timezone": cb.timezone,
            "queue": q.code if q else None, "required_skills": cb.required_skills, "status": cb.status,
            "attempts": cb.attempts, "max_attempts": cb.max_attempts, "capacity_reserved": cb.capacity_reserved,
            "reserved_slot_start": cb.reserved_slot_start, "promise_text": cb.promise_text,
            "owner_agent_id": cb.owner_agent_id, "version": cb.version, "reason": cb.reason,
            "cancelled_reason": cb.cancelled_reason, "created_via": cb.created_via, "created_at": cb.created_at,
            "attempt_history": [{"attempt": a.attempt_number, "agent_id": a.agent_id, "started_at": a.started_at,
                                 "ended_at": a.ended_at, "result": a.result} for a in attempts]}
