"""Outbound calling: eligibility, agent-initiated dialling and preview campaigns.

Every dial is preceded by a fresh eligibility evaluation against the active,
versioned calling rule set for the recipient's jurisdiction. The result —
including the rule-set version — is stored on the ``OutboundAttempt`` whether
the call is placed or refused. Caller identity is always an owned, verified
number: there is no way to present an arbitrary caller ID.

Predictive / progressive dialling is intentionally not implemented.
"""
from __future__ import annotations

import csv
import io
import uuid
from datetime import timedelta
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import phonenumbers
from sqlalchemy import and_, func, or_, select
from sqlalchemy.orm import Session

from ..adapters.storage import get_storage
from ..adapters.telephony.registry import get_provider
from ..db import utcnow
from ..errors import AppError, Forbidden, InvalidTransition, NotFound, ReconciliationRequired, ValidationFailed
from ..models import (Agent, AgentParticipation, AgentQueueMembership, Call, CallLeg, Callback, CallingRuleSet,
                      Campaign, CampaignContact, CampaignImport, CommunicationPreference, Consent, ContactPoint,
                      Customer, Interaction, Job, Objection, OutcomeCode, OutboundAttempt, PhoneNumber,
                      StoredObject, SuppressionEntry, SuppressionList)
from ..models.enums import AgentState, Presence, TelephonyRegistration
from . import agent_state, callbacks, events
from .calls import provider_status
from .interactions import identity_for, new_interaction


class OutboundNotPermitted(AppError):
    status_code = 422
    code = "OUTBOUND_NOT_PERMITTED"


def _jurisdiction(e164: str) -> str | None:
    try:
        return phonenumbers.region_code_for_number(phonenumbers.parse(e164))
    except phonenumbers.NumberParseException:
        return None


def active_rule_set(db: Session, org_id: uuid.UUID, jurisdiction: str) -> CallingRuleSet | None:
    now = utcnow()
    return db.scalar(select(CallingRuleSet).where(
        CallingRuleSet.org_id == org_id, CallingRuleSet.jurisdiction == jurisdiction, CallingRuleSet.status == "active",
        CallingRuleSet.effective_from <= now,
        or_(CallingRuleSet.effective_to.is_(None), CallingRuleSet.effective_to > now))
        .order_by(CallingRuleSet.version.desc()).limit(1))


def _within_window(rules: dict[str, Any], tz: str) -> tuple[bool, str]:
    try:
        local = utcnow().astimezone(ZoneInfo(tz))
    except ZoneInfoNotFoundError:
        return False, f"unknown recipient timezone {tz}"
    windows = (rules.get("calling_windows") or {}).get(str(local.isoweekday()), [])
    hhmm = local.strftime("%H:%M")
    for start, end in windows:
        if start <= hhmm < end:
            return True, f"recipient local time {hhmm} ({tz}) within {start}-{end}"
    return False, f"recipient local time {hhmm} ({tz}) outside permitted windows {windows or 'none today'}"


def check_eligibility(db: Session, org_id: uuid.UUID, *, number: str, purpose: str,
                      customer_id: uuid.UUID | None = None, campaign_contact: CampaignContact | None = None,
                      callback: Callback | None = None, caller_id: PhoneNumber | None = None,
                      recipient_timezone: str | None = None, agent_id: uuid.UUID | None = None,
                      exclude_interaction_id: uuid.UUID | None = None) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []

    def add(check: str, passed: bool, detail: str) -> None:
        checks.append({"check": check, "passed": passed, "detail": detail})

    from .customers import normalise_phone

    norm = normalise_phone(number)
    add("number_valid", bool(norm), norm or "not a valid telephone number")
    if not norm:
        return {"eligible": False, "checks": checks, "normalized_number": None, "rule_set": None}
    if purpose not in ("service", "marketing"):
        add("purpose_known", False, f"unknown purpose '{purpose}'")
    if caller_id is None:
        add("caller_id_owned", False, "no owned outbound caller ID configured")
    else:
        ok = caller_id.org_id == org_id and caller_id.outbound_allowed and caller_id.verified_at is not None
        add("caller_id_owned", ok, f"presenting {caller_id.e164} ({caller_id.label})" if ok
            else "caller ID is not an owned, verified, outbound-enabled number")
    juris = _jurisdiction(norm)
    rs = active_rule_set(db, org_id, juris) if juris else None
    add("rule_set_active", rs is not None,
        f"{juris} rule set v{rs.version}" if rs else f"no active calling rule set for jurisdiction {juris}")
    if rs is None:
        return {"eligible": False, "checks": checks, "normalized_number": norm, "rule_set": None,
                "jurisdiction": juris}
    rules = rs.rules
    pconf = (rules.get("purposes") or {}).get(purpose)
    if pconf is None:
        add("purpose_permitted", False, f"purpose '{purpose}' is not configured for {juris}")
        pconf = {}
    if campaign_contact is not None:
        camp = db.get(Campaign, campaign_contact.campaign_id)
        add("campaign_active", camp.status == "active", f"campaign '{camp.name}' is {camp.status}")
        add("campaign_contact_open", campaign_contact.status in ("ready", "reserved", "in_progress"),
            f"contact status {campaign_contact.status}")
        add("campaign_attempt_limit", campaign_contact.attempts < camp.max_attempts_per_contact,
            f"{campaign_contact.attempts}/{camp.max_attempts_per_contact} attempts used")
    # Basis: consent or other applicable basis.
    required = pconf.get("basis_required", [])
    basis_found = None
    if callback is not None:
        if "customer_request" in required:
            basis_found = f"customer requested callback {callback.reference}"
    if basis_found is None and customer_id:
        cons = db.scalars(select(Consent).where(Consent.customer_id == customer_id, Consent.status == "granted",
                                                Consent.purpose == f"{purpose}_calls")).all()
        for c in cons:
            if c.basis in required:
                basis_found = f"{c.basis} recorded {c.captured_at:%Y-%m-%d} via {c.source}"
                break
    add("basis", basis_found is not None,
        basis_found or f"no recorded basis among {required} for {purpose} calls")
    # Suppression lists.
    lists = pconf.get("screen_lists", [])
    hits = db.execute(select(SuppressionList.code, SuppressionEntry.reason).join(
        SuppressionEntry, SuppressionEntry.list_id == SuppressionList.id).where(
        SuppressionList.org_id == org_id, SuppressionList.code.in_(lists), SuppressionEntry.normalized_number == norm,
        or_(SuppressionEntry.expires_at.is_(None), SuppressionEntry.expires_at > utcnow()))).all()
    add("suppression", not hits, "not on " + ", ".join(lists) if not hits
        else "listed on " + ", ".join(f"{c} ({r})" for c, r in hits))
    # Objections.
    scopes = (rules.get("objection_scopes") or {}).get(purpose, [])
    cust_ids = {customer_id} if customer_id else set()
    cust_ids |= set(db.scalars(select(ContactPoint.customer_id).where(ContactPoint.org_id == org_id,
                                                                      ContactPoint.normalized == norm)))
    obj = db.scalars(select(Objection).where(Objection.customer_id.in_(cust_ids), Objection.active.is_(True),
                                             Objection.scope.in_(scopes))).all() if cust_ids else []
    add("objection", not obj, "no applicable objection" if not obj
        else "objection recorded: " + ", ".join(o.scope for o in obj))
    # Communication preferences.
    if customer_id:
        pref = db.scalar(select(CommunicationPreference).where(CommunicationPreference.customer_id == customer_id,
                                                               CommunicationPreference.channel == "phone",
                                                               CommunicationPreference.purpose == purpose))
        add("preference", pref is None or pref.allowed,
            "customer prefers no phone contact for this purpose" if pref is not None and not pref.allowed
            else "no conflicting preference")
    # Local calling window.
    tz = recipient_timezone
    if tz is None and customer_id:
        cust = db.get(Customer, customer_id)
        tz = cust.timezone if cust else None
    if tz is None:
        tz = {"GB": "Europe/London", "US": "America/New_York"}.get(juris or "", "UTC")
    ok, why = _within_window(rules, tz)
    add("calling_window", ok, why)
    # Attempt limits for this number (all purposes).
    since_day = utcnow() - timedelta(days=1)
    since_week = utcnow() - timedelta(days=7)
    placed = and_(OutboundAttempt.org_id == org_id, OutboundAttempt.normalized_number == norm,
                  OutboundAttempt.status != "refused")
    n_day = db.scalar(select(func.count()).select_from(OutboundAttempt).where(placed,
                                                                             OutboundAttempt.created_at > since_day))
    n_week = db.scalar(select(func.count()).select_from(OutboundAttempt).where(placed,
                                                                              OutboundAttempt.created_at > since_week))
    max_day, max_week = rules.get("max_attempts_per_day", 3), rules.get("max_attempts_per_7_days", 10)
    add("attempt_limit", n_day < max_day and n_week < max_week,
        f"{n_day}/{max_day} in 24h, {n_week}/{max_week} in 7 days")
    last = db.scalar(select(func.max(OutboundAttempt.created_at)).where(placed))
    gap = rules.get("min_minutes_between_attempts", 0)
    if last is not None and gap:
        mins = (utcnow() - last).total_seconds() / 60
        add("attempt_spacing", mins >= gap, f"last attempt {mins:.0f} min ago (minimum {gap})")
    # Existing active contact attempts.
    live = db.scalar(select(OutboundAttempt.id).where(placed, OutboundAttempt.status.in_(["dialling", "connected",
                                                                                          "unknown"]),
                                                      OutboundAttempt.ended_at.is_(None)).limit(1))
    active_it = None
    if customer_id:
        q = select(Interaction.id).where(Interaction.customer_id == customer_id, Interaction.channel == "voice",
                                         Interaction.status.in_(["connecting", "active"]))
        if exclude_interaction_id:
            q = q.where(Interaction.id != exclude_interaction_id)
        active_it = db.scalar(q.limit(1))
    add("no_active_attempt", live is None and active_it is None,
        "no other live attempt or call" if live is None and active_it is None
        else "another attempt or call with this customer is in progress")
    if campaign_contact is not None and campaign_contact.reserved_by_agent_id and agent_id \
            and campaign_contact.reserved_by_agent_id != agent_id:
        add("contact_reservation", False, "contact is reserved by another agent")
    eligible = all(c["passed"] for c in checks)
    return {"eligible": eligible, "checks": checks, "normalized_number": norm, "jurisdiction": juris,
            "rule_set": {"id": str(rs.id), "jurisdiction": rs.jurisdiction, "version": rs.version},
            "evaluated_at": utcnow().isoformat()}


def default_caller_id(db: Session, org_id: uuid.UUID) -> PhoneNumber | None:
    return db.scalar(select(PhoneNumber).where(PhoneNumber.org_id == org_id, PhoneNumber.outbound_allowed.is_(True),
                                               PhoneNumber.verified_at.is_not(None)).order_by(PhoneNumber.e164).limit(1))


def place_call(db: Session, agent: Agent, *, number: str | None, purpose: str, customer_id: uuid.UUID | None,
               campaign_contact_id: uuid.UUID | None, callback_id: uuid.UUID | None,
               interaction_id: uuid.UUID | None, caller_id_number_id: uuid.UUID | None,
               idempotency_key: str, actor_user_id: uuid.UUID) -> OutboundAttempt:
    existing = db.scalar(select(OutboundAttempt).where(OutboundAttempt.org_id == agent.org_id,
                                                       OutboundAttempt.idempotency_key == idempotency_key))
    if existing:
        return existing  # never re-dial on retry
    if agent.reconcile_required:
        raise ReconciliationRequired("Reconcile call state before dialling")
    if provider_status(db, agent.org_id) != "connected":
        from ..errors import ProviderUnavailable

        raise ProviderUnavailable("Telephony provider not connected; dialling disabled")
    if not get_provider().capabilities().outbound_dial:
        from ..errors import Unsupported

        raise Unsupported("Provider does not support outbound dialling")
    if agent.presence != Presence.ONLINE or agent.telephony_registration != TelephonyRegistration.REGISTERED:
        raise InvalidTransition("Your application and telephony device must both be connected", code="NOT_READY")

    it: Interaction | None = None
    contact = db.get(CampaignContact, campaign_contact_id) if campaign_contact_id else None
    cb = callbacks.get(db, agent.org_id, callback_id, lock=True) if callback_id else None
    if interaction_id:
        it = db.get(Interaction, interaction_id)
        if it is None or it.org_id != agent.org_id or it.owner_agent_id != agent.id:
            raise Forbidden("You do not own this work item", code="NOT_OWNER")
        if it.status != "active":
            raise InvalidTransition(f"Work item is {it.status}")
        live_call = db.scalar(select(Call).where(Call.interaction_id == it.id, Call.status == "in_progress"))
        if live_call:
            raise InvalidTransition("A call is already in progress for this work item", code="DUPLICATE_ATTEMPT")
        cb = cb or (callbacks.get(db, agent.org_id, it.callback_id, lock=True) if it.callback_id else None)
        contact = contact or (db.get(CampaignContact, it.campaign_contact_id) if it.campaign_contact_id else None)
        customer_id = customer_id or it.customer_id
    elif agent.state != AgentState.AVAILABLE and agent.state != AgentState.AFTER_CALL_WORK:
        raise InvalidTransition(f"Cannot start a manual call while {agent.state}", code="NOT_READY")
    if cb is not None:
        number = number or cb.phone_number
        purpose = "service"
        customer_id = customer_id or cb.customer_id
    if contact is not None:
        number = number or contact.normalized_number
        purpose = db.get(Campaign, contact.campaign_id).purpose
        customer_id = customer_id or contact.customer_id
    if not number:
        raise ValidationFailed("A number is required")
    caller = db.get(PhoneNumber, caller_id_number_id) if caller_id_number_id else None
    if contact is not None and caller is None:
        caller = db.get(PhoneNumber, db.get(Campaign, contact.campaign_id).caller_id_number_id)
    caller = caller or default_caller_id(db, agent.org_id)
    elig = check_eligibility(db, agent.org_id, number=number, purpose=purpose, customer_id=customer_id,
                             campaign_contact=contact, callback=cb, caller_id=caller,
                             recipient_timezone=contact.timezone if contact else (cb.timezone if cb else None),
                             agent_id=agent.id, exclude_interaction_id=it.id if it else None)
    rs = elig.get("rule_set") or {}
    attempt = OutboundAttempt(org_id=agent.org_id, idempotency_key=idempotency_key, agent_id=agent.id,
                              customer_id=customer_id, campaign_contact_id=contact.id if contact else None,
                              callback_id=cb.id if cb else None,
                              normalized_number=elig.get("normalized_number") or number, purpose=purpose,
                              rule_set_id=uuid.UUID(rs["id"]) if rs.get("id") else None,
                              rule_set_version=rs.get("version"), eligibility=elig,
                              status="refused" if not elig["eligible"] else "dialling",
                              caller_id_number_id=caller.id if caller else None, created_at=utcnow(),
                              interaction_id=it.id if it else None)
    db.add(attempt)
    if not elig["eligible"]:
        attempt.ended_at = utcnow()
        failed = [c for c in elig["checks"] if not c["passed"]]
        if it:
            events.timeline(db, it, "outbound.refused", "system", actor_user_id=actor_user_id,
                            failed_checks=[c["check"] for c in failed])
        db.commit()
        raise OutboundNotPermitted("This call is not permitted by the configured checks",
                                   details={"attempt_id": str(attempt.id), "failed": failed, "eligibility": elig})
    if it is None:
        it = new_interaction(db, agent.org_id, channel="voice", direction="outbound", status="connecting",
                             source=get_provider().name, is_simulated=get_provider().name == "simulated",
                             customer_id=customer_id, owner_agent_id=agent.id,
                             customer_match_status="selected_unverified" if customer_id else "unmatched",
                             subject="Manual outbound call", match_hint={"dialled": attempt.normalized_number})
        db.add(AgentParticipation(org_id=it.org_id, interaction_id=it.id, agent_id=agent.id, role="primary",
                                  accepted_at=utcnow()))
        agent.current_interaction_id = it.id
        agent_state.transition(db, agent, AgentState.CONNECTING, reason="manual_outbound", source="agent",
                               actor_user_id=actor_user_id)
    else:
        it.status = "connecting"
        it.version += 1
    attempt.interaction_id = it.id
    if cb is not None:
        callbacks.start_attempt(db, cb, agent.id, it.id)
    if contact is not None:
        contact.status = "in_progress"
        contact.attempts += 1
        contact.last_attempt_at = utcnow()
        contact.version += 1
    events.timeline(db, it, "outbound.dial_requested", "agent", actor_user_id=actor_user_id,
                    number=attempt.normalized_number, purpose=purpose, rule_set=rs,
                    caller_id=caller.e164 if caller else None)
    db.commit()

    res = get_provider().dial(caller.e164, attempt.normalized_number, identity_for(agent.id), request_id=str(attempt.id))
    attempt = db.get(OutboundAttempt, attempt.id)
    it = db.get(Interaction, it.id)
    if res.outcome == "accepted" and res.provider_call_id:
        call = Call(org_id=it.org_id, interaction_id=it.id, provider=get_provider().name,
                    provider_call_id=res.provider_call_id, direction="outbound", from_number=caller.e164,
                    to_number=attempt.normalized_number, status="in_progress", started_at=utcnow(),
                    caller_id_number_id=caller.id)
        db.add(call)
        db.flush()
        if res.data.get("agent_leg_id"):
            db.add(CallLeg(org_id=it.org_id, call_id=call.id, provider_leg_id=res.data["agent_leg_id"], leg_type="agent",
                           agent_id=agent.id, status="initiated", started_at=utcnow()))
        if res.data.get("customer_leg_id"):
            db.add(CallLeg(org_id=it.org_id, call_id=call.id, provider_leg_id=res.data["customer_leg_id"],
                           leg_type="customer", external_number=attempt.normalized_number, status="initiated",
                           started_at=utcnow()))
        db.flush()
        from . import provider_events

        provider_events.reprocess_unmatched(db, call.provider, call.provider_call_id)
    elif res.outcome == "rejected":
        attempt.status = "failed"
        attempt.ended_at = utcnow()
        attempt.note = res.error_code
        it.status = "wrap_up"
        it.ended_at = utcnow()
        it.end_reason = "dial_failed"
        part = db.scalar(select(AgentParticipation).where(AgentParticipation.interaction_id == it.id,
                                                          AgentParticipation.agent_id == agent.id,
                                                          AgentParticipation.ended_at.is_(None)))
        if part:
            part.ended_at = utcnow()
            part.wrap_started_at = utcnow()
        agent_state.transition(db, agent, AgentState.AFTER_CALL_WORK, reason="dial_failed", source="system", force=True)
        events.timeline(db, it, "outbound.dial_failed", "provider", error=res.error_code)
    else:
        attempt.status = "unknown"
        attempt.note = "Dial outcome unknown; not retried. Reconciliation will look for the call at the provider."
        it.needs_reconciliation = True
        agent_state.mark_reconcile(db, agent, "dial outcome unknown")
        events.timeline(db, it, "outbound.dial_unknown", "system", note=attempt.note)
    return attempt


# --------------------------------------------------------------------------- campaigns

def import_csv(db: Session, campaign: Campaign, filename: str, content: bytes, by: uuid.UUID) -> CampaignImport:
    if campaign.status not in ("draft", "review"):
        raise InvalidTransition("Imports are only allowed before activation")
    if len(content) > 5_000_000:
        raise ValidationFailed("File too large (max 5 MB)")
    key, sha, size = get_storage().put(content, prefix=f"imports/{campaign.org_id}")
    db.add(StoredObject(org_id=campaign.org_id, storage_key=key, kind="import", content_type="text/csv",
                        size_bytes=size, sha256=sha, created_at=utcnow()))
    imp = CampaignImport(org_id=campaign.org_id, campaign_id=campaign.id, filename=filename[:255], storage_key=key,
                         status="queued", errors=[], uploaded_by=by)
    db.add(imp)
    db.flush()
    campaign.status = "importing"
    db.add(Job(org_id=campaign.org_id, kind="campaign_import", payload={"import_id": str(imp.id)}, run_at=utcnow()))
    return imp


def process_import(db: Session, imp: CampaignImport) -> None:
    from .customers import normalise_phone

    campaign = db.get(Campaign, imp.campaign_id)
    imp.status = "processing"
    text = get_storage().get(imp.storage_key).decode("utf-8-sig", errors="replace")
    reader = csv.DictReader(io.StringIO(text))
    required = {"phone", "name"}
    if not reader.fieldnames or not required <= {f.strip().lower() for f in reader.fieldnames}:
        imp.status = "failed"
        imp.errors = [{"row": 0, "error": f"missing required columns {sorted(required)}"}]
        campaign.status = "draft"
        return
    seen: set[str] = set(db.scalars(select(CampaignContact.normalized_number)
                                    .where(CampaignContact.campaign_id == campaign.id)))
    errors, valid, total = [], 0, 0
    caller = db.get(PhoneNumber, campaign.caller_id_number_id)
    for i, row in enumerate(reader, start=2):
        total += 1
        row = {(k or "").strip().lower(): (v or "").strip() for k, v in row.items()}
        norm = normalise_phone(row.get("phone"))
        tz = row.get("timezone") or "Europe/London"
        problems = []
        if not norm:
            problems.append("invalid phone number")
        try:
            ZoneInfo(tz)
        except (ZoneInfoNotFoundError, ValueError):
            problems.append(f"unknown timezone {tz}")
        cust = None
        if row.get("customer_ref"):
            cust = db.scalar(select(Customer).where(Customer.org_id == campaign.org_id,
                                                    Customer.customer_ref == row["customer_ref"]))
            if cust is None:
                problems.append(f"unknown customer_ref {row['customer_ref']}")
        if norm and norm in seen:
            problems.append("duplicate number in campaign")
        if problems:
            errors.append({"row": i, "phone": row.get("phone", "")[-4:], "errors": problems})
            continue
        seen.add(norm)
        pre = check_eligibility(db, campaign.org_id, number=norm, purpose=campaign.purpose,
                                customer_id=cust.id if cust else None, caller_id=caller, recipient_timezone=tz)
        # Calling window/campaign_active are time-dependent; exclusion uses only durable reasons.
        durable_fail = [c for c in pre["checks"] if not c["passed"] and c["check"] in
                        ("suppression", "objection", "basis", "preference", "number_valid")]
        db.add(CampaignContact(org_id=campaign.org_id, campaign_id=campaign.id, import_id=imp.id,
                               customer_id=cust.id if cust else None, display_name=row.get("name", "")[:200],
                               normalized_number=norm, timezone=tz, precheck=pre,
                               status="excluded" if durable_fail else "ready"))
        valid += 1
    imp.total_rows, imp.valid_rows, imp.invalid_rows = total, valid, total - valid
    imp.errors = errors[:500]
    imp.status = "validated"
    imp.processed_at = utcnow()
    campaign.status = "review"
    db.flush()
    campaign.review_summary = review_summary(db, campaign)


def review_summary(db: Session, campaign: Campaign) -> dict[str, Any]:
    contacts = db.scalars(select(CampaignContact).where(CampaignContact.campaign_id == campaign.id)).all()
    by_status: dict[str, int] = {}
    reasons: dict[str, int] = {}
    for c in contacts:
        by_status[c.status] = by_status.get(c.status, 0) + 1
        for chk in (c.precheck or {}).get("checks", []):
            if not chk["passed"]:
                reasons[chk["check"]] = reasons.get(chk["check"], 0) + 1
    return {"total_contacts": len(contacts), "by_status": by_status, "precheck_failures": reasons,
            "note": "Eligibility is re-evaluated immediately before every dial; this summary is informational."}


def activate(db: Session, campaign: Campaign, approver_id: uuid.UUID, *, require_four_eyes: bool = True) -> Campaign:
    if campaign.status != "review":
        raise InvalidTransition(f"Campaign must be in review to activate (is {campaign.status})")
    if require_four_eyes and campaign.created_by == approver_id:
        raise Forbidden("A different person must approve the campaign (four-eyes rule)", code="FOUR_EYES_REQUIRED")
    caller = db.get(PhoneNumber, campaign.caller_id_number_id)
    if not caller or not caller.outbound_allowed or not caller.verified_at:
        raise ValidationFailed("Campaign caller ID is not an owned, verified, outbound-enabled number")
    if active_rule_set(db, campaign.org_id, campaign.jurisdiction) is None:
        raise ValidationFailed(f"No active calling rule set for {campaign.jurisdiction}")
    ready = db.scalar(select(func.count()).select_from(CampaignContact).where(
        CampaignContact.campaign_id == campaign.id, CampaignContact.status == "ready"))
    if not ready:
        raise ValidationFailed("Campaign has no eligible contacts to call")
    if campaign.dial_mode != "preview":
        raise ValidationFailed("Only preview dialling is supported in this release")
    campaign.status = "active"
    campaign.approved_by = approver_id
    campaign.activated_at = utcnow()
    campaign.version += 1
    return campaign


def next_contact(db: Session, agent: Agent, campaign: Campaign, actor_user_id: uuid.UUID) -> dict[str, Any]:
    if campaign.status != "active":
        raise InvalidTransition(f"Campaign is {campaign.status}")
    member = db.scalar(select(AgentQueueMembership).where(AgentQueueMembership.agent_id == agent.id,
                                                          AgentQueueMembership.queue_id == campaign.queue_id))
    if member is None:
        raise Forbidden("You are not assigned to this campaign's queue")
    if agent.state not in (AgentState.AVAILABLE, AgentState.AFTER_CALL_WORK) or agent.current_interaction_id:
        raise InvalidTransition("Finish your current work before previewing the next contact", code="NOT_READY")
    contact = db.scalar(select(CampaignContact).where(CampaignContact.campaign_id == campaign.id,
                                                      CampaignContact.status == "ready")
                        .order_by(CampaignContact.attempts, CampaignContact.created_at)
                        .with_for_update(skip_locked=True).limit(1))
    if contact is None:
        raise NotFound("No contacts are ready to call in this campaign", code="NO_CONTACTS")
    contact.status = "reserved"
    contact.reserved_by_agent_id = agent.id
    contact.reserved_at = utcnow()
    contact.version += 1
    it = new_interaction(db, agent.org_id, channel="voice", direction="outbound", status="active", source="campaign",
                         customer_id=contact.customer_id, owner_agent_id=agent.id, campaign_contact_id=contact.id,
                         current_queue_id=campaign.queue_id, subject=f"Preview: {campaign.name}",
                         customer_match_status="selected_unverified" if contact.customer_id else "unmatched",
                         match_hint={"campaign": campaign.name})
    db.add(AgentParticipation(org_id=it.org_id, interaction_id=it.id, agent_id=agent.id, role="primary",
                              accepted_at=utcnow(), connected_at=None))
    agent.current_interaction_id = it.id
    agent_state.transition(db, agent, AgentState.ON_INTERACTION, reason="campaign_preview", source="agent",
                           actor_user_id=actor_user_id, force=agent.state == AgentState.AFTER_CALL_WORK)
    elig = check_eligibility(db, agent.org_id, number=contact.normalized_number, purpose=campaign.purpose,
                             customer_id=contact.customer_id, campaign_contact=contact,
                             caller_id=db.get(PhoneNumber, campaign.caller_id_number_id),
                             recipient_timezone=contact.timezone, agent_id=agent.id, exclude_interaction_id=it.id)
    events.timeline(db, it, "campaign.preview", "agent", actor_user_id=actor_user_id, campaign=campaign.name)
    return {"interaction_id": it.id, "contact": contact_view(contact), "eligibility": elig}


def skip_contact(db: Session, agent: Agent, it: Interaction, reason: str, actor_user_id: uuid.UUID) -> None:
    contact = db.get(CampaignContact, it.campaign_contact_id) if it.campaign_contact_id else None
    if contact is None or it.owner_agent_id != agent.id:
        raise Forbidden("Not your preview")
    if db.scalar(select(Call.id).where(Call.interaction_id == it.id).limit(1)):
        raise InvalidTransition("A call was already placed; complete wrap-up instead")
    contact.status = "ready"
    contact.reserved_by_agent_id = None
    contact.version += 1
    it.status = "completed"
    it.end_reason = "preview_skipped"
    it.disposition_code = "preview_skipped"
    it.disposition_note = reason
    it.ended_at = it.wrap_completed_at = utcnow()
    it.version += 1
    part = db.scalar(select(AgentParticipation).where(AgentParticipation.interaction_id == it.id,
                                                      AgentParticipation.agent_id == agent.id))
    if part:
        part.ended_at = part.wrap_ended_at = utcnow()
        part.outcome = "skipped"
    agent.current_interaction_id = None
    events.timeline(db, it, "campaign.skipped", "agent", actor_user_id=actor_user_id, reason=reason)
    db.flush()
    ready = agent_state.readiness(db, agent)
    # No call was placed (checked above), so leaving preview straight to availability is safe.
    agent_state.transition(db, agent, AgentState.AVAILABLE if ready["ready"] else AgentState.UNAVAILABLE,
                           reason="preview_skipped", source="agent", actor_user_id=actor_user_id, force=True)


def on_campaign_interaction_completed(db: Session, it: Interaction, disposition_code: str) -> None:
    contact = db.get(CampaignContact, it.campaign_contact_id)
    camp = db.get(Campaign, contact.campaign_id)
    oc = db.scalar(select(OutcomeCode).where(OutcomeCode.org_id == it.org_id, OutcomeCode.code == disposition_code))
    contact.last_outcome = disposition_code
    contact.reserved_by_agent_id = None
    contact.version += 1
    if oc and oc.category == "do_not_call":
        contact.status = "excluded"
    elif oc and oc.category != "no_contact":
        contact.status = "completed"
    elif contact.attempts >= camp.max_attempts_per_contact:
        contact.status = "exhausted"
    else:
        contact.status = "ready"


def contact_view(c: CampaignContact) -> dict[str, Any]:
    return {"id": c.id, "display_name": c.display_name, "number": c.normalized_number, "timezone": c.timezone,
            "status": c.status, "attempts": c.attempts, "last_outcome": c.last_outcome, "customer_id": c.customer_id,
            "precheck": c.precheck, "version": c.version}
