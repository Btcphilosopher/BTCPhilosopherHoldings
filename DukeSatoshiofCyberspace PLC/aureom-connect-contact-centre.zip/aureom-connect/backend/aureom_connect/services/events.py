"""Application event outbox + interaction timeline helpers.

Events are written in the same transaction as the state change they describe
(transactional outbox) and delivered by the WebSocket gateway after commit.
``pg_notify`` wakes gateways in other processes; delivery also falls back to
polling so a missed notification only delays, never loses, an event.
"""
from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import text
from sqlalchemy.orm import Session

from ..db import utcnow
from ..models import AppEvent, InteractionEvent

CHANNEL = "aureom_events"


def _jsonable(v: Any) -> Any:
    if isinstance(v, uuid.UUID):
        return str(v)
    if isinstance(v, datetime):
        return v.isoformat()
    if isinstance(v, dict):
        return {k: _jsonable(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [_jsonable(x) for x in v]
    return v


def publish(db: Session, org_id: uuid.UUID, audience: str, type_: str, **payload: Any) -> None:
    db.add(AppEvent(org_id=org_id, audience=audience, type=type_, payload=_jsonable(payload), created_at=utcnow()))
    db.execute(text("SELECT pg_notify(:c, :p)"), {"c": CHANNEL, "p": str(org_id)})


def to_agent(db: Session, org_id: uuid.UUID, agent_id: uuid.UUID, type_: str, **payload: Any) -> None:
    publish(db, org_id, f"agent:{agent_id}", type_, **payload)


def to_supervisors(db: Session, org_id: uuid.UUID, type_: str, **payload: Any) -> None:
    publish(db, org_id, "role:supervisor", type_, **payload)


def timeline(db: Session, interaction, type_: str, source: str, *, actor_user_id: uuid.UUID | None = None,
             occurred_at: datetime | None = None, **data: Any) -> None:
    db.add(InteractionEvent(org_id=interaction.org_id, interaction_id=interaction.id, type=type_, source=source,
                            actor_user_id=actor_user_id, occurred_at=occurred_at or utcnow(), recorded_at=utcnow(),
                            data=_jsonable(data)))
    publish(db, interaction.org_id, f"interaction:{interaction.id}", "interaction.updated",
            interaction_id=interaction.id, event=type_)
    publish(db, interaction.org_id, "role:supervisor", "ops.changed", reason=type_)
