"""Provider health, disconnection handling and state reconciliation.

When the provider becomes unreachable:
  * the organisation's provider status becomes ``disconnected`` and every voice
    control is disabled in the UI and refused by the API;
  * outstanding ``requested`` controls become ``unknown`` (their confirmations
    may have been lost);
  * agents with live work are flagged ``reconcile_required``.

When it returns, the provider's *authoritative* call state is queried and
compared with ours. Differences are applied through synthetic, clearly
labelled events. Unknown controls are resolved by **observation only** – a
dial, transfer or hang-up with an unknown outcome is never re-sent.
"""
from __future__ import annotations

import uuid
from datetime import timedelta
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..adapters.telephony.base import NormalizedEvent, ProviderCallState
from ..adapters.telephony.registry import get_provider
from ..config import get_settings
from ..db import utcnow
from ..errors import ProviderUnavailable
from ..models import Agent, Call, CallControl, CallLeg, Interaction, ProviderConfig
from ..models.enums import AgentState, Presence
from . import agent_state, audit, calls, events, interactions, provider_events

DISCONNECT_AFTER_FAILURES = 2


def _cfg(db: Session, org_id: uuid.UUID) -> ProviderConfig:
    name = get_provider().name
    cfg = db.scalar(select(ProviderConfig).where(ProviderConfig.org_id == org_id, ProviderConfig.provider == name))
    if cfg is None:
        cfg = ProviderConfig(org_id=org_id, provider=name, enabled=True, public_settings={},
                             connection_status="unknown")
        db.add(cfg)
        db.flush()
    return cfg


def set_status(db: Session, cfg: ProviderConfig, status: str, reason: str) -> None:
    if cfg.connection_status == status:
        return
    prev = cfg.connection_status
    cfg.connection_status = status
    cfg.status_changed_at = utcnow()
    audit.record(db, action="provider.status_changed", org_id=cfg.org_id, actor_type="system",
                 target_type="provider", target_id=cfg.provider, details={"from": prev, "to": status, "reason": reason})
    events.publish(db, cfg.org_id, "org", "provider.status", provider=cfg.provider, status=status, previous=prev,
                   reason=reason)


def check_health(db: Session, org_id: uuid.UUID) -> str:
    cfg = _cfg(db, org_id)
    ok = get_provider().health()
    if ok:
        cfg.last_heartbeat_ok_at = utcnow()
        cfg.consecutive_failures = 0
        if cfg.connection_status in ("disconnected", "degraded", "unknown", "reconciling"):
            set_status(db, cfg, "reconciling", "provider reachable again")
            db.flush()
            try:
                summary = reconcile_org(db, org_id)
            except (ConnectionError, ProviderUnavailable) as exc:
                set_status(db, cfg, "degraded", f"reconciliation failed: {exc}")
                return cfg.connection_status
            set_status(db, cfg, "connected", f"reconciled: {summary}")
        return cfg.connection_status
    cfg.consecutive_failures += 1
    if cfg.consecutive_failures >= DISCONNECT_AFTER_FAILURES:
        if cfg.connection_status != "disconnected":
            set_status(db, cfg, "disconnected", "health checks failing")
            on_disconnected(db, org_id)
    elif cfg.connection_status == "connected":
        set_status(db, cfg, "degraded", "health check failed")
    return cfg.connection_status


def on_disconnected(db: Session, org_id: uuid.UUID) -> None:
    for ctl in db.scalars(select(CallControl).where(CallControl.org_id == org_id, CallControl.status == "requested")):
        ctl.status = "unknown"
        ctl.error_code = "PROVIDER_DISCONNECTED"
        it = db.get(Interaction, ctl.interaction_id)
        it.needs_reconciliation = True
    busy = [AgentState.CALL_OFFERED, AgentState.CONNECTING, AgentState.ON_INTERACTION, AgentState.AFTER_CALL_WORK,
            AgentState.AVAILABLE]
    for agent in db.scalars(select(Agent).where(Agent.org_id == org_id, Agent.state.in_(busy))):
        agent_state.mark_reconcile(db, agent, "telephony provider disconnected")
    for it in db.scalars(select(Interaction).where(Interaction.org_id == org_id, Interaction.channel == "voice",
                                                  Interaction.status.in_(["connecting", "active", "queued", "offered"]))):
        it.needs_reconciliation = True


def _synthetic(db: Session, call: Call, type_: str, *, leg_id: str | None = None, request_id: str | None = None,
               **data: Any) -> dict[str, Any]:
    ev = NormalizedEvent(provider_event_id=f"reconcile:{uuid.uuid4().hex}", type=type_, occurred_at=utcnow(),
                         provider_call_id=call.provider_call_id, provider_leg_id=leg_id, sequence=None,
                         request_id=request_id, data={**data, "synthetic": True, "source": "reconciliation"})
    token = calls.resolution_source.set("reconciliation")
    try:
        return provider_events.process(db, call.provider, ev)
    finally:
        calls.resolution_source.reset(token)


def reconcile_call(db: Session, call: Call, state: ProviderCallState | None) -> list[str]:
    changes: list[str] = []
    it = db.get(Interaction, call.interaction_id)
    local_legs = {lg.provider_leg_id: lg for lg in db.scalars(select(CallLeg).where(CallLeg.call_id == call.id))}
    pending = db.scalars(select(CallControl).where(CallControl.call_id == call.id,
                                                   CallControl.status.in_(["requested", "unknown"]))).all()
    if state is not None:
        for pl in state.legs:
            lg = local_legs.get(pl.provider_leg_id)
            if lg is None:
                continue
            if pl.status == "answered" and lg.status in ("initiated", "ringing"):
                ctl = next((c for c in pending if c.action == "answer" and c.leg_id in (None, lg.id)), None)
                _synthetic(db, call, "leg.answered", leg_id=lg.provider_leg_id, leg_type=lg.leg_type,
                           identity=pl.identity, request_id=str(ctl.id) if ctl and lg.leg_type == "agent" else None)
                changes.append(f"leg {lg.leg_type} answered")
            if pl.status == "answered" and pl.on_hold != lg.on_hold:
                ctl = next((c for c in pending if c.action == ("hold" if pl.on_hold else "resume")), None)
                _synthetic(db, call, "leg.held" if pl.on_hold else "leg.resumed", leg_id=lg.provider_leg_id,
                           leg_type=lg.leg_type, request_id=str(ctl.id) if ctl else None)
                changes.append(f"{lg.leg_type} hold={pl.on_hold}")
            if pl.status == "answered" and pl.muted != lg.provider_muted:
                ctl = next((c for c in pending if c.action == ("mute" if pl.muted else "unmute")), None)
                _synthetic(db, call, "leg.muted" if pl.muted else "leg.unmuted", leg_id=lg.provider_leg_id,
                           request_id=str(ctl.id) if ctl else None)
                changes.append(f"mute={pl.muted}")
            if pl.status in ("completed", "failed", "rejected") and lg.status not in ("completed", "failed", "rejected"):
                if lg.leg_type == "consult" and pl.status in ("failed", "rejected"):
                    _synthetic(db, call, "transfer.failed", leg_id=lg.provider_leg_id, reason="observed_failed",
                               behaviour="return_to_original")
                lg.status = pl.status
                lg.ended_at = utcnow()
                lg.end_reason = "observed_by_reconciliation"
                changes.append(f"leg {lg.leg_type} {pl.status}")
        # Transfer completion observed: the consult leg is now the only live agent leg.
        ts = it.transfer_state or {}
        ctl_tc = next((c for c in pending if c.action == "warm_transfer_complete"), None)
        if ctl_tc and ts.get("consult_leg_id"):
            cleg = db.get(CallLeg, uuid.UUID(ts["consult_leg_id"]))
            prov = next((p for p in state.legs if cleg and p.provider_leg_id == cleg.provider_leg_id), None)
            old_live = [p for p in state.legs if p.leg_type == "agent" and p.status == "answered"]
            if prov and prov.status == "answered" and not old_live:
                _synthetic(db, call, "transfer.completed", leg_id=cleg.provider_leg_id, mode="warm",
                           request_id=str(ctl_tc.id))
                changes.append("warm transfer completed")
    ended = state is None or state.status in ("completed", "failed")
    if ended and call.status == "in_progress":
        ctl_end = next((c for c in pending if c.action == "end"), None)
        _synthetic(db, call, "call.completed", end_reason=(state.end_reason if state else "not_found_at_provider")
                   or "observed_completed", request_id=str(ctl_end.id) if ctl_end else None)
        changes.append("call completed")
    # Whatever is still pending was not observed at the provider: mark failed (not applied) – never re-send.
    in_flight_cutoff = utcnow() - timedelta(seconds=10)
    for ctl in db.scalars(select(CallControl).where(CallControl.call_id == call.id,
                                                    CallControl.status.in_(["requested", "unknown"]))):
        if ctl.status == "requested" and ctl.requested_at > in_flight_cutoff and not ended:
            continue  # still legitimately in flight
        observed_ok = False
        if ctl.action == "end" and (ended or call.status == "completed"):
            observed_ok = True
        if observed_ok:
            calls.ack(db, str(ctl.id), ok=True, resolved_by="reconciliation")
        else:
            ctl.status = "failed"
            ctl.resolved_by = "reconciliation"
            ctl.error_code = ctl.error_code or "NOT_OBSERVED_AT_PROVIDER"
            ctl.error_message = "Provider state does not show this change; it was not re-sent."
            if ctl.action == "answer" and ctl.agent_id:
                interactions.connect_failed(db, it, db.get(Agent, ctl.agent_id), reason="not_observed_at_provider")
        changes.append(f"control {ctl.action} -> {ctl.status} (reconciliation)")
    it.needs_reconciliation = False
    if changes:
        events.timeline(db, it, "reconciled", "system", changes=changes,
                        note="State corrected from the provider's authoritative call state.")
    return changes


def reconcile_org(db: Session, org_id: uuid.UUID) -> str:
    provider = get_provider()
    try:
        active = {c.provider_call_id: c for c in provider.list_active_calls()}
    except ConnectionError as exc:
        raise ProviderUnavailable(str(exc)) from exc
    n_calls = 0
    for call in db.scalars(select(Call).where(Call.org_id == org_id, Call.status == "in_progress")).all():
        state = active.get(call.provider_call_id) or provider.get_call_state(call.provider_call_id)
        reconcile_call(db, call, state)
        n_calls += 1
    for it in db.scalars(select(Interaction).where(Interaction.org_id == org_id,
                                                  Interaction.needs_reconciliation.is_(True))):
        it.needs_reconciliation = False
    n_agents = 0
    for agent in db.scalars(select(Agent).where(Agent.org_id == org_id, Agent.reconcile_required.is_(True))).all():
        if reconcile_agent(db, agent, query_provider=False)["cleared"]:
            n_agents += 1
    return f"{n_calls} live call(s) checked, {n_agents} agent(s) cleared"


def reconcile_agent(db: Session, agent: Agent, *, query_provider: bool = True) -> dict[str, Any]:
    """Compare this agent's call state with the provider; clear the flag only when consistent."""
    provider = get_provider()
    cfg = _cfg(db, agent.org_id)
    if cfg.connection_status == "disconnected":
        raise ProviderUnavailable("Provider disconnected; cannot reconcile yet")
    changes: list[str] = []
    if query_provider:
        call_ids = {lg.call_id for lg in db.scalars(select(CallLeg).where(
            CallLeg.agent_id == agent.id, CallLeg.status.in_(["initiated", "ringing", "answered", "held"])))}
        if agent.current_interaction_id:
            c = interactions.primary_call(db, agent.current_interaction_id)
            if c:
                call_ids.add(c.id)
        for cid in call_ids:
            call = db.get(Call, cid)
            if call.status != "in_progress":
                continue
            state = provider.get_call_state(call.provider_call_id)
            if state is None and not provider.health():
                raise ProviderUnavailable("Provider state query failed")
            changes += reconcile_call(db, call, state)
    conflicts = agent_state.conflicting_call_state(db, agent)
    live_work = agent.state in (AgentState.CONNECTING, AgentState.ON_INTERACTION, AgentState.AFTER_CALL_WORK,
                                AgentState.CALL_OFFERED)
    unresolved = db.scalar(select(CallControl.id).where(CallControl.agent_id == agent.id,
                                                        CallControl.status.in_(["unknown"])).limit(1))
    cleared = False
    if unresolved is None and (not conflicts or live_work):
        # Live work that matches provider state is consistent; idle with no live legs is consistent.
        agent.reconcile_required = False
        agent.reconcile_reason = None
        cleared = True
        events.to_agent(db, agent.org_id, agent.id, "agent.reconciled", changes=changes)
        events.to_supervisors(db, agent.org_id, "agent.reconciled", agent_id=agent.id)
    return {"cleared": cleared, "changes": changes, "conflicts": conflicts, "state": agent.state}


def sweep_presence(db: Session) -> int:
    grace = timedelta(seconds=get_settings().presence_grace_seconds)
    n = 0
    for agent in db.scalars(select(Agent).where(Agent.presence == Presence.ONLINE,
                                                Agent.presence_last_seen < utcnow() - grace)):
        agent.presence = Presence.OFFLINE
        n += 1
        events.to_supervisors(db, agent.org_id, "agent.presence", agent_id=agent.id, presence="offline")
        if agent.state == AgentState.AVAILABLE:
            agent_state.transition(db, agent, AgentState.UNAVAILABLE, reason="application_disconnected", source="system")
        elif agent.state in (AgentState.CALL_OFFERED, AgentState.CONNECTING, AgentState.ON_INTERACTION):
            agent_state.mark_reconcile(db, agent, "application disconnected during work")
    return n
