"""Human-readable reference numbers (atomic per organisation counter)."""
from __future__ import annotations

import uuid

from sqlalchemy import text
from sqlalchemy.orm import Session

PREFIX = {"interaction": ("INT", 100000), "case": ("CASE", 10000), "callback": ("CB", 1000), "customer": ("PCS", 100)}


def next_ref(db: Session, org_id: uuid.UUID, name: str) -> str:
    prefix, start = PREFIX[name]
    value = db.execute(
        text(
            "INSERT INTO counters (id, org_id, name, value) VALUES (:id, :org, :name, :start) "
            "ON CONFLICT (org_id, name) DO UPDATE SET value = counters.value + 1 RETURNING value"
        ),
        {"id": uuid.uuid4(), "org": org_id, "name": name, "start": start + 1},
    ).scalar_one()
    return f"{prefix}-{value}"
