"""Quality assurance and supervisor monitoring.

QA: people score interactions against a documented, versioned rubric. The
score formula is published with the rubric; agents can acknowledge or
dispute; disputes trigger a re-review that keeps the history. AI is never
used to produce a score.

Monitoring: listen / coach (barge only where the provider supports it) is
permission-gated, requires a reason, is audited, and the agent is always
notified in their workspace. There is no covert mode.
"""
from __future__ import annotations

import random
import uuid
from datetime import timedelta
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..adapters.telephony.registry import get_provider
from ..db import utcnow
from ..errors import Forbidden, InvalidTransition, NotFound, Unsupported, ValidationFailed
from ..models import (AgentParticipation, Interaction, MonitoringSession, Organisation, QaReview, QaRubric)
from . import audit, events
from .interactions import primary_call


def active_rubric(db: Session, org_id: uuid.UUID) -> QaRubric:
    r = db.scalar(select(QaRubric).where(QaRubric.org_id == org_id, QaRubric.status == "active")
                  .order_by(QaRubric.version.desc()))
    if r is None:
        raise NotFound("No active QA rubric")
    return r


def score(rubric: QaRubric, scores: dict[str, dict[str, Any]]) -> float:
    total = 0.0
    maximum = 0.0
    for c in rubric.criteria:
        entry = scores.get(c["id"])
        if entry is None:
            raise ValidationFailed(f"Missing score for criterion '{c['id']}'")
        s = entry.get("score")
        if s not in c["scale"]:
            raise ValidationFailed(f"Score for '{c['id']}' must be one of {c['scale']}")
        if not str(entry.get("evidence", "")).strip():
            raise ValidationFailed(f"Evidence is required for criterion '{c['id']}'")
        total += s * c["weight"]
        maximum += max(c["scale"]) * c["weight"]
    return round(total / maximum * 100, 1)


def sample(db: Session, org_id: uuid.UUID, rate: float = 0.15, seed: int | None = None) -> int:
    """Queue reviews: every complaint-related contact plus a random sample (documented, reproducible)."""
    rubric = active_rubric(db, org_id)
    since = utcnow() - timedelta(days=7)
    reviewed = select(QaReview.interaction_id)
    rows = db.execute(select(Interaction, AgentParticipation).join(
        AgentParticipation, AgentParticipation.interaction_id == Interaction.id).where(
        Interaction.org_id == org_id, Interaction.status == "completed", Interaction.channel == "voice",
        Interaction.created_at > since, Interaction.id.notin_(reviewed), AgentParticipation.connected_at.is_not(None))
        .order_by(Interaction.created_at)).all()
    rng = random.Random(seed if seed is not None else int(utcnow().strftime("%Y%m%d")))
    n = 0
    seen: set[uuid.UUID] = set()
    for it, part in rows:
        if it.id in seen:
            continue
        reason = None
        if it.disposition_code in ("complaint_logged", "escalated"):
            reason = "all_complaints_and_escalations"
        elif rng.random() < rate:
            reason = "random_sample"
        if reason:
            db.add(QaReview(org_id=org_id, interaction_id=it.id, agent_id=part.agent_id, rubric_id=rubric.id,
                            rubric_version=rubric.version, status="queued", selection_reason=reason, scores={},
                            history=[]))
            seen.add(it.id)
            n += 1
    return n


def submit(db: Session, p, rev: QaReview, scores: dict[str, dict[str, Any]], comments: str) -> QaReview:
    if rev.status not in ("queued", "in_progress", "disputed"):
        raise InvalidTransition(f"Review is {rev.status}")
    if rev.agent_id == p.agent_id:
        raise Forbidden("You cannot review your own interaction")
    rubric = db.get(QaRubric, rev.rubric_id)
    pct = score(rubric, scores)
    if rev.status == "disputed":
        rev.history = [*rev.history, {"at": utcnow().isoformat(), "previous_total": rev.total_percent,
                                      "previous_scores": rev.scores, "dispute_note": rev.dispute_note,
                                      "reviewer": str(rev.reviewer_user_id)}]
        rev.status = "revised"
    else:
        rev.status = "submitted"
    rev.scores = scores
    rev.total_percent = pct
    rev.comments = comments
    rev.reviewer_user_id = p.user_id
    rev.submitted_at = utcnow()
    events.to_agent(db, rev.org_id, rev.agent_id, "qa.review_submitted", review_id=rev.id)
    return rev


def agent_response(db: Session, p, rev: QaReview, action: str, note: str | None) -> QaReview:
    if rev.agent_id != p.agent_id:
        raise Forbidden("Only the reviewed agent can respond")
    if rev.status not in ("submitted", "revised"):
        raise InvalidTransition("Nothing to respond to")
    if action == "acknowledge":
        rev.status = "acknowledged"
        rev.agent_acknowledged_at = utcnow()
    elif action == "dispute":
        if not note or len(note.strip()) < 5:
            raise ValidationFailed("Explain the dispute")
        rev.status = "disputed"
        rev.dispute_note = note
    else:
        raise ValidationFailed("action must be acknowledge or dispute")
    return rev


# --------------------------------------------------------------------------- monitoring

def start_monitoring(db: Session, p, it: Interaction, mode: str, reason: str) -> MonitoringSession:
    perm = {"listen": "monitoring.listen", "coach": "monitoring.coach", "barge": "monitoring.coach"}.get(mode)
    if perm is None:
        raise ValidationFailed("mode must be listen, coach or barge")
    p.require(perm)
    org = db.get(Organisation, p.org_id)
    if not org.settings.get("monitoring_enabled", False):
        raise Forbidden("Monitoring is not enabled for this organisation", code="MONITORING_DISABLED")
    if not reason or len(reason.strip()) < 5:
        raise ValidationFailed("A reason is required for monitoring", code="REASON_REQUIRED")
    caps = get_provider().capabilities()
    if not getattr(caps, f"monitoring_{mode}"):
        raise Unsupported(f"Provider does not support '{mode}' monitoring; it is disabled")
    if it.status != "active" or it.owner_agent_id is None:
        raise InvalidTransition("Only active calls can be monitored")
    call = primary_call(db, it.id)
    ms = MonitoringSession(org_id=it.org_id, interaction_id=it.id, supervisor_user_id=p.user_id,
                           agent_id=it.owner_agent_id, mode=mode, reason=reason, status="requested",
                           agent_notified=True, started_at=utcnow())
    db.add(ms)
    db.flush()
    audit.by_principal(db, p, "monitoring.started", "interaction", it.id, mode=mode, reason=reason,
                       agent_id=str(it.owner_agent_id))
    events.to_agent(db, it.org_id, it.owner_agent_id, "monitoring.requested", interaction_id=it.id, mode=mode,
                    supervisor=p.display_name)
    events.timeline(db, it, "monitoring.requested", "supervisor", actor_user_id=p.user_id, mode=mode,
                    supervisor=p.display_name, agent_notified=True)
    db.commit()
    res = get_provider().start_monitoring(call.provider_call_id, f"supervisor:{p.user_id}", mode,
                                          request_id=f"monitor:{ms.id}")
    if res.outcome != "accepted":
        ms.status = "failed"
    return ms


def stop_monitoring(db: Session, p, ms: MonitoringSession) -> MonitoringSession:
    if ms.supervisor_user_id != p.user_id and not p.has("monitoring.coach"):
        raise Forbidden("Not your monitoring session")
    if ms.status not in ("active", "requested"):
        return ms
    call = primary_call(db, ms.interaction_id)
    if ms.provider_leg_id and call:
        get_provider().stop_monitoring(call.provider_call_id, ms.provider_leg_id, request_id=f"monitor-stop:{ms.id}")
    ms.status = "ended"
    ms.ended_at = utcnow()
    audit.by_principal(db, p, "monitoring.ended", "interaction", ms.interaction_id)
    events.to_agent(db, ms.org_id, ms.agent_id, "monitoring.ended", interaction_id=ms.interaction_id)
    return ms


def review_view(db: Session, r: QaReview) -> dict[str, Any]:
    it = db.get(Interaction, r.interaction_id)
    return {"id": r.id, "interaction_id": r.interaction_id, "interaction_reference": it.reference if it else None,
            "agent_id": r.agent_id, "rubric_id": r.rubric_id, "rubric_version": r.rubric_version, "status": r.status,
            "selection_reason": r.selection_reason, "scores": r.scores, "total_percent": r.total_percent,
            "comments": r.comments, "reviewer_user_id": r.reviewer_user_id, "submitted_at": r.submitted_at,
            "agent_acknowledged_at": r.agent_acknowledged_at, "dispute_note": r.dispute_note, "history": r.history,
            "ai_assisted": r.ai_assisted,
            "interpretation": "Score against the published rubric for this one interaction. Not a measure of "
                              "overall performance."}


def queue_counts(db: Session, org_id: uuid.UUID) -> dict[str, int]:
    return dict(db.execute(select(QaReview.status, func.count()).where(QaReview.org_id == org_id)
                           .group_by(QaReview.status)).all())
