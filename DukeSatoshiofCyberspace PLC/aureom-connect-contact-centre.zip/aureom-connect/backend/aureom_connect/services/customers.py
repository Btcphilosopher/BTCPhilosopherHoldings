"""Customer matching and verification.

* An inbound number is only a *hint*: matching returns candidates with reasons.
* Selecting a candidate does not verify them. Restricted data and sensitive
  actions require a ``verified`` verification on an interaction the agent owns.
* Records are never merged automatically; possible duplicates are flagged for
  back-office review.
"""
from __future__ import annotations

import uuid
from typing import Any

import phonenumbers
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ..db import utcnow
from ..errors import Forbidden, NotFound, ValidationFailed, VerificationRequired
from ..models import (Account, CommunicationPreference, Consent, ContactPoint, Customer, CustomerRestricted,
                      CustomerSecret, Interaction, Objection, PossibleDuplicate, SourceSystemRef, Task,
                      Verification, VerificationPolicy)
from ..security.crypto import verify_secret_value
from . import events

FACTOR_LABELS = {
    "date_of_birth": "Date of birth",
    "postcode": "Postcode",
    "account_last4": "Last four digits of account number",
    "security_word": "Security word",
}


def normalise_phone(raw: str | None, region: str = "GB") -> str | None:
    if not raw:
        return None
    try:
        num = phonenumbers.parse(raw, region)
    except phonenumbers.NumberParseException:
        return None
    if not phonenumbers.is_valid_number(num):
        return None
    return phonenumbers.format_number(num, phonenumbers.PhoneNumberFormat.E164)


def normalise_answer(factor: str, answer: str) -> str:
    """Bring a spoken/typed answer into the stored canonical form (dates as ISO YYYY-MM-DD)."""
    if factor != "date_of_birth":
        return answer
    from datetime import datetime as _dt

    text = " ".join(answer.strip().replace(",", " ").split())
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y", "%d %m %Y", "%d %B %Y", "%d %b %Y", "%d/%m/%y"):
        try:
            return _dt.strptime(text, fmt).date().isoformat()
        except ValueError:
            continue
    return answer


def mask_phone(e164: str) -> str:
    return e164[:4] + "•" * max(0, len(e164) - 7) + e164[-3:] if len(e164) > 7 else "•••"


def match_by_phone(db: Session, org_id: uuid.UUID, raw: str | None) -> list[dict[str, Any]]:
    norm = normalise_phone(raw)
    if not norm:
        return []
    rows = db.execute(select(ContactPoint, Customer).join(Customer, Customer.id == ContactPoint.customer_id).where(
        ContactPoint.org_id == org_id, ContactPoint.kind == "phone", ContactPoint.normalized == norm)).all()
    out = []
    for cp, cust in rows:
        reasons = [f"Caller number matches {cp.label or 'a'} phone on record"]
        if cp.is_primary:
            reasons.append("number is the primary contact")
        if cp.verified_at:
            reasons.append("number was previously verified")
        shared = sum(1 for c, _ in rows if c.normalized == norm) > 1
        if shared:
            reasons.append("number is shared by more than one customer record")
        out.append({"customer_id": cust.id, "customer_ref": cust.customer_ref, "display_name": cust.display_name,
                    "match_reasons": reasons, "strength": "hint", "shared_number": shared})
    return out


def search(db: Session, org_id: uuid.UUID, q: str, limit: int = 20) -> list[Customer]:
    like = f"%{q.strip()}%"
    norm = normalise_phone(q)
    cond = [Customer.display_name.ilike(like), Customer.customer_ref.ilike(like)]
    if norm:
        sub = select(ContactPoint.customer_id).where(ContactPoint.normalized == norm)
        cond.append(Customer.id.in_(sub))
    email_sub = select(ContactPoint.customer_id).where(ContactPoint.kind == "email",
                                                       ContactPoint.normalized.ilike(like.lower()))
    cond.append(Customer.id.in_(email_sub))
    return list(db.scalars(select(Customer).where(Customer.org_id == org_id, or_(*cond))
                           .order_by(Customer.display_name).limit(limit)))


def active_policy(db: Session, org_id: uuid.UUID) -> VerificationPolicy:
    pol = db.scalar(select(VerificationPolicy).where(VerificationPolicy.org_id == org_id,
                                                     VerificationPolicy.active.is_(True)))
    if pol is None:
        raise ValidationFailed("No verification policy configured")
    return pol


def verification_for(db: Session, interaction_id: uuid.UUID, customer_id: uuid.UUID) -> Verification | None:
    return db.scalar(select(Verification).where(Verification.interaction_id == interaction_id,
                                                Verification.customer_id == customer_id)
                     .order_by(Verification.started_at.desc()).limit(1))


def is_verified_context(db: Session, agent_id: uuid.UUID | None, customer_id: uuid.UUID,
                        interaction_id: uuid.UUID | None) -> bool:
    if agent_id is None or interaction_id is None:
        return False
    it = db.get(Interaction, interaction_id)
    if it is None or it.customer_id != customer_id or it.owner_agent_id != agent_id:
        return False
    if it.status not in ("active", "wrap_up", "connecting"):
        return False
    v = verification_for(db, interaction_id, customer_id)
    return bool(v and v.status == "verified")


def require_verified(db: Session, agent_id: uuid.UUID | None, customer_id: uuid.UUID,
                     interaction_id: uuid.UUID | None, action: str) -> None:
    if not is_verified_context(db, agent_id, customer_id, interaction_id):
        raise VerificationRequired(f"Customer verification is required before: {action}",
                                   details={"action": action, "customer_id": str(customer_id)})


def select_candidate(db: Session, it: Interaction, customer_id: uuid.UUID, agent_id: uuid.UUID,
                     actor_user_id: uuid.UUID) -> None:
    if it.owner_agent_id != agent_id:
        raise Forbidden("Only the owning agent can identify the customer")
    cust = db.get(Customer, customer_id)
    if cust is None or cust.org_id != it.org_id:
        raise NotFound("Customer not found")
    if it.customer_id and it.customer_id != customer_id:
        events.timeline(db, it, "customer.reselected", "agent", actor_user_id=actor_user_id,
                        previous=str(it.customer_id), selected=str(customer_id))
    it.customer_id = customer_id
    it.customer_match_status = "selected_unverified"
    it.version += 1
    events.timeline(db, it, "customer.selected", "agent", actor_user_id=actor_user_id, customer=cust.customer_ref,
                    note="Selected as probable match; not yet verified.")


def verify(db: Session, it: Interaction, agent_id: uuid.UUID, answers: dict[str, str],
           actor_user_id: uuid.UUID) -> dict[str, Any]:
    """Check the customer's answers against stored hashes. Answers are never stored or logged."""
    if it.owner_agent_id != agent_id:
        raise Forbidden("Only the owning agent can verify the customer")
    if not it.customer_id:
        raise ValidationFailed("Select the customer record before verification")
    pol = active_policy(db, it.org_id)
    v = verification_for(db, it.id, it.customer_id)
    if v is None:
        v = Verification(org_id=it.org_id, interaction_id=it.id, customer_id=it.customer_id, agent_id=agent_id,
                         policy_id=pol.id, status="in_progress", passed_factors=[], started_at=utcnow())
        db.add(v)
        db.flush()
    if v.status in ("verified", "locked"):
        return _verification_view(v, pol, {})
    secrets = {s.factor: s for s in db.scalars(select(CustomerSecret).where(CustomerSecret.customer_id == it.customer_id))}
    results: dict[str, bool] = {}
    for factor, answer in answers.items():
        if factor not in pol.factors:
            raise ValidationFailed(f"Factor not permitted by policy: {factor}")
        secret = secrets.get(factor)
        ok = bool(secret and answer and verify_secret_value(secret.value_hash, normalise_answer(factor, answer)))
        results[factor] = ok
        if ok and factor not in v.passed_factors:
            v.passed_factors = [*v.passed_factors, factor]
        if not ok:
            v.failed_attempts += 1
    if len(v.passed_factors) >= pol.required_passes:
        v.status = "verified"
        v.completed_at = utcnow()
        it.customer_match_status = "verified"
        it.version += 1
    elif v.failed_attempts >= pol.max_failures:
        v.status = "locked"
        v.completed_at = utcnow()
    events.timeline(db, it, "customer.verification", "agent", actor_user_id=actor_user_id, status=v.status,
                    factors_checked=sorted(results), passed=sorted(k for k, ok in results.items() if ok),
                    failed=sorted(k for k, ok in results.items() if not ok))
    return _verification_view(v, pol, results)


def _verification_view(v: Verification, pol: VerificationPolicy, results: dict[str, bool]) -> dict[str, Any]:
    return {"status": v.status, "passed_factors": v.passed_factors, "failed_attempts": v.failed_attempts,
            "required_passes": pol.required_passes, "max_failures": pol.max_failures, "last_results": results,
            "available_factors": [{"code": f, "label": FACTOR_LABELS.get(f, f)} for f in pol.factors]}


def verification_status(db: Session, it: Interaction) -> dict[str, Any] | None:
    if not it.customer_id:
        return None
    pol = active_policy(db, it.org_id)
    v = verification_for(db, it.id, it.customer_id)
    if v is None:
        return {"status": "unverified", "passed_factors": [], "failed_attempts": 0,
                "required_passes": pol.required_passes, "max_failures": pol.max_failures, "last_results": {},
                "available_factors": [{"code": f, "label": FACTOR_LABELS.get(f, f)} for f in pol.factors]}
    return _verification_view(v, pol, {})


def customer_view(db: Session, cust: Customer, *, verified: bool) -> dict[str, Any]:
    cps = db.scalars(select(ContactPoint).where(ContactPoint.customer_id == cust.id)).all()
    acc = db.get(Account, cust.account_id) if cust.account_id else None
    view: dict[str, Any] = {
        "id": cust.id, "customer_ref": cust.customer_ref, "display_name": cust.display_name, "kind": cust.kind,
        "preferred_language": cust.preferred_language, "timezone": cust.timezone, "status": cust.status,
        "support_flags": cust.support_flags, "version": cust.version,
        "account": {"id": acc.id, "account_ref": acc.account_ref, "name": acc.name} if acc else None,
        "contact_points": [{"id": c.id, "kind": c.kind, "label": c.label, "is_primary": c.is_primary,
                            "value": c.value if verified else (mask_phone(c.normalized) if c.kind == "phone"
                                                               else c.value[:2] + "•••" if c.kind == "email"
                                                               else "••••"),
                            "verified_at": c.verified_at} for c in cps],
        "preferences": [{"channel": p.channel, "purpose": p.purpose, "allowed": p.allowed,
                         "preferred_window": p.preferred_window}
                        for p in db.scalars(select(CommunicationPreference).where(
                            CommunicationPreference.customer_id == cust.id))],
        "consents": [{"id": c.id, "purpose": c.purpose, "basis": c.basis, "status": c.status, "source": c.source,
                      "captured_at": c.captured_at, "withdrawn_at": c.withdrawn_at, "jurisdiction": c.jurisdiction}
                     for c in db.scalars(select(Consent).where(Consent.customer_id == cust.id))],
        "objections": [{"id": o.id, "scope": o.scope, "source": o.source, "recorded_at": o.recorded_at,
                        "active": o.active, "note": o.note}
                       for o in db.scalars(select(Objection).where(Objection.customer_id == cust.id))],
        "source_refs": [{"system": s.system, "external_id": s.external_id, "synced_at": s.synced_at}
                        for s in db.scalars(select(SourceSystemRef).where(SourceSystemRef.customer_id == cust.id))],
        "restricted": None,
        "restricted_access": "verified" if verified else "withheld_until_verified",
    }
    if verified:
        r = db.scalar(select(CustomerRestricted).where(CustomerRestricted.customer_id == cust.id))
        view["restricted"] = r.data if r else {}
    return view


def flag_possible_duplicate(db: Session, org_id: uuid.UUID, a: uuid.UUID, b: uuid.UUID, reason: str,
                            raised_by: uuid.UUID) -> PossibleDuplicate:
    if a == b:
        raise ValidationFailed("Cannot flag a record as a duplicate of itself")
    dup = PossibleDuplicate(org_id=org_id, customer_a_id=a, customer_b_id=b, reason=reason, raised_by=raised_by,
                            raised_at=utcnow())
    db.add(dup)
    db.add(Task(org_id=org_id, kind="duplicate_review", title="Review possible duplicate customer records",
                description=f"Raised by an agent: {reason}. Records are not merged automatically.",
                customer_id=a, priority="normal"))
    return dup


def record_objection(db: Session, org_id: uuid.UUID, customer_id: uuid.UUID, scope: str, source: str, note: str,
                     by: uuid.UUID) -> Objection:
    o = Objection(org_id=org_id, customer_id=customer_id, scope=scope, source=source, note=note, recorded_by=by,
                  recorded_at=utcnow(), active=True)
    db.add(o)
    return o
