"""Workforce scheduling and transparent demand forecasting.

* Published schedules are immutable except through an approved shift-change
  request; nothing changes a published shift to "fit" a forecast.
* Forecast method (documented): for each 30-minute interval of the target
  day, take the same weekday and interval over the previous N weeks of
  observed demand; expected = mean; 80 % range = mean ± 1.2816·σ (normal
  approximation, floored at 0), also reporting the observed min–max.
* Required agents use Erlang C for the queue's answer target, with average
  handling time from the same history and a configurable shrinkage.
* Forecasts are stored separately from observed demand and labelled.
"""
from __future__ import annotations

import math
import statistics
import uuid
from datetime import date, datetime, time, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import utcnow
from ..errors import Forbidden, InvalidTransition, ValidationFailed
from ..models import (Agent, AgentAvailability, Forecast, LeaveRequest, ObservedDemand, Queue, QueueEntry,
                      Schedule, Shift, ShiftChangeRequest, SlaPolicy)
from . import audit, events

UK = ZoneInfo("Europe/London")


# --------------------------------------------------------------------------- Erlang C

def erlang_c(traffic_erlangs: float, agents: int) -> float:
    """Probability a contact waits (Erlang C)."""
    if agents <= traffic_erlangs:
        return 1.0
    s = sum(traffic_erlangs ** k / math.factorial(k) for k in range(agents))
    top = traffic_erlangs ** agents / math.factorial(agents) * agents / (agents - traffic_erlangs)
    return top / (s + top)


def required_agents(calls: float, aht_seconds: float, interval_seconds: int, target_seconds: int,
                    target_pct: float, shrinkage: float = 0.3, max_agents: int = 200) -> int:
    if calls <= 0:
        return 0
    a = calls * aht_seconds / interval_seconds
    for n in range(max(1, math.ceil(a)), max_agents):
        pw = erlang_c(a, n)
        sl = 1 - pw * math.exp(-(n - a) * target_seconds / aht_seconds)
        if sl >= target_pct:
            return math.ceil(n / (1 - shrinkage))
    return max_agents


# --------------------------------------------------------------------------- forecast

def generate_forecast(db: Session, org_id: uuid.UUID, queue: Queue, target: date, *, weeks: int = 6,
                      shrinkage: float = 0.3, by: uuid.UUID | None = None) -> Forecast:
    pol = db.get(SlaPolicy, queue.sla_policy_id) if queue.sla_policy_id else None
    tgt_s = pol.target_seconds if pol else 20
    tgt_pct = (pol.target_percent or 80) / 100 if pol else 0.8
    intervals = []
    for slot in range(48):
        st_local = datetime.combine(target, time(slot // 2, 30 * (slot % 2)), UK)
        hist: list[int] = []
        aht: list[float] = []
        for w in range(1, weeks + 1):
            past = st_local - timedelta(weeks=w)
            rows = db.scalars(select(ObservedDemand).where(ObservedDemand.queue_id == queue.id,
                                                           ObservedDemand.interval_start == past)).all()
            if rows:
                hist.append(sum(r.offered for r in rows))
                aht += [r.avg_handle_seconds for r in rows if r.avg_handle_seconds]
        if not hist:
            continue
        mean = statistics.mean(hist)
        sd = statistics.pstdev(hist) if len(hist) > 1 else 0.0
        handle = statistics.mean(aht) if aht else 300.0
        intervals.append({"start": st_local.isoformat(), "expected": round(mean, 2),
                          "lower_80": round(max(0.0, mean - 1.2816 * sd), 2), "upper_80": round(mean + 1.2816 * sd, 2),
                          "observed_min": min(hist), "observed_max": max(hist), "n_weeks": len(hist),
                          "aht_seconds": round(handle),
                          "required_agents": required_agents(mean, handle, 1800, tgt_s, tgt_pct, shrinkage),
                          "required_agents_upper": required_agents(mean + 1.2816 * sd, handle, 1800, tgt_s, tgt_pct,
                                                                   shrinkage)})
    fc = Forecast(org_id=org_id, queue_id=queue.id, target_date=target, method="same_weekday_interval_mean",
                  parameters={"weeks": weeks, "interval_minutes": 30, "shrinkage": shrinkage,
                              "service_target": {"seconds": tgt_s, "percent": tgt_pct * 100},
                              "range": "80% normal approximation (mean ± 1.2816σ), floored at 0"},
                  intervals=intervals, generated_at=utcnow(), generated_by=by,
                  notes="Forecast, not observed demand. History includes imported synthetic data in the demo.")
    db.add(fc)
    db.flush()
    return fc


def observed_today(db: Session, queue: Queue, day: date) -> dict[str, int]:
    start = datetime.combine(day, time(0), UK)
    out: dict[str, int] = {}
    for qe in db.scalars(select(QueueEntry).where(QueueEntry.queue_id == queue.id, QueueEntry.sequence == 1,
                                                  QueueEntry.entered_at >= start,
                                                  QueueEntry.entered_at < start + timedelta(days=1))):
        loc = qe.entered_at.astimezone(UK)
        key = datetime.combine(day, time(loc.hour, 30 if loc.minute >= 30 else 0), UK).isoformat()
        out[key] = out.get(key, 0) + 1
    return out


# --------------------------------------------------------------------------- schedules

def _on_duty(shift: Shift, at: datetime) -> bool:
    if not (shift.start_at <= at < shift.end_at):
        return False
    for act in shift.activities or []:
        if datetime.fromisoformat(act["start"]) <= at < datetime.fromisoformat(act["end"]):
            return False
    return True


def staffing(db: Session, org_id: uuid.UUID, queue: Queue, day: date, forecast: Forecast | None) -> list[dict[str, Any]]:
    start = datetime.combine(day, time(0), UK)
    shifts = db.execute(select(Shift, Schedule).join(Schedule, Schedule.id == Shift.schedule_id).where(
        Shift.org_id == org_id, Shift.start_at < start + timedelta(days=1), Shift.end_at > start,
        Schedule.status == "published")).all()
    fc = {i["start"]: i for i in (forecast.intervals if forecast else [])}
    obs = observed_today(db, queue, day)
    rows = []
    for slot in range(48):
        at = start + timedelta(minutes=30 * slot)
        key = at.isoformat()
        scheduled = sum(1 for sh, _ in shifts if queue.code in (sh.queue_codes or []) and _on_duty(sh, at))
        f = fc.get(key)
        if f is None and scheduled == 0 and key not in obs:
            continue
        req = f["required_agents"] if f else 0
        rows.append({"interval": key, "scheduled_agents": scheduled, "forecast_expected": f["expected"] if f else None,
                     "forecast_range": [f["lower_80"], f["upper_80"]] if f else None, "required_agents": req,
                     "gap": scheduled - req, "observed_offered": obs.get(key),
                     "status": "short" if scheduled < req else ("over" if scheduled > req + 2 else "ok")})
    return rows


def conflicts(db: Session, schedule: Schedule) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    shifts = db.scalars(select(Shift).where(Shift.schedule_id == schedule.id).order_by(Shift.agent_id,
                                                                                         Shift.start_at)).all()
    by_agent: dict[uuid.UUID, list[Shift]] = {}
    for sh in shifts:
        by_agent.setdefault(sh.agent_id, []).append(sh)
    for agent_id, lst in by_agent.items():
        agent = db.get(Agent, agent_id)
        for a, b in zip(lst, lst[1:]):
            if b.start_at < a.end_at:
                out.append({"severity": "blocking", "type": "overlap", "agent": agent.display_name,
                            "shift_ids": [str(a.id), str(b.id)]})
            elif (b.start_at - a.end_at) < timedelta(hours=11):
                out.append({"severity": "warning", "type": "short_rest", "agent": agent.display_name,
                            "detail": f"{(b.start_at - a.end_at)} between shifts (< 11h)", "shift_ids": [str(b.id)]})
        for sh in lst:
            dur = sh.end_at - sh.start_at
            if dur > timedelta(hours=6) and not any(x.get("kind") in ("break", "lunch") for x in sh.activities or []):
                out.append({"severity": "warning", "type": "no_break", "agent": agent.display_name,
                            "shift_ids": [str(sh.id)]})
            for lv in db.scalars(select(LeaveRequest).where(LeaveRequest.agent_id == agent_id,
                                                            LeaveRequest.status == "approved",
                                                            LeaveRequest.start_at < sh.end_at,
                                                            LeaveRequest.end_at > sh.start_at)):
                out.append({"severity": "blocking", "type": "leave_clash", "agent": agent.display_name,
                            "detail": f"approved {lv.kind} leave", "shift_ids": [str(sh.id)]})
            wd = sh.start_at.astimezone(UK).isoweekday()
            av = db.scalar(select(AgentAvailability).where(AgentAvailability.agent_id == agent_id,
                                                           AgentAvailability.weekday == wd))
            if av is not None:
                st, en = sh.start_at.astimezone(UK).strftime("%H:%M"), sh.end_at.astimezone(UK).strftime("%H:%M")
                if not any(s0 <= st and en <= e0 for s0, e0 in av.intervals):
                    out.append({"severity": "warning", "type": "outside_availability", "agent": agent.display_name,
                                "detail": f"{st}-{en} outside declared {av.intervals}", "shift_ids": [str(sh.id)]})
    return out


def edit_shift(db: Session, p, shift: Shift, start_at: datetime, end_at: datetime, expected_version: int) -> Shift:
    sched = db.get(Schedule, shift.schedule_id)
    if sched.status != "draft":
        raise InvalidTransition("Published shifts can only change through an approved shift-change request",
                                code="PUBLISHED_SCHEDULE_IMMUTABLE")
    if shift.version != expected_version:
        from ..errors import VersionConflict

        raise VersionConflict("Shift changed", details={"current_version": shift.version})
    if end_at <= start_at:
        raise ValidationFailed("Shift must end after it starts")
    shift.start_at, shift.end_at = start_at, end_at
    shift.version += 1
    return shift


def publish(db: Session, p, sched: Schedule) -> dict[str, Any]:
    if sched.status != "draft":
        raise InvalidTransition("Only a draft schedule can be published")
    found = conflicts(db, sched)
    blocking = [c for c in found if c["severity"] == "blocking"]
    if blocking:
        raise ValidationFailed("Resolve blocking conflicts before publishing", code="SCHEDULE_CONFLICTS",
                               details={"conflicts": blocking})
    sched.status = "published"
    sched.published_at = utcnow()
    sched.published_by = p.user_id
    for agent_id in {sh.agent_id for sh in db.scalars(select(Shift).where(Shift.schedule_id == sched.id))}:
        events.to_agent(db, sched.org_id, agent_id, "schedule.published", schedule_id=sched.id, name=sched.name)
    return {"status": sched.status, "warnings": found}


def request_change(db: Session, p, shift: Shift, kind: str, start_at: datetime | None, end_at: datetime | None,
                   reason: str) -> ShiftChangeRequest:
    if shift.agent_id != p.agent_id:
        raise Forbidden("You can only request changes to your own shifts")
    if kind not in ("change", "drop", "swap"):
        raise ValidationFailed("kind must be change, drop or swap")
    if kind == "change" and not (start_at and end_at and end_at > start_at):
        raise ValidationFailed("Proposed start and end are required")
    r = ShiftChangeRequest(org_id=shift.org_id, shift_id=shift.id, requested_by_agent_id=p.agent_id, kind=kind,
                           proposed_start_at=start_at, proposed_end_at=end_at, reason=reason, status="requested")
    db.add(r)
    return r


def decide_change(db: Session, p, r: ShiftChangeRequest, approve: bool, note: str) -> ShiftChangeRequest:
    p.require("schedule.manage")
    if r.status != "requested":
        raise InvalidTransition("Request already decided")
    r.status = "approved" if approve else "declined"
    r.decided_by, r.decided_at, r.decision_note = p.user_id, utcnow(), note
    if approve:
        sh = db.get(Shift, r.shift_id)
        before = {"start_at": sh.start_at.isoformat(), "end_at": sh.end_at.isoformat()}
        if r.kind == "change":
            sh.start_at, sh.end_at = r.proposed_start_at, r.proposed_end_at
            sh.note = f"Changed by approved request {r.id}"
        elif r.kind == "drop":
            sh.end_at = sh.start_at  # zero-length: retained for history
            sh.note = f"Dropped by approved request {r.id}"
        sh.version += 1
        audit.by_principal(db, p, "schedule.published_shift_changed", "shift", sh.id, before=before,
                           request_id=str(r.id))
    events.to_agent(db, r.org_id, r.requested_by_agent_id, "schedule.change_decided", request_id=r.id,
                    status=r.status)
    return r


def shift_view(sh: Shift, agent: Agent | None = None) -> dict[str, Any]:
    return {"id": sh.id, "agent_id": sh.agent_id, "agent": agent.display_name if agent else None,
            "start_at": sh.start_at, "end_at": sh.end_at, "activities": sh.activities, "queue_codes": sh.queue_codes,
            "note": sh.note, "version": sh.version}
