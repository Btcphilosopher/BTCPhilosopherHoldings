"""Recording policy, provider-confirmed status, protected access and retention.

* Policy is chosen per queue (purpose + jurisdiction + mode).
* ``Recording.status`` only becomes ``active`` on the provider's
  ``recording.started`` event; requesting is not recording.
* Secure payments pause recording via the provider; the pause must be
  confirmed before card capture is considered protected.
* Access requires ``recording.access`` + a role in the recording's
  ``access_roles`` + a stated purpose, and every access is audited.
"""
from __future__ import annotations

import uuid
from datetime import timedelta
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..adapters.storage import get_storage
from ..adapters.telephony.registry import get_provider
from ..db import utcnow
from ..errors import Forbidden, NotFound, ValidationFailed
from ..models import Call, Interaction, Queue, Recording, RecordingPolicy, StoredObject
from . import audit, events

ACCESS_PURPOSES = {"quality_review", "complaint_investigation", "dispute_resolution", "regulatory_request",
                   "training_with_consent"}


def policy_for_queue(db: Session, q: Queue) -> RecordingPolicy | None:
    return db.get(RecordingPolicy, q.recording_policy_id) if q.recording_policy_id else None


def on_enqueued(db: Session, it: Interaction, q: Queue) -> None:
    """Play the recording notice (if policy requires) while the caller waits."""
    pol = policy_for_queue(db, q)
    if pol is None or pol.mode == "off":
        return
    call = db.scalar(select(Call).where(Call.interaction_id == it.id))
    if call is None:
        return
    if pol.notice_text:
        res = get_provider().play_notice(call.provider_call_id, pol.notice_text, request_id=f"notice:{it.id}")
        events.timeline(db, it, "recording.notice_requested", "system", policy=pol.name,
                        outcome=res.outcome)


def start_for_connected_call(db: Session, it: Interaction, call: Call) -> Recording | None:
    q = db.get(Queue, it.current_queue_id) if it.current_queue_id else None
    if q is None:
        return None
    pol = policy_for_queue(db, q)
    if pol is None or pol.mode == "off":
        return None
    existing = db.scalar(select(Recording).where(Recording.call_id == call.id,
                                                 Recording.status.in_(["requested", "active", "paused"])))
    if existing:
        return existing
    consent = "not_required"
    if pol.mode == "consent_required":
        given = any(step.get("consent") == "given" for step in (it.ivr_path or []))
        consent = "given" if given else "refused"
        if not given:
            events.timeline(db, it, "recording.not_started", "system", reason="consent_not_given", policy=pol.name)
            return None
    rec = Recording(org_id=it.org_id, interaction_id=it.id, call_id=call.id, policy_id=pol.id,
                    policy_version=pol.version, purpose=pol.purpose, jurisdiction=pol.jurisdiction,
                    status="requested", consent_status=consent, access_roles=list(pol.access_roles or []),
                    pause_intervals=[], is_synthetic_media=(call.provider == "simulated"))
    db.add(rec)
    db.flush()
    res = get_provider().start_recording(call.provider_call_id, request_id=f"rec:{rec.id}")
    if res.outcome == "accepted":
        rec.provider_recording_id = res.data.get("recording_id")
    elif res.outcome == "rejected":
        rec.status = "failed"
    events.timeline(db, it, "recording.requested", "system", policy=pol.name, outcome=res.outcome,
                    note="Recording is not active until the provider confirms it.")
    return rec


def _rec_for_event(db: Session, call: Call, provider_recording_id: str | None) -> Recording | None:
    q = select(Recording).where(Recording.call_id == call.id)
    if provider_recording_id:
        r = db.scalar(q.where(Recording.provider_recording_id == provider_recording_id))
        if r:
            return r
    return db.scalar(q.order_by(Recording.created_at.desc()).limit(1))


def apply_event(db: Session, it: Interaction, call: Call, ev) -> str:
    rec = _rec_for_event(db, call, ev.data.get("recording_id"))
    if rec is None:
        return "unmatched_recording"
    if not rec.provider_recording_id and ev.data.get("recording_id"):
        rec.provider_recording_id = ev.data["recording_id"]
    t = ev.type
    if t == "recording.started":
        rec.status = "active"
        rec.started_at = ev.occurred_at
        events.timeline(db, it, "recording.active", "provider", occurred_at=ev.occurred_at,
                        note="Provider confirmed recording is running.")
    elif t == "recording.paused":
        rec.status = "paused"
        rec.pause_intervals = [*rec.pause_intervals, {"start": ev.occurred_at.isoformat(), "end": None,
                                                      "reason": ev.data.get("reason")}]
        events.timeline(db, it, "recording.paused", "provider", occurred_at=ev.occurred_at, reason=ev.data.get("reason"))
    elif t == "recording.resumed":
        rec.status = "active"
        if rec.pause_intervals and rec.pause_intervals[-1].get("end") is None:
            last = dict(rec.pause_intervals[-1])
            last["end"] = ev.occurred_at.isoformat()
            rec.pause_intervals = [*rec.pause_intervals[:-1], last]
        events.timeline(db, it, "recording.resumed", "provider", occurred_at=ev.occurred_at)
    elif t == "recording.stopped":
        rec.status = "stopped"
        rec.ended_at = ev.occurred_at
    elif t == "recording.available":
        pol = db.get(RecordingPolicy, rec.policy_id) if rec.policy_id else None
        rec.retention_until = utcnow() + timedelta(days=pol.retention_days if pol else 30)
        rec.content_type = ev.data.get("content_type", "audio/wav")
        rec.is_synthetic_media = bool(ev.data.get("synthetic_media", rec.is_synthetic_media))
        from ..models import Job

        db.add(Job(org_id=it.org_id, kind="fetch_recording", payload={"recording_id": str(rec.id)}, run_at=utcnow(),
                   dedupe_key=f"fetch_recording:{rec.id}"))
    elif t == "recording.failed":
        rec.status = "failed"
    return "applied"


def fetch_media(db: Session, rec: Recording) -> None:
    if rec.storage_key or not rec.provider_recording_id:
        return
    data, ctype = get_provider().fetch_recording(rec.provider_recording_id)
    key, sha, size = get_storage().put(data, prefix=f"recordings/{rec.org_id}")
    db.add(StoredObject(org_id=rec.org_id, storage_key=key, kind="recording", content_type=ctype, size_bytes=size,
                        sha256=sha, created_at=utcnow()))
    rec.storage_key = key
    rec.content_type = ctype
    rec.status = "available"


def can_access(p, rec: Recording) -> tuple[bool, str]:
    if rec.org_id != p.org_id:
        return False, "different organisation"
    if not p.has("recording.access"):
        return False, "missing permission recording.access"
    if not set(p.roles) & set(rec.access_roles or []):
        return False, "role not permitted by this recording's policy"
    if rec.deletion_status == "deleted" or rec.status == "deleted":
        return False, "recording deleted"
    if rec.retention_until and rec.retention_until < utcnow() and not rec.legal_hold:
        return False, "retention period has ended"
    if rec.status != "available" or not rec.storage_key:
        return False, f"recording media not available (status {rec.status})"
    return True, "ok"


def open_media(db: Session, p, recording_id: uuid.UUID, purpose: str) -> tuple[bytes, str, Recording]:
    rec = db.get(Recording, recording_id)
    if rec is None or rec.org_id != p.org_id:
        raise NotFound("Recording not found")
    if purpose not in ACCESS_PURPOSES:
        raise ValidationFailed("A permitted access purpose is required", details={"allowed": sorted(ACCESS_PURPOSES)})
    ok, why = can_access(p, rec)
    audit.by_principal(db, p, "recording.access_attempt", "recording", rec.id, purpose=purpose, allowed=ok, reason=why)
    if not ok:
        db.commit()
        raise Forbidden(f"Recording access denied: {why}", code="RECORDING_ACCESS_DENIED")
    return get_storage().get(rec.storage_key), rec.content_type or "application/octet-stream", rec


def delete_recording(db: Session, p, recording_id: uuid.UUID, reason: str) -> Recording:
    p.require("recording.delete")
    rec = db.get(Recording, recording_id)
    if rec is None or rec.org_id != p.org_id:
        raise NotFound("Recording not found")
    if rec.legal_hold:
        raise Forbidden("Recording is under legal hold", code="LEGAL_HOLD")
    _delete_media(db, rec)
    audit.by_principal(db, p, "recording.deleted", "recording", rec.id, reason=reason)
    return rec


def _delete_media(db: Session, rec: Recording) -> None:
    if rec.storage_key:
        get_storage().delete(rec.storage_key)
        so = db.scalar(select(StoredObject).where(StoredObject.storage_key == rec.storage_key))
        if so:
            so.deleted_at = utcnow()
    rec.storage_key = None
    rec.status = "deleted"
    rec.deletion_status = "deleted"
    rec.deleted_at = utcnow()


def apply_retention(db: Session) -> int:
    due = db.scalars(select(Recording).where(Recording.retention_until < utcnow(), Recording.legal_hold.is_(False),
                                             Recording.deletion_status != "deleted")).all()
    for rec in due:
        _delete_media(db, rec)
        audit.record(db, action="recording.retention_deleted", org_id=rec.org_id, actor_type="worker",
                     target_type="recording", target_id=rec.id, details={"retention_until": rec.retention_until})
    return len(due)


def recording_view(rec: Recording) -> dict[str, Any]:
    return {"id": rec.id, "status": rec.status, "purpose": rec.purpose, "jurisdiction": rec.jurisdiction,
            "consent_status": rec.consent_status, "notice_played_confirmed": rec.notice_played_confirmed,
            "access_roles": rec.access_roles, "started_at": rec.started_at, "ended_at": rec.ended_at,
            "pause_intervals": rec.pause_intervals, "retention_until": rec.retention_until,
            "legal_hold": rec.legal_hold, "deletion_status": rec.deletion_status, "deleted_at": rec.deleted_at,
            "is_synthetic_media": rec.is_synthetic_media, "content_type": rec.content_type,
            "confirmed_by_provider": rec.status in ("active", "paused", "stopped", "available")}
