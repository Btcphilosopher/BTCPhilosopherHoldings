"""Hash-chained audit trail.

Each row stores ``hash = sha256(prev_hash || canonical_json(row))``. The chain
is verified by ``verify_chain``; a break indicates deletion or modification.
Writes take a transaction-scoped advisory lock so the chain stays linear
under concurrency.
"""
from __future__ import annotations

import hashlib
import json
import uuid
from datetime import timezone
from typing import Any

from sqlalchemy import select, text
from sqlalchemy.orm import Session

from ..db import utcnow
from ..models import AuditLog
from ..security.redaction import redact

GENESIS = "0" * 64
_LOCK_KEY = 7_311_001


def _canonical(row: dict[str, Any]) -> bytes:
    return json.dumps(row, sort_keys=True, separators=(",", ":"), default=str).encode()


def _row_material(entry: AuditLog) -> dict[str, Any]:
    return {
        "org_id": str(entry.org_id) if entry.org_id else None,
        "at": entry.at.astimezone(timezone.utc).isoformat(),
        "actor_user_id": str(entry.actor_user_id) if entry.actor_user_id else None,
        "actor_type": entry.actor_type,
        "action": entry.action,
        "target_type": entry.target_type,
        "target_id": entry.target_id,
        "details": entry.details,
    }


def record(db: Session, *, action: str, org_id: uuid.UUID | None, actor_user_id: uuid.UUID | None = None,
           actor_type: str = "user", target_type: str | None = None, target_id: Any = None,
           details: dict[str, Any] | None = None, request_id: str | None = None, ip: str | None = None) -> AuditLog:
    db.execute(text("SELECT pg_advisory_xact_lock(:k)"), {"k": _LOCK_KEY})
    last = db.scalar(select(AuditLog).order_by(AuditLog.seq.desc()).limit(1))
    prev_hash = last.hash if last else GENESIS
    entry = AuditLog(org_id=org_id, at=utcnow(), actor_user_id=actor_user_id, actor_type=actor_type, action=action,
                     target_type=target_type, target_id=str(target_id) if target_id is not None else None,
                     details=redact(json.loads(json.dumps(details or {}, default=str))), request_id=request_id, ip=ip, prev_hash=prev_hash, hash="")
    entry.hash = hashlib.sha256(prev_hash.encode() + _canonical(_row_material(entry))).hexdigest()
    db.add(entry)
    db.flush()
    return entry


def by_principal(db: Session, p, action: str, target_type: str | None = None, target_id: Any = None,
                 **details: Any) -> AuditLog:
    return record(db, action=action, org_id=p.org_id, actor_user_id=p.user_id, actor_type="user",
                  target_type=target_type, target_id=target_id, details=details, request_id=p.request_id, ip=p.ip)


def verify_chain(db: Session) -> dict[str, Any]:
    prev = GENESIS
    count = 0
    for entry in db.scalars(select(AuditLog).order_by(AuditLog.seq)):
        expected = hashlib.sha256(prev.encode() + _canonical(_row_material(entry))).hexdigest()
        if entry.prev_hash != prev or entry.hash != expected:
            return {"valid": False, "broken_at_seq": entry.seq, "checked": count}
        prev = entry.hash
        count += 1
    return {"valid": True, "checked": count, "head": prev}
