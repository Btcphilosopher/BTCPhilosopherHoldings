"""Call controls with explicit requested / acknowledged / failed / unknown outcomes.

* A control is persisted (with its idempotency key) *before* the provider is
  called, so a retried request never re-sends the command.
* A 2xx from the provider leaves the control ``requested``; only a matching
  provider event (or a reconciliation pass) moves it to ``acknowledged``.
* An unknown outcome is never retried automatically: the interaction and agent
  are flagged for reconciliation and consequential actions are blocked.
* Unsupported controls are refused, never simulated.
"""
from __future__ import annotations

import contextvars
import uuid
from datetime import timedelta
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..adapters.telephony.base import ControlResult
from ..adapters.telephony.registry import get_provider
from ..config import get_settings
from ..db import utcnow
from ..errors import (Forbidden, InvalidTransition, NotFound, ProviderUnavailable, ReconciliationRequired,
                      Unsupported, ValidationFailed)
from ..models import (Agent, AgentParticipation, Call, CallControl, CallLeg, Interaction, Offer, ProviderConfig,
                      Queue, SecurePaymentSession)
from ..models.enums import AgentState, Presence, TelephonyRegistration
from . import agent_state, events
from .interactions import (agent_leg, customer_leg, enqueue, get_interaction, identity_for, open_participation,
                           primary_call)

CAPABILITY_FOR = {
    "hold": "hold", "resume": "resume", "mute": "mute", "unmute": "mute", "warm_transfer_start": "warm_transfer",
    "warm_transfer_complete": "warm_transfer", "warm_transfer_cancel": "warm_transfer",
    "blind_transfer": "blind_transfer", "conference": "conference", "end": "end",
    "start_secure_payment": "secure_payment",
}
CONSEQUENTIAL = {"warm_transfer_start", "warm_transfer_complete", "blind_transfer", "conference", "end",
                 "start_secure_payment"}


def provider_status(db: Session, org_id: uuid.UUID) -> str:
    cfg = db.scalar(select(ProviderConfig).where(ProviderConfig.org_id == org_id,
                                                 ProviderConfig.provider == get_provider().name))
    return cfg.connection_status if cfg else "unknown"


def available_controls(db: Session, it: Interaction, agent: Agent) -> dict[str, dict[str, Any]]:
    """What the UI may enable, and why anything is disabled."""
    caps = get_provider().capabilities()
    call = primary_call(db, it.id) if it.channel == "voice" else None
    cust = customer_leg(db, call) if call else None
    mine = agent_leg(db, call, agent.id) if call else None
    ts = it.transfer_state or {}
    status = provider_status(db, it.org_id)
    pending = {c.action for c in db.scalars(select(CallControl).where(CallControl.interaction_id == it.id,
                                                                      CallControl.status == "requested"))}
    out: dict[str, dict[str, Any]] = {}

    def put(action: str, ok: bool, reason: str = "") -> None:
        cap = CAPABILITY_FOR.get(action)
        if cap and not getattr(caps, cap):
            out[action] = {"enabled": False, "reason": f"Not supported by provider '{caps.provider}'"}
            return
        if it.channel != "voice":
            out[action] = {"enabled": False, "reason": "Not a voice interaction"}
            return
        if status != "connected":
            out[action] = {"enabled": False, "reason": f"Telephony provider {status}"}
            return
        if agent.reconcile_required or it.needs_reconciliation:
            out[action] = {"enabled": False, "reason": "Call state must be reconciled first"}
            return
        if action in pending:
            out[action] = {"enabled": False, "reason": "Previous request awaiting provider confirmation"}
            return
        out[action] = {"enabled": ok, "reason": "" if ok else reason}

    owner = it.owner_agent_id == agent.id
    live = bool(call and call.status == "in_progress")
    answered = bool(cust and cust.status in ("answered", "held"))
    put("hold", owner and live and answered and not (cust and cust.on_hold), "Customer not connected or already held")
    put("resume", owner and live and bool(cust and cust.on_hold) and ts.get("status") not in ("consult_ringing",),
        "Customer is not on hold")
    put("mute", bool(mine and mine.status == "answered" and not mine.provider_muted), "Your leg is not connected")
    put("unmute", bool(mine and mine.provider_muted), "You are not muted")
    consult_active = ts.get("status") in ("consult_ringing", "consult_connected")
    put("warm_transfer_start", owner and live and answered and not consult_active, "Not available now")
    put("warm_transfer_complete", owner and ts.get("status") == "consult_connected", "Consulted agent not connected")
    put("warm_transfer_cancel", owner and consult_active, "No consultation in progress")
    put("blind_transfer", owner and live and answered and not consult_active, "Not available now")
    put("conference", owner and ts.get("status") == "consult_connected", "Consulted agent not connected")
    put("end", owner and live, "No live call")
    put("start_secure_payment", owner and live and answered and not consult_active, "Not available now")
    return out


def _target_agent(db: Session, org_id: uuid.UUID, target_id: Any, me: Agent) -> Agent:
    try:
        target = db.get(Agent, uuid.UUID(str(target_id)))
    except ValueError:
        target = None
    if target is None or target.org_id != org_id:
        raise NotFound("Target agent not found")
    if target.id == me.id:
        raise ValidationFailed("Cannot transfer to yourself")
    blockers = []
    if target.state != AgentState.AVAILABLE:
        blockers.append(f"target is {target.state}")
    if target.presence != Presence.ONLINE:
        blockers.append("target application not connected")
    if target.telephony_registration != TelephonyRegistration.REGISTERED:
        blockers.append("target has no confirmed telephony registration")
    if target.reconcile_required:
        blockers.append("target requires reconciliation")
    if blockers:
        raise InvalidTransition("Target agent cannot take a consultation now", code="TARGET_NOT_AVAILABLE",
                                details={"blockers": blockers})
    return target


def perform(db: Session, agent: Agent, interaction_id: uuid.UUID, action: str, params: dict[str, Any],
            idempotency_key: str, actor_user_id: uuid.UUID) -> CallControl:
    existing = db.scalar(select(CallControl).where(CallControl.org_id == agent.org_id,
                                                   CallControl.idempotency_key == idempotency_key))
    if existing is not None:
        if existing.action != action or existing.interaction_id != interaction_id:
            raise ValidationFailed("Idempotency key reused for a different control", code="IDEMPOTENCY_KEY_REUSED")
        return existing  # never re-send

    it = get_interaction(db, agent.org_id, interaction_id, lock=True)
    if action not in CAPABILITY_FOR:
        raise ValidationFailed(f"Unknown action '{action}'")
    caps = get_provider().capabilities()
    if not getattr(caps, CAPABILITY_FOR[action]):
        raise Unsupported(f"'{action}' is not supported by provider '{caps.provider}'",
                          details={"action": action, "provider": caps.provider})
    if it.owner_agent_id != agent.id and action not in ("mute", "unmute"):
        raise Forbidden("Only the owning agent can control this call", code="NOT_OWNER")
    if agent.reconcile_required or it.needs_reconciliation:
        raise ReconciliationRequired("Call state must be reconciled with the provider before further controls",
                                     details={"agent": agent.reconcile_reason})
    if provider_status(db, it.org_id) != "connected":
        raise ProviderUnavailable("Telephony provider is not connected; controls are disabled")
    controls = available_controls(db, it, agent)
    if not controls.get(action, {}).get("enabled"):
        raise InvalidTransition(f"'{action}' is not possible now: {controls.get(action, {}).get('reason')}",
                                details={"action": action, "reason": controls.get(action, {}).get("reason")})
    call = primary_call(db, it.id)
    cust = customer_leg(db, call)
    mine = agent_leg(db, call, agent.id)
    ts = dict(it.transfer_state or {})

    ctl = CallControl(org_id=it.org_id, interaction_id=it.id, call_id=call.id, agent_id=agent.id, action=action,
                      params=params, idempotency_key=idempotency_key, status="requested", requested_at=utcnow())
    target: Agent | None = None
    offer: Offer | None = None
    if action in ("hold", "resume"):
        ctl.leg_id = cust.id
    elif action in ("mute", "unmute"):
        ctl.leg_id = mine.id if mine else None
    elif action == "warm_transfer_start":
        target = _target_agent(db, it.org_id, params.get("target_agent_id"), agent)
        timeout = get_settings().transfer_consult_timeout_seconds
        offer = Offer(org_id=it.org_id, interaction_id=it.id, agent_id=target.id, kind="consult", status="pending",
                      offered_at=utcnow(), expires_at=utcnow() + timedelta(seconds=timeout))
        db.add(offer)
        agent_state.transition(db, target, AgentState.CALL_OFFERED, reason=f"consult:{it.reference}", source="system")
    elif action in ("warm_transfer_complete", "warm_transfer_cancel", "conference"):
        ctl.leg_id = uuid.UUID(ts["consult_leg_id"]) if ts.get("consult_leg_id") else None
    elif action == "blind_transfer":
        q = db.get(Queue, uuid.UUID(str(params.get("target_queue_id")))) if params.get("target_queue_id") else None
        if q is None or q.org_id != it.org_id:
            raise ValidationFailed("target_queue_id is required for a blind transfer to a queue")
        ctl.leg_id = mine.id if mine else None
        ctl.params = {**params, "target_queue_code": q.code}
    elif action == "start_secure_payment":
        amount = int(params.get("amount_minor") or 0)
        if amount <= 0:
            raise ValidationFailed("amount_minor must be positive")
    db.add(ctl)
    db.flush()
    rid = str(ctl.id)
    ctl.provider_request_id = rid
    events.timeline(db, it, "control.requested", "agent", actor_user_id=actor_user_id, action=action,
                    control_id=rid, params={k: v for k, v in params.items() if k != "amount_minor"})
    db.commit()  # persisted before sending: a retry will find it and not re-send

    p = get_provider()
    pcid = call.provider_call_id
    if action == "hold":
        res = p.hold(pcid, cust.provider_leg_id, request_id=rid)
    elif action == "resume":
        res = p.resume(pcid, cust.provider_leg_id, request_id=rid)
    elif action in ("mute", "unmute"):
        res = p.mute(pcid, mine.provider_leg_id, action == "mute", request_id=rid)
    elif action == "warm_transfer_start":
        res = p.start_consult(pcid, identity_for(target.id), request_id=rid)
    elif action == "warm_transfer_complete":
        res = p.complete_transfer(pcid, _leg_provider_id(db, ctl.leg_id), request_id=rid)
    elif action == "warm_transfer_cancel":
        res = p.cancel_consult(pcid, _leg_provider_id(db, ctl.leg_id), request_id=rid)
    elif action == "conference":
        res = p.conference(pcid, _leg_provider_id(db, ctl.leg_id), request_id=rid)
    elif action == "blind_transfer":
        res = p.blind_transfer(pcid, mine.provider_leg_id, request_id=rid)
    elif action == "end":
        res = p.hangup(pcid, request_id=rid)
    elif action == "start_secure_payment":
        res = p.start_secure_payment(pcid, int(params["amount_minor"]), params.get("currency", "GBP"), request_id=rid)
    else:  # pragma: no cover
        raise ValidationFailed("unhandled action")
    _apply_result(db, it, agent, ctl, res, target=target, offer=offer)
    return ctl


def _leg_provider_id(db: Session, leg_id: uuid.UUID | None) -> str:
    leg = db.get(CallLeg, leg_id) if leg_id else None
    if leg is None:
        raise ValidationFailed("Consultation leg not found")
    return leg.provider_leg_id


def _apply_result(db: Session, it: Interaction, agent: Agent, ctl: CallControl, res: ControlResult, *,
                  target: Agent | None, offer: Offer | None) -> None:
    # Provider events may have been processed concurrently while we waited for the response:
    # reload with locks and never overwrite an outcome an event already established.
    it = db.scalar(select(Interaction).where(Interaction.id == it.id).with_for_update()
                   .execution_options(populate_existing=True))
    ctl = db.scalar(select(CallControl).where(CallControl.id == ctl.id).with_for_update()
                    .execution_options(populate_existing=True))
    if offer is not None:
        offer = db.scalar(select(Offer).where(Offer.id == offer.id).execution_options(populate_existing=True))
    if ctl.status != "requested" and res.outcome != "accepted":
        events.timeline(db, it, "control.response_after_event", "system", action=ctl.action,
                        control_id=str(ctl.id), response=res.outcome, kept_status=ctl.status)
        return
    if res.outcome == "accepted":
        events.timeline(db, it, "control.sent", "system", action=ctl.action, control_id=str(ctl.id),
                        note="Provider accepted the request; awaiting confirmation event.")
        if ctl.action == "warm_transfer_start" and target is not None:
            call = primary_call(db, it.id)
            leg = db.scalar(select(CallLeg).where(CallLeg.call_id == call.id,
                                                  CallLeg.provider_leg_id == res.provider_leg_id)) \
                if res.provider_leg_id else None
            if leg is None:  # the provider's leg.ringing event may already have created it
                leg = CallLeg(org_id=it.org_id, call_id=call.id,
                              provider_leg_id=res.provider_leg_id or f"pending:{ctl.id}", leg_type="consult",
                              agent_id=target.id, status="ringing", started_at=utcnow())
                db.add(leg)
                db.flush()
            ctl.leg_id = leg.id
            it.transfer_state = {"status": "consult_ringing", "target_agent_id": str(target.id),
                                 "target_agent": target.display_name, "consult_leg_id": str(leg.id),
                                 "offer_id": str(offer.id) if offer else None, "start_control_id": str(ctl.id),
                                 "started_at": utcnow().isoformat()}
            it.version += 1
            events.to_agent(db, it.org_id, target.id, "offer.created", offer_id=offer.id, interaction_id=it.id,
                            kind="consult", from_agent=agent.display_name, expires_at=offer.expires_at,
                            reference=it.reference)
        if ctl.action == "start_secure_payment":
            db.add(SecurePaymentSession(org_id=it.org_id, interaction_id=it.id,
                                        provider_session_id=res.data.get("payment_session_id"),
                                        amount_minor=int(ctl.params["amount_minor"]),
                                        currency=ctl.params.get("currency", "GBP"), status="requested",
                                        started_at=utcnow()))
    elif res.outcome == "rejected":
        ctl.status = "failed"
        ctl.error_code, ctl.error_message = res.error_code, res.error_message
        ctl.resolved_by = "provider_response"
        events.timeline(db, it, "control.failed", "provider", action=ctl.action, control_id=str(ctl.id),
                        error=res.error_code)
        if target is not None and offer is not None:
            offer.status = "withdrawn"
            offer.response_reason = "consult_request_failed"
            if target.state == AgentState.CALL_OFFERED:
                agent_state.transition(db, target, AgentState.AVAILABLE, reason="consult_request_failed",
                                       source="system")
    else:
        ctl.status = "unknown"
        ctl.error_code, ctl.error_message = res.error_code, res.error_message
        it.needs_reconciliation = True
        agent_state.mark_reconcile(db, agent, f"{ctl.action} outcome unknown")
        events.timeline(db, it, "control.unknown", "system", action=ctl.action, control_id=str(ctl.id),
                        note="No reliable response from provider. Not retried. Reconciliation required.")
        if target is not None and offer is not None and offer.status == "pending":
            offer.status = "withdrawn"
            offer.response_reason = "consult_outcome_unknown"
            agent_state.mark_reconcile(db, target, "consult outcome unknown")
    events.to_agent(db, it.org_id, agent.id, "control.updated", control_id=ctl.id, action=ctl.action,
                    status=ctl.status)


# --------------------------------------------------------------------------- consult accept / decline

def accept_consult(db: Session, target: Agent, it: Interaction, offer: Offer, *, actor_user_id) -> dict[str, Any]:
    ts = dict(it.transfer_state or {})
    if ts.get("status") != "consult_ringing" or ts.get("offer_id") != str(offer.id):
        raise InvalidTransition("Consultation is no longer ringing", code="OFFER_NOT_PENDING")
    offer.status = "accepted"
    offer.responded_at = utcnow()
    leg = db.get(CallLeg, uuid.UUID(ts["consult_leg_id"]))
    db.add(AgentParticipation(org_id=it.org_id, interaction_id=it.id, agent_id=target.id, role="consult",
                              accepted_at=utcnow(), leg_id=leg.id))
    agent_state.transition(db, target, AgentState.CONNECTING, reason=f"consult_accepted:{it.reference}",
                           source="agent", actor_user_id=actor_user_id)
    events.timeline(db, it, "consult.accepted", "agent", actor_user_id=actor_user_id, agent=target.display_name)
    db.commit()
    call = primary_call(db, it.id)
    # Simulated device behaviour: the consulted agent's softphone answers once they accept in the app.
    res = get_provider().answer_leg(call.provider_call_id, leg.provider_leg_id, request_id=f"consult-answer:{offer.id}")
    if res.outcome != "accepted":
        events.timeline(db, it, "consult.answer_failed", "provider", outcome=res.outcome, error=res.error_code)
        if res.outcome == "unknown":
            agent_state.mark_reconcile(db, target, "consult answer outcome unknown")
    return {"interaction_id": it.id, "status": it.status, "kind": "consult"}


def consult_declined(db: Session, it: Interaction, target: Agent, offer: Offer, *, reason: str) -> None:
    ts = dict(it.transfer_state or {})
    events.timeline(db, it, "consult.declined", "agent" if reason == "rejected" else "system",
                    agent=target.display_name, reason=reason)
    if target.state == AgentState.CALL_OFFERED:
        agent_state.transition(db, target, AgentState.AVAILABLE if reason == "rejected" else AgentState.UNAVAILABLE,
                               reason=f"consult_{reason}", source="system")
    if ts.get("consult_leg_id"):
        leg = db.get(CallLeg, uuid.UUID(ts["consult_leg_id"]))
        call = primary_call(db, it.id)
        db.commit()
        if leg and call and leg.status == "ringing":
            res = get_provider().reject_leg(call.provider_call_id, leg.provider_leg_id,
                                            request_id=f"consult-decline:{offer.id}")
            if res.outcome == "unknown":
                it.needs_reconciliation = True


# --------------------------------------------------------------------------- provider confirmations

# Set to "reconciliation" while synthetic events derived from provider state queries are applied.
resolution_source: contextvars.ContextVar[str] = contextvars.ContextVar("resolution_source", default="provider_event")


def ack(db: Session, request_id: str | None, *, ok: bool, error: str | None = None,
        resolved_by: str | None = None) -> CallControl | None:
    resolved_by = resolved_by or resolution_source.get()
    if not request_id:
        return None
    try:
        ctl = db.get(CallControl, uuid.UUID(request_id))
    except ValueError:
        return None
    if ctl is None or ctl.status in ("acknowledged", "failed"):
        return ctl
    ctl.status = "acknowledged" if ok else "failed"
    ctl.acknowledged_at = utcnow()
    ctl.resolved_by = resolved_by
    if error:
        ctl.error_code = error
    if ctl.agent_id:
        events.to_agent(db, ctl.org_id, ctl.agent_id, "control.updated", control_id=ctl.id, action=ctl.action,
                        status=ctl.status)
    return ctl


def on_transfer_completed(db: Session, it: Interaction, call: Call, ev) -> None:
    mode = ev.data.get("mode", "warm")
    ctl = ack(db, ev.request_id, ok=True)
    ts = dict(it.transfer_state or {})
    from_agent_id = ctl.agent_id if ctl else it.owner_agent_id
    from_agent = db.get(Agent, from_agent_id) if from_agent_id else None
    if from_agent:
        part = open_participation(db, it.id, from_agent.id)
        if part:
            part.ended_at = ev.occurred_at
            part.outcome = "transferred_out"  # wrap-up still open (wrap_ended_at is null)
            part.wrap_started_at = utcnow()
        agent_state.transition(db, from_agent, AgentState.AFTER_CALL_WORK, reason=f"transferred_{mode}",
                               source="provider", force=True)
    it.transfer_count += 1
    if mode == "warm":
        target_id = uuid.UUID(ts["target_agent_id"]) if ts.get("target_agent_id") else None
        it.owner_agent_id = target_id
        tpart = db.scalar(select(AgentParticipation).where(AgentParticipation.interaction_id == it.id,
                                                           AgentParticipation.agent_id == target_id,
                                                           AgentParticipation.ended_at.is_(None)))
        if tpart:
            tpart.role = "transfer_receiver"
        target = db.get(Agent, target_id) if target_id else None
        if target:
            target.current_interaction_id = it.id
        leg = db.get(CallLeg, uuid.UUID(ts["consult_leg_id"])) if ts.get("consult_leg_id") else None
        it.transfer_state = {**ts, "status": "completed", "completed_at": ev.occurred_at.isoformat()}
        events.timeline(db, it, "transfer.completed", "provider", occurred_at=ev.occurred_at, mode="warm",
                        to_agent=ts.get("target_agent"), note="Same interaction continues with the receiving agent.")
        if leg:
            leg.leg_type = "agent"
        if target:
            events.to_agent(db, it.org_id, target.id, "interaction.owned", interaction_id=it.id)
    else:
        q_code = (ctl.params or {}).get("target_queue_code") if ctl else None
        it.owner_agent_id = None
        it.transfer_state = {"status": "blind_completed", "queue": q_code, "completed_at": ev.occurred_at.isoformat()}
        q = db.scalar(select(Queue).where(Queue.org_id == it.org_id, Queue.code == q_code)) if q_code else None
        events.timeline(db, it, "transfer.completed", "provider", occurred_at=ev.occurred_at, mode="blind", queue=q_code)
        if q:
            from .interactions import close_queue_entry

            close_queue_entry(db, it, "transferred")
            it.status = "ivr"  # transient; enqueue sets queued
            enqueue(db, it, q, reason="blind_transfer")
    it.version += 1


def on_transfer_failed(db: Session, it: Interaction, ev) -> None:
    ts = dict(it.transfer_state or {})
    reason = ev.data.get("reason", "unknown")
    start_ctl_id = ts.get("start_control_id")
    if start_ctl_id:
        ctl = db.get(CallControl, uuid.UUID(start_ctl_id))
        if ctl and ctl.status == "requested":
            ack(db, start_ctl_id, ok=False, error=f"consult_{reason}")
    target_id = ts.get("target_agent_id")
    if target_id:
        target = db.get(Agent, uuid.UUID(target_id))
        tpart = db.scalar(select(AgentParticipation).where(AgentParticipation.interaction_id == it.id,
                                                           AgentParticipation.agent_id == target.id,
                                                           AgentParticipation.ended_at.is_(None)))
        if tpart:
            tpart.ended_at = ev.occurred_at
            tpart.wrap_ended_at = ev.occurred_at
            tpart.outcome = "consult_failed"
        if target.state in (AgentState.CALL_OFFERED, AgentState.CONNECTING):
            agent_state.transition(db, target, AgentState.AVAILABLE if reason == "rejected" else AgentState.UNAVAILABLE,
                                   reason=f"consult_{reason}", source="provider")
        offer = db.get(Offer, uuid.UUID(ts["offer_id"])) if ts.get("offer_id") else None
        if offer and offer.status == "pending":
            offer.status = "rejected" if reason == "rejected" else "expired"
            offer.responded_at = utcnow()
    it.transfer_state = {**ts, "status": "failed", "failure_reason": reason, "failed_at": ev.occurred_at.isoformat(),
                         "customer_on_hold": bool(ev.data.get("customer_on_hold")),
                         "behaviour": ev.data.get("behaviour")}
    it.version += 1
    events.timeline(db, it, "transfer.failed", "provider", occurred_at=ev.occurred_at, reason=reason,
                    behaviour=ev.data.get("behaviour"),
                    note="Original call preserved: customer remains with the original agent (on hold).")
    if it.owner_agent_id:
        events.to_agent(db, it.org_id, it.owner_agent_id, "transfer.failed", interaction_id=it.id, reason=reason)


def on_transfer_cancelled(db: Session, it: Interaction, ev) -> None:
    ack(db, ev.request_id, ok=True)
    ts = dict(it.transfer_state or {})
    if ts.get("target_agent_id"):
        target = db.get(Agent, uuid.UUID(ts["target_agent_id"]))
        tpart = db.scalar(select(AgentParticipation).where(AgentParticipation.interaction_id == it.id,
                                                           AgentParticipation.agent_id == target.id,
                                                           AgentParticipation.ended_at.is_(None)))
        if tpart:
            tpart.ended_at = tpart.wrap_ended_at = ev.occurred_at
            tpart.outcome = "consult_only"
        if target.state in (AgentState.CALL_OFFERED, AgentState.CONNECTING, AgentState.ON_INTERACTION):
            agent_state.transition(db, target, AgentState.AVAILABLE, reason="consult_cancelled", source="provider",
                                   force=True)
            target.current_interaction_id = None
    it.transfer_state = {**ts, "status": "cancelled", "cancelled_at": ev.occurred_at.isoformat()}
    it.version += 1
    events.timeline(db, it, "transfer.cancelled", "provider", occurred_at=ev.occurred_at)


def on_conference_started(db: Session, it: Interaction, ev) -> None:
    ack(db, ev.request_id, ok=True)
    ts = dict(it.transfer_state or {})
    if ts.get("target_agent_id"):
        tpart = db.scalar(select(AgentParticipation).where(
            AgentParticipation.interaction_id == it.id,
            AgentParticipation.agent_id == uuid.UUID(ts["target_agent_id"]), AgentParticipation.ended_at.is_(None)))
        if tpart:
            tpart.role = "conference"
    it.transfer_state = {**ts, "status": "conference"}
    it.version += 1
    events.timeline(db, it, "conference.started", "provider", occurred_at=ev.occurred_at)
