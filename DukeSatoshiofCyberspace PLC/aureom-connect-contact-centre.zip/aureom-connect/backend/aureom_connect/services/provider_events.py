"""Verified provider event ingestion.

Guarantees:

* **Authenticity** – the adapter verifies the webhook signature and timestamp
  before anything is stored; unverified requests are rejected and audited.
* **Duplicates** – ``(provider, provider_event_id)`` is unique; repeats are
  counted and not re-applied.
* **Out of order / late** – every leg tracks the last applied provider
  sequence; an older event never regresses state (``stale_ignored``).
* **Early** – events for a call we have not recorded yet are stored as
  ``unmatched`` and re-processed once the call exists.
* **Missing** – a sequence gap is recorded and a reconciliation job queries
  the provider's authoritative call state.
* Provider event time (``occurred_at``) and ingestion time (``received_at``)
  are stored separately; reports use event time.
"""
from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..adapters.telephony.base import NormalizedEvent
from ..adapters.telephony.registry import get_provider
from ..db import utcnow
from ..errors import NotFound, Unauthorized
from ..models import (Agent, AgentParticipation, Call, CallLeg, Interaction, InteractionEvent, Job,
                      MonitoringSession, OutboundAttempt, ProviderEvent, SecurePaymentSession, Transcript)
from ..models.enums import AgentState
from . import agent_state, audit, calls, events, interactions, recording, routing

TERMINAL_LEG = {"completed", "failed", "no_answer", "busy", "rejected"}


def ingest(db: Session, provider_name: str, headers: dict[str, str], body: bytes, url: str) -> dict[str, Any]:
    adapter = get_provider()
    if adapter.name != provider_name:
        raise NotFound(f"Provider '{provider_name}' is not configured")
    if not adapter.verify_webhook(headers, body, url):
        audit.record(db, action="provider.event_rejected", org_id=None, actor_type="provider",
                     details={"provider": provider_name, "reason": "signature_or_timestamp_invalid"})
        db.commit()
        raise Unauthorized("Provider event signature invalid", code="INVALID_SIGNATURE")
    results = []
    orgs: set[uuid.UUID] = set()
    for ev in adapter.parse_events(body, headers):
        res = process(db, provider_name, ev)
        results.append(res)
        if res.get("org_id"):
            orgs.add(res["org_id"])
        db.commit()
    for org_id in orgs:
        routing.route_org(db, org_id)
        db.commit()
    return {"results": [{k: (str(v) if isinstance(v, uuid.UUID) else v) for k, v in r.items()} for r in results]}


def process(db: Session, provider: str, ev: NormalizedEvent, *, existing: ProviderEvent | None = None) -> dict[str, Any]:
    if existing is None:
        dup = db.scalar(select(ProviderEvent).where(ProviderEvent.provider == provider,
                                                    ProviderEvent.provider_event_id == ev.provider_event_id))
        if dup is not None:
            dup.duplicate_count += 1
            return {"event_id": ev.provider_event_id, "status": "duplicate", "org_id": dup.org_id}
        pe = ProviderEvent(provider=provider, provider_event_id=ev.provider_event_id, event_type=ev.type,
                           provider_call_id=ev.provider_call_id, provider_leg_id=ev.provider_leg_id,
                           sequence=ev.sequence, occurred_at=ev.occurred_at, received_at=utcnow(),
                           signature_verified=True, payload=ev.model_dump(mode="json"), processing_status="received")
        try:
            with db.begin_nested():
                db.add(pe)
                db.flush()
        except IntegrityError:
            return {"event_id": ev.provider_event_id, "status": "duplicate", "org_id": None}
    else:
        pe = existing
    try:
        with db.begin_nested():
            status, note, org_id = _apply(db, provider, ev)
    except Exception as exc:  # keep the raw event; surface the failure for operators
        status, note, org_id = "error", f"{type(exc).__name__}: {exc}"[:500], None
    pe.processing_status = status
    pe.processing_note = note
    if org_id:
        pe.org_id = org_id
    return {"event_id": ev.provider_event_id, "status": status, "note": note, "org_id": org_id}


def reprocess_unmatched(db: Session, provider: str, provider_call_id: str) -> int:
    pending = db.scalars(select(ProviderEvent).where(ProviderEvent.provider == provider,
                                                     ProviderEvent.provider_call_id == provider_call_id,
                                                     ProviderEvent.processing_status == "unmatched")
                         .order_by(ProviderEvent.sequence.asc().nulls_first(), ProviderEvent.occurred_at)).all()
    for pe in pending:
        process(db, provider, NormalizedEvent(**pe.payload), existing=pe)
    return len(pending)


# --------------------------------------------------------------------------- dispatch

def _apply(db: Session, provider: str, ev: NormalizedEvent) -> tuple[str, str | None, uuid.UUID | None]:
    t = ev.type
    if t.startswith("device."):
        return _device(db, ev)
    call = None
    if ev.provider_call_id:
        call = db.scalar(select(Call).where(Call.provider == provider, Call.provider_call_id == ev.provider_call_id))
    if t == "call.initiated" and call is None:
        if ev.data.get("direction") == "outbound":
            return "unmatched", "outbound call not yet recorded (dial response pending)", None
        it = interactions.handle_inbound_call(db, provider, ev)
        if it is None:
            return "unmatched", f"no organisation owns number {ev.data.get('to_number')}", None
        call = db.scalar(select(Call).where(Call.provider == provider, Call.provider_call_id == ev.provider_call_id))
        call.last_provider_sequence = ev.sequence or 0
        call.last_provider_event_at = ev.occurred_at
        db.flush()
        reprocess_unmatched(db, provider, ev.provider_call_id)
        return "applied", "inbound interaction created", it.org_id
    if call is None:
        return "unmatched", "call not yet known; buffered for re-processing", None
    it = db.get(Interaction, call.interaction_id, with_for_update=True)
    note = None
    if ev.sequence is not None:
        if call.last_provider_sequence and ev.sequence > call.last_provider_sequence + 1:
            note = f"sequence gap: expected {call.last_provider_sequence + 1}, got {ev.sequence}"
            db.add(Job(org_id=it.org_id, kind="reconcile_call", payload={"call_id": str(call.id), "reason": note},
                       run_at=utcnow()))
        if ev.sequence > (call.last_provider_sequence or 0):
            call.last_provider_sequence = ev.sequence
            call.last_provider_event_at = ev.occurred_at
    if t == "call.initiated":
        return "applied", "outbound call confirmed by provider", it.org_id
    if t.startswith("leg."):
        status = _leg_event(db, it, call, ev)
    elif t == "call.completed":
        status = _call_completed(db, it, call, ev)
    elif t == "ivr.input":
        if ev.data.get("consent_digit"):
            it.ivr_path = [*it.ivr_path, {"consent": "given" if ev.data["consent_digit"] == "1" else "refused"}]
        interactions.handle_ivr_input(db, it, str(ev.data.get("digits", "")), ev)
        status = "applied"
    elif t == "transfer.completed":
        calls.on_transfer_completed(db, it, call, ev)
        status = "applied"
    elif t == "transfer.failed":
        calls.on_transfer_failed(db, it, ev)
        status = "applied"
    elif t == "transfer.cancelled":
        calls.on_transfer_cancelled(db, it, ev)
        status = "applied"
    elif t == "conference.started":
        calls.on_conference_started(db, it, ev)
        status = "applied"
    elif t.startswith("recording."):
        status = recording.apply_event(db, it, call, ev)
    elif t == "notice.played":
        events.timeline(db, it, "recording.notice_played", "provider", occurred_at=ev.occurred_at,
                        text=ev.data.get("text"))
        status = "applied"
    elif t.startswith("payment."):
        status = _payment(db, it, ev)
    elif t == "transcript.available":
        db.add(Transcript(org_id=it.org_id, interaction_id=it.id, source="machine", language=ev.data.get("language", "en"),
                          provenance={"engine": ev.data.get("engine"), "engine_version": ev.data.get("engine_version"),
                                      "generated_at": ev.occurred_at.isoformat(), "provider": provider,
                                      "simulated": bool(ev.data.get("simulated")),
                                      "status": "machine_output_unverified"},
                          segments=ev.data.get("segments", [])))
        events.timeline(db, it, "transcript.available", "provider", occurred_at=ev.occurred_at,
                        engine=ev.data.get("engine"), simulated=bool(ev.data.get("simulated")))
        status = "applied"
    elif t.startswith("monitor."):
        status = _monitor(db, it, ev)
    else:
        status = "ignored"
        note = f"unhandled event type {t}"
    return status, note, it.org_id


def _device(db: Session, ev: NormalizedEvent) -> tuple[str, str | None, uuid.UUID | None]:
    agent = interactions.agent_from_identity(db, ev.data.get("identity"))
    if agent is None:
        return "unmatched", "unknown device identity", None
    agent = db.get(Agent, agent.id, with_for_update=True)
    if ev.type == "device.registered":
        if agent.telephony_registered_at and ev.occurred_at < agent.telephony_registered_at:
            return "stale_ignored", "older registration event", agent.org_id
        agent.telephony_registration = "registered"
        agent.telephony_device_id = ev.data.get("device_id")
        agent.telephony_registered_at = ev.occurred_at
        events.to_agent(db, agent.org_id, agent.id, "telephony.registration", status="registered")
        events.to_supervisors(db, agent.org_id, "agent.telephony", agent_id=agent.id, status="registered")
        return "applied", None, agent.org_id
    if ev.type == "device.unregistered":
        if agent.telephony_registered_at and ev.occurred_at < agent.telephony_registered_at:
            return "stale_ignored", "unregistration older than current registration", agent.org_id
        agent.telephony_registration = "unregistered"
        agent.telephony_registered_at = ev.occurred_at
        reason = ev.data.get("reason", "unknown")
        events.to_agent(db, agent.org_id, agent.id, "telephony.registration", status="unregistered", reason=reason)
        events.to_supervisors(db, agent.org_id, "agent.telephony", agent_id=agent.id, status="unregistered",
                              reason=reason)
        if agent.state == AgentState.AVAILABLE:
            agent_state.transition(db, agent, AgentState.UNAVAILABLE, reason=f"device_lost:{reason}", source="provider")
        elif agent.state in (AgentState.CALL_OFFERED, AgentState.CONNECTING, AgentState.ON_INTERACTION):
            agent_state.mark_reconcile(db, agent, f"telephony device lost during work ({reason})")
        return "applied", None, agent.org_id
    return "ignored", None, agent.org_id


def _hold_close(db: Session, it: Interaction, leg: CallLeg, at: datetime) -> None:
    if leg.hold_started_at is None:
        return
    secs = max(0, int((at - leg.hold_started_at).total_seconds()))
    leg.hold_seconds_total += secs
    leg.hold_started_at = None
    if it.owner_agent_id:
        part = interactions.open_participation(db, it.id, it.owner_agent_id)
        if part:
            part.hold_seconds += secs


def _leg_event(db: Session, it: Interaction, call: Call, ev: NormalizedEvent) -> str:
    leg = db.scalar(select(CallLeg).where(CallLeg.call_id == call.id, CallLeg.provider_leg_id == ev.provider_leg_id))
    if leg is None:
        agent = interactions.agent_from_identity(db, ev.data.get("identity"))
        leg_type = ev.data.get("leg_type", "external")
        leg = CallLeg(org_id=it.org_id, call_id=call.id, provider_leg_id=ev.provider_leg_id, leg_type=leg_type,
                      agent_id=agent.id if agent else None, external_number=ev.data.get("number"), status="initiated",
                      started_at=ev.occurred_at)
        db.add(leg)
        db.flush()
    if ev.sequence is not None:
        if ev.sequence <= leg.last_sequence:
            if ev.type == "leg.answered" and leg.answered_at is None:
                leg.answered_at = ev.occurred_at  # fill a missing fact without regressing state
            return "stale_ignored"
        leg.last_sequence = ev.sequence
    t = ev.type
    if t == "leg.ringing":
        if leg.status not in TERMINAL_LEG and leg.status != "answered":
            leg.status = "ringing"
        if leg.leg_type == "consult":
            calls.ack(db, ev.request_id, ok=True)  # consultation leg created and ringing at the provider
        return "applied"
    if t == "leg.answered":
        leg.status = "answered"
        leg.answered_at = ev.occurred_at
        _leg_answered(db, it, call, leg, ev)
        return "applied"
    if t in ("leg.held", "leg.resumed"):
        held = t == "leg.held"
        leg.on_hold = held
        if held:
            leg.hold_started_at = ev.occurred_at
        else:
            _hold_close(db, it, leg, ev.occurred_at)
        calls.ack(db, ev.request_id, ok=True)
        events.timeline(db, it, "call.held" if held else "call.resumed", "provider", occurred_at=ev.occurred_at,
                        leg=leg.leg_type, reason=ev.data.get("reason"), confirmed=True)
        return "applied"
    if t in ("leg.muted", "leg.unmuted"):
        leg.provider_muted = t == "leg.muted"
        calls.ack(db, ev.request_id, ok=True)
        events.timeline(db, it, t, "provider", occurred_at=ev.occurred_at, confirmed=True)
        return "applied"
    if t == "leg.completed":
        leg.status = "completed"
        leg.ended_at = ev.occurred_at
        leg.end_reason = ev.data.get("reason")
        _hold_close(db, it, leg, ev.occurred_at)
        return "applied"
    if t == "leg.failed":
        leg.status = "failed"
        leg.ended_at = ev.occurred_at
        leg.end_reason = ev.data.get("reason")
        if leg.leg_type == "agent" and leg.agent_id and it.direction == "inbound":
            calls.ack(db, ev.request_id, ok=False, error=leg.end_reason)
            agent = db.get(Agent, leg.agent_id)
            interactions.connect_failed(db, it, agent, reason=leg.end_reason or "leg_failed")
        return "applied"
    return "ignored"


def _leg_answered(db: Session, it: Interaction, call: Call, leg: CallLeg, ev: NormalizedEvent) -> None:
    now = ev.occurred_at
    if leg.leg_type == "customer":
        if call.direction == "outbound":
            call.answered_at = now
            it.status = "active"
            it.connected_at = it.connected_at or now
            it.version += 1
            if it.owner_agent_id:
                part = interactions.open_participation(db, it.id, it.owner_agent_id)
                if part and part.connected_at is None:
                    part.connected_at = now
                agent = db.get(Agent, it.owner_agent_id)
                if agent.state != AgentState.ON_INTERACTION:
                    agent_state.transition(db, agent, AgentState.ON_INTERACTION, reason="outbound_answered",
                                           source="provider", force=True)
            att = db.scalar(select(OutboundAttempt).where(OutboundAttempt.interaction_id == it.id))
            if att:
                att.status = "connected"
            events.timeline(db, it, "outbound.answered", "provider", occurred_at=now)
            recording.start_for_connected_call(db, it, call)
        return
    if leg.leg_type == "agent" and leg.agent_id:
        if call.direction == "outbound":
            events.timeline(db, it, "outbound.agent_leg_connected", "provider", occurred_at=now)
            return
        calls.ack(db, ev.request_id, ok=True)
        agent = db.get(Agent, leg.agent_id)
        part = interactions.open_participation(db, it.id, agent.id)
        if part:
            part.connected_at = now
            part.leg_id = leg.id
        it.status = "active"
        it.connected_at = it.connected_at or now
        it.version += 1
        call.answered_at = call.answered_at or now
        interactions.close_queue_entry(db, it, "answered", now)
        if agent.state != AgentState.ON_INTERACTION:
            agent_state.transition(db, agent, AgentState.ON_INTERACTION, reason=f"connected:{it.reference}",
                                   source="provider", force=agent.state == AgentState.UNAVAILABLE)
        events.timeline(db, it, "agent.connected", "provider", occurred_at=now, agent=agent.display_name,
                        note="Provider confirmed the agent leg is connected." +
                             (" Simulated: no audio path." if it.is_simulated else ""))
        rec = recording.start_for_connected_call(db, it, call)
        if rec and db.scalar(select(InteractionEvent.id).where(InteractionEvent.interaction_id == it.id,
                                                               InteractionEvent.type == "recording.notice_played")
                             .limit(1)):
            rec.notice_played_confirmed = True
        return
    if leg.leg_type == "consult" and leg.agent_id:
        target = db.get(Agent, leg.agent_id)
        part = db.scalar(select(AgentParticipation).where(AgentParticipation.interaction_id == it.id,
                                                          AgentParticipation.agent_id == target.id,
                                                          AgentParticipation.ended_at.is_(None)))
        if part:
            part.connected_at = now
            part.leg_id = leg.id
        ts = dict(it.transfer_state or {})
        it.transfer_state = {**ts, "status": "consult_connected", "connected_at": now.isoformat()}
        it.version += 1
        target.current_interaction_id = it.id
        if target.state != AgentState.ON_INTERACTION:
            agent_state.transition(db, target, AgentState.ON_INTERACTION, reason=f"consult:{it.reference}",
                                   source="provider", force=True)
        events.timeline(db, it, "consult.connected", "provider", occurred_at=now, agent=target.display_name)
        if it.owner_agent_id:
            events.to_agent(db, it.org_id, it.owner_agent_id, "consult.connected", interaction_id=it.id)


def _call_completed(db: Session, it: Interaction, call: Call, ev: NormalizedEvent) -> str:
    if call.status == "completed":
        return "stale_ignored"
    call.status = "completed"
    call.ended_at = ev.occurred_at
    call.end_reason = ev.data.get("end_reason")
    for leg in db.scalars(select(CallLeg).where(CallLeg.call_id == call.id)):
        _hold_close(db, it, leg, ev.occurred_at)
        if leg.status not in TERMINAL_LEG:
            leg.status = "completed"
            leg.ended_at = ev.occurred_at
            leg.end_reason = call.end_reason
    calls.ack(db, ev.request_id, ok=True)
    att = db.scalar(select(OutboundAttempt).where(OutboundAttempt.interaction_id == it.id))
    if att:
        if att.status == "dialling":
            att.status = call.end_reason if call.end_reason in ("no_answer", "busy") else "failed"
        att.ended_at = ev.occurred_at
    ts = dict(it.transfer_state or {})
    if ts.get("status") in ("consult_ringing", "consult_connected"):
        it.transfer_state = {**ts, "status": "failed", "failure_reason": "call_ended_during_consult"}
        if ts.get("target_agent_id"):
            target = db.get(Agent, uuid.UUID(ts["target_agent_id"]))
            if target.state == AgentState.CALL_OFFERED:
                agent_state.transition(db, target, AgentState.AVAILABLE, reason="call_ended", source="provider")
    interactions.begin_wrap_up(db, it, ev.occurred_at, call.end_reason)
    return "applied"


def _payment(db: Session, it: Interaction, ev: NormalizedEvent) -> str:
    sess = db.scalar(select(SecurePaymentSession).where(SecurePaymentSession.interaction_id == it.id)
                     .order_by(SecurePaymentSession.started_at.desc()).limit(1))
    if sess is None:
        return "unmatched"
    if ev.type == "payment.started":
        sess.status = "in_progress"
        sess.provider_session_id = ev.data.get("payment_session_id")
        sess.recording_paused_confirmed = bool(ev.data.get("recording_paused"))
        calls.ack(db, ev.request_id, ok=True)
        events.timeline(db, it, "payment.started", "provider", occurred_at=ev.occurred_at,
                        recording_paused_confirmed=sess.recording_paused_confirmed,
                        note="Card details are captured by the provider. They never reach this application.")
    elif ev.type == "payment.completed":
        sess.status = "completed" if ev.data.get("result") == "approved" else "declined"
        sess.result_reference = ev.data.get("reference")
        sess.ended_at = ev.occurred_at
        events.timeline(db, it, "payment.completed", "provider", occurred_at=ev.occurred_at,
                        result=ev.data.get("result"), reference=sess.result_reference)
    elif ev.type == "payment.failed":
        sess.status = "failed"
        sess.ended_at = ev.occurred_at
    return "applied"


def _monitor(db: Session, it: Interaction, ev: NormalizedEvent) -> str:
    ms = db.scalar(select(MonitoringSession).where(MonitoringSession.interaction_id == it.id,
                                                   MonitoringSession.status.in_(["requested", "active"]))
                   .order_by(MonitoringSession.started_at.desc()).limit(1))
    if ms is None:
        return "unmatched"
    if ev.type == "monitor.started":
        ms.status = "active"
        ms.provider_leg_id = ev.provider_leg_id
        events.to_agent(db, it.org_id, ms.agent_id, "monitoring.started", interaction_id=it.id, mode=ms.mode)
    else:
        ms.status = "ended"
        ms.ended_at = ev.occurred_at
        events.to_agent(db, it.org_id, ms.agent_id, "monitoring.ended", interaction_id=it.id)
    events.timeline(db, it, ev.type, "provider", occurred_at=ev.occurred_at, mode=ms.mode)
    return "applied"
