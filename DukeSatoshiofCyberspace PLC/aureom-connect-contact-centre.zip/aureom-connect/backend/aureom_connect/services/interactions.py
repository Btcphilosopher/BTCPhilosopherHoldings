"""Interaction lifecycle: inbound creation, IVR, queueing, offers, acceptance, wrap-up."""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta
from typing import Any

from sqlalchemy import func, select, update
from sqlalchemy.orm import Session

from ..adapters.telephony.registry import get_provider
from ..db import utcnow
from ..errors import Forbidden, InvalidTransition, NotFound, OwnershipConflict, ValidationFailed
from ..models import (Agent, AgentParticipation, Call, CallControl, CallLeg, Callback, Interaction, IvrMenu,
                      OutcomeCode, PhoneNumber, Queue, QueueEntry, Task)
from ..models.enums import AgentState
from . import agent_state, customers, events, recording, refs, routing


def identity_for(agent_id: uuid.UUID) -> str:
    return f"agent:{agent_id}"


def agent_from_identity(db: Session, identity: str | None) -> Agent | None:
    if not identity or not identity.startswith("agent:"):
        return None
    try:
        return db.get(Agent, uuid.UUID(identity.split(":", 1)[1]))
    except ValueError:
        return None


def get_interaction(db: Session, org_id: uuid.UUID, interaction_id: uuid.UUID, *, lock: bool = False) -> Interaction:
    q = select(Interaction).where(Interaction.id == interaction_id, Interaction.org_id == org_id)
    if lock:
        q = q.with_for_update()
    it = db.scalar(q)
    if it is None:
        raise NotFound("Interaction not found")
    return it


def primary_call(db: Session, interaction_id: uuid.UUID) -> Call | None:
    return db.scalar(select(Call).where(Call.interaction_id == interaction_id).order_by(Call.created_at.desc()).limit(1))


def legs_of(db: Session, call_id: uuid.UUID) -> list[CallLeg]:
    return list(db.scalars(select(CallLeg).where(CallLeg.call_id == call_id).order_by(CallLeg.created_at)))


def customer_leg(db: Session, call: Call) -> CallLeg | None:
    return db.scalar(select(CallLeg).where(CallLeg.call_id == call.id, CallLeg.leg_type == "customer"))


def agent_leg(db: Session, call: Call, agent_id: uuid.UUID) -> CallLeg | None:
    return db.scalar(select(CallLeg).where(CallLeg.call_id == call.id, CallLeg.agent_id == agent_id,
                                           CallLeg.status.in_(["ringing", "answered", "initiated"]))
                     .order_by(CallLeg.created_at.desc()).limit(1))


def open_participation(db: Session, interaction_id: uuid.UUID, agent_id: uuid.UUID) -> AgentParticipation | None:
    return db.scalar(select(AgentParticipation).where(
        AgentParticipation.interaction_id == interaction_id, AgentParticipation.agent_id == agent_id,
        AgentParticipation.wrap_ended_at.is_(None), AgentParticipation.outcome.is_(None))
        .order_by(AgentParticipation.created_at.desc()).limit(1))


# --------------------------------------------------------------------------- creation

def new_interaction(db: Session, org_id: uuid.UUID, *, channel: str, direction: str, status: str, source: str,
                    is_simulated: bool = False, **kw: Any) -> Interaction:
    it = Interaction(org_id=org_id, reference=refs.next_ref(db, org_id, "interaction"), channel=channel,
                     direction=direction, status=status, source=source, is_simulated=is_simulated,
                     match_hint=kw.pop("match_hint", {}), required_skills=kw.pop("required_skills", []),
                     ivr_path=[], transfer_state={}, **kw)
    db.add(it)
    db.flush()
    return it


def handle_inbound_call(db: Session, provider: str, ev) -> Interaction | None:
    to_number = ev.data.get("to_number")
    from_number = ev.data.get("from_number") or "unknown"
    number = db.scalar(select(PhoneNumber).where(PhoneNumber.e164 == to_number))
    if number is None:
        return None
    it = new_interaction(db, number.org_id, channel="voice", direction="inbound", status="ivr", source=provider,
                         is_simulated=(provider == "simulated"), match_hint={"ani": from_number})
    call = Call(org_id=it.org_id, interaction_id=it.id, provider=provider, provider_call_id=ev.provider_call_id,
                direction="inbound", from_number=from_number, to_number=to_number, status="in_progress",
                started_at=ev.occurred_at)
    db.add(call)
    db.flush()
    leg_id = ev.data.get("customer_leg_id") or ev.provider_leg_id
    if leg_id:
        db.add(CallLeg(org_id=it.org_id, call_id=call.id, provider_leg_id=leg_id, leg_type="customer",
                       external_number=from_number, status="initiated", started_at=ev.occurred_at))
    cands = customers.match_by_phone(db, it.org_id, from_number)
    it.match_hint = {"ani": from_number, "candidate_ids": [str(c["customer_id"]) for c in cands],
                     "note": "Telephone number is a matching hint, not proof of identity."}
    it.customer_match_status = "candidates" if cands else "unmatched"
    events.timeline(db, it, "call.received", "provider", occurred_at=ev.occurred_at, to=to_number,
                    candidates=len(cands), simulated=it.is_simulated)
    menu = db.get(IvrMenu, number.ivr_menu_id) if number.ivr_menu_id else None
    if menu is None:
        q = db.get(Queue, number.default_queue_id) if number.default_queue_id else None
        if q:
            enqueue(db, it, q, reason="default_queue")
        return it
    it.ivr_path = [{"node": menu.definition.get("start"), "menu_id": str(menu.id), "version": menu.version}]
    # Out of hours handling is decided by the IVR's start node queue (if any) or the menu's closed action.
    start_queue_code = menu.definition.get("hours_queue")
    if start_queue_code:
        q = db.scalar(select(Queue).where(Queue.org_id == it.org_id, Queue.code == start_queue_code))
        open_, why = routing.is_open(db, q.business_hours_id if q else None, ev.occurred_at)
        if not open_:
            events.timeline(db, it, "ivr.closed", "system", reason=why)
            _ivr_action(db, it, menu.closed_action or {"action": "voicemail"}, ev)
    return it


def handle_ivr_input(db: Session, it: Interaction, digits: str, ev) -> None:
    if it.status != "ivr":
        events.timeline(db, it, "ivr.input_ignored", "provider", digits=digits, status=it.status)
        return
    if not it.ivr_path:
        return
    menu = db.get(IvrMenu, uuid.UUID(it.ivr_path[0]["menu_id"]))
    node_id = it.ivr_path[-1]["node"]
    for d in digits:
        node = menu.definition["nodes"].get(node_id, {})
        opt = node.get("options", {}).get(d)
        if opt is None:
            events.timeline(db, it, "ivr.invalid_digit", "provider", digit=d, node=node_id)
            opt = node.get("timeout_action")
            if opt is None:
                continue
        it.ivr_path = [*it.ivr_path, {"node": node_id, "digit": d, "action": opt.get("action"),
                                      "target": opt.get("target")}]
        if opt.get("language"):
            it.language = opt["language"]
        if opt["action"] == "menu":
            node_id = opt["target"]
            it.ivr_path = [*it.ivr_path, {"node": node_id}]
            continue
        _ivr_action(db, it, opt, ev)
        return


def _ivr_action(db: Session, it: Interaction, opt: dict[str, Any], ev) -> None:
    action = opt.get("action")
    if action == "queue":
        q = db.scalar(select(Queue).where(Queue.org_id == it.org_id, Queue.code == opt["target"]))
        if q is None:
            events.timeline(db, it, "ivr.config_error", "system", target=opt.get("target"))
            return
        if opt.get("urgency_flag"):
            it.urgency_flag = opt["urgency_flag"]  # labelled only; does not alter routing priority
        enqueue(db, it, q, reason="ivr")
    elif action == "voicemail":
        to_voicemail(db, it, reason=opt.get("reason", "ivr_choice"))
    elif action == "callback":
        q = db.scalar(select(Queue).where(Queue.org_id == it.org_id, Queue.code == opt["target"]))
        request_callback_from_ivr(db, it, q)


def enqueue(db: Session, it: Interaction, q: Queue, *, reason: str) -> QueueEntry | None:
    now = utcnow()
    open_, why = routing.is_open(db, q.business_hours_id, now)
    if not open_ and reason in ("ivr", "default_queue"):
        events.timeline(db, it, "queue.closed", "system", queue=q.code, reason=why)
        if q.voicemail_enabled:
            to_voicemail(db, it, reason="queue_closed")
        return None
    seq = db.scalar(select(func.count()).select_from(QueueEntry).where(QueueEntry.interaction_id == it.id)) or 0
    entry = QueueEntry(org_id=it.org_id, interaction_id=it.id, queue_id=q.id, sequence=seq + 1, entered_at=now)
    db.add(entry)
    it.status = "queued"
    it.current_queue_id = q.id
    it.version += 1
    it.required_skills = list(q.required_skills or [])
    it.routing_priority = it.routing_priority or 0
    if it.first_queued_at is None:
        it.first_queued_at = now
    if it.routable_since is None:
        it.routable_since = now
    if q.required_language and not it.language:
        it.language = q.required_language
    db.flush()
    events.timeline(db, it, "queue.entered", "system", queue=q.code, reason=reason, sequence=entry.sequence)
    if it.channel == "voice" and entry.sequence == 1:
        recording.on_enqueued(db, it, q)
    return entry


def close_queue_entry(db: Session, it: Interaction, reason: str, at: datetime | None = None) -> None:
    for entry in db.scalars(select(QueueEntry).where(QueueEntry.interaction_id == it.id, QueueEntry.left_at.is_(None))):
        entry.left_at = at or utcnow()
        entry.exit_reason = reason


def to_voicemail(db: Session, it: Interaction, *, reason: str) -> None:
    close_queue_entry(db, it, "voicemail")
    it.status = "voicemail"
    it.version += 1
    events.timeline(db, it, "voicemail.requested", "system", reason=reason,
                    note="Voicemail capture is simulated: no audio is stored.")
    q = db.get(Queue, it.current_queue_id) if it.current_queue_id else None
    db.add(Task(org_id=it.org_id, kind="back_office", title=f"Voicemail follow-up {it.reference}",
                description="Caller left a (simulated) voicemail. Review and respond.", interaction_id=it.id,
                customer_id=it.customer_id, assignee_queue_id=q.id if q else None, due_at=utcnow() + timedelta(hours=4)))
    call = primary_call(db, it.id)
    if call and call.status == "in_progress":
        get_provider().hangup(call.provider_call_id, request_id=f"voicemail:{it.id}")


def request_callback_from_ivr(db: Session, it: Interaction, q: Queue | None) -> None:
    from . import callbacks as cb_service

    if q is None:
        return
    ani = (it.match_hint or {}).get("ani")
    cb = cb_service.create_callback(db, it.org_id, phone_number=ani, number_confirmation_method="ani_confirmed_in_ivr",
                                    window_start=utcnow(), window_end=utcnow() + timedelta(hours=2), queue=q,
                                    customer_id=it.customer_id, origin_interaction_id=it.id, created_by=None,
                                    created_via="ivr", reason="Requested in IVR while waiting", reserve_capacity=False)
    close_queue_entry(db, it, "callback")
    it.status = "callback_requested"
    it.version += 1
    events.timeline(db, it, "callback.requested", "customer", callback=cb.reference, promise=cb.promise_text)
    call = primary_call(db, it.id)
    if call and call.status == "in_progress":
        get_provider().hangup(call.provider_call_id, request_id=f"callback:{it.id}")


# --------------------------------------------------------------------------- offers

def _pending_offer(db: Session, it: Interaction, agent_id: uuid.UUID, offer_id: uuid.UUID | None):
    from ..models import Offer

    q = select(Offer).where(Offer.interaction_id == it.id, Offer.agent_id == agent_id, Offer.status == "pending")
    if offer_id:
        q = select(Offer).where(Offer.id == offer_id, Offer.interaction_id == it.id)
    return db.scalar(q.with_for_update())


def accept(db: Session, agent: Agent, interaction_id: uuid.UUID, *, offer_id: uuid.UUID | None,
           expected_version: int | None, actor_user_id: uuid.UUID) -> dict[str, Any]:
    """Accept an offer. Ownership is taken with a guarded UPDATE so that at most one agent can win."""
    it = get_interaction(db, agent.org_id, interaction_id)
    offer = _pending_offer(db, it, agent.id, offer_id)
    if offer is None:
        raise OwnershipConflict("No pending offer for you on this interaction", code="OFFER_NOT_PENDING")
    if offer.agent_id != agent.id:
        raise Forbidden("This offer belongs to another agent")
    if offer.status != "pending":
        raise OwnershipConflict(f"Offer is {offer.status}", code="OFFER_NOT_PENDING", details={"status": offer.status})
    if offer.expires_at < utcnow():
        expire_offer(db, offer)
        raise OwnershipConflict("Offer expired before it was accepted", code="OFFER_EXPIRED")
    if agent.reconcile_required:
        from ..errors import ReconciliationRequired

        raise ReconciliationRequired("Reconcile call state before accepting work")
    if offer.kind == "consult":
        from . import calls

        return calls.accept_consult(db, agent, it, offer, actor_user_id=actor_user_id)

    guard = [Interaction.id == it.id, Interaction.owner_agent_id.is_(None), Interaction.status == "offered"]
    if expected_version is not None:
        guard.append(Interaction.version == expected_version)
    new_status = "connecting" if it.channel == "voice" and not it.callback_id and not it.campaign_contact_id else "active"
    res = db.execute(update(Interaction).where(*guard)
                     .values(owner_agent_id=agent.id, status=new_status, version=Interaction.version + 1)
                     .execution_options(synchronize_session=False))
    if res.rowcount != 1:
        db.rollback()
        raise OwnershipConflict("Interaction was already accepted or changed", details={"interaction_id": str(it.id)})
    db.refresh(it)
    now = utcnow()
    offer.status = "accepted"
    offer.responded_at = now
    part = AgentParticipation(org_id=it.org_id, interaction_id=it.id, agent_id=agent.id, role="primary",
                              accepted_at=now)
    db.add(part)
    agent.current_interaction_id = it.id
    events.timeline(db, it, "offer.accepted", "agent", actor_user_id=actor_user_id, agent=agent.display_name)
    if it.channel == "voice" and new_status == "connecting":
        agent_state.transition(db, agent, AgentState.CONNECTING, reason=f"accepted:{it.reference}", source="agent",
                               actor_user_id=actor_user_id)
        db.flush()
        _connect_agent(db, it, agent, offer)
    else:
        close_queue_entry(db, it, "answered", now)
        part.connected_at = now
        if it.connected_at is None:
            it.connected_at = now
        target = AgentState.ON_INTERACTION
        if agent.state != target:
            agent_state.transition(db, agent, target, reason=f"accepted:{it.reference}", source="agent",
                                   actor_user_id=actor_user_id)
        if it.callback_id:
            cb = db.get(Callback, it.callback_id)
            cb.status = "in_progress"
            cb.owner_agent_id = agent.id
            cb.owner_since = now
            cb.version += 1
    return {"interaction_id": it.id, "status": it.status, "version": it.version}


def _connect_agent(db: Session, it: Interaction, agent: Agent, offer) -> None:
    call = primary_call(db, it.id)
    if call is None:
        raise ValidationFailed("Interaction has no call to connect")
    ctl = CallControl(org_id=it.org_id, interaction_id=it.id, call_id=call.id, agent_id=agent.id, action="answer",
                      params={"offer_id": str(offer.id)}, idempotency_key=f"accept:{offer.id}", status="requested",
                      requested_at=utcnow())
    db.add(ctl)
    db.commit()  # persist ownership + control before talking to the provider
    result = get_provider().connect_agent(call.provider_call_id, identity_for(agent.id), request_id=str(ctl.id))
    # Events may already have been applied by a concurrent webhook request: reload before deciding.
    ctl = db.scalar(select(CallControl).where(CallControl.id == ctl.id).with_for_update()
                    .execution_options(populate_existing=True))
    it = db.scalar(select(Interaction).where(Interaction.id == it.id).with_for_update()
                   .execution_options(populate_existing=True))
    agent = db.scalar(select(Agent).where(Agent.id == agent.id).execution_options(populate_existing=True))
    ctl.provider_request_id = str(ctl.id)
    if ctl.status != "requested":
        return
    if result.outcome == "accepted":
        if result.provider_leg_id:
            existing = db.scalar(select(CallLeg).where(CallLeg.call_id == call.id,
                                                       CallLeg.provider_leg_id == result.provider_leg_id))
            if existing is None:
                db.add(CallLeg(org_id=it.org_id, call_id=call.id, provider_leg_id=result.provider_leg_id,
                               leg_type="agent", agent_id=agent.id, status="ringing", started_at=utcnow()))
        events.timeline(db, it, "control.requested", "agent", action="answer", control_id=str(ctl.id),
                        note="Connection requested; waiting for provider confirmation.")
    elif result.outcome == "rejected":
        ctl.status = "failed"
        ctl.error_code, ctl.error_message = result.error_code, result.error_message
        connect_failed(db, it, agent, reason=result.error_code or "provider_rejected")
    else:
        ctl.status = "unknown"
        ctl.error_code = result.error_code
        it.needs_reconciliation = True
        agent_state.mark_reconcile(db, agent, "connect outcome unknown")
        events.timeline(db, it, "control.unknown", "system", action="answer", control_id=str(ctl.id))


def connect_failed(db: Session, it: Interaction, agent: Agent, *, reason: str) -> None:
    """The provider could not connect the agent: put the work back without losing its place."""
    part = open_participation(db, it.id, agent.id)
    if part:
        part.outcome = "failed"
        part.ended_at = utcnow()
        part.wrap_ended_at = utcnow()
    if it.owner_agent_id == agent.id and it.status in ("connecting", "offered"):
        it.owner_agent_id = None
        it.status = "queued"
        it.version += 1
    agent.current_interaction_id = None
    if agent.state in (AgentState.CONNECTING, AgentState.CALL_OFFERED):
        agent_state.transition(db, agent, AgentState.UNAVAILABLE, reason=f"connect_failed:{reason}", source="system")
    events.timeline(db, it, "agent.connect_failed", "provider", agent=agent.display_name, reason=reason)


def reject(db: Session, agent: Agent, interaction_id: uuid.UUID, *, offer_id: uuid.UUID | None, reason: str | None,
           actor_user_id: uuid.UUID) -> None:
    it = get_interaction(db, agent.org_id, interaction_id)
    offer = _pending_offer(db, it, agent.id, offer_id)
    if offer is None or offer.status != "pending":
        raise OwnershipConflict("No pending offer to reject", code="OFFER_NOT_PENDING")
    if offer.agent_id != agent.id:
        raise Forbidden("This offer belongs to another agent")
    offer.status = "rejected"
    offer.responded_at = utcnow()
    offer.response_reason = reason or "declined"
    if offer.kind == "consult":
        from . import calls

        calls.consult_declined(db, it, agent, offer, reason="rejected")
        return
    it.status = "queued"
    it.version += 1
    events.timeline(db, it, "offer.rejected", "agent", actor_user_id=actor_user_id, agent=agent.display_name,
                    reason=offer.response_reason)
    if agent.state == AgentState.CALL_OFFERED:
        agent_state.transition(db, agent, AgentState.AVAILABLE, reason="offer_rejected", source="agent",
                               actor_user_id=actor_user_id)


def expire_offer(db: Session, offer) -> None:
    if offer.status != "pending":
        return
    offer.status = "expired"
    offer.responded_at = utcnow()
    agent = db.get(Agent, offer.agent_id)
    it = db.get(Interaction, offer.interaction_id)
    if offer.kind == "consult":
        from . import calls

        calls.consult_declined(db, it, agent, offer, reason="no_answer")
        return
    if it.status == "offered":
        it.status = "queued"
        it.version += 1
    agent.missed_offer_count += 1
    events.timeline(db, it, "offer.expired", "system", agent=agent.display_name)
    if agent.state == AgentState.CALL_OFFERED:
        agent_state.transition(db, agent, AgentState.UNAVAILABLE, reason="missed_offer", source="system")
    events.to_agent(db, agent.org_id, agent.id, "offer.expired", offer_id=offer.id, interaction_id=it.id)


def withdraw_offers(db: Session, it: Interaction, reason: str) -> None:
    from ..models import Offer

    for offer in db.scalars(select(Offer).where(Offer.interaction_id == it.id, Offer.status == "pending")):
        offer.status = "withdrawn"
        offer.responded_at = utcnow()
        offer.response_reason = reason
        agent = db.get(Agent, offer.agent_id)
        events.to_agent(db, agent.org_id, agent.id, "offer.withdrawn", offer_id=offer.id, interaction_id=it.id,
                        reason=reason)
        if agent.state == AgentState.CALL_OFFERED:
            agent_state.transition(db, agent, AgentState.AVAILABLE, reason=f"offer_withdrawn:{reason}", source="system")


# --------------------------------------------------------------------------- end of call / wrap-up

def begin_wrap_up(db: Session, it: Interaction, at: datetime, reason: str | None) -> None:
    """Call ended: every connected participant enters after-call work; queued callers are abandoned."""
    it.ended_at = it.ended_at or at
    it.end_reason = reason
    if it.status in ("queued", "offered", "ivr"):
        was_queued = it.status in ("queued", "offered")
        withdraw_offers(db, it, "caller_hung_up")
        close_queue_entry(db, it, "abandoned" if was_queued else "ivr_hangup", at)
        it.status = "abandoned" if was_queued else "completed"
        it.version += 1
        events.timeline(db, it, "call.abandoned" if was_queued else "call.ended_in_ivr", "provider", occurred_at=at,
                        reason=reason)
        return
    if it.status in ("voicemail", "callback_requested", "completed", "wrap_up", "abandoned"):
        return
    parts = db.scalars(select(AgentParticipation).where(AgentParticipation.interaction_id == it.id,
                                                        AgentParticipation.ended_at.is_(None))).all()
    any_connected = False
    for part in parts:
        part.ended_at = at
        agent = db.get(Agent, part.agent_id)
        # Outbound attempts always get wrap-up so the attempt outcome is dispositioned (e.g. no answer).
        if part.connected_at is None and it.direction != "outbound":
            part.outcome = "failed"
            part.wrap_ended_at = at
            if agent.state in (AgentState.CONNECTING, AgentState.CALL_OFFERED):
                agent_state.transition(db, agent, AgentState.AVAILABLE, reason="call_ended_before_connect",
                                       source="system")
            continue
        any_connected = True
        part.wrap_started_at = utcnow()
        if agent.state != AgentState.AFTER_CALL_WORK:
            agent_state.transition(db, agent, AgentState.AFTER_CALL_WORK, reason=f"call_ended:{reason}",
                                   source="provider", force=agent.state not in agent_state.ALLOWED or
                                   AgentState.AFTER_CALL_WORK not in agent_state.ALLOWED.get(agent.state, set()))
        events.to_agent(db, agent.org_id, agent.id, "interaction.wrap_up", interaction_id=it.id)
    withdraw_offers(db, it, "call_ended")
    if any_connected or it.owner_agent_id:
        it.status = "wrap_up"
    else:
        it.status = "completed" if it.direction == "outbound" else "abandoned"
        close_queue_entry(db, it, "abandoned", at)
    it.version += 1
    events.timeline(db, it, "call.ended", "provider", occurred_at=at, reason=reason)


def complete_wrap_up(db: Session, agent: Agent, interaction_id: uuid.UUID, *, disposition_code: str, note: str | None,
                     expected_version: int | None, actor_user_id: uuid.UUID) -> dict[str, Any]:
    it = get_interaction(db, agent.org_id, interaction_id, lock=True)
    part = db.scalar(select(AgentParticipation).where(
        AgentParticipation.interaction_id == it.id, AgentParticipation.agent_id == agent.id,
        AgentParticipation.wrap_started_at.is_not(None), AgentParticipation.wrap_ended_at.is_(None)))
    if part is None:
        if it.channel != "voice" and it.owner_agent_id == agent.id and it.status == "active":
            part = open_participation(db, it.id, agent.id)
            part.ended_at = utcnow()
            part.wrap_started_at = utcnow()
            it.ended_at = utcnow()
            it.status = "wrap_up"
        else:
            raise InvalidTransition("No after-call work open for you on this interaction",
                                    details={"status": it.status})
    if expected_version is not None and it.version != expected_version:
        from ..errors import VersionConflict

        raise VersionConflict("Interaction changed since it was read",
                              details={"expected_version": expected_version, "current_version": it.version})
    oc = db.scalar(select(OutcomeCode).where(OutcomeCode.org_id == it.org_id, OutcomeCode.code == disposition_code,
                                             OutcomeCode.active.is_(True)))
    if oc is None:
        raise ValidationFailed("Unknown disposition code", details={"code": disposition_code})
    now = utcnow()
    part.wrap_ended_at = now
    part.outcome = part.outcome or "handled"
    is_owner = it.owner_agent_id == agent.id
    if is_owner:
        it.disposition_code = disposition_code
        it.disposition_note = note
        it.status = "completed"
        it.wrap_completed_at = now
        it.version += 1
    events.timeline(db, it, "wrap_up.completed", "agent", actor_user_id=actor_user_id, agent=agent.display_name,
                    disposition=disposition_code, owner=is_owner)
    if it.callback_id and is_owner:
        from . import callbacks as cb_service

        cb_service.on_interaction_completed(db, it, disposition_code)
    if it.campaign_contact_id and is_owner:
        from . import outbound

        outbound.on_campaign_interaction_completed(db, it, disposition_code)
    agent.current_interaction_id = None
    others_open = db.scalar(select(func.count()).select_from(AgentParticipation).where(
        AgentParticipation.agent_id == agent.id, AgentParticipation.wrap_ended_at.is_(None),
        AgentParticipation.outcome.is_(None)))
    if others_open:
        return {"interaction_id": it.id, "status": it.status, "agent_state": agent.state}
    conflicts = agent_state.conflicting_call_state(db, agent)
    if conflicts:
        agent_state.mark_reconcile(db, agent, "; ".join(conflicts))
        agent_state.transition(db, agent, AgentState.UNAVAILABLE, reason="wrap_up_done_conflict", source="system")
    else:
        ready = agent_state.readiness(db, agent)
        target = AgentState.AVAILABLE if ready["ready"] else AgentState.UNAVAILABLE
        # Chat/e-mail work has no telephony after-call state; the agent returns from on_interaction directly.
        agent_state.transition(db, agent, target, reason="wrap_up_completed" if ready["ready"]
                               else "wrap_up_completed_not_ready", source="system",
                               force=it.channel != "voice" and agent.state == AgentState.ON_INTERACTION)
    return {"interaction_id": it.id, "status": it.status, "agent_state": agent.state}
