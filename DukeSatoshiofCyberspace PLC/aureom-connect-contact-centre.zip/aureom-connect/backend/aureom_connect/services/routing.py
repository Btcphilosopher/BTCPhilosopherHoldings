"""Transparent routing baseline.

Algorithm (documented in docs/routing.md):

1. Candidate work = interactions in ``queued`` with no pending offer, ordered by
   queue routing priority (desc), interaction routing priority (desc), then
   longest waiting (``routable_since`` asc). Routing priority is operational
   ordering only; urgency flags (safeguarding, clinical, legal) are separate
   labels and never change routing automatically.
2. For each, eligible agents = state ``available`` (or chat capacity),
   application connected, provider-confirmed device registration (voice),
   no reconciliation pending, member of the queue, all required skills,
   matching language, and not having declined/missed this interaction.
3. Pick the agent idle longest (``available_since`` asc).
4. Create an offer with a timeout. Every evaluation that excludes agents is
   stored as a ``RoutingDecision`` with per-agent reasons.

Concurrency: a per-organisation advisory lock serialises routing passes across
API and worker processes; rows are additionally locked ``FOR UPDATE``.
"""
from __future__ import annotations

import uuid
import zlib
from datetime import datetime, time, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from sqlalchemy import func, select, text
from sqlalchemy.orm import Session

from ..db import utcnow
from ..models import (Agent, AgentQueueMembership, AgentSkill, BusinessHours, Holiday, Interaction, Offer, Queue,
                      QueueEntry, RoutingDecision, Skill)
from ..models.enums import AgentState, Presence, TelephonyRegistration
from . import agent_state, events

REDECISION_SECONDS = 60


# --------------------------------------------------------------------------- business hours

def _parse(t: str) -> time:
    h, m = t.split(":")
    return time(int(h), int(m))


def is_open(db: Session, bh_id: uuid.UUID | None, at: datetime | None = None) -> tuple[bool, str]:
    if bh_id is None:
        return True, "no business hours configured (always open)"
    bh = db.get(BusinessHours, bh_id)
    if bh is None:
        return True, "business hours not found (treated as open)"
    tz = ZoneInfo(bh.timezone)
    local = (at or utcnow()).astimezone(tz)
    hol = db.scalar(select(Holiday).where(Holiday.business_hours_id == bh.id, Holiday.day == local.date()))
    if hol is not None:
        intervals = hol.intervals or []
        label = f"holiday: {hol.name}"
    else:
        intervals = bh.weekly.get(str(local.isoweekday()), [])
        label = f"weekday {local.isoweekday()}"
    for start, end in intervals:
        if _parse(start) <= local.time() < _parse(end):
            return True, f"open ({label} {start}-{end} {bh.timezone})"
    return False, f"closed ({label}, local time {local.strftime('%H:%M')} {bh.timezone})"


# --------------------------------------------------------------------------- eligibility

def _agent_skill_codes(db: Session, org_id: uuid.UUID) -> dict[uuid.UUID, set[str]]:
    rows = db.execute(select(AgentSkill.agent_id, Skill.code).join(Skill, Skill.id == AgentSkill.skill_id)
                      .where(Skill.org_id == org_id)).all()
    out: dict[uuid.UUID, set[str]] = {}
    for agent_id, code in rows:
        out.setdefault(agent_id, set()).add(code)
    return out


def _memberships(db: Session, org_id: uuid.UUID) -> dict[uuid.UUID, set[uuid.UUID]]:
    rows = db.execute(select(AgentQueueMembership.agent_id, AgentQueueMembership.queue_id)
                      .join(Agent, Agent.id == AgentQueueMembership.agent_id).where(Agent.org_id == org_id)).all()
    out: dict[uuid.UUID, set[uuid.UUID]] = {}
    for a, q in rows:
        out.setdefault(a, set()).add(q)
    return out


def _active_owned(db: Session, org_id: uuid.UUID) -> dict[uuid.UUID, list[str]]:
    rows = db.execute(select(Interaction.owner_agent_id, Interaction.channel).where(
        Interaction.org_id == org_id, Interaction.owner_agent_id.is_not(None),
        Interaction.status.in_(["offered", "connecting", "active", "wrap_up"]))).all()
    out: dict[uuid.UUID, list[str]] = {}
    for a, ch in rows:
        out.setdefault(a, []).append(ch)
    return out


def evaluate_agent(agent: Agent, interaction: Interaction, queue: Queue, *, skills: set[str], queues: set[uuid.UUID],
                   active_channels: list[str], declined: set[uuid.UUID]) -> list[str]:
    """Return exclusion reasons (empty list = eligible)."""
    reasons: list[str] = []
    voice = interaction.channel == "voice"
    if voice:
        if agent.state != AgentState.AVAILABLE:
            reasons.append(f"state is {agent.state}")
        if active_channels:
            reasons.append("already handling an interaction")
    else:
        if agent.state not in (AgentState.AVAILABLE, AgentState.ON_INTERACTION):
            reasons.append(f"state is {agent.state}")
        if any(ch == "voice" for ch in active_channels):
            reasons.append("on a voice interaction")
        if len(active_channels) >= agent.max_concurrent_chats:
            reasons.append("at concurrent chat/email capacity")
    if agent.presence != Presence.ONLINE:
        reasons.append("application not connected")
    if voice and agent.telephony_registration != TelephonyRegistration.REGISTERED:
        reasons.append("no provider-confirmed telephony registration")
    if agent.reconcile_required:
        reasons.append("call state reconciliation pending")
    if queue.id not in queues:
        reasons.append(f"not a member of queue {queue.code}")
    required = set(interaction.required_skills or queue.required_skills or [])
    missing = required - skills
    if missing:
        reasons.append(f"missing skills: {', '.join(sorted(missing))}")
    lang = interaction.language or queue.required_language
    if lang and lang not in (agent.languages or []):
        reasons.append(f"does not speak '{lang}'")
    if agent.id in declined:
        reasons.append("declined or missed this interaction already")
    return reasons


def _declined_agents(db: Session, interaction_id: uuid.UUID) -> set[uuid.UUID]:
    return set(db.scalars(select(Offer.agent_id).where(Offer.interaction_id == interaction_id,
                                                       Offer.status.in_(["rejected", "expired"]))).all())


def _record_decision(db: Session, interaction: Interaction, queue: Queue, outcome: str, selected: uuid.UUID | None,
                     candidates: list[dict[str, Any]], explanation: str, force: bool = False) -> RoutingDecision | None:
    if not force:
        last = db.scalar(select(RoutingDecision).where(RoutingDecision.interaction_id == interaction.id)
                         .order_by(RoutingDecision.decided_at.desc()).limit(1))
        if last and last.outcome == outcome and (utcnow() - last.decided_at).total_seconds() < REDECISION_SECONDS \
                and last.candidates == candidates:
            return None
    d = RoutingDecision(org_id=interaction.org_id, interaction_id=interaction.id, queue_id=queue.id, outcome=outcome,
                        selected_agent_id=selected, candidates=candidates, explanation=explanation, decided_at=utcnow())
    db.add(d)
    db.flush()
    if outcome != "offered":
        events.to_supervisors(db, interaction.org_id, "routing.no_eligible_agent", interaction_id=interaction.id,
                              queue=queue.code)
    return d


def _org_lock(db: Session, org_id: uuid.UUID) -> None:
    db.execute(text("SELECT pg_advisory_xact_lock(:k)"), {"k": zlib.crc32(f"route:{org_id}".encode())})


def route_org(db: Session, org_id: uuid.UUID, *, limit: int = 50) -> list[Offer]:
    """One routing pass. Caller commits."""
    _org_lock(db, org_id)
    pending_offer = select(Offer.id).where(Offer.interaction_id == Interaction.id, Offer.status == "pending").exists()
    rows = db.execute(
        select(Interaction, Queue)
        .join(Queue, Queue.id == Interaction.current_queue_id)
        .where(Interaction.org_id == org_id, Interaction.status == "queued", ~pending_offer)
        .order_by(Queue.routing_priority.desc(), Interaction.routing_priority.desc(),
                  Interaction.routable_since.asc())
        .limit(limit)
        .with_for_update(of=Interaction, skip_locked=True)
    ).all()
    if not rows:
        return []
    agents = db.scalars(select(Agent).where(Agent.org_id == org_id).with_for_update(skip_locked=True)).all()
    skills = _agent_skill_codes(db, org_id)
    member = _memberships(db, org_id)
    active = _active_owned(db, org_id)
    offers: list[Offer] = []
    for interaction, queue in rows:
        declined = _declined_agents(db, interaction.id)
        candidates: list[dict[str, Any]] = []
        eligible: list[Agent] = []
        for agent in agents:
            reasons = evaluate_agent(agent, interaction, queue, skills=skills.get(agent.id, set()),
                                     queues=member.get(agent.id, set()), active_channels=active.get(agent.id, []),
                                     declined=declined)
            idle = (utcnow() - agent.available_since).total_seconds() if agent.available_since else None
            candidates.append({"agent_id": str(agent.id), "agent": agent.display_name, "eligible": not reasons,
                               "reasons": reasons, "idle_seconds": round(idle) if idle is not None else None})
            if not reasons:
                eligible.append(agent)
        if not eligible:
            _record_decision(db, interaction, queue, "no_eligible_agent", None, candidates,
                             "No agent met every eligibility rule; interaction remains queued.")
            continue
        eligible.sort(key=lambda a: (a.available_since or utcnow(), a.display_name))
        chosen = eligible[0]
        decision = _record_decision(db, interaction, queue, "offered", chosen.id, candidates,
                                    f"Longest-idle eligible agent selected ({chosen.display_name}) among "
                                    f"{len(eligible)} eligible.", force=True)
        offers.append(make_offer(db, interaction, queue, chosen, decision.id if decision else None))
        # Update local views so the same agent is not offered two voice calls in one pass.
        active.setdefault(chosen.id, []).append(interaction.channel)
    return offers


def make_offer(db: Session, interaction: Interaction, queue: Queue, agent: Agent,
               decision_id: uuid.UUID | None, kind: str = "queue") -> Offer:
    entry = db.scalar(select(QueueEntry).where(QueueEntry.interaction_id == interaction.id,
                                               QueueEntry.left_at.is_(None)))
    now = utcnow()
    offer = Offer(org_id=interaction.org_id, interaction_id=interaction.id, agent_id=agent.id,
                  queue_entry_id=entry.id if entry else None, kind=kind, status="pending", offered_at=now,
                  expires_at=now + timedelta(seconds=queue.offer_timeout_seconds), routing_decision_id=decision_id)
    db.add(offer)
    if entry:
        entry.offers_made += 1
    interaction.status = "offered"
    interaction.version += 1
    if interaction.channel == "voice" or agent.state == AgentState.AVAILABLE:
        agent_state.transition(db, agent, AgentState.CALL_OFFERED, reason=f"offer:{interaction.reference}",
                               source="system")
    db.flush()
    events.to_agent(db, agent.org_id, agent.id, "offer.created", offer_id=offer.id, interaction_id=interaction.id,
                    channel=interaction.channel, queue=queue.code, expires_at=offer.expires_at,
                    reference=interaction.reference)
    events.timeline(db, interaction, "offer.created", "system", agent_id=str(agent.id), agent=agent.display_name,
                    offer_id=str(offer.id), expires_at=offer.expires_at.isoformat())
    return offer


def queue_snapshot(db: Session, org_id: uuid.UUID) -> list[dict[str, Any]]:
    now = utcnow()
    queues = db.scalars(select(Queue).where(Queue.org_id == org_id, Queue.active.is_(True))
                        .order_by(Queue.routing_priority.desc(), Queue.name)).all()
    out = []
    for q in queues:
        waiting = db.execute(select(func.count(), func.min(Interaction.routable_since)).where(
            Interaction.current_queue_id == q.id, Interaction.status.in_(["queued", "offered"]))).one()
        open_, why = is_open(db, q.business_hours_id)
        out.append({"id": q.id, "code": q.code, "name": q.name, "channel": q.channel, "waiting": waiting[0],
                    "longest_wait_seconds": round((now - waiting[1]).total_seconds()) if waiting[1] else 0,
                    "open": open_, "hours_status": why, "routing_priority": q.routing_priority})
    return out
