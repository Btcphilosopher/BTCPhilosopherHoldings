"""Contact-centre metrics with explicit definitions.

Time basis: **provider event time** (queue entry, connection, end) – never
ingestion time. Ingestion lag is reported separately.

Population: inbound voice interactions whose *first* queue entry falls in the
window [start, end). An interaction is counted once regardless of transfers,
overflow or re-queueing, and is attributed to its first queue.
"""
from __future__ import annotations

import statistics
import uuid
from datetime import datetime, timedelta
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..models import (Agent, AgentParticipation, Callback, Case, CaseInteraction, Feedback, Interaction, Organisation,
                      OutboundAttempt, ProviderEvent, Queue, QueueEntry, SlaPolicy)

DEFINITIONS: dict[str, dict[str, str]] = {
    "offered": {"definition": "Inbound voice interactions whose first queue entry occurred in the window.",
                "denominator": "-", "exclusions": "Calls ending in the IVR before reaching a queue; outbound calls.",
                "transfers": "Counted once; attributed to the first queue."},
    "answered": {"definition": "Offered interactions connected to an agent (provider-confirmed agent leg).",
                 "denominator": "offered", "exclusions": "-", "transfers": "Counted once."},
    "abandoned": {"definition": "Offered interactions where the caller hung up before connection, waiting at least "
                                "the short-abandon threshold.",
                  "denominator": "offered − short_abandoned", "exclusions": "Short abandons, voicemail and callback "
                                                                         "deflections are reported separately.",
                  "transfers": "-"},
    "short_abandoned": {"definition": "Abandoned within the organisation's short-abandon threshold (seconds).",
                        "denominator": "-", "exclusions": "-", "transfers": "-"},
    "service_level": {"definition": "Answered within the queue's answer threshold ÷ (offered − short abandoned).",
                      "denominator": "offered − short_abandoned",
                      "exclusions": "Short abandons. Deflections count against service level (not excluded).",
                      "transfers": "Wait measured from first queue entry to first agent connection."},
    "queue_wait": {"definition": "First queue entry → first agent connection (answered) or → end (abandoned).",
                   "denominator": "answered (ASA)", "exclusions": "-",
                   "transfers": "Includes time spent in overflow queues; excludes time after the first connection."},
    "talk_time": {"definition": "Σ over agent participations of (end − connection) − hold.",
                  "denominator": "answered", "exclusions": "Consult-only participations are included "
                                                           "(the time was spent on this customer).",
                  "transfers": "All agents' talk time on one interaction is summed."},
    "hold_time": {"definition": "Σ provider-confirmed hold intervals (hold → resume events).",
                  "denominator": "answered", "exclusions": "-", "transfers": "Summed across agents."},
    "after_call_work": {"definition": "Σ (wrap-up end − wrap-up start) per participation.",
                        "denominator": "answered", "exclusions": "Wrap-up still open at report time.",
                        "transfers": "Each agent's ACW counted."},
    "handling_time": {"definition": "Average (talk + hold + ACW) per answered interaction.",
                      "denominator": "answered", "exclusions": "-",
                      "transfers": "Per interaction, so a transfer does not create two contacts. Shorter is not "
                                   "automatically better: read alongside resolution, repeat contacts and feedback."},
    "transfers": {"definition": "Answered interactions with at least one completed transfer.",
                  "denominator": "answered", "exclusions": "Failed/cancelled consultations.", "transfers": "-"},
    "callback_completion": {"definition": "Callbacks requested in the window that reached 'completed' ÷ those "
                                          "that reached a final state (completed, exhausted, expired).",
                            "denominator": "requested − cancelled − still open",
                            "exclusions": "Cancelled callbacks; callbacks still open are reported separately.",
                            "transfers": "-"},
    "repeat_contacts": {"definition": "Offered interactions with an identified customer who had another "
                                      "interaction in the preceding N days.",
                        "denominator": "offered with identified customer",
                        "exclusions": "Unidentified callers.", "transfers": "Transferred calls are one contact."},
    "customer_feedback": {"definition": "Post-contact survey scores 1–5 for interactions in the population; "
                                        "CSAT = share of 4–5.",
                          "denominator": "responses (response rate = responses ÷ answered)",
                          "exclusions": "-", "transfers": "-"},
    "case_resolution": {"definition": "Cases created in the window that were explicitly resolved (with outcome). "
                                      "A call ending never resolves a case. FCR = resolved with exactly one linked "
                                      "interaction and never reopened.",
                        "denominator": "cases created", "exclusions": "-", "transfers": "-"},
}


def _p(values: list[float], q: float) -> float | None:
    if not values:
        return None
    s = sorted(values)
    k = (len(s) - 1) * q
    f = int(k)
    c = min(f + 1, len(s) - 1)
    return round(s[f] + (s[c] - s[f]) * (k - f), 1)


def summary(db: Session, org_id: uuid.UUID, start: datetime, end: datetime, queue_id: uuid.UUID | None = None,
            include_synthetic_history: bool = True) -> dict[str, Any]:
    org = db.get(Organisation, org_id)
    short_s = int(org.settings.get("short_abandon_seconds", 5))
    repeat_days = int(org.settings.get("repeat_contact_days", 7))
    first = (select(QueueEntry.interaction_id, QueueEntry.queue_id, QueueEntry.entered_at)
             .where(QueueEntry.sequence == 1, QueueEntry.entered_at >= start, QueueEntry.entered_at < end)
             .subquery())
    q = (select(Interaction, first.c.queue_id, first.c.entered_at).join(first, first.c.interaction_id == Interaction.id)
         .where(Interaction.org_id == org_id, Interaction.channel == "voice", Interaction.direction == "inbound"))
    if queue_id:
        q = q.where(first.c.queue_id == queue_id)
    if not include_synthetic_history:
        q = q.where(Interaction.source != "synthetic_history")
    rows = db.execute(q).all()
    thresholds: dict[uuid.UUID, int] = {}
    for qq in db.scalars(select(Queue).where(Queue.org_id == org_id)):
        pol = db.get(SlaPolicy, qq.sla_policy_id) if qq.sla_policy_id else None
        thresholds[qq.id] = pol.target_seconds if pol else int(org.settings.get("service_level_threshold_seconds", 20))

    offered = len(rows)
    answered = abandoned = short_ab = voicemail = callback = in_progress = within_sl = transferred = 0
    waits_answered: list[float] = []
    talk = hold = acw = 0.0
    ids: list[uuid.UUID] = []
    customers: dict[uuid.UUID, datetime] = {}
    for it, qid, entered in rows:
        ids.append(it.id)
        if it.customer_id:
            customers[it.id] = entered
        if it.connected_at is not None:
            answered += 1
            w = max(0.0, (it.connected_at - entered).total_seconds())
            waits_answered.append(w)
            if w <= thresholds.get(qid, 20):
                within_sl += 1
            if it.transfer_count > 0:
                transferred += 1
        elif it.status == "abandoned":
            w = ((it.ended_at or entered) - entered).total_seconds()
            if w < short_s:
                short_ab += 1
            else:
                abandoned += 1
        elif it.status == "voicemail":
            voicemail += 1
        elif it.status == "callback_requested":
            callback += 1
        else:
            in_progress += 1
    if ids:
        for part in db.scalars(select(AgentParticipation).where(AgentParticipation.interaction_id.in_(ids))):
            if part.connected_at and part.ended_at:
                talk += max(0.0, (part.ended_at - part.connected_at).total_seconds() - part.hold_seconds)
            hold += part.hold_seconds
            if part.wrap_started_at and part.wrap_ended_at:
                acw += max(0.0, (part.wrap_ended_at - part.wrap_started_at).total_seconds())
    sl_den = offered - short_ab
    # Repeat contacts.
    repeats = 0
    matched = 0
    for it, _, entered in rows:
        if not it.customer_id:
            continue
        matched += 1
        prior = db.scalar(select(func.count()).select_from(Interaction).where(
            Interaction.customer_id == it.customer_id, Interaction.id != it.id,
            Interaction.created_at < entered, Interaction.created_at >= entered - timedelta(days=repeat_days)))
        if prior:
            repeats += 1
    # Feedback.
    scores = [f.score for f in db.scalars(select(Feedback).where(Feedback.interaction_id.in_(ids)))] if ids else []
    # Callbacks due in window.
    cbs = db.scalars(select(Callback).where(Callback.org_id == org_id, Callback.created_at >= start,
                                            Callback.created_at < end)).all()
    cb_due = [c for c in cbs if c.status != "cancelled"]
    cb_done = [c for c in cb_due if c.status == "completed"]
    cb_open = [c for c in cb_due if c.status in ("pending", "ready", "offered", "in_progress")]
    # Cases.
    cases = db.scalars(select(Case).where(Case.org_id == org_id, Case.created_at >= start, Case.created_at < end)).all()
    resolved = [c for c in cases if c.resolved_at is not None]
    fcr = 0
    for c in resolved:
        links = db.scalar(select(func.count()).select_from(CaseInteraction).where(CaseInteraction.case_id == c.id))
        if links == 1 and c.reopen_count == 0:
            fcr += 1
    # Outbound.
    out_rows = db.execute(select(OutboundAttempt.status, func.count()).where(
        OutboundAttempt.org_id == org_id, OutboundAttempt.created_at >= start, OutboundAttempt.created_at < end)
        .group_by(OutboundAttempt.status)).all()
    refused_reasons: dict[str, int] = {}
    for a in db.scalars(select(OutboundAttempt).where(OutboundAttempt.org_id == org_id,
                                                      OutboundAttempt.status == "refused",
                                                      OutboundAttempt.created_at >= start,
                                                      OutboundAttempt.created_at < end)):
        for chk in (a.eligibility or {}).get("checks", []):
            if not chk["passed"]:
                refused_reasons[chk["check"]] = refused_reasons.get(chk["check"], 0) + 1
    # Ingestion lag.
    lags = [(e.received_at - e.occurred_at).total_seconds() * 1000 for e in db.scalars(
        select(ProviderEvent).where(ProviderEvent.org_id == org_id, ProviderEvent.occurred_at >= start,
                                    ProviderEvent.occurred_at < end, ProviderEvent.signature_verified.is_(True)))]
    ev_status = dict(db.execute(select(ProviderEvent.processing_status, func.count()).where(
        ProviderEvent.org_id == org_id, ProviderEvent.occurred_at >= start, ProviderEvent.occurred_at < end)
        .group_by(ProviderEvent.processing_status)).all())

    def rate(n: int, d: int) -> float | None:
        return round(n / d * 100, 1) if d else None

    return {
        "window": {"start": start, "end": end, "time_basis": "provider event time"},
        "filters": {"queue_id": queue_id, "include_synthetic_history": include_synthetic_history},
        "parameters": {"short_abandon_seconds": short_s, "repeat_contact_days": repeat_days,
                       "service_level_thresholds_seconds": {str(k): v for k, v in thresholds.items()}},
        "volumes": {"offered": offered, "answered": answered, "abandoned": abandoned, "short_abandoned": short_ab,
                    "voicemail": voicemail, "callback_requested": callback, "in_progress_or_other": in_progress},
        "rates": {"answer_rate_pct": rate(answered, offered), "abandon_rate_pct": rate(abandoned, sl_den),
                  "service_level_pct": rate(within_sl, sl_den), "transfer_rate_pct": rate(transferred, answered),
                  "repeat_contact_rate_pct": rate(repeats, matched)},
        "times_seconds": {
            "average_speed_of_answer": round(statistics.mean(waits_answered), 1) if waits_answered else None,
            "p90_queue_wait_answered": _p(waits_answered, 0.9),
            "talk_total": round(talk), "hold_total": round(hold), "acw_total": round(acw),
            "average_talk": round(talk / answered, 1) if answered else None,
            "average_hold": round(hold / answered, 1) if answered else None,
            "average_acw": round(acw / answered, 1) if answered else None,
            "average_handling_time": round((talk + hold + acw) / answered, 1) if answered else None},
        "transfers": {"interactions_transferred": transferred},
        "repeat_contacts": {"repeats": repeats, "identified_contacts": matched},
        "callbacks": {"requested": len(cbs), "completed": len(cb_done), "still_open": len(cb_open),
                      "cancelled": len([c for c in cbs if c.status == "cancelled"]),
                      "completion_rate_pct": rate(len(cb_done), len(cb_due) - len(cb_open))},
        "customer_feedback": {"responses": len(scores), "response_rate_pct": rate(len(scores), answered),
                              "mean_score": round(statistics.mean(scores), 2) if scores else None,
                              "csat_pct": rate(len([s for s in scores if s >= 4]), len(scores))},
        "cases": {"created": len(cases), "resolved": len(resolved), "first_contact_resolution": fcr,
                  "resolution_rate_pct": rate(len(resolved), len(cases))},
        "outbound": {"attempts_by_status": dict(out_rows), "refusal_reasons": refused_reasons},
        "data_quality": {"provider_events_by_status": ev_status,
                         "ingestion_lag_ms_p50": _p(lags, 0.5), "ingestion_lag_ms_p95": _p(lags, 0.95),
                         "interactions_needing_reconciliation": db.scalar(select(func.count()).select_from(Interaction)
                                                                          .where(Interaction.org_id == org_id,
                                                                                 Interaction.needs_reconciliation.is_(True)))},
        "definitions": DEFINITIONS,
        "caution": "Handling time alone is not a measure of service quality. Read it with resolution, repeat "
                   "contacts and customer feedback.",
    }


def by_agent(db: Session, org_id: uuid.UUID, start: datetime, end: datetime) -> list[dict[str, Any]]:
    out = []
    for a in db.scalars(select(Agent).where(Agent.org_id == org_id).order_by(Agent.display_name)):
        parts = db.scalars(select(AgentParticipation).where(
            AgentParticipation.agent_id == a.id, AgentParticipation.connected_at >= start,
            AgentParticipation.connected_at < end)).all()
        handled = [x for x in parts if x.connected_at]
        talk = sum(max(0.0, (x.ended_at - x.connected_at).total_seconds() - x.hold_seconds) for x in handled if x.ended_at)
        acw = sum((x.wrap_ended_at - x.wrap_started_at).total_seconds() for x in handled
                  if x.wrap_started_at and x.wrap_ended_at)
        hold = sum(x.hold_seconds for x in handled)
        n = len(handled)
        out.append({"agent_id": a.id, "agent": a.display_name, "handled": n,
                    "transferred_out": len([x for x in handled if x.outcome == "transferred_out"]),
                    "average_talk_seconds": round(talk / n, 1) if n else None,
                    "average_hold_seconds": round(hold / n, 1) if n else None,
                    "average_acw_seconds": round(acw / n, 1) if n else None})
    return out
