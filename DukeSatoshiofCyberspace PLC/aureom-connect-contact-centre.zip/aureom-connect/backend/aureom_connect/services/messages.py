"""Approved follow-up messages.

Bodies are rendered server-side from an *approved* template; agents (or AI
drafts) only supply placeholder values, which the agent must review. Sending
is done by the worker through the channel adapter.
"""
from __future__ import annotations

import re
import uuid
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..adapters.channels.registry import send_email
from ..db import utcnow
from ..errors import NotFound, ValidationFailed
from ..models import ContactPoint, Customer, Interaction, Job, MessageTemplate, OutboundMessage
from . import events

PLACEHOLDER = re.compile(r"\{([a-z_]+)\}")


def render(t: MessageTemplate, values: dict[str, str]) -> tuple[str, str]:
    missing = [ph for ph in t.placeholders if not str(values.get(ph, "")).strip()]
    if missing:
        raise ValidationFailed("All placeholders must be completed", details={"missing": missing})
    unknown = set(values) - set(t.placeholders)
    if unknown:
        raise ValidationFailed("Unknown placeholders", details={"unknown": sorted(unknown)})
    clean = {k: str(v).replace("{", "(").replace("}", ")")[:500] for k, v in values.items()}
    return (PLACEHOLDER.sub(lambda m: clean.get(m.group(1), m.group(0)), t.subject),
            PLACEHOLDER.sub(lambda m: clean.get(m.group(1), m.group(0)), t.body))


def create_and_queue(db: Session, p, *, template_id: uuid.UUID, customer_id: uuid.UUID,
                     interaction_id: uuid.UUID | None, case_id: uuid.UUID | None, values: dict[str, str],
                     ai_suggestion_id: uuid.UUID | None, reviewed: bool) -> OutboundMessage:
    if not reviewed:
        raise ValidationFailed("The agent must review the message before it is sent", code="REVIEW_REQUIRED")
    t = db.get(MessageTemplate, template_id)
    if t is None or t.org_id != p.org_id:
        raise NotFound("Template not found")
    if not t.approved:
        raise ValidationFailed("Template is not approved for sending", code="TEMPLATE_NOT_APPROVED")
    cust = db.get(Customer, customer_id)
    if cust is None or cust.org_id != p.org_id:
        raise NotFound("Customer not found")
    cp = db.scalar(select(ContactPoint).where(ContactPoint.customer_id == cust.id, ContactPoint.kind == t.channel,
                                              ContactPoint.is_primary.is_(True)))
    if cp is None:
        raise ValidationFailed(f"Customer has no primary {t.channel} address")
    subject, body = render(t, values)
    msg = OutboundMessage(org_id=p.org_id, customer_id=cust.id, interaction_id=interaction_id, case_id=case_id,
                          template_id=t.id, template_version=t.version, channel=t.channel, to_address=cp.value,
                          subject=subject, body=body, status="queued", drafted_by="ai" if ai_suggestion_id else "agent",
                          ai_suggestion_id=ai_suggestion_id, reviewed_by=p.user_id, reviewed_at=utcnow())
    db.add(msg)
    db.flush()
    db.add(Job(org_id=p.org_id, kind="send_message", payload={"message_id": str(msg.id)}, run_at=utcnow(),
               dedupe_key=f"send_message:{msg.id}"))
    if interaction_id:
        it = db.get(Interaction, interaction_id)
        if it:
            events.timeline(db, it, "message.queued", "agent", actor_user_id=p.user_id, template=t.code,
                            channel=t.channel)
    return msg


def deliver(db: Session, msg: OutboundMessage) -> None:
    if msg.status != "queued":
        return
    try:
        status, mid = send_email(msg.to_address, msg.subject, msg.body) if msg.channel == "email" else ("captured", None)
    except OSError as exc:
        msg.error = str(exc)[:500]
        raise
    msg.status = "sent" if status == "sent" else "captured_not_sent"
    msg.channel_message_id = mid
    msg.sent_at = utcnow()


def view(m: OutboundMessage) -> dict[str, Any]:
    return {"id": m.id, "channel": m.channel, "to": m.to_address, "subject": m.subject, "body": m.body,
            "status": m.status, "drafted_by": m.drafted_by, "reviewed_by": m.reviewed_by, "reviewed_at": m.reviewed_at,
            "sent_at": m.sent_at, "template_version": m.template_version,
            "status_note": "captured_not_sent = no mail server configured; message stored only"
            if m.status == "captured_not_sent" else None}
