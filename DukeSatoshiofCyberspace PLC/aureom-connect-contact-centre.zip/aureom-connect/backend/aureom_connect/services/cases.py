"""Cases and back-office tasks.

* A case is only ``resolved`` by an explicit action with an outcome; ending a
  call never resolves a case.
* Reopening a resolved/closed case, or overriding its outcome, requires a reason
  and is recorded as a case event and in the audit trail.
* SLA status distinguishes internal targets from contractual commitments.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import utcnow
from ..errors import InvalidTransition, NotFound, ValidationFailed, VersionConflict
from ..models import (Agent, Case, CaseEvent, CaseInteraction, CaseNote, Interaction, OutcomeCode, Queue, SlaPolicy,
                      Task)
from . import events, refs

OPEN_STATES = {"open", "pending_customer", "pending_internal"}
DONE_STATES = {"resolved", "closed"}


def sla_status(policy: SlaPolicy | None, due_at: datetime | None, done_at: datetime | None) -> dict[str, Any] | None:
    if policy is None or due_at is None:
        return None
    ref = done_at or utcnow()
    remaining = (due_at - ref).total_seconds()
    if done_at:
        state = "met" if remaining >= 0 else "missed"
    elif remaining < 0:
        state = "breached"
    elif remaining < policy.target_seconds * 0.2:
        state = "at_risk"
    else:
        state = "on_track"
    return {"policy": policy.name, "kind": policy.kind,
            "label": "Contractual commitment" if policy.kind == "contractual_commitment" else "Internal target",
            "contract_ref": policy.contract_ref, "due_at": due_at, "state": state,
            "seconds_remaining": int(remaining)}


def _event(db: Session, c: Case, type_: str, actor: uuid.UUID | None, **data: Any) -> None:
    db.add(CaseEvent(org_id=c.org_id, case_id=c.id, type=type_, actor_user_id=actor, at=utcnow(),
                     data=events._jsonable(data)))


def get_case(db: Session, org_id: uuid.UUID, case_id: uuid.UUID, lock: bool = False) -> Case:
    q = select(Case).where(Case.id == case_id, Case.org_id == org_id)
    c = db.scalar(q.with_for_update() if lock else q)
    if c is None:
        raise NotFound("Case not found")
    return c


def create_case(db: Session, p, *, customer_id: uuid.UUID | None, title: str, category: str, priority: str,
                interaction_id: uuid.UUID | None, owner_agent_id: uuid.UUID | None, owner_queue_code: str | None,
                sla_policy_id: uuid.UUID | None, note: str | None) -> Case:
    if priority not in ("low", "normal", "high"):
        raise ValidationFailed("priority must be low, normal or high")
    pol = db.get(SlaPolicy, sla_policy_id) if sla_policy_id else db.scalar(
        select(SlaPolicy).where(SlaPolicy.org_id == p.org_id, SlaPolicy.applies_to == "case_resolution",
                                SlaPolicy.kind == ("contractual_commitment" if category == "complaint"
                                                   else "internal_target")).limit(1))
    q = db.scalar(select(Queue).where(Queue.org_id == p.org_id, Queue.code == owner_queue_code)) \
        if owner_queue_code else None
    c = Case(org_id=p.org_id, case_ref=refs.next_ref(db, p.org_id, "case"), customer_id=customer_id, title=title,
             category=category, priority=priority, status="open", owner_agent_id=owner_agent_id or p.agent_id,
             owner_queue_id=q.id if q else None, sla_policy_id=pol.id if pol else None,
             due_at=utcnow() + timedelta(seconds=pol.target_seconds) if pol else None, created_by=p.user_id)
    db.add(c)
    db.flush()
    _event(db, c, "created", p.user_id, category=category, priority=priority)
    if interaction_id:
        link_interaction(db, p, c, interaction_id, "origin")
    if note:
        db.add(CaseNote(org_id=c.org_id, case_id=c.id, author_user_id=p.user_id, body=note,
                        interaction_id=interaction_id, created_at=utcnow()))
    return c


def link_interaction(db: Session, p, c: Case, interaction_id: uuid.UUID, link_type: str = "related") -> None:
    it = db.get(Interaction, interaction_id)
    if it is None or it.org_id != c.org_id:
        raise NotFound("Interaction not found")
    if it.customer_id and c.customer_id and it.customer_id != c.customer_id:
        raise ValidationFailed("Interaction belongs to a different customer")
    exists = db.scalar(select(CaseInteraction).where(CaseInteraction.case_id == c.id,
                                                     CaseInteraction.interaction_id == interaction_id))
    if exists:
        return
    db.add(CaseInteraction(org_id=c.org_id, case_id=c.id, interaction_id=interaction_id, link_type=link_type,
                           linked_by=p.user_id, linked_at=utcnow()))
    _event(db, c, "interaction_linked", p.user_id, interaction=it.reference, link_type=link_type)
    events.timeline(db, it, "case.linked", "agent", actor_user_id=p.user_id, case=c.case_ref)


def update_case(db: Session, p, c: Case, *, expected_version: int, status: str | None = None,
                outcome_code: str | None = None, resolution_note: str | None = None, reason: str | None = None,
                title: str | None = None, priority: str | None = None, owner_agent_id: uuid.UUID | None = None,
                note: str | None = None) -> Case:
    if c.version != expected_version:
        raise VersionConflict("Case was changed by someone else", details={"current_version": c.version})
    changes: dict[str, Any] = {}
    if status and status != c.status:
        if c.status in DONE_STATES and status in OPEN_STATES:
            if not reason or len(reason.strip()) < 5:
                raise ValidationFailed("A reason is required to reopen a completed case", code="REASON_REQUIRED")
            c.reopen_count += 1
            c.resolved_at = None
            c.closed_at = None
            _event(db, c, "reopened", p.user_id, reason=reason, previous_status=c.status)
        elif status == "resolved":
            if not outcome_code:
                raise ValidationFailed("An outcome is required to resolve a case", code="OUTCOME_REQUIRED")
            oc = db.scalar(select(OutcomeCode).where(OutcomeCode.org_id == c.org_id, OutcomeCode.code == outcome_code))
            if oc is None:
                raise ValidationFailed("Unknown outcome code")
            c.outcome_code = outcome_code
            c.resolution_note = resolution_note
            c.resolved_at = utcnow()
            c.resolved_by = p.user_id
            _event(db, c, "resolved", p.user_id, outcome=outcome_code)
        elif status == "closed":
            if c.status != "resolved":
                raise InvalidTransition("Only a resolved case can be closed")
            c.closed_at = utcnow()
            _event(db, c, "closed", p.user_id)
        elif status not in OPEN_STATES:
            raise ValidationFailed(f"Unknown status {status}")
        changes["status"] = [c.status, status]
        c.status = status
    elif outcome_code and c.status in DONE_STATES and outcome_code != c.outcome_code:
        p.require("case.override")
        if not reason or len(reason.strip()) < 5:
            raise ValidationFailed("A reason is required to override a completed case", code="REASON_REQUIRED")
        _event(db, c, "outcome_overridden", p.user_id, reason=reason, previous=c.outcome_code, new=outcome_code)
        changes["outcome_code"] = [c.outcome_code, outcome_code]
        c.outcome_code = outcome_code
    if title:
        changes["title"] = [c.title, title]
        c.title = title
    if priority:
        changes["priority"] = [c.priority, priority]
        c.priority = priority
    if owner_agent_id:
        if db.get(Agent, owner_agent_id) is None:
            raise NotFound("Agent not found")
        changes["owner_agent_id"] = [str(c.owner_agent_id), str(owner_agent_id)]
        c.owner_agent_id = owner_agent_id
    if note:
        db.add(CaseNote(org_id=c.org_id, case_id=c.id, author_user_id=p.user_id, body=note, created_at=utcnow()))
        changes["note_added"] = True
    if changes:
        c.version += 1
        _event(db, c, "updated", p.user_id, changes=changes)
    return c


def escalate(db: Session, p, c: Case, reason: str, queue_code: str | None, expected_version: int) -> Case:
    if c.version != expected_version:
        raise VersionConflict("Case was changed by someone else", details={"current_version": c.version})
    if c.status in DONE_STATES:
        raise InvalidTransition("Reopen the case before escalating")
    if not reason.strip():
        raise ValidationFailed("An escalation reason is required")
    c.escalation_level += 1
    if queue_code:
        q = db.scalar(select(Queue).where(Queue.org_id == c.org_id, Queue.code == queue_code))
        if q is None:
            raise NotFound("Queue not found")
        c.owner_queue_id = q.id
        c.owner_agent_id = None
    c.priority = "high"
    c.version += 1
    _event(db, c, "escalated", p.user_id, level=c.escalation_level, reason=reason, queue=queue_code)
    return c


def case_view(db: Session, c: Case, *, detail: bool = False) -> dict[str, Any]:
    pol = db.get(SlaPolicy, c.sla_policy_id) if c.sla_policy_id else None
    owner = db.get(Agent, c.owner_agent_id) if c.owner_agent_id else None
    q = db.get(Queue, c.owner_queue_id) if c.owner_queue_id else None
    out = {"id": c.id, "case_ref": c.case_ref, "customer_id": c.customer_id, "title": c.title, "category": c.category,
           "status": c.status, "priority": c.priority, "owner_agent": owner.display_name if owner else None,
           "owner_agent_id": c.owner_agent_id, "owner_queue": q.code if q else None, "due_at": c.due_at,
           "escalation_level": c.escalation_level, "outcome_code": c.outcome_code,
           "resolution_note": c.resolution_note, "resolved_at": c.resolved_at, "closed_at": c.closed_at,
           "reopen_count": c.reopen_count, "version": c.version, "created_at": c.created_at,
           "sla": sla_status(pol, c.due_at, c.resolved_at)}
    if detail:
        out["events"] = [{"type": e.type, "at": e.at, "actor_user_id": e.actor_user_id, "data": e.data}
                         for e in db.scalars(select(CaseEvent).where(CaseEvent.case_id == c.id).order_by(CaseEvent.at))]
        out["notes"] = [{"id": n.id, "body": n.body, "author_user_id": n.author_user_id, "created_at": n.created_at,
                         "visibility": n.visibility}
                        for n in db.scalars(select(CaseNote).where(CaseNote.case_id == c.id).order_by(CaseNote.created_at))]
        out["interactions"] = [{"interaction_id": ci.interaction_id, "reference": it.reference, "link_type": ci.link_type,
                                "channel": it.channel, "status": it.status, "created_at": it.created_at}
                               for ci, it in db.execute(select(CaseInteraction, Interaction).join(
                                   Interaction, Interaction.id == CaseInteraction.interaction_id)
                                   .where(CaseInteraction.case_id == c.id))]
        out["tasks"] = [task_view(db, t) for t in db.scalars(select(Task).where(Task.case_id == c.id))]
    return out


# --------------------------------------------------------------------------- tasks

def create_task(db: Session, p, *, title: str, description: str, kind: str, due_at: datetime | None,
                assignee_agent_id: uuid.UUID | None, assignee_queue_code: str | None, case_id: uuid.UUID | None,
                interaction_id: uuid.UUID | None, customer_id: uuid.UUID | None, priority: str) -> Task:
    if due_at and due_at < utcnow() - timedelta(minutes=1):
        raise ValidationFailed("Due date is in the past")
    q = db.scalar(select(Queue).where(Queue.org_id == p.org_id, Queue.code == assignee_queue_code)) \
        if assignee_queue_code else None
    if assignee_agent_id and db.get(Agent, assignee_agent_id) is None:
        raise NotFound("Assignee not found")
    if case_id:
        get_case(db, p.org_id, case_id)
    pol = db.scalar(select(SlaPolicy).where(SlaPolicy.org_id == p.org_id, SlaPolicy.applies_to == "task_completion"))
    t = Task(org_id=p.org_id, kind=kind, title=title, description=description, status="open", priority=priority,
             case_id=case_id, interaction_id=interaction_id, customer_id=customer_id,
             assignee_agent_id=assignee_agent_id, assignee_queue_id=q.id if q else None,
             due_at=due_at or (utcnow() + timedelta(seconds=pol.target_seconds) if pol else None),
             sla_policy_id=pol.id if pol else None, created_by=p.user_id)
    db.add(t)
    db.flush()
    if interaction_id:
        it = db.get(Interaction, interaction_id)
        if it:
            events.timeline(db, it, "task.created", "agent", actor_user_id=p.user_id, task=title,
                            due_at=t.due_at.isoformat() if t.due_at else None)
    if assignee_agent_id:
        events.to_agent(db, p.org_id, assignee_agent_id, "task.assigned", task_id=t.id, title=title)
    return t


def update_task(db: Session, p, t: Task, *, expected_version: int, status: str | None, note: str | None,
                assignee_agent_id: uuid.UUID | None, due_at: datetime | None, reason: str | None) -> Task:
    if t.version != expected_version:
        raise VersionConflict("Task was changed by someone else", details={"current_version": t.version})
    if status:
        if t.status in ("done", "cancelled") and status in ("open", "in_progress"):
            if not reason:
                raise ValidationFailed("A reason is required to reopen a completed task", code="REASON_REQUIRED")
        if status == "done":
            t.completed_at = utcnow()
            t.completed_by = p.user_id
            t.completion_note = note
        if status == "cancelled" and not reason:
            raise ValidationFailed("A reason is required to cancel a task", code="REASON_REQUIRED")
        t.status = status
    if assignee_agent_id:
        t.assignee_agent_id = assignee_agent_id
    if due_at:
        t.due_at = due_at
    t.version += 1
    return t


def task_view(db: Session, t: Task) -> dict[str, Any]:
    pol = db.get(SlaPolicy, t.sla_policy_id) if t.sla_policy_id else None
    a = db.get(Agent, t.assignee_agent_id) if t.assignee_agent_id else None
    q = db.get(Queue, t.assignee_queue_id) if t.assignee_queue_id else None
    return {"id": t.id, "kind": t.kind, "title": t.title, "description": t.description, "status": t.status,
            "priority": t.priority, "case_id": t.case_id, "interaction_id": t.interaction_id,
            "customer_id": t.customer_id, "assignee_agent_id": t.assignee_agent_id,
            "assignee": a.display_name if a else None, "assignee_queue": q.code if q else None, "due_at": t.due_at,
            "created_by": t.created_by, "created_at": t.created_at, "completed_at": t.completed_at,
            "completed_by": t.completed_by, "completion_note": t.completion_note, "version": t.version,
            "sla": sla_status(pol, t.due_at, t.completed_at)}
