"""Versioned knowledge base with review workflow and effective dates.

Agents only ever see the *approved* version that is effective now. Authors
create drafts; a different person approves (four-eyes). Search uses
PostgreSQL full-text search with weighted title/summary/body.
"""
from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import func, or_, select, text
from sqlalchemy.orm import Session

from ..db import utcnow
from ..errors import Forbidden, InvalidTransition, NotFound, ValidationFailed
from ..models import KnowledgeArticle, KnowledgeVersion, User


def _effective(now: datetime):
    return [KnowledgeVersion.status == "approved", KnowledgeVersion.effective_from <= now,
            or_(KnowledgeVersion.effective_to.is_(None), KnowledgeVersion.effective_to > now)]


def search(db: Session, org_id: uuid.UUID, q: str, *, limit: int = 10, visibility: str | None = None
           ) -> list[dict[str, Any]]:
    now = utcnow()
    q = (q or "").strip()[:200]
    base = select(KnowledgeVersion, KnowledgeArticle).join(
        KnowledgeArticle, KnowledgeArticle.id == KnowledgeVersion.article_id).where(
        KnowledgeVersion.org_id == org_id, *_effective(now))
    if visibility:
        base = base.where(KnowledgeArticle.visibility == visibility)
    if q:
        tsq = func.websearch_to_tsquery("english", q)
        rank = func.ts_rank_cd(KnowledgeVersion.search_vector, tsq)
        snippet = func.ts_headline("english", KnowledgeVersion.body, tsq,
                                   "MaxWords=30, MinWords=12, StartSel=«, StopSel=»")
        rows = db.execute(base.add_columns(rank.label("rank"), snippet.label("snippet"))
                          .where(KnowledgeVersion.search_vector.op("@@")(tsq))
                          .order_by(text("rank DESC")).limit(limit)).all()
        if not rows:  # fall back to OR-matching of individual terms
            terms = " | ".join(w for w in "".join(c if c.isalnum() else " " for c in q).split() if len(w) > 2)
            if terms:
                tsq2 = func.to_tsquery("english", terms)
                rows = db.execute(base.add_columns(func.ts_rank_cd(KnowledgeVersion.search_vector, tsq2).label("rank"),
                                                   func.ts_headline("english", KnowledgeVersion.body, tsq2,
                                                                    "MaxWords=30, MinWords=12, StartSel=«, StopSel=»")
                                                   .label("snippet"))
                                  .where(KnowledgeVersion.search_vector.op("@@")(tsq2))
                                  .order_by(text("rank DESC")).limit(limit)).all()
    else:
        rows = db.execute(base.add_columns(func.cast(0, KnowledgeVersion.version.type).label("rank"),
                                           KnowledgeVersion.summary.label("snippet"))
                          .order_by(KnowledgeVersion.title).limit(limit)).all()
    return [{"article_id": a.id, "version_id": v.id, "slug": a.slug, "title": v.title, "summary": v.summary,
             "snippet": snip, "version": v.version, "visibility": a.visibility, "owner_team": a.owner_team,
             "effective_from": v.effective_from, "review_due_at": v.review_due_at, "tags": v.tags,
             "score": round(float(rank or 0), 4),
             "review_overdue": bool(v.review_due_at and v.review_due_at < now)} for v, a, rank, snip in rows]


def current_version(db: Session, article: KnowledgeArticle) -> KnowledgeVersion | None:
    return db.scalar(select(KnowledgeVersion).where(KnowledgeVersion.article_id == article.id, *_effective(utcnow()))
                     .order_by(KnowledgeVersion.version.desc()).limit(1))


def article_view(db: Session, a: KnowledgeArticle, *, include_versions: bool) -> dict[str, Any]:
    cur = current_version(db, a)
    owner = db.get(User, a.owner_user_id) if a.owner_user_id else None
    out = {"id": a.id, "slug": a.slug, "visibility": a.visibility, "owner_team": a.owner_team,
           "owner": owner.display_name if owner else None,
           "current": _version_view(db, cur) if cur else None}
    if include_versions:
        out["versions"] = [_version_view(db, v) for v in db.scalars(select(KnowledgeVersion).where(
            KnowledgeVersion.article_id == a.id).order_by(KnowledgeVersion.version.desc()))]
    return out


def _version_view(db: Session, v: KnowledgeVersion) -> dict[str, Any]:
    reviewer = db.get(User, v.reviewed_by) if v.reviewed_by else None
    return {"id": v.id, "version": v.version, "title": v.title, "summary": v.summary, "body": v.body, "tags": v.tags,
            "status": v.status, "effective_from": v.effective_from, "effective_to": v.effective_to,
            "review_due_at": v.review_due_at, "reviewed_by": reviewer.display_name if reviewer else None,
            "approved_at": v.approved_at, "change_note": v.change_note}


def create_draft(db: Session, p, article_id: uuid.UUID | None, *, slug: str | None, title: str, summary: str,
                 body: str, tags: list[str], visibility: str, owner_team: str, change_note: str) -> KnowledgeVersion:
    if article_id:
        a = db.get(KnowledgeArticle, article_id)
        if a is None or a.org_id != p.org_id:
            raise NotFound("Article not found")
    else:
        if not slug:
            raise ValidationFailed("slug is required for a new article")
        a = KnowledgeArticle(org_id=p.org_id, slug=slug, owner_user_id=p.user_id, owner_team=owner_team,
                             visibility=visibility)
        db.add(a)
        db.flush()
    n = (db.scalar(select(func.max(KnowledgeVersion.version)).where(KnowledgeVersion.article_id == a.id)) or 0) + 1
    v = KnowledgeVersion(org_id=p.org_id, article_id=a.id, version=n, title=title, summary=summary, body=body,
                         tags=tags, status="draft", authored_by=p.user_id, change_note=change_note)
    db.add(v)
    db.flush()
    return v


def submit_for_review(db: Session, p, v: KnowledgeVersion) -> None:
    if v.status != "draft":
        raise InvalidTransition("Only drafts can be submitted for review")
    v.status = "in_review"


def approve(db: Session, p, v: KnowledgeVersion, *, effective_from: datetime | None,
            review_due_at: datetime | None) -> None:
    p.require("knowledge.approve")
    if v.status != "in_review":
        raise InvalidTransition("Only versions in review can be approved")
    if v.authored_by == p.user_id:
        raise Forbidden("An article must be approved by someone other than its author", code="FOUR_EYES_REQUIRED")
    eff = effective_from or utcnow()
    # Close the previous approved version at the new effective date.
    for prev in db.scalars(select(KnowledgeVersion).where(KnowledgeVersion.article_id == v.article_id,
                                                          KnowledgeVersion.status == "approved",
                                                          KnowledgeVersion.id != v.id,
                                                          KnowledgeVersion.effective_to.is_(None))):
        prev.effective_to = eff
    v.status = "approved"
    v.effective_from = eff
    v.review_due_at = review_due_at
    v.reviewed_by = p.user_id
    v.approved_at = utcnow()
    a = db.get(KnowledgeArticle, v.article_id)
    a.current_version_id = v.id
