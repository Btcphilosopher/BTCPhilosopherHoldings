"""WS /v1/events – application events (never media).

Protocol::

    client → {"type": "auth", "token": "<access token>"}        (first message, within 5 s)
    client → {"type": "subscribe", "since": <cursor>, "interactions": ["<id>", ...]}
    server → {"type": "ready", "cursor": n, "presence": "online"}
    server → {"type": "event", "id": n, "event": "...", "audience": "...", "payload": {...}, "at": "..."}
    client → {"type": "ping"}   every ≤ 15 s  (refreshes application presence)
    server → {"type": "pong"} / {"type": "heartbeat"}

Events are *signals*. Clients re-read authoritative state over REST. After a
reconnect the client resubscribes with its last cursor so nothing is missed;
the server also tells the agent whether reconciliation is required.
The token is sent in the first message, not the URL, to keep it out of logs.
"""
from __future__ import annotations

import asyncio
import json
import logging
import threading
import uuid
from typing import Any

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from sqlalchemy import or_, select
from starlette.concurrency import run_in_threadpool

from ..config import get_settings
from ..db import session_scope, utcnow
from ..errors import AppError
from ..models import Agent, AppEvent
from ..models.enums import Presence
from ..security.auth import principal_from_token
from ..services import events as event_service

log = logging.getLogger("aureom.ws")
router = APIRouter()


class Hub:
    """Wakes connected sockets when new events are committed (in-process or via LISTEN/NOTIFY)."""

    def __init__(self) -> None:
        self._waiters: set[asyncio.Event] = set()
        self._loop: asyncio.AbstractEventLoop | None = None
        self._listener: threading.Thread | None = None

    def register(self) -> asyncio.Event:
        self._loop = asyncio.get_running_loop()
        ev = asyncio.Event()
        self._waiters.add(ev)
        return ev

    def unregister(self, ev: asyncio.Event) -> None:
        self._waiters.discard(ev)

    def wake(self) -> None:
        loop = self._loop
        if loop is None:
            return
        for ev in list(self._waiters):
            loop.call_soon_threadsafe(ev.set)

    def start_listener(self) -> None:
        if self._listener is not None:
            return

        def run() -> None:
            import time

            import psycopg

            url = get_settings().database_url.replace("postgresql+psycopg://", "postgresql://")
            while True:
                try:
                    with psycopg.connect(url, autocommit=True) as conn:
                        conn.execute(f"LISTEN {event_service.CHANNEL}")
                        for _ in conn.notifies():
                            self.wake()
                except Exception as exc:  # pragma: no cover - reconnect loop
                    log.warning("LISTEN connection lost (%s); retrying", type(exc).__name__)
                    time.sleep(2)

        self._listener = threading.Thread(target=run, daemon=True, name="pg-listen")
        self._listener.start()


hub = Hub()


def _audiences(p) -> list[str]:
    aud = ["org", f"user:{p.user_id}"]
    if p.agent_id:
        aud.append(f"agent:{p.agent_id}")
    if p.has("ops.read"):
        aud.append("role:supervisor")
    return aud


def _fetch(org_id: uuid.UUID, cursor: int, audiences: list[str], interactions: set[str]) -> list[dict[str, Any]]:
    with session_scope() as db:
        conds = [AppEvent.audience.in_(audiences)]
        if interactions:
            conds.append(AppEvent.audience.in_([f"interaction:{i}" for i in interactions]))
        rows = db.scalars(select(AppEvent).where(AppEvent.org_id == org_id, AppEvent.id > cursor, or_(*conds))
                          .order_by(AppEvent.id).limit(200)).all()
        return [{"type": "event", "id": r.id, "event": r.type, "audience": r.audience, "payload": r.payload,
                 "at": r.created_at.isoformat()} for r in rows]


def _touch_presence(agent_id: uuid.UUID | None) -> dict[str, Any] | None:
    if agent_id is None:
        return None
    with session_scope() as db:
        a = db.get(Agent, agent_id)
        was = a.presence
        a.presence = Presence.ONLINE
        a.presence_last_seen = utcnow()
        if was != Presence.ONLINE:
            event_service.to_supervisors(db, a.org_id, "agent.presence", agent_id=a.id, presence="online")
        return {"reconcile_required": a.reconcile_required, "reconcile_reason": a.reconcile_reason, "state": a.state}


@router.websocket("/v1/events")
async def events_socket(ws: WebSocket) -> None:
    await ws.accept()
    try:
        first = await asyncio.wait_for(ws.receive_text(), timeout=5)
        msg = json.loads(first)
        if msg.get("type") != "auth":
            await ws.close(code=4401)
            return

        def auth():
            with session_scope() as db:
                return principal_from_token(db, msg.get("token", ""))

        p = await run_in_threadpool(auth)
    except (asyncio.TimeoutError, ValueError, AppError, WebSocketDisconnect):
        try:
            await ws.close(code=4401)
        except RuntimeError:
            pass
        return

    cursor = 0
    subscribed: set[str] = set()
    audiences = _audiences(p)
    wake = hub.register()
    state = await run_in_threadpool(_touch_presence, p.agent_id)
    await ws.send_json({"type": "ready", "cursor": cursor, "presence": "online", "agent": state})

    async def reader() -> None:
        nonlocal cursor, subscribed
        while True:
            m = json.loads(await ws.receive_text())
            if m.get("type") == "subscribe":
                cursor = int(m.get("since") or 0)
                subscribed = {str(i) for i in (m.get("interactions") or [])}
                wake.set()
            elif m.get("type") == "ping":
                st = await run_in_threadpool(_touch_presence, p.agent_id)
                await ws.send_json({"type": "pong", "agent": st, "server_time": utcnow().isoformat()})

    reader_task = asyncio.create_task(reader())
    try:
        while not reader_task.done():
            try:
                await asyncio.wait_for(wake.wait(), timeout=1.0)
            except asyncio.TimeoutError:
                pass
            wake.clear()
            batch = await run_in_threadpool(_fetch, p.org_id, cursor, audiences, subscribed)
            for item in batch:
                await ws.send_json(item)
                cursor = item["id"]
    except (WebSocketDisconnect, RuntimeError):
        pass
    finally:
        hub.unregister(wake)
        reader_task.cancel()
