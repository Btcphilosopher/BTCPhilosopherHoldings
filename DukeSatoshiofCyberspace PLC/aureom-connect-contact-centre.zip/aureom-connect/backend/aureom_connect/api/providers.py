"""/v1/providers/{provider}/events (verified webhooks) and provider status/simulator demo controls."""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..adapters.telephony.registry import get_provider
from ..config import get_settings
from ..db import get_db
from ..errors import Forbidden, ValidationFailed
from ..models import ProviderConfig, ProviderEvent
from ..security.auth import Principal, require
from ..services import audit, provider_events, reconciliation

router = APIRouter(tags=["providers"])


@router.post("/v1/providers/{provider}/events", include_in_schema=True)
async def provider_webhook(provider: str, request: Request, db: Session = Depends(get_db)) -> dict:
    body = await request.body()
    headers = dict(request.headers)
    url = str(request.url)
    from starlette.concurrency import run_in_threadpool

    return await run_in_threadpool(provider_events.ingest, db, provider, headers, body, url)


@router.get("/v1/providers/status")
def provider_status(p: Principal = Depends(require("ops.read")), db: Session = Depends(get_db)) -> dict:
    prov = get_provider()
    cfg = db.scalar(select(ProviderConfig).where(ProviderConfig.org_id == p.org_id, ProviderConfig.provider == prov.name))
    recent = db.scalars(select(ProviderEvent).where(ProviderEvent.org_id == p.org_id)
                        .order_by(ProviderEvent.received_at.desc()).limit(40)).all()
    return {"provider": prov.name, "capabilities": prov.capabilities().model_dump(),
            "connection_status": cfg.connection_status if cfg else "unknown",
            "status_changed_at": cfg.status_changed_at if cfg else None,
            "last_heartbeat_ok_at": cfg.last_heartbeat_ok_at if cfg else None,
            "recent_events": [{"provider_event_id": e.provider_event_id, "type": e.event_type, "sequence": e.sequence,
                               "occurred_at": e.occurred_at, "received_at": e.received_at,
                               "ingestion_lag_ms": round((e.received_at - e.occurred_at).total_seconds() * 1000),
                               "status": e.processing_status, "duplicates": e.duplicate_count,
                               "note": e.processing_note, "synthetic": bool((e.payload or {}).get("data", {})
                                                                            .get("synthetic"))}
                              for e in recent]}


@router.post("/v1/providers/health-check")
def health_check(p: Principal = Depends(require("ops.read")), db: Session = Depends(get_db)) -> dict:
    status = reconciliation.check_health(db, p.org_id)
    db.commit()
    return {"connection_status": status}


# ---------------------------------------------------------------------------- simulator (demo only)

def _sim_guard(p: Principal) -> None:
    s = get_settings()
    if not s.demo_mode or s.telephony_provider != "simulated":
        raise Forbidden("Simulator controls are only available in demo mode with the simulated provider")
    if not (p.has("simulator.control") or p.has("ops.read")):
        raise Forbidden("Missing permission simulator.control")


def _sim_client():
    prov = get_provider()
    return prov.client  # type: ignore[attr-defined]


class SimInbound(BaseModel):
    from_number: str
    to_number: str = "+441614960100"
    ivr_digits: str | None = None
    consent_digit: str | None = None
    script: list[dict[str, Any]] = []


@router.post("/v1/simulator/inbound-call")
def sim_inbound(body: SimInbound, p: Principal = Depends(require("ops.read")), db: Session = Depends(get_db)) -> dict:
    _sim_guard(p)
    r = _sim_client().post("/v1/demo/inbound", json=body.model_dump())
    audit.by_principal(db, p, "simulator.inbound_call", "simulator", None, to=body.to_number)
    db.commit()
    if r.status_code >= 400:
        raise ValidationFailed(f"Simulator refused: {r.text}")
    return {**r.json(), "simulated": True, "note": "Simulated signalling only. No audio."}


@router.post("/v1/simulator/calls/{provider_call_id}/customer-hangup")
def sim_hangup(provider_call_id: str, p: Principal = Depends(require("ops.read")), db: Session = Depends(get_db)) -> dict:
    _sim_guard(p)
    r = _sim_client().post(f"/v1/demo/calls/{provider_call_id}/customer-hangup")
    audit.by_principal(db, p, "simulator.customer_hangup", "call", provider_call_id)
    db.commit()
    return r.json()


@router.get("/v1/simulator/faults")
def sim_get_faults(p: Principal = Depends(require("ops.read"))) -> dict:
    _sim_guard(p)
    return _sim_client().get("/v1/demo/faults").json()


@router.put("/v1/simulator/faults")
def sim_set_faults(body: dict[str, Any], p: Principal = Depends(require("ops.read")),
                   db: Session = Depends(get_db)) -> dict:
    _sim_guard(p)
    r = _sim_client().put("/v1/demo/faults", json=body)
    audit.by_principal(db, p, "simulator.faults_changed", "simulator", None, faults=body)
    db.commit()
    if r.status_code >= 400:
        raise ValidationFailed(r.text)
    return r.json()


@router.post("/v1/simulator/devices/{agent_id}/drop")
def sim_drop_device(agent_id: str, p: Principal = Depends(require("ops.read")), db: Session = Depends(get_db)) -> dict:
    _sim_guard(p)
    r = _sim_client().post(f"/v1/demo/devices/agent:{agent_id}/drop")
    audit.by_principal(db, p, "simulator.device_dropped", "agent", agent_id)
    db.commit()
    return r.json()
