"""/v1/ai/* (proposals only) and /v1/messages (approved follow-up messages)."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import get_db
from ..errors import NotFound
from ..models import Interaction, MessageTemplate, OutboundMessage
from ..security.auth import Principal, require
from ..services import ai, audit, messages
from .deps import idempotent

router = APIRouter(tags=["ai assistance & messages"])


def _it(db: Session, p: Principal, iid: uuid.UUID) -> Interaction:
    it = db.get(Interaction, iid)
    if it is None or it.org_id != p.org_id:
        raise NotFound("Interaction not found")
    return it


def _view(s) -> dict:
    return {"id": s.id, "kind": s.kind, "provider": s.provider, "model": s.model, "output": s.output,
            "sources": s.sources, "uncertainty": s.uncertainty, "safety_flags": s.safety_flags, "status": s.status,
            "requires_review": True,
            "notice": "AI proposal. Review, correct and decide yourself. It cannot take any action."}


@router.get("/v1/ai/status")
def status(p: Principal = Depends(require("ai.use"))) -> dict:
    a = ai.get_assistant()
    s = get_settings()
    return {"enabled": a is not None, "provider": a.provider if a else None, "model": a.model if a else None,
            "configured_provider": s.ai_provider,
            "note": "Heuristic baseline is rule-based, not a language model." if a and a.provider == "heuristic" else ""}


class AiIn(BaseModel):
    interaction_id: uuid.UUID
    notes: str = ""
    template_id: uuid.UUID | None = None


@router.post("/v1/ai/suggest-articles")
def suggest_articles(body: AiIn, p: Principal = Depends(require("ai.use")), db: Session = Depends(get_db)) -> dict:
    s = ai.suggest_articles(db, p, _it(db, p, body.interaction_id))
    audit.by_principal(db, p, "ai.suggest_articles", "interaction", body.interaction_id, provider=s.provider)
    db.commit()
    return _view(s)


@router.post("/v1/ai/draft-summary")
def draft_summary(body: AiIn, p: Principal = Depends(require("ai.use")), db: Session = Depends(get_db)) -> dict:
    s = ai.draft_summary(db, p, _it(db, p, body.interaction_id), body.notes)
    audit.by_principal(db, p, "ai.draft_summary", "interaction", body.interaction_id, provider=s.provider,
                       flags=s.safety_flags)
    db.commit()
    return _view(s)


@router.post("/v1/ai/classify")
def classify(body: AiIn, p: Principal = Depends(require("ai.use")), db: Session = Depends(get_db)) -> dict:
    s = ai.classify(db, p, _it(db, p, body.interaction_id))
    audit.by_principal(db, p, "ai.classify", "interaction", body.interaction_id, provider=s.provider)
    db.commit()
    return _view(s)


@router.post("/v1/ai/draft-message")
def draft_message(body: AiIn, p: Principal = Depends(require("ai.use")), db: Session = Depends(get_db)) -> dict:
    if body.template_id is None:
        from ..errors import ValidationFailed

        raise ValidationFailed("template_id is required")
    s = ai.draft_message(db, p, _it(db, p, body.interaction_id), body.template_id)
    audit.by_principal(db, p, "ai.draft_message", "interaction", body.interaction_id, provider=s.provider)
    db.commit()
    return _view(s)


class ReviewIn(BaseModel):
    decision: str = Field(pattern="^(accepted|edited|rejected)$")


@router.post("/v1/ai/suggestions/{suggestion_id}/review")
def review(suggestion_id: uuid.UUID, body: ReviewIn, p: Principal = Depends(require("ai.use")),
           db: Session = Depends(get_db)) -> dict:
    s = ai.review(db, p, suggestion_id, body.decision)
    audit.by_principal(db, p, "ai.suggestion_reviewed", "ai_suggestion", s.id, decision=body.decision)
    db.commit()
    return _view(s)


# --------------------------------------------------------------------------- messages

@router.get("/v1/message-templates")
def templates(p: Principal = Depends(require("workspace.read")), db: Session = Depends(get_db)) -> list[dict]:
    return [{"id": t.id, "code": t.code, "name": t.name, "channel": t.channel, "subject": t.subject, "body": t.body,
             "placeholders": t.placeholders, "approved": t.approved, "version": t.version}
            for t in db.scalars(select(MessageTemplate).where(MessageTemplate.org_id == p.org_id)
                                .order_by(MessageTemplate.name))]


class MessageIn(BaseModel):
    template_id: uuid.UUID
    customer_id: uuid.UUID
    interaction_id: uuid.UUID | None = None
    case_id: uuid.UUID | None = None
    placeholder_values: dict[str, str]
    ai_suggestion_id: uuid.UUID | None = None
    reviewed: bool = Field(description="Agent confirms they reviewed the rendered message")


@router.post("/v1/messages", status_code=202)
def send(body: MessageIn, request: Request, p: Principal = Depends(require("message.send")),
         db: Session = Depends(get_db)):
    def run():
        m = messages.create_and_queue(db, p, template_id=body.template_id, customer_id=body.customer_id,
                                      interaction_id=body.interaction_id, case_id=body.case_id,
                                      values=body.placeholder_values, ai_suggestion_id=body.ai_suggestion_id,
                                      reviewed=body.reviewed)
        audit.by_principal(db, p, "message.queued", "outbound_message", m.id, template=str(body.template_id),
                           ai_assisted=bool(body.ai_suggestion_id))
        return 202, messages.view(m)

    return idempotent(request, db, p, body.model_dump(mode="json"), run)


@router.get("/v1/messages")
def list_messages(customer_id: uuid.UUID | None = None, p: Principal = Depends(require("workspace.read")),
                  db: Session = Depends(get_db)) -> list[dict]:
    q = select(OutboundMessage).where(OutboundMessage.org_id == p.org_id)
    if customer_id:
        q = q.where(OutboundMessage.customer_id == customer_id)
    return [messages.view(m) for m in db.scalars(q.order_by(OutboundMessage.created_at.desc()).limit(100))]
