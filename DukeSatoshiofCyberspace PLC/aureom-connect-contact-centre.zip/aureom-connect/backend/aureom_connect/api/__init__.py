"""API routers."""
from __future__ import annotations

import importlib

MODULES = ["auth", "agent", "interactions", "providers", "ops", "customers", "cases", "callbacks", "outbound",
           "knowledge", "ai", "recordings", "quality", "workforce", "reports", "admin", "channels"]


def routers():
    from ..realtime.ws import router as ws_router

    out = []
    for name in MODULES:
        try:
            mod = importlib.import_module(f"{__name__}.{name}")
        except ModuleNotFoundError as exc:
            if exc.name == f"{__name__}.{name}":
                continue  # module not present in this build
            raise
        out.append(mod.router)
    out.append(ws_router)
    return out
