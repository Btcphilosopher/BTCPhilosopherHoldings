"""/v1/customers – search, record view (restricted data only in a verified context), objections, duplicates."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db, utcnow
from ..errors import NotFound, ValidationFailed
from ..models import Case, Consent, ContactPoint, Customer, Interaction, Task
from ..security.auth import Principal, require
from ..services import audit, customers
from ..services.cases import case_view, task_view

router = APIRouter(prefix="/v1/customers", tags=["customers"])


def _cust(db: Session, p: Principal, cid: uuid.UUID) -> Customer:
    c = db.get(Customer, cid)
    if c is None or c.org_id != p.org_id:
        raise NotFound("Customer not found")
    return c


@router.get("")
def search(q: str = Query("", max_length=100), p: Principal = Depends(require("customer.read")),
           db: Session = Depends(get_db)) -> list[dict]:
    if len(q.strip()) < 2:
        rows = db.scalars(select(Customer).where(Customer.org_id == p.org_id).order_by(Customer.display_name)
                          .limit(25)).all()
    else:
        rows = customers.search(db, p.org_id, q)
    audit.by_principal(db, p, "customer.search", "customer", None, query_length=len(q))
    db.commit()
    return [{"id": c.id, "customer_ref": c.customer_ref, "display_name": c.display_name, "kind": c.kind,
             "status": c.status, "support_flags": c.support_flags} for c in rows]


@router.get("/{customer_id}")
def get_customer(customer_id: uuid.UUID, interaction_id: uuid.UUID | None = None,
                 p: Principal = Depends(require("customer.read")), db: Session = Depends(get_db)) -> dict:
    c = _cust(db, p, customer_id)
    verified = customers.is_verified_context(db, p.agent_id, c.id, interaction_id)
    view = customers.customer_view(db, c, verified=verified)
    view["cases"] = [case_view(db, cs) for cs in db.scalars(select(Case).where(Case.customer_id == c.id)
                                                            .order_by(Case.created_at.desc()))]
    view["open_tasks"] = [task_view(db, t) for t in db.scalars(select(Task).where(
        Task.customer_id == c.id, Task.status.in_(["open", "in_progress"])))]
    view["interactions"] = [{"id": it.id, "reference": it.reference, "channel": it.channel, "direction": it.direction,
                             "status": it.status, "created_at": it.created_at, "disposition_code": it.disposition_code,
                             "transfer_count": it.transfer_count}
                            for it in db.scalars(select(Interaction).where(Interaction.customer_id == c.id)
                                                 .order_by(Interaction.created_at.desc()).limit(30))]
    if verified:
        audit.by_principal(db, p, "customer.restricted_viewed", "customer", c.id, interaction=str(interaction_id))
        db.commit()
    return view


class ContactUpdate(BaseModel):
    interaction_id: uuid.UUID
    kind: str = Field(pattern="^(phone|email)$")
    value: str
    label: str = "updated"
    expected_version: int


@router.post("/{customer_id}/contact-points")
def add_contact_point(customer_id: uuid.UUID, body: ContactUpdate, p: Principal = Depends(require("customer.update")),
                      db: Session = Depends(get_db)) -> dict:
    """A sensitive action: requires a verified customer on an interaction the agent owns."""
    c = _cust(db, p, customer_id)
    customers.require_verified(db, p.agent_id, c.id, body.interaction_id, "change contact details")
    if c.version != body.expected_version:
        from ..errors import VersionConflict

        raise VersionConflict("Customer record changed", details={"current_version": c.version})
    norm = customers.normalise_phone(body.value) if body.kind == "phone" else body.value.strip().lower()
    if not norm:
        raise ValidationFailed("Invalid contact value")
    db.add(ContactPoint(org_id=c.org_id, customer_id=c.id, kind=body.kind, value=body.value, normalized=norm,
                        label=body.label, source="agent", verified_at=utcnow()))
    c.version += 1
    audit.by_principal(db, p, "customer.contact_added", "customer", c.id, kind=body.kind)
    db.commit()
    return {"ok": True, "version": c.version}


class ObjectionIn(BaseModel):
    scope: str = Field(pattern="^(all_marketing|telephone_marketing|all_telephone)$")
    note: str = ""
    interaction_id: uuid.UUID | None = None


@router.post("/{customer_id}/objections")
def add_objection(customer_id: uuid.UUID, body: ObjectionIn, p: Principal = Depends(require("customer.read")),
                  db: Session = Depends(get_db)) -> dict:
    """Recording an objection never requires verification: it only ever reduces contact."""
    c = _cust(db, p, customer_id)
    o = customers.record_objection(db, p.org_id, c.id, body.scope, "agent", body.note, p.user_id)
    audit.by_principal(db, p, "customer.objection_recorded", "customer", c.id, scope=body.scope)
    db.commit()
    return {"id": o.id, "scope": o.scope}


class ConsentWithdraw(BaseModel):
    reason: str = ""


@router.post("/{customer_id}/consents/{consent_id}/withdraw")
def withdraw_consent(customer_id: uuid.UUID, consent_id: uuid.UUID, body: ConsentWithdraw,
                     p: Principal = Depends(require("customer.read")), db: Session = Depends(get_db)) -> dict:
    c = _cust(db, p, customer_id)
    con = db.get(Consent, consent_id)
    if con is None or con.customer_id != c.id:
        raise NotFound("Consent not found")
    con.status, con.withdrawn_at = "withdrawn", utcnow()
    audit.by_principal(db, p, "customer.consent_withdrawn", "customer", c.id, purpose=con.purpose, reason=body.reason)
    db.commit()
    return {"ok": True}


class DuplicateIn(BaseModel):
    other_customer_id: uuid.UUID
    reason: str = Field(min_length=5)


@router.post("/{customer_id}/possible-duplicates")
def flag_duplicate(customer_id: uuid.UUID, body: DuplicateIn, p: Principal = Depends(require("customer.read")),
                   db: Session = Depends(get_db)) -> dict:
    _cust(db, p, customer_id)
    _cust(db, p, body.other_customer_id)
    dup = customers.flag_possible_duplicate(db, p.org_id, customer_id, body.other_customer_id, body.reason, p.user_id)
    audit.by_principal(db, p, "customer.possible_duplicate", "customer", customer_id,
                       other=str(body.other_customer_id))
    db.commit()
    return {"id": dup.id, "status": dup.status, "note": "Flagged for back-office review; records were not merged."}
