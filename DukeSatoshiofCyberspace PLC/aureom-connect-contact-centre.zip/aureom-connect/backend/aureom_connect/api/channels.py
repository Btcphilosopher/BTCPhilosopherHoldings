"""/v1/channels – e-mail and web-chat channel adapters (customer-facing endpoints).

Customer content is untrusted: it is stored as data, never interpreted.
Web-chat sessions use a random bearer token (hashed at rest) scoped to one
interaction. In demo mode a supervisor can inject a simulated inbound e-mail.
"""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Header, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import get_db, utcnow
from ..errors import Forbidden, NotFound, Unauthorized
from ..models import ChatMessage, Interaction, Organisation, Queue
from ..security.auth import Principal, require
from ..security.crypto import constant_time_equals, random_token, token_hash
from ..security.ratelimit import limiter
from ..services import audit, events, interactions, routing

router = APIRouter(prefix="/v1/channels", tags=["channels"])


def _queue(db: Session, org_id: uuid.UUID, code: str) -> Queue:
    q = db.scalar(select(Queue).where(Queue.org_id == org_id, Queue.code == code))
    if q is None:
        raise NotFound("Queue not found")
    return q


class EmailIn(BaseModel):
    from_address: str = Field(max_length=320)
    subject: str = Field(max_length=300)
    body: str = Field(max_length=20000)
    queue: str = "CARE"


@router.post("/email/inbound", status_code=202)
def inbound_email(body: EmailIn, p: Principal = Depends(require("ops.read")), db: Session = Depends(get_db)) -> dict:
    """Demo stand-in for a mail provider's inbound webhook (a production adapter would verify a signature)."""
    if not get_settings().demo_mode:
        raise Forbidden("Simulated inbound e-mail is only available in demo mode")
    q = _queue(db, p.org_id, body.queue)
    from ..services.customers import search

    match = [c for c in search(db, p.org_id, body.from_address)][:3]
    it = interactions.new_interaction(db, p.org_id, channel="email", direction="inbound", status="ivr",
                                      source="email", is_simulated=True, subject=body.subject,
                                      match_hint={"from_address": body.from_address,
                                                  "candidate_ids": [str(c.id) for c in match],
                                                  "note": "Sender address is a matching hint, not proof of identity."},
                                      customer_match_status="candidates" if match else "unmatched")
    db.add(ChatMessage(org_id=p.org_id, interaction_id=it.id, sender="customer", body=body.body, subject=body.subject,
                       sent_at=utcnow(), attachments=[]))
    interactions.enqueue(db, it, q, reason="email")
    audit.by_principal(db, p, "channel.email_injected", "interaction", it.id)
    db.commit()
    routing.route_org(db, p.org_id)
    db.commit()
    return {"interaction_id": it.id, "reference": it.reference, "simulated": True}


class ChatStart(BaseModel):
    organisation: str = "pennine"
    name: str = Field(min_length=1, max_length=100)
    topic: str = Field("TECH", pattern="^(TECH|CARE)$")
    first_message: str = Field(min_length=1, max_length=2000)


@router.post("/webchat/sessions", status_code=201)
def start_chat(body: ChatStart, request: Request, db: Session = Depends(get_db)) -> dict:
    ip = request.client.host if request.client else "unknown"
    limiter.check(f"chat:{ip}", 10)
    org = db.scalar(select(Organisation).where(Organisation.slug == body.organisation))
    if org is None:
        raise NotFound("Organisation not found")
    token = random_token(24)
    it = interactions.new_interaction(db, org.id, channel="chat", direction="inbound", status="ivr", source="webchat",
                                      subject=f"Web chat: {body.name}",
                                      match_hint={"chat_token_hash": token_hash(token), "display_name": body.name,
                                                  "note": "Self-declared name; not verified."})
    db.add(ChatMessage(org_id=org.id, interaction_id=it.id, sender="customer", body=body.first_message,
                       sent_at=utcnow(), attachments=[]))
    interactions.enqueue(db, it, _queue(db, org.id, body.topic), reason="webchat")
    db.commit()
    routing.route_org(db, org.id)
    db.commit()
    return {"session_id": it.id, "token": token, "reference": it.reference,
            "note": "Keep this token private; it gives access to this chat only."}


def _chat(db: Session, session_id: uuid.UUID, authorization: str | None) -> Interaction:
    it = db.get(Interaction, session_id)
    if it is None or it.channel != "chat":
        raise NotFound("Chat not found")
    tok = (authorization or "").removeprefix("Bearer ").strip()
    if not tok or not constant_time_equals(token_hash(tok), (it.match_hint or {}).get("chat_token_hash", "")):
        raise Unauthorized("Invalid chat token")
    return it


class ChatMsg(BaseModel):
    body: str = Field(min_length=1, max_length=2000)


@router.post("/webchat/sessions/{session_id}/messages", status_code=201)
def customer_message(session_id: uuid.UUID, body: ChatMsg, request: Request,
                     authorization: str | None = Header(default=None), db: Session = Depends(get_db)) -> dict:
    it = _chat(db, session_id, authorization)
    limiter.check(f"chatmsg:{session_id}", 30)
    if it.status in ("completed", "abandoned"):
        raise Forbidden("This chat has ended")
    m = ChatMessage(org_id=it.org_id, interaction_id=it.id, sender="customer", body=body.body, sent_at=utcnow(),
                    attachments=[])
    db.add(m)
    db.flush()
    events.publish(db, it.org_id, f"interaction:{it.id}", "message.created", interaction_id=it.id, message_id=m.id)
    if it.owner_agent_id:
        events.to_agent(db, it.org_id, it.owner_agent_id, "message.created", interaction_id=it.id)
    db.commit()
    return {"id": m.id}


@router.get("/webchat/sessions/{session_id}/messages")
def customer_poll(session_id: uuid.UUID, authorization: str | None = Header(default=None),
                  db: Session = Depends(get_db)) -> dict:
    it = _chat(db, session_id, authorization)
    msgs = db.scalars(select(ChatMessage).where(ChatMessage.interaction_id == it.id)
                      .order_by(ChatMessage.sent_at)).all()
    return {"status": it.status, "agent_joined": it.owner_agent_id is not None,
            "messages": [{"id": m.id, "sender": m.sender, "body": m.body, "sent_at": m.sent_at} for m in msgs]}


@router.post("/webchat/sessions/{session_id}/end")
def customer_end(session_id: uuid.UUID, authorization: str | None = Header(default=None),
                 db: Session = Depends(get_db)) -> dict:
    it = _chat(db, session_id, authorization)
    if it.status in ("queued", "offered"):
        interactions.begin_wrap_up(db, it, utcnow(), "customer_left_chat")
    else:
        events.timeline(db, it, "chat.customer_left", "customer")
    db.commit()
    return {"status": it.status}
