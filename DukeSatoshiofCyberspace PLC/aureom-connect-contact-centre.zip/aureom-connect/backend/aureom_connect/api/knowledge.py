"""/v1/knowledge – search approved, effective articles; authoring and four-eyes approval."""
from __future__ import annotations

import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..errors import NotFound
from ..models import KnowledgeArticle, KnowledgeVersion
from ..security.auth import Principal, require
from ..services import audit, knowledge

router = APIRouter(prefix="/v1/knowledge", tags=["knowledge"])


@router.get("/search")
def search(q: str = Query("", max_length=200), visibility: str | None = None,
           p: Principal = Depends(require("knowledge.read")), db: Session = Depends(get_db)) -> dict:
    return {"query": q, "results": knowledge.search(db, p.org_id, q, limit=15, visibility=visibility),
            "note": "Only approved versions effective now are returned."}


@router.get("/articles")
def list_articles(p: Principal = Depends(require("knowledge.read")), db: Session = Depends(get_db)) -> list[dict]:
    editor = p.has("knowledge.write")
    return [knowledge.article_view(db, a, include_versions=editor)
            for a in db.scalars(select(KnowledgeArticle).where(KnowledgeArticle.org_id == p.org_id)
                                .order_by(KnowledgeArticle.slug))]


@router.get("/articles/{article_id}")
def get_article(article_id: uuid.UUID, p: Principal = Depends(require("knowledge.read")),
                db: Session = Depends(get_db)) -> dict:
    a = db.get(KnowledgeArticle, article_id)
    if a is None or a.org_id != p.org_id:
        raise NotFound("Article not found")
    return knowledge.article_view(db, a, include_versions=p.has("knowledge.write"))


class DraftIn(BaseModel):
    article_id: uuid.UUID | None = None
    slug: str | None = None
    title: str = Field(min_length=3)
    summary: str = ""
    body: str = Field(min_length=10)
    tags: list[str] = []
    visibility: str = Field("internal", pattern="^(internal|customer_visible)$")
    owner_team: str = ""
    change_note: str = ""


@router.post("/versions", status_code=201)
def create_draft(body: DraftIn, p: Principal = Depends(require("knowledge.write")), db: Session = Depends(get_db)) -> dict:
    v = knowledge.create_draft(db, p, body.article_id, slug=body.slug, title=body.title, summary=body.summary,
                               body=body.body, tags=body.tags, visibility=body.visibility, owner_team=body.owner_team,
                               change_note=body.change_note)
    audit.by_principal(db, p, "knowledge.draft_created", "knowledge_version", v.id)
    db.commit()
    return {"id": v.id, "article_id": v.article_id, "version": v.version, "status": v.status}


def _version(db: Session, p: Principal, vid: uuid.UUID) -> KnowledgeVersion:
    v = db.get(KnowledgeVersion, vid)
    if v is None or v.org_id != p.org_id:
        raise NotFound("Version not found")
    return v


@router.post("/versions/{version_id}/submit")
def submit(version_id: uuid.UUID, p: Principal = Depends(require("knowledge.write")), db: Session = Depends(get_db)) -> dict:
    v = _version(db, p, version_id)
    knowledge.submit_for_review(db, p, v)
    audit.by_principal(db, p, "knowledge.submitted", "knowledge_version", v.id)
    db.commit()
    return {"id": v.id, "status": v.status}


class ApproveIn(BaseModel):
    effective_from: datetime | None = None
    review_due_at: datetime | None = None


@router.post("/versions/{version_id}/approve")
def approve(version_id: uuid.UUID, body: ApproveIn, p: Principal = Depends(require("knowledge.approve")),
            db: Session = Depends(get_db)) -> dict:
    v = _version(db, p, version_id)
    knowledge.approve(db, p, v, effective_from=body.effective_from, review_due_at=body.review_due_at)
    audit.by_principal(db, p, "knowledge.approved", "knowledge_version", v.id, version=v.version)
    db.commit()
    return {"id": v.id, "status": v.status, "effective_from": v.effective_from}
