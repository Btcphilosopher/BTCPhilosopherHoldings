"""/v1/cases and /v1/tasks."""
from __future__ import annotations

import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ..db import get_db
from ..errors import NotFound
from ..models import Case, OutcomeCode, Task
from ..security.auth import Principal, require
from ..services import audit, cases
from .deps import idempotent

router = APIRouter(tags=["cases & tasks"])


class CaseIn(BaseModel):
    customer_id: uuid.UUID | None = None
    title: str = Field(min_length=3, max_length=300)
    category: str = Field(min_length=2, max_length=64)
    priority: str = "normal"
    interaction_id: uuid.UUID | None = None
    owner_agent_id: uuid.UUID | None = None
    owner_queue: str | None = None
    sla_policy_id: uuid.UUID | None = None
    note: str | None = None


@router.post("/v1/cases", status_code=201)
def create_case(body: CaseIn, request: Request, p: Principal = Depends(require("case.write")),
                db: Session = Depends(get_db)):
    def run():
        c = cases.create_case(db, p, customer_id=body.customer_id, title=body.title, category=body.category,
                              priority=body.priority, interaction_id=body.interaction_id,
                              owner_agent_id=body.owner_agent_id, owner_queue_code=body.owner_queue,
                              sla_policy_id=body.sla_policy_id, note=body.note)
        audit.by_principal(db, p, "case.created", "case", c.id, case_ref=c.case_ref)
        return 201, cases.case_view(db, c, detail=True)

    return idempotent(request, db, p, body.model_dump(mode="json"), run)


@router.get("/v1/cases")
def list_cases(status: str | None = None, mine: bool = False, p: Principal = Depends(require("case.read")),
               db: Session = Depends(get_db)) -> list[dict]:
    q = select(Case).where(Case.org_id == p.org_id)
    if status:
        q = q.where(Case.status.in_(status.split(",")))
    if mine and p.agent_id:
        q = q.where(Case.owner_agent_id == p.agent_id)
    return [cases.case_view(db, c) for c in db.scalars(q.order_by(Case.due_at.asc().nulls_last()).limit(200))]


@router.get("/v1/cases/{case_id}")
def get_case(case_id: uuid.UUID, p: Principal = Depends(require("case.read")), db: Session = Depends(get_db)) -> dict:
    return cases.case_view(db, cases.get_case(db, p.org_id, case_id), detail=True)


class CaseUpdate(BaseModel):
    expected_version: int
    status: str | None = None
    outcome_code: str | None = None
    resolution_note: str | None = None
    reason: str | None = Field(None, description="Required to reopen or override a completed case")
    title: str | None = None
    priority: str | None = None
    owner_agent_id: uuid.UUID | None = None
    note: str | None = None


@router.patch("/v1/cases/{case_id}")
def update_case(case_id: uuid.UUID, body: CaseUpdate, p: Principal = Depends(require("case.write")),
                db: Session = Depends(get_db)) -> dict:
    c = cases.get_case(db, p.org_id, case_id, lock=True)
    before = c.status
    cases.update_case(db, p, c, expected_version=body.expected_version, status=body.status,
                      outcome_code=body.outcome_code, resolution_note=body.resolution_note, reason=body.reason,
                      title=body.title, priority=body.priority, owner_agent_id=body.owner_agent_id, note=body.note)
    audit.by_principal(db, p, "case.updated", "case", c.id, status_from=before, status_to=c.status,
                       reason=body.reason)
    db.commit()
    return cases.case_view(db, c, detail=True)


class EscalateIn(BaseModel):
    expected_version: int
    reason: str = Field(min_length=3)
    queue: str | None = None


@router.post("/v1/cases/{case_id}/escalate")
def escalate(case_id: uuid.UUID, body: EscalateIn, p: Principal = Depends(require("case.write")),
             db: Session = Depends(get_db)) -> dict:
    c = cases.get_case(db, p.org_id, case_id, lock=True)
    cases.escalate(db, p, c, body.reason, body.queue, body.expected_version)
    audit.by_principal(db, p, "case.escalated", "case", c.id, reason=body.reason, level=c.escalation_level)
    db.commit()
    return cases.case_view(db, c, detail=True)


class LinkIn(BaseModel):
    interaction_id: uuid.UUID
    link_type: str = "related"


@router.post("/v1/cases/{case_id}/interactions")
def link(case_id: uuid.UUID, body: LinkIn, p: Principal = Depends(require("case.write")),
         db: Session = Depends(get_db)) -> dict:
    c = cases.get_case(db, p.org_id, case_id)
    cases.link_interaction(db, p, c, body.interaction_id, body.link_type)
    audit.by_principal(db, p, "case.interaction_linked", "case", c.id, interaction=str(body.interaction_id))
    db.commit()
    return cases.case_view(db, c, detail=True)


@router.get("/v1/outcome-codes")
def outcome_codes(p: Principal = Depends(require("workspace.read")), db: Session = Depends(get_db)) -> list[dict]:
    return [{"code": o.code, "label": o.label, "category": o.category, "requires_follow_up": o.requires_follow_up}
            for o in db.scalars(select(OutcomeCode).where(OutcomeCode.org_id == p.org_id, OutcomeCode.active.is_(True))
                                .order_by(OutcomeCode.label))]


# --------------------------------------------------------------------------- tasks

class TaskIn(BaseModel):
    title: str = Field(min_length=3, max_length=300)
    description: str = ""
    kind: str = "follow_up"
    due_at: datetime | None = None
    assignee_agent_id: uuid.UUID | None = None
    assignee_queue: str | None = None
    case_id: uuid.UUID | None = None
    interaction_id: uuid.UUID | None = None
    customer_id: uuid.UUID | None = None
    priority: str = "normal"


@router.post("/v1/tasks", status_code=201)
def create_task(body: TaskIn, request: Request, p: Principal = Depends(require("task.write")),
                db: Session = Depends(get_db)):
    def run():
        t = cases.create_task(db, p, title=body.title, description=body.description, kind=body.kind,
                              due_at=body.due_at, assignee_agent_id=body.assignee_agent_id,
                              assignee_queue_code=body.assignee_queue, case_id=body.case_id,
                              interaction_id=body.interaction_id, customer_id=body.customer_id,
                              priority=body.priority)
        audit.by_principal(db, p, "task.created", "task", t.id, title=t.title)
        return 201, cases.task_view(db, t)

    return idempotent(request, db, p, body.model_dump(mode="json"), run)


@router.get("/v1/tasks")
def list_tasks(scope: str = "mine", status: str = "open,in_progress", p: Principal = Depends(require("task.read")),
               db: Session = Depends(get_db)) -> list[dict]:
    q = select(Task).where(Task.org_id == p.org_id, Task.status.in_(status.split(",")))
    if scope == "mine":
        from ..models import AgentQueueMembership

        qids = select(AgentQueueMembership.queue_id).where(AgentQueueMembership.agent_id == p.agent_id)
        q = q.where(or_(Task.assignee_agent_id == p.agent_id,
                        (Task.assignee_agent_id.is_(None)) & Task.assignee_queue_id.in_(qids)))
    return [cases.task_view(db, t) for t in db.scalars(q.order_by(Task.due_at.asc().nulls_last()).limit(200))]


class TaskUpdate(BaseModel):
    expected_version: int
    status: str | None = None
    note: str | None = None
    assignee_agent_id: uuid.UUID | None = None
    due_at: datetime | None = None
    reason: str | None = None


@router.patch("/v1/tasks/{task_id}")
def update_task(task_id: uuid.UUID, body: TaskUpdate, p: Principal = Depends(require("task.write")),
                db: Session = Depends(get_db)) -> dict:
    t = db.scalar(select(Task).where(Task.id == task_id, Task.org_id == p.org_id).with_for_update())
    if t is None:
        raise NotFound("Task not found")
    cases.update_task(db, p, t, expected_version=body.expected_version, status=body.status, note=body.note,
                      assignee_agent_id=body.assignee_agent_id, due_at=body.due_at, reason=body.reason)
    audit.by_principal(db, p, "task.updated", "task", t.id, status=t.status, reason=body.reason)
    db.commit()
    return cases.task_view(db, t)
