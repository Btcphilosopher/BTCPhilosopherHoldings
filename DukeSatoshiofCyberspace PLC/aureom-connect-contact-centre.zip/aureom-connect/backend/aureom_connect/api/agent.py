"""/v1/agent/* and /v1/agents/* – workspace, availability, media credentials, reconciliation."""
from __future__ import annotations

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from ..adapters.telephony.registry import get_provider
from ..db import get_db, utcnow
from ..models import (Agent, AgentParticipation, AgentQueueMembership, AppEvent, Callback, Interaction, Offer, Task)
from ..models.enums import Presence
from ..security.auth import Principal, require, require_agent
from ..services import agent_state, audit, calls, reconciliation, routing
from .views import agent_for, agent_view, interaction_summary

router = APIRouter(tags=["agent"])


@router.get("/v1/agent/workspace")
def workspace(p: Principal = Depends(require_agent), db: Session = Depends(get_db)) -> dict:
    a = agent_for(db, p)
    offers = db.scalars(select(Offer).where(Offer.agent_id == a.id, Offer.status == "pending")
                        .order_by(Offer.offered_at)).all()
    part_ids = select(AgentParticipation.interaction_id).where(AgentParticipation.agent_id == a.id,
                                                               AgentParticipation.wrap_ended_at.is_(None))
    active = db.scalars(select(Interaction).where(
        Interaction.org_id == p.org_id,
        or_(Interaction.owner_agent_id == a.id, Interaction.id.in_(part_ids)),
        Interaction.status.in_(["connecting", "active", "wrap_up", "offered"])).order_by(Interaction.created_at)).all()
    my_queue_ids = select(AgentQueueMembership.queue_id).where(AgentQueueMembership.agent_id == a.id)
    tasks = db.scalars(select(Task).where(Task.org_id == p.org_id, Task.status.in_(["open", "in_progress"]),
                                          or_(Task.assignee_agent_id == a.id,
                                              (Task.assignee_agent_id.is_(None)) & Task.assignee_queue_id.in_(my_queue_ids)))
                       .order_by(Task.due_at.asc().nulls_last()).limit(25)).all()
    cbs = db.scalars(select(Callback).where(Callback.owner_agent_id == a.id,
                                            Callback.status.in_(["in_progress", "offered"]))).all()
    snapshot = [q for q in routing.queue_snapshot(db, p.org_id)
                if q["id"] in set(db.scalars(my_queue_ids))]
    cursor = db.scalar(select(func.max(AppEvent.id)).where(AppEvent.org_id == p.org_id)) or 0
    caps = get_provider().capabilities()
    return {
        "agent": agent_view(db, a, detail=True),
        "provider": {"name": caps.provider, "status": calls.provider_status(db, p.org_id), "media": caps.media,
                     "simulated": caps.media == "none_simulated", "notes": caps.notes},
        "offers": [{"id": o.id, "kind": o.kind, "offered_at": o.offered_at, "expires_at": o.expires_at,
                    "interaction": interaction_summary(db, db.get(Interaction, o.interaction_id))} for o in offers],
        "active": [interaction_summary(db, it) for it in active],
        "tasks": [{"id": t.id, "title": t.title, "status": t.status, "due_at": t.due_at, "priority": t.priority,
                   "kind": t.kind, "assigned_to_me": t.assignee_agent_id == a.id, "version": t.version,
                   "case_id": t.case_id, "overdue": bool(t.due_at and t.due_at < utcnow())} for t in tasks],
        "callbacks": [{"id": c.id, "reference": c.reference, "status": c.status, "window_end": c.window_end}
                      for c in cbs],
        "queues": snapshot,
        "event_cursor": cursor,
        "server_time": utcnow(),
    }


class AvailabilityIn(BaseModel):
    state: str
    reason: str | None = None
    expected_version: int | None = None


@router.put("/v1/agents/me/availability")
def set_availability(body: AvailabilityIn, p: Principal = Depends(require_agent), db: Session = Depends(get_db)) -> dict:
    a = db.get(Agent, p.agent_id, with_for_update=True)
    agent_state.request_state(db, a, body.state, reason=body.reason, actor_user_id=p.user_id,
                              expected_version=body.expected_version)
    audit.by_principal(db, p, "agent.availability", "agent", a.id, state=body.state, reason=body.reason)
    db.commit()
    if body.state == "available":
        routing.route_org(db, p.org_id)
        db.commit()
    return agent_view(db, a, detail=True)


@router.post("/v1/agents/me/media-credential")
def media_credential(p: Principal = Depends(require_agent), db: Session = Depends(get_db)) -> dict:
    """Short-lived credential for the browser to register its device directly with the provider."""
    cred = get_provider().issue_media_credential(f"agent:{p.agent_id}", ttl_seconds=600)
    audit.by_principal(db, p, "agent.media_credential_issued", "agent", p.agent_id, provider=cred.provider,
                       expires_at=cred.expires_at.isoformat())
    db.commit()
    return cred.model_dump()


@router.post("/v1/agents/me/presence")
def presence(p: Principal = Depends(require_agent), db: Session = Depends(get_db)) -> dict:
    """REST heartbeat fallback (the event WebSocket also refreshes presence)."""
    a = db.get(Agent, p.agent_id)
    a.presence = Presence.ONLINE
    a.presence_last_seen = utcnow()
    db.commit()
    return {"presence": a.presence, "last_seen": a.presence_last_seen}


@router.post("/v1/agents/me/reconcile")
def reconcile_me(p: Principal = Depends(require_agent), db: Session = Depends(get_db)) -> dict:
    a = db.get(Agent, p.agent_id, with_for_update=True)
    result = reconciliation.reconcile_agent(db, a)
    audit.by_principal(db, p, "agent.reconcile", "agent", a.id, cleared=result["cleared"], changes=result["changes"])
    db.commit()
    return {**result, "agent": agent_view(db, a, detail=True)}


@router.get("/v1/agents/directory")
def directory(p: Principal = Depends(require_agent), db: Session = Depends(get_db)) -> list[dict]:
    """Minimal colleague directory for transfers: availability and skills only."""
    out = []
    for a in db.scalars(select(Agent).where(Agent.org_id == p.org_id, Agent.id != p.agent_id)
                        .order_by(Agent.display_name)):
        v = agent_view(db, a)
        ready = (a.state == "available" and a.presence == "online" and a.telephony_registration == "registered"
                 and not a.reconcile_required)
        out.append({"id": a.id, "display_name": a.display_name, "state": a.state, "skills": v["skills"],
                    "queues": v["queues"], "languages": a.languages, "can_take_consult": ready})
    return out


@router.get("/v1/agents")
def list_agents(p: Principal = Depends(require("agent.read")), db: Session = Depends(get_db)) -> list[dict]:
    return [agent_view(db, a, detail=True) for a in db.scalars(select(Agent).where(Agent.org_id == p.org_id)
                                                               .order_by(Agent.display_name))]


class SupervisorStateIn(BaseModel):
    state: str
    reason: str


@router.put("/v1/agents/{agent_id}/state")
def supervisor_set_state(agent_id: str, body: SupervisorStateIn, p: Principal = Depends(require("agent.manage_state")),
                         db: Session = Depends(get_db)) -> dict:
    import uuid

    a = db.get(Agent, uuid.UUID(agent_id), with_for_update=True)
    if a is None or a.org_id != p.org_id:
        from ..errors import NotFound

        raise NotFound("Agent not found")
    if body.state not in ("unavailable", "break", "offline"):
        from ..errors import ValidationFailed

        raise ValidationFailed("Supervisors may only set unavailable, break or offline")
    agent_state.request_state(db, a, body.state, reason=f"supervisor: {body.reason}", actor_user_id=p.user_id,
                              expected_version=None, source="supervisor")
    audit.by_principal(db, p, "agent.state_set_by_supervisor", "agent", a.id, state=body.state, reason=body.reason)
    db.commit()
    return agent_view(db, a, detail=True)
