"""/v1/interactions – detail, accept/reject, call actions, wrap-up, identity and verification."""
from __future__ import annotations

import uuid
from typing import Any

from fastapi import APIRouter, Depends, Query, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db, utcnow
from ..errors import Forbidden, NotFound, ValidationFailed
from ..models import (Agent, ChatMessage, Interaction, InteractionSummary, Transcript, TranscriptCorrection)
from ..security.auth import Principal, current_principal, require, require_agent
from ..services import audit, calls, customers, events, interactions, routing
from .deps import idempotent
from .views import can_view_interaction, interaction_detail, interaction_summary

router = APIRouter(prefix="/v1/interactions", tags=["interactions"])


def _load(db: Session, p: Principal, interaction_id: uuid.UUID) -> Interaction:
    it = db.get(Interaction, interaction_id)
    if it is None or it.org_id != p.org_id:
        raise NotFound("Interaction not found")
    return it


@router.get("")
def list_interactions(status: str | None = None, queue: str | None = None, limit: int = Query(50, le=200),
                      p: Principal = Depends(require("ops.read")), db: Session = Depends(get_db)) -> list[dict]:
    q = select(Interaction).where(Interaction.org_id == p.org_id)
    if status:
        q = q.where(Interaction.status.in_(status.split(",")))
    rows = db.scalars(q.order_by(Interaction.created_at.desc()).limit(limit)).all()
    out = [interaction_summary(db, it) for it in rows]
    if queue:
        out = [o for o in out if o["queue"] and o["queue"]["code"] == queue]
    return out


@router.get("/{interaction_id}")
def get_interaction(interaction_id: uuid.UUID, p: Principal = Depends(current_principal),
                    db: Session = Depends(get_db)) -> dict:
    it = _load(db, p, interaction_id)
    detail = interaction_detail(db, p, it)
    if it.customer_id and detail.get("customer_record", {}) and detail["customer_record"]["restricted"] is not None:
        audit.by_principal(db, p, "customer.restricted_viewed", "customer", it.customer_id,
                           interaction=it.reference)
        db.commit()
    return detail


class AcceptIn(BaseModel):
    offer_id: uuid.UUID | None = None
    expected_version: int | None = None


@router.post("/{interaction_id}/accept")
def accept(interaction_id: uuid.UUID, body: AcceptIn, request: Request, p: Principal = Depends(require_agent),
           db: Session = Depends(get_db)):
    def run():
        agent = db.get(Agent, p.agent_id, with_for_update=True)
        res = interactions.accept(db, agent, interaction_id, offer_id=body.offer_id,
                                  expected_version=body.expected_version, actor_user_id=p.user_id)
        audit.by_principal(db, p, "interaction.accepted", "interaction", interaction_id)
        return 200, res

    return idempotent(request, db, p, body.model_dump(mode="json"), run)


class RejectIn(BaseModel):
    offer_id: uuid.UUID | None = None
    reason: str | None = None


@router.post("/{interaction_id}/reject")
def reject(interaction_id: uuid.UUID, body: RejectIn, request: Request, p: Principal = Depends(require_agent),
           db: Session = Depends(get_db)):
    def run():
        agent = db.get(Agent, p.agent_id, with_for_update=True)
        interactions.reject(db, agent, interaction_id, offer_id=body.offer_id, reason=body.reason,
                            actor_user_id=p.user_id)
        db.commit()
        routing.route_org(db, p.org_id)
        return 200, {"ok": True}

    return idempotent(request, db, p, body.model_dump(mode="json"), run)


class ActionIn(BaseModel):
    action: str = Field(description="hold | resume | mute | unmute | warm_transfer_start | warm_transfer_complete | "
                                    "warm_transfer_cancel | blind_transfer | conference | end | start_secure_payment | "
                                    "answer | reject")
    params: dict[str, Any] = Field(default_factory=dict)


@router.post("/{interaction_id}/actions")
def action(interaction_id: uuid.UUID, body: ActionIn, request: Request, p: Principal = Depends(require_agent),
           db: Session = Depends(get_db)):
    key = request.headers.get("Idempotency-Key")
    if not key:
        raise ValidationFailed("Idempotency-Key header is required for call actions", code="IDEMPOTENCY_KEY_REQUIRED")

    def run():
        agent = db.get(Agent, p.agent_id)
        if body.action == "answer":
            res = interactions.accept(db, agent, interaction_id, offer_id=body.params.get("offer_id"),
                                      expected_version=body.params.get("expected_version"), actor_user_id=p.user_id)
            return 200, {"action": "answer", "result": res}
        if body.action == "reject":
            interactions.reject(db, agent, interaction_id, offer_id=body.params.get("offer_id"),
                                reason=body.params.get("reason"), actor_user_id=p.user_id)
            return 200, {"action": "reject", "status": "done"}
        ctl = calls.perform(db, agent, interaction_id, body.action, body.params, key, p.user_id)
        audit.by_principal(db, p, f"call.{body.action}", "interaction", interaction_id, control_id=str(ctl.id),
                           status=ctl.status)
        return 202, {"control_id": ctl.id, "action": ctl.action, "status": ctl.status,
                     "error_code": ctl.error_code, "error_message": ctl.error_message,
                     "note": "Status 'requested' means the provider accepted the request. The call state changes "
                             "only when the provider confirms it."}

    return idempotent(request, db, p, body.model_dump(mode="json"), run)


class WrapUpIn(BaseModel):
    disposition_code: str
    note: str | None = None
    expected_version: int | None = None


@router.post("/{interaction_id}/wrap-up")
def wrap_up(interaction_id: uuid.UUID, body: WrapUpIn, request: Request, p: Principal = Depends(require_agent),
            db: Session = Depends(get_db)):
    def run():
        agent = db.get(Agent, p.agent_id, with_for_update=True)
        res = interactions.complete_wrap_up(db, agent, interaction_id, disposition_code=body.disposition_code,
                                            note=body.note, expected_version=body.expected_version,
                                            actor_user_id=p.user_id)
        audit.by_principal(db, p, "interaction.wrap_up_completed", "interaction", interaction_id,
                           disposition=body.disposition_code)
        db.commit()
        routing.route_org(db, p.org_id)
        return 200, res

    return idempotent(request, db, p, body.model_dump(mode="json"), run)


class SelectCustomerIn(BaseModel):
    customer_id: uuid.UUID


@router.post("/{interaction_id}/customer")
def select_customer(interaction_id: uuid.UUID, body: SelectCustomerIn, p: Principal = Depends(require_agent),
                    db: Session = Depends(get_db)) -> dict:
    it = _load(db, p, interaction_id)
    customers.select_candidate(db, it, body.customer_id, p.agent_id, p.user_id)
    audit.by_principal(db, p, "interaction.customer_selected", "interaction", it.id, customer_id=str(body.customer_id))
    db.commit()
    return interaction_detail(db, p, it)


class VerifyIn(BaseModel):
    answers: dict[str, str] = Field(description="factor code -> answer given by the customer (never stored)")


@router.post("/{interaction_id}/verification")
def verify(interaction_id: uuid.UUID, body: VerifyIn, p: Principal = Depends(require_agent),
           db: Session = Depends(get_db)) -> dict:
    p.require("customer.verify")
    it = _load(db, p, interaction_id)
    res = customers.verify(db, it, p.agent_id, body.answers, p.user_id)
    audit.by_principal(db, p, "customer.verification_attempt", "interaction", it.id, status=res["status"],
                       factors=sorted(body.answers.keys()))
    db.commit()
    return res


class SummaryIn(BaseModel):
    body: str = Field(min_length=10, max_length=8000)
    ai_suggestion_id: uuid.UUID | None = None
    reviewed: bool = Field(description="Must be true: the agent confirms they reviewed and corrected the text")


@router.post("/{interaction_id}/summary")
def save_summary(interaction_id: uuid.UUID, body: SummaryIn, p: Principal = Depends(require_agent),
                 db: Session = Depends(get_db)) -> dict:
    it = _load(db, p, interaction_id)
    if not can_view_interaction(db, p, it) or (it.owner_agent_id != p.agent_id and not
                                               interactions.open_participation(db, it.id, p.agent_id)):
        from sqlalchemy import select as _s

        from ..models import AgentParticipation

        if not db.scalar(_s(AgentParticipation.id).where(AgentParticipation.interaction_id == it.id,
                                                         AgentParticipation.agent_id == p.agent_id)):
            raise Forbidden("Only an agent who handled this interaction can save its summary")
    if not body.reviewed:
        raise ValidationFailed("Summaries must be reviewed by the agent before saving", code="REVIEW_REQUIRED")
    source = "agent_written"
    if body.ai_suggestion_id:
        from ..models import AiSuggestion

        sug = db.get(AiSuggestion, body.ai_suggestion_id)
        if sug is None or sug.interaction_id != it.id or sug.kind != "summary_draft":
            raise ValidationFailed("AI suggestion does not belong to this interaction")
        original = (sug.output or {}).get("summary", "")
        sug.status = "accepted" if original.strip() == body.body.strip() else "edited"
        sug.reviewed_by, sug.reviewed_at = p.user_id, utcnow()
        source = "ai_draft_reviewed"
    prev = db.scalar(select(InteractionSummary).where(InteractionSummary.interaction_id == it.id)
                     .order_by(InteractionSummary.reviewed_at.desc()).limit(1))
    s = InteractionSummary(org_id=it.org_id, interaction_id=it.id, body=body.body, source=source,
                           ai_suggestion_id=body.ai_suggestion_id, authored_by=p.user_id, reviewed_at=utcnow(),
                           supersedes_id=prev.id if prev else None)
    db.add(s)
    events.timeline(db, it, "summary.saved", "agent", actor_user_id=p.user_id, summary_source=source)
    audit.by_principal(db, p, "interaction.summary_saved", "interaction", it.id, source=source)
    db.commit()
    return {"id": s.id, "source": source, "reviewed_at": s.reviewed_at}


class MessageIn(BaseModel):
    body: str = Field(min_length=1, max_length=4000)


@router.post("/{interaction_id}/messages")
def send_message(interaction_id: uuid.UUID, body: MessageIn, p: Principal = Depends(require_agent),
                 db: Session = Depends(get_db)) -> dict:
    from ..adapters.channels.registry import channel_for

    it = _load(db, p, interaction_id)
    if it.owner_agent_id != p.agent_id or it.status != "active":
        raise Forbidden("Only the owning agent can reply to an active conversation")
    if it.channel not in ("chat", "email"):
        raise ValidationFailed("Messages are only for chat and email interactions")
    msg = ChatMessage(org_id=it.org_id, interaction_id=it.id, sender="agent", agent_id=p.agent_id, body=body.body,
                      sent_at=utcnow(), attachments=[])
    db.add(msg)
    db.flush()
    channel_for(it.channel).deliver_agent_message(db, it, msg)
    events.timeline(db, it, "message.sent", "agent", actor_user_id=p.user_id, channel=it.channel)
    events.publish(db, it.org_id, f"interaction:{it.id}", "message.created", interaction_id=it.id, message_id=msg.id)
    db.commit()
    return {"id": msg.id, "sent_at": msg.sent_at}


class CorrectionIn(BaseModel):
    segment_index: int
    corrected_text: str = Field(min_length=1, max_length=2000)
    reason: str = Field(min_length=3, max_length=500)


@router.post("/{interaction_id}/transcripts/{transcript_id}/corrections")
def correct_transcript(interaction_id: uuid.UUID, transcript_id: uuid.UUID, body: CorrectionIn,
                       p: Principal = Depends(current_principal), db: Session = Depends(get_db)) -> dict:
    p.require("transcript.correct")
    it = _load(db, p, interaction_id)
    if not can_view_interaction(db, p, it):
        raise Forbidden("Not permitted")
    t = db.get(Transcript, transcript_id)
    if t is None or t.interaction_id != it.id:
        raise NotFound("Transcript not found")
    seg = next((s for s in t.segments if s.get("i") == body.segment_index), None)
    if seg is None:
        raise ValidationFailed("Segment not found")
    c = TranscriptCorrection(org_id=it.org_id, transcript_id=t.id, segment_index=body.segment_index,
                             original_text=seg["text"], corrected_text=body.corrected_text, reason=body.reason,
                             corrected_by=p.user_id, corrected_at=utcnow())
    db.add(c)
    audit.by_principal(db, p, "transcript.corrected", "transcript", t.id, segment=body.segment_index)
    db.commit()
    return {"id": c.id, "note": "Original machine output preserved; correction stored separately."}


@router.post("/{interaction_id}/reconcile")
def reconcile_interaction(interaction_id: uuid.UUID, p: Principal = Depends(require_agent),
                          db: Session = Depends(get_db)) -> dict:
    """Ask the provider for this call's authoritative state (used to resolve 'unknown' control outcomes)."""
    from ..adapters.telephony.registry import get_provider
    from ..services import reconciliation

    it = _load(db, p, interaction_id)
    if it.owner_agent_id != p.agent_id:
        raise Forbidden("Only the owning agent can reconcile this interaction")
    call = interactions.primary_call(db, it.id)
    if call is None:
        return {"changes": []}
    state = get_provider().get_call_state(call.provider_call_id)
    if state is None and not get_provider().health():
        from ..errors import ProviderUnavailable

        raise ProviderUnavailable("Provider unreachable; cannot reconcile yet")
    changes = reconciliation.reconcile_call(db, call, state)
    agent = db.get(Agent, p.agent_id)
    agent_res = reconciliation.reconcile_agent(db, agent, query_provider=False)
    audit.by_principal(db, p, "interaction.reconciled", "interaction", it.id, changes=changes)
    db.commit()
    return {"changes": changes, "agent": agent_res}
