"""Response shaping shared by routers (server-side authorisation already applied)."""
from __future__ import annotations

import uuid
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..adapters.telephony.registry import get_provider
from ..errors import Forbidden
from ..models import (Agent, AgentParticipation, AgentQueueMembership, AgentSkill, AiSuggestion, Call, CallControl,
                      CallLeg, Case, CaseInteraction, ChatMessage, Customer, Interaction, InteractionEvent,
                      InteractionSummary, MonitoringSession, Offer, Queue, QueueEntry, Recording,
                      SecurePaymentSession, Skill, Task, Transcript, TranscriptCorrection)
from ..security.auth import Principal
from ..services import agent_state, calls, customers, recording


def cols(obj: Any, *names: str) -> dict[str, Any]:
    return {n: getattr(obj, n) for n in names}


def agent_for(db: Session, p: Principal) -> Agent:
    if p.agent_id is None:
        raise Forbidden("You are not configured as an agent", code="NOT_AN_AGENT")
    return db.get(Agent, p.agent_id)


def agent_view(db: Session, a: Agent, *, detail: bool = False) -> dict[str, Any]:
    out = cols(a, "id", "display_name", "state", "state_reason", "state_since", "state_version", "presence",
               "presence_last_seen", "telephony_registration", "telephony_registered_at", "reconcile_required",
               "reconcile_reason", "current_interaction_id", "languages", "team", "available_since",
               "missed_offer_count")
    out["skills"] = [code for (code,) in db.execute(select(Skill.code).join(AgentSkill, AgentSkill.skill_id == Skill.id)
                                                    .where(AgentSkill.agent_id == a.id))]
    out["queues"] = [code for (code,) in db.execute(select(Queue.code).join(
        AgentQueueMembership, AgentQueueMembership.queue_id == Queue.id).where(AgentQueueMembership.agent_id == a.id))]
    if detail:
        out["readiness"] = agent_state.readiness(db, a)
    return out


def interaction_summary(db: Session, it: Interaction) -> dict[str, Any]:
    q = db.get(Queue, it.current_queue_id) if it.current_queue_id else None
    cust = db.get(Customer, it.customer_id) if it.customer_id else None
    return {**cols(it, "id", "reference", "channel", "direction", "status", "version", "customer_match_status",
                   "owner_agent_id", "first_queued_at", "routable_since", "connected_at", "ended_at", "subject",
                   "urgency_flag", "is_simulated", "transfer_count", "needs_reconciliation", "callback_id",
                   "campaign_contact_id", "disposition_code", "language"),
            "queue": {"id": q.id, "code": q.code, "name": q.name} if q else None,
            "customer": {"id": cust.id, "display_name": cust.display_name, "customer_ref": cust.customer_ref}
            if cust else None,
            "caller": (it.match_hint or {}).get("ani") and customers.mask_phone((it.match_hint or {}).get("ani"))}


def can_view_interaction(db: Session, p: Principal, it: Interaction) -> bool:
    if it.org_id != p.org_id:
        return False
    if p.has("ops.read") or p.has("qa.review"):
        return True
    if p.agent_id is None:
        return False
    if it.owner_agent_id == p.agent_id:
        return True
    if db.scalar(select(AgentParticipation.id).where(AgentParticipation.interaction_id == it.id,
                                                     AgentParticipation.agent_id == p.agent_id).limit(1)):
        return True
    return bool(db.scalar(select(Offer.id).where(Offer.interaction_id == it.id, Offer.agent_id == p.agent_id,
                                                 Offer.status == "pending").limit(1)))


def interaction_detail(db: Session, p: Principal, it: Interaction) -> dict[str, Any]:
    if not can_view_interaction(db, p, it):
        raise Forbidden("You cannot view this interaction")
    out = interaction_summary(db, it)
    out["transfer_state"] = it.transfer_state
    out["ivr_path"] = it.ivr_path
    out["disposition_note"] = it.disposition_note
    out["end_reason"] = it.end_reason
    call = db.scalar(select(Call).where(Call.interaction_id == it.id).order_by(Call.created_at.desc()).limit(1))
    out["call"] = None
    if call:
        legs = db.scalars(select(CallLeg).where(CallLeg.call_id == call.id).order_by(CallLeg.created_at)).all()
        out["call"] = {**cols(call, "id", "provider", "provider_call_id", "direction", "status", "started_at",
                              "answered_at", "ended_at", "end_reason", "last_provider_sequence",
                              "last_provider_event_at"),
                       "from_number": customers.mask_phone(call.from_number) if call.direction == "inbound"
                       else call.from_number,
                       "to_number": call.to_number if call.direction == "inbound" else customers.mask_phone(call.to_number),
                       "legs": [{**cols(lg, "id", "provider_leg_id", "leg_type", "agent_id", "status", "on_hold",
                                        "provider_muted", "answered_at", "ended_at", "end_reason",
                                        "hold_seconds_total")} for lg in legs]}
    out["participations"] = [cols(pp, "id", "agent_id", "role", "accepted_at", "connected_at", "ended_at",
                                  "wrap_started_at", "wrap_ended_at", "hold_seconds", "outcome")
                             for pp in db.scalars(select(AgentParticipation).where(
                                 AgentParticipation.interaction_id == it.id).order_by(AgentParticipation.created_at))]
    out["queue_entries"] = [{**cols(qe, "id", "sequence", "entered_at", "left_at", "exit_reason", "offers_made"),
                             "queue": db.get(Queue, qe.queue_id).code}
                            for qe in db.scalars(select(QueueEntry).where(QueueEntry.interaction_id == it.id)
                                                 .order_by(QueueEntry.sequence))]
    out["controls"] = [cols(c, "id", "action", "status", "requested_at", "acknowledged_at", "resolved_by",
                            "error_code", "error_message", "agent_id")
                       for c in db.scalars(select(CallControl).where(CallControl.interaction_id == it.id)
                                           .order_by(CallControl.requested_at.desc()).limit(30))]
    agent = db.get(Agent, p.agent_id) if p.agent_id else None
    out["available_controls"] = calls.available_controls(db, it, agent) if agent and it.channel == "voice" else {}
    out["capabilities"] = get_provider().capabilities().model_dump()
    out["provider_status"] = calls.provider_status(db, it.org_id)
    # Customer identity: candidates are hints; restricted data only in verified context.
    cands = []
    for cid in (it.match_hint or {}).get("candidate_ids", []):
        c = db.get(Customer, uuid.UUID(cid))
        if c:
            cands.append({"customer_id": c.id, "customer_ref": c.customer_ref, "display_name": c.display_name})
    ani = (it.match_hint or {}).get("ani")
    out["candidates"] = customers.match_by_phone(db, it.org_id, ani) if ani else cands
    out["match_note"] = "Telephone number is a matching hint, not proof of identity."
    out["customer_record"] = None
    out["verification"] = None
    if it.customer_id:
        cust = db.get(Customer, it.customer_id)
        verified = customers.is_verified_context(db, p.agent_id, cust.id, it.id)
        out["customer_record"] = customers.customer_view(db, cust, verified=verified)
        out["verification"] = customers.verification_status(db, it)
    out["recordings"] = [recording.recording_view(r) for r in db.scalars(
        select(Recording).where(Recording.interaction_id == it.id))]
    out["transcripts"] = []
    for t in db.scalars(select(Transcript).where(Transcript.interaction_id == it.id)):
        corr = db.scalars(select(TranscriptCorrection).where(TranscriptCorrection.transcript_id == t.id)
                          .order_by(TranscriptCorrection.corrected_at)).all()
        out["transcripts"].append({"id": t.id, "provenance": t.provenance, "source": t.source,
                                   "segments": t.segments, "label": "Machine transcript – unverified, not a record of fact",
                                   "corrections": [cols(c, "segment_index", "original_text", "corrected_text", "reason",
                                                        "corrected_by", "corrected_at") for c in corr]})
    out["timeline"] = [cols(e, "id", "type", "source", "occurred_at", "recorded_at", "data", "actor_user_id")
                       for e in db.scalars(select(InteractionEvent).where(InteractionEvent.interaction_id == it.id)
                                           .order_by(InteractionEvent.recorded_at))]
    out["summaries"] = [cols(s, "id", "body", "source", "authored_by", "reviewed_at", "ai_suggestion_id")
                        for s in db.scalars(select(InteractionSummary).where(
                            InteractionSummary.interaction_id == it.id).order_by(InteractionSummary.reviewed_at.desc()))]
    out["messages"] = [cols(m, "id", "sender", "agent_id", "body", "subject", "sent_at")
                       for m in db.scalars(select(ChatMessage).where(ChatMessage.interaction_id == it.id)
                                           .order_by(ChatMessage.sent_at))]
    out["cases"] = [{"id": c.id, "case_ref": c.case_ref, "title": c.title, "status": c.status, "link_type": ci.link_type}
                    for ci, c in db.execute(select(CaseInteraction, Case).join(Case, Case.id == CaseInteraction.case_id)
                                            .where(CaseInteraction.interaction_id == it.id))]
    out["tasks"] = [cols(t, "id", "title", "status", "due_at", "assignee_agent_id", "kind", "priority")
                    for t in db.scalars(select(Task).where(Task.interaction_id == it.id))]
    out["monitoring"] = [cols(m, "id", "mode", "status", "supervisor_user_id", "started_at", "ended_at")
                         for m in db.scalars(select(MonitoringSession).where(MonitoringSession.interaction_id == it.id,
                                                                             MonitoringSession.status == "active"))]
    out["payments"] = [cols(s, "id", "status", "amount_minor", "currency", "recording_paused_confirmed",
                            "result_reference", "started_at", "ended_at")
                       for s in db.scalars(select(SecurePaymentSession).where(
                           SecurePaymentSession.interaction_id == it.id))]
    out["ai_suggestions"] = [cols(s, "id", "kind", "provider", "model", "output", "sources", "uncertainty",
                                  "safety_flags", "status", "created_at")
                             for s in db.scalars(select(AiSuggestion).where(AiSuggestion.interaction_id == it.id)
                                                 .order_by(AiSuggestion.created_at.desc()).limit(10))]
    my_offer = db.scalar(select(Offer).where(Offer.interaction_id == it.id, Offer.agent_id == p.agent_id,
                                             Offer.status == "pending")) if p.agent_id else None
    out["my_offer"] = cols(my_offer, "id", "kind", "offered_at", "expires_at") if my_offer else None
    return out
