"""/v1/reports – metrics with definitions; agent breakdown; audit-history views live in /v1/audit."""
from __future__ import annotations

import uuid
from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..db import get_db, utcnow
from ..errors import ValidationFailed
from ..security.auth import Principal, require
from ..services import reports

router = APIRouter(prefix="/v1/reports", tags=["reports"])


def _window(start: datetime | None, end: datetime | None) -> tuple[datetime, datetime]:
    if start is None:
        local = utcnow().astimezone(ZoneInfo("Europe/London"))
        start = datetime.combine(local.date(), time(0), ZoneInfo("Europe/London"))
    end = end or utcnow() + timedelta(seconds=1)
    if end <= start:
        raise ValidationFailed("end must be after start")
    if end - start > timedelta(days=93):
        raise ValidationFailed("window may not exceed 93 days")
    return start, end


@router.get("/summary")
def summary(start: datetime | None = None, end: datetime | None = None, queue_id: uuid.UUID | None = None,
            include_synthetic_history: bool = True, p: Principal = Depends(require("report.read")),
            db: Session = Depends(get_db)) -> dict:
    s, e = _window(start, end)
    return reports.summary(db, p.org_id, s, e, queue_id, include_synthetic_history)


@router.get("/agents")
def agents(start: datetime | None = None, end: datetime | None = None, p: Principal = Depends(require("report.read")),
           db: Session = Depends(get_db)) -> dict:
    s, e = _window(start, end)
    return {"window": {"start": s, "end": e}, "agents": reports.by_agent(db, p.org_id, s, e),
            "caution": "Per-agent figures describe workload, not quality. Do not rank agents by handling time."}


@router.get("/definitions")
def definitions(p: Principal = Depends(require("report.read"))) -> dict:
    return reports.DEFINITIONS
