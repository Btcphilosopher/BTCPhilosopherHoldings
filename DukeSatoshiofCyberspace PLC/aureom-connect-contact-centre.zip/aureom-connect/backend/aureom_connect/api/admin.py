"""/v1/admin/* and /v1/audit – configuration and audit history."""
from __future__ import annotations

import uuid
from datetime import date, datetime
from typing import Any

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import get_db, utcnow
from ..errors import Forbidden, InvalidTransition, NotFound, ValidationFailed
from ..models import (AuditLog, BusinessHours, CallingRuleSet, Holiday, IvrMenu, Organisation, PhoneNumber, Queue,
                      RecordingPolicy, SuppressionEntry, SuppressionList, User)
from ..models.enums import Role
from ..security.auth import Principal, require
from ..services import audit, customers, routing

router = APIRouter(tags=["administration"])

SECURITY_ACTIONS_PREFIX = ("auth.", "admin.", "recording.", "provider.", "rules.", "customer.restricted")


@router.get("/v1/admin/organisation")
def organisation(p: Principal = Depends(require("ops.read")), db: Session = Depends(get_db)) -> dict:
    org = db.get(Organisation, p.org_id)
    return {"id": org.id, "name": org.name, "slug": org.slug, "timezone": org.timezone,
            "jurisdiction": org.jurisdiction, "settings": org.settings}


@router.get("/v1/admin/users")
def users(p: Principal = Depends(require("admin.users")), db: Session = Depends(get_db)) -> list[dict]:
    return [{"id": u.id, "email": u.email, "display_name": u.display_name, "roles": u.roles, "active": u.active,
             "mfa_enrolled": u.mfa_enrolled, "oidc_linked": bool(u.oidc_subject), "last_login_at": u.last_login_at}
            for u in db.scalars(select(User).where(User.org_id == p.org_id).order_by(User.display_name))]


class RolesIn(BaseModel):
    roles: list[str]
    reason: str = Field(min_length=5)


@router.put("/v1/admin/users/{user_id}/roles")
def set_roles(user_id: uuid.UUID, body: RolesIn, p: Principal = Depends(require("admin.users")),
              db: Session = Depends(get_db)) -> dict:
    u = db.get(User, user_id)
    if u is None or u.org_id != p.org_id:
        raise NotFound("User not found")
    bad = [r for r in body.roles if r not in {x.value for x in Role}]
    if bad:
        raise ValidationFailed("Unknown roles", details={"roles": bad})
    if u.id == p.user_id and "admin" not in body.roles:
        raise Forbidden("You cannot remove your own admin role")
    before = list(u.roles)
    u.roles = body.roles
    audit.by_principal(db, p, "admin.roles_changed", "user", u.id, before=before, after=body.roles, reason=body.reason)
    db.commit()
    return {"id": u.id, "roles": u.roles}


class QueueUpdate(BaseModel):
    routing_priority: int | None = Field(None, ge=0, le=10)
    required_skills: list[str] | None = None
    required_language: str | None = None
    overflow_after_seconds: int | None = Field(None, ge=10)
    offer_timeout_seconds: int | None = Field(None, ge=5, le=120)
    voicemail_enabled: bool | None = None
    callback_enabled: bool | None = None
    reason: str = Field(min_length=3)


@router.patch("/v1/admin/queues/{queue_id}")
def update_queue(queue_id: uuid.UUID, body: QueueUpdate, p: Principal = Depends(require("queue.manage")),
                 db: Session = Depends(get_db)) -> dict:
    q = db.get(Queue, queue_id)
    if q is None or q.org_id != p.org_id:
        raise NotFound("Queue not found")
    changes = {k: v for k, v in body.model_dump(exclude_unset=True).items() if k != "reason"}
    for k, v in changes.items():
        setattr(q, k, v)
    audit.by_principal(db, p, "admin.queue_updated", "queue", q.id, changes=changes, reason=body.reason)
    db.commit()
    return {"id": q.id, "code": q.code, **changes}


@router.get("/v1/admin/routing-config")
def routing_config(p: Principal = Depends(require("queue.read")), db: Session = Depends(get_db)) -> dict:
    hours = db.scalars(select(BusinessHours).where(BusinessHours.org_id == p.org_id)).all()
    return {
        "business_hours": [{"id": h.id, "name": h.name, "timezone": h.timezone, "weekly": h.weekly,
                            "open_now": routing.is_open(db, h.id),
                            "holidays": [{"id": x.id, "day": x.day, "name": x.name, "intervals": x.intervals}
                                         for x in db.scalars(select(Holiday).where(Holiday.business_hours_id == h.id)
                                                             .order_by(Holiday.day))]} for h in hours],
        "ivr_menus": [{"id": m.id, "name": m.name, "version": m.version, "published": m.published,
                       "definition": m.definition, "closed_action": m.closed_action}
                      for m in db.scalars(select(IvrMenu).where(IvrMenu.org_id == p.org_id))],
        "numbers": [{"id": n.id, "e164": n.e164, "label": n.label, "outbound_allowed": n.outbound_allowed,
                     "verified": n.verified_at is not None, "ivr_menu_id": n.ivr_menu_id}
                    for n in db.scalars(select(PhoneNumber).where(PhoneNumber.org_id == p.org_id))],
        "recording_policies": [{"id": r.id, "name": r.name, "jurisdiction": r.jurisdiction, "purpose": r.purpose,
                                "mode": r.mode, "notice_text": r.notice_text, "retention_days": r.retention_days,
                                "access_roles": r.access_roles, "pause_for_payment": r.pause_for_payment,
                                "version": r.version}
                               for r in db.scalars(select(RecordingPolicy).where(RecordingPolicy.org_id == p.org_id))],
        "routing_algorithm": "Eligibility (state, app presence, provider-confirmed registration, reconciliation, "
                             "queue membership, skills, language) → longest-waiting interaction (queue priority, "
                             "interaction priority, wait) → longest-idle eligible agent. Urgency flags never "
                             "change routing priority automatically.",
    }


class HolidayIn(BaseModel):
    business_hours_id: uuid.UUID
    day: date
    name: str
    intervals: list[list[str]] = []


@router.post("/v1/admin/holidays", status_code=201)
def add_holiday(body: HolidayIn, p: Principal = Depends(require("admin.config")), db: Session = Depends(get_db)) -> dict:
    bh = db.get(BusinessHours, body.business_hours_id)
    if bh is None or bh.org_id != p.org_id:
        raise NotFound("Business hours not found")
    h = Holiday(org_id=p.org_id, business_hours_id=bh.id, day=body.day, name=body.name, intervals=body.intervals)
    db.add(h)
    audit.by_principal(db, p, "admin.holiday_added", "business_hours", bh.id, day=str(body.day), name=body.name)
    db.commit()
    return {"id": h.id}


class RuleSetIn(BaseModel):
    jurisdiction: str = Field(min_length=2, max_length=16)
    rules: dict[str, Any]
    effective_from: datetime
    source_notes: str = Field(min_length=10, description="Where the rules came from and when they were checked")


@router.post("/v1/admin/calling-rules", status_code=201)
def new_rule_set(body: RuleSetIn, p: Principal = Depends(require("rules.manage")), db: Session = Depends(get_db)) -> dict:
    for key in ("calling_windows", "purposes", "objection_scopes"):
        if key not in body.rules:
            raise ValidationFailed(f"rules.{key} is required")
    n = (db.scalar(select(func.max(CallingRuleSet.version)).where(CallingRuleSet.org_id == p.org_id,
                                                                  CallingRuleSet.jurisdiction == body.jurisdiction))
         or 0) + 1
    rs = CallingRuleSet(org_id=p.org_id, jurisdiction=body.jurisdiction, version=n, status="draft",
                        effective_from=body.effective_from, rules=body.rules, source_notes=body.source_notes)
    db.add(rs)
    db.flush()
    audit.by_principal(db, p, "rules.calling_rules_drafted", "calling_rule_set", rs.id, version=n,
                       jurisdiction=body.jurisdiction)
    db.commit()
    return {"id": rs.id, "version": rs.version, "status": rs.status}


@router.post("/v1/admin/calling-rules/{rule_set_id}/activate")
def activate_rule_set(rule_set_id: uuid.UUID, p: Principal = Depends(require("rules.manage")),
                      db: Session = Depends(get_db)) -> dict:
    rs = db.get(CallingRuleSet, rule_set_id)
    if rs is None or rs.org_id != p.org_id:
        raise NotFound("Rule set not found")
    if rs.status != "draft":
        raise InvalidTransition("Only a draft rule set can be activated")
    for prev in db.scalars(select(CallingRuleSet).where(CallingRuleSet.org_id == p.org_id,
                                                        CallingRuleSet.jurisdiction == rs.jurisdiction,
                                                        CallingRuleSet.status == "active")):
        prev.status = "retired"
        prev.effective_to = max(rs.effective_from, utcnow())
    rs.status = "active"
    rs.approved_by = p.user_id
    audit.by_principal(db, p, "rules.calling_rules_activated", "calling_rule_set", rs.id, version=rs.version)
    db.commit()
    return {"id": rs.id, "status": rs.status, "version": rs.version}


@router.get("/v1/admin/suppression")
def suppression(p: Principal = Depends(require("campaign.read")), db: Session = Depends(get_db)) -> list[dict]:
    out = []
    for sl in db.scalars(select(SuppressionList).where(SuppressionList.org_id == p.org_id)):
        n = db.scalar(select(func.count()).select_from(SuppressionEntry).where(SuppressionEntry.list_id == sl.id))
        out.append({"id": sl.id, "code": sl.code, "name": sl.name, "source": sl.source, "refreshed_at": sl.refreshed_at,
                    "entries": n})
    return out


class SuppressIn(BaseModel):
    list_code: str
    number: str
    reason: str = Field(min_length=3)


@router.post("/v1/admin/suppression/entries", status_code=201)
def add_suppression(body: SuppressIn, p: Principal = Depends(require("customer.read")),
                    db: Session = Depends(get_db)) -> dict:
    """Any agent may add to the internal do-not-call list (it only reduces contact); other lists need compliance."""
    sl = db.scalar(select(SuppressionList).where(SuppressionList.org_id == p.org_id,
                                                 SuppressionList.code == body.list_code))
    if sl is None:
        raise NotFound("List not found")
    if sl.code != "internal_dnc":
        p.require("suppression.manage")
    norm = customers.normalise_phone(body.number)
    if not norm:
        raise ValidationFailed("Invalid number")
    exists = db.scalar(select(SuppressionEntry).where(SuppressionEntry.list_id == sl.id,
                                                      SuppressionEntry.normalized_number == norm))
    if exists is None:
        db.add(SuppressionEntry(org_id=p.org_id, list_id=sl.id, normalized_number=norm, reason=body.reason,
                                added_at=utcnow()))
    audit.by_principal(db, p, "suppression.added", "suppression_list", sl.id, number=norm, reason=body.reason)
    db.commit()
    return {"list": sl.code, "number": customers.mask_phone(norm)}


@router.get("/v1/audit")
def audit_log(target_type: str | None = None, target_id: str | None = None, action: str | None = None,
              limit: int = 100, p: Principal = Depends(require("ops.read")), db: Session = Depends(get_db)) -> list[dict]:
    q = select(AuditLog).where(AuditLog.org_id == p.org_id)
    if target_type:
        q = q.where(AuditLog.target_type == target_type)
    if target_id:
        q = q.where(AuditLog.target_id == target_id)
    if action:
        q = q.where(AuditLog.action.like(f"{action}%"))
    full = p.has("audit.read") and p.mfa
    rows = db.scalars(q.order_by(AuditLog.seq.desc()).limit(min(limit, 500))).all()
    users = {u.id: u.display_name for u in db.scalars(select(User).where(User.org_id == p.org_id))}
    out = []
    for r in rows:
        if not full and r.action.startswith(SECURITY_ACTIONS_PREFIX) and r.action not in ("recording.access_attempt",):
            continue
        out.append({"seq": r.seq, "at": r.at, "actor": users.get(r.actor_user_id, r.actor_type),
                    "actor_type": r.actor_type, "action": r.action, "target_type": r.target_type,
                    "target_id": r.target_id, "details": r.details, "request_id": r.request_id, "hash": r.hash[:16]})
    return out


@router.get("/v1/audit/verify")
def audit_verify(p: Principal = Depends(require("ops.read")), db: Session = Depends(get_db)) -> dict:
    return audit.verify_chain(db)
