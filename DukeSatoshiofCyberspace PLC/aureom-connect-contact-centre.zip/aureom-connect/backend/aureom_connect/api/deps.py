"""Shared API helpers: idempotency keys, version checks, JSON encoding."""
from __future__ import annotations

import hashlib
import json
from collections.abc import Callable
from typing import Any

from fastapi import Request
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..db import session_factory, utcnow
from ..errors import AppError, Conflict, ValidationFailed, VersionConflict
from ..models import IdempotencyRecord
from ..security.auth import Principal


def check_version(entity: Any, expected: int | None, name: str = "resource") -> None:
    if expected is not None and entity.version != expected:
        raise VersionConflict(f"{name} was modified by someone else", details={
            "expected_version": expected, "current_version": entity.version})


def _request_hash(method: str, path: str, body: Any) -> str:
    return hashlib.sha256(json.dumps([method, path, jsonable_encoder(body)], sort_keys=True).encode()).hexdigest()


def idempotent(request: Request, db: Session, p: Principal, body: Any, handler: Callable[[], tuple[int, Any]],
               *, required: bool = True) -> JSONResponse:
    """Run ``handler`` at most once per (org, user, Idempotency-Key).

    * Same key + same request → the stored response is replayed.
    * Same key + different request → 422 IDEMPOTENCY_KEY_REUSED.
    * Same key while the first request is still running → 409 IDEMPOTENCY_IN_PROGRESS.
    * Handler raised an error → the claim is released so the client may retry.
    """
    key = request.headers.get("Idempotency-Key")
    if not key:
        if required:
            raise ValidationFailed("Idempotency-Key header is required for this operation",
                                   code="IDEMPOTENCY_KEY_REQUIRED")
        status, payload = handler()
        db.commit()
        return JSONResponse(status_code=status, content=jsonable_encoder(payload))
    if len(key) > 128:
        raise ValidationFailed("Idempotency-Key too long")
    rhash = _request_hash(request.method, request.url.path, body)

    # Claim the key in an independent, immediately committed transaction.
    claim_db = session_factory()()
    try:
        existing = claim_db.scalar(select(IdempotencyRecord).where(
            IdempotencyRecord.org_id == p.org_id, IdempotencyRecord.user_id == p.user_id,
            IdempotencyRecord.key == key))
        if existing is None:
            rec = IdempotencyRecord(org_id=p.org_id, user_id=p.user_id, key=key, method=request.method,
                                    path=request.url.path, request_hash=rhash, response_body={})
            claim_db.add(rec)
            try:
                claim_db.commit()
            except IntegrityError:
                claim_db.rollback()
                raise Conflict("A request with this Idempotency-Key is in progress", code="IDEMPOTENCY_IN_PROGRESS")
            rec_id = rec.id
        else:
            if existing.request_hash != rhash:
                raise ValidationFailed("Idempotency-Key was already used for a different request",
                                       code="IDEMPOTENCY_KEY_REUSED")
            if existing.completed_at is None:
                raise Conflict("A request with this Idempotency-Key is in progress", code="IDEMPOTENCY_IN_PROGRESS")
            resp = JSONResponse(status_code=existing.status_code or 200, content=existing.response_body.get("body"))
            resp.headers["Idempotent-Replayed"] = "true"
            return resp
    finally:
        claim_db.close()

    try:
        status, payload = handler()
        encoded = jsonable_encoder(payload)
        rec = db.get(IdempotencyRecord, rec_id)
        rec.status_code = status
        rec.response_body = {"body": encoded}
        rec.completed_at = utcnow()
        db.commit()
        return JSONResponse(status_code=status, content=encoded)
    except Exception:
        db.rollback()
        release = session_factory()()
        try:
            rec = release.get(IdempotencyRecord, rec_id)
            if rec is not None:
                release.delete(rec)
                release.commit()
        finally:
            release.close()
        raise


def error_body(exc: AppError, request_id: str | None) -> dict[str, Any]:
    return {"error": {"code": exc.code, "message": exc.message, "details": jsonable_encoder(exc.details),
                      "request_id": request_id}}
