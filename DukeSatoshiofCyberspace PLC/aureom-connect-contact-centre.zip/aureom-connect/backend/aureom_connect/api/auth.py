"""/v1/auth – local sign-in (password + TOTP) and OIDC organisational sign-in."""
from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import get_db
from ..errors import Unauthorized, ValidationFailed
from ..models import Agent, Organisation, User
from ..security import auth
from ..security.auth import Principal, current_principal
from ..security.permissions import permissions_for
from ..security.ratelimit import limiter
from ..services import audit

router = APIRouter(prefix="/v1/auth", tags=["auth"])


class LoginIn(BaseModel):
    organisation: str = Field(examples=["pennine"])
    email: str
    password: str
    totp_code: str | None = None


class RefreshIn(BaseModel):
    refresh_token: str


def _token_response(db: Session, user: User, mfa: bool) -> dict:
    agent = db.scalar(select(Agent).where(Agent.user_id == user.id))
    refresh = auth.issue_refresh_token(db, user, mfa=mfa)
    return {"access_token": auth.issue_access_token(user, agent, mfa=mfa), "token_type": "bearer",
            "expires_in": get_settings().access_token_minutes * 60, "refresh_token": refresh,
            "user": {"id": user.id, "email": user.email, "display_name": user.display_name, "roles": user.roles,
                     "agent_id": agent.id if agent else None, "mfa": mfa,
                     "permissions": sorted(permissions_for(user.roles))}}


@router.post("/login")
def login(body: LoginIn, request: Request, db: Session = Depends(get_db)) -> dict:
    ip = request.client.host if request.client else "unknown"
    limiter.check(f"login:{ip}", get_settings().login_rate_limit_per_minute)
    try:
        user, mfa = auth.password_login(db, body.organisation, body.email, body.password, body.totp_code)
    except Unauthorized as exc:
        org = db.scalar(select(Organisation).where(Organisation.slug == body.organisation))
        audit.record(db, action="auth.login_failed", org_id=org.id if org else None, actor_type="anonymous",
                     details={"email": body.email, "reason": exc.code}, ip=ip)
        db.commit()
        raise
    audit.record(db, action="auth.login", org_id=user.org_id, actor_user_id=user.id, details={"mfa": mfa,
                                                                                              "method": "password"}, ip=ip)
    out = _token_response(db, user, mfa)
    db.commit()
    return out


@router.post("/refresh")
def refresh(body: RefreshIn, db: Session = Depends(get_db)) -> dict:
    user, mfa, new_raw = auth.rotate_refresh_token(db, body.refresh_token)
    agent = db.scalar(select(Agent).where(Agent.user_id == user.id))
    out = {"access_token": auth.issue_access_token(user, agent, mfa=mfa), "token_type": "bearer",
           "expires_in": get_settings().access_token_minutes * 60, "refresh_token": new_raw}
    db.commit()
    return out


@router.post("/logout")
def logout(body: RefreshIn, p: Principal = Depends(current_principal), db: Session = Depends(get_db)) -> dict:
    from ..db import utcnow
    from ..models import RefreshToken
    from ..security.crypto import token_hash

    rt = db.scalar(select(RefreshToken).where(RefreshToken.token_hash == token_hash(body.refresh_token)))
    if rt and rt.user_id == p.user_id:
        rt.revoked_at = utcnow()
    audit.by_principal(db, p, "auth.logout")
    db.commit()
    return {"ok": True}


@router.get("/me")
def me(p: Principal = Depends(current_principal)) -> dict:
    return {"user_id": p.user_id, "org_id": p.org_id, "email": p.email, "display_name": p.display_name,
            "roles": p.roles, "permissions": sorted(p.permissions), "agent_id": p.agent_id, "mfa": p.mfa}


@router.get("/oidc/config")
def oidc_config() -> dict:
    s = get_settings()
    return {"enabled": bool(s.oidc_issuer and s.oidc_client_id), "issuer": s.oidc_issuer,
            "mfa_evidence": "ID token 'amr' claim must include one of " + ", ".join(s.oidc_mfa_amr_values),
            "status": "externally integrated – requires an identity provider; not exercised in the demo"}


@router.get("/oidc/start")
def oidc_start() -> dict:
    """Begin authorization-code + PKCE. The browser is redirected to the IdP's authorization endpoint."""
    import httpx

    s = get_settings()
    if not (s.oidc_issuer and s.oidc_client_id and s.oidc_redirect_uri):
        raise ValidationFailed("OIDC is not configured", code="OIDC_NOT_CONFIGURED")
    meta = httpx.get(f"{s.oidc_issuer.rstrip('/')}/.well-known/openid-configuration", timeout=5).json()
    from ..security.crypto import random_token

    verifier, challenge = auth.pkce_pair()
    state, nonce = random_token(16), random_token(16)
    from urllib.parse import urlencode

    url = meta["authorization_endpoint"] + "?" + urlencode({
        "response_type": "code", "client_id": s.oidc_client_id, "redirect_uri": s.oidc_redirect_uri,
        "scope": "openid email profile", "state": state, "nonce": nonce, "code_challenge": challenge,
        "code_challenge_method": "S256"})
    # The caller (web BFF) must keep state, nonce and verifier in a secure, httpOnly, same-site cookie.
    return {"authorization_url": url, "state": state, "nonce": nonce, "code_verifier": verifier}


class OidcCallback(BaseModel):
    organisation: str
    code: str
    code_verifier: str
    nonce: str


@router.post("/oidc/callback")
def oidc_callback(body: OidcCallback, db: Session = Depends(get_db)) -> dict:
    import httpx
    import jwt as pyjwt

    s = get_settings()
    if not (s.oidc_issuer and s.oidc_client_id):
        raise ValidationFailed("OIDC is not configured", code="OIDC_NOT_CONFIGURED")
    meta = httpx.get(f"{s.oidc_issuer.rstrip('/')}/.well-known/openid-configuration", timeout=5).json()
    tok = httpx.post(meta["token_endpoint"], data={
        "grant_type": "authorization_code", "code": body.code, "redirect_uri": s.oidc_redirect_uri,
        "client_id": s.oidc_client_id, "client_secret": s.oidc_client_secret or "",
        "code_verifier": body.code_verifier}, timeout=10).json()
    key = pyjwt.PyJWKClient(meta["jwks_uri"]).get_signing_key_from_jwt(tok["id_token"]).key
    claims, mfa = auth.validate_id_token(tok["id_token"], signing_key=key, issuer=s.oidc_issuer,
                                         audience=s.oidc_client_id, nonce=body.nonce,
                                         mfa_amr_values=s.oidc_mfa_amr_values)
    org = db.scalar(select(Organisation).where(Organisation.slug == body.organisation))
    user = db.scalar(select(User).where(User.org_id == org.id, User.email == str(claims.get("email", "")).lower())) \
        if org else None
    if user is None or not user.active:
        raise Unauthorized("No active user for this identity in the organisation")
    if user.oidc_subject and user.oidc_subject != claims["sub"]:
        raise Unauthorized("Identity subject mismatch")
    user.oidc_subject = claims["sub"]
    if auth.mfa_required_for(org, user) and not mfa:
        raise Unauthorized("Identity provider did not evidence MFA", code="MFA_REQUIRED")
    audit.record(db, action="auth.login", org_id=org.id, actor_user_id=user.id, details={"mfa": mfa, "method": "oidc"})
    out = _token_response(db, user, mfa)
    db.commit()
    return out
