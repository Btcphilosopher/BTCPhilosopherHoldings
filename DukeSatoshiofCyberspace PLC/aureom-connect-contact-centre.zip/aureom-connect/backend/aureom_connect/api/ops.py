"""/v1/queues and /v1/ops – supervisor live operations."""
from __future__ import annotations

from datetime import timedelta

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import get_db, utcnow
from ..models import (Agent, AgentParticipation, Callback, Case, Interaction, MonitoringSession, Offer, QaReview,
                      Queue, RoutingDecision, SlaPolicy, Task)
from ..security.auth import Principal, current_principal, require
from ..services import calls, routing
from .views import agent_view, interaction_summary

router = APIRouter(tags=["operations"])


@router.get("/v1/queues")
def list_queues(p: Principal = Depends(current_principal), db: Session = Depends(get_db)) -> list[dict]:
    p.require("workspace.read") if not p.has("queue.read") else None
    snap = {q["id"]: q for q in routing.queue_snapshot(db, p.org_id)}
    out = []
    for q in db.scalars(select(Queue).where(Queue.org_id == p.org_id).order_by(Queue.routing_priority.desc())):
        sla = db.get(SlaPolicy, q.sla_policy_id) if q.sla_policy_id else None
        out.append({**snap.get(q.id, {}), "id": q.id, "code": q.code, "name": q.name, "channel": q.channel,
                    "required_skills": q.required_skills, "required_language": q.required_language,
                    "overflow_queue_id": q.overflow_queue_id, "overflow_after_seconds": q.overflow_after_seconds,
                    "voicemail_enabled": q.voicemail_enabled, "callback_enabled": q.callback_enabled,
                    "offer_timeout_seconds": q.offer_timeout_seconds,
                    "sla": {"name": sla.name, "target_seconds": sla.target_seconds, "target_percent": sla.target_percent,
                            "kind": sla.kind, "contract_ref": sla.contract_ref} if sla else None})
    return out


@router.get("/v1/ops/live")
def live(p: Principal = Depends(require("ops.read")), db: Session = Depends(get_db)) -> dict:
    now = utcnow()
    waiting = db.scalars(select(Interaction).where(Interaction.org_id == p.org_id,
                                                   Interaction.status.in_(["queued", "offered"]))
                         .order_by(Interaction.routable_since)).all()
    agents = db.scalars(select(Agent).where(Agent.org_id == p.org_id).order_by(Agent.display_name)).all()
    since = now - timedelta(hours=1)
    failures = db.scalars(select(RoutingDecision).where(RoutingDecision.org_id == p.org_id,
                                                        RoutingDecision.outcome != "offered",
                                                        RoutingDecision.decided_at > since)
                          .order_by(RoutingDecision.decided_at.desc()).limit(20)).all()
    missed = db.scalar(select(func.count()).select_from(Offer).where(Offer.org_id == p.org_id,
                                                                     Offer.status == "expired",
                                                                     Offer.responded_at > since))
    cb_rows = db.execute(select(Callback.status, func.count()).where(Callback.org_id == p.org_id)
                         .group_by(Callback.status)).all()
    overdue_cb = db.scalar(select(func.count()).select_from(Callback).where(
        Callback.org_id == p.org_id, Callback.status.in_(["pending", "ready"]), Callback.window_end < now + timedelta(minutes=30)))
    case_rows = db.execute(select(Case.status, func.count()).where(Case.org_id == p.org_id).group_by(Case.status)).all()
    case_breach = db.scalar(select(func.count()).select_from(Case).where(
        Case.org_id == p.org_id, Case.status.notin_(["resolved", "closed"]), Case.due_at < now))
    task_open = db.scalar(select(func.count()).select_from(Task).where(Task.org_id == p.org_id,
                                                                       Task.status.in_(["open", "in_progress"])))
    task_overdue = db.scalar(select(func.count()).select_from(Task).where(
        Task.org_id == p.org_id, Task.status.in_(["open", "in_progress"]), Task.due_at < now))
    acw_overdue = []
    for part, a in db.execute(select(AgentParticipation, Agent).join(Agent, Agent.id == AgentParticipation.agent_id).where(
            AgentParticipation.org_id == p.org_id, AgentParticipation.wrap_started_at.is_not(None),
            AgentParticipation.wrap_ended_at.is_(None))):
        secs = (now - part.wrap_started_at).total_seconds()
        if secs > 120:
            acw_overdue.append({"agent": a.display_name, "interaction_id": part.interaction_id, "seconds": round(secs)})
    qa = db.scalar(select(func.count()).select_from(QaReview).where(QaReview.org_id == p.org_id,
                                                                    QaReview.status.in_(["queued", "in_progress"])))
    monitors = db.scalars(select(MonitoringSession).where(MonitoringSession.org_id == p.org_id,
                                                          MonitoringSession.status == "active")).all()
    state_counts: dict[str, int] = {}
    for a in agents:
        state_counts[a.state] = state_counts.get(a.state, 0) + 1
    return {
        "generated_at": now,
        "provider": {"status": calls.provider_status(db, p.org_id)},
        "queues": routing.queue_snapshot(db, p.org_id),
        "waiting": [{**interaction_summary(db, it), "wait_seconds": round((now - it.routable_since).total_seconds())
                     if it.routable_since else None} for it in waiting],
        "agents": [agent_view(db, a, detail=True) for a in agents],
        "agent_state_counts": state_counts,
        "routing_failures": [{"interaction_id": f.interaction_id, "decided_at": f.decided_at, "outcome": f.outcome,
                              "explanation": f.explanation,
                              "excluded": [c for c in f.candidates if not c.get("eligible")][:6]} for f in failures],
        "missed_offers_last_hour": missed,
        "callback_backlog": {"by_status": dict(cb_rows), "due_within_30_min": overdue_cb},
        "case_workload": {"by_status": dict(case_rows), "past_due": case_breach, "tasks_open": task_open,
                          "tasks_overdue": task_overdue},
        "after_call_work_overdue": acw_overdue,
        "quality_queue": qa,
        "active_monitoring": [{"id": m.id, "interaction_id": m.interaction_id, "mode": m.mode, "agent_id": m.agent_id,
                               "started_at": m.started_at, "agent_notified": m.agent_notified} for m in monitors],
    }


@router.get("/v1/ops/routing-decisions/{interaction_id}")
def routing_decisions(interaction_id: str, p: Principal = Depends(require("ops.read")),
                      db: Session = Depends(get_db)) -> list[dict]:
    import uuid

    rows = db.scalars(select(RoutingDecision).where(RoutingDecision.org_id == p.org_id,
                                                    RoutingDecision.interaction_id == uuid.UUID(interaction_id))
                      .order_by(RoutingDecision.decided_at)).all()
    return [{"decided_at": r.decided_at, "outcome": r.outcome, "selected_agent_id": r.selected_agent_id,
             "explanation": r.explanation, "candidates": r.candidates} for r in rows]
