"""/v1/quality (rubrics, reviews) and /v1/monitoring (permissioned, agent-visible)."""
from __future__ import annotations

import uuid
from typing import Any

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..errors import NotFound
from ..models import Interaction, MonitoringSession, QaReview
from ..security.auth import Principal, current_principal, require
from ..services import audit, quality

router = APIRouter(tags=["quality & monitoring"])


@router.get("/v1/quality/rubric")
def rubric(p: Principal = Depends(current_principal), db: Session = Depends(get_db)) -> dict:
    r = quality.active_rubric(db, p.org_id)
    return {"id": r.id, "name": r.name, "version": r.version, "criteria": r.criteria, "documentation": r.documentation}


@router.get("/v1/quality/reviews")
def reviews(status: str | None = None, mine: bool = False, p: Principal = Depends(current_principal),
            db: Session = Depends(get_db)) -> list[dict]:
    q = select(QaReview).where(QaReview.org_id == p.org_id)
    if mine or not p.has("qa.review"):
        p.require("qa.read_own")
        q = q.where(QaReview.agent_id == p.agent_id, QaReview.status.notin_(["queued", "in_progress"]))
    if status:
        q = q.where(QaReview.status.in_(status.split(",")))
    return [quality.review_view(db, r) for r in db.scalars(q.order_by(QaReview.created_at.desc()).limit(200))]


@router.post("/v1/quality/sample")
def run_sample(p: Principal = Depends(require("qa.review")), db: Session = Depends(get_db)) -> dict:
    n = quality.sample(db, p.org_id)
    audit.by_principal(db, p, "qa.sampled", "qa", None, queued=n)
    db.commit()
    return {"queued": n, "method": "All complaint/escalation outcomes plus a 15% random sample of completed voice "
                                   "interactions in the last 7 days (seeded by date for reproducibility)."}


def _rev(db: Session, p: Principal, rid: uuid.UUID) -> QaReview:
    r = db.get(QaReview, rid)
    if r is None or r.org_id != p.org_id:
        raise NotFound("Review not found")
    return r


class SubmitIn(BaseModel):
    scores: dict[str, dict[str, Any]] = Field(description="criterion id -> {score, evidence}")
    comments: str = ""


@router.post("/v1/quality/reviews/{review_id}/submit")
def submit(review_id: uuid.UUID, body: SubmitIn, p: Principal = Depends(require("qa.review")),
           db: Session = Depends(get_db)) -> dict:
    r = quality.submit(db, p, _rev(db, p, review_id), body.scores, body.comments)
    audit.by_principal(db, p, "qa.review_submitted", "qa_review", r.id, total=r.total_percent, status=r.status)
    db.commit()
    return quality.review_view(db, r)


class RespondIn(BaseModel):
    action: str = Field(pattern="^(acknowledge|dispute)$")
    note: str | None = None


@router.post("/v1/quality/reviews/{review_id}/respond")
def respond(review_id: uuid.UUID, body: RespondIn, p: Principal = Depends(require("qa.read_own")),
            db: Session = Depends(get_db)) -> dict:
    r = quality.agent_response(db, p, _rev(db, p, review_id), body.action, body.note)
    audit.by_principal(db, p, f"qa.review_{body.action}", "qa_review", r.id)
    db.commit()
    return quality.review_view(db, r)


class MonitorIn(BaseModel):
    interaction_id: uuid.UUID
    mode: str = Field(pattern="^(listen|coach|barge)$")
    reason: str = Field(min_length=5)


@router.post("/v1/monitoring", status_code=201)
def start_monitor(body: MonitorIn, p: Principal = Depends(require("ops.read")), db: Session = Depends(get_db)) -> dict:
    it = db.get(Interaction, body.interaction_id)
    if it is None or it.org_id != p.org_id:
        raise NotFound("Interaction not found")
    ms = quality.start_monitoring(db, p, it, body.mode, body.reason)
    db.commit()
    return {"id": ms.id, "status": ms.status, "mode": ms.mode, "agent_notified": ms.agent_notified,
            "note": "The agent sees that you are monitoring. Simulated provider: no audio is carried."}


@router.post("/v1/monitoring/{session_id}/stop")
def stop_monitor(session_id: uuid.UUID, p: Principal = Depends(require("ops.read")),
                 db: Session = Depends(get_db)) -> dict:
    ms = db.get(MonitoringSession, session_id)
    if ms is None or ms.org_id != p.org_id:
        raise NotFound("Monitoring session not found")
    quality.stop_monitoring(db, p, ms)
    db.commit()
    return {"id": ms.id, "status": ms.status}
