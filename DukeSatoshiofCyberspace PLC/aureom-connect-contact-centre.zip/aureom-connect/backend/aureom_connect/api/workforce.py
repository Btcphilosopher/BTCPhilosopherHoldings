"""/v1/workforce – schedules, shifts, change requests, leave, forecasts and staffing gaps."""
from __future__ import annotations

import uuid
from datetime import date, datetime, timedelta

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db, utcnow
from ..errors import NotFound
from ..models import Agent, Forecast, LeaveRequest, Queue, Schedule, Shift, ShiftChangeRequest
from ..security.auth import Principal, require, require_agent
from ..services import audit, workforce

router = APIRouter(prefix="/v1/workforce", tags=["workforce"])


@router.get("/my-schedule")
def my_schedule(p: Principal = Depends(require_agent), db: Session = Depends(get_db)) -> dict:
    p.require("schedule.read_own")
    now = utcnow()
    rows = db.execute(select(Shift, Schedule).join(Schedule, Schedule.id == Shift.schedule_id).where(
        Shift.agent_id == p.agent_id, Schedule.status == "published", Shift.end_at > now - timedelta(days=1),
        Shift.start_at < now + timedelta(days=14)).order_by(Shift.start_at)).all()
    reqs = db.scalars(select(ShiftChangeRequest).where(ShiftChangeRequest.requested_by_agent_id == p.agent_id)
                      .order_by(ShiftChangeRequest.created_at.desc())).all()
    leave = db.scalars(select(LeaveRequest).where(LeaveRequest.agent_id == p.agent_id)).all()
    return {"shifts": [{**workforce.shift_view(sh), "schedule": sc.name} for sh, sc in rows],
            "change_requests": [{"id": r.id, "shift_id": r.shift_id, "kind": r.kind, "status": r.status,
                                 "reason": r.reason, "proposed_start_at": r.proposed_start_at,
                                 "proposed_end_at": r.proposed_end_at, "decision_note": r.decision_note} for r in reqs],
            "leave": [{"id": lv.id, "kind": lv.kind, "status": lv.status, "start_at": lv.start_at, "end_at": lv.end_at}
                      for lv in leave]}


@router.get("/schedules")
def schedules(p: Principal = Depends(require("schedule.read")), db: Session = Depends(get_db)) -> list[dict]:
    out = []
    for sc in db.scalars(select(Schedule).where(Schedule.org_id == p.org_id).order_by(Schedule.period_start)):
        out.append({"id": sc.id, "name": sc.name, "status": sc.status, "period_start": sc.period_start,
                    "period_end": sc.period_end, "published_at": sc.published_at, "version": sc.version})
    return out


@router.get("/schedules/{schedule_id}")
def schedule(schedule_id: uuid.UUID, p: Principal = Depends(require("schedule.read")),
             db: Session = Depends(get_db)) -> dict:
    sc = db.get(Schedule, schedule_id)
    if sc is None or sc.org_id != p.org_id:
        raise NotFound("Schedule not found")
    agents = {a.id: a for a in db.scalars(select(Agent).where(Agent.org_id == p.org_id))}
    shifts = db.scalars(select(Shift).where(Shift.schedule_id == sc.id).order_by(Shift.start_at)).all()
    return {"id": sc.id, "name": sc.name, "status": sc.status, "period_start": sc.period_start,
            "period_end": sc.period_end, "shifts": [workforce.shift_view(s, agents.get(s.agent_id)) for s in shifts],
            "conflicts": workforce.conflicts(db, sc)}


@router.post("/schedules/{schedule_id}/publish")
def publish(schedule_id: uuid.UUID, p: Principal = Depends(require("schedule.manage")), db: Session = Depends(get_db)) -> dict:
    sc = db.get(Schedule, schedule_id)
    if sc is None or sc.org_id != p.org_id:
        raise NotFound("Schedule not found")
    res = workforce.publish(db, p, sc)
    audit.by_principal(db, p, "schedule.published", "schedule", sc.id, warnings=len(res["warnings"]))
    db.commit()
    return res


class ShiftEdit(BaseModel):
    start_at: datetime
    end_at: datetime
    expected_version: int


@router.patch("/shifts/{shift_id}")
def edit_shift(shift_id: uuid.UUID, body: ShiftEdit, p: Principal = Depends(require("schedule.manage")),
               db: Session = Depends(get_db)) -> dict:
    sh = db.get(Shift, shift_id)
    if sh is None or sh.org_id != p.org_id:
        raise NotFound("Shift not found")
    workforce.edit_shift(db, p, sh, body.start_at, body.end_at, body.expected_version)
    audit.by_principal(db, p, "schedule.draft_shift_edited", "shift", sh.id)
    db.commit()
    return workforce.shift_view(sh)


class ChangeIn(BaseModel):
    shift_id: uuid.UUID
    kind: str = Field(pattern="^(change|drop|swap)$")
    proposed_start_at: datetime | None = None
    proposed_end_at: datetime | None = None
    reason: str = Field(min_length=3)


@router.post("/shift-change-requests", status_code=201)
def request_change(body: ChangeIn, p: Principal = Depends(require_agent), db: Session = Depends(get_db)) -> dict:
    p.require("schedule.request_change")
    sh = db.get(Shift, body.shift_id)
    if sh is None or sh.org_id != p.org_id:
        raise NotFound("Shift not found")
    r = workforce.request_change(db, p, sh, body.kind, body.proposed_start_at, body.proposed_end_at, body.reason)
    db.flush()
    audit.by_principal(db, p, "schedule.change_requested", "shift", sh.id, kind=body.kind)
    db.commit()
    return {"id": r.id, "status": r.status}


@router.get("/shift-change-requests")
def change_requests(p: Principal = Depends(require("schedule.read")), db: Session = Depends(get_db)) -> list[dict]:
    agents = {a.id: a.display_name for a in db.scalars(select(Agent).where(Agent.org_id == p.org_id))}
    return [{"id": r.id, "shift_id": r.shift_id, "agent": agents.get(r.requested_by_agent_id), "kind": r.kind,
             "status": r.status, "reason": r.reason, "proposed_start_at": r.proposed_start_at,
             "proposed_end_at": r.proposed_end_at, "decision_note": r.decision_note, "created_at": r.created_at}
            for r in db.scalars(select(ShiftChangeRequest).where(ShiftChangeRequest.org_id == p.org_id)
                                .order_by(ShiftChangeRequest.created_at.desc()))]


class DecideIn(BaseModel):
    approve: bool
    note: str = ""


@router.post("/shift-change-requests/{request_id}/decide")
def decide(request_id: uuid.UUID, body: DecideIn, p: Principal = Depends(require("schedule.manage")),
           db: Session = Depends(get_db)) -> dict:
    r = db.get(ShiftChangeRequest, request_id)
    if r is None or r.org_id != p.org_id:
        raise NotFound("Request not found")
    workforce.decide_change(db, p, r, body.approve, body.note)
    audit.by_principal(db, p, "schedule.change_decided", "shift_change_request", r.id, status=r.status)
    db.commit()
    return {"id": r.id, "status": r.status}


class ForecastIn(BaseModel):
    queue: str
    target_date: date
    weeks: int = Field(6, ge=2, le=12)
    shrinkage: float = Field(0.3, ge=0, le=0.6)


@router.post("/forecasts", status_code=201)
def forecast(body: ForecastIn, p: Principal = Depends(require("forecast.read")), db: Session = Depends(get_db)) -> dict:
    q = db.scalar(select(Queue).where(Queue.org_id == p.org_id, Queue.code == body.queue))
    if q is None:
        raise NotFound("Queue not found")
    fc = workforce.generate_forecast(db, p.org_id, q, body.target_date, weeks=body.weeks, shrinkage=body.shrinkage,
                                     by=p.user_id)
    rows = workforce.staffing(db, p.org_id, q, body.target_date, fc)
    db.commit()
    return {"forecast_id": fc.id, "method": fc.method, "parameters": fc.parameters, "notes": fc.notes,
            "intervals": fc.intervals, "staffing": rows,
            "gaps": [r for r in rows if r["status"] == "short"],
            "policy": "Gaps are shown for planning. Published shifts are never changed automatically."}


@router.get("/staffing")
def staffing(queue: str, day: date, p: Principal = Depends(require("schedule.read")), db: Session = Depends(get_db)) -> dict:
    q = db.scalar(select(Queue).where(Queue.org_id == p.org_id, Queue.code == queue))
    if q is None:
        raise NotFound("Queue not found")
    fc = db.scalar(select(Forecast).where(Forecast.queue_id == q.id, Forecast.target_date == day)
                   .order_by(Forecast.generated_at.desc()))
    return {"queue": q.code, "day": day, "forecast_id": fc.id if fc else None,
            "rows": workforce.staffing(db, p.org_id, q, day, fc)}
