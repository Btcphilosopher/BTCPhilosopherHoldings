"""/v1/outbound-calls (click-to-call, callbacks, preview) and /v1/campaigns."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, File, Request, UploadFile
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..errors import NotFound, ValidationFailed
from ..models import Agent, Campaign, CampaignContact, CampaignImport, CallingRuleSet, Interaction, Organisation, \
    OutboundAttempt, PhoneNumber, Queue
from ..security.auth import Principal, require, require_agent
from ..services import audit, outbound
from .deps import idempotent

router = APIRouter(tags=["outbound"])


class OutboundIn(BaseModel):
    number: str | None = None
    purpose: str = Field("service", pattern="^(service|marketing)$")
    customer_id: uuid.UUID | None = None
    campaign_contact_id: uuid.UUID | None = None
    callback_id: uuid.UUID | None = None
    interaction_id: uuid.UUID | None = Field(None, description="Owned callback/preview work item to dial from")
    caller_id_number_id: uuid.UUID | None = None


def attempt_view(a: OutboundAttempt) -> dict:
    return {"id": a.id, "status": a.status, "interaction_id": a.interaction_id, "number": a.normalized_number,
            "purpose": a.purpose, "eligibility": a.eligibility, "rule_set_version": a.rule_set_version,
            "created_at": a.created_at, "note": a.note}


@router.post("/v1/outbound-calls", status_code=202)
def place_call(body: OutboundIn, request: Request, p: Principal = Depends(require_agent),
               db: Session = Depends(get_db)):
    p.require("outbound.dial")
    key = request.headers.get("Idempotency-Key")
    if not key:
        raise ValidationFailed("Idempotency-Key header is required to dial", code="IDEMPOTENCY_KEY_REQUIRED")

    def run():
        agent = db.get(Agent, p.agent_id, with_for_update=True)
        att = outbound.place_call(db, agent, number=body.number, purpose=body.purpose, customer_id=body.customer_id,
                                  campaign_contact_id=body.campaign_contact_id, callback_id=body.callback_id,
                                  interaction_id=body.interaction_id, caller_id_number_id=body.caller_id_number_id,
                                  idempotency_key=key, actor_user_id=p.user_id)
        audit.by_principal(db, p, "outbound.dial", "outbound_attempt", att.id, status=att.status,
                           purpose=att.purpose, rule_set_version=att.rule_set_version)
        return 202, {**attempt_view(att), "note": "Dialling requested. Connection is confirmed only by provider events."}

    return idempotent(request, db, p, body.model_dump(mode="json"), run)


@router.post("/v1/outbound-calls/eligibility")
def eligibility(body: OutboundIn, p: Principal = Depends(require("outbound.dial")), db: Session = Depends(get_db)) -> dict:
    contact = db.get(CampaignContact, body.campaign_contact_id) if body.campaign_contact_id else None
    from ..services import callbacks as cbs

    cb = cbs.get(db, p.org_id, body.callback_id) if body.callback_id else None
    number = body.number or (contact.normalized_number if contact else None) or (cb.phone_number if cb else None)
    if not number:
        raise ValidationFailed("number, campaign_contact_id or callback_id is required")
    caller = db.get(PhoneNumber, body.caller_id_number_id) if body.caller_id_number_id else \
        outbound.default_caller_id(db, p.org_id)
    return outbound.check_eligibility(db, p.org_id, number=number, purpose=body.purpose,
                                      customer_id=body.customer_id or (contact.customer_id if contact else None),
                                      campaign_contact=contact, callback=cb, caller_id=caller,
                                      recipient_timezone=contact.timezone if contact else None, agent_id=p.agent_id,
                                      exclude_interaction_id=body.interaction_id)


@router.get("/v1/outbound-calls")
def attempts(limit: int = 50, p: Principal = Depends(require("ops.read")), db: Session = Depends(get_db)) -> list[dict]:
    return [attempt_view(a) for a in db.scalars(select(OutboundAttempt).where(OutboundAttempt.org_id == p.org_id)
                                                .order_by(OutboundAttempt.created_at.desc()).limit(limit))]


@router.get("/v1/calling-rules")
def rule_sets(p: Principal = Depends(require("campaign.read")), db: Session = Depends(get_db)) -> list[dict]:
    return [{"id": r.id, "jurisdiction": r.jurisdiction, "version": r.version, "status": r.status,
             "effective_from": r.effective_from, "effective_to": r.effective_to, "rules": r.rules,
             "source_notes": r.source_notes}
            for r in db.scalars(select(CallingRuleSet).where(CallingRuleSet.org_id == p.org_id)
                                .order_by(CallingRuleSet.jurisdiction, CallingRuleSet.version.desc()))]


# --------------------------------------------------------------------------- campaigns

def campaign_view(db: Session, c: Campaign) -> dict:
    q = db.get(Queue, c.queue_id)
    caller = db.get(PhoneNumber, c.caller_id_number_id)
    imports = db.scalars(select(CampaignImport).where(CampaignImport.campaign_id == c.id)
                         .order_by(CampaignImport.created_at.desc())).all()
    return {"id": c.id, "name": c.name, "purpose": c.purpose, "dial_mode": c.dial_mode, "status": c.status,
            "queue": q.code, "jurisdiction": c.jurisdiction, "caller_id": caller.e164 if caller else None,
            "max_attempts_per_contact": c.max_attempts_per_contact, "description": c.description,
            "created_by": c.created_by, "approved_by": c.approved_by, "activated_at": c.activated_at,
            "review_summary": c.review_summary, "version": c.version,
            "imports": [{"id": i.id, "filename": i.filename, "status": i.status, "total_rows": i.total_rows,
                         "valid_rows": i.valid_rows, "invalid_rows": i.invalid_rows, "errors": i.errors[:50],
                         "processed_at": i.processed_at} for i in imports]}


def _campaign(db: Session, p: Principal, cid: uuid.UUID) -> Campaign:
    c = db.get(Campaign, cid)
    if c is None or c.org_id != p.org_id:
        raise NotFound("Campaign not found")
    return c


@router.get("/v1/campaigns")
def list_campaigns(p: Principal = Depends(require("workspace.read")), db: Session = Depends(get_db)) -> list[dict]:
    return [campaign_view(db, c) for c in db.scalars(select(Campaign).where(Campaign.org_id == p.org_id)
                                                     .order_by(Campaign.created_at))]


class CampaignIn(BaseModel):
    name: str = Field(min_length=3)
    purpose: str = Field(pattern="^(service|marketing)$")
    queue: str
    caller_id_number_id: uuid.UUID
    jurisdiction: str = "GB"
    max_attempts_per_contact: int = Field(3, ge=1, le=5)
    description: str = ""


@router.post("/v1/campaigns", status_code=201)
def create_campaign(body: CampaignIn, p: Principal = Depends(require("campaign.manage")),
                    db: Session = Depends(get_db)) -> dict:
    q = db.scalar(select(Queue).where(Queue.org_id == p.org_id, Queue.code == body.queue))
    caller = db.get(PhoneNumber, body.caller_id_number_id)
    if q is None or caller is None or caller.org_id != p.org_id:
        raise ValidationFailed("Unknown queue or caller ID")
    if not caller.outbound_allowed or not caller.verified_at:
        raise ValidationFailed("Caller ID must be an owned, verified, outbound-enabled number")
    c = Campaign(org_id=p.org_id, name=body.name, purpose=body.purpose, dial_mode="preview", status="draft",
                 queue_id=q.id, jurisdiction=body.jurisdiction, caller_id_number_id=caller.id,
                 max_attempts_per_contact=body.max_attempts_per_contact, description=body.description,
                 created_by=p.user_id, review_summary={})
    db.add(c)
    db.flush()
    audit.by_principal(db, p, "campaign.created", "campaign", c.id, name=c.name)
    db.commit()
    return campaign_view(db, c)


@router.get("/v1/campaigns/{campaign_id}")
def get_campaign(campaign_id: uuid.UUID, p: Principal = Depends(require("workspace.read")),
                 db: Session = Depends(get_db)) -> dict:
    c = _campaign(db, p, campaign_id)
    out = campaign_view(db, c)
    if p.has("campaign.read"):
        out["contacts"] = [outbound.contact_view(x) for x in db.scalars(
            select(CampaignContact).where(CampaignContact.campaign_id == c.id).order_by(CampaignContact.created_at)
            .limit(500))]
    return out


@router.post("/v1/campaigns/{campaign_id}/imports", status_code=202)
async def upload(campaign_id: uuid.UUID, file: UploadFile = File(...), p: Principal = Depends(require("campaign.manage")),
                 db: Session = Depends(get_db)) -> dict:
    content = await file.read()
    from starlette.concurrency import run_in_threadpool

    def go():
        c = _campaign(db, p, campaign_id)
        imp = outbound.import_csv(db, c, file.filename or "upload.csv", content, p.user_id)
        audit.by_principal(db, p, "campaign.import_uploaded", "campaign", c.id, filename=imp.filename, bytes=len(content))
        db.commit()
        return {"import_id": imp.id, "status": imp.status,
                "note": "Validation runs in the background worker; review the results before activating."}

    return await run_in_threadpool(go)


class ActivateIn(BaseModel):
    expected_version: int


@router.post("/v1/campaigns/{campaign_id}/activate")
def activate(campaign_id: uuid.UUID, body: ActivateIn, p: Principal = Depends(require("campaign.manage")),
             db: Session = Depends(get_db)) -> dict:
    c = _campaign(db, p, campaign_id)
    if c.version != body.expected_version:
        from ..errors import VersionConflict

        raise VersionConflict("Campaign changed", details={"current_version": c.version})
    org = db.get(Organisation, p.org_id)
    outbound.activate(db, c, p.user_id, require_four_eyes=bool(org.settings.get("four_eyes_campaigns", True)))
    audit.by_principal(db, p, "campaign.activated", "campaign", c.id, created_by=str(c.created_by))
    db.commit()
    return campaign_view(db, c)


@router.post("/v1/campaigns/{campaign_id}/pause")
def pause(campaign_id: uuid.UUID, p: Principal = Depends(require("campaign.manage")), db: Session = Depends(get_db)) -> dict:
    c = _campaign(db, p, campaign_id)
    if c.status != "active":
        raise ValidationFailed("Only an active campaign can be paused")
    c.status = "paused"
    c.version += 1
    audit.by_principal(db, p, "campaign.paused", "campaign", c.id)
    db.commit()
    return campaign_view(db, c)


@router.post("/v1/campaigns/{campaign_id}/next")
def next_contact(campaign_id: uuid.UUID, p: Principal = Depends(require_agent), db: Session = Depends(get_db)) -> dict:
    c = _campaign(db, p, campaign_id)
    agent = db.get(Agent, p.agent_id, with_for_update=True)
    res = outbound.next_contact(db, agent, c, p.user_id)
    audit.by_principal(db, p, "campaign.preview_reserved", "campaign_contact", res["contact"]["id"])
    db.commit()
    return res


class SkipIn(BaseModel):
    reason: str = Field(min_length=3)


@router.post("/v1/interactions/{interaction_id}/skip-preview")
def skip(interaction_id: uuid.UUID, body: SkipIn, p: Principal = Depends(require_agent),
         db: Session = Depends(get_db)) -> dict:
    it = db.get(Interaction, interaction_id)
    if it is None or it.org_id != p.org_id:
        raise NotFound("Interaction not found")
    agent = db.get(Agent, p.agent_id, with_for_update=True)
    outbound.skip_contact(db, agent, it, body.reason, p.user_id)
    audit.by_principal(db, p, "campaign.preview_skipped", "interaction", it.id, reason=body.reason)
    db.commit()
    return {"ok": True}
