"""/v1/recordings – metadata, permissioned media access (audited), deletion and legal hold."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Query
from fastapi.responses import Response
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..errors import NotFound
from ..models import Interaction, Recording
from ..security.auth import Principal, current_principal, require
from ..services import audit, recording

router = APIRouter(prefix="/v1/recordings", tags=["recordings"])


@router.get("")
def list_recordings(p: Principal = Depends(require("recording.access")), db: Session = Depends(get_db)) -> list[dict]:
    rows = db.execute(select(Recording, Interaction).join(Interaction, Interaction.id == Recording.interaction_id)
                      .where(Recording.org_id == p.org_id).order_by(Recording.created_at.desc()).limit(100)).all()
    out = []
    for r, it in rows:
        ok, why = recording.can_access(p, r)
        out.append({**recording.recording_view(r), "interaction_id": it.id, "interaction_reference": it.reference,
                    "you_can_listen": ok, "access_note": why})
    return out


@router.get("/{recording_id}")
def get_recording(recording_id: uuid.UUID, p: Principal = Depends(current_principal),
                  db: Session = Depends(get_db)) -> dict:
    r = db.get(Recording, recording_id)
    if r is None or r.org_id != p.org_id:
        raise NotFound("Recording not found")
    ok, why = recording.can_access(p, r)
    return {**recording.recording_view(r), "you_can_listen": ok, "access_note": why,
            "allowed_purposes": sorted(recording.ACCESS_PURPOSES)}


@router.get("/{recording_id}/media")
def media(recording_id: uuid.UUID, purpose: str = Query(...), p: Principal = Depends(current_principal),
          db: Session = Depends(get_db)) -> Response:
    data, ctype, rec = recording.open_media(db, p, recording_id, purpose)
    db.commit()
    headers = {"Content-Disposition": "inline", "Cache-Control": "no-store"}
    if rec.is_synthetic_media:
        headers["X-Synthetic-Media"] = "true; simulator tone, not a call recording"
    return Response(content=data, media_type=ctype, headers=headers)


class DeleteIn(BaseModel):
    reason: str = Field(min_length=5)


@router.post("/{recording_id}/delete")
def delete(recording_id: uuid.UUID, body: DeleteIn, p: Principal = Depends(require("recording.delete")),
           db: Session = Depends(get_db)) -> dict:
    rec = recording.delete_recording(db, p, recording_id, body.reason)
    db.commit()
    return recording.recording_view(rec)


class HoldIn(BaseModel):
    legal_hold: bool
    reason: str = Field(min_length=5)


@router.post("/{recording_id}/legal-hold")
def legal_hold(recording_id: uuid.UUID, body: HoldIn, p: Principal = Depends(require("recording.legal_hold")),
               db: Session = Depends(get_db)) -> dict:
    r = db.get(Recording, recording_id)
    if r is None or r.org_id != p.org_id:
        raise NotFound("Recording not found")
    r.legal_hold = body.legal_hold
    audit.by_principal(db, p, "recording.legal_hold", "recording", r.id, legal_hold=body.legal_hold, reason=body.reason)
    db.commit()
    return recording.recording_view(r)
