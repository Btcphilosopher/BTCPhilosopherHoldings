"""/v1/callbacks."""
from __future__ import annotations

import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..errors import NotFound
from ..models import Callback, Organisation, Queue
from ..security.auth import Principal, require
from ..services import audit, callbacks
from .deps import idempotent

router = APIRouter(prefix="/v1/callbacks", tags=["callbacks"])


class CallbackIn(BaseModel):
    phone_number: str
    number_confirmation_method: str | None = Field(
        None, description="customer_confirmed | verified_contact_point | ani_confirmed_in_ivr; null = unconfirmed")
    window_start: datetime
    window_end: datetime
    queue: str
    customer_id: uuid.UUID | None = None
    origin_interaction_id: uuid.UUID | None = None
    reason: str = ""
    reserve_capacity: bool = False
    max_attempts: int = 3
    timezone: str = "Europe/London"


@router.post("", status_code=201)
def create(body: CallbackIn, request: Request, p: Principal = Depends(require("callback.write")),
           db: Session = Depends(get_db)):
    def run():
        q = db.scalar(select(Queue).where(Queue.org_id == p.org_id, Queue.code == body.queue))
        if q is None:
            raise NotFound("Queue not found")
        org = db.get(Organisation, p.org_id)
        cb = callbacks.create_callback(db, p.org_id, phone_number=body.phone_number,
                                       number_confirmation_method=body.number_confirmation_method,
                                       window_start=body.window_start, window_end=body.window_end, queue=q,
                                       customer_id=body.customer_id, origin_interaction_id=body.origin_interaction_id,
                                       created_by=p.user_id, created_via="agent", reason=body.reason,
                                       reserve_capacity=body.reserve_capacity, max_attempts=body.max_attempts,
                                       timezone=body.timezone,
                                       slots_per_interval=int(org.settings.get("callback_slots_per_interval", 2)))
        audit.by_principal(db, p, "callback.created", "callback", cb.id, reference=cb.reference,
                           reserved=cb.capacity_reserved)
        return 201, callbacks.view(db, cb)

    return idempotent(request, db, p, body.model_dump(mode="json"), run)


@router.get("")
def list_callbacks(status: str = "pending,ready,offered,in_progress", p: Principal = Depends(require("callback.read")),
                   db: Session = Depends(get_db)) -> list[dict]:
    rows = db.scalars(select(Callback).where(Callback.org_id == p.org_id, Callback.status.in_(status.split(",")))
                      .order_by(Callback.window_start)).all()
    return [callbacks.view(db, cb) for cb in rows]


@router.get("/{callback_id}")
def get(callback_id: uuid.UUID, p: Principal = Depends(require("callback.read")), db: Session = Depends(get_db)) -> dict:
    return callbacks.view(db, callbacks.get(db, p.org_id, callback_id))


class CancelIn(BaseModel):
    reason: str = Field(min_length=3)
    expected_version: int | None = None


@router.post("/{callback_id}/cancel")
def cancel(callback_id: uuid.UUID, body: CancelIn, p: Principal = Depends(require("callback.write")),
           db: Session = Depends(get_db)) -> dict:
    cb = callbacks.cancel(db, p.org_id, callback_id, body.reason, body.expected_version, p.user_id)
    audit.by_principal(db, p, "callback.cancelled", "callback", cb.id, reason=body.reason)
    db.commit()
    return callbacks.view(db, cb)
