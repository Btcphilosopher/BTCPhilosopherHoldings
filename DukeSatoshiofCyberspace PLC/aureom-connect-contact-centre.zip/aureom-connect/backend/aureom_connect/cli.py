"""Command line: migrate, seed, worker, totp, verify-audit, export-openapi."""
from __future__ import annotations

import argparse
import json
import sys


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="aureom")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("migrate", help="apply database migrations (alembic upgrade head)")
    b = sub.add_parser("bootstrap", help="migrate, then seed the demo organisation if the database is empty")
    b.add_argument("--no-seed", action="store_true")
    s = sub.add_parser("seed", help="load Pennine Customer Services synthetic data")
    s.add_argument("--standard-hours", action="store_true", help="use realistic UK hours instead of 24x7 demo hours")
    s.add_argument("--history-days", type=int, default=7)
    sub.add_parser("worker", help="run the background worker")
    t = sub.add_parser("totp", help="print the current demo TOTP code for a seeded MFA user")
    t.add_argument("email")
    sub.add_parser("verify-audit", help="verify the audit hash chain")
    vo = sub.add_parser("verify-objects", help="decrypt every stored object under ROOT and check its SHA-256")
    vo.add_argument("root")
    sub.add_parser("row-counts", help="print row counts for key tables (backup verification)")
    o = sub.add_parser("export-openapi", help="write the OpenAPI document")
    o.add_argument("path")
    args = ap.parse_args(argv)

    if args.cmd == "bootstrap":
        main(["migrate"])
        if args.no_seed:
            return 0
        from sqlalchemy import func, select

        from .db import session_scope
        from .models import Organisation

        with session_scope() as db:
            existing = db.scalar(select(func.count()).select_from(Organisation))
        if existing:
            print(json.dumps({"bootstrap": "database already contains data; seed skipped"}))
            return 0
        return main(["seed"])
    if args.cmd == "migrate":
        from alembic import command
        from alembic.config import Config
        import os

        cfg = Config(os.path.join(os.path.dirname(os.path.dirname(__file__)), "alembic.ini"))
        command.upgrade(cfg, "head")
        return 0
    if args.cmd == "seed":
        from .db import session_scope
        from .seed.pennine import seed

        with session_scope() as db:
            info = seed(db, always_open=not args.standard_hours, history_days=args.history_days)
        print(json.dumps({"seeded": "Pennine Customer Services", "history_interactions": info["history_interactions"]}))
        return 0
    if args.cmd == "worker":
        from .worker.main import run_forever

        run_forever()
        return 0
    if args.cmd == "totp":
        import pyotp

        from .seed.pennine import DEMO_TOTP

        secret = DEMO_TOTP.get(args.email)
        if not secret:
            print("not a seeded MFA demo user", file=sys.stderr)
            return 1
        print(pyotp.TOTP(secret).now())
        return 0
    if args.cmd == "verify-audit":
        from .db import session_scope
        from .services.audit import verify_chain

        with session_scope() as db:
            res = verify_chain(db)
        print(json.dumps(res))
        return 0 if res["valid"] else 2
    if args.cmd == "verify-objects":
        import hashlib

        from sqlalchemy import select

        from .adapters.storage import LocalProtectedStorage
        from .db import session_scope
        from .models import StoredObject

        store = LocalProtectedStorage(args.root)
        ok = bad = 0
        with session_scope() as db:
            for so in db.scalars(select(StoredObject).where(StoredObject.deleted_at.is_(None))):
                try:
                    good = hashlib.sha256(store.get(so.storage_key)).hexdigest() == so.sha256
                except Exception:  # missing file or wrong key
                    good = False
                ok, bad = (ok + 1, bad) if good else (ok, bad + 1)
        print(json.dumps({"objects_verified": ok, "objects_failed": bad}))
        return 0 if bad == 0 else 3
    if args.cmd == "row-counts":
        from sqlalchemy import text

        from .db import session_scope

        tables = ["organisations", "users", "agents", "customers", "interactions", "calls", "call_legs",
                  "provider_events", "recordings", "cases", "tasks", "callbacks", "audit_log", "stored_objects"]
        with session_scope() as db:
            print(json.dumps({t: db.execute(text(f"select count(*) from {t}")).scalar_one() for t in tables}))
        return 0
    if args.cmd == "export-openapi":
        from .main import app

        with open(args.path, "w") as f:
            json.dump(app.openapi(), f, indent=2, default=str)
        return 0
    return 1


if __name__ == "__main__":
    sys.exit(main())
