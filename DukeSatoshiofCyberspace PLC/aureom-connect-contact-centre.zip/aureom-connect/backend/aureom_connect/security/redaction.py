"""Redaction for logs and audit details.

Phone numbers, e-mail addresses, bearer tokens and card-like digit runs are
masked. Applied to log records via a logging filter and to audit details
before they are hashed and stored.
"""
from __future__ import annotations

import logging
import re
from typing import Any

_EMAIL = re.compile(r"([A-Za-z0-9._%+-])[A-Za-z0-9._%+-]*@([A-Za-z0-9.-]+\.[A-Za-z]{2,})")
_PHONE = re.compile(r"(?<![\w])\+?\d[\d \-()]{7,}\d(?![\w])")
_CARD = re.compile(r"\b(?:\d[ -]?){13,19}\b")
_BEARER = re.compile(r"(?i)(bearer\s+)[A-Za-z0-9\-._~+/]+=*")
_JWT = re.compile(r"eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+")

SENSITIVE_KEYS = {"password", "token", "access_token", "refresh_token", "secret", "authorization", "totp",
                  "code", "answer", "answers", "value", "api_key", "card_number", "cvv", "pan", "otp"}


def _mask_phone(m: re.Match[str]) -> str:
    digits = re.sub(r"\D", "", m.group(0))
    if len(digits) < 8:
        return m.group(0)
    return f"[phone …{digits[-3:]}]"


def redact_text(text: str) -> str:
    text = _JWT.sub("[jwt]", text)
    text = _BEARER.sub(r"\1[redacted]", text)
    text = _CARD.sub("[card-like-number]", text)
    text = _EMAIL.sub(lambda m: f"{m.group(1)}***@{m.group(2)}", text)
    text = _PHONE.sub(_mask_phone, text)
    return text


def redact(obj: Any, *, _depth: int = 0) -> Any:
    if _depth > 8:
        return "[depth]"
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if str(k).lower() in SENSITIVE_KEYS:
                out[k] = "[redacted]"
            else:
                out[k] = redact(v, _depth=_depth + 1)
        return out
    if isinstance(obj, (list, tuple)):
        return [redact(v, _depth=_depth + 1) for v in obj]
    if isinstance(obj, str):
        return redact_text(obj)
    return obj


class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:  # noqa: A003
        if isinstance(record.msg, str):
            record.msg = redact_text(record.msg)
        if record.args:
            if isinstance(record.args, dict):
                record.args = redact(record.args)
            else:
                record.args = tuple(redact(a) if isinstance(a, (str, dict, list)) else a for a in record.args)
        return True


def install_log_redaction() -> None:
    root = logging.getLogger()
    flt = RedactingFilter()
    for handler in root.handlers:
        handler.addFilter(flt)
    root.addFilter(flt)
    for name in ("uvicorn", "uvicorn.access", "uvicorn.error", "aureom"):
        logging.getLogger(name).addFilter(flt)
