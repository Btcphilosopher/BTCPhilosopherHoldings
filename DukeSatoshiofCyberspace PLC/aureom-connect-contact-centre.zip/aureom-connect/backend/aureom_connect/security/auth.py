"""Authentication: local password + TOTP (development / break-glass) and OIDC.

Organisational sign-in is expected to use the OIDC flow against the
organisation's identity provider (Entra ID, Okta, Keycloak, ...). MFA is then
evidenced by the ``amr`` claim of the ID token. The local password + TOTP
path exists for the demonstration and for break-glass administration.
"""
from __future__ import annotations

import base64
import hashlib
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any

import jwt
import pyotp
from fastapi import Depends, Header, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import get_db, utcnow
from ..errors import Forbidden, Unauthorized
from ..models import Agent, Organisation, RefreshToken, User
from .crypto import decrypt_str, random_token, token_hash, verify_password
from .permissions import MFA_SENSITIVE, permissions_for

ALGO = "HS256"


@dataclass
class Principal:
    user_id: uuid.UUID
    org_id: uuid.UUID
    email: str
    display_name: str
    roles: list[str]
    permissions: set[str]
    mfa: bool
    agent_id: uuid.UUID | None = None
    request_id: str | None = None
    ip: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def has(self, perm: str) -> bool:
        return perm in self.permissions

    def require(self, perm: str) -> None:
        if perm not in self.permissions:
            raise Forbidden(f"Missing permission: {perm}", code="PERMISSION_DENIED", details={"permission": perm})
        if perm in MFA_SENSITIVE and not self.mfa:
            raise Forbidden("This action requires multi-factor authentication", code="MFA_REQUIRED",
                            details={"permission": perm})


def issue_access_token(user: User, agent: Agent | None, *, mfa: bool) -> str:
    s = get_settings()
    now = datetime.now(timezone.utc)
    claims = {
        "sub": str(user.id), "org": str(user.org_id), "mfa": mfa, "typ": "access",
        "agent": str(agent.id) if agent else None,
        "iat": int(now.timestamp()), "exp": int((now + timedelta(minutes=s.access_token_minutes)).timestamp()),
        "jti": uuid.uuid4().hex,
    }
    return jwt.encode(claims, s.jwt_secret, algorithm=ALGO)


def decode_access_token(token: str) -> dict[str, Any]:
    try:
        claims = jwt.decode(token, get_settings().jwt_secret, algorithms=[ALGO], options={"require": ["exp", "sub"]})
    except jwt.ExpiredSignatureError as exc:
        raise Unauthorized("Access token expired", code="TOKEN_EXPIRED") from exc
    except jwt.PyJWTError as exc:
        raise Unauthorized("Invalid access token") from exc
    if claims.get("typ") != "access":
        raise Unauthorized("Wrong token type")
    return claims


def issue_refresh_token(db: Session, user: User, *, mfa: bool) -> str:
    raw = random_token()
    db.add(RefreshToken(user_id=user.id, token_hash=token_hash(raw), mfa_satisfied=mfa,
                        expires_at=utcnow() + timedelta(days=get_settings().refresh_token_days)))
    return raw


def rotate_refresh_token(db: Session, raw: str) -> tuple[User, bool, str]:
    rt = db.scalar(select(RefreshToken).where(RefreshToken.token_hash == token_hash(raw)).with_for_update())
    if rt is None or rt.expires_at < utcnow():
        raise Unauthorized("Refresh token invalid or expired")
    if rt.revoked_at is not None:
        # Reuse of a rotated token: revoke the whole family for this user.
        for other in db.scalars(select(RefreshToken).where(RefreshToken.user_id == rt.user_id,
                                                           RefreshToken.revoked_at.is_(None))):
            other.revoked_at = utcnow()
        db.commit()
        raise Unauthorized("Refresh token reuse detected; sessions revoked", code="TOKEN_REUSE")
    user = db.get(User, rt.user_id)
    if user is None or not user.active:
        raise Unauthorized("User inactive")
    new_raw = random_token()
    new = RefreshToken(user_id=user.id, token_hash=token_hash(new_raw), mfa_satisfied=rt.mfa_satisfied,
                       expires_at=utcnow() + timedelta(days=get_settings().refresh_token_days))
    db.add(new)
    db.flush()
    rt.revoked_at = utcnow()
    rt.replaced_by = new.id
    return user, rt.mfa_satisfied, new_raw


def mfa_required_for(org: Organisation, user: User) -> bool:
    roles_requiring = set(org.settings.get("mfa_required_roles", ["admin", "compliance_officer"]))
    return bool(roles_requiring & set(user.roles))


def verify_totp(user: User, code: str | None) -> bool:
    if not user.totp_secret_enc or not code:
        return False
    secret = decrypt_str(user.totp_secret_enc)
    return pyotp.TOTP(secret).verify(code, valid_window=1)


def password_login(db: Session, org_slug: str, email: str, password: str, totp_code: str | None) -> tuple[User, bool]:
    org = db.scalar(select(Organisation).where(Organisation.slug == org_slug))
    if org is None:
        raise Unauthorized("Invalid credentials")
    user = db.scalar(select(User).where(User.org_id == org.id, User.email == email.lower()))
    if user is None or not user.active or not verify_password(user.password_hash, password):
        raise Unauthorized("Invalid credentials")
    mfa_ok = verify_totp(user, totp_code) if user.mfa_enrolled else False
    if mfa_required_for(org, user) and not mfa_ok:
        raise Unauthorized("A valid one-time code is required for this account", code="MFA_REQUIRED")
    user.last_login_at = utcnow()
    return user, mfa_ok


# --------------------------------------------------------------------------- OIDC

def pkce_pair() -> tuple[str, str]:
    verifier = random_token(48)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    return verifier, challenge


def validate_id_token(id_token: str, *, signing_key: Any, issuer: str, audience: str, nonce: str,
                      mfa_amr_values: list[str]) -> tuple[dict[str, Any], bool]:
    """Validate an OIDC ID token and report whether MFA is evidenced via ``amr``."""
    claims = jwt.decode(id_token, signing_key, algorithms=["RS256", "ES256", "PS256"], audience=audience,
                        issuer=issuer, options={"require": ["exp", "iat", "sub", "aud", "iss"]})
    if claims.get("nonce") != nonce:
        raise Unauthorized("OIDC nonce mismatch")
    amr = claims.get("amr") or []
    mfa = any(v in amr for v in mfa_amr_values)
    return claims, mfa


# --------------------------------------------------------------------------- dependencies

def _principal_from_claims(db: Session, claims: dict[str, Any]) -> Principal:
    user = db.get(User, uuid.UUID(claims["sub"]))
    if user is None or not user.active or str(user.org_id) != claims.get("org"):
        raise Unauthorized("User not found or inactive")
    agent = db.scalar(select(Agent).where(Agent.user_id == user.id))
    return Principal(user_id=user.id, org_id=user.org_id, email=user.email, display_name=user.display_name,
                     roles=list(user.roles), permissions=permissions_for(user.roles), mfa=bool(claims.get("mfa")),
                     agent_id=agent.id if agent else None)


def principal_from_token(db: Session, token: str) -> Principal:
    return _principal_from_claims(db, decode_access_token(token))


def current_principal(request: Request, authorization: str | None = Header(default=None),
                      db: Session = Depends(get_db)) -> Principal:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise Unauthorized("Missing bearer token")
    p = principal_from_token(db, authorization.split(" ", 1)[1].strip())
    p.request_id = getattr(request.state, "request_id", None)
    p.ip = request.client.host if request.client else None
    request.state.principal = p
    return p


def require(perm: str):
    def dep(p: Principal = Depends(current_principal)) -> Principal:
        p.require(perm)
        return p

    return dep


def require_agent(p: Principal = Depends(current_principal)) -> Principal:
    if p.agent_id is None:
        raise Forbidden("This endpoint is for agents", code="NOT_AN_AGENT")
    p.require("interaction.handle")
    return p
