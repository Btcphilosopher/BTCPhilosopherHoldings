"""Role → permission mapping. Enforced server-side on every endpoint."""
from __future__ import annotations

from ..models.enums import Role

AGENT_PERMS = {
    "workspace.read", "interaction.handle", "customer.read", "customer.verify", "customer.update",
    "case.read", "case.write", "task.read", "task.write", "knowledge.read", "outbound.dial",
    "callback.read", "callback.write", "schedule.read_own", "schedule.request_change",
    "message.send", "ai.use", "qa.read_own", "transcript.read", "transcript.correct",
}

SUPERVISOR_PERMS = AGENT_PERMS | {
    "ops.read", "queue.read", "queue.manage", "agent.read", "agent.manage_state", "campaign.read",
    "campaign.manage", "report.read", "qa.review", "case.override", "monitoring.listen",
    "monitoring.coach", "schedule.read", "callback.manage", "audit.read_ops", "recording.access",
    "customer.duplicates", "forecast.read",
}

ROLE_PERMISSIONS: dict[str, set[str]] = {
    Role.AGENT: AGENT_PERMS,
    Role.SUPERVISOR: SUPERVISOR_PERMS,
    Role.QUALITY_REVIEWER: {"qa.review", "qa.manage_rubrics", "report.read", "recording.access",
                            "transcript.read", "workspace.read", "knowledge.read", "ops.read", "agent.read"},
    Role.WORKFORCE_MANAGER: {"schedule.read", "schedule.manage", "forecast.read", "forecast.manage",
                             "agent.read", "report.read", "ops.read", "knowledge.read"},
    Role.COMPLIANCE_OFFICER: {"recording.access", "recording.delete", "recording.legal_hold", "audit.read",
                              "rules.manage", "campaign.read", "report.read", "transcript.read",
                              "suppression.manage", "knowledge.read", "ops.read"},
    Role.KNOWLEDGE_EDITOR: {"knowledge.read", "knowledge.write", "knowledge.approve", "message_template.manage"},
    Role.ADMIN: {"admin.users", "admin.config", "audit.read", "ops.read", "queue.read", "queue.manage",
                 "agent.read", "report.read", "rules.manage", "provider.manage", "knowledge.read",
                 "campaign.read", "simulator.control", "schedule.read", "message_template.manage"},
}

# Permissions that a user may only exercise after MFA was satisfied in this session.
MFA_SENSITIVE = {"admin.users", "admin.config", "provider.manage", "recording.delete", "rules.manage",
                 "audit.read", "recording.legal_hold"}


def permissions_for(roles: list[str]) -> set[str]:
    perms: set[str] = set()
    for role in roles:
        perms |= ROLE_PERMISSIONS.get(role, set())
    return perms
