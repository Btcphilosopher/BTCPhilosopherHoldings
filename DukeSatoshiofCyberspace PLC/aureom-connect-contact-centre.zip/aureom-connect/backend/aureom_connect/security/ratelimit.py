"""In-process sliding-window rate limiter.

Adequate for a single API instance. For horizontally scaled deployments the
same interface should be backed by a shared store (documented in
docs/security.md); this is called out as a deferred item.
"""
from __future__ import annotations

import threading
import time
from collections import defaultdict, deque

from ..errors import RateLimited


class SlidingWindowLimiter:
    def __init__(self) -> None:
        self._hits: dict[str, deque[float]] = defaultdict(deque)
        self._lock = threading.Lock()

    def check(self, key: str, limit: int, window_seconds: float = 60.0) -> None:
        now = time.monotonic()
        with self._lock:
            q = self._hits[key]
            while q and q[0] <= now - window_seconds:
                q.popleft()
            if len(q) >= limit:
                retry = max(0.0, window_seconds - (now - q[0]))
                raise RateLimited("Too many requests", details={"retry_after_seconds": round(retry, 1)})
            q.append(now)

    def reset(self) -> None:
        with self._lock:
            self._hits.clear()


limiter = SlidingWindowLimiter()
