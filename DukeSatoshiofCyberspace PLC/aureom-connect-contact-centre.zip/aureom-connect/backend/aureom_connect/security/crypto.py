"""Encryption of secrets and stored objects, hashing helpers."""
from __future__ import annotations

import hashlib
import hmac
import secrets

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerifyMismatchError
from cryptography.fernet import Fernet, InvalidToken

from ..config import get_settings

_ph = PasswordHasher()


def _fernet() -> Fernet:
    return Fernet(get_settings().master_key.encode())


def encrypt_str(value: str) -> str:
    return _fernet().encrypt(value.encode()).decode()


def decrypt_str(token: str) -> str:
    try:
        return _fernet().decrypt(token.encode()).decode()
    except InvalidToken as exc:  # pragma: no cover - indicates key rotation problem
        raise RuntimeError("Unable to decrypt secret: master key mismatch") from exc


def encrypt_bytes(data: bytes) -> bytes:
    return _fernet().encrypt(data)


def decrypt_bytes(data: bytes) -> bytes:
    return _fernet().decrypt(data)


def hash_password(password: str) -> str:
    return _ph.hash(password)


def verify_password(password_hash: str | None, password: str) -> bool:
    if not password_hash:
        return False
    try:
        return _ph.verify(password_hash, password)
    except (VerifyMismatchError, InvalidHashError):
        return False


def hash_secret_value(value: str) -> str:
    """Hash a customer verification factor (normalised) for comparison only."""
    return _ph.hash(normalise_factor(value))


def verify_secret_value(value_hash: str, candidate: str) -> bool:
    try:
        return _ph.verify(value_hash, normalise_factor(candidate))
    except (VerifyMismatchError, InvalidHashError):
        return False


def normalise_factor(value: str) -> str:
    return "".join(ch for ch in value.lower() if ch.isalnum())


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def random_token(nbytes: int = 32) -> str:
    return secrets.token_urlsafe(nbytes)


def hmac_sha256_hex(secret: str, message: bytes) -> str:
    return hmac.new(secret.encode(), message, hashlib.sha256).hexdigest()


def constant_time_equals(a: str, b: str) -> bool:
    return hmac.compare_digest(a.encode(), b.encode())
