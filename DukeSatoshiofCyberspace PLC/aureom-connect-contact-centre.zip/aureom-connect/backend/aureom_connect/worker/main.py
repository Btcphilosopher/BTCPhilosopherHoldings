"""Background worker: timers, reconciliation, imports, notifications, retention.

Safe to run several instances: jobs are claimed with ``FOR UPDATE SKIP LOCKED``
and routing passes take a per-organisation advisory lock.
"""
from __future__ import annotations

import logging
import os
import socket
import time
import traceback
import uuid
from datetime import timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import session_scope, utcnow
from ..models import Interaction, Job, Offer, Organisation, ProviderEvent, Queue, QueueEntry
from ..services import callbacks, interactions, reconciliation, recording, routing

log = logging.getLogger("aureom.worker")
WORKER_ID = f"{socket.gethostname()}:{os.getpid()}"


def expire_offers(db: Session) -> int:
    n = 0
    for offer in db.scalars(select(Offer).where(Offer.status == "pending", Offer.expires_at < utcnow())
                            .with_for_update(skip_locked=True)):
        interactions.expire_offer(db, offer)
        n += 1
    return n


def overflow(db: Session) -> int:
    n = 0
    rows = db.execute(select(QueueEntry, Queue, Interaction).join(Queue, Queue.id == QueueEntry.queue_id)
                      .join(Interaction, Interaction.id == QueueEntry.interaction_id)
                      .where(QueueEntry.left_at.is_(None), Queue.overflow_queue_id.is_not(None),
                             Queue.overflow_after_seconds.is_not(None), Interaction.status == "queued")
                      .with_for_update(of=Interaction, skip_locked=True)).all()
    for entry, q, it in rows:
        if (utcnow() - entry.entered_at).total_seconds() < q.overflow_after_seconds:
            continue
        target = db.get(Queue, q.overflow_queue_id)
        entry.left_at = utcnow()
        entry.exit_reason = "overflow"
        from ..services import events

        events.timeline(db, it, "queue.overflow", "system", from_queue=q.code, to_queue=target.code,
                        after_seconds=q.overflow_after_seconds)
        interactions.enqueue(db, it, target, reason="overflow")
        n += 1
    return n


def reprocess_unmatched(db: Session) -> int:
    from ..adapters.telephony.base import NormalizedEvent
    from ..services import provider_events

    n = 0
    cutoff = utcnow() - timedelta(seconds=2)
    for pe in db.scalars(select(ProviderEvent).where(ProviderEvent.processing_status == "unmatched",
                                                     ProviderEvent.received_at < cutoff,
                                                     ProviderEvent.received_at > utcnow() - timedelta(minutes=10))
                         .limit(50)):
        provider_events.process(db, pe.provider, NormalizedEvent(**pe.payload), existing=pe)
        n += 1
    return n


def run_job(db: Session, job: Job) -> None:
    from ..models import CampaignImport, OutboundMessage, Recording

    p = job.payload
    if job.kind == "fetch_recording":
        rec = db.get(Recording, uuid.UUID(p["recording_id"]))
        recording.fetch_media(db, rec)
    elif job.kind == "campaign_import":
        from ..services import outbound

        outbound.process_import(db, db.get(CampaignImport, uuid.UUID(p["import_id"])))
    elif job.kind == "reconcile_call":
        from ..adapters.telephony.registry import get_provider
        from ..models import Call

        call = db.get(Call, uuid.UUID(p["call_id"]))
        if call and call.status == "in_progress":
            reconciliation.reconcile_call(db, call, get_provider().get_call_state(call.provider_call_id))
    elif job.kind == "send_message":
        from ..services import messages

        messages.deliver(db, db.get(OutboundMessage, uuid.UUID(p["message_id"])))
    elif job.kind == "qa_sample":
        from ..services import quality

        quality.sample(db, uuid.UUID(p["org_id"]))
    else:
        raise ValueError(f"unknown job kind {job.kind}")


def run_jobs(db_factory=session_scope, limit: int = 20) -> int:
    done = 0
    for _ in range(limit):
        with db_factory() as db:
            job = db.scalar(select(Job).where(Job.status == "queued", Job.run_at <= utcnow())
                            .order_by(Job.run_at).with_for_update(skip_locked=True).limit(1))
            if job is None:
                break
            job.status = "running"
            job.locked_by = WORKER_ID
            job.locked_at = utcnow()
            job.attempts += 1
            job_id = job.id
        try:
            with db_factory() as db:
                run_job(db, db.get(Job, job_id))
                j = db.get(Job, job_id)
                j.status = "done"
                j.finished_at = utcnow()
        except Exception as exc:
            log.warning("job %s failed: %s", job_id, exc)
            with db_factory() as db:
                j = db.get(Job, job_id)
                j.last_error = "".join(traceback.format_exception_only(type(exc), exc))[:2000]
                if j.attempts >= j.max_attempts:
                    j.status = "failed"
                else:
                    j.status = "queued"
                    j.run_at = utcnow() + timedelta(seconds=2 ** j.attempts)
        done += 1
    return done


def tick(*, health: bool = True) -> dict[str, int]:
    stats: dict[str, int] = {}
    with session_scope() as db:
        org_ids = list(db.scalars(select(Organisation.id)))
    for org_id in org_ids:
        if health:
            with session_scope() as db:
                reconciliation.check_health(db, org_id)
    with session_scope() as db:
        stats["offers_expired"] = expire_offers(db)
    with session_scope() as db:
        stats["overflowed"] = overflow(db)
    with session_scope() as db:
        stats["callbacks_ready"] = callbacks.make_ready(db)
    with session_scope() as db:
        stats["presence_swept"] = reconciliation.sweep_presence(db)
    with session_scope() as db:
        stats["unmatched_reprocessed"] = reprocess_unmatched(db)
    for org_id in org_ids:
        with session_scope() as db:
            stats[f"offers:{org_id}"] = len(routing.route_org(db, org_id))
    stats["jobs"] = run_jobs()
    return stats


def run_forever(interval: float = 1.0) -> None:  # pragma: no cover - process loop
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    from ..security.redaction import install_log_redaction

    install_log_redaction()
    logging.getLogger("httpx").setLevel(logging.WARNING)
    log.info("worker %s starting", WORKER_ID)
    last_retention = 0.0
    while True:
        started = time.monotonic()
        try:
            tick()
            if time.monotonic() - last_retention > 60:
                with session_scope() as db:
                    recording.apply_retention(db)
                last_retention = time.monotonic()
        except Exception:
            log.exception("worker tick failed")
        time.sleep(max(0.1, interval - (time.monotonic() - started)))


if __name__ == "__main__":  # pragma: no cover
    run_forever()
