"""Workforce scheduling, availability, leave, forecasts and observed demand."""
from __future__ import annotations

import uuid
from datetime import date, datetime

from sqlalchemy import Date, DateTime, Float, Integer, String, Text, UniqueConstraint, Index
from sqlalchemy.orm import Mapped, mapped_column

from ..db import Base, TimestampMixin
from ._common import JSONDict, JSONList, OrgFK, TS, TSNull, UUIDPK, fk


class Schedule(Base, TimestampMixin):
    __tablename__ = "schedules"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    name: Mapped[str] = mapped_column(String(200))
    period_start: Mapped[date] = mapped_column(Date)
    period_end: Mapped[date] = mapped_column(Date)
    status: Mapped[str] = mapped_column(String(16), default="draft")
    version: Mapped[int] = mapped_column(Integer, default=1)
    published_at: Mapped[TSNull]
    published_by: Mapped[uuid.UUID | None] = fk("users.id")
    supersedes_id: Mapped[uuid.UUID | None] = fk("schedules.id")


class Shift(Base, TimestampMixin):
    __tablename__ = "shifts"
    __table_args__ = (Index("ix_shifts_agent_time", "agent_id", "start_at"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    schedule_id: Mapped[uuid.UUID] = fk("schedules.id", nullable=False)
    agent_id: Mapped[uuid.UUID] = fk("agents.id", nullable=False)
    start_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    end_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    activities: Mapped[JSONList]  # [{"kind": "break|lunch|training", "start", "end"}]
    queue_codes: Mapped[JSONList]
    note: Mapped[str] = mapped_column(Text, default="")
    version: Mapped[int] = mapped_column(Integer, default=1)


class AgentAvailability(Base):
    """Agent-declared weekly availability (contracted/preferred hours)."""

    __tablename__ = "agent_availability"
    __table_args__ = (UniqueConstraint("agent_id", "weekday"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    agent_id: Mapped[uuid.UUID] = fk("agents.id", nullable=False)
    weekday: Mapped[int] = mapped_column(Integer)  # 1=Mon
    intervals: Mapped[JSONList]  # [["08:00","17:00"]]


class LeaveRequest(Base, TimestampMixin):
    __tablename__ = "leave_requests"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    agent_id: Mapped[uuid.UUID] = fk("agents.id", nullable=False)
    start_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    end_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    kind: Mapped[str] = mapped_column(String(32))  # annual | sick | training | other
    status: Mapped[str] = mapped_column(String(16), default="requested")  # requested | approved | declined | cancelled
    decided_by: Mapped[uuid.UUID | None] = fk("users.id")
    note: Mapped[str] = mapped_column(Text, default="")


class ShiftChangeRequest(Base, TimestampMixin):
    __tablename__ = "shift_change_requests"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    shift_id: Mapped[uuid.UUID] = fk("shifts.id", nullable=False)
    requested_by_agent_id: Mapped[uuid.UUID] = fk("agents.id", nullable=False)
    kind: Mapped[str] = mapped_column(String(16))  # change | swap | drop
    proposed_start_at: Mapped[TSNull]
    proposed_end_at: Mapped[TSNull]
    swap_with_agent_id: Mapped[uuid.UUID | None] = fk("agents.id")
    reason: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(16), default="requested")
    decided_by: Mapped[uuid.UUID | None] = fk("users.id")
    decided_at: Mapped[TSNull]
    decision_note: Mapped[str] = mapped_column(Text, default="")


class ObservedDemand(Base):
    """Observed contacts per interval. ``source`` distinguishes derived from imported history."""

    __tablename__ = "observed_demand"
    __table_args__ = (UniqueConstraint("queue_id", "interval_start", "source"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    queue_id: Mapped[uuid.UUID] = fk("queues.id", nullable=False)
    interval_start: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    interval_minutes: Mapped[int] = mapped_column(Integer, default=30)
    offered: Mapped[int] = mapped_column(Integer, default=0)
    answered: Mapped[int] = mapped_column(Integer, default=0)
    avg_handle_seconds: Mapped[float | None] = mapped_column(Float, nullable=True)
    source: Mapped[str] = mapped_column(String(32))  # derived_from_interactions | imported_synthetic_history


class Forecast(Base):
    """A generated forecast. Never mixed with observed demand."""

    __tablename__ = "forecasts"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    queue_id: Mapped[uuid.UUID] = fk("queues.id", nullable=False)
    target_date: Mapped[date] = mapped_column(Date)
    method: Mapped[str] = mapped_column(String(64))
    parameters: Mapped[JSONDict]
    intervals: Mapped[JSONList]  # [{"start","expected","lower","upper","n_weeks","required_agents"}]
    generated_at: Mapped[TS]
    generated_by: Mapped[uuid.UUID | None] = fk("users.id")
    notes: Mapped[str] = mapped_column(Text, default="")
