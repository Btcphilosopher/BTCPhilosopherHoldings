"""Organisations, users, agents and skills."""
from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from ..db import Base, TimestampMixin
from ._common import JSONDict, JSONList, OrgFK, TS, TSNull, UUIDPK, fk
from .enums import AgentState, Presence, TelephonyRegistration


class Organisation(Base, TimestampMixin):
    __tablename__ = "organisations"
    id: Mapped[UUIDPK]
    slug: Mapped[str] = mapped_column(String(64), unique=True)
    name: Mapped[str] = mapped_column(String(200))
    timezone: Mapped[str] = mapped_column(String(64), default="Europe/London")
    jurisdiction: Mapped[str] = mapped_column(String(16), default="GB")
    # Security / behaviour policy: mfa_required_roles, verification policy, short_abandon_seconds ...
    settings: Mapped[JSONDict]


class User(Base, TimestampMixin):
    __tablename__ = "users"
    __table_args__ = (UniqueConstraint("org_id", "email"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    email: Mapped[str] = mapped_column(String(320))
    display_name: Mapped[str] = mapped_column(String(200))
    roles: Mapped[JSONList]
    password_hash: Mapped[str | None] = mapped_column(String(255), nullable=True)
    # TOTP secret encrypted with the master key (never returned by the API).
    totp_secret_enc: Mapped[str | None] = mapped_column(Text, nullable=True)
    mfa_enrolled: Mapped[bool] = mapped_column(Boolean, default=False)
    oidc_subject: Mapped[str | None] = mapped_column(String(255), nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    last_login_at: Mapped[TSNull]


class RefreshToken(Base):
    __tablename__ = "refresh_tokens"
    id: Mapped[UUIDPK]
    user_id: Mapped[uuid.UUID] = fk("users.id", nullable=False)
    token_hash: Mapped[str] = mapped_column(String(128), unique=True)
    issued_at: Mapped[TS]
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    revoked_at: Mapped[TSNull]
    replaced_by: Mapped[uuid.UUID | None] = fk("refresh_tokens.id")
    mfa_satisfied: Mapped[bool] = mapped_column(Boolean, default=False)


class Skill(Base):
    __tablename__ = "skills"
    __table_args__ = (UniqueConstraint("org_id", "code"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    code: Mapped[str] = mapped_column(String(64))
    name: Mapped[str] = mapped_column(String(200))


class Agent(Base, TimestampMixin):
    """An agent's routable identity.

    Three separate facts are tracked deliberately:

    * ``presence``      – is the agent application connected (WebSocket heartbeats)?
    * ``telephony_registration`` – has the *media provider* confirmed a device registration?
    * ``state``         – the explicit work state used for routing.

    A connected browser does not imply the agent can receive audio, so routing
    requires all three.
    """

    __tablename__ = "agents"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    user_id: Mapped[uuid.UUID] = fk("users.id", nullable=False)
    display_name: Mapped[str] = mapped_column(String(200))
    languages: Mapped[JSONList]
    state: Mapped[str] = mapped_column(String(32), default=AgentState.OFFLINE)
    state_reason: Mapped[str | None] = mapped_column(String(64), nullable=True)
    state_since: Mapped[TS]
    state_version: Mapped[int] = mapped_column(Integer, default=1)
    # Last time the agent became idle-available (used for longest-idle agent selection).
    available_since: Mapped[TSNull]

    presence: Mapped[str] = mapped_column(String(16), default=Presence.OFFLINE)
    presence_last_seen: Mapped[TSNull]
    telephony_registration: Mapped[str] = mapped_column(String(16), default=TelephonyRegistration.UNKNOWN)
    telephony_device_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    telephony_registered_at: Mapped[TSNull]

    # Set whenever application and provider state may disagree (reconnect,
    # provider outage, unknown control outcome). Consequential actions are
    # refused until a reconciliation pass clears it.
    reconcile_required: Mapped[bool] = mapped_column(Boolean, default=False)
    reconcile_reason: Mapped[str | None] = mapped_column(String(200), nullable=True)
    current_interaction_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True)
    missed_offer_count: Mapped[int] = mapped_column(Integer, default=0)
    max_concurrent_chats: Mapped[int] = mapped_column(Integer, default=2)
    team: Mapped[str | None] = mapped_column(String(100), nullable=True)
    supervisor_notes: Mapped[str | None] = mapped_column(Text, nullable=True)


class AgentSkill(Base):
    __tablename__ = "agent_skills"
    __table_args__ = (UniqueConstraint("agent_id", "skill_id"),)
    id: Mapped[UUIDPK]
    agent_id: Mapped[uuid.UUID] = fk("agents.id", nullable=False)
    skill_id: Mapped[uuid.UUID] = fk("skills.id", nullable=False)
    proficiency: Mapped[int] = mapped_column(Integer, default=3)  # 1..5


class AgentQueueMembership(Base):
    __tablename__ = "agent_queue_memberships"
    __table_args__ = (UniqueConstraint("agent_id", "queue_id"),)
    id: Mapped[UUIDPK]
    agent_id: Mapped[uuid.UUID] = fk("agents.id", nullable=False)
    queue_id: Mapped[uuid.UUID] = fk("queues.id", nullable=False)


class AgentStateHistory(Base):
    __tablename__ = "agent_state_history"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    agent_id: Mapped[uuid.UUID] = fk("agents.id", nullable=False)
    from_state: Mapped[str] = mapped_column(String(32))
    to_state: Mapped[str] = mapped_column(String(32))
    reason: Mapped[str | None] = mapped_column(String(200), nullable=True)
    source: Mapped[str] = mapped_column(String(32))  # agent | system | provider | supervisor
    actor_user_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True)
    at: Mapped[TS]
