"""Outbound calling: calling rules, suppression, campaigns, imports and attempts."""
from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import DateTime, Integer, String, Text, UniqueConstraint, Index
from sqlalchemy.orm import Mapped, mapped_column

from ..db import Base, TimestampMixin
from ._common import JSONDict, JSONList, OrgFK, TS, TSNull, UUIDPK, fk


class CallingRuleSet(Base, TimestampMixin):
    """Jurisdiction-specific, versioned permitted-calling configuration.

    ``rules`` example::

        {"calling_windows": {"1": [["08:00","21:00"]], ...},   # recipient local time
         "max_attempts_per_day": 2, "max_attempts_per_7_days": 6,
         "min_minutes_between_attempts": 120,
         "purposes": {"marketing": {"requires": ["consent_or_screened"], "screen_lists": ["internal_dnc", "national_registry"]},
                      "service":   {"requires": ["any_basis"], "screen_lists": ["internal_dnc"]}},
         "honour_objection_scopes": {"marketing": ["all_marketing","telephone_marketing","all_telephone"],
                                     "service": ["all_telephone"]}}

    Rule *content* is organisational configuration that must be validated
    against current official sources before live use; the seeded rules are
    illustrative.
    """

    __tablename__ = "calling_rule_sets"
    __table_args__ = (UniqueConstraint("org_id", "jurisdiction", "version"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    jurisdiction: Mapped[str] = mapped_column(String(16))
    version: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(16), default="draft")  # draft | active | retired
    effective_from: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    effective_to: Mapped[TSNull]
    rules: Mapped[JSONDict]
    source_notes: Mapped[str] = mapped_column(Text, default="")
    approved_by: Mapped[uuid.UUID | None] = fk("users.id")


class SuppressionList(Base, TimestampMixin):
    __tablename__ = "suppression_lists"
    __table_args__ = (UniqueConstraint("org_id", "code"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    code: Mapped[str] = mapped_column(String(64))  # internal_dnc | national_registry | litigation_hold
    name: Mapped[str] = mapped_column(String(200))
    source: Mapped[str] = mapped_column(String(200))
    refreshed_at: Mapped[TSNull]


class SuppressionEntry(Base):
    __tablename__ = "suppression_entries"
    __table_args__ = (UniqueConstraint("list_id", "normalized_number"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    list_id: Mapped[uuid.UUID] = fk("suppression_lists.id", nullable=False)
    normalized_number: Mapped[str] = mapped_column(String(32), index=True)
    reason: Mapped[str] = mapped_column(String(200), default="")
    added_at: Mapped[TS]
    expires_at: Mapped[TSNull]


class Campaign(Base, TimestampMixin):
    __tablename__ = "campaigns"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    name: Mapped[str] = mapped_column(String(200))
    purpose: Mapped[str] = mapped_column(String(32))  # service | marketing
    dial_mode: Mapped[str] = mapped_column(String(16), default="preview")  # preview only in this release
    status: Mapped[str] = mapped_column(String(16), default="draft")
    queue_id: Mapped[uuid.UUID] = fk("queues.id", nullable=False)
    jurisdiction: Mapped[str] = mapped_column(String(16), default="GB")
    caller_id_number_id: Mapped[uuid.UUID] = fk("phone_numbers.id", nullable=False)
    max_attempts_per_contact: Mapped[int] = mapped_column(Integer, default=3)
    script_article_id: Mapped[uuid.UUID | None] = fk("knowledge_articles.id")
    description: Mapped[str] = mapped_column(Text, default="")
    created_by: Mapped[uuid.UUID | None] = fk("users.id")
    approved_by: Mapped[uuid.UUID | None] = fk("users.id")
    activated_at: Mapped[TSNull]
    review_summary: Mapped[JSONDict]
    version: Mapped[int] = mapped_column(Integer, default=1)


class CampaignImport(Base, TimestampMixin):
    __tablename__ = "campaign_imports"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    campaign_id: Mapped[uuid.UUID] = fk("campaigns.id", nullable=False)
    filename: Mapped[str] = mapped_column(String(255))
    storage_key: Mapped[str | None] = mapped_column(String(255), nullable=True)
    status: Mapped[str] = mapped_column(String(16), default="queued")  # queued | processing | validated | failed
    total_rows: Mapped[int] = mapped_column(Integer, default=0)
    valid_rows: Mapped[int] = mapped_column(Integer, default=0)
    invalid_rows: Mapped[int] = mapped_column(Integer, default=0)
    errors: Mapped[JSONList]
    uploaded_by: Mapped[uuid.UUID | None] = fk("users.id")
    processed_at: Mapped[TSNull]


class CampaignContact(Base, TimestampMixin):
    __tablename__ = "campaign_contacts"
    __table_args__ = (
        UniqueConstraint("campaign_id", "normalized_number"),
        Index("ix_campaign_contacts_status", "campaign_id", "status"),
    )
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    campaign_id: Mapped[uuid.UUID] = fk("campaigns.id", nullable=False)
    import_id: Mapped[uuid.UUID | None] = fk("campaign_imports.id")
    customer_id: Mapped[uuid.UUID | None] = fk("customers.id")
    display_name: Mapped[str] = mapped_column(String(200))
    normalized_number: Mapped[str] = mapped_column(String(32))
    timezone: Mapped[str] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(16), default="pending")
    # pending | ready | reserved | in_progress | completed | excluded | exhausted
    precheck: Mapped[JSONDict]  # last eligibility result (informational; always re-checked at dial)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    last_attempt_at: Mapped[TSNull]
    last_outcome: Mapped[str | None] = mapped_column(String(64), nullable=True)
    reserved_by_agent_id: Mapped[uuid.UUID | None] = fk("agents.id")
    reserved_at: Mapped[TSNull]
    version: Mapped[int] = mapped_column(Integer, default=1)


class OutboundAttempt(Base):
    """Every attempted (or refused) outbound dial, with the eligibility evidence."""

    __tablename__ = "outbound_attempts"
    __table_args__ = (UniqueConstraint("org_id", "idempotency_key"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    idempotency_key: Mapped[str] = mapped_column(String(128))
    agent_id: Mapped[uuid.UUID | None] = fk("agents.id")
    customer_id: Mapped[uuid.UUID | None] = fk("customers.id")
    campaign_contact_id: Mapped[uuid.UUID | None] = fk("campaign_contacts.id")
    callback_id: Mapped[uuid.UUID | None] = fk("callbacks.id")
    normalized_number: Mapped[str] = mapped_column(String(32), index=True)
    purpose: Mapped[str] = mapped_column(String(32))
    rule_set_id: Mapped[uuid.UUID | None] = fk("calling_rule_sets.id")
    rule_set_version: Mapped[int | None] = mapped_column(Integer, nullable=True)
    eligibility: Mapped[JSONDict]  # {"eligible": bool, "checks": [{"check","passed","detail"}]}
    status: Mapped[str] = mapped_column(String(16))  # refused | dialling | connected | no_answer | failed | busy | unknown
    interaction_id: Mapped[uuid.UUID | None] = fk("interactions.id")
    caller_id_number_id: Mapped[uuid.UUID | None] = fk("phone_numbers.id")
    created_at: Mapped[TS]
    ended_at: Mapped[TSNull]
    note: Mapped[str | None] = mapped_column(Text, nullable=True)
