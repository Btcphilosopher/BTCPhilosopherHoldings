"""Customer records.

Restricted attributes (date of birth, postcode, account security answers) are
kept in ``CustomerSecret`` and are never returned to the browser. Agents
submit the customer's answers and the server returns pass/fail per factor.
"""
from __future__ import annotations

import uuid

from sqlalchemy import Boolean, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from ..db import Base, TimestampMixin
from ._common import JSONDict, JSONList, OrgFK, TS, TSNull, UUIDPK, fk


class Account(Base, TimestampMixin):
    """A customer organisation (business account)."""

    __tablename__ = "accounts"
    __table_args__ = (UniqueConstraint("org_id", "account_ref"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    account_ref: Mapped[str] = mapped_column(String(64))
    name: Mapped[str] = mapped_column(String(200))
    registration_number: Mapped[str | None] = mapped_column(String(64), nullable=True)


class Customer(Base, TimestampMixin):
    __tablename__ = "customers"
    __table_args__ = (UniqueConstraint("org_id", "customer_ref"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    customer_ref: Mapped[str] = mapped_column(String(64))
    account_id: Mapped[uuid.UUID | None] = fk("accounts.id")
    kind: Mapped[str] = mapped_column(String(32), default="person")  # person | organisation_contact
    display_name: Mapped[str] = mapped_column(String(200))
    preferred_language: Mapped[str] = mapped_column(String(16), default="en")
    timezone: Mapped[str] = mapped_column(String(64), default="Europe/London")
    status: Mapped[str] = mapped_column(String(32), default="active")
    # Flags such as "vulnerable_customer_support_plan" shown as labelled cues,
    # never used for routing priority automatically.
    support_flags: Mapped[JSONList]
    version: Mapped[int] = mapped_column(Integer, default=1)


class CustomerSecret(Base):
    """Restricted verification data. Values are stored normalised and hashed."""

    __tablename__ = "customer_secrets"
    __table_args__ = (UniqueConstraint("customer_id", "factor"),)
    id: Mapped[UUIDPK]
    customer_id: Mapped[uuid.UUID] = fk("customers.id", nullable=False)
    factor: Mapped[str] = mapped_column(String(64))  # date_of_birth | postcode | account_last4 | security_word
    value_hash: Mapped[str] = mapped_column(String(255))


class CustomerRestricted(Base):
    """Restricted (but displayable after verification) attributes, e.g. balance, address."""

    __tablename__ = "customer_restricted"
    id: Mapped[UUIDPK]
    customer_id: Mapped[uuid.UUID] = fk("customers.id", nullable=False)
    data: Mapped[JSONDict]


class ContactPoint(Base, TimestampMixin):
    __tablename__ = "contact_points"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    customer_id: Mapped[uuid.UUID] = fk("customers.id", nullable=False)
    kind: Mapped[str] = mapped_column(String(16))  # phone | email | postal
    value: Mapped[str] = mapped_column(String(320))
    normalized: Mapped[str] = mapped_column(String(320), index=True)
    label: Mapped[str] = mapped_column(String(64), default="")
    is_primary: Mapped[bool] = mapped_column(Boolean, default=False)
    verified_at: Mapped[TSNull]
    source: Mapped[str] = mapped_column(String(64), default="crm")


class CommunicationPreference(Base, TimestampMixin):
    __tablename__ = "communication_preferences"
    __table_args__ = (UniqueConstraint("customer_id", "channel", "purpose"),)
    id: Mapped[UUIDPK]
    customer_id: Mapped[uuid.UUID] = fk("customers.id", nullable=False)
    channel: Mapped[str] = mapped_column(String(16))  # phone | email | sms | post
    purpose: Mapped[str] = mapped_column(String(32))  # service | marketing
    allowed: Mapped[bool] = mapped_column(Boolean, default=True)
    preferred_window: Mapped[JSONDict]  # {"start": "09:00", "end": "17:00"}


class Consent(Base):
    __tablename__ = "consents"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    customer_id: Mapped[uuid.UUID] = fk("customers.id", nullable=False)
    purpose: Mapped[str] = mapped_column(String(64))  # marketing_calls | service_calls | recording
    basis: Mapped[str] = mapped_column(String(32))  # consent | contract | legitimate_interest | customer_request
    status: Mapped[str] = mapped_column(String(16))  # granted | withdrawn
    jurisdiction: Mapped[str] = mapped_column(String(16), default="GB")
    source: Mapped[str] = mapped_column(String(64))
    evidence_ref: Mapped[str | None] = mapped_column(String(255), nullable=True)
    captured_at: Mapped[TS]
    withdrawn_at: Mapped[TSNull]


class Objection(Base):
    __tablename__ = "objections"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    customer_id: Mapped[uuid.UUID] = fk("customers.id", nullable=False)
    scope: Mapped[str] = mapped_column(String(64))  # all_marketing | telephone_marketing | all_telephone
    source: Mapped[str] = mapped_column(String(64))
    note: Mapped[str] = mapped_column(Text, default="")
    recorded_at: Mapped[TS]
    recorded_by: Mapped[uuid.UUID | None] = fk("users.id")
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class SourceSystemRef(Base):
    __tablename__ = "source_system_refs"
    __table_args__ = (UniqueConstraint("customer_id", "system"),)
    id: Mapped[UUIDPK]
    customer_id: Mapped[uuid.UUID] = fk("customers.id", nullable=False)
    system: Mapped[str] = mapped_column(String(64))
    external_id: Mapped[str] = mapped_column(String(128))
    synced_at: Mapped[TSNull]


class PossibleDuplicate(Base):
    """Flag that two records may be the same person. Never auto-merged."""

    __tablename__ = "possible_duplicates"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    customer_a_id: Mapped[uuid.UUID] = fk("customers.id", nullable=False)
    customer_b_id: Mapped[uuid.UUID] = fk("customers.id", nullable=False)
    reason: Mapped[str] = mapped_column(Text)
    raised_by: Mapped[uuid.UUID | None] = fk("users.id")
    raised_at: Mapped[TS]
    status: Mapped[str] = mapped_column(String(16), default="open")  # open | not_duplicate | merged_by_backoffice


class VerificationPolicy(Base):
    __tablename__ = "verification_policies"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    name: Mapped[str] = mapped_column(String(200))
    factors: Mapped[JSONList]  # factor codes the agent may ask for
    required_passes: Mapped[int] = mapped_column(Integer, default=2)
    max_failures: Mapped[int] = mapped_column(Integer, default=3)
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class Verification(Base):
    """Per-interaction verification record. Never stores the answers given."""

    __tablename__ = "verifications"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    interaction_id: Mapped[uuid.UUID] = fk("interactions.id", nullable=False)
    customer_id: Mapped[uuid.UUID] = fk("customers.id", nullable=False)
    agent_id: Mapped[uuid.UUID | None] = fk("agents.id")
    policy_id: Mapped[uuid.UUID] = fk("verification_policies.id", nullable=False)
    status: Mapped[str] = mapped_column(String(16), default="in_progress")
    passed_factors: Mapped[JSONList]
    failed_attempts: Mapped[int] = mapped_column(Integer, default=0)
    method: Mapped[str] = mapped_column(String(32), default="knowledge_factors")
    started_at: Mapped[TS]
    completed_at: Mapped[TSNull]
