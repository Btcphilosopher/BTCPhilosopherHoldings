from __future__ import annotations

import uuid
from datetime import datetime
from typing import Annotated, Any

from sqlalchemy import DateTime, ForeignKey, Uuid
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import mapped_column

from ..db import new_id, utcnow

UUIDPK = Annotated[uuid.UUID, mapped_column(Uuid, primary_key=True, default=new_id)]
OrgFK = Annotated[uuid.UUID, mapped_column(Uuid, ForeignKey("organisations.id"), index=True, nullable=False)]
TS = Annotated[datetime, mapped_column(DateTime(timezone=True), nullable=False, default=utcnow)]
TSNull = Annotated[datetime | None, mapped_column(DateTime(timezone=True), nullable=True)]
JSONDict = Annotated[dict[str, Any], mapped_column(JSONB, nullable=False, default=dict)]
JSONList = Annotated[list[Any], mapped_column(JSONB, nullable=False, default=list)]


def fk(target: str, *, nullable: bool = True, index: bool = True, ondelete: str | None = None,
       use_alter: bool = False):
    return mapped_column(Uuid, ForeignKey(target, ondelete=ondelete, use_alter=use_alter), nullable=nullable,
                         index=index)
