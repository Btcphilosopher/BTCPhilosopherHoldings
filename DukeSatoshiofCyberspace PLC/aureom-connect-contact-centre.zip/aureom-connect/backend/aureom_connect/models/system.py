"""Audit trail, idempotency, application events (outbox), background jobs, stored objects."""
from __future__ import annotations

import uuid

from sqlalchemy import BigInteger, Identity, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from ..db import Base
from ._common import JSONDict, OrgFK, TS, TSNull, UUIDPK, fk


class AuditLog(Base):
    """Append-only, hash-chained audit trail (tamper evident, not tamper proof)."""

    __tablename__ = "audit_log"
    __table_args__ = (Index("ix_audit_target", "org_id", "target_type", "target_id"),)
    seq: Mapped[int] = mapped_column(BigInteger, Identity(always=False), primary_key=True)
    org_id: Mapped[uuid.UUID | None] = fk("organisations.id")
    at: Mapped[TS]
    actor_user_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True)
    actor_type: Mapped[str] = mapped_column(String(32))  # user | system | provider | worker
    action: Mapped[str] = mapped_column(String(100), index=True)
    target_type: Mapped[str | None] = mapped_column(String(64), nullable=True)
    target_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    request_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    details: Mapped[JSONDict]  # redacted before storage
    prev_hash: Mapped[str] = mapped_column(String(64))
    hash: Mapped[str] = mapped_column(String(64))


class IdempotencyRecord(Base):
    __tablename__ = "idempotency_records"
    __table_args__ = (UniqueConstraint("org_id", "user_id", "key"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    user_id: Mapped[uuid.UUID] = fk("users.id", nullable=False)
    key: Mapped[str] = mapped_column(String(128))
    method: Mapped[str] = mapped_column(String(8))
    path: Mapped[str] = mapped_column(String(300))
    request_hash: Mapped[str] = mapped_column(String(64))
    status_code: Mapped[int | None] = mapped_column(Integer, nullable=True)
    response_body: Mapped[JSONDict]
    created_at: Mapped[TS]
    completed_at: Mapped[TSNull]


class AppEvent(Base):
    """Outbox for application events delivered over the event WebSocket.

    Sequence ``id`` lets clients resume after reconnect (``since`` cursor).
    Payloads are *signals*; clients re-fetch authoritative state over REST.
    """

    __tablename__ = "app_events"
    __table_args__ = (Index("ix_app_events_org_seq", "org_id", "id"),)
    id: Mapped[int] = mapped_column(BigInteger, Identity(always=False), primary_key=True)
    org_id: Mapped[OrgFK]
    audience: Mapped[str] = mapped_column(String(80))  # org | role:supervisor | agent:<uuid> | interaction:<uuid>
    type: Mapped[str] = mapped_column(String(80))
    payload: Mapped[JSONDict]
    created_at: Mapped[TS]


class Job(Base):
    __tablename__ = "jobs"
    __table_args__ = (Index("ix_jobs_ready", "status", "run_at"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[uuid.UUID | None] = fk("organisations.id")
    kind: Mapped[str] = mapped_column(String(64))
    payload: Mapped[JSONDict]
    status: Mapped[str] = mapped_column(String(16), default="queued")  # queued | running | done | failed
    run_at: Mapped[TS]
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    max_attempts: Mapped[int] = mapped_column(Integer, default=5)
    locked_by: Mapped[str | None] = mapped_column(String(64), nullable=True)
    locked_at: Mapped[TSNull]
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    dedupe_key: Mapped[str | None] = mapped_column(String(128), nullable=True, unique=True)
    finished_at: Mapped[TSNull]


class StoredObject(Base):
    """Metadata for protected objects (recordings, attachments, imports)."""

    __tablename__ = "stored_objects"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    storage_key: Mapped[str] = mapped_column(String(255), unique=True)
    kind: Mapped[str] = mapped_column(String(32))  # recording | attachment | import
    content_type: Mapped[str] = mapped_column(String(100))
    size_bytes: Mapped[int] = mapped_column(BigInteger)
    sha256: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[TS]
    deleted_at: Mapped[TSNull]


class Counter(Base):
    """Per-organisation human reference counters (CASE-10001, CB-1001...)."""

    __tablename__ = "counters"
    __table_args__ = (UniqueConstraint("org_id", "name"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    name: Mapped[str] = mapped_column(String(32))
    value: Mapped[int] = mapped_column(BigInteger, default=0)
