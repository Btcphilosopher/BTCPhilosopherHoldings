"""Interaction, call, leg, participation, queue entry, offer and provider event model.

These are intentionally separate tables:

* ``Interaction``         – one customer contact, end to end (may span transfers).
* ``Call``                – a telephone call known to the provider.
* ``CallLeg``             – one party's connection within a call.
* ``AgentParticipation``  – an agent's involvement in an interaction.
* ``QueueEntry``          – one stay in one queue (overflow creates another entry).
* ``Offer``               – an offer of work to a specific agent.
* ``CallControl``         – a requested control and its *confirmed* outcome.
* ``ProviderEvent``       – raw, verified provider events with provider and ingestion time.
"""
from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import BigInteger, Boolean, DateTime, Integer, String, Text, UniqueConstraint, Index
from sqlalchemy.orm import Mapped, mapped_column

from ..db import Base, TimestampMixin
from ._common import JSONDict, JSONList, OrgFK, TS, TSNull, UUIDPK, fk


class Interaction(Base, TimestampMixin):
    __tablename__ = "interactions"
    __table_args__ = (Index("ix_interactions_org_status", "org_id", "status"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    reference: Mapped[str] = mapped_column(String(32), unique=True)
    channel: Mapped[str] = mapped_column(String(16))
    direction: Mapped[str] = mapped_column(String(16))
    status: Mapped[str] = mapped_column(String(32))
    source: Mapped[str] = mapped_column(String(32))  # provider name | webchat | email | manual
    is_simulated: Mapped[bool] = mapped_column(Boolean, default=False)
    customer_id: Mapped[uuid.UUID | None] = fk("customers.id")
    customer_match_status: Mapped[str] = mapped_column(String(32), default="unmatched")
    match_hint: Mapped[JSONDict]  # e.g. {"ani": "+4411...", "candidates": [...]} — hints only
    current_queue_id: Mapped[uuid.UUID | None] = fk("queues.id")
    owner_agent_id: Mapped[uuid.UUID | None] = fk("agents.id")
    version: Mapped[int] = mapped_column(Integer, default=1)
    language: Mapped[str | None] = mapped_column(String(16), nullable=True)
    required_skills: Mapped[JSONList]
    routing_priority: Mapped[int] = mapped_column(Integer, default=0)
    # Separate, labelled marker (e.g. "safeguarding concern"). Never alters routing priority automatically.
    urgency_flag: Mapped[str | None] = mapped_column(String(64), nullable=True)
    first_queued_at: Mapped[TSNull]
    routable_since: Mapped[TSNull]  # wait clock used for longest-waiting selection
    connected_at: Mapped[TSNull]
    ended_at: Mapped[TSNull]
    wrap_completed_at: Mapped[TSNull]
    disposition_code: Mapped[str | None] = mapped_column(String(64), nullable=True)
    disposition_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    transfer_count: Mapped[int] = mapped_column(Integer, default=0)
    campaign_contact_id: Mapped[uuid.UUID | None] = fk("campaign_contacts.id", use_alter=True)
    callback_id: Mapped[uuid.UUID | None] = fk("callbacks.id", use_alter=True)
    subject: Mapped[str | None] = mapped_column(String(300), nullable=True)
    ivr_path: Mapped[JSONList]
    end_reason: Mapped[str | None] = mapped_column(String(64), nullable=True)
    # Set when a control outcome is unknown or provider state may differ; cleared by reconciliation.
    needs_reconciliation: Mapped[bool] = mapped_column(Boolean, default=False)
    transfer_state: Mapped[JSONDict]  # {"status": "consulting|failed|completed", "target_agent_id", "consult_leg_id", ...}


class InteractionEvent(Base):
    """Human-readable, append-only timeline for an interaction."""

    __tablename__ = "interaction_events"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    interaction_id: Mapped[uuid.UUID] = fk("interactions.id", nullable=False)
    type: Mapped[str] = mapped_column(String(64))
    source: Mapped[str] = mapped_column(String(32))  # provider | agent | system | supervisor | customer
    actor_user_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True)
    occurred_at: Mapped[TS]  # event time (provider time if from provider)
    recorded_at: Mapped[TS]  # ingestion time
    data: Mapped[JSONDict]


class Call(Base, TimestampMixin):
    __tablename__ = "calls"
    __table_args__ = (UniqueConstraint("provider", "provider_call_id"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    interaction_id: Mapped[uuid.UUID] = fk("interactions.id", nullable=False)
    provider: Mapped[str] = mapped_column(String(32))
    provider_call_id: Mapped[str] = mapped_column(String(128))
    direction: Mapped[str] = mapped_column(String(16))
    from_number: Mapped[str] = mapped_column(String(32))
    to_number: Mapped[str] = mapped_column(String(32))
    status: Mapped[str] = mapped_column(String(32), default="initiated")
    last_provider_sequence: Mapped[int] = mapped_column(BigInteger, default=0)
    last_provider_event_at: Mapped[TSNull]
    started_at: Mapped[TSNull]
    answered_at: Mapped[TSNull]
    ended_at: Mapped[TSNull]
    end_reason: Mapped[str | None] = mapped_column(String(64), nullable=True)
    caller_id_number_id: Mapped[uuid.UUID | None] = fk("phone_numbers.id")


class CallLeg(Base, TimestampMixin):
    __tablename__ = "call_legs"
    __table_args__ = (UniqueConstraint("call_id", "provider_leg_id"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    call_id: Mapped[uuid.UUID] = fk("calls.id", nullable=False)
    provider_leg_id: Mapped[str] = mapped_column(String(128))
    leg_type: Mapped[str] = mapped_column(String(32))  # customer | agent | consult | external
    agent_id: Mapped[uuid.UUID | None] = fk("agents.id")
    external_number: Mapped[str | None] = mapped_column(String(32), nullable=True)
    status: Mapped[str] = mapped_column(String(32), default="initiated")
    on_hold: Mapped[bool] = mapped_column(Boolean, default=False)
    # Provider-side mute confirmed by provider (distinct from browser microphone mute).
    provider_muted: Mapped[bool] = mapped_column(Boolean, default=False)
    started_at: Mapped[TSNull]
    answered_at: Mapped[TSNull]
    ended_at: Mapped[TSNull]
    hold_started_at: Mapped[TSNull]
    hold_seconds_total: Mapped[int] = mapped_column(Integer, default=0)
    last_sequence: Mapped[int] = mapped_column(BigInteger, default=0)
    end_reason: Mapped[str | None] = mapped_column(String(64), nullable=True)


class AgentParticipation(Base, TimestampMixin):
    __tablename__ = "agent_participations"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    interaction_id: Mapped[uuid.UUID] = fk("interactions.id", nullable=False)
    agent_id: Mapped[uuid.UUID] = fk("agents.id", nullable=False)
    role: Mapped[str] = mapped_column(String(32))  # primary | consult | transfer_receiver | conference | monitor
    leg_id: Mapped[uuid.UUID | None] = fk("call_legs.id")
    accepted_at: Mapped[TSNull]
    connected_at: Mapped[TSNull]
    ended_at: Mapped[TSNull]
    wrap_started_at: Mapped[TSNull]
    wrap_ended_at: Mapped[TSNull]
    hold_seconds: Mapped[int] = mapped_column(Integer, default=0)
    outcome: Mapped[str | None] = mapped_column(String(32), nullable=True)  # handled | transferred_out | consult_only | failed


class QueueEntry(Base):
    __tablename__ = "queue_entries"
    __table_args__ = (Index("ix_queue_entries_open", "queue_id", "left_at"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    interaction_id: Mapped[uuid.UUID] = fk("interactions.id", nullable=False)
    queue_id: Mapped[uuid.UUID] = fk("queues.id", nullable=False)
    sequence: Mapped[int] = mapped_column(Integer, default=1)  # 1 = first queue for the interaction
    entered_at: Mapped[TS]
    left_at: Mapped[TSNull]
    exit_reason: Mapped[str | None] = mapped_column(String(32), nullable=True)
    # answered | abandoned | overflow | voicemail | callback | transferred | closed | failed
    offers_made: Mapped[int] = mapped_column(Integer, default=0)


class Offer(Base):
    __tablename__ = "offers"
    __table_args__ = (Index("ix_offers_pending", "status", "expires_at"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    interaction_id: Mapped[uuid.UUID] = fk("interactions.id", nullable=False)
    agent_id: Mapped[uuid.UUID] = fk("agents.id", nullable=False)
    queue_entry_id: Mapped[uuid.UUID | None] = fk("queue_entries.id")
    kind: Mapped[str] = mapped_column(String(32), default="queue")  # queue | consult | callback
    status: Mapped[str] = mapped_column(String(16), default="pending")
    offered_at: Mapped[TS]
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    responded_at: Mapped[TSNull]
    response_reason: Mapped[str | None] = mapped_column(String(64), nullable=True)
    routing_decision_id: Mapped[uuid.UUID | None] = fk("routing_decisions.id")


class RoutingDecision(Base):
    """Transparent record of each routing evaluation, including why agents were excluded."""

    __tablename__ = "routing_decisions"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    interaction_id: Mapped[uuid.UUID] = fk("interactions.id", nullable=False)
    queue_id: Mapped[uuid.UUID | None] = fk("queues.id")
    decided_at: Mapped[TS]
    outcome: Mapped[str] = mapped_column(String(32))  # offered | no_eligible_agent | queue_closed | overflowed
    selected_agent_id: Mapped[uuid.UUID | None] = fk("agents.id")
    candidates: Mapped[JSONList]  # [{"agent_id", "eligible", "reasons": [...], "idle_seconds"}]
    explanation: Mapped[str] = mapped_column(Text, default="")


class CallControl(Base):
    __tablename__ = "call_controls"
    __table_args__ = (UniqueConstraint("org_id", "idempotency_key"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    interaction_id: Mapped[uuid.UUID] = fk("interactions.id", nullable=False)
    call_id: Mapped[uuid.UUID | None] = fk("calls.id")
    leg_id: Mapped[uuid.UUID | None] = fk("call_legs.id")
    agent_id: Mapped[uuid.UUID | None] = fk("agents.id")
    action: Mapped[str] = mapped_column(String(32))
    params: Mapped[JSONDict]
    idempotency_key: Mapped[str] = mapped_column(String(128))
    status: Mapped[str] = mapped_column(String(16), default="requested")
    provider_request_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    requested_at: Mapped[TS]
    acknowledged_at: Mapped[TSNull]
    resolved_by: Mapped[str | None] = mapped_column(String(32), nullable=True)  # provider_event | reconciliation | timeout
    error_code: Mapped[str | None] = mapped_column(String(64), nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)


class ProviderEvent(Base):
    __tablename__ = "provider_events"
    __table_args__ = (
        UniqueConstraint("provider", "provider_event_id"),
        Index("ix_provider_events_call", "provider", "provider_call_id", "sequence"),
    )
    id: Mapped[UUIDPK]
    org_id: Mapped[uuid.UUID | None] = fk("organisations.id")
    provider: Mapped[str] = mapped_column(String(32))
    provider_event_id: Mapped[str] = mapped_column(String(128))
    event_type: Mapped[str] = mapped_column(String(64))
    provider_call_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    provider_leg_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    sequence: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))  # provider event time
    received_at: Mapped[TS]  # ingestion time
    signature_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    payload: Mapped[JSONDict]
    processing_status: Mapped[str] = mapped_column(String(32), default="received")
    # received | applied | stale_ignored | duplicate | gap_detected | unmatched | error
    processing_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    duplicate_count: Mapped[int] = mapped_column(Integer, default=0)


class Recording(Base, TimestampMixin):
    __tablename__ = "recordings"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    interaction_id: Mapped[uuid.UUID] = fk("interactions.id", nullable=False)
    call_id: Mapped[uuid.UUID | None] = fk("calls.id")
    policy_id: Mapped[uuid.UUID | None] = fk("recording_policies.id")
    policy_version: Mapped[int | None] = mapped_column(Integer, nullable=True)
    provider_recording_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    purpose: Mapped[str] = mapped_column(String(64))
    jurisdiction: Mapped[str] = mapped_column(String(16))
    status: Mapped[str] = mapped_column(String(32), default="requested")
    notice_played_confirmed: Mapped[bool] = mapped_column(Boolean, default=False)
    consent_status: Mapped[str] = mapped_column(String(32), default="not_required")  # not_required | pending | given | refused
    access_roles: Mapped[JSONList]
    started_at: Mapped[TSNull]
    ended_at: Mapped[TSNull]
    pause_intervals: Mapped[JSONList]  # [{"start","end","reason"}]
    storage_key: Mapped[str | None] = mapped_column(String(255), nullable=True)
    content_type: Mapped[str | None] = mapped_column(String(64), nullable=True)
    is_synthetic_media: Mapped[bool] = mapped_column(Boolean, default=False)
    retention_until: Mapped[TSNull]
    legal_hold: Mapped[bool] = mapped_column(Boolean, default=False)
    deletion_status: Mapped[str] = mapped_column(String(32), default="retained")  # retained | scheduled | deleted | failed
    deleted_at: Mapped[TSNull]


class Transcript(Base, TimestampMixin):
    """Machine (or human) transcript. Original segments are immutable."""

    __tablename__ = "transcripts"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    interaction_id: Mapped[uuid.UUID] = fk("interactions.id", nullable=False)
    recording_id: Mapped[uuid.UUID | None] = fk("recordings.id")
    provenance: Mapped[JSONDict]  # {"engine","engine_version","generated_at","simulated":bool}
    source: Mapped[str] = mapped_column(String(16), default="machine")
    segments: Mapped[JSONList]  # [{"i","speaker","start","end","text","confidence"}]
    language: Mapped[str] = mapped_column(String(16), default="en")


class TranscriptCorrection(Base):
    __tablename__ = "transcript_corrections"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    transcript_id: Mapped[uuid.UUID] = fk("transcripts.id", nullable=False)
    segment_index: Mapped[int] = mapped_column(Integer)
    original_text: Mapped[str] = mapped_column(Text)
    corrected_text: Mapped[str] = mapped_column(Text)
    reason: Mapped[str] = mapped_column(Text)
    corrected_by: Mapped[uuid.UUID] = fk("users.id", nullable=False)
    corrected_at: Mapped[TS]


class SecurePaymentSession(Base):
    """Provider-hosted payment capture. The application never sees card data."""

    __tablename__ = "secure_payment_sessions"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    interaction_id: Mapped[uuid.UUID] = fk("interactions.id", nullable=False)
    provider_session_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    amount_minor: Mapped[int] = mapped_column(Integer)
    currency: Mapped[str] = mapped_column(String(3), default="GBP")
    status: Mapped[str] = mapped_column(String(32), default="requested")
    recording_paused_confirmed: Mapped[bool] = mapped_column(Boolean, default=False)
    result_reference: Mapped[str | None] = mapped_column(String(128), nullable=True)
    started_at: Mapped[TS]
    ended_at: Mapped[TSNull]


class MonitoringSession(Base):
    """Supervisor listen/coach/barge. Permissioned, audited and visible to the agent."""

    __tablename__ = "monitoring_sessions"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    interaction_id: Mapped[uuid.UUID] = fk("interactions.id", nullable=False)
    supervisor_user_id: Mapped[uuid.UUID] = fk("users.id", nullable=False)
    agent_id: Mapped[uuid.UUID] = fk("agents.id", nullable=False)
    mode: Mapped[str] = mapped_column(String(16))  # listen | coach | barge
    reason: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(16), default="requested")
    agent_notified: Mapped[bool] = mapped_column(Boolean, default=True)
    provider_leg_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    started_at: Mapped[TS]
    ended_at: Mapped[TSNull]


class ChatMessage(Base):
    """Messages for chat and email interactions (customer content is untrusted)."""

    __tablename__ = "chat_messages"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    interaction_id: Mapped[uuid.UUID] = fk("interactions.id", nullable=False)
    sender: Mapped[str] = mapped_column(String(16))  # customer | agent | system
    agent_id: Mapped[uuid.UUID | None] = fk("agents.id")
    body: Mapped[str] = mapped_column(Text)
    subject: Mapped[str | None] = mapped_column(String(300), nullable=True)
    sent_at: Mapped[TS]
    channel_message_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    attachments: Mapped[JSONList]


class Feedback(Base):
    """Post-contact customer feedback (survey)."""

    __tablename__ = "feedback"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    interaction_id: Mapped[uuid.UUID] = fk("interactions.id", nullable=False)
    score: Mapped[int] = mapped_column(Integer)  # 1..5
    comment: Mapped[str | None] = mapped_column(Text, nullable=True)
    received_at: Mapped[TS]
    channel: Mapped[str] = mapped_column(String(16), default="ivr_survey")
