"""Versioned knowledge base."""
from __future__ import annotations

import uuid

from sqlalchemy import Computed, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import TSVECTOR
from sqlalchemy.orm import Mapped, mapped_column

from ..db import Base, TimestampMixin
from ._common import JSONList, OrgFK, TSNull, UUIDPK, fk


class KnowledgeArticle(Base, TimestampMixin):
    __tablename__ = "knowledge_articles"
    __table_args__ = (UniqueConstraint("org_id", "slug"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    slug: Mapped[str] = mapped_column(String(120))
    owner_user_id: Mapped[uuid.UUID | None] = fk("users.id")
    owner_team: Mapped[str] = mapped_column(String(100), default="")
    visibility: Mapped[str] = mapped_column(String(32), default="internal")  # internal | customer_visible
    current_version_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True)


class KnowledgeVersion(Base, TimestampMixin):
    __tablename__ = "knowledge_versions"
    __table_args__ = (
        UniqueConstraint("article_id", "version"),
        Index("ix_knowledge_versions_search", "search_vector", postgresql_using="gin"),
    )
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    article_id: Mapped[uuid.UUID] = fk("knowledge_articles.id", nullable=False)
    version: Mapped[int] = mapped_column(Integer)
    title: Mapped[str] = mapped_column(String(300))
    summary: Mapped[str] = mapped_column(Text, default="")
    body: Mapped[str] = mapped_column(Text)
    tags: Mapped[JSONList]
    status: Mapped[str] = mapped_column(String(16), default="draft")  # draft | in_review | approved | retired
    effective_from: Mapped[TSNull]
    effective_to: Mapped[TSNull]
    review_due_at: Mapped[TSNull]
    authored_by: Mapped[uuid.UUID | None] = fk("users.id")
    reviewed_by: Mapped[uuid.UUID | None] = fk("users.id")
    approved_at: Mapped[TSNull]
    change_note: Mapped[str] = mapped_column(Text, default="")
    search_vector = mapped_column(
        TSVECTOR,
        Computed(
            "setweight(to_tsvector('english', coalesce(title, '')), 'A') || "
            "setweight(to_tsvector('english', coalesce(summary, '')), 'B') || "
            "setweight(to_tsvector('english', coalesce(body, '')), 'C')",
            persisted=True,
        ),
    )
