"""Cases, tasks, outcomes, SLAs, messages, callbacks and summaries."""
from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from ..db import Base, TimestampMixin
from ._common import JSONDict, JSONList, OrgFK, TS, TSNull, UUIDPK, fk


class SlaPolicy(Base, TimestampMixin):
    """Service-level target.

    ``kind`` distinguishes an *internal target* from a *contractual commitment*;
    reports label them differently and only contractual ones cite ``contract_ref``.
    """

    __tablename__ = "sla_policies"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    name: Mapped[str] = mapped_column(String(200))
    applies_to: Mapped[str] = mapped_column(String(32))  # queue_answer | case_resolution | task_completion | callback
    target_seconds: Mapped[int] = mapped_column(Integer)
    target_percent: Mapped[int | None] = mapped_column(Integer, nullable=True)
    kind: Mapped[str] = mapped_column(String(32), default="internal_target")  # internal_target | contractual_commitment
    contract_ref: Mapped[str | None] = mapped_column(String(200), nullable=True)
    business_hours_only: Mapped[bool] = mapped_column(Boolean, default=False)


class OutcomeCode(Base):
    __tablename__ = "outcome_codes"
    __table_args__ = (UniqueConstraint("org_id", "code"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    code: Mapped[str] = mapped_column(String(64))
    label: Mapped[str] = mapped_column(String(200))
    category: Mapped[str] = mapped_column(String(64))
    applies_to: Mapped[JSONList]  # ["interaction", "case", "outbound"]
    requires_follow_up: Mapped[bool] = mapped_column(Boolean, default=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class Case(Base, TimestampMixin):
    __tablename__ = "cases"
    __table_args__ = (UniqueConstraint("org_id", "case_ref"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    case_ref: Mapped[str] = mapped_column(String(32))
    customer_id: Mapped[uuid.UUID | None] = fk("customers.id")
    title: Mapped[str] = mapped_column(String(300))
    category: Mapped[str] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(32), default="open")
    priority: Mapped[str] = mapped_column(String(16), default="normal")  # low | normal | high
    owner_agent_id: Mapped[uuid.UUID | None] = fk("agents.id")
    owner_queue_id: Mapped[uuid.UUID | None] = fk("queues.id")
    sla_policy_id: Mapped[uuid.UUID | None] = fk("sla_policies.id")
    due_at: Mapped[TSNull]
    escalation_level: Mapped[int] = mapped_column(Integer, default=0)
    outcome_code: Mapped[str | None] = mapped_column(String(64), nullable=True)
    resolution_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    resolved_at: Mapped[TSNull]
    resolved_by: Mapped[uuid.UUID | None] = fk("users.id")
    closed_at: Mapped[TSNull]
    reopen_count: Mapped[int] = mapped_column(Integer, default=0)
    version: Mapped[int] = mapped_column(Integer, default=1)
    created_by: Mapped[uuid.UUID | None] = fk("users.id")


class CaseEvent(Base):
    __tablename__ = "case_events"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    case_id: Mapped[uuid.UUID] = fk("cases.id", nullable=False)
    type: Mapped[str] = mapped_column(String(64))
    actor_user_id: Mapped[uuid.UUID | None] = fk("users.id")
    at: Mapped[TS]
    data: Mapped[JSONDict]


class CaseNote(Base):
    __tablename__ = "case_notes"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    case_id: Mapped[uuid.UUID] = fk("cases.id", nullable=False)
    author_user_id: Mapped[uuid.UUID] = fk("users.id", nullable=False)
    body: Mapped[str] = mapped_column(Text)
    visibility: Mapped[str] = mapped_column(String(16), default="internal")
    interaction_id: Mapped[uuid.UUID | None] = fk("interactions.id")
    created_at: Mapped[TS]


class CaseInteraction(Base):
    __tablename__ = "case_interactions"
    __table_args__ = (UniqueConstraint("case_id", "interaction_id"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    case_id: Mapped[uuid.UUID] = fk("cases.id", nullable=False)
    interaction_id: Mapped[uuid.UUID] = fk("interactions.id", nullable=False)
    link_type: Mapped[str] = mapped_column(String(32), default="related")  # origin | related | follow_up
    linked_by: Mapped[uuid.UUID | None] = fk("users.id")
    linked_at: Mapped[TS]


class Task(Base, TimestampMixin):
    __tablename__ = "tasks"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    kind: Mapped[str] = mapped_column(String(32), default="follow_up")  # follow_up | back_office | duplicate_review | callback_prep
    title: Mapped[str] = mapped_column(String(300))
    description: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(16), default="open")
    priority: Mapped[str] = mapped_column(String(16), default="normal")
    case_id: Mapped[uuid.UUID | None] = fk("cases.id")
    interaction_id: Mapped[uuid.UUID | None] = fk("interactions.id")
    customer_id: Mapped[uuid.UUID | None] = fk("customers.id")
    assignee_agent_id: Mapped[uuid.UUID | None] = fk("agents.id")
    assignee_queue_id: Mapped[uuid.UUID | None] = fk("queues.id")
    due_at: Mapped[TSNull]
    sla_policy_id: Mapped[uuid.UUID | None] = fk("sla_policies.id")
    created_by: Mapped[uuid.UUID | None] = fk("users.id")
    completed_at: Mapped[TSNull]
    completed_by: Mapped[uuid.UUID | None] = fk("users.id")
    completion_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    version: Mapped[int] = mapped_column(Integer, default=1)


class MessageTemplate(Base, TimestampMixin):
    __tablename__ = "message_templates"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    code: Mapped[str] = mapped_column(String(64))
    name: Mapped[str] = mapped_column(String(200))
    channel: Mapped[str] = mapped_column(String(16))  # email | sms
    subject: Mapped[str] = mapped_column(String(300), default="")
    body: Mapped[str] = mapped_column(Text)
    placeholders: Mapped[JSONList]
    approved: Mapped[bool] = mapped_column(Boolean, default=False)
    approved_by: Mapped[uuid.UUID | None] = fk("users.id")
    version: Mapped[int] = mapped_column(Integer, default=1)


class OutboundMessage(Base, TimestampMixin):
    __tablename__ = "outbound_messages"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    customer_id: Mapped[uuid.UUID | None] = fk("customers.id")
    interaction_id: Mapped[uuid.UUID | None] = fk("interactions.id")
    case_id: Mapped[uuid.UUID | None] = fk("cases.id")
    template_id: Mapped[uuid.UUID | None] = fk("message_templates.id")
    template_version: Mapped[int | None] = mapped_column(Integer, nullable=True)
    channel: Mapped[str] = mapped_column(String(16))
    to_address: Mapped[str] = mapped_column(String(320))
    subject: Mapped[str] = mapped_column(String(300), default="")
    body: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(32), default="draft")  # draft | queued | sent | captured_not_sent | failed
    drafted_by: Mapped[str] = mapped_column(String(16), default="agent")  # agent | ai
    ai_suggestion_id: Mapped[uuid.UUID | None] = fk("ai_suggestions.id")
    reviewed_by: Mapped[uuid.UUID | None] = fk("users.id")
    reviewed_at: Mapped[TSNull]
    sent_at: Mapped[TSNull]
    channel_message_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)


class Callback(Base, TimestampMixin):
    __tablename__ = "callbacks"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    reference: Mapped[str] = mapped_column(String(32), unique=True)
    customer_id: Mapped[uuid.UUID | None] = fk("customers.id")
    origin_interaction_id: Mapped[uuid.UUID | None] = fk("interactions.id")
    phone_number: Mapped[str] = mapped_column(String(32))
    number_confirmed: Mapped[bool] = mapped_column(Boolean, default=False)
    number_confirmation_method: Mapped[str | None] = mapped_column(String(32), nullable=True)  # ani_match | customer_confirmed | verified_contact_point
    window_start: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    window_end: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    timezone: Mapped[str] = mapped_column(String(64), default="Europe/London")
    queue_id: Mapped[uuid.UUID] = fk("queues.id", nullable=False)
    required_skills: Mapped[JSONList]
    language: Mapped[str | None] = mapped_column(String(16), nullable=True)
    reason: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(16), default="pending")
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    max_attempts: Mapped[int] = mapped_column(Integer, default=3)
    # No exact time is promised unless capacity was actually reserved.
    capacity_reserved: Mapped[bool] = mapped_column(Boolean, default=False)
    reserved_slot_start: Mapped[TSNull]
    promise_text: Mapped[str] = mapped_column(Text, default="")
    owner_agent_id: Mapped[uuid.UUID | None] = fk("agents.id")
    owner_since: Mapped[TSNull]
    version: Mapped[int] = mapped_column(Integer, default=1)
    cancelled_reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    completed_at: Mapped[TSNull]
    created_by: Mapped[uuid.UUID | None] = fk("users.id")
    created_via: Mapped[str] = mapped_column(String(32), default="agent")  # agent | ivr | web


class CallbackAttempt(Base):
    __tablename__ = "callback_attempts"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    callback_id: Mapped[uuid.UUID] = fk("callbacks.id", nullable=False)
    attempt_number: Mapped[int] = mapped_column(Integer)
    agent_id: Mapped[uuid.UUID | None] = fk("agents.id")
    interaction_id: Mapped[uuid.UUID | None] = fk("interactions.id")
    started_at: Mapped[TS]
    ended_at: Mapped[TSNull]
    result: Mapped[str | None] = mapped_column(String(32), nullable=True)  # connected | no_answer | busy | voicemail | failed | wrong_party
    note: Mapped[str | None] = mapped_column(Text, nullable=True)


class InteractionSummary(Base):
    """Authoritative summary. Only saved after explicit agent review."""

    __tablename__ = "interaction_summaries"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    interaction_id: Mapped[uuid.UUID] = fk("interactions.id", nullable=False)
    body: Mapped[str] = mapped_column(Text)
    source: Mapped[str] = mapped_column(String(32))  # agent_written | ai_draft_reviewed
    ai_suggestion_id: Mapped[uuid.UUID | None] = fk("ai_suggestions.id")
    authored_by: Mapped[uuid.UUID] = fk("users.id", nullable=False)
    reviewed_at: Mapped[TS]
    supersedes_id: Mapped[uuid.UUID | None] = fk("interaction_summaries.id")


class AiSuggestion(Base):
    """Every AI output is a *proposal* with sources and uncertainty; nothing is authoritative."""

    __tablename__ = "ai_suggestions"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    interaction_id: Mapped[uuid.UUID | None] = fk("interactions.id")
    case_id: Mapped[uuid.UUID | None] = fk("cases.id")
    kind: Mapped[str] = mapped_column(String(32))  # article_suggestion | summary_draft | message_draft | case_classification
    provider: Mapped[str] = mapped_column(String(32))
    model: Mapped[str] = mapped_column(String(64))
    output: Mapped[JSONDict]
    sources: Mapped[JSONList]
    uncertainty: Mapped[JSONDict]  # {"confidence": 0..1, "notes": [...]}
    safety_flags: Mapped[JSONList]  # e.g. ["untrusted_input_contains_instructions"]
    status: Mapped[str] = mapped_column(String(16), default="proposed")
    requested_by: Mapped[uuid.UUID | None] = fk("users.id")
    reviewed_by: Mapped[uuid.UUID | None] = fk("users.id")
    reviewed_at: Mapped[TSNull]
    created_at: Mapped[TS]
