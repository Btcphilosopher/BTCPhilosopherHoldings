"""Quality assurance: documented rubrics and reviewable evaluations."""
from __future__ import annotations

import uuid

from sqlalchemy import Boolean, Float, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from ..db import Base, TimestampMixin
from ._common import JSONDict, JSONList, OrgFK, TSNull, UUIDPK, fk


class QaRubric(Base, TimestampMixin):
    """``criteria`` = [{"id","label","description","weight","scale":[0,1,2],"guidance":{score: text}}]."""

    __tablename__ = "qa_rubrics"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    name: Mapped[str] = mapped_column(String(200))
    version: Mapped[int] = mapped_column(Integer, default=1)
    status: Mapped[str] = mapped_column(String(16), default="active")
    criteria: Mapped[JSONList]
    documentation: Mapped[str] = mapped_column(Text, default="")


class QaReview(Base, TimestampMixin):
    __tablename__ = "qa_reviews"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    interaction_id: Mapped[uuid.UUID] = fk("interactions.id", nullable=False)
    agent_id: Mapped[uuid.UUID] = fk("agents.id", nullable=False)
    rubric_id: Mapped[uuid.UUID] = fk("qa_rubrics.id", nullable=False)
    rubric_version: Mapped[int] = mapped_column(Integer)
    reviewer_user_id: Mapped[uuid.UUID | None] = fk("users.id")
    status: Mapped[str] = mapped_column(String(16), default="queued")
    # queued | in_progress | submitted | acknowledged | disputed | revised
    selection_reason: Mapped[str] = mapped_column(String(64), default="random_sample")
    scores: Mapped[JSONDict]  # {criterion_id: {"score": n, "evidence": "..."}}
    total_percent: Mapped[float | None] = mapped_column(Float, nullable=True)
    comments: Mapped[str] = mapped_column(Text, default="")
    ai_assisted: Mapped[bool] = mapped_column(Boolean, default=False)  # never auto-scored
    submitted_at: Mapped[TSNull]
    agent_acknowledged_at: Mapped[TSNull]
    dispute_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    history: Mapped[JSONList]
