"""Enumerations shared by models, services and API schemas.

Stored as plain strings so that migrations stay simple and new values can be
added without a database enum migration. Services validate transitions.
"""
from enum import StrEnum


class Role(StrEnum):
    AGENT = "agent"
    SUPERVISOR = "supervisor"
    QUALITY_REVIEWER = "quality_reviewer"
    WORKFORCE_MANAGER = "workforce_manager"
    COMPLIANCE_OFFICER = "compliance_officer"
    KNOWLEDGE_EDITOR = "knowledge_editor"
    ADMIN = "admin"


class AgentState(StrEnum):
    OFFLINE = "offline"
    AVAILABLE = "available"
    CALL_OFFERED = "call_offered"
    CONNECTING = "connecting"
    ON_INTERACTION = "on_interaction"
    AFTER_CALL_WORK = "after_call_work"
    BREAK = "break"
    UNAVAILABLE = "unavailable"


class Presence(StrEnum):
    ONLINE = "online"
    OFFLINE = "offline"


class TelephonyRegistration(StrEnum):
    REGISTERED = "registered"
    UNREGISTERED = "unregistered"
    UNKNOWN = "unknown"


class Channel(StrEnum):
    VOICE = "voice"
    EMAIL = "email"
    CHAT = "chat"


class Direction(StrEnum):
    INBOUND = "inbound"
    OUTBOUND = "outbound"


class InteractionStatus(StrEnum):
    IVR = "ivr"
    QUEUED = "queued"
    OFFERED = "offered"
    CONNECTING = "connecting"
    ACTIVE = "active"
    WRAP_UP = "wrap_up"
    COMPLETED = "completed"
    ABANDONED = "abandoned"
    VOICEMAIL = "voicemail"
    CALLBACK_REQUESTED = "callback_requested"
    FAILED = "failed"


class CustomerMatchStatus(StrEnum):
    UNMATCHED = "unmatched"
    CANDIDATES = "candidates"  # one or more possible matches, none confirmed
    SELECTED_UNVERIFIED = "selected_unverified"
    VERIFIED = "verified"


class VerificationStatus(StrEnum):
    UNVERIFIED = "unverified"
    IN_PROGRESS = "in_progress"
    VERIFIED = "verified"
    FAILED = "failed"
    LOCKED = "locked"


class OfferStatus(StrEnum):
    PENDING = "pending"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    EXPIRED = "expired"
    WITHDRAWN = "withdrawn"


class ControlStatus(StrEnum):
    REQUESTED = "requested"
    ACKNOWLEDGED = "acknowledged"
    FAILED = "failed"
    UNKNOWN = "unknown"


class ControlAction(StrEnum):
    ANSWER = "answer"
    REJECT = "reject"
    MUTE = "mute"
    UNMUTE = "unmute"
    HOLD = "hold"
    RESUME = "resume"
    WARM_TRANSFER_START = "warm_transfer_start"
    WARM_TRANSFER_COMPLETE = "warm_transfer_complete"
    WARM_TRANSFER_CANCEL = "warm_transfer_cancel"
    BLIND_TRANSFER = "blind_transfer"
    CONFERENCE = "conference"
    END = "end"
    START_SECURE_PAYMENT = "start_secure_payment"


class LegStatus(StrEnum):
    INITIATED = "initiated"
    RINGING = "ringing"
    ANSWERED = "answered"
    HELD = "held"
    COMPLETED = "completed"
    FAILED = "failed"
    NO_ANSWER = "no_answer"
    BUSY = "busy"
    REJECTED = "rejected"


class RecordingStatus(StrEnum):
    NOT_RECORDING = "not_recording"
    REQUESTED = "requested"
    ACTIVE = "active"  # only after provider confirmation
    PAUSED = "paused"
    STOPPED = "stopped"
    AVAILABLE = "available"
    FAILED = "failed"
    DELETED = "deleted"


class CaseStatus(StrEnum):
    OPEN = "open"
    PENDING_CUSTOMER = "pending_customer"
    PENDING_INTERNAL = "pending_internal"
    RESOLVED = "resolved"
    CLOSED = "closed"


class TaskStatus(StrEnum):
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    DONE = "done"
    CANCELLED = "cancelled"


class CallbackStatus(StrEnum):
    PENDING = "pending"  # waiting for window
    READY = "ready"  # routable
    OFFERED = "offered"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    EXHAUSTED = "exhausted"  # attempt limit reached
    EXPIRED = "expired"


class CampaignStatus(StrEnum):
    DRAFT = "draft"
    IMPORTING = "importing"
    REVIEW = "review"
    ACTIVE = "active"
    PAUSED = "paused"
    COMPLETED = "completed"


class ScheduleStatus(StrEnum):
    DRAFT = "draft"
    PUBLISHED = "published"
    SUPERSEDED = "superseded"


class SuggestionStatus(StrEnum):
    PROPOSED = "proposed"
    ACCEPTED = "accepted"
    EDITED = "edited"
    REJECTED = "rejected"
