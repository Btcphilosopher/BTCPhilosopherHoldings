"""Routing configuration: hours, holidays, queues, IVR, entry points, recording policy."""
from __future__ import annotations

import uuid
from datetime import date

from sqlalchemy import Boolean, Date, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from ..db import Base, TimestampMixin
from ._common import JSONDict, JSONList, OrgFK, TSNull, UUIDPK, fk


class BusinessHours(Base, TimestampMixin):
    """Weekly opening hours.

    ``weekly`` maps ISO weekday (``"1"`` = Monday) to a list of
    ``["HH:MM", "HH:MM"]`` open intervals in ``timezone``.
    """

    __tablename__ = "business_hours"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    name: Mapped[str] = mapped_column(String(200))
    timezone: Mapped[str] = mapped_column(String(64))
    weekly: Mapped[JSONDict]


class Holiday(Base):
    __tablename__ = "holidays"
    __table_args__ = (UniqueConstraint("business_hours_id", "day"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    business_hours_id: Mapped[uuid.UUID] = fk("business_hours.id", nullable=False)
    day: Mapped[date] = mapped_column(Date)
    name: Mapped[str] = mapped_column(String(200))
    # Optional reduced hours for the day; empty list means closed all day.
    intervals: Mapped[JSONList]


class RecordingPolicy(Base, TimestampMixin):
    """Recording behaviour by purpose and jurisdiction.

    mode: ``off`` | ``notify_and_record`` | ``consent_required``.
    The policy expresses *intent*; whether recording is actually running is
    only known from provider confirmation (see ``Recording.status``).
    """

    __tablename__ = "recording_policies"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    name: Mapped[str] = mapped_column(String(200))
    jurisdiction: Mapped[str] = mapped_column(String(16))
    purpose: Mapped[str] = mapped_column(String(64))  # quality_training | regulatory | dispute_resolution
    mode: Mapped[str] = mapped_column(String(32), default="notify_and_record")
    notice_text: Mapped[str] = mapped_column(Text, default="")
    retention_days: Mapped[int] = mapped_column(Integer, default=90)
    access_roles: Mapped[JSONList]  # roles allowed to listen (with recording.access permission)
    pause_for_payment: Mapped[bool] = mapped_column(Boolean, default=True)
    version: Mapped[int] = mapped_column(Integer, default=1)


class Queue(Base, TimestampMixin):
    __tablename__ = "queues"
    __table_args__ = (UniqueConstraint("org_id", "code"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    code: Mapped[str] = mapped_column(String(64))
    name: Mapped[str] = mapped_column(String(200))
    channel: Mapped[str] = mapped_column(String(16), default="voice")
    # Routing priority: higher is routed first. This is an *operational*
    # ordering only and is separate from any safeguarding/clinical/legal
    # urgency marker on an interaction.
    routing_priority: Mapped[int] = mapped_column(Integer, default=5)
    required_skills: Mapped[JSONList]
    required_language: Mapped[str | None] = mapped_column(String(16), nullable=True)
    business_hours_id: Mapped[uuid.UUID | None] = fk("business_hours.id")
    overflow_queue_id: Mapped[uuid.UUID | None] = fk("queues.id")
    overflow_after_seconds: Mapped[int | None] = mapped_column(Integer, nullable=True)
    voicemail_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    callback_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    recording_policy_id: Mapped[uuid.UUID | None] = fk("recording_policies.id")
    sla_policy_id: Mapped[uuid.UUID | None] = fk("sla_policies.id")
    offer_timeout_seconds: Mapped[int] = mapped_column(Integer, default=20)
    wrap_up_seconds: Mapped[int] = mapped_column(Integer, default=120)
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class IvrMenu(Base, TimestampMixin):
    """Versioned IVR definition.

    ``definition`` = {"start": node_id, "nodes": {node_id: {
        "prompt": str, "options": {digit: {"action": "queue|menu|voicemail|callback",
        "target": code}}, "timeout_action": {...}, "language": "en"}}}
    """

    __tablename__ = "ivr_menus"
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    name: Mapped[str] = mapped_column(String(200))
    version: Mapped[int] = mapped_column(Integer, default=1)
    published: Mapped[bool] = mapped_column(Boolean, default=False)
    definition: Mapped[JSONDict]
    closed_action: Mapped[JSONDict]  # what to do out of hours


class PhoneNumber(Base, TimestampMixin):
    """Numbers the organisation owns and has verified with the provider.

    Only these may be used as outbound caller identity (no spoofing).
    """

    __tablename__ = "phone_numbers"
    __table_args__ = (UniqueConstraint("org_id", "e164"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    e164: Mapped[str] = mapped_column(String(20))
    label: Mapped[str] = mapped_column(String(200))
    ivr_menu_id: Mapped[uuid.UUID | None] = fk("ivr_menus.id")
    default_queue_id: Mapped[uuid.UUID | None] = fk("queues.id")
    provider: Mapped[str] = mapped_column(String(32), default="simulated")
    provider_number_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    outbound_allowed: Mapped[bool] = mapped_column(Boolean, default=False)
    verified_at: Mapped[TSNull]


class ProviderConfig(Base, TimestampMixin):
    """Provider connection settings. Secrets are encrypted at rest and never returned."""

    __tablename__ = "provider_configs"
    __table_args__ = (UniqueConstraint("org_id", "provider"),)
    id: Mapped[UUIDPK]
    org_id: Mapped[OrgFK]
    provider: Mapped[str] = mapped_column(String(32))
    enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    public_settings: Mapped[JSONDict]
    secret_enc: Mapped[str | None] = mapped_column(Text, nullable=True)
    connection_status: Mapped[str] = mapped_column(String(32), default="unknown")  # connected | degraded | disconnected
    status_changed_at: Mapped[TSNull]
    last_heartbeat_ok_at: Mapped[TSNull]
    consecutive_failures: Mapped[int] = mapped_column(Integer, default=0)
