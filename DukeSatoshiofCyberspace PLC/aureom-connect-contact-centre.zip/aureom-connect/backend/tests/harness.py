"""Deterministic end-to-end harness.

* The real FastAPI application runs in-process (``TestClient``).
* The real simulator application runs in-process; instead of posting
  webhooks itself, its events are collected and delivered by ``pump()`` to
  the API's webhook endpoint with genuine HMAC signatures.
* Simulator timers are run explicitly (``pump(horizon=...)``), so device
  answers, dial outcomes and consult timeouts happen exactly when a test says.
"""
from __future__ import annotations

import heapq
import json
import time
import uuid
from typing import Any

from fastapi.testclient import TestClient

from aureom_connect.adapters.telephony.registry import set_provider
from aureom_connect.adapters.telephony.simulated import SimulatedTelephonyAdapter
from aureom_connect.config import get_settings
from aureom_sim.app import SimConfig, create_app, sign

PASSWORD = "Pennine-Demo-2026!"


class Harness:
    def __init__(self, api_app):
        s = get_settings()
        self.events: list[dict[str, Any]] = []
        self.delivered: list[dict[str, Any]] = []
        self.webhook_responses: list[dict[str, Any]] = []
        self.sim_cfg = SimConfig(api_key=s.simulator_api_key, webhook_secret=s.simulator_webhook_secret,
                                 webhook_url="http://api/v1/providers/simulated/events", realtime=False)
        self.sim_app = create_app(self.sim_cfg, emit=self.events.append, start_threads=False)
        self.engine = self.sim_app.state.engine
        self.sim = TestClient(self.sim_app, base_url="http://sim")
        self.adapter = SimulatedTelephonyAdapter(base_url="http://sim", api_key=s.simulator_api_key,
                                                 webhook_secret=s.simulator_webhook_secret, client=self.sim)
        set_provider(self.adapter)
        self.api = TestClient(api_app, base_url="http://api", raise_server_exceptions=True)
        self.tokens: dict[str, str] = {}
        self.users: dict[str, dict[str, Any]] = {}
        self.media: dict[str, str] = {}

    # ------------------------------------------------------------------ auth
    def login(self, who: str, totp: str | None = None) -> dict[str, str]:
        email = who if "@" in who else f"{who}@pennine.example"
        if email not in self.tokens:
            r = self.api.post("/v1/auth/login", json={"organisation": "pennine", "email": email, "password": PASSWORD,
                                                      "totp_code": totp})
            assert r.status_code == 200, r.text
            self.tokens[email] = r.json()["access_token"]
            self.users[email] = r.json()["user"]
        return {"Authorization": f"Bearer {self.tokens[email]}"}

    def h(self, who: str, idem: str | None = None) -> dict[str, str]:
        headers = self.login(who)
        headers = dict(headers)
        headers["Idempotency-Key"] = idem or uuid.uuid4().hex
        return headers

    def agent_id(self, who: str) -> str:
        self.login(who)
        email = who if "@" in who else f"{who}@pennine.example"
        return str(self.users[email]["agent_id"])

    # ------------------------------------------------------------------ simulator plumbing
    def deliver(self, ev: dict[str, Any]) -> dict[str, Any]:
        clean = {k: v for k, v in ev.items() if not k.startswith("_")}
        body = json.dumps({"events": [clean]}).encode()
        ts = str(int(time.time()))
        r = self.api.post("/v1/providers/simulated/events", content=body, headers={
            "Content-Type": "application/json", "X-Sim-Timestamp": ts,
            "X-Sim-Signature": sign(self.sim_cfg.webhook_secret, ts, body)})
        assert r.status_code == 200, r.text
        self.delivered.append(clean)
        res = r.json()["results"][0]
        self.webhook_responses.append(res)
        return res

    def run_timers(self, horizon: float) -> int:
        """Run simulator timers due within ``horizon`` seconds from now (simulated time passing)."""
        ran = 0
        limit = time.monotonic() + horizon
        while True:
            with self.engine.lock:
                if not self.engine._timers or self.engine._timers[0][0] > limit:
                    break
                _, _, fn = heapq.heappop(self.engine._timers)
            fn()
            ran += 1
        return ran

    def pump(self, horizon: float = 5.0, max_rounds: int = 50) -> list[dict[str, Any]]:
        out = []
        for _ in range(max_rounds):
            progressed = False
            while self.events:
                out.append(self.deliver(self.events.pop(0)))
                progressed = True
            if self.run_timers(horizon):
                progressed = True
            if not progressed:
                break
        return out

    def tick(self, health: bool = True) -> dict[str, int]:
        from aureom_connect.worker.main import tick

        stats = tick(health=health)
        self.pump()
        return stats

    # ------------------------------------------------------------------ agent helpers
    def make_ready(self, who: str) -> dict[str, Any]:
        h = self.login(who)
        assert self.api.post("/v1/agents/me/presence", headers=h).status_code == 200
        cred = self.api.post("/v1/agents/me/media-credential", headers=h).json()
        self.media[who] = cred["token"]
        r = self.sim.post("/v1/devices/register", json={"token": cred["token"]})
        assert r.status_code == 200, r.text
        self.pump()
        r = self.api.put("/v1/agents/me/availability", headers=h, json={"state": "available"})
        assert r.status_code == 200, r.text
        return r.json()

    def inbound(self, from_number: str = "+441134960101", digits: str = "1", **kw: Any) -> str:
        r = self.sim.post("/v1/demo/inbound", headers={"X-Sim-Api-Key": self.sim_cfg.api_key},
                          json={"from_number": from_number, "to_number": "+441614960100", "ivr_digits": digits, **kw})
        assert r.status_code == 202, r.text
        self.pump(horizon=1.0)
        return r.json()["call_id"]

    def workspace(self, who: str) -> dict[str, Any]:
        r = self.api.get("/v1/agent/workspace", headers=self.login(who))
        assert r.status_code == 200, r.text
        return r.json()

    def interaction(self, who: str, iid: str) -> dict[str, Any]:
        r = self.api.get(f"/v1/interactions/{iid}", headers=self.login(who))
        assert r.status_code == 200, r.text
        return r.json()

    def accept_first_offer(self, who: str) -> str:
        ws = self.workspace(who)
        assert ws["offers"], f"{who} has no offers: {ws}"
        offer = ws["offers"][0]
        iid = str(offer["interaction"]["id"])
        r = self.api.post(f"/v1/interactions/{iid}/accept", headers=self.h(who), json={"offer_id": offer["id"]})
        assert r.status_code == 200, r.text
        self.pump()
        return iid

    def action(self, who: str, iid: str, action: str, idem: str | None = None, **params: Any):
        return self.api.post(f"/v1/interactions/{iid}/actions", headers=self.h(who, idem),
                             json={"action": action, "params": params})

    def faults(self, **faults: Any) -> None:
        r = self.sim.put("/v1/demo/faults", headers={"X-Sim-Api-Key": self.sim_cfg.api_key}, json=faults)
        assert r.status_code == 200, r.text
