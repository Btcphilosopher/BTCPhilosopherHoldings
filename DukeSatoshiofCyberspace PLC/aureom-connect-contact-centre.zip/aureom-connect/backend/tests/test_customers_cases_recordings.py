"""Customer identity & verification, cases and tasks, recordings and payments."""
from __future__ import annotations

from sqlalchemy import select, text

from aureom_connect.db import session_scope
from aureom_connect.models import AuditLog, Recording


def _call(h, who="amira.khan", number="+441134960145", digits="1"):
    h.make_ready(who)
    h.inbound(from_number=number, digits=digits)
    return h.accept_first_offer(who)


def test_shared_number_candidates_and_no_auto_merge(h):
    iid = _call(h, number="+441134960101")  # Margaret and Tom Ellison share this number
    d = h.interaction("amira.khan", iid)
    refs = sorted(c["customer_ref"] for c in d["candidates"])
    assert refs == ["PCS-100231", "PCS-100232"]
    assert all(c["shared_number"] for c in d["candidates"])
    assert d["customer_record"] is None and d["customer_match_status"] == "candidates"
    a, b = d["candidates"][0]["customer_id"], d["candidates"][1]["customer_id"]
    r = h.api.post(f"/v1/customers/{a}/possible-duplicates", headers=h.login("amira.khan"),
                   json={"other_customer_id": b, "reason": "same household, check records"})
    assert r.status_code == 200 and "not merged" in r.json()["note"]


def test_verification_gates_restricted_data_and_sensitive_actions(h):
    iid = _call(h)
    d = h.interaction("amira.khan", iid)
    cust = d["candidates"][0]["customer_id"]
    d = h.api.post(f"/v1/interactions/{iid}/customer", headers=h.login("amira.khan"), json={"customer_id": cust}).json()
    assert d["customer_match_status"] == "selected_unverified"
    rec = d["customer_record"]
    assert rec["restricted"] is None and rec["restricted_access"] == "withheld_until_verified"
    assert all("•" in cp["value"] for cp in rec["contact_points"])
    # Sensitive action refused before verification.
    r = h.api.post(f"/v1/customers/{cust}/contact-points", headers=h.login("amira.khan"),
                   json={"interaction_id": iid, "kind": "email", "value": "new@example.org",
                         "expected_version": rec["version"]})
    assert r.status_code == 403 and r.json()["error"]["code"] == "VERIFICATION_REQUIRED"
    # Wrong answer then two correct factors.
    r = h.api.post(f"/v1/interactions/{iid}/verification", headers=h.login("amira.khan"),
                   json={"answers": {"date_of_birth": "1980-01-01"}})
    assert r.json()["status"] == "in_progress" and r.json()["last_results"] == {"date_of_birth": False}
    r = h.api.post(f"/v1/interactions/{iid}/verification", headers=h.login("amira.khan"),
                   json={"answers": {"date_of_birth": "21/07/1979", "postcode": "ol14 6qt"}})
    assert r.json()["status"] == "verified"
    d = h.interaction("amira.khan", iid)
    assert d["customer_record"]["restricted"]["balance"] == "£212.55 overdue"
    r = h.api.post(f"/v1/customers/{cust}/contact-points", headers=h.login("amira.khan"),
                   json={"interaction_id": iid, "kind": "email", "value": "new@example.org",
                         "expected_version": d["customer_record"]["version"]})
    assert r.status_code == 200
    # Answers are never stored or written to the audit log.
    with session_scope() as s:
        details = " ".join(str(a.details) for a in s.scalars(select(AuditLog)))
    assert "1979-07-21" not in details and "ol14" not in details.lower()


def test_verification_locks_after_failures(h):
    iid = _call(h)
    cust = h.interaction("amira.khan", iid)["candidates"][0]["customer_id"]
    h.api.post(f"/v1/interactions/{iid}/customer", headers=h.login("amira.khan"), json={"customer_id": cust})
    for _ in range(3):
        r = h.api.post(f"/v1/interactions/{iid}/verification", headers=h.login("amira.khan"),
                       json={"answers": {"postcode": "XX1 1XX"}})
    assert r.json()["status"] == "locked"
    r = h.api.post(f"/v1/interactions/{iid}/verification", headers=h.login("amira.khan"),
                   json={"answers": {"date_of_birth": "1979-07-21", "postcode": "OL14 6QT"}})
    assert r.json()["status"] == "locked"


def test_case_resolution_reopen_and_override(h):
    iid = _call(h)
    cust = h.interaction("amira.khan", iid)["candidates"][0]["customer_id"]
    r = h.api.post("/v1/cases", headers=h.h("amira.khan"),
                   json={"customer_id": cust, "title": "Payment arrangement", "category": "billing",
                         "interaction_id": iid, "note": "Wants monthly plan"})
    assert r.status_code == 201, r.text
    case = r.json()
    assert case["sla"]["label"] == "Internal target"
    # The call ending does not resolve the case.
    h.action("amira.khan", iid, "end")
    h.pump()
    case = h.api.get(f"/v1/cases/{case['id']}", headers=h.login("amira.khan")).json()
    assert case["status"] == "open"
    r = h.api.patch(f"/v1/cases/{case['id']}", headers=h.login("amira.khan"),
                    json={"expected_version": case["version"], "status": "resolved"})
    assert r.status_code == 422 and r.json()["error"]["code"] == "OUTCOME_REQUIRED"
    r = h.api.patch(f"/v1/cases/{case['id']}", headers=h.login("amira.khan"),
                    json={"expected_version": case["version"], "status": "resolved",
                          "outcome_code": "payment_arrangement", "resolution_note": "Monthly £25"})
    case = r.json()
    assert case["status"] == "resolved"
    r = h.api.patch(f"/v1/cases/{case['id']}", headers=h.login("amira.khan"),
                    json={"expected_version": case["version"], "status": "open"})
    assert r.json()["error"]["code"] == "REASON_REQUIRED"
    r = h.api.patch(f"/v1/cases/{case['id']}", headers=h.login("amira.khan"),
                    json={"expected_version": case["version"] - 1, "status": "open", "reason": "customer rang back"})
    assert r.status_code == 409  # stale version
    r = h.api.patch(f"/v1/cases/{case['id']}", headers=h.login("amira.khan"),
                    json={"expected_version": case["version"], "status": "open", "reason": "customer rang back"})
    case = r.json()
    assert case["reopen_count"] == 1 and any(e["type"] == "reopened" for e in case["events"])
    # Override of a completed case needs case.override (supervisor) and a reason.
    r = h.api.patch(f"/v1/cases/{case['id']}", headers=h.login("amira.khan"),
                    json={"expected_version": case["version"], "status": "resolved", "outcome_code": "info_provided"})
    case = r.json()
    r = h.api.patch(f"/v1/cases/{case['id']}", headers=h.login("amira.khan"),
                    json={"expected_version": case["version"], "outcome_code": "escalated", "reason": "wrong outcome"})
    assert r.status_code == 403
    r = h.api.patch(f"/v1/cases/{case['id']}", headers=h.login("grace.thornton"),
                    json={"expected_version": case["version"], "outcome_code": "escalated", "reason": "wrong outcome"})
    assert r.status_code == 200 and any(e["type"] == "outcome_overridden" for e in r.json()["events"])


def test_follow_up_task(h):
    iid = _call(h)
    r = h.api.post("/v1/tasks", headers=h.h("amira.khan"),
                   json={"title": "Send arrangement letter", "interaction_id": iid,
                         "assignee_agent_id": h.agent_id("femi.adeyemi"), "priority": "high"})
    assert r.status_code == 201, r.text
    t = r.json()
    assert t["sla"]["kind"] == "internal_target" and t["due_at"]
    tasks = h.api.get("/v1/tasks", headers=h.login("femi.adeyemi")).json()
    assert any(x["id"] == t["id"] for x in tasks)
    r = h.api.patch(f"/v1/tasks/{t['id']}", headers=h.login("femi.adeyemi"),
                    json={"expected_version": t["version"], "status": "done", "note": "sent"})
    assert r.json()["status"] == "done" and r.json()["sla"]["state"] == "met"


def test_recording_permissions_retention_and_payment(h, db):
    iid = _call(h)
    d = h.interaction("amira.khan", iid)
    assert d["recordings"][0]["status"] == "active"
    # Secure payment: provider pauses recording; card data never reaches us.
    r = h.action("amira.khan", iid, "start_secure_payment", amount_minor=2500)
    assert r.status_code == 202
    h.pump()
    d = h.interaction("amira.khan", iid)
    assert d["payments"][0]["status"] == "completed" and d["payments"][0]["recording_paused_confirmed"]
    assert d["recordings"][0]["pause_intervals"][0]["reason"] == "secure_payment"
    h.action("amira.khan", iid, "end")
    h.pump()
    h.tick()  # worker fetches the (synthetic) media into protected storage
    rec = db.scalar(select(Recording))
    db.refresh(rec)
    assert rec.status == "available" and rec.is_synthetic_media and rec.retention_until
    url = f"/v1/recordings/{rec.id}/media?purpose=complaint_investigation"
    assert h.api.get(url, headers=h.login("amira.khan")).status_code == 403  # agents cannot listen
    # BILLING uses the quality policy: quality reviewers may listen; purpose required.
    assert h.api.get(f"/v1/recordings/{rec.id}/media?purpose=fun", headers=h.login("harriet.lowe")).status_code == 422
    r = h.api.get(f"/v1/recordings/{rec.id}/media?purpose=quality_review", headers=h.login("harriet.lowe"))
    assert r.status_code == 200 and r.headers["content-type"] == "audio/wav"
    assert r.headers["x-synthetic-media"].startswith("true")
    with session_scope() as s:
        attempts = s.scalars(select(AuditLog).where(AuditLog.action == "recording.access_attempt")).all()
    assert [a.details["allowed"] for a in attempts] == [False, True]
    # Retention: legal hold prevents deletion; past retention the worker deletes media.
    with session_scope() as s:
        s.execute(text("update recordings set retention_until = now() - interval '1 day', legal_hold = true"))
    from aureom_connect.services.recording import apply_retention

    with session_scope() as s:
        assert apply_retention(s) == 0
        s.execute(text("update recordings set legal_hold = false"))
    with session_scope() as s:
        assert apply_retention(s) == 1
    db.refresh(rec)
    assert rec.deletion_status == "deleted" and rec.storage_key is None


def test_date_of_birth_formats_are_normalised():
    from aureom_connect.services.customers import normalise_answer

    for raw in ("1979-07-21", "21/07/1979", "21-07-1979", "21.07.1979", "21 July 1979", "21 Jul 1979"):
        assert normalise_answer("date_of_birth", raw) == "1979-07-21", raw
    assert normalise_answer("postcode", "OL14 6QT") == "OL14 6QT"
