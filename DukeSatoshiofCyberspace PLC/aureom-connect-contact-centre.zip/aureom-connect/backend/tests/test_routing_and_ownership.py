"""Routing eligibility, ordering, business hours, overflow and transactional ownership."""
from __future__ import annotations

import threading
import uuid
from datetime import timedelta

from sqlalchemy import select, text

from aureom_connect.db import session_scope, utcnow
from aureom_connect.models import Agent, Interaction, Offer, Queue, RoutingDecision


def test_requires_skill_language_membership_and_registration(h):
    h.make_ready("ben.hughes")      # technical, care, welsh; TECH+CARE
    h.make_ready("chloe.dawson")    # billing, technical; BILLING+TECH — not CARE, no Welsh
    # Welsh-language option (4) → CARE with language cy → only Ben is eligible.
    h.inbound(from_number="+441134960145", digits="4")
    assert h.workspace("ben.hughes")["offers"], "Welsh speaker should be offered the call"
    assert not h.workspace("chloe.dawson")["offers"]
    iid = h.workspace("ben.hughes")["offers"][0]["interaction"]["id"]
    r = h.api.get(f"/v1/ops/routing-decisions/{iid}", headers=h.login("grace.thornton"))
    decision = r.json()[-1]
    chloe = next(c for c in decision["candidates"] if c["agent"] == "Chloe Dawson")
    assert not chloe["eligible"]
    assert any("not a member of queue CARE" in x for x in chloe["reasons"])
    assert any("does not speak 'cy'" in x for x in chloe["reasons"])


def test_connected_browser_is_not_enough(h):
    hd = h.login("amira.khan")
    h.api.post("/v1/agents/me/presence", headers=hd)  # app connected, but no provider registration
    r = h.api.put("/v1/agents/me/availability", headers=hd, json={"state": "available"})
    assert r.status_code == 409
    assert r.json()["error"]["code"] == "NOT_READY"
    assert any("registration" in b for b in r.json()["error"]["details"]["blockers"])


def test_longest_waiting_and_longest_idle(h):
    h.make_ready("amira.khan")
    h.make_ready("femi.adeyemi")
    # Make Femi idle longest.
    with session_scope() as db:
        femi = db.scalar(select(Agent).where(Agent.display_name == "Femi Adeyemi"))
        femi.available_since = utcnow() - timedelta(minutes=10)
    # Two billing calls; the first waits longer.
    first = h.inbound(from_number="+441134960145", digits="1")
    ws_femi = h.workspace("femi.adeyemi")
    assert ws_femi["offers"], "longest-idle agent gets the first call"
    second = h.inbound(from_number="+441134960201", digits="1")
    ws_amira = h.workspace("amira.khan")
    assert ws_amira["offers"]
    assert ws_femi["offers"][0]["interaction"]["id"] != ws_amira["offers"][0]["interaction"]["id"]
    assert first != second


def test_urgency_flag_does_not_change_routing_priority(h, db):
    h.make_ready("amira.khan")
    h.inbound(from_number="+441134960145", digits="1")
    it = db.scalar(select(Interaction).where(Interaction.status == "offered"))
    assert it.urgency_flag is None
    assert it.routing_priority == 0


def test_closed_queue_goes_to_voicemail(h, db):
    with session_scope() as s:
        std = s.execute(text("select id from business_hours where name like 'Standard%'")).scalar_one()
        s.execute(text("update queues set business_hours_id=:b"), {"b": std})
        # Christmas Day (closed all day) for "now": add a holiday on today's date.
        s.execute(text("insert into holidays (id, org_id, business_hours_id, day, name, intervals) "
                       "select gen_random_uuid(), org_id, id, (now() at time zone 'Europe/London')::date, "
                       "'Test closure', '[]'::jsonb from business_hours where id=:b "
                       "on conflict do nothing"), {"b": std})
    h.make_ready("amira.khan")
    h.inbound(from_number="+441134960145", digits="1")
    it = db.scalar(select(Interaction).order_by(Interaction.created_at.desc()).limit(1))
    assert it.status == "voicemail"
    assert not h.workspace("amira.khan")["offers"]


def test_overflow_keeps_wait_clock(h, db):
    h.inbound(from_number="+441134960145", digits="2")  # TECH, nobody available
    it = db.scalar(select(Interaction).where(Interaction.status == "queued"))
    started = it.routable_since
    with session_scope() as s:
        s.execute(text("update queue_entries set entered_at = entered_at - interval '10 minutes'"))
    h.tick()
    db.expire_all()
    it = db.get(Interaction, it.id)
    q = db.get(Queue, it.current_queue_id)
    assert q.code == "CARE"
    assert it.routable_since == started
    r = h.interaction("grace.thornton", str(it.id))
    assert [e["exit_reason"] for e in r["queue_entries"]] == ["overflow", None]


def test_concurrent_accept_has_single_owner(h, db):
    """Two pending offers for one interaction (e.g. a race between routers): exactly one accept wins."""
    h.make_ready("amira.khan")
    h.make_ready("eilidh.fraser")
    h.inbound(from_number="+441134960145", digits="1")
    it = db.scalar(select(Interaction).where(Interaction.status == "offered"))
    first_offer = db.scalar(select(Offer).where(Offer.interaction_id == it.id, Offer.status == "pending"))
    other_name = "Eilidh Fraser" if db.get(Agent, first_offer.agent_id).display_name == "Amira Khan" else "Amira Khan"
    with session_scope() as s:
        other = s.scalar(select(Agent).where(Agent.display_name == other_name))
        other.state = "call_offered"
        s.add(Offer(org_id=it.org_id, interaction_id=it.id, agent_id=other.id, kind="queue", status="pending",
                    offered_at=utcnow(), expires_at=utcnow() + timedelta(seconds=30)))
    offers = {db.get(Agent, o.agent_id).display_name: o.id for o in db.scalars(
        select(Offer).where(Offer.interaction_id == it.id, Offer.status == "pending"))}
    who = {"Amira Khan": "amira.khan", "Eilidh Fraser": "eilidh.fraser"}
    barrier = threading.Barrier(2)
    results: dict[str, int] = {}

    def go(name: str) -> None:
        barrier.wait()
        r = h.api.post(f"/v1/interactions/{it.id}/accept", headers=h.h(who[name]), json={"offer_id": str(offers[name])})
        results[name] = r.status_code

    for name in offers:
        h.login(who[name])
    threads = [threading.Thread(target=go, args=(n,)) for n in offers]
    [t.start() for t in threads]
    [t.join() for t in threads]
    assert sorted(results.values()) == [200, 409], results
    db.expire_all()
    it = db.get(Interaction, it.id)
    winner = next(n for n, c in results.items() if c == 200)
    assert db.get(Agent, it.owner_agent_id).display_name == winner


def test_accept_is_idempotent_and_expired_offers_cannot_be_accepted(h, db):
    h.make_ready("amira.khan")
    h.inbound(from_number="+441134960145", digits="1")
    ws = h.workspace("amira.khan")
    offer = ws["offers"][0]
    iid = offer["interaction"]["id"]
    key = uuid.uuid4().hex
    r1 = h.api.post(f"/v1/interactions/{iid}/accept", headers=h.h("amira.khan", key), json={"offer_id": offer["id"]})
    r2 = h.api.post(f"/v1/interactions/{iid}/accept", headers=h.h("amira.khan", key), json={"offer_id": offer["id"]})
    assert r1.status_code == r2.status_code == 200
    assert r2.headers.get("Idempotent-Replayed") == "true"
    # A different key on an already-accepted offer is a conflict, not a second acceptance.
    r3 = h.api.post(f"/v1/interactions/{iid}/accept", headers=h.h("amira.khan"), json={"offer_id": offer["id"]})
    assert r3.status_code == 409


def test_missed_offer_makes_agent_unavailable_and_reroutes(h, db):
    h.make_ready("amira.khan")
    h.make_ready("eilidh.fraser")
    h.inbound(from_number="+441134960145", digits="1")
    first = db.scalar(select(Offer).where(Offer.status == "pending"))
    first_agent = db.get(Agent, first.agent_id).display_name
    with session_scope() as s:
        s.execute(text("update offers set expires_at = now() - interval '1 second' where status='pending'"))
    h.tick()
    db.expire_all()
    assert db.get(Offer, first.id).status == "expired"
    assert db.get(Agent, first.agent_id).state == "unavailable"
    nxt = db.scalar(select(Offer).where(Offer.status == "pending"))
    assert nxt is not None and db.get(Agent, nxt.agent_id).display_name != first_agent
    # The excluded agent is recorded with a reason.
    dec = db.scalars(select(RoutingDecision).where(RoutingDecision.interaction_id == first.interaction_id)
                     .order_by(RoutingDecision.decided_at)).all()[-1]
    me = next(c for c in dec.candidates if c["agent"] == first_agent)
    assert not me["eligible"]
