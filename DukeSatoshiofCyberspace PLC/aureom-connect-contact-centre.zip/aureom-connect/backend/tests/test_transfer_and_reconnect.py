"""Warm/blind transfer (incl. failure) and provider disconnection recovery."""
from __future__ import annotations

from sqlalchemy import select, text

from aureom_connect.db import session_scope
from aureom_connect.models import Interaction


def _call_for(h, who="amira.khan", number="+441134960145", digits="1"):
    h.make_ready(who)
    h.inbound(from_number=number, digits=digits)
    return h.accept_first_offer(who)


def test_warm_transfer_success_keeps_one_interaction(h, db):
    iid = _call_for(h)
    h.make_ready("eilidh.fraser")
    target = h.agent_id("eilidh.fraser")
    r = h.action("amira.khan", iid, "warm_transfer_start", target_agent_id=target)
    assert r.status_code == 202, r.text
    h.pump()
    d = h.interaction("amira.khan", iid)
    assert d["transfer_state"]["status"] == "consult_ringing"
    assert next(lg for lg in d["call"]["legs"] if lg["leg_type"] == "customer")["on_hold"]
    ws = h.workspace("eilidh.fraser")
    assert ws["offers"] and ws["offers"][0]["kind"] == "consult"
    r = h.api.post(f"/v1/interactions/{iid}/accept", headers=h.h("eilidh.fraser"),
                   json={"offer_id": ws["offers"][0]["id"]})
    assert r.status_code == 200, r.text
    h.pump()
    assert h.interaction("amira.khan", iid)["transfer_state"]["status"] == "consult_connected"
    r = h.action("amira.khan", iid, "warm_transfer_complete")
    assert r.status_code == 202, r.text
    h.pump()
    d = h.interaction("eilidh.fraser", iid)
    assert d["owner_agent_id"] == target
    assert d["transfer_count"] == 1
    assert d["transfer_state"]["status"] == "completed"
    assert h.workspace("amira.khan")["agent"]["state"] == "after_call_work"
    assert h.workspace("eilidh.fraser")["agent"]["state"] == "on_interaction"
    # Original agent completes their wrap-up; receiving agent ends the call later.
    r = h.api.post(f"/v1/interactions/{iid}/wrap-up", headers=h.h("amira.khan"), json={"disposition_code": "transferred"})
    assert r.status_code == 200, r.text
    h.action("eilidh.fraser", iid, "end")
    h.pump()
    r = h.api.post(f"/v1/interactions/{iid}/wrap-up", headers=h.h("eilidh.fraser"),
                   json={"disposition_code": "resolved_first_contact"})
    assert r.status_code == 200, r.text
    assert db.scalar(select(Interaction).where(Interaction.id == iid)).status == "completed"
    # Reports count it once, as answered and transferred.
    rep = h.api.get("/v1/reports/summary?include_synthetic_history=false", headers=h.login("grace.thornton")).json()
    assert rep["volumes"]["offered"] == 1
    assert rep["volumes"]["answered"] == 1
    assert rep["transfers"]["interactions_transferred"] == 1


def test_warm_transfer_rejected_preserves_original_call(h, db):
    iid = _call_for(h)
    h.make_ready("eilidh.fraser")
    h.action("amira.khan", iid, "warm_transfer_start", target_agent_id=h.agent_id("eilidh.fraser"))
    h.pump()
    ws = h.workspace("eilidh.fraser")
    r = h.api.post(f"/v1/interactions/{iid}/reject", headers=h.h("eilidh.fraser"),
                   json={"offer_id": ws["offers"][0]["id"], "reason": "busy with complaint"})
    assert r.status_code == 200, r.text
    h.pump()
    d = h.interaction("amira.khan", iid)
    assert d["transfer_state"]["status"] == "failed"
    assert d["transfer_state"]["failure_reason"] == "rejected"
    assert d["owner_agent_id"] == h.agent_id("amira.khan")
    assert d["status"] == "active"
    cust = next(lg for lg in d["call"]["legs"] if lg["leg_type"] == "customer")
    assert cust["status"] == "answered" and cust["on_hold"]
    assert d["available_controls"]["resume"]["enabled"]
    assert h.workspace("eilidh.fraser")["agent"]["state"] == "available"
    h.action("amira.khan", iid, "resume")
    h.pump()
    d = h.interaction("amira.khan", iid)
    assert not next(lg for lg in d["call"]["legs"] if lg["leg_type"] == "customer")["on_hold"]
    assert d["transfer_count"] == 0


def test_warm_transfer_no_answer(h, db):
    iid = _call_for(h)
    h.make_ready("eilidh.fraser")
    h.action("amira.khan", iid, "warm_transfer_start", target_agent_id=h.agent_id("eilidh.fraser"))
    h.pump()
    with session_scope() as s:
        s.execute(text("update offers set expires_at = now() - interval '1 second' where kind='consult'"))
    h.tick()
    d = h.interaction("amira.khan", iid)
    assert d["transfer_state"]["status"] == "failed"
    assert d["status"] == "active" and d["owner_agent_id"] == h.agent_id("amira.khan")
    assert h.workspace("eilidh.fraser")["agent"]["state"] == "unavailable"


def test_blind_transfer_requeues_same_interaction(h, db):
    iid = _call_for(h)
    care = next(q for q in h.api.get("/v1/queues", headers=h.login("grace.thornton")).json() if q["code"] == "CARE")
    r = h.action("amira.khan", iid, "blind_transfer", target_queue_id=str(care["id"]))
    assert r.status_code == 202, r.text
    h.pump()
    d = h.interaction("grace.thornton", iid)
    assert d["status"] == "queued" and d["queue"]["code"] == "CARE"
    assert d["transfer_count"] == 1
    assert [qe["queue"] for qe in d["queue_entries"]] == ["BILLING", "CARE"]
    assert h.workspace("amira.khan")["agent"]["state"] == "after_call_work"


def test_provider_disconnection_and_recovery(h, db):
    iid = _call_for(h)
    # Blackhole outage: the provider applies the request but the response and events are lost.
    h.faults(outage="blackhole")
    r = h.action("amira.khan", iid, "hold")
    assert r.json()["status"] == "unknown"
    h.pump()
    d = h.interaction("amira.khan", iid)
    assert d["needs_reconciliation"] is True
    assert all(not c["enabled"] for c in d["available_controls"].values())
    r = h.action("amira.khan", iid, "end")
    assert r.status_code == 409 and r.json()["error"]["code"] == "RECONCILIATION_REQUIRED"
    h.tick()
    h.tick()  # two failed health checks → disconnected
    ws = h.workspace("amira.khan")
    assert ws["provider"]["status"] == "disconnected"
    assert ws["agent"]["reconcile_required"]
    # Restore: reconciliation queries authoritative state and resolves the unknown hold without re-sending it.
    h.faults(outage=None)
    h.tick()
    ws = h.workspace("amira.khan")
    assert ws["provider"]["status"] == "connected"
    d = h.interaction("amira.khan", iid)
    hold = next(c for c in d["controls"] if c["action"] == "hold")
    assert hold["status"] == "acknowledged" and hold["resolved_by"] == "reconciliation"
    assert next(lg for lg in d["call"]["legs"] if lg["leg_type"] == "customer")["on_hold"] is True
    assert len([e for e in h.engine.event_log if e["type"] == "leg.held"]) == 1, "hold was never re-sent"
    assert not ws["agent"]["reconcile_required"]
    assert any(e["type"] == "reconciled" for e in d["timeline"])


def test_call_ended_during_outage_is_reconciled(h, db):
    iid = _call_for(h)
    call = h.interaction("amira.khan", iid)["call"]["provider_call_id"]
    h.faults(outage="refuse")
    h.engine.customer_hangup(call)  # call.completed event lost in the outage
    h.pump()
    assert h.interaction("amira.khan", iid)["status"] == "active"
    h.tick()
    h.tick()
    h.faults(outage=None)
    h.tick()
    d = h.interaction("amira.khan", iid)
    assert d["status"] == "wrap_up"
    assert h.workspace("amira.khan")["agent"]["state"] == "after_call_work"
