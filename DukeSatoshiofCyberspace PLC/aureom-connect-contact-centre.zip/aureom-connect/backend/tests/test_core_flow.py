"""The first required path: inbound event → queue → offer → acceptance → workspace → disposition → ACW → report."""
from __future__ import annotations


def test_inbound_to_wrap_up(h):
    h.make_ready("amira.khan")  # billing skill
    call_id = h.inbound(from_number="+441134960145", digits="1")  # Rhys Morgan → BILLING
    ws = h.workspace("amira.khan")
    assert ws["agent"]["state"] == "call_offered"
    assert len(ws["offers"]) == 1
    offer = ws["offers"][0]
    assert offer["interaction"]["queue"]["code"] == "BILLING"

    iid = h.accept_first_offer("amira.khan")
    detail = h.interaction("amira.khan", iid)
    assert detail["status"] == "active"
    assert detail["owner_agent_id"] == h.agent_id("amira.khan")
    answer = [c for c in detail["controls"] if c["action"] == "answer"][0]
    assert answer["status"] == "acknowledged"  # provider confirmed the agent leg
    assert h.workspace("amira.khan")["agent"]["state"] == "on_interaction"
    # Recording: requested, then confirmed active by provider event.
    assert detail["recordings"][0]["status"] == "active"
    assert detail["recordings"][0]["confirmed_by_provider"] is True
    # Candidate shown as a hint; customer not yet identified.
    assert detail["customer_match_status"] == "candidates"
    assert [c["customer_ref"] for c in detail["candidates"]] == ["PCS-100245"]

    r = h.action("amira.khan", iid, "end")
    assert r.status_code == 202, r.text
    assert r.json()["status"] == "requested"
    h.pump()
    detail = h.interaction("amira.khan", iid)
    assert detail["status"] == "wrap_up"
    assert h.workspace("amira.khan")["agent"]["state"] == "after_call_work"
    end_ctl = [c for c in detail["controls"] if c["action"] == "end"][0]
    assert end_ctl["status"] == "acknowledged"

    r = h.api.post(f"/v1/interactions/{iid}/wrap-up", headers=h.h("amira.khan"),
                   json={"disposition_code": "info_provided", "note": "Explained bill"})
    assert r.status_code == 200, r.text
    assert r.json()["agent_state"] == "available"
    detail = h.interaction("amira.khan", iid)
    assert detail["status"] == "completed"
    assert detail["disposition_code"] == "info_provided"
    assert [qe["exit_reason"] for qe in detail["queue_entries"]] == ["answered"]
    assert call_id == detail["call"]["provider_call_id"]
