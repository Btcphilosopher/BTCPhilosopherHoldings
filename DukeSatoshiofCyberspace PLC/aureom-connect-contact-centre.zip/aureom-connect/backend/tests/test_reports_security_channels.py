"""Report arithmetic, security controls, channels, WebSocket events, Twilio adapter."""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import logging
import time
import uuid
from datetime import datetime, timedelta, timezone

import jwt
import pyotp
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from sqlalchemy import select, text

from aureom_connect.db import session_scope, utcnow
from aureom_connect.models import (AgentParticipation, Callback, Case, CaseInteraction, Customer, Feedback, Interaction,
                                   Organisation, Queue, QueueEntry)
from aureom_connect.services import reports
from aureom_connect.services.audit import verify_chain


# ---------------------------------------------------------------- report arithmetic

def test_report_arithmetic(db):
    """Constructed fixtures with known answers (no synthetic history in the window)."""
    org = db.scalar(select(Organisation))
    q = db.scalar(select(Queue).where(Queue.code == "BILLING"))  # SLA threshold 20 s
    cust = db.scalar(select(Customer).where(Customer.customer_ref == "PCS-100245"))
    t0 = datetime(2030, 1, 7, 9, 0, tzinfo=timezone.utc)  # a window far from seeded data

    def mk(minute, *, wait, answered=True, status="completed", talk=0, hold=0, acw=0, transfers=0, customer=None,
           second_agent_talk=0):
        start = t0 + timedelta(minutes=minute)
        it = Interaction(org_id=org.id, reference=f"T-{uuid.uuid4().hex[:6]}", channel="voice", direction="inbound",
                         status=status, source="test", customer_id=customer, match_hint={}, required_skills=[],
                         ivr_path=[], transfer_state={}, first_queued_at=start, routable_since=start,
                         transfer_count=transfers)
        it.created_at = start
        db.add(it)
        db.flush()
        db.add(QueueEntry(org_id=org.id, interaction_id=it.id, queue_id=q.id, sequence=1, entered_at=start,
                          left_at=start + timedelta(seconds=wait)))
        if answered:
            conn = start + timedelta(seconds=wait)
            it.connected_at = conn
            end = conn + timedelta(seconds=talk + hold)
            it.ended_at = end
            agent_id = db.execute(text("select id from agents limit 1")).scalar_one()
            db.add(AgentParticipation(org_id=org.id, interaction_id=it.id, agent_id=agent_id, role="primary",
                                      connected_at=conn, ended_at=end, hold_seconds=hold, wrap_started_at=end,
                                      wrap_ended_at=end + timedelta(seconds=acw)))
            if second_agent_talk:
                db.add(AgentParticipation(org_id=org.id, interaction_id=it.id, agent_id=agent_id,
                                          role="transfer_receiver", connected_at=end,
                                          ended_at=end + timedelta(seconds=second_agent_talk), hold_seconds=0))
        else:
            it.ended_at = start + timedelta(seconds=wait)
        return it

    a = mk(0, wait=10, talk=100, hold=20, acw=30, customer=cust.id)             # answered within SL
    mk(1, wait=40, talk=200, acw=60, transfers=1, second_agent_talk=50)         # answered late, transferred
    mk(2, wait=3, answered=False, status="abandoned")                           # short abandon (<5 s)
    mk(3, wait=60, answered=False, status="abandoned")                          # abandon
    mk(4, wait=30, answered=False, status="callback_requested")                 # deflected
    b = mk(5, wait=5, talk=50, customer=cust.id)                                # repeat contact (same customer)
    db.add(Feedback(org_id=org.id, interaction_id=a.id, score=5, received_at=t0 + timedelta(hours=1)))
    db.add(Feedback(org_id=org.id, interaction_id=b.id, score=3, received_at=t0 + timedelta(hours=1)))
    c1 = Case(org_id=org.id, case_ref="CASE-T1", title="x", category="billing", status="resolved",
              resolved_at=t0 + timedelta(hours=2))
    c1.created_at = t0
    c2 = Case(org_id=org.id, case_ref="CASE-T2", title="y", category="billing", status="open")
    c2.created_at = t0
    db.add_all([c1, c2])
    db.flush()
    db.add(CaseInteraction(org_id=org.id, case_id=c1.id, interaction_id=a.id, linked_at=t0))
    db.commit()

    r = reports.summary(db, org.id, t0, t0 + timedelta(hours=8))
    v, rates, times = r["volumes"], r["rates"], r["times_seconds"]
    assert v == {"offered": 6, "answered": 3, "abandoned": 1, "short_abandoned": 1, "voicemail": 0,
                 "callback_requested": 1, "in_progress_or_other": 0}
    assert rates["answer_rate_pct"] == 50.0                      # 3 / 6
    assert rates["abandon_rate_pct"] == 20.0                     # 1 / (6 − 1)
    assert rates["service_level_pct"] == 40.0                    # (a, b) within 20 s / 5
    assert rates["transfer_rate_pct"] == 33.3                    # 1 / 3 answered — counted once
    assert times["average_speed_of_answer"] == round((10 + 40 + 5) / 3, 1)
    assert times["talk_total"] == 100 + 200 + 50 + 50            # second agent's talk included
    assert times["hold_total"] == 20
    assert times["acw_total"] == 90
    assert times["average_handling_time"] == round((400 + 20 + 90) / 3, 1)
    assert r["repeat_contacts"] == {"repeats": 1, "identified_contacts": 2}
    assert r["customer_feedback"]["mean_score"] == 4.0 and r["customer_feedback"]["csat_pct"] == 50.0
    assert r["cases"] == {"created": 2, "resolved": 1, "first_contact_resolution": 1, "resolution_rate_pct": 50.0}
    assert r["window"]["time_basis"] == "provider event time"


# ---------------------------------------------------------------- security

def test_mfa_required_for_admin(h):
    r = h.api.post("/v1/auth/login", json={"organisation": "pennine", "email": "kit.admin@pennine.example",
                                           "password": "Pennine-Demo-2026!"})
    assert r.status_code == 401 and r.json()["error"]["code"] == "MFA_REQUIRED"
    code = pyotp.TOTP("KRSXG5CTMVRXEZLUKN2XAZLSKNSWG4TF").now()
    r = h.api.post("/v1/auth/login", json={"organisation": "pennine", "email": "kit.admin@pennine.example",
                                           "password": "Pennine-Demo-2026!", "totp_code": code})
    assert r.status_code == 200 and r.json()["user"]["mfa"] is True
    tok = r.json()["access_token"]
    assert h.api.get("/v1/admin/users", headers={"Authorization": f"Bearer {tok}"}).status_code == 200


def test_permissions_enforced_server_side(h):
    agent = h.login("amira.khan")
    assert h.api.get("/v1/ops/live", headers=agent).status_code == 403
    assert h.api.get("/v1/admin/users", headers=agent).status_code == 403
    assert h.api.get("/v1/recordings", headers=agent).status_code == 403
    assert h.api.get("/v1/agent/workspace", headers=h.login("grace.thornton")).status_code == 403
    assert h.api.get("/v1/agent/workspace").status_code == 401


def test_org_scoping(h, db):
    with session_scope() as s:
        other = Organisation(slug="other", name="Other Org", settings={})
        s.add(other)
        s.flush()
        s.add(Customer(org_id=other.id, customer_ref="X-1", display_name="Other customer", support_flags=[]))
    cid = db.scalar(select(Customer).where(Customer.customer_ref == "X-1")).id
    assert h.api.get(f"/v1/customers/{cid}", headers=h.login("amira.khan")).status_code == 404


def test_refresh_rotation_and_reuse_detection(h):
    r = h.api.post("/v1/auth/login", json={"organisation": "pennine", "email": "amira.khan@pennine.example",
                                           "password": "Pennine-Demo-2026!"}).json()
    rt = r["refresh_token"]
    r2 = h.api.post("/v1/auth/refresh", json={"refresh_token": rt})
    assert r2.status_code == 200
    r3 = h.api.post("/v1/auth/refresh", json={"refresh_token": rt})  # reuse of a rotated token
    assert r3.status_code == 401 and r3.json()["error"]["code"] == "TOKEN_REUSE"
    r4 = h.api.post("/v1/auth/refresh", json={"refresh_token": r2.json()["refresh_token"]})
    assert r4.status_code == 401, "family revoked after reuse"


def test_rate_limit_login(h):
    from aureom_connect.config import get_settings

    for _ in range(get_settings().login_rate_limit_per_minute):
        h.api.post("/v1/auth/login", json={"organisation": "pennine", "email": "x@y.z", "password": "bad"})
    r = h.api.post("/v1/auth/login", json={"organisation": "pennine", "email": "x@y.z", "password": "bad"})
    assert r.status_code == 429 and r.json()["error"]["code"] == "RATE_LIMITED"


def test_log_redaction(caplog):
    from aureom_connect.security.redaction import RedactingFilter, redact

    logger = logging.getLogger("aureom.test")
    logger.addFilter(RedactingFilter())
    with caplog.at_level(logging.INFO, logger="aureom.test"):
        logger.info("caller +44 113 496 0145 emailed jane.doe@example.org card 4111 1111 1111 1111 "
                    "Bearer abc.def.ghi")
    msg = caplog.records[-1].getMessage()
    assert "496 0145" not in msg and "jane.doe" not in msg and "4111" not in msg and "abc.def" not in msg
    assert redact({"password": "x", "nested": {"token": "y"}}) == {"password": "[redacted]",
                                                                   "nested": {"token": "[redacted]"}}


def test_audit_chain_detects_tampering(h, db):
    h.make_ready("amira.khan")
    assert verify_chain(db)["valid"]
    with session_scope() as s:
        s.execute(text("update audit_log set details = '{\"tampered\": true}' where seq = "
                       "(select min(seq) + 1 from audit_log)"))
    res = verify_chain(db)
    assert res["valid"] is False and res["broken_at_seq"]


def test_oidc_id_token_validation_and_mfa_evidence():
    from aureom_connect.security.auth import validate_id_token

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    now = int(time.time())
    base = {"iss": "https://idp.example", "aud": "aureom", "sub": "u1", "iat": now, "exp": now + 300,
            "nonce": "n1", "email": "amira.khan@pennine.example"}
    tok = jwt.encode({**base, "amr": ["pwd", "mfa"]}, key, algorithm="RS256")
    claims, mfa = validate_id_token(tok, signing_key=key.public_key(), issuer="https://idp.example", audience="aureom",
                                    nonce="n1", mfa_amr_values=["mfa"])
    assert mfa and claims["sub"] == "u1"
    tok = jwt.encode({**base, "amr": ["pwd"]}, key, algorithm="RS256")
    assert validate_id_token(tok, signing_key=key.public_key(), issuer="https://idp.example", audience="aureom",
                             nonce="n1", mfa_amr_values=["mfa"])[1] is False
    with pytest.raises(Exception):
        validate_id_token(tok, signing_key=key.public_key(), issuer="https://idp.example", audience="aureom",
                          nonce="WRONG", mfa_amr_values=["mfa"])
    other = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    with pytest.raises(jwt.InvalidSignatureError):
        validate_id_token(jwt.encode(base, other, algorithm="RS256"), signing_key=key.public_key(),
                          issuer="https://idp.example", audience="aureom", nonce="n1", mfa_amr_values=["mfa"])


def test_secrets_encrypted_at_rest(db):
    row = db.execute(text("select totp_secret_enc from users where email='kit.admin@pennine.example'")).scalar_one()
    assert "KRSXG5" not in row and row.startswith("gAAAA")


# ---------------------------------------------------------------- channels & events

def test_webchat_flow(h):
    r = h.api.post("/v1/channels/webchat/sessions",
                   json={"name": "Sam", "topic": "TECH", "first_message": "My water is brown"})
    assert r.status_code == 201
    sess = r.json()
    h.make_ready("ben.hughes")
    iid = h.accept_first_offer("ben.hughes")
    assert iid == str(sess["session_id"])
    r = h.api.post(f"/v1/interactions/{iid}/messages", headers=h.login("ben.hughes"),
                   json={"body": "Sorry to hear that. Can you tell me your postcode?"})
    assert r.status_code == 200
    bad = h.api.get(f"/v1/channels/webchat/sessions/{iid}/messages", headers={"Authorization": "Bearer nope"})
    assert bad.status_code == 401
    msgs = h.api.get(f"/v1/channels/webchat/sessions/{iid}/messages",
                     headers={"Authorization": f"Bearer {sess['token']}"}).json()
    assert [m["sender"] for m in msgs["messages"]] == ["customer", "agent"] and msgs["agent_joined"]
    r = h.api.post(f"/v1/interactions/{iid}/wrap-up", headers=h.h("ben.hughes"), json={"disposition_code": "info_provided"})
    assert r.status_code == 200 and r.json()["status"] == "completed"


def test_email_channel(h):
    r = h.api.post("/v1/channels/email/inbound", headers=h.login("grace.thornton"),
                   json={"from_address": "rhys.morgan@example.org", "subject": "Bill query", "body": "Why so high?",
                         "queue": "BILLING"})
    assert r.status_code == 202
    h.make_ready("amira.khan")
    iid = h.accept_first_offer("amira.khan")
    d = h.interaction("amira.khan", iid)
    assert d["channel"] == "email" and d["messages"][0]["body"] == "Why so high?"
    assert d["customer_match_status"] == "candidates"


def test_websocket_auth_and_resume(h):
    tok = h.tokens.get("amira.khan@pennine.example") or h.login("amira.khan")["Authorization"].split()[1]
    with h.api.websocket_connect("/v1/events") as ws:
        ws.send_json({"type": "auth", "token": "garbage"})
        with pytest.raises(Exception):
            ws.receive_json()
    with h.api.websocket_connect("/v1/events") as ws:
        ws.send_json({"type": "auth", "token": tok})
        ready = ws.receive_json()
        assert ready["type"] == "ready"
        ws.send_json({"type": "subscribe", "since": 0})
        ev = ws.receive_json()
        assert ev["type"] == "event" and ev["id"] > 0
        ws.send_json({"type": "ping"})
        while True:
            m = ws.receive_json()
            if m["type"] == "pong":
                break
        assert m["agent"]["state"] in ("offline", "available", "unavailable")


# ---------------------------------------------------------------- Twilio adapter (offline unit checks)

def test_twilio_adapter_signature_token_and_capabilities():
    from aureom_connect.adapters.telephony.twilio import TwilioAdapter, sanitise_identity, twilio_signature

    a = TwilioAdapter(account_sid="ACxxxxxxxx", api_key_sid="SKxxxxxxxx", api_key_secret="s" * 32,
                      auth_token="authtoken", twiml_app_sid="APxxxxxxxx")
    url = "https://example.test/v1/providers/twilio/events"
    params = {"CallSid": "CA1", "CallStatus": "ringing", "From": "+441134960145"}
    data = url + "".join(f"{k}{params[k]}" for k in sorted(params))
    expected = base64.b64encode(hmac.new(b"authtoken", data.encode(), hashlib.sha1).digest()).decode()
    assert twilio_signature("authtoken", url, params) == expected
    body = "&".join(f"{k}={v}" for k, v in params.items()).replace("+", "%2B").encode()
    assert a.verify_webhook({"X-Twilio-Signature": expected, "Content-Type": "application/x-www-form-urlencoded"},
                            body, url)
    assert not a.verify_webhook({"X-Twilio-Signature": "bad"}, body, url)
    cred = a.issue_media_credential("agent:1234-abcd")
    hdr = jwt.get_unverified_header(cred.token)
    claims = jwt.decode(cred.token, "s" * 32, algorithms=["HS256"])
    assert hdr["cty"] == "twilio-fpa;v=1"
    assert claims["iss"] == "SKxxxxxxxx" and claims["sub"] == "ACxxxxxxxx"
    assert claims["grants"]["identity"] == sanitise_identity("agent:1234-abcd") == "agent_1234_abcd"
    caps = a.capabilities()
    assert caps.end and not caps.hold and not caps.warm_transfer and not caps.answer
    assert a.hold("CA1", "CA1", request_id="r").outcome == "rejected"
    ev = a.parse_events(body, {})[0]
    assert ev.type == "leg.ringing" and ev.provider_call_id == "CA1"
