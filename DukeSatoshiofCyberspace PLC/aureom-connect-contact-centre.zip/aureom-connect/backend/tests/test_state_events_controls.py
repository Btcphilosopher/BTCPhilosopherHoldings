"""Agent state machine, provider event handling, call controls."""
from __future__ import annotations

import json
import time
import uuid

from sqlalchemy import select, text

from aureom_connect.db import session_scope
from aureom_connect.models import Agent, CallControl, Job, ProviderEvent
from aureom_sim.app import sign


def _connected_call(h, who="amira.khan", digits="1", number="+441134960145"):
    h.make_ready(who)
    h.inbound(from_number=number, digits=digits)
    return h.accept_first_offer(who)


# ---------------------------------------------------------------- agent state

def test_system_states_cannot_be_requested(h):
    h.make_ready("amira.khan")
    for state in ("on_interaction", "call_offered", "connecting", "after_call_work"):
        r = h.api.put("/v1/agents/me/availability", headers=h.login("amira.khan"), json={"state": state})
        assert r.status_code == 422 and r.json()["error"]["code"] == "STATE_NOT_REQUESTABLE"


def test_cannot_go_offline_mid_call_and_version_checked(h):
    iid = _connected_call(h)
    r = h.api.put("/v1/agents/me/availability", headers=h.login("amira.khan"), json={"state": "break"})
    assert r.status_code == 409
    ws = h.workspace("amira.khan")
    r = h.api.put("/v1/agents/me/availability", headers=h.login("amira.khan"),
                  json={"state": "available", "expected_version": ws["agent"]["state_version"] - 1})
    assert r.status_code == 409
    assert iid


def test_device_loss_while_available_makes_unavailable(h):
    h.make_ready("amira.khan")
    h.sim.post(f"/v1/demo/devices/agent:{h.agent_id('amira.khan')}/drop", headers={"X-Sim-Api-Key": h.sim_cfg.api_key})
    h.pump()
    a = h.workspace("amira.khan")["agent"]
    assert a["telephony_registration"] == "unregistered"
    assert a["state"] == "unavailable"
    assert "device_lost" in a["state_reason"]


def test_device_loss_on_call_requires_reconciliation(h):
    _connected_call(h)
    h.sim.post(f"/v1/demo/devices/agent:{h.agent_id('amira.khan')}/drop", headers={"X-Sim-Api-Key": h.sim_cfg.api_key})
    h.pump()
    a = h.workspace("amira.khan")["agent"]
    assert a["state"] == "on_interaction"  # the call continues at the provider
    assert a["reconcile_required"] is True


def test_browser_disconnect_sweep(h):
    h.make_ready("amira.khan")
    with session_scope() as s:
        s.execute(text("update agents set presence_last_seen = now() - interval '5 minutes' "
                       "where display_name='Amira Khan'"))
    h.tick()
    a = h.workspace("amira.khan")["agent"]  # the workspace call itself does not refresh presence
    assert a["presence"] == "offline"
    assert a["state"] == "unavailable" and a["state_reason"] == "application_disconnected"


# ---------------------------------------------------------------- provider events

def test_invalid_signature_rejected(h):
    body = json.dumps({"events": [{"id": "EVforged", "type": "call.initiated", "occurred_at": "2026-11-26T10:00:00+00:00",
                                   "call_id": "CAx", "data": {"to_number": "+441614960100"}}]}).encode()
    ts = str(int(time.time()))
    r = h.api.post("/v1/providers/simulated/events", content=body,
                   headers={"X-Sim-Timestamp": ts, "X-Sim-Signature": sign("wrong-secret", ts, body)})
    assert r.status_code == 401
    old = str(int(time.time()) - 3600)
    r = h.api.post("/v1/providers/simulated/events", content=body,
                   headers={"X-Sim-Timestamp": old, "X-Sim-Signature": sign(h.sim_cfg.webhook_secret, old, body)})
    assert r.status_code == 401, "replayed (stale) webhook must be rejected"


def test_duplicate_events_are_not_reapplied(h, db):
    h.make_ready("amira.khan")
    h.faults(duplicate_next=50)
    h.inbound(from_number="+441134960145", digits="1")
    iid = h.accept_first_offer("amira.khan")
    statuses = [r["status"] for r in h.webhook_responses]
    assert "duplicate" in statuses
    dups = db.scalars(select(ProviderEvent).where(ProviderEvent.duplicate_count > 0)).all()
    assert dups
    d = h.interaction("amira.khan", iid)
    assert len([e for e in d["timeline"] if e["type"] == "call.received"]) == 1
    assert len([qe for qe in d["queue_entries"]]) == 1


def test_out_of_order_events_do_not_regress_state(h, db):
    iid = _connected_call(h)
    d = h.interaction("amira.khan", iid)
    cust_leg = next(lg for lg in d["call"]["legs"] if lg["leg_type"] == "customer")
    # Deliver hold, then a late duplicate-id-free "resumed" with an OLDER sequence: must be ignored.
    h.faults(reorder_next=1)
    r = h.action("amira.khan", iid, "hold")
    assert r.status_code == 202
    h.pump()
    h.engine.flush_reorder_buffer()
    h.pump()
    call_id = d["call"]["provider_call_id"]
    stale = {"id": f"EV{uuid.uuid4().hex[:12]}", "type": "leg.resumed", "occurred_at": "2026-01-01T00:00:00+00:00",
             "sequence": 1, "call_id": call_id, "leg_id": cust_leg["provider_leg_id"], "data": {"leg_type": "customer"}}
    res = h.deliver(stale)
    assert res["status"] == "stale_ignored"  # stored for audit, never applied
    d = h.interaction("amira.khan", iid)
    leg = next(lg for lg in d["call"]["legs"] if lg["leg_type"] == "customer")
    assert leg["on_hold"] is True, "older event must not undo a newer hold"
    pe = db.scalar(select(ProviderEvent).where(ProviderEvent.provider_event_id == stale["id"]))
    assert pe.occurred_at.year == 2026 and pe.received_at > pe.occurred_at


def test_early_events_are_buffered_then_applied(h, db):
    h.make_ready("amira.khan")
    h.sim.post("/v1/demo/inbound", headers={"X-Sim-Api-Key": h.sim_cfg.api_key},
               json={"from_number": "+441134960145", "to_number": "+441614960100", "ivr_digits": "1"})
    h.run_timers(1.0)
    events = list(h.events)
    h.events.clear()
    # Deliver in reverse: leg/ivr events arrive before call.initiated.
    for ev in reversed(events):
        h.deliver(ev)
    h.pump()
    assert any(r["status"] == "unmatched" for r in h.webhook_responses)
    assert h.workspace("amira.khan")["offers"], "buffered events re-processed once the call existed"


def test_sequence_gap_schedules_reconciliation(h, db):
    iid = _connected_call(h)
    h.faults(drop_types=["leg.held"])
    h.action("amira.khan", iid, "hold")
    h.pump()
    h.faults(drop_types=[])
    h.action("amira.khan", iid, "mute")  # next event's sequence skips the dropped one
    h.pump()
    jobs = db.scalars(select(Job).where(Job.kind == "reconcile_call")).all()
    assert jobs and "sequence gap" in jobs[0].payload["reason"]
    h.tick()  # worker runs reconciliation: provider says customer is on hold
    d = h.interaction("amira.khan", iid)
    hold = next(c for c in d["controls"] if c["action"] == "hold")
    assert hold["status"] == "acknowledged" and hold["resolved_by"] == "reconciliation"


# ---------------------------------------------------------------- controls

def test_hold_is_requested_then_acknowledged_by_event(h):
    iid = _connected_call(h)
    r = h.action("amira.khan", iid, "hold")
    assert r.status_code == 202 and r.json()["status"] == "requested"
    d = h.interaction("amira.khan", iid)
    assert next(c for c in d["controls"] if c["action"] == "hold")["status"] == "requested"
    assert d["available_controls"]["hold"]["enabled"] is False  # awaiting confirmation
    h.pump()
    d = h.interaction("amira.khan", iid)
    assert next(c for c in d["controls"] if c["action"] == "hold")["status"] == "acknowledged"
    assert d["available_controls"]["resume"]["enabled"] is True
    # Mute (agent's own leg) is distinct from hold (customer leg).
    h.action("amira.khan", iid, "mute")
    h.pump()
    d = h.interaction("amira.khan", iid)
    legs = {lg["leg_type"]: lg for lg in d["call"]["legs"]}
    assert legs["customer"]["on_hold"] and not legs["customer"]["provider_muted"]
    assert legs["agent"]["provider_muted"] and not legs["agent"]["on_hold"]


def test_action_retry_does_not_resend(h):
    iid = _connected_call(h)
    key = uuid.uuid4().hex
    r1 = h.action("amira.khan", iid, "hold", idem=key)
    r2 = h.action("amira.khan", iid, "hold", idem=key)
    assert r1.json()["control_id"] == r2.json()["control_id"]
    sent = [e for e in h.engine.event_log if e["type"] == "leg.held"]
    assert len(sent) == 1


def test_provider_refusal_marks_failed(h, db):
    iid = _connected_call(h)
    h.faults(outage="refuse")
    r = h.action("amira.khan", iid, "hold")
    assert r.status_code == 202 and r.json()["status"] == "failed"
    assert r.json()["error_code"] == "PROVIDER_UNAVAILABLE"


def test_unsupported_controls_are_refused_not_simulated(h):
    iid = _connected_call(h)
    caps = h.adapter.capabilities

    def limited():
        c = caps()
        c.warm_transfer = False
        c.conference = False
        return c

    h.adapter.capabilities = limited
    d = h.interaction("amira.khan", iid)
    assert d["available_controls"]["warm_transfer_start"] == {"enabled": False,
                                                              "reason": "Not supported by provider 'simulated'"}
    r = h.action("amira.khan", iid, "warm_transfer_start", target_agent_id=h.agent_id("eilidh.fraser"))
    assert r.status_code == 422 and r.json()["error"]["code"] == "UNSUPPORTED_BY_PROVIDER"
    h.adapter.capabilities = caps


def test_wrap_up_does_not_make_available_with_live_leg(h, db):
    iid = _connected_call(h)
    h.action("amira.khan", iid, "end")
    h.pump()
    # Simulate a conflicting live leg the provider never closed.
    with session_scope() as s:
        s.execute(text("update call_legs set status='answered' where leg_type='agent'"))
    r = h.api.post(f"/v1/interactions/{iid}/wrap-up", headers=h.h("amira.khan"),
                   json={"disposition_code": "info_provided"})
    assert r.status_code == 200
    a = h.workspace("amira.khan")["agent"]
    assert a["state"] == "unavailable" and a["reconcile_required"]
