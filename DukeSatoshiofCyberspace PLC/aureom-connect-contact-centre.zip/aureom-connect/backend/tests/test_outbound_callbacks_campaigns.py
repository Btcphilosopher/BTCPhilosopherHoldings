"""Outbound eligibility and dialling, callbacks, preview campaigns."""
from __future__ import annotations

import json
import uuid
from datetime import timedelta

import pytest
from sqlalchemy import select, text

from aureom_connect.db import session_scope, utcnow
from aureom_connect.models import Callback, CallbackAttempt, Customer, OutboundAttempt


def _windows(open_all: bool = True) -> None:
    w = {str(d): [["00:00", "23:59"]] for d in range(1, 8)} if open_all else {str(d): [] for d in range(1, 8)}
    with session_scope() as s:
        s.execute(text("update calling_rule_sets set rules = jsonb_set(rules, '{calling_windows}', cast(:w as jsonb))"),
                  {"w": json.dumps(w)})


def _cust(db, ref):
    return db.scalar(select(Customer).where(Customer.customer_ref == ref))


@pytest.fixture
def open_windows(h):
    _windows(True)


def _elig(h, who="amira.khan", **body):
    r = h.api.post("/v1/outbound-calls/eligibility", headers=h.login(who), json=body)
    assert r.status_code == 200, r.text
    return {c["check"]: c for c in r.json()["checks"]}, r.json()


def test_eligibility_rules(h, db, open_windows):
    # Suppressed (internal DNC) – Lucy Barraclough.
    checks, res = _elig(h, number="+441134960188", purpose="service", customer_id=str(_cust(db, "PCS-100288").id))
    assert not checks["suppression"]["passed"] and not res["eligible"]
    # Marketing without consent – George Whitaker also has a telephone-marketing objection and preference.
    checks, res = _elig(h, number="+441134960177", purpose="marketing", customer_id=str(_cust(db, "PCS-100277").id))
    assert not checks["basis"]["passed"] and not checks["objection"]["passed"] and not checks["preference"]["passed"]
    # Marketing: number on national registry snapshot – Owen Pickles.
    checks, res = _elig(h, number="+441134960256", purpose="marketing", customer_id=str(_cust(db, "PCS-100356").id))
    assert not checks["suppression"]["passed"]
    # Service call with contract basis – eligible; records rule-set version.
    checks, res = _elig(h, number="+441134960145", purpose="service", customer_id=str(_cust(db, "PCS-100245").id))
    assert res["eligible"], res
    assert res["rule_set"]["jurisdiction"] == "GB" and res["rule_set"]["version"] == 2
    # Jurisdiction-specific: a US number is evaluated against the US rule set.
    checks, res = _elig(h, number="+12025550142", purpose="service", customer_id=str(_cust(db, "PCS-100339").id))
    assert res["rule_set"]["jurisdiction"] == "US"


def test_calling_window_blocks(h, db):
    _windows(False)
    checks, res = _elig(h, number="+441134960145", purpose="service", customer_id=str(_cust(db, "PCS-100245").id))
    assert not checks["calling_window"]["passed"] and not res["eligible"]


def test_place_eligible_call_and_refusal_recorded(h, db, open_windows):
    h.make_ready("amira.khan")
    cust = _cust(db, "PCS-100245")
    key = uuid.uuid4().hex
    r = h.api.post("/v1/outbound-calls", headers=h.h("amira.khan", key),
                   json={"number": "+441134960145", "purpose": "service", "customer_id": str(cust.id)})
    assert r.status_code == 202, r.text
    iid = r.json()["interaction_id"]
    # Retrying with the same key never re-dials.
    r2 = h.api.post("/v1/outbound-calls", headers=h.h("amira.khan", key),
                    json={"number": "+441134960145", "purpose": "service", "customer_id": str(cust.id)})
    assert r2.json()["id"] == r.json()["id"]
    assert len([e for e in h.engine.event_log if e["type"] == "call.initiated" and e["data"].get("direction") == "outbound"]) == 1
    h.pump()
    d = h.interaction("amira.khan", iid)
    assert d["status"] == "active" and d["direction"] == "outbound"
    assert d["call"]["from_number"] == "+441614960100"  # owned, verified caller ID
    assert h.workspace("amira.khan")["agent"]["state"] == "on_interaction"
    att = db.scalar(select(OutboundAttempt).where(OutboundAttempt.interaction_id == uuid.UUID(iid)))
    assert att.status == "connected" and att.eligibility["eligible"]
    h.action("amira.khan", iid, "end")
    h.pump()
    h.api.post(f"/v1/interactions/{iid}/wrap-up", headers=h.h("amira.khan"), json={"disposition_code": "info_provided"})
    # Suppressed number is refused and the refusal is recorded.
    r = h.api.post("/v1/outbound-calls", headers=h.h("amira.khan"), json={"number": "+441134960188", "purpose": "service"})
    assert r.status_code == 422 and r.json()["error"]["code"] == "OUTBOUND_NOT_PERMITTED"
    refused = db.scalar(select(OutboundAttempt).where(OutboundAttempt.status == "refused"))
    assert refused is not None and any(not c["passed"] for c in refused.eligibility["checks"])


def test_attempt_limits_and_active_attempts(h, db, open_windows):
    h.make_ready("amira.khan")
    with session_scope() as s:
        org = s.execute(text("select org_id from customers limit 1")).scalar_one()
        for i in range(2):
            s.add(OutboundAttempt(org_id=org, idempotency_key=f"x{i}", normalized_number="+441134960201",
                                  purpose="service", eligibility={}, status="no_answer",
                                  created_at=utcnow() - timedelta(hours=3 + i), ended_at=utcnow()))
    checks, res = _elig(h, number="+441134960201", purpose="service")
    assert not checks["attempt_limit"]["passed"]
    with session_scope() as s:
        s.execute(text("update outbound_attempts set status='dialling', ended_at=null, created_at=now() - interval '3 days'"))
    checks, res = _elig(h, number="+441134960201", purpose="service")
    assert not checks["no_active_attempt"]["passed"]


def test_callback_promise_wording_and_capacity(h, db):
    now = utcnow()
    body = {"phone_number": "+441134960160", "number_confirmation_method": "customer_confirmed",
            "window_start": (now + timedelta(hours=2)).isoformat(), "window_end": (now + timedelta(hours=4)).isoformat(),
            "queue": "BILLING"}
    r = h.api.post("/v1/callbacks", headers=h.h("amira.khan"), json=body)
    assert r.status_code == 201, r.text
    assert "not a guaranteed time" in r.json()["promise_text"] and not r.json()["capacity_reserved"]
    reserved = []
    for _ in range(3):
        r = h.api.post("/v1/callbacks", headers=h.h("amira.khan"), json={**body, "reserve_capacity": True})
        reserved.append(r.json()["capacity_reserved"])
    assert reserved == [True, True, False], "only configured slot capacity can be reserved"


def test_callback_processing_retry_and_ownership(h, db, open_windows):
    now = utcnow()
    cust = _cust(db, "PCS-100245")
    r = h.api.post("/v1/callbacks", headers=h.h("amira.khan"),
                   json={"phone_number": "+441134960145", "number_confirmation_method": "verified_contact_point",
                         "window_start": (now - timedelta(minutes=1)).isoformat(),
                         "window_end": (now + timedelta(hours=3)).isoformat(), "queue": "BILLING",
                         "customer_id": str(cust.id), "max_attempts": 2})
    cb_id = r.json()["id"]
    h.make_ready("amira.khan")
    h.tick()
    iid = h.accept_first_offer("amira.khan")
    cb = h.api.get(f"/v1/callbacks/{cb_id}", headers=h.login("amira.khan")).json()
    assert cb["status"] == "in_progress" and cb["owner_agent_id"] == h.agent_id("amira.khan")
    h.faults(outbound_outcome="no_answer")
    r = h.api.post("/v1/outbound-calls", headers=h.h("amira.khan"), json={"interaction_id": iid})
    assert r.status_code == 202, r.text
    # A second, concurrent attempt on the same callback is refused.
    r2 = h.api.post("/v1/outbound-calls", headers=h.h("amira.khan"), json={"interaction_id": iid})
    assert r2.status_code in (409, 422)
    h.pump()
    assert h.workspace("amira.khan")["agent"]["state"] == "after_call_work"
    h.api.post(f"/v1/interactions/{iid}/wrap-up", headers=h.h("amira.khan"), json={"disposition_code": "no_answer"})
    cb = h.api.get(f"/v1/callbacks/{cb_id}", headers=h.login("amira.khan")).json()
    assert cb["status"] == "pending" and cb["attempts"] == 1
    assert cb["attempt_history"][0]["result"] == "no_answer"
    # Second (final) attempt also unanswered → exhausted.
    with session_scope() as s:
        s.execute(text("update callbacks set window_start = now() - interval '1 minute' where id=:i"), {"i": cb_id})
        s.execute(text("delete from outbound_attempts"))  # isolate attempt spacing from the first call
    h.tick()
    iid2 = h.accept_first_offer("amira.khan")
    h.api.post("/v1/outbound-calls", headers=h.h("amira.khan"), json={"interaction_id": iid2})
    h.pump()
    h.api.post(f"/v1/interactions/{iid2}/wrap-up", headers=h.h("amira.khan"), json={"disposition_code": "no_answer"})
    cb = h.api.get(f"/v1/callbacks/{cb_id}", headers=h.login("amira.khan")).json()
    assert cb["status"] == "exhausted" and cb["attempts"] == 2


def test_callback_cancel_requires_reason(h):
    now = utcnow()
    r = h.api.post("/v1/callbacks", headers=h.h("amira.khan"),
                   json={"phone_number": "+441134960160", "window_start": (now + timedelta(hours=1)).isoformat(),
                         "window_end": (now + timedelta(hours=2)).isoformat(), "queue": "TECH"})
    cb = r.json()
    r = h.api.post(f"/v1/callbacks/{cb['id']}/cancel", headers=h.login("amira.khan"), json={"reason": ""})
    assert r.status_code == 422
    r = h.api.post(f"/v1/callbacks/{cb['id']}/cancel", headers=h.login("amira.khan"),
                   json={"reason": "customer called back", "expected_version": cb["version"]})
    assert r.status_code == 200 and r.json()["status"] == "cancelled"


def test_campaign_import_review_and_four_eyes(h, db, open_windows):
    sup = h.login("grace.thornton")
    camps = h.api.get("/v1/campaigns", headers=sup).json()
    draft = next(c for c in camps if c["status"] == "draft")
    csv = ("name,phone,customer_ref,timezone\nAisha Rahman,+441134960160,PCS-100260,Europe/London\n"
           "George Whitaker,+441134960177,PCS-100277,Europe/London\nBad Row,12345,,Europe/London\n"
           "Dup,+441134960160,,Europe/London\nOwen Pickles,+441134960256,PCS-100356,Mars/Base\n")
    r = h.api.post(f"/v1/campaigns/{draft['id']}/imports", headers=sup,
                   files={"file": ("list.csv", csv.encode(), "text/csv")})
    assert r.status_code == 202, r.text
    h.tick()
    c = h.api.get(f"/v1/campaigns/{draft['id']}", headers=sup).json()
    imp = c["imports"][0]
    assert c["status"] == "review"
    assert (imp["total_rows"], imp["valid_rows"], imp["invalid_rows"]) == (5, 2, 3)
    assert c["review_summary"]["by_status"] == {"ready": 1, "excluded": 1}  # George: objection/no consent
    r = h.api.post(f"/v1/campaigns/{draft['id']}/activate", headers=sup, json={"expected_version": c["version"]})
    assert r.status_code == 403 and r.json()["error"]["code"] == "FOUR_EYES_REQUIRED"
    r = h.api.post(f"/v1/campaigns/{draft['id']}/activate", headers=h.login("sam.okafor"),
                   json={"expected_version": c["version"]})
    assert r.status_code == 200 and r.json()["status"] == "active"


def test_preview_campaign_rechecks_at_dial(h, db, open_windows):
    h.make_ready("femi.adeyemi")
    camp = next(c for c in h.api.get("/v1/campaigns", headers=h.login("femi.adeyemi")).json() if c["status"] == "active")
    r = h.api.post(f"/v1/campaigns/{camp['id']}/next", headers=h.login("femi.adeyemi"))
    assert r.status_code == 200, r.text
    prev = r.json()
    iid = prev["interaction_id"]
    # An objection recorded after the preview must block the dial.
    cust_id = prev["contact"]["customer_id"]
    h.api.post(f"/v1/customers/{cust_id}/objections", headers=h.login("femi.adeyemi"),
               json={"scope": "all_telephone", "note": "asked not to be called"})
    r = h.api.post("/v1/outbound-calls", headers=h.h("femi.adeyemi"), json={"interaction_id": iid})
    assert r.status_code == 422
    assert any(c["check"] == "objection" for c in r.json()["error"]["details"]["failed"])
    r = h.api.post(f"/v1/interactions/{iid}/skip-preview", headers=h.login("femi.adeyemi"),
                   json={"reason": "customer objected"})
    assert r.status_code == 200
    assert h.workspace("femi.adeyemi")["agent"]["state"] == "available"
