"""Test fixtures.

A template database is migrated with Alembic and seeded once per session; each
test gets its own copy (``CREATE DATABASE … TEMPLATE``) so tests are isolated
and run against real PostgreSQL semantics (row locks, advisory locks, JSONB,
full-text search).
"""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import uuid
from pathlib import Path

import psycopg
import pytest

ADMIN_URL = os.environ.get("AUREOM_TEST_ADMIN_URL", "postgresql://postgres@127.0.0.1:55432/postgres")
SA_PREFIX = "postgresql+psycopg://"
TEMPLATE = "aureom_test_template"
BACKEND = Path(__file__).resolve().parents[1]

os.environ.setdefault("AUREOM_ENVIRONMENT", "test")
os.environ.setdefault("AUREOM_STORAGE_DIR", tempfile.mkdtemp(prefix="aureom-test-objects-"))
os.environ.setdefault("AUREOM_AI_PROVIDER", "heuristic")


def _db_url(name: str) -> str:
    base = ADMIN_URL.rsplit("/", 1)[0]
    return f"{SA_PREFIX}{base.split('://', 1)[1]}/{name}"


def _admin(sql: str) -> None:
    with psycopg.connect(ADMIN_URL, autocommit=True) as c:
        c.execute(sql)


@pytest.fixture(scope="session")
def template_db():
    _admin(f"DROP DATABASE IF EXISTS {TEMPLATE} WITH (FORCE)")
    _admin(f"CREATE DATABASE {TEMPLATE}")
    env = {**os.environ, "AUREOM_DATABASE_URL": _db_url(TEMPLATE)}
    subprocess.run([sys.executable, "-m", "alembic", "upgrade", "head"], cwd=BACKEND, env=env, check=True,
                   capture_output=True)
    subprocess.run([sys.executable, "-m", "aureom_connect.cli", "seed"], cwd=BACKEND, env=env, check=True,
                   capture_output=True)
    yield TEMPLATE
    _admin(f"DROP DATABASE IF EXISTS {TEMPLATE} WITH (FORCE)")


@pytest.fixture
def db_url(template_db):
    name = f"aureom_t_{uuid.uuid4().hex[:10]}"
    _admin(f"CREATE DATABASE {name} TEMPLATE {template_db}")
    url = _db_url(name)
    from aureom_connect.db import reset_engine

    reset_engine(url)
    yield url
    from aureom_connect.db import get_engine

    get_engine().dispose()
    _admin(f"DROP DATABASE IF EXISTS {name} WITH (FORCE)")


@pytest.fixture
def h(db_url, request):
    from aureom_connect.main import app
    from aureom_connect.security.ratelimit import limiter

    from .harness import Harness

    limiter.reset()
    harness = Harness(app)
    if not request.node.get_closest_marker("seed_callbacks"):
        # Seeded callbacks would (correctly) be routed first; most tests want a clean queue.
        from sqlalchemy import text

        from aureom_connect.db import session_scope

        with session_scope() as s:
            s.execute(text("UPDATE callbacks SET status='cancelled', cancelled_reason='test isolation'"))
    harness.tick()  # first health check → provider connected
    yield harness
    from aureom_connect.adapters.telephony.registry import set_provider

    set_provider(None)


@pytest.fixture
def db(db_url):
    from aureom_connect.db import session_factory

    s = session_factory()()
    yield s
    s.close()
