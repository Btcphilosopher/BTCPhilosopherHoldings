'use client';

import React, { useState } from 'react';
import { WhiskyDesign, CaskEntity, WoodSpecies, CaskSeasoning } from '@/types/whisky';
import { SYNTHETIC_CASKS, SYNTHETIC_WAREHOUSES } from '@/lib/data/synthetic-db';
import { Wine, Search, Plus, Filter, ShieldCheck, History, ArrowRight } from 'lucide-react';

interface CaskLabProps {
  design: WhiskyDesign;
  onUpdateDesign: (updated: WhiskyDesign) => void;
}

export const CaskLab: React.FC<CaskLabProps> = ({
  design,
  onUpdateDesign,
}) => {
  const [casks, setCasks] = useState<CaskEntity[]>(SYNTHETIC_CASKS);
  const [selectedCask, setSelectedCask] = useState<CaskEntity>(SYNTHETIC_CASKS[0]);
  const [filterSeasoning, setFilterSeasoning] = useState<string>('ALL');

  const filteredCasks = filterSeasoning === 'ALL'
    ? casks
    : casks.filter(c => c.seasoning.toLowerCase().includes(filterSeasoning.toLowerCase()));

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#171513] border border-[#2E2822] p-5 rounded-lg">
        <div>
          <div className="text-xs font-mono text-[#C67D38] uppercase">STAGE 7 &bull; CASK PROGRAMME & WOOD INVENTORY</div>
          <h2 className="font-editorial text-2xl font-bold text-[#F5F2EB]">
            Cooperage Specifications, Wood Species & Cask Lifecycle
          </h2>
          <p className="text-xs text-[#8C8476] mt-0.5">
            Track Quercus alba vs Quercus robur, seasoning histories, toast/char extraction, and cask audit trails.
          </p>
        </div>

        <div className="flex items-center gap-3 text-xs font-mono">
          <span className="text-[#8C8476]">Total Active Stock:</span>
          <span className="text-[#FAF7F0] font-bold">{casks.length} Casks in Lab Vault</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (5 cols): Cask Inventory List with Filters */}
        <div className="lg:col-span-5 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-[#2A241E] pb-3">
            <div>
              <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                Cask Inventory Browser
              </h3>
              <p className="text-xs text-[#8C8476]">
                Select cask to inspect extraction properties & lifecycle
              </p>
            </div>
            <div className="flex items-center gap-1">
              <select
                value={filterSeasoning}
                onChange={(e) => setFilterSeasoning(e.target.value)}
                className="bg-[#12110F] text-[#FAF7F0] text-xs font-mono px-2 py-1 rounded border border-[#332A22] focus:outline-none focus:border-[#C67D38]"
              >
                <option value="ALL">All Seasonings</option>
                <option value="Bourbon">ex-Bourbon</option>
                <option value="Sherry">ex-Sherry</option>
                <option value="Pedro">ex-PX</option>
                <option value="Port">ex-Port</option>
                <option value="Virgin">Virgin Oak</option>
                <option value="Refill">Refill Hogshead</option>
              </select>
            </div>
          </div>

          {/* Cask List */}
          <div className="space-y-2 max-h-[560px] overflow-y-auto pr-1">
            {filteredCasks.map(c => (
              <div
                key={c.id}
                onClick={() => setSelectedCask(c)}
                className={`p-3 rounded border cursor-pointer transition-all ${
                  selectedCask.id === c.id
                    ? 'bg-[#2A2016] border-[#C67D38] text-[#FAF7F0]'
                    : 'bg-[#12110F] border-[#2E2822] text-[#A69E91] hover:border-[#483B2F]'
                }`}
              >
                <div className="flex justify-between items-center text-xs font-mono">
                  <span className="font-bold text-[#FAF7F0]">{c.caskNumber}</span>
                  <span className="text-[#E5A93C] font-semibold">{c.ageYears} YO</span>
                </div>
                <div className="text-[11px] text-[#8C8476] mt-1 font-mono flex justify-between">
                  <span>{c.seasoning} &bull; {c.woodSpecies.split('(')[0]}</span>
                  <span>{c.currentVolumeLitres} L ({c.currentABVPct}%)</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column (7 cols): Selected Cask Deep Dive & Lifecycle Audit */}
        <div className="lg:col-span-7 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-5">
          <div className="flex items-center justify-between border-b border-[#2A241E] pb-3">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-editorial text-xl font-bold text-[#F5F2EB]">
                  {selectedCask.caskNumber}
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#132A1B] text-[#52C47C] border border-[#214D2E]">
                  {selectedCask.status}
                </span>
              </div>
              <p className="text-xs text-[#8C8476] mt-0.5">
                Location: {selectedCask.rackLocation} &bull; Warehouse: {selectedCask.warehouseId}
              </p>
            </div>

            <div className="text-right font-mono text-xs">
              <div className="text-[10px] text-[#8C8476]">ESTIMATED VALUE:</div>
              <div className="text-base font-bold text-[#FAF7F0]">£{selectedCask.valuationGBP.toLocaleString()}</div>
            </div>
          </div>

          {/* Cooperage & Wood Matrix */}
          <div className="bg-[#12110F] p-4 rounded border border-[#2E2822] space-y-3 text-xs font-mono">
            <div className="text-[#C67D38] font-bold uppercase text-[11px]">
              COOPERAGE & CHEMICAL EXTRACTION PROFILE
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div>
                <span className="text-[#8C8476] block">WOOD SPECIES:</span>
                <span className="text-[#FAF7F0] font-bold">{selectedCask.woodSpecies}</span>
              </div>
              <div>
                <span className="text-[#8C8476] block">SEASONING:</span>
                <span className="text-[#E5A93C] font-bold">{selectedCask.seasoning}</span>
              </div>
              <div>
                <span className="text-[#8C8476] block">TOAST / CHAR:</span>
                <span className="text-[#FAF7F0] font-bold">{selectedCask.toastLevel} &bull; {selectedCask.charLevel}</span>
              </div>
              <div>
                <span className="text-[#8C8476] block">FILL DATE / AGE:</span>
                <span className="text-[#FAF7F0] font-bold">{selectedCask.fillDate} ({selectedCask.ageYears} YO)</span>
              </div>
              <div>
                <span className="text-[#8C8476] block">CURRENT VOLUME:</span>
                <span className="text-[#FAF7F0] font-bold">{selectedCask.currentVolumeLitres} L / {selectedCask.capacityLitres} L</span>
              </div>
              <div>
                <span className="text-[#8C8476] block">CURRENT STRENGTH:</span>
                <span className="text-[#FAF7F0] font-bold">{selectedCask.currentABVPct}% ABV</span>
              </div>
            </div>
          </div>

          {/* Sensory Contribution of Cask */}
          <div className="bg-[#12110F] p-4 rounded border border-[#2E2822] space-y-2 text-xs font-mono">
            <div className="text-[#E5A93C] font-bold uppercase text-[11px]">
              PREDICTED SENSORY CONTRIBUTION VECTOR
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-[11px]">
              <div>
                <span className="text-[#8C8476]">Vanilla:</span>{' '}
                <span className="text-[#FAF7F0] font-bold">{selectedCask.sensoryContribution.vanilla.toFixed(2)}</span>
              </div>
              <div>
                <span className="text-[#8C8476]">Oak:</span>{' '}
                <span className="text-[#FAF7F0] font-bold">{selectedCask.sensoryContribution.oak.toFixed(2)}</span>
              </div>
              <div>
                <span className="text-[#8C8476]">Dried Fruit:</span>{' '}
                <span className="text-[#FAF7F0] font-bold">{selectedCask.sensoryContribution.driedFruit.toFixed(2)}</span>
              </div>
              <div>
                <span className="text-[#8C8476]">Spice:</span>{' '}
                <span className="text-[#FAF7F0] font-bold">{selectedCask.sensoryContribution.spice.toFixed(2)}</span>
              </div>
              <div>
                <span className="text-[#8C8476]">Caramel:</span>{' '}
                <span className="text-[#FAF7F0] font-bold">{selectedCask.sensoryContribution.caramel.toFixed(2)}</span>
              </div>
              <div>
                <span className="text-[#8C8476]">Tannin Grip:</span>{' '}
                <span className="text-[#FAF7F0] font-bold">{selectedCask.sensoryContribution.tannin.toFixed(2)}</span>
              </div>
              <div>
                <span className="text-[#8C8476]">Palate Body:</span>{' '}
                <span className="text-[#FAF7F0] font-bold">{selectedCask.sensoryContribution.body.toFixed(2)}</span>
              </div>
              <div>
                <span className="text-[#8C8476]">Finish Length:</span>{' '}
                <span className="text-[#FAF7F0] font-bold">{selectedCask.sensoryContribution.finish.toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Cask Lifecycle Audit History */}
          <div className="bg-[#12110F] p-4 rounded border border-[#2E2822] space-y-3 text-xs font-mono">
            <div className="flex items-center gap-1.5 text-[#52C47C] font-bold uppercase text-[11px]">
              <History className="w-3.5 h-3.5" />
              <span>CASK LIFECYCLE AUDIT TRAIL</span>
            </div>

            <div className="space-y-2 border-l-2 border-[#2E2822] pl-3">
              <div className="text-[11px]">
                <span className="text-[#C67D38] font-bold">2006-04-18:</span>{' '}
                <span className="text-[#FAF7F0]">Initial Spirit Fill at 63.5% ABV ({selectedCask.capacityLitres}L)</span> &bull; Operator: J. Fraser
              </div>
              <div className="text-[11px]">
                <span className="text-[#C67D38] font-bold">2016-04-20:</span>{' '}
                <span className="text-[#FAF7F0]">10-Year Quality Sampling & Regauging</span> &bull; 174.2 L @ 59.8% ABV
              </div>
              <div className="text-[11px]">
                <span className="text-[#C67D38] font-bold">2026-08-14:</span>{' '}
                <span className="text-[#FAF7F0]">Sensory Panel Approved for Master Blend Allocation</span> &bull; Conformance: Optimal
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
