'use client';

import React, { useState } from 'react';
import { WhiskyDesign, TargetWhiskyProfile, SensoryAxisProfile, ScotchRegion, WhiskyStyle } from '@/types/whisky';
import { SensoryRadar } from './SensoryRadar';
import { Sliders, Save, RotateCcw, Check, Sparkles } from 'lucide-react';

interface TargetDesignerProps {
  design: WhiskyDesign;
  onUpdateDesign: (updated: WhiskyDesign) => void;
}

const REGIONS: ScotchRegion[] = ['Highland', 'Speyside', 'Islay', 'Campbeltown', 'Lowland', 'Islands'];
const STYLES: WhiskyStyle[] = ['Single Malt', 'Single Cask', 'Small Batch', 'Blended Malt', 'Grain', 'Experimental'];

export const TargetDesigner: React.FC<TargetDesignerProps> = ({
  design,
  onUpdateDesign,
}) => {
  const [target, setTarget] = useState<TargetWhiskyProfile>(design.targetProfile);
  const [isSaved, setIsSaved] = useState(false);

  const handleSensoryChange = (key: keyof SensoryAxisProfile, value: number) => {
    setTarget(prev => ({
      ...prev,
      sensory: {
        ...prev.sensory,
        [key]: Math.round(value * 100) / 100,
      },
    }));
    setIsSaved(false);
  };

  const handleSave = () => {
    onUpdateDesign({
      ...design,
      targetProfile: target,
      updatedAt: new Date().toISOString().split('T')[0],
    });
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2500);
  };

  const handleApplyPreset = (presetName: string) => {
    let presetSensory: Partial<SensoryAxisProfile> = {};
    if (presetName === 'Highland Elegant') {
      presetSensory = {
        fruit: 0.82, floral: 0.50, malt: 0.40, cereal: 0.25, spice: 0.66,
        oak: 0.58, vanilla: 0.71, caramel: 0.60, nut: 0.50, driedFruit: 0.45,
        smoke: 0.21, medicinal: 0.05, mineral: 0.42, body: 0.78, dryness: 0.68,
        sweetness: 0.60, finish: 0.91, complexity: 0.88, oiliness: 0.55, tannin: 0.45,
      };
    } else if (presetName === 'Islay Maritime Peat') {
      presetSensory = {
        fruit: 0.65, floral: 0.30, malt: 0.45, cereal: 0.35, spice: 0.62,
        oak: 0.65, vanilla: 0.72, caramel: 0.55, nut: 0.45, driedFruit: 0.30,
        smoke: 0.88, medicinal: 0.82, mineral: 0.75, salt: 0.70, herbal: 0.45,
        body: 0.85, dryness: 0.72, sweetness: 0.52, finish: 0.94, complexity: 0.90,
      };
    } else if (presetName === 'Speyside Sherry Bomb') {
      presetSensory = {
        fruit: 0.85, floral: 0.35, malt: 0.42, cereal: 0.20, spice: 0.86,
        oak: 0.88, vanilla: 0.55, caramel: 0.88, nut: 0.82, driedFruit: 0.95,
        smoke: 0.05, medicinal: 0.02, mineral: 0.32, body: 0.92, dryness: 0.68,
        sweetness: 0.85, finish: 0.93, complexity: 0.92, oiliness: 0.70, tannin: 0.65,
      };
    }

    setTarget(prev => ({
      ...prev,
      sensory: {
        ...prev.sensory,
        ...presetSensory,
      },
    }));
    setIsSaved(false);
  };

  const sensorySliders: { key: keyof SensoryAxisProfile; label: string; group: string }[] = [
    // Fruit / Floral / Grain
    { key: 'fruit', label: 'Orchard & Fresh Fruit', group: 'Distillate Character' },
    { key: 'floral', label: 'Floral & Blossom', group: 'Distillate Character' },
    { key: 'malt', label: 'Malted Barley Backbone', group: 'Distillate Character' },
    { key: 'cereal', label: 'Biscuity / Cereal Grist', group: 'Distillate Character' },
    { key: 'oiliness', label: 'Distillate Viscosity / Oiliness', group: 'Distillate Character' },
    // Wood / Oak / Maturation
    { key: 'oak', label: 'Toasted Oak Structure', group: 'Maturation Character' },
    { key: 'vanilla', label: 'Bourbon Vanillin', group: 'Maturation Character' },
    { key: 'spice', label: 'Baking Spices (Clove, Cinnamon)', group: 'Maturation Character' },
    { key: 'caramel', label: 'Toffee / Caramel Sweetness', group: 'Maturation Character' },
    { key: 'nut', label: 'Toasted Nut / Hazelnut', group: 'Maturation Character' },
    { key: 'driedFruit', label: 'Dried Fruit / Sherry Raisin', group: 'Maturation Character' },
    { key: 'tannin', label: 'Wood Tannin Grip', group: 'Maturation Character' },
    // Peat / Maritime / Mineral
    { key: 'smoke', label: 'Peat Smoke Phenols', group: 'Peat & Terroir' },
    { key: 'medicinal', label: 'Medicinal / Iodine / Seaweed', group: 'Peat & Terroir' },
    { key: 'mineral', label: 'Flint / Granite Mineral', group: 'Peat & Terroir' },
    { key: 'salt', label: 'Coastal Sea Salt', group: 'Peat & Terroir' },
    { key: 'herbal', label: 'Highland Heather / Pine', group: 'Peat & Terroir' },
    // Structure & Mouthfeel
    { key: 'body', label: 'Palate Body & Weight', group: 'Palate Structure' },
    { key: 'dryness', label: 'Finish Dryness', group: 'Palate Structure' },
    { key: 'sweetness', label: 'Malt & Wood Sweetness', group: 'Palate Structure' },
    { key: 'finish', label: 'Finish Persistence & Length', group: 'Palate Structure' },
    { key: 'complexity', label: 'Overall Structural Complexity', group: 'Palate Structure' },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#171513] border border-[#2E2822] p-5 rounded-lg">
        <div>
          <div className="text-xs font-mono text-[#C67D38] uppercase">STAGE 1 &bull; TARGET SPECIFICATION</div>
          <h2 className="font-editorial text-2xl font-bold text-[#F5F2EB]">
            Whisky Objective & Sensory Target Designer
          </h2>
          <p className="text-xs text-[#8C8476] mt-0.5">
            Specify the desired target sensory dimensions, target age, edition size, and commercial positioning.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 bg-[#12110F] p-1 rounded border border-[#2B251F] text-xs">
            <span className="text-[#7A7264] px-2 font-mono">PRESETS:</span>
            <button
              onClick={() => handleApplyPreset('Highland Elegant')}
              className="px-2.5 py-1 rounded bg-[#1F1C18] hover:bg-[#2A2621] text-[#C5BDB2] text-xs transition-colors"
            >
              Highland Elegant
            </button>
            <button
              onClick={() => handleApplyPreset('Islay Maritime Peat')}
              className="px-2.5 py-1 rounded bg-[#1F1C18] hover:bg-[#2A2621] text-[#C5BDB2] text-xs transition-colors"
            >
              Islay Maritime Peat
            </button>
            <button
              onClick={() => handleApplyPreset('Speyside Sherry Bomb')}
              className="px-2.5 py-1 rounded bg-[#1F1C18] hover:bg-[#2A2621] text-[#C5BDB2] text-xs transition-colors"
            >
              Speyside Sherry
            </button>
          </div>

          <button
            onClick={handleSave}
            className="flex items-center gap-1.5 px-4 py-2 rounded bg-[#C67D38] hover:bg-[#DF9B56] text-[#12110F] font-semibold text-xs transition-all shadow-md"
          >
            {isSaved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
            <span>{isSaved ? 'Saved Target Specification' : 'Save Specification'}</span>
          </button>
        </div>
      </div>

      {/* Target Parameters Form Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left (7 cols): Numerical Sensory Sliders */}
        <div className="lg:col-span-7 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-6">
          <div className="border-b border-[#2A241E] pb-3 flex justify-between items-center">
            <div>
              <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                Numerical Sensory Profile (0.00 – 1.00)
              </h3>
              <p className="text-xs text-[#8C8476]">
                Design targets representing intended organoleptic boundaries.
              </p>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#1F1B17] text-[#C67D38] border border-[#3D3124]">
              22 Scaled Axes
            </span>
          </div>

          {['Distillate Character', 'Maturation Character', 'Peat & Terroir', 'Palate Structure'].map(groupName => {
            const groupSliders = sensorySliders.filter(s => s.group === groupName);
            return (
              <div key={groupName} className="space-y-3">
                <div className="text-xs font-mono font-bold text-[#C67D38] uppercase tracking-wider border-b border-[#24201B] pb-1">
                  {groupName}
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {groupSliders.map(s => {
                    const val = target.sensory[s.key] || 0;
                    return (
                      <div key={s.key} className="bg-[#12110F] p-3 rounded border border-[#26211C] space-y-1.5">
                        <div className="flex justify-between items-center text-xs font-mono">
                          <span className="text-[#C5BDB2]">{s.label}</span>
                          <span className="font-bold text-[#E5A93C] text-sm">{val.toFixed(2)}</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="1"
                          step="0.01"
                          value={val}
                          onChange={(e) => handleSensoryChange(s.key, parseFloat(e.target.value))}
                          className="w-full accent-[#C67D38] bg-[#2A241E] h-1.5 rounded-lg cursor-pointer"
                        />
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        {/* Right (5 cols): Metadata + Sensory Radar Preview */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Metadata Parameters Card */}
          <div className="bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-4">
            <h3 className="font-editorial text-lg font-bold text-[#F5F2EB] border-b border-[#2A241E] pb-2">
              Product Attributes & Specification
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-mono text-[#8C8476] mb-1">DESIGN NAME</label>
                <input
                  type="text"
                  value={target.name}
                  onChange={(e) => setTarget({ ...target, name: e.target.value })}
                  className="w-full bg-[#12110F] text-[#FAF7F0] px-3 py-2 rounded border border-[#332A22] font-serif focus:outline-none focus:border-[#C67D38]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-mono text-[#8C8476] mb-1">SCOTCH REGION</label>
                  <select
                    value={target.region}
                    onChange={(e) => setTarget({ ...target, region: e.target.value as ScotchRegion })}
                    className="w-full bg-[#12110F] text-[#FAF7F0] px-3 py-2 rounded border border-[#332A22] font-mono focus:outline-none focus:border-[#C67D38]"
                  >
                    {REGIONS.map(r => (
                      <option key={r} value={r}>{r}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-mono text-[#8C8476] mb-1">WHISKY STYLE</label>
                  <select
                    value={target.style}
                    onChange={(e) => setTarget({ ...target, style: e.target.value as WhiskyStyle })}
                    className="w-full bg-[#12110F] text-[#FAF7F0] px-3 py-2 rounded border border-[#332A22] font-mono focus:outline-none focus:border-[#C67D38]"
                  >
                    {STYLES.map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-mono text-[#8C8476] mb-1">TARGET AGE STATEMENT</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min="3"
                      max="50"
                      value={target.targetAgeYears}
                      onChange={(e) => setTarget({ ...target, targetAgeYears: parseInt(e.target.value) || 3 })}
                      className="w-full bg-[#12110F] text-[#FAF7F0] px-3 py-2 rounded border border-[#332A22] font-mono focus:outline-none focus:border-[#C67D38]"
                    />
                    <span className="font-mono text-[#8C8476]">Years</span>
                  </div>
                </div>

                <div>
                  <label className="block font-mono text-[#8C8476] mb-1">TARGET BOTTLING ABV</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      step="0.1"
                      min="40.0"
                      max="65.0"
                      value={target.targetABV}
                      onChange={(e) => setTarget({ ...target, targetABV: parseFloat(e.target.value) || 40.0 })}
                      className="w-full bg-[#12110F] text-[#FAF7F0] px-3 py-2 rounded border border-[#332A22] font-mono focus:outline-none focus:border-[#C67D38]"
                    />
                    <span className="font-mono text-[#8C8476]">%</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-mono text-[#8C8476] mb-1">EDITION BOTTLE COUNT</label>
                  <input
                    type="number"
                    min="100"
                    max="50000"
                    step="50"
                    value={target.targetBottles}
                    onChange={(e) => setTarget({ ...target, targetBottles: parseInt(e.target.value) || 100 })}
                    className="w-full bg-[#12110F] text-[#FAF7F0] px-3 py-2 rounded border border-[#332A22] font-mono focus:outline-none focus:border-[#C67D38]"
                  />
                </div>

                <div>
                  <label className="block font-mono text-[#8C8476] mb-1">POSITIONING TIER</label>
                  <select
                    value={target.positioning}
                    onChange={(e) => setTarget({ ...target, positioning: e.target.value as TargetWhiskyProfile['positioning'] })}
                    className="w-full bg-[#12110F] text-[#FAF7F0] px-3 py-2 rounded border border-[#332A22] font-mono focus:outline-none focus:border-[#C67D38]"
                  >
                    <option value="Core Luxury">Core Luxury (£65 - £110)</option>
                    <option value="Connoisseur Reserve">Connoisseur Reserve (£110 - £180)</option>
                    <option value="Ultra-Premium">Ultra-Premium (£180 - £350)</option>
                    <option value="Prestige Collector">Prestige Collector (£350+)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-mono text-[#8C8476] mb-1">TASTING / PRODUCT BRIEF</label>
                <textarea
                  rows={3}
                  value={target.description}
                  onChange={(e) => setTarget({ ...target, description: e.target.value })}
                  className="w-full bg-[#12110F] text-[#FAF7F0] px-3 py-2 rounded border border-[#332A22] font-serif text-xs focus:outline-none focus:border-[#C67D38]"
                />
              </div>
            </div>
          </div>

          {/* Radar Preview */}
          <div className="bg-[#171513] border border-[#2E2822] rounded-lg p-5 flex flex-col items-center">
            <h4 className="font-editorial text-base font-bold text-[#F5F2EB] mb-2 self-start">
              Target Sensory Envelope
            </h4>
            <SensoryRadar target={target.sensory} size={300} showLegend={false} />
            <div className="text-[11px] text-[#8C8476] font-mono text-center mt-2">
              Geometry ready for process simulation matching.
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
