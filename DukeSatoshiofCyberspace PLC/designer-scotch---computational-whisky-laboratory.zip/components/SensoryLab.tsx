'use client';

import React, { useState } from 'react';
import { WhiskyDesign, SensoryPanelistScore, SensoryAxisProfile } from '@/types/whisky';
import { SYNTHETIC_PANEL_SCORES } from '@/lib/data/synthetic-db';
import { projectSensoryToPCA, computeSensoryDistanceBreakdown, aggregatePanelScores, PCAProjectionPoint } from '@/lib/engines/sensory';
import { SensoryRadar } from './SensoryRadar';
import { SearchCheck, Plus, Check, UserCheck, ShieldCheck, Compass, Info } from 'lucide-react';

interface SensoryLabProps {
  design: WhiskyDesign;
}

export const SensoryLab: React.FC<SensoryLabProps> = ({ design }) => {
  const [panelScores, setPanelScores] = useState<SensoryPanelistScore[]>(SYNTHETIC_PANEL_SCORES);
  const [activePanelist, setActivePanelist] = useState<SensoryPanelistScore>(SYNTHETIC_PANEL_SCORES[0]);

  // Aggregate panel scores
  const measuredPanelSensory = aggregatePanelScores(panelScores);
  const predictedSensory = design.activeBlend.sensoryProfile || design.targetProfile.sensory;

  // Sensory distance analysis
  const distanceAnalysis = computeSensoryDistanceBreakdown(
    design.targetProfile.sensory,
    predictedSensory,
    measuredPanelSensory
  );

  // PCA projections
  const pcaPoints: PCAProjectionPoint[] = [
    projectSensoryToPCA(design.targetProfile.sensory, 'TGT', `Target: ${design.targetProfile.name}`, 'Target'),
    projectSensoryToPCA(predictedSensory, 'PRED', `Modelled: ${design.activeBlend.name}`, 'Predicted Design'),
    projectSensoryToPCA(measuredPanelSensory, 'MEAS', 'Measured Sensory Panel (N=3 ISO)', 'Measured Panel'),
    // Benchmark references
    projectSensoryToPCA(
      { fruit: 0.85, oak: 0.50, smoke: 0.05, vanilla: 0.65, finish: 0.85, cereal: 0.30, complexity: 0.80 } as any,
      'REF-SPEY', 'Benchmark: Speyside 18yo Standard', 'Benchmark Malt'
    ),
    projectSensoryToPCA(
      { fruit: 0.50, oak: 0.60, smoke: 0.85, medicinal: 0.80, finish: 0.90, salt: 0.65, complexity: 0.88 } as any,
      'REF-ISL', 'Benchmark: Islay Heavy Peat 16yo', 'Benchmark Malt'
    ),
  ];

  // PCA Map dimensions
  const pcaWidth = 520;
  const pcaHeight = 320;
  const pad = 40;

  // Domain for PC1 and PC2: approx -0.5 to +0.8
  const getPcaX = (pc1: number) => pad + ((pc1 + 0.4) / 1.2) * (pcaWidth - pad * 2);
  const getPcaY = (pc2: number) => pcaHeight - pad - ((pc2 + 0.4) / 1.2) * (pcaHeight - pad * 2);

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#171513] border border-[#2E2822] p-5 rounded-lg">
        <div>
          <div className="text-xs font-mono text-[#C67D38] uppercase">STAGE 11 &bull; SENSORY SCIENCE & MULTIVARIATE PCA</div>
          <h2 className="font-editorial text-2xl font-bold text-[#F5F2EB]">
            Multivariate PCA Mapping, Distance Feedback & Panel Evaluations
          </h2>
          <p className="text-xs text-[#8C8476] mt-0.5">
            Explicitly distinguish Modelled Predictions from Physical Sensory Panel Evaluations.
          </p>
        </div>

        <div className="flex items-center gap-3 text-xs font-mono">
          <div className="bg-[#12110F] px-3 py-1.5 rounded border border-[#2E2822]">
            <span className="text-[#8C8476]">OVERALL DISTANCE:</span>{' '}
            <span className="text-[#52C47C] font-bold">{distanceAnalysis.overallDistance.toFixed(3)}</span>
          </div>
          <div className="bg-[#12110F] px-3 py-1.5 rounded border border-[#2E2822]">
            <span className="text-[#8C8476]">CONFORMANCE:</span>{' '}
            <span className="text-[#E5A93C] font-bold">{distanceAnalysis.conformanceRatePct}%</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (6 cols): 2D PCA Sensory Map */}
        <div className="lg:col-span-6 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-[#2A241E] pb-3">
            <div>
              <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                Multivariate PCA Sensory Space Map
              </h3>
              <p className="text-xs text-[#8C8476]">
                Dimension reduction: PC1 (Maturity/Oak) vs PC2 (Smoke/Phenols)
              </p>
            </div>
            <div className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#16233B] text-[#6BA5F2] border border-[#233B63]">
              R-Style Eigen Projection
            </div>
          </div>

          {/* SVG PCA Scatter Plot */}
          <div className="bg-[#12110F] p-4 rounded border border-[#26211C] space-y-2">
            <div className="w-full overflow-x-auto">
              <svg width="100%" height={pcaHeight} viewBox={`0 0 ${pcaWidth} ${pcaHeight}`} className="overflow-visible select-none">
                {/* Center Axes */}
                <line x1={getPcaX(0)} y1={pad} x2={getPcaX(0)} y2={pcaHeight - pad} stroke="#2E2822" strokeWidth="1" strokeDasharray="2,2" />
                <line x1={pad} y1={getPcaY(0)} x2={pcaWidth - pad} y2={getPcaY(0)} stroke="#2E2822" strokeWidth="1" strokeDasharray="2,2" />

                {/* Axis Labels */}
                <text x={pcaWidth - pad} y={getPcaY(0) - 8} fill="#7A7062" fontSize="9" fontFamily="monospace" textAnchor="end">
                  + PC1: Wood Extraction / Oak &rarr;
                </text>
                <text x={pad} y={getPcaY(0) - 8} fill="#7A7062" fontSize="9" fontFamily="monospace">
                  &larr; Cereal / Spirit Freshness
                </text>
                <text x={getPcaX(0) + 6} y={pad + 10} fill="#7A7062" fontSize="9" fontFamily="monospace">
                  &uarr; + PC2: Peat Smoke / Phenols
                </text>
                <text x={getPcaX(0) + 6} y={pcaHeight - pad - 6} fill="#7A7062" fontSize="9" fontFamily="monospace">
                  &darr; - PC2: Fresh Orchard Fruit
                </text>

                {/* Plot Points */}
                {pcaPoints.map(pt => {
                  const cx = getPcaX(pt.pc1);
                  const cy = getPcaY(pt.pc2);

                  let color = '#C5BDB2';
                  if (pt.category === 'Target') color = '#64B5F6';
                  if (pt.category === 'Predicted Design') color = '#E5A93C';
                  if (pt.category === 'Measured Panel') color = '#50E3C2';

                  return (
                    <g key={pt.id} className="cursor-pointer">
                      <circle cx={cx} cy={cy} r="6" fill={color} stroke="#141312" strokeWidth="1.5" />
                      <text x={cx + 9} y={cy + 3} fill={color} fontSize="10" fontFamily="sans-serif" fontWeight="600">
                        {pt.name}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </div>
          </div>

          {/* Triangulation Radar */}
          <div className="bg-[#12110F] p-4 rounded border border-[#2E2822] flex flex-col items-center">
            <h4 className="font-editorial text-sm font-bold text-[#F5F2EB] mb-1 self-start">
              Sensory Triangulation: Target vs Predicted vs Physical Panel
            </h4>
            <SensoryRadar
              target={design.targetProfile.sensory}
              predicted={predictedSensory}
              measured={measuredPanelSensory}
              size={290}
            />
          </div>
        </div>

        {/* Right Column (6 cols): Sensory Distance Breakdown & Tasting Notebook */}
        <div className="lg:col-span-6 space-y-6">
          
          {/* Numerical Distance Matrix Table */}
          <div className="bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-[#2A241E] pb-3">
              <div>
                <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                  Sensory Target Distance Matrix
                </h3>
                <p className="text-xs text-[#8C8476]">
                  Transparent residual delta: Target vs Model vs Measured Panel
                </p>
              </div>
            </div>

            <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1 text-xs font-mono">
              {distanceAnalysis.breakdown.slice(0, 8).map(row => (
                <div key={row.axis} className="bg-[#12110F] p-2.5 rounded border border-[#26211C] flex justify-between items-center">
                  <div>
                    <span className="font-bold text-[#FAF7F0]">{row.label}</span>
                    <span className="text-[10px] text-[#8C8476] ml-2">
                      Tgt: {row.targetValue.toFixed(2)} &bull; Pred: {row.predictedValue.toFixed(2)}
                      {row.measuredValue !== undefined && ` • Meas: ${row.measuredValue.toFixed(2)}`}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-[#FAF7F0]">&Delta; {row.difference.toFixed(2)}</span>
                    <span className={`text-[9px] px-1.5 py-0.5 rounded font-mono ${
                      row.status === 'In Range' ? 'bg-[#132A1B] text-[#52C47C]' : 'bg-[#2E2012] text-[#E5A93C]'
                    }`}>
                      {row.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Digital Tasting Notebook & Panelists */}
          <div className="bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-[#2A241E] pb-3">
              <div>
                <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                  Digital Tasting Notebook & Blind Panel
                </h3>
                <p className="text-xs text-[#8C8476]">
                  ISO 8586 expert panel sensory descriptors
                </p>
              </div>
              <div className="flex gap-1 font-mono text-xs">
                {panelScores.map(p => (
                  <button
                    key={p.panelistId}
                    onClick={() => setActivePanelist(p)}
                    className={`px-2.5 py-1 rounded text-xs transition-colors ${
                      activePanelist.panelistId === p.panelistId
                        ? 'bg-[#C67D38] text-[#12110F] font-bold'
                        : 'bg-[#12110F] text-[#A69E91] border border-[#2E2822]'
                    }`}
                  >
                    {p.panelistName.split(' ')[1]}
                  </button>
                ))}
              </div>
            </div>

            {/* Panelist Tasting Sheet */}
            <div className="bg-[#12110F] p-4 rounded border border-[#2E2822] space-y-3 text-xs">
              <div className="flex justify-between items-center font-mono">
                <div>
                  <span className="text-[#FAF7F0] font-bold">{activePanelist.panelistName}</span>
                  <span className="text-[#8C8476] ml-2">({activePanelist.qualification})</span>
                </div>
                <span className="text-[#52C47C] font-bold">Confidence: {(activePanelist.confidenceScore * 100).toFixed(0)}%</span>
              </div>

              <div className="space-y-2 text-[#C5BDB2]">
                <div>
                  <strong className="text-[#E5A93C] font-mono text-[11px] uppercase block">NOSE:</strong>
                  <p className="italic">{activePanelist.tastingNotes.nose.join(' • ')}</p>
                </div>
                <div>
                  <strong className="text-[#E5A93C] font-mono text-[11px] uppercase block">PALATE:</strong>
                  <p className="italic">{activePanelist.tastingNotes.palate.join(' • ')}</p>
                </div>
                <div>
                  <strong className="text-[#E5A93C] font-mono text-[11px] uppercase block">TEXTURE & MOUTHFEEL:</strong>
                  <p className="italic">{activePanelist.tastingNotes.texture}</p>
                </div>
                <div>
                  <strong className="text-[#E5A93C] font-mono text-[11px] uppercase block">FINISH:</strong>
                  <p className="italic">{activePanelist.tastingNotes.finish.join(' • ')}</p>
                </div>
              </div>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};
