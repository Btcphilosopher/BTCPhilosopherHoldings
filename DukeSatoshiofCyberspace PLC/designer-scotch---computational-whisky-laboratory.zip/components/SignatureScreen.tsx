'use client';

import React, { useState } from 'react';
import { WhiskyDesign, SensoryAxisProfile } from '@/types/whisky';
import { SensoryRadar } from './SensoryRadar';
import { calculateBlendProperties } from '@/lib/engines/blending';
import { simulateCaskMaturation } from '@/lib/engines/maturation';
import { SYNTHETIC_WAREHOUSES, SYNTHETIC_PANEL_SCORES } from '@/lib/data/synthetic-db';
import { aggregatePanelScores, computeSensoryDistanceBreakdown } from '@/lib/engines/sensory';
import { calculateMaturationEconomics, buildProductValuation } from '@/lib/engines/economics';
import { ArrowRight, Sparkles, TrendingUp, ShieldAlert, CheckCircle2, Sliders, Play, Info } from 'lucide-react';
import { ActiveTab } from './HeaderNav';

interface SignatureScreenProps {
  design: WhiskyDesign;
  onNavigate: (tab: ActiveTab) => void;
  onUpdateDesign: (updated: WhiskyDesign) => void;
}

export const SignatureScreen: React.FC<SignatureScreenProps> = ({
  design,
  onNavigate,
  onUpdateDesign,
}) => {
  const [scrubbedAge, setScrubbedAge] = useState<number>(design.targetProfile.targetAgeYears || 18);
  const [selectedBlendIdx, setSelectedBlendIdx] = useState<number>(0);

  const primaryCask = design.caskProgramme[0] || design.activeBlend.components[0]?.caskSnapshot;
  const warehouse = SYNTHETIC_WAREHOUSES.find(w => w.id === design.warehouseId) || SYNTHETIC_WAREHOUSES[0];

  // Maturation simulation for timeline scrubber
  const matSimulation = simulateCaskMaturation(
    design.distillationProfile.predictedNewMakeSensory || design.targetProfile.sensory,
    primaryCask,
    warehouse,
    scrubbedAge
  );

  const currentScrubbedPoint = matSimulation.timeline.find(p => p.ageYears === scrubbedAge) || matSimulation.timeline[matSimulation.timeline.length - 1];

  // Recalculate blend
  const calculatedBlend = calculateBlendProperties(design.activeBlend.components, design.targetProfile);
  const measuredPanelSensory = aggregatePanelScores(SYNTHETIC_PANEL_SCORES);
  const sensoryDistanceAnalysis = computeSensoryDistanceBreakdown(
    design.targetProfile.sensory,
    calculatedBlend.sensoryProfile,
    measuredPanelSensory
  );

  // Financial calculations
  const matEconomics = calculateMaturationEconomics(primaryCask, 2.85, scrubbedAge);
  const productVal = buildProductValuation(design.targetProfile, calculatedBlend, matEconomics.matureCostPerBottleLiquidGBP);

  const principalSensoryBars: { key: keyof SensoryAxisProfile; label: string; target: number; predicted: number }[] = [
    { key: 'fruit', label: 'Orchard Fruit', target: design.targetProfile.sensory.fruit, predicted: calculatedBlend.sensoryProfile.fruit },
    { key: 'oak', label: 'Toasted Oak', target: design.targetProfile.sensory.oak, predicted: calculatedBlend.sensoryProfile.oak },
    { key: 'vanilla', label: 'Bourbon Vanilla', target: design.targetProfile.sensory.vanilla, predicted: calculatedBlend.sensoryProfile.vanilla },
    { key: 'spice', label: 'Baking Spices', target: design.targetProfile.sensory.spice, predicted: calculatedBlend.sensoryProfile.spice },
    { key: 'smoke', label: 'Peat Smoke', target: design.targetProfile.sensory.smoke, predicted: calculatedBlend.sensoryProfile.smoke },
    { key: 'body', label: 'Palate Body', target: design.targetProfile.sensory.body, predicted: calculatedBlend.sensoryProfile.body },
    { key: 'finish', label: 'Finish Length', target: design.targetProfile.sensory.finish, predicted: calculatedBlend.sensoryProfile.finish },
    { key: 'complexity', label: 'Depth / Complexity', target: design.targetProfile.sensory.complexity, predicted: calculatedBlend.sensoryProfile.complexity },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Signature Top Hero Panel */}
      <div className="bg-gradient-to-r from-[#1A1714] via-[#1F1C18] to-[#171513] border border-[#383028] rounded-lg p-6 relative overflow-hidden shadow-2xl">
        <div className="absolute right-0 top-0 bottom-0 w-96 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-[#C67D38]/10 via-transparent to-transparent pointer-events-none" />

        <div className="flex flex-wrap items-start justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-xs text-[#C67D38] uppercase tracking-wider font-semibold">
                DESIGN SPECIFICATION &bull; {design.code} v{design.version}
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#2D2418] text-[#E5A93C] border border-[#594326]">
                {design.targetProfile.region} {design.targetProfile.style}
              </span>
            </div>

            <h2 className="font-editorial text-3xl font-bold text-[#FAF7F0] tracking-tight">
              {design.name}
            </h2>
            <p className="text-sm text-[#B8AFA2] max-w-2xl mt-1 leading-relaxed italic">
              &ldquo;{design.targetProfile.description}&rdquo;
            </p>

            <div className="flex flex-wrap items-center gap-4 mt-4 text-xs font-mono">
              <div className="bg-[#12110F] px-3 py-1.5 rounded border border-[#2E2822]">
                <span className="text-[#877E71]">TARGET AGE:</span>{' '}
                <span className="text-[#FAF7F0] font-bold">{design.targetProfile.targetAgeYears} YO</span>
              </div>
              <div className="bg-[#12110F] px-3 py-1.5 rounded border border-[#2E2822]">
                <span className="text-[#877E71]">TARGET STRENGTH:</span>{' '}
                <span className="text-[#FAF7F0] font-bold">{design.targetProfile.targetABV}% ABV</span>
              </div>
              <div className="bg-[#12110F] px-3 py-1.5 rounded border border-[#2E2822]">
                <span className="text-[#877E71]">EDITION SIZE:</span>{' '}
                <span className="text-[#FAF7F0] font-bold">{design.targetProfile.targetBottles.toLocaleString()} Bottles</span>
              </div>
              <div className="bg-[#12110F] px-3 py-1.5 rounded border border-[#2E2822]">
                <span className="text-[#877E71]">POSITIONING:</span>{' '}
                <span className="text-[#E5A93C] font-bold">{design.targetProfile.positioning}</span>
              </div>
            </div>
          </div>

          {/* Quick Metrics KPI Cards */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="bg-[#141210] p-3 rounded border border-[#332A22] text-center min-w-[130px]">
              <div className="text-[10px] font-mono text-[#8C8476] uppercase">Sensory Distance</div>
              <div className="text-xl font-bold font-mono text-[#52C47C] mt-0.5">
                {sensoryDistanceAnalysis.overallDistance.toFixed(3)}
              </div>
              <div className="text-[9px] text-[#A69D8F] font-mono">
                {sensoryDistanceAnalysis.conformanceRatePct}% Target Match
              </div>
            </div>

            <div className="bg-[#141210] p-3 rounded border border-[#332A22] text-center min-w-[130px]">
              <div className="text-[10px] font-mono text-[#8C8476] uppercase">Calculated ABV</div>
              <div className="text-xl font-bold font-mono text-[#E5A93C] mt-0.5">
                {calculatedBlend.calculatedABV.toFixed(1)}%
              </div>
              <div className="text-[9px] text-[#A69D8F] font-mono">
                {calculatedBlend.bottlesYield700ml} Bottles Yield
              </div>
            </div>

            <div className="bg-[#141210] p-3 rounded border border-[#332A22] text-center min-w-[130px]">
              <div className="text-[10px] font-mono text-[#8C8476] uppercase">Liquid Cost / Btl</div>
              <div className="text-xl font-bold font-mono text-[#FAF7F0] mt-0.5">
                £{calculatedBlend.costPerBottleGBP.toFixed(2)}
              </div>
              <div className="text-[9px] text-[#A69D8F] font-mono">
                RRP: £{productVal.recommendedRetailPriceGBP}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Grid Layout: Process Chain Modules */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (5 cols): Sensory Radar & Principal Attributes */}
        <div className="lg:col-span-5 bg-[#171513] border border-[#2E2822] rounded-lg p-5 flex flex-col justify-between space-y-4">
          <div className="flex items-center justify-between border-b border-[#2A241E] pb-3">
            <div>
              <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                Sensory Profile Radar
              </h3>
              <p className="text-xs text-[#8C8273]">
                Multivariate calibration: Target vs Predicted vs Physical Panel
              </p>
            </div>
            <button
              onClick={() => onNavigate('sensory')}
              className="text-xs font-mono text-[#C67D38] hover:text-[#E5A93C] flex items-center gap-1"
            >
              Sensory Lab <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="py-2 flex justify-center">
            <SensoryRadar
              target={design.targetProfile.sensory}
              predicted={calculatedBlend.sensoryProfile}
              measured={measuredPanelSensory}
              size={330}
            />
          </div>

          {/* Bar Visualizers */}
          <div className="space-y-2 border-t border-[#2A241E] pt-3">
            <div className="text-xs font-mono text-[#A89F90] mb-2 flex justify-between">
              <span>PRINCIPAL SENSORY DIMENSIONS</span>
              <span>PREDICTED / TARGET</span>
            </div>
            {principalSensoryBars.map(bar => {
              const pctTarget = Math.round(bar.target * 100);
              const pctPred = Math.round(bar.predicted * 100);
              return (
                <div key={bar.key} className="space-y-1 text-xs">
                  <div className="flex justify-between text-[#C5BDB2] text-[11px] font-mono">
                    <span>{bar.label}</span>
                    <span>
                      <span className="text-[#E5A93C] font-semibold">{bar.predicted.toFixed(2)}</span>
                      <span className="text-[#64B5F6] text-[10px]"> (Tgt: {bar.target.toFixed(2)})</span>
                    </span>
                  </div>
                  <div className="w-full bg-[#231F1B] h-2 rounded-full overflow-hidden relative">
                    {/* Target marker line */}
                    <div 
                      className="absolute top-0 bottom-0 w-0.5 bg-[#64B5F6] z-10" 
                      style={{ left: `${pctTarget}%` }} 
                      title={`Target: ${pctTarget}%`}
                    />
                    {/* Predicted bar */}
                    <div 
                      className="bg-gradient-to-r from-[#B5672A] to-[#E5A93C] h-full rounded-full transition-all duration-300"
                      style={{ width: `${pctPred}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column (7 cols): Maturation Timeline + Blending Recipe + Economics */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Maturation Timeline Scrubber */}
          <div className="bg-[#171513] border border-[#2E2822] rounded-lg p-5">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#2A241E] pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                    Maturation Trajectory
                  </h3>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#2B231A] text-[#E5A93C] border border-[#523F23]">
                    {warehouse.type.split('(')[0]}
                  </span>
                </div>
                <p className="text-xs text-[#8C8273]">
                  Kinetic wood extraction, subtractive esterification & Angel’s Share
                </p>
              </div>
              <button
                onClick={() => onNavigate('maturation')}
                className="text-xs font-mono text-[#C67D38] hover:text-[#E5A93C] flex items-center gap-1"
              >
                Maturation Lab <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {/* Scrubber slider */}
            <div className="mt-4 p-4 bg-[#12110F] rounded-md border border-[#26211C] space-y-3">
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="text-[#8C8476]">SCRUB MATURATION TIMELINE:</span>
                <span className="text-base font-bold text-[#E5A93C]">{scrubbedAge} YEARS IN OAK</span>
              </div>
              
              <input
                type="range"
                min="0"
                max="25"
                step="1"
                value={scrubbedAge}
                onChange={(e) => setScrubbedAge(parseInt(e.target.value))}
                className="w-full accent-[#C67D38] bg-[#2A241E] h-2 rounded-lg cursor-pointer"
              />

              {/* Trajectory Milestone Dots */}
              <div className="flex justify-between text-[10px] font-mono text-[#7A7062] px-1">
                {[0, 3, 8, 12, 15, 18, 21, 25].map(yr => (
                  <button
                    key={yr}
                    onClick={() => setScrubbedAge(yr)}
                    className={`hover:text-[#E5A93C] transition-colors ${scrubbedAge === yr ? 'text-[#E5A93C] font-bold underline' : ''}`}
                  >
                    Year {yr}
                  </button>
                ))}
              </div>

              {/* Dynamic Metrics at Selected Year */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 text-xs font-mono border-t border-[#26211C]">
                <div className="bg-[#1C1916] p-2 rounded border border-[#2E2822]">
                  <div className="text-[10px] text-[#8C8476]">REMAINING VOL:</div>
                  <div className="text-[#FAF7F0] font-bold">{currentScrubbedPoint.remainingVolumeLitres} L</div>
                  <div className="text-[9px] text-[#E06A53]">
                    -{(100 - (currentScrubbedPoint.remainingVolumeLitres / primaryCask.capacityLitres) * 100).toFixed(1)}% Angel’s Share
                  </div>
                </div>

                <div className="bg-[#1C1916] p-2 rounded border border-[#2E2822]">
                  <div className="text-[10px] text-[#8C8476]">ESTIMATED ABV:</div>
                  <div className="text-[#FAF7F0] font-bold">{currentScrubbedPoint.estimatedABVPct}%</div>
                  <div className="text-[9px] text-[#A69D8F]">Drift: -{(primaryCask.fillStrengthABVPct - currentScrubbedPoint.estimatedABVPct).toFixed(1)}%</div>
                </div>

                <div className="bg-[#1C1916] p-2 rounded border border-[#2E2822]">
                  <div className="text-[10px] text-[#8C8476]">WOOD EXTRACT:</div>
                  <div className="text-[#FAF7F0] font-bold">{currentScrubbedPoint.woodExtractPPM} ppm</div>
                  <div className="text-[9px] text-[#52C47C]">Vanillin / Syringol</div>
                </div>

                <div className="bg-[#1C1916] p-2 rounded border border-[#2E2822]">
                  <div className="text-[10px] text-[#8C8476]">UNCERTAINTY:</div>
                  <div className="text-[#E5A93C] font-bold">&plusmn;{(currentScrubbedPoint.uncertaintyMargin * 100).toFixed(1)}%</div>
                  <div className="text-[9px] text-[#8C8476]">95% Conf Band</div>
                </div>
              </div>
            </div>
          </div>

          {/* Active Blend Formulation */}
          <div className="bg-[#171513] border border-[#2E2822] rounded-lg p-5">
            <div className="flex items-center justify-between border-b border-[#2A241E] pb-3">
              <div>
                <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                  Blend Formulation & Cask Composition
                </h3>
                <p className="text-xs text-[#8C8273]">
                  {design.activeBlend.components.length} Casks vatting &bull; Youngest Age: {calculatedBlend.calculatedAgeStatement} YO
                </p>
              </div>
              <button
                onClick={() => onNavigate('blending')}
                className="text-xs font-mono text-[#C67D38] hover:text-[#E5A93C] flex items-center gap-1"
              >
                Blending Lab <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {/* Cask Percentages Visualizer */}
            <div className="mt-4 space-y-2.5">
              {design.activeBlend.components.map((comp, idx) => {
                const cask = comp.caskSnapshot;
                return (
                  <div key={comp.caskId} className="bg-[#12110F] p-3 rounded border border-[#26211C] space-y-1.5">
                    <div className="flex justify-between items-center text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-[#FAF7F0]">{cask.caskNumber.split('-').pop()}</span>
                        <span className="text-[11px] text-[#C5BDB2]">
                          {cask.woodSpecies.split('(')[0]} &bull; {cask.seasoning} ({cask.ageYears} YO)
                        </span>
                      </div>
                      <div className="font-mono font-bold text-[#E5A93C] text-sm">
                        {comp.percentage}%
                      </div>
                    </div>
                    {/* Progress Bar */}
                    <div className="w-full bg-[#231F1B] h-2 rounded-full overflow-hidden">
                      <div 
                        className="bg-gradient-to-r from-[#9C5820] to-[#E5A93C] h-full rounded-full"
                        style={{ width: `${comp.percentage}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Economics Summary */}
          <div className="bg-[#171513] border border-[#2E2822] rounded-lg p-5">
            <div className="flex items-center justify-between border-b border-[#2A241E] pb-3">
              <div>
                <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                  Commercial Valuation & Premiumisation
                </h3>
                <p className="text-xs text-[#8C8273]">
                  Cost per litre, packaging, duty, and recommended retail pricing
                </p>
              </div>
              <button
                onClick={() => onNavigate('economics')}
                className="text-xs font-mono text-[#C67D38] hover:text-[#E5A93C] flex items-center gap-1"
              >
                Economics Lab <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 text-xs font-mono">
              <div className="bg-[#12110F] p-3 rounded border border-[#26211C]">
                <div className="text-[10px] text-[#8C8476]">LIQUID COST:</div>
                <div className="text-base font-bold text-[#FAF7F0] mt-0.5">£{calculatedBlend.costPerBottleGBP.toFixed(2)}</div>
                <div className="text-[9px] text-[#8C8476]">per 700ml bottle</div>
              </div>

              <div className="bg-[#12110F] p-3 rounded border border-[#26211C]">
                <div className="text-[10px] text-[#8C8476]">EXCISE & DUTY:</div>
                <div className="text-base font-bold text-[#FAF7F0] mt-0.5">£{productVal.dutyAndExciseGBP.toFixed(2)}</div>
                <div className="text-[9px] text-[#8C8476]">UK Spirits Tariff</div>
              </div>

              <div className="bg-[#12110F] p-3 rounded border border-[#26211C]">
                <div className="text-[10px] text-[#8C8476]">DISTILLERY MARGIN:</div>
                <div className="text-base font-bold text-[#52C47C] mt-0.5">£{productVal.distilleryMarginGBP.toFixed(2)}</div>
                <div className="text-[9px] text-[#8C8476]">per bottle unit</div>
              </div>

              <div className="bg-[#12110F] p-3 rounded border border-[#483726] bg-[#1F1912]">
                <div className="text-[10px] text-[#E5A93C] font-semibold">MODELLED RRP:</div>
                <div className="text-lg font-bold text-[#F5C782] mt-0.5">£{productVal.recommendedRetailPriceGBP}</div>
                <div className="text-[9px] text-[#C5BDB2]">Incl. 20% VAT</div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
