'use client';

import React, { useState } from 'react';
import { WhiskyDesign, CaskEntity, WarehouseEnvironment } from '@/types/whisky';
import { SYNTHETIC_CASKS, SYNTHETIC_WAREHOUSES } from '@/lib/data/synthetic-db';
import { Boxes, Thermometer, Droplets, Info, Eye, X, Wine } from 'lucide-react';
import { SensoryRadar } from './SensoryRadar';

interface WarehouseDigitalTwinProps {
  design: WhiskyDesign;
}

export const WarehouseDigitalTwin: React.FC<WarehouseDigitalTwinProps> = ({ design }) => {
  const [selectedWarehouseId, setSelectedWarehouseId] = useState<string>(design.warehouseId || 'WH-01');
  const [activeCask, setActiveCask] = useState<CaskEntity | null>(SYNTHETIC_CASKS[0]);

  const currentWarehouse = SYNTHETIC_WAREHOUSES.find(w => w.id === selectedWarehouseId) || SYNTHETIC_WAREHOUSES[0];

  // Generate visual rack slots (Bays 1-5, Tiers 1-4 = 20 visual positions)
  const bays = [1, 2, 3, 4, 5];
  const tiers = [4, 3, 2, 1]; // Tier 4 top, Tier 1 bottom (earth floor)

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#171513] border border-[#2E2822] p-5 rounded-lg">
        <div>
          <div className="text-xs font-mono text-[#C67D38] uppercase">STAGE 8 &bull; WAREHOUSE DIGITAL TWIN</div>
          <h2 className="font-editorial text-2xl font-bold text-[#F5F2EB]">
            Warehouse Microclimates & Spatial Cask Digital Twin
          </h2>
          <p className="text-xs text-[#8C8476] mt-0.5">
            Real-time environmental monitoring across dunnage earth floors and palletised upper tiers.
          </p>
        </div>

        {/* Warehouse Selector */}
        <div className="flex items-center gap-2">
          <select
            value={selectedWarehouseId}
            onChange={(e) => setSelectedWarehouseId(e.target.value)}
            className="bg-[#12110F] text-[#FAF7F0] text-xs font-mono px-3 py-1.5 rounded border border-[#332A22] focus:outline-none focus:border-[#C67D38]"
          >
            {SYNTHETIC_WAREHOUSES.map(w => (
              <option key={w.id} value={w.id}>{w.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Warehouse Environmental KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-[#171513] border border-[#2E2822] p-4 rounded-lg flex items-center gap-3">
          <Thermometer className="w-6 h-6 text-[#E56A3C]" />
          <div>
            <div className="text-[10px] font-mono text-[#8C8476]">MEAN AMBIENT TEMP</div>
            <div className="text-lg font-bold font-mono text-[#FAF7F0]">{currentWarehouse.avgTempC}&deg;C</div>
          </div>
        </div>

        <div className="bg-[#171513] border border-[#2E2822] p-4 rounded-lg flex items-center gap-3">
          <Droplets className="w-6 h-6 text-[#64B5F6]" />
          <div>
            <div className="text-[10px] font-mono text-[#8C8476]">RELATIVE HUMIDITY</div>
            <div className="text-lg font-bold font-mono text-[#FAF7F0]">{currentWarehouse.avgHumidityPct}%</div>
          </div>
        </div>

        <div className="bg-[#171513] border border-[#2E2822] p-4 rounded-lg flex items-center gap-3">
          <Boxes className="w-6 h-6 text-[#E5A93C]" />
          <div>
            <div className="text-[10px] font-mono text-[#8C8476]">ANNUAL EVAPORATION</div>
            <div className="text-lg font-bold font-mono text-[#FAF7F0]">{currentWarehouse.annualEvaporationLossPct}% / yr</div>
          </div>
        </div>

        <div className="bg-[#171513] border border-[#2E2822] p-4 rounded-lg flex items-center gap-3">
          <Wine className="w-6 h-6 text-[#52C47C]" />
          <div>
            <div className="text-[10px] font-mono text-[#8C8476]">STORED CASKS</div>
            <div className="text-lg font-bold font-mono text-[#FAF7F0]">{currentWarehouse.caskCount.toLocaleString()}</div>
          </div>
        </div>
      </div>

      {/* Spatial Rack Grid & Inspection Modal */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Spatial Rack Visualizer (7 cols) */}
        <div className="lg:col-span-7 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-[#2A241E] pb-3">
            <div>
              <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                Spatial Rack Matrix & Microclimate Gradient
              </h3>
              <p className="text-xs text-[#8C8476]">
                Click any cask stave to launch digital twin telemetry
              </p>
            </div>
            <div className="text-[10px] font-mono text-[#8C8476]">
              Tier 4 (Warm / Dry) &darr; Tier 1 (Cool / Moist)
            </div>
          </div>

          {/* Visual Grid of Racks */}
          <div className="space-y-3 bg-[#12110F] p-4 rounded border border-[#2E2822]">
            {tiers.map(tier => {
              const tierTemp = (currentWarehouse.avgTempC + (tier - 2.5) * 1.2).toFixed(1);
              const tierHumidity = (currentWarehouse.avgHumidityPct - (tier - 2.5) * 3.5).toFixed(0);

              return (
                <div key={`tier-${tier}`} className="flex items-center gap-3">
                  <div className="w-20 shrink-0 font-mono text-[10px] text-[#8C8476]">
                    <div>TIER {tier}</div>
                    <div className="text-[#C5BDB2]">{tierTemp}&deg;C &bull; {tierHumidity}%</div>
                  </div>

                  <div className="grid grid-cols-5 gap-2 flex-1">
                    {bays.map(bay => {
                      const caskIdx = (bay * tier + 3) % SYNTHETIC_CASKS.length;
                      const cask = SYNTHETIC_CASKS[caskIdx];
                      const isSelected = activeCask?.id === cask.id;

                      const isSherry = cask.seasoning.includes('Sherry') || cask.seasoning.includes('Pedro');
                      const isVirgin = cask.seasoning === 'Virgin Oak';

                      return (
                        <div
                          key={`bay-${bay}-tier-${tier}`}
                          onClick={() => setActiveCask(cask)}
                          className={`h-16 rounded p-2 border cursor-pointer flex flex-col justify-between transition-all select-none ${
                            isSelected
                              ? 'bg-[#3D2C1B] border-[#E5A93C] shadow-lg ring-1 ring-[#E5A93C]'
                              : isSherry
                              ? 'bg-[#251515] border-[#4A2626] hover:border-[#803E3E]'
                              : isVirgin
                              ? 'bg-[#262114] border-[#4A3D24] hover:border-[#8A703E]'
                              : 'bg-[#181614] border-[#2E2822] hover:border-[#4D3F33]'
                          }`}
                        >
                          <div className="flex justify-between items-center text-[10px] font-mono">
                            <span className="font-bold text-[#FAF7F0]">B{bay}</span>
                            <span className="text-[#E5A93C] font-semibold">{cask.ageYears}y</span>
                          </div>
                          <div className="text-[9px] font-mono text-[#A89F90] truncate">
                            {cask.caskNumber.split('-').pop()}
                          </div>
                          <div className="w-full bg-[#12110F] h-1 rounded-full overflow-hidden">
                            <div
                              className="bg-[#C67D38] h-full"
                              style={{ width: `${(cask.currentVolumeLitres / cask.capacityLitres) * 100}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex items-center gap-4 text-[10px] font-mono text-[#8C8476] pt-1">
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-[#181614] border border-[#2E2822]" /> ex-Bourbon / Refill</span>
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-[#251515] border border-[#4A2626]" /> ex-Sherry / Port</span>
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-[#262114] border border-[#4A3D24]" /> Virgin Oak</span>
          </div>
        </div>

        {/* Selected Cask Telemetry Drawer (5 cols) */}
        <div className="lg:col-span-5 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-4">
          {activeCask ? (
            <div className="space-y-4">
              <div className="flex justify-between items-start border-b border-[#2A241E] pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                      {activeCask.caskNumber}
                    </h3>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#132A1B] text-[#52C47C] border border-[#214D2E]">
                      {activeCask.status}
                    </span>
                  </div>
                  <p className="text-xs text-[#8C8476] mt-0.5">
                    {activeCask.woodSpecies} &bull; {activeCask.seasoning}
                  </p>
                </div>
              </div>

              {/* Quick Metrics */}
              <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                <div className="bg-[#12110F] p-3 rounded border border-[#26211C]">
                  <div className="text-[10px] text-[#8C8476]">AGE / FILL DATE:</div>
                  <div className="text-[#FAF7F0] font-bold mt-0.5">{activeCask.ageYears} YO ({activeCask.fillDate})</div>
                </div>
                <div className="bg-[#12110F] p-3 rounded border border-[#26211C]">
                  <div className="text-[10px] text-[#8C8476]">VOLUME / STRENGTH:</div>
                  <div className="text-[#E5A93C] font-bold mt-0.5">{activeCask.currentVolumeLitres} L @ {activeCask.currentABVPct}%</div>
                </div>
                <div className="bg-[#12110F] p-3 rounded border border-[#26211C]">
                  <div className="text-[10px] text-[#8C8476]">TOAST / CHAR:</div>
                  <div className="text-[#FAF7F0] font-bold mt-0.5">{activeCask.toastLevel} &bull; {activeCask.charLevel}</div>
                </div>
                <div className="bg-[#12110F] p-3 rounded border border-[#26211C]">
                  <div className="text-[10px] text-[#8C8476]">ESTIMATED VALUATION:</div>
                  <div className="text-[#52C47C] font-bold mt-0.5">£{activeCask.valuationGBP.toLocaleString()}</div>
                </div>
              </div>

              {/* Sensory Radar for this Cask */}
              <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex flex-col items-center">
                <div className="text-[11px] font-mono text-[#C67D38] self-start mb-1 font-bold">
                  WOOD EXTRACTION SENSORY VECTOR
                </div>
                <SensoryRadar predicted={activeCask.sensoryContribution} size={250} showLegend={false} />
              </div>
            </div>
          ) : (
            <div className="py-20 text-center text-xs text-[#8C8476] font-mono">
              Click any cask on the warehouse rack grid to view digital twin telemetry.
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
