'use client';

import React from 'react';
import { WhiskyDesign } from '@/types/whisky';
import { SensoryRadar } from './SensoryRadar';
import { simulateDistillationProcess } from '@/lib/engines/kinetics';
import { Sparkles, FlaskConical, AlertCircle, Info } from 'lucide-react';

interface NewMakeLabProps {
  design: WhiskyDesign;
}

export const NewMakeLab: React.FC<NewMakeLabProps> = ({ design }) => {
  const distSimulation = simulateDistillationProcess(
    design.distillationProfile,
    design.fermentationProfile.estimatedWashABVPct || 8.4,
    3.8,
    18,
    design.kilningSchedule.targetPhenolsPPM || 0
  );

  const { predictedNewMakeSensory, predictedCompounds, newMakeABVPct, totalYieldLPA } = distSimulation;

  const newMakeAxes: { key: keyof typeof predictedNewMakeSensory; label: string }[] = [
    { key: 'fruit', label: 'Fruit' },
    { key: 'floral', label: 'Floral' },
    { key: 'cereal', label: 'Cereal' },
    { key: 'malt', label: 'Malt' },
    { key: 'oiliness', label: 'Oiliness' },
    { key: 'spice', label: 'Spice' },
    { key: 'smoke', label: 'Smoke' },
    { key: 'body', label: 'Body' },
    { key: 'finish', label: 'Finish' },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#171513] border border-[#2E2822] p-5 rounded-lg">
        <div>
          <div className="text-xs font-mono text-[#C67D38] uppercase">STAGE 6 &bull; NEW-MAKE SPIRIT FINGERPRINT</div>
          <h2 className="font-editorial text-2xl font-bold text-[#F5F2EB]">
            Raw Distillate Character & Chemical Compound Proxies
          </h2>
          <p className="text-xs text-[#8C8476] mt-0.5">
            The sensory and chromatographic foundation prior to wood maturation.
          </p>
        </div>

        <div className="flex items-center gap-3 text-xs font-mono">
          <div className="bg-[#12110F] px-3 py-1.5 rounded border border-[#2E2822]">
            <span className="text-[#8C8476]">COLLECTION STRENGTH:</span>{' '}
            <span className="text-[#E5A93C] font-bold">{newMakeABVPct}% ABV</span>
          </div>
          <div className="bg-[#12110F] px-3 py-1.5 rounded border border-[#2E2822]">
            <span className="text-[#8C8476]">BATCH YIELD:</span>{' '}
            <span className="text-[#52C47C] font-bold">{totalYieldLPA} LPA</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left (5 cols): New Make Sensory Radar */}
        <div className="lg:col-span-5 bg-[#171513] border border-[#2E2822] rounded-lg p-5 flex flex-col justify-between space-y-4">
          <div className="border-b border-[#2A241E] pb-3">
            <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
              New-Make Distillate Radar
            </h3>
            <p className="text-xs text-[#8C8476]">
              Predicted spirit organoleptic balance (Zero oak extract at Year 0)
            </p>
          </div>

          <div className="py-2 flex justify-center">
            <SensoryRadar
              predicted={predictedNewMakeSensory}
              axes={newMakeAxes}
              size={320}
              showLegend={false}
            />
          </div>

          <div className="bg-[#12110F] p-3.5 rounded border border-[#2E2822] text-xs font-mono space-y-2">
            <div className="flex justify-between">
              <span className="text-[#8C8476]">Orchard Fruit (Esters):</span>
              <span className="text-[#E5A93C] font-bold">{predictedNewMakeSensory.fruit.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#8C8476]">Distillate Oiliness:</span>
              <span className="text-[#FAF7F0] font-bold">{predictedNewMakeSensory.oiliness.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#8C8476]">Cereal / Grain Backbone:</span>
              <span className="text-[#FAF7F0] font-bold">{predictedNewMakeSensory.cereal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#8C8476]">Peat Smoke Influence:</span>
              <span className="text-[#FAF7F0] font-bold">{predictedNewMakeSensory.smoke.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Right (7 cols): Chromatographic Compound Library */}
        <div className="lg:col-span-7 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-4">
          <div className="flex items-center gap-2 border-b border-[#2A241E] pb-3">
            <FlaskConical className="w-5 h-5 text-[#E5A93C]" />
            <div>
              <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                Chemical Compound Proxy Concentrations (GC-MS / HPLC Model)
              </h3>
              <p className="text-xs text-[#8C8476]">
                Comparison with human sensory detection thresholds in 40% ethanol matrix
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {predictedCompounds.map((comp) => {
              const sensoryRatio = comp.concentrationMgPerLitre / comp.sensoryThresholdMgPerLitre;
              return (
                <div key={comp.name} className="bg-[#12110F] p-3.5 rounded border border-[#26211C] space-y-2">
                  <div className="flex flex-wrap justify-between items-start gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-[#FAF7F0]">{comp.name}</span>
                        <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#1C1814] text-[#C67D38] border border-[#3A2D20]">
                          {comp.chemicalClass}
                        </span>
                      </div>
                      <div className="text-[11px] text-[#A89E90] mt-0.5 italic">
                        {comp.sensoryDescriptor}
                      </div>
                    </div>

                    <div className="text-right font-mono text-xs">
                      <span className="text-[#E5A93C] font-bold">{comp.concentrationMgPerLitre} mg/L</span>
                      <span className="text-[10px] text-[#8C8476] block">
                        Threshold: {comp.sensoryThresholdMgPerLitre} mg/L ({sensoryRatio.toFixed(1)}x OAV)
                      </span>
                    </div>
                  </div>

                  <div className="flex justify-between items-center text-[10px] font-mono text-[#7A7062] pt-1 border-t border-[#1C1A17]">
                    <span>Uncertainty Margin: &plusmn;{comp.uncertaintyBandPct}%</span>
                    <span>Classified: MODELLED PROXY</span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="bg-[#1A1612] p-3 rounded border border-[#3E2F20] text-xs text-[#C5BDB2] flex items-start gap-2">
            <Info className="w-4 h-4 text-[#C67D38] shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed">
              <strong>Analytical Discipline:</strong> Volatile compound predictions are computed via empirical mass balances from fermentation esterification and still copper catalytic constants. They represent model expectations for experimental calibration, not physical GC-MS certificates.
            </p>
          </div>
        </div>

      </div>
    </div>
  );
};
