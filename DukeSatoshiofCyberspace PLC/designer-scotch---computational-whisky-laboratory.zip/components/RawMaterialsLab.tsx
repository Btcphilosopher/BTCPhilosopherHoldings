'use client';

import React, { useState } from 'react';
import { WhiskyDesign, BarleyProfile, KilningSchedule } from '@/types/whisky';
import { SYNTHETIC_BARLEY_PROFILES } from '@/lib/data/synthetic-db';
import { Wheat, Flame, Save, Check, Layers } from 'lucide-react';

interface RawMaterialsLabProps {
  design: WhiskyDesign;
  onUpdateDesign: (updated: WhiskyDesign) => void;
}

export const RawMaterialsLab: React.FC<RawMaterialsLabProps> = ({
  design,
  onUpdateDesign,
}) => {
  const [selectedBarley, setSelectedBarley] = useState<BarleyProfile>(design.barleyProfile);
  const [kilning, setKilning] = useState<KilningSchedule>(design.kilningSchedule);
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    onUpdateDesign({
      ...design,
      barleyProfile: selectedBarley,
      kilningSchedule: kilning,
      updatedAt: new Date().toISOString().split('T')[0],
    });
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  // Smoke & Phenolic Model Sensory Projection
  const estimatedPhenols = kilning.targetPhenolsPPM;
  const smokeContribution = estimatedPhenols > 0 ? Math.min(1.0, (estimatedPhenols / 55.0) * 0.95) : 0.02;
  const medicinalContribution = estimatedPhenols > 20 ? Math.min(1.0, (estimatedPhenols / 60.0) * 0.9) : 0.01;
  const ashCharContribution = estimatedPhenols > 10 ? Math.min(1.0, (estimatedPhenols / 50.0) * 0.8) : 0.0;
  const seaweedContribution = kilning.peatSource.includes('Islay') ? Math.min(1.0, (estimatedPhenols / 45.0) * 0.75) : 0.05;

  return (
    <div className="space-y-6 pb-12">
      {/* Header bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#171513] border border-[#2E2822] p-5 rounded-lg">
        <div>
          <div className="text-xs font-mono text-[#C67D38] uppercase">STAGE 2 &bull; RAW MATERIALS & MALTING</div>
          <h2 className="font-editorial text-2xl font-bold text-[#F5F2EB]">
            Barley Agronomy, Malting & Peat-Smoke Kilning
          </h2>
          <p className="text-xs text-[#8C8476] mt-0.5">
            Model cereal starch potential, diastatic power, and phenolic peat smoke absorption.
          </p>
        </div>

        <button
          onClick={handleSave}
          className="flex items-center gap-1.5 px-4 py-2 rounded bg-[#C67D38] hover:bg-[#DF9B56] text-[#12110F] font-semibold text-xs transition-all shadow-md"
        >
          {isSaved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
          <span>{isSaved ? 'Saved Specification' : 'Save Specification'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Barley Cultivar Selector (6 cols) */}
        <div className="lg:col-span-6 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-4">
          <div className="flex items-center gap-2 border-b border-[#2A241E] pb-3">
            <Wheat className="w-5 h-5 text-[#E5A93C]" />
            <div>
              <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                Barley Cultivar & Agronomy Parameters
              </h3>
              <p className="text-xs text-[#8C8476]">
                Select Scottish certified malting barley cultivar
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <label className="block font-mono text-xs text-[#8C8476]">CULTIVAR SELECTOR</label>
            <div className="grid grid-cols-1 gap-2">
              {SYNTHETIC_BARLEY_PROFILES.map(b => (
                <div
                  key={b.id}
                  onClick={() => setSelectedBarley(b)}
                  className={`p-3 rounded border cursor-pointer transition-all ${
                    selectedBarley.id === b.id
                      ? 'bg-[#2A2116] border-[#C67D38] text-[#FAF7F0]'
                      : 'bg-[#12110F] border-[#2E2822] text-[#A69E91] hover:border-[#483B2F]'
                  }`}
                >
                  <div className="flex justify-between items-center text-xs font-mono">
                    <span className="font-bold text-[#FAF7F0]">{b.variety}</span>
                    <span className="text-[#C67D38]">{b.origin}</span>
                  </div>
                  <div className="text-[11px] text-[#8C8476] mt-1 font-mono">
                    Potential Extract: <span className="text-[#FAF7F0]">{b.potentialExtractLPAperTonne} LPA/t</span> &bull; 
                    Protein: <span className="text-[#FAF7F0]">{b.proteinContentPct}%</span> &bull; 
                    Nitrogen: <span className="text-[#FAF7F0]">{b.nitrogenPct}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Detailed Selected Barley Analysis */}
          <div className="bg-[#12110F] p-4 rounded border border-[#2E2822] space-y-3 text-xs font-mono">
            <div className="text-[#C67D38] font-bold uppercase tracking-wider text-[11px]">
              LABORATORY AGRONOMY METRICS (MEASURED)
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div>
                <span className="text-[#8C8476] block">1000-GRAIN WT:</span>
                <span className="text-[#FAF7F0] font-bold text-sm">{selectedBarley.thousandGrainWeightG} g</span>
              </div>
              <div>
                <span className="text-[#8C8476] block">DIASTATIC POWER:</span>
                <span className="text-[#FAF7F0] font-bold text-sm">{selectedBarley.diastaticPowerWK} &deg;WK</span>
              </div>
              <div>
                <span className="text-[#8C8476] block">&alpha;-AMYLASE:</span>
                <span className="text-[#FAF7F0] font-bold text-sm">{selectedBarley.alphaAmylaseDU} DU</span>
              </div>
              <div>
                <span className="text-[#8C8476] block">GERMINATION ENERGY:</span>
                <span className="text-[#52C47C] font-bold text-sm">{selectedBarley.germinationEnergyPct}%</span>
              </div>
              <div>
                <span className="text-[#8C8476] block">GRAIN MOISTURE:</span>
                <span className="text-[#FAF7F0] font-bold text-sm">{selectedBarley.moisturePct}%</span>
              </div>
              <div>
                <span className="text-[#8C8476] block">HARVEST CROP:</span>
                <span className="text-[#FAF7F0] font-bold text-sm">{selectedBarley.harvestYear}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Kilning & Peat Smoke Model (6 cols) */}
        <div className="lg:col-span-6 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-5">
          <div className="flex items-center gap-2 border-b border-[#2A241E] pb-3">
            <Flame className="w-5 h-5 text-[#E56A3C]" />
            <div>
              <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                Kilning Programme & Peat Phenol Kinetics
              </h3>
              <p className="text-xs text-[#8C8476]">
                Model heat schedule and peat smoke phenolic adsorption
              </p>
            </div>
          </div>

          <div className="space-y-4 text-xs font-mono">
            <div>
              <label className="block text-[#8C8476] mb-1">PEAT SOURCE PROFILE</label>
              <select
                value={kilning.peatSource}
                onChange={(e) => setKilning({ ...kilning, peatSource: e.target.value as KilningSchedule['peatSource'] })}
                className="w-full bg-[#12110F] text-[#FAF7F0] px-3 py-2 rounded border border-[#332A22] focus:outline-none focus:border-[#C67D38]"
              >
                <option value="Unpeated">Unpeated Clean Convection (0 ppm)</option>
                <option value="Highland Heath & Moss">Highland Heath & Moss (Earthy, Dry Smoke)</option>
                <option value="Islay Maritime Bog">Islay Maritime Bog (Medicinal, Seaweed, Tar)</option>
                <option value="Orkney Heather & Calluna">Orkney Heather & Calluna (Aromatic, Floral Peat)</option>
              </select>
            </div>

            {/* Phenol Slider */}
            <div className="bg-[#12110F] p-4 rounded border border-[#2E2822] space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-[#C5BDB2]">TARGET GRAIN PHENOLS (PPM):</span>
                <span className="text-base font-bold text-[#E56A3C]">{kilning.targetPhenolsPPM} PPM</span>
              </div>
              <input
                type="range"
                min="0"
                max="65"
                step="1"
                value={kilning.targetPhenolsPPM}
                onChange={(e) => setKilning({ ...kilning, targetPhenolsPPM: parseInt(e.target.value) })}
                className="w-full accent-[#E56A3C] bg-[#2A241E] h-2 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[#7A7062]">
                <span>0 ppm (Unpeated)</span>
                <span>15 ppm (Light)</span>
                <span>35 ppm (Medium)</span>
                <span>55+ ppm (Heavy Islay)</span>
              </div>
            </div>

            {/* Kilning Schedule Breakdown (0-4h, 4-8h, 8-12h) */}
            <div className="bg-[#12110F] p-4 rounded border border-[#2E2822] space-y-2">
              <div className="text-[11px] text-[#C67D38] font-bold">KILNING TIME-TEMPERATURE PROGRAMME</div>
              <div className="grid grid-cols-3 gap-2 text-center text-[10px]">
                <div className="bg-[#1C1916] p-2 rounded border border-[#2E2822]">
                  <div className="text-[#8C8476]">0 &ndash; 4 HOURS</div>
                  <div className="text-[#FAF7F0] font-bold text-xs mt-0.5">Drying Phase</div>
                  <div className="text-[#A69D8F]">45&deg;C &bull; High Airflow</div>
                </div>
                <div className="bg-[#1C1916] p-2 rounded border border-[#2E2822]">
                  <div className="text-[#8C8476]">4 &ndash; 8 HOURS</div>
                  <div className="text-[#FAF7F0] font-bold text-xs mt-0.5">Peat Smoke Kiss</div>
                  <div className="text-[#E56A3C]">58&deg;C &bull; Phenol Dosing</div>
                </div>
                <div className="bg-[#1C1916] p-2 rounded border border-[#2E2822]">
                  <div className="text-[#8C8476]">8 &ndash; 12 HOURS</div>
                  <div className="text-[#FAF7F0] font-bold text-xs mt-0.5">Curing & Colour</div>
                  <div className="text-[#FAF7F0]">72&deg;C &bull; Final Lock</div>
                </div>
              </div>
            </div>

            {/* Projected Peat Smoke Sensory Contribution */}
            <div className="bg-[#1C1814] p-3 rounded border border-[#3E2E20] space-y-1.5">
              <div className="text-[11px] text-[#E5A93C] font-bold uppercase">
                MODELLED PEAT SENSORY VECTOR (ESTIMATED INFLUENCE)
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                <div>
                  <span className="text-[#8C8476]">Smoke:</span>{' '}
                  <span className="text-[#FAF7F0] font-bold">{smokeContribution.toFixed(2)}</span>
                </div>
                <div>
                  <span className="text-[#8C8476]">Medicinal:</span>{' '}
                  <span className="text-[#FAF7F0] font-bold">{medicinalContribution.toFixed(2)}</span>
                </div>
                <div>
                  <span className="text-[#8C8476]">Char / Ash:</span>{' '}
                  <span className="text-[#FAF7F0] font-bold">{ashCharContribution.toFixed(2)}</span>
                </div>
                <div>
                  <span className="text-[#8C8476]">Seaweed / Brine:</span>{' '}
                  <span className="text-[#FAF7F0] font-bold">{seaweedContribution.toFixed(2)}</span>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};
