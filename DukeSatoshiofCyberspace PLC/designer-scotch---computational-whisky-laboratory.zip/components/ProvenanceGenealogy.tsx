'use client';

import React, { useState } from 'react';
import { WhiskyDesign, ProvenanceNode } from '@/types/whisky';
import { PROVENANCE_NODE_MAP, SYNTHETIC_PROVENANCE_TREE } from '@/lib/data/synthetic-db';
import { GitBranch, ShieldCheck, CheckCircle2, FileText, ArrowDown, MapPin, User, Clock, Layers } from 'lucide-react';

interface ProvenanceGenealogyProps {
  design: WhiskyDesign;
}

export const ProvenanceGenealogy: React.FC<ProvenanceGenealogyProps> = ({ design }) => {
  const [selectedNodeId, setSelectedNodeId] = useState<string>('PROV-BOTTLE-01');

  const selectedNode = PROVENANCE_NODE_MAP[selectedNodeId] || SYNTHETIC_PROVENANCE_TREE;

  // Ordered list of nodes for vertical provenance tree
  const provenanceChain: ProvenanceNode[] = [
    PROVENANCE_NODE_MAP['PROV-BOTTLE-01'],
    PROVENANCE_NODE_MAP['PROV-BLEND-01'],
    PROVENANCE_NODE_MAP['PROV-CASK-4812'],
    PROVENANCE_NODE_MAP['PROV-NEWMAKE-01'],
    PROVENANCE_NODE_MAP['PROV-DISTILL-01'],
    PROVENANCE_NODE_MAP['PROV-FERM-01'],
    PROVENANCE_NODE_MAP['PROV-MASH-01'],
    PROVENANCE_NODE_MAP['PROV-BARLEY-01'],
  ].filter(Boolean);

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#171513] border border-[#2E2822] p-5 rounded-lg">
        <div>
          <div className="text-xs font-mono text-[#C67D38] uppercase">STAGE 14 &bull; PROVENANCE & GENEALOGY GRAPH</div>
          <h2 className="font-editorial text-2xl font-bold text-[#F5F2EB]">
            Chain of Custody, Batch Genealogy & Traceability Graph
          </h2>
          <p className="text-xs text-[#8C8476] mt-0.5">
            Every bottle is computationally traceable back through vatting, maturation casks, spirit safe cuts, washback fermentation, mash tun, and agricultural barley lot.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="px-2.5 py-1 rounded bg-[#132A1B] text-[#52C47C] border border-[#214D2E] flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4" /> ALL 8 STAGES VERIFIED
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left (6 cols): Vertical Genealogical Pipeline Tree */}
        <div className="lg:col-span-6 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-4">
          <div className="border-b border-[#2A241E] pb-3 flex justify-between items-center">
            <div>
              <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                Visual Provenance Tree
              </h3>
              <p className="text-xs text-[#8C8476]">
                Click any node in the production graph to inspect audit dossier
              </p>
            </div>
            <span className="text-[10px] font-mono text-[#8C8476]">
              Bottling &larr; Agriculture
            </span>
          </div>

          <div className="space-y-3 relative">
            {provenanceChain.map((node, i) => {
              const isSelected = selectedNode.id === node.id;
              return (
                <div key={node.id} className="relative">
                  {/* Connecting vertical line */}
                  {i < provenanceChain.length - 1 && (
                    <div className="absolute left-6 top-10 bottom-0 w-0.5 bg-[#2E2822] -mb-3 z-0" />
                  )}

                  <div
                    onClick={() => setSelectedNodeId(node.id)}
                    className={`p-3.5 rounded border cursor-pointer relative z-10 transition-all flex items-start gap-3.5 ${
                      isSelected
                        ? 'bg-[#2A2016] border-[#C67D38] shadow-md ring-1 ring-[#C67D38]'
                        : 'bg-[#12110F] border-[#26211C] hover:border-[#42362A]'
                    }`}
                  >
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 font-mono text-xs font-bold ${
                      isSelected ? 'bg-[#C67D38] text-[#12110F]' : 'bg-[#231F1B] text-[#A89E90]'
                    }`}>
                      {8 - i}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-mono text-[10px] px-1.5 py-0.2 rounded bg-[#1C1814] text-[#C67D38] border border-[#3A2D20]">
                          {node.category}
                        </span>
                        <span className="font-mono text-[#52C47C] text-[10px] flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" /> {node.status}
                        </span>
                      </div>
                      <div className="font-bold text-[#FAF7F0] text-sm mt-1">
                        {node.title}
                      </div>
                      <div className="text-[11px] font-mono text-[#8C8476] mt-0.5">
                        Batch: {node.batchCode} &bull; {node.timestamp}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right (6 cols): Node Audit Record Details */}
        <div className="lg:col-span-6 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-5">
          <div className="border-b border-[#2A241E] pb-3">
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs text-[#C67D38] uppercase font-bold">
                AUDIT NODE DOSSIER &bull; {selectedNode.category}
              </span>
            </div>
            <h3 className="font-editorial text-xl font-bold text-[#F5F2EB] mt-0.5">
              {selectedNode.title}
            </h3>
            <p className="text-xs font-mono text-[#8C8476] mt-1">
              BATCH IDENTIFIER: <span className="text-[#FAF7F0] font-bold">{selectedNode.batchCode}</span>
            </p>
          </div>

          {/* Node Metadata Strip */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C]">
              <div className="text-[10px] text-[#8C8476] flex items-center gap-1">
                <Clock className="w-3 h-3 text-[#C67D38]" /> TIMESTAMP
              </div>
              <div className="text-[#FAF7F0] font-bold mt-1 text-[11px]">{selectedNode.timestamp}</div>
            </div>

            <div className="bg-[#12110F] p-3 rounded border border-[#26211C]">
              <div className="text-[10px] text-[#8C8476] flex items-center gap-1">
                <MapPin className="w-3 h-3 text-[#64B5F6]" /> LOCATION
              </div>
              <div className="text-[#FAF7F0] font-bold mt-1 text-[11px]">{selectedNode.location}</div>
            </div>

            <div className="bg-[#12110F] p-3 rounded border border-[#26211C]">
              <div className="text-[10px] text-[#8C8476] flex items-center gap-1">
                <User className="w-3 h-3 text-[#52C47C]" /> OPERATOR
              </div>
              <div className="text-[#FAF7F0] font-bold mt-1 text-[11px]">{selectedNode.operator}</div>
            </div>
          </div>

          {/* Verified Technical Process Metrics */}
          <div className="bg-[#12110F] p-4 rounded border border-[#2E2822] space-y-3 font-mono text-xs">
            <div className="text-[#C67D38] font-bold uppercase text-[11px] flex justify-between">
              <span>RECORDED BATCH METRICS & LAB LOG</span>
              <span className="text-[#52C47C]">AUDITED VALID</span>
            </div>

            <div className="space-y-2 pt-1">
              {Object.entries(selectedNode.metrics).map(([key, val]) => (
                <div key={key} className="bg-[#181614] p-2.5 rounded border border-[#2A241E] flex justify-between items-center">
                  <span className="text-[#A89E90]">{key}:</span>
                  <span className="text-[#FAF7F0] font-bold">{val}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Regulatory Compliance Sign-off */}
          <div className="bg-[#141210] p-4 rounded border border-[#2E2822] space-y-1.5 text-xs text-[#C5BDB2]">
            <div className="flex items-center gap-2 font-mono text-[11px] text-[#52C47C] font-bold">
              <ShieldCheck className="w-4 h-4" />
              <span>REGULATORY COMPLIANCE ATTESTATION</span>
            </div>
            <p className="text-[11px] leading-relaxed italic">
              Verified compliant with Scotch Whisky Regulations 2009 (SI 2009/2890). Distilled at an authentic Scottish distillery from 100% malted barley, fermented solely with yeast, matured in oak casks of capacity &le;700L in Scotland for &ge;3 years.
            </p>
          </div>

        </div>
      </div>
    </div>
  );
};
