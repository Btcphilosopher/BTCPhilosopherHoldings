'use client';

import React from 'react';
import { X, ShieldCheck, Scale, AlertTriangle, CheckCircle2, FileText, ExternalLink } from 'lucide-react';

interface ModelValidationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ModelValidationModal: React.FC<ModelValidationModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#171513] border border-[#3E342A] rounded-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto p-6 space-y-5 shadow-2xl">
        
        {/* Header */}
        <div className="flex justify-between items-start border-b border-[#2A241E] pb-3">
          <div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-[#C67D38]" />
              <h3 className="font-editorial text-xl font-bold text-[#F5F2EB]">
                Regulatory Rules & Model Calibration Discipline
              </h3>
            </div>
            <p className="text-xs text-[#8C8476] mt-0.5">
              The Scotch Whisky Regulations 2009 (SI 2009/2890) & Computational Epistemology
            </p>
          </div>

          <button
            onClick={onClose}
            className="text-[#8C8476] hover:text-[#FAF7F0] p-1 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Regulatory Verification Checklist */}
        <div className="space-y-3 text-xs">
          <div className="font-mono text-[#C67D38] font-bold text-xs uppercase">
            1. SCOTCH WHISKY REGULATIONS 2009 (SWR 2009) VERIFICATION RULES
          </div>

          <div className="space-y-2 bg-[#12110F] p-4 rounded border border-[#26211C] font-mono text-[11px] text-[#C5BDB2]">
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#52C47C] shrink-0 mt-0.5" />
              <div>
                <strong className="text-[#FAF7F0]">Raw Materials:</strong> Must be produced at a distillery in Scotland from water and malted barley (to which only whole grains of other cereals may be added). No added enzymes other than endogenous malt diastase.
              </div>
            </div>

            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#52C47C] shrink-0 mt-0.5" />
              <div>
                <strong className="text-[#FAF7F0]">Fermentation:</strong> Fermented at that distillery only by the addition of yeast.
              </div>
            </div>

            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#52C47C] shrink-0 mt-0.5" />
              <div>
                <strong className="text-[#FAF7F0]">Distillation Strength:</strong> Distilled to an alcoholic strength of less than 94.8% by volume so that the distillate has an aroma and taste derived from the raw materials.
              </div>
            </div>

            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#52C47C] shrink-0 mt-0.5" />
              <div>
                <strong className="text-[#FAF7F0]">Maturation Requirements:</strong> Matured in an excise warehouse in Scotland in oak casks of a capacity not exceeding 700 litres for a minimum period of three years.
              </div>
            </div>

            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#52C47C] shrink-0 mt-0.5" />
              <div>
                <strong className="text-[#FAF7F0]">Minimum Bottling Strength:</strong> Minimum alcoholic strength by volume on retail release is 40.0% ABV.
              </div>
            </div>

            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#52C47C] shrink-0 mt-0.5" />
              <div>
                <strong className="text-[#FAF7F0]">Age Statement Rule:</strong> Where an age statement is made, it must correspond to the youngest whisky in the blend.
              </div>
            </div>
          </div>
        </div>

        {/* Epistemological Model Discipline */}
        <div className="space-y-2 text-xs">
          <div className="font-mono text-[#E5A93C] font-bold text-xs uppercase">
            2. SCIENTIFIC EPISTEMOLOGY & DATA LABELLING DISCIPLINE
          </div>

          <div className="bg-[#12110F] p-4 rounded border border-[#26211C] space-y-2 text-[11px] text-[#C5BDB2] leading-relaxed">
            <p>
              <strong>Never present a model prediction as a physical tasting result.</strong> The platform strictly distinguishes between:
            </p>
            <ul className="list-disc pl-5 space-y-1 font-mono text-[10px]">
              <li><span className="text-[#52C47C] font-bold">MEASURED DATA:</span> Direct laboratory analytical measurements (GC-MS chromatography, density meter, ISO sensory panels).</li>
              <li><span className="text-[#E5A93C] font-bold">SIMULATED DATA:</span> Time-integrated differential physical equations (fermentation kinetics, copper interaction indices, Angel&apos;s share evaporation).</li>
              <li><span className="text-[#64B5F6] font-bold">MODELLED DATA:</span> Empirical statistical regressions and multivariate PCA projections.</li>
              <li><span className="text-[#C67D38] font-bold">PREDICTED OUTCOME:</span> Expected sensory vectors subject to explicit confidence bands (&plusmn; margin).</li>
            </ul>
          </div>
        </div>

        <div className="pt-2 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded bg-[#C67D38] hover:bg-[#DF9B56] text-[#12110F] font-semibold text-xs font-mono transition-colors"
          >
            Acknowledge & Close
          </button>
        </div>

      </div>
    </div>
  );
};
