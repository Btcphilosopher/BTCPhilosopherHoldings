'use client';

import React from 'react';
import { WhiskyDesign } from '@/types/whisky';
import { 
  Compass, 
  FlaskConical, 
  Wheat, 
  Droplet, 
  Flame, 
  Wine, 
  Boxes, 
  GitBranch, 
  TrendingUp, 
  ShieldCheck, 
  FileText, 
  Database,
  Layers,
  Sparkles,
  SearchCheck
} from 'lucide-react';

export type ActiveTab = 
  | 'signature'
  | 'target'
  | 'raw-material'
  | 'mash-water'
  | 'fermentation'
  | 'distillation'
  | 'new-make'
  | 'casks'
  | 'warehouse'
  | 'maturation'
  | 'blending'
  | 'sensory'
  | 'experiments'
  | 'economics'
  | 'provenance'
  | 'data-import'
  | 'validation';

interface HeaderNavProps {
  designs: WhiskyDesign[];
  activeDesignId: string;
  onSelectDesign: (id: string) => void;
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  onOpenValidation: () => void;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  designs,
  activeDesignId,
  onSelectDesign,
  activeTab,
  onSelectTab,
  onOpenValidation,
}) => {
  const currentDesign = designs.find(d => d.id === activeDesignId) || designs[0];

  const navItems: { id: ActiveTab; label: string; icon: React.ReactNode; group?: string }[] = [
    { id: 'signature', label: 'Overview', icon: <Compass className="w-3.5 h-3.5" /> },
    { id: 'target', label: '1. Target', icon: <Compass className="w-3.5 h-3.5" /> },
    { id: 'raw-material', label: '2. Raw Materials', icon: <Wheat className="w-3.5 h-3.5" /> },
    { id: 'mash-water', label: '3. Mash & Water', icon: <Droplet className="w-3.5 h-3.5" /> },
    { id: 'fermentation', label: '4. Fermentation', icon: <FlaskConical className="w-3.5 h-3.5" /> },
    { id: 'distillation', label: '5. Distillation', icon: <Flame className="w-3.5 h-3.5" /> },
    { id: 'new-make', label: '6. New Make', icon: <Sparkles className="w-3.5 h-3.5" /> },
    { id: 'casks', label: '7. Casks', icon: <Wine className="w-3.5 h-3.5" /> },
    { id: 'warehouse', label: '8. Warehouse Twin', icon: <Boxes className="w-3.5 h-3.5" /> },
    { id: 'maturation', label: '9. Maturation', icon: <Layers className="w-3.5 h-3.5" /> },
    { id: 'blending', label: '10. Blending Lab', icon: <FlaskConical className="w-3.5 h-3.5" /> },
    { id: 'sensory', label: '11. Sensory & PCA', icon: <SearchCheck className="w-3.5 h-3.5" /> },
    { id: 'experiments', label: '12. Experiments', icon: <FlaskConical className="w-3.5 h-3.5" /> },
    { id: 'economics', label: '13. Economics', icon: <TrendingUp className="w-3.5 h-3.5" /> },
    { id: 'provenance', label: '14. Provenance', icon: <GitBranch className="w-3.5 h-3.5" /> },
    { id: 'data-import', label: 'Data I/O', icon: <Database className="w-3.5 h-3.5" /> },
  ];

  return (
    <header className="border-b border-[#2A2621] bg-[#141210]/95 backdrop-blur sticky top-0 z-40">
      {/* Top Banner: Brand + Design Selector + Regulatory Badges */}
      <div className="max-w-[1720px] mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-4">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-gradient-to-br from-[#C67D38] via-[#8C4E1E] to-[#361E0A] flex items-center justify-center border border-[#E5A93C]/40 shadow-inner">
            <span className="font-editorial text-sm font-bold text-[#FFF3DE]">DS</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-editorial text-base tracking-widest font-bold text-[#F5F2EB] uppercase">
                Designer Scotch
              </h1>
              <span className="text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-[#2A231C] text-[#C67D38] border border-[#483726]">
                Lab v3.7
              </span>
            </div>
            <p className="text-[11px] text-[#8C8476] tracking-tight">
              Computational Distillery Laboratory &bull; Scotch Whisky Engineering
            </p>
          </div>
        </div>

        {/* Active Design Selector */}
        <div className="flex items-center gap-2 bg-[#1C1A17] p-1.5 rounded-md border border-[#332D26]">
          <span className="text-[11px] text-[#A69D8F] uppercase font-mono px-2">Design:</span>
          <select
            value={activeDesignId}
            onChange={(e) => onSelectDesign(e.target.value)}
            aria-label="Select Whisky Design"
            className="bg-[#12110F] text-[#F0ECE1] text-xs font-serif font-semibold px-3 py-1 rounded border border-[#443C33] focus:outline-none focus:border-[#C67D38]"
          >
            {designs.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name} ({d.targetProfile.region} &bull; {d.targetProfile.targetAgeYears}yo &bull; {d.code})
              </option>
            ))}
          </select>

          <span className="text-[10px] font-mono px-2 py-0.5 bg-[#251F19] text-[#E5A93C] rounded border border-[#4C3B29]">
            {currentDesign.targetProfile.style}
          </span>
        </div>

        {/* Data Discipline Classification Badges */}
        <div className="hidden lg:flex items-center gap-1.5 text-[10px] font-mono">
          <span className="px-2 py-0.5 rounded bg-[#132A1B] text-[#52C47C] border border-[#214D2E] flex items-center gap-1" title="Hard analytical measurement from GC-MS / Laboratory">
            <span className="w-1.5 h-1.5 rounded-full bg-[#52C47C]" /> MEASURED
          </span>
          <span className="px-2 py-0.5 rounded bg-[#2E2413] text-[#E5A93C] border border-[#523F1C] flex items-center gap-1" title="Physical ODE & Extraction Simulation">
            <span className="w-1.5 h-1.5 rounded-full bg-[#E5A93C]" /> SIMULATED
          </span>
          <span className="px-2 py-0.5 rounded bg-[#16233B] text-[#6BA5F2] border border-[#233B63] flex items-center gap-1" title="Multivariate Regression & Statistical Model">
            <span className="w-1.5 h-1.5 rounded-full bg-[#6BA5F2]" /> MODELLED
          </span>
          <button
            onClick={onOpenValidation}
            className="ml-2 px-2.5 py-1 rounded bg-[#26211C] hover:bg-[#383028] text-[#C5BDB2] hover:text-[#FFF] border border-[#42382E] transition-colors flex items-center gap-1"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-[#C67D38]" /> Model Calibration & SWR2009 Rules
          </button>
        </div>
      </div>

      {/* Process Chain Navigation Tabs */}
      <div className="max-w-[1720px] mx-auto px-2 flex items-center gap-1 overflow-x-auto no-scrollbar border-t border-[#23201C] py-1 text-xs">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-[#2A231C] text-[#F5C782] border border-[#6B4B27] shadow-sm'
                  : 'text-[#A39A8B] hover:text-[#E8E3D7] hover:bg-[#1C1A17]'
              }`}
            >
              {item.icon}
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
