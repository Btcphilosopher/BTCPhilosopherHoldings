'use client';

import React, { useState } from 'react';
import { WhiskyDesign, FermentationProfile, YeastProfile } from '@/types/whisky';
import { SYNTHETIC_YEAST_PROFILES } from '@/lib/data/synthetic-db';
import { simulateFermentationKinetics } from '@/lib/engines/kinetics';
import { FlaskConical, Thermometer, Clock, Activity, Save, Check, Sparkles } from 'lucide-react';

interface FermentationLabProps {
  design: WhiskyDesign;
  onUpdateDesign: (updated: WhiskyDesign) => void;
}

export const FermentationLab: React.FC<FermentationLabProps> = ({
  design,
  onUpdateDesign,
}) => {
  const [yeast, setYeast] = useState<YeastProfile>(design.yeastProfile);
  const [ferm, setFerm] = useState<FermentationProfile>(design.fermentationProfile);
  const [isSaved, setIsSaved] = useState(false);

  // Run real-time ODE kinetic simulation
  const kinetics = simulateFermentationKinetics(design.mashProfile, yeast, ferm);
  const { timeSteps, finalWashABV, apparentAttenuationPct, totalEstersPPM, higherAlcoholsPPM } = kinetics;

  const handleSave = () => {
    onUpdateDesign({
      ...design,
      yeastProfile: yeast,
      fermentationProfile: ferm,
      updatedAt: new Date().toISOString().split('T')[0],
    });
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  // SVG dimensions for kinetic charts
  const chartWidth = 580;
  const chartHeight = 180;
  const padding = 35;

  const maxHour = ferm.durationHours || 72;
  const maxEthanol = 10.0;
  const maxEsters = 6.0;

  const getX = (hour: number) => padding + (hour / maxHour) * (chartWidth - padding * 2);
  const getY_Ethanol = (abv: number) => chartHeight - padding - (abv / maxEthanol) * (chartHeight - padding * 2);
  const getY_Sugar = (sugar: number) => chartHeight - padding - (sugar / 180.0) * (chartHeight - padding * 2);
  const getY_Esters = (est: number) => chartHeight - padding - (est / maxEsters) * (chartHeight - padding * 2);

  const ethanolPath = timeSteps.map((pt, i) => `${i === 0 ? 'M' : 'L'} ${getX(pt.hour)} ${getY_Ethanol(pt.ethanolABVPct)}`).join(' ');
  const sugarPath = timeSteps.map((pt, i) => `${i === 0 ? 'M' : 'L'} ${getX(pt.hour)} ${getY_Sugar(pt.sugarConcentrationGperL)}`).join(' ');
  const isoamylPath = timeSteps.map((pt, i) => `${i === 0 ? 'M' : 'L'} ${getX(pt.hour)} ${getY_Esters(pt.isoamylAcetateMgL)}`).join(' ');
  const ethylHexPath = timeSteps.map((pt, i) => `${i === 0 ? 'M' : 'L'} ${getX(pt.hour)} ${getY_Esters(pt.ethylHexanoateMgL * 2.5)}`).join(' ');

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#171513] border border-[#2E2822] p-5 rounded-lg">
        <div>
          <div className="text-xs font-mono text-[#C67D38] uppercase">STAGE 4 &bull; FERMENTATION ENGINE</div>
          <h2 className="font-editorial text-2xl font-bold text-[#F5F2EB]">
            Yeast Inoculation, Kinetics & Flavour Precursor Synthesis
          </h2>
          <p className="text-xs text-[#8C8476] mt-0.5">
            0h &ndash; 72h+ kinetic differential modelling for ethanol, biomass, esters (isoamyl acetate/ethyl hexanoate), and organic acids.
          </p>
        </div>

        <button
          onClick={handleSave}
          className="flex items-center gap-1.5 px-4 py-2 rounded bg-[#C67D38] hover:bg-[#DF9B56] text-[#12110F] font-semibold text-xs transition-all shadow-md"
        >
          {isSaved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
          <span>{isSaved ? 'Saved Specification' : 'Save Specification'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (5 cols): Yeast Strain Selection & Parameters */}
        <div className="lg:col-span-5 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-4">
          <div className="flex items-center gap-2 border-b border-[#2A241E] pb-3">
            <FlaskConical className="w-5 h-5 text-[#52C47C]" />
            <div>
              <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                Yeast Profile Library
              </h3>
              <p className="text-xs text-[#8C8476]">
                Configure metabolic ester tendency and attenuation
              </p>
            </div>
          </div>

          <div className="space-y-2">
            {SYNTHETIC_YEAST_PROFILES.map(y => (
              <div
                key={y.id}
                onClick={() => setYeast(y)}
                className={`p-3 rounded border cursor-pointer transition-all ${
                  yeast.id === y.id
                    ? 'bg-[#152618] border-[#52C47C] text-[#FAF7F0]'
                    : 'bg-[#12110F] border-[#2E2822] text-[#A69E91] hover:border-[#38523C]'
                }`}
              >
                <div className="flex justify-between items-center text-xs font-mono">
                  <span className="font-bold text-[#FAF7F0]">{y.name}</span>
                  <span className="text-[#52C47C]">{y.fermentationRate}</span>
                </div>
                <div className="text-[11px] text-[#8C8476] mt-1 font-mono flex justify-between">
                  <span>Ester Tendency: {(y.esterTendency * 100).toFixed(0)}%</span>
                  <span>Attenuation: {y.attenuationLimitPct}%</span>
                </div>
              </div>
            ))}
          </div>

          {/* Fermentation Controls */}
          <div className="bg-[#12110F] p-4 rounded border border-[#2E2822] space-y-3 text-xs font-mono">
            <div className="text-[#52C47C] font-bold uppercase text-[11px]">
              PROCESS PARAMETERS & RUN CONTROLS
            </div>

            <div>
              <div className="flex justify-between text-[#8C8476] mb-1">
                <span>FERMENTATION DURATION:</span>
                <span className="text-[#FAF7F0] font-bold">{ferm.durationHours} Hours</span>
              </div>
              <input
                type="range" min="48" max="96" step="6" value={ferm.durationHours}
                onChange={(e) => setFerm({ ...ferm, durationHours: parseInt(e.target.value) })}
                className="w-full accent-[#52C47C] bg-[#2A241E] h-1.5 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[#7A7062]">
                <span>48h (Fast Clean)</span>
                <span>72h (Optimal Esters)</span>
                <span>96h (Secondary LAB Acid)</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[#8C8476] mb-1">PITCH TEMP (&deg;C)</label>
                <input
                  type="number" step="0.5" min="16.0" max="24.0" value={ferm.pitchTempC}
                  onChange={(e) => setFerm({ ...ferm, pitchTempC: parseFloat(e.target.value) || 19.5 })}
                  className="w-full bg-[#1C1916] text-[#FAF7F0] px-3 py-1.5 rounded border border-[#332A22] focus:outline-none focus:border-[#52C47C]"
                />
              </div>
              <div>
                <label className="block text-[#8C8476] mb-1">PEAK EXOTHERM (&deg;C)</label>
                <input
                  type="number" step="0.5" min="28.0" max="36.0" value={ferm.maxPeakTempC}
                  onChange={(e) => setFerm({ ...ferm, maxPeakTempC: parseFloat(e.target.value) || 33.0 })}
                  className="w-full bg-[#1C1916] text-[#FAF7F0] px-3 py-1.5 rounded border border-[#332A22] focus:outline-none focus:border-[#52C47C]"
                />
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between border-t border-[#26211C]">
              <span className="text-[#C5BDB2]">Allow Secondary LAB (Lactic Acid)?</span>
              <input
                type="checkbox"
                checked={ferm.lacticAcidBacteriaAllowed}
                onChange={(e) => setFerm({ ...ferm, lacticAcidBacteriaAllowed: e.target.checked })}
                className="w-4 h-4 accent-[#52C47C] rounded"
              />
            </div>
          </div>
        </div>

        {/* Right Column (7 cols): Dynamic Kinetic Curves Charts */}
        <div className="lg:col-span-7 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-6">
          <div className="flex items-center justify-between border-b border-[#2A241E] pb-3">
            <div>
              <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                Time-Course Fermentation Kinetics (0h &ndash; {ferm.durationHours}h)
              </h3>
              <p className="text-xs text-[#8C8476]">
                Simulated biological wash state during primary & secondary phases
              </p>
            </div>
            <div className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#132A1B] text-[#52C47C] border border-[#214D2E]">
              ODE Monod Solver
            </div>
          </div>

          {/* Chart 1: Sugars vs Ethanol ABV */}
          <div className="bg-[#12110F] p-4 rounded border border-[#26211C] space-y-2">
            <div className="flex justify-between items-center text-xs font-mono">
              <span className="text-[#E5A93C] font-semibold">Ethanol Accumulation (% ABV)</span>
              <span className="text-[#64B5F6] font-semibold">Sugar Depletion (g/L)</span>
            </div>

            <div className="w-full overflow-x-auto">
              <svg width="100%" height={chartHeight} viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="overflow-visible">
                {/* Grid lines */}
                {[0, 24, 48, 72, 96].filter(h => h <= maxHour).map(h => (
                  <g key={`grid-h-${h}`}>
                    <line x1={getX(h)} y1={padding} x2={getX(h)} y2={chartHeight - padding} stroke="#26211C" strokeDasharray="2,3" />
                    <text x={getX(h)} y={chartHeight - padding + 15} fill="#7A7062" fontSize="9" fontFamily="monospace" textAnchor="middle">{h}h</text>
                  </g>
                ))}

                {/* Sugar curve (Blue dashed) */}
                <path d={sugarPath} fill="none" stroke="#64B5F6" strokeWidth="2" strokeDasharray="4,2" />

                {/* Ethanol curve (Amber solid) */}
                <path d={ethanolPath} fill="none" stroke="#E5A93C" strokeWidth="2.5" />
              </svg>
            </div>
          </div>

          {/* Chart 2: Esters Synthesis (Isoamyl Acetate & Ethyl Hexanoate) */}
          <div className="bg-[#12110F] p-4 rounded border border-[#26211C] space-y-2">
            <div className="flex justify-between items-center text-xs font-mono">
              <span className="text-[#52C47C] font-semibold">Isoamyl Acetate (Banana/Pear, mg/L)</span>
              <span className="text-[#E57373] font-semibold">Ethyl Hexanoate (Green Apple, mg/L)</span>
            </div>

            <div className="w-full overflow-x-auto">
              <svg width="100%" height={chartHeight} viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="overflow-visible">
                {[0, 24, 48, 72, 96].filter(h => h <= maxHour).map(h => (
                  <line key={`grid-h2-${h}`} x1={getX(h)} y1={padding} x2={getX(h)} y2={chartHeight - padding} stroke="#26211C" strokeDasharray="2,3" />
                ))}

                <path d={isoamylPath} fill="none" stroke="#52C47C" strokeWidth="2.5" />
                <path d={ethylHexPath} fill="none" stroke="#E57373" strokeWidth="2" strokeDasharray="3,2" />
              </svg>
            </div>
          </div>

          {/* Wash Endpoint Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs font-mono">
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C]">
              <div className="text-[10px] text-[#8C8476]">FINAL WASH ABV:</div>
              <div className="text-base font-bold text-[#E5A93C] mt-0.5">{finalWashABV}%</div>
            </div>
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C]">
              <div className="text-[10px] text-[#8C8476]">ATTENUATION:</div>
              <div className="text-base font-bold text-[#52C47C] mt-0.5">{apparentAttenuationPct}%</div>
            </div>
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C]">
              <div className="text-[10px] text-[#8C8476]">TOTAL ESTERS:</div>
              <div className="text-base font-bold text-[#FAF7F0] mt-0.5">{totalEstersPPM} ppm</div>
            </div>
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C]">
              <div className="text-[10px] text-[#8C8476]">FUSEL ALCOHOLS:</div>
              <div className="text-base font-bold text-[#FAF7F0] mt-0.5">{higherAlcoholsPPM} ppm</div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
