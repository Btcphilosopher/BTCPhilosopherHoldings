'use client';

import React, { useState } from 'react';
import { WhiskyDesign, ExperimentTrial } from '@/types/whisky';
import { SYNTHETIC_EXPERIMENT_TRIALS } from '@/lib/data/synthetic-db';
import { FlaskConical, Plus, CheckCircle2, TrendingUp, Sparkles, Brain, ArrowRight, Save, Check } from 'lucide-react';

interface ExperimentsLabProps {
  design: WhiskyDesign;
  onUpdateDesign: (updated: WhiskyDesign) => void;
}

export const ExperimentsLab: React.FC<ExperimentsLabProps> = ({
  design,
  onUpdateDesign,
}) => {
  const [trials, setTrials] = useState<ExperimentTrial[]>(design.experiments || SYNTHETIC_EXPERIMENT_TRIALS);
  const [selectedTrial, setSelectedTrial] = useState<ExperimentTrial>(trials[0]);
  const [isSaved, setIsSaved] = useState(false);

  const handleUpdateTrialStatus = (armIndex: number, newStatus: 'Completed' | 'Validated' | 'In Progress') => {
    const updatedArms = [...selectedTrial.testArms];
    updatedArms[armIndex].status = newStatus;
    
    // Bayesian update: more completed/validated arms boost posterior confidence
    const validatedCount = updatedArms.filter(a => a.status === 'Validated').length;
    const newPosterior = Math.min(0.99, selectedTrial.bayesianPriorConfidence + (validatedCount * 0.08));

    const updatedTrial: ExperimentTrial = {
      ...selectedTrial,
      testArms: updatedArms,
      bayesianPosteriorConfidence: Math.round(newPosterior * 100) / 100,
    };

    setSelectedTrial(updatedTrial);
    setTrials(prev => prev.map(t => t.id === updatedTrial.id ? updatedTrial : t));
  };

  const handleSave = () => {
    onUpdateDesign({
      ...design,
      experiments: trials,
      updatedAt: new Date().toISOString().split('T')[0],
    });
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#171513] border border-[#2E2822] p-5 rounded-lg">
        <div>
          <div className="text-xs font-mono text-[#C67D38] uppercase">STAGE 12 &bull; EXPERIMENTAL DESIGN & BAYESIAN LAB</div>
          <h2 className="font-editorial text-2xl font-bold text-[#F5F2EB]">
            Design of Experiments (DOE) & Bayesian Learning Lab
          </h2>
          <p className="text-xs text-[#8C8476] mt-0.5">
            Test process hypotheses (fermentation hours, still reflux angles, cut points) and update posterior confidence.
          </p>
        </div>

        <button
          onClick={handleSave}
          className="flex items-center gap-1.5 px-4 py-2 rounded bg-[#C67D38] hover:bg-[#DF9B56] text-[#12110F] font-semibold text-xs transition-all shadow-md"
        >
          {isSaved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
          <span>{isSaved ? 'Saved Experiments' : 'Save Experiments'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left (5 cols): Experiment Selector */}
        <div className="lg:col-span-5 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-[#2A241E] pb-3">
            <div>
              <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                Experimental DOE Trials
              </h3>
              <p className="text-xs text-[#8C8476]">
                Factorial & response surface process investigations
              </p>
            </div>
          </div>

          <div className="space-y-2">
            {trials.map(t => (
              <div
                key={t.id}
                onClick={() => setSelectedTrial(t)}
                className={`p-3.5 rounded border cursor-pointer transition-all ${
                  selectedTrial.id === t.id
                    ? 'bg-[#2A2116] border-[#C67D38] text-[#FAF7F0]'
                    : 'bg-[#12110F] border-[#2E2822] text-[#A69E91] hover:border-[#483B2F]'
                }`}
              >
                <div className="flex justify-between items-center text-xs font-mono">
                  <span className="font-bold text-[#FAF7F0]">{t.code}</span>
                  <span className="text-[#E5A93C] font-semibold">{t.variableType}</span>
                </div>
                <div className="text-[11px] text-[#A69E91] mt-1 line-clamp-2">
                  {t.hypothesis}
                </div>
                <div className="text-[10px] font-mono text-[#52C47C] mt-2 flex justify-between">
                  <span>Prior Conf: {(t.bayesianPriorConfidence * 100).toFixed(0)}%</span>
                  <span>Posterior: {(t.bayesianPosteriorConfidence * 100).toFixed(0)}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right (7 cols): Selected Experiment Deep Dive & Bayesian Update */}
        <div className="lg:col-span-7 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-5">
          <div className="flex items-center justify-between border-b border-[#2A241E] pb-3">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-editorial text-xl font-bold text-[#F5F2EB]">
                  {selectedTrial.code}
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#2D2216] text-[#E5A93C] border border-[#523F23]">
                  {selectedTrial.variableType}
                </span>
              </div>
              <p className="text-xs text-[#8C8476] mt-0.5 italic">
                &ldquo;{selectedTrial.hypothesis}&rdquo;
              </p>
            </div>
          </div>

          {/* Bayesian Confidence Updating Meter */}
          <div className="bg-[#12110F] p-4 rounded border border-[#2E2822] space-y-3 font-mono text-xs">
            <div className="flex items-center gap-2 text-[#E5A93C] font-bold text-[11px] uppercase">
              <Brain className="w-4 h-4" />
              <span>BAYESIAN EVIDENCE & PARAMETER REFINEMENT</span>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-[#1C1814] p-3 rounded border border-[#2E2822]">
                <div className="text-[10px] text-[#8C8476]">PRIOR BELIEF (MODEL INITIAL):</div>
                <div className="text-lg font-bold text-[#FAF7F0] mt-0.5">{(selectedTrial.bayesianPriorConfidence * 100).toFixed(0)}%</div>
                <div className="w-full bg-[#231F1B] h-1.5 rounded-full overflow-hidden mt-2">
                  <div className="bg-[#8C8476] h-full" style={{ width: `${selectedTrial.bayesianPriorConfidence * 100}%` }} />
                </div>
              </div>

              <div className="bg-[#1C1814] p-3 rounded border border-[#2E2822]">
                <div className="text-[10px] text-[#52C47C]">POSTERIOR CONFIDENCE (MEASURED):</div>
                <div className="text-lg font-bold text-[#52C47C] mt-0.5">{(selectedTrial.bayesianPosteriorConfidence * 100).toFixed(0)}%</div>
                <div className="w-full bg-[#231F1B] h-1.5 rounded-full overflow-hidden mt-2">
                  <div className="bg-[#52C47C] h-full" style={{ width: `${selectedTrial.bayesianPosteriorConfidence * 100}%` }} />
                </div>
              </div>
            </div>
          </div>

          {/* Test Arms Matrix */}
          <div className="space-y-3">
            <div className="text-xs font-mono font-bold text-[#C67D38] uppercase">
              EXPERIMENTAL ARMS & MEASURED OUTCOMES
            </div>

            {selectedTrial.testArms.map((arm, idx) => (
              <div key={arm.armName} className="bg-[#12110F] p-4 rounded border border-[#26211C] space-y-2 text-xs">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="font-mono font-bold text-[#FAF7F0]">{arm.armName}</div>
                    <div className="text-[11px] font-mono text-[#E5A93C] mt-0.5">
                      Parameter Value: {arm.parameterValue}
                    </div>
                  </div>

                  {/* Status Toggle */}
                  <div className="flex items-center gap-1 font-mono text-[10px]">
                    {(['In Progress', 'Completed', 'Validated'] as const).map(st => (
                      <button
                        key={st}
                        onClick={() => handleUpdateTrialStatus(idx, st)}
                        className={`px-2 py-0.5 rounded border transition-colors ${
                          arm.status === st
                            ? st === 'Validated'
                              ? 'bg-[#132A1B] border-[#52C47C] text-[#52C47C] font-bold'
                              : 'bg-[#2A2016] border-[#C67D38] text-[#E5A93C] font-bold'
                            : 'bg-[#1C1916] border-[#2E2822] text-[#7A7062] hover:text-[#C5BDB2]'
                        }`}
                      >
                        {st}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="text-[11px] font-mono text-[#A89E90] bg-[#171513] p-2.5 rounded border border-[#221E1A] space-y-1">
                  <div><strong className="text-[#8C8476]">Predicted:</strong> {arm.predictedOutcome}</div>
                  {arm.measuredOutcome && (
                    <div><strong className="text-[#52C47C]">Measured Physical:</strong> {arm.measuredOutcome}</div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Scientific Notes */}
          <div className="bg-[#141210] p-4 rounded border border-[#2E2822] text-xs space-y-1">
            <span className="font-mono text-[10px] text-[#8C8476] uppercase font-bold">SCIENTIFIC OBSERVATION & CHROMATOGRAPHY NOTES:</span>
            <p className="text-[#C5BDB2] italic leading-relaxed">
              {selectedTrial.scientificNotes}
            </p>
          </div>

        </div>
      </div>
    </div>
  );
};
