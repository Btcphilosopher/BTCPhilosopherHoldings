'use client';

import React from 'react';
import { SensoryAxisProfile } from '@/types/whisky';

interface SensoryRadarProps {
  target?: Partial<SensoryAxisProfile>;
  predicted?: Partial<SensoryAxisProfile>;
  measured?: Partial<SensoryAxisProfile>;
  axes?: { key: keyof SensoryAxisProfile; label: string }[];
  size?: number;
  showLegend?: boolean;
}

const DEFAULT_AXES: { key: keyof SensoryAxisProfile; label: string }[] = [
  { key: 'fruit', label: 'Fruit' },
  { key: 'floral', label: 'Floral' },
  { key: 'malt', label: 'Malt' },
  { key: 'cereal', label: 'Cereal' },
  { key: 'spice', label: 'Spice' },
  { key: 'oak', label: 'Oak' },
  { key: 'vanilla', label: 'Vanilla' },
  { key: 'caramel', label: 'Caramel' },
  { key: 'nut', label: 'Nut' },
  { key: 'driedFruit', label: 'Dried Fruit' },
  { key: 'smoke', label: 'Smoke' },
  { key: 'mineral', label: 'Mineral' },
  { key: 'body', label: 'Body' },
  { key: 'dryness', label: 'Dryness' },
  { key: 'finish', label: 'Finish' },
  { key: 'complexity', label: 'Complexity' },
];

export const SensoryRadar: React.FC<SensoryRadarProps> = ({
  target,
  predicted,
  measured,
  axes = DEFAULT_AXES,
  size = 380,
  showLegend = true,
}) => {
  const center = size / 2;
  const radius = (size / 2) - 48;
  const numAxes = axes.length;
  const angleStep = (Math.PI * 2) / numAxes;

  // Concentric polygon grid levels: 0.25, 0.5, 0.75, 1.0
  const gridLevels = [0.25, 0.5, 0.75, 1.0];

  const getCoordinates = (value: number, index: number) => {
    const angle = index * angleStep - Math.PI / 2;
    const r = Math.min(1.0, Math.max(0, value)) * radius;
    const x = center + r * Math.cos(angle);
    const y = center + r * Math.sin(angle);
    return { x, y };
  };

  const generatePolygonPath = (profile?: Partial<SensoryAxisProfile>) => {
    if (!profile) return '';
    return axes
      .map((axis, i) => {
        const val = profile[axis.key] ?? 0;
        const { x, y } = getCoordinates(val, i);
        return `${x},${y}`;
      })
      .join(' ');
  };

  const targetPath = generatePolygonPath(target);
  const predictedPath = generatePolygonPath(predicted);
  const measuredPath = generatePolygonPath(measured);

  return (
    <div className="flex flex-col items-center">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="overflow-visible select-none">
          <defs>
            {/* Gradients for Scottish Highland aesthetics */}
            <radialGradient id="radarGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#C67D38" stopOpacity="0.08" />
              <stop offset="100%" stopColor="#C67D38" stopOpacity="0.0" />
            </radialGradient>
            <linearGradient id="targetGrad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#4A90E2" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#4A90E2" stopOpacity="0.05" />
            </linearGradient>
            <linearGradient id="predictedGrad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#E5A93C" stopOpacity="0.45" />
              <stop offset="100%" stopColor="#C67D38" stopOpacity="0.1" />
            </linearGradient>
            <linearGradient id="measuredGrad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#50E3C2" stopOpacity="0.5" />
              <stop offset="100%" stopColor="#2E7D32" stopOpacity="0.15" />
            </linearGradient>
          </defs>

          {/* Background circle glow */}
          <circle cx={center} cy={center} r={radius} fill="url(#radarGlow)" />

          {/* Concentric grid rings */}
          {gridLevels.map((lvl) => {
            const r = lvl * radius;
            return (
              <g key={`grid-${lvl}`}>
                <circle
                  cx={center}
                  cy={center}
                  r={r}
                  fill="none"
                  stroke="#332D26"
                  strokeWidth="1"
                  strokeDasharray={lvl < 1.0 ? '2,3' : 'none'}
                />
                <text
                  x={center + 4}
                  y={center - r + 10}
                  fill="#7A7062"
                  fontSize="9"
                  fontFamily="monospace"
                >
                  {lvl.toFixed(2)}
                </text>
              </g>
            );
          })}

          {/* Radial axis lines and labels */}
          {axes.map((axis, i) => {
            const angle = i * angleStep - Math.PI / 2;
            const lineX = center + radius * Math.cos(angle);
            const lineY = center + radius * Math.sin(angle);
            
            const labelDist = radius + 18;
            const labelX = center + labelDist * Math.cos(angle);
            const labelY = center + labelDist * Math.sin(angle) + 4;

            return (
              <g key={`axis-${axis.key}`}>
                <line
                  x1={center}
                  y1={center}
                  x2={lineX}
                  y2={lineY}
                  stroke="#332D26"
                  strokeWidth="1"
                />
                <text
                  x={labelX}
                  y={labelY}
                  textAnchor="middle"
                  fill="#C5BDB2"
                  fontSize="10"
                  fontFamily="sans-serif"
                  fontWeight="500"
                  className="tracking-tight"
                >
                  {axis.label}
                </text>
              </g>
            );
          })}

          {/* Target Profile Polygon (Blue dashed) */}
          {targetPath && target && (
            <g>
              <polygon
                points={targetPath}
                fill="url(#targetGrad)"
                stroke="#64B5F6"
                strokeWidth="1.5"
                strokeDasharray="4,3"
                opacity={0.85}
              />
              {axes.map((axis, i) => {
                const { x, y } = getCoordinates(target[axis.key] ?? 0, i);
                return (
                  <circle
                    key={`target-pt-${axis.key}`}
                    cx={x}
                    cy={y}
                    r="2.5"
                    fill="#90CAF9"
                  />
                );
              })}
            </g>
          )}

          {/* Predicted Model Profile Polygon (Amber/Copper solid) */}
          {predictedPath && predicted && (
            <g>
              <polygon
                points={predictedPath}
                fill="url(#predictedGrad)"
                stroke="#E5A93C"
                strokeWidth="2"
              />
              {axes.map((axis, i) => {
                const { x, y } = getCoordinates(predicted[axis.key] ?? 0, i);
                return (
                  <circle
                    key={`predicted-pt-${axis.key}`}
                    cx={x}
                    cy={y}
                    r="3.5"
                    fill="#E5A93C"
                    stroke="#1E1B18"
                    strokeWidth="1.5"
                  />
                );
              })}
            </g>
          )}

          {/* Measured Physical Panel Score (Green/Teal solid) */}
          {measuredPath && measured && (
            <g>
              <polygon
                points={measuredPath}
                fill="url(#measuredGrad)"
                stroke="#50E3C2"
                strokeWidth="1.8"
              />
              {axes.map((axis, i) => {
                const { x, y } = getCoordinates(measured[axis.key] ?? 0, i);
                return (
                  <rect
                    key={`measured-pt-${axis.key}`}
                    x={x - 3}
                    y={y - 3}
                    width="6"
                    height="6"
                    fill="#50E3C2"
                    stroke="#141312"
                    strokeWidth="1"
                  />
                );
              })}
            </g>
          )}
        </svg>
      </div>

      {/* Legend & Confidence breakdown */}
      {showLegend && (
        <div className="flex flex-wrap items-center justify-center gap-6 mt-3 text-xs">
          {target && (
            <div className="flex items-center gap-2">
              <span className="w-3 h-0.5 border-t border-dashed border-[#64B5F6] inline-block" />
              <span className="text-[#90CAF9] font-medium">Target Specification</span>
            </div>
          )}
          {predicted && (
            <div className="flex items-center gap-2">
              <span className="w-3 h-1 bg-[#E5A93C] rounded-sm inline-block" />
              <span className="text-[#E5A93C] font-medium">Modelled / Predicted Output</span>
            </div>
          )}
          {measured && (
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 bg-[#50E3C2] inline-block" />
              <span className="text-[#50E3C2] font-medium">Measured Sensory Panel</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
