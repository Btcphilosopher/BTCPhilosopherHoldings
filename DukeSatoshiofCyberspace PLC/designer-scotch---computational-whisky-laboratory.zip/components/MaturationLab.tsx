'use client';

import React, { useState } from 'react';
import { WhiskyDesign, CaskEntity, SensoryAxisProfile } from '@/types/whisky';
import { simulateCaskMaturation } from '@/lib/engines/maturation';
import { SYNTHETIC_WAREHOUSES, SYNTHETIC_CASKS } from '@/lib/data/synthetic-db';
import { Layers, Play, RefreshCw, Sliders, Info, Sparkles, TrendingUp } from 'lucide-react';
import { SensoryRadar } from './SensoryRadar';

interface MaturationLabProps {
  design: WhiskyDesign;
}

export const MaturationLab: React.FC<MaturationLabProps> = ({ design }) => {
  const [selectedCaskId, setSelectedCaskId] = useState<string>(design.caskProgramme[0]?.id || SYNTHETIC_CASKS[0].id);
  const [targetAge, setTargetAge] = useState<number>(design.targetProfile.targetAgeYears || 18);
  const [showMonteCarlo, setShowMonteCarlo] = useState<boolean>(false);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  const selectedCask = SYNTHETIC_CASKS.find(c => c.id === selectedCaskId) || SYNTHETIC_CASKS[0];
  const warehouse = SYNTHETIC_WAREHOUSES.find(w => w.id === design.warehouseId) || SYNTHETIC_WAREHOUSES[0];

  const initialSensory = design.distillationProfile.predictedNewMakeSensory || design.targetProfile.sensory;

  // Run scientific maturation engine
  const simulation = simulateCaskMaturation(initialSensory, selectedCask, warehouse, targetAge);
  const currentPoint = simulation.timeline.find(p => p.ageYears === targetAge) || simulation.timeline[simulation.timeline.length - 1];

  const handleRunMonteCarlo = () => {
    setIsSimulating(true);
    setTimeout(() => {
      setIsSimulating(false);
      setShowMonteCarlo(true);
    }, 600);
  };

  // SVG dimensions for maturation curves
  const width = 640;
  const height = 240;
  const pad = 40;

  const maxYear = 25;
  const getX = (yr: number) => pad + (yr / maxYear) * (width - pad * 2);
  const getY = (val: number) => height - pad - Math.min(1.0, Math.max(0, val)) * (height - pad * 2);

  // Generate paths for sensory dimensions across timeline
  const makePath = (key: keyof SensoryAxisProfile) => {
    return simulation.timeline
      .filter(p => p.ageYears <= maxYear)
      .map((p, i) => `${i === 0 ? 'M' : 'L'} ${getX(p.ageYears)} ${getY(p.sensory[key] || 0)}`)
      .join(' ');
  };

  const vanillaPath = makePath('vanilla');
  const oakPath = makePath('oak');
  const fruitPath = makePath('fruit');
  const spicePath = makePath('spice');
  const complexityPath = makePath('complexity');
  const tanninPath = makePath('tannin');

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#171513] border border-[#2E2822] p-5 rounded-lg">
        <div>
          <div className="text-xs font-mono text-[#C67D38] uppercase">STAGE 9 &bull; TIME-DEPENDENT MATURATION ENGINE</div>
          <h2 className="font-editorial text-2xl font-bold text-[#F5F2EB]">
            Wood Extraction Curves, Angel’s Share & Monte Carlo Simulation
          </h2>
          <p className="text-xs text-[#8C8476] mt-0.5">
            Model interactive oak vanillin, lactones, tannin polymerisation, and evaporative volume/alcohol decay.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <select
            value={selectedCaskId}
            onChange={(e) => setSelectedCaskId(e.target.value)}
            className="bg-[#12110F] text-[#FAF7F0] text-xs font-mono px-3 py-2 rounded border border-[#332A22] focus:outline-none focus:border-[#C67D38]"
          >
            {SYNTHETIC_CASKS.slice(0, 6).map(c => (
              <option key={c.id} value={c.id}>
                {c.caskNumber} ({c.woodSpecies.split('(')[0]} &bull; {c.seasoning})
              </option>
            ))}
          </select>

          <button
            onClick={handleRunMonteCarlo}
            disabled={isSimulating}
            className="flex items-center gap-1.5 px-4 py-2 rounded bg-[#C67D38] hover:bg-[#DF9B56] text-[#12110F] font-semibold text-xs transition-all shadow-md"
          >
            {isSimulating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
            <span>{isSimulating ? 'Simulating 1,000 Runs...' : 'Run Monte Carlo 1,000 Runs'}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (7 cols): Interactive Curves & Scrubber */}
        <div className="lg:col-span-7 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-5">
          <div className="flex items-center justify-between border-b border-[#2A241E] pb-3">
            <div>
              <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                Multivariate Sensory Evolution (0 to 25 Years)
              </h3>
              <p className="text-xs text-[#8C8476]">
                Kinetic trajectory with empirical wood saturation asymptotes
              </p>
            </div>
            <div className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#2A231C] text-[#E5A93C] border border-[#483726]">
              {selectedCask.seasoning} &bull; {selectedCask.toastLevel} Toast
            </div>
          </div>

          {/* SVG Multi-Line Chart */}
          <div className="bg-[#12110F] p-4 rounded border border-[#26211C] space-y-2">
            <div className="flex flex-wrap gap-4 text-xs font-mono mb-2">
              <span className="flex items-center gap-1.5 text-[#E5A93C]"><span className="w-3 h-0.5 bg-[#E5A93C]" /> Vanilla ({currentPoint.sensory.vanilla})</span>
              <span className="flex items-center gap-1.5 text-[#B5672A]"><span className="w-3 h-0.5 bg-[#B5672A]" /> Toasted Oak ({currentPoint.sensory.oak})</span>
              <span className="flex items-center gap-1.5 text-[#64B5F6]"><span className="w-3 h-0.5 bg-[#64B5F6]" /> Orchard Fruit ({currentPoint.sensory.fruit})</span>
              <span className="flex items-center gap-1.5 text-[#E57373]"><span className="w-3 h-0.5 bg-[#E57373]" /> Spice ({currentPoint.sensory.spice})</span>
              <span className="flex items-center gap-1.5 text-[#52C47C]"><span className="w-3 h-0.5 bg-[#52C47C]" /> Complexity ({currentPoint.sensory.complexity})</span>
            </div>

            <div className="w-full overflow-x-auto">
              <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} className="overflow-visible select-none">
                {/* Years Grid */}
                {[0, 3, 5, 8, 10, 12, 15, 18, 21, 25].map(yr => (
                  <g key={`mat-yr-${yr}`}>
                    <line x1={getX(yr)} y1={pad} x2={getX(yr)} y2={height - pad} stroke="#26211C" strokeDasharray="2,3" />
                    <text x={getX(yr)} y={height - pad + 15} fill="#7A7062" fontSize="9" fontFamily="monospace" textAnchor="middle">{yr}y</text>
                  </g>
                ))}

                {/* Scrubber vertical line */}
                <line
                  x1={getX(targetAge)}
                  y1={pad}
                  x2={getX(targetAge)}
                  y2={height - pad}
                  stroke="#FAF7F0"
                  strokeWidth="1.5"
                  strokeDasharray="4,2"
                />

                {/* Sensory Lines */}
                <path d={vanillaPath} fill="none" stroke="#E5A93C" strokeWidth="2.5" />
                <path d={oakPath} fill="none" stroke="#B5672A" strokeWidth="2.5" />
                <path d={fruitPath} fill="none" stroke="#64B5F6" strokeWidth="2" strokeDasharray="3,2" />
                <path d={spicePath} fill="none" stroke="#E57373" strokeWidth="1.8" />
                <path d={complexityPath} fill="none" stroke="#52C47C" strokeWidth="2" />
                <path d={tanninPath} fill="none" stroke="#8C8476" strokeWidth="1.5" strokeDasharray="2,2" />

                {/* Dot at scrubber */}
                <circle cx={getX(targetAge)} cy={getY(currentPoint.sensory.complexity)} r="4" fill="#52C47C" />
              </svg>
            </div>
          </div>

          {/* Interactive Age Scrubber Slider */}
          <div className="bg-[#12110F] p-4 rounded border border-[#26211C] space-y-2 font-mono text-xs">
            <div className="flex justify-between items-center">
              <span className="text-[#8C8476]">SCRUB MATURATION TARGET:</span>
              <span className="text-base font-bold text-[#E5A93C]">{targetAge} YEARS IN OAK</span>
            </div>
            <input
              type="range" min="0" max="25" step="1" value={targetAge}
              onChange={(e) => setTargetAge(parseInt(e.target.value))}
              className="w-full accent-[#C67D38] bg-[#2A241E] h-2 rounded-lg cursor-pointer"
            />
          </div>

          {/* Angel's Share & Volume Loss Calculation */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs font-mono">
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C]">
              <div className="text-[10px] text-[#8C8476]">REMAINING VOL:</div>
              <div className="text-base font-bold text-[#FAF7F0] mt-0.5">{currentPoint.remainingVolumeLitres} L</div>
              <div className="text-[9px] text-[#E57373]">-{simulation.volumeLossTotalPct}% Total Loss</div>
            </div>
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C]">
              <div className="text-[10px] text-[#8C8476]">ESTIMATED STRENGTH:</div>
              <div className="text-base font-bold text-[#E5A93C] mt-0.5">{currentPoint.estimatedABVPct}% ABV</div>
              <div className="text-[9px] text-[#8C8476]">-{simulation.lpaLossTotalPct}% LPA Loss</div>
            </div>
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C]">
              <div className="text-[10px] text-[#8C8476]">WOOD EXTRACT:</div>
              <div className="text-base font-bold text-[#52C47C] mt-0.5">{currentPoint.woodExtractPPM} ppm</div>
              <div className="text-[9px] text-[#8C8476]">Vanillin/Lactones</div>
            </div>
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C]">
              <div className="text-[10px] text-[#8C8476]">UNCERTAINTY BAND:</div>
              <div className="text-base font-bold text-[#FAF7F0] mt-0.5">&plusmn;{(currentPoint.uncertaintyMargin * 100).toFixed(1)}%</div>
              <div className="text-[9px] text-[#8C8476]">95% CI Boundary</div>
            </div>
          </div>
        </div>

        {/* Right Column (5 cols): Sensory Radar + Monte Carlo Percentile Bands */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Radar at Selected Age */}
          <div className="bg-[#171513] border border-[#2E2822] rounded-lg p-5 flex flex-col items-center">
            <h4 className="font-editorial text-base font-bold text-[#F5F2EB] mb-2 self-start">
              Predicted Sensory State at {targetAge} Years
            </h4>
            <SensoryRadar predicted={currentPoint.sensory} size={290} showLegend={false} />
          </div>

          {/* Monte Carlo 1,000 Trajectories Display */}
          {showMonteCarlo && (
            <div className="bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-3">
              <div className="flex items-center gap-2 border-b border-[#2A241E] pb-2">
                <Sparkles className="w-4 h-4 text-[#E5A93C]" />
                <h4 className="font-editorial text-base font-bold text-[#F5F2EB]">
                  Monte Carlo 1,000 Runs & Uncertainty Bands
                </h4>
              </div>

              <div className="space-y-2 text-xs font-mono text-[#C5BDB2]">
                <div className="flex justify-between bg-[#12110F] p-2 rounded border border-[#26211C]">
                  <span>P90 Upper Bound Complexity:</span>
                  <span className="text-[#52C47C] font-bold">
                    {simulation.monteCarloSummary.p90UpperBand[simulation.monteCarloSummary.p90UpperBand.length - 1]}
                  </span>
                </div>
                <div className="flex justify-between bg-[#12110F] p-2 rounded border border-[#26211C]">
                  <span>Median Modeled Trajectory:</span>
                  <span className="text-[#E5A93C] font-bold">
                    {simulation.monteCarloSummary.medianTrajectory[simulation.monteCarloSummary.medianTrajectory.length - 1]}
                  </span>
                </div>
                <div className="flex justify-between bg-[#12110F] p-2 rounded border border-[#26211C]">
                  <span>P10 Lower Bound:</span>
                  <span className="text-[#E57373] font-bold">
                    {simulation.monteCarloSummary.p10LowerBand[simulation.monteCarloSummary.p10LowerBand.length - 1]}
                  </span>
                </div>
              </div>

              <p className="text-[11px] text-[#8C8476] leading-relaxed">
                Stochastic variations account for warehouse temperature swings (&plusmn;1.4&deg;C) and staves porosity fluctuations.
              </p>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
