'use client';

import React, { useState } from 'react';
import { WhiskyDesign, MashProfile, WaterChemistry } from '@/types/whisky';
import { SYNTHETIC_WATER_PROFILES } from '@/lib/data/synthetic-db';
import { Droplet, Thermometer, Gauge, Save, Check, RefreshCw } from 'lucide-react';

interface MashWaterLabProps {
  design: WhiskyDesign;
  onUpdateDesign: (updated: WhiskyDesign) => void;
}

export const MashWaterLab: React.FC<MashWaterLabProps> = ({
  design,
  onUpdateDesign,
}) => {
  const [water, setWater] = useState<WaterChemistry>(design.waterChemistry);
  const [mash, setMash] = useState<MashProfile>(design.mashProfile);
  const [isSaved, setIsSaved] = useState(false);

  // Mashing extract calculations
  const gristTonnes = 8.5;
  const liquorVolumeLitres = Math.round(gristTonnes * 1000 * mash.liquorToGristRatio);
  const estimatedSugarPlato = Math.round((mash.originalGravitySG - 1.0) * 1000 * 0.25 * 10) / 10;
  const theoreticalLPA = Math.round(gristTonnes * (design.barleyProfile.potentialExtractLPAperTonne || 415) * (mash.fermentableExtractPct / 100));

  const handleSave = () => {
    onUpdateDesign({
      ...design,
      waterChemistry: water,
      mashProfile: mash,
      updatedAt: new Date().toISOString().split('T')[0],
    });
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#171513] border border-[#2E2822] p-5 rounded-lg">
        <div>
          <div className="text-xs font-mono text-[#C67D38] uppercase">STAGE 3 &bull; MASHING & WATER CHEMISTRY</div>
          <h2 className="font-editorial text-2xl font-bold text-[#F5F2EB]">
            Brewing Liquor Chemistry, Mash Tun Extraction & Gravity
          </h2>
          <p className="text-xs text-[#8C8476] mt-0.5">
            Model water ion concentrations, enzyme activation strike temperatures, and wort clarity.
          </p>
        </div>

        <button
          onClick={handleSave}
          className="flex items-center gap-1.5 px-4 py-2 rounded bg-[#C67D38] hover:bg-[#DF9B56] text-[#12110F] font-semibold text-xs transition-all shadow-md"
        >
          {isSaved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
          <span>{isSaved ? 'Saved Specification' : 'Save Specification'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left (6 cols): Water Chemistry Engine */}
        <div className="lg:col-span-6 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-4">
          <div className="flex items-center gap-2 border-b border-[#2A241E] pb-3">
            <Droplet className="w-5 h-5 text-[#64B5F6]" />
            <div>
              <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                Brewing Water Ionic Balance (ppm / mg/L)
              </h3>
              <p className="text-xs text-[#8C8476]">
                Configure distillery water catchment & mineral additions
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <label className="block font-mono text-xs text-[#8C8476]">SOURCE PROFILE PRESET</label>
            <div className="grid grid-cols-1 gap-2">
              {SYNTHETIC_WATER_PROFILES.map(w => (
                <div
                  key={w.id}
                  onClick={() => setWater(w)}
                  className={`p-3 rounded border cursor-pointer transition-all ${
                    water.id === w.id
                      ? 'bg-[#182638] border-[#64B5F6] text-[#FAF7F0]'
                      : 'bg-[#12110F] border-[#2E2822] text-[#A69E91] hover:border-[#384860]'
                  }`}
                >
                  <div className="flex justify-between items-center text-xs font-mono">
                    <span className="font-bold text-[#FAF7F0]">{w.name}</span>
                    <span className="text-[#64B5F6]">pH {w.pH}</span>
                  </div>
                  <div className="text-[11px] text-[#8C8476] mt-0.5">{w.source}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Ionic Sliders */}
          <div className="bg-[#12110F] p-4 rounded border border-[#2E2822] space-y-3 text-xs font-mono">
            <div className="text-[#64B5F6] font-bold uppercase text-[11px] flex justify-between">
              <span>MINERAL ION CONCENTRATIONS (PPM)</span>
              <span>CALCULATED pH: {water.pH}</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <div className="flex justify-between text-[#8C8476]">
                  <span>Calcium (Ca2+):</span>
                  <span className="text-[#FAF7F0] font-bold">{water.calciumPPM} ppm</span>
                </div>
                <input
                  type="range" min="2" max="120" step="1" value={water.calciumPPM}
                  onChange={(e) => setWater({ ...water, calciumPPM: parseInt(e.target.value) })}
                  className="w-full accent-[#64B5F6] bg-[#2A241E] h-1.5 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[#8C8476]">
                  <span>Magnesium (Mg2+):</span>
                  <span className="text-[#FAF7F0] font-bold">{water.magnesiumPPM} ppm</span>
                </div>
                <input
                  type="range" min="1" max="40" step="0.5" value={water.magnesiumPPM}
                  onChange={(e) => setWater({ ...water, magnesiumPPM: parseFloat(e.target.value) })}
                  className="w-full accent-[#64B5F6] bg-[#2A241E] h-1.5 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[#8C8476]">
                  <span>Bicarbonate (HCO3-):</span>
                  <span className="text-[#FAF7F0] font-bold">{water.bicarbonatePPM} ppm</span>
                </div>
                <input
                  type="range" min="5" max="150" step="1" value={water.bicarbonatePPM}
                  onChange={(e) => setWater({ ...water, bicarbonatePPM: parseInt(e.target.value) })}
                  className="w-full accent-[#64B5F6] bg-[#2A241E] h-1.5 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[#8C8476]">
                  <span>Sulfate (SO4 2-):</span>
                  <span className="text-[#FAF7F0] font-bold">{water.sulfatePPM} ppm</span>
                </div>
                <input
                  type="range" min="2" max="100" step="1" value={water.sulfatePPM}
                  onChange={(e) => setWater({ ...water, sulfatePPM: parseInt(e.target.value) })}
                  className="w-full accent-[#64B5F6] bg-[#2A241E] h-1.5 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[#8C8476]">
                  <span>Chloride (Cl-):</span>
                  <span className="text-[#FAF7F0] font-bold">{water.chloridePPM} ppm</span>
                </div>
                <input
                  type="range" min="5" max="80" step="1" value={water.chloridePPM}
                  onChange={(e) => setWater({ ...water, chloridePPM: parseInt(e.target.value) })}
                  className="w-full accent-[#64B5F6] bg-[#2A241E] h-1.5 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[#8C8476]">
                  <span>Sodium (Na+):</span>
                  <span className="text-[#FAF7F0] font-bold">{water.sodiumPPM} ppm</span>
                </div>
                <input
                  type="range" min="2" max="60" step="1" value={water.sodiumPPM}
                  onChange={(e) => setWater({ ...water, sodiumPPM: parseInt(e.target.value) })}
                  className="w-full accent-[#64B5F6] bg-[#2A241E] h-1.5 rounded-lg cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right (6 cols): Mash Profile & Extraction */}
        <div className="lg:col-span-6 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-4">
          <div className="flex items-center gap-2 border-b border-[#2A241E] pb-3">
            <Gauge className="w-5 h-5 text-[#E5A93C]" />
            <div>
              <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                Mash Tun Programme & Wort Extraction
              </h3>
              <p className="text-xs text-[#8C8476]">
                Configure liquor ratio, strike water temperature, and sparge cycles
              </p>
            </div>
          </div>

          <div className="space-y-4 text-xs font-mono">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[#8C8476] mb-1">LIQUOR TO GRIST RATIO</label>
                <div className="flex items-center gap-2">
                  <input
                    type="number" step="0.1" min="3.0" max="5.5" value={mash.liquorToGristRatio}
                    onChange={(e) => setMash({ ...mash, liquorToGristRatio: parseFloat(e.target.value) || 4.0 })}
                    className="w-full bg-[#12110F] text-[#FAF7F0] px-3 py-2 rounded border border-[#332A22] focus:outline-none focus:border-[#C67D38]"
                  />
                  <span className="text-[#8C8476]">L/kg</span>
                </div>
              </div>

              <div>
                <label className="block text-[#8C8476] mb-1">STRIKE TEMPERATURE</label>
                <div className="flex items-center gap-2">
                  <input
                    type="number" step="0.5" min="60.0" max="69.0" value={mash.strikeTempC}
                    onChange={(e) => setMash({ ...mash, strikeTempC: parseFloat(e.target.value) || 64.5 })}
                    className="w-full bg-[#12110F] text-[#FAF7F0] px-3 py-2 rounded border border-[#332A22] focus:outline-none focus:border-[#C67D38]"
                  />
                  <span className="text-[#8C8476]">&deg;C</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[#8C8476] mb-1">ORIGINAL GRAVITY (SG)</label>
                <input
                  type="number" step="0.001" min="1.050" max="1.085" value={mash.originalGravitySG}
                  onChange={(e) => setMash({ ...mash, originalGravitySG: parseFloat(e.target.value) || 1.065 })}
                  className="w-full bg-[#12110F] text-[#FAF7F0] px-3 py-2 rounded border border-[#332A22] focus:outline-none focus:border-[#C67D38]"
                />
              </div>

              <div>
                <label className="block text-[#8C8476] mb-1">WORT TURBIDITY (EBC)</label>
                <div className="flex items-center gap-2">
                  <input
                    type="number" min="5" max="50" value={mash.clearWortTurbidityEBC}
                    onChange={(e) => setMash({ ...mash, clearWortTurbidityEBC: parseInt(e.target.value) || 12 })}
                    className="w-full bg-[#12110F] text-[#FAF7F0] px-3 py-2 rounded border border-[#332A22] focus:outline-none focus:border-[#C67D38]"
                  />
                  <span className="text-[10px] text-[#8C8476]">{mash.clearWortTurbidityEBC < 18 ? 'Clear (Ester)' : 'Cloudy (Nutty)'}</span>
                </div>
              </div>
            </div>

            {/* Calculated Wort Batch Output Card */}
            <div className="bg-[#12110F] p-4 rounded border border-[#2E2822] space-y-3">
              <div className="text-[#E5A93C] font-bold uppercase text-[11px]">
                CALCULATED MASH RUN OUTPUT
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
                <div className="bg-[#1C1916] p-2 rounded border border-[#2E2822]">
                  <div className="text-[10px] text-[#8C8476]">WORT VOLUME:</div>
                  <div className="text-[#FAF7F0] font-bold text-sm">{mash.wortVolumeLitres.toLocaleString()} L</div>
                </div>
                <div className="bg-[#1C1916] p-2 rounded border border-[#2E2822]">
                  <div className="text-[10px] text-[#8C8476]">SUGARS (PLATO):</div>
                  <div className="text-[#FAF7F0] font-bold text-sm">{estimatedSugarPlato}&deg;P</div>
                </div>
                <div className="bg-[#1C1916] p-2 rounded border border-[#2E2822]">
                  <div className="text-[10px] text-[#8C8476]">EXTRACT EFF.:</div>
                  <div className="text-[#52C47C] font-bold text-sm">{mash.fermentableExtractPct}%</div>
                </div>
                <div className="bg-[#1C1916] p-2 rounded border border-[#2E2822]">
                  <div className="text-[10px] text-[#8C8476]">POTENTIAL LPA:</div>
                  <div className="text-[#E5A93C] font-bold text-sm">{theoreticalLPA} LPA</div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};
