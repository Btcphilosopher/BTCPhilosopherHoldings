'use client';

import React, { useState } from 'react';
import { WhiskyDesign, DistillationProfile, StillGeometry } from '@/types/whisky';
import { simulateDistillationProcess } from '@/lib/engines/kinetics';
import { Flame, Sliders, Save, Check, RefreshCw, Gauge, Zap } from 'lucide-react';

interface DistillationLabProps {
  design: WhiskyDesign;
  onUpdateDesign: (updated: WhiskyDesign) => void;
}

export const DistillationLab: React.FC<DistillationLabProps> = ({
  design,
  onUpdateDesign,
}) => {
  const [distProfile, setDistProfile] = useState<DistillationProfile>(design.distillationProfile);
  const [isSaved, setIsSaved] = useState(false);

  // Run distillation simulation
  const distSimulation = simulateDistillationProcess(
    distProfile,
    design.fermentationProfile.estimatedWashABVPct || 8.4,
    3.8, // wash esters
    18,  // wash sulphur
    design.kilningSchedule.targetPhenolsPPM || 0
  );

  const {
    foreshotsVolumeL,
    headsVolumeL,
    heartVolumeL,
    tailsVolumeL,
    newMakeABVPct,
    totalYieldLPA,
    copperInteractionScore,
    predictedNewMakeSensory,
  } = distSimulation;

  const handleSpiritStillGeometryChange = (field: keyof StillGeometry, value: any) => {
    setDistProfile(prev => ({
      ...prev,
      spiritStillGeometry: {
        ...prev.spiritStillGeometry,
        [field]: value,
      },
    }));
  };

  const handleSave = () => {
    onUpdateDesign({
      ...design,
      distillationProfile: {
        ...distProfile,
        newMakeSpiritStrengthABVPct: newMakeABVPct,
        spiritYieldLPA: totalYieldLPA,
        newMakeYieldLitres: heartVolumeL,
        predictedNewMakeSensory,
      } as any,
      updatedAt: new Date().toISOString().split('T')[0],
    });
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#171513] border border-[#2E2822] p-5 rounded-lg">
        <div>
          <div className="text-xs font-mono text-[#C67D38] uppercase">STAGE 5 &bull; STILLHOUSE DISTILLATION & CUTS</div>
          <h2 className="font-editorial text-2xl font-bold text-[#F5F2EB]">
            Copper Pot Still Geometry, Reflux & Fraction Cut Engine
          </h2>
          <p className="text-xs text-[#8C8476] mt-0.5">
            Model copper contact catalytic de-sulphurisation, lyne arm reflux, and precise Heads/Heart/Tails cut points.
          </p>
        </div>

        <button
          onClick={handleSave}
          className="flex items-center gap-1.5 px-4 py-2 rounded bg-[#C67D38] hover:bg-[#DF9B56] text-[#12110F] font-semibold text-xs transition-all shadow-md"
        >
          {isSaved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
          <span>{isSaved ? 'Saved Specification' : 'Save Specification'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left (6 cols): Spirit Still Geometry & Copper Dynamics */}
        <div className="lg:col-span-6 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-5">
          <div className="flex items-center gap-2 border-b border-[#2A241E] pb-3">
            <Flame className="w-5 h-5 text-[#C67D38]" />
            <div>
              <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                Spirit Still Geometry & Condenser Configuration
              </h3>
              <p className="text-xs text-[#8C8476]">
                Configure physical still dimensions and copper reflux surface
              </p>
            </div>
          </div>

          <div className="space-y-4 text-xs font-mono">
            <div>
              <label className="block text-[#8C8476] mb-1">STILL NECK SHAPE</label>
              <select
                value={distProfile.spiritStillGeometry.neckShape}
                onChange={(e) => handleSpiritStillGeometryChange('neckShape', e.target.value)}
                className="w-full bg-[#12110F] text-[#FAF7F0] px-3 py-2 rounded border border-[#332A22] focus:outline-none focus:border-[#C67D38]"
              >
                <option value="Lantern">Lantern Shape (Moderate Reflux)</option>
                <option value="Boil Ball (Milton)">Boil Ball / Milton (High Internal Reflux)</option>
                <option value="Straight Conical">Straight Conical (Low Reflux, Heavy Spirit)</option>
                <option value="Lamp Glass">Lamp Glass (High Reflux, Floral)</option>
              </select>
            </div>

            <div>
              <label className="block text-[#8C8476] mb-1">CONDENSER SYSTEM</label>
              <select
                value={distProfile.spiritStillGeometry.condenserType}
                onChange={(e) => handleSpiritStillGeometryChange('condenserType', e.target.value)}
                className="w-full bg-[#12110F] text-[#FAF7F0] px-3 py-2 rounded border border-[#332A22] focus:outline-none focus:border-[#C67D38]"
              >
                <option value="Shell & Tube (High Copper)">Shell & Tube (High Copper Surface, Clean/Light)</option>
                <option value="Traditional Worm Tub (Low Copper/Meaty)">Traditional Worm Tub (Low Copper, Meaty/Sulphury)</option>
              </select>
            </div>

            {/* Lyne Arm Angle Slider (-15 deg to +15 deg) */}
            <div className="bg-[#12110F] p-4 rounded border border-[#2E2822] space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-[#C5BDB2]">LYNE ARM INCLINATION:</span>
                <span className="text-sm font-bold text-[#E5A93C]">
                  {distProfile.spiritStillGeometry.lyneArmAngleDegrees > 0 ? `+${distProfile.spiritStillGeometry.lyneArmAngleDegrees}` : distProfile.spiritStillGeometry.lyneArmAngleDegrees}&deg; ({distProfile.spiritStillGeometry.lyneArmAngleDegrees > 0 ? 'Ascending / Light' : distProfile.spiritStillGeometry.lyneArmAngleDegrees < 0 ? 'Descending / Heavy' : 'Horizontal'})
                </span>
              </div>
              <input
                type="range" min="-15" max="15" step="1"
                value={distProfile.spiritStillGeometry.lyneArmAngleDegrees}
                onChange={(e) => handleSpiritStillGeometryChange('lyneArmAngleDegrees', parseInt(e.target.value))}
                className="w-full accent-[#C67D38] bg-[#2A241E] h-1.5 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[#7A7062]">
                <span>-15&deg; (Downward heavy)</span>
                <span>0&deg;</span>
                <span>+15&deg; (Ascending ester purge)</span>
              </div>
            </div>

            {/* Copper Interaction Index Card */}
            <div className="bg-[#1F1912] p-4 rounded border border-[#443322] space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-[#E5A93C] font-bold">TOTAL COPPER CONTACT SCORE:</span>
                <span className="text-lg font-bold text-[#FAF7F0]">{copperInteractionScore} / 10.0</span>
              </div>
              <div className="text-[11px] text-[#C5BDB2] leading-relaxed">
                {copperInteractionScore > 7.5
                  ? 'High copper stripping efficiency. Removes heavy sulphur/cabbage precursors and purifies fresh orchard fruit & floral esters.'
                  : copperInteractionScore > 5.0
                  ? 'Balanced medium copper profile. Preserves malt cereal body and savoury character.'
                  : 'Low copper regime (meaty, heavy oils, sulphury savoury notes).'}
              </div>
            </div>

          </div>
        </div>

        {/* Right (6 cols): Fraction Cut Points Engine */}
        <div className="lg:col-span-6 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-5">
          <div className="flex items-center gap-2 border-b border-[#2A241E] pb-3">
            <Sliders className="w-5 h-5 text-[#E5A93C]" />
            <div>
              <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                Fraction Cut Points Engine (Foreshots / Heads / Heart / Tails)
              </h3>
              <p className="text-xs text-[#8C8476]">
                Adjust cut strengths to define the collection window for new-make spirit
              </p>
            </div>
          </div>

          <div className="space-y-4 text-xs font-mono">
            {/* Visual Cut Band Bar */}
            <div className="bg-[#12110F] p-4 rounded border border-[#2E2822] space-y-2">
              <div className="text-[11px] text-[#8C8476] uppercase">DISTILLATE FRACTION VOLUME DISTRIBUTION</div>
              
              <div className="w-full h-8 rounded flex overflow-hidden font-mono text-[10px] font-bold text-center select-none">
                <div style={{ width: '6%' }} className="bg-[#612A2A] text-[#FFA8A8] flex items-center justify-center" title={`Foreshots: ${foreshotsVolumeL}L`}>
                  FORE
                </div>
                <div style={{ width: '14%' }} className="bg-[#804E1E] text-[#FFD4A8] flex items-center justify-center" title={`Heads: ${headsVolumeL}L`}>
                  HEADS
                </div>
                <div style={{ width: '58%' }} className="bg-[#2E6B39] text-[#B0FFBD] flex items-center justify-center" title={`Heart Cut: ${heartVolumeL}L`}>
                  HEART ({heartVolumeL} L)
                </div>
                <div style={{ width: '22%' }} className="bg-[#3D3A36] text-[#C2BDB6] flex items-center justify-center" title={`Tails: ${tailsVolumeL}L`}>
                  TAILS
                </div>
              </div>

              <div className="flex justify-between text-[10px] text-[#7A7062] pt-1">
                <span>Start (~80% ABV)</span>
                <span className="text-[#E5A93C]">Cut 1: {distProfile.headsToHeartCutABVPct}%</span>
                <span className="text-[#52C47C]">Cut 2: {distProfile.heartToTailsCutABVPct}%</span>
                <span>End (~1% ABV)</span>
              </div>
            </div>

            {/* Cut Sliders */}
            <div className="bg-[#12110F] p-4 rounded border border-[#2E2822] space-y-3">
              <div>
                <div className="flex justify-between text-[#8C8476] mb-1">
                  <span>HEADS &rarr; HEART CUT POINT:</span>
                  <span className="text-[#E5A93C] font-bold">{distProfile.headsToHeartCutABVPct}% ABV</span>
                </div>
                <input
                  type="range" min="70.0" max="76.0" step="0.2"
                  value={distProfile.headsToHeartCutABVPct}
                  onChange={(e) => setDistProfile({ ...distProfile, headsToHeartCutABVPct: parseFloat(e.target.value) })}
                  className="w-full accent-[#E5A93C] bg-[#2A241E] h-1.5 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[#8C8476] mb-1">
                  <span>HEART &rarr; TAILS CUT POINT:</span>
                  <span className="text-[#52C47C] font-bold">{distProfile.heartToTailsCutABVPct}% ABV</span>
                </div>
                <input
                  type="range" min="58.0" max="66.0" step="0.2"
                  value={distProfile.heartToTailsCutABVPct}
                  onChange={(e) => setDistProfile({ ...distProfile, heartToTailsCutABVPct: parseFloat(e.target.value) })}
                  className="w-full accent-[#52C47C] bg-[#2A241E] h-1.5 rounded-lg cursor-pointer"
                />
                <div className="text-[10px] text-[#7A7062] mt-1">
                  {distProfile.heartToTailsCutABVPct < 62 ? 'Deep cut into tails (maximizes peat phenols & heavy grain oils)' : 'High cut (produces lighter, cleaner, ester-forward spirit)'}
                </div>
              </div>
            </div>

            {/* Real-time Distillation Output Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
              <div className="bg-[#12110F] p-3 rounded border border-[#2E2822]">
                <div className="text-[10px] text-[#8C8476]">NEW-MAKE ABV:</div>
                <div className="text-base font-bold text-[#E5A93C] mt-0.5">{newMakeABVPct}%</div>
              </div>
              <div className="bg-[#12110F] p-3 rounded border border-[#2E2822]">
                <div className="text-[10px] text-[#8C8476]">HEART YIELD:</div>
                <div className="text-base font-bold text-[#FAF7F0] mt-0.5">{heartVolumeL} L</div>
              </div>
              <div className="bg-[#12110F] p-3 rounded border border-[#2E2822]">
                <div className="text-[10px] text-[#8C8476]">TOTAL LPA:</div>
                <div className="text-base font-bold text-[#52C47C] mt-0.5">{totalYieldLPA} LPA</div>
              </div>
              <div className="bg-[#12110F] p-3 rounded border border-[#2E2822]">
                <div className="text-[10px] text-[#8C8476]">STILL RUN TIME:</div>
                <div className="text-base font-bold text-[#FAF7F0] mt-0.5">{distProfile.spiritStillRunHours} Hours</div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};
