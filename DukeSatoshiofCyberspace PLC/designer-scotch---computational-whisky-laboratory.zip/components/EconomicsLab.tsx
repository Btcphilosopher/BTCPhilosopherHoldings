'use client';

import React, { useState } from 'react';
import { WhiskyDesign } from '@/types/whisky';
import { calculateDistilleryBatchCost, calculateMaturationEconomics, buildProductValuation } from '@/lib/engines/economics';
import { calculateBlendProperties } from '@/lib/engines/blending';
import { TrendingUp, DollarSign, Package, ShieldCheck, Scale, Award } from 'lucide-react';

interface EconomicsLabProps {
  design: WhiskyDesign;
}

export const EconomicsLab: React.FC<EconomicsLabProps> = ({ design }) => {
  const [selectedAgeScenario, setSelectedAgeScenario] = useState<number>(design.targetProfile.targetAgeYears || 18);

  const primaryCask = design.caskProgramme[0] || design.activeBlend.components[0]?.caskSnapshot;
  const blend = calculateBlendProperties(design.activeBlend.components, design.targetProfile);

  // Batch cost calculations
  const batchCost = calculateDistilleryBatchCost(8.5, design.distillationProfile);
  const matEconomics = calculateMaturationEconomics(primaryCask, batchCost.costPerLPA_NewMakeGBP, selectedAgeScenario);
  const productValuation = buildProductValuation(design.targetProfile, blend, matEconomics.matureCostPerBottleLiquidGBP);

  // Age Economics Comparison table (8, 12, 15, 18, 21, 25 YO)
  const ageComparisonAges = [8, 12, 15, 18, 21, 25];
  const ageComparisons = ageComparisonAges.map(age => {
    const econ = calculateMaturationEconomics(primaryCask, batchCost.costPerLPA_NewMakeGBP, age);
    const val = buildProductValuation(design.targetProfile, { ...blend, calculatedAgeStatement: age }, econ.matureCostPerBottleLiquidGBP);
    return {
      age,
      matureCostPerLPA: econ.matureCostPerLPA_GBP,
      liquidCostPerBottle: econ.matureCostPerBottleLiquidGBP,
      totalMatureCost: econ.totalMatureBatchCostGBP,
      evaporatedLossGBP: econ.evaporatedLpaWriteOffGBP,
      rrp: val.recommendedRetailPriceGBP,
    };
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#171513] border border-[#2E2822] p-5 rounded-lg">
        <div>
          <div className="text-xs font-mono text-[#C67D38] uppercase">STAGE 13 &bull; DISTILLERY ECONOMICS & PREMIUMISATION</div>
          <h2 className="font-editorial text-2xl font-bold text-[#F5F2EB]">
            Cost Accounting, Maturation Carry & Product Valuation
          </h2>
          <p className="text-xs text-[#8C8476] mt-0.5">
            Transparent commercial modelling: raw materials, evaporation write-offs, financing carry, packaging, and margins.
          </p>
        </div>

        <div className="flex items-center gap-3 text-xs font-mono">
          <div className="bg-[#12110F] px-3 py-1.5 rounded border border-[#2E2822]">
            <span className="text-[#8C8476]">MODELLED RRP:</span>{' '}
            <span className="text-[#E5A93C] font-bold text-sm">£{productValuation.recommendedRetailPriceGBP}</span>
          </div>
          <div className="bg-[#12110F] px-3 py-1.5 rounded border border-[#2E2822]">
            <span className="text-[#8C8476]">STATUS:</span>{' '}
            <span className="text-[#52C47C] font-bold">{productValuation.economicViabilityStatus}</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (6 cols): Granular Batch Cost & Maturation Economics */}
        <div className="lg:col-span-6 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-5">
          <div className="border-b border-[#2A241E] pb-3">
            <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
              Distillation Batch Cost Structure (per 8.5t Grist Run)
            </h3>
            <p className="text-xs text-[#8C8476]">
              Direct production expenses from barley through copper spirit safe
            </p>
          </div>

          <div className="space-y-2 text-xs font-mono">
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex justify-between">
              <span className="text-[#C5BDB2]">Scottish Malting Barley (8.5t @ £310/t):</span>
              <span className="text-[#FAF7F0] font-bold">£{batchCost.rawMaterialBarleyGBP.toLocaleString()}</span>
            </div>
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex justify-between">
              <span className="text-[#C5BDB2]">Malting Energy & Kilning Power:</span>
              <span className="text-[#FAF7F0] font-bold">£{batchCost.maltingEnergyGBP.toLocaleString()}</span>
            </div>
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex justify-between">
              <span className="text-[#C5BDB2]">Brewing Water & Mash Pumping:</span>
              <span className="text-[#FAF7F0] font-bold">£{batchCost.brewingWaterPumpingGBP.toLocaleString()}</span>
            </div>
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex justify-between">
              <span className="text-[#C5BDB2]">Yeast Culture Inoculation:</span>
              <span className="text-[#FAF7F0] font-bold">£{batchCost.yeastCultureGBP.toLocaleString()}</span>
            </div>
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex justify-between">
              <span className="text-[#C5BDB2]">Stillhouse Steam & Electrical Thermal Run:</span>
              <span className="text-[#FAF7F0] font-bold">£{batchCost.distillationSteamPowerGBP.toLocaleString()}</span>
            </div>
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex justify-between">
              <span className="text-[#C5BDB2]">Direct Distiller Labour:</span>
              <span className="text-[#FAF7F0] font-bold">£{batchCost.directLabourGBP.toLocaleString()}</span>
            </div>
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex justify-between">
              <span className="text-[#C5BDB2]">Copper Pot Still Wear Amortisation:</span>
              <span className="text-[#FAF7F0] font-bold">£{batchCost.copperAmortisationGBP.toLocaleString()}</span>
            </div>

            <div className="bg-[#1F1812] p-3.5 rounded border border-[#443220] flex justify-between items-center pt-2">
              <span className="text-[#E5A93C] font-bold">TOTAL NEW-MAKE BATCH COST:</span>
              <span className="text-base font-bold text-[#FAF7F0]">
                £{batchCost.totalNewMakeBatchCostGBP.toLocaleString()} (£{batchCost.costPerLPA_NewMakeGBP}/LPA)
              </span>
            </div>
          </div>

          {/* Maturation Carry Breakdown */}
          <div className="bg-[#12110F] p-4 rounded border border-[#2E2822] space-y-2 text-xs font-mono">
            <div className="text-[#C67D38] font-bold uppercase text-[11px] flex justify-between">
              <span>MATURATION CARRY COST ({selectedAgeScenario} YEARS)</span>
              <span>£{matEconomics.matureCostPerLPA_GBP} / Mature LPA</span>
            </div>

            <div className="space-y-1.5 pt-1 text-[#A89E90]">
              <div className="flex justify-between">
                <span>Initial Spirit Allocation:</span>
                <span className="text-[#FAF7F0]">£{matEconomics.initialSpiritCostGBP}</span>
              </div>
              <div className="flex justify-between">
                <span>Cask Purchase & Cooperage:</span>
                <span className="text-[#FAF7F0]">£{matEconomics.caskAcquisitionCostGBP}</span>
              </div>
              <div className="flex justify-between">
                <span>Warehouse Storage ({selectedAgeScenario} yrs @ £42/yr):</span>
                <span className="text-[#FAF7F0]">£{matEconomics.totalStorageAccumulatedGBP}</span>
              </div>
              <div className="flex justify-between">
                <span>Angel’s Share Evaporation Loss Write-off:</span>
                <span className="text-[#E57373]">£{matEconomics.evaporatedLpaWriteOffGBP}</span>
              </div>
              <div className="flex justify-between">
                <span>Capital Financing Cost (4.5% p.a. Inventory Hold):</span>
                <span className="text-[#FAF7F0]">£{matEconomics.capitalFinancingCostGBP}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (6 cols): Product Packaging, Duty & RRP Price Architecture */}
        <div className="lg:col-span-6 space-y-6">
          
          {/* Price Architecture Breakdown */}
          <div className="bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-4">
            <div className="border-b border-[#2A241E] pb-3">
              <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                Commercial Product Value & Tier Pricing Architecture
              </h3>
              <p className="text-xs text-[#8C8476]">
                Transparent waterfall from mature liquid to recommended retail price (RRP)
              </p>
            </div>

            <div className="space-y-2 text-xs font-mono">
              <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex justify-between">
                <span className="text-[#C5BDB2]">Mature Whisky Liquid ({selectedAgeScenario} YO):</span>
                <span className="text-[#FAF7F0] font-bold">£{productValuation.liquidCostGBP.toFixed(2)}</span>
              </div>
              <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex justify-between">
                <span className="text-[#C5BDB2]">Heavy Bespoke Flint Glassware (700ml):</span>
                <span className="text-[#FAF7F0] font-bold">£{productValuation.bespokeBottleGlasswareGBP.toFixed(2)}</span>
              </div>
              <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex justify-between">
                <span className="text-[#C5BDB2]">Natural Micro-Agglomerated Cork & Tin Foil:</span>
                <span className="text-[#FAF7F0] font-bold">£{productValuation.corkAndTinCapsuleGBP.toFixed(2)}</span>
              </div>
              <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex justify-between">
                <span className="text-[#C5BDB2]">Debossed Presentation Box & Story Booklet:</span>
                <span className="text-[#FAF7F0] font-bold">£{productValuation.debossedPresentationBoxGBP.toFixed(2)}</span>
              </div>
              <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex justify-between">
                <span className="text-[#C5BDB2]">UK Spirits Duty & Excise ({blend.calculatedABV}% ABV):</span>
                <span className="text-[#FAF7F0] font-bold">£{productValuation.dutyAndExciseGBP.toFixed(2)}</span>
              </div>
              <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex justify-between">
                <span className="text-[#52C47C] font-semibold">Distillery Gross Margin:</span>
                <span className="text-[#52C47C] font-bold">£{productValuation.distilleryMarginGBP.toFixed(2)}</span>
              </div>
              <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex justify-between">
                <span className="text-[#C5BDB2]">Wholesale Distributor Margin (22%):</span>
                <span className="text-[#FAF7F0] font-bold">£{productValuation.distributorMarginGBP.toFixed(2)}</span>
              </div>
              <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex justify-between">
                <span className="text-[#C5BDB2]">Retailer Margin (35%):</span>
                <span className="text-[#FAF7F0] font-bold">£{productValuation.retailerMarginGBP.toFixed(2)}</span>
              </div>

              <div className="bg-[#241A10] p-4 rounded border border-[#523A1E] flex justify-between items-center text-sm font-mono mt-3">
                <span className="text-[#F5C782] font-bold">RECOMMENDED RETAIL PRICE (RRP):</span>
                <span className="text-xl font-bold text-[#FAF7F0]">
                  £{productValuation.recommendedRetailPriceGBP}
                  <span className="text-xs text-[#8C8476] ml-1.5 font-normal">(Incl. 20% VAT)</span>
                </span>
              </div>
            </div>
          </div>

          {/* Age Statement Scenario Comparison */}
          <div className="bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-3">
            <h4 className="font-editorial text-base font-bold text-[#F5F2EB] border-b border-[#2A241E] pb-2">
              Age Statement Financial Implications (8y &ndash; 25y)
            </h4>

            <div className="overflow-x-auto">
              <table className="w-full text-xs font-mono text-left">
                <thead>
                  <tr className="border-b border-[#26211C] text-[#8C8476]">
                    <th className="py-2">AGE</th>
                    <th className="py-2">COST / LPA</th>
                    <th className="py-2">LIQUID / BTL</th>
                    <th className="py-2">EVAP. LOSS</th>
                    <th className="py-2 text-right">MODELLED RRP</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1F1C18]">
                  {ageComparisons.map(item => (
                    <tr
                      key={item.age}
                      onClick={() => setSelectedAgeScenario(item.age)}
                      className={`cursor-pointer transition-colors ${
                        selectedAgeScenario === item.age ? 'bg-[#2A2016] text-[#FAF7F0]' : 'hover:bg-[#141210] text-[#A69E91]'
                      }`}
                    >
                      <td className="py-2 font-bold">{item.age} YO</td>
                      <td className="py-2">£{item.matureCostPerLPA.toFixed(2)}</td>
                      <td className="py-2">£{item.liquidCostPerBottle.toFixed(2)}</td>
                      <td className="py-2 text-[#E57373]">£{item.evaporatedLossGBP}</td>
                      <td className="py-2 text-right font-bold text-[#E5A93C]">£{item.rrp}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
