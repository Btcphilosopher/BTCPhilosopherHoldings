'use client';

import React, { useState } from 'react';
import { WhiskyDesign, BlendComponent, CaskEntity } from '@/types/whisky';
import { SYNTHETIC_CASKS } from '@/lib/data/synthetic-db';
import { calculateBlendProperties, optimizeBlendWeights } from '@/lib/engines/blending';
import { SensoryRadar } from './SensoryRadar';
import { FlaskConical, Sparkles, RefreshCw, Save, Check, Plus, Trash2, ArrowRight } from 'lucide-react';

interface BlendingLabProps {
  design: WhiskyDesign;
  onUpdateDesign: (updated: WhiskyDesign) => void;
}

export const BlendingLab: React.FC<BlendingLabProps> = ({
  design,
  onUpdateDesign,
}) => {
  const [components, setComponents] = useState<BlendComponent[]>(design.activeBlend.components);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [optResult, setOptResult] = useState<any | null>(null);
  const [isSaved, setIsSaved] = useState(false);

  // Recalculate blend metrics in real time
  const calculatedBlend = calculateBlendProperties(components, design.targetProfile);

  const handlePercentageChange = (caskId: string, newPct: number) => {
    setComponents(prev => {
      return prev.map(c => c.caskId === caskId ? { ...c, percentage: newPct } : c);
    });
    setIsSaved(false);
  };

  const handleRemoveCask = (caskId: string) => {
    setComponents(prev => prev.filter(c => c.caskId !== caskId));
    setIsSaved(false);
  };

  const handleAddCask = (cask: CaskEntity) => {
    if (components.some(c => c.caskId === cask.id)) return;
    setComponents(prev => [
      ...prev,
      { caskId: cask.id, percentage: 10, caskSnapshot: cask },
    ]);
    setIsSaved(false);
  };

  const handleRunOptimizer = () => {
    setIsOptimizing(true);
    setTimeout(() => {
      const result = optimizeBlendWeights(SYNTHETIC_CASKS.slice(0, 6), design.targetProfile, 350);
      setOptResult(result);
      setComponents(result.optimalWeights.map(w => ({
        caskId: w.caskId,
        percentage: w.percentage,
        caskSnapshot: w.cask,
      })));
      setIsOptimizing(false);
      setIsSaved(false);
    }, 500);
  };

  const handleSave = () => {
    onUpdateDesign({
      ...design,
      activeBlend: calculatedBlend,
      updatedAt: new Date().toISOString().split('T')[0],
    });
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#171513] border border-[#2E2822] p-5 rounded-lg">
        <div>
          <div className="text-xs font-mono text-[#C67D38] uppercase">STAGE 10 &bull; BLENDING LABORATORY & OPTIMISATION</div>
          <h2 className="font-editorial text-2xl font-bold text-[#F5F2EB]">
            Multi-Cask Vatting, Interactive Weights & RhinoQuant Solver
          </h2>
          <p className="text-xs text-[#8C8476] mt-0.5">
            Construct complex cask marriages with real-time sensory distance recalculation and quadratic optimization.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleRunOptimizer}
            disabled={isOptimizing}
            className="flex items-center gap-1.5 px-4 py-2 rounded bg-[#2A2114] hover:bg-[#3D2F1D] text-[#E5A93C] border border-[#6B4B27] font-semibold text-xs transition-all shadow-sm"
          >
            {isOptimizing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            <span>{isOptimizing ? 'Optimising Constrained Solver...' : 'RhinoQuant Auto-Optimise Blend'}</span>
          </button>

          <button
            onClick={handleSave}
            className="flex items-center gap-1.5 px-4 py-2 rounded bg-[#C67D38] hover:bg-[#DF9B56] text-[#12110F] font-semibold text-xs transition-all shadow-md"
          >
            {isSaved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
            <span>{isSaved ? 'Saved Blend Recipe' : 'Save Blend Recipe'}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left (7 cols): Interactive Cask Sliders & Vatting Weights */}
        <div className="lg:col-span-7 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-5">
          <div className="flex items-center justify-between border-b border-[#2A241E] pb-3">
            <div>
              <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                Cask Allocation & Fractional Weights
              </h3>
              <p className="text-xs text-[#8C8476]">
                Adjust percentages to marry spirit components
              </p>
            </div>
            <div className="text-right text-xs font-mono">
              <span className="text-[#8C8476]">Target Distance:</span>{' '}
              <span className="text-[#52C47C] font-bold text-sm">{calculatedBlend.sensoryDistanceToTarget.toFixed(3)}</span>
            </div>
          </div>

          {/* Active Casks List with Sliders */}
          <div className="space-y-3">
            {components.map((comp) => {
              const cask = comp.caskSnapshot;
              return (
                <div key={comp.caskId} className="bg-[#12110F] p-4 rounded border border-[#26211C] space-y-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sm font-bold text-[#FAF7F0]">{cask.caskNumber}</span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#2A2016] text-[#E5A93C] border border-[#483726]">
                          {cask.ageYears} YO &bull; {cask.seasoning}
                        </span>
                      </div>
                      <div className="text-[11px] text-[#8C8476] mt-0.5 font-mono">
                        {cask.woodSpecies.split('(')[0]} &bull; {cask.currentVolumeLitres} L @ {cask.currentABVPct}% ABV
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="font-mono font-bold text-lg text-[#E5A93C]">
                        {comp.percentage}%
                      </div>
                      <button
                        onClick={() => handleRemoveCask(comp.caskId)}
                        className="text-[#8C8476] hover:text-[#E57373] transition-colors p-1"
                        title="Remove cask from blend"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Percentage Slider */}
                  <input
                    type="range"
                    min="0"
                    max="100"
                    step="1"
                    value={comp.percentage}
                    onChange={(e) => handlePercentageChange(comp.caskId, parseInt(e.target.value))}
                    className="w-full accent-[#C67D38] bg-[#2A241E] h-2 rounded-lg cursor-pointer"
                  />
                </div>
              );
            })}
          </div>

          {/* Add Available Cask from Inventory Bar */}
          <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
            <span className="text-[#8C8476]">ADD CASK TO BLEND:</span>
            <div className="flex flex-wrap gap-1.5">
              {SYNTHETIC_CASKS.filter(c => !components.some(x => x.caskId === c.id)).slice(0, 4).map(c => (
                <button
                  key={c.id}
                  onClick={() => handleAddCask(c)}
                  className="px-2.5 py-1 rounded bg-[#1C1814] hover:bg-[#2B231A] text-[#C5BDB2] hover:text-[#FAF7F0] border border-[#3E2F20] transition-colors flex items-center gap-1"
                >
                  <Plus className="w-3 h-3" />
                  <span>{c.caskNumber.split('-').pop()} ({c.seasoning.split(' ')[0]})</span>
                </button>
              ))}
            </div>
          </div>

          {/* Blend Metrics Card */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs font-mono">
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C]">
              <div className="text-[10px] text-[#8C8476]">VATTED STRENGTH:</div>
              <div className="text-base font-bold text-[#E5A93C] mt-0.5">{calculatedBlend.calculatedABV}% ABV</div>
            </div>
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C]">
              <div className="text-[10px] text-[#8C8476]">YOUNGEST CASK AGE:</div>
              <div className="text-base font-bold text-[#FAF7F0] mt-0.5">{calculatedBlend.calculatedAgeStatement} YO</div>
            </div>
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C]">
              <div className="text-[10px] text-[#8C8476]">700ML BOTTLES YIELD:</div>
              <div className="text-base font-bold text-[#52C47C] mt-0.5">{calculatedBlend.bottlesYield700ml.toLocaleString()}</div>
            </div>
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C]">
              <div className="text-[10px] text-[#8C8476]">LIQUID COST / BTL:</div>
              <div className="text-base font-bold text-[#FAF7F0] mt-0.5">£{calculatedBlend.costPerBottleGBP.toFixed(2)}</div>
            </div>
          </div>
        </div>

        {/* Right (5 cols): Sensory Radar & Optimisation Convergence */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Radar Preview */}
          <div className="bg-[#171513] border border-[#2E2822] rounded-lg p-5 flex flex-col items-center">
            <h4 className="font-editorial text-base font-bold text-[#F5F2EB] mb-2 self-start">
              Blended Sensory Output vs Target
            </h4>
            <SensoryRadar
              target={design.targetProfile.sensory}
              predicted={calculatedBlend.sensoryProfile}
              size={300}
            />
          </div>

          {/* RhinoQuant Solver Result Details */}
          {optResult && (
            <div className="bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-3">
              <div className="flex items-center gap-2 border-b border-[#2A241E] pb-2">
                <Sparkles className="w-4 h-4 text-[#52C47C]" />
                <h4 className="font-editorial text-base font-bold text-[#F5F2EB]">
                  RhinoQuant Solver Convergence
                </h4>
              </div>

              <div className="space-y-2 text-xs font-mono">
                <div className="flex justify-between text-[#8C8476]">
                  <span>Initial Distance:</span>
                  <span className="text-[#E57373] font-bold">{optResult.initialDistance.toFixed(3)}</span>
                </div>
                <div className="flex justify-between text-[#8C8476]">
                  <span>Optimized Minimal Distance:</span>
                  <span className="text-[#52C47C] font-bold">{optResult.optimizedDistance.toFixed(3)}</span>
                </div>
                <div className="flex justify-between text-[#8C8476]">
                  <span>Iterations / Epochs:</span>
                  <span className="text-[#FAF7F0]">350 gradient steps</span>
                </div>
              </div>

              <div className="text-[11px] text-[#A69E91] leading-relaxed pt-1 border-t border-[#26211C]">
                &ldquo;Under the specified target function and constraints, this design produces the smallest predicted distance from the target sensory profile.&rdquo;
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
