'use client';

import React, { useState } from 'react';
import { WhiskyDesign } from '@/types/whisky';
import { Database, Upload, Download, CheckCircle2, AlertCircle, FileText, Code } from 'lucide-react';

interface DataImportExportProps {
  design: WhiskyDesign;
  onImportDesign: (imported: WhiskyDesign) => void;
}

export const DataImportExport: React.FC<DataImportExportProps> = ({
  design,
  onImportDesign,
}) => {
  const [jsonInput, setJsonInput] = useState<string>('');
  const [importStatus, setImportStatus] = useState<{ success: boolean; message: string } | null>(null);

  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(design, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${design.code}_DESIGN_DOSSIER.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportJSON = () => {
    try {
      if (!jsonInput.trim()) {
        setImportStatus({ success: false, message: 'JSON input cannot be empty.' });
        return;
      }

      const parsed = JSON.parse(jsonInput);

      // Validate required core schema
      if (!parsed.id || !parsed.targetProfile || !parsed.distillationProfile || !parsed.activeBlend) {
        setImportStatus({
          success: false,
          message: 'Schema Validation Error: Missing critical top-level structures (targetProfile, distillationProfile, or activeBlend).',
        });
        return;
      }

      if (!parsed.targetProfile.sensory || typeof parsed.targetProfile.sensory.fruit !== 'number') {
        setImportStatus({
          success: false,
          message: 'Schema Validation Error: Malformed sensory profile numerical vector.',
        });
        return;
      }

      onImportDesign(parsed);
      setImportStatus({
        success: true,
        message: `Successfully validated and imported recipe "${parsed.name}" (${parsed.code}).`,
      });
    } catch (err: any) {
      setImportStatus({
        success: false,
        message: `JSON Syntax Parse Error: ${err.message || 'Invalid format.'}`,
      });
    }
  };

  const loadSampleJSON = () => {
    setJsonInput(JSON.stringify(design, null, 2));
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#171513] border border-[#2E2822] p-5 rounded-lg">
        <div>
          <div className="text-xs font-mono text-[#C67D38] uppercase">DATA MANAGEMENT & INTEROPERABILITY</div>
          <h2 className="font-editorial text-2xl font-bold text-[#F5F2EB]">
            Laboratory Data Import / Export & Schema Validation
          </h2>
          <p className="text-xs text-[#8C8476] mt-0.5">
            Interchange design dossiers, chromatography datasets, and panel calibration records via strict schema mapping.
          </p>
        </div>

        <button
          onClick={handleExportJSON}
          className="flex items-center gap-1.5 px-4 py-2 rounded bg-[#C67D38] hover:bg-[#DF9B56] text-[#12110F] font-semibold text-xs transition-all shadow-md"
        >
          <Download className="w-4 h-4" />
          <span>Export Production Dossier (JSON)</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left (6 cols): Import JSON Schema Validator */}
        <div className="lg:col-span-6 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-[#2A241E] pb-3">
            <div>
              <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
                Import Production Specification (JSON)
              </h3>
              <p className="text-xs text-[#8C8476]">
                Validates strict physical mass balance and sensory schema
              </p>
            </div>
            <button
              onClick={loadSampleJSON}
              className="text-xs font-mono text-[#C67D38] hover:text-[#E5A93C]"
            >
              Load Current Design JSON
            </button>
          </div>

          <textarea
            rows={14}
            value={jsonInput}
            onChange={(e) => setJsonInput(e.target.value)}
            placeholder="Paste raw JSON production specification or laboratory dataset here..."
            className="w-full bg-[#12110F] text-[#FAF7F0] p-3 rounded border border-[#332A22] font-mono text-xs focus:outline-none focus:border-[#C67D38]"
          />

          {importStatus && (
            <div className={`p-3 rounded border text-xs font-mono flex items-start gap-2 ${
              importStatus.success
                ? 'bg-[#132A1B] border-[#214D2E] text-[#52C47C]'
                : 'bg-[#2E1818] border-[#5E2626] text-[#E57373]'
            }`}>
              {importStatus.success ? <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" /> : <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />}
              <span>{importStatus.message}</span>
            </div>
          )}

          <button
            onClick={handleImportJSON}
            className="w-full py-2.5 rounded bg-[#2A2114] hover:bg-[#3D2F1D] text-[#E5A93C] border border-[#6B4B27] font-semibold text-xs font-mono transition-colors flex items-center justify-center gap-2"
          >
            <Upload className="w-4 h-4" /> Validate & Import Specification
          </button>
        </div>

        {/* Right (6 cols): Active Specification Snapshot */}
        <div className="lg:col-span-6 bg-[#171513] border border-[#2E2822] rounded-lg p-5 space-y-4">
          <div className="border-b border-[#2A241E] pb-3">
            <h3 className="font-editorial text-lg font-bold text-[#F5F2EB]">
              Active Specification Overview ({design.code})
            </h3>
            <p className="text-xs text-[#8C8476]">
              Summary of active computational graph objects
            </p>
          </div>

          <div className="space-y-2 text-xs font-mono">
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex justify-between">
              <span className="text-[#8C8476]">TARGET PROFILE:</span>
              <span className="text-[#FAF7F0] font-bold">{design.targetProfile.name} ({design.targetProfile.region})</span>
            </div>
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex justify-between">
              <span className="text-[#8C8476]">BARLEY VARIETAL:</span>
              <span className="text-[#FAF7F0] font-bold">{design.barleyProfile.variety}</span>
            </div>
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex justify-between">
              <span className="text-[#8C8476]">YEAST STRAIN:</span>
              <span className="text-[#FAF7F0] font-bold">{design.yeastProfile.name}</span>
            </div>
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex justify-between">
              <span className="text-[#8C8476]">WATER SOURCE:</span>
              <span className="text-[#FAF7F0] font-bold">{design.waterChemistry.name}</span>
            </div>
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex justify-between">
              <span className="text-[#8C8476]">DISTILLATION CUTS:</span>
              <span className="text-[#FAF7F0] font-bold">{design.distillationProfile.headsToHeartCutABVPct}% &rarr; {design.distillationProfile.heartToTailsCutABVPct}% ABV</span>
            </div>
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex justify-between">
              <span className="text-[#8C8476]">ACTIVE CASKS MARRIED:</span>
              <span className="text-[#E5A93C] font-bold">{design.activeBlend.components.length} Casks</span>
            </div>
            <div className="bg-[#12110F] p-3 rounded border border-[#26211C] flex justify-between">
              <span className="text-[#8C8476]">SENSORY DISTANCE:</span>
              <span className="text-[#52C47C] font-bold">{design.activeBlend.sensoryDistanceToTarget.toFixed(3)}</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
