import { TargetWhiskyProfile, DistillationProfile, CaskEntity, BlendDesign } from '@/types/whisky';

export interface DistilleryCostBreakdown {
  rawMaterialBarleyGBP: number;     // £/batch
  maltingEnergyGBP: number;
  brewingWaterPumpingGBP: number;
  yeastCultureGBP: number;
  distillationSteamPowerGBP: number;
  directLabourGBP: number;
  copperAmortisationGBP: number;
  totalNewMakeBatchCostGBP: number;
  costPerLPA_NewMakeGBP: number;    // £ / Litre of Pure Alcohol
}

export interface MaturationFinancialEconomics {
  initialSpiritCostGBP: number;
  caskAcquisitionCostGBP: number;
  warehouseStoragePerYearGBP: number;
  totalStorageAccumulatedGBP: number;
  evaporatedLpaWriteOffGBP: number;
  capitalFinancingCostGBP: number;  // 4.5% cost of capital on inventory
  totalMatureBatchCostGBP: number;
  matureCostPerLPA_GBP: number;
  matureCostPerBottleLiquidGBP: number;
}

export interface ProductValuationModel {
  liquidCostGBP: number;
  bespokeBottleGlasswareGBP: number;
  corkAndTinCapsuleGBP: number;
  debossedPresentationBoxGBP: number;
  dutyAndExciseGBP: number;         // UK Duty: ~£31.64 per LPA (~£8.86/bottle @ 40%, ~£12.50 @ 56%)
  distilleryMarginGBP: number;
  distributorMarginGBP: number;
  retailerMarginGBP: number;
  recommendedRetailPriceGBP: number;
  scarcityMultiplier: number;
  distinctivenessIndex: number;
  economicViabilityStatus: 'High Margin Prestige' | 'Balanced Commercial' | 'Margin Squeeze / Rebalance Required';
}

export function calculateDistilleryBatchCost(
  barleyTonnes: number = 8.5,
  distProfile: DistillationProfile
): DistilleryCostBreakdown {
  const barleyCostPerTonne = 310; // £310/t Scottish malting barley
  const rawMaterialBarleyGBP = Math.round(barleyTonnes * barleyCostPerTonne);
  const maltingEnergyGBP = Math.round(barleyTonnes * 68);
  const brewingWaterPumpingGBP = 450;
  const yeastCultureGBP = 380;
  const distillationSteamPowerGBP = Math.round(distProfile.spiritStillRunHours * 180 + distProfile.washStillRunHours * 160);
  const directLabourGBP = 1450;
  const copperAmortisationGBP = 280;

  const totalNewMakeBatchCostGBP = 
    rawMaterialBarleyGBP +
    maltingEnergyGBP +
    brewingWaterPumpingGBP +
    yeastCultureGBP +
    distillationSteamPowerGBP +
    directLabourGBP +
    copperAmortisationGBP;

  const lpa = distProfile.spiritYieldLPA || 2450;
  const costPerLPA_NewMakeGBP = Math.round((totalNewMakeBatchCostGBP / lpa) * 100) / 100;

  return {
    rawMaterialBarleyGBP,
    maltingEnergyGBP,
    brewingWaterPumpingGBP,
    yeastCultureGBP,
    distillationSteamPowerGBP,
    directLabourGBP,
    copperAmortisationGBP,
    totalNewMakeBatchCostGBP,
    costPerLPA_NewMakeGBP,
  };
}

export function calculateMaturationEconomics(
  cask: CaskEntity,
  costPerLPA_NewMake: number = 2.85,
  yearsMaturing: number = 18
): MaturationFinancialEconomics {
  const initialLPA = cask.capacityLitres * (cask.fillStrengthABVPct / 100);
  const initialSpiritCostGBP = Math.round(initialLPA * costPerLPA_NewMake);
  
  // Cask purchase cost based on type
  let caskAcquisitionCostGBP = 450; // ex-bourbon barrel
  if (cask.seasoning.includes('Sherry') || cask.seasoning.includes('Pedro')) caskAcquisitionCostGBP = 1450;
  if (cask.seasoning.includes('Port')) caskAcquisitionCostGBP = 1200;
  if (cask.seasoning === 'Virgin Oak') caskAcquisitionCostGBP = 750;

  const warehouseStoragePerYearGBP = 42; // £42/year per cask dunnage space, insurance, maintenance
  const totalStorageAccumulatedGBP = warehouseStoragePerYearGBP * yearsMaturing;

  // Evaporative loss calculation
  const remainingVol = cask.capacityLitres * Math.pow(0.98, yearsMaturing);
  const remainingABV = Math.max(40, cask.fillStrengthABVPct - (0.35 * yearsMaturing));
  const remainingLPA = remainingVol * (remainingABV / 100);
  const lpaLost = Math.max(0, initialLPA - remainingLPA);
  const evaporatedLpaWriteOffGBP = Math.round(lpaLost * costPerLPA_NewMake * 1.8); // Opportunity cost write-off

  // Cost of capital tied up in inventory (4.5% p.a.)
  const capitalFinancingCostGBP = Math.round((initialSpiritCostGBP + caskAcquisitionCostGBP) * (Math.pow(1.045, yearsMaturing) - 1.0));

  const totalMatureBatchCostGBP = 
    initialSpiritCostGBP +
    caskAcquisitionCostGBP +
    totalStorageAccumulatedGBP +
    evaporatedLpaWriteOffGBP +
    capitalFinancingCostGBP;

  const matureCostPerLPA_GBP = Math.round((totalMatureBatchCostGBP / Math.max(1, remainingLPA)) * 100) / 100;
  const bottlesYield = Math.floor((remainingVol / 0.7) * 0.98);
  const matureCostPerBottleLiquidGBP = bottlesYield > 0 ? Math.round((totalMatureBatchCostGBP / bottlesYield) * 100) / 100 : 85;

  return {
    initialSpiritCostGBP,
    caskAcquisitionCostGBP,
    warehouseStoragePerYearGBP,
    totalStorageAccumulatedGBP,
    evaporatedLpaWriteOffGBP,
    capitalFinancingCostGBP,
    totalMatureBatchCostGBP,
    matureCostPerLPA_GBP,
    matureCostPerBottleLiquidGBP,
  };
}

export function buildProductValuation(
  target: TargetWhiskyProfile,
  blend: BlendDesign,
  liquidCostPerBottle: number
): ProductValuationModel {
  const isUltra = target.positioning === 'Ultra-Premium' || target.positioning === 'Prestige Collector';
  
  const bespokeBottleGlasswareGBP = isUltra ? 22.0 : 8.5;
  const corkAndTinCapsuleGBP = isUltra ? 6.5 : 2.5;
  const debossedPresentationBoxGBP = isUltra ? 34.0 : 11.0;
  
  // UK / EU Spirits Duty calculation
  const bottleABV = blend.calculatedABV || target.targetABV || 46.0;
  const dutyRatePerLPA = 31.64; // UK excise
  const dutyAndExciseGBP = Math.round((0.7 * (bottleABV / 100) * dutyRatePerLPA + 0.75) * 100) / 100;

  const totalProductionCost = 
    liquidCostPerBottle +
    bespokeBottleGlasswareGBP +
    corkAndTinCapsuleGBP +
    debossedPresentationBoxGBP +
    dutyAndExciseGBP;

  // Scarcity & distinctiveness
  const ageBonus = Math.max(1.0, 1.0 + (blend.calculatedAgeStatement / 20.0) * 0.8);
  const bottleCountFactor = target.targetBottles < 600 ? 1.6 : target.targetBottles < 2000 ? 1.3 : 1.05;
  const scarcityMultiplier = Math.round(ageBonus * bottleCountFactor * 100) / 100;
  
  const distinctivenessIndex = Math.round((0.75 + (1.0 - (blend.sensoryDistanceToTarget || 0.1)) * 0.25) * 100) / 100;

  // Margins
  const distilleryMarginGBP = Math.round((totalProductionCost * (isUltra ? 1.8 : 0.95)) * 100) / 100;
  const exDistilleryPrice = totalProductionCost + distilleryMarginGBP;
  
  const distributorMarginGBP = Math.round((exDistilleryPrice * 0.22) * 100) / 100;
  const wholesalePrice = exDistilleryPrice + distributorMarginGBP;
  
  const retailerMarginGBP = Math.round((wholesalePrice * 0.35) * 100) / 100;
  const rrpBeforeVat = wholesalePrice + retailerMarginGBP;
  const recommendedRetailPriceGBP = Math.round((rrpBeforeVat * 1.20) / 5) * 5; // rounded with 20% VAT to nearest £5

  let economicViabilityStatus: ProductValuationModel['economicViabilityStatus'] = 'Balanced Commercial';
  if (recommendedRetailPriceGBP >= target.targetRetailPriceGBP * 0.85 && distilleryMarginGBP / totalProductionCost > 1.2) {
    economicViabilityStatus = 'High Margin Prestige';
  } else if (distilleryMarginGBP / totalProductionCost < 0.6) {
    economicViabilityStatus = 'Margin Squeeze / Rebalance Required';
  }

  return {
    liquidCostGBP: liquidCostPerBottle,
    bespokeBottleGlasswareGBP,
    corkAndTinCapsuleGBP,
    debossedPresentationBoxGBP,
    dutyAndExciseGBP,
    distilleryMarginGBP,
    distributorMarginGBP,
    retailerMarginGBP,
    recommendedRetailPriceGBP,
    scarcityMultiplier,
    distinctivenessIndex,
    economicViabilityStatus,
  };
}
