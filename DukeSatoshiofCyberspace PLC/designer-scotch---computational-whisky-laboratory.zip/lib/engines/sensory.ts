import { SensoryAxisProfile, SensoryPanelistScore } from '@/types/whisky';

export interface PCAProjectionPoint {
  id: string;
  name: string;
  category: 'Target' | 'Predicted Design' | 'Measured Panel' | 'Benchmark Malt' | 'Cask Component';
  pc1: number; // Wood Extraction / Maturity vs Green Cereal
  pc2: number; // Smoke / Phenolic vs Orchard Fruit / Esters
  sensory: Partial<SensoryAxisProfile>;
  confidenceBand?: number;
}

/**
 * Multivariate PCA projection onto two primary sensory components
 * PC1 = 0.35*Oak + 0.30*Vanilla + 0.28*Tannin + 0.25*Complexity - 0.32*Cereal - 0.28*Mineral
 * PC2 = 0.48*Smoke + 0.42*Medicinal + 0.25*Salt - 0.45*Fruit - 0.38*Floral
 */
export function projectSensoryToPCA(profile: SensoryAxisProfile, id: string, name: string, category: PCAProjectionPoint['category']): PCAProjectionPoint {
  const pc1 = 
    (profile.oak || 0) * 0.35 +
    (profile.vanilla || 0) * 0.30 +
    (profile.tannin || 0) * 0.28 +
    (profile.complexity || 0) * 0.25 +
    (profile.driedFruit || 0) * 0.22 -
    (profile.cereal || 0) * 0.32 -
    (profile.mineral || 0) * 0.20;

  const pc2 =
    (profile.smoke || 0) * 0.52 +
    (profile.medicinal || 0) * 0.45 +
    (profile.salt || 0) * 0.25 -
    (profile.fruit || 0) * 0.44 -
    (profile.floral || 0) * 0.36;

  return {
    id,
    name,
    category,
    pc1: Math.round(pc1 * 100) / 100,
    pc2: Math.round(pc2 * 100) / 100,
    sensory: profile,
  };
}

export interface SensoryDistanceBreakdown {
  axis: keyof SensoryAxisProfile;
  label: string;
  targetValue: number;
  predictedValue: number;
  measuredValue?: number;
  difference: number;
  status: 'In Range' | 'Slight Variance' | 'High Divergence';
}

export function computeSensoryDistanceBreakdown(
  target: SensoryAxisProfile,
  predicted: SensoryAxisProfile,
  measured?: SensoryAxisProfile
): {
  overallDistance: number;
  breakdown: SensoryDistanceBreakdown[];
  conformanceRatePct: number;
} {
  const axes: { key: keyof SensoryAxisProfile; label: string }[] = [
    { key: 'fruit', label: 'Orchard & Fresh Fruit' },
    { key: 'floral', label: 'Floral & Heather' },
    { key: 'malt', label: 'Malted Barley' },
    { key: 'cereal', label: 'Biscuity / Cereal' },
    { key: 'spice', label: 'Baking Spices' },
    { key: 'oak', label: 'Toasted Oak' },
    { key: 'vanilla', label: 'Bourbon Vanilla' },
    { key: 'caramel', label: 'Toffee / Caramel' },
    { key: 'nut', label: 'Hazelnut & Walnut' },
    { key: 'driedFruit', label: 'Raisin & Sultana' },
    { key: 'smoke', label: 'Peat Smoke' },
    { key: 'medicinal', label: 'Medicinal / Iodine' },
    { key: 'mineral', label: 'Flint & Mineral' },
    { key: 'salt', label: 'Coastal Brine' },
    { key: 'herbal', label: 'Pine & Fresh Herb' },
    { key: 'body', label: 'Palate Body' },
    { key: 'dryness', label: 'Mouthfeel Dryness' },
    { key: 'sweetness', label: 'Rich Sweetness' },
    { key: 'finish', label: 'Finish Length' },
    { key: 'complexity', label: 'Depth & Complexity' },
    { key: 'oiliness', label: 'Viscous Texture' },
    { key: 'tannin', label: 'Wood Tannin Grip' },
  ];

  let totalSqDiff = 0;
  let inRangeCount = 0;

  const breakdown: SensoryDistanceBreakdown[] = axes.map(({ key, label }) => {
    const tVal = target[key] || 0;
    const pVal = predicted[key] || 0;
    const mVal = measured ? (measured[key] || 0) : undefined;
    const diff = Math.abs(pVal - tVal);

    let status: SensoryDistanceBreakdown['status'] = 'In Range';
    if (diff > 0.22) {
      status = 'High Divergence';
    } else if (diff > 0.10) {
      status = 'Slight Variance';
    } else {
      inRangeCount++;
    }

    totalSqDiff += diff * diff;

    return {
      axis: key,
      label,
      targetValue: tVal,
      predictedValue: pVal,
      measuredValue: mVal,
      difference: Math.round(diff * 100) / 100,
      status,
    };
  });

  const overallDistance = Math.round(Math.sqrt(totalSqDiff / axes.length) * 1000) / 1000;
  const conformanceRatePct = Math.round((inRangeCount / axes.length) * 100);

  return {
    overallDistance,
    breakdown,
    conformanceRatePct,
  };
}

export function aggregatePanelScores(scores: SensoryPanelistScore[]): SensoryAxisProfile {
  if (!scores || scores.length === 0) {
    return {} as SensoryAxisProfile;
  }

  const result: Record<string, number> = {};
  const sampleKeys = Object.keys(scores[0].ratings) as (keyof SensoryAxisProfile)[];

  sampleKeys.forEach(k => {
    let weightedSum = 0;
    let totalWeight = 0;

    scores.forEach(panelist => {
      const conf = panelist.confidenceScore || 0.85;
      weightedSum += (panelist.ratings[k] || 0) * conf;
      totalWeight += conf;
    });

    result[k] = totalWeight > 0 ? Math.round((weightedSum / totalWeight) * 100) / 100 : 0;
  });

  return result as unknown as SensoryAxisProfile;
}
