import { CaskEntity, SensoryAxisProfile, WarehouseEnvironment } from '@/types/whisky';

export interface MaturationTrajectoryPoint {
  ageYears: number;
  sensory: SensoryAxisProfile;
  remainingVolumeLitres: number;
  estimatedABVPct: number;
  woodExtractPPM: number;       // Vanillin, coniferaldehyde, syringaldehyde
  lactonePPM: number;           // cis/trans oak lactones (coconut, woody)
  tanninIndex: number;          // Ellagitannins (astringency, structure)
  subtractiveLossSulphurPct: number; // Disappearance of young sulphur notes
  interactiveOxidationScore: number;
  uncertaintyMargin: number;    // e.g. ± 0.08
}

export interface MonteCarloTrajectory {
  simId: number;
  path: { age: number; score: number; abv: number; volume: number }[];
}

export interface MaturationSimulationResult {
  timeline: MaturationTrajectoryPoint[];
  finalProfile: SensoryAxisProfile;
  volumeLossTotalPct: number;
  lpaLossTotalPct: number;
  monteCarloSummary: {
    ages: number[];
    medianTrajectory: number[];
    p10LowerBand: number[];
    p90UpperBand: number[];
    sampleTrajectories: MonteCarloTrajectory[];
  };
}

export function simulateCaskMaturation(
  newMakeSensory: SensoryAxisProfile,
  cask: CaskEntity,
  warehouse: WarehouseEnvironment,
  targetAgeYears: number = 18
): MaturationSimulationResult {
  const isAmericanOak = cask.woodSpecies.includes('American');
  const isVirgin = cask.seasoning === 'Virgin Oak';
  const isSherry = cask.seasoning.includes('Sherry') || cask.seasoning.includes('Pedro');
  const isPort = cask.seasoning.includes('Port');
  const isBourbon = cask.seasoning.includes('Bourbon');

  // Wood extraction multipliers
  const vanillinFactor = (isAmericanOak ? 1.4 : 0.8) * (isVirgin ? 1.8 : isBourbon ? 1.2 : 0.7);
  const tanninFactor = (isAmericanOak ? 0.7 : 1.5) * (isVirgin ? 1.6 : isSherry ? 1.3 : 0.8);
  const driedFruitFactor = isSherry ? 1.9 : isPort ? 1.6 : 0.3;
  const spiceFactor = (isAmericanOak ? 0.9 : 1.4) * (cask.toastLevel === 'Heavy' ? 1.3 : 1.0);

  const keyYears = [0, 0.5, 1, 3, 5, 8, 10, 12, 15, 18, 21, 25, 30].filter(y => y <= Math.max(targetAgeYears + 2, 25));
  if (!keyYears.includes(targetAgeYears)) {
    keyYears.push(targetAgeYears);
    keyYears.sort((a, b) => a - b);
  }

  const timeline: MaturationTrajectoryPoint[] = [];

  let currentVol = cask.capacityLitres;
  let currentABV = cask.fillStrengthABVPct;

  const annualEvap = warehouse.annualEvaporationLossPct / 100;
  const annualAbvDrift = warehouse.annualAlcoholDriftABVPct;

  keyYears.forEach((year) => {
    // Volume loss compound
    const vol = cask.capacityLitres * Math.pow(1.0 - annualEvap, year);
    // ABV drift
    const abv = Math.max(40.0, cask.fillStrengthABVPct + (annualAbvDrift * year));

    // Dynamic asymptotic wood extraction curves: 1 - exp(-k * t)
    const kExt = 0.14;
    const woodSat = 1.0 - Math.exp(-kExt * year);
    const kOx = 0.08;
    const oxSat = 1.0 - Math.exp(-kOx * year);

    // Subtractive maturation: early aggressive disappearance of pungent green cereal & sulphur
    const youngSpiritLoss = Math.exp(-0.25 * year);

    // Reconstruct sensory dimensions at year t
    const vanilla = Math.min(0.98, (0.05 + woodSat * 0.72 * vanillinFactor));
    const oak = Math.min(0.98, (woodSat * 0.78 * (cask.charLevel.includes('Alligator') ? 1.15 : 0.95)));
    const fruit = Math.max(0.2, (newMakeSensory.fruit * (0.8 + 0.2 * oxSat) + driedFruitFactor * woodSat * 0.35));
    const driedFruit = Math.min(0.95, (0.02 + woodSat * 0.65 * driedFruitFactor));
    const spice = Math.min(0.95, (newMakeSensory.spice * 0.7 + woodSat * 0.55 * spiceFactor));
    const tannin = Math.min(0.92, (woodSat * 0.6 * tanninFactor));
    const cereal = Math.max(0.1, newMakeSensory.cereal * youngSpiritLoss);
    const floral = Math.max(0.1, newMakeSensory.floral * (1.0 - oxSat * 0.45));
    const smoke = Math.max(0.02, newMakeSensory.smoke * (1.0 - oxSat * 0.35)); // Peat mellows with age
    const medicinal = Math.max(0.01, newMakeSensory.medicinal * (1.0 - oxSat * 0.45));
    const body = Math.min(0.95, Math.max(0.4, newMakeSensory.body * 0.6 + woodSat * 0.35 + (isSherry ? 0.15 : 0)));
    const complexity = Math.min(0.98, (0.35 + (1.0 - Math.exp(-0.11 * year)) * 0.58));
    const finish = Math.min(0.98, (0.45 + (1.0 - Math.exp(-0.1 * year)) * 0.5));
    const sweetness = Math.min(0.92, (0.25 + woodSat * 0.45 * (isSherry || isBourbon ? 1.2 : 0.8)));
    const dryness = Math.min(0.9, (0.3 + tannin * 0.55));
    const caramel = Math.min(0.9, (woodSat * 0.65 * (cask.toastLevel === 'Heavy' ? 1.2 : 0.85)));
    const nut = Math.min(0.85, (0.1 + woodSat * 0.5 * (isSherry ? 1.3 : 0.7)));

    const sensoryPoint: SensoryAxisProfile = {
      fruit: Math.round(fruit * 100) / 100,
      floral: Math.round(floral * 100) / 100,
      malt: Math.round((newMakeSensory.malt * youngSpiritLoss + woodSat * 0.2) * 100) / 100,
      cereal: Math.round(cereal * 100) / 100,
      spice: Math.round(spice * 100) / 100,
      oak: Math.round(oak * 100) / 100,
      vanilla: Math.round(vanilla * 100) / 100,
      caramel: Math.round(caramel * 100) / 100,
      nut: Math.round(nut * 100) / 100,
      driedFruit: Math.round(driedFruit * 100) / 100,
      smoke: Math.round(smoke * 100) / 100,
      medicinal: Math.round(medicinal * 100) / 100,
      mineral: Math.round((newMakeSensory.mineral * 0.85) * 100) / 100,
      salt: Math.round((newMakeSensory.salt * 0.95) * 100) / 100,
      herbal: Math.round((newMakeSensory.herbal * (1.0 - oxSat * 0.3)) * 100) / 100,
      body: Math.round(body * 100) / 100,
      dryness: Math.round(dryness * 100) / 100,
      sweetness: Math.round(sweetness * 100) / 100,
      finish: Math.round(finish * 100) / 100,
      complexity: Math.round(complexity * 100) / 100,
      oiliness: Math.round((newMakeSensory.oiliness * (0.6 + youngSpiritLoss * 0.4)) * 100) / 100,
      tannin: Math.round(tannin * 100) / 100,
    };

    const uncertainty = Math.round((0.04 + Math.sqrt(year) * 0.015) * 1000) / 1000;

    timeline.push({
      ageYears: year,
      sensory: sensoryPoint,
      remainingVolumeLitres: Math.round(vol * 10) / 10,
      estimatedABVPct: Math.round(abv * 10) / 10,
      woodExtractPPM: Math.round(woodSat * 480 * vanillinFactor),
      lactonePPM: Math.round(woodSat * 12.5 * (isAmericanOak ? 1.5 : 0.6) * 10) / 10,
      tanninIndex: Math.round(tannin * 100),
      subtractiveLossSulphurPct: Math.round((1.0 - youngSpiritLoss) * 100),
      interactiveOxidationScore: Math.round(oxSat * 100),
      uncertaintyMargin: uncertainty,
    });
  });

  const targetPoint = timeline.find(p => p.ageYears === targetAgeYears) || timeline[timeline.length - 1];
  const totalVolLossPct = Math.round(((cask.capacityLitres - targetPoint.remainingVolumeLitres) / cask.capacityLitres) * 100 * 10) / 10;
  const initialLPA = cask.capacityLitres * (cask.fillStrengthABVPct / 100);
  const finalLPA = targetPoint.remainingVolumeLitres * (targetPoint.estimatedABVPct / 100);
  const totalLpaLossPct = Math.round(((initialLPA - finalLPA) / initialLPA) * 100 * 10) / 10;

  // Generate 1,000 Monte Carlo trajectories with seeded deterministic variations
  const sampleAges = [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 25];
  const monteCarloRuns = 1000;
  const sampleTrajectories: MonteCarloTrajectory[] = [];
  
  // Store distribution arrays for percentiles
  const complexityDistributions: number[][] = sampleAges.map(() => []);

  for (let s = 0; s < monteCarloRuns; s++) {
    // Deterministic pseudo-random seed generator
    const seed = (s * 9301 + 49297) % 233280;
    const rnd1 = (seed / 233280.0) - 0.5; // -0.5 to 0.5
    const seed2 = ((s + 17) * 9301 + 49297) % 233280;
    const rnd2 = (seed2 / 233280.0) - 0.5;

    const microclimateTempVariation = rnd1 * 2.8; // +/- 1.4C
    const woodPorosityVariation = rnd2 * 0.3;     // +/- 15% extraction rate

    const path: { age: number; score: number; abv: number; volume: number }[] = [];

    sampleAges.forEach((age, ageIdx) => {
      const basePoint = timeline.find(p => p.ageYears === age) || timeline[Math.min(timeline.length - 1, ageIdx)];
      const kVar = 0.14 * (1.0 + woodPorosityVariation);
      const modeledScore = Math.min(1.0, Math.max(0.1, 0.35 + (1.0 - Math.exp(-kVar * age)) * 0.58 + (rnd1 * 0.08)));
      const modeledVol = cask.capacityLitres * Math.pow(1.0 - (annualEvap * (1.0 + microclimateTempVariation * 0.05)), age);
      const modeledAbv = Math.max(40.0, cask.fillStrengthABVPct + (annualAbvDrift * age) + (rnd2 * 0.6));

      complexityDistributions[ageIdx].push(modeledScore);

      if (s < 12) { // store first 12 representative trajectories for visual rendering
        path.push({
          age,
          score: Math.round(modeledScore * 1000) / 1000,
          abv: Math.round(modeledAbv * 10) / 10,
          volume: Math.round(modeledVol * 10) / 10,
        });
      }
    });

    if (s < 12) {
      sampleTrajectories.push({ simId: s + 1, path });
    }
  }

  // Calculate p10, median, p90
  const medianTrajectory: number[] = [];
  const p10LowerBand: number[] = [];
  const p90UpperBand: number[] = [];

  sampleAges.forEach((_, idx) => {
    const sorted = [...complexityDistributions[idx]].sort((a, b) => a - b);
    const p10 = sorted[Math.floor(monteCarloRuns * 0.1)];
    const med = sorted[Math.floor(monteCarloRuns * 0.5)];
    const p90 = sorted[Math.floor(monteCarloRuns * 0.9)];

    p10LowerBand.push(Math.round(p10 * 1000) / 1000);
    medianTrajectory.push(Math.round(med * 1000) / 1000);
    p90UpperBand.push(Math.round(p90 * 1000) / 1000);
  });

  return {
    timeline,
    finalProfile: targetPoint.sensory,
    volumeLossTotalPct: totalVolLossPct,
    lpaLossTotalPct: totalLpaLossPct,
    monteCarloSummary: {
      ages: sampleAges,
      medianTrajectory,
      p10LowerBand,
      p90UpperBand,
      sampleTrajectories,
    },
  };
}
