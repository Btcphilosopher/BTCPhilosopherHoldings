import { FermentationProfile, MashProfile, YeastProfile, DistillationProfile, SensoryAxisProfile, CompoundConcentration } from '@/types/whisky';

export interface FermentationTimeStep {
  hour: number;
  sugarConcentrationGperL: number; // e.g. 140 -> 3
  ethanolABVPct: number;           // e.g. 0.0 -> 8.5%
  biomassGperL: number;            // e.g. 1.0 -> 8.5 -> 6.0
  phValue: number;                 // e.g. 5.4 -> 4.1
  isoamylAcetateMgL: number;       // Banana/pear ester
  ethylHexanoateMgL: number;       // Green apple/tropical ester
  higherAlcoholsMgL: number;       // Fusel oils
  sulphurCompoundsUgL: number;     // H2S / DMS (declines with vigorous gas purge)
  temperatureC: number;
}

export function simulateFermentationKinetics(
  mash: MashProfile,
  yeast: YeastProfile,
  ferm: FermentationProfile
): {
  timeSteps: FermentationTimeStep[];
  finalWashABV: number;
  apparentAttenuationPct: number;
  totalEstersPPM: number;
  higherAlcoholsPPM: number;
  washSensoryProfile: Partial<SensoryAxisProfile>;
} {
  const hoursTotal = ferm.durationHours || 72;
  const stepsCount = 13; // 0h, 6h, 12h, 18h, 24h, 30h, 36h, 42h, 48h, 54h, 60h, 66h, 72h (+ up to 96h)
  const dt = hoursTotal / (stepsCount - 1);

  // Initial conditions based on Original Gravity
  const initialSugarGperL = (mash.originalGravitySG - 1.0) * 1000 * 2.6; // approx 169 g/L for 1.065
  let sugar = initialSugarGperL;
  let ethanol = 0.05;
  let biomass = ferm.pitchRateMillionCellsPerMl * 0.15; // g/L proxy
  let ph = 5.35;
  let isoamylAcetate = 0.1;
  let ethylHexanoate = 0.05;
  let higherAlcohols = 10;
  let sulphurUgL = 120; // high at start

  const timeSteps: FermentationTimeStep[] = [];

  const maxGrowthRate = yeast.fermentationRate === 'Fast (48h)' ? 0.22 : yeast.fermentationRate === 'Moderate (60h)' ? 0.17 : 0.13;
  const esterMultiplier = yeast.esterTendency * 1.4;

  for (let i = 0; i < stepsCount; i++) {
    const t = Math.round(i * dt);
    
    // Model temperature curve
    let currentTemp = ferm.pitchTempC;
    if (t < 36) {
      // Exothermic phase
      currentTemp = ferm.pitchTempC + (ferm.maxPeakTempC - ferm.pitchTempC) * Math.sin((t / 36) * (Math.PI / 2));
    } else {
      // Cooling / stationary phase
      currentTemp = ferm.maxPeakTempC - (ferm.maxPeakTempC - 20) * ((t - 36) / (hoursTotal - 36)) * 0.7;
    }

    timeSteps.push({
      hour: t,
      sugarConcentrationGperL: Math.max(2.0, Math.round(sugar * 10) / 10),
      ethanolABVPct: Math.round(ethanol * 100) / 100,
      biomassGperL: Math.round(biomass * 100) / 100,
      phValue: Math.round(ph * 100) / 100,
      isoamylAcetateMgL: Math.round(isoamylAcetate * 100) / 100,
      ethylHexanoateMgL: Math.round(ethylHexanoate * 100) / 100,
      higherAlcoholsMgL: Math.round(higherAlcohols * 10) / 10,
      sulphurCompoundsUgL: Math.max(8.0, Math.round(sulphurUgL * 10) / 10),
      temperatureC: Math.round(currentTemp * 10) / 10,
    });

    // Kinetic integration step (Monod/logistic approximation)
    if (sugar > 3.0) {
      const consumptionRate = maxGrowthRate * (sugar / (sugar + 15.0)) * (1.0 - ethanol / 11.0);
      const dSugar = consumptionRate * biomass * dt * 2.8;
      const actualDSugar = Math.min(sugar - 2.5, dSugar);
      sugar -= actualDSugar;

      const dEthanol = actualDSugar * 0.051 * (mash.fermentableExtractPct / 100);
      ethanol += dEthanol;

      if (t < 36) {
        biomass = Math.min(9.5, biomass + actualDSugar * 0.045);
      } else {
        biomass = Math.max(3.0, biomass - 0.08 * dt);
      }

      ph = Math.max(3.95, ph - 0.015 * dt);
      
      // Secondary metabolites
      isoamylAcetate += dEthanol * 0.35 * esterMultiplier * (currentTemp > 28 ? 1.25 : 1.0);
      ethylHexanoate += dEthanol * 0.18 * esterMultiplier;
      higherAlcohols += dEthanol * 22 * yeast.higherAlcoholTendency;
      sulphurUgL = Math.max(10, sulphurUgL - (dEthanol * 14 * yeast.sulphurReductionAbility));

      // Lactic Acid Bacteria in long ferments (>60h)
      if (t > 54 && ferm.lacticAcidBacteriaAllowed) {
        ph = Math.max(3.8, ph - 0.04 * (dt / 10));
        ethylHexanoate += 0.08; // complex fruity notes from wash acidification
      }
    }
  }

  const finalWashABV = Math.min(9.8, Math.max(7.2, Math.round(ethanol * 100) / 100));
  const apparentAttenuation = Math.min(92, Math.round(((initialSugarGperL - sugar) / initialSugarGperL) * 100 * 10) / 10);
  const totalEsters = Math.round((isoamylAcetate + ethylHexanoate) * 100) / 100;

  // Wash sensory estimation
  const washSensoryProfile: Partial<SensoryAxisProfile> = {
    fruit: Math.min(0.95, 0.45 + (totalEsters / 6.0) * 0.4),
    cereal: Math.max(0.2, 0.85 - (apparentAttenuation / 100) * 0.4),
    floral: Math.min(0.85, 0.3 + yeast.esterTendency * 0.4),
    herbal: ferm.lacticAcidBacteriaAllowed && ferm.durationHours > 65 ? 0.65 : 0.35,
    sweetness: Math.max(0.15, 0.6 - (apparentAttenuation / 100) * 0.45),
  };

  return {
    timeSteps,
    finalWashABV,
    apparentAttenuationPct: apparentAttenuation,
    totalEstersPPM: totalEsters,
    higherAlcoholsPPM: Math.round(higherAlcohols),
    washSensoryProfile,
  };
}

export function simulateDistillationProcess(
  distProfile: DistillationProfile,
  washABV: number,
  washEstersPPM: number,
  washSulphurUgL: number,
  peatPhenolsPPM: number
): {
  foreshotsVolumeL: number;
  headsVolumeL: number;
  heartVolumeL: number;
  tailsVolumeL: number;
  newMakeABVPct: number;
  totalYieldLPA: number;
  copperInteractionScore: number;
  predictedNewMakeSensory: SensoryAxisProfile;
  predictedCompounds: CompoundConcentration[];
} {
  const { washStillGeometry, spiritStillGeometry, headsToHeartCutABVPct, heartToTailsCutABVPct, spiritStillChargeLitres } = distProfile;

  // Copper interaction factor: Lyne arm angle (+ is ascending -> more reflux & copper contact)
  const angleContact = Math.max(0.5, 1.0 + spiritStillGeometry.lyneArmAngleDegrees * 0.04);
  const neckReflux = (spiritStillGeometry.neckHeightMetres / 3.0) * (spiritStillGeometry.refluxRatio / 1.0);
  const condenserTypeMultiplier = spiritStillGeometry.condenserType.includes('Shell & Tube') ? 1.35 : 0.75;
  const copperScore = Math.min(10, Math.max(1, (spiritStillGeometry.copperContactIndex * 0.4 + angleContact * 2.5 + neckReflux * 2.0) * condenserTypeMultiplier));

  // Cuts volume distribution
  const totalSpiritRun = spiritStillChargeLitres * 0.38; // low wines conversion
  const foreshotsVolumeL = Math.round(totalSpiritRun * 0.025);
  const headsVolumeL = Math.round(totalSpiritRun * 0.095);
  const heartFraction = Math.max(0.4, (headsToHeartCutABVPct - heartToTailsCutABVPct) / 18.0);
  const heartVolumeL = Math.round(totalSpiritRun * 0.58 * heartFraction);
  const tailsVolumeL = Math.round(totalSpiritRun * (1.0 - 0.025 - 0.095 - (0.58 * heartFraction)));

  const newMakeABV = Math.round(((headsToHeartCutABVPct + heartToTailsCutABVPct) / 2.0) * 10) / 10;
  const totalYieldLPA = Math.round((heartVolumeL * (newMakeABV / 100)) * 10) / 10;

  // Sensory prediction of New Make spirit
  // High copper contact removes sulphur and purifies light esters (fruity, floral, clean)
  // Low copper / early tails cut increases oiliness, cereal, heavy savoury notes
  const fruitScore = Math.min(0.95, Math.max(0.3, 0.45 + (copperScore / 10) * 0.35 + (washEstersPPM / 8) * 0.2));
  const floralScore = Math.min(0.9, Math.max(0.2, 0.35 + (copperScore / 10) * 0.4));
  const cerealScore = Math.min(0.9, Math.max(0.2, 0.75 - (copperScore / 10) * 0.25 + (heartToTailsCutABVPct < 62 ? 0.2 : 0)));
  const oilinessScore = Math.min(0.95, Math.max(0.15, 0.85 - (copperScore / 10) * 0.45 + (heartToTailsCutABVPct < 62 ? 0.25 : 0)));
  const smokeScore = peatPhenolsPPM > 0 ? Math.min(0.98, Math.max(0.05, (peatPhenolsPPM / 55.0) * 0.9)) : 0.02;
  const medicinalScore = peatPhenolsPPM > 20 ? Math.min(0.95, (peatPhenolsPPM / 60.0) * 0.85) : 0.01;
  const mineralScore = Math.min(0.85, 0.3 + (copperScore > 7 ? 0.3 : 0.1));
  const finishScore = Math.min(0.95, 0.45 + (oilinessScore * 0.3) + (smokeScore * 0.25));

  const predictedNewMakeSensory: SensoryAxisProfile = {
    fruit: Math.round(fruitScore * 100) / 100,
    floral: Math.round(floralScore * 100) / 100,
    malt: Math.round((cerealScore * 0.85) * 100) / 100,
    cereal: Math.round(cerealScore * 100) / 100,
    spice: Math.round((0.25 + (10 - copperScore) * 0.03) * 100) / 100,
    oak: 0.00, // Zero oak in new-make
    vanilla: 0.00,
    caramel: 0.00,
    nut: Math.round((0.2 + (heartToTailsCutABVPct < 63 ? 0.25 : 0.05)) * 100) / 100,
    driedFruit: 0.02,
    smoke: Math.round(smokeScore * 100) / 100,
    medicinal: Math.round(medicinalScore * 100) / 100,
    mineral: Math.round(mineralScore * 100) / 100,
    salt: peatPhenolsPPM > 15 ? 0.35 : 0.05,
    herbal: Math.round((0.2 + (10 - copperScore) * 0.02) * 100) / 100,
    body: Math.round((0.4 + oilinessScore * 0.45) * 100) / 100,
    dryness: 0.55,
    sweetness: Math.round((0.45 + fruitScore * 0.2) * 100) / 100,
    finish: Math.round(finishScore * 100) / 100,
    complexity: Math.round((0.4 + (fruitScore + oilinessScore + smokeScore) * 0.18) * 100) / 100,
    oiliness: Math.round(oilinessScore * 100) / 100,
    tannin: 0.00,
  };

  // Chemical compound proxies
  const predictedCompounds: CompoundConcentration[] = [
    {
      name: 'Ethyl Hexanoate (Green Apple / Anise)',
      chemicalClass: 'ESTERS',
      concentrationMgPerLitre: Math.round((1.2 + (copperScore / 10) * 1.6) * 100) / 100,
      sensoryThresholdMgPerLitre: 0.2,
      sensoryDescriptor: 'Crisp green apple, pineapple, fresh pear',
      uncertaintyBandPct: 8.5,
    },
    {
      name: 'Isoamyl Acetate (Banana Drops)',
      chemicalClass: 'ESTERS',
      concentrationMgPerLitre: Math.round((2.8 + washEstersPPM * 0.8) * 100) / 100,
      sensoryThresholdMgPerLitre: 0.6,
      sensoryDescriptor: 'Sweet pear drops, confectionery banana',
      uncertaintyBandPct: 7.2,
    },
    {
      name: 'Isoamyl Alcohol (Fusel Oil)',
      chemicalClass: 'HIGHER ALCOHOLS',
      concentrationMgPerLitre: Math.round((180 - copperScore * 7 + (heartToTailsCutABVPct < 63 ? 40 : 0)) * 10) / 10,
      sensoryThresholdMgPerLitre: 30.0,
      sensoryDescriptor: 'Alcoholic warmth, grain body, solvent backbone',
      uncertaintyBandPct: 5.0,
    },
    {
      name: 'Acetaldehyde (Green Leaf / Cut Grass)',
      chemicalClass: 'ALDEHYDES',
      concentrationMgPerLitre: Math.round((18 - (foreshotsVolumeL / 50) * 4) * 10) / 10,
      sensoryThresholdMgPerLitre: 2.0,
      sensoryDescriptor: 'Pungent crushed grass, green apple skin',
      uncertaintyBandPct: 11.0,
    },
    {
      name: '4-Ethylguaiacol & Cresol (Peat Phenols)',
      chemicalClass: 'PHENOLS',
      concentrationMgPerLitre: Math.round((peatPhenolsPPM * 0.38) * 100) / 100,
      sensoryThresholdMgPerLitre: 0.05,
      sensoryDescriptor: 'Smoky hearth, creosote, medicinal iodine, tar',
      uncertaintyBandPct: 9.2,
    },
    {
      name: 'Dimethyl Trisulphide (DMTS)',
      chemicalClass: 'SULPHUR COMPOUNDS',
      concentrationMgPerLitre: Math.max(0.002, Math.round((0.08 - (copperScore / 10) * 0.075) * 1000) / 1000),
      sensoryThresholdMgPerLitre: 0.001,
      sensoryDescriptor: 'Cooked cabbage, meaty, struck match',
      uncertaintyBandPct: 14.5,
    },
  ];

  return {
    foreshotsVolumeL,
    headsVolumeL,
    heartVolumeL,
    tailsVolumeL,
    newMakeABVPct: newMakeABV,
    totalYieldLPA,
    copperInteractionScore: Math.round(copperScore * 10) / 10,
    predictedNewMakeSensory,
    predictedCompounds,
  };
}
