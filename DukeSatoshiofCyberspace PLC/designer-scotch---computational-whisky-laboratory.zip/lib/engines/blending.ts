import { BlendComponent, CaskEntity, SensoryAxisProfile, TargetWhiskyProfile, BlendDesign } from '@/types/whisky';

export function calculateBlendProperties(
  components: BlendComponent[],
  target: TargetWhiskyProfile
): BlendDesign {
  if (!components || components.length === 0) {
    return {
      id: 'BL-EMPTY',
      name: 'Empty Blend',
      code: 'DS-BL-0000',
      components: [],
      calculatedABV: 0,
      calculatedAgeStatement: 0,
      totalVolumeLitres: 0,
      bottlesYield700ml: 0,
      sensoryProfile: target.sensory,
      compounds: [],
      costPerBottleGBP: 0,
      sensoryDistanceToTarget: 1.0,
    };
  }

  // Normalize percentages if they don't sum to 100
  const totalRawPct = components.reduce((sum, c) => sum + c.percentage, 0);
  const normalizedComponents = components.map(c => ({
    ...c,
    percentage: totalRawPct > 0 ? (c.percentage / totalRawPct) * 100 : 0,
  }));

  let weightedABV = 0;
  let minAge = 999;
  let totalVolume = 0;
  let weightedCost = 0;

  const sensoryAccumulator: Record<keyof SensoryAxisProfile, number> = {
    fruit: 0, floral: 0, malt: 0, cereal: 0, spice: 0, oak: 0, vanilla: 0,
    caramel: 0, nut: 0, driedFruit: 0, smoke: 0, medicinal: 0, mineral: 0,
    salt: 0, herbal: 0, body: 0, dryness: 0, sweetness: 0, finish: 0,
    complexity: 0, oiliness: 0, tannin: 0,
  };

  normalizedComponents.forEach(({ percentage, caskSnapshot }) => {
    const fraction = percentage / 100;
    weightedABV += (caskSnapshot.currentABVPct || 54.0) * fraction;
    minAge = Math.min(minAge, caskSnapshot.ageYears);
    totalVolume += caskSnapshot.currentVolumeLitres * fraction;
    weightedCost += (caskSnapshot.costBasisGBP || 1200) * fraction;

    const s = caskSnapshot.sensoryContribution;
    (Object.keys(sensoryAccumulator) as (keyof SensoryAxisProfile)[]).forEach(key => {
      sensoryAccumulator[key] += (s[key] || 0) * fraction;
    });
  });

  const finalSensory: SensoryAxisProfile = {} as SensoryAxisProfile;
  (Object.keys(sensoryAccumulator) as (keyof SensoryAxisProfile)[]).forEach(key => {
    finalSensory[key] = Math.round(sensoryAccumulator[key] * 100) / 100;
  });

  // Calculate Euclidean Distance to target profile
  let squaredDistance = 0;
  let axisCount = 0;
  const targetSensory = target.sensory;

  (Object.keys(targetSensory) as (keyof SensoryAxisProfile)[]).forEach(key => {
    const diff = (finalSensory[key] || 0) - (targetSensory[key] || 0);
    // Give higher weight to principal dimensions (fruit, smoke, oak, finish)
    const weight = ['fruit', 'oak', 'smoke', 'vanilla', 'finish', 'body'].includes(key) ? 1.8 : 1.0;
    squaredDistance += diff * diff * weight;
    axisCount += weight;
  });

  const distance = Math.round(Math.sqrt(squaredDistance / axisCount) * 1000) / 1000;
  const bottleYield = Math.floor((totalVolume / 0.7) * 0.98); // 2% filtration / bottling loss
  const costPerBottle = bottleYield > 0 ? Math.round((weightedCost / bottleYield + 14.5) * 100) / 100 : 45.0;

  return {
    id: `BL-${Math.round(totalVolume)}L`,
    name: `${target.name} Blend Formulation`,
    code: `DS-BL-${minAge === 999 ? 0 : minAge}YO-${Math.round(weightedABV * 10)}`,
    components: normalizedComponents,
    calculatedABV: Math.round(weightedABV * 10) / 10,
    calculatedAgeStatement: minAge === 999 ? 0 : minAge,
    totalVolumeLitres: Math.round(totalVolume * 10) / 10,
    bottlesYield700ml: bottleYield,
    sensoryProfile: finalSensory,
    compounds: [],
    costPerBottleGBP: costPerBottle,
    sensoryDistanceToTarget: distance,
  };
}

/**
 * RhinoQuant Constrained Solver:
 * Multi-cask optimization searching for fractional weights that minimize distance to target.
 */
export function optimizeBlendWeights(
  availableCasks: CaskEntity[],
  target: TargetWhiskyProfile,
  maxIterations: number = 300
): {
  optimalWeights: { caskId: string; percentage: number; cask: CaskEntity }[];
  initialDistance: number;
  optimizedDistance: number;
  convergencePath: { step: number; distance: number }[];
} {
  if (availableCasks.length === 0) {
    return { optimalWeights: [], initialDistance: 1.0, optimizedDistance: 1.0, convergencePath: [] };
  }

  const n = availableCasks.length;
  // Initialize equal weights
  let weights = availableCasks.map(() => 100 / n);

  const evalDistance = (w: number[]): number => {
    const totalW = w.reduce((a, b) => a + b, 0);
    const norm = w.map(v => (v / totalW));

    let sqDiff = 0;
    const targetS = target.sensory;

    (Object.keys(targetS) as (keyof SensoryAxisProfile)[]).forEach(k => {
      let blendedVal = 0;
      for (let i = 0; i < n; i++) {
        blendedVal += (availableCasks[i].sensoryContribution[k] || 0) * norm[i];
      }
      const diff = blendedVal - (targetS[k] || 0);
      const weight = ['fruit', 'oak', 'smoke', 'vanilla', 'finish', 'body'].includes(k) ? 2.0 : 1.0;
      sqDiff += diff * diff * weight;
    });

    return Math.sqrt(sqDiff / Object.keys(targetS).length);
  };

  const initialDistance = Math.round(evalDistance(weights) * 1000) / 1000;
  const convergencePath: { step: number; distance: number }[] = [{ step: 0, distance: initialDistance }];

  let bestWeights = [...weights];
  let bestDist = initialDistance;
  let stepSize = 8.0;

  for (let iter = 1; iter <= maxIterations; iter++) {
    // Random perturbation / gradient step
    const idxA = Math.floor(Math.random() * n);
    const idxB = (idxA + 1 + Math.floor(Math.random() * (n - 1))) % n;

    const delta = (Math.random() * stepSize);
    const testWeights = [...bestWeights];

    if (testWeights[idxA] >= delta) {
      testWeights[idxA] -= delta;
      testWeights[idxB] += delta;

      const d = evalDistance(testWeights);
      if (d < bestDist) {
        bestDist = d;
        bestWeights = testWeights;
      }
    }

    if (iter % 30 === 0) {
      stepSize *= 0.82; // Annealing schedule
      convergencePath.push({ step: iter, distance: Math.round(bestDist * 1000) / 1000 });
    }
  }

  // Filter out tiny fractions (< 1%) and renormalize
  const totalBest = bestWeights.reduce((a, b) => a + b, 0);
  let cleaned = bestWeights.map(w => (w / totalBest) * 100);
  cleaned = cleaned.map(w => (w < 1.5 ? 0 : w));
  const cleanSum = cleaned.reduce((a, b) => a + b, 0);
  cleaned = cleaned.map(w => Math.round((w / cleanSum) * 100));

  // Correct rounding drift to ensure exact 100%
  const roundDiff = 100 - cleaned.reduce((a, b) => a + b, 0);
  if (cleaned.length > 0 && roundDiff !== 0) {
    const maxIdx = cleaned.indexOf(Math.max(...cleaned));
    cleaned[maxIdx] += roundDiff;
  }

  const optimalWeights = availableCasks.map((cask, i) => ({
    caskId: cask.id,
    percentage: cleaned[i],
    cask,
  })).filter(item => item.percentage > 0);

  return {
    optimalWeights,
    initialDistance,
    optimizedDistance: Math.round(bestDist * 1000) / 1000,
    convergencePath,
  };
}
