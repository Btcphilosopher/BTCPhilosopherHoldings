export type ScotchRegion = 'Highland' | 'Speyside' | 'Islay' | 'Campbeltown' | 'Lowland' | 'Islands';
export type WhiskyStyle = 'Single Malt' | 'Single Cask' | 'Small Batch' | 'Blended Malt' | 'Grain' | 'Experimental';
export type WoodSpecies = 'Quercus alba (American White Oak)' | 'Quercus robur (European Oak)' | 'Quercus petraea (Sessile Oak)' | 'Quercus mongolica (Mizunara)';
export type CaskSeasoning = 'ex-Bourbon' | 'ex-Oloroso Sherry' | 'ex-Pedro Ximénez' | 'ex-Tawny Port' | 'ex-Madeira' | 'Virgin Oak' | 'Refill Hogshead' | 'STR (Shaved, Toasted, Recharred)';
export type ToastLevel = 'Light' | 'Medium' | 'Medium Plus' | 'Heavy';
export type CharLevel = 'Char 1 (Light)' | 'Char 2 (Medium)' | 'Char 3 (Alligator)' | 'Char 4 (Heavy Alligator)';

export type DataClassification = 'MEASURED DATA' | 'SIMULATED DATA' | 'MODELLED DATA' | 'EXPERT INPUT' | 'PREDICTED OUTCOME';

export interface SensoryAxisProfile {
  fruit: number;         // 0.00 to 1.00
  floral: number;
  malt: number;
  cereal: number;
  spice: number;
  oak: number;
  vanilla: number;
  caramel: number;
  nut: number;
  driedFruit: number;
  smoke: number;
  medicinal: number;
  mineral: number;
  salt: number;
  herbal: number;
  body: number;
  dryness: number;
  sweetness: number;
  finish: number;
  complexity: number;
  oiliness: number;
  tannin: number;
}

export interface TargetWhiskyProfile {
  id: string;
  name: string;
  code: string;
  region: ScotchRegion;
  style: WhiskyStyle;
  description: string;
  targetAgeYears: number;
  targetABV: number;
  targetBottles: number;
  sensory: SensoryAxisProfile;
  targetCostPerBottleGBP: number;
  targetRetailPriceGBP: number;
  positioning: 'Ultra-Premium' | 'Prestige Collector' | 'Connoisseur Reserve' | 'Core Luxury';
}

export interface BarleyProfile {
  id: string;
  variety: string;
  origin: string;
  harvestYear: number;
  proteinContentPct: number;     // e.g. 9.8%
  nitrogenPct: number;           // e.g. 1.45%
  moisturePct: number;           // e.g. 12.5%
  thousandGrainWeightG: number;  // e.g. 42g
  potentialExtractLPAperTonne: number; // e.g. 415 LPA/t
  diastaticPowerWK: number;      // Windisch-Kolbach units e.g. 260
  alphaAmylaseDU: number;        // Dextrinizing units e.g. 48
  germinationEnergyPct: number;  // e.g. 98%
}

export interface KilningSchedule {
  dryingHours: number;           // 0-4h
  intermediateHours: number;     // 4-8h
  curingHours: number;           // 8-12h
  maxTempC: number;              // e.g. 72C
  peatExposureHours: number;     // e.g. 18h
  peatSource: 'Islay Maritime Bog' | 'Highland Heath & Moss' | 'Orkney Heather & Calluna' | 'Unpeated';
  targetPhenolsPPM: number;      // e.g. 25 PPM
}

export interface WaterChemistry {
  id: string;
  name: string;
  source: string;
  calciumPPM: number;       // Ca2+
  magnesiumPPM: number;     // Mg2+
  sodiumPPM: number;        // Na+
  potassiumPPM: number;     // K+
  bicarbonatePPM: number;   // HCO3-
  sulfatePPM: number;       // SO4(2-)
  chloridePPM: number;      // Cl-
  pH: number;
  alkalinityCaCO3PPM: number;
  totalHardnessCaCO3PPM: number;
}

export interface MashProfile {
  liquorToGristRatio: number; // e.g. 4.0 L/kg
  mashTunsCount: number;
  strikeTempC: number;        // e.g. 64.5C
  mashDurationMins: number;   // e.g. 90 mins
  spargeWaterTempC: number;   // e.g. 78C
  spargeWatersCount: number;  // e.g. 3
  wortVolumeLitres: number;
  originalGravitySG: number;  // e.g. 1.065
  fermentableExtractPct: number; // e.g. 88.5%
  clearWortTurbidityEBC: number; // Low = clear/fruity, high = nutty/cereal
}

export interface YeastProfile {
  id: string;
  name: string;
  strainType: 'Distillers M-Type (Standard)' | 'MX-Distillers (High Ester)' | 'Pinnacle Expressive' | 'Brewer’s Ale Yeast Blend' | 'Cultivated Wild Islay Isolates';
  attenuationLimitPct: number;   // e.g. 89%
  optimalTempMinC: number;
  optimalTempMaxC: number;
  fermentationRate: 'Fast (48h)' | 'Moderate (60h)' | 'Extended Slow (72-96h)';
  esterTendency: number;         // 0.0 - 1.0
  higherAlcoholTendency: number; // 0.0 - 1.0
  sulphurReductionAbility: number; // 0.0 - 1.0
  stressToleranceABVPct: number; // e.g. 10.5%
}

export interface FermentationProfile {
  yeastProfileId: string;
  pitchRateMillionCellsPerMl: number; // e.g. 15 M cells/mL
  pitchTempC: number;                 // e.g. 19.5C
  maxPeakTempC: number;               // e.g. 33.5C
  durationHours: number;              // 48 to 96 hours
  dissolvedOxygenPPM: number;         // e.g. 8.2 PPM
  lacticAcidBacteriaAllowed: boolean; // Malolactic-like wash acidification in long ferments
  washVolumeLitres: number;
  estimatedWashABVPct: number;        // e.g. 8.4%
}

export interface StillGeometry {
  potDiameterMetres: number;
  neckHeightMetres: number;
  neckShape: 'Lantern' | 'Lamp Glass' | 'Straight Conical' | 'Boil Ball (Milton)';
  lyneArmAngleDegrees: number;        // -15 (downwards/heavy) to +15 (ascending/light)
  condenserType: 'Shell & Tube (High Copper)' | 'Traditional Worm Tub (Low Copper/Meaty)';
  copperContactIndex: number;         // 1.0 to 10.0
  refluxRatio: number;                // 0.2 to 2.5
}

export interface DistillationProfile {
  washStillChargeLitres: number;
  washStillRunHours: number;
  spiritStillChargeLitres: number;
  spiritStillRunHours: number;
  washStillGeometry: StillGeometry;
  spiritStillGeometry: StillGeometry;
  foreshotsCutMins: number;           // e.g. 15 mins
  headsToHeartCutABVPct: number;      // e.g. 72.5% ABV
  heartToTailsCutABVPct: number;      // e.g. 63.8% ABV
  demistingStrengthABVPct: number;
  newMakeSpiritStrengthABVPct: number;// e.g. 68.4% ABV
  newMakeYieldLitres: number;
  spiritYieldLPA: number;
  predictedNewMakeSensory?: SensoryAxisProfile;
}

export interface CompoundConcentration {
  name: string;
  chemicalClass: 'ESTERS' | 'HIGHER ALCOHOLS' | 'ALDEHYDES' | 'PHENOLS' | 'LACTONES' | 'SULPHUR COMPOUNDS' | 'OAK VOLATILES';
  concentrationMgPerLitre: number;
  sensoryThresholdMgPerLitre: number;
  sensoryDescriptor: string;
  uncertaintyBandPct: number;
}

export interface CaskEntity {
  id: string;
  caskNumber: string;
  woodSpecies: WoodSpecies;
  seasoning: CaskSeasoning;
  toastLevel: ToastLevel;
  charLevel: CharLevel;
  capacityLitres: number;
  currentVolumeLitres: number;
  fillStrengthABVPct: number;
  currentABVPct: number;
  fillDate: string; // ISO date
  ageYears: number;
  warehouseId: string;
  rackLocation: string; // e.g. "Bay 4, Tier 3, Stave 12"
  sensoryContribution: SensoryAxisProfile;
  valuationGBP: number;
  costBasisGBP: number;
  status: 'Maturing' | 'Sampling' | 'Ready for Blend' | 'Blended' | 'Reserved';
}

export interface WarehouseEnvironment {
  id: string;
  name: string;
  type: 'Traditional Dunnage (Earth Floor, Cool, High Humidity)' | 'Palletised Brick (Variable, Warm Upper Tiers)' | 'Racked Concrete Insulated';
  avgTempC: number;
  avgHumidityPct: number;
  annualEvaporationLossPct: number; // Volume loss per annum (1.5% - 2.5%)
  annualAlcoholDriftABVPct: number; // e.g. -0.4% ABV / year (cool/humid) or +0.1% (dry/hot)
  caskCount: number;
}

export interface BlendComponent {
  caskId: string;
  percentage: number; // 0 to 100
  caskSnapshot: CaskEntity;
}

export interface BlendDesign {
  id: string;
  name: string;
  code: string;
  components: BlendComponent[];
  calculatedABV: number;
  calculatedAgeStatement: number; // Youngest cask rule
  totalVolumeLitres: number;
  bottlesYield700ml: number;
  sensoryProfile: SensoryAxisProfile;
  compounds: CompoundConcentration[];
  costPerBottleGBP: number;
  sensoryDistanceToTarget: number;
}

export interface SensoryPanelistScore {
  panelistId: string;
  panelistName: string;
  qualification: 'Master Blender' | 'Sensory Scientist' | 'Panelist ISO Qualified' | 'Distillery Manager';
  blindSampleCode: string;
  evaluationDate: string;
  ratings: SensoryAxisProfile;
  confidenceScore: number; // 0.0 - 1.0
  tastingNotes: {
    nose: string[];
    palate: string[];
    texture: string;
    finish: string[];
  };
}

export interface ExperimentTrial {
  id: string;
  code: string;
  hypothesis: string;
  variableType: 'Fermentation Duration' | 'Still Lyne Arm Angle' | 'Cut Point Heart ABV' | 'Cask Fill Strength' | 'Barley Cultivar' | 'Water Mineral Ratio';
  testArms: {
    armName: string;
    parameterValue: number | string;
    predictedOutcome: string;
    measuredOutcome?: string;
    status: 'Planned' | 'In Progress' | 'Completed' | 'Validated';
    predictedSensoryDelta: Partial<SensoryAxisProfile>;
  }[];
  bayesianPriorConfidence: number;
  bayesianPosteriorConfidence: number;
  scientificNotes: string;
}

export interface ProvenanceNode {
  id: string;
  title: string;
  category: 'RAW MATERIAL' | 'MASH & LIQUOR' | 'FERMENTATION' | 'DISTILLATION' | 'NEW MAKE SPIRIT' | 'CASK MATURATION' | 'VAT & BLEND' | 'BOTTLING';
  batchCode: string;
  timestamp: string;
  location: string;
  operator: string;
  metrics: Record<string, string | number>;
  status: 'VERIFIED' | 'SIMULATED' | 'AUDITED';
  childrenIds: string[];
}

export interface WhiskyDesign {
  id: string;
  name: string;
  code: string;
  version: number;
  createdAt: string;
  updatedAt: string;
  targetProfile: TargetWhiskyProfile;
  barleyProfile: BarleyProfile;
  kilningSchedule: KilningSchedule;
  waterChemistry: WaterChemistry;
  mashProfile: MashProfile;
  yeastProfile: YeastProfile;
  fermentationProfile: FermentationProfile;
  distillationProfile: DistillationProfile;
  caskProgramme: CaskEntity[];
  activeBlend: BlendDesign;
  warehouseId: string;
  experiments: ExperimentTrial[];
  provenanceRootId: string;
  complianceChecked: boolean;
}
