import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'DESIGNER SCOTCH | Computational Whisky Laboratory',
  description: 'Computational whisky design, distillation simulation, maturation modelling, blending optimization and premiumisation laboratory.',
  openGraph: {
    title: 'DESIGNER SCOTCH | Computational Whisky Laboratory',
    description: 'Computational whisky design, distillation simulation, maturation modelling, blending optimization and premiumisation laboratory.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'DESIGNER SCOTCH | Computational Whisky Laboratory',
    description: 'Computational whisky design, distillation simulation, maturation modelling, blending optimization and premiumisation laboratory.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="dark">
      <body className="bg-[#121110] text-[#EAE5D9] antialiased selection:bg-[#B37039]/30 selection:text-[#F7DCB9]" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
