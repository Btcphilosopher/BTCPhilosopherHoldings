'use client';

import React, { useState } from 'react';
import { WhiskyDesign } from '@/types/whisky';
import { MASTER_WHISKY_DESIGNS } from '@/lib/data/synthetic-db';
import { HeaderNav, ActiveTab } from '@/components/HeaderNav';
import { SignatureScreen } from '@/components/SignatureScreen';
import { TargetDesigner } from '@/components/TargetDesigner';
import { RawMaterialsLab } from '@/components/RawMaterialsLab';
import { MashWaterLab } from '@/components/MashWaterLab';
import { FermentationLab } from '@/components/FermentationLab';
import { DistillationLab } from '@/components/DistillationLab';
import { NewMakeLab } from '@/components/NewMakeLab';
import { CaskLab } from '@/components/CaskLab';
import { WarehouseDigitalTwin } from '@/components/WarehouseDigitalTwin';
import { MaturationLab } from '@/components/MaturationLab';
import { BlendingLab } from '@/components/BlendingLab';
import { SensoryLab } from '@/components/SensoryLab';
import { ExperimentsLab } from '@/components/ExperimentsLab';
import { EconomicsLab } from '@/components/EconomicsLab';
import { ProvenanceGenealogy } from '@/components/ProvenanceGenealogy';
import { DataImportExport } from '@/components/DataImportExport';
import { ModelValidationModal } from '@/components/ModelValidationModal';

export default function Home() {
  const [designs, setDesigns] = useState<WhiskyDesign[]>(MASTER_WHISKY_DESIGNS);
  const [activeDesignId, setActiveDesignId] = useState<string>(MASTER_WHISKY_DESIGNS[0].id);
  const [activeTab, setActiveTab] = useState<ActiveTab>('signature');
  const [validationModalOpen, setValidationModalOpen] = useState<boolean>(false);

  const activeDesign = designs.find(d => d.id === activeDesignId) || designs[0];

  const handleUpdateActiveDesign = (updated: WhiskyDesign) => {
    setDesigns(prev => prev.map(d => d.id === updated.id ? updated : d));
  };

  const handleImportDesign = (imported: WhiskyDesign) => {
    setDesigns(prev => {
      const exists = prev.some(d => d.id === imported.id);
      if (exists) {
        return prev.map(d => d.id === imported.id ? imported : d);
      }
      return [imported, ...prev];
    });
    setActiveDesignId(imported.id);
    setActiveTab('signature');
  };

  return (
    <div className="min-h-screen bg-[#0D0C0B] text-[#EAE5D9] flex flex-col font-sans distillery-grid">
      {/* Top Header & Navigation */}
      <HeaderNav
        designs={designs}
        activeDesignId={activeDesignId}
        onSelectDesign={setActiveDesignId}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenValidation={() => setValidationModalOpen(true)}
      />

      {/* Main Computational Workbench */}
      <main className="flex-1 max-w-[1720px] w-full mx-auto px-4 py-6">
        {activeTab === 'signature' && (
          <SignatureScreen
            design={activeDesign}
            onNavigate={setActiveTab}
            onUpdateDesign={handleUpdateActiveDesign}
          />
        )}

        {activeTab === 'target' && (
          <TargetDesigner
            design={activeDesign}
            onUpdateDesign={handleUpdateActiveDesign}
          />
        )}

        {activeTab === 'raw-material' && (
          <RawMaterialsLab
            design={activeDesign}
            onUpdateDesign={handleUpdateActiveDesign}
          />
        )}

        {activeTab === 'mash-water' && (
          <MashWaterLab
            design={activeDesign}
            onUpdateDesign={handleUpdateActiveDesign}
          />
        )}

        {activeTab === 'fermentation' && (
          <FermentationLab
            design={activeDesign}
            onUpdateDesign={handleUpdateActiveDesign}
          />
        )}

        {activeTab === 'distillation' && (
          <DistillationLab
            design={activeDesign}
            onUpdateDesign={handleUpdateActiveDesign}
          />
        )}

        {activeTab === 'new-make' && (
          <NewMakeLab
            design={activeDesign}
          />
        )}

        {activeTab === 'casks' && (
          <CaskLab
            design={activeDesign}
            onUpdateDesign={handleUpdateActiveDesign}
          />
        )}

        {activeTab === 'warehouse' && (
          <WarehouseDigitalTwin
            design={activeDesign}
          />
        )}

        {activeTab === 'maturation' && (
          <MaturationLab
            design={activeDesign}
          />
        )}

        {activeTab === 'blending' && (
          <BlendingLab
            design={activeDesign}
            onUpdateDesign={handleUpdateActiveDesign}
          />
        )}

        {activeTab === 'sensory' && (
          <SensoryLab
            design={activeDesign}
          />
        )}

        {activeTab === 'experiments' && (
          <ExperimentsLab
            design={activeDesign}
            onUpdateDesign={handleUpdateActiveDesign}
          />
        )}

        {activeTab === 'economics' && (
          <EconomicsLab
            design={activeDesign}
          />
        )}

        {activeTab === 'provenance' && (
          <ProvenanceGenealogy
            design={activeDesign}
          />
        )}

        {activeTab === 'data-import' && (
          <DataImportExport
            design={activeDesign}
            onImportDesign={handleImportDesign}
          />
        )}
      </main>

      {/* Footer Strip */}
      <footer className="border-t border-[#26211C] bg-[#12110F] py-3 text-xs font-mono text-[#7A7062]">
        <div className="max-w-[1720px] mx-auto px-4 flex flex-wrap justify-between items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-[#C67D38] font-bold">DESIGNER SCOTCH</span>
            <span>&bull;</span>
            <span>Computational Whisky Design & Maturation Platform</span>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <span>DESIGN &rarr; MODEL &rarr; SIMULATE &rarr; TASTE-PREDICT &rarr; MATURE &rarr; BLEND &rarr; VALUE</span>
            <button
              onClick={() => setValidationModalOpen(true)}
              className="text-[#C67D38] hover:underline"
            >
              SWR 2009 Compliance & Epistemology
            </button>
          </div>
        </div>
      </footer>

      {/* Compliance & Epistemology Modal */}
      <ModelValidationModal
        isOpen={validationModalOpen}
        onClose={() => setValidationModalOpen(false)}
      />
    </div>
  );
}
