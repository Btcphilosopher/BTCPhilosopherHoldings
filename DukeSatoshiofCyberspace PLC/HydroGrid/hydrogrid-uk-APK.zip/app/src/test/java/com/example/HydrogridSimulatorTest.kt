package com.example

import com.example.core.model.*
import com.example.core.simulation.PlantSimulatorEngine
import org.junit.Assert.*
import org.junit.Test

class HydrogridSimulatorTest {

    @Test
    fun `initial baseline matches fictional conditions and SEC calculation`() {
        val engine = PlantSimulatorEngine()
        val snap = engine.snapshot()
        assertEquals(360.0, snap.h2OutputKgPerHr, 0.01)
        assertEquals(20.0, snap.electrolyserPowerMw, 0.01)
        assertEquals(12400.0, snap.storageInventoryKg, 0.01)
        assertEquals(8640.0, snap.dispatchTodayKg, 0.01)

        val sec = snap.waterElectrolysis.specificElectricityKwhPerKg(ElectricalBoundary.COMPLETE_PLANT)
        assertNotNull(sec)
        assertEquals(55.56, sec!!, 0.1)

        val h2042 = snap.qualityBatches.first { it.batchId == "H2-042" }
        assertEquals(LabReviewStatus.SAMPLE_PENDING, h2042.reviewStatus)
        assertEquals(BatchReleaseStatus.HOLD_FOR_REVIEW, h2042.releaseStatus)
    }

    @Test
    fun `storage limits prevent overfilling and prevent divide by zero when halted`() {
        val engine = PlantSimulatorEngine()
        // Pause active loading on DSP-904 so storage isn't simultaneously drained into a trailer
        engine.advanceDispatchOrder("DSP-904", DispatchStage.CANCELLED, reason = "Test isolation")
        engine.setSpeed(SimSpeed.ACCEL_60X)
        // Tighten operating limits close to current inventory to force full-storage block
        engine.updateStorageLimits("BANK-A", 350.0, 4802.0)
        engine.updateStorageLimits("BANK-B", 350.0, 4102.0)
        engine.updateStorageLimits("BANK-C", 350.0, 3502.0)

        engine.step(60.0)
        val afterFill = engine.snapshot()
        assertTrue(afterFill.storageInventoryKg <= 4802.0 + 4102.0 + 3502.0 + 0.01)

        val blocked = engine.step(10.0)
        assertNotNull(blocked.flowBlockedReason)
        assertEquals(0.0, blocked.h2OutputKgPerHr, 0.001)
        assertNull(blocked.waterElectrolysis.specificElectricityKwhPerKg(ElectricalBoundary.COMPLETE_PLANT))
    }

    @Test
    fun `quality hold blocks dispatch until sample review and authorised release`() {
        val engine = PlantSimulatorEngine()
        engine.setRole(UserRole.DISPATCH)

        // DSP-905 is assigned H2-042 (HOLD FOR REVIEW) -> must fail
        val blocked = engine.advanceDispatchOrder("DSP-905", DispatchStage.AUTHORISED)
        assertTrue(blocked.isFailure)
        assertEquals(
            DispatchStage.HELD,
            engine.snapshot().dispatchOrders.first { it.orderId == "DSP-905" }.stage
        )

        // Operator cannot register sample (RBAC)
        engine.setRole(UserRole.OPERATOR)
        val opSample = engine.registerSample(
            "H2-042", ReadingSourceType.DISCRETE_SAMPLE, 99.991, 1.8, 1.2, "Op", null, "Test"
        )
        assertTrue(opSample.isFailure)

        // Lab staff records passing sample -> still HOLD_FOR_REVIEW until authorised release
        engine.setRole(UserRole.LAB_STAFF)
        val labRes = engine.registerSample(
            "H2-042", ReadingSourceType.DISCRETE_SAMPLE, 99.991, 1.8, 1.2, "Dr. Campbell", "COA.pdf", "Pass"
        )
        assertTrue(labRes.isSuccess)
        val batchAfterSample = labRes.getOrThrow().qualityBatches.first { it.batchId == "H2-042" }
        assertEquals(BatchReleaseStatus.HOLD_FOR_REVIEW, batchAfterSample.releaseStatus)
        assertEquals(2, batchAfterSample.samples.size) // Original SMP-100 preserved!

        // Supervisor authorises release
        engine.setRole(UserRole.SUPERVISOR)
        val relRes = engine.authoriseBatchRelease("H2-042", "Dr. Campbell")
        assertTrue(relRes.isSuccess)

        // Now Dispatch can authorise, load, and reconcile without double deduction
        engine.setRole(UserRole.DISPATCH)
        assertTrue(engine.advanceDispatchOrder("DSP-905", DispatchStage.AUTHORISED).isSuccess)
        assertTrue(engine.advanceDispatchOrder("DSP-905", DispatchStage.LOADING).isSuccess)
        val storageBeforeReconcile = engine.snapshot().storageInventoryKg
        val rec = engine.advanceDispatchOrder("DSP-905", DispatchStage.RECONCILED, confirmedTransferKg = 880.0)
        assertTrue(rec.isSuccess)
        val snapAfter = rec.getOrThrow()
        assertEquals(storageBeforeReconcile - 880.0, snapAfter.storageInventoryKg, 0.05)
        assertEquals(8640.0 + 880.0, snapAfter.dispatchTodayKg, 0.05)
    }

    @Test
    fun `pressure volume estimator validates bounds and reporting periods scale properly`() {
        val valid = PlantSimulatorEngine.estimateMassFromPressureAndVolume(368.0, 205.0, 18.4)
        assertTrue(valid.isSuccess)
        assertTrue(valid.getOrThrow() > 4000.0)

        val invalid = PlantSimulatorEngine.estimateMassFromPressureAndVolume(600.0, 205.0, 18.4)
        assertTrue(invalid.isFailure)

        val engine = PlantSimulatorEngine()
        val shift = engine.buildPeriodReport("Shift", 8.0)
        val daily = engine.buildPeriodReport("Daily", 24.0)
        assertEquals(daily.h2ProducedKg / 3.0, shift.h2ProducedKg, 0.01)
    }

    @Test
    fun `stale telemetry and recovery maintain explicit freshness state`() {
        val engine = PlantSimulatorEngine()
        val stale = engine.updateWallClock("14:21:00 UTC", incrementDataAge = true)
        assertEquals(1L, stale.dataAgeSeconds)
        engine.setFreshnessState(DataFreshnessState.CACHED, 15L)
        val aged = engine.updateWallClock("14:21:20 UTC", incrementDataAge = true)
        assertEquals(16L, aged.dataAgeSeconds)
        assertEquals(DataFreshnessState.CACHED, aged.freshnessState)
        val recovered = engine.setFreshnessState(DataFreshnessState.DEMO_DATA, 0L)
        assertEquals(DataFreshnessState.DEMO_DATA, recovered.freshnessState)
        assertEquals(0L, recovered.dataAgeSeconds)
    }
}
