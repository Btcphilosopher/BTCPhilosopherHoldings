package com.example.data.repository

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.example.core.model.*
import com.example.core.simulation.PlantSimulatorEngine
import com.example.data.local.*
import com.example.data.remote.HistorianGatewayAdapter
import com.example.data.remote.HydrogridApiClient
import com.example.data.remote.ReadOnlyOpcUaHistorianAdapter
import com.example.data.remote.RetrofitHydrogridApiClient
import com.example.data.sync.TelemetrySyncWorker
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.TimeUnit

class HydrogridRepository(
    private val context: Context,
    private val database: HydrogridDatabase = HydrogridDatabase.getInstance(context),
    val preferencesStore: TerminalPreferencesStore = TerminalPreferencesStore(context),
    val credentialManager: KeystoreCredentialManager = KeystoreCredentialManager(context),
    private val apiClient: HydrogridApiClient = RetrofitHydrogridApiClient(),
    private val historianAdapter: HistorianGatewayAdapter = ReadOnlyOpcUaHistorianAdapter(),
    private val simulator: PlantSimulatorEngine = PlantSimulatorEngine()
) {
    private val dao = database.hydrogridDao()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _snapshot = MutableStateFlow(simulator.snapshot())
    val snapshot: StateFlow<PlantSnapshot> = _snapshot.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val wallClockFormatter = SimpleDateFormat("HH:mm:ss 'UTC'", Locale.UK).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    private var telemetryFrozenForStaleDemo = false

    init {
        // Hydrate role & boundary preferences from DataStore
        scope.launch {
            preferencesStore.preferencesFlow.collect { prefs ->
                simulator.setRole(prefs.selectedRole)
                simulator.setElectricalBoundary(prefs.electricalBoundary)
                _snapshot.value = simulator.snapshot()
            }
        }

        // Observe Room pending queue count & conflicts
        scope.launch {
            dao.observePendingActions().collect { pending ->
                val conflictMsg = pending.firstOrNull { it.conflictMessage != null }?.conflictMessage
                _snapshot.value = _snapshot.value.copy(
                    pendingSyncCount = pending.size,
                    lastSyncConflict = conflictMsg
                )
            }
        }

        // Start 1-second simulation & wall-clock loop
        scope.launch {
            while (isActive) {
                delay(1000L)
                val wallStr = wallClockFormatter.format(Date())
                if (telemetryFrozenForStaleDemo) {
                    // Wall clock advances while telemetry stays frozen -> data age rises -> STALE!
                    _snapshot.value = simulator.updateWallClock(wallStr, incrementDataAge = true)
                } else {
                    simulator.updateWallClock(wallStr, incrementDataAge = false)
                    val stepped = simulator.step(1.0)
                    _snapshot.value = stepped.copy(
                        pendingSyncCount = _snapshot.value.pendingSyncCount,
                        lastSyncConflict = _snapshot.value.lastSyncConflict
                    )
                    persistSnapshotToRoom(stepped)
                }
            }
        }

        schedulePeriodicSync()
    }

    fun clearBanner() {
        _statusBanner.value = null
    }

    fun setSimSpeed(speed: SimSpeed) {
        _snapshot.value = simulator.setSpeed(speed)
    }

    fun resetSimulation() {
        telemetryFrozenForStaleDemo = false
        val role = _snapshot.value.activeRole
        _snapshot.value = simulator.reset(role)
        _statusBanner.value = "Simulation reset to initial Aberdeen Green H2 Works baseline (360.0 kg/h, 20.0 MW, 12,400 kg)."
    }

    fun simulateStaleTelemetryTest(stale: Boolean) {
        telemetryFrozenForStaleDemo = stale
        _snapshot.value = if (stale) {
            simulator.setFreshnessState(DataFreshnessState.STALE, dataAgeSeconds = 35L)
        } else {
            simulator.setFreshnessState(DataFreshnessState.DEMO_DATA, dataAgeSeconds = 0L)
        }
    }

    fun triggerCachedFallbackMode() {
        telemetryFrozenForStaleDemo = true
        _snapshot.value = simulator.setFreshnessState(DataFreshnessState.CACHED, dataAgeSeconds = 12L)
        _statusBanner.value = "Viewing Room-cached plant state (CACHED). Advancing wall clock does not imply fresh telemetry."
    }

    fun recoverLiveTelemetry() {
        telemetryFrozenForStaleDemo = false
        scope.launch {
            val prefs = preferencesStore.preferencesFlow.first()
            if (prefs.useRemoteBackend) {
                val res = apiClient.checkConnection(
                    prefs.backendBaseUrl,
                    prefs.selectedRole.name,
                    credentialManager.getApiToken()
                )
                if (res.isSuccess) {
                    _snapshot.value = simulator.setFreshnessState(DataFreshnessState.CONNECTED, 0L)
                    _statusBanner.value = "Connected to FastAPI simulation backend."
                } else {
                    _snapshot.value = simulator.setFreshnessState(DataFreshnessState.CACHED, 5L)
                    _statusBanner.value = "Backend unreachable (${res.exceptionOrNull()?.message}); serving local Room cache."
                }
            } else {
                _snapshot.value = simulator.setFreshnessState(DataFreshnessState.DEMO_DATA, 0L)
                _statusBanner.value = "Telemetry recovered (DEMO DATA active)."
            }
        }
    }

    fun setRole(role: UserRole) {
        scope.launch { preferencesStore.setSelectedRole(role) }
        _snapshot.value = simulator.setRole(role)
    }

    fun setElectricalBoundary(boundary: ElectricalBoundary) {
        scope.launch { preferencesStore.setElectricalBoundary(boundary) }
        _snapshot.value = simulator.setElectricalBoundary(boundary)
    }

    fun registerSample(
        batchId: String,
        sourceType: ReadingSourceType,
        purityPct: Double,
        moisturePpm: Double,
        oxygenPpm: Double,
        analystName: String,
        attachmentRef: String?,
        notes: String,
        correctionReason: String? = null
    ) {
        val key = UUID.randomUUID().toString()
        val res = simulator.registerSample(
            batchId = batchId,
            sourceType = sourceType,
            purityPct = purityPct,
            moisturePpm = moisturePpm,
            oxygenPpm = oxygenPpm,
            analystName = analystName,
            attachmentRef = attachmentRef,
            notes = notes,
            correctionReason = correctionReason,
            idempotencyKey = key
        )
        handleMutationResult("REGISTER_SAMPLE", batchId, "purity=$purityPct,moisture=$moisturePpm", key, res)
    }

    fun authoriseBatchRelease(batchId: String, authoriserName: String) {
        val key = UUID.randomUUID().toString()
        val res = simulator.authoriseBatchRelease(batchId, authoriserName, key)
        handleMutationResult("RELEASE_BATCH", batchId, "authoriser=$authoriserName", key, res)
    }

    fun advanceDispatchOrder(
        orderId: String,
        targetStage: DispatchStage,
        confirmedTransferKg: Double? = null,
        reason: String? = null
    ) {
        val key = UUID.randomUUID().toString()
        val res = simulator.advanceDispatchOrder(orderId, targetStage, confirmedTransferKg, reason, key)
        handleMutationResult("DISPATCH_${targetStage.name}", orderId, "confirmed=$confirmedTransferKg", key, res)
    }

    fun updateStorageLimits(bankId: String, minKg: Double, maxKg: Double) {
        val key = UUID.randomUUID().toString()
        val res = simulator.updateStorageLimits(bankId, minKg, maxKg)
        handleMutationResult("STORAGE_LIMITS", bankId, "min=$minKg,max=$maxKg", key, res)
    }

    fun acknowledgeAlert(alertId: String) {
        _snapshot.value = simulator.acknowledgeAlert(alertId)
        _statusBanner.value = "Alert $alertId acknowledged. Physical condition remains flagged until verified cleared."
    }

    fun injectEquipmentFault(equipmentTag: String, reason: String) {
        _snapshot.value = simulator.injectEquipmentFault(equipmentTag, reason)
        _statusBanner.value = "Fault raised on $equipmentTag: $reason"
    }

    fun resolveMaintenanceFault(workOrderId: String) {
        val key = UUID.randomUUID().toString()
        val res = simulator.resolveMaintenanceFault(workOrderId)
        handleMutationResult("RESOLVE_FAULT", workOrderId, "closed", key, res)
    }

    fun addShiftHandover(shiftName: String, operatorName: String, summary: String) {
        _snapshot.value = simulator.addShiftHandover(shiftName, operatorName, summary)
        _statusBanner.value = "Shift handover logged."
    }

    fun updateSimulationConfig(config: SimulationConfig) {
        _snapshot.value = simulator.updateSimulationConfig(config)
        _statusBanner.value = "Plant capacity & efficiency assumptions updated."
    }

    fun buildPeriodReport(periodLabel: String, hoursWindow: Double): PeriodReportMetrics =
        simulator.buildPeriodReport(periodLabel, hoursWindow)

    suspend fun probeHistorianProvenance(): Map<String, String> =
        historianAdapter.probeTagProvenance()

    suspend fun testRemoteBackend(url: String): String {
        val token = credentialManager.getApiToken()
        val role = _snapshot.value.activeRole.name
        val res = apiClient.checkConnection(url, role, token)
        return res.fold(
            onSuccess = {
                _snapshot.value = simulator.setFreshnessState(DataFreshnessState.CONNECTED, 0L)
                "Connected: ${it.plantName} (v${it.version})"
            },
            onFailure = { "Connection failed: ${it.message}" }
        )
    }

    fun triggerImmediateWorkManagerSync() {
        val request = OneTimeWorkRequestBuilder<TelemetrySyncWorker>().build()
        WorkManager.getInstance(context).enqueue(request)
        _statusBanner.value = "Background WorkManager sync queued."
    }

    fun resolveOfflineConflictDiscard(idempotencyKey: String) {
        scope.launch {
            dao.deletePendingAction(idempotencyKey)
        }
    }

    fun observePendingActions(): Flow<List<PendingSyncActionEntity>> = dao.observePendingActions()

    private fun handleMutationResult(
        actionType: String,
        entityId: String,
        payloadJson: String,
        idempotencyKey: String,
        result: Result<PlantSnapshot>
    ) {
        result.onSuccess { updated ->
            _snapshot.value = updated
            scope.launch {
                val prefs = preferencesStore.preferencesFlow.first()
                if (prefs.useRemoteBackend) {
                    dao.enqueueAction(
                        PendingSyncActionEntity(
                            idempotencyKey = idempotencyKey,
                            actionType = actionType,
                            entityId = entityId,
                            payloadJson = payloadJson,
                            actorRole = updated.activeRole.name,
                            expectedVersion = updated.version - 1,
                            createdAtEpochMs = System.currentTimeMillis()
                        )
                    )
                    triggerImmediateWorkManagerSync()
                }
                persistSnapshotToRoom(updated)
            }
        }.onFailure { err ->
            _snapshot.value = simulator.snapshot()
            _statusBanner.value = err.message ?: "Action rejected"
        }
    }

    private suspend fun persistSnapshotToRoom(snap: PlantSnapshot) {
        dao.upsertSnapshot(
            CachedSnapshotEntity(
                plantName = snap.plantName,
                h2OutputKgHr = snap.h2OutputKgPerHr,
                electrolyserPowerMw = snap.electrolyserPowerMw,
                storageInventoryKg = snap.storageInventoryKg,
                dispatchTodayKg = snap.dispatchTodayKg,
                simTimeIso = snap.simTimeIso,
                cachedAtEpochMs = System.currentTimeMillis(),
                version = snap.version,
                payloadSummaryJson = "h2=${snap.h2OutputKgPerHr},stored=${snap.storageInventoryKg}"
            )
        )
        val auditEntities = snap.auditLog.take(25).map {
            CachedAuditLogEntity(
                id = it.id,
                timestampIso = it.timestampIso,
                actorRole = it.actorRole.name,
                action = it.action,
                entityRef = it.entityRef,
                detail = it.detail,
                idempotencyKey = it.idempotencyKey
            )
        }
        dao.insertAuditEntries(auditEntities)
    }

    private fun schedulePeriodicSync() {
        val req = PeriodicWorkRequestBuilder<TelemetrySyncWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "hydrogrid_periodic_sync",
            ExistingPeriodicWorkPolicy.KEEP,
            req
        )
    }
}
