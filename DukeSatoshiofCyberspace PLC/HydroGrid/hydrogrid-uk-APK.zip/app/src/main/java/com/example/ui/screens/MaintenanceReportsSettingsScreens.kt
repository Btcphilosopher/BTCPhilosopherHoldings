package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.model.*
import com.example.data.local.PendingSyncActionEntity
import com.example.data.local.TerminalPreferences
import com.example.ui.components.StatusPill
import com.example.ui.components.StatusTone
import com.example.ui.components.toTone
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun MaintenanceScreen(
    snapshot: PlantSnapshot,
    onAcknowledgeAlert: (String) -> Unit,
    onResolveFault: (String) -> Unit,
    onAddHandover: (String, String, String) -> Unit,
    onInjectFault: (String, String) -> Unit
) {
    var handoverShift by remember { mutableStateOf("Back Shift (14:00–22:00)") }
    var handoverOperator by remember { mutableStateOf("D. Nairn") }
    var handoverNote by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        WorkspaceSectionHeader(
            title = "Maintenance, Equipment Register & Shift Handover",
            subtitle = "Acknowledging alerts does NOT clear physical plant conditions • Safety-instrumented ESD & gas interlocks remain on independent hardware"
        )

        // System Boundary Card
        Surface(
            color = StatusDemoBg,
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, SaltireBlue),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "SYSTEM BOUNDARY: This Android terminal is strictly read-only/monitoring for plant control, gas detection, ESD, and protective interlocks. Physical fault clearance requires authorised Maintenance sign-off after field verification.",
                style = MaterialTheme.typography.bodySmall.copy(color = MidnightNavy, fontWeight = FontWeight.SemiBold),
                modifier = Modifier.padding(12.dp)
            )
        }

        // Active Alerts
        Surface(
            color = PureWhite,
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, ThinRuleBlue),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("ACTIVE ALERTS & ACKNOWLEDGEMENTS", style = MaterialTheme.typography.titleSmall.copy(color = MidnightNavy, fontWeight = FontWeight.Bold))
                    OutlinedButton(onClick = { onInjectFault("CMP-501", "Diaphragm interstage pressure trip (Demo)") }) {
                        Text("Simulate Equipment Fault")
                    }
                }
                snapshot.alerts.forEach { alert ->
                    Surface(
                        color = if (alert.physicalConditionResolved) StatusHealthyBg else StatusAmberBg,
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, if (alert.physicalConditionResolved) StatusHealthy else StatusAmber),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("${alert.severity} • ${alert.equipmentTag}: ${alert.message}", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = InkPrimary))
                                Text(
                                    "Ack: ${if (alert.acknowledged) "Yes (${alert.acknowledgedBy})" else "Pending"} • Physical Condition Resolved: ${if (alert.physicalConditionResolved) "Verified Cleared" else "UNRESOLVED"}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = InkSecondary)
                                )
                            }
                            if (!alert.acknowledged) {
                                Button(onClick = { onAcknowledgeAlert(alert.id) }, colors = ButtonDefaults.buttonColors(containerColor = StatusAmber)) {
                                    Text("Acknowledge")
                                }
                            }
                        }
                    }
                }
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            // Work Orders & Equipment Register
            Surface(
                color = PureWhite,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, ThinRuleBlue),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("WORK ORDERS & INSPECTIONS", style = MaterialTheme.typography.titleSmall.copy(color = MidnightNavy, fontWeight = FontWeight.Bold))
                    snapshot.workOrders.forEach { wo ->
                        Surface(color = SoftPanelBg, shape = RoundedCornerShape(6.dp), border = BorderStroke(1.dp, HairlineBorder), modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("${wo.id} • ${wo.equipmentTag} • ${wo.category} (${wo.priority})", style = MaterialTheme.typography.labelMedium.copy(color = SaltireBlue, fontWeight = FontWeight.Bold))
                                    Text(wo.title, style = MaterialTheme.typography.bodySmall)
                                    Text("Status: ${wo.status} • Assigned: ${wo.assignedTo} • Due: ${wo.dueDateIso}", style = MaterialTheme.typography.labelSmall.copy(color = InkMuted))
                                }
                                if (wo.physicalFaultActive && wo.status != "CLOSED") {
                                    Button(onClick = { onResolveFault(wo.id) }, colors = ButtonDefaults.buttonColors(containerColor = StatusHealthy)) {
                                        Text("Clear Physical Fault")
                                    }
                                }
                            }
                        }
                    }

                    HorizontalDivider(color = ThinRuleBlue)
                    Text("EQUIPMENT REGISTER", style = MaterialTheme.typography.labelSmall.copy(color = InkSecondary, fontWeight = FontWeight.Bold))
                    snapshot.equipment.forEach { eq ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("${eq.tag} • ${eq.name} (${String.format(Locale.UK, "%,.0f", eq.operatingHours)} h)", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                            StatusPill(eq.state.label, eq.state.toTone())
                        }
                    }
                }
            }

            // Spare Parts & Shift Handovers
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(
                    color = PureWhite,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, ThinRuleBlue),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("CRITICAL SPARE PARTS", style = MaterialTheme.typography.titleSmall.copy(color = MidnightNavy, fontWeight = FontWeight.Bold))
                        snapshot.spareParts.forEach { sp ->
                            MetricPairRow("${sp.sku} • ${sp.name}", "On hand: ${sp.onHand} (Min ${sp.reorderPoint}) • £${String.format(Locale.UK, "%,.0f", sp.unitCostGbp)}")
                        }
                    }
                }

                Surface(
                    color = PureWhite,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, ThinRuleBlue),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("SHIFT HANDOVER LOG", style = MaterialTheme.typography.titleSmall.copy(color = MidnightNavy, fontWeight = FontWeight.Bold))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = handoverShift, onValueChange = { handoverShift = it }, label = { Text("Shift") }, singleLine = true, modifier = Modifier.weight(1f))
                            OutlinedTextField(value = handoverOperator, onValueChange = { handoverOperator = it }, label = { Text("Operator") }, singleLine = true, modifier = Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(value = handoverNote, onValueChange = { handoverNote = it }, label = { Text("Handover summary") }, singleLine = true, modifier = Modifier.weight(1f))
                            Button(
                                onClick = {
                                    if (handoverNote.isNotBlank()) {
                                        onAddHandover(handoverShift, handoverOperator, handoverNote)
                                        handoverNote = ""
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SaltireBlue)
                            ) { Text("Log") }
                        }
                        snapshot.shiftHandovers.forEach { sh ->
                            Surface(color = SoftPanelBg, shape = RoundedCornerShape(6.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text("${sh.shiftName} • ${sh.operatorName} • ${sh.timestampIso}", style = MaterialTheme.typography.labelSmall.copy(color = SaltireBlue, fontWeight = FontWeight.Bold))
                                    Text(sh.summary, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReportsScreen(
    snapshot: PlantSnapshot,
    onBuildReport: (String, Double) -> PeriodReportMetrics
) {
    var selectedPeriod by remember { mutableStateOf("Daily (24h)") }
    var customHoursStr by remember { mutableStateOf("12") }
    val hours = when (selectedPeriod) {
        "Shift (8h)" -> 8.0
        "Daily (24h)" -> 24.0
        else -> (customHoursStr.toDoubleOrNull() ?: 12.0).coerceIn(1.0, 720.0)
    }
    val report = remember(snapshot.version, selectedPeriod, hours) {
        onBuildReport(selectedPeriod, hours)
    }
    val t = snapshot.tariffs

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        WorkspaceSectionHeader(
            title = "Energy, Operating Cost & Production Reporting",
            subtitle = "Tariff Basis: ${t.tariffEffectiveDate} • Allocation: ${t.allocationMethod}"
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf("Shift (8h)", "Daily (24h)", "Custom").forEach { period ->
                FilterChip(
                    selected = selectedPeriod == period,
                    onClick = { selectedPeriod = period },
                    label = { Text(period) }
                )
            }
            if (selectedPeriod == "Custom") {
                OutlinedTextField(
                    value = customHoursStr,
                    onValueChange = { customHoursStr = it },
                    label = { Text("Window (hours)") },
                    singleLine = true,
                    modifier = Modifier.width(150.dp)
                )
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatPanelCard(
                title = "H₂ Produced / Plan",
                value = "${String.format(Locale.UK, "%,.0f", report.h2ProducedKg)} kg",
                detail = "${String.format(Locale.UK, "%.1f", report.productionVsPlanPct)}% vs plan • Util ${String.format(Locale.UK, "%.1f", report.equipmentUtilisationPct)}%",
                modifier = Modifier.weight(1f)
            )
            StatPanelCard(
                title = "Dispatched / Inv. Delta",
                value = "${String.format(Locale.UK, "%,.0f", report.h2DispatchedKg)} kg",
                detail = "Net inventory Δ: ${String.format(Locale.UK, "%+,.0f", report.inventoryChangeKg)} kg",
                modifier = Modifier.weight(1f)
            )
            StatPanelCard(
                title = "Specific Electricity & Water",
                value = report.specificElectricityKwhPerKg?.let { "${String.format(Locale.UK, "%.1f", it)} kWh/kg" } ?: "—",
                detail = "Water: ${report.specificWaterLPerKg?.let { "${String.format(Locale.UK, "%.1f", it)} L/kg" } ?: "—"} • Comp: ${String.format(Locale.UK, "%.2f", report.compressionEnergyMwh)} MWh",
                modifier = Modifier.weight(1f)
            )
            StatPanelCard(
                title = "Cost / kg Produced & Dispatched",
                value = report.costPerKgProducedGbp?.let { "£${String.format(Locale.UK, "%.2f", it)} / kg" } ?: "—",
                detail = "Dispatched basis: ${report.costPerKgDispatchedGbp?.let { "£${String.format(Locale.UK, "%.2f", it)} / kg" } ?: "—"}",
                modifier = Modifier.weight(1f)
            )
        }

        // Dated Fictional Tariffs & Carbon Intensity Accounting Boundary
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Surface(
                color = PureWhite,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, ThinRuleBlue),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("DATED FICTIONAL TARIFF ASSUMPTIONS", style = MaterialTheme.typography.titleSmall.copy(color = MidnightNavy, fontWeight = FontWeight.Bold))
                    HorizontalDivider(color = ThinRuleBlue)
                    MetricPairRow("Effective Date", t.tariffEffectiveDate)
                    MetricPairRow("Electricity Tariff", "£${String.format(Locale.UK, "%.2f", t.electricityTariffGbpPerMwh)} / MWh (${String.format(Locale.UK, "%.2f", report.totalElectricityMwh)} MWh used)")
                    MetricPairRow("Feedwater Tariff", "£${String.format(Locale.UK, "%.2f", t.waterTariffGbpPerM3)} / m³ (${String.format(Locale.UK, "%.1f", report.totalWaterFeedM3)} m³ used)")
                    MetricPairRow("Consumables (Resin/N₂/Purge)", "£${String.format(Locale.UK, "%.2f", t.consumablesGbpPerKgH2)} / kg H₂")
                    MetricPairRow("Allocation Method", t.allocationMethod)
                    MetricPairRow("Period Downtime", "${String.format(Locale.UK, "%.0f", report.downtimeMinutes)} min")
                }
            }

            Surface(
                color = PureWhite,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, StatusAmber.copy(alpha = 0.6f)),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("CARBON INTENSITY ACCOUNTING TRANSPARENCY", style = MaterialTheme.typography.titleSmall.copy(color = MidnightNavy, fontWeight = FontWeight.Bold))
                    HorizontalDivider(color = ThinRuleBlue)
                    MetricPairRow("Calculated Carbon Intensity", report.calculatedCarbonIntensityKgCo2PerKgH2?.let { "${String.format(Locale.UK, "%.2f", it)} kg CO₂e / kg H₂" } ?: "—")
                    MetricPairRow("Accounting Boundary", t.carbonIntensityBoundary)
                    MetricPairRow("Grid Residual Emission Factor", "${String.format(Locale.UK, "%.1f", t.gridEmissionFactorGCo2PerKwh)} gCO₂e/kWh")
                    MetricPairRow("Assumed Renewable PPA Share", "${String.format(Locale.UK, "%.0f", t.renewablePpaSharePct)}% (Does not imply verified RFNBO/LCHS cert.)")
                    MetricPairRow("Factor Source", t.carbonFactorSource)
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    snapshot: PlantSnapshot,
    preferences: TerminalPreferences,
    pendingSyncActions: List<PendingSyncActionEntity>,
    backendTestResult: String?,
    hasStoredToken: Boolean,
    onSaveBackendConfig: (String, Boolean) -> Unit,
    onSaveApiToken: (String) -> Unit,
    onTestConnection: (String) -> Unit,
    onSelectRole: (UserRole) -> Unit,
    onSetReducedMotion: (Boolean) -> Unit,
    onSimulateStale: (Boolean) -> Unit,
    onTriggerCached: () -> Unit,
    onRecoverTelemetry: () -> Unit,
    onTriggerSync: () -> Unit,
    onDiscardConflict: (String) -> Unit,
    onUpdateSimConfig: (SimulationConfig) -> Unit
) {
    var urlInput by remember(preferences.backendBaseUrl) { mutableStateOf(preferences.backendBaseUrl) }
    var useRemote by remember(preferences.useRemoteBackend) { mutableStateOf(preferences.useRemoteBackend) }
    var tokenInput by remember { mutableStateOf("") }
    var capInput by remember(snapshot.simConfig.electrolyserMaxCapacityKgHr) {
        mutableStateOf(snapshot.simConfig.electrolyserMaxCapacityKgHr.toInt().toString())
    }
    var powerInput by remember(snapshot.simConfig.targetPowerMw) {
        mutableStateOf(snapshot.simConfig.targetPowerMw.toString())
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        WorkspaceSectionHeader(
            title = "Terminal Settings, Security & Resilience",
            subtitle = "Keystore-backed credentials • Replaceable FastAPI client • DataStore preferences • Offline Room sync & stale telemetry recovery"
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            // Backend & Keystore Credentials
            Surface(
                color = PureWhite,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, ThinRuleBlue),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("FASTAPI BACKEND & KEYSTORE VAULT", style = MaterialTheme.typography.titleSmall.copy(color = MidnightNavy, fontWeight = FontWeight.Bold))
                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = { urlInput = it },
                        label = { Text("FastAPI Simulation Server URL") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Sync mutations with remote FastAPI backend", style = MaterialTheme.typography.bodySmall)
                        Switch(checked = useRemote, onCheckedChange = {
                            useRemote = it
                            onSaveBackendConfig(urlInput, it)
                        })
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { onSaveBackendConfig(urlInput, useRemote) }, colors = ButtonDefaults.buttonColors(containerColor = SaltireBlue)) {
                            Text("Save URL")
                        }
                        OutlinedButton(onClick = { onTestConnection(urlInput) }) {
                            Text("Test Health Check")
                        }
                    }
                    backendTestResult?.let {
                        Text(it, style = MaterialTheme.typography.labelMedium.copy(color = SaltireBlue))
                    }

                    HorizontalDivider(color = ThinRuleBlue)
                    Text("ANDROID KEYSTORE CREDENTIALS (AES-256-GCM)", style = MaterialTheme.typography.labelSmall.copy(color = InkSecondary, fontWeight = FontWeight.Bold))
                    Text("Token Status: ${if (hasStoredToken) "Encrypted token stored in AndroidKeyStore" else "No token saved (Demo Role Header active)"}", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = tokenInput, onValueChange = { tokenInput = it }, label = { Text("Operator / Gateway Bearer Token") }, singleLine = true, modifier = Modifier.weight(1f))
                        Button(onClick = {
                            onSaveApiToken(tokenInput)
                            tokenInput = ""
                        }) { Text("Encrypt & Store") }
                    }
                }
            }

            // Telemetry Resilience, Accessibility & Simulation Config
            Surface(
                color = PureWhite,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, ThinRuleBlue),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("TELEMETRY RESILIENCE & OFFLINE RECOVERY", style = MaterialTheme.typography.titleSmall.copy(color = MidnightNavy, fontWeight = FontWeight.Bold))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { onSimulateStale(true) }, modifier = Modifier.testTag("simulate_stale_btn")) {
                            Text("Simulate Stale Data")
                        }
                        OutlinedButton(onClick = onTriggerCached) {
                            Text("Force Cached Mode")
                        }
                        Button(onClick = onRecoverTelemetry, colors = ButtonDefaults.buttonColors(containerColor = StatusHealthy), modifier = Modifier.testTag("recover_telemetry_btn")) {
                            Text("Recover Telemetry")
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Reduced Motion (pause schematic flow animation)", style = MaterialTheme.typography.bodySmall)
                        Switch(checked = preferences.reducedMotion, onCheckedChange = onSetReducedMotion)
                    }

                    HorizontalDivider(color = ThinRuleBlue)
                    Text("SIMULATION CAPACITY & POWER SETPOINT", style = MaterialTheme.typography.labelSmall.copy(color = InkSecondary, fontWeight = FontWeight.Bold))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = capInput, onValueChange = { capInput = it }, label = { Text("Max H₂ Cap (kg/h)") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = powerInput, onValueChange = { powerInput = it }, label = { Text("Target Power (MW)") }, singleLine = true, modifier = Modifier.weight(1f))
                        Button(onClick = {
                            val cap = capInput.toDoubleOrNull() ?: snapshot.simConfig.electrolyserMaxCapacityKgHr
                            val mw = powerInput.toDoubleOrNull() ?: snapshot.simConfig.targetPowerMw
                            onUpdateSimConfig(snapshot.simConfig.copy(electrolyserMaxCapacityKgHr = cap, targetPowerMw = mw))
                        }) { Text("Apply") }
                    }

                    HorizontalDivider(color = ThinRuleBlue)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("WORKMANAGER SYNC QUEUE (${pendingSyncActions.size} pending)", style = MaterialTheme.typography.labelSmall.copy(color = InkSecondary, fontWeight = FontWeight.Bold))
                        TextButton(onClick = onTriggerSync) { Text("Sync Now") }
                    }
                    pendingSyncActions.forEach { act ->
                        Surface(color = if (act.conflictMessage != null) StatusFaultBg else SoftPanelBg, shape = RoundedCornerShape(4.dp), modifier = Modifier.fillMaxWidth()) {
                            Row(modifier = Modifier.padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("${act.actionType} (${act.entityId}) • ${act.conflictMessage ?: "Queued"}", style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f))
                                if (act.conflictMessage != null) {
                                    TextButton(onClick = { onDiscardConflict(act.idempotencyKey) }) { Text("Resolve") }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Role Permissions Matrix
        Surface(
            color = PureWhite,
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, ThinRuleBlue),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("ROLE-BASED ACCESS CONTROL (ENFORCED IN APP & BACKEND)", style = MaterialTheme.typography.titleSmall.copy(color = MidnightNavy, fontWeight = FontWeight.Bold))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    UserRole.entries.forEach { role ->
                        FilterChip(
                            selected = snapshot.activeRole == role,
                            onClick = { onSelectRole(role) },
                            label = { Text(role.title) }
                        )
                    }
                }
                Text("Active Role Permissions: ${snapshot.activeRole.permissionsSummary}", style = MaterialTheme.typography.bodySmall.copy(color = SaltireBlue))
            }
        }
    }
}
