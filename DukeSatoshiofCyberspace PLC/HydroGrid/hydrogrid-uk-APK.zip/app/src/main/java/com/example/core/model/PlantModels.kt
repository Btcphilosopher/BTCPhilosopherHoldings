package com.example.core.model

enum class Workspace(val label: String) {
    OVERVIEW("Overview"),
    WATER("Water"),
    ELECTROLYSIS("Electrolysis"),
    COMPRESSION("Compression"),
    STORAGE("Storage"),
    QUALITY("Quality"),
    DISPATCH("Dispatch"),
    MAINTENANCE("Maintenance"),
    REPORTS("Reports"),
    SETTINGS("Settings")
}

enum class DataFreshnessState(val badgeLabel: String) {
    DEMO_DATA("DEMO DATA"),
    CONNECTED("CONNECTED"),
    CACHED("CACHED"),
    STALE("STALE")
}

enum class SimSpeed(val multiplier: Int, val label: String) {
    PAUSED(0, "Paused"),
    NORMAL_1X(1, "1x Normal"),
    ACCEL_10X(10, "10x Demo"),
    ACCEL_60X(60, "60x Fast")
}

enum class ElectricalBoundary(val label: String, val description: String) {
    COMPLETE_PLANT(
        "Complete Plant",
        "Includes PEM stacks, rectifier losses, water treatment, drying, cooling, and compression."
    ),
    STACK_ONLY(
        "Stack-Only",
        "DC electrical input at PEM electrolyser stack terminals only."
    )
}

enum class EquipmentState(val label: String) {
    RUNNING("RUNNING"),
    STANDBY("STANDBY"),
    FAULT("FAULT"),
    MAINTENANCE("MAINTENANCE"),
    BLOCKED("BLOCKED FLOW")
}

enum class DataQualityFlag(val label: String) {
    LIVE("LIVE"),
    ESTIMATED("ESTIMATED"),
    STALE("STALE"),
    FAULTY("FAULTY"),
    MANUAL("MANUAL")
}

enum class ReadingSourceType(val label: String) {
    CONTINUOUS_ANALYSER("Continuous Analyser"),
    DISCRETE_SAMPLE("Discrete Lab Sample"),
    MANUAL_ENTRY("Manual Record")
}

enum class UserRole(val title: String, val permissionsSummary: String) {
    OPERATOR("Operator", "Monitor telemetry, start/stop sim, acknowledge alerts, log shift handover"),
    SUPERVISOR("Supervisor", "All Operator actions + authorise batch release & overrides"),
    LAB_STAFF("Lab Staff", "Register samples, enter/correct lab findings, submit batch review"),
    DISPATCH("Dispatch", "Check-in trailers, authorise & reconcile H2 loading"),
    MAINTENANCE("Maintenance", "Log inspections, manage work orders, clear physical faults"),
    ADMIN("Administrator", "Configure capacities, tariffs, backend URL, credentials & roles")
}

enum class ProcessStageId(val title: String, val tag: String) {
    WATER_TREATMENT("Water Treatment Skid", "WT-101"),
    ELECTROLYSIS("PEM Electrolysis Array", "ELX-200"),
    GAS_SEPARATION("Gas Separation Vessels", "SEP-301"),
    DRYING_PURIFICATION("Drying & Purification", "PUR-401"),
    COMPRESSION("Multi-Stage Compression", "CMP-501"),
    STORAGE("High-Pressure Storage Banks", "STR-600"),
    DISPATCH("Tube-Trailer Loading Bay", "DSP-701")
}

data class EquipmentUnit(
    val id: String,
    val stageId: ProcessStageId,
    val name: String,
    val tag: String,
    val state: EquipmentState,
    val operatingHours: Double,
    val primaryMetricLabel: String,
    val primaryMetricValue: String,
    val secondaryMetricLabel: String,
    val secondaryMetricValue: String,
    val temperatureC: Double,
    val pressureBar: Double,
    val sensorProvenance: String,
    val dataQuality: DataQualityFlag,
    val maintenanceStatus: String,
    val historySeries: List<Float>,
    val activeAlertSummary: String? = null
)

data class StorageBank(
    val id: String,
    val name: String,
    val inventoryKg: Double,
    val maxCapacityKg: Double,
    val operatingMinKg: Double,
    val operatingMaxKg: Double,
    val pressureBar: Double,
    val temperatureC: Double,
    val vesselVolumeM3: Double,
    val state: EquipmentState,
    val maintenanceStatus: String,
    val dataQuality: DataQualityFlag,
    val linkedBatchId: String
) {
    val capacityNormalisedPct: Double
        get() = if (maxCapacityKg > 0.0) (inventoryKg / maxCapacityKg) * 100.0 else 0.0

    val availableHeadroomKg: Double
        get() = (operatingMaxKg - inventoryKg).coerceAtLeast(0.0)

    val isAtOperatingLimit: Boolean
        get() = inventoryKg >= operatingMaxKg - 0.5
}

data class CompressorUnit(
    val id: String,
    val name: String,
    val state: EquipmentState,
    val suctionBar: Double,
    val dischargeBar: Double,
    val dischargeTempC: Double,
    val powerKw: Double,
    val throughputKgPerHr: Double,
    val maintenanceStatus: String,
    val dataQuality: DataQualityFlag,
    val blockedReason: String? = null
)

data class WaterElectrolysisMetrics(
    val feedwaterFlowLPerHr: Double,
    val treatedWaterAvailableL: Double,
    val treatedTankCapacityL: Double,
    val roRejectLossLPerHr: Double,
    val ediBlowdownLossLPerHr: Double,
    val stoichiometricWaterUsedKgPerHr: Double,
    val conductivityMicroSPerCm: Double,
    val tocPpb: Double,
    val waterProvenance: String,
    val activeModules: Int,
    val totalModules: Int,
    val stackDcPowerMw: Double,
    val auxBalanceOfPlantMw: Double,
    val compressionPowerMw: Double,
    val totalPlantPowerMw: Double,
    val h2OutputKgPerHr: Double,
    val o2OutputKgPerHr: Double,
    val h2PurificationLossKgPerHr: Double,
    val stackOperatingHours: Double,
    val waterFlowHistory: List<Float>,
    val powerHistoryMw: List<Float>
) {
    fun effectivePowerMw(boundary: ElectricalBoundary): Double = when (boundary) {
        ElectricalBoundary.COMPLETE_PLANT -> totalPlantPowerMw
        ElectricalBoundary.STACK_ONLY -> stackDcPowerMw
    }

    fun specificElectricityKwhPerKg(boundary: ElectricalBoundary): Double? {
        if (h2OutputKgPerHr <= 0.01) return null
        return (effectivePowerMw(boundary) * 1000.0) / h2OutputKgPerHr
    }

    val specificWaterFeedLPerKg: Double?
        get() = if (h2OutputKgPerHr > 0.01) feedwaterFlowLPerHr / h2OutputKgPerHr else null
}

enum class LabReviewStatus(val label: String) {
    SAMPLE_PENDING("SAMPLE PENDING"),
    IN_REVIEW("IN REVIEW"),
    RETEST_REQUIRED("RETEST REQUIRED"),
    REVIEWED_PASS("REVIEWED — WITHIN SPEC"),
    REVIEWED_FAIL("REVIEWED — OUT OF SPEC")
}

enum class BatchReleaseStatus(val label: String) {
    HOLD_FOR_REVIEW("HOLD FOR REVIEW"),
    QUARANTINED("QUARANTINED"),
    RELEASED("AUTHORISED RELEASE")
}

data class AcceptanceSpec(
    val version: String,
    val standardName: String,
    val minPurityPct: Double,
    val maxMoisturePpm: Double,
    val maxOxygenPpm: Double,
    val maxNitrogenPpm: Double
)

data class LabSample(
    val sampleId: String,
    val batchId: String,
    val timestampIso: String,
    val sourceType: ReadingSourceType,
    val purityPct: Double?,
    val moisturePpm: Double?,
    val oxygenPpm: Double?,
    val predictedPurityPct: Double,
    val predictedMoisturePpm: Double,
    val attachmentRef: String?,
    val analystName: String,
    val notes: String,
    val isOriginalRecord: Boolean = true,
    val correctionReason: String? = null
)

data class QualityBatch(
    val batchId: String,
    val producedMassKg: Double,
    val remainingMassKg: Double,
    val storageBankId: String,
    val latestSampleTimestamp: String,
    val measuredPurityPct: Double?,
    val measuredMoisturePpm: Double?,
    val predictedPurityPct: Double,
    val predictedMoisturePpm: Double,
    val reviewStatus: LabReviewStatus,
    val releaseStatus: BatchReleaseStatus,
    val specVersion: String,
    val authorisedBy: String?,
    val authorisedAtIso: String?,
    val samples: List<LabSample>
)

enum class DispatchStage(val label: String) {
    BOOKED("Booked"),
    ARRIVED("Arrived"),
    CHECKED("Checked"),
    AUTHORISED("Authorised"),
    LOADING("Loading"),
    RECONCILED("Reconciled"),
    RELEASED("Released"),
    HELD("Held"),
    CANCELLED("Cancelled"),
    EXCEPTION("Exception")
}

data class DispatchOrder(
    val orderId: String,
    val customerName: String,
    val requiredSpecVersion: String,
    val trailerRegistration: String,
    val requestedMassKg: Double,
    val estimatedLoadedKg: Double,
    val confirmedTransferKg: Double?,
    val assignedBatchId: String,
    val sourceBankId: String,
    val stage: DispatchStage,
    val scheduledTimeIso: String,
    val deliveryDocNumber: String?,
    val holdOrExceptionReason: String? = null
)

data class MaintenanceWorkOrder(
    val id: String,
    val equipmentTag: String,
    val title: String,
    val category: String,
    val priority: String,
    val status: String,
    val assignedTo: String,
    val dueDateIso: String,
    val physicalFaultActive: Boolean
)

data class SparePartItem(
    val sku: String,
    val name: String,
    val onHand: Int,
    val reorderPoint: Int,
    val unitCostGbp: Double
)

data class ShiftHandover(
    val id: String,
    val shiftName: String,
    val operatorName: String,
    val timestampIso: String,
    val summary: String
)

data class PlantAlert(
    val id: String,
    val severity: String,
    val equipmentTag: String,
    val message: String,
    val raisedAtIso: String,
    val acknowledged: Boolean,
    val acknowledgedBy: String?,
    val physicalConditionResolved: Boolean
)

data class AuditEntry(
    val id: String,
    val timestampIso: String,
    val actorRole: UserRole,
    val action: String,
    val entityRef: String,
    val detail: String,
    val idempotencyKey: String
)

data class TariffAndCostConfig(
    val tariffEffectiveDate: String,
    val electricityTariffGbpPerMwh: Double,
    val waterTariffGbpPerM3: Double,
    val consumablesGbpPerKgH2: Double,
    val allocationMethod: String,
    val plannedDailyProductionKg: Double,
    val carbonIntensityBoundary: String,
    val gridEmissionFactorGCo2PerKwh: Double,
    val renewablePpaSharePct: Double,
    val carbonFactorSource: String
)

data class PeriodReportMetrics(
    val periodLabel: String,
    val h2ProducedKg: Double,
    val h2DispatchedKg: Double,
    val inventoryChangeKg: Double,
    val totalElectricityMwh: Double,
    val compressionEnergyMwh: Double,
    val totalWaterFeedM3: Double,
    val downtimeMinutes: Double,
    val specificElectricityKwhPerKg: Double?,
    val specificWaterLPerKg: Double?,
    val costPerKgProducedGbp: Double?,
    val costPerKgDispatchedGbp: Double?,
    val equipmentUtilisationPct: Double,
    val productionVsPlanPct: Double,
    val calculatedCarbonIntensityKgCo2PerKgH2: Double?
)

data class SimulationConfig(
    val electrolyserMaxCapacityKgHr: Double = 420.0,
    val targetPowerMw: Double = 20.0,
    val plantSpecificEnergyKwhPerKg: Double = 55.5556,
    val stackSpecificEnergyKwhPerKg: Double = 49.4,
    val waterTreatmentRecoveryPct: Double = 70.0,
    val purificationRecoveryPct: Double = 98.2,
    val bankAMaxKg: Double = 5500.0,
    val bankBMaxKg: Double = 5500.0,
    val bankCMaxKg: Double = 5500.0
)

data class PlantSnapshot(
    val plantName: String,
    val freshnessState: DataFreshnessState,
    val simTimeIso: String,
    val wallTimeIso: String,
    val simElapsedSeconds: Long,
    val dataAgeSeconds: Long,
    val simSpeed: SimSpeed,
    val electricalBoundary: ElectricalBoundary,
    val activeRole: UserRole,
    val h2OutputKgPerHr: Double,
    val electrolyserPowerMw: Double,
    val storageInventoryKg: Double,
    val dispatchTodayKg: Double,
    val producedTodayKg: Double,
    val h2LossesTodayKg: Double,
    val o2OutputTodayKg: Double,
    val waterLossTodayL: Double,
    val flowBlockedReason: String?,
    val outputTrendKgHr: List<Float>,
    val waterElectrolysis: WaterElectrolysisMetrics,
    val compressors: List<CompressorUnit>,
    val storageBanks: List<StorageBank>,
    val equipment: List<EquipmentUnit>,
    val qualityBatches: List<QualityBatch>,
    val acceptanceSpec: AcceptanceSpec,
    val dispatchOrders: List<DispatchOrder>,
    val workOrders: List<MaintenanceWorkOrder>,
    val spareParts: List<SparePartItem>,
    val shiftHandovers: List<ShiftHandover>,
    val alerts: List<PlantAlert>,
    val auditLog: List<AuditEntry>,
    val tariffs: TariffAndCostConfig,
    val simConfig: SimulationConfig,
    val version: Long,
    val pendingSyncCount: Int = 0,
    val lastSyncConflict: String? = null
)
