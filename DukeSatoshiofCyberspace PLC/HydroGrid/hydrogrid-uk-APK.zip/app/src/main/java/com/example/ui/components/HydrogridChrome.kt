package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.core.model.*
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun HydrogridAngularHLogo(modifier: Modifier = Modifier) {
    Canvas(
        modifier = modifier
            .size(34.dp)
            .semantics { contentDescription = "Hydrogrid UK angular H emblem" }
    ) {
        val w = size.width
        val h = size.height
        // Left vertical chamfered beam (white)
        val leftBeam = Path().apply {
            moveTo(w * 0.14f, h * 0.12f)
            lineTo(w * 0.34f, h * 0.04f)
            lineTo(w * 0.34f, h * 0.88f)
            lineTo(w * 0.14f, h * 0.96f)
            close()
        }
        drawPath(leftBeam, color = PureWhite)

        // Right vertical chamfered beam (Saltire / Process Cyan)
        val rightBeam = Path().apply {
            moveTo(w * 0.66f, h * 0.12f)
            lineTo(w * 0.86f, h * 0.04f)
            lineTo(w * 0.86f, h * 0.88f)
            lineTo(w * 0.66f, h * 0.96f)
            close()
        }
        drawPath(rightBeam, color = ProcessCyan)

        // Angular diagonal crossbar (Saltire Blue + White chamfer)
        val crossBlue = Path().apply {
            moveTo(w * 0.14f, h * 0.56f)
            lineTo(w * 0.86f, h * 0.36f)
            lineTo(w * 0.86f, h * 0.52f)
            lineTo(w * 0.14f, h * 0.72f)
            close()
        }
        drawPath(crossBlue, color = ActiveNavBlue)

        val crossWhite = Path().apply {
            moveTo(w * 0.34f, h * 0.44f)
            lineTo(w * 0.66f, h * 0.36f)
            lineTo(w * 0.66f, h * 0.48f)
            lineTo(w * 0.34f, h * 0.56f)
            close()
        }
        drawPath(crossWhite, color = PureWhite)
    }
}

@Composable
fun ScottishSaltireFlag(modifier: Modifier = Modifier) {
    Canvas(
        modifier = modifier
            .size(width = 28.dp, height = 18.dp)
            .clip(RoundedCornerShape(2.dp))
            .semantics { contentDescription = "Scottish Saltire flag" }
    ) {
        drawRect(color = SaltireBlue)
        val strokeW = size.height * 0.22f
        drawLine(
            color = PureWhite,
            start = Offset(0f, 0f),
            end = Offset(size.width, size.height),
            strokeWidth = strokeW,
            cap = StrokeCap.Square
        )
        drawLine(
            color = PureWhite,
            start = Offset(0f, size.height),
            end = Offset(size.width, 0f),
            strokeWidth = strokeW,
            cap = StrokeCap.Square
        )
    }
}

@Composable
fun HydrogridTopHeader(
    snapshot: PlantSnapshot,
    isCompact: Boolean,
    onSetSimSpeed: (SimSpeed) -> Unit,
    onResetSim: () -> Unit,
    onSelectRole: (UserRole) -> Unit,
    onOpenSettings: () -> Unit
) {
    var roleMenuOpen by remember { mutableStateOf(false) }

    Surface(
        color = MidnightNavy,
        tonalElevation = 0.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Brand Identity: Angular H + HYDROGRID UK + Subtitle + Saltire
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    HydrogridAngularHLogo()
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "HYDROGRID UK",
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    color = PureWhite,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.8.sp
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            ScottishSaltireFlag()
                        }
                        Text(
                            text = "SCOTTISH HYDROGEN • PRODUCTION & STORAGE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = ProcessCyanBright,
                                letterSpacing = 0.9.sp
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                if (!isCompact) {
                    Spacer(Modifier.width(12.dp))
                    // Plant Name + Freshness + Separate Sim Clock vs Wall Clock
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.horizontalScroll(rememberScrollState())
                    ) {
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = snapshot.plantName,
                                style = MaterialTheme.typography.titleSmall.copy(color = PureWhite),
                                maxLines = 1
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "SIM ${snapshot.simTimeIso.substringAfter(" ")}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = ProcessCyanBright)
                                )
                                Text(
                                    text = "|",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MidnightNavyBorder)
                                )
                                Text(
                                    text = "WALL ${snapshot.wallTimeIso} • AGE ${snapshot.dataAgeSeconds}s",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (snapshot.dataAgeSeconds >= 20L) StatusAmber else BrushedSteelMid
                                    )
                                )
                            }
                        }

                        FreshnessBadge(snapshot.freshnessState, snapshot.dataAgeSeconds)

                        // Simulation Transport Bar
                        Surface(
                            color = MidnightNavyElevated,
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, MidnightNavyBorder)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                IconButton(
                                    onClick = {
                                        onSetSimSpeed(
                                            if (snapshot.simSpeed == SimSpeed.PAUSED) SimSpeed.NORMAL_1X else SimSpeed.PAUSED
                                        )
                                    },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .testTag("sim_play_pause_btn")
                                ) {
                                    Icon(
                                        imageVector = if (snapshot.simSpeed == SimSpeed.PAUSED) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                                        contentDescription = if (snapshot.simSpeed == SimSpeed.PAUSED) "Resume simulation" else "Pause simulation",
                                        tint = ProcessCyanBright,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                listOf(SimSpeed.NORMAL_1X, SimSpeed.ACCEL_10X).forEach { spd ->
                                    val active = snapshot.simSpeed == spd
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(if (active) ActiveNavBlue else Color.Transparent)
                                            .clickable { onSetSimSpeed(spd) }
                                            .padding(horizontal = 8.dp, vertical = 6.dp)
                                            .testTag("sim_speed_${spd.multiplier}x")
                                    ) {
                                        Text(
                                            text = "${spd.multiplier}x",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = if (active) PureWhite else BrushedSteelMid,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }
                                }
                                IconButton(
                                    onClick = onResetSim,
                                    modifier = Modifier
                                        .size(36.dp)
                                        .testTag("sim_reset_btn")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.RestartAlt,
                                        contentDescription = "Reset simulation",
                                        tint = BrushedSteelLight,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        // Role Pill
                        Box {
                            Surface(
                                color = MidnightNavyElevated,
                                shape = RoundedCornerShape(6.dp),
                                border = BorderStroke(1.dp, SaltireBlue),
                                modifier = Modifier
                                    .clickable { roleMenuOpen = true }
                                    .testTag("header_role_pill")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Badge,
                                        contentDescription = "Active user role",
                                        tint = ProcessCyanBright,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Text(
                                        text = snapshot.activeRole.title.uppercase(Locale.UK),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = PureWhite,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                    Icon(
                                        imageVector = Icons.Filled.ArrowDropDown,
                                        contentDescription = null,
                                        tint = BrushedSteelMid,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                            DropdownMenu(
                                expanded = roleMenuOpen,
                                onDismissRequest = { roleMenuOpen = false }
                            ) {
                                UserRole.entries.forEach { role ->
                                    DropdownMenuItem(
                                        text = {
                                            Column {
                                                Text(role.title, fontWeight = FontWeight.SemiBold)
                                                Text(
                                                    role.permissionsSummary,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = InkMuted
                                                )
                                            }
                                        },
                                        onClick = {
                                            onSelectRole(role)
                                            roleMenuOpen = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FreshnessBadge(snapshot.freshnessState, snapshot.dataAgeSeconds)
                        IconButton(
                            onClick = onOpenSettings,
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(Icons.Outlined.Settings, contentDescription = "Settings", tint = PureWhite)
                        }
                    }
                }
            }

            if (isCompact) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MidnightNavySurface)
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${snapshot.plantName} • AGE ${snapshot.dataAgeSeconds}s",
                        style = MaterialTheme.typography.labelSmall.copy(color = BrushedSteelLight),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = "SIM ${snapshot.simTimeIso.substringAfter(" ")}",
                        style = MaterialTheme.typography.labelSmall.copy(color = ProcessCyanBright)
                    )
                }
            }

            HorizontalDivider(thickness = 1.dp, color = SaltireBlue.copy(alpha = 0.65f))
        }
    }
}

@Composable
fun FreshnessBadge(freshness: DataFreshnessState, dataAgeSeconds: Long) {
    val (bg, fg) = when (freshness) {
        DataFreshnessState.CONNECTED -> StatusHealthyBg to StatusHealthy
        DataFreshnessState.DEMO_DATA -> StatusDemoBg to StatusDemo
        DataFreshnessState.CACHED -> StatusAmberBg to StatusAmber
        DataFreshnessState.STALE -> StatusFaultBg to StatusFault
    }
    Surface(
        color = bg,
        shape = RoundedCornerShape(4.dp),
        border = BorderStroke(1.dp, fg.copy(alpha = 0.45f))
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(fg)
            )
            Text(
                text = if (freshness == DataFreshnessState.STALE) "STALE (${dataAgeSeconds}s)" else freshness.badgeLabel,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = fg,
                    fontWeight = FontWeight.Bold
                )
            )
        }
    }
}

@Composable
fun HydrogridSidebar(
    activeWorkspace: Workspace,
    alertCount: Int,
    holdCount: Int,
    onSelectWorkspace: (Workspace) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MidnightNavy,
        modifier = modifier
            .width(194.dp)
            .fillMaxHeight()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(vertical = 10.dp, horizontal = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = "WORKSPACES",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = BrushedSteelMid,
                    letterSpacing = 1.1.sp
                ),
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )

            Workspace.entries.forEach { ws ->
                val selected = ws == activeWorkspace
                val badgeCount = when (ws) {
                    Workspace.QUALITY -> holdCount
                    Workspace.MAINTENANCE -> alertCount
                    else -> 0
                }
                Surface(
                    color = if (selected) ActiveNavBlue else Color.Transparent,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 44.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { onSelectWorkspace(ws) }
                        .testTag("nav_${ws.name.lowercase(Locale.UK)}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = workspaceIcon(ws, selected),
                                contentDescription = ws.label,
                                tint = if (selected) PureWhite else BrushedSteelMid,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = ws.label,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    color = if (selected) PureWhite else BrushedSteelLight,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                ),
                                maxLines = 1
                            )
                        }
                        if (badgeCount > 0) {
                            Surface(
                                color = StatusAmber,
                                shape = CircleShape
                            ) {
                                Text(
                                    text = "$badgeCount",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = PureWhite,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.weight(1f))
            HorizontalDivider(color = MidnightNavyBorder, modifier = Modifier.padding(vertical = 8.dp))
            Text(
                text = "MONITORING TERMINAL ONLY\nESD & Interlocks on Independent SIS",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = BrushedSteelMid,
                    lineHeight = 14.sp
                ),
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
fun CompactWorkspaceBar(
    activeWorkspace: Workspace,
    onSelectWorkspace: (Workspace) -> Unit
) {
    Surface(
        color = MidnightNavy,
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Workspace.entries.forEach { ws ->
                val selected = ws == activeWorkspace
                Surface(
                    color = if (selected) ActiveNavBlue else MidnightNavyElevated,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .clickable { onSelectWorkspace(ws) }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        Icon(
                            imageVector = workspaceIcon(ws, selected),
                            contentDescription = ws.label,
                            tint = PureWhite,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = ws.label,
                            style = MaterialTheme.typography.labelMedium.copy(color = PureWhite)
                        )
                    }
                }
            }
        }
    }
}

fun workspaceIcon(workspace: Workspace, selected: Boolean): ImageVector = when (workspace) {
    Workspace.OVERVIEW -> if (selected) Icons.Filled.Dashboard else Icons.Outlined.Dashboard
    Workspace.WATER -> if (selected) Icons.Filled.WaterDrop else Icons.Outlined.WaterDrop
    Workspace.ELECTROLYSIS -> if (selected) Icons.Filled.Bolt else Icons.Outlined.Bolt
    Workspace.COMPRESSION -> if (selected) Icons.Filled.Compress else Icons.Outlined.Compress
    Workspace.STORAGE -> if (selected) Icons.Filled.Inventory2 else Icons.Outlined.Inventory2
    Workspace.QUALITY -> if (selected) Icons.Filled.Science else Icons.Outlined.Science
    Workspace.DISPATCH -> if (selected) Icons.Filled.LocalShipping else Icons.Outlined.LocalShipping
    Workspace.MAINTENANCE -> if (selected) Icons.Filled.Build else Icons.Outlined.Build
    Workspace.REPORTS -> Icons.AutoMirrored.Filled.Assignment
    Workspace.SETTINGS -> if (selected) Icons.Filled.Settings else Icons.Outlined.Settings
}

@Composable
fun StatusPill(
    label: String,
    tone: StatusTone,
    modifier: Modifier = Modifier
) {
    val (bg, fg) = when (tone) {
        StatusTone.HEALTHY -> StatusHealthyBg to StatusHealthy
        StatusTone.AMBER -> StatusAmberBg to StatusAmber
        StatusTone.FAULT -> StatusFaultBg to StatusFault
        StatusTone.INFO -> StatusDemoBg to SaltireBlue
        StatusTone.NEUTRAL -> StatusStaleBg to StatusStale
    }
    Surface(
        color = bg,
        shape = RoundedCornerShape(4.dp),
        border = BorderStroke(1.dp, fg.copy(alpha = 0.35f)),
        modifier = modifier
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = fg,
                fontWeight = FontWeight.Bold
            ),
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
        )
    }
}

enum class StatusTone { HEALTHY, AMBER, FAULT, INFO, NEUTRAL }

fun EquipmentState.toTone(): StatusTone = when (this) {
    EquipmentState.RUNNING -> StatusTone.HEALTHY
    EquipmentState.STANDBY -> StatusTone.INFO
    EquipmentState.BLOCKED -> StatusTone.AMBER
    EquipmentState.MAINTENANCE -> StatusTone.AMBER
    EquipmentState.FAULT -> StatusTone.FAULT
}

@Composable
fun EquipmentDetailDialog(
    unit: EquipmentUnit,
    alerts: List<PlantAlert>,
    workOrders: List<MaintenanceWorkOrder>,
    onDismiss: () -> Unit,
    onAcknowledgeAlert: (String) -> Unit,
    onInjectFault: (String, String) -> Unit
) {
    val unitAlerts = alerts.filter { it.equipmentTag == unit.tag }
    val unitWos = workOrders.filter { it.equipmentTag == unit.tag }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            color = PureWhite,
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, SaltireBlue.copy(alpha = 0.35f)),
            modifier = Modifier
                .widthIn(min = 340.dp, max = 640.dp)
                .fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${unit.tag} • ${unit.name}",
                            style = MaterialTheme.typography.headlineSmall.copy(color = MidnightNavy)
                        )
                        Text(
                            text = "Provenance: ${unit.sensorProvenance}",
                            style = MaterialTheme.typography.labelSmall.copy(color = InkMuted)
                        )
                    }
                    StatusPill(unit.state.label, unit.state.toTone())
                }

                HorizontalDivider(color = ThinRuleBlue)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    DetailStatBox(unit.primaryMetricLabel, unit.primaryMetricValue, Modifier.weight(1f))
                    DetailStatBox(unit.secondaryMetricLabel, unit.secondaryMetricValue, Modifier.weight(1f))
                    DetailStatBox("Pressure / Temp", "${String.format(Locale.UK, "%.1f", unit.pressureBar)} bar / ${String.format(Locale.UK, "%.1f", unit.temperatureC)} °C", Modifier.weight(1f))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    DetailStatBox("Operating Hours", "${String.format(Locale.UK, "%,.1f", unit.operatingHours)} h", Modifier.weight(1f))
                    DetailStatBox("Data Quality", unit.dataQuality.label, Modifier.weight(1f))
                    DetailStatBox("Maintenance", unit.maintenanceStatus, Modifier.weight(1.4f))
                }

                Text(
                    text = "RECENT TELEMETRY TREND (${unit.primaryMetricLabel.uppercase(Locale.UK)})",
                    style = MaterialTheme.typography.labelSmall.copy(color = InkSecondary)
                )
                OutputTrendChart(
                    points = unit.historySeries,
                    lineColor = ProcessCyan,
                    unitSuffix = "",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                )

                Text(
                    text = "ALERTS & INTERLOCK BOUNDARY",
                    style = MaterialTheme.typography.labelSmall.copy(color = InkSecondary)
                )
                if (unitAlerts.isEmpty()) {
                    Text(
                        text = "No active alarms on ${unit.tag}.",
                        style = MaterialTheme.typography.bodySmall.copy(color = InkMuted)
                    )
                } else {
                    unitAlerts.forEach { alert ->
                        Surface(
                            color = if (alert.physicalConditionResolved) StatusHealthyBg else StatusAmberBg,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${alert.severity}: ${alert.message}",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = InkPrimary,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    )
                                    Text(
                                        text = if (alert.acknowledged) "Acknowledged by ${alert.acknowledgedBy} • Physical resolved: ${alert.physicalConditionResolved}"
                                        else "Unacknowledged • Raised ${alert.raisedAtIso}",
                                        style = MaterialTheme.typography.labelSmall.copy(color = InkSecondary)
                                    )
                                }
                                if (!alert.acknowledged) {
                                    TextButton(onClick = { onAcknowledgeAlert(alert.id) }) {
                                        Text("Acknowledge")
                                    }
                                }
                            }
                        }
                    }
                }

                if (unitWos.isNotEmpty()) {
                    Text(
                        text = "MAINTENANCE RECORDS",
                        style = MaterialTheme.typography.labelSmall.copy(color = InkSecondary)
                    )
                    unitWos.forEach { wo ->
                        Text(
                            text = "• ${wo.id} [${wo.status}] ${wo.title} (Due ${wo.dueDateIso})",
                            style = MaterialTheme.typography.bodySmall.copy(color = InkPrimary)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    OutlinedButton(
                        onClick = {
                            onInjectFault(unit.tag, "Simulated instrumentation trip on ${unit.tag}")
                        },
                        border = BorderStroke(1.dp, StatusAmber)
                    ) {
                        Text("Simulate Trip / Fault", color = StatusAmber)
                    }
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = SaltireBlue)
                    ) {
                        Text("Close")
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailStatBox(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        color = SoftPanelBg,
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, HairlineBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(label.uppercase(Locale.UK), style = MaterialTheme.typography.labelSmall, color = InkMuted)
            Spacer(Modifier.height(2.dp))
            Text(value, style = MaterialTheme.typography.titleSmall, color = InkPrimary)
        }
    }
}
