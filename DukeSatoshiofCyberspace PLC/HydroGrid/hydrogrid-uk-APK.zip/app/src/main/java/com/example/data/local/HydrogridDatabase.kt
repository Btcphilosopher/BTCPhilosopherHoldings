package com.example.data.local

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "cached_snapshots")
data class CachedSnapshotEntity(
    @PrimaryKey val id: String = "latest",
    val plantName: String,
    val h2OutputKgHr: Double,
    val electrolyserPowerMw: Double,
    val storageInventoryKg: Double,
    val dispatchTodayKg: Double,
    val simTimeIso: String,
    val cachedAtEpochMs: Long,
    val version: Long,
    val payloadSummaryJson: String
)

@Entity(tableName = "pending_sync_actions")
data class PendingSyncActionEntity(
    @PrimaryKey val idempotencyKey: String,
    val actionType: String,
    val entityId: String,
    val payloadJson: String,
    val actorRole: String,
    val expectedVersion: Long,
    val createdAtEpochMs: Long,
    val conflictMessage: String? = null
)

@Entity(tableName = "cached_audit_log")
data class CachedAuditLogEntity(
    @PrimaryKey val id: String,
    val timestampIso: String,
    val actorRole: String,
    val action: String,
    val entityRef: String,
    val detail: String,
    val idempotencyKey: String
)

@Dao
interface HydrogridDao {
    @Query("SELECT * FROM cached_snapshots WHERE id = 'latest' LIMIT 1")
    fun observeLatestSnapshot(): Flow<CachedSnapshotEntity?>

    @Query("SELECT * FROM cached_snapshots WHERE id = 'latest' LIMIT 1")
    suspend fun getLatestSnapshot(): CachedSnapshotEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSnapshot(snapshot: CachedSnapshotEntity)

    @Query("SELECT * FROM pending_sync_actions ORDER BY createdAtEpochMs ASC")
    fun observePendingActions(): Flow<List<PendingSyncActionEntity>>

    @Query("SELECT * FROM pending_sync_actions ORDER BY createdAtEpochMs ASC")
    suspend fun getPendingActions(): List<PendingSyncActionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun enqueueAction(action: PendingSyncActionEntity)

    @Query("DELETE FROM pending_sync_actions WHERE idempotencyKey = :key")
    suspend fun deletePendingAction(key: String)

    @Query("UPDATE pending_sync_actions SET conflictMessage = :msg WHERE idempotencyKey = :key")
    suspend fun markActionConflict(key: String, msg: String)

    @Query("SELECT * FROM cached_audit_log ORDER BY id DESC LIMIT 100")
    fun observeAuditLog(): Flow<List<CachedAuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditEntries(entries: List<CachedAuditLogEntity>)
}

@Database(
    entities = [
        CachedSnapshotEntity::class,
        PendingSyncActionEntity::class,
        CachedAuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class HydrogridDatabase : RoomDatabase() {
    abstract fun hydrogridDao(): HydrogridDao

    companion object {
        @Volatile
        private var INSTANCE: HydrogridDatabase? = null

        fun getInstance(context: Context): HydrogridDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    HydrogridDatabase::class.java,
                    "hydrogrid_terminal.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
