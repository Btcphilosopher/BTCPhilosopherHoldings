package com.example

import android.app.Application
import com.example.data.repository.HydrogridRepository

class HydrogridApplication : Application() {
    val repository: HydrogridRepository by lazy {
        HydrogridRepository(applicationContext)
    }
}
