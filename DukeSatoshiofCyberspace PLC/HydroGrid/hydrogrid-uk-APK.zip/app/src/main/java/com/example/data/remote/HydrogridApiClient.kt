package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class RemoteHealthResponse(
    val status: String,
    @Json(name = "plant_name") val plantName: String,
    @Json(name = "sim_time_iso") val simTimeIso: String,
    val version: Long
)

@JsonClass(generateAdapter = true)
data class RemoteSnapshotSummary(
    @Json(name = "plant_name") val plantName: String,
    @Json(name = "sim_time_iso") val simTimeIso: String,
    @Json(name = "h2_output_kg_hr") val h2OutputKgHr: Double,
    @Json(name = "electrolyser_power_mw") val electrolyserPowerMw: Double,
    @Json(name = "storage_inventory_kg") val storageInventoryKg: Double,
    @Json(name = "dispatch_today_kg") val dispatchTodayKg: Double,
    val version: Long
)

@JsonClass(generateAdapter = true)
data class RemoteMutationRequest(
    @Json(name = "action_type") val actionType: String,
    @Json(name = "entity_id") val entityId: String,
    @Json(name = "payload_json") val payloadJson: String,
    @Json(name = "expected_version") val expectedVersion: Long
)

@JsonClass(generateAdapter = true)
data class RemoteMutationResponse(
    val accepted: Boolean,
    val version: Long,
    val message: String
)

interface HydrogridFastApiService {
    @GET("api/v1/health")
    suspend fun getHealth(
        @Header("Authorization") authHeader: String?,
        @Header("X-Hydrogrid-Role") role: String
    ): Response<RemoteHealthResponse>

    @GET("api/v1/snapshot")
    suspend fun getSnapshot(
        @Header("Authorization") authHeader: String?,
        @Header("X-Hydrogrid-Role") role: String
    ): Response<RemoteSnapshotSummary>

    @POST("api/v1/actions")
    suspend fun submitIdempotentAction(
        @Header("Authorization") authHeader: String?,
        @Header("X-Hydrogrid-Role") role: String,
        @Header("Idempotency-Key") idempotencyKey: String,
        @Body request: RemoteMutationRequest
    ): Response<RemoteMutationResponse>
}

/**
 * Replaceable API client abstraction allowing seamless switching between
 * FastAPI backend, offline demo simulator, or industrial historian adapters.
 */
interface HydrogridApiClient {
    suspend fun checkConnection(baseUrl: String, role: String, token: String?): Result<RemoteHealthResponse>
    suspend fun fetchSnapshot(baseUrl: String, role: String, token: String?): Result<RemoteSnapshotSummary>
    suspend fun pushAction(
        baseUrl: String,
        role: String,
        token: String?,
        idempotencyKey: String,
        request: RemoteMutationRequest
    ): Result<RemoteMutationResponse>
}

/**
 * Read-only industrial historian / OPC-UA / Modbus gateway adapter boundary.
 * Physical plant control and safety interlocks remain strictly isolated.
 */
interface HistorianGatewayAdapter {
    val adapterName: String
    val isReadOnly: Boolean get() = true
    suspend fun probeTagProvenance(): Map<String, String>
}

class ReadOnlyOpcUaHistorianAdapter : HistorianGatewayAdapter {
    override val adapterName: String = "OPC-UA / SCADA Read-Only Historian Bridge v1.4"
    override suspend fun probeTagProvenance(): Map<String, String> = mapOf(
        "WT-101" to "SCADA Historian • Endress+Hauser CLS16E (RO/EDI)",
        "ELX-200" to "PLC Rectifier Bus • Modbus TCP Read-Only Gateway",
        "SEP-301" to "Coriolis Mass Meter • Emerson CMF050",
        "PUR-401" to "Online Moisture Analyser • Michell QMA601",
        "CMP-501" to "Compressor PLC • OPC-UA Read-Only",
        "STR-600" to "Mass-Balance Integrator + Redundant PT/TT",
        "DSP-701" to "Weighbridge + Coriolis Custody Transfer"
    )
}

class RetrofitHydrogridApiClient : HydrogridApiClient {

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttp: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(4, TimeUnit.SECONDS)
        .writeTimeout(4, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        })
        .build()

    private fun serviceFor(baseUrl: String): HydrogridFastApiService {
        val normalized = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
        return Retrofit.Builder()
            .baseUrl(normalized)
            .client(okHttp)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(HydrogridFastApiService::class.java)
    }

    private fun bearerOrNull(token: String?): String? =
        token?.takeIf { it.isNotBlank() }?.let { "Bearer $it" }

    override suspend fun checkConnection(
        baseUrl: String,
        role: String,
        token: String?
    ): Result<RemoteHealthResponse> = runCatching {
        val resp = serviceFor(baseUrl).getHealth(bearerOrNull(token), role)
        if (resp.isSuccessful && resp.body() != null) {
            resp.body()!!
        } else {
            throw IllegalStateException("Backend returned HTTP ${resp.code()}")
        }
    }

    override suspend fun fetchSnapshot(
        baseUrl: String,
        role: String,
        token: String?
    ): Result<RemoteSnapshotSummary> = runCatching {
        val resp = serviceFor(baseUrl).getSnapshot(bearerOrNull(token), role)
        if (resp.isSuccessful && resp.body() != null) {
            resp.body()!!
        } else {
            throw IllegalStateException("Snapshot HTTP ${resp.code()}")
        }
    }

    override suspend fun pushAction(
        baseUrl: String,
        role: String,
        token: String?,
        idempotencyKey: String,
        request: RemoteMutationRequest
    ): Result<RemoteMutationResponse> = runCatching {
        val resp = serviceFor(baseUrl).submitIdempotentAction(bearerOrNull(token), role, idempotencyKey, request)
        if (resp.isSuccessful && resp.body() != null) {
            resp.body()!!
        } else if (resp.code() == 409) {
            throw ConflictException("Version conflict (409): server state advanced beyond v${request.expectedVersion}")
        } else {
            throw IllegalStateException("Action HTTP ${resp.code()}")
        }
    }
}

class ConflictException(message: String) : IllegalStateException(message)
