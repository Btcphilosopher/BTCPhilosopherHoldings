package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.model.*
import com.example.ui.components.StatusPill
import com.example.ui.components.StatusTone
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun QualityScreen(
    snapshot: PlantSnapshot,
    onRegisterSample: (
        batchId: String,
        sourceType: ReadingSourceType,
        purityPct: Double,
        moisturePpm: Double,
        oxygenPpm: Double,
        analystName: String,
        attachmentRef: String?,
        notes: String,
        correctionReason: String?
    ) -> Unit,
    onAuthoriseRelease: (String, String) -> Unit
) {
    var selectedBatchId by remember { mutableStateOf("H2-042") }
    val selectedBatch = snapshot.qualityBatches.find { it.batchId == selectedBatchId }
        ?: snapshot.qualityBatches.first()

    var sourceType by remember { mutableStateOf(ReadingSourceType.DISCRETE_SAMPLE) }
    var purityStr by remember { mutableStateOf("99.991") }
    var moistureStr by remember { mutableStateOf("1.9") }
    var oxygenStr by remember { mutableStateOf("1.4") }
    var analystStr by remember { mutableStateOf("Dr. F. Campbell") }
    var attachmentStr by remember { mutableStateOf("COA-LAB-GC-042.pdf") }
    var notesStr by remember { mutableStateOf("GC-TCD & chilled-mirror hygrometer check") }
    var correctionReasonStr by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        WorkspaceSectionHeader(
            title = "Laboratory Quality & Batch Release",
            subtitle = "Versioned Spec: ${snapshot.acceptanceSpec.version} (${snapshot.acceptanceSpec.standardName}) • Measured lab findings remain separate from predicted quality; passing thresholds never auto-certify"
        )

        // Acceptance Spec Strip
        Surface(
            color = PureWhite,
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, ThinRuleBlue),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "SPEC ${snapshot.acceptanceSpec.version}: Purity ≥ ${snapshot.acceptanceSpec.minPurityPct}% • Moisture ≤ ${snapshot.acceptanceSpec.maxMoisturePpm} ppm • O₂ ≤ ${snapshot.acceptanceSpec.maxOxygenPpm} ppm",
                    style = MaterialTheme.typography.labelMedium.copy(color = MidnightNavy, fontWeight = FontWeight.Bold)
                )
                StatusPill("ACTIVE ROLE: ${snapshot.activeRole.title.uppercase(Locale.UK)}", StatusTone.INFO)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Left: Batch Register
            Column(
                modifier = Modifier.weight(0.42f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                snapshot.qualityBatches.forEach { batch ->
                    val isSelected = batch.batchId == selectedBatch.batchId
                    val tone = when (batch.releaseStatus) {
                        BatchReleaseStatus.RELEASED -> StatusTone.HEALTHY
                        BatchReleaseStatus.HOLD_FOR_REVIEW -> StatusTone.AMBER
                        BatchReleaseStatus.QUARANTINED -> StatusTone.FAULT
                    }
                    Surface(
                        color = if (isSelected) StatusDemoBg else PureWhite,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(if (isSelected) 2.dp else 1.dp, if (isSelected) SaltireBlue else ThinRuleBlue),
                        onClick = { selectedBatchId = batch.batchId },
                        modifier = Modifier.fillMaxWidth().testTag("quality_batch_${batch.batchId}")
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Batch ${batch.batchId}", style = MaterialTheme.typography.titleMedium.copy(color = MidnightNavy))
                                StatusPill(batch.releaseStatus.label, tone)
                            }
                            Text(
                                "Bank: ${batch.storageBankId} • Remaining: ${String.format(Locale.UK, "%,.0f", batch.remainingMassKg)} kg",
                                style = MaterialTheme.typography.bodySmall.copy(color = InkSecondary)
                            )
                            Text(
                                "Measured: ${batch.measuredPurityPct?.let { String.format(Locale.UK, "%.3f%%", it) } ?: "Pending"} | Predicted: ${String.format(Locale.UK, "%.3f%%", batch.predictedPurityPct)}",
                                style = MaterialTheme.typography.labelSmall.copy(color = InkMuted)
                            )
                        }
                    }
                }
            }

            // Right: Selected Batch Detail, Sample Registration & Release Authorisation
            Surface(
                color = PureWhite,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, ThinRuleBlue),
                modifier = Modifier.weight(0.58f)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("BATCH ${selectedBatch.batchId} • ${selectedBatch.reviewStatus.label}", style = MaterialTheme.typography.titleMedium.copy(color = MidnightNavy))
                            Text("Predicted (online analyser model): ${selectedBatch.predictedPurityPct}% H₂, ${selectedBatch.predictedMoisturePpm} ppm H₂O", style = MaterialTheme.typography.labelSmall.copy(color = InkMuted))
                        }
                        if (selectedBatch.releaseStatus != BatchReleaseStatus.RELEASED) {
                            Button(
                                onClick = { onAuthoriseRelease(selectedBatch.batchId, analystStr) },
                                enabled = selectedBatch.reviewStatus == LabReviewStatus.REVIEWED_PASS,
                                colors = ButtonDefaults.buttonColors(containerColor = StatusHealthy),
                                modifier = Modifier.testTag("authorise_release_btn")
                            ) {
                                Text("Authorise Release")
                            }
                        } else {
                            StatusPill("AUTHORISED BY ${selectedBatch.authorisedBy ?: "QA"}", StatusTone.HEALTHY)
                        }
                    }

                    HorizontalDivider(color = ThinRuleBlue)

                    Text("REGISTER SAMPLE / RETEST (PRESERVES ORIGINAL RECORDS)", style = MaterialTheme.typography.labelSmall.copy(color = SaltireBlue, fontWeight = FontWeight.Bold))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ReadingSourceType.entries.forEach { src ->
                            FilterChip(
                                selected = sourceType == src,
                                onClick = { sourceType = src },
                                label = { Text(src.label, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = purityStr, onValueChange = { purityStr = it }, label = { Text("Purity %") }, singleLine = true, modifier = Modifier.weight(1f).testTag("sample_purity_input"))
                        OutlinedTextField(value = moistureStr, onValueChange = { moistureStr = it }, label = { Text("Moisture ppm") }, singleLine = true, modifier = Modifier.weight(1f).testTag("sample_moisture_input"))
                        OutlinedTextField(value = oxygenStr, onValueChange = { oxygenStr = it }, label = { Text("O₂ ppm") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = analystStr, onValueChange = { analystStr = it }, label = { Text("Analyst / Reviewer") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = attachmentStr, onValueChange = { attachmentStr = it }, label = { Text("Attachment Ref") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                    if (selectedBatch.samples.any { it.purityPct != null }) {
                        OutlinedTextField(
                            value = correctionReasonStr,
                            onValueChange = { correctionReasonStr = it },
                            label = { Text("Retest / Correction Audit Reason") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = notesStr, onValueChange = { notesStr = it }, label = { Text("Lab Notes") }, singleLine = true, modifier = Modifier.weight(1f))
                        Button(
                            onClick = {
                                val p = purityStr.toDoubleOrNull() ?: 99.99
                                val m = moistureStr.toDoubleOrNull() ?: 2.0
                                val o = oxygenStr.toDoubleOrNull() ?: 1.5
                                onRegisterSample(
                                    selectedBatch.batchId,
                                    sourceType,
                                    p,
                                    m,
                                    o,
                                    analystStr,
                                    attachmentStr,
                                    notesStr,
                                    correctionReasonStr.takeIf { it.isNotBlank() }
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SaltireBlue),
                            modifier = Modifier.testTag("submit_sample_btn")
                        ) {
                            Text("Record Sample")
                        }
                    }

                    HorizontalDivider(color = ThinRuleBlue)
                    Text("PRESERVED LABORATORY AUDIT RECORDS (${selectedBatch.samples.size})", style = MaterialTheme.typography.labelSmall.copy(color = InkSecondary, fontWeight = FontWeight.Bold))
                    selectedBatch.samples.reversed().forEach { smp ->
                        Surface(color = SoftPanelBg, shape = RoundedCornerShape(6.dp), border = BorderStroke(1.dp, HairlineBorder), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    "${smp.sampleId} • ${smp.sourceType.label} • ${smp.timestampIso} • ${if (smp.isOriginalRecord) "ORIGINAL" else "RETEST/CORRECTION"}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = SaltireBlue, fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    "Measured: ${smp.purityPct?.let { "$it% H₂, ${smp.moisturePpm} ppm H₂O, ${smp.oxygenPpm} ppm O₂" } ?: "Sample pending lab assay"} • Analyst: ${smp.analystName}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = InkPrimary)
                                )
                                smp.correctionReason?.let { r ->
                                    Text("Correction Reason: $r", style = MaterialTheme.typography.labelSmall.copy(color = StatusAmber))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DispatchScreen(
    snapshot: PlantSnapshot,
    onAdvanceOrder: (String, DispatchStage, Double?, String?) -> Unit
) {
    var reconcileOrder by remember { mutableStateOf<DispatchOrder?>(null) }
    val releasedInventoryKg = snapshot.storageBanks.sumOf { bank ->
        val batch = snapshot.qualityBatches.find { it.batchId == bank.linkedBatchId }
        if (batch?.releaseStatus == BatchReleaseStatus.RELEASED) bank.inventoryKg else 0.0
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        WorkspaceSectionHeader(
            title = "Tube-Trailer Dispatch & Custody Transfer",
            subtitle = "Booked → Arrived → Checked → Authorised → Loading → Reconciled → Released • Quality-held inventory is strictly blocked from dispatch"
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatPanelCard(
                title = "Available Released Inventory",
                value = "${String.format(Locale.UK, "%,.0f", releasedInventoryKg)} kg",
                detail = "Excludes held/quarantined batches (e.g. H2-042)",
                modifier = Modifier.weight(1f)
            )
            StatPanelCard(
                title = "Dispatched Today",
                value = "${String.format(Locale.UK, "%,.0f", snapshot.dispatchTodayKg)} kg",
                detail = "Traceable reconciliation without double deduction",
                modifier = Modifier.weight(1f)
            )
            StatPanelCard(
                title = "Active Trailer Orders",
                value = "${snapshot.dispatchOrders.size}",
                detail = "Live queue backed by order records",
                modifier = Modifier.weight(1f)
            )
        }

        snapshot.dispatchOrders.forEach { order ->
            val batch = snapshot.qualityBatches.find { it.batchId == order.assignedBatchId }
            val batchReleased = batch?.releaseStatus == BatchReleaseStatus.RELEASED
            val tone = when (order.stage) {
                DispatchStage.RELEASED, DispatchStage.RECONCILED -> StatusTone.HEALTHY
                DispatchStage.HELD, DispatchStage.EXCEPTION -> StatusTone.AMBER
                DispatchStage.CANCELLED -> StatusTone.FAULT
                DispatchStage.LOADING, DispatchStage.AUTHORISED -> StatusTone.INFO
                else -> StatusTone.NEUTRAL
            }

            Surface(
                color = PureWhite,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, if (order.stage == DispatchStage.HELD) StatusAmber else ThinRuleBlue),
                modifier = Modifier.fillMaxWidth().testTag("dispatch_card_${order.orderId}")
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${order.orderId} • Trailer ${order.trailerRegistration} — ${order.customerName}", style = MaterialTheme.typography.titleMedium.copy(color = MidnightNavy))
                            Text(
                                "Batch ${order.assignedBatchId} (${batch?.releaseStatus?.label ?: "Unknown"}) • Source ${order.sourceBankId} • Spec ${order.requiredSpecVersion} • Slot ${order.scheduledTimeIso}",
                                style = MaterialTheme.typography.labelSmall.copy(color = if (batchReleased) InkSecondary else StatusAmber)
                            )
                        }
                        StatusPill(order.stage.label.uppercase(Locale.UK), tone)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text("Requested: ${String.format(Locale.UK, "%.0f", order.requestedMassKg)} kg", style = MaterialTheme.typography.bodySmall)
                        Text("Estimated Loaded: ${String.format(Locale.UK, "%.1f", order.estimatedLoadedKg)} kg", style = MaterialTheme.typography.bodySmall)
                        Text("Confirmed Transfer: ${order.confirmedTransferKg?.let { "${String.format(Locale.UK, "%.1f", it)} kg" } ?: "Pending Weighbridge"}", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold, color = SaltireBlue))
                        order.deliveryDocNumber?.let { dn ->
                            Text("Doc: $dn", style = MaterialTheme.typography.labelMedium.copy(color = StatusHealthy))
                        }
                    }

                    order.holdOrExceptionReason?.let { msg ->
                        Text(msg, style = MaterialTheme.typography.labelSmall.copy(color = StatusAmber, fontWeight = FontWeight.Bold))
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        when (order.stage) {
                            DispatchStage.BOOKED -> {
                                ActionBtn("Check-In Arrived") { onAdvanceOrder(order.orderId, DispatchStage.ARRIVED, null, null) }
                            }
                            DispatchStage.ARRIVED -> {
                                ActionBtn("Complete Safety Check") { onAdvanceOrder(order.orderId, DispatchStage.CHECKED, null, null) }
                            }
                            DispatchStage.CHECKED, DispatchStage.HELD -> {
                                ActionBtn("Authorise Loading", tag = "authorise_${order.orderId}") {
                                    onAdvanceOrder(order.orderId, DispatchStage.AUTHORISED, null, null)
                                }
                            }
                            DispatchStage.AUTHORISED -> {
                                ActionBtn("Start Loading") { onAdvanceOrder(order.orderId, DispatchStage.LOADING, null, null) }
                            }
                            DispatchStage.LOADING -> {
                                ActionBtn("Reconcile Weighbridge", tag = "reconcile_${order.orderId}") {
                                    reconcileOrder = order
                                }
                            }
                            DispatchStage.RECONCILED -> {
                                ActionBtn("Release Trailer & Doc", tag = "release_${order.orderId}") {
                                    onAdvanceOrder(order.orderId, DispatchStage.RELEASED, null, null)
                                }
                            }
                            else -> {}
                        }
                        if (order.stage !in setOf(DispatchStage.RELEASED, DispatchStage.CANCELLED)) {
                            OutlinedButton(
                                onClick = { onAdvanceOrder(order.orderId, DispatchStage.CANCELLED, null, "Cancelled by terminal user") }
                            ) { Text("Cancel") }
                        }
                    }
                }
            }
        }
    }

    reconcileOrder?.let { ord ->
        var confirmedStr by remember(ord) { mutableStateOf(String.format(Locale.UK, "%.1f", ord.requestedMassKg)) }
        AlertDialog(
            onDismissRequest = { reconcileOrder = null },
            title = { Text("Reconcile Custody Transfer • ${ord.orderId}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Estimated flowmeter loaded: ${String.format(Locale.UK, "%.1f", ord.estimatedLoadedKg)} kg. Enter confirmed weighbridge/Coriolis mass; storage bank balance will adjust by net delta without double deduction.", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(
                        value = confirmedStr,
                        onValueChange = { confirmedStr = it },
                        label = { Text("Confirmed Transfer Mass (kg)") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val confirmed = confirmedStr.toDoubleOrNull() ?: ord.requestedMassKg
                    onAdvanceOrder(ord.orderId, DispatchStage.RECONCILED, confirmed, null)
                    reconcileOrder = null
                }) { Text("Confirm & Issue Note") }
            },
            dismissButton = {
                TextButton(onClick = { reconcileOrder = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun ActionBtn(label: String, tag: String = "", onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = SaltireBlue),
        modifier = if (tag.isNotEmpty()) Modifier.testTag(tag) else Modifier
    ) {
        Text(label)
    }
}
