package com.example.data.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.data.local.HydrogridDatabase
import com.example.data.local.KeystoreCredentialManager
import com.example.data.local.TerminalPreferencesStore
import com.example.data.remote.ConflictException
import com.example.data.remote.RemoteMutationRequest
import com.example.data.remote.RetrofitHydrogridApiClient
import kotlinx.coroutines.flow.first

class TelemetrySyncWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val db = HydrogridDatabase.getInstance(applicationContext)
        val dao = db.hydrogridDao()
        val prefsStore = TerminalPreferencesStore(applicationContext)
        val prefs = prefsStore.preferencesFlow.first()

        if (!prefs.useRemoteBackend) {
            return Result.success()
        }

        val token = KeystoreCredentialManager(applicationContext).getApiToken()
        val client = RetrofitHydrogridApiClient()

        val pending = dao.getPendingActions()
        for (item in pending) {
            val res = client.pushAction(
                baseUrl = prefs.backendBaseUrl,
                role = item.actorRole,
                token = token,
                idempotencyKey = item.idempotencyKey,
                request = RemoteMutationRequest(
                    actionType = item.actionType,
                    entityId = item.entityId,
                    payloadJson = item.payloadJson,
                    expectedVersion = item.expectedVersion
                )
            )
            res.onSuccess {
                dao.deletePendingAction(item.idempotencyKey)
            }.onFailure { err ->
                if (err is ConflictException) {
                    dao.markActionConflict(item.idempotencyKey, err.message ?: "Sync conflict")
                } else {
                    return Result.retry()
                }
            }
        }

        prefsStore.setLastSyncEpochMs(System.currentTimeMillis())
        return Result.success()
    }
}
