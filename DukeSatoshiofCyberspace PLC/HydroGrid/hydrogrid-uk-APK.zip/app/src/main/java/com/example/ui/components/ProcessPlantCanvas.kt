package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.ui.theme.*
import java.util.Locale

/**
 * Interactive layered industrial process illustration driven directly by live PlantSnapshot state.
 * Keeps electrical supply and oxygen exhaust visually distinct from the cyan hydrogen route,
 * respects reduced motion, pauses animation when simulation is paused/faulted/stale, and
 * makes every process skid clickable to open its detailed telemetry & maintenance inspection dialog.
 */
@Composable
fun ProcessPlantIllustration(
    snapshot: PlantSnapshot,
    reducedMotion: Boolean,
    onEquipmentClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val isFlowActive = snapshot.simSpeed != SimSpeed.PAUSED &&
        snapshot.freshnessState != DataFreshnessState.STALE &&
        snapshot.h2OutputKgPerHr > 0.1 &&
        snapshot.flowBlockedReason == null

    val infiniteTransition = rememberInfiniteTransition(label = "processFlow")
    val animatedPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "flowPhase"
    )
    val flowPhase = if (isFlowActive && !reducedMotion) animatedPhase else 0.35f

    val eqMap = remember(snapshot.equipment) { snapshot.equipment.associateBy { it.id } }

    Surface(
        color = PureWhite,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, ThinRuleBlue),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            // Top Process Header & Legend
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "HYDROGEN PRODUCTION & STORAGE PROCESS SCHEMATIC",
                        style = MaterialTheme.typography.titleSmall.copy(
                            color = MidnightNavy,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "Tap any equipment module for live telemetry, sensor provenance, maintenance & alerts",
                        style = MaterialTheme.typography.labelSmall.copy(color = InkMuted)
                    )
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LegendDot("Power Bus", ElectricalGold)
                    LegendDot("Feedwater", SaltireBlue)
                    LegendDot("H₂ Stream", ProcessCyan)
                    LegendDot("O₂ Exhaust", OxygenTeal)
                }
            }

            snapshot.flowBlockedReason?.let { reason ->
                Spacer(Modifier.height(6.dp))
                Surface(
                    color = StatusAmberBg,
                    shape = RoundedCornerShape(4.dp),
                    border = BorderStroke(1.dp, StatusAmber),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = reason,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = StatusAmber,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            // Layered Process Canvas + Accessible Clickable Equipment Overlays
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .heightIn(min = 240.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(SoftPanelBg)
            ) {
                val maxW = maxWidth
                val maxH = maxHeight

                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    // Subtle blueprint grid
                    val gridStep = 28.dp.toPx()
                    var gx = gridStep
                    while (gx < w) {
                        drawLine(ThinRuleBlue.copy(alpha = 0.25f), Offset(gx, 0f), Offset(gx, h), 1f)
                        gx += gridStep
                    }
                    var gy = gridStep
                    while (gy < h) {
                        drawLine(ThinRuleBlue.copy(alpha = 0.25f), Offset(0f, gy), Offset(w, gy), 1f)
                        gy += gridStep
                    }

                    // 7 Stage horizontal anchor X positions
                    val xWater = w * 0.08f
                    val xElx = w * 0.23f
                    val xSep = w * 0.37f
                    val xPur = w * 0.50f
                    val xCmp = w * 0.63f
                    val xStr = w * 0.78f
                    val xDsp = w * 0.92f
                    val yMain = h * 0.56f
                    val yPowerBus = h * 0.14f

                    // 1. Electrical Power Supply Bus (top, distinct Gold/Amber bus -> Rectifier -> Electrolyser + Compressor)
                    val powerActive = snapshot.electrolyserPowerMw > 0.1
                    drawLine(
                        color = if (powerActive) ElectricalGold else BrushedSteelMid,
                        start = Offset(w * 0.04f, yPowerBus),
                        end = Offset(xCmp, yPowerBus),
                        strokeWidth = 3.5.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                    // Drop feeds to Electrolyser & Compressor
                    drawLine(
                        color = if (powerActive) ElectricalGold else BrushedSteelMid,
                        start = Offset(xElx, yPowerBus),
                        end = Offset(xElx, yMain - h * 0.18f),
                        strokeWidth = 3.dp.toPx()
                    )
                    drawLine(
                        color = if (powerActive) ElectricalGold else BrushedSteelMid,
                        start = Offset(xCmp, yPowerBus),
                        end = Offset(xCmp, yMain - h * 0.16f),
                        strokeWidth = 2.5.dp.toPx()
                    )
                    if (isFlowActive && !reducedMotion) {
                        val px = w * 0.04f + flowPhase * (xElx - w * 0.04f)
                        drawCircle(PureWhite, radius = 4.dp.toPx(), center = Offset(px, yPowerBus))
                        drawCircle(ElectricalGold, radius = 2.5.dp.toPx(), center = Offset(px, yPowerBus))
                    }

                    // 2. Distinct Oxygen Vent / Exhaust Header from Electrolyser & Separator
                    drawLine(
                        color = OxygenTeal.copy(alpha = 0.75f),
                        start = Offset(xElx + w * 0.02f, yMain - h * 0.16f),
                        end = Offset(xElx + w * 0.02f, h * 0.24f),
                        strokeWidth = 3.dp.toPx()
                    )
                    drawLine(
                        color = OxygenTeal.copy(alpha = 0.75f),
                        start = Offset(xElx + w * 0.02f, h * 0.24f),
                        end = Offset(xSep + w * 0.03f, h * 0.24f),
                        strokeWidth = 3.dp.toPx()
                    )
                    if (isFlowActive && !reducedMotion) {
                        val oy = (yMain - h * 0.16f) - flowPhase * ((yMain - h * 0.16f) - h * 0.24f)
                        drawCircle(OxygenTeal, radius = 3.dp.toPx(), center = Offset(xElx + w * 0.02f, oy))
                    }

                    // 3. Process Material Flow Pipes
                    val h2Color = when {
                        snapshot.freshnessState == DataFreshnessState.STALE -> StatusStale
                        snapshot.flowBlockedReason != null -> StatusAmber
                        else -> ProcessCyan
                    }
                    // Water -> Electrolyser
                    drawProcessPipe(Offset(xWater, yMain), Offset(xElx, yMain), SaltireBlue, isFlowActive, reducedMotion, flowPhase)
                    // Electrolyser -> Gas Separation -> Purification -> Compression -> Storage -> Dispatch
                    drawProcessPipe(Offset(xElx, yMain), Offset(xSep, yMain), h2Color, isFlowActive, reducedMotion, flowPhase)
                    drawProcessPipe(Offset(xSep, yMain), Offset(xPur, yMain), h2Color, isFlowActive, reducedMotion, flowPhase)
                    drawProcessPipe(Offset(xPur, yMain), Offset(xCmp, yMain), h2Color, isFlowActive, reducedMotion, flowPhase)
                    drawProcessPipe(Offset(xCmp, yMain), Offset(xStr, yMain), h2Color, isFlowActive, reducedMotion, flowPhase)

                    val loadingActive = snapshot.dispatchOrders.any { it.stage == DispatchStage.LOADING }
                    drawProcessPipe(
                        Offset(xStr, yMain),
                        Offset(xDsp, yMain),
                        if (loadingActive) ProcessCyan else BrushedSteelMid,
                        isFlowActive && loadingActive,
                        reducedMotion,
                        flowPhase
                    )

                    // 4. Brushed-Metal Industrial Equipment Illustrations
                    // Water Treatment Skid (RO/EDI twin cylinders)
                    drawBrushedCylinder(Offset(xWater - w * 0.032f, yMain - h * 0.16f), Size(w * 0.028f, h * 0.28f), SaltireBlue)
                    drawBrushedCylinder(Offset(xWater + w * 0.004f, yMain - h * 0.16f), Size(w * 0.028f, h * 0.28f), SaltireBlue)

                    // PEM Electrolyser Array (4 modular stacks)
                    val elxState = eqMap["ELX-200"]?.state ?: EquipmentState.RUNNING
                    drawElectrolyserSkid(Offset(xElx - w * 0.052f, yMain - h * 0.16f), Size(w * 0.104f, h * 0.30f), elxState)

                    // Gas Separation Vessel (vertical drum)
                    drawBrushedCylinder(Offset(xSep - w * 0.028f, yMain - h * 0.17f), Size(w * 0.056f, h * 0.32f), ProcessCyan)

                    // Drying & Purification (Twin-tower TSA columns)
                    drawBrushedCylinder(Offset(xPur - w * 0.034f, yMain - h * 0.18f), Size(w * 0.028f, h * 0.33f), ProcessCyan)
                    drawBrushedCylinder(Offset(xPur + w * 0.006f, yMain - h * 0.18f), Size(w * 0.028f, h * 0.33f), SaltireBlue)

                    // Compressor Skid
                    val cmpState = eqMap["CMP-501"]?.state ?: EquipmentState.RUNNING
                    drawCompressorUnit(Offset(xCmp - w * 0.042f, yMain - h * 0.14f), Size(w * 0.084f, h * 0.26f), cmpState)

                    // 3 Horizontal Pressure-Vessel Storage Banks (live fill inside vessels!)
                    drawStorageBanksIllustration(
                        topLeft = Offset(xStr - w * 0.058f, yMain - h * 0.22f),
                        size = Size(w * 0.116f, h * 0.42f),
                        banks = snapshot.storageBanks
                    )

                    // Tube-Trailer Loading Bay
                    drawTubeTrailer(
                        topLeft = Offset(xDsp - w * 0.052f, yMain - h * 0.13f),
                        size = Size(w * 0.104f, h * 0.25f),
                        loadingActive = loadingActive
                    )
                }

                // Electrical Supply Tag at Top
                Surface(
                    color = StatusAmberBg,
                    shape = RoundedCornerShape(4.dp),
                    border = BorderStroke(1.dp, ElectricalGold),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(start = 10.dp, top = 6.dp)
                ) {
                    Text(
                        text = "HV GRID + WIND PPA • ${String.format(Locale.UK, "%.1f", snapshot.waterElectrolysis.totalPlantPowerMw)} MW",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = MidnightNavy,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                // Distinct O2 Vent Badge
                Surface(
                    color = ProcessCyanSoft,
                    shape = RoundedCornerShape(4.dp),
                    border = BorderStroke(1.dp, OxygenTeal),
                    modifier = Modifier
                        .offset(x = maxW * 0.24f, y = maxH * 0.18f)
                ) {
                    Text(
                        text = "O₂ OUTLET ${String.format(Locale.UK, "%,.0f", snapshot.waterElectrolysis.o2OutputKgPerHr)} kg/h",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = MidnightNavy,
                            fontWeight = FontWeight.SemiBold
                        ),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                // Clickable Equipment Stage Cards / Hit Targets along bottom & over units
                val stagePositions = listOf(
                    "WT-101" to 0.08f,
                    "ELX-200" to 0.23f,
                    "SEP-301" to 0.37f,
                    "PUR-401" to 0.50f,
                    "CMP-501" to 0.63f,
                    "STR-600" to 0.78f,
                    "DSP-701" to 0.92f
                )

                stagePositions.forEach { (id, xFrac) ->
                    val unit = eqMap[id]
                    if (unit != null) {
                        val cardW = (maxW * 0.132f).coerceAtLeast(78.dp)
                        val xOffset = (maxW * xFrac - cardW / 2).coerceIn(2.dp, maxW - cardW - 2.dp)
                        // Interactive hit box over the illustration itself
                        Box(
                            modifier = Modifier
                                .offset(x = xOffset, y = maxH * 0.33f)
                                .size(width = cardW, height = maxH * 0.43f)
                                .clickable { onEquipmentClick(unit.id) }
                                .testTag("process_node_${unit.id}")
                                .semantics { contentDescription = "Inspect ${unit.name}" }
                        )
                        // Compact technical label below each unit
                        Surface(
                            color = PureWhite,
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(
                                1.dp,
                                when (unit.state) {
                                    EquipmentState.FAULT -> StatusFault
                                    EquipmentState.BLOCKED, EquipmentState.MAINTENANCE -> StatusAmber
                                    else -> ThinRuleBlue
                                }
                            ),
                            modifier = Modifier
                                .offset(x = xOffset, y = maxH - 54.dp)
                                .width(cardW)
                                .clickable { onEquipmentClick(unit.id) }
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 4.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = unit.tag,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = SaltireBlue,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    maxLines = 1
                                )
                                Text(
                                    text = unit.primaryMetricValue,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = InkPrimary,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 9.5.sp
                                    ),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .background(color, RoundedCornerShape(2.dp))
        )
        Text(label, style = MaterialTheme.typography.labelSmall.copy(color = InkSecondary))
    }
}

private fun DrawScope.drawProcessPipe(
    start: Offset,
    end: Offset,
    color: Color,
    animated: Boolean,
    reducedMotion: Boolean,
    phase: Float
) {
    drawLine(
        color = BrushedSteelMid.copy(alpha = 0.45f),
        start = start,
        end = end,
        strokeWidth = 7.dp.toPx(),
        cap = StrokeCap.Round
    )
    drawLine(
        color = color,
        start = start,
        end = end,
        strokeWidth = 3.5.dp.toPx(),
        cap = StrokeCap.Round
    )
    if (animated && !reducedMotion) {
        val segs = 2
        for (i in 0 until segs) {
            val t = (phase + i / segs.toFloat()) % 1f
            val px = start.x + (end.x - start.x) * t
            val py = start.y + (end.y - start.y) * t
            drawCircle(PureWhite, radius = 3.dp.toPx(), center = Offset(px, py))
        }
    }
}

private fun DrawScope.drawBrushedCylinder(topLeft: Offset, size: Size, accent: Color) {
    val metalBrush = Brush.horizontalGradient(
        colors = listOf(BrushedSteelMid, PureWhite, BrushedSteelLight, BrushedSteelMid),
        startX = topLeft.x,
        endX = topLeft.x + size.width
    )
    drawRoundRect(
        brush = metalBrush,
        topLeft = topLeft,
        size = size,
        cornerRadius = CornerRadius(size.width * 0.35f, size.width * 0.35f)
    )
    drawRoundRect(
        color = BrushedSteelDark,
        topLeft = topLeft,
        size = size,
        cornerRadius = CornerRadius(size.width * 0.35f, size.width * 0.35f),
        style = Stroke(width = 1.5.dp.toPx())
    )
    // Accent collar band
    drawRect(
        color = accent,
        topLeft = Offset(topLeft.x + 2f, topLeft.y + size.height * 0.18f),
        size = Size(size.width - 4f, 4.dp.toPx())
    )
}

private fun DrawScope.drawElectrolyserSkid(topLeft: Offset, size: Size, state: EquipmentState) {
    val frameColor = when (state) {
        EquipmentState.FAULT -> StatusFault
        EquipmentState.BLOCKED, EquipmentState.MAINTENANCE -> StatusAmber
        else -> MidnightNavy
    }
    drawRoundRect(
        brush = Brush.verticalGradient(
            listOf(BrushedSteelLight, PureWhite, BrushedSteelMid),
            startY = topLeft.y,
            endY = topLeft.y + size.height
        ),
        topLeft = topLeft,
        size = size,
        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
    )
    drawRoundRect(
        color = frameColor,
        topLeft = topLeft,
        size = size,
        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx()),
        style = Stroke(width = 2.dp.toPx())
    )
    // 4 PEM Stack cells inside skid
    val cellW = (size.width - 14.dp.toPx()) / 4f
    for (i in 0 until 4) {
        val cx = topLeft.x + 4.dp.toPx() + i * (cellW + 2.dp.toPx())
        drawRect(
            color = if (state == EquipmentState.RUNNING) SaltireBlue else BrushedSteelDark,
            topLeft = Offset(cx, topLeft.y + 8.dp.toPx()),
            size = Size(cellW, size.height - 16.dp.toPx())
        )
        drawLine(
            color = ProcessCyanBright,
            start = Offset(cx + cellW * 0.5f, topLeft.y + 10.dp.toPx()),
            end = Offset(cx + cellW * 0.5f, topLeft.y + size.height - 10.dp.toPx()),
            strokeWidth = 1.5.dp.toPx()
        )
    }
}

private fun DrawScope.drawCompressorUnit(topLeft: Offset, size: Size, state: EquipmentState) {
    val rimColor = when (state) {
        EquipmentState.FAULT -> StatusFault
        EquipmentState.BLOCKED -> StatusAmber
        else -> MidnightNavy
    }
    drawRoundRect(
        brush = Brush.verticalGradient(listOf(PureWhite, BrushedSteelLight, BrushedSteelMid)),
        topLeft = topLeft,
        size = size,
        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
    )
    drawRoundRect(
        color = rimColor,
        topLeft = topLeft,
        size = size,
        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx()),
        style = Stroke(width = 1.8.dp.toPx())
    )
    val center = Offset(topLeft.x + size.width * 0.5f, topLeft.y + size.height * 0.5f)
    val radius = (minOf(size.width, size.height) * 0.34f)
    drawCircle(color = SaltireBlue.copy(alpha = 0.2f), radius = radius, center = center)
    drawCircle(color = SaltireBlue, radius = radius, center = center, style = Stroke(2.dp.toPx()))
    drawCircle(color = ProcessCyan, radius = radius * 0.4f, center = center)
}

private fun DrawScope.drawStorageBanksIllustration(
    topLeft: Offset,
    size: Size,
    banks: List<StorageBank>
) {
    val count = banks.size.coerceAtLeast(1)
    val vesselH = (size.height - (count - 1) * 6.dp.toPx()) / count
    banks.forEachIndexed { idx, bank ->
        val vy = topLeft.y + idx * (vesselH + 6.dp.toPx())
        val vTopLeft = Offset(topLeft.x, vy)
        val vSize = Size(size.width, vesselH)
        val fillFrac = (bank.inventoryKg / bank.maxCapacityKg.coerceAtLeast(1.0)).toFloat().coerceIn(0f, 1f)
        val isHold = bank.linkedBatchId == "H2-042"

        // Brushed-metal horizontal pressure vessel
        drawRoundRect(
            brush = Brush.verticalGradient(
                listOf(BrushedSteelMid, PureWhite, BrushedSteelLight),
                startY = vy,
                endY = vy + vesselH
            ),
            topLeft = vTopLeft,
            size = vSize,
            cornerRadius = CornerRadius(vesselH * 0.5f, vesselH * 0.5f)
        )
        // Live fill gauge inside vessel
        drawRoundRect(
            color = if (isHold) StatusAmber.copy(alpha = 0.72f) else ProcessCyan.copy(alpha = 0.72f),
            topLeft = vTopLeft,
            size = Size(vSize.width * fillFrac, vSize.height),
            cornerRadius = CornerRadius(vesselH * 0.5f, vesselH * 0.5f)
        )
        drawRoundRect(
            color = if (bank.isAtOperatingLimit) StatusAmber else MidnightNavy,
            topLeft = vTopLeft,
            size = vSize,
            cornerRadius = CornerRadius(vesselH * 0.5f, vesselH * 0.5f),
            style = Stroke(width = 1.6.dp.toPx())
        )
    }
}

private fun DrawScope.drawTubeTrailer(topLeft: Offset, size: Size, loadingActive: Boolean) {
    val chassisY = topLeft.y + size.height * 0.72f
    // Trailer tubes
    val tubeH = size.height * 0.20f
    for (row in 0..2) {
        val ty = topLeft.y + row * (tubeH + 2.dp.toPx())
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(PureWhite, BrushedSteelLight, BrushedSteelMid)),
            topLeft = Offset(topLeft.x, ty),
            size = Size(size.width * 0.88f, tubeH),
            cornerRadius = CornerRadius(tubeH * 0.45f, tubeH * 0.45f)
        )
        drawRoundRect(
            color = if (loadingActive) ProcessCyan else BrushedSteelDark,
            topLeft = Offset(topLeft.x, ty),
            size = Size(size.width * 0.88f, tubeH),
            cornerRadius = CornerRadius(tubeH * 0.45f, tubeH * 0.45f),
            style = Stroke(width = 1.2.dp.toPx())
        )
    }
    // Chassis + Wheels
    drawRect(
        color = MidnightNavy,
        topLeft = Offset(topLeft.x, chassisY),
        size = Size(size.width, 4.dp.toPx())
    )
    val wheelR = 5.dp.toPx()
    drawCircle(MidnightNavy, wheelR, Offset(topLeft.x + size.width * 0.22f, chassisY + wheelR + 2f))
    drawCircle(MidnightNavy, wheelR, Offset(topLeft.x + size.width * 0.68f, chassisY + wheelR + 2f))
}
