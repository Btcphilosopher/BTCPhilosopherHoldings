package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Hydrogrid UK Scottish Industrial Palette
val MidnightNavy = Color(0xFF0A192F)
val MidnightNavySurface = Color(0xFF0E2342)
val MidnightNavyElevated = Color(0xFF142E54)
val MidnightNavyBorder = Color(0xFF1F3E6E)

val SaltireBlue = Color(0xFF005EB8)
val ActiveNavBlue = Color(0xFF1D63DC)
val ThinRuleBlue = Color(0xFFBFD7F5)

val ProcessCyan = Color(0xFF00B4D8)
val ProcessCyanBright = Color(0xFF22D3EE)
val ProcessCyanSoft = Color(0xFFE0F7FA)

val OxygenTeal = Color(0xFF0EA5E9)
val ElectricalGold = Color(0xFFF59E0B)
val BrushedSteelLight = Color(0xFFE2E8F0)
val BrushedSteelMid = Color(0xFF94A3B8)
val BrushedSteelDark = Color(0xFF475569)

// Surfaces & Text
val CanvasSlate = Color(0xFFF1F5F9)
val PureWhite = Color(0xFFFFFFFF)
val SoftPanelBg = Color(0xFFF8FAFC)
val InkPrimary = Color(0xFF0F172A)
val InkSecondary = Color(0xFF475569)
val InkMuted = Color(0xFF64748B)
val HairlineBorder = Color(0xFFCBD5E1)

// Semantic Status Colors (consistent across all workspaces)
val StatusHealthy = Color(0xFF059669)
val StatusHealthyBg = Color(0xFFECFDF5)
val StatusAmber = Color(0xFFD97706)
val StatusAmberBg = Color(0xFFFEF3C7)
val StatusFault = Color(0xFFDC2626)
val StatusFaultBg = Color(0xFFFEE2E2)
val StatusStale = Color(0xFF64748B)
val StatusStaleBg = Color(0xFFE2E8F0)
val StatusDemo = Color(0xFF1D4ED8)
val StatusDemoBg = Color(0xFFDBEAFE)
