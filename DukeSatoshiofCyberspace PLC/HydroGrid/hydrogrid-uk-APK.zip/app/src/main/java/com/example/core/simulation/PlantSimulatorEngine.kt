package com.example.core.simulation

import com.example.core.model.*
import java.util.Locale
import java.util.UUID
import kotlin.math.max
import kotlin.math.min

/**
 * Simplified configurable mass-and-energy process simulator for Hydrogrid UK.
 * NOTE: Not a validated electrolyser engineering model; all efficiency and tariff
 * assumptions are configurable and explicitly documented for demonstration/planning.
 */
class PlantSimulatorEngine {

    private var state: PlantSnapshot = createInitialSnapshot()
    private val processedIdempotencyKeys = mutableSetOf<String>()

    fun snapshot(): PlantSnapshot = state

    fun reset(role: UserRole = state.activeRole): PlantSnapshot {
        processedIdempotencyKeys.clear()
        state = createInitialSnapshot(activeRole = role)
        return state
    }

    fun setSpeed(speed: SimSpeed): PlantSnapshot {
        state = state.copy(simSpeed = speed, version = state.version + 1)
        return state
    }

    fun setElectricalBoundary(boundary: ElectricalBoundary): PlantSnapshot {
        state = state.copy(electricalBoundary = boundary, version = state.version + 1)
        return state
    }

    fun setRole(role: UserRole): PlantSnapshot {
        state = state.copy(activeRole = role)
        return state
    }

    fun setFreshnessState(freshness: DataFreshnessState, dataAgeSeconds: Long = 0L): PlantSnapshot {
        state = state.copy(
            freshnessState = freshness,
            dataAgeSeconds = dataAgeSeconds
        )
        return state
    }

    fun updateWallClock(wallTimeIso: String, incrementDataAge: Boolean): PlantSnapshot {
        val nextAge = if (incrementDataAge) state.dataAgeSeconds + 1 else 0L
        val nextFreshness = when {
            state.freshnessState == DataFreshnessState.DEMO_DATA -> DataFreshnessState.DEMO_DATA
            nextAge >= 30L -> DataFreshnessState.STALE
            else -> state.freshnessState
        }
        state = state.copy(
            wallTimeIso = wallTimeIso,
            dataAgeSeconds = nextAge,
            freshnessState = nextFreshness
        )
        return state
    }

    fun step(realSeconds: Double = 1.0): PlantSnapshot {
        val multiplier = state.simSpeed.multiplier
        if (multiplier <= 0) return state

        val dtSeconds = realSeconds * multiplier
        val dtHours = dtSeconds / 3600.0
        val newElapsed = state.simElapsedSeconds + dtSeconds.toLong().coerceAtLeast(1L)
        val simClockStr = formatSimClock(newElapsed)

        val elx = state.equipment.first { it.id == "ELX-200" }
        val wt = state.equipment.first { it.id == "WT-101" }
        val cmp = state.equipment.first { it.id == "CMP-501" }

        val hasBlockingFault = elx.state == EquipmentState.FAULT ||
            wt.state == EquipmentState.FAULT ||
            cmp.state == EquipmentState.FAULT ||
            elx.state == EquipmentState.MAINTENANCE ||
            wt.state == EquipmentState.MAINTENANCE

        val activeBankIdx = state.storageBanks.indexOfFirst { !it.isAtOperatingLimit && it.state != EquipmentState.MAINTENANCE }
        val allStorageFull = activeBankIdx == -1

        val effectiveFlowBlockedReason = when {
            hasBlockingFault -> "Upstream unit fault/maintenance halted production"
            allStorageFull -> "BLOCKED FLOW: All storage banks at configured operating max limit"
            state.waterElectrolysis.treatedWaterAvailableL <= 50.0 -> "Treated water buffer depleted"
            else -> null
        }

        val targetMw = if (effectiveFlowBlockedReason != null) 0.0 else state.simConfig.targetPowerMw
        val secPlant = state.simConfig.plantSpecificEnergyKwhPerKg.coerceAtLeast(1.0)
        val secStack = state.simConfig.stackSpecificEnergyKwhPerKg.coerceAtLeast(1.0)

        // Net H2 output (kg/h) bounded by configured capacity & available storage headroom
        val rawH2RateKgHr = if (effectiveFlowBlockedReason != null) 0.0
        else min(
            state.simConfig.electrolyserMaxCapacityKgHr,
            (targetMw * 1000.0) / secPlant
        )

        val purRecovery = (state.simConfig.purificationRecoveryPct / 100.0).coerceIn(0.85, 1.0)
        val grossStackH2KgHr = if (rawH2RateKgHr > 0.0) rawH2RateKgHr / purRecovery else 0.0
        val h2LossKgHr = (grossStackH2KgHr - rawH2RateKgHr).coerceAtLeast(0.0)
        val o2RateKgHr = grossStackH2KgHr * 7.9365 // Stoichiometric O2/H2 mass ratio (16 / 2.016)
        val stoichWaterKgHr = grossStackH2KgHr * 8.9365 // Stoichiometric H2O/H2 mass ratio (18.015 / 2.016)
        val wtRecovery = (state.simConfig.waterTreatmentRecoveryPct / 100.0).coerceIn(0.4, 0.98)
        val feedwaterFlowLHr = if (stoichWaterKgHr > 0.0) stoichWaterKgHr / wtRecovery else 0.0
        val rejectLossLHr = feedwaterFlowLHr * (1.0 - wtRecovery) * 0.82
        val ediBlowdownLHr = feedwaterFlowLHr * (1.0 - wtRecovery) * 0.18

        // Energy split: Stack DC + Aux Balance of Plant + Compression
        val stackDcMw = if (grossStackH2KgHr > 0.0) (grossStackH2KgHr * secStack) / 1000.0 else 0.0
        val compressionMw = if (rawH2RateKgHr > 0.0) (rawH2RateKgHr * 2.35) / 1000.0 else 0.0
        val auxBopMw = (targetMw - stackDcMw - compressionMw).coerceAtLeast(0.0)

        // Material delta over dtHours
        val producedKg = rawH2RateKgHr * dtHours
        val h2LossKg = h2LossKgHr * dtHours
        val o2Kg = o2RateKgHr * dtHours
        val waterLossL = (rejectLossLHr + ediBlowdownLHr) * dtHours

        val updatedBanks = state.storageBanks.toMutableList()
        var actualStoredKg = 0.0
        var remainingToStore = producedKg
        if (remainingToStore > 0.0) {
            for (i in updatedBanks.indices) {
                val bank = updatedBanks[i]
                if (bank.state == EquipmentState.MAINTENANCE) continue
                val headroom = bank.availableHeadroomKg
                if (headroom > 0.0) {
                    val addKg = min(remainingToStore, headroom)
                    val newInv = bank.inventoryKg + addKg
                    val newPressure = estimatePressureFromMassBar(
                        massKg = newInv,
                        volumeM3 = bank.vesselVolumeM3,
                        tempC = bank.temperatureC
                    )
                    updatedBanks[i] = bank.copy(
                        inventoryKg = newInv,
                        pressureBar = newPressure,
                        state = if (newInv >= bank.operatingMaxKg - 0.5) EquipmentState.BLOCKED else EquipmentState.RUNNING
                    )
                    actualStoredKg += addKg
                    remainingToStore -= addKg
                    if (remainingToStore <= 1e-6) break
                }
            }
        }

        // Advance active loading trailers gradually
        var dispatchedDelta = 0.0
        val updatedOrders = state.dispatchOrders.map { order ->
            if (order.stage == DispatchStage.LOADING && order.estimatedLoadedKg < order.requestedMassKg) {
                val loadStep = min(240.0 * dtHours, order.requestedMassKg - order.estimatedLoadedKg)
                val bankIdx = updatedBanks.indexOfFirst { it.id == order.sourceBankId }
                if (bankIdx >= 0 && updatedBanks[bankIdx].inventoryKg >= loadStep) {
                    val b = updatedBanks[bankIdx]
                    val nextInv = (b.inventoryKg - loadStep).coerceAtLeast(0.0)
                    updatedBanks[bankIdx] = b.copy(
                        inventoryKg = nextInv,
                        pressureBar = estimatePressureFromMassBar(nextInv, b.vesselVolumeM3, b.temperatureC),
                        state = EquipmentState.RUNNING
                    )
                    dispatchedDelta += loadStep
                    order.copy(estimatedLoadedKg = order.estimatedLoadedKg + loadStep)
                } else order
            } else order
        }

        val totalStored = updatedBanks.sumOf { it.inventoryKg }
        val newTrend = (state.outputTrendKgHr.drop(1) + rawH2RateKgHr.toFloat())
        val newWaterHist = (state.waterElectrolysis.waterFlowHistory.drop(1) + feedwaterFlowLHr.toFloat())
        val newPowerHist = (state.waterElectrolysis.powerHistoryMw.drop(1) + targetMw.toFloat())

        val nextStateForUnits = if (effectiveFlowBlockedReason != null) {
            if (allStorageFull) EquipmentState.BLOCKED else EquipmentState.STANDBY
        } else EquipmentState.RUNNING

        val updatedEquipment = state.equipment.map { unit ->
            val nextUnitState = when {
                unit.state == EquipmentState.FAULT || unit.state == EquipmentState.MAINTENANCE -> unit.state
                effectiveFlowBlockedReason != null -> nextStateForUnits
                else -> EquipmentState.RUNNING
            }
            val hrsInc = if (nextUnitState == EquipmentState.RUNNING) dtHours else 0.0
            val nextHist = (unit.historySeries.drop(1) + when (unit.stageId) {
                ProcessStageId.WATER_TREATMENT -> feedwaterFlowLHr.toFloat()
                ProcessStageId.ELECTROLYSIS -> targetMw.toFloat()
                ProcessStageId.COMPRESSION -> if (nextUnitState == EquipmentState.RUNNING) 380f else 120f
                ProcessStageId.STORAGE -> totalStored.toFloat()
                else -> rawH2RateKgHr.toFloat()
            })
            unit.copy(
                state = nextUnitState,
                operatingHours = unit.operatingHours + hrsInc,
                historySeries = nextHist,
                primaryMetricValue = when (unit.stageId) {
                    ProcessStageId.WATER_TREATMENT -> format1(feedwaterFlowLHr) + " L/h"
                    ProcessStageId.ELECTROLYSIS -> format1(targetMw) + " MW"
                    ProcessStageId.GAS_SEPARATION -> format1(grossStackH2KgHr) + " kg/h"
                    ProcessStageId.DRYING_PURIFICATION -> format1(rawH2RateKgHr) + " kg/h"
                    ProcessStageId.COMPRESSION -> if (nextUnitState == EquipmentState.RUNNING) "382 bar" else "118 bar"
                    ProcessStageId.STORAGE -> format0(totalStored) + " kg"
                    ProcessStageId.DISPATCH -> format0(state.dispatchTodayKg + dispatchedDelta) + " kg"
                },
                activeAlertSummary = effectiveFlowBlockedReason ?: unit.activeAlertSummary
            )
        }

        val updatedCompressors = state.compressors.map { cmpUnit ->
            val cmpState = when {
                cmpUnit.state == EquipmentState.FAULT || cmpUnit.state == EquipmentState.MAINTENANCE -> cmpUnit.state
                allStorageFull -> EquipmentState.BLOCKED
                effectiveFlowBlockedReason != null -> EquipmentState.STANDBY
                else -> EquipmentState.RUNNING
            }
            cmpUnit.copy(
                state = cmpState,
                throughputKgPerHr = if (cmpState == EquipmentState.RUNNING) rawH2RateKgHr / 2.0 else 0.0,
                powerKw = if (cmpState == EquipmentState.RUNNING) (compressionMw * 1000.0) / 2.0 else 4.0,
                blockedReason = if (allStorageFull) "Storage bank operating max reached" else null
            )
        }

        val updatedWe = state.waterElectrolysis.copy(
            feedwaterFlowLPerHr = feedwaterFlowLHr,
            roRejectLossLPerHr = rejectLossLHr,
            ediBlowdownLossLPerHr = ediBlowdownLHr,
            stoichiometricWaterUsedKgPerHr = stoichWaterKgHr,
            treatedWaterAvailableL = (state.waterElectrolysis.treatedWaterAvailableL + (feedwaterFlowLHr - rejectLossLHr - ediBlowdownLHr - stoichWaterKgHr) * dtHours)
                .coerceIn(1000.0, state.waterElectrolysis.treatedTankCapacityL),
            stackDcPowerMw = stackDcMw,
            auxBalanceOfPlantMw = auxBopMw,
            compressionPowerMw = compressionMw,
            totalPlantPowerMw = targetMw,
            h2OutputKgPerHr = rawH2RateKgHr,
            o2OutputKgPerHr = o2RateKgHr,
            h2PurificationLossKgPerHr = h2LossKgHr,
            stackOperatingHours = state.waterElectrolysis.stackOperatingHours + (if (rawH2RateKgHr > 0.0) dtHours else 0.0),
            waterFlowHistory = newWaterHist,
            powerHistoryMw = newPowerHist
        )

        val updatedBatches = state.qualityBatches.map { b ->
            if (b.batchId == "H2-042") {
                b.copy(
                    producedMassKg = b.producedMassKg + actualStoredKg,
                    remainingMassKg = b.remainingMassKg + actualStoredKg
                )
            } else b
        }

        state = state.copy(
            simTimeIso = simClockStr,
            simElapsedSeconds = newElapsed,
            dataAgeSeconds = if (state.freshnessState == DataFreshnessState.STALE) state.dataAgeSeconds else 0L,
            h2OutputKgPerHr = rawH2RateKgHr,
            electrolyserPowerMw = updatedWe.effectivePowerMw(state.electricalBoundary),
            storageInventoryKg = totalStored,
            dispatchTodayKg = state.dispatchTodayKg + dispatchedDelta,
            producedTodayKg = state.producedTodayKg + producedKg,
            h2LossesTodayKg = state.h2LossesTodayKg + h2LossKg,
            o2OutputTodayKg = state.o2OutputTodayKg + o2Kg,
            waterLossTodayL = state.waterLossTodayL + waterLossL,
            flowBlockedReason = effectiveFlowBlockedReason,
            outputTrendKgHr = newTrend,
            waterElectrolysis = updatedWe,
            compressors = updatedCompressors,
            storageBanks = updatedBanks,
            equipment = updatedEquipment,
            qualityBatches = updatedBatches,
            dispatchOrders = updatedOrders,
            version = state.version + 1
        )
        return state
    }

    fun registerSample(
        batchId: String,
        sourceType: ReadingSourceType,
        purityPct: Double,
        moisturePpm: Double,
        oxygenPpm: Double,
        analystName: String,
        attachmentRef: String?,
        notes: String,
        correctionReason: String? = null,
        idempotencyKey: String = UUID.randomUUID().toString()
    ): Result<PlantSnapshot> {
        if (!processedIdempotencyKeys.add(idempotencyKey)) return Result.success(state)
        if (state.activeRole !in setOf(UserRole.LAB_STAFF, UserRole.SUPERVISOR, UserRole.ADMIN)) {
            return Result.failure(IllegalStateException("Role ${state.activeRole.title} cannot register laboratory samples."))
        }
        val batch = state.qualityBatches.find { it.batchId == batchId }
            ?: return Result.failure(IllegalArgumentException("Batch $batchId not found"))

        val spec = state.acceptanceSpec
        val withinSpec = purityPct >= spec.minPurityPct &&
            moisturePpm <= spec.maxMoisturePpm &&
            oxygenPpm <= spec.maxOxygenPpm

        val isOriginal = batch.samples.none { it.purityPct != null }
        val newSample = LabSample(
            sampleId = "SMP-${100 + batch.samples.size + 1}",
            batchId = batchId,
            timestampIso = state.simTimeIso,
            sourceType = sourceType,
            purityPct = purityPct,
            moisturePpm = moisturePpm,
            oxygenPpm = oxygenPpm,
            predictedPurityPct = batch.predictedPurityPct,
            predictedMoisturePpm = batch.predictedMoisturePpm,
            attachmentRef = attachmentRef?.takeIf { it.isNotBlank() },
            analystName = analystName.ifBlank { state.activeRole.title },
            notes = notes,
            isOriginalRecord = isOriginal,
            correctionReason = if (!isOriginal) (correctionReason ?: "Retest / Superseding sample") else null
        )

        // Note: Passing threshold NEVER auto-certifies or auto-releases; supervisor/lab review is required!
        val nextReview = if (withinSpec) LabReviewStatus.REVIEWED_PASS else LabReviewStatus.REVIEWED_FAIL
        val nextRelease = if (withinSpec) batch.releaseStatus else BatchReleaseStatus.QUARANTINED

        val updatedBatches = state.qualityBatches.map {
            if (it.batchId == batchId) {
                it.copy(
                    latestSampleTimestamp = state.simTimeIso,
                    measuredPurityPct = purityPct,
                    measuredMoisturePpm = moisturePpm,
                    reviewStatus = nextReview,
                    releaseStatus = nextRelease,
                    samples = it.samples + newSample // Preserve all original records!
                )
            } else it
        }
        val audit = AuditEntry(
            id = "AUD-${state.auditLog.size + 1}",
            timestampIso = state.simTimeIso,
            actorRole = state.activeRole,
            action = if (isOriginal) "REGISTER_LAB_SAMPLE" else "RETEST_LAB_SAMPLE",
            entityRef = batchId,
            detail = "${sourceType.label}: purity=${format3(purityPct)}%, moisture=${format1(moisturePpm)} ppm (Hold remains until authorised release)",
            idempotencyKey = idempotencyKey
        )
        state = state.copy(
            qualityBatches = updatedBatches,
            auditLog = listOf(audit) + state.auditLog,
            version = state.version + 1
        )
        return Result.success(state)
    }

    fun authoriseBatchRelease(
        batchId: String,
        authoriserName: String,
        idempotencyKey: String = UUID.randomUUID().toString()
    ): Result<PlantSnapshot> {
        if (!processedIdempotencyKeys.add(idempotencyKey)) return Result.success(state)
        if (state.activeRole !in setOf(UserRole.SUPERVISOR, UserRole.LAB_STAFF, UserRole.ADMIN)) {
            return Result.failure(IllegalStateException("Only Lab Staff, Supervisor, or Admin may release batches."))
        }
        val batch = state.qualityBatches.find { it.batchId == batchId }
            ?: return Result.failure(IllegalArgumentException("Batch $batchId not found"))
        if (batch.reviewStatus != LabReviewStatus.REVIEWED_PASS || batch.measuredPurityPct == null) {
            return Result.failure(IllegalStateException("Batch $batchId cannot be released before a passing reviewed laboratory sample."))
        }
        val updatedBatches = state.qualityBatches.map {
            if (it.batchId == batchId) {
                it.copy(
                    releaseStatus = BatchReleaseStatus.RELEASED,
                    authorisedBy = authoriserName.ifBlank { state.activeRole.title },
                    authorisedAtIso = state.simTimeIso
                )
            } else it
        }
        val audit = AuditEntry(
            id = "AUD-${state.auditLog.size + 1}",
            timestampIso = state.simTimeIso,
            actorRole = state.activeRole,
            action = "AUTHORISE_BATCH_RELEASE",
            entityRef = batchId,
            detail = "Released batch $batchId under spec ${batch.specVersion} by $authoriserName",
            idempotencyKey = idempotencyKey
        )
        state = state.copy(
            qualityBatches = updatedBatches,
            auditLog = listOf(audit) + state.auditLog,
            version = state.version + 1
        )
        return Result.success(state)
    }

    fun advanceDispatchOrder(
        orderId: String,
        targetStage: DispatchStage,
        confirmedTransferKg: Double? = null,
        reason: String? = null,
        idempotencyKey: String = UUID.randomUUID().toString()
    ): Result<PlantSnapshot> {
        if (!processedIdempotencyKeys.add(idempotencyKey)) return Result.success(state)
        if (state.activeRole !in setOf(UserRole.DISPATCH, UserRole.SUPERVISOR, UserRole.OPERATOR, UserRole.ADMIN)) {
            return Result.failure(IllegalStateException("Role ${state.activeRole.title} cannot modify dispatch orders."))
        }
        val order = state.dispatchOrders.find { it.orderId == orderId }
            ?: return Result.failure(IllegalArgumentException("Order $orderId not found"))

        val linkedBatch = state.qualityBatches.find { it.batchId == order.assignedBatchId }
        // Gate dispatch authorisation & loading if batch is on quality hold or quarantined!
        if (targetStage in setOf(DispatchStage.AUTHORISED, DispatchStage.LOADING, DispatchStage.RECONCILED, DispatchStage.RELEASED)) {
            if (linkedBatch == null || linkedBatch.releaseStatus != BatchReleaseStatus.RELEASED) {
                val holdReason = "Blocked: Batch ${order.assignedBatchId} is ${linkedBatch?.releaseStatus?.label ?: "UNASSIGNED"} — quality-held inventory cannot be dispatched."
                val heldOrders = state.dispatchOrders.map {
                    if (it.orderId == orderId) it.copy(stage = DispatchStage.HELD, holdOrExceptionReason = holdReason) else it
                }
                state = state.copy(
                    dispatchOrders = heldOrders,
                    auditLog = listOf(
                        AuditEntry(
                            id = "AUD-${state.auditLog.size + 1}",
                            timestampIso = state.simTimeIso,
                            actorRole = state.activeRole,
                            action = "DISPATCH_BLOCKED_QUALITY_HOLD",
                            entityRef = orderId,
                            detail = holdReason,
                            idempotencyKey = idempotencyKey
                        )
                    ) + state.auditLog,
                    version = state.version + 1
                )
                return Result.failure(IllegalStateException(holdReason))
            }
        }

        val updatedBanks = state.storageBanks.toMutableList()
        var dispatchDelta = 0.0
        var finalEstimated = order.estimatedLoadedKg
        var finalConfirmed = order.confirmedTransferKg
        var docNumber = order.deliveryDocNumber

        if (targetStage == DispatchStage.RECONCILED) {
            val confirmed = confirmedTransferKg ?: order.requestedMassKg
            // Traceable movement without double deduction: only adjust storage by delta (confirmed - estimatedLoadedKg)
            val deltaToDeduct = confirmed - order.estimatedLoadedKg
            val bankIdx = updatedBanks.indexOfFirst { it.id == order.sourceBankId }
            if (bankIdx >= 0) {
                val b = updatedBanks[bankIdx]
                if (deltaToDeduct > b.inventoryKg) {
                    return Result.failure(IllegalStateException("Insufficient released inventory in ${b.name} for reconciliation."))
                }
                val newInv = (b.inventoryKg - deltaToDeduct).coerceAtLeast(0.0)
                updatedBanks[bankIdx] = b.copy(
                    inventoryKg = newInv,
                    pressureBar = estimatePressureFromMassBar(newInv, b.vesselVolumeM3, b.temperatureC),
                    state = if (newInv < b.operatingMaxKg - 0.5) EquipmentState.RUNNING else b.state
                )
            }
            dispatchDelta = deltaToDeduct
            finalConfirmed = confirmed
            finalEstimated = order.estimatedLoadedKg
            docNumber = docNumber ?: "DN-UK-${orderId.takeLast(3)}-${state.simElapsedSeconds % 1000}"
        }

        val updatedOrders = state.dispatchOrders.map {
            if (it.orderId == orderId) {
                it.copy(
                    stage = targetStage,
                    estimatedLoadedKg = finalEstimated,
                    confirmedTransferKg = finalConfirmed,
                    deliveryDocNumber = docNumber,
                    holdOrExceptionReason = reason
                )
            } else it
        }

        val totalStored = updatedBanks.sumOf { it.inventoryKg }
        val audit = AuditEntry(
            id = "AUD-${state.auditLog.size + 1}",
            timestampIso = state.simTimeIso,
            actorRole = state.activeRole,
            action = "DISPATCH_${targetStage.name}",
            entityRef = orderId,
            detail = "Order $orderId (${order.trailerRegistration}) -> ${targetStage.label}" +
                (finalConfirmed?.let { " | Confirmed: ${format1(it)} kg" } ?: ""),
            idempotencyKey = idempotencyKey
        )

        state = state.copy(
            storageBanks = updatedBanks,
            storageInventoryKg = totalStored,
            dispatchTodayKg = (state.dispatchTodayKg + dispatchDelta).coerceAtLeast(0.0),
            dispatchOrders = updatedOrders,
            auditLog = listOf(audit) + state.auditLog,
            version = state.version + 1
        )
        return Result.success(state)
    }

    fun updateStorageLimits(bankId: String, operatingMinKg: Double, operatingMaxKg: Double): Result<PlantSnapshot> {
        if (state.activeRole !in setOf(UserRole.ADMIN, UserRole.SUPERVISOR, UserRole.OPERATOR)) {
            return Result.failure(IllegalStateException("Insufficient role permissions to edit operating limits."))
        }
        val bank = state.storageBanks.find { it.id == bankId }
            ?: return Result.failure(IllegalArgumentException("Bank $bankId not found"))
        if (operatingMinKg < 0 || operatingMaxKg > bank.maxCapacityKg || operatingMinKg >= operatingMaxKg) {
            return Result.failure(IllegalArgumentException("Limits must satisfy 0 <= min < max <= ${bank.maxCapacityKg.toInt()} kg"))
        }
        val updated = state.storageBanks.map {
            if (it.id == bankId) {
                it.copy(
                    operatingMinKg = operatingMinKg,
                    operatingMaxKg = operatingMaxKg,
                    state = if (it.inventoryKg >= operatingMaxKg - 0.5) EquipmentState.BLOCKED else EquipmentState.RUNNING
                )
            } else it
        }
        state = state.copy(
            storageBanks = updated,
            auditLog = listOf(
                AuditEntry(
                    id = "AUD-${state.auditLog.size + 1}",
                    timestampIso = state.simTimeIso,
                    actorRole = state.activeRole,
                    action = "UPDATE_STORAGE_LIMITS",
                    entityRef = bankId,
                    detail = "Operating envelope updated to ${operatingMinKg.toInt()}–${operatingMaxKg.toInt()} kg",
                    idempotencyKey = UUID.randomUUID().toString()
                )
            ) + state.auditLog,
            version = state.version + 1
        )
        return Result.success(state)
    }

    fun acknowledgeAlert(alertId: String): PlantSnapshot {
        // Explicitly acknowledges without falsely marking physical condition resolved!
        val updatedAlerts = state.alerts.map {
            if (it.id == alertId) it.copy(acknowledged = true, acknowledgedBy = state.activeRole.title) else it
        }
        state = state.copy(
            alerts = updatedAlerts,
            auditLog = listOf(
                AuditEntry(
                    id = "AUD-${state.auditLog.size + 1}",
                    timestampIso = state.simTimeIso,
                    actorRole = state.activeRole,
                    action = "ACKNOWLEDGE_ALERT",
                    entityRef = alertId,
                    detail = "Alert acknowledged (physical condition status unchanged)",
                    idempotencyKey = UUID.randomUUID().toString()
                )
            ) + state.auditLog,
            version = state.version + 1
        )
        return state
    }

    fun injectEquipmentFault(equipmentTag: String, reason: String): PlantSnapshot {
        val updatedEquipment = state.equipment.map {
            if (it.tag == equipmentTag) it.copy(state = EquipmentState.FAULT, activeAlertSummary = reason) else it
        }
        val alert = PlantAlert(
            id = "ALT-${state.alerts.size + 101}",
            severity = "CRITICAL",
            equipmentTag = equipmentTag,
            message = reason,
            raisedAtIso = state.simTimeIso,
            acknowledged = false,
            acknowledgedBy = null,
            physicalConditionResolved = false
        )
        val wo = MaintenanceWorkOrder(
            id = "WO-${204 + state.workOrders.size}",
            equipmentTag = equipmentTag,
            title = "Investigate & clear fault: $reason",
            category = "Corrective",
            priority = "HIGH",
            status = "OPEN",
            assignedTo = "Duty Maintenance Engineer",
            dueDateIso = "2026-11-21",
            physicalFaultActive = true
        )
        state = state.copy(
            equipment = updatedEquipment,
            alerts = listOf(alert) + state.alerts,
            workOrders = listOf(wo) + state.workOrders,
            version = state.version + 1
        )
        return state
    }

    fun resolveMaintenanceFault(workOrderId: String): Result<PlantSnapshot> {
        if (state.activeRole !in setOf(UserRole.MAINTENANCE, UserRole.SUPERVISOR, UserRole.ADMIN)) {
            return Result.failure(IllegalStateException("Only Maintenance, Supervisor, or Admin can sign off physical fault clearance."))
        }
        val wo = state.workOrders.find { it.id == workOrderId }
            ?: return Result.failure(IllegalArgumentException("Work order not found"))
        val updatedWos = state.workOrders.map {
            if (it.id == workOrderId) it.copy(status = "CLOSED", physicalFaultActive = false) else it
        }
        val updatedEquipment = state.equipment.map {
            if (it.tag == wo.equipmentTag) it.copy(state = EquipmentState.RUNNING, activeAlertSummary = null) else it
        }
        val updatedAlerts = state.alerts.map {
            if (it.equipmentTag == wo.equipmentTag) it.copy(physicalConditionResolved = true) else it
        }
        state = state.copy(
            workOrders = updatedWos,
            equipment = updatedEquipment,
            alerts = updatedAlerts,
            auditLog = listOf(
                AuditEntry(
                    id = "AUD-${state.auditLog.size + 1}",
                    timestampIso = state.simTimeIso,
                    actorRole = state.activeRole,
                    action = "RESOLVE_PHYSICAL_FAULT",
                    entityRef = wo.equipmentTag,
                    detail = "Work order $workOrderId signed off; physical fault verified cleared.",
                    idempotencyKey = UUID.randomUUID().toString()
                )
            ) + state.auditLog,
            version = state.version + 1
        )
        return Result.success(state)
    }

    fun addShiftHandover(shiftName: String, operatorName: String, summary: String): PlantSnapshot {
        val note = ShiftHandover(
            id = "SH-${state.shiftHandovers.size + 1}",
            shiftName = shiftName,
            operatorName = operatorName.ifBlank { state.activeRole.title },
            timestampIso = state.simTimeIso,
            summary = summary
        )
        state = state.copy(shiftHandovers = listOf(note) + state.shiftHandovers, version = state.version + 1)
        return state
    }

    fun updateSimulationConfig(config: SimulationConfig): PlantSnapshot {
        val updatedBanks = state.storageBanks.map { b ->
            val maxCap = when (b.id) {
                "BANK-A" -> config.bankAMaxKg
                "BANK-B" -> config.bankBMaxKg
                else -> config.bankCMaxKg
            }
            b.copy(maxCapacityKg = maxCap, operatingMaxKg = min(b.operatingMaxKg, maxCap))
        }
        state = state.copy(simConfig = config, storageBanks = updatedBanks, version = state.version + 1)
        return state
    }

    fun buildPeriodReport(periodLabel: String, hoursWindow: Double): PeriodReportMetrics {
        val scale = hoursWindow / 24.0
        val producedKg = state.producedTodayKg * scale
        val dispatchedKg = state.dispatchTodayKg * scale
        val totalElecMwh = ((state.waterElectrolysis.totalPlantPowerMw * hoursWindow) * 0.96).coerceAtLeast(0.0)
        val compressionMwh = ((state.waterElectrolysis.compressionPowerMw * hoursWindow) * 0.96).coerceAtLeast(0.0)
        val waterFeedM3 = ((state.waterElectrolysis.feedwaterFlowLPerHr * hoursWindow) / 1000.0).coerceAtLeast(0.0)
        val sec = if (producedKg > 0.01) (totalElecMwh * 1000.0) / producedKg else null
        val swu = if (producedKg > 0.01) (waterFeedM3 * 1000.0) / producedKg else null

        val elecCost = totalElecMwh * state.tariffs.electricityTariffGbpPerMwh
        val waterCost = waterFeedM3 * state.tariffs.waterTariffGbpPerM3
        val consCost = producedKg * state.tariffs.consumablesGbpPerKgH2
        val totalOpCost = elecCost + waterCost + consCost
        val costProduced = if (producedKg > 0.01) totalOpCost / producedKg else null
        val costDispatched = if (dispatchedKg > 0.01) totalOpCost / dispatchedKg else null

        val plannedKg = state.tariffs.plannedDailyProductionKg * scale
        val prodVsPlan = if (plannedKg > 0.01) (producedKg / plannedKg) * 100.0 else 0.0
        val maxPossible = state.simConfig.electrolyserMaxCapacityKgHr * hoursWindow
        val utilPct = if (maxPossible > 0.01) (producedKg / maxPossible) * 100.0 else 0.0

        val gridShare = (100.0 - state.tariffs.renewablePpaSharePct).coerceIn(0.0, 100.0) / 100.0
        val carbonIntensity = sec?.let { (it * gridShare * state.tariffs.gridEmissionFactorGCo2PerKwh) / 1000.0 }

        return PeriodReportMetrics(
            periodLabel = periodLabel,
            h2ProducedKg = producedKg,
            h2DispatchedKg = dispatchedKg,
            inventoryChangeKg = producedKg - dispatchedKg,
            totalElectricityMwh = totalElecMwh,
            compressionEnergyMwh = compressionMwh,
            totalWaterFeedM3 = waterFeedM3,
            downtimeMinutes = if (state.flowBlockedReason != null) 18.0 * scale else 4.0 * scale,
            specificElectricityKwhPerKg = sec,
            specificWaterLPerKg = swu,
            costPerKgProducedGbp = costProduced,
            costPerKgDispatchedGbp = costDispatched,
            equipmentUtilisationPct = utilPct.coerceIn(0.0, 100.0),
            productionVsPlanPct = prodVsPlan,
            calculatedCarbonIntensityKgCo2PerKgH2 = carbonIntensity
        )
    }

    companion object {
        /**
         * Explicit pressure-derived mass model requiring vessel volume, temperature,
         * and non-ideal compressibility Z(P, T) within validity limits [1..450 bar, 250..340 K].
         */
        fun estimateMassFromPressureAndVolume(
            pressureBar: Double,
            vesselVolumeM3: Double,
            temperatureC: Double
        ): Result<Double> {
            val tempK = temperatureC + 273.15
            if (pressureBar !in 1.0..450.0) {
                return Result.failure(IllegalArgumentException("Pressure $pressureBar bar outside model validity (1–450 bar)."))
            }
            if (tempK !in 250.0..340.0) {
                return Result.failure(IllegalArgumentException("Temperature $temperatureC °C outside model validity (-23 to +67 °C)."))
            }
            if (vesselVolumeM3 <= 0.0) {
                return Result.failure(IllegalArgumentException("Vessel volume must be > 0 m³."))
            }
            // Simplified virial compressibility approximation for H2 around 293 K: Z ≈ 1 + 0.00062 * P_bar
            val zFactor = 1.0 + 0.00062 * pressureBar
            val rSpecificH2 = 4124.2 // J/(kg·K)
            val pressurePa = pressureBar * 100_000.0
            val massKg = (pressurePa * vesselVolumeM3) / (zFactor * rSpecificH2 * tempK)
            return Result.success(massKg)
        }

        private fun estimatePressureFromMassBar(massKg: Double, volumeM3: Double, tempC: Double): Double {
            val tempK = tempC + 273.15
            val rSpecificH2 = 4124.2
            val pIdealBar = (massKg * rSpecificH2 * tempK) / (volumeM3 * 100_000.0)
            // Inverse compressibility approx
            return (pIdealBar * (1.0 + 0.00055 * pIdealBar)).coerceIn(1.0, 440.0)
        }

        private fun formatSimClock(elapsedSeconds: Long): String {
            val baseSeconds = (14 * 3600 + 20 * 60) + elapsedSeconds
            val hrs = (baseSeconds / 3600) % 24
            val mins = (baseSeconds % 3600) / 60
            val secs = baseSeconds % 60
            return String.format(Locale.UK, "2026-11-21 %02d:%02d:%02d UTC", hrs, mins, secs)
        }

        fun createInitialSnapshot(activeRole: UserRole = UserRole.OPERATOR): PlantSnapshot {
            val banks = listOf(
                StorageBank(
                    id = "BANK-A",
                    name = "Bank A • High Pressure",
                    inventoryKg = 4800.0,
                    maxCapacityKg = 5500.0,
                    operatingMinKg = 350.0,
                    operatingMaxKg = 5250.0,
                    pressureBar = 368.0,
                    temperatureC = 18.4,
                    vesselVolumeM3 = 205.0,
                    state = EquipmentState.RUNNING,
                    maintenanceStatus = "Statutory Inspection Valid (2027-04)",
                    dataQuality = DataQualityFlag.LIVE,
                    linkedBatchId = "H2-041"
                ),
                StorageBank(
                    id = "BANK-B",
                    name = "Bank B • Buffer & Lab Hold",
                    inventoryKg = 4100.0,
                    maxCapacityKg = 5500.0,
                    operatingMinKg = 350.0,
                    operatingMaxKg = 5250.0,
                    pressureBar = 312.0,
                    temperatureC = 17.9,
                    vesselVolumeM3 = 205.0,
                    state = EquipmentState.RUNNING,
                    maintenanceStatus = "PSV Calibrated (2026-10)",
                    dataQuality = DataQualityFlag.LIVE,
                    linkedBatchId = "H2-042"
                ),
                StorageBank(
                    id = "BANK-C",
                    name = "Bank C • Dispatch Reserve",
                    inventoryKg = 3500.0,
                    maxCapacityKg = 5500.0,
                    operatingMinKg = 350.0,
                    operatingMaxKg = 5250.0,
                    pressureBar = 264.0,
                    temperatureC = 17.2,
                    vesselVolumeM3 = 205.0,
                    state = EquipmentState.RUNNING,
                    maintenanceStatus = "Healthy — Next NDT 2027-01",
                    dataQuality = DataQualityFlag.LIVE,
                    linkedBatchId = "H2-040"
                )
            )

            val batches = listOf(
                QualityBatch(
                    batchId = "H2-042",
                    producedMassKg = 4100.0,
                    remainingMassKg = 4100.0,
                    storageBankId = "BANK-B",
                    latestSampleTimestamp = "2026-11-21 14:12 UTC",
                    measuredPurityPct = null,
                    measuredMoisturePpm = null,
                    predictedPurityPct = 99.985,
                    predictedMoisturePpm = 2.4,
                    reviewStatus = LabReviewStatus.SAMPLE_PENDING,
                    releaseStatus = BatchReleaseStatus.HOLD_FOR_REVIEW,
                    specVersion = "ISO-14687-D-v2.1",
                    authorisedBy = null,
                    authorisedAtIso = null,
                    samples = listOf(
                        LabSample(
                            sampleId = "SMP-100",
                            batchId = "H2-042",
                            timestampIso = "2026-11-21 14:12 UTC",
                            sourceType = ReadingSourceType.CONTINUOUS_ANALYSER,
                            purityPct = null,
                            moisturePpm = null,
                            oxygenPpm = null,
                            predictedPurityPct = 99.985,
                            predictedMoisturePpm = 2.4,
                            attachmentRef = "GC-TRACE-042-PRELIM.pdf",
                            analystName = "A. MacLeod",
                            notes = "Sample cylinder drawn; awaiting laboratory GC-TCD & chilled-mirror verification."
                        )
                    )
                ),
                QualityBatch(
                    batchId = "H2-041",
                    producedMassKg = 4800.0,
                    remainingMassKg = 4800.0,
                    storageBankId = "BANK-A",
                    latestSampleTimestamp = "2026-11-21 09:40 UTC",
                    measuredPurityPct = 99.992,
                    measuredMoisturePpm = 1.8,
                    predictedPurityPct = 99.990,
                    predictedMoisturePpm = 2.1,
                    reviewStatus = LabReviewStatus.REVIEWED_PASS,
                    releaseStatus = BatchReleaseStatus.RELEASED,
                    specVersion = "ISO-14687-D-v2.1",
                    authorisedBy = "Dr. F. Campbell (QA Lead)",
                    authorisedAtIso = "2026-11-21 10:05 UTC",
                    samples = listOf(
                        LabSample(
                            sampleId = "SMP-098",
                            batchId = "H2-041",
                            timestampIso = "2026-11-21 09:40 UTC",
                            sourceType = ReadingSourceType.DISCRETE_SAMPLE,
                            purityPct = 99.992,
                            moisturePpm = 1.8,
                            oxygenPpm = 1.2,
                            predictedPurityPct = 99.990,
                            predictedMoisturePpm = 2.1,
                            attachmentRef = "COA-H2-041-SIGNED.pdf",
                            analystName = "A. MacLeod",
                            notes = "Verified ISO 14687 Grade D compliant."
                        )
                    )
                ),
                QualityBatch(
                    batchId = "H2-040",
                    producedMassKg = 6400.0,
                    remainingMassKg = 3500.0,
                    storageBankId = "BANK-C",
                    latestSampleTimestamp = "2026-11-21 04:15 UTC",
                    measuredPurityPct = 99.989,
                    measuredMoisturePpm = 2.1,
                    predictedPurityPct = 99.988,
                    predictedMoisturePpm = 2.2,
                    reviewStatus = LabReviewStatus.REVIEWED_PASS,
                    releaseStatus = BatchReleaseStatus.RELEASED,
                    specVersion = "ISO-14687-D-v2.1",
                    authorisedBy = "Dr. F. Campbell (QA Lead)",
                    authorisedAtIso = "2026-11-21 04:42 UTC",
                    samples = listOf(
                        LabSample(
                            sampleId = "SMP-095",
                            batchId = "H2-040",
                            timestampIso = "2026-11-21 04:15 UTC",
                            sourceType = ReadingSourceType.DISCRETE_SAMPLE,
                            purityPct = 99.989,
                            moisturePpm = 2.1,
                            oxygenPpm = 1.6,
                            predictedPurityPct = 99.988,
                            predictedMoisturePpm = 2.2,
                            attachmentRef = "COA-H2-040-SIGNED.pdf",
                            analystName = "R. Henderson",
                            notes = "Night-shift batch cleared for commercial dispatch."
                        )
                    )
                )
            )

            val orders = listOf(
                DispatchOrder(
                    orderId = "DSP-904",
                    customerName = "Aberdeen Zero-Emission Bus Depot",
                    requiredSpecVersion = "ISO-14687-D-v2.1",
                    trailerRegistration = "SC24 HYD",
                    requestedMassKg = 920.0,
                    estimatedLoadedKg = 540.0,
                    confirmedTransferKg = null,
                    assignedBatchId = "H2-041",
                    sourceBankId = "BANK-A",
                    stage = DispatchStage.LOADING,
                    scheduledTimeIso = "14:00 UTC",
                    deliveryDocNumber = null
                ),
                DispatchOrder(
                    orderId = "DSP-905",
                    customerName = "Peterhead Port Mobility Hub",
                    requiredSpecVersion = "ISO-14687-D-v2.1",
                    trailerRegistration = "SC73 H2X",
                    requestedMassKg = 880.0,
                    estimatedLoadedKg = 0.0,
                    confirmedTransferKg = null,
                    assignedBatchId = "H2-042",
                    sourceBankId = "BANK-B",
                    stage = DispatchStage.CHECKED,
                    scheduledTimeIso = "15:15 UTC",
                    deliveryDocNumber = null,
                    holdOrExceptionReason = "Awaiting Batch H2-042 lab release before loading authorisation"
                ),
                DispatchOrder(
                    orderId = "DSP-906",
                    customerName = "Inverness Rail Freight Trial",
                    requiredSpecVersion = "ISO-14687-D-v2.1",
                    trailerRegistration = "SC25 GRN",
                    requestedMassKg = 1050.0,
                    estimatedLoadedKg = 0.0,
                    confirmedTransferKg = null,
                    assignedBatchId = "H2-040",
                    sourceBankId = "BANK-C",
                    stage = DispatchStage.ARRIVED,
                    scheduledTimeIso = "16:30 UTC",
                    deliveryDocNumber = null
                ),
                DispatchOrder(
                    orderId = "DSP-903",
                    customerName = "Dundee Hydrogen Fleet",
                    requiredSpecVersion = "ISO-14687-D-v2.1",
                    trailerRegistration = "SC22 DND",
                    requestedMassKg = 960.0,
                    estimatedLoadedKg = 955.0,
                    confirmedTransferKg = 958.0,
                    assignedBatchId = "H2-040",
                    sourceBankId = "BANK-C",
                    stage = DispatchStage.RELEASED,
                    scheduledTimeIso = "11:20 UTC",
                    deliveryDocNumber = "DN-UK-903-418"
                )
            )

            val equipmentList = listOf(
                EquipmentUnit(
                    id = "WT-101",
                    stageId = ProcessStageId.WATER_TREATMENT,
                    name = "RO / EDI Water Treatment Skid",
                    tag = "WT-101",
                    state = EquipmentState.RUNNING,
                    operatingHours = 4812.4,
                    primaryMetricLabel = "Feedwater",
                    primaryMetricValue = "4,680.0 L/h",
                    secondaryMetricLabel = "Conductivity",
                    secondaryMetricValue = "0.08 µS/cm",
                    temperatureC = 14.2,
                    pressureBar = 4.6,
                    sensorProvenance = "SCADA Historian • Endress+Hauser CLS16E",
                    dataQuality = DataQualityFlag.LIVE,
                    maintenanceStatus = "EDI Resin Regen Due in 14 days",
                    historySeries = listOf(4620f, 4645f, 4690f, 4670f, 4680f, 4685f, 4675f, 4680f)
                ),
                EquipmentUnit(
                    id = "ELX-200",
                    stageId = ProcessStageId.ELECTROLYSIS,
                    name = "PEM Electrolyser Array (4 × 5 MW)",
                    tag = "ELX-200",
                    state = EquipmentState.RUNNING,
                    operatingHours = 11420.8,
                    primaryMetricLabel = "Power Input",
                    primaryMetricValue = "20.0 MW",
                    secondaryMetricLabel = "H₂ Output",
                    secondaryMetricValue = "360.0 kg/h",
                    temperatureC = 64.5,
                    pressureBar = 30.2,
                    sensorProvenance = "PLC Rectifier Bus • Modbus TCP Gateway",
                    dataQuality = DataQualityFlag.LIVE,
                    maintenanceStatus = "4/4 Modules Online",
                    historySeries = listOf(19.6f, 19.8f, 20.0f, 19.9f, 20.1f, 20.0f, 20.0f, 20.0f)
                ),
                EquipmentUnit(
                    id = "SEP-301",
                    stageId = ProcessStageId.GAS_SEPARATION,
                    name = "H₂ / O₂ Gas-Liquid Separation Vessels",
                    tag = "SEP-301",
                    state = EquipmentState.RUNNING,
                    operatingHours = 11420.8,
                    primaryMetricLabel = "Raw H₂ Flow",
                    primaryMetricValue = "366.6 kg/h",
                    secondaryMetricLabel = "O₂ Vent/Rec.",
                    secondaryMetricValue = "2,909 kg/h",
                    temperatureC = 38.0,
                    pressureBar = 29.8,
                    sensorProvenance = "Coriolis Mass Meter • Emerson CMF050",
                    dataQuality = DataQualityFlag.LIVE,
                    maintenanceStatus = "Demister DP Normal (0.14 bar)",
                    historySeries = listOf(362f, 364f, 366f, 365f, 367f, 366f, 367f, 366.6f)
                ),
                EquipmentUnit(
                    id = "PUR-401",
                    stageId = ProcessStageId.DRYING_PURIFICATION,
                    name = "DeOxo & Twin-Tower TSA Dryer",
                    tag = "PUR-401",
                    state = EquipmentState.RUNNING,
                    operatingHours = 11390.2,
                    primaryMetricLabel = "Purified H₂",
                    primaryMetricValue = "360.0 kg/h",
                    secondaryMetricLabel = "Dew Point",
                    secondaryMetricValue = "-72.4 °C",
                    temperatureC = 24.8,
                    pressureBar = 29.1,
                    sensorProvenance = "Online Moisture Analyser • Michell QMA601",
                    dataQuality = DataQualityFlag.LIVE,
                    maintenanceStatus = "Tower B Regen Active",
                    historySeries = listOf(355f, 358f, 360f, 359f, 361f, 360f, 360f, 360f)
                ),
                EquipmentUnit(
                    id = "CMP-501",
                    stageId = ProcessStageId.COMPRESSION,
                    name = "Diaphragm Compressor Skid (A/B)",
                    tag = "CMP-501",
                    state = EquipmentState.RUNNING,
                    operatingHours = 8940.5,
                    primaryMetricLabel = "Discharge",
                    primaryMetricValue = "382 bar",
                    secondaryMetricLabel = "Power",
                    secondaryMetricValue = "846 kW",
                    temperatureC = 44.2,
                    pressureBar = 382.0,
                    sensorProvenance = "Compressor PLC • OPC-UA Read-Only",
                    dataQuality = DataQualityFlag.LIVE,
                    maintenanceStatus = "Diaphragm Hours: 1,420 / 4,000 h",
                    historySeries = listOf(375f, 378f, 380f, 381f, 382f, 381f, 382f, 382f)
                ),
                EquipmentUnit(
                    id = "STR-600",
                    stageId = ProcessStageId.STORAGE,
                    name = "Horizontal Pressure-Vessel Banks (A–C)",
                    tag = "STR-600",
                    state = EquipmentState.RUNNING,
                    operatingHours = 12100.0,
                    primaryMetricLabel = "Total Mass",
                    primaryMetricValue = "12,400 kg",
                    secondaryMetricLabel = "Cap. Norm.",
                    secondaryMetricValue = "75.2%",
                    temperatureC = 17.8,
                    pressureBar = 368.0,
                    sensorProvenance = "Mass-Balance Integrator + PT/TT Redundant",
                    dataQuality = DataQualityFlag.LIVE,
                    maintenanceStatus = "Bank B Holding Batch H2-042",
                    historySeries = listOf(12150f, 12210f, 12260f, 12300f, 12340f, 12370f, 12390f, 12400f)
                ),
                EquipmentUnit(
                    id = "DSP-701",
                    stageId = ProcessStageId.DISPATCH,
                    name = "Tube-Trailer Loading Gantry (Bay 1–2)",
                    tag = "DSP-701",
                    state = EquipmentState.RUNNING,
                    operatingHours = 5120.0,
                    primaryMetricLabel = "Dispatched",
                    primaryMetricValue = "8,640 kg",
                    secondaryMetricLabel = "Active Bay",
                    secondaryMetricValue = "SC24 HYD (58%)",
                    temperatureC = 12.6,
                    pressureBar = 295.0,
                    sensorProvenance = "Weighbridge + Coriolis Custody Transfer",
                    dataQuality = DataQualityFlag.LIVE,
                    maintenanceStatus = "Breakaway Coupling Inspected",
                    historySeries = listOf(7200f, 7500f, 7800f, 8050f, 8240f, 8400f, 8520f, 8640f)
                )
            )

            return PlantSnapshot(
                plantName = "Aberdeen Green H₂ Works — Phase II",
                freshnessState = DataFreshnessState.DEMO_DATA,
                simTimeIso = "2026-11-21 14:20:00 UTC",
                wallTimeIso = "14:20:00 UTC",
                simElapsedSeconds = 0L,
                dataAgeSeconds = 0L,
                simSpeed = SimSpeed.NORMAL_1X,
                electricalBoundary = ElectricalBoundary.COMPLETE_PLANT,
                activeRole = activeRole,
                h2OutputKgPerHr = 360.0,
                electrolyserPowerMw = 20.0,
                storageInventoryKg = 12400.0,
                dispatchTodayKg = 8640.0,
                producedTodayKg = 8520.0,
                h2LossesTodayKg = 156.2,
                o2OutputTodayKg = 68850.0,
                waterLossTodayL = 32840.0,
                flowBlockedReason = null,
                outputTrendKgHr = listOf(
                    338f, 344f, 352f, 358f, 360f, 356f, 349f, 355f, 361f, 360f, 358f, 360f
                ),
                waterElectrolysis = WaterElectrolysisMetrics(
                    feedwaterFlowLPerHr = 4680.0,
                    treatedWaterAvailableL = 42800.0,
                    treatedTankCapacityL = 60000.0,
                    roRejectLossLPerHr = 1151.0,
                    ediBlowdownLossLPerHr = 253.0,
                    stoichiometricWaterUsedKgPerHr = 3276.0,
                    conductivityMicroSPerCm = 0.08,
                    tocPpb = 14.0,
                    waterProvenance = "Scottish Water Municipal + RO/EDI Skid WT-101",
                    activeModules = 4,
                    totalModules = 4,
                    stackDcPowerMw = 18.11,
                    auxBalanceOfPlantMw = 1.04,
                    compressionPowerMw = 0.85,
                    totalPlantPowerMw = 20.0,
                    h2OutputKgPerHr = 360.0,
                    o2OutputKgPerHr = 2909.0,
                    h2PurificationLossKgPerHr = 6.6,
                    stackOperatingHours = 11420.8,
                    waterFlowHistory = listOf(4580f, 4620f, 4660f, 4690f, 4675f, 4680f, 4680f, 4680f),
                    powerHistoryMw = listOf(19.2f, 19.6f, 19.9f, 20.0f, 19.8f, 20.0f, 20.0f, 20.0f)
                ),
                compressors = listOf(
                    CompressorUnit(
                        id = "CMP-501A",
                        name = "Compressor A (30 → 400 bar)",
                        state = EquipmentState.RUNNING,
                        suctionBar = 29.1,
                        dischargeBar = 382.0,
                        dischargeTempC = 44.2,
                        powerKw = 425.0,
                        throughputKgPerHr = 180.0,
                        maintenanceStatus = "Healthy — Oil Analysis OK",
                        dataQuality = DataQualityFlag.LIVE
                    ),
                    CompressorUnit(
                        id = "CMP-501B",
                        name = "Compressor B (30 → 400 bar)",
                        state = EquipmentState.RUNNING,
                        suctionBar = 29.1,
                        dischargeBar = 381.4,
                        dischargeTempC = 43.8,
                        powerKw = 421.0,
                        throughputKgPerHr = 180.0,
                        maintenanceStatus = "Healthy — Diaphragm OK",
                        dataQuality = DataQualityFlag.LIVE
                    )
                ),
                storageBanks = banks,
                equipment = equipmentList,
                qualityBatches = batches,
                acceptanceSpec = AcceptanceSpec(
                    version = "ISO-14687-D-v2.1",
                    standardName = "ISO 14687:2019 Grade D Fuel Cell",
                    minPurityPct = 99.97,
                    maxMoisturePpm = 5.0,
                    maxOxygenPpm = 5.0,
                    maxNitrogenPpm = 300.0
                ),
                dispatchOrders = orders,
                workOrders = listOf(
                    MaintenanceWorkOrder(
                        id = "WO-201",
                        equipmentTag = "PUR-401",
                        title = "Inspect TSA Tower B Switching Valve Seal",
                        category = "Preventive",
                        priority = "MEDIUM",
                        status = "IN PROGRESS",
                        assignedTo = "C. Robertson",
                        dueDateIso = "2026-11-22",
                        physicalFaultActive = false
                    ),
                    MaintenanceWorkOrder(
                        id = "WO-202",
                        equipmentTag = "WT-101",
                        title = "Replace RO Pre-Filter Cartridges (5 µm)",
                        category = "Preventive",
                        priority = "LOW",
                        status = "SCHEDULED",
                        assignedTo = "M. Stewart",
                        dueDateIso = "2026-11-24",
                        physicalFaultActive = false
                    )
                ),
                spareParts = listOf(
                    SparePartItem("SP-DIAPHRAGM-400", "Hofer Diaphragm Set (Stage 2)", 4, 2, 1850.0),
                    SparePartItem("SP-RO-MEMBRANE", "8-inch Brackish RO Element", 6, 3, 620.0),
                    SparePartItem("SP-QMA-SENSOR", "Moisture Analyser Sensor Cell", 2, 1, 2400.0),
                    SparePartItem("SP-BREAKAWAY-350", "Trailer Bay Breakaway Seal Kit", 5, 2, 340.0)
                ),
                shiftHandovers = listOf(
                    ShiftHandover(
                        id = "SH-12",
                        shiftName = "Day Shift (06:00–14:00)",
                        operatorName = "K. Fraser",
                        timestampIso = "2026-11-21 14:00 UTC",
                        summary = "Steady 20 MW wind PPA operation. Batch H2-042 in Bank B sampled at 14:12 UTC; holding for lab verification before releasing trailer SC73 H2X."
                    )
                ),
                alerts = listOf(
                    PlantAlert(
                        id = "ALT-100",
                        severity = "WARNING",
                        equipmentTag = "STR-600",
                        message = "Bank B holding Batch H2-042 (HOLD FOR REVIEW) — dispatch blocked until Lab/Supervisor release.",
                        raisedAtIso = "2026-11-21 14:12 UTC",
                        acknowledged = false,
                        acknowledgedBy = null,
                        physicalConditionResolved = false
                    )
                ),
                auditLog = listOf(
                    AuditEntry(
                        id = "AUD-1",
                        timestampIso = "2026-11-21 14:12 UTC",
                        actorRole = UserRole.LAB_STAFF,
                        action = "DRAW_QUALITY_SAMPLE",
                        entityRef = "H2-042",
                        detail = "Sample SMP-100 drawn for Bank B; status set HOLD FOR REVIEW",
                        idempotencyKey = "seed-aud-1"
                    )
                ),
                tariffs = TariffAndCostConfig(
                    tariffEffectiveDate = "2026-11-01 (Fictional Demo Tariff)",
                    electricityTariffGbpPerMwh = 58.50,
                    waterTariffGbpPerM3 = 1.95,
                    consumablesGbpPerKgH2 = 0.22,
                    allocationMethod = "Period Energy & Feedwater Attribution (Mass Basis)",
                    plannedDailyProductionKg = 8640.0,
                    carbonIntensityBoundary = "Scope 2 Location/Market Mix (Electricity input at plant meter only)",
                    gridEmissionFactorGCo2PerKwh = 112.0,
                    renewablePpaSharePct = 88.0,
                    carbonFactorSource = "Illustrative UK DESNZ 2026 Demo Factor (Not Verified Cert.)"
                ),
                simConfig = SimulationConfig(),
                version = 1L
            )
        }

        private fun format0(v: Double) = String.format(Locale.UK, "%,.0f", v)
        private fun format1(v: Double) = String.format(Locale.UK, "%,.1f", v)
        private fun format3(v: Double) = String.format(Locale.UK, "%.3f", v)
    }
}
