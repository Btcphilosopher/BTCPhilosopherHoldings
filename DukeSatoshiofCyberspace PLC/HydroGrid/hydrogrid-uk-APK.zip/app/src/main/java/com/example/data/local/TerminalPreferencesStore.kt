package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.example.core.model.ElectricalBoundary
import com.example.core.model.UserRole
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "hydrogrid_terminal_prefs")

data class TerminalPreferences(
    val backendBaseUrl: String = "http://10.0.2.2:8000",
    val useRemoteBackend: Boolean = false,
    val reducedMotion: Boolean = false,
    val selectedRole: UserRole = UserRole.OPERATOR,
    val electricalBoundary: ElectricalBoundary = ElectricalBoundary.COMPLETE_PLANT,
    val lastSyncEpochMs: Long = 0L
)

class TerminalPreferencesStore(private val context: Context) {

    private object Keys {
        val BACKEND_URL = stringPreferencesKey("backend_base_url")
        val USE_REMOTE = booleanPreferencesKey("use_remote_backend")
        val REDUCED_MOTION = booleanPreferencesKey("reduced_motion")
        val SELECTED_ROLE = stringPreferencesKey("selected_role")
        val ELECTRICAL_BOUNDARY = stringPreferencesKey("electrical_boundary")
        val LAST_SYNC_MS = longPreferencesKey("last_sync_epoch_ms")
    }

    val preferencesFlow: Flow<TerminalPreferences> = context.dataStore.data.map { prefs ->
        TerminalPreferences(
            backendBaseUrl = prefs[Keys.BACKEND_URL] ?: "http://10.0.2.2:8000",
            useRemoteBackend = prefs[Keys.USE_REMOTE] ?: false,
            reducedMotion = prefs[Keys.REDUCED_MOTION] ?: false,
            selectedRole = prefs[Keys.SELECTED_ROLE]?.let { name ->
                UserRole.entries.firstOrNull { it.name == name }
            } ?: UserRole.OPERATOR,
            electricalBoundary = prefs[Keys.ELECTRICAL_BOUNDARY]?.let { name ->
                ElectricalBoundary.entries.firstOrNull { it.name == name }
            } ?: ElectricalBoundary.COMPLETE_PLANT,
            lastSyncEpochMs = prefs[Keys.LAST_SYNC_MS] ?: 0L
        )
    }

    suspend fun setBackendBaseUrl(url: String) {
        context.dataStore.edit { it[Keys.BACKEND_URL] = url.trim() }
    }

    suspend fun setUseRemoteBackend(enabled: Boolean) {
        context.dataStore.edit { it[Keys.USE_REMOTE] = enabled }
    }

    suspend fun setReducedMotion(enabled: Boolean) {
        context.dataStore.edit { it[Keys.REDUCED_MOTION] = enabled }
    }

    suspend fun setSelectedRole(role: UserRole) {
        context.dataStore.edit { it[Keys.SELECTED_ROLE] = role.name }
    }

    suspend fun setElectricalBoundary(boundary: ElectricalBoundary) {
        context.dataStore.edit { it[Keys.ELECTRICAL_BOUNDARY] = boundary.name }
    }

    suspend fun setLastSyncEpochMs(epochMs: Long) {
        context.dataStore.edit { it[Keys.LAST_SYNC_MS] = epochMs }
    }
}
