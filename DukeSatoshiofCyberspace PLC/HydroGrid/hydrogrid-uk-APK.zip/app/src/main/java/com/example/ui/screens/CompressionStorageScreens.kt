package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.model.*
import com.example.core.simulation.PlantSimulatorEngine
import com.example.ui.components.CapacityNormalisedBar
import com.example.ui.components.StatusPill
import com.example.ui.components.StatusTone
import com.example.ui.components.toTone
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun CompressionScreen(snapshot: PlantSnapshot) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        WorkspaceSectionHeader(
            title = "Multi-Stage Hydrogen Compression",
            subtitle = "30 bar → 400 bar diaphragm compression • Reports blocked flow when downstream storage banks reach operating limits"
        )

        snapshot.flowBlockedReason?.let { reason ->
            Surface(
                color = StatusAmberBg,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, StatusAmber),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = reason,
                    style = MaterialTheme.typography.titleSmall.copy(color = StatusAmber, fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            snapshot.compressors.forEach { cmp ->
                Surface(
                    color = PureWhite,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, ThinRuleBlue),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(cmp.name, style = MaterialTheme.typography.titleMedium.copy(color = MidnightNavy))
                            StatusPill(cmp.state.label, cmp.state.toTone())
                        }
                        HorizontalDivider(color = ThinRuleBlue)
                        MetricPairRow("Suction / Discharge Pressure", "${String.format(Locale.UK, "%.1f", cmp.suctionBar)} bar → ${String.format(Locale.UK, "%.1f", cmp.dischargeBar)} bar")
                        MetricPairRow("Discharge Gas Temperature", "${String.format(Locale.UK, "%.1f", cmp.dischargeTempC)} °C")
                        MetricPairRow("Throughput Rate", "${String.format(Locale.UK, "%.1f", cmp.throughputKgPerHr)} kg/h")
                        MetricPairRow("Compressor Shaft Power", "${String.format(Locale.UK, "%.1f", cmp.powerKw)} kW")
                        MetricPairRow("Maintenance Status", cmp.maintenanceStatus)
                        MetricPairRow("Data Quality Flag", cmp.dataQuality.label)
                        cmp.blockedReason?.let { blk ->
                            Text("Blocked: $blk", style = MaterialTheme.typography.labelSmall.copy(color = StatusAmber, fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StorageScreen(
    snapshot: PlantSnapshot,
    onUpdateLimits: (String, Double, Double) -> Unit
) {
    var editingBank by remember { mutableStateOf<StorageBank?>(null) }
    var pressureInput by remember { mutableStateOf("368.0") }
    var tempInput by remember { mutableStateOf("18.4") }
    var volumeInput by remember { mutableStateOf("205.0") }

    val estimationResult = remember(pressureInput, tempInput, volumeInput) {
        val p = pressureInput.toDoubleOrNull()
        val t = tempInput.toDoubleOrNull()
        val v = volumeInput.toDoubleOrNull()
        if (p == null || t == null || v == null) {
            Result.failure(IllegalArgumentException("Enter valid numeric pressure, temperature, and vessel volume."))
        } else {
            PlantSimulatorEngine.estimateMassFromPressureAndVolume(p, v, t)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        WorkspaceSectionHeader(
            title = "High-Pressure Storage Vessel Banks",
            subtitle = "Capacity-normalised inventory • Configurable operating limits • Prevents filling beyond configured limits"
        )

        snapshot.storageBanks.forEach { bank ->
            val batch = snapshot.qualityBatches.find { it.batchId == bank.linkedBatchId }
            val isHold = batch?.releaseStatus != BatchReleaseStatus.RELEASED
            Surface(
                color = PureWhite,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, if (bank.isAtOperatingLimit || isHold) StatusAmber else ThinRuleBlue),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("${bank.id} — ${bank.name}", style = MaterialTheme.typography.titleMedium.copy(color = MidnightNavy))
                            Text(
                                "Linked Batch: ${bank.linkedBatchId} (${batch?.releaseStatus?.label ?: "Unknown"}) • Vessel Geometric Vol: ${bank.vesselVolumeM3} m³",
                                style = MaterialTheme.typography.labelSmall.copy(color = if (isHold) StatusAmber else InkSecondary)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            StatusPill(bank.state.label, bank.state.toTone())
                            OutlinedButton(
                                onClick = { editingBank = bank },
                                modifier = Modifier.testTag("edit_limits_${bank.id}")
                            ) {
                                Text("Edit Operating Limits")
                            }
                        }
                    }

                    CapacityNormalisedBar(
                        bankName = bank.id,
                        inventoryKg = bank.inventoryKg,
                        maxCapacityKg = bank.maxCapacityKg,
                        operatingMaxKg = bank.operatingMaxKg,
                        linkedBatchId = bank.linkedBatchId,
                        barColor = if (isHold) StatusAmber else ProcessCyan,
                        isBlocked = bank.isAtOperatingLimit || isHold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        MetricPairRow("Reported P / T", "${String.format(Locale.UK, "%.1f", bank.pressureBar)} bar / ${String.format(Locale.UK, "%.1f", bank.temperatureC)} °C")
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(Modifier.weight(1f)) {
                            MetricPairRow("Available Headroom", "${String.format(Locale.UK, "%,.1f", bank.availableHeadroomKg)} kg (to ${String.format(Locale.UK, "%,.0f", bank.operatingMaxKg)} kg op-max)")
                        }
                        Box(Modifier.weight(1f)) {
                            MetricPairRow("Maintenance / Data Quality", "${bank.maintenanceStatus} • ${bank.dataQuality.label}")
                        }
                    }
                }
            }
        }

        // Explicit Pressure-Volume-Temperature-Z Gas Property Calculator
        Surface(
            color = PureWhite,
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, SaltireBlue.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "PRESSURE-DERIVED MASS ESTIMATOR (EXPLICIT GAS-PROPERTY MODEL)",
                    style = MaterialTheme.typography.titleSmall.copy(color = MidnightNavy, fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Stored mass is never inferred from pressure alone. Model: m = (P·V) / (Z(P)·R_H2·T), virial Z ≈ 1 + 0.00062·P_bar. Validity limits: 1–450 bar, -23 to +67 °C.",
                    style = MaterialTheme.typography.bodySmall.copy(color = InkSecondary)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = pressureInput,
                        onValueChange = { pressureInput = it },
                        label = { Text("Pressure (bar)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = volumeInput,
                        onValueChange = { volumeInput = it },
                        label = { Text("Vessel Volume (m³)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = tempInput,
                        onValueChange = { tempInput = it },
                        label = { Text("Gas Temp (°C)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                estimationResult.onSuccess { estKg ->
                    Text(
                        text = "Estimated Inventory Mass: ${String.format(Locale.UK, "%,.1f", estKg)} kg (Non-custody estimate within model bounds)",
                        style = MaterialTheme.typography.titleSmall.copy(color = SaltireBlue, fontWeight = FontWeight.Bold)
                    )
                }.onFailure { err ->
                    Text(
                        text = "Invalid / Out-of-Range: ${err.message}",
                        style = MaterialTheme.typography.labelMedium.copy(color = StatusFault)
                    )
                }
            }
        }
    }

    editingBank?.let { bank ->
        var minStr by remember(bank) { mutableStateOf(bank.operatingMinKg.toInt().toString()) }
        var maxStr by remember(bank) { mutableStateOf(bank.operatingMaxKg.toInt().toString()) }
        AlertDialog(
            onDismissRequest = { editingBank = null },
            title = { Text("Operating Limits • ${bank.id}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Design max capacity: ${bank.maxCapacityKg.toInt()} kg. Filling stops automatically if inventory reaches Operating Max.", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(value = minStr, onValueChange = { minStr = it }, label = { Text("Operating Min (kg)") }, singleLine = true)
                    OutlinedTextField(value = maxStr, onValueChange = { maxStr = it }, label = { Text("Operating Max (kg)") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    val minV = minStr.toDoubleOrNull() ?: bank.operatingMinKg
                    val maxV = maxStr.toDoubleOrNull() ?: bank.operatingMaxKg
                    onUpdateLimits(bank.id, minV, maxV)
                    editingBank = null
                }) { Text("Save Limits") }
            },
            dismissButton = {
                TextButton(onClick = { editingBank = null }) { Text("Cancel") }
            }
        )
    }
}
