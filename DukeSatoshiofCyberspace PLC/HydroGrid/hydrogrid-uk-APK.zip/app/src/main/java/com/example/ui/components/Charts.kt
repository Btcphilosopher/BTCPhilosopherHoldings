package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun OutputTrendChart(
    points: List<Float>,
    lineColor: Color = ProcessCyan,
    unitSuffix: String = " kg/h",
    modifier: Modifier = Modifier
) {
    val safePoints = if (points.size >= 2) points else listOf(0f, 0f)
    val minVal = (safePoints.minOrNull() ?: 0f) * 0.96f
    val maxVal = ((safePoints.maxOrNull() ?: 10f) * 1.04f).coerceAtLeast(minVal + 1f)
    val latest = safePoints.lastOrNull() ?: 0f

    Column(modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "MAX ${String.format(Locale.UK, "%.1f", maxVal)}$unitSuffix",
                style = MaterialTheme.typography.labelSmall.copy(color = InkMuted)
            )
            Text(
                text = "NOW ${String.format(Locale.UK, "%.1f", latest)}$unitSuffix",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = SaltireBlue,
                    fontWeight = FontWeight.Bold
                )
            )
        }
        Spacer(Modifier.height(4.dp))
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(4.dp))
                .background(SoftPanelBg)
                .border(1.dp, ThinRuleBlue, RoundedCornerShape(4.dp))
        ) {
            val padX = 8.dp.toPx()
            val padY = 10.dp.toPx()
            val chartW = (size.width - padX * 2).coerceAtLeast(1f)
            val chartH = (size.height - padY * 2).coerceAtLeast(1f)

            // Thin horizontal engineering gridlines
            for (i in 0..3) {
                val y = padY + (chartH / 3f) * i
                drawLine(
                    color = ThinRuleBlue.copy(alpha = 0.65f),
                    start = Offset(padX, y),
                    end = Offset(size.width - padX, y),
                    strokeWidth = 1.dp.toPx()
                )
            }

            val linePath = Path()
            val fillPath = Path()
            val coords = safePoints.mapIndexed { idx, value ->
                val x = padX + (idx.toFloat() / (safePoints.size - 1).coerceAtLeast(1)) * chartW
                val norm = ((value - minVal) / (maxVal - minVal)).coerceIn(0f, 1f)
                val y = padY + (1f - norm) * chartH
                Offset(x, y)
            }

            coords.forEachIndexed { idx, pt ->
                if (idx == 0) {
                    linePath.moveTo(pt.x, pt.y)
                    fillPath.moveTo(pt.x, padY + chartH)
                    fillPath.lineTo(pt.x, pt.y)
                } else {
                    linePath.lineTo(pt.x, pt.y)
                    fillPath.lineTo(pt.x, pt.y)
                }
            }
            coords.lastOrNull()?.let { last ->
                fillPath.lineTo(last.x, padY + chartH)
                fillPath.close()
            }

            drawPath(
                path = fillPath,
                brush = Brush.verticalGradient(
                    colors = listOf(lineColor.copy(alpha = 0.28f), lineColor.copy(alpha = 0.02f)),
                    startY = padY,
                    endY = padY + chartH
                )
            )
            drawPath(
                path = linePath,
                color = lineColor,
                style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
            )
            coords.lastOrNull()?.let { last ->
                drawCircle(color = PureWhite, radius = 4.5.dp.toPx(), center = last)
                drawCircle(color = lineColor, radius = 3.dp.toPx(), center = last)
            }
        }
    }
}

@Composable
fun CapacityNormalisedBar(
    bankName: String,
    inventoryKg: Double,
    maxCapacityKg: Double,
    operatingMaxKg: Double,
    linkedBatchId: String,
    barColor: Color,
    isBlocked: Boolean,
    modifier: Modifier = Modifier
) {
    val pct = if (maxCapacityKg > 0.0) (inventoryKg / maxCapacityKg).coerceIn(0.0, 1.0) else 0.0
    val limitPct = if (maxCapacityKg > 0.0) (operatingMaxKg / maxCapacityKg).coerceIn(0.0, 1.0) else 1.0

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "$bankName • $linkedBatchId",
                style = MaterialTheme.typography.labelMedium.copy(
                    color = InkPrimary,
                    fontWeight = FontWeight.SemiBold
                )
            )
            Text(
                text = "${String.format(Locale.UK, "%,.0f", inventoryKg)} / ${String.format(Locale.UK, "%,.0f", maxCapacityKg)} kg (${String.format(Locale.UK, "%.1f", pct * 100.0)}% cap-norm)",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = if (isBlocked) StatusAmber else InkSecondary,
                    fontWeight = FontWeight.SemiBold
                )
            )
        }
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(12.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(CanvasSlate)
                .border(1.dp, HairlineBorder, RoundedCornerShape(3.dp))
        ) {
            val fillW = size.width * pct.toFloat()
            drawRoundRect(
                color = if (isBlocked) StatusAmber else barColor,
                topLeft = Offset.Zero,
                size = Size(fillW, size.height),
                cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
            )
            val limitX = size.width * limitPct.toFloat()
            drawLine(
                color = MidnightNavy,
                start = Offset(limitX, 0f),
                end = Offset(limitX, size.height),
                strokeWidth = 2.dp.toPx()
            )
        }
    }
}
