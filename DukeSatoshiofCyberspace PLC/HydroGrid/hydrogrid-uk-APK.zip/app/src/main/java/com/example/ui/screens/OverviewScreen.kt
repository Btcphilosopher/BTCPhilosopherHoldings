package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun OverviewScreen(
    snapshot: PlantSnapshot,
    isCompact: Boolean,
    reducedMotion: Boolean,
    onEquipmentClick: (String) -> Unit,
    onNavigateWorkspace: (Workspace) -> Unit,
    onToggleBoundary: (ElectricalBoundary) -> Unit
) {
    val sec = snapshot.waterElectrolysis.specificElectricityKwhPerKg(snapshot.electricalBoundary)
    val activeBatch = snapshot.qualityBatches.firstOrNull { it.batchId == "H2-042" }
        ?: snapshot.qualityBatches.first()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. TOP ROW: Four White KPI Cards with large dark numerical values
        if (isCompact) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    KpiCard(
                        title = "HYDROGEN OUTPUT",
                        value = String.format(Locale.UK, "%.1f", snapshot.h2OutputKgPerHr),
                        unit = "kg/h",
                        subtitle = "Illustrative • Net purified H₂",
                        accentColor = ProcessCyan,
                        modifier = Modifier.weight(1f).testTag("kpi_h2_output")
                    )
                    KpiCard(
                        title = "ELECTROLYSER POWER",
                        value = String.format(Locale.UK, "%.1f", snapshot.electrolyserPowerMw),
                        unit = "MW",
                        subtitle = "${snapshot.electricalBoundary.label} • ${sec?.let { String.format(Locale.UK, "%.1f kWh/kg", it) } ?: "— kWh/kg"}",
                        accentColor = SaltireBlue,
                        onClick = {
                            val next = if (snapshot.electricalBoundary == ElectricalBoundary.COMPLETE_PLANT) {
                                ElectricalBoundary.STACK_ONLY
                            } else ElectricalBoundary.COMPLETE_PLANT
                            onToggleBoundary(next)
                        },
                        modifier = Modifier.weight(1f).testTag("kpi_power")
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    KpiCard(
                        title = "STORAGE INVENTORY",
                        value = String.format(Locale.UK, "%,.0f", snapshot.storageInventoryKg),
                        unit = "kg",
                        subtitle = "Illustrative • 3 Banks (${String.format(Locale.UK, "%.1f", (snapshot.storageInventoryKg / 16500.0) * 100.0)}% cap)",
                        accentColor = ProcessCyan,
                        modifier = Modifier.weight(1f).testTag("kpi_storage")
                    )
                    KpiCard(
                        title = "DISPATCH TODAY",
                        value = String.format(Locale.UK, "%,.0f", snapshot.dispatchTodayKg),
                        unit = "kg",
                        subtitle = "Illustrative • Reconciled + Loading",
                        accentColor = SaltireBlue,
                        modifier = Modifier.weight(1f).testTag("kpi_dispatch")
                    )
                }
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                KpiCard(
                    title = "HYDROGEN OUTPUT",
                    value = String.format(Locale.UK, "%.1f", snapshot.h2OutputKgPerHr),
                    unit = "kg/h",
                    subtitle = "Illustrative • Net purified H₂",
                    accentColor = ProcessCyan,
                    modifier = Modifier.weight(1f).testTag("kpi_h2_output")
                )
                KpiCard(
                    title = "ELECTROLYSER POWER",
                    value = String.format(Locale.UK, "%.1f", snapshot.electrolyserPowerMw),
                    unit = "MW",
                    subtitle = "${snapshot.electricalBoundary.label} • ${sec?.let { String.format(Locale.UK, "%.1f kWh/kg", it) } ?: "— kWh/kg"}",
                    accentColor = SaltireBlue,
                    onClick = {
                        val next = if (snapshot.electricalBoundary == ElectricalBoundary.COMPLETE_PLANT) {
                            ElectricalBoundary.STACK_ONLY
                        } else ElectricalBoundary.COMPLETE_PLANT
                        onToggleBoundary(next)
                    },
                    modifier = Modifier.weight(1f).testTag("kpi_power")
                )
                KpiCard(
                    title = "STORAGE INVENTORY",
                    value = String.format(Locale.UK, "%,.0f", snapshot.storageInventoryKg),
                    unit = "kg",
                    subtitle = "Illustrative • 3 Banks (${String.format(Locale.UK, "%.1f", (snapshot.storageInventoryKg / snapshot.storageBanks.sumOf { it.maxCapacityKg }.coerceAtLeast(1.0)) * 100.0)}% cap-norm)",
                    accentColor = ProcessCyan,
                    modifier = Modifier.weight(1f).testTag("kpi_storage")
                )
                KpiCard(
                    title = "DISPATCH TODAY",
                    value = String.format(Locale.UK, "%,.0f", snapshot.dispatchTodayKg),
                    unit = "kg",
                    subtitle = "Illustrative • Reporting day total",
                    accentColor = SaltireBlue,
                    modifier = Modifier.weight(1f).testTag("kpi_dispatch")
                )
            }
        }

        // 2. MIDDLE ROW: Large Process Illustration (~66%) + Right-hand Quality & Output Trend Panel (~34%)
        if (isCompact) {
            ProcessPlantIllustration(
                snapshot = snapshot,
                reducedMotion = reducedMotion,
                onEquipmentClick = onEquipmentClick,
                modifier = Modifier.fillMaxWidth().height(310.dp)
            )
            QualityAndTrendPanel(
                batch = activeBatch,
                trendPoints = snapshot.outputTrendKgHr,
                onOpenQuality = { onNavigateWorkspace(Workspace.QUALITY) },
                modifier = Modifier.fillMaxWidth()
            )
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(336.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ProcessPlantIllustration(
                    snapshot = snapshot,
                    reducedMotion = reducedMotion,
                    onEquipmentClick = onEquipmentClick,
                    modifier = Modifier
                        .weight(0.66f)
                        .fillMaxHeight()
                )
                QualityAndTrendPanel(
                    batch = activeBatch,
                    trendPoints = snapshot.outputTrendKgHr,
                    onOpenQuality = { onNavigateWorkspace(Workspace.QUALITY) },
                    modifier = Modifier
                        .weight(0.34f)
                        .fillMaxHeight()
                )
            }
        }

        // 3. BOTTOM ROW: Energy & Water | Storage Banks | Dispatch Queue
        if (isCompact) {
            EnergyAndWaterCard(snapshot, onNavigateWorkspace, Modifier.fillMaxWidth())
            StorageBanksCard(snapshot, onNavigateWorkspace, Modifier.fillMaxWidth())
            DispatchQueueCard(snapshot, onNavigateWorkspace, Modifier.fillMaxWidth())
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                EnergyAndWaterCard(snapshot, onNavigateWorkspace, Modifier.weight(1f))
                StorageBanksCard(snapshot, onNavigateWorkspace, Modifier.weight(1f))
                DispatchQueueCard(snapshot, onNavigateWorkspace, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun KpiCard(
    title: String,
    value: String,
    unit: String,
    subtitle: String,
    accentColor: androidx.compose.ui.graphics.Color,
    onClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Surface(
        color = PureWhite,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, ThinRuleBlue),
        modifier = modifier.then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = InkSecondary,
                        fontWeight = FontWeight.Bold
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Box(
                    modifier = Modifier
                        .size(width = 22.dp, height = 3.dp)
                        .background(accentColor, RoundedCornerShape(2.dp))
                )
            }
            Spacer(Modifier.height(6.dp))
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = value,
                    style = MaterialTheme.typography.displaySmall.copy(color = MidnightNavy)
                )
                Text(
                    text = unit,
                    style = MaterialTheme.typography.titleMedium.copy(color = SaltireBlue),
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }
            Spacer(Modifier.height(4.dp))
            HorizontalDivider(color = ThinRuleBlue.copy(alpha = 0.6f))
            Spacer(Modifier.height(4.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall.copy(color = InkMuted),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun QualityAndTrendPanel(
    batch: QualityBatch,
    trendPoints: List<Float>,
    onOpenQuality: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isHold = batch.releaseStatus != BatchReleaseStatus.RELEASED
    Surface(
        color = PureWhite,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, if (isHold) StatusAmber.copy(alpha = 0.7f) else ThinRuleBlue),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "QUALITY & OUTPUT TREND",
                    style = MaterialTheme.typography.titleSmall.copy(
                        color = MidnightNavy,
                        fontWeight = FontWeight.Bold
                    )
                )
                StatusPill(
                    label = batch.releaseStatus.label,
                    tone = when (batch.releaseStatus) {
                        BatchReleaseStatus.RELEASED -> StatusTone.HEALTHY
                        BatchReleaseStatus.HOLD_FOR_REVIEW -> StatusTone.AMBER
                        BatchReleaseStatus.QUARANTINED -> StatusTone.FAULT
                    }
                )
            }

            // Batch Metadata Card (Amber when HOLD FOR REVIEW — never green!)
            Surface(
                color = if (isHold) StatusAmberBg else StatusHealthyBg,
                shape = RoundedCornerShape(6.dp),
                border = BorderStroke(1.dp, if (isHold) StatusAmber else StatusHealthy),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenQuality() }
                    .testTag("overview_quality_batch_card")
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Batch ${batch.batchId}",
                            style = MaterialTheme.typography.titleSmall.copy(
                                color = MidnightNavy,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = batch.reviewStatus.label,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (isHold) StatusAmber else StatusHealthy,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Purity: ${batch.measuredPurityPct?.let { String.format(Locale.UK, "%.3f%%", it) } ?: "Pending Lab"}",
                            style = MaterialTheme.typography.labelMedium.copy(color = InkPrimary)
                        )
                        Text(
                            text = "H₂O: ${batch.measuredMoisturePpm?.let { String.format(Locale.UK, "%.1f ppm", it) } ?: "Pending"}",
                            style = MaterialTheme.typography.labelMedium.copy(color = InkPrimary)
                        )
                    }
                    Text(
                        text = "Sampled: ${batch.latestSampleTimestamp} • Spec ${batch.specVersion}",
                        style = MaterialTheme.typography.labelSmall.copy(color = InkSecondary)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "H₂ PRODUCTION TREND (kg/h)",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = InkSecondary,
                        fontWeight = FontWeight.Bold
                    )
                )
                TextButton(
                    onClick = onOpenQuality,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                ) {
                    Text("Open Lab", style = MaterialTheme.typography.labelSmall, color = SaltireBlue)
                }
            }

            OutputTrendChart(
                points = trendPoints,
                lineColor = ProcessCyan,
                unitSuffix = " kg/h",
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .heightIn(min = 100.dp)
            )
        }
    }
}

@Composable
private fun EnergyAndWaterCard(
    snapshot: PlantSnapshot,
    onNavigate: (Workspace) -> Unit,
    modifier: Modifier = Modifier
) {
    val we = snapshot.waterElectrolysis
    val sec = we.specificElectricityKwhPerKg(snapshot.electricalBoundary)
    Surface(
        color = PureWhite,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, ThinRuleBlue),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Filled.Bolt, contentDescription = null, tint = SaltireBlue, modifier = Modifier.size(18.dp))
                    Text("ENERGY & WATER", style = MaterialTheme.typography.titleSmall.copy(color = MidnightNavy, fontWeight = FontWeight.Bold))
                }
                Text(
                    text = "Details →",
                    style = MaterialTheme.typography.labelSmall.copy(color = SaltireBlue, fontWeight = FontWeight.Bold),
                    modifier = Modifier.clickable { onNavigate(Workspace.WATER) }.padding(4.dp)
                )
            }
            HorizontalDivider(color = ThinRuleBlue)
            MetricPairRow("Specific Electricity (${snapshot.electricalBoundary.label})", sec?.let { String.format(Locale.UK, "%.1f kWh/kg", it) } ?: "—")
            MetricPairRow("Stack DC / Aux+Compression", "${String.format(Locale.UK, "%.2f", we.stackDcPowerMw)} MW / ${String.format(Locale.UK, "%.2f", we.auxBalanceOfPlantMw + we.compressionPowerMw)} MW")
            MetricPairRow("Feedwater Intake (incl. RO/EDI)", "${String.format(Locale.UK, "%,.0f", we.feedwaterFlowLPerHr)} L/h (${we.specificWaterFeedLPerKg?.let { String.format(Locale.UK, "%.1f L/kg", it) } ?: "—"})")
            MetricPairRow("Stoichiometric H₂O Reaction", "${String.format(Locale.UK, "%,.0f", we.stoichiometricWaterUsedKgPerHr)} kg/h")
            MetricPairRow("Treatment Reject + Blowdown", "${String.format(Locale.UK, "%,.0f", we.roRejectLossLPerHr + we.ediBlowdownLossLPerHr)} L/h")
        }
    }
}

@Composable
private fun StorageBanksCard(
    snapshot: PlantSnapshot,
    onNavigate: (Workspace) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = PureWhite,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, ThinRuleBlue),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Filled.Inventory2, contentDescription = null, tint = ProcessCyan, modifier = Modifier.size(18.dp))
                    Text("STORAGE BANKS", style = MaterialTheme.typography.titleSmall.copy(color = MidnightNavy, fontWeight = FontWeight.Bold))
                }
                Text(
                    text = "Manage →",
                    style = MaterialTheme.typography.labelSmall.copy(color = SaltireBlue, fontWeight = FontWeight.Bold),
                    modifier = Modifier.clickable { onNavigate(Workspace.STORAGE) }.padding(4.dp)
                )
            }
            HorizontalDivider(color = ThinRuleBlue)
            snapshot.storageBanks.forEach { bank ->
                val isHold = snapshot.qualityBatches.find { it.batchId == bank.linkedBatchId }?.releaseStatus != BatchReleaseStatus.RELEASED
                CapacityNormalisedBar(
                    bankName = bank.id,
                    inventoryKg = bank.inventoryKg,
                    maxCapacityKg = bank.maxCapacityKg,
                    operatingMaxKg = bank.operatingMaxKg,
                    linkedBatchId = if (isHold) "${bank.linkedBatchId} (HOLD)" else bank.linkedBatchId,
                    barColor = if (isHold) StatusAmber else ProcessCyan,
                    isBlocked = bank.isAtOperatingLimit || isHold
                )
            }
        }
    }
}

@Composable
private fun DispatchQueueCard(
    snapshot: PlantSnapshot,
    onNavigate: (Workspace) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = PureWhite,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, ThinRuleBlue),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Filled.LocalShipping, contentDescription = null, tint = SaltireBlue, modifier = Modifier.size(18.dp))
                    Text("DISPATCH QUEUE", style = MaterialTheme.typography.titleSmall.copy(color = MidnightNavy, fontWeight = FontWeight.Bold))
                }
                Text(
                    text = "Workflow →",
                    style = MaterialTheme.typography.labelSmall.copy(color = SaltireBlue, fontWeight = FontWeight.Bold),
                    modifier = Modifier.clickable { onNavigate(Workspace.DISPATCH) }.padding(4.dp)
                )
            }
            HorizontalDivider(color = ThinRuleBlue)
            snapshot.dispatchOrders.take(4).forEach { order ->
                val tone = when (order.stage) {
                    DispatchStage.RELEASED, DispatchStage.RECONCILED -> StatusTone.HEALTHY
                    DispatchStage.HELD, DispatchStage.EXCEPTION -> StatusTone.AMBER
                    DispatchStage.CANCELLED -> StatusTone.FAULT
                    DispatchStage.LOADING, DispatchStage.AUTHORISED -> StatusTone.INFO
                    else -> StatusTone.NEUTRAL
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${order.trailerRegistration} • ${order.customerName}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = InkPrimary,
                                fontWeight = FontWeight.SemiBold
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${order.orderId} • ${String.format(Locale.UK, "%.0f", order.requestedMassKg)} kg • Batch ${order.assignedBatchId}",
                            style = MaterialTheme.typography.labelSmall.copy(color = InkMuted)
                        )
                    }
                    StatusPill(order.stage.label.uppercase(Locale.UK), tone)
                }
            }
        }
    }
}

@Composable
fun MetricPairRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(color = InkSecondary),
            modifier = Modifier.weight(1f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium.copy(
                color = InkPrimary,
                fontWeight = FontWeight.Bold
            )
        )
    }
}
