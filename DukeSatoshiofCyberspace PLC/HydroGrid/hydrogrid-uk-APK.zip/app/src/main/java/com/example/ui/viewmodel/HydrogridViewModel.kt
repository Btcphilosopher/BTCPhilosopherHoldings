package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.HydrogridApplication
import com.example.core.model.*
import com.example.data.local.PendingSyncActionEntity
import com.example.data.local.TerminalPreferences
import com.example.data.repository.HydrogridRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class HydrogridViewModel(application: Application) : AndroidViewModel(application) {

    private val repo: HydrogridRepository =
        (application as HydrogridApplication).repository

    val snapshot: StateFlow<PlantSnapshot> = repo.snapshot
    val statusBanner: StateFlow<String?> = repo.statusBanner

    val preferences: StateFlow<TerminalPreferences> = repo.preferencesStore.preferencesFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = TerminalPreferences()
        )

    val pendingSyncActions: StateFlow<List<PendingSyncActionEntity>> = repo.observePendingActions()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _activeWorkspace = MutableStateFlow(Workspace.OVERVIEW)
    val activeWorkspace: StateFlow<Workspace> = _activeWorkspace.asStateFlow()

    private val _selectedEquipmentId = MutableStateFlow<String?>(null)
    val selectedEquipment: StateFlow<EquipmentUnit?> = combine(
        snapshot,
        _selectedEquipmentId
    ) { snap, id ->
        if (id == null) null else snap.equipment.find { it.id == id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _backendTestResult = MutableStateFlow<String?>(null)
    val backendTestResult: StateFlow<String?> = _backendTestResult.asStateFlow()

    fun selectWorkspace(workspace: Workspace) {
        _activeWorkspace.value = workspace
    }

    fun openEquipmentDetail(equipmentId: String) {
        _selectedEquipmentId.value = equipmentId
    }

    fun closeEquipmentDetail() {
        _selectedEquipmentId.value = null
    }

    fun clearBanner() = repo.clearBanner()

    fun setSimSpeed(speed: SimSpeed) = repo.setSimSpeed(speed)
    fun resetSimulation() = repo.resetSimulation()
    fun setRole(role: UserRole) = repo.setRole(role)
    fun setElectricalBoundary(boundary: ElectricalBoundary) = repo.setElectricalBoundary(boundary)

    fun simulateStaleTelemetry(stale: Boolean) = repo.simulateStaleTelemetryTest(stale)
    fun triggerCachedMode() = repo.triggerCachedFallbackMode()
    fun recoverLiveTelemetry() = repo.recoverLiveTelemetry()

    fun registerSample(
        batchId: String,
        sourceType: ReadingSourceType,
        purityPct: Double,
        moisturePpm: Double,
        oxygenPpm: Double,
        analystName: String,
        attachmentRef: String?,
        notes: String,
        correctionReason: String? = null
    ) = repo.registerSample(
        batchId, sourceType, purityPct, moisturePpm, oxygenPpm, analystName, attachmentRef, notes, correctionReason
    )

    fun authoriseBatchRelease(batchId: String, authoriserName: String) =
        repo.authoriseBatchRelease(batchId, authoriserName)

    fun advanceDispatchOrder(
        orderId: String,
        targetStage: DispatchStage,
        confirmedTransferKg: Double? = null,
        reason: String? = null
    ) = repo.advanceDispatchOrder(orderId, targetStage, confirmedTransferKg, reason)

    fun updateStorageLimits(bankId: String, minKg: Double, maxKg: Double) =
        repo.updateStorageLimits(bankId, minKg, maxKg)

    fun acknowledgeAlert(alertId: String) = repo.acknowledgeAlert(alertId)
    fun injectFault(equipmentTag: String, reason: String) = repo.injectEquipmentFault(equipmentTag, reason)
    fun resolveFault(workOrderId: String) = repo.resolveMaintenanceFault(workOrderId)
    fun addShiftHandover(shiftName: String, operatorName: String, summary: String) =
        repo.addShiftHandover(shiftName, operatorName, summary)

    fun updateSimConfig(config: SimulationConfig) = repo.updateSimulationConfig(config)

    fun buildPeriodReport(label: String, hoursWindow: Double): PeriodReportMetrics =
        repo.buildPeriodReport(label, hoursWindow)

    fun setReducedMotion(enabled: Boolean) {
        viewModelScope.launch { repo.preferencesStore.setReducedMotion(enabled) }
    }

    fun setBackendConfig(url: String, enabled: Boolean) {
        viewModelScope.launch {
            repo.preferencesStore.setBackendBaseUrl(url)
            repo.preferencesStore.setUseRemoteBackend(enabled)
        }
    }

    fun saveApiToken(token: String) {
        repo.credentialManager.saveApiToken(token)
    }

    fun hasStoredApiToken(): Boolean = repo.credentialManager.hasStoredToken()

    fun testRemoteConnection(url: String) {
        viewModelScope.launch {
            _backendTestResult.value = "Testing..."
            _backendTestResult.value = repo.testRemoteBackend(url)
        }
    }

    fun triggerManualSync() = repo.triggerImmediateWorkManagerSync()

    fun discardSyncConflict(key: String) = repo.resolveOfflineConflictDiscard(key)
}
