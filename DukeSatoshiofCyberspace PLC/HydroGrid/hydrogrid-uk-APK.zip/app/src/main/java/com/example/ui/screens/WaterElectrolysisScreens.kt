package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.model.ElectricalBoundary
import com.example.core.model.PlantSnapshot
import com.example.ui.components.OutputTrendChart
import com.example.ui.components.StatusPill
import com.example.ui.components.StatusTone
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun WaterScreen(snapshot: PlantSnapshot) {
    val we = snapshot.waterElectrolysis
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        WorkspaceSectionHeader(
            title = "Water Treatment & Mass Accounting",
            subtitle = "Provenance: ${we.waterProvenance} • Distinguishes total feedwater intake from stoichiometric reaction water"
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatPanelCard(
                title = "Feedwater Receipt",
                value = "${String.format(Locale.UK, "%,.0f", we.feedwaterFlowLPerHr)} L/h",
                detail = "Specific feed: ${we.specificWaterFeedLPerKg?.let { String.format(Locale.UK, "%.1f L/kg H₂", it) } ?: "—"}",
                modifier = Modifier.weight(1f)
            )
            StatPanelCard(
                title = "Treated Water Tank",
                value = "${String.format(Locale.UK, "%,.0f", we.treatedWaterAvailableL)} L",
                detail = "Capacity: ${String.format(Locale.UK, "%,.0f", we.treatedTankCapacityL)} L (${String.format(Locale.UK, "%.1f", (we.treatedWaterAvailableL / we.treatedTankCapacityL) * 100)}%)",
                modifier = Modifier.weight(1f)
            )
            StatPanelCard(
                title = "Stoichiometric Consumption",
                value = "${String.format(Locale.UK, "%,.0f", we.stoichiometricWaterUsedKgPerHr)} kg/h",
                detail = "8.94 kg H₂O / kg gross H₂ (distinct from feedwater)",
                modifier = Modifier.weight(1f)
            )
            StatPanelCard(
                title = "Treatment Losses (RO + EDI)",
                value = "${String.format(Locale.UK, "%,.0f", we.roRejectLossLPerHr + we.ediBlowdownLossLPerHr)} L/h",
                detail = "RO Reject ${String.format(Locale.UK, "%,.0f", we.roRejectLossLPerHr)} • EDI ${String.format(Locale.UK, "%,.0f", we.ediBlowdownLossLPerHr)}",
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                color = PureWhite,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, ThinRuleBlue),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("WATER QUALITY & PROVENANCE", style = MaterialTheme.typography.titleSmall.copy(color = MidnightNavy, fontWeight = FontWeight.Bold))
                        StatusPill("CONTINUOUS ANALYSER", StatusTone.HEALTHY)
                    }
                    HorizontalDivider(color = ThinRuleBlue)
                    MetricPairRow("EDI Permeate Conductivity", "${String.format(Locale.UK, "%.3f", we.conductivityMicroSPerCm)} µS/cm (Limit < 0.10)")
                    MetricPairRow("Total Organic Carbon (TOC)", "${String.format(Locale.UK, "%.1f", we.tocPpb)} ppb (Limit < 50)")
                    MetricPairRow("Modelled Treatment Recovery", "${String.format(Locale.UK, "%.1f", snapshot.simConfig.waterTreatmentRecoveryPct)}% configurable assumption")
                    MetricPairRow("Cumulative Treatment Loss Today", "${String.format(Locale.UK, "%,.0f", snapshot.waterLossTodayL)} L")
                }
            }

            Surface(
                color = PureWhite,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, ThinRuleBlue),
                modifier = Modifier.weight(1.3f)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("FEEDWATER FLOW TREND (L/h)", style = MaterialTheme.typography.titleSmall.copy(color = MidnightNavy, fontWeight = FontWeight.Bold))
                    OutputTrendChart(
                        points = we.waterFlowHistory,
                        lineColor = SaltireBlue,
                        unitSuffix = " L/h",
                        modifier = Modifier.fillMaxWidth().height(155.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ElectrolysisScreen(
    snapshot: PlantSnapshot,
    onSelectBoundary: (ElectricalBoundary) -> Unit
) {
    val we = snapshot.waterElectrolysis
    val sec = we.specificElectricityKwhPerKg(snapshot.electricalBoundary)
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        WorkspaceSectionHeader(
            title = "PEM Electrolysis & Electrical Accounting",
            subtitle = "Boundary-aligned specific energy • Distinct H₂ and O₂ outlets • Configurable simplified model (not a validated stack engineering model)"
        )

        // Measurement Boundary Selector
        Surface(
            color = PureWhite,
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, ThinRuleBlue),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("ELECTRICAL MEASUREMENT BOUNDARY", style = MaterialTheme.typography.labelSmall.copy(color = SaltireBlue, fontWeight = FontWeight.Bold))
                    Text(snapshot.electricalBoundary.description, style = MaterialTheme.typography.bodySmall.copy(color = InkSecondary))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ElectricalBoundary.entries.forEach { boundary ->
                        FilterChip(
                            selected = snapshot.electricalBoundary == boundary,
                            onClick = { onSelectBoundary(boundary) },
                            label = { Text(boundary.label) }
                        )
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatPanelCard(
                title = "Modules Online",
                value = "${we.activeModules} / ${we.totalModules}",
                detail = "Accumulated: ${String.format(Locale.UK, "%,.1f", we.stackOperatingHours)} h",
                modifier = Modifier.weight(1f)
            )
            StatPanelCard(
                title = "Electrical Input (${snapshot.electricalBoundary.label})",
                value = "${String.format(Locale.UK, "%.2f", we.effectivePowerMw(snapshot.electricalBoundary))} MW",
                detail = "SEC: ${sec?.let { String.format(Locale.UK, "%.1f kWh/kg", it) } ?: "— (Output stopped)"}",
                modifier = Modifier.weight(1f)
            )
            StatPanelCard(
                title = "Net H₂ Produced Rate",
                value = "${String.format(Locale.UK, "%.1f", we.h2OutputKgPerHr)} kg/h",
                detail = "Purification purge loss: ${String.format(Locale.UK, "%.1f", we.h2PurificationLossKgPerHr)} kg/h",
                modifier = Modifier.weight(1f)
            )
            StatPanelCard(
                title = "Co-Product O₂ Outlet",
                value = "${String.format(Locale.UK, "%,.0f", we.o2OutputKgPerHr)} kg/h",
                detail = "Today O₂: ${String.format(Locale.UK, "%,.0f", snapshot.o2OutputTodayKg)} kg",
                modifier = Modifier.weight(1f)
            )
        }

        Surface(
            color = PureWhite,
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, ThinRuleBlue),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("ELECTRICAL INPUT TREND (MW)", style = MaterialTheme.typography.titleSmall.copy(color = MidnightNavy, fontWeight = FontWeight.Bold))
                OutputTrendChart(
                    points = we.powerHistoryMw,
                    lineColor = ElectricalGold,
                    unitSuffix = " MW",
                    modifier = Modifier.fillMaxWidth().height(170.dp)
                )
            }
        }
    }
}

@Composable
fun WorkspaceSectionHeader(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
            text = title.uppercase(Locale.UK),
            style = MaterialTheme.typography.headlineSmall.copy(
                color = MidnightNavy,
                fontWeight = FontWeight.Bold
            )
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall.copy(color = InkSecondary)
        )
        HorizontalDivider(color = ThinRuleBlue, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
fun StatPanelCard(
    title: String,
    value: String,
    detail: String,
    modifier: Modifier = Modifier
) {
    Surface(
        color = PureWhite,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, ThinRuleBlue),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title.uppercase(Locale.UK), style = MaterialTheme.typography.labelSmall.copy(color = InkMuted, fontWeight = FontWeight.Bold))
            Text(value, style = MaterialTheme.typography.headlineMedium.copy(color = MidnightNavy))
            HorizontalDivider(color = ThinRuleBlue.copy(alpha = 0.5f))
            Text(detail, style = MaterialTheme.typography.labelSmall.copy(color = InkSecondary))
        }
    }
}
