package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val HydrogridLightColorScheme = lightColorScheme(
    primary = SaltireBlue,
    onPrimary = PureWhite,
    primaryContainer = StatusDemoBg,
    onPrimaryContainer = MidnightNavy,
    secondary = ProcessCyan,
    onSecondary = MidnightNavy,
    secondaryContainer = ProcessCyanSoft,
    onSecondaryContainer = MidnightNavy,
    tertiary = ActiveNavBlue,
    onTertiary = PureWhite,
    background = CanvasSlate,
    onBackground = InkPrimary,
    surface = PureWhite,
    onSurface = InkPrimary,
    surfaceVariant = SoftPanelBg,
    onSurfaceVariant = InkSecondary,
    outline = HairlineBorder,
    outlineVariant = ThinRuleBlue,
    error = StatusFault,
    onError = PureWhite,
    errorContainer = StatusFaultBg,
    onErrorContainer = StatusFault
)

@Composable
fun HydrogridTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = HydrogridLightColorScheme,
        typography = HydrogridTypography,
        content = content
    )
}
