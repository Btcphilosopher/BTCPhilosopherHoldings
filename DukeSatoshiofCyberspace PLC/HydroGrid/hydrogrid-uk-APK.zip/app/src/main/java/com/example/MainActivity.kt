package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.model.BatchReleaseStatus
import com.example.core.model.Workspace
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.HydrogridViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            HydrogridTheme {
                HydrogridTerminalApp()
            }
        }
    }
}

@Composable
fun HydrogridTerminalApp(
    viewModel: HydrogridViewModel = viewModel()
) {
    val snapshot by viewModel.snapshot.collectAsStateWithLifecycle()
    val prefs by viewModel.preferences.collectAsStateWithLifecycle()
    val activeWorkspace by viewModel.activeWorkspace.collectAsStateWithLifecycle()
    val selectedEquipment by viewModel.selectedEquipment.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()
    val pendingActions by viewModel.pendingSyncActions.collectAsStateWithLifecycle()
    val backendTestResult by viewModel.backendTestResult.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(statusBanner) {
        statusBanner?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearBanner()
        }
    }

    // Back navigation from secondary workspaces returns to Overview
    BackHandler(enabled = activeWorkspace != Workspace.OVERVIEW) {
        viewModel.selectWorkspace(Workspace.OVERVIEW)
    }

    val alertCount = remember(snapshot.alerts) {
        snapshot.alerts.count { !it.physicalConditionResolved }
    }
    val holdCount = remember(snapshot.qualityBatches) {
        snapshot.qualityBatches.count { it.releaseStatus != BatchReleaseStatus.RELEASED }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasSlate)
    ) {
        val isCompact = maxWidth < 760.dp

        Scaffold(
            containerColor = CanvasSlate,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            contentWindowInsets = WindowInsets.safeDrawing,
            topBar = {
                HydrogridTopHeader(
                    snapshot = snapshot,
                    isCompact = isCompact,
                    onSetSimSpeed = viewModel::setSimSpeed,
                    onResetSim = viewModel::resetSimulation,
                    onSelectRole = viewModel::setRole,
                    onOpenSettings = { viewModel.selectWorkspace(Workspace.SETTINGS) }
                )
            },
            bottomBar = {
                if (isCompact) {
                    CompactWorkspaceBar(
                        activeWorkspace = activeWorkspace,
                        onSelectWorkspace = viewModel::selectWorkspace
                    )
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (!isCompact) {
                    HydrogridSidebar(
                        activeWorkspace = activeWorkspace,
                        alertCount = alertCount,
                        holdCount = holdCount,
                        onSelectWorkspace = viewModel::selectWorkspace
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    when (activeWorkspace) {
                        Workspace.OVERVIEW -> OverviewScreen(
                            snapshot = snapshot,
                            isCompact = isCompact,
                            reducedMotion = prefs.reducedMotion,
                            onEquipmentClick = viewModel::openEquipmentDetail,
                            onNavigateWorkspace = viewModel::selectWorkspace,
                            onToggleBoundary = viewModel::setElectricalBoundary
                        )
                        Workspace.WATER -> WaterScreen(snapshot = snapshot)
                        Workspace.ELECTROLYSIS -> ElectrolysisScreen(
                            snapshot = snapshot,
                            onSelectBoundary = viewModel::setElectricalBoundary
                        )
                        Workspace.COMPRESSION -> CompressionScreen(snapshot = snapshot)
                        Workspace.STORAGE -> StorageScreen(
                            snapshot = snapshot,
                            onUpdateLimits = viewModel::updateStorageLimits
                        )
                        Workspace.QUALITY -> QualityScreen(
                            snapshot = snapshot,
                            onRegisterSample = viewModel::registerSample,
                            onAuthoriseRelease = viewModel::authoriseBatchRelease
                        )
                        Workspace.DISPATCH -> DispatchScreen(
                            snapshot = snapshot,
                            onAdvanceOrder = viewModel::advanceDispatchOrder
                        )
                        Workspace.MAINTENANCE -> MaintenanceScreen(
                            snapshot = snapshot,
                            onAcknowledgeAlert = viewModel::acknowledgeAlert,
                            onResolveFault = viewModel::resolveFault,
                            onAddHandover = viewModel::addShiftHandover,
                            onInjectFault = viewModel::injectFault
                        )
                        Workspace.REPORTS -> ReportsScreen(
                            snapshot = snapshot,
                            onBuildReport = viewModel::buildPeriodReport
                        )
                        Workspace.SETTINGS -> SettingsScreen(
                            snapshot = snapshot,
                            preferences = prefs,
                            pendingSyncActions = pendingActions,
                            backendTestResult = backendTestResult,
                            hasStoredToken = viewModel.hasStoredApiToken(),
                            onSaveBackendConfig = viewModel::setBackendConfig,
                            onSaveApiToken = viewModel::saveApiToken,
                            onTestConnection = viewModel::testRemoteConnection,
                            onSelectRole = viewModel::setRole,
                            onSetReducedMotion = viewModel::setReducedMotion,
                            onSimulateStale = viewModel::simulateStaleTelemetry,
                            onTriggerCached = viewModel::triggerCachedMode,
                            onRecoverTelemetry = viewModel::recoverLiveTelemetry,
                            onTriggerSync = viewModel::triggerManualSync,
                            onDiscardConflict = viewModel::discardSyncConflict,
                            onUpdateSimConfig = viewModel::updateSimConfig
                        )
                    }
                }
            }
        }
    }

    selectedEquipment?.let { unit ->
        EquipmentDetailDialog(
            unit = unit,
            alerts = snapshot.alerts,
            workOrders = snapshot.workOrders,
            onDismiss = viewModel::closeEquipmentDetail,
            onAcknowledgeAlert = viewModel::acknowledgeAlert,
            onInjectFault = viewModel::injectFault
        )
    }
}
