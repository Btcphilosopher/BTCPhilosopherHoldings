# HYDROGRID UK — API Documentation, Backend Migrations & Android Build Guide

## 1. Architecture Summary
- **Android Terminal**: Kotlin, Jetpack Compose (M3), MVVM (`ViewModel` + `StateFlow`), Room cache & offline sync queue, DataStore preferences, WorkManager background sync, AndroidKeyStore AES-256-GCM credentials, and replaceable `HydrogridApiClient` (Retrofit/Moshi).
- **Simulation Backend**: Python 3.12, FastAPI, SQLAlchemy 2.0, PostgreSQL 16, Alembic migrations, and pytest suite.
- **Safety & System Boundary**: Monitoring, planning, and simulation terminal only. Physical plant controls, gas detection, emergency shutdown (ESD), and protective interlocks remain on independent safety-instrumented systems.

## 2. Running the Python/FastAPI/PostgreSQL Backend
```bash
cd backend
docker compose up --build
```
Or locally with an existing PostgreSQL instance:
```bash
cd backend
pip install -r requirements.txt
export DATABASE_URL="postgresql+psycopg://hydrogrid:hydrogrid_dev_pass@localhost:5432/hydrogrid_uk"
alembic upgrade head
python seed_data.py
uvicorn app.main:app --host 0.0.0.0 --port 8000
```
Run backend tests:
```bash
cd backend
pytest -v
```

## 3. FastAPI Endpoints (OpenAPI available at `/docs`)
| Method | Endpoint | Role Required | Description |
|---|---|---|---|
| `GET` | `/api/v1/health` | Any | Health check, plant name, sim clock, and state version |
| `GET` | `/api/v1/snapshot` | Any | Current KPIs, mass/energy totals, and flow block status |
| `POST` | `/api/v1/sim/speed` | Operator / Supervisor / Admin | Set `PAUSED`, `NORMAL_1X`, `ACCEL_10X`, `ACCEL_60X` |
| `POST` | `/api/v1/sim/step` | Any | Advance simulation by `real_seconds` |
| `POST` | `/api/v1/sim/reset` | Operator / Supervisor / Admin | Reset to initial Aberdeen Green H2 Works baseline |
| `POST` | `/api/v1/quality/samples` | Lab Staff / Supervisor / Admin | Record discrete/analyser/manual sample (never auto-releases) |
| `POST` | `/api/v1/quality/release` | Lab Staff / Supervisor / Admin | Authorise batch release after passing review |
| `POST` | `/api/v1/dispatch/reconcile` | Dispatch / Supervisor / Admin | Reconcile weighbridge mass; blocks quality-held batches (`409`) |
| `POST` | `/api/v1/actions` | Any (RBAC-checked) | Idempotent offline sync mutation (`Idempotency-Key` + `expected_version`) |

## 4. Building the Android APK & Emulator Setup
1. **Build Debug APK**:
   ```bash
   gradle :app:assembleDebug
   ```
   Output APK: `app/build/outputs/apk/debug/app-debug.apk`
2. **Run Android Unit & Robolectric Tests**:
   ```bash
   gradle :app:testDebugUnitTest
   ```
3. **Android Tablet Emulator Setup**:
   - Create an AVD in Android Studio Device Manager using **Pixel Tablet** (2560×1600 landscape, API 34–36).
   - Start the backend on your host machine (`port 8000`).
   - In the Hydrogrid UK app **Settings** workspace, keep the default URL `http://10.0.2.2:8000` (Android emulator loopback alias to host `localhost:8000`), optionally store an encrypted bearer token in AndroidKeyStore, and tap **Test Health Check**.
