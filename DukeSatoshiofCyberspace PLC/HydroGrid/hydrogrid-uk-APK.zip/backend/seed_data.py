"""Seed initial Aberdeen Green H2 Works demonstration data into the database."""
from app.db import Base, SessionLocal, engine
from app.models import (
    DispatchOrderRecord,
    LabSampleRecord,
    PlantStateRecord,
    QualityBatchRecord,
    StorageBankRecord,
)


def seed() -> None:
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        if not db.query(PlantStateRecord).filter_by(id="singleton").first():
            db.add(
                PlantStateRecord(
                    id="singleton",
                    plant_name="Aberdeen Green H2 Works — Phase II",
                    sim_elapsed_seconds=0,
                    sim_speed="NORMAL_1X",
                    h2_output_kg_hr=360.0,
                    electrolyser_power_mw=20.0,
                    produced_today_kg=8520.0,
                    dispatched_today_kg=8640.0,
                    h2_losses_today_kg=156.2,
                    o2_output_today_kg=68850.0,
                    water_loss_today_l=32840.0,
                    version=1,
                )
            )
        if db.query(StorageBankRecord).count() == 0:
            db.add_all([
                StorageBankRecord(id="BANK-A", name="Bank A • High Pressure", inventory_kg=4800.0, max_capacity_kg=5500.0, operating_min_kg=350.0, operating_max_kg=5250.0, pressure_bar=368.0, temperature_c=18.4, vessel_volume_m3=205.0, state="RUNNING", linked_batch_id="H2-041"),
                StorageBankRecord(id="BANK-B", name="Bank B • Buffer & Lab Hold", inventory_kg=4100.0, max_capacity_kg=5500.0, operating_min_kg=350.0, operating_max_kg=5250.0, pressure_bar=312.0, temperature_c=17.9, vessel_volume_m3=205.0, state="RUNNING", linked_batch_id="H2-042"),
                StorageBankRecord(id="BANK-C", name="Bank C • Dispatch Reserve", inventory_kg=3500.0, max_capacity_kg=5500.0, operating_min_kg=350.0, operating_max_kg=5250.0, pressure_bar=264.0, temperature_c=17.2, vessel_volume_m3=205.0, state="RUNNING", linked_batch_id="H2-040"),
            ])
        if db.query(QualityBatchRecord).count() == 0:
            db.add_all([
                QualityBatchRecord(batch_id="H2-042", storage_bank_id="BANK-B", remaining_mass_kg=4100.0, measured_purity_pct=None, measured_moisture_ppm=None, predicted_purity_pct=99.985, predicted_moisture_ppm=2.4, review_status="SAMPLE_PENDING", release_status="HOLD_FOR_REVIEW", spec_version="ISO-14687-D-v2.1"),
                QualityBatchRecord(batch_id="H2-041", storage_bank_id="BANK-A", remaining_mass_kg=4800.0, measured_purity_pct=99.992, measured_moisture_ppm=1.8, predicted_purity_pct=99.990, predicted_moisture_ppm=2.1, review_status="REVIEWED_PASS", release_status="RELEASED", spec_version="ISO-14687-D-v2.1", authorised_by="Dr. F. Campbell"),
                QualityBatchRecord(batch_id="H2-040", storage_bank_id="BANK-C", remaining_mass_kg=3500.0, measured_purity_pct=99.989, measured_moisture_ppm=2.1, predicted_purity_pct=99.988, predicted_moisture_ppm=2.2, review_status="REVIEWED_PASS", release_status="RELEASED", spec_version="ISO-14687-D-v2.1", authorised_by="Dr. F. Campbell"),
            ])
            db.add(LabSampleRecord(sample_id="SMP-100", batch_id="H2-042", timestamp_iso="2026-11-21 14:12 UTC", source_type="CONTINUOUS_ANALYSER", analyst_name="A. MacLeod", notes="Sample cylinder drawn; awaiting laboratory verification.", is_original=True))
        if db.query(DispatchOrderRecord).count() == 0:
            db.add_all([
                DispatchOrderRecord(order_id="DSP-904", customer_name="Aberdeen Zero-Emission Bus Depot", trailer_registration="SC24 HYD", requested_mass_kg=920.0, estimated_loaded_kg=540.0, assigned_batch_id="H2-041", source_bank_id="BANK-A", stage="LOADING"),
                DispatchOrderRecord(order_id="DSP-905", customer_name="Peterhead Port Mobility Hub", trailer_registration="SC73 H2X", requested_mass_kg=880.0, estimated_loaded_kg=0.0, assigned_batch_id="H2-042", source_bank_id="BANK-B", stage="CHECKED", hold_reason="Awaiting Batch H2-042 release"),
            ])
        db.commit()
    finally:
        db.close()


if __name__ == "__main__":
    seed()
    print("Seeded Hydrogrid UK baseline data.")
