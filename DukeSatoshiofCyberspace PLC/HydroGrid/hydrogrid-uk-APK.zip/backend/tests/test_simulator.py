from fastapi.testclient import TestClient
from app.main import app, sim


def setup_function():
    sim.reset()


def test_initial_kpi_and_sec_accuracy():
    client = TestClient(app)
    r = client.get("/api/v1/snapshot", headers={"X-Hydrogrid-Role": "OPERATOR"})
    assert r.status_code == 200
    data = r.json()
    assert data["h2_output_kg_hr"] == 360.0
    assert data["electrolyser_power_mw"] == 20.0
    assert data["storage_inventory_kg"] == 12400.0
    assert data["dispatch_today_kg"] == 8640.0
    assert abs(data["specific_electricity_kwh_per_kg"] - 55.56) < 0.1


def test_material_conservation_and_storage_capacity_blocking():
    sim.sim_speed = "ACCEL_60X"
    for b in sim.banks:
        b.inventory_kg = b.operating_max_kg - 2.0
    before = sim.total_storage_kg
    sim.step(real_seconds=60.0)
    # Must never exceed sum of operating_max_kg
    assert sim.total_storage_kg <= sum(b.operating_max_kg for b in sim.banks)
    assert sim.total_storage_kg >= before
    # Subsequent step must report BLOCKED FLOW and zero H2 output without divide-by-zero
    summary = sim.step(real_seconds=10.0)
    assert summary["flow_blocked_reason"] is not None
    assert summary["h2_output_kg_hr"] == 0.0
    assert summary["specific_electricity_kwh_per_kg"] is None


def test_quality_hold_blocks_dispatch_and_allows_after_authorised_release():
    client = TestClient(app)
    # Attempt to reconcile DSP-905 linked to held batch H2-042 -> blocked (409)
    blocked = client.post(
        "/api/v1/dispatch/reconcile",
        json={"order_id": "DSP-905", "confirmed_mass_kg": 880.0},
        headers={"X-Hydrogrid-Role": "DISPATCH"},
    )
    assert blocked.status_code == 409

    # Register lab sample -> still not auto-released
    smp = client.post(
        "/api/v1/quality/samples",
        json={"batch_id": "H2-042", "purity_pct": 99.991, "moisture_ppm": 1.8, "oxygen_ppm": 1.2, "analyst_name": "Dr. Campbell"},
        headers={"X-Hydrogrid-Role": "LAB_STAFF"},
    )
    assert smp.status_code == 200
    assert smp.json()["release_status"] == "HOLD_FOR_REVIEW"

    # Operator cannot authorise release (RBAC 403)
    forbidden = client.post(
        "/api/v1/quality/release",
        json={"batch_id": "H2-042", "authoriser_name": "Op"},
        headers={"X-Hydrogrid-Role": "OPERATOR"},
    )
    assert forbidden.status_code == 403

    # Supervisor authorises release
    rel = client.post(
        "/api/v1/quality/release",
        json={"batch_id": "H2-042", "authoriser_name": "Dr. Campbell"},
        headers={"X-Hydrogrid-Role": "SUPERVISOR"},
    )
    assert rel.status_code == 200
    assert rel.json()["release_status"] == "RELEASED"

    # Now dispatch reconciliation succeeds without double deduction
    ok = client.post(
        "/api/v1/dispatch/reconcile",
        json={"order_id": "DSP-905", "confirmed_mass_kg": 880.0},
        headers={"X-Hydrogrid-Role": "DISPATCH"},
    )
    assert ok.status_code == 200
    assert ok.json()["stage"] == "RECONCILED"


def test_idempotency_and_offline_conflict():
    client = TestClient(app)
    headers = {"X-Hydrogrid-Role": "OPERATOR", "Idempotency-Key": "sync-key-001"}
    r1 = client.post("/api/v1/actions", json={"action_type": "TEST", "entity_id": "WT-101", "payload_json": "{}", "expected_version": 1}, headers=headers)
    assert r1.status_code == 200
    v_after_first = r1.json()["version"]

    # Replay same idempotency key -> does not mutate again
    r2 = client.post("/api/v1/actions", json={"action_type": "TEST", "entity_id": "WT-101", "payload_json": "{}", "expected_version": 1}, headers=headers)
    assert r2.status_code == 200
    assert r2.json()["version"] == v_after_first
