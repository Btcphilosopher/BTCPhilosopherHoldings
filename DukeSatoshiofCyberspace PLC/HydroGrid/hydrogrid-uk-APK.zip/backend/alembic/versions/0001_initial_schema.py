"""Initial Hydrogrid UK schema

Revision ID: 0001_initial_schema
Revises:
Create Date: 2026-11-21
"""
from alembic import op
import sqlalchemy as sa

revision = "0001_initial_schema"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "plant_state",
        sa.Column("id", sa.String(32), primary_key=True),
        sa.Column("plant_name", sa.String(128), nullable=False),
        sa.Column("sim_elapsed_seconds", sa.Integer, nullable=False),
        sa.Column("sim_speed", sa.String(24), nullable=False),
        sa.Column("h2_output_kg_hr", sa.Float, nullable=False),
        sa.Column("electrolyser_power_mw", sa.Float, nullable=False),
        sa.Column("produced_today_kg", sa.Float, nullable=False),
        sa.Column("dispatched_today_kg", sa.Float, nullable=False),
        sa.Column("h2_losses_today_kg", sa.Float, nullable=False),
        sa.Column("o2_output_today_kg", sa.Float, nullable=False),
        sa.Column("water_loss_today_l", sa.Float, nullable=False),
        sa.Column("version", sa.Integer, nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True)),
    )
    op.create_table(
        "storage_banks",
        sa.Column("id", sa.String(32), primary_key=True),
        sa.Column("name", sa.String(128), nullable=False),
        sa.Column("inventory_kg", sa.Float, nullable=False),
        sa.Column("max_capacity_kg", sa.Float, nullable=False),
        sa.Column("operating_min_kg", sa.Float, nullable=False),
        sa.Column("operating_max_kg", sa.Float, nullable=False),
        sa.Column("pressure_bar", sa.Float, nullable=False),
        sa.Column("temperature_c", sa.Float, nullable=False),
        sa.Column("vessel_volume_m3", sa.Float, nullable=False),
        sa.Column("state", sa.String(32), nullable=False),
        sa.Column("linked_batch_id", sa.String(32), nullable=False),
    )
    op.create_table(
        "quality_batches",
        sa.Column("batch_id", sa.String(32), primary_key=True),
        sa.Column("storage_bank_id", sa.String(32), nullable=False),
        sa.Column("remaining_mass_kg", sa.Float, nullable=False),
        sa.Column("measured_purity_pct", sa.Float),
        sa.Column("measured_moisture_ppm", sa.Float),
        sa.Column("predicted_purity_pct", sa.Float, nullable=False),
        sa.Column("predicted_moisture_ppm", sa.Float, nullable=False),
        sa.Column("review_status", sa.String(32), nullable=False),
        sa.Column("release_status", sa.String(32), nullable=False),
        sa.Column("spec_version", sa.String(32), nullable=False),
        sa.Column("authorised_by", sa.String(128)),
    )
    op.create_table(
        "lab_samples",
        sa.Column("sample_id", sa.String(32), primary_key=True),
        sa.Column("batch_id", sa.String(32), sa.ForeignKey("quality_batches.batch_id"), nullable=False),
        sa.Column("timestamp_iso", sa.String(64), nullable=False),
        sa.Column("source_type", sa.String(32), nullable=False),
        sa.Column("purity_pct", sa.Float),
        sa.Column("moisture_ppm", sa.Float),
        sa.Column("oxygen_ppm", sa.Float),
        sa.Column("analyst_name", sa.String(128), nullable=False),
        sa.Column("notes", sa.Text, nullable=False),
        sa.Column("is_original", sa.Boolean, nullable=False),
        sa.Column("correction_reason", sa.Text),
    )
    op.create_table(
        "dispatch_orders",
        sa.Column("order_id", sa.String(32), primary_key=True),
        sa.Column("customer_name", sa.String(128), nullable=False),
        sa.Column("trailer_registration", sa.String(32), nullable=False),
        sa.Column("requested_mass_kg", sa.Float, nullable=False),
        sa.Column("estimated_loaded_kg", sa.Float, nullable=False),
        sa.Column("confirmed_transfer_kg", sa.Float),
        sa.Column("assigned_batch_id", sa.String(32), nullable=False),
        sa.Column("source_bank_id", sa.String(32), nullable=False),
        sa.Column("stage", sa.String(32), nullable=False),
        sa.Column("delivery_doc_number", sa.String(64)),
        sa.Column("hold_reason", sa.Text),
    )
    op.create_table(
        "audit_log",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column("idempotency_key", sa.String(128), unique=True, nullable=False),
        sa.Column("actor_role", sa.String(32), nullable=False),
        sa.Column("action", sa.String(64), nullable=False),
        sa.Column("entity_ref", sa.String(64), nullable=False),
        sa.Column("detail", sa.Text, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True)),
    )


def downgrade() -> None:
    op.drop_table("audit_log")
    op.drop_table("dispatch_orders")
    op.drop_table("lab_samples")
    op.drop_table("quality_batches")
    op.drop_table("storage_banks")
    op.drop_table("plant_state")
