from datetime import datetime, timezone
from sqlalchemy import Column, String, Float, Integer, Boolean, DateTime, Text, ForeignKey
from .db import Base


class PlantStateRecord(Base):
    __tablename__ = "plant_state"

    id = Column(String(32), primary_key=True, default="singleton")
    plant_name = Column(String(128), nullable=False)
    sim_elapsed_seconds = Column(Integer, nullable=False, default=0)
    sim_speed = Column(String(24), nullable=False, default="NORMAL_1X")
    h2_output_kg_hr = Column(Float, nullable=False, default=360.0)
    electrolyser_power_mw = Column(Float, nullable=False, default=20.0)
    produced_today_kg = Column(Float, nullable=False, default=8520.0)
    dispatched_today_kg = Column(Float, nullable=False, default=8640.0)
    h2_losses_today_kg = Column(Float, nullable=False, default=156.2)
    o2_output_today_kg = Column(Float, nullable=False, default=68850.0)
    water_loss_today_l = Column(Float, nullable=False, default=32840.0)
    version = Column(Integer, nullable=False, default=1)
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class StorageBankRecord(Base):
    __tablename__ = "storage_banks"

    id = Column(String(32), primary_key=True)
    name = Column(String(128), nullable=False)
    inventory_kg = Column(Float, nullable=False)
    max_capacity_kg = Column(Float, nullable=False)
    operating_min_kg = Column(Float, nullable=False)
    operating_max_kg = Column(Float, nullable=False)
    pressure_bar = Column(Float, nullable=False)
    temperature_c = Column(Float, nullable=False)
    vessel_volume_m3 = Column(Float, nullable=False)
    state = Column(String(32), nullable=False)
    linked_batch_id = Column(String(32), nullable=False)


class QualityBatchRecord(Base):
    __tablename__ = "quality_batches"

    batch_id = Column(String(32), primary_key=True)
    storage_bank_id = Column(String(32), nullable=False)
    remaining_mass_kg = Column(Float, nullable=False)
    measured_purity_pct = Column(Float, nullable=True)
    measured_moisture_ppm = Column(Float, nullable=True)
    predicted_purity_pct = Column(Float, nullable=False)
    predicted_moisture_ppm = Column(Float, nullable=False)
    review_status = Column(String(32), nullable=False)
    release_status = Column(String(32), nullable=False)
    spec_version = Column(String(32), nullable=False)
    authorised_by = Column(String(128), nullable=True)


class LabSampleRecord(Base):
    __tablename__ = "lab_samples"

    sample_id = Column(String(32), primary_key=True)
    batch_id = Column(String(32), ForeignKey("quality_batches.batch_id"), nullable=False)
    timestamp_iso = Column(String(64), nullable=False)
    source_type = Column(String(32), nullable=False)
    purity_pct = Column(Float, nullable=True)
    moisture_ppm = Column(Float, nullable=True)
    oxygen_ppm = Column(Float, nullable=True)
    analyst_name = Column(String(128), nullable=False)
    notes = Column(Text, nullable=False)
    is_original = Column(Boolean, nullable=False, default=True)
    correction_reason = Column(Text, nullable=True)


class DispatchOrderRecord(Base):
    __tablename__ = "dispatch_orders"

    order_id = Column(String(32), primary_key=True)
    customer_name = Column(String(128), nullable=False)
    trailer_registration = Column(String(32), nullable=False)
    requested_mass_kg = Column(Float, nullable=False)
    estimated_loaded_kg = Column(Float, nullable=False, default=0.0)
    confirmed_transfer_kg = Column(Float, nullable=True)
    assigned_batch_id = Column(String(32), nullable=False)
    source_bank_id = Column(String(32), nullable=False)
    stage = Column(String(32), nullable=False)
    delivery_doc_number = Column(String(64), nullable=True)
    hold_reason = Column(Text, nullable=True)


class AuditLogRecord(Base):
    __tablename__ = "audit_log"

    id = Column(Integer, primary_key=True, autoincrement=True)
    idempotency_key = Column(String(128), unique=True, nullable=False)
    actor_role = Column(String(32), nullable=False)
    action = Column(String(64), nullable=False)
    entity_ref = Column(String(64), nullable=False)
    detail = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
