from dataclasses import dataclass, field
from typing import Optional


@dataclass
class SimStorageBank:
    id: str
    name: str
    inventory_kg: float
    max_capacity_kg: float
    operating_min_kg: float
    operating_max_kg: float
    pressure_bar: float
    temperature_c: float
    vessel_volume_m3: float
    linked_batch_id: str
    state: str = "RUNNING"

    @property
    def headroom_kg(self) -> float:
        return max(0.0, self.operating_max_kg - self.inventory_kg)

    @property
    def capacity_normalised_pct(self) -> float:
        return (self.inventory_kg / self.max_capacity_kg * 100.0) if self.max_capacity_kg > 0 else 0.0


@dataclass
class SimQualityBatch:
    batch_id: str
    storage_bank_id: str
    remaining_mass_kg: float
    measured_purity_pct: Optional[float]
    measured_moisture_ppm: Optional[float]
    predicted_purity_pct: float
    predicted_moisture_ppm: float
    review_status: str
    release_status: str
    spec_version: str = "ISO-14687-D-v2.1"
    authorised_by: Optional[str] = None
    samples: list[dict] = field(default_factory=list)


@dataclass
class SimDispatchOrder:
    order_id: str
    customer_name: str
    trailer_registration: str
    requested_mass_kg: float
    estimated_loaded_kg: float
    confirmed_transfer_kg: Optional[float]
    assigned_batch_id: str
    source_bank_id: str
    stage: str
    delivery_doc_number: Optional[str] = None
    hold_reason: Optional[str] = None


class HydrogridSimulator:
    """
    Simplified configurable mass-and-energy hydrogen plant simulator.
    Note: Explicitly NOT a validated electrolyser engineering model.
    """

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self.plant_name = "Aberdeen Green H2 Works — Phase II"
        self.sim_elapsed_seconds = 0
        self.sim_speed = "NORMAL_1X"  # PAUSED, NORMAL_1X, ACCEL_10X, ACCEL_60X
        self.target_power_mw = 20.0
        self.max_capacity_kg_hr = 420.0
        self.plant_sec_kwh_per_kg = 55.5556
        self.water_recovery_pct = 70.0
        self.purification_recovery_pct = 98.2
        self.h2_output_kg_hr = 360.0
        self.produced_today_kg = 8520.0
        self.dispatched_today_kg = 8640.0
        self.h2_losses_today_kg = 156.2
        self.o2_output_today_kg = 68850.0
        self.water_loss_today_l = 32840.0
        self.flow_blocked_reason: Optional[str] = None
        self.equipment_fault_active = False
        self.version = 1
        self.idempotency_keys: set[str] = set()

        self.banks = [
            SimStorageBank("BANK-A", "Bank A • High Pressure", 4800.0, 5500.0, 350.0, 5250.0, 368.0, 18.4, 205.0, "H2-041"),
            SimStorageBank("BANK-B", "Bank B • Buffer & Lab Hold", 4100.0, 5500.0, 350.0, 5250.0, 312.0, 17.9, 205.0, "H2-042"),
            SimStorageBank("BANK-C", "Bank C • Dispatch Reserve", 3500.0, 5500.0, 350.0, 5250.0, 264.0, 17.2, 205.0, "H2-040"),
        ]
        self.batches = {
            "H2-042": SimQualityBatch("H2-042", "BANK-B", 4100.0, None, None, 99.985, 2.4, "SAMPLE_PENDING", "HOLD_FOR_REVIEW"),
            "H2-041": SimQualityBatch("H2-041", "BANK-A", 4800.0, 99.992, 1.8, 99.990, 2.1, "REVIEWED_PASS", "RELEASED", authorised_by="Dr. F. Campbell"),
            "H2-040": SimQualityBatch("H2-040", "BANK-C", 3500.0, 99.989, 2.1, 99.988, 2.2, "REVIEWED_PASS", "RELEASED", authorised_by="Dr. F. Campbell"),
        }
        self.orders = {
            "DSP-904": SimDispatchOrder("DSP-904", "Aberdeen Zero-Emission Bus Depot", "SC24 HYD", 920.0, 540.0, None, "H2-041", "BANK-A", "LOADING"),
            "DSP-905": SimDispatchOrder("DSP-905", "Peterhead Port Mobility Hub", "SC73 H2X", 880.0, 0.0, None, "H2-042", "BANK-B", "CHECKED", hold_reason="Awaiting H2-042 release"),
            "DSP-906": SimDispatchOrder("DSP-906", "Inverness Rail Freight Trial", "SC25 GRN", 1050.0, 0.0, None, "H2-040", "BANK-C", "ARRIVED"),
        }

    def speed_multiplier(self) -> int:
        return {"PAUSED": 0, "NORMAL_1X": 1, "ACCEL_10X": 10, "ACCEL_60X": 60}.get(self.sim_speed, 1)

    @property
    def total_storage_kg(self) -> float:
        return sum(b.inventory_kg for b in self.banks)

    def specific_electricity_kwh_per_kg(self) -> Optional[float]:
        if self.h2_output_kg_hr <= 0.01:
            return None
        return (self.target_power_mw * 1000.0) / self.h2_output_kg_hr

    def step(self, real_seconds: float = 1.0) -> dict:
        mult = self.speed_multiplier()
        if mult <= 0:
            return self.summary()
        dt_seconds = real_seconds * mult
        dt_hours = dt_seconds / 3600.0
        self.sim_elapsed_seconds += int(max(1, dt_seconds))

        available_bank = next((b for b in self.banks if b.headroom_kg > 0.01), None)
        if self.equipment_fault_active:
            self.flow_blocked_reason = "Equipment fault active"
            self.h2_output_kg_hr = 0.0
            return self.summary()
        if available_bank is None:
            self.flow_blocked_reason = "BLOCKED FLOW: Storage banks at operating limit"
            self.h2_output_kg_hr = 0.0
            return self.summary()

        self.flow_blocked_reason = None
        net_rate = min(self.max_capacity_kg_hr, (self.target_power_mw * 1000.0) / max(self.plant_sec_kwh_per_kg, 1.0))
        self.h2_output_kg_hr = net_rate
        pur_rec = max(0.85, min(1.0, self.purification_recovery_pct / 100.0))
        gross_rate = net_rate / pur_rec
        loss_rate = gross_rate - net_rate
        o2_rate = gross_rate * 7.9365
        stoich_water_rate = gross_rate * 8.9365
        wt_rec = max(0.4, min(0.98, self.water_recovery_pct / 100.0))
        feedwater_rate = stoich_water_rate / wt_rec
        water_loss_rate = feedwater_rate * (1.0 - wt_rec)

        produced_kg = net_rate * dt_hours
        remaining = produced_kg
        stored_actual = 0.0
        for bank in self.banks:
            if bank.headroom_kg > 0:
                add = min(remaining, bank.headroom_kg)
                bank.inventory_kg += add
                stored_actual += add
                remaining -= add
                if bank.headroom_kg <= 0.5:
                    bank.state = "BLOCKED"
                if remaining <= 1e-9:
                    break

        self.produced_today_kg += stored_actual
        self.h2_losses_today_kg += loss_rate * dt_hours
        self.o2_output_today_kg += o2_rate * dt_hours
        self.water_loss_today_l += water_loss_rate * dt_hours
        self.version += 1
        return self.summary()

    def register_sample(self, batch_id: str, purity_pct: float, moisture_ppm: float, oxygen_ppm: float, analyst: str) -> SimQualityBatch:
        batch = self.batches[batch_id]
        within_spec = purity_pct >= 99.97 and moisture_ppm <= 5.0 and oxygen_ppm <= 5.0
        is_original = len(batch.samples) == 0
        batch.samples.append({
            "purity_pct": purity_pct,
            "moisture_ppm": moisture_ppm,
            "oxygen_ppm": oxygen_ppm,
            "analyst": analyst,
            "is_original": is_original,
        })
        batch.measured_purity_pct = purity_pct
        batch.measured_moisture_ppm = moisture_ppm
        batch.review_status = "REVIEWED_PASS" if within_spec else "REVIEWED_FAIL"
        if not within_spec:
            batch.release_status = "QUARANTINED"
        # Note: passing threshold never auto-releases
        self.version += 1
        return batch

    def authorise_release(self, batch_id: str, authoriser: str) -> SimQualityBatch:
        batch = self.batches[batch_id]
        if batch.review_status != "REVIEWED_PASS":
            raise ValueError(f"Batch {batch_id} has not passed lab review.")
        batch.release_status = "RELEASED"
        batch.authorised_by = authoriser
        self.version += 1
        return batch

    def reconcile_dispatch(self, order_id: str, confirmed_mass_kg: float) -> SimDispatchOrder:
        order = self.orders[order_id]
        batch = self.batches[order.assigned_batch_id]
        if batch.release_status != "RELEASED":
            order.stage = "HELD"
            order.hold_reason = f"Batch {batch.batch_id} is {batch.release_status}; cannot dispatch held inventory."
            raise ValueError(order.hold_reason)
        bank = next(b for b in self.banks if b.id == order.source_bank_id)
        delta_kg = confirmed_mass_kg - order.estimated_loaded_kg
        if delta_kg > bank.inventory_kg:
            raise ValueError("Insufficient bank inventory for reconciliation.")
        bank.inventory_kg -= delta_kg
        self.dispatched_today_kg += delta_kg
        order.confirmed_transfer_kg = confirmed_mass_kg
        order.stage = "RECONCILED"
        order.delivery_doc_number = f"DN-UK-{order_id[-3:]}-{self.sim_elapsed_seconds % 1000}"
        self.version += 1
        return order

    def sim_time_iso(self) -> str:
        base = 14 * 3600 + 20 * 60 + self.sim_elapsed_seconds
        hrs = (base // 3600) % 24
        mins = (base % 3600) // 60
        secs = base % 60
        return f"2026-11-21 {hrs:02d}:{mins:02d}:{secs:02d} UTC"

    def summary(self) -> dict:
        return {
            "plant_name": self.plant_name,
            "sim_time_iso": self.sim_time_iso(),
            "sim_speed": self.sim_speed,
            "h2_output_kg_hr": round(self.h2_output_kg_hr, 2),
            "electrolyser_power_mw": round(self.target_power_mw if self.h2_output_kg_hr > 0 else 0.0, 2),
            "specific_electricity_kwh_per_kg": round(self.specific_electricity_kwh_per_kg(), 2) if self.specific_electricity_kwh_per_kg() else None,
            "storage_inventory_kg": round(self.total_storage_kg, 2),
            "dispatch_today_kg": round(self.dispatched_today_kg, 2),
            "produced_today_kg": round(self.produced_today_kg, 2),
            "h2_losses_today_kg": round(self.h2_losses_today_kg, 2),
            "o2_output_today_kg": round(self.o2_output_today_kg, 2),
            "water_loss_today_l": round(self.water_loss_today_l, 2),
            "flow_blocked_reason": self.flow_blocked_reason,
            "version": self.version,
        }
