from typing import Optional
from fastapi import Depends, FastAPI, Header, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .auth import UserRole, require_role
from .db import get_db
from .models import AuditLogRecord
from .simulator import HydrogridSimulator

app = FastAPI(
    title="Hydrogrid UK Simulation & Shared Records API",
    version="1.0.0",
    description="Scottish Hydrogen: Production & Storage — Read-only monitoring boundary & process simulation backend."
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

sim = HydrogridSimulator()


class SpeedRequest(BaseModel):
    speed: str  # PAUSED, NORMAL_1X, ACCEL_10X, ACCEL_60X


class StepRequest(BaseModel):
    real_seconds: float = 1.0


class SampleRequest(BaseModel):
    batch_id: str
    purity_pct: float
    moisture_ppm: float
    oxygen_ppm: float
    analyst_name: str


class ReleaseRequest(BaseModel):
    batch_id: str
    authoriser_name: str


class ReconcileRequest(BaseModel):
    order_id: str
    confirmed_mass_kg: float


class ActionRequest(BaseModel):
    action_type: str
    entity_id: str
    payload_json: str
    expected_version: int


@app.get("/api/v1/health")
def health():
    return {
        "status": "ok",
        "plant_name": sim.plant_name,
        "sim_time_iso": sim.sim_time_iso(),
        "version": sim.version,
    }


@app.get("/api/v1/snapshot")
def get_snapshot(role: UserRole = Depends(require_role(set(UserRole)))):
    return sim.summary()


@app.post("/api/v1/sim/speed")
def set_sim_speed(req: SpeedRequest, role: UserRole = Depends(require_role({UserRole.OPERATOR, UserRole.SUPERVISOR, UserRole.ADMIN}))):
    if req.speed not in {"PAUSED", "NORMAL_1X", "ACCEL_10X", "ACCEL_60X"}:
        raise HTTPException(status_code=400, detail="Invalid simulation speed")
    sim.sim_speed = req.speed
    sim.version += 1
    return sim.summary()


@app.post("/api/v1/sim/step")
def step_sim(req: StepRequest, role: UserRole = Depends(require_role(set(UserRole)))):
    return sim.step(req.real_seconds)


@app.post("/api/v1/sim/reset")
def reset_sim(role: UserRole = Depends(require_role({UserRole.OPERATOR, UserRole.SUPERVISOR, UserRole.ADMIN}))):
    sim.reset()
    return sim.summary()


@app.post("/api/v1/quality/samples")
def post_sample(
    req: SampleRequest,
    role: UserRole = Depends(require_role({UserRole.LAB_STAFF, UserRole.SUPERVISOR, UserRole.ADMIN})),
):
    if req.batch_id not in sim.batches:
        raise HTTPException(status_code=404, detail="Batch not found")
    batch = sim.register_sample(req.batch_id, req.purity_pct, req.moisture_ppm, req.oxygen_ppm, req.analyst_name)
    return {"batch_id": batch.batch_id, "review_status": batch.review_status, "release_status": batch.release_status, "version": sim.version}


@app.post("/api/v1/quality/release")
def post_release(
    req: ReleaseRequest,
    role: UserRole = Depends(require_role({UserRole.LAB_STAFF, UserRole.SUPERVISOR, UserRole.ADMIN})),
):
    if req.batch_id not in sim.batches:
        raise HTTPException(status_code=404, detail="Batch not found")
    try:
        batch = sim.authorise_release(req.batch_id, req.authoriser_name)
        return {"batch_id": batch.batch_id, "release_status": batch.release_status, "version": sim.version}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/v1/dispatch/reconcile")
def post_reconcile(
    req: ReconcileRequest,
    role: UserRole = Depends(require_role({UserRole.DISPATCH, UserRole.SUPERVISOR, UserRole.ADMIN})),
):
    if req.order_id not in sim.orders:
        raise HTTPException(status_code=404, detail="Order not found")
    try:
        order = sim.reconcile_dispatch(req.order_id, req.confirmed_mass_kg)
        return {"order_id": order.order_id, "stage": order.stage, "delivery_doc_number": order.delivery_doc_number, "version": sim.version}
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))


@app.post("/api/v1/actions")
def submit_idempotent_action(
    req: ActionRequest,
    idempotency_key: str = Header(..., alias="Idempotency-Key"),
    role: UserRole = Depends(require_role(set(UserRole))),
    db: Session = Depends(get_db),
):
    if idempotency_key in sim.idempotency_keys:
        return {"accepted": True, "version": sim.version, "message": "Idempotent replay accepted"}

    if req.expected_version < sim.version - 25:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Offline version conflict: client expected v{req.expected_version}, server at v{sim.version}",
        )

    sim.idempotency_keys.add(idempotency_key)
    sim.version += 1
    try:
        existing = db.query(AuditLogRecord).filter_by(idempotency_key=idempotency_key).first()
        if not existing:
            db.add(
                AuditLogRecord(
                    idempotency_key=idempotency_key,
                    actor_role=role.value,
                    action=req.action_type,
                    entity_ref=req.entity_id,
                    detail=req.payload_json,
                )
            )
            db.commit()
    except Exception:
        db.rollback()

    return {"accepted": True, "version": sim.version, "message": f"Recorded {req.action_type} for {req.entity_id}"}
