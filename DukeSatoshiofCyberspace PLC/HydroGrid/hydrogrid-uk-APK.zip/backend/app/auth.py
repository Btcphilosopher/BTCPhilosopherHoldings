import os
from enum import Enum
from typing import Optional
from fastapi import Header, HTTPException, status


class UserRole(str, Enum):
    OPERATOR = "OPERATOR"
    SUPERVISOR = "SUPERVISOR"
    LAB_STAFF = "LAB_STAFF"
    DISPATCH = "DISPATCH"
    MAINTENANCE = "MAINTENANCE"
    ADMIN = "ADMIN"


def require_role(allowed_roles: set[UserRole]):
    def dependency(
        x_hydrogrid_role: Optional[str] = Header(default="OPERATOR"),
        authorization: Optional[str] = Header(default=None),
    ) -> UserRole:
        configured_token = os.getenv("HYDROGRID_API_TOKEN", "").strip()
        if configured_token:
            expected = f"Bearer {configured_token}"
            if authorization != expected:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Missing or invalid Bearer token",
                )
        try:
            role = UserRole((x_hydrogrid_role or "OPERATOR").upper())
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Unknown role: {x_hydrogrid_role}",
            )
        if role not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Role {role.value} is not permitted for this operation.",
            )
        return role

    return dependency
