import { ChangeDetectionStrategy, Component, HostListener, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './components/header/header';
import { OverviewComponent } from './components/overview/overview';
import { FlowViewComponent } from './components/flow-view/flow-view';
import { ThermalViewComponent } from './components/thermal-view/thermal-view';
import { StabilityViewComponent } from './components/stability-view/stability-view';
import { CampaignViewComponent } from './components/campaign-view/campaign-view';
import { ValidationViewComponent } from './components/validation-view/validation-view';
import { UncertaintyViewComponent } from './components/uncertainty-view/uncertainty-view';
import { AnomaliesViewComponent } from './components/anomalies-view/anomalies-view';
import { RepoViewComponent } from './components/repo-view/repo-view';
import { ReportViewComponent } from './components/report-view/report-view';
import { DataImporterComponent } from './components/data-importer/data-importer';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    HeaderComponent,
    OverviewComponent,
    FlowViewComponent,
    ThermalViewComponent,
    StabilityViewComponent,
    CampaignViewComponent,
    ValidationViewComponent,
    UncertaintyViewComponent,
    AnomaliesViewComponent,
    RepoViewComponent,
    ReportViewComponent,
    DataImporterComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  public readonly activeTab = signal<string>('overview');

  @HostListener('window:tab-change', ['$event'])
  public onTabChange(event: Event): void {
    const custom = event as CustomEvent<string>;
    if (custom && custom.detail) {
      this.activeTab.set(custom.detail);
    }
  }
}
