/**
 * NEWTON ROCKETS LTD.
 * LH2 INJECTION ENGINE - CRYOGENIC INJECTION TEST / DIGITAL-TWIN MODULE
 * Core Type Definitions and Data Schemas
 */

export type PhaseState =
  | 'SUBCOOLED_LIQUID'
  | 'SATURATED_LIQUID'
  | 'TWO_PHASE'
  | 'SATURATED_VAPOUR'
  | 'SUPERHEATED_VAPOUR'
  | 'SUPERCRITICAL';

export type QualityFlag =
  | 'VALID'
  | 'UNCALIBRATED'
  | 'OUT_OF_RANGE'
  | 'DEGRADED'
  | 'INTERPOLATED'
  | 'SENSOR_FAULT';

export type ParameterClassification =
  | 'THEORETICAL'
  | 'ASSUMED'
  | 'CALIBRATED'
  | 'MEASURED'
  | 'VALIDATED';

export type ValidationLevel = 0 | 1 | 2 | 3 | 4 | 5;

export interface ValidationHierarchyStatus {
  level: ValidationLevel;
  name: string;
  description: string;
  achieved: boolean;
  provenance: string;
  lastVerifiedDate: string;
}

export interface CryogenicFluidState {
  temperature: number; // K
  pressure: number; // bar (or MPa)
  pressureMpa: number; // MPa
  density: number; // kg/m^3
  enthalpy: number; // kJ/kg
  internalEnergy: number; // kJ/kg
  specificHeatCp: number; // kJ/(kg·K)
  specificHeatCv: number; // kJ/(kg·K)
  thermalConductivity: number; // W/(m·K)
  viscosity: number; // Pa·s
  vapourFraction: number; // 0.0 (pure liquid) to 1.0 (pure vapor)
  phaseState: PhaseState;
  saturationTemperature: number; // K at current pressure
  saturationPressure: number; // bar at current temperature
  subcoolingMargin: number; // K = Tsat - T
  speedOfSound: number; // m/s
  // Metrology & Validity
  source: string;
  validityRange: {
    tempMinK: number;
    tempMaxK: number;
    presMinBar: number;
    presMaxBar: number;
  };
  uncertaintyFraction: number; // e.g. 0.0025 (0.25%)
  isExtrapolated: boolean;
  validityFlag: 'VALID' | 'MODEL_OUTSIDE_VALID_RANGE';
}

export interface SensorSignal {
  timestamp: number; // seconds from test start (t=0)
  value: number;
  unit: string;
  sensorId: string;
  calibrationRevision: string;
  uncertainty: number; // absolute 1-sigma uncertainty
  qualityFlag: QualityFlag;
  rawUnfilteredValue?: number;
}

export interface TelemetryFrame {
  timestamp: number; // s
  upstreamPressure: SensorSignal; // bar
  downstreamPressure: SensorSignal; // bar
  fluidTemperature: SensorSignal; // K
  wallTemperature: SensorSignal; // K
  massFlow: SensorSignal; // kg/s
  ambientTemperature: SensorSignal; // K
  opticalTransmission?: SensorSignal; // % (void indicator)
  electricalImpedance?: SensorSignal; // Ohm (liquid presence)
  highSpeedPressureOscillation?: SensorSignal; // bar (filtered dynamic component)
  
  // Model-Derived (must be labeled MODEL-DEPENDENT ESTIMATE when applicable)
  derivedState: {
    density: number; // kg/m3
    massFlux: number; // kg/(m2·s) - MODEL-DEPENDENT ESTIMATE
    enthalpyChange: number; // kJ/kg
    pressureDrop: number; // bar
    phaseState: PhaseState;
    voidFraction: number; // 0 to 1 - MODEL-DEPENDENT ESTIMATE
    flashingCavitationNumber: number; // sigma
    wallHeatFlux: number; // kW/m2 - MODEL-DEPENDENT ESTIMATE
    cooldownRate: number; // K/s
    thermalGradient: number; // K/mm
  };
}

export interface TestArticleMetadata {
  testArticleId: string;
  hardwareRevision: string;
  instrumentationRevision: string;
  numberOfMeasurementLocations: number;
  sensorConfiguration: {
    upstreamPressureSensor: string;
    downstreamPressureSensor: string;
    fluidTempRtd: string;
    wallTempThermocouple: string;
    flowmeterType: string;
    flowmeterSerial: string;
  };
  manifoldMaterial: string;
  nominalLineRatingBar: number;
  dataSourceType: 'EXPERIMENTAL_TEST_ARTICLE' | 'SYNTHETIC_GROUND_TRUTH';
}

export interface TransientMetrics {
  t0: number; // start of valve trigger (s)
  initialState: {
    pressureBar: number;
    temperatureK: number;
    phase: PhaseState;
  };
  transientOnset: number; // s
  peakResponseTime: number; // s
  peakMassFlow: number; // kg/s
  peakPressureOvershootPct: number; // %
  riseTime10To90: number; // s
  settlingTime2Pct: number; // s
  settlingIntervalStart: number; // s
  settlingIntervalEnd: number; // s
  steadyStateMeanFlow: number; // kg/s
  steadyStateFlowStd: number; // kg/s
  steadyStateFlowCV: number; // % (coefficient of variation)
  steadyStatePressureDrop: number; // bar
  shutdownTime: number; // s
  acousticTransitDelayMs: number; // ms
}

export interface StabilityAnalysis {
  sampleRateHz: number;
  windowDurationSec: number;
  dominantFrequencyHz: number;
  secondaryFrequencyHz: number;
  peakAmplitudeBar: number;
  dampingRatio: number;
  frequencyDriftHzPerSec: number;
  spectralData: {
    frequencies: number[]; // Hz (0 to 500)
    psdValues: number[]; // bar^2/Hz
    fftAmplitudes: number[]; // bar
  };
  observedSignalDescription: string;
  engineeringInterpretation: string; // explicitly separated
  instabilityRiskRating: 'LOW' | 'MODERATE' | 'ELEVATED' | 'HIGH';
}

export interface AnomalyEvent {
  id: string;
  timestamp: number; // s
  signal: string;
  magnitude: string;
  durationSec: number;
  detectionMethod: string;
  confidence: number; // 0.0 to 1.0
  severity: 'INFO' | 'CAUTION' | 'WARNING' | 'ANOMALY';
  description: string;
}

export interface UncertaintyMetrics {
  nominal: number;
  p5: number;
  p50: number;
  p95: number;
  stdDev: number;
  expandedUncertainty95: number;
  unit: string;
}

export interface PropulsionTwinComparison {
  timestamp: number;
  measuredMassFlow: number;
  modelPredictedMassFlow: number;
  residualMassFlow: number;
  uncertaintyBand95: number;
  measuredPressureDrop: number;
  modelPredictedPressureDrop: number;
  residualPressureDrop: number;
}

export interface IgnitionCorrelationState {
  testId: string;
  ignitionEventTimeSec: number;
  injectionFluidTemperatureK: number;
  injectionPressureBar: number;
  subcoolingMarginK: number;
  injectedVoidFraction: number;
  firstDetectedResponseTimeSec: number;
  stableResponseTimeSec: number;
  ignitionDelayMs: number;
  initialChamberPressurizationRateBarPerSec: number;
  correlationAssessment: string;
}

export interface ModelCalibrationParameter {
  name: string;
  symbol: string;
  nominalValue: number;
  calibratedValue: number;
  confidenceInterval95: [number, number];
  unit: string;
  classification: ParameterClassification;
  fitR2: number;
  sensitivityIndex: number;
}

export interface TestRun {
  testId: string;
  campaignId: string;
  testDate: string;
  title: string;
  operator: string;
  metadata: TestArticleMetadata;
  validationLevel: ValidationLevel;
  environmentalAmbientK: number;
  targetInletPressureBar: number;
  targetMassFlowKgS: number;
  telemetry: TelemetryFrame[];
  transientMetrics: TransientMetrics;
  stability: StabilityAnalysis;
  anomalies: AnomalyEvent[];
  propulsionComparison: PropulsionTwinComparison[];
  ignitionCorrelation: IgnitionCorrelationState;
  calibratedParameters: ModelCalibrationParameter[];
  overallUncertainty: {
    massFlow: UncertaintyMetrics;
    fluidTemp: UncertaintyMetrics;
    upstreamPressure: UncertaintyMetrics;
    pressureDrop: UncertaintyMetrics;
    density: UncertaintyMetrics;
  };
  provenanceHash: string;
}
