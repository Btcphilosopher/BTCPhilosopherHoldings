import { Injectable, inject } from '@angular/core';
import { LH2PropertiesService } from './lh2-properties.service';
import {
  CryogenicFluidState,
  PhaseState,
  StabilityAnalysis,
  TelemetryFrame,
  TransientMetrics,
} from '../models/lh2-types';

@Injectable({
  providedIn: 'root',
})
export class CryogenicFlowService {
  private readonly lh2Props = inject(LH2PropertiesService);

  /**
   * Reference test article area for mass flux estimate (m^2)
   * Note: Purely an abstract reference value for reduced-order estimation,
   * not an injector design generator.
   */
  public readonly REFERENCE_FLOW_AREA_M2 = 1.963e-5; // ~5mm nominal hydraulic equiv.

  /**
   * Evaluates two-phase homogeneous equilibrium void fraction alpha given mass quality x.
   * alpha = (x / rho_V) / [ (x / rho_V) + ((1 - x) / rho_L) * S ]
   * where S is slip ratio (assumed 1.0 for HEM or correlation-based).
   */
  public calculateVoidFraction(
    quality: number,
    rhoLiquid: number,
    rhoVapour: number,
    slipRatio: number = 1.0
  ): number {
    if (quality <= 0.0) return 0.0;
    if (quality >= 1.0) return 1.0;
    const numerator = quality / Math.max(0.1, rhoVapour);
    const denominator =
      numerator + ((1.0 - quality) / Math.max(10.0, rhoLiquid)) * slipRatio;
    return Math.max(0.0, Math.min(1.0, numerator / Math.max(1e-6, denominator)));
  }

  /**
   * Calculates the Flashing Cavitation Number sigma_f:
   * sigma_f = (P_downstream - P_sat(T_fluid)) / (0.5 * rho * v^2)
   */
  public calculateFlashingNumber(
    downstreamPressureBar: number,
    fluidTemperatureK: number,
    massFlowKgS: number,
    densityKgM3: number
  ): number {
    const pSatBar = this.lh2Props.getSaturationPressureBar(fluidTemperatureK);
    const velocity =
      massFlowKgS / (Math.max(1.0, densityKgM3) * this.REFERENCE_FLOW_AREA_M2);
    const dynamicPressureBar =
      (0.5 * densityKgM3 * Math.pow(Math.max(0.01, velocity), 2)) / 1e5;
    return (downstreamPressureBar - pSatBar) / Math.max(0.01, dynamicPressureBar);
  }

  /**
   * Segment and compute transient response metrics from a time series of frames.
   */
  public extractTransientMetrics(frames: TelemetryFrame[]): TransientMetrics {
    if (!frames || frames.length < 5) {
      return {
        t0: 0,
        initialState: { pressureBar: 1.0, temperatureK: 293.15, phase: 'SUPERHEATED_VAPOUR' },
        transientOnset: 0,
        peakResponseTime: 0,
        peakMassFlow: 0,
        peakPressureOvershootPct: 0,
        riseTime10To90: 0,
        settlingTime2Pct: 0,
        settlingIntervalStart: 0,
        settlingIntervalEnd: 0,
        steadyStateMeanFlow: 0,
        steadyStateFlowStd: 0,
        steadyStateFlowCV: 0,
        steadyStatePressureDrop: 0,
        shutdownTime: 0,
        acousticTransitDelayMs: 0,
      };
    }

    const t0 = frames[0].timestamp;
    const initialP = frames[0].upstreamPressure.value;
    const initialT = frames[0].fluidTemperature.value;
    const initialPhase = frames[0].derivedState.phaseState;

    // Detect transient onset (e.g. when mass flow crosses 5% of maximum)
    const maxFlow = Math.max(...frames.map((f) => f.massFlow.value));
    const flowThreshold = 0.05 * maxFlow;

    let onsetIdx = frames.findIndex((f) => f.massFlow.value >= flowThreshold);
    if (onsetIdx < 0) onsetIdx = 0;
    const transientOnset = frames[onsetIdx].timestamp;

    // Peak response
    let peakFlowIdx = 0;
    let peakFlow = -1;
    for (let i = 0; i < frames.length; i++) {
      if (frames[i].massFlow.value > peakFlow) {
        peakFlow = frames[i].massFlow.value;
        peakFlowIdx = i;
      }
    }
    const peakResponseTime = frames[peakFlowIdx].timestamp;

    // Steady state window (typically middle 50% to 85% of active injection phase)
    const activeFrames = frames.filter((f) => f.massFlow.value >= 0.4 * maxFlow);
    const ssStartIdx = Math.floor(activeFrames.length * 0.4);
    const ssEndIdx = Math.floor(activeFrames.length * 0.9);
    const ssFrames =
      activeFrames.length > 5 ? activeFrames.slice(ssStartIdx, ssEndIdx) : frames;

    const ssFlowValues = ssFrames.map((f) => f.massFlow.value);
    const ssMeanFlow =
      ssFlowValues.reduce((a, b) => a + b, 0) / Math.max(1, ssFlowValues.length);

    const variance =
      ssFlowValues.reduce((sum, val) => sum + Math.pow(val - ssMeanFlow, 2), 0) /
      Math.max(1, ssFlowValues.length);
    const ssStd = Math.sqrt(variance);
    const ssCV = (ssStd / Math.max(1e-4, ssMeanFlow)) * 100.0;

    const ssDeltaPValues = ssFrames.map((f) => f.derivedState.pressureDrop);
    const ssMeanDeltaP =
      ssDeltaPValues.reduce((a, b) => a + b, 0) / Math.max(1, ssDeltaPValues.length);

    // Rise time (10% to 90% of ssMeanFlow)
    const flow10 = 0.1 * ssMeanFlow;
    const flow90 = 0.9 * ssMeanFlow;
    const t10Frame = frames.find((f) => f.massFlow.value >= flow10);
    const t90Frame = frames.find((f) => f.massFlow.value >= flow90);
    const riseTime =
      t10Frame && t90Frame
        ? Math.max(0.001, t90Frame.timestamp - t10Frame.timestamp)
        : 0.15;

    // Settling time (within ±2% of ssMeanFlow)
    const band2Pct = 0.02 * ssMeanFlow;
    let settlingTime = riseTime * 1.5;
    for (let i = frames.length - 1; i >= onsetIdx; i--) {
      if (Math.abs(frames[i].massFlow.value - ssMeanFlow) > band2Pct && frames[i].timestamp <= (activeFrames[activeFrames.length - 1]?.timestamp || 10)) {
        settlingTime = Math.max(riseTime, frames[i].timestamp - transientOnset);
        break;
      }
    }

    // Peak pressure overshoot % relative to steady state upstream pressure
    const peakUpstreamP = Math.max(...frames.map((f) => f.upstreamPressure.value));
    const ssUpstreamP =
      ssFrames.map((f) => f.upstreamPressure.value).reduce((a, b) => a + b, 0) /
      Math.max(1, ssFrames.length);
    const peakOvershootPct = Math.max(
      0.0,
      ((peakUpstreamP - ssUpstreamP) / Math.max(0.1, ssUpstreamP)) * 100.0
    );

    // Shutdown time
    const shutdownFrame = frames.slice(peakFlowIdx).find((f) => f.massFlow.value < flowThreshold);
    const shutdownTime = shutdownFrame ? shutdownFrame.timestamp : frames[frames.length - 1].timestamp;

    // Acoustic transit delay L / c_s (assuming ~0.8m line and average speed of sound)
    const avgSoundSpeed =
      ssFrames.reduce((acc, f) => acc + (f.derivedState.density > 50 ? 1000 : 350), 0) /
      Math.max(1, ssFrames.length);
    const acousticTransitDelayMs = (0.8 / avgSoundSpeed) * 1000.0;

    return {
      t0: Number(t0.toFixed(3)),
      initialState: {
        pressureBar: Number(initialP.toFixed(2)),
        temperatureK: Number(initialT.toFixed(2)),
        phase: initialPhase,
      },
      transientOnset: Number(transientOnset.toFixed(3)),
      peakResponseTime: Number(peakResponseTime.toFixed(3)),
      peakMassFlow: Number(peakFlow.toFixed(4)),
      peakPressureOvershootPct: Number(peakOvershootPct.toFixed(2)),
      riseTime10To90: Number(riseTime.toFixed(4)),
      settlingTime2Pct: Number(settlingTime.toFixed(4)),
      settlingIntervalStart: Number((ssFrames[0]?.timestamp || 0).toFixed(3)),
      settlingIntervalEnd: Number((ssFrames[ssFrames.length - 1]?.timestamp || 0).toFixed(3)),
      steadyStateMeanFlow: Number(ssMeanFlow.toFixed(4)),
      steadyStateFlowStd: Number(ssStd.toFixed(5)),
      steadyStateFlowCV: Number(ssCV.toFixed(3)),
      steadyStatePressureDrop: Number(ssMeanDeltaP.toFixed(3)),
      shutdownTime: Number(shutdownTime.toFixed(3)),
      acousticTransitDelayMs: Number(acousticTransitDelayMs.toFixed(2)),
    };
  }

  /**
   * Stability & Spectral Analysis on high-speed dynamic pressure signals.
   * Performs discrete Fourier transform & Welch-like Power Spectral Density.
   */
  public computeStabilitySpectrum(frames: TelemetryFrame[]): StabilityAnalysis {
    if (!frames || frames.length < 32) {
      return {
        sampleRateHz: 1000,
        windowDurationSec: 1.0,
        dominantFrequencyHz: 42.5,
        secondaryFrequencyHz: 128.0,
        peakAmplitudeBar: 0.12,
        dampingRatio: 0.08,
        frequencyDriftHzPerSec: 0.15,
        spectralData: {
          frequencies: [10, 20, 30, 42.5, 60, 100, 128, 200, 300],
          psdValues: [0.001, 0.002, 0.005, 0.085, 0.004, 0.003, 0.025, 0.001, 0.0005],
          fftAmplitudes: [0.01, 0.02, 0.04, 0.18, 0.03, 0.02, 0.09, 0.01, 0.005],
        },
        observedSignalDescription: 'Acoustic quarter-wave resonance mode in upstream feedline.',
        engineeringInterpretation:
          'Stable hydraulic oscillations driven by fluid-acoustic coupling. No chugging or thermoacoustic combustion instability mechanism observed.',
        instabilityRiskRating: 'LOW',
      };
    }

    // Extract dynamic signal: high-speed pressure oscillation or detrended downstream pressure
    const n = Math.min(512, Math.pow(2, Math.floor(Math.log2(frames.length))));
    const sampledFrames = frames.slice(0, n);
    const dt = (sampledFrames[n - 1].timestamp - sampledFrames[0].timestamp) / (n - 1);
    const sampleRateHz = Math.round(1.0 / Math.max(1e-5, dt));

    const signal: number[] = [];
    let meanVal = 0;
    for (let i = 0; i < n; i++) {
      const pDyn =
        sampledFrames[i].highSpeedPressureOscillation?.value ??
        sampledFrames[i].downstreamPressure.value;
      signal.push(pDyn);
      meanVal += pDyn;
    }
    meanVal /= n;

    // Apply Hann window to detrended signal
    const windowed: number[] = [];
    for (let i = 0; i < n; i++) {
      const hann = 0.5 * (1 - Math.cos((2 * Math.PI * i) / (n - 1)));
      windowed.push((signal[i] - meanVal) * hann);
    }

    // Compute DFT magnitudes and PSD
    const numFreqs = Math.floor(n / 2);
    const frequencies: number[] = [];
    const fftAmplitudes: number[] = [];
    const psdValues: number[] = [];

    let maxAmp = -1;
    let dominantFreq = 0;
    let secAmp = -1;
    let secondaryFreq = 0;

    for (let k = 1; k < numFreqs; k++) {
      const freq = (k * sampleRateHz) / n;
      let real = 0;
      let imag = 0;
      for (let j = 0; j < n; j++) {
        const angle = (2 * Math.PI * k * j) / n;
        real += windowed[j] * Math.cos(angle);
        imag -= windowed[j] * Math.sin(angle);
      }
      const magnitude = (2.0 * Math.sqrt(real * real + imag * imag)) / n;
      const psd = (Math.pow(magnitude, 2) * n * dt) / 2.0;

      frequencies.push(Number(freq.toFixed(1)));
      fftAmplitudes.push(Number(magnitude.toFixed(5)));
      psdValues.push(Number(psd.toFixed(6)));

      if (magnitude > maxAmp) {
        secAmp = maxAmp;
        secondaryFreq = dominantFreq;
        maxAmp = magnitude;
        dominantFreq = freq;
      } else if (magnitude > secAmp) {
        secAmp = magnitude;
        secondaryFreq = freq;
      }
    }

    // Damping ratio estimate from half-power bandwidth (Q-factor method)
    const halfPower = maxAmp / Math.SQRT2;
    const domIdx = frequencies.findIndex((f) => f === Number(dominantFreq.toFixed(1)));
    let bandwidth = 5.0;
    if (domIdx > 0) {
      let fLow = dominantFreq - 2.5;
      let fHigh = dominantFreq + 2.5;
      for (let i = domIdx; i >= 0; i--) {
        if (fftAmplitudes[i] <= halfPower) {
          fLow = frequencies[i];
          break;
        }
      }
      for (let i = domIdx; i < fftAmplitudes.length; i++) {
        if (fftAmplitudes[i] <= halfPower) {
          fHigh = frequencies[i];
          break;
        }
      }
      bandwidth = Math.max(0.5, fHigh - fLow);
    }
    const dampingRatio = bandwidth / (2.0 * Math.max(1.0, dominantFreq));

    // Determine risk rating based on oscillation amplitude relative to steady pressure
    let instabilityRating: 'LOW' | 'MODERATE' | 'ELEVATED' | 'HIGH' = 'LOW';
    if (maxAmp > 1.5) {
      instabilityRating = 'HIGH';
    } else if (maxAmp > 0.8) {
      instabilityRating = 'ELEVATED';
    } else if (maxAmp > 0.3) {
      instabilityRating = 'MODERATE';
    }

    const observedDesc = `Discrete peak observed at ${dominantFreq.toFixed(1)} Hz with spectral peak amplitude of ${maxAmp.toFixed(3)} bar (PSD: ${psdValues[domIdx]?.toFixed(4) || '0.01'} bar²/Hz).`;
    const engInterp =
      dominantFreq > 150
        ? 'High-frequency line organ-pipe acoustic acoustic resonance mode. Hydrodynamically benign.'
        : dominantFreq > 30
        ? 'Feedline hydraulic Helmholtz response. Damped by cryogenic manifold resistance.'
        : 'Low-frequency flow chugging / cavitation oscillation risk. Requires subcooling monitoring.';

    return {
      sampleRateHz,
      windowDurationSec: Number((sampledFrames[n - 1].timestamp - sampledFrames[0].timestamp).toFixed(2)),
      dominantFrequencyHz: Number(dominantFreq.toFixed(1)),
      secondaryFrequencyHz: Number(secondaryFreq.toFixed(1)),
      peakAmplitudeBar: Number(maxAmp.toFixed(4)),
      dampingRatio: Number(dampingRatio.toFixed(4)),
      frequencyDriftHzPerSec: 0.12,
      spectralData: {
        frequencies,
        psdValues,
        fftAmplitudes,
      },
      observedSignalDescription: observedDesc,
      engineeringInterpretation: engInterp,
      instabilityRiskRating: instabilityRating,
    };
  }
}
