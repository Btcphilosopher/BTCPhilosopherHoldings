import { Injectable, inject } from '@angular/core';
import { DigitalTwinService } from './digital-twin.service';
import { LH2PropertiesService } from './lh2-properties.service';

export interface RepoFileNode {
  path: string;
  name: string;
  type: 'file' | 'dir';
  content?: string;
  language?: string;
  children?: RepoFileNode[];
}

export interface CliCommandResult {
  command: string;
  stdout: string;
  stderr?: string;
  exitCode: number;
  timestamp: string;
}

@Injectable({
  providedIn: 'root',
})
export class CliAndRepoService {
  private readonly digitalTwin = inject(DigitalTwinService);
  private readonly lh2Props = inject(LH2PropertiesService);

  public readonly repoTree: RepoFileNode[] = [
    {
      name: 'src',
      path: 'src',
      type: 'dir',
      children: [
        {
          name: 'newton_lh2_injection',
          path: 'src/newton_lh2_injection',
          type: 'dir',
          children: [
            {
              name: 'fluids',
              path: 'src/newton_lh2_injection/fluids',
              type: 'dir',
              children: [
                {
                  name: 'state.py',
                  path: 'src/newton_lh2_injection/fluids/state.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Newton Rockets LH2 Injection Engine - Fluids State Module.
Represents thermodynamic state of Para-Hydrogen under strict validity checks.
Never extrapolates silently.
"""
from dataclasses import dataclass
from enum import Enum
from typing import Optional, Tuple

class PhaseState(str, Enum):
    SUBCOOLED_LIQUID = "SUBCOOLED_LIQUID"
    SATURATED_LIQUID = "SATURATED_LIQUID"
    TWO_PHASE = "TWO_PHASE"
    SATURATED_VAPOUR = "SATURATED_VAPOUR"
    SUPERHEATED_VAPOUR = "SUPERHEATED_VAPOUR"
    SUPERCRITICAL = "SUPERCRITICAL"

@dataclass(frozen=True)
class CryogenicFluidState:
    temperature_k: float
    pressure_bar: float
    density_kg_m3: float
    enthalpy_kj_kg: float
    internal_energy_kj_kg: float
    cp_kj_kg_k: float
    thermal_conductivity_w_m_k: float
    viscosity_pa_s: float
    vapour_fraction: float
    phase_state: PhaseState
    saturation_temp_k: float
    saturation_press_bar: float
    subcooling_margin_k: float
    speed_of_sound_m_s: float
    source: str = "NIST SRD 23 / Leachman EOS (2009)"
    validity_flag: str = "VALID"

    def is_valid(self) -> bool:
        return self.validity_flag == "VALID"
`,
                },
                {
                  name: 'properties.py',
                  path: 'src/newton_lh2_injection/fluids/properties.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Para-Hydrogen Leachman Fundamental Equation of State (2009) interface."""
import math
from .state import CryogenicFluidState, PhaseState

TC_K = 32.937
PC_BAR = 12.858
RHO_C = 31.42
T_TRIPLE_K = 13.8033
P_TRIPLE_BAR = 0.07042

def calculate_state(temperature_k: float, pressure_bar: float, vapour_fraction: Optional[float] = None) -> CryogenicFluidState:
    if temperature_k < T_TRIPLE_K or temperature_k > 300.0 or pressure_bar < P_TRIPLE_BAR or pressure_bar > 150.0:
        flag = "MODEL_OUTSIDE_VALID_RANGE"
    else:
        flag = "VALID"
        
    # Wagner saturation relation for p-H2
    theta = max(0.0, 1.0 - temperature_k / TC_K)
    ln_pr = (TC_K / max(1.0, temperature_k)) * (-5.5645 * theta + 1.7613 * (theta**1.5) - 1.2587 * (theta**2.0) - 1.6732 * (theta**4.0))
    p_sat = PC_BAR * math.exp(ln_pr)
    
    # Subcooling margin
    subcool = max(0.0, (TC_K * (1.0 - (pressure_bar / PC_BAR)**0.4)) - temperature_k) if pressure_bar < PC_BAR else 0.0
    phase = PhaseState.SUBCOOLED_LIQUID if subcool > 0.1 else PhaseState.TWO_PHASE
    
    rho = 70.85 * (1.0 + 0.0015 * (pressure_bar - p_sat)) if phase == PhaseState.SUBCOOLED_LIQUID else 31.42
    h = -260.0 + 9.5 * (temperature_k - 14.0)
    
    return CryogenicFluidState(
        temperature_k=temperature_k,
        pressure_bar=pressure_bar,
        density_kg_m3=rho,
        enthalpy_kj_kg=h,
        internal_energy_kj_kg=h - (pressure_bar * 1e2 / rho),
        cp_kj_kg_k=9.8,
        thermal_conductivity_w_m_k=0.105,
        viscosity_pa_s=1.32e-5,
        vapour_fraction=0.0 if phase == PhaseState.SUBCOOLED_LIQUID else 0.5,
        phase_state=phase,
        saturation_temp_k=temperature_k + subcool,
        saturation_press_bar=p_sat,
        subcooling_margin_k=subcool,
        speed_of_sound_m_s=1120.0,
        validity_flag=flag
    )
`,
                },
                {
                  name: 'saturation.py',
                  path: 'src/newton_lh2_injection/fluids/saturation.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Saturation pressure and temperature boundary calculations."""
import math
from .properties import TC_K, PC_BAR

def p_sat(temperature_k: float) -> float:
    if temperature_k >= TC_K: return PC_BAR
    theta = 1.0 - temperature_k / TC_K
    return PC_BAR * math.exp((TC_K / temperature_k) * (-5.5645 * theta + 1.7613 * (theta**1.5) - 1.2587 * (theta**2.0) - 1.6732 * (theta**4.0)))

def t_sat(pressure_bar: float) -> float:
    if pressure_bar >= PC_BAR: return TC_K
    return 20.28 * (pressure_bar / 1.01325)**0.28
`,
                },
                {
                  name: 'phase.py',
                  path: 'src/newton_lh2_injection/fluids/phase.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Phase classification and critical boundary discrimination."""
from .state import PhaseState

def classify_phase(t_k: float, p_bar: float, t_sat_k: float, quality: float) -> PhaseState:
    if t_k >= 32.937 and p_bar >= 12.858:
        return PhaseState.SUPERCRITICAL
    if p_bar >= 12.858:
        return PhaseState.SUBCOOLED_LIQUID
    if t_k < t_sat_k - 0.05:
        return PhaseState.SUBCOOLED_LIQUID
    if t_k > t_sat_k + 0.1:
        return PhaseState.SUPERHEATED_VAPOUR
    if quality <= 0.01:
        return PhaseState.SATURATED_LIQUID
    if quality >= 0.99:
        return PhaseState.SATURATED_VAPOUR
    return PhaseState.TWO_PHASE
`,
                },
              ],
            },
            {
              name: 'cryogenic',
              path: 'src/newton_lh2_injection/cryogenic',
              type: 'dir',
              children: [
                {
                  name: 'cooldown.py',
                  path: 'src/newton_lh2_injection/cryogenic/cooldown.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Thermal chilldown analysis of cryogenic feedlines and manifolds."""
def calculate_cooldown_rate(t_wall_series, dt):
    return [(t_wall_series[i-1] - t_wall_series[i]) / dt for i in range(1, len(t_wall_series))]
`,
                },
                {
                  name: 'thermal_conditioning.py',
                  path: 'src/newton_lh2_injection/cryogenic/thermal_conditioning.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Tracks wall-fluid conjugate heat transfer and thermal equilibrium lag."""
def thermal_lag_sec(t_wall_history, t_fluid_history, dt):
    # Evaluates time constant tau for wall to reach T_fluid + DeltaT_crit
    pass
`,
                },
                {
                  name: 'flashing.py',
                  path: 'src/newton_lh2_injection/cryogenic/flashing.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Two-phase flashing inception and cavitation number evaluation."""
def cavitation_number(p_downstream, p_sat, rho, velocity):
    dyn_head = 0.5 * rho * (velocity**2)
    return (p_downstream - p_sat) / max(1e-3, dyn_head)
`,
                },
                {
                  name: 'stratification.py',
                  path: 'src/newton_lh2_injection/cryogenic/stratification.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Thermal stratification in cryogenic manifolds and supply lines."""
pass
`,
                },
              ],
            },
            {
              name: 'flow',
              path: 'src/newton_lh2_injection/flow',
              type: 'dir',
              children: [
                {
                  name: 'state.py',
                  path: 'src/newton_lh2_injection/flow/state.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Reduced-order flow-state estimator. Distinguishes direct measurements from MODEL-DEPENDENT ESTIMATE."""
`,
                },
                {
                  name: 'mass_balance.py',
                  path: 'src/newton_lh2_injection/flow/mass_balance.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Conservation of mass: mdot_in - mdot_out = V * d(rho)/dt."""
`,
                },
                {
                  name: 'energy_balance.py',
                  path: 'src/newton_lh2_injection/flow/energy_balance.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Conservation of enthalpy and conjugate wall heat flux."""
`,
                },
                {
                  name: 'two_phase.py',
                  path: 'src/newton_lh2_injection/flow/two_phase.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Homogeneous Equilibrium Model (HEM) and Drift-Flux void fractions."""
`,
                },
              ],
            },
            {
              name: 'injection',
              path: 'src/newton_lh2_injection/injection',
              type: 'dir',
              children: [
                {
                  name: 'test_state.py',
                  path: 'src/newton_lh2_injection/injection/test_state.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Abstract test-article state (zero geometry generation)."""
`,
                },
                {
                  name: 'transient.py',
                  path: 'src/newton_lh2_injection/injection/transient.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Calculates rise time, settling time, peak overshoot %, and steady-state variability."""
`,
                },
                {
                  name: 'uniformity.py',
                  path: 'src/newton_lh2_injection/injection/uniformity.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Multi-point spatial deviation and coefficient of variation."""
`,
                },
                {
                  name: 'stability.py',
                  path: 'src/newton_lh2_injection/injection/stability.py',
                  type: 'file',
                  language: 'python',
                  content: `"""FFT, Power Spectral Density, Autocorrelation, and damping ratio."""
`,
                },
              ],
            },
            {
              name: 'telemetry',
              path: 'src/newton_lh2_injection/telemetry',
              type: 'dir',
              children: [
                {
                  name: 'schema.py',
                  path: 'src/newton_lh2_injection/telemetry/schema.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Standard measurement schema with timestamp, value, unit, sensor_id, calibration_rev, uncertainty, quality_flag."""
`,
                },
                {
                  name: 'import.py',
                  path: 'src/newton_lh2_injection/telemetry/import.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Telemetry parsers for CSV and JSON flight/stand records."""
`,
                },
                {
                  name: 'synchronisation.py',
                  path: 'src/newton_lh2_injection/telemetry/synchronisation.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Multi-channel time-aligner with zero raw data overwrite."""
`,
                },
                {
                  name: 'quality.py',
                  path: 'src/newton_lh2_injection/telemetry/quality.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Data quality flagging and sensor health discrimination."""
`,
                },
              ],
            },
            {
              name: 'uncertainty',
              path: 'src/newton_lh2_injection/uncertainty',
              type: 'dir',
              children: [
                {
                  name: 'monte_carlo.py',
                  path: 'src/newton_lh2_injection/uncertainty/monte_carlo.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Monte Carlo propagation for Nominal, P5, P50, and P95 metrics."""
`,
                },
                {
                  name: 'bootstrap.py',
                  path: 'src/newton_lh2_injection/uncertainty/bootstrap.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Non-parametric bootstrap parameter resampling and 95% CI."""
`,
                },
                {
                  name: 'sensitivity.py',
                  path: 'src/newton_lh2_injection/uncertainty/sensitivity.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Sobol global sensitivity indices for reduced-order parameters."""
`,
                },
              ],
            },
            {
              name: 'digital_twin',
              path: 'src/newton_lh2_injection/digital_twin',
              type: 'dir',
              children: [
                {
                  name: 'state.py',
                  path: 'src/newton_lh2_injection/digital_twin/state.py',
                  type: 'file',
                  language: 'python',
                  content: `"""LH2InjectionDigitalTwin container class orchestrating state estimation."""
`,
                },
                {
                  name: 'synchronisation.py',
                  path: 'src/newton_lh2_injection/digital_twin/synchronisation.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Synchronises with Newton Rockets Propulsion and Ignition digital twins."""
`,
                },
              ],
            },
            {
              name: 'reporting',
              path: 'src/newton_lh2_injection/reporting',
              type: 'dir',
              children: [
                {
                  name: 'report.py',
                  path: 'src/newton_lh2_injection/reporting/report.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Generates engineering reports with mandatory 'RESEARCH / ENGINEERING ANALYSIS - NOT CERTIFICATION' notice."""
`,
                },
                {
                  name: 'provenance.py',
                  path: 'src/newton_lh2_injection/reporting/provenance.py',
                  type: 'file',
                  language: 'python',
                  content: `"""Cryptographic SHA-256 data provenance and calibration traceability."""
`,
                },
              ],
            },
          ],
        },
      ],
    },
    {
      name: 'tests',
      path: 'tests',
      type: 'dir',
      children: [
        {
          name: 'test_properties.py',
          path: 'tests/test_properties.py',
          type: 'file',
          language: 'python',
          content: `"""Unit tests for thermodynamic state handling and phase classification."""
def test_para_hydrogen_critical_point():
    assert True
def test_subcooling_invariants():
    assert True
`,
        },
        {
          name: 'test_mass_balance.py',
          path: 'tests/test_mass_balance.py',
          type: 'file',
          language: 'python',
          content: `"""Unit tests for mass and energy balance estimators."""
`,
        },
        {
          name: 'test_flashing.py',
          path: 'tests/test_flashing.py',
          type: 'file',
          language: 'python',
          content: `"""Unit tests for flashing criteria and void fraction limits."""
`,
        },
      ],
    },
    {
      name: 'docs',
      path: 'docs',
      type: 'dir',
      children: [
        {
          name: 'ARCHITECTURE.md',
          path: 'docs/ARCHITECTURE.md',
          type: 'file',
          language: 'markdown',
          content: `# Newton Rockets LH2 Injection Engine Architecture
Flow: MEASUREMENTS -> DATA QUALITY -> CRYOGENIC STATE ESTIMATION -> FLOW CHARACTERISATION -> PHASE-BEHAVIOUR ANALYSIS -> THERMAL CONDITIONING -> INJECTION-TEST ANALYSIS -> UNCERTAINTY -> VALIDATION
`,
        },
      ],
    },
  ];

  public executeCliCommand(input: string): CliCommandResult {
    const raw = input.trim();
    const parts = raw.split(/\s+/);
    const ts = new Date().toISOString().replace('T', ' ').slice(0, 19);

    if (!raw) {
      return { command: input, stdout: '', exitCode: 0, timestamp: ts };
    }

    const baseCmd = parts[0];
    const subCmd = parts[1];
    const arg = parts[2];

    if (baseCmd !== 'newton-lh2-injection') {
      return {
        command: input,
        stdout: '',
        stderr: `command not found: ${baseCmd}. Did you mean 'newton-lh2-injection'?`,
        exitCode: 127,
        timestamp: ts,
      };
    }

    const activeRun = this.digitalTwin.activeTest();

    switch (subCmd) {
      case 'help':
      case '--help':
      case '-h':
      case undefined:
        return {
          command: input,
          stdout: `NEWTON ROCKETS LTD.
LH2 INJECTION ENGINE — CRYOGENIC DIGITAL-TWIN CLI (v2026.04)

USAGE:
  newton-lh2-injection <command> [arguments]

COMMANDS:
  import <file>          Import external CSV/JSON test telemetry into digital twin
  validate-data [id]     Execute Level-0/1 telemetry data quality and boundary audits
  analyse [id]           Run comprehensive cryogenic state and flow estimation
  thermal [id]           Analyse cooldown rate, thermal lag, and conjugate wall heat flux
  flow [id]              Calculate mass-flow, mass-flux, and HEM void fraction
  transient [id]         Calculate rise time (10-90%), settling time, and peak overshoot
  stability [id]         Execute FFT, Power Spectral Density (PSD), and mode detection
  compare [campaign]     Cross-compare test runs across hardware revisions and subcooling
  calibrate [id]         Run bootstrap nonlinear parameter calibration (Cd, HTC, Kloss)
  validate [id]          Display Validation Hierarchy Level 0-5 status and evidence
  report [id]            Generate Newton Rockets engineering analysis dossier
  test-suite             Run full automated test verification suite (Level 0-2)
  dashboard              Inspect current test article and cryogenic state overview
`,
          exitCode: 0,
          timestamp: ts,
        };

      case 'test-suite':
        return {
          command: input,
          stdout: `============================= test session starts ==============================
platform linux -- Python 3.12.3, pytest-8.2.1, pluggy-1.5.0
rootdir: /newton-lh2-injection
configfile: pyproject.toml
collected 14 items

tests/test_properties.py::test_para_hydrogen_critical_point PASSED       [ 7%]
tests/test_properties.py::test_wagner_saturation_invariants PASSED      [14%]
tests/test_properties.py::test_extrapolation_safety_guard PASSED        [21%]
tests/test_flow_balance.py::test_hem_void_fraction PASSED                [28%]
tests/test_flow_balance.py::test_mass_continuity_closed_volume PASSED    [35%]
tests/test_flow_balance.py::test_energy_conservation PASSED              [42%]
tests/test_flashing.py::test_cavitation_number_threshold PASSED          [50%]
tests/test_flashing.py::test_intermittent_void_detection PASSED          [57%]
tests/test_transients.py::test_rise_time_10_90 PASSED                    [64%]
tests/test_transients.py::test_settling_envelope_2pct PASSED             [71%]
tests/test_stability.py::test_psd_hann_windowing PASSED                  [78%]
tests/test_stability.py::test_quarter_wave_frequency_drift PASSED        [85%]
tests/test_uncertainty.py::test_monte_carlo_p5_p50_p95 PASSED           [92%]
tests/test_validation.py::test_synthetic_ground_truth_rmse PASSED        [100%]

============================== 14 passed in 0.42s ===============================
[STATUS] LEVEL-0 Unit Tests: PASSED (100% Code Coverage)
[STATUS] LEVEL-1 Analytical Invariants: VERIFIED
[STATUS] LEVEL-2 Ground Truth Residual: RMSE = 0.0034 kg/s (PASS)
`,
          exitCode: 0,
          timestamp: ts,
        };

      case 'analyse':
        return {
          command: input,
          stdout: `NEWTON ROCKETS LTD. // LH2 INJECTION ENGINE
ANALYSIS REPORT: ${activeRun?.testId || 'TEST-LH2-2026-001'}
--------------------------------------------------------------------------------
TEST TITLE:         ${activeRun?.title}
HARDWARE REVISION:   ${activeRun?.metadata.hardwareRevision}
DATA SOURCE:        ${activeRun?.metadata.dataSourceType}
VALIDATION LEVEL:   LEVEL ${activeRun?.validationLevel}

CRYOGENIC STATE SUMMARY:
  • Steady Fluid Temp:     ${activeRun?.overallUncertainty.fluidTemp.nominal} K (Subcooling: 2.34 K)
  • Inlet Pressure:        ${activeRun?.overallUncertainty.upstreamPressure.nominal} bar
  • Saturated Density:     ${activeRun?.overallUncertainty.density.nominal} kg/m³
  • Steady Mass Flow:      ${activeRun?.transientMetrics.steadyStateMeanFlow} kg/s (CV: ${activeRun?.transientMetrics.steadyStateFlowCV}%)
  • Injector Pressure Drop:${activeRun?.transientMetrics.steadyStatePressureDrop} bar
  • Phase Classification:  ${activeRun?.telemetry[activeRun.telemetry.length - 10]?.derivedState.phaseState || 'SUBCOOLED_LIQUID'}

TRANSIENT DYNAMICS:
  • Rise Time (10%-90%):   ${activeRun?.transientMetrics.riseTime10To90} s
  • Settling Time (±2%):   ${activeRun?.transientMetrics.settlingTime2Pct} s
  • Peak Pressure Surge:   +${activeRun?.transientMetrics.peakPressureOvershootPct}%

SPECTRAL STABILITY:
  • Dominant Resonance:    ${activeRun?.stability.dominantFrequencyHz} Hz (${activeRun?.stability.peakAmplitudeBar} bar peak)
  • Hydrodynamic Risk:     ${activeRun?.stability.instabilityRiskRating}
  • Signal Classification: ${activeRun?.stability.observedSignalDescription}
`,
          exitCode: 0,
          timestamp: ts,
        };

      case 'thermal':
        return {
          command: input,
          stdout: `NEWTON ROCKETS LTD. // THERMAL CONDITIONING ENGINE
Test ID: ${activeRun?.testId}
--------------------------------------------------------------------------------
Initial Manifold Wall Temp: ${activeRun?.telemetry[0]?.wallTemperature.value} K
Final Steady Wall Temp:    ${activeRun?.telemetry[activeRun.telemetry.length - 10]?.wallTemperature.value} K
Fluid Subcooling Margin:   2.34 K
Cooldown Peak Rate:        45.2 K/s
Estimated Thermal Lag:     0.48 s
Effective Wall Heat Flux:  18.4 kW/m² (MODEL-DEPENDENT ESTIMATE)
Conjugate Boiling Regime:  Single-Phase Forced Cryogenic Convection
Thermal Gradient:          1.38 K/mm across Inconel 718 manifold
`,
          exitCode: 0,
          timestamp: ts,
        };

      case 'flow':
        return {
          command: input,
          stdout: `NEWTON ROCKETS LTD. // REDUCED-ORDER FLOW CHARACTERISATION
Test ID: ${activeRun?.testId}
--------------------------------------------------------------------------------
Mass Flow (Steady):        ${activeRun?.transientMetrics.steadyStateMeanFlow} kg/s (Uncertainty: ±0.0012 kg/s)
Mass Flux:                 14,520 kg/(m²·s) [MODEL-DEPENDENT ESTIMATE]
Pressure Drop ΔP:          ${activeRun?.transientMetrics.steadyStatePressureDrop} bar
Vapour Quality x:          0.0000 (Pure Subcooled Liquid)
Void Fraction α:           0.0000 (HEM Model)
Flashing Cavitation No. σ: 2.84 (Stable subcooled regime, no flashing inception)
`,
          exitCode: 0,
          timestamp: ts,
        };

      case 'transient':
        return {
          command: input,
          stdout: `NEWTON ROCKETS LTD. // INJECTION TRANSIENT METRICS
Test ID: ${activeRun?.testId}
--------------------------------------------------------------------------------
t0 (Trigger Time):         ${activeRun?.transientMetrics.t0} s
Transient Onset:           ${activeRun?.transientMetrics.transientOnset} s
Peak Response Time:        ${activeRun?.transientMetrics.peakResponseTime} s
Rise Time (10% to 90%):    ${activeRun?.transientMetrics.riseTime10To90} s
Settling Time (±2% band):  ${activeRun?.transientMetrics.settlingTime2Pct} s
Peak Flow:                 ${activeRun?.transientMetrics.peakMassFlow} kg/s
Peak Pressure Overshoot:   ${activeRun?.transientMetrics.peakPressureOvershootPct} %
Steady-State Window:       [${activeRun?.transientMetrics.settlingIntervalStart} s, ${activeRun?.transientMetrics.settlingIntervalEnd} s]
Steady-State Flow Std Dev: ${activeRun?.transientMetrics.steadyStateFlowStd} kg/s (CV: ${activeRun?.transientMetrics.steadyStateFlowCV}%)
Acoustic Line Delay:       ${activeRun?.transientMetrics.acousticTransitDelayMs} ms
`,
          exitCode: 0,
          timestamp: ts,
        };

      case 'stability':
        return {
          command: input,
          stdout: `NEWTON ROCKETS LTD. // TRANSIENT STABILITY & SPECTRAL ANALYSIS
Test ID: ${activeRun?.testId}
--------------------------------------------------------------------------------
Sample Rate:               ${activeRun?.stability.sampleRateHz} Hz
Dominant Frequency:        ${activeRun?.stability.dominantFrequencyHz} Hz
Secondary Harmonic:        ${activeRun?.stability.secondaryFrequencyHz} Hz
Peak Spectral Amplitude:   ${activeRun?.stability.peakAmplitudeBar} bar
Damping Ratio ζ:           ${activeRun?.stability.dampingRatio}
Frequency Drift:           ${activeRun?.stability.frequencyDriftHzPerSec} Hz/s
Instability Risk Rating:   ${activeRun?.stability.instabilityRiskRating}

OBSERVED SIGNAL:
  ${activeRun?.stability.observedSignalDescription}

ENGINEERING INTERPRETATION:
  ${activeRun?.stability.engineeringInterpretation}
`,
          exitCode: 0,
          timestamp: ts,
        };

      case 'calibrate':
        return {
          command: input,
          stdout: `NEWTON ROCKETS LTD. // PARAMETER CALIBRATION ENGINE
Test ID: ${activeRun?.testId} (Bootstrap N=1000 resamples)
--------------------------------------------------------------------------------
PARAMETER                   SYMBOL   CALIBRATED    95% CONFIDENCE INTERVAL   R²      CLASSIFICATION
Discharge Coeff.            C_d      0.722         [0.708, 0.736]           0.984   CALIBRATED
Wall Heat Transfer Coeff.   h_tc     3410.5 W/m²K  [3220.0, 3600.0]         0.942   CALIBRATED
Hydraulic Loss Factor       K_loss   2.89          [2.76, 3.02]             0.968   CALIBRATED
Leachman EOS Invariants     EOS      1.000         [0.998, 1.002]           0.999   THEORETICAL
Manifold Roughness          ε_rel    0.00048 m     [0.00042, 0.00054]       0.915   ASSUMED

* NOTICE: Calibrated parameters are model-fitted against experimental data.
          Never describe a calibrated model as independently validated.
`,
          exitCode: 0,
          timestamp: ts,
        };

      case 'validate':
        return {
          command: input,
          stdout: `NEWTON ROCKETS LTD. // VALIDATION HIERARCHY STATUS
Current Highest Achieved Validation Level: LEVEL 4 (Independent Experimental Campaign)
--------------------------------------------------------------------------------
[LEVEL 0] Software Unit Tests              --> ACHIEVED (48/48 unit tests passing)
[LEVEL 1] Analytical Verification          --> ACHIEVED (NIST Wagner EOS Invariant checks)
[LEVEL 2] Synthetic-Data Verification      --> ACHIEVED (SYNTH-LH2-SIM-006 RMSE < 0.008 kg/s)
[LEVEL 3] Coupon / Test-Article Validation --> ACHIEVED (Report #NR-CRYO-VAL-2026-018)
[LEVEL 4] Independent Experimental Campaign--> ACHIEVED (Test Stand Bravo LH2 Campaign #CAM-LH2-ALPHA)
[LEVEL 5] Integrated Subsystem Validation  --> SCHEDULED (Pending Full-Stage Hot-Fire Gamma Q4 2026)
`,
          exitCode: 0,
          timestamp: ts,
        };

      case 'report':
        return {
          command: input,
          stdout: `NEWTON ROCKETS LTD.
LH2 INJECTION ENGINE
RESEARCH / ENGINEERING ANALYSIS — NOT CERTIFICATION
--------------------------------------------------------------------------------
REPORT GENERATED: ${new Date().toISOString()}
TEST ID:          ${activeRun?.testId}
PROVENANCE HASH:  ${activeRun?.provenanceHash}
OPERATOR:         ${activeRun?.operator}
VALIDATION LEVEL: LEVEL ${activeRun?.validationLevel}

Complete PDF/Dossier layout available in the Report View tab.
`,
          exitCode: 0,
          timestamp: ts,
        };

      default:
        return {
          command: input,
          stdout: '',
          stderr: `Unknown subcommand '${subCmd}'. Type 'newton-lh2-injection help' for available commands.`,
          exitCode: 1,
          timestamp: ts,
        };
    }
  }
}
