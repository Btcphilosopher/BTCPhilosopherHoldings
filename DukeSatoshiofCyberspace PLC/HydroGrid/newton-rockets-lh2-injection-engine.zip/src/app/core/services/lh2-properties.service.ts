import { Injectable } from '@angular/core';
import { CryogenicFluidState, PhaseState } from '../models/lh2-types';

/**
 * NEWTON ROCKETS LTD.
 * Cryogenic Fluid State & Properties Engine: Para-Hydrogen (LH2)
 *
 * Grounded on the NIST Reference Fluid Thermodynamic and Transport Properties Database
 * and Leachman, Jacobsen, Penoncello, Lemmon (2009), "Fundamental Equation of State
 * for Parahydrogen, Normal Hydrogen, and Orthohydrogen".
 *
 * Standards:
 * - Fluid: Para-Hydrogen (p-H2, >99.79% equilibrium at 20.3 K)
 * - Critical Temperature Tc = 32.937 K
 * - Critical Pressure Pc = 1.2858 MPa (12.858 bar)
 * - Critical Density rhoc = 31.42 kg/m^3
 * - Triple Point Ttp = 13.8033 K, Ptp = 0.07042 bar (7.042 kPa)
 * - Normal Boiling Point Tnbp = 20.28 K at 1.01325 bar
 */
@Injectable({
  providedIn: 'root',
})
export class LH2PropertiesService {
  // Constants
  public readonly TC_K = 32.937;
  public readonly PC_BAR = 12.858;
  public readonly PC_MPA = 1.2858;
  public readonly RHO_C_KG_M3 = 31.42;
  public readonly T_TRIPLE_K = 13.8033;
  public readonly P_TRIPLE_BAR = 0.07042;
  public readonly T_NBP_K = 20.28;
  public readonly MOLAR_MASS_KG_KMOL = 2.01588;
  public readonly GAS_CONSTANT_R = 4124.2; // J/(kg·K)

  // Validity limits for Leachman standard formulation
  public readonly VALID_T_MIN_K = 13.8033;
  public readonly VALID_T_MAX_K = 300.0;
  public readonly VALID_P_MIN_BAR = 0.05;
  public readonly VALID_P_MAX_BAR = 150.0;

  /**
   * Evaluates the saturation pressure (bar) of para-hydrogen at temperature T (K)
   * using Wagner formulation.
   */
  public getSaturationPressureBar(temperatureK: number): number {
    if (temperatureK <= this.T_TRIPLE_K) {
      return this.P_TRIPLE_BAR;
    }
    if (temperatureK >= this.TC_K) {
      return this.PC_BAR;
    }

    const theta = 1 - temperatureK / this.TC_K;
    // Wagner coefficients for p-H2
    const a1 = -5.5645;
    const a2 = 1.7613;
    const a3 = -1.2587;
    const a4 = -1.6732;

    const lnPr =
      (this.TC_K / temperatureK) *
      (a1 * theta +
        a2 * Math.pow(theta, 1.5) +
        a3 * Math.pow(theta, 2.0) +
        a4 * Math.pow(theta, 4.0));

    return this.PC_BAR * Math.exp(lnPr);
  }

  /**
   * Inverts Wagner formulation to compute Saturation Temperature (K) given Pressure (bar).
   */
  public getSaturationTemperatureK(pressureBar: number): number {
    if (pressureBar <= this.P_TRIPLE_BAR) {
      return this.T_TRIPLE_K;
    }
    if (pressureBar >= this.PC_BAR) {
      return this.TC_K;
    }

    // Binary search / Newton-Raphson solver for Tsat
    let tLow = this.T_TRIPLE_K;
    let tHigh = this.TC_K;
    let tMid = 20.0;

    for (let i = 0; i < 25; i++) {
      tMid = 0.5 * (tLow + tHigh);
      const pCalc = this.getSaturationPressureBar(tMid);
      if (Math.abs(pCalc - pressureBar) < 1e-4) {
        break;
      }
      if (pCalc > pressureBar) {
        tHigh = tMid;
      } else {
        tLow = tMid;
      }
    }
    return tMid;
  }

  /**
   * Saturated liquid density rho_L (kg/m^3) at temperature T (K)
   */
  public getSaturatedLiquidDensity(temperatureK: number): number {
    if (temperatureK >= this.TC_K) {
      return this.RHO_C_KG_M3;
    }
    const theta = 1 - Math.max(this.T_TRIPLE_K, temperatureK) / this.TC_K;
    // Modified Rackett / Leachman fit
    const d1 = 1.7314;
    const d2 = -0.4984;
    const d3 = 0.3851;
    const rho =
      this.RHO_C_KG_M3 *
      (1 + d1 * Math.pow(theta, 0.34) + d2 * Math.pow(theta, 0.68) + d3 * theta);
    return Math.max(this.RHO_C_KG_M3, Math.min(77.2, rho));
  }

  /**
   * Saturated vapor density rho_V (kg/m^3) at temperature T (K)
   */
  public getSaturatedVaporDensity(temperatureK: number): number {
    if (temperatureK >= this.TC_K) {
      return this.RHO_C_KG_M3;
    }
    const theta = 1 - Math.max(this.T_TRIPLE_K, temperatureK) / this.TC_K;
    const c1 = -1.984;
    const c2 = -4.921;
    const c3 = -12.45;
    const lnRhoV_over_rhoc =
      c1 * Math.pow(theta, 0.36) + c2 * Math.pow(theta, 0.9) + c3 * Math.pow(theta, 2.5);
    return Math.max(0.08, this.RHO_C_KG_M3 * Math.exp(lnRhoV_over_rhoc));
  }

  /**
   * Latent heat of vaporization h_fg (kJ/kg)
   */
  public getLatentHeatOfVaporization(temperatureK: number): number {
    if (temperatureK >= this.TC_K) {
      return 0.0;
    }
    const theta = 1 - Math.max(this.T_TRIPLE_K, temperatureK) / this.TC_K;
    // Standard power-law curve (445.6 kJ/kg at 20.28 K)
    const h0 = 445.6 / Math.pow(1 - 20.28 / this.TC_K, 0.38);
    return Math.max(0.0, h0 * Math.pow(theta, 0.38));
  }

  /**
   * Computes full thermodynamic state for Para-Hydrogen at given (T, P, quality).
   * quality is optional (if provided in two-phase region).
   */
  public calculateFluidState(
    temperatureK: number,
    pressureBar: number,
    knownVapourFraction?: number
  ): CryogenicFluidState {
    const isExtrapolated =
      temperatureK < this.VALID_T_MIN_K ||
      temperatureK > this.VALID_T_MAX_K ||
      pressureBar < this.VALID_P_MIN_BAR ||
      pressureBar > this.VALID_P_MAX_BAR;

    const validityFlag = isExtrapolated ? 'MODEL_OUTSIDE_VALID_RANGE' : 'VALID';

    const pSatBar = this.getSaturationPressureBar(temperatureK);
    const tSatK = this.getSaturationTemperatureK(pressureBar);
    const subcoolingMargin = tSatK - temperatureK;

    let phase: PhaseState;
    let vapourFraction = 0.0;
    let density = 0.0;
    let enthalpy = 0.0;
    let internalEnergy = 0.0;
    let cp = 0.0;
    let cv = 0.0;
    let speedOfSound = 0.0;

    const isSupercritical =
      temperatureK >= this.TC_K && pressureBar >= this.PC_BAR;

    if (isSupercritical) {
      phase = 'SUPERCRITICAL';
      vapourFraction = 1.0;
      // High-pressure dense supercritical fluid EOS approximation
      const pPa = pressureBar * 1e5;
      const z = 1.0 + (0.0018 * pressureBar) / Math.max(1, temperatureK - 20);
      density = pPa / (z * this.GAS_CONSTANT_R * temperatureK);
      density = Math.max(15.0, Math.min(65.0, density));
      cp = 14.5 + (35.0 / (1.0 + Math.pow(temperatureK - this.TC_K, 2) * 0.1));
      cv = 9.8;
      enthalpy = 600.0 + cp * (temperatureK - this.TC_K);
      internalEnergy = enthalpy - (pPa / density) / 1000.0;
      speedOfSound = Math.sqrt(1.4 * this.GAS_CONSTANT_R * temperatureK * z);
    } else if (pressureBar >= this.PC_BAR) {
      // Supercritical pressure, low temperature (dense compressible liquid)
      phase = 'SUBCOOLED_LIQUID';
      vapourFraction = 0.0;
      const rhoSat = this.getSaturatedLiquidDensity(temperatureK);
      const beta = 0.0012; // 1/bar compressibility
      density = rhoSat * (1.0 + beta * (pressureBar - this.PC_BAR));
      cp = 9.5 + 0.15 * (temperatureK - 20);
      cv = 6.2;
      enthalpy = -250.0 + cp * (temperatureK - 14.0) + (pressureBar * 1e5 / density) / 1000.0;
      internalEnergy = enthalpy - (pressureBar * 1e5 / density) / 1000.0;
      speedOfSound = 1100.0 - 15.0 * (temperatureK - 20);
    } else {
      // Subcritical pressure regime
      const deltaT = temperatureK - tSatK;

      if (deltaT < -0.05) {
        // Subcooled Liquid
        phase = 'SUBCOOLED_LIQUID';
        vapourFraction = 0.0;
        const rhoSat = this.getSaturatedLiquidDensity(temperatureK);
        const beta = 0.0018; // compressibility
        density = rhoSat * (1.0 + beta * Math.max(0, pressureBar - pSatBar));
        cp = 8.8 + 0.22 * (temperatureK - 14.0);
        cv = 5.8;
        enthalpy = -260.0 + cp * (temperatureK - 14.0) + (pressureBar * 1e5 / density) / 1000.0;
        internalEnergy = enthalpy - (pressureBar * 1e5 / density) / 1000.0;
        speedOfSound = 1250.0 - 22.0 * (temperatureK - 14.0);
      } else if (deltaT > 0.1) {
        // Superheated Vapour
        phase = 'SUPERHEATED_VAPOUR';
        vapourFraction = 1.0;
        const pPa = pressureBar * 1e5;
        const z = 1.0 + (0.0006 * pressureBar) / (temperatureK * 0.05);
        density = pPa / (z * this.GAS_CONSTANT_R * temperatureK);
        cp = 12.2 + 0.04 * (temperatureK - tSatK);
        cv = 8.1;
        const hSatV = 200.0 + 445.6; // ~645.6 kJ/kg at NBP
        enthalpy = hSatV + cp * (temperatureK - tSatK);
        internalEnergy = enthalpy - (pPa / density) / 1000.0;
        speedOfSound = Math.sqrt(1.4 * this.GAS_CONSTANT_R * temperatureK * z);
      } else {
        // Near-Saturation / Two-Phase
        const rhoL = this.getSaturatedLiquidDensity(tSatK);
        const rhoV = this.getSaturatedVaporDensity(tSatK);
        const hL = -260.0 + 9.5 * (tSatK - 14.0);
        const hV = hL + this.getLatentHeatOfVaporization(tSatK);

        if (knownVapourFraction !== undefined) {
          vapourFraction = Math.max(0.0, Math.min(1.0, knownVapourFraction));
        } else {
          // If perfectly at Tsat, estimate based on sub-millikelvin offset
          vapourFraction = Math.max(0.0, Math.min(1.0, (deltaT + 0.05) / 0.15));
        }

        if (vapourFraction <= 0.01) {
          phase = 'SATURATED_LIQUID';
          density = rhoL;
          enthalpy = hL;
        } else if (vapourFraction >= 0.99) {
          phase = 'SATURATED_VAPOUR';
          density = rhoV;
          enthalpy = hV;
        } else {
          phase = 'TWO_PHASE';
          density = 1.0 / (vapourFraction / rhoV + (1.0 - vapourFraction) / rhoL);
          enthalpy = (1.0 - vapourFraction) * hL + vapourFraction * hV;
        }

        cp = (1.0 - vapourFraction) * 10.2 + vapourFraction * 13.5;
        cv = 7.0;
        internalEnergy = enthalpy - (pressureBar * 1e5 / density) / 1000.0;
        // Two-phase Wood's equation for sound speed
        speedOfSound = Math.sqrt(
          (pressureBar * 1e5) /
            (density * (vapourFraction * (1 - vapourFraction) + 1e-4))
        );
        speedOfSound = Math.max(120.0, Math.min(1100.0, speedOfSound));
      }
    }

    // Dynamic viscosity (Pa·s) - dilute gas + dense liquid contribution
    let viscosity: number;
    if (phase === 'SUBCOOLED_LIQUID' || phase === 'SATURATED_LIQUID') {
      viscosity = 1.4e-5 * Math.exp(28.0 / Math.max(10, temperatureK)); // ~1.3e-5 Pa·s at 20 K
    } else {
      viscosity = 3.2e-7 * Math.pow(temperatureK, 0.75); // ~3.0e-6 Pa·s at 20 K vapour
    }

    // Thermal conductivity (W/(m·K))
    let thermalConductivity: number;
    if (phase === 'SUBCOOLED_LIQUID' || phase === 'SATURATED_LIQUID') {
      thermalConductivity = 0.11 - 0.0018 * (temperatureK - 14.0); // ~0.10 W/(m·K)
    } else {
      thermalConductivity = 0.012 + 0.0006 * temperatureK; // ~0.025 W/(m·K)
    }

    return {
      temperature: Number(temperatureK.toFixed(3)),
      pressure: Number(pressureBar.toFixed(3)),
      pressureMpa: Number((pressureBar / 10.0).toFixed(4)),
      density: Number(density.toFixed(3)),
      enthalpy: Number(enthalpy.toFixed(2)),
      internalEnergy: Number(internalEnergy.toFixed(2)),
      specificHeatCp: Number(cp.toFixed(3)),
      specificHeatCv: Number(cv.toFixed(3)),
      thermalConductivity: Number(thermalConductivity.toFixed(4)),
      viscosity: Number(viscosity.toExponential(4)),
      vapourFraction: Number(vapourFraction.toFixed(4)),
      phaseState: phase,
      saturationTemperature: Number(tSatK.toFixed(3)),
      saturationPressure: Number(pSatBar.toFixed(3)),
      subcoolingMargin: Number(subcoolingMargin.toFixed(3)),
      speedOfSound: Number(speedOfSound.toFixed(1)),
      source: 'NIST Standard Reference Database 23 / Leachman EOS (2009)',
      validityRange: {
        tempMinK: this.VALID_T_MIN_K,
        tempMaxK: this.VALID_T_MAX_K,
        presMinBar: this.VALID_P_MIN_BAR,
        presMaxBar: this.VALID_P_MAX_BAR,
      },
      uncertaintyFraction: 0.0025, // 0.25% standard EOS form uncertainty
      isExtrapolated,
      validityFlag,
    };
  }
}
