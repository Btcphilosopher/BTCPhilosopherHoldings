import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';

@Component({
  selector: 'app-anomalies-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let test = twinService.activeTest();

    @if (test) {
      <div class="space-y-6">
        <!-- Header & Config Banner -->
        <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5 flex flex-col md:flex-row items-center justify-between gap-4">
          <div>
            <h3 class="text-sm font-semibold text-white font-tech uppercase tracking-wide">
              Automated Cryogenic Telemetry Anomaly Detection
            </h3>
            <p class="text-xs text-slate-400 mt-0.5">
              Identifies pressure surges, unexpected flashing inception, thermal excursions, oscillatory bursts, and sensor dropouts without inferring physical causation.
            </p>
          </div>

          <div class="flex items-center gap-2 text-xs font-mono">
            <span class="text-slate-400">STATUS:</span>
            <span class="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-amber-300 font-bold">
              {{ test.anomalies.length }} DETECTED EVENTS
            </span>
          </div>
        </div>

        <!-- Detection Thresholds Configuration Strip -->
        <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5 space-y-3">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <h4 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">
              Active Detector Sensitivity Limits & Invariants
            </h4>
            <span class="text-[11px] font-mono text-slate-500">Configurable Rule Set</span>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-mono">
            <div class="p-3 bg-slate-900 border border-slate-800 rounded-lg">
              <span class="text-slate-400">Pressure Gradient (|dP/dt|):</span>
              <div class="text-sm font-bold text-white mt-1">> 150.0 bar/s</div>
              <span class="text-[10px] text-slate-500">Water-hammer surge detection</span>
            </div>

            <div class="p-3 bg-slate-900 border border-slate-800 rounded-lg">
              <span class="text-slate-400">Flashing Void Inception (α):</span>
              <div class="text-sm font-bold text-white mt-1">> 12.0 % void</div>
              <span class="text-[10px] text-slate-500">Cavitation number σ_f < 1.0</span>
            </div>

            <div class="p-3 bg-slate-900 border border-slate-800 rounded-lg">
              <span class="text-slate-400">Thermal Excursion Rate (dT/dt):</span>
              <div class="text-sm font-bold text-white mt-1">> +1.20 K / 100ms</div>
              <span class="text-[10px] text-slate-500">Subcooling margin loss</span>
            </div>

            <div class="p-3 bg-slate-900 border border-slate-800 rounded-lg">
              <span class="text-slate-400">Sensor Boundary Voltage:</span>
              <div class="text-sm font-bold text-white mt-1">±10 V Full Scale</div>
              <span class="text-[10px] text-slate-500">Dropout & open-circuit check</span>
            </div>
          </div>
        </div>

        <!-- Anomaly Events Table -->
        <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5 space-y-3">
          <div class="flex items-center justify-between">
            <h4 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">
              Telemetry Anomaly Event Log (Click to Scrub Time Cursor)
            </h4>
            <span class="text-xs font-mono text-slate-400">Test ID: {{ test.testId }}</span>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs font-mono">
              <thead>
                <tr class="border-b border-slate-800 text-slate-400">
                  <th class="py-2.5 px-3">Event ID</th>
                  <th class="py-2.5 px-3">Time (s)</th>
                  <th class="py-2.5 px-3">Signal Channel</th>
                  <th class="py-2.5 px-3">Magnitude</th>
                  <th class="py-2.5 px-3">Duration (s)</th>
                  <th class="py-2.5 px-3">Detection Method</th>
                  <th class="py-2.5 px-3">Confidence</th>
                  <th class="py-2.5 px-3">Severity</th>
                  <th class="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/50 text-slate-300">
                @for (anom of test.anomalies; track anom.id) {
                  <tr class="hover:bg-slate-900/50 cursor-pointer" (click)="twinService.setPlaybackTime(anom.timestamp)">
                    <td class="py-2.5 px-3 text-cyan-400 font-bold">{{ anom.id }}</td>
                    <td class="py-2.5 px-3 text-amber-300 font-semibold tabular-nums">T+{{ anom.timestamp.toFixed(3) }}s</td>
                    <td class="py-2.5 px-3 text-slate-200">{{ anom.signal }}</td>
                    <td class="py-2.5 px-3 text-white font-medium">{{ anom.magnitude }}</td>
                    <td class="py-2.5 px-3 tabular-nums text-slate-400">{{ anom.durationSec.toFixed(3) }}</td>
                    <td class="py-2.5 px-3 text-slate-400 max-w-xs truncate" [title]="anom.detectionMethod">{{ anom.detectionMethod }}</td>
                    <td class="py-2.5 px-3 tabular-nums text-emerald-400">{{ (anom.confidence * 100).toFixed(0) }}%</td>
                    <td class="py-2.5 px-3">
                      <span class="px-2 py-0.5 rounded text-[10px] font-bold"
                        [class.bg-amber-500_20]="anom.severity === 'WARNING' || anom.severity === 'CAUTION'"
                        [class.text-amber-300]="anom.severity === 'WARNING' || anom.severity === 'CAUTION'"
                        [class.bg-rose-500_20]="anom.severity === 'ANOMALY'"
                        [class.text-rose-300]="anom.severity === 'ANOMALY'">
                        {{ anom.severity }}
                      </span>
                    </td>
                    <td class="py-2.5 px-3 text-right">
                      <button
                        type="button"
                        class="px-2 py-0.5 text-[10px] font-mono rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 transition-colors"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>

          <div class="bg-slate-900 border border-slate-800 rounded-lg p-3 text-xs font-mono text-slate-400">
            <strong class="text-amber-400">CORE PRINCIPLE:</strong>
            Anomaly detection flags observed signal irregularities. Physical root causes (e.g. valve flutter vs line acoustics vs cryogenic cavitation) must be verified through separate analytical investigation.
          </div>
        </div>
      </div>
    }
  `,
})
export class AnomaliesViewComponent {
  public readonly twinService = inject(DigitalTwinService);
}
