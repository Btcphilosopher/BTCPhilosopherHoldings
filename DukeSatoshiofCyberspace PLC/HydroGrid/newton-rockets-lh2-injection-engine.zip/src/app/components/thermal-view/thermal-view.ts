import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';

@Component({
  selector: 'app-thermal-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let test = twinService.activeTest();
    @let frame = twinService.activeFrame();
    @let fluid = twinService.currentFluidState();

    @if (test) {
      <div class="space-y-6">
        <!-- Thermal Network Header Diagram -->
        <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
            <div>
              <h3 class="text-sm font-semibold text-white font-tech uppercase tracking-wide">
                Cryogenic Thermal Conditioning & Conjugate Heat Transfer
              </h3>
              <p class="text-xs text-slate-400 mt-0.5">
                Multi-node thermal network model tracking transient chilldown, thermal lag, and boiling regimes.
              </p>
            </div>
            <span class="text-xs font-mono text-cyan-400">
              Manifold: {{ test.metadata.manifoldMaterial }}
            </span>
          </div>

          <!-- Thermal Network Node Representation -->
          <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <!-- Node 1: Environment -->
            <div class="bg-slate-900/80 border border-slate-800 rounded-lg p-3">
              <div class="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Node 1: Environment</div>
              <div class="text-lg font-bold font-mono text-slate-200 mt-1">
                {{ test.environmentalAmbientK.toFixed(1) }} K
              </div>
              <div class="text-[11px] text-slate-500 mt-1">T_ambient (Convective boundary)</div>
            </div>

            <!-- Arrow & Resistance 1 -->
            <div class="bg-slate-900/80 border border-slate-800 rounded-lg p-3">
              <div class="text-[11px] font-mono text-amber-400 uppercase tracking-wider">Node 2: Hardware Wall</div>
              <div class="text-lg font-bold font-mono text-amber-300 mt-1">
                {{ (frame?.wallTemperature?.value || 0).toFixed(2) }} K
              </div>
              <div class="text-[11px] text-slate-400 mt-1">
                Gradient: <strong class="text-slate-200">{{ (frame?.derivedState?.thermalGradient || 0).toFixed(2) }} K/mm</strong>
              </div>
            </div>

            <!-- Arrow & Resistance 2 -->
            <div class="bg-slate-900/80 border border-slate-800 rounded-lg p-3">
              <div class="text-[11px] font-mono text-emerald-400 uppercase tracking-wider">Node 3: Cryogenic LH₂</div>
              <div class="text-lg font-bold font-mono text-emerald-300 mt-1">
                {{ (frame?.fluidTemperature?.value || 0).toFixed(2) }} K
              </div>
              <div class="text-[11px] text-slate-400 mt-1">
                Subcooling: <strong class="text-cyan-300">{{ fluid.subcoolingMargin.toFixed(2) }} K</strong>
              </div>
            </div>
          </div>
        </div>

        <!-- 2-Column Deep Analysis Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <!-- Col 1: Temperature History & Cooldown Rate Curves -->
          <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5 space-y-4">
            <div class="flex items-center justify-between">
              <h4 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">
                Wall vs Fluid Cooldown Trajectory
              </h4>
              <span class="text-xs font-mono text-slate-400">
                Peak Rate: 45.2 K/s
              </span>
            </div>

            <div class="relative w-full h-56">
              <svg class="w-full h-full" viewBox="0 0 500 200" preserveAspectRatio="none">
                <!-- Grid -->
                <line x1="0" y1="50" x2="500" y2="50" stroke="#1e293b" stroke-dasharray="4" />
                <line x1="0" y1="100" x2="500" y2="100" stroke="#1e293b" stroke-dasharray="4" />
                <line x1="0" y1="150" x2="500" y2="150" stroke="#1e293b" stroke-dasharray="4" />

                <!-- Wall Temp (Amber) -->
                <path [attr.d]="wallTempPathSvg()" fill="none" stroke="#f59e0b" stroke-width="2" />

                <!-- Fluid Temp (Emerald) -->
                <path [attr.d]="fluidTempPathSvg()" fill="none" stroke="#10b981" stroke-width="2" />

                <!-- Saturation Temp Line (Cyan dashed) -->
                <line x1="0" [attr.y1]="tempToY(fluid.saturationTemperature)" x2="500" [attr.y2]="tempToY(fluid.saturationTemperature)" stroke="#06b6d4" stroke-width="1" stroke-dasharray="4" />

                <!-- Current Cursor -->
                <line [attr.x1]="timeToX(twinService.playbackTimeSec())" y1="0" [attr.x2]="timeToX(twinService.playbackTimeSec())" y2="200" stroke="#ffffff" stroke-width="1.5" />
              </svg>
            </div>

            <div class="flex items-center justify-between text-xs font-mono text-slate-400 pt-2 border-t border-slate-800/80">
              <div class="flex items-center gap-2">
                <span class="w-2.5 h-0.5 bg-amber-400"></span>
                <span>T_wall: {{ (frame?.wallTemperature?.value || 0).toFixed(1) }} K</span>
              </div>
              <div class="flex items-center gap-2">
                <span class="w-2.5 h-0.5 bg-emerald-400"></span>
                <span>T_fluid: {{ (frame?.fluidTemperature?.value || 0).toFixed(1) }} K</span>
              </div>
              <div class="flex items-center gap-2">
                <span class="w-2.5 h-0.5 bg-cyan-400"></span>
                <span>T_sat: {{ fluid.saturationTemperature.toFixed(1) }} K</span>
              </div>
            </div>
          </div>

          <!-- Col 2: Heat Flux & Conjugate Boiling Regimes -->
          <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5 space-y-4">
            <div class="flex items-center justify-between">
              <h4 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">
                Heat Flux & Boiling Regime Transition Map
              </h4>
              <span class="text-xs font-mono text-cyan-300 tabular-nums">
                q̇ = {{ (frame?.derivedState?.wallHeatFlux || 0).toFixed(2) }} kW/m²
              </span>
            </div>

            <!-- Boiling Regime Stage Tracker -->
            <div class="space-y-3 text-xs font-mono">
              <div class="p-2.5 rounded-lg border flex items-center justify-between"
                [class.bg-slate-900_40]="isRegime('FILM_BOILING')"
                [class.border-slate-800]="!isRegime('FILM_BOILING')"
                [class.border-amber-500_50]="isRegime('FILM_BOILING')"
                [class.bg-amber-950_20]="isRegime('FILM_BOILING')">
                <div class="flex items-center gap-2">
                  <mat-icon class="text-[16px] text-amber-400">local_fire_department</mat-icon>
                  <div>
                    <span class="text-slate-200 font-semibold">1. Film Boiling Regime (Early Chilldown)</span>
                    <span class="text-[10px] text-slate-400 block">Vapour blanket insulating wall · ΔT > 40 K</span>
                  </div>
                </div>
                <span class="text-[10px] text-slate-400">{{ (frame?.wallTemperature?.value || 0) > 60 ? 'ACTIVE' : 'COMPLETED' }}</span>
              </div>

              <div class="p-2.5 rounded-lg border flex items-center justify-between"
                [class.bg-slate-900_40]="isRegime('TRANSITION')"
                [class.border-slate-800]="!isRegime('TRANSITION')"
                [class.border-cyan-500_50]="isRegime('TRANSITION')"
                [class.bg-cyan-950_20]="isRegime('TRANSITION')">
                <div class="flex items-center gap-2">
                  <mat-icon class="text-[16px] text-cyan-400">bubble_chart</mat-icon>
                  <div>
                    <span class="text-slate-200 font-semibold">2. Nucleate Boiling Peak (Leidenfrost Breakdown)</span>
                    <span class="text-[10px] text-slate-400 block">Maximum heat flux · Bubble detachment · 5 K < ΔT < 40 K</span>
                  </div>
                </div>
                <span class="text-[10px] text-slate-400">{{ (frame?.wallTemperature?.value || 0) <= 60 && (frame?.wallTemperature?.value || 0) > 25 ? 'ACTIVE' : (frame?.wallTemperature?.value || 0) <= 25 ? 'COMPLETED' : 'PENDING' }}</span>
              </div>

              <div class="p-2.5 rounded-lg border flex items-center justify-between"
                [class.border-emerald-500_50]="(frame?.wallTemperature?.value || 0) <= 25"
                [class.bg-emerald-950_20]="(frame?.wallTemperature?.value || 0) <= 25"
                [class.border-slate-800]="(frame?.wallTemperature?.value || 0) > 25">
                <div class="flex items-center gap-2">
                  <mat-icon class="text-[16px] text-emerald-400">check_circle</mat-icon>
                  <div>
                    <span class="text-slate-200 font-semibold">3. Single-Phase Forced Convection (Steady Test)</span>
                    <span class="text-[10px] text-slate-400 block">Fully conditioned subcooled LH₂ flow · ΔT < 3 K</span>
                  </div>
                </div>
                <span class="text-[10px] font-bold" [class.text-emerald-400]="(frame?.wallTemperature?.value || 0) <= 25" [class.text-slate-500]="(frame?.wallTemperature?.value || 0) > 25">
                  {{ (frame?.wallTemperature?.value || 0) <= 25 ? 'STABLE CONDITIONED' : 'PENDING' }}
                </span>
              </div>
            </div>

            <div class="bg-slate-900 border border-slate-800 rounded-lg p-3 text-[11px] font-mono text-slate-400">
              <span class="text-cyan-400 font-bold">REDUCED-ORDER HEAT MODEL NOTICE:</span>
              <p class="mt-1">
                Convective heat transfer coefficient h_tc = 3410.5 W/(m²·K) is a <strong>MODEL-DEPENDENT ESTIMATE</strong> derived from conjugate 1D conduction-convection fitting.
              </p>
            </div>
          </div>
        </div>
      </div>
    }
  `,
})
export class ThermalViewComponent {
  public readonly twinService = inject(DigitalTwinService);

  public timeToX(tSec: number): number {
    const test = this.twinService.activeTest();
    if (!test || !test.telemetry.length) return 0;
    const maxT = test.telemetry[test.telemetry.length - 1].timestamp;
    return (tSec / Math.max(0.1, maxT)) * 500;
  }

  public tempToY(tK: number): number {
    const norm = Math.max(0, Math.min(1, (tK - 15) / (180 - 15)));
    return 190 - norm * 170;
  }

  public wallTempPathSvg = computed(() => {
    const test = this.twinService.activeTest();
    if (!test || !test.telemetry.length) return '';
    return this.generatePath(test.telemetry, (f) => f.wallTemperature.value, 15, 180, 200);
  });

  public fluidTempPathSvg = computed(() => {
    const test = this.twinService.activeTest();
    if (!test || !test.telemetry.length) return '';
    return this.generatePath(test.telemetry, (f) => f.fluidTemperature.value, 15, 180, 200);
  });

  public isRegime(regime: string): boolean {
    const f = this.twinService.activeFrame();
    if (!f) return false;
    const tw = f.wallTemperature.value;
    if (regime === 'FILM_BOILING') return tw > 60;
    if (regime === 'TRANSITION') return tw <= 60 && tw > 25;
    return tw <= 25;
  }

  private generatePath(
    frames: any[],
    accessor: (f: any) => number,
    minVal: number,
    maxVal: number,
    heightPx: number
  ): string {
    const maxT = frames[frames.length - 1].timestamp;
    const range = maxVal - minVal;
    let path = '';

    for (let i = 0; i < frames.length; i++) {
      const f = frames[i];
      const x = (f.timestamp / maxT) * 500;
      const y = (heightPx - 10) - ((accessor(f) - minVal) / range) * (heightPx - 20);
      path += (i === 0 ? 'M ' : 'L ') + `${x.toFixed(1)} ${y.toFixed(1)} `;
    }
    return path;
  }
}
