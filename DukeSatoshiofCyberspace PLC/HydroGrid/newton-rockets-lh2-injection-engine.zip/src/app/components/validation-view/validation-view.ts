import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';

@Component({
  selector: 'app-validation-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let test = twinService.activeTest();
    @let ign = test?.ignitionCorrelation;

    @if (test) {
      <div class="space-y-6">
        <!-- Banner: Propulsion Model vs Measurement Residual Header -->
        <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
            <div>
              <h3 class="text-sm font-semibold text-white font-tech uppercase tracking-wide">
                Newton Rockets Propulsion Digital-Twin Validation
              </h3>
              <p class="text-xs text-slate-400 mt-0.5">
                Comparison of theoretical propulsion twin predictions with experimental measurements.
              </p>
            </div>
            <div class="flex items-center gap-2 text-xs font-mono text-cyan-400">
              <mat-icon class="text-[16px]">sync_alt</mat-icon>
              <span>MODEL · MEASUREMENT · RESIDUAL · UNCERTAINTY</span>
            </div>
          </div>

          <!-- Model vs Measurement vs Residual Chart -->
          <div class="space-y-4">
            <div class="flex items-center justify-between text-xs font-mono">
              <div class="flex items-center gap-4">
                <div class="flex items-center gap-1.5 text-white">
                  <span class="w-3 h-0.5 bg-white"></span>
                  <span>MEASURED MASS FLOW ṁ(t)</span>
                </div>
                <div class="flex items-center gap-1.5 text-cyan-400">
                  <span class="w-3 h-0.5 bg-cyan-400 stroke-dasharray"></span>
                  <span>PROPULSION TWIN MODEL</span>
                </div>
                <div class="flex items-center gap-1.5 text-amber-400">
                  <span class="w-3 h-0.5 bg-amber-400"></span>
                  <span>RESIDUAL (MEASURED - MODEL)</span>
                </div>
              </div>
              <span class="text-slate-400">R² = 0.984 · RMSE = 0.0042 kg/s</span>
            </div>

            <div class="relative w-full h-56">
              <svg class="w-full h-full" viewBox="0 0 1000 200" preserveAspectRatio="none">
                <!-- Grid -->
                <line x1="0" y1="50" x2="1000" y2="50" stroke="#1e293b" stroke-dasharray="4" />
                <line x1="0" y1="100" x2="1000" y2="100" stroke="#1e293b" stroke-dasharray="4" />
                <line x1="0" y1="150" x2="1000" y2="150" stroke="#1e293b" stroke-dasharray="4" />

                <!-- Zero Residual Line -->
                <line x1="0" y1="170" x2="1000" y2="170" stroke="#475569" stroke-width="1" stroke-dasharray="2" />

                <!-- Residual Curve (Amber) -->
                <path [attr.d]="residualPathSvg()" fill="none" stroke="#f59e0b" stroke-width="1.5" />

                <!-- Measured Curve (White) -->
                <path [attr.d]="measuredPathSvg()" fill="none" stroke="#ffffff" stroke-width="2" />

                <!-- Model Curve (Cyan dashed) -->
                <path [attr.d]="modelPathSvg()" fill="none" stroke="#06b6d4" stroke-width="2" stroke-dasharray="4 2" />
              </svg>

              <!-- Y-axis -->
              <div class="absolute left-2 top-2 text-[10px] font-mono text-slate-500">Flow: 0.45 kg/s</div>
              <div class="absolute left-2 bottom-8 text-[10px] font-mono text-amber-500">Residual: ±0.02 kg/s</div>
            </div>
          </div>
        </div>

        <!-- 2-Column Grid: Ignition Correlation + Validation Hierarchy -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <!-- Col 1: Ignition Interface Correlation -->
          <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5 space-y-4">
            <div class="flex items-center justify-between border-b border-slate-800 pb-3">
              <div class="flex items-center gap-2">
                <mat-icon class="text-amber-400 text-[18px]">bolt</mat-icon>
                <h4 class="text-xs font-mono font-bold uppercase tracking-wide text-white">
                  Newton Rockets Ignition Interface Correlation
                </h4>
              </div>
              <span class="text-xs font-mono text-cyan-400">t_ign = {{ ign?.ignitionEventTimeSec }} s</span>
            </div>

            <div class="space-y-2.5 text-xs font-mono">
              <div class="flex justify-between py-1 border-b border-slate-800/50">
                <span class="text-slate-400">Cryogenic Fluid Temp at Ignition:</span>
                <span class="text-white font-semibold tabular-nums">{{ ign?.injectionFluidTemperatureK?.toFixed(2) }} K</span>
              </div>
              <div class="flex justify-between py-1 border-b border-slate-800/50">
                <span class="text-slate-400">Subcooling Margin at Ignition:</span>
                <span class="text-cyan-300 font-semibold tabular-nums">{{ ign?.subcoolingMarginK?.toFixed(2) }} K</span>
              </div>
              <div class="flex justify-between py-1 border-b border-slate-800/50">
                <span class="text-slate-400">Injected Void Fraction (α):</span>
                <span class="text-slate-200 tabular-nums">{{ ((ign?.injectedVoidFraction || 0) * 100).toFixed(1) }} %</span>
              </div>
              <div class="flex justify-between py-1 border-b border-slate-800/50">
                <span class="text-slate-400">Ignition Delay (Δt_ign):</span>
                <span class="text-emerald-300 font-semibold tabular-nums">{{ ign?.ignitionDelayMs?.toFixed(1) }} ms</span>
              </div>
              <div class="flex justify-between py-1 border-b border-slate-800/50">
                <span class="text-slate-400">Chamber Pressurization (dP/dt):</span>
                <span class="text-white font-semibold tabular-nums">{{ ign?.initialChamberPressurizationRateBarPerSec }} bar/s</span>
              </div>
            </div>

            <div class="bg-slate-900/90 border border-slate-800 rounded-lg p-3 text-xs font-mono text-slate-300">
              <div class="text-[11px] font-bold text-amber-400 mb-1">IGNITION CORRELATION ASSESSMENT:</div>
              <p>{{ ign?.correlationAssessment }}</p>
            </div>
          </div>

          <!-- Col 2: Validation Hierarchy Levels 0 to 5 -->
          <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5 space-y-3">
            <div class="flex items-center justify-between border-b border-slate-800 pb-3">
              <div class="flex items-center gap-2">
                <mat-icon class="text-cyan-400 text-[18px]">account_tree</mat-icon>
                <h4 class="text-xs font-mono font-bold uppercase tracking-wide text-white">
                  Newton Rockets Validation Hierarchy (Levels 0–5)
                </h4>
              </div>
              <span class="text-xs font-mono text-emerald-400 font-bold">LEVEL 4 ACHIEVED</span>
            </div>

            <div class="space-y-2">
              @for (lvl of twinService.validationLevels(); track lvl.level) {
                <div class="p-2.5 rounded-lg border flex items-start justify-between text-xs font-mono"
                  [class.bg-slate-900_30]="!lvl.achieved"
                  [class.border-slate-800]="!lvl.achieved"
                  [class.bg-emerald-950_10]="lvl.achieved"
                  [class.border-emerald-800_40]="lvl.achieved">
                  <div class="space-y-0.5">
                    <div class="flex items-center gap-2">
                      <strong [class.text-emerald-300]="lvl.achieved" [class.text-slate-400]="!lvl.achieved">
                        [LEVEL {{ lvl.level }}] {{ lvl.name }}
                      </strong>
                    </div>
                    <p class="text-[11px] text-slate-400">{{ lvl.description }}</p>
                    <div class="text-[10px] text-slate-500 italic">{{ lvl.provenance }}</div>
                  </div>

                  <span class="px-2 py-0.5 rounded text-[10px] font-bold shrink-0 ml-2"
                    [class.bg-emerald-500_20]="lvl.achieved"
                    [class.text-emerald-300]="lvl.achieved"
                    [class.bg-slate-800]="!lvl.achieved"
                    [class.text-slate-500]="!lvl.achieved">
                    {{ lvl.achieved ? 'ACHIEVED' : 'SCHEDULED' }}
                  </span>
                </div>
              }
            </div>
          </div>
        </div>
      </div>
    }
  `,
})
export class ValidationViewComponent {
  public readonly twinService = inject(DigitalTwinService);

  public measuredPathSvg = computed(() => {
    const test = this.twinService.activeTest();
    if (!test) return '';
    const comp = test.propulsionComparison;
    if (!comp.length) return '';
    const maxT = 6.0;
    let path = '';
    for (let i = 0; i < comp.length; i++) {
      const c = comp[i];
      const x = (c.timestamp / maxT) * 1000;
      const y = 140 - (c.measuredMassFlow / 0.45) * 120;
      path += (i === 0 ? 'M ' : 'L ') + `${x.toFixed(1)} ${y.toFixed(1)} `;
    }
    return path;
  });

  public modelPathSvg = computed(() => {
    const test = this.twinService.activeTest();
    if (!test) return '';
    const comp = test.propulsionComparison;
    if (!comp.length) return '';
    const maxT = 6.0;
    let path = '';
    for (let i = 0; i < comp.length; i++) {
      const c = comp[i];
      const x = (c.timestamp / maxT) * 1000;
      const y = 140 - (c.modelPredictedMassFlow / 0.45) * 120;
      path += (i === 0 ? 'M ' : 'L ') + `${x.toFixed(1)} ${y.toFixed(1)} `;
    }
    return path;
  });

  public residualPathSvg = computed(() => {
    const test = this.twinService.activeTest();
    if (!test) return '';
    const comp = test.propulsionComparison;
    if (!comp.length) return '';
    const maxT = 6.0;
    let path = '';
    for (let i = 0; i < comp.length; i++) {
      const c = comp[i];
      const x = (c.timestamp / maxT) * 1000;
      const y = 170 - (c.residualMassFlow / 0.05) * 20; // centered at y=170
      path += (i === 0 ? 'M ' : 'L ') + `${x.toFixed(1)} ${y.toFixed(1)} `;
    }
    return path;
  });
}
