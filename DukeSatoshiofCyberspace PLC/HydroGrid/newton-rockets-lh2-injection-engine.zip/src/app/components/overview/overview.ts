import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';

@Component({
  selector: 'app-overview',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let test = twinService.activeTest();
    @let frame = twinService.activeFrame();
    @let fluid = twinService.currentFluidState();

    @if (test) {
      <div class="space-y-6">
        <!-- Banner 1: Test Article Metrology & Provenance Header -->
        <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5 shadow-sm">
          <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div>
              <div class="flex items-center gap-2.5 text-xs text-slate-400 font-mono">
                <span>{{ test.testId }}</span>
                <span aria-hidden="true">·</span>
                <span>{{ test.campaignId }}</span>
                <span aria-hidden="true">·</span>
                <span>{{ test.testDate }}</span>
                <span aria-hidden="true">·</span>
                <span class="text-cyan-400">{{ test.metadata.hardwareRevision }}</span>
              </div>
              <h2 class="text-xl font-bold tracking-tight text-white mt-1">{{ test.title }}</h2>
              <div class="text-xs text-slate-400 mt-1 flex flex-wrap items-center gap-4">
                <span>Operator: <strong class="text-slate-200 font-normal">{{ test.operator }}</strong></span>
                <span>Instrumentation: <strong class="text-slate-200 font-mono font-normal">{{ test.metadata.instrumentationRevision }}</strong></span>
                <span>Manifold: <strong class="text-slate-200 font-normal">{{ test.metadata.manifoldMaterial }}</strong></span>
                <span>Line Rating: <strong class="text-slate-200 font-mono font-normal">{{ test.metadata.nominalLineRatingBar }} bar</strong></span>
              </div>
            </div>

            <!-- Provenance & Validation Badges -->
            <div class="flex flex-wrap items-center gap-2">
              @if (test.metadata.dataSourceType === 'SYNTHETIC_GROUND_TRUTH') {
                <div class="px-3 py-1.5 bg-amber-950/40 border border-amber-800/80 rounded-lg text-xs font-mono text-amber-300 flex items-center gap-1.5">
                  <mat-icon class="text-[15px] !w-4 !h-4 leading-none">science</mat-icon>
                  <span>SYNTHETIC — NOT EXPERIMENTAL DATA</span>
                </div>
              } @else {
                <div class="px-3 py-1.5 bg-emerald-950/40 border border-emerald-800/80 rounded-lg text-xs font-mono text-emerald-300 flex items-center gap-1.5">
                  <mat-icon class="text-[15px] !w-4 !h-4 leading-none">precision_manufacturing</mat-icon>
                  <span>EXPERIMENTAL TEST ARTICLE</span>
                </div>
              }

              <div class="px-3 py-1.5 bg-slate-800/80 border border-slate-700 rounded-lg text-xs font-mono text-slate-300 flex items-center gap-1.5">
                <mat-icon class="text-[15px] !w-4 !h-4 leading-none text-cyan-400">verified</mat-icon>
                <span>VALIDATION LEVEL {{ test.validationLevel }}</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Telemetry Timeline Scrubber / Replay Bar -->
        <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <div class="flex items-center gap-3 w-full md:w-auto">
            <button
              type="button"
              (click)="togglePlay()"
              class="w-8 h-8 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white flex items-center justify-center transition-colors cursor-pointer shrink-0"
              title="Play/Pause Telemetry Replay"
            >
              <mat-icon class="text-[18px] !w-4.5 !h-4.5 leading-none">
                {{ isPlaying() ? 'pause' : 'play_arrow' }}
              </mat-icon>
            </button>

            <button
              type="button"
              (click)="stepTime(-0.1)"
              class="w-7 h-7 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors cursor-pointer shrink-0"
              title="Step Back 100ms"
            >
              <mat-icon class="text-[16px] !w-4 !h-4 leading-none">replay_10</mat-icon>
            </button>

            <button
              type="button"
              (click)="stepTime(0.1)"
              class="w-7 h-7 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors cursor-pointer shrink-0"
              title="Step Forward 100ms"
            >
              <mat-icon class="text-[16px] !w-4 !h-4 leading-none">forward_10</mat-icon>
            </button>

            <div class="font-mono text-xs text-slate-400 shrink-0">
              <span class="text-slate-500">T+</span>
              <strong class="text-cyan-300 text-sm font-semibold tabular-nums ml-0.5">
                {{ twinService.playbackTimeSec().toFixed(3) }}
              </strong>
              <span class="text-slate-500 ml-1">/ {{ maxTimeSec().toFixed(2) }} s</span>
            </div>
          </div>

          <!-- Slider -->
          <div class="w-full flex-1 max-w-2xl px-2">
            <input
              type="range"
              min="0"
              [max]="maxTimeSec()"
              step="0.02"
              [value]="twinService.playbackTimeSec()"
              (input)="onSliderChange($event)"
              class="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-500"
            />
          </div>

          <!-- Raw / Filtered Mode Toggle -->
          <div class="flex items-center gap-2 shrink-0">
            <span class="text-xs font-mono text-slate-400">RAW TELEMETRY:</span>
            <button
              type="button"
              (click)="twinService.showRawTelemetry.set(!twinService.showRawTelemetry())"
              class="px-2.5 py-1 text-xs font-mono rounded transition-colors cursor-pointer"
              [class.bg-cyan-500_20]="twinService.showRawTelemetry()"
              [class.text-cyan-300]="twinService.showRawTelemetry()"
              [class.border]="true"
              [class.border-cyan-500_40]="twinService.showRawTelemetry()"
              [class.bg-slate-900]="!twinService.showRawTelemetry()"
              [class.text-slate-400]="!twinService.showRawTelemetry()"
              [class.border-slate-800]="!twinService.showRawTelemetry()"
            >
              {{ twinService.showRawTelemetry() ? 'UNFILTERED' : 'CONDITIONED' }}
            </button>
          </div>
        </div>

        <!-- Section 2: Core Cryogenic State Telemetry Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <!-- Card 1: Fluid Temperature & Subcooling -->
          <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-4.5 flex flex-col justify-between">
            <div class="flex items-center justify-between text-xs text-slate-400 font-mono">
              <span class="uppercase tracking-wider">Fluid Temp (T_fluid)</span>
              <mat-icon class="text-[16px] !w-4 !h-4 text-cyan-400">thermostat</mat-icon>
            </div>
            <div class="my-2">
              <div class="text-2xl font-bold font-mono text-white tabular-nums">
                {{ fluid.temperature.toFixed(2) }}
                <span class="text-xs font-normal text-slate-400 uppercase ml-1">K</span>
              </div>
              <div class="text-xs font-mono mt-1" [class.text-emerald-400]="fluid.subcoolingMargin > 0.5" [class.text-amber-400]="fluid.subcoolingMargin <= 0.5">
                Subcooling: <strong>{{ fluid.subcoolingMargin.toFixed(2) }} K</strong>
              </div>
            </div>
            <div class="text-[11px] font-mono text-slate-500 flex items-center justify-between border-t border-slate-800/80 pt-2">
              <span>T_sat: {{ fluid.saturationTemperature.toFixed(2) }} K</span>
              <span>±0.15 K</span>
            </div>
          </div>

          <!-- Card 2: Static & Differential Pressure -->
          <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-4.5 flex flex-col justify-between">
            <div class="flex items-center justify-between text-xs text-slate-400 font-mono">
              <span class="uppercase tracking-wider">Inlet Pressure (P_up)</span>
              <mat-icon class="text-[16px] !w-4 !h-4 text-cyan-400">speed</mat-icon>
            </div>
            <div class="my-2">
              <div class="text-2xl font-bold font-mono text-white tabular-nums">
                {{ fluid.pressure.toFixed(2) }}
                <span class="text-xs font-normal text-slate-400 uppercase ml-1">bar</span>
              </div>
              <div class="text-xs font-mono text-slate-300 mt-1">
                Pressure Drop ΔP: <strong class="text-cyan-300">{{ (frame?.derivedState?.pressureDrop || 0).toFixed(2) }} bar</strong>
              </div>
            </div>
            <div class="text-[11px] font-mono text-slate-500 flex items-center justify-between border-t border-slate-800/80 pt-2">
              <span>P_down: {{ (frame?.downstreamPressure?.value || 0).toFixed(2) }} bar</span>
              <span>±0.05 bar</span>
            </div>
          </div>

          <!-- Card 3: Thermodynamic Density -->
          <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-4.5 flex flex-col justify-between">
            <div class="flex items-center justify-between text-xs text-slate-400 font-mono">
              <span class="uppercase tracking-wider">Fluid Density (ρ)</span>
              <mat-icon class="text-[16px] !w-4 !h-4 text-cyan-400">compress</mat-icon>
            </div>
            <div class="my-2">
              <div class="text-2xl font-bold font-mono text-white tabular-nums">
                {{ fluid.density.toFixed(2) }}
                <span class="text-xs font-normal text-slate-400 uppercase ml-1">kg/m³</span>
              </div>
              <div class="text-xs font-mono text-slate-400 mt-1">
                Enthalpy: <strong class="text-slate-200">{{ fluid.enthalpy.toFixed(1) }} kJ/kg</strong>
              </div>
            </div>
            <div class="text-[11px] font-mono text-slate-500 flex items-center justify-between border-t border-slate-800/80 pt-2">
              <span>Sound Speed: {{ fluid.speedOfSound.toFixed(0) }} m/s</span>
              <span>NIST EOS</span>
            </div>
          </div>

          <!-- Card 4: Measured Mass Flow Rate -->
          <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-4.5 flex flex-col justify-between">
            <div class="flex items-center justify-between text-xs text-slate-400 font-mono">
              <span class="uppercase tracking-wider">Mass Flow (ṁ)</span>
              <mat-icon class="text-[16px] !w-4 !h-4 text-cyan-400">waves</mat-icon>
            </div>
            <div class="my-2">
              <div class="text-2xl font-bold font-mono text-white tabular-nums">
                {{ (frame?.massFlow?.value || 0).toFixed(4) }}
                <span class="text-xs font-normal text-slate-400 uppercase ml-1">kg/s</span>
              </div>
              <div class="text-xs font-mono text-slate-400 mt-1">
                Mass Flux: <strong class="text-slate-200">{{ (frame?.derivedState?.massFlux || 0).toFixed(0) }} kg/(m²·s)</strong>
                <span class="text-[9px] text-amber-400 block">*MODEL ESTIMATE</span>
              </div>
            </div>
            <div class="text-[11px] font-mono text-slate-500 flex items-center justify-between border-t border-slate-800/80 pt-2">
              <span>Target: {{ test.targetMassFlowKgS }} kg/s</span>
              <span>±0.0012 kg/s</span>
            </div>
          </div>

          <!-- Card 5: Thermodynamic Phase State -->
          <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-4.5 flex flex-col justify-between">
            <div class="flex items-center justify-between text-xs text-slate-400 font-mono">
              <span class="uppercase tracking-wider">Phase State</span>
              <mat-icon class="text-[16px] !w-4 !h-4" [class.text-emerald-400]="fluid.phaseState === 'SUBCOOLED_LIQUID'" [class.text-amber-400]="fluid.phaseState !== 'SUBCOOLED_LIQUID'">
                grain
              </mat-icon>
            </div>
            <div class="my-2">
              <div class="text-base font-bold font-mono tracking-tight" [class.text-emerald-300]="fluid.phaseState === 'SUBCOOLED_LIQUID'" [class.text-amber-300]="fluid.phaseState === 'TWO_PHASE'" [class.text-cyan-300]="fluid.phaseState === 'SUPERCRITICAL'">
                {{ formatPhase(fluid.phaseState) }}
              </div>
              <div class="text-xs font-mono text-slate-400 mt-1">
                Void Fraction α: <strong class="text-slate-200">{{ ((frame?.derivedState?.voidFraction || 0) * 100).toFixed(1) }}%</strong>
              </div>
            </div>
            <div class="text-[11px] font-mono text-slate-500 flex items-center justify-between border-t border-slate-800/80 pt-2">
              <span>Model: HEM Drift-Flux</span>
              <span>{{ fluid.validityFlag }}</span>
            </div>
          </div>
        </div>

        <!-- Section 3: Engineering Analysis Metrics (3-column layout) -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <!-- Col 1: Injection Transient Metrics -->
          <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5 space-y-4">
            <div class="flex items-center justify-between border-b border-slate-800 pb-3">
              <div class="flex items-center gap-2">
                <mat-icon class="text-cyan-400 text-[18px]">timer</mat-icon>
                <h3 class="text-sm font-semibold text-white font-tech uppercase tracking-wide">Injection Transient Metrics</h3>
              </div>
              <span class="text-xs font-mono text-slate-400">t0 = {{ test.transientMetrics.t0 }}s</span>
            </div>

            <div class="space-y-2.5 text-xs font-mono">
              <div class="flex justify-between py-1 border-b border-slate-800/50">
                <span class="text-slate-400">Rise Time (10% to 90%):</span>
                <span class="text-white font-semibold tabular-nums">{{ (test.transientMetrics.riseTime10To90 * 1000).toFixed(1) }} ms</span>
              </div>
              <div class="flex justify-between py-1 border-b border-slate-800/50">
                <span class="text-slate-400">Settling Time (±2% band):</span>
                <span class="text-white font-semibold tabular-nums">{{ (test.transientMetrics.settlingTime2Pct * 1000).toFixed(1) }} ms</span>
              </div>
              <div class="flex justify-between py-1 border-b border-slate-800/50">
                <span class="text-slate-400">Peak Pressure Surge:</span>
                <span class="text-amber-300 font-semibold tabular-nums">+{{ test.transientMetrics.peakPressureOvershootPct.toFixed(1) }} %</span>
              </div>
              <div class="flex justify-between py-1 border-b border-slate-800/50">
                <span class="text-slate-400">Steady State Mean Flow:</span>
                <span class="text-cyan-300 font-semibold tabular-nums">{{ test.transientMetrics.steadyStateMeanFlow.toFixed(4) }} kg/s</span>
              </div>
              <div class="flex justify-between py-1 border-b border-slate-800/50">
                <span class="text-slate-400">Flow Coeff. of Variation (CV):</span>
                <span class="text-slate-200 tabular-nums">{{ test.transientMetrics.steadyStateFlowCV.toFixed(2) }} %</span>
              </div>
              <div class="flex justify-between py-1">
                <span class="text-slate-400">Acoustic Transit Delay:</span>
                <span class="text-slate-300 tabular-nums">{{ test.transientMetrics.acousticTransitDelayMs.toFixed(2) }} ms</span>
              </div>
            </div>
          </div>

          <!-- Col 2: Spectral Stability & Dynamics -->
          <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5 space-y-4">
            <div class="flex items-center justify-between border-b border-slate-800 pb-3">
              <div class="flex items-center gap-2">
                <mat-icon class="text-cyan-400 text-[18px]">graphic_eq</mat-icon>
                <h3 class="text-sm font-semibold text-white font-tech uppercase tracking-wide">Dynamic Stability & PSD</h3>
              </div>
              <span class="text-xs font-mono" [class.text-emerald-400]="test.stability.instabilityRiskRating === 'LOW'" [class.text-amber-400]="test.stability.instabilityRiskRating !== 'LOW'">
                ● {{ test.stability.instabilityRiskRating }} RISK
              </span>
            </div>

            <div class="space-y-2.5 text-xs font-mono">
              <div class="flex justify-between py-1 border-b border-slate-800/50">
                <span class="text-slate-400">Dominant Mode Frequency:</span>
                <span class="text-cyan-300 font-semibold tabular-nums">{{ test.stability.dominantFrequencyHz.toFixed(1) }} Hz</span>
              </div>
              <div class="flex justify-between py-1 border-b border-slate-800/50">
                <span class="text-slate-400">Secondary Harmonic:</span>
                <span class="text-slate-200 tabular-nums">{{ test.stability.secondaryFrequencyHz.toFixed(1) }} Hz</span>
              </div>
              <div class="flex justify-between py-1 border-b border-slate-800/50">
                <span class="text-slate-400">Peak Spectral Amplitude:</span>
                <span class="text-white font-semibold tabular-nums">{{ test.stability.peakAmplitudeBar.toFixed(3) }} bar</span>
              </div>
              <div class="flex justify-between py-1 border-b border-slate-800/50">
                <span class="text-slate-400">Damping Ratio (ζ):</span>
                <span class="text-slate-200 tabular-nums">{{ test.stability.dampingRatio.toFixed(3) }}</span>
              </div>
              <div class="flex justify-between py-1 border-b border-slate-800/50">
                <span class="text-slate-400">Sample Rate:</span>
                <span class="text-slate-400 tabular-nums">{{ test.stability.sampleRateHz }} Hz</span>
              </div>
              <div class="pt-1 text-[11px] text-slate-400 italic">
                {{ test.stability.observedSignalDescription }}
              </div>
            </div>
          </div>

          <!-- Col 3: Thermal Conditioning & Cooldown -->
          <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5 space-y-4">
            <div class="flex items-center justify-between border-b border-slate-800 pb-3">
              <div class="flex items-center gap-2">
                <mat-icon class="text-cyan-400 text-[18px]">ac_unit</mat-icon>
                <h3 class="text-sm font-semibold text-white font-tech uppercase tracking-wide">Thermal Conditioning State</h3>
              </div>
              <span class="text-xs font-mono text-cyan-400">T_wall = {{ (frame?.wallTemperature?.value || 0).toFixed(1) }} K</span>
            </div>

            <div class="space-y-2.5 text-xs font-mono">
              <div class="flex justify-between py-1 border-b border-slate-800/50">
                <span class="text-slate-400">Initial Wall Soak Temp:</span>
                <span class="text-slate-200 tabular-nums">{{ test.telemetry[0]?.wallTemperature?.value?.toFixed(1) || '85.0' }} K</span>
              </div>
              <div class="flex justify-between py-1 border-b border-slate-800/50">
                <span class="text-slate-400">Instantaneous Cooldown Rate:</span>
                <span class="text-white font-semibold tabular-nums">{{ (frame?.derivedState?.cooldownRate || 0).toFixed(1) }} K/s</span>
              </div>
              <div class="flex justify-between py-1 border-b border-slate-800/50">
                <span class="text-slate-400">Thermal Wall Gradient:</span>
                <span class="text-slate-200 tabular-nums">{{ (frame?.derivedState?.thermalGradient || 0).toFixed(2) }} K/mm</span>
              </div>
              <div class="flex justify-between py-1 border-b border-slate-800/50">
                <span class="text-slate-400">Wall Heat Flux (Estimated):</span>
                <span class="text-cyan-300 font-semibold tabular-nums">{{ (frame?.derivedState?.wallHeatFlux || 0).toFixed(2) }} kW/m²</span>
              </div>
              <div class="flex justify-between py-1">
                <span class="text-slate-400">Conjugate Boiling Regime:</span>
                <span class="text-emerald-300 font-semibold">Single-Phase Forced Convection</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Section 4: Live Anomaly Detection Strip -->
        @if (test.anomalies.length > 0) {
          <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4">
            <div class="flex items-center justify-between mb-3">
              <div class="flex items-center gap-2">
                <mat-icon class="text-amber-400 text-[18px]">warning</mat-icon>
                <h4 class="text-xs font-mono font-bold uppercase tracking-wider text-amber-300">
                  Detected Telemetry Anomalies ({{ test.anomalies.length }})
                </h4>
              </div>
              <span class="text-xs font-mono text-slate-400">Grounded Detection Engine</span>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              @for (anom of test.anomalies; track anom.id) {
                <div
                  (click)="twinService.setPlaybackTime(anom.timestamp)"
                  class="bg-[#0b111c] border border-slate-800 hover:border-slate-700 rounded-lg p-3 cursor-pointer transition-colors"
                >
                  <div class="flex items-center justify-between text-xs font-mono">
                    <span class="text-amber-400 font-bold">T+{{ anom.timestamp.toFixed(3) }}s</span>
                    <span class="text-[10px] text-slate-400">{{ anom.signal }}</span>
                  </div>
                  <div class="text-xs font-medium text-slate-200 mt-1">{{ anom.magnitude }}</div>
                  <div class="text-[11px] text-slate-400 mt-1">{{ anom.description }}</div>
                  <div class="text-[10px] font-mono text-slate-500 mt-2 flex justify-between">
                    <span>{{ anom.detectionMethod }}</span>
                    <span>Confidence: {{ (anom.confidence * 100).toFixed(0) }}%</span>
                  </div>
                </div>
              }
            </div>
          </div>
        }
      </div>
    }
  `,
})
export class OverviewComponent {
  public readonly twinService = inject(DigitalTwinService);
  public readonly isPlaying = this.twinService.isPlaying;

  public readonly maxTimeSec = computed(() => {
    const test = this.twinService.activeTest();
    if (!test || !test.telemetry.length) return 5.0;
    return test.telemetry[test.telemetry.length - 1].timestamp;
  });

  private intervalTimer: any = null;

  public togglePlay(): void {
    const currentlyPlaying = this.isPlaying();
    this.twinService.isPlaying.set(!currentlyPlaying);

    if (!currentlyPlaying) {
      this.startPlaybackTimer();
    } else {
      this.stopPlaybackTimer();
    }
  }

  public stepTime(deltaSec: number): void {
    this.twinService.setPlaybackTime(this.twinService.playbackTimeSec() + deltaSec);
  }

  public onSliderChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input) {
      this.twinService.setPlaybackTime(parseFloat(input.value));
    }
  }

  public formatPhase(phase: string): string {
    return phase.replace(/_/g, ' ');
  }

  private startPlaybackTimer(): void {
    this.stopPlaybackTimer();
    this.intervalTimer = setInterval(() => {
      const current = this.twinService.playbackTimeSec();
      const max = this.maxTimeSec();
      if (current >= max) {
        this.twinService.setPlaybackTime(0);
      } else {
        this.twinService.setPlaybackTime(current + 0.04);
      }
    }, 40);
  }

  private stopPlaybackTimer(): void {
    if (this.intervalTimer) {
      clearInterval(this.intervalTimer);
      this.intervalTimer = null;
    }
  }
}
