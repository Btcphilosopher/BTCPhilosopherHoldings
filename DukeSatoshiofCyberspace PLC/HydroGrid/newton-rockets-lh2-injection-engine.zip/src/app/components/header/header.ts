import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';

@Component({
  selector: 'app-header',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bg-[#0b111c] border-b border-slate-800/80 px-6 py-3.5 flex flex-col md:flex-row items-center justify-between gap-4 select-none sticky top-0 z-50">
      <!-- Zone 1: Wordmark Brand -->
      <div class="flex items-center gap-3 w-full md:w-auto justify-between md:justify-start">
        <div class="flex items-center gap-2.5">
          <div class="w-2.5 h-6 bg-cyan-500 rounded-xs"></div>
          <div>
            <div class="text-xs font-mono tracking-widest text-slate-400 uppercase font-semibold">Newton Rockets Ltd.</div>
            <h1 class="text-sm font-bold tracking-tight text-white font-tech uppercase">LH₂ Injection Engine</h1>
          </div>
        </div>

        <!-- Quick Test Selector on Mobile -->
        <div class="md:hidden">
          <select
            class="bg-slate-900 border border-slate-700 text-xs font-mono text-cyan-300 rounded px-2 py-1 outline-none"
            [value]="twinService.activeTestId()"
            (change)="onTestSelect($event)"
          >
            @for (test of twinService.testRuns(); track test.testId) {
              <option [value]="test.testId">{{ test.testId }}</option>
            }
          </select>
        </div>
      </div>

      <!-- Zone 2: Navigation Links -->
      <nav class="flex items-center gap-1 overflow-x-auto max-w-full pb-1 md:pb-0 scrollbar-none">
        @for (tab of tabs; track tab.id) {
          <button
            type="button"
            (click)="selectTab(tab.id)"
            class="px-3 py-1.5 text-xs font-medium rounded-md transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer"
            [class.bg-slate-800]="activeTab() === tab.id"
            [class.text-white]="activeTab() === tab.id"
            [class.text-slate-400]="activeTab() !== tab.id"
            [class.hover:text-slate-200]="activeTab() !== tab.id"
            [class.hover:bg-slate-800/50]="activeTab() !== tab.id"
          >
            <mat-icon class="text-[16px] leading-none !w-4 !h-4">{{ tab.icon }}</mat-icon>
            <span>{{ tab.label }}</span>
            @if (tab.badge) {
              <span class="text-[10px] font-mono px-1 py-0.2 bg-amber-500/20 text-amber-300 rounded">
                {{ tab.badge }}
              </span>
            }
          </button>
        }
      </nav>

      <!-- Zone 3: Active Test Switcher & Action Controls -->
      <div class="hidden md:flex items-center gap-3">
        <!-- Test Run Selector -->
        <div class="flex items-center gap-2 bg-slate-900/90 border border-slate-800 rounded-md px-2.5 py-1">
          <span class="text-[11px] font-mono text-slate-400 uppercase">Test ID:</span>
          <select
            class="bg-transparent text-xs font-mono font-semibold text-cyan-300 outline-none cursor-pointer pr-2"
            [value]="twinService.activeTestId()"
            (change)="onTestSelect($event)"
          >
            @for (test of twinService.testRuns(); track test.testId) {
              <option [value]="test.testId" class="bg-slate-900 text-slate-200 font-mono">
                {{ test.testId }} ({{ test.metadata.hardwareRevision }})
              </option>
            }
          </select>
        </div>

        <!-- Import / Add Telemetry -->
        <button
          type="button"
          (click)="triggerTab('importer')"
          class="px-2.5 py-1 text-xs font-medium text-slate-300 bg-slate-800/80 hover:bg-slate-700 border border-slate-700 rounded-md transition-colors flex items-center gap-1 cursor-pointer whitespace-nowrap"
          title="Import CSV/JSON test record"
        >
          <mat-icon class="text-[14px] !w-3.5 !h-3.5 leading-none">upload_file</mat-icon>
          <span>Import</span>
        </button>

        <!-- Generate Report Button -->
        <button
          type="button"
          (click)="triggerTab('report')"
          class="px-3 py-1 text-xs font-medium text-white bg-cyan-600 hover:bg-cyan-500 rounded-md transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap shadow-sm shadow-cyan-950"
        >
          <mat-icon class="text-[14px] !w-3.5 !h-3.5 leading-none">article</mat-icon>
          <span>Dossier Report</span>
        </button>
      </div>
    </header>
  `,
})
export class HeaderComponent {
  public readonly twinService = inject(DigitalTwinService);
  public readonly activeTab = signal<string>('overview');

  public readonly anomalyCount = computed(() => {
    return this.twinService.activeTest()?.anomalies.length || 0;
  });

  public readonly tabs = [
    { id: 'overview', label: 'Overview', icon: 'dashboard' },
    { id: 'flow', label: 'Flow & Dynamics', icon: 'waves' },
    { id: 'thermal', label: 'Thermal Conditioning', icon: 'thermostat' },
    { id: 'stability', label: 'Stability & FFT', icon: 'graphic_eq' },
    { id: 'campaign', label: 'Campaigns', icon: 'compare_arrows' },
    { id: 'validation', label: 'Twin Validation', icon: 'verified' },
    { id: 'uncertainty', label: 'Uncertainty & Calib', icon: 'analytics' },
    { id: 'anomalies', label: 'Anomalies', icon: 'warning_amber', badge: '3' },
    { id: 'code_cli', label: 'CLI & Codebase', icon: 'terminal' },
    { id: 'report', label: 'Report', icon: 'description' },
  ];

  public selectTab(tabId: string): void {
    this.activeTab.set(tabId);
    const event = new CustomEvent('tab-change', { detail: tabId });
    window.dispatchEvent(event);
  }

  public triggerTab(tabId: string): void {
    this.selectTab(tabId);
  }

  public onTestSelect(event: Event): void {
    const select = event.target as HTMLSelectElement;
    if (select && select.value) {
      this.twinService.setActiveTest(select.value);
    }
  }
}
