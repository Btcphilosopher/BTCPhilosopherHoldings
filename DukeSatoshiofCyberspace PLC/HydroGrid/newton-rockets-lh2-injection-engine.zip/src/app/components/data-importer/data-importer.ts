import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';

@Component({
  selector: 'app-data-importer',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 max-w-4xl mx-auto">
      <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5">
        <h3 class="text-sm font-semibold text-white font-tech uppercase tracking-wide">
          Import Cryogenic Test Telemetry (CSV / JSON)
        </h3>
        <p class="text-xs text-slate-400 mt-0.5">
          Ingest raw experimental or simulated flight/rig records into the Newton Rockets LH₂ digital-twin engine.
        </p>
      </div>

      <!-- File Upload Zone -->
      <div class="bg-[#0b111c] border-2 border-dashed border-slate-700 hover:border-cyan-500 rounded-xl p-8 text-center transition-colors">
        <mat-icon class="text-4xl text-cyan-400 mb-2">cloud_upload</mat-icon>
        <h4 class="text-sm font-semibold text-white">Upload Test Telemetry File</h4>
        <p class="text-xs text-slate-400 mt-1 max-w-md mx-auto">
          Drag and drop your telemetry CSV or JSON file here, or click to browse.
        </p>

        <input
          type="file"
          #fileInput
          accept=".csv,.json"
          (change)="onFileSelected($event)"
          class="hidden"
        />

        <div class="mt-4 flex items-center justify-center gap-3">
          <button
            type="button"
            (click)="fileInput.click()"
            class="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-mono font-medium transition-colors cursor-pointer"
          >
            Select File from Device
          </button>

          <button
            type="button"
            (click)="downloadSampleCsv()"
            class="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-lg text-xs font-mono transition-colors cursor-pointer"
          >
            Download CSV Template
          </button>
        </div>

        @if (statusMessage()) {
          <div class="mt-4 p-3 rounded-lg text-xs font-mono"
            [class.bg-emerald-950_40]="statusSuccess()"
            [class.text-emerald-300]="statusSuccess()"
            [class.border]="true"
            [class.border-emerald-800]="statusSuccess()"
            [class.bg-rose-950_40]="!statusSuccess()"
            [class.text-rose-300]="!statusSuccess()"
            [class.border-rose-800]="!statusSuccess()">
            {{ statusMessage() }}
          </div>
        }
      </div>

      <!-- Schema Specification Helper -->
      <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5 space-y-3 text-xs font-mono">
        <h4 class="text-xs font-bold uppercase tracking-wider text-slate-200">
          Required Telemetry Schema Columns
        </h4>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-slate-300">
          <div class="p-2.5 bg-slate-900 rounded border border-slate-800">
            <span class="text-cyan-400 font-bold">time / timestamp (s):</span>
            <span class="text-slate-400 block mt-0.5">Test elapsed time in seconds from valve pre-trigger (e.g. 0.000 to 5.000 s).</span>
          </div>
          <div class="p-2.5 bg-slate-900 rounded border border-slate-800">
            <span class="text-cyan-400 font-bold">p_upstream / p1 (bar):</span>
            <span class="text-slate-400 block mt-0.5">Static upstream line pressure transducer measurement (0 to 100 bar).</span>
          </div>
          <div class="p-2.5 bg-slate-900 rounded border border-slate-800">
            <span class="text-cyan-400 font-bold">p_downstream / p2 (bar):</span>
            <span class="text-slate-400 block mt-0.5">Downstream / manifold exit pressure transducer measurement.</span>
          </div>
          <div class="p-2.5 bg-slate-900 rounded border border-slate-800">
            <span class="text-cyan-400 font-bold">t_fluid / rtd (K):</span>
            <span class="text-slate-400 block mt-0.5">Subcooled cryogenic fluid temperature from 4-wire Pt1000 RTD sensor (14 to 300 K).</span>
          </div>
          <div class="p-2.5 bg-slate-900 rounded border border-slate-800">
            <span class="text-cyan-400 font-bold">t_wall / tc (K):</span>
            <span class="text-slate-400 block mt-0.5">Manifold metal wall temperature from ungrounded Type E thermocouple.</span>
          </div>
          <div class="p-2.5 bg-slate-900 rounded border border-slate-800">
            <span class="text-cyan-400 font-bold">mass_flow / mdot (kg/s):</span>
            <span class="text-slate-400 block mt-0.5">Coriolis mass flowmeter measurement (0.0 to 1.0 kg/s).</span>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class DataImporterComponent {
  public readonly twinService = inject(DigitalTwinService);
  public readonly statusMessage = signal<string>('');
  public readonly statusSuccess = signal<boolean>(false);

  public onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (!input.files || !input.files.length) return;
    const file = input.files[0];
    const reader = new FileReader();

    reader.onload = (e) => {
      const content = e.target?.result as string;
      if (content) {
        const res = this.twinService.importCustomTelemetry(content, file.name);
        if (res.success) {
          this.statusSuccess.set(true);
          this.statusMessage.set(`Successfully ingested telemetry dataset '${res.testId}'. Switched to live analysis.`);
        } else {
          this.statusSuccess.set(false);
          this.statusMessage.set(`Import Failed: ${res.error}`);
        }
      }
    };

    reader.readAsText(file);
  }

  public downloadSampleCsv(): void {
    const csvContent =
`timestamp,p_upstream,p_downstream,t_fluid,t_wall,mass_flow
0.00,2.5,1.1,288.5,85.0,0.000
0.50,3.2,1.2,180.2,65.4,0.012
1.00,4.0,1.2,45.0,42.1,0.025
1.20,12.5,8.2,22.4,32.0,0.110
1.40,35.0,26.4,21.5,24.5,0.245
1.60,42.5,34.1,21.2,22.8,0.285
2.00,42.5,34.2,21.2,22.8,0.285
3.00,42.5,34.2,21.2,22.8,0.285
4.00,42.5,34.2,21.2,22.8,0.285
4.80,15.2,10.1,25.0,23.5,0.080
5.00,2.0,1.1,45.0,24.0,0.000`;

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'newton_lh2_telemetry_template.csv';
    a.click();
    URL.revokeObjectURL(url);
  }
}
