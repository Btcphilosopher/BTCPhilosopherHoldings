import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';

@Component({
  selector: 'app-campaign-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Top Campaign Header & Filter Bar -->
      <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5 flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <h3 class="text-sm font-semibold text-white font-tech uppercase tracking-wide">
            Experimental Campaigns & Multi-Test Repeatability
          </h3>
          <p class="text-xs text-slate-400 mt-0.5">
            Cross-run comparison across hardware revisions, environmental ambient conditions, and cryogenic subcooling margins.
          </p>
        </div>

        <!-- Campaign Filter Tabs -->
        <div class="flex items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded-lg text-xs font-mono">
          @for (camp of campaigns; track camp.id) {
            <button
              type="button"
              (click)="selectedCampaign.set(camp.id)"
              class="px-3 py-1 rounded transition-colors cursor-pointer"
              [class.bg-cyan-600]="selectedCampaign() === camp.id"
              [class.text-white]="selectedCampaign() === camp.id"
              [class.text-slate-400]="selectedCampaign() !== camp.id"
            >
              {{ camp.name }}
            </button>
          }
        </div>
      </div>

      <!-- Multi-Test Overlay Chart -->
      <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5 space-y-4">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <mat-icon class="text-cyan-400 text-[18px]">layers</mat-icon>
            <h4 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">
              Transient Mass Flow Multi-Test Overlay ṁ(t)
            </h4>
          </div>
          <span class="text-xs font-mono text-slate-400">
            {{ filteredRuns().length }} Test Runs Overlaid
          </span>
        </div>

        <div class="relative w-full h-64">
          <svg class="w-full h-full" viewBox="0 0 1000 240" preserveAspectRatio="none">
            <!-- Grid -->
            <line x1="0" y1="60" x2="1000" y2="60" stroke="#1e293b" stroke-dasharray="4" />
            <line x1="0" y1="120" x2="1000" y2="120" stroke="#1e293b" stroke-dasharray="4" />
            <line x1="0" y1="180" x2="1000" y2="180" stroke="#1e293b" stroke-dasharray="4" />

            <!-- Overlaid Test Curves -->
            @for (run of filteredRuns(); track run.testId; let idx = $index) {
              <path
                [attr.d]="getRunFlowPath(run)"
                fill="none"
                [attr.stroke]="getRunColor(idx, run)"
                [attr.stroke-width]="twinService.activeTestId() === run.testId ? 3 : 1.5"
                [attr.stroke-dasharray]="run.metadata.dataSourceType === 'SYNTHETIC_GROUND_TRUTH' ? '6 3' : 'none'"
                [attr.opacity]="twinService.activeTestId() === run.testId ? 1 : 0.65"
              />
            }
          </svg>

          <!-- Y-axis -->
          <div class="absolute left-2 top-2 text-[10px] font-mono text-slate-500">0.45 kg/s</div>
          <div class="absolute left-2 top-1/2 -translate-y-1/2 text-[10px] font-mono text-slate-500">0.22 kg/s</div>
          <div class="absolute left-2 bottom-2 text-[10px] font-mono text-slate-500">0.00 kg/s</div>
        </div>

        <!-- Legend and Quick Selector -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2 border-t border-slate-800">
          @for (run of filteredRuns(); track run.testId; let idx = $index) {
            <button
              type="button"
              (click)="twinService.setActiveTest(run.testId)"
              class="p-2.5 rounded-lg border text-left text-xs font-mono transition-colors cursor-pointer"
              [class.bg-slate-900]="twinService.activeTestId() !== run.testId"
              [class.border-slate-800]="twinService.activeTestId() !== run.testId"
              [class.bg-cyan-950_30]="twinService.activeTestId() === run.testId"
              [class.border-cyan-500_60]="twinService.activeTestId() === run.testId"
            >
              <div class="flex items-center justify-between">
                <div class="flex items-center gap-1.5">
                  <span class="w-2.5 h-2.5 rounded-xs" [style.background-color]="getRunColor(idx, run)"></span>
                  <strong class="text-white">{{ run.testId }}</strong>
                </div>
                <span class="text-[10px] text-slate-400">{{ run.metadata.hardwareRevision }}</span>
              </div>
              <div class="text-[11px] text-slate-400 mt-1 flex justify-between">
                <span>Steady: {{ run.transientMetrics.steadyStateMeanFlow.toFixed(3) }} kg/s</span>
                <span>Rise: {{ (run.transientMetrics.riseTime10To90 * 1000).toFixed(0) }} ms</span>
              </div>
            </button>
          }
        </div>
      </div>

      <!-- Campaign Statistical Repeatability Metrics Table -->
      <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5 space-y-3">
        <h4 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">
          Between-Test Statistical Repeatability & Dispersion
        </h4>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs font-mono">
            <thead>
              <tr class="border-b border-slate-800 text-slate-400">
                <th class="py-2.5 px-3">Test Run</th>
                <th class="py-2.5 px-3">Hardware Rev</th>
                <th class="py-2.5 px-3">Inlet P (bar)</th>
                <th class="py-2.5 px-3">Fluid T (K)</th>
                <th class="py-2.5 px-3">Steady ṁ (kg/s)</th>
                <th class="py-2.5 px-3">Flow CV (%)</th>
                <th class="py-2.5 px-3">Rise Time (ms)</th>
                <th class="py-2.5 px-3">Dominant f₀ (Hz)</th>
                <th class="py-2.5 px-3">Anomalies</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/50 text-slate-300">
              @for (r of filteredRuns(); track r.testId) {
                <tr class="hover:bg-slate-900/50 cursor-pointer" (click)="twinService.setActiveTest(r.testId)">
                  <td class="py-2.5 px-3 text-cyan-400 font-semibold">{{ r.testId }}</td>
                  <td class="py-2.5 px-3 text-slate-300">{{ r.metadata.hardwareRevision }}</td>
                  <td class="py-2.5 px-3 tabular-nums">{{ r.targetInletPressureBar.toFixed(1) }}</td>
                  <td class="py-2.5 px-3 tabular-nums">{{ r.overallUncertainty.fluidTemp.nominal.toFixed(2) }}</td>
                  <td class="py-2.5 px-3 tabular-nums font-semibold text-white">{{ r.transientMetrics.steadyStateMeanFlow.toFixed(4) }}</td>
                  <td class="py-2.5 px-3 tabular-nums">{{ r.transientMetrics.steadyStateFlowCV.toFixed(2) }}%</td>
                  <td class="py-2.5 px-3 tabular-nums">{{ (r.transientMetrics.riseTime10To90 * 1000).toFixed(0) }}</td>
                  <td class="py-2.5 px-3 tabular-nums">{{ r.stability.dominantFrequencyHz.toFixed(1) }}</td>
                  <td class="py-2.5 px-3">
                    @if (r.anomalies.length > 0) {
                      <span class="text-amber-400 font-bold">▲ {{ r.anomalies.length }} events</span>
                    } @else {
                      <span class="text-emerald-400">● 0 none</span>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class CampaignViewComponent {
  public readonly twinService = inject(DigitalTwinService);
  public readonly selectedCampaign = signal<string>('ALL');

  public readonly campaigns = [
    { id: 'ALL', name: 'All Campaigns (6 Runs)' },
    { id: 'CAM-LH2-ALPHA', name: 'Campaign Alpha (Rev B)' },
    { id: 'CAM-LH2-BETA', name: 'Campaign Beta (Rev C)' },
    { id: 'CAM-LH2-BENCHMARK', name: 'Synthetic Benchmark' },
  ];

  public readonly filteredRuns = computed(() => {
    const all = this.twinService.testRuns();
    const camp = this.selectedCampaign();
    if (camp === 'ALL') return all;
    return all.filter((r) => r.campaignId === camp);
  });

  public getRunColor(index: number, run: any): string {
    if (run.metadata.dataSourceType === 'SYNTHETIC_GROUND_TRUTH') return '#f59e0b';
    const colors = ['#06b6d4', '#3b82f6', '#10b981', '#ec4899', '#8b5cf6'];
    return colors[index % colors.length];
  }

  public getRunFlowPath(run: any): string {
    const maxT = 6.5;
    let path = '';
    for (let i = 0; i < run.telemetry.length; i++) {
      const f = run.telemetry[i];
      const x = (f.timestamp / maxT) * 1000;
      const y = 230 - (f.massFlow.value / 0.45) * 210;
      path += (i === 0 ? 'M ' : 'L ') + `${x.toFixed(1)} ${y.toFixed(1)} `;
    }
    return path;
  }
}
